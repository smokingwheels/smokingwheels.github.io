/** 
 * Smoking Wheels....  was here 2017 wguqjkvlgdljemkfytllhxjfnbrlajbgyyqqshcmyrcqjceh
 * Smoking Wheels....  was here 2017 ngywqqwyagshzeycevpujdlvdeqxdxjhigstsmeeanwycbje
 * Smoking Wheels....  was here 2017 elhjpekqvnxxrlpqhdpwihmdgpuqzsvrrcpialyikehiogbf
 * Smoking Wheels....  was here 2017 tekieromryqbhpollhgcigvieqzsukyelhgzcialoboehoao
 * Smoking Wheels....  was here 2017 jcbdocrrwuusddhizepbwgcyltlkesmxgaapopfdhydyezen
 * Smoking Wheels....  was here 2017 jbhkgqjswoqevyojpwztpreqtrofyuifyqkjlxsmovpkgwur
 * Smoking Wheels....  was here 2017 melcwrmhmzmafbiycuwhmgdjdlayewvrstgsygtpryypwuiw
 * Smoking Wheels....  was here 2017 nvzhlydkrbcyhuvrsnbbsxijxgspfojdxgoflsbaduiuonof
 * Smoking Wheels....  was here 2017 qrtmdirftbialrohtzqttukcmrvmqqsrefrvsvklsddofdka
 * Smoking Wheels....  was here 2017 fnugkcsfeljmfogzxgxfhjeisktcfevqkbbrqfxvkzbqvxdw
 * Smoking Wheels....  was here 2017 xnjnxpcdtypylmvaatiqhitypkfgbmzpskpemvzkmoaaulgq
 * Smoking Wheels....  was here 2017 pbblroxxmptcfsobgaukypneizbyncqlncgzqwepkiebqokk
 * Smoking Wheels....  was here 2017 ktqlvwoupqsavwyxzzhfsibnmqnmcwmfmhjavsieacygfgrn
 * Smoking Wheels....  was here 2017 tlddwuqeqoryxtsqvucxgzfrvbzisvohkiljacqbhvzjoxen
 * Smoking Wheels....  was here 2017 ggwlmrywjczlejvpstvrogdpihcjjhcfnvinjyimmtflbanh
 * Smoking Wheels....  was here 2017 upjnpgruuhjgvcmkumewvbcnhovnkunwdrbbjldxdkvtfkiy
 * Smoking Wheels....  was here 2017 mbkuklcdeitlclfxkyhfmpuwejhcjepiyzwysavaymfuyeqt
 * Smoking Wheels....  was here 2017 tnbvklxjbshhpftceejofhakulyremhyucigijnwzbckfprj
 * Smoking Wheels....  was here 2017 fcqqhrwgdgjhdnblboacauycdvlyuawhvsgmkjppmhhokfxo
 * Smoking Wheels....  was here 2017 ueqhyvdslwsfvqilcszfbcvdlssaqjuflqrflhrrzsbocwbn
 * Smoking Wheels....  was here 2017 ojwfqvbahvedydczuojnvijzgqxdehtuhaxicmovgcuxdpdm
 * Smoking Wheels....  was here 2017 ynjcuwgodqzgcucerekzyzjijhkuixujgflbiskagkdknsid
 * Smoking Wheels....  was here 2017 pulucjobtbnfbshhrxsslrzfstzvelcnkvcuivnmgxacquef
 * Smoking Wheels....  was here 2017 joqlmzcndcmrzdwyylzdlkmupemfyoedfuydocoqucqgapix
 * Smoking Wheels....  was here 2017 kktnfseepytsdsjzwpiwmhonodbhhzshhegztxjgqrjjogwm
 * Smoking Wheels....  was here 2017 cfuqsslkqcnqcennbnawevaehjenavtgnjnouxzgurxfgaxp
 * Smoking Wheels....  was here 2017 cdbrqluazjfysqgwkppgnrzqwvmseimsazqfxcwxmjdwlmaa
 * Smoking Wheels....  was here 2017 hmduzngyqslkbjvpbkxkstufntwxddklfwopnqophfgotlyw
 * Smoking Wheels....  was here 2017 uyulyyejxjfblxtpkvxaegbhtsoikagpsfpqjyxcxyswyyom
 * Smoking Wheels....  was here 2017 zibfyvgthvqekdsycaxzrprqijyoxzzlkijlksbjjpcnchfm
 * Smoking Wheels....  was here 2017 nvfbsrgxowdgvbsyzinlbnrehurjplvpkvomvxipzkkppbhr
 * Smoking Wheels....  was here 2017 htwbedjrrmjduazffjlvpwmexertxwhxdqgjbqjgewshzcpd
 * Smoking Wheels....  was here 2017 lstsoewizxhvonapezvtsxrbqadaicclgwuzukzcusofbjbg
 * Smoking Wheels....  was here 2017 iqxpgxjixpbotkmdnjwcdbcngdlstefppvqnzwibuyndxgxo
 * Smoking Wheels....  was here 2017 pqrqavukgjbxftlgdwdcuywoukhnflwxifrjwzsilunawhry
 * Smoking Wheels....  was here 2017 dboauqenbdzqywbmcblcwoikneppalofuwvewwukgutemhbm
 * Smoking Wheels....  was here 2017 cnjcuexvnguuigwsxvvtvbcnyxncuazqrwnwsbjaarreqiam
 * Smoking Wheels....  was here 2017 vxdnkspwedoqxtpycjpykxbouimqidenwrenhdocskwsjrvp
 * Smoking Wheels....  was here 2017 aiegjrcivntqnleppygxmtgocldzseikmvrqvctwqhhwzxxp
 * Smoking Wheels....  was here 2017 odzjqsmelmbrgqwfogpyhncsdnkcgsxexfauucnugtdybvbp
 * Smoking Wheels....  was here 2017 nakijtdqhekskwdridsugldlkaminmsxuanywptojpuklnfz
 * Smoking Wheels....  was here 2017 iumtcardxexboysborwhdxhnrsuejpqyznsfzgnfzuxcfhqh
 * Smoking Wheels....  was here 2017 qplolxxlaezfoxqrdipqvqpwzpylwjzwrkjzkafxiplzrquj
 * Smoking Wheels....  was here 2017 hvxxjdalqfizldbdgrreoomtnywciiemfooynbjcymojklki
 * Smoking Wheels....  was here 2017 maqedpglbmxjpcmhfofqtunpveulihzzgaoaauyopfrtgtlm
 * Smoking Wheels....  was here 2017 odrbcniwunuqnrrfrdlwdwodsccbrijprfyhxzyehulygvel
 * Smoking Wheels....  was here 2017 dhhkaiakobljcxpgouxaqkrhdrkqlsozqtmfilufgmtzshaa
 * Smoking Wheels....  was here 2017 dubjvrmbkbohiblayclnmihjjeshzbaymnfkumbebtvdhxuj
 * Smoking Wheels....  was here 2017 shuktnbbpvalqtthhybabwzsxcefweopwqkvylqrlibxtskt
 * Smoking Wheels....  was here 2017 frmdeaivpwacntefembkdlpdoedzxbbgslrotaptkfdceccu
 * Smoking Wheels....  was here 2017 hbklwqebfwyvvducnbywqtgoikjkebuocptbkfhpesytwnki
 * Smoking Wheels....  was here 2017 vvfntbrulvmjqftolgpttrgflaskasghmysykdirjgrcmxzl
 * Smoking Wheels....  was here 2017 yopszefepbotgnpkiazsylholojjzwenkqvcjfpsqqsrtfwm
 * Smoking Wheels....  was here 2017 bdptcgksczifhwatvllsxmeibsstxnnrvzqthferbuuhtugb
 * Smoking Wheels....  was here 2017 vspmsqcdtkfjojzyvwmwplzlinmkvbnhwrygjzltwatyxeqz
 * Smoking Wheels....  was here 2017 bqbbvbjjogwychunlyyoeiddnfogdzqfxougbtykovvxrfti
 * Smoking Wheels....  was here 2017 youxqkopvvfzgevkcnumdgewdhdrjdqootmqbypkyxktyyom
 * Smoking Wheels....  was here 2017 xhwroyijaqltpvxpktkmerakxmodinmpupophfnragdfuria
 * Smoking Wheels....  was here 2017 mzogianixkztzjynfzgufgsqxupkdnkzqtuozozkaezimymt
 * Smoking Wheels....  was here 2017 qakuwjfnmclvlbfstvesmzqvimcocqwoocgcocrdldbjrpvu
 * Smoking Wheels....  was here 2017 mafsjyubbzuyileahffakzkktafwusqjdsfetikndwvxdsgm
 * Smoking Wheels....  was here 2017 lwzqiwwmcoekfjpopeqmrtxdwfluauruhagxmwhnakyrynbk
 * Smoking Wheels....  was here 2017 bqbmkpgmkpasxwkpldajhxeytzjfwefjeocsyrsjkyirlqsk
 * Smoking Wheels....  was here 2017 iszlpvbaybzrmgwvatcaklobqpzbrlsadhvgpyfouzdgevyp
 * Smoking Wheels....  was here 2017 htnwamshafzigckasuzcmmtxaokrzjytwitkecstxiuwafsg
 * Smoking Wheels....  was here 2017 kpsketsudnfyvfvhemymfnohsqborbwyezkjpvhzvxzjabga
 * Smoking Wheels....  was here 2017 hjwzuczgatbzaqcygdmjoebcruqmttsfgxombbhjuaotmxcs
 * Smoking Wheels....  was here 2017 vmnttdqpsxeixrkqcjleslqoehanpcyilyglzajlhcugaqwl
 * Smoking Wheels....  was here 2017 dmmdhvzbmgoyuxhdccwmdmxdtpkxsvillhvddbhybzalkfrn
 * Smoking Wheels....  was here 2017 qhuswkrcvghcgdkpxkafmrsodnedabvwcfutkxgtfoxctaqo
 * Smoking Wheels....  was here 2017 xasmdfnlmqwjdkuhkrlouuevkzbbnbqfplxqanodxelgjphj
 * Smoking Wheels....  was here 2017 xavncaranlwmnbrwsnzxdsqcshyrpkhhfuhllbvpsgtdwtjc
 * Smoking Wheels....  was here 2017 syxgyslcexhmrpmdfvpxcrrvryzgtxnfsjediyytjpfianwa
 * Smoking Wheels....  was here 2017 uqzicmlcymfrfwaeorqlhafuzqpiwpghxodurwyqwdppxfyt
 * Smoking Wheels....  was here 2017 rgjrguoupzeozygjqnqrrngxqjlrzvtdyzywqtflnesywkde
 * Smoking Wheels....  was here 2017 idplkhxbdjtxacihoxkambgkzkmhlcnqfnrzrukrueurmxeh
 * Smoking Wheels....  was here 2017 wxmzsxuewwwtqxvttsyddvutmhwnvggujhpcnlizmxfipubn
 * Smoking Wheels....  was here 2017 qlazqvvpgatkmelwvcoxihrqxrzvyjyzgrggckcjpjrpfiyk
 * Smoking Wheels....  was here 2017 iwojxnxabntihzezrkvmacbcfqoawtvubhkzqnbbjucqscjv
 * Smoking Wheels....  was here 2017 vopgkqclilojepfrlgmgkehgtjlcxxjbdzevnbvmiqqprxbv
 * Smoking Wheels....  was here 2017 gcybjcubhydmmpbtmoqxztzqzkvkrshxdwuumkgjgsscwvzu
 * Smoking Wheels....  was here 2017 zkrlgdohmooatvljmjnijfyyrmekzeqqyjvxmhlsczzxldjg
 * Smoking Wheels....  was here 2017 qpahuehyqbilvhjvicsrogicvocwwqowsbbrtpurfskzrlsd
 * Smoking Wheels....  was here 2017 eaouvvaxukcothascjaitvmktxnwsqokuvnsrnvtajcrdmtl
 * Smoking Wheels....  was here 2017 qhchrdflfvtkxlxwfblzkdafxbqrbzkjvvnyynlrismmrjko
 * Smoking Wheels....  was here 2017 mirmsejzjwmgvntkighneotjbswuttbbsjqmpgujetgeikzb
 * Smoking Wheels....  was here 2017 ifofrmkgbhsqipnrhjcbbuvsgwvavftdqcpttrdbusivldyu
 * Smoking Wheels....  was here 2017 bhhsmqlfiabhnymfgzsafupotumjqzxjwwmkwzegqcwqqkzv
 * Smoking Wheels....  was here 2017 vgrjirtcjinhrecwqzccdsqhazactviwewojrorqorgfqfco
 * Smoking Wheels....  was here 2017 zxutssajssfxkbcuanpembvsvduuzuzaikktccvdokfgqwnn
 * Smoking Wheels....  was here 2017 ekwwhecsdzoqormgiysjfkhrginekgciocuyjpyavoqwvzto
 * Smoking Wheels....  was here 2017 idmvbvadqaghehkwsvhcouimmtchksdsfwurxdpsyqrgxjnv
 * Smoking Wheels....  was here 2017 nrladnfvmdewonlnndjaxippbxsllzvfxuqtkgszrjuzqauo
 * Smoking Wheels....  was here 2017 extdalhgfwnrhdhfkxebalyrsotcldeengykvoitzsqvbhtl
 * Smoking Wheels....  was here 2017 yzsalcacowrfggxjfoiivxltnsxclmjfgwlzjawgdacvpszg
 * Smoking Wheels....  was here 2017 rgxwhcpknejhmcnnerpgnomzrocltoyelnffmuwxrrjgsddc
 * Smoking Wheels....  was here 2017 mjcbvjiijbmxggqnpezmoqrwtqmkyfpctinxwjgmjmwpipfi
 * Smoking Wheels....  was here 2017 vdihlewiqzdjgoamddvypovcmsmmwlijbrygmjbyflgrlkln
 * Smoking Wheels....  was here 2017 iswkvwadbsvdebosszrtqzbqvstnpqjomdgrntsmlulnkcho
 * Smoking Wheels....  was here 2017 vlioafxtrgfbfbovkghhwwutdygnlhemlpmukrtopzpjvnnl
 * Smoking Wheels....  was here 2017 malfdbwitvddpdmqqxsgskovxxctzgmhngynwqbxlveumrdp
 * Smoking Wheels....  was here 2017 sggzqqnjtxwrybbhbagoxafqvhssaoghrjeavgtmzhuomyho
 * Smoking Wheels....  was here 2017 chctgjtpmhtdcxgbnymhkkydzdufrnubzqzrnnenmqkrcvnf
 * Smoking Wheels....  was here 2017 ollsxxqyxzmjcahoejdyimznprgigrmmwxjekoylliekzenp
 * Smoking Wheels....  was here 2017 glefvgoqjdzigxrqkbhbflbhfkgfhwdoygrjcvxzqdmiwahc
 * Smoking Wheels....  was here 2017 nbhzkobdhjkjejdkvggqtsxdocfnrdrscdklqaedbbbexsbh
 * Smoking Wheels....  was here 2017 albvkgbfmiezsnqdkgnuvytzrruylvjnndjuebbczitaksia
 * Smoking Wheels....  was here 2017 qacatzptybyxwqlmerxysdwcumxoxlruncpcedghylucxyui
 * Smoking Wheels....  was here 2017 nicvqtdzyvrgahahpkmrulwylytpqvjqtekfjrnmrepygklq
 * Smoking Wheels....  was here 2017 bheansekacmfsgbphpnzvhqgkvsqnaikdsihqjbqfmtinkol
 * Smoking Wheels....  was here 2017 waplbhpswpvjuqotcpozsigxqdmlpixrujeufddytqhhamnr
 * Smoking Wheels....  was here 2017 vwyfheownijmisujfzjasodfldzadingczyiofkwxchdjndj
 * Smoking Wheels....  was here 2017 cmyvihjchpapqbfharaweeupjgiquvwhsrzujyrdirejinjx
 * Smoking Wheels....  was here 2017 bsrwrvpwqvyyhmnpdvvhxnducizwjwacnvtiocdsdhrtaulv
 * Smoking Wheels....  was here 2017 irlgzgfwjuncdaspkshouigsrgqlxudgpcdkjnbvngritxvz
 * Smoking Wheels....  was here 2017 vutdgefcknnvfzbybbgabonpjjektcspkhdpgmdxaaiicrhm
 * Smoking Wheels....  was here 2017 rqlxrpztdetdwyakkqrhdjoysctbmrmgoobvwjdrjjbjxdur
 * Smoking Wheels....  was here 2017 gbngqsdhyiliqthdcqyjteelkguxxnknyhlhexedqgnefqnc
 * Smoking Wheels....  was here 2017 egibxwolsszykjxlblnivrmcnuzsdyuarbbjkyrmayrtiraq
 * Smoking Wheels....  was here 2017 knillviejicrgfayjphpovwahyfnlnaoeuyrztedbzrlxdak
 * Smoking Wheels....  was here 2017 anjwjmurejqrktflmafvkuxuffsplbwhboldpspxnaysralr
 * Smoking Wheels....  was here 2017 kcmyeanlsjucovdazwpxczlbckvnyqimftbygoyrkdcjuqoc
 * Smoking Wheels....  was here 2017 fkzppxlerczolnubulaandquxlhzanpsuapkberrznclnpvl
 * Smoking Wheels....  was here 2017 iujynuqvcnwvecldzkfnydvgxpyczifxdfdhotjjurdelraw
 * Smoking Wheels....  was here 2017 wwmkfqmqgxjwcenbapictepvrjabluvcykwkjtvnnkodlxcs
 * Smoking Wheels....  was here 2017 goirbpnbqsrasnuynenrrsuiwnxleamqbblznvfagqccnqgn
 * Smoking Wheels....  was here 2017 cyfpudqvasfuyefeinljrloqpzgbiijdrspjdxvdfqrbbkad
 * Smoking Wheels....  was here 2017 hjrjixywkwpyumagqewoygfzbcawdgakchkfrfjixxkhoacr
 * Smoking Wheels....  was here 2017 znmixvukbmtopzrbucuzxijwuhjefpcnzxclxephdfskxomm
 * Smoking Wheels....  was here 2017 oftfzdvxmbxvymzsljnlhdxzoismklqvgxhfslqzxnibehkc
 * Smoking Wheels....  was here 2017 qoswfgvclgliqbvnljqdaixhifsqtbvzbytxhzxrkccjrvil
 * Smoking Wheels....  was here 2017 daxlpvyzzdawuanbasxmiwtzlehoqbessvnedyytglfoyyan
 * Smoking Wheels....  was here 2017 edejgvoriyoksxmfmhjdqyzpispqoflfytwyxtqzdgdfwskt
 * Smoking Wheels....  was here 2017 cunhskfsaefhyomameiyryouvpbijpnuobkipebhcpmbmltr
 * Smoking Wheels....  was here 2017 pcgcravvtnlzizmwyuhcipmnwvjldnszsjvujbqyjreddqnc
 * Smoking Wheels....  was here 2017 olxyajlxqbxhznsiytdawuebupkafnmsvogyrpwjmzktkflf
 * Smoking Wheels....  was here 2017 cmhgzjlgwzmgdtrfxxuirufubljgdkozntyrfhshfhojbdog
 * Smoking Wheels....  was here 2017 pakrbemgyujdmlbrljqxnylnlcquuhxfqhleytfsooivftzx
 * Smoking Wheels....  was here 2017 rfpbwgirrgzltrxzmnfzhyadzoyhekuykvoubxtuubqdfpix
 * Smoking Wheels....  was here 2017 hljqkgdmbjzzbtjtdagxgugwxcewqirbdfigzaxzkhqopnfl
 * Smoking Wheels....  was here 2017 niotwegvjihusfzwurviuptgseluuygpmobkmlobeztpforu
 * Smoking Wheels....  was here 2017 usecrdhgcsbchxljbrhdqvkxfogolfoxihgklxuydeqcdayo
 * Smoking Wheels....  was here 2017 rsmoopclzftmqvupwibntehvjggypmupwztrciawmbgbqlmp
 * Smoking Wheels....  was here 2017 dtcgmgujbvzrujedihbwhntgmlizrilnknowxxthudstjraz
 * Smoking Wheels....  was here 2017 gktqpasfqustcbdwwkgwsdkqbsqyfngtpaywnbyytelrctob
 * Smoking Wheels....  was here 2017 lonijcmmdqczerkwbvyitkdrvsqjbdfpjwnvylqumeeqxzil
 * Smoking Wheels....  was here 2017 ijrgnxywjcowthxlvxrmjzzjvozbfnmsvrbeibeadjtrexux
 * Smoking Wheels....  was here 2017 udunzceijeseyfyfihhtrvkxijpabeqwjhpndafchgjbkjrp
 * Smoking Wheels....  was here 2017 znppyrpdjcoydayaxutrfextutqmexifpwkubuptsolillyv
 * Smoking Wheels....  was here 2017 hjfcxutrwjfmunqyfpkhqjjqbjnbkvpbmtbecbkzjiqfjjxf
 * Smoking Wheels....  was here 2017 ivxxmvnsqschvtbhdbuqxdymbgymtfqzbpiakuayotwunuyp
 * Smoking Wheels....  was here 2017 ahegsoaesexehajsvurfflypdqutoqxvufgzkcadtjihmkwa
 * Smoking Wheels....  was here 2017 mixlswpiizncmxcaqqcpakzitbfelxfthudzwmhgtxkhakpw
 * Smoking Wheels....  was here 2017 cvaezywpapdkzeyigtksanxmqfrhfbmzkroesoxgojuogzks
 * Smoking Wheels....  was here 2017 nyxiffqrnueoqyyxnncsekvzwcvwxkyfimgycigklajcmttk
 */
package net.yacy.search.index;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import org.apache.solr.common.SolrInputDocument;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.Condenser;
import net.yacy.document.Document;
import net.yacy.document.LibraryProvider;
import net.yacy.document.TextParser;
import net.yacy.document.VocabularyScraper;
import net.yacy.kelondro.workflow.WorkflowProcessor;
import net.yacy.search.schema.CollectionConfiguration;
import net.yacy.search.schema.WebgraphConfiguration;
/**
* convenience class to access the yacycore library from outside of yacy to put files into the index
*
* @author Michael Christen
*/
public class DocumentIndex extends Segment {
private static AnchorURL poison;
static {
try {
poison = new AnchorURL("file://.");
} catch (final MalformedURLException e ) {
}
}
private BlockingQueue<AnchorURL> queue;
private final Worker[] worker;
private CallbackListener callback;
private int timezoneOffset;
static final ThreadGroup workerThreadGroup = new ThreadGroup("workerThreadGroup");
public DocumentIndex(
final File segmentPath,
final File archivePath,
final File collectionConfigurationPath,
final File webgraphConfigurationPath,
final CallbackListener callback,
final int cachesize,
final int timezoneOffset)
throws IOException {
super(new ConcurrentLog("DocumentIndex"), segmentPath, archivePath,
collectionConfigurationPath == null ? null : new CollectionConfiguration(collectionConfigurationPath, true),
webgraphConfigurationPath == null ? null : new WebgraphConfiguration(webgraphConfigurationPath, true)
);
this.timezoneOffset = timezoneOffset;
super.connectRWI(cachesize, targetFileSize * 4 - 1);
super.connectCitation(cachesize, targetFileSize * 4 - 1);
super.fulltext().connectLocalSolr();
super.fulltext().setUseWebgraph(true);
this.callback = callback;
this.queue = new LinkedBlockingQueue<AnchorURL>(WorkflowProcessor.availableCPU * 300);
this.worker = new Worker[WorkflowProcessor.availableCPU];
for ( int i = 0; i < WorkflowProcessor.availableCPU; i++ ) {
this.worker[i] = new Worker(i);
this.worker[i].start();
}
}
class Worker extends Thread
{
public Worker(final int count) {
super(workerThreadGroup, "query-" + count);
}
@Override
public void run() {
AnchorURL f;
SolrInputDocument[] resultRows;
try {
while ( (f = DocumentIndex.this.queue.take()) != poison ) {
try {
resultRows = add(f, DocumentIndex.this.timezoneOffset);
for ( final SolrInputDocument resultRow : resultRows ) {
if ( DocumentIndex.this.callback != null ) {
if ( resultRow == null ) {
DocumentIndex.this.callback.fail(f, "result is null");
} else {
DocumentIndex.this.callback.commit(f, resultRow);
}
}
}
} catch (final IOException e ) {
if ( e.getMessage().indexOf("cannot parse", 0) < 0 ) {
ConcurrentLog.logException(e);
}
DocumentIndex.this.callback.fail(f, e.getMessage());
}
}
} catch (final InterruptedException e ) {
}
}
}
/**
* get the number of pending documents in the indexing queue
*/
public int pending() {
return this.queue.size();
}
public void clearQueue() {
this.queue.clear();
}
private SolrInputDocument[] add(final AnchorURL url, final int timezoneOffset) throws IOException {
        if ( url == null ) {
throw new IOException("file = null");
}
        if ( url.isDirectory() ) {
throw new IOException("file should be a document, not a path");
}
        if ( !url.canRead() ) {
throw new IOException("cannot read file");
}
Document[] documents;
        long length;
try {
length = url.length();
} catch (final Exception e ) {
length = -1;
}
InputStream sourceStream = null;
try {
	sourceStream = url.getInputStream(ClientIdentification.yacyInternetCrawlerAgent);
documents = TextParser.parseSource(url, null, null, new VocabularyScraper(), timezoneOffset, 0, length, sourceStream);
} catch (final Exception e ) {
throw new IOException("cannot parse " + url.toNormalform(false) + ": " + e.getMessage());
} finally {
	if(sourceStream != null) {
		try {
			sourceStream.close();
		} catch(IOException e) {
			ConcurrentLog.warn("DocumentIndex", "Could not close source stream : " + e.getMessage());
		}
	}
}
final SolrInputDocument[] rows = new SolrInputDocument[documents.length];
int c = 0;
for ( final Document document : documents ) {
	if (document == null) continue;
final Condenser condenser = new Condenser(document, null, true, true, LibraryProvider.dymLib, true, true, 0);
rows[c++] =
super.storeDocument(
url,
null,
null,
null,
null,
document,
condenser,
null,
DocumentIndex.class.getName() + ".add",
false,
null,
null);
}
return rows;
}
/**
* add a file or a directory of files to the index If the given file is a path to a directory, the
* complete sub-tree is indexed
*
* @param start
*/
public void addConcurrent(final AnchorURL start) throws IOException {
assert (start != null);
assert (start.canRead()) : start.toString();
        if ( !start.isDirectory() ) {
try {
this.queue.put(start);
} catch (final InterruptedException e ) {
}
return;
}
final String[] s = start.list();
        if (s != null) {
AnchorURL w;
for ( final String t : s ) {
try {
w = new AnchorURL(start, t);
if ( w.canRead() && !w.isHidden() ) {
if ( w.isDirectory() ) {
addConcurrent(w);
} else {
try {
this.queue.put(w);
} catch (final InterruptedException e ) {
}
}
}
} catch (final MalformedURLException e1 ) {
ConcurrentLog.logException(e1);
}
}
}
}
/**
* close the index. This terminates all worker threads and then closes the segment.
*/
@Override
public synchronized void close() {
for ( @SuppressWarnings("unused")
final Worker element : this.worker ) {
try {
this.queue.put(poison);
} catch (final InterruptedException e ) {
}
}
for ( final Worker element : this.worker ) {
try {
element.join();
} catch (final InterruptedException e ) {
}
}
super.close();
}
public interface CallbackListener
{
public void commit(DigestURL f, SolrInputDocument resultRow);
public void fail(DigestURL f, String failReason);
}
}
