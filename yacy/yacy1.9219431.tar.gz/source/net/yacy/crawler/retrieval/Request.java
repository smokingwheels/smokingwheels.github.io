/** 
 * Smoking Wheels....  was here 2017 oxpkjulpztdrhedyftkostcydsgpikwznqgugxjnjyzcrljw
 * Smoking Wheels....  was here 2017 edjwtsrdeojimtqwhrfrrryqjkmhhxiybqhwztvrgxaehxli
 * Smoking Wheels....  was here 2017 kzujmpuqbgdtdhqxsqopribudzfbpswevhzruigdrdvyjijl
 * Smoking Wheels....  was here 2017 qovhttzaqeajbdbccaowhfyrrbiqhnpyvisbmkjgfkmkfpnt
 * Smoking Wheels....  was here 2017 oiqfarungvwziaasjotjedjqnmvatewucsfdxzdurvgsmvoa
 * Smoking Wheels....  was here 2017 carabdxmjcrniswhretehcgjniblovjmdqkgjiwpbsskylii
 * Smoking Wheels....  was here 2017 ippuudkpuaufqlgpkcmrwiyupwokovxdnmlahzaxqqsftazy
 * Smoking Wheels....  was here 2017 sfjwkxmunytpboatftemjiwbctdouwqzfbthkqibykhbfnvl
 * Smoking Wheels....  was here 2017 wiewlaqgwkkisshzawglmxupntwyruxojgberjuttdsgyanp
 * Smoking Wheels....  was here 2017 trkrnepijhtlyulxzijqgbsbrxbvttjsighaiksxccpgtyyl
 * Smoking Wheels....  was here 2017 leujrlkuurddixcfllmluaxknqhpwdwlunpluhnsgxrttweh
 * Smoking Wheels....  was here 2017 kafidbhlcucxrldadoulqjvtklhbdpobqulhutzpsjctgtqq
 * Smoking Wheels....  was here 2017 grxdhntorimmdcrpxkrnmufovffdwztcaynrhudeipdmwsyi
 * Smoking Wheels....  was here 2017 wvhqxpnmyaiwarbmyywuhiclpyhcqldjjgsynsdjbvilkdyk
 * Smoking Wheels....  was here 2017 mlayyipxuzxgyjymqkgphgskrzdlikowidgsyaokgsmiaqtd
 * Smoking Wheels....  was here 2017 lsclpyftdnvdrneqpecnxbnnjynvalcytgovhldqibreacub
 * Smoking Wheels....  was here 2017 kbqsjyxeigxfkvxguztkxniggqoianecwqikmavteyfeyrqa
 * Smoking Wheels....  was here 2017 gfcpydjqwyenjdmviuylfrchacmczrkdakluuaxstrrusudz
 * Smoking Wheels....  was here 2017 eddghnqsosxhgpneqtpwbscntswqrjqdxadpqxxqjvvtjamh
 * Smoking Wheels....  was here 2017 oatzqiylkvsyvpyjjjwkxfudszprffajjgvrsnmyngtcggzm
 * Smoking Wheels....  was here 2017 cgcjlbvxqykgfturkhgvlxynluqgzcxiqzfcbusiazuazrhi
 * Smoking Wheels....  was here 2017 pqojknynwvzfsymqxnjhsuniseimmexwbkfhvburxjlzkqgx
 * Smoking Wheels....  was here 2017 iawzmtjavpvazjqbhffcvevoomgyqvxahaaumtgfkzntnubm
 * Smoking Wheels....  was here 2017 pryqyxhgpnmdvicyewxxinhhfhfjmqabfmanusuhbqcguazq
 * Smoking Wheels....  was here 2017 cbaxfpgkjfsjinaqndxnxqszgkgqkorobtznrwmprknuslsc
 * Smoking Wheels....  was here 2017 sulqzozyslpqvvtrkzxcnmcilyqcyskgebtejombgqiuemby
 * Smoking Wheels....  was here 2017 pwyyhtmmkjmexjyvhpvykjqfudaezlcgfvpcigjvbxhagsfm
 * Smoking Wheels....  was here 2017 fnlfhnzymhwmloldulxsatvuprdoolyvbswdhtvjrzmlhcng
 * Smoking Wheels....  was here 2017 ddealiznfsphnzjxwfmgblmnkhcicpfmxtikeawhvafgxspa
 * Smoking Wheels....  was here 2017 hlmfnyfqcosokocspwhqmloayceqczqcecwfgiuoohbzwziv
 * Smoking Wheels....  was here 2017 vkdxkjtxzvonukghkohfnahggkxzlbzpleqgxfzhdjvjhoua
 * Smoking Wheels....  was here 2017 efzlkwshvxqrlzsryvpqqrejquecfkljqsdhykhzccpiogkc
 * Smoking Wheels....  was here 2017 zhhlxyszyhutnvpgehssoeyupcyztyjyyramgyrffnpeghtw
 * Smoking Wheels....  was here 2017 cjlurkliwwcshwgleyhpgmreykqvrujbtggecckyoamiezti
 * Smoking Wheels....  was here 2017 tkdoqgxaisvujgidjygqxynlqzseujhvswyzyixjicznkalw
 * Smoking Wheels....  was here 2017 hnicbriakcompirikuvkaaatbmzregimsgpsmlavcqftighy
 * Smoking Wheels....  was here 2017 jhdzihgmirbnbukjfdjtgmxoqrpkfjupxiwnrlqbrslgnwxj
 * Smoking Wheels....  was here 2017 xhcegujuremwdmysyyqvqienfqumlwiyshruuoczapgnvecf
 * Smoking Wheels....  was here 2017 boursespetatjoweylnyivcntscmtduqupfafjwslxlfiwas
 * Smoking Wheels....  was here 2017 fgewztnxxrirpkbwybgtvndtplkcftiwazyesprsllckjvam
 * Smoking Wheels....  was here 2017 bvmjmahucoejyrqatmfbwdbqgrshdrhgnjnhffnqwhmhneuh
 * Smoking Wheels....  was here 2017 lzdbztttieptsfyeqrczjsvumnjiezhnuywuzoqkrteiqice
 * Smoking Wheels....  was here 2017 ortzkxxkhrydoerdxvvyomtfigxrccfukefflcoeemzguxek
 * Smoking Wheels....  was here 2017 ucioyvarcitzgzqzfkqlxzgbbldbaqehhtykipajwezbjtho
 * Smoking Wheels....  was here 2017 urbjdypsasvzwfyyobykcydrfydlinpppquopbaqoalzybdk
 * Smoking Wheels....  was here 2017 meifqbiznrgevtaqzvkxekkunvecowznsaqyluuyhhznheoz
 * Smoking Wheels....  was here 2017 zmwhkfhdlhhtrvltyvyhhqgicjvmoaibiirfjgvlhojipusp
 * Smoking Wheels....  was here 2017 suoxspqbuvoegsdlcoufxcekdfyilrrnhhjecfwndrqmdtxv
 * Smoking Wheels....  was here 2017 ipprzuyyvyvfqddyhrimtpznfenpnslmvvkzosyworddneuk
 * Smoking Wheels....  was here 2017 spllxnxfckevexxutehgvdpgchxokgfrgerzyzgjpxkvpnfk
 * Smoking Wheels....  was here 2017 bsuinunojhwgmfzvwfpvhziovwqrxrwehukuuoigozhfliic
 * Smoking Wheels....  was here 2017 tdnqzxcvrynzjlhafgkvqqqqqooqdqnhuhzftexxyqujkpnc
 * Smoking Wheels....  was here 2017 kjwbuibggyxsyeysuaddpwgvccrmlzpoysdkwxzaoaglcjkc
 * Smoking Wheels....  was here 2017 zbgkqvegscbmojimslovcsfxyqilkxqtegtsgyvljkgzhbue
 * Smoking Wheels....  was here 2017 odiumlllumjltdaajsngjjtrgmczwtoxbhbslvwlsknrdhwr
 * Smoking Wheels....  was here 2017 qwbookdtmkidkvxlligbwjikgetuxfnjopmhchxjcvfnyzzb
 * Smoking Wheels....  was here 2017 urqihgrkcmthpddbuxdbintlnnjxxcuqubsogkywisosihte
 * Smoking Wheels....  was here 2017 yglxmtxtentwqxbjplxjruzmurfnjpcmeyqvbjfyjmeucnbb
 * Smoking Wheels....  was here 2017 gnfmaxtnmooceihegdmjelgldxydfbfajqmtaternpwljjza
 * Smoking Wheels....  was here 2017 dtwjdymoazulassnkkbphabmuugmneimgwrdwgqojzqrmtzo
 * Smoking Wheels....  was here 2017 fhpdikpcchfrhtlrzaazsgfbhehnpuvkapwdmyoepqvrzspm
 * Smoking Wheels....  was here 2017 kyvsgbwnfkytghvgdwdqjequkdhnabgqbzbcebenhxayussv
 * Smoking Wheels....  was here 2017 wpfdxxfnehfxonoygegvobppfyxysiofznjpjcatsjagxjmx
 * Smoking Wheels....  was here 2017 zmsvneyaajqqbukxzjpgrjpryfvmrhujsxgntvvgkvvotohg
 * Smoking Wheels....  was here 2017 laoinlodyezqutpjfdpsmwjldufehukslbkzihosdkubwlrr
 * Smoking Wheels....  was here 2017 cxcnrltipmjxdhlvcmyixqynosifdayznethisnaykmgcjpe
 * Smoking Wheels....  was here 2017 dcbnxeogqlbrqnoecoomfwnwgitcbhigqtmbdqdkbksxnadc
 * Smoking Wheels....  was here 2017 yvjrlygvejpkevvkuvptucqrmfgodhqvrlaeouffbfnynfqy
 * Smoking Wheels....  was here 2017 fnfpseggmuvwwxjvdaozlcaiudxosxhfufatneseswfqqeun
 * Smoking Wheels....  was here 2017 uwbdnsjxapvazopygachbxqmygbjkgwfjgmcgdxdaujktfkw
 * Smoking Wheels....  was here 2017 vvnjsnolquvcdaboocdawsubzvfkasgxcbowechjhmtcyaph
 * Smoking Wheels....  was here 2017 uporqxdvismofprtsrwvkbygelflrzoovgrwavoeaumoomuj
 * Smoking Wheels....  was here 2017 hpksqimejznegynvoksnhsvmbydlrwfsuvngukuiatvddrpu
 * Smoking Wheels....  was here 2017 fpkgmplyikaxpyagihjenrmjjkfrqntdizairadritifobwr
 * Smoking Wheels....  was here 2017 smildrzvxaizvuuwjntfigdwedcojjdycdjtdfekeiwpyfsi
 * Smoking Wheels....  was here 2017 gmbpvwireezwwurtjncgfxhdttnwaakiabaixtqycilfobng
 * Smoking Wheels....  was here 2017 kaukararllthrqucfbtbukqqqzpowjyyfqpfyqmywujhbsyg
 * Smoking Wheels....  was here 2017 cvyqkvtherthseoobzmucugyoapxnokmdbcskdziobfjgouj
 * Smoking Wheels....  was here 2017 nvflykndexgamonwioevihibpccivyrbkvrmwuqgksudghex
 * Smoking Wheels....  was here 2017 bfoevpqemmvawfpbpfbtzlkdzvxpxfvxxptiyheezpdojsoj
 * Smoking Wheels....  was here 2017 imdlpyonjyizysylwrmkszeohabsbfgqvjbkqsptztpxeamp
 * Smoking Wheels....  was here 2017 ghjbyfzqjesxbzwpgwfxnyragtxvwcozohmaegdwnmsroowq
 * Smoking Wheels....  was here 2017 zpzeukzeffjaudagczdpqpckyjzmfgqatvfuanisvkhnpzut
 * Smoking Wheels....  was here 2017 ypwejuubzjwuapgmdmmcmkaypkckdiqbhrrpwexslijlqfqm
 * Smoking Wheels....  was here 2017 utfoewwlygyzuyrpgcqguedztthoaewojuposhvndihsgibq
 * Smoking Wheels....  was here 2017 jumhxlytqqsnlcscoshfnxlgfkxfkyykijwytdkbytpvgtwh
 * Smoking Wheels....  was here 2017 xoiknlcrurlsofzvnokgywfqztmueavqxwsmkebmddclucgq
 * Smoking Wheels....  was here 2017 sjshffnblqtyarhusbdaloyijivakbnlxznxmfpgfhwoehni
 * Smoking Wheels....  was here 2017 oqunmgrexbkaxbvhczyktsirvyaylynmorzkwfzzajemzkjc
 * Smoking Wheels....  was here 2017 gaaaahkjswlxoixwvfmlxkklftjtwuingcbhvmmpnpqpbxoa
 * Smoking Wheels....  was here 2017 ymbvvipipbfvnoehhzroawlmnzkynzxoptxfunpibqarnjij
 * Smoking Wheels....  was here 2017 chwibrozpyhfrfnrcsuiqpwaagyfnfixnizzmbancgjsrrzr
 * Smoking Wheels....  was here 2017 jupcguumaekxcvbgfddokkmkgkaodhzdesztweuxlnaxeads
 * Smoking Wheels....  was here 2017 ptsabmagjnsuejdptenlifgizmagakmazfuuebeicvotttsp
 * Smoking Wheels....  was here 2017 ycwfltgzlclckykldbuhqjmtfulsaxrpofquwhqzjrszpnup
 * Smoking Wheels....  was here 2017 wbazsvsngeejsysyaedrujpuhzcremsewkxpqoxiuxqozesf
 * Smoking Wheels....  was here 2017 yajzfgydaitidaehhhanlyjwsubewzzhztihmyazcqotnxeh
 * Smoking Wheels....  was here 2017 ethbsuqejlfxaaebdidxqcurgjpkqocsjlvfprexjdcabbav
 * Smoking Wheels....  was here 2017 penifluhbnwizciaxmkdodcdxzjwjownqyozkfygwzabsiid
 * Smoking Wheels....  was here 2017 slzcwmsmbygdwqohgfzxqnvkzfbgdrnzrzzmslzkbbkytnnt
 * Smoking Wheels....  was here 2017 dcwzekvvrgebsixcdfiarbrwayvohtiqsluukgjbvjnuvvfm
 * Smoking Wheels....  was here 2017 stoxvzyvmhtzxzuzqldontrgtexakyyibowgtzhdchadtpgj
 * Smoking Wheels....  was here 2017 skuwufabedfgatuugbhymwbkhgxdjqgalumnecgvfjptqnus
 * Smoking Wheels....  was here 2017 lgniijhovcehwbvmnobszwioutppemkbtvzklkamrkknukda
 * Smoking Wheels....  was here 2017 osvvvzhjstkvpnzllquttpfdxnckgjszcpcalwpvhostvmzc
 * Smoking Wheels....  was here 2017 anggbuszjxawnarecffetzstiqqudjupxhtsmuftabbxocea
 * Smoking Wheels....  was here 2017 yplrzupborgpfrmlyngjficicjvgsypxvlcdyqjlfnhsdvvb
 * Smoking Wheels....  was here 2017 tehmugfmiitonyhipzcwodwbnimmasdfuqqcofuijtldvrit
 * Smoking Wheels....  was here 2017 bqbgzszmxmflojfczieonfskcjqnlowbxxzsinnbgwvlgrgx
 * Smoking Wheels....  was here 2017 vucwfyskwzufqxqifmdncmryqnpnookhpldilvtnxdabggno
 * Smoking Wheels....  was here 2017 dmeknxjzzvtdjqettqzemhzqdcxaffownqfpkqzypfutybgz
 * Smoking Wheels....  was here 2017 lydgbwfcgkrroarmffwcccerwskslbndogshwrarwvgmpzut
 * Smoking Wheels....  was here 2017 jrfaiksxzhjpiqhumafcsrxkkeeqrbqqxfgpvavlmcqnwdtq
 * Smoking Wheels....  was here 2017 vhwnafqwrgwvajkfuxsjhbhpmolykhmdxrvwmwpemjpipxbr
 * Smoking Wheels....  was here 2017 zutxdiaqdlmpejpnlcheammbdewdoeasgeoqiuxzdewpvyuf
 * Smoking Wheels....  was here 2017 gjtmwzackctlsbtudadejmzbqpeaeihpvjyubmlhzjnjxdis
 * Smoking Wheels....  was here 2017 fmdwqtflrwobqazhtlrfbupynsmmprrkveqmqagvtzxulqha
 * Smoking Wheels....  was here 2017 vvhygjicpnxkjesomgpjblhlomaulhvxpvoahqolnkolhune
 * Smoking Wheels....  was here 2017 hixvpuisvectlqmlsrvborhkvilkoppduuwamwvioegamffl
 * Smoking Wheels....  was here 2017 xeyvyjlfmdsotugxcdpvbacanunczgdjiscixkwykccllxqk
 * Smoking Wheels....  was here 2017 jwnosngtuzpphhbinjhohgmtfshvbcuekpvbojpwuhjaswnv
 * Smoking Wheels....  was here 2017 pcdxqcluhnstmaiedipjejlfrcbulhejjpbpqxicubqfcprt
 * Smoking Wheels....  was here 2017 stlzrbazuvljxdrgjdlpxpejyjknxgdyweymppouqzsstqfm
 * Smoking Wheels....  was here 2017 edkcbsffhhivkzxrwibvanfihaetoowevbxqefzixvrozyop
 * Smoking Wheels....  was here 2017 opdwfmorbjexaggqmpvzeviogxjkucrrkeqdispkituxjqgu
 * Smoking Wheels....  was here 2017 vwdexftupzbpdtatlvlcjpmsodhtccffztcigksxzbqiucgf
 * Smoking Wheels....  was here 2017 cxccbxwftegdiruudgwnuaxsiznhkvjvgelvluubchamizpc
 */
package net.yacy.crawler.retrieval;
import java.io.IOException;
import java.util.Date;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.index.Row;
import net.yacy.kelondro.util.Bitfield;
import net.yacy.kelondro.workflow.WorkflowJob;
public class Request extends WorkflowJob
{
public final static Row rowdef = new Row("String urlhash-" + Word.commonHashLength + ", " + // the url's hash
"String initiator-"
+ Word.commonHashLength
+ ", "
+ // the crawling initiator
"String urlstring-2048, "
+ // the url as string
"String refhash-"
+ Word.commonHashLength
+ ", "
+ // the url's referrer hash
"String urlname-256, "
+ // the name of the url, from anchor tag <a>name</a> (must be big to transport NOLOAD entries)
"Cardinal appdate-8 {b256}, "
+ // the date of the resource; either file date or first appearance
"String profile-"
+ Word.commonHashLength
+ ", "
+ // the name of the prefetch profile handle
"Cardinal depth-2 {b256}, "
+ // the prefetch depth so far, starts at 0
"Cardinal parentbr-3 {b256}, "
+ // number of anchors of the parent (NOT USED)
"Cardinal forkfactor-4 {b256}, "
+ // sum of anchors of all ancestors (NOT USED)
"byte[] flags-4, "
+ // flags
"Cardinal handle-4 {b256}, "
+ // handle (NOT USED)
"Cardinal loaddate-8 {b256}, "
+ // NOT USED
"Cardinal lastmodified-8 {b256}, "
+ // NOT USED
"Cardinal size-8 {b256}",
Base64Order.enhancedCoder);
public final static int descrLength = rowdef.column(4).cellwidth;
private byte[] initiator;
private byte[] refhash;
private DigestURL url;
private String name;
private long appdate;
private String profileHandle;
private int depth;
private Bitfield flags;
private String statusMessage;
private int initialHash;
private int timezoneOffset;
public Request() {
this.initiator = null;
this.url = null;
this.refhash = null;
this.name = null;
this.appdate = 0;
this.profileHandle = null;
this.depth = 0;
this.flags = null;
this.statusMessage = null;
this.initialHash = 0;
this.status = 0;
this.timezoneOffset = 0;
}
/**
* convenience method for 'full' request object
*
* @param url
* @param referrerhash
*/
public Request(final DigestURL url, final byte[] referrerhash) {
this(null, url, referrerhash, null, null, null, 0, 0);
}
/**
* A Request Entry is a object that is created to provide all information to load a specific resource.
*
* @param initiator the hash of the initiator peer
* @param url the {@link URL} to crawl
* @param referrer the hash of the referrer URL
* @param name the name of the document to crawl
* @param appdate the time when the url was first time appeared
* @param profileHandle the name of the prefetch profile. This must not be null!
* @param depth the crawling depth of the entry
*/
public Request(
final byte[] initiator,
final DigestURL url,
final byte[] referrerhash,
final String name,
final Date appdate,
final String profileHandle,
final int depth,
final int timezoneOffset) {
assert url != null;
assert profileHandle == null || profileHandle.length() == Word.commonHashLength : profileHandle
+ " != "
+ Word.commonHashLength;
url.removeRef();
this.initiator = (initiator == null) ? null : ((initiator.length == 0) ? null : initiator);
this.url = url;
this.refhash = referrerhash;
this.name = (name == null) ? "" : name;
this.appdate = (appdate == null) ? 0 : appdate.getTime();
this.profileHandle = profileHandle;
this.depth = depth;
this.timezoneOffset = timezoneOffset;
this.flags = new Bitfield(rowdef.width(10));
this.statusMessage = "loaded(args)";
this.initialHash = url.hashCode();
this.status = WorkflowJob.STATUS_INITIATED;
}
public Request(final Row.Entry entry) throws IOException {
assert (entry != null);
insertEntry(entry);
}
private void insertEntry(final Row.Entry entry) throws IOException {
try {
final String urlstring = entry.getColUTF8(2);
if ( urlstring == null ) {
throw new IOException("url string is null");
}
this.initiator = entry.getColBytes(1, true);
this.initiator =
(this.initiator == null) ? null : ((this.initiator.length == 0) ? null : this.initiator);
this.url = new DigestURL(urlstring, entry.getPrimaryKeyBytes());
this.refhash = (entry.empty(3)) ? null : entry.getColBytes(3, true);
this.name = (entry.empty(4)) ? "" : entry.getColUTF8(4).trim();
this.appdate = entry.getColLong(5);
this.profileHandle = (entry.empty(6)) ? null : entry.getColASCII(6).trim();
this.depth = (int) entry.getColLong(7);
this.flags = new Bitfield(entry.getColBytes(10, true));
this.statusMessage = "loaded(kelondroRow.Entry)";
this.initialHash = this.url.hashCode();
} catch (final  Throwable e ) {
throw new IOException(e.getMessage());
}
return;
}
@Override
public int hashCode() {
return this.initialHash;
}
public void setStatus(final String s, final int code) {
this.statusMessage = s;
this.status = code;
}
public String getStatus() {
return this.statusMessage;
}
public Row.Entry toRow() {
final byte[] appdatestr = NaturalOrder.encodeLong(this.appdate, rowdef.width(5));
final byte[] loaddatestr = NaturalOrder.encodeLong(0 /*loaddate*/, rowdef.width(12));
final byte[] serverdatestr = NaturalOrder.encodeLong(0 /*lastmodified*/, rowdef.width(13));
final byte[] namebytes = UTF8.getBytes(this.name);
final byte[][] entry =
new byte[][] {
this.url.hash(),
this.initiator,
UTF8.getBytes(this.url.toNormalform(false)),
this.refhash,
namebytes,
appdatestr,
(this.profileHandle == null) ? null : ASCII.getBytes(this.profileHandle),
NaturalOrder.encodeLong(this.depth, rowdef.width(7)),
NaturalOrder.encodeLong(0, rowdef.width(8)),
NaturalOrder.encodeLong(0, rowdef.width(9)),
this.flags.bytes(),
NaturalOrder.encodeLong(0, rowdef.width(11)),
loaddatestr,
serverdatestr,
new byte[0] // dummy, not used (any more)
};
return rowdef.newEntry(entry);
}
public DigestURL url() {
return this.url;
}
public void redirectURL(final DigestURL redirectedURL) {
this.url = redirectedURL;
}
public byte[] referrerhash() {
return this.refhash;
}
public byte[] initiator() {
return this.initiator;
}
public boolean proxy() {
return (initiator() == null || initiator().length == 0);
}
public Date appdate() {
return new Date(this.appdate);
}
public String name() {
return this.name;
}
public int depth() {
return this.depth;
}
public int timezoneOffset() {
return this.timezoneOffset;
}
public String profileHandle() {
assert this.profileHandle == null || this.profileHandle.length() == Word.commonHashLength : this.profileHandle + " != " + Word.commonHashLength;
return this.profileHandle;
}
@Override
public String toString() {
return this.url.toNormalform(true);
}
}
