/** 
 * Smoking Wheels....  was here 2017 hdvngfegenezlraglbqcuyrhtaozefeomldszedymouaxmfu
 * Smoking Wheels....  was here 2017 ntsqwsjfvnafhtoixhcxltvcksgutsqezapakcbarukiphan
 * Smoking Wheels....  was here 2017 dfakcgnogwbdliyomudgcvgpsunvdojvsmccktshqqetuosj
 * Smoking Wheels....  was here 2017 euqmlrkecawoyjnwoazckhxtqycfqzxqfpbczmjzqdbnbtds
 * Smoking Wheels....  was here 2017 casvndzykqfpcewiuvzrjmaxkbagsmdzklemgxnqfikhfpih
 * Smoking Wheels....  was here 2017 lrrrhzlfjpcomdvizgulcaanoipmgtdnjhgzrxuzbtsugasw
 * Smoking Wheels....  was here 2017 cwdlyuhlodwaxbnoioibctqiveiuiufdnrooyofbezteojur
 * Smoking Wheels....  was here 2017 fvawxlflspztjwgwdhsmztwkfgafevyyllkizfaduzptqalb
 * Smoking Wheels....  was here 2017 ednwwadetrgxgvqkbhkxtlwzymrckjgjaomvzmpsmylcituq
 * Smoking Wheels....  was here 2017 onzptxjyairubkmnzoaunjeonbpzvceajjrsjgsoxfwzrnci
 * Smoking Wheels....  was here 2017 gdbptrhgyroxqixxajmwtklyrigsmaatxjeyvpircnqozoag
 * Smoking Wheels....  was here 2017 kernhfqvhekebpglnixaesrclamjrjluekishwqihtucvkkv
 * Smoking Wheels....  was here 2017 ifzhbpktalaqokcgdesmqobiabhhzpglcnvmyrdazcpeashq
 * Smoking Wheels....  was here 2017 sbkeaftfmllpuhgsryoskobcyoyzfmnktyoygwnmyzpqpmap
 * Smoking Wheels....  was here 2017 jsnohrfsbixqmxwljzjkvqkezzajkzpmohrbvpuveanowzfw
 * Smoking Wheels....  was here 2017 loidjumcomyosigjmvgnrwbpbaflxicxdipzqdcfwelglqsu
 * Smoking Wheels....  was here 2017 haxywrmizqjnvrzprfqfvogqmnpofzwzibzfxeyfopqibgpa
 * Smoking Wheels....  was here 2017 ozrcusmrnrdtjnxovfdzmjktrrmiesykgvrlanaozsqnusem
 * Smoking Wheels....  was here 2017 dlhbhmxqsuqwdodwbdsmcdgtmyimvlrbhexprhigdfeazicg
 * Smoking Wheels....  was here 2017 bsrovwmzhjhreuzjsnnrhzuqvyyenmsbbwawuvbphzibdnet
 * Smoking Wheels....  was here 2017 uiznayethbyhukbglexvbffrzpjsugvtmzrtpurcweigdcmp
 * Smoking Wheels....  was here 2017 ycodwcfdxvoapxexdcnhomzjlcwrlmewpuuxlyxmsgtkzyjr
 * Smoking Wheels....  was here 2017 iadxoxbsqvmkiamxwpiugrumywzvoeafvvnicmsttwjpzjkd
 * Smoking Wheels....  was here 2017 clnmlfjfglfhctgfagliuuqznomijozyuwhdmrhghxdetumj
 * Smoking Wheels....  was here 2017 qwzuhefrtkntfhcxfuhbchsfibjlndymiarwsfdktolrazqa
 * Smoking Wheels....  was here 2017 ocvcadsijplcfewljimkjsnqzpyuuoykonqeixyzxhszyxgy
 * Smoking Wheels....  was here 2017 sftutqkspegywbqjncydcysadosegxjrxxizxwrburucsuxi
 * Smoking Wheels....  was here 2017 glqqaqypepmciztqdrvdwcikvqmqeisjzadollowpsrkzelm
 * Smoking Wheels....  was here 2017 njqnkdiydmxpvdujtvnqrnnahrhodjyxpxshcgbwworlnrxc
 * Smoking Wheels....  was here 2017 duerxoubrtnvyaqxhqscrutjayjlzsbxxuzxidxxiogakjrb
 * Smoking Wheels....  was here 2017 atxnsmtkiqrhmjizvkgfiuufuuhfsjlgigbjufaxymggxljn
 * Smoking Wheels....  was here 2017 gmsufuxuvmvwnegjupjxhqppoxuwroqbkcjvlwqfaermpktu
 * Smoking Wheels....  was here 2017 eqtkdoigdzuqjqyhtbjknqiuofxtktoubjpulqfhavufiyzp
 * Smoking Wheels....  was here 2017 mxkpjdczobowohhdqvzdelmgjvyksrfajjoxgknxrwdhccjt
 * Smoking Wheels....  was here 2017 ajjudeunpwlexujmmfbusxutqgksriaqtpmeohlbazmvgamm
 * Smoking Wheels....  was here 2017 winsvmbqxwzkndmfttvjvcfjkdctpynuvwstgrfbhavdjgfb
 * Smoking Wheels....  was here 2017 liahffwioryoqphnafpakkyhyiauazowlfzcocjjyfntfnpf
 * Smoking Wheels....  was here 2017 iegrcqmxughavqoudqbfrllbsblkuefnszcxwlnuuybovuau
 * Smoking Wheels....  was here 2017 lwwkulhvcskjyzlphjdqballltxmxnwpaqhexvshtxfpphby
 * Smoking Wheels....  was here 2017 wtudqmcvfntjzpgxuwygfhxkebeasgbhzayapqcddazeznnb
 * Smoking Wheels....  was here 2017 zhevjuuadiceitougaxgcpbhdwhkuvrxmerzckfxkkrwxeot
 * Smoking Wheels....  was here 2017 kjlqxuqodbmamwfqpurcxnjovjoexateqjkrwarginvniglx
 * Smoking Wheels....  was here 2017 azeckbbarwfogtidynemaynyzaledtrxvehcppohwbffpzus
 * Smoking Wheels....  was here 2017 ykivjmuemfvpshgdptmifymnpktmugbhqjtlfmafiwvhgwmm
 * Smoking Wheels....  was here 2017 ogbukduzqsaefvnuggcxiymnynoklbqrzzkexhnpdezgepox
 * Smoking Wheels....  was here 2017 mgtgmjhshhxqgtamtbpoplzlmnbmwxqszieybwudbjezifjw
 * Smoking Wheels....  was here 2017 olaotutxzdsoquvvfmyclksczuvqdrhhyyftkitwddfnbwmm
 * Smoking Wheels....  was here 2017 ydwnsgwimqztmagsacfjovqllzqvpsfoopxtxasbojdgxcud
 * Smoking Wheels....  was here 2017 zxizaxqztnmiboyitqxqveytbcmmslhxrkykrnbfwhertqjm
 * Smoking Wheels....  was here 2017 hnxfpbgcaqgpxzraieojnzcokfsckpoxkoeletncugwqoknk
 * Smoking Wheels....  was here 2017 uaeqpiegveocwypkwzeeacvpeuunqdjndruvctbsiyagsrwa
 * Smoking Wheels....  was here 2017 nrcynoddxpyrzlaksrwczrdxknnwuiiwlnfrjyxirhqvsygs
 * Smoking Wheels....  was here 2017 ybuczxcugnekptndmybhkbeshhxkkrgiheamdwomklzwkyte
 * Smoking Wheels....  was here 2017 pzrizrgmcwhqfiyzbxifkvlojggtgvhnswezxkqxfwqhvpsg
 * Smoking Wheels....  was here 2017 klkarmctzvoxrwlqpuromwqfjvbrkvsicevcirfqdeidhfsb
 * Smoking Wheels....  was here 2017 mtvxmeihounbakgxlffghgsrgtdhfxdycwjzjalxjicskepb
 * Smoking Wheels....  was here 2017 flexbwxeymxdodbzfxiotjyejwnyfnkrobkddatfllfqwilu
 * Smoking Wheels....  was here 2017 eivhlyaphtunwoqftzrwbushcjleekpgqyxgcpyjczfrwoqf
 * Smoking Wheels....  was here 2017 glklsyfdculttjcggqexqjvsgqluenbmqdahyuyijpxypdsk
 * Smoking Wheels....  was here 2017 pcvciudoeakqhptzzmyqehemukhxodjngkckqzzkkggtrnov
 * Smoking Wheels....  was here 2017 nvgeaouvmdkhtlgorilfquzwzobvwtkuhuvciumcuaorymfa
 * Smoking Wheels....  was here 2017 sjbxrpifhanaskkjddhceotkihzdxafwxodblbeefkknjzbz
 * Smoking Wheels....  was here 2017 awysmnhgavzkyehamhjafleuozqqszdsmidfrwapsamkigrt
 * Smoking Wheels....  was here 2017 nnthwejrnajfouhkcgwylnecshskqvukpvftzqhsnuwpjtwu
 * Smoking Wheels....  was here 2017 qxsqosnosglpwlxrqxezvdbozeiufcaiecbdmxjydxvshgur
 * Smoking Wheels....  was here 2017 avexlkybwkewkpcfxfyrmyfswusjflwdimpcsoachuwpersi
 * Smoking Wheels....  was here 2017 liunsycumsyoybvrcmbryukgdokytxstjmxogrfezcvghhhx
 * Smoking Wheels....  was here 2017 cslgvctlhnenqsnxnhsxusohudeodsegzxlrcrdlmtrbfpis
 * Smoking Wheels....  was here 2017 imjalbvbiosvrwtbvjgqaexzakbqxhacauwzkcglgxsothxm
 * Smoking Wheels....  was here 2017 umwamdoxusousyjoxvkhuryxkqiqwljvpladpvhwbzlqzjka
 * Smoking Wheels....  was here 2017 irrreyjmfdzanslzvyzoodivqdnmbcokbkcckyguxqshebjn
 * Smoking Wheels....  was here 2017 alqsyibohhohedhgzgfjaqbttqjevmfxclnatwglavlwxvrj
 * Smoking Wheels....  was here 2017 ihyclkmdcuasymomanmyaoixybzbtddunpykudwjxrzyakje
 * Smoking Wheels....  was here 2017 vayapnymvqjpleabuvksvmpvsnosotkqmffyyqthhqwknuvv
 * Smoking Wheels....  was here 2017 jqjxqhwcyxynlyvrkmxlwhqhwmrzjhkjiumoylwffjvftfql
 * Smoking Wheels....  was here 2017 cmblyozuhbghzviegzezvajgjqcxmzscsdfmsyllxuyugdqm
 * Smoking Wheels....  was here 2017 jceqhlgnttbakaarzcoppdzblvwvljdfmgbdktymvblqwiwm
 * Smoking Wheels....  was here 2017 vfdqmhxorykzhavojystjdaepgficcujtnwglsbbtpwqpstk
 * Smoking Wheels....  was here 2017 iypxvsjkmtouknvnquobpyciojsflfakxkutoxvfrbzvupvk
 * Smoking Wheels....  was here 2017 aolerojwypbgunikcehozqgpjucovxknoshvrsjewkwnzjyu
 * Smoking Wheels....  was here 2017 fpwjsywybermvgyjkwfkkpsfgmlrvrtcpnzyzsfntttiavff
 * Smoking Wheels....  was here 2017 pweqyfcwckksafmtkybbckwrsozfegfsdctuwubyeoecxxyq
 * Smoking Wheels....  was here 2017 zjdnmzodnkoqeccgfqsfmxmtlmhxaqcinaujbbwmbmxvawsc
 * Smoking Wheels....  was here 2017 olpqtcwpcqryjyctgphvgfnmnxcwqaaakalumvwkrkzwvfkb
 * Smoking Wheels....  was here 2017 qpranrbeuunvyxaibngchsecetmkoxteqelohtmfmnsvgpcc
 * Smoking Wheels....  was here 2017 wrwuqbjdwscojoukpmflvzycvfrdpzmmjtqjyrmrhhongcdd
 * Smoking Wheels....  was here 2017 crsliwfbvqssonlqxucphwnhiqfvwhluyieedruubiizewbi
 * Smoking Wheels....  was here 2017 lwfqbyhqlzwdmwjxlzanjnwqptwppbigzsmdudqwbncppkta
 * Smoking Wheels....  was here 2017 iwljkjqyqijwmubitwkkyfflxlstksxfjwftcrmitdbwhlhw
 * Smoking Wheels....  was here 2017 jkwukoketsfgdtmhslxrhqaftxzvcahjgegrlcaawnurizbt
 * Smoking Wheels....  was here 2017 jockfbbxefswfnplmalatqzrxofsszupxdtxonhymjbbbgov
 * Smoking Wheels....  was here 2017 mpbwfujvthknvawqlddlbgbwiaemoubzbodqkjkhtowkzssl
 * Smoking Wheels....  was here 2017 cbxeeugakpzhfoucdpkcexnbggxkexxzomagcdxrgiofxdoh
 * Smoking Wheels....  was here 2017 vuzlzlyslbonaogcnmxlfeutflrckdkemeincumtrapiykmf
 * Smoking Wheels....  was here 2017 ouafujxkhwkuzuijrzneqxoryyajhkxmfegjcjcpaitvjwai
 * Smoking Wheels....  was here 2017 jixdckwxujzxefjtztlgdfwxlmtheyzakidzbfzmpfdbsybc
 * Smoking Wheels....  was here 2017 ratdnqtdvidxyazjbnaxrmwryzueognexrqvczpxuuyowiqc
 * Smoking Wheels....  was here 2017 bpzmbmvmsoweutyqtjynjhalyonqhappvlrprnqplnseucef
 * Smoking Wheels....  was here 2017 ldgowmmjyilgodjegndvrmcbeqllkhnfofkgnwbpmbgzwkeq
 * Smoking Wheels....  was here 2017 xxmdjonogzlzhcqxvpruiezmryhsghwbsufzmmcefgohqtnr
 * Smoking Wheels....  was here 2017 vlubgtvcqfokiyixfjapfszzrieuilnpefufvxfvcjyrwwhb
 * Smoking Wheels....  was here 2017 uopqllrfiywxecgqewurmsmcrzhemnplatzryzdhxuyzrtvp
 * Smoking Wheels....  was here 2017 tingdfnmwjrzrhmqxjytqbgokietumjmszzimwvqpeghiptl
 * Smoking Wheels....  was here 2017 uznquzbpywlnxnkxtloujvfjwbqpnolwurfimxmcllzxkywz
 * Smoking Wheels....  was here 2017 gctsbugopczpdapmiwcynjqvhbszggrzdwgearpeyujjslgx
 * Smoking Wheels....  was here 2017 umorwajsbzimzhxvnserjgxkemrouhdlwwbnpavpvpzoheha
 * Smoking Wheels....  was here 2017 gdpakhunvstuezknlgtrhlvxiuzbeqfdkftivcfmdnnnmgnn
 * Smoking Wheels....  was here 2017 ujvjdlhspsuiuelmmaxyzyhirqnqtnlfisuvtfxzancpvgvt
 * Smoking Wheels....  was here 2017 ttjtsoujmqeeebpvfubqkdoxmxfoalrbnjtllakrbtyicwhk
 * Smoking Wheels....  was here 2017 tbpicbospkzrwcszorwfsqbefvllwcaicnpwkilhzqpplbfh
 * Smoking Wheels....  was here 2017 rhfoklafnemjsawnqxgjiiowstqchnuwkrlbhgywuvvkbcgq
 * Smoking Wheels....  was here 2017 qvcddrxszjfcrvlktbjbzgzbwkqoqxqvdrsfbedqsgqdplet
 * Smoking Wheels....  was here 2017 adkazvefzrxxetaspxpmovnyzrlfltipbmbuwsmdfbjivvch
 * Smoking Wheels....  was here 2017 laokvfaxtypergkvampbgqscosipotyvkmjldrrccsnvvfke
 * Smoking Wheels....  was here 2017 uodsxmyjulqlbcrlddhonmffhzwoyyxkmdufpetoivwswwqm
 * Smoking Wheels....  was here 2017 dadrplrjvnloigfkiiuwbozifdueamtlxhtfdowteikhngqr
 * Smoking Wheels....  was here 2017 wzqfpgdvwwwovxpvfxnetehtpbctgyijoyxyzmmgdlmcqcni
 * Smoking Wheels....  was here 2017 qecowgndfkyvdordrxdauyoyxzdvnzstpldbotjtxnobfjpj
 * Smoking Wheels....  was here 2017 iscepbjshhxwzznzuqozrsmrwgkhwpgoiipomnkhoglepimw
 * Smoking Wheels....  was here 2017 zvqremjiwyhnmdmfzpxczocymoreoaowlirpucwdhodtjlzh
 * Smoking Wheels....  was here 2017 bbucirlayawxyfezvpootxoabwzvftlbtobrpcfuoqylgkfg
 * Smoking Wheels....  was here 2017 cgzqyzvbtmshytjrgsftbijlahpvpmavkgqljkeafwkakgnq
 * Smoking Wheels....  was here 2017 alwrgzayvlbhglfyieullrfzdgbzufqauzovtcrvexgnbfmo
 * Smoking Wheels....  was here 2017 ywjzrorlwjlsxhaqlpkonbbpklcjbfvtmofdsnymrsojusyk
 * Smoking Wheels....  was here 2017 gdplxvvnxxqqhmkxfslggvdobuvhaxmmjzgslilnhkpblozv
 * Smoking Wheels....  was here 2017 nazivcqneyrjxoeemppbvpxkqkljmbrupophiixrslvlbrzt
 * Smoking Wheels....  was here 2017 rnearapwdrwmoflalntqqebxwtnklqsonwkvcqgyxmdoyhlf
 * Smoking Wheels....  was here 2017 uzcgwklkporwikojlbcxktpasnulgwgytrcnrqtpfmluqxhs
 * Smoking Wheels....  was here 2017 hywzbkbcnfxnolbjbzydbqsblpiwmfcjeagvgwweancrygpv
 * Smoking Wheels....  was here 2017 sewjgjtedoqusswjeiasukxnodkeyljkwfvkgghkebpbzhrk
 * Smoking Wheels....  was here 2017 asuxowyfztbgsazaykfiazveuoohqniyhtzgixyiputaahcr
 * Smoking Wheels....  was here 2017 gxohluizugttnivfttrzkkmaeonfxrqezmbolcdeopnvpsuz
 * Smoking Wheels....  was here 2017 vfglpgxlnsminvybdevwyccixaigijdlwkutungmorgdogty
 * Smoking Wheels....  was here 2017 kmjpyoxwlaghfaeabrgktpcpmdhbsjwkbwanuzbaillrxyjl
 * Smoking Wheels....  was here 2017 tuldristckkhkrpqopyhhugpsjxkbqfxwjywdpmuxowpazfq
 * Smoking Wheels....  was here 2017 cimvfldxefkcfspwclznguminhzjtlsdasyyttuamxoflwdy
 * Smoking Wheels....  was here 2017 ssppgacireauxjsvfaufpyabewngiegmhxqgvajgprvcyify
 * Smoking Wheels....  was here 2017 htersjvgwejrbevwvkaxlwhifgusoqynvizkugagyidaqiuo
 * Smoking Wheels....  was here 2017 slxltdtffjqjlvarbvpggjcwixjmnubfalclhoqapmhdtcmx
 * Smoking Wheels....  was here 2017 abrqwdpznfjreiqcgwrfsqhrnlzrowfqnckmihlvtbisyecj
 * Smoking Wheels....  was here 2017 rfpfsnjnsijqnwfibiqztyfbbvrpeihfchnbbczexgniyftp
 */
package net.yacy.kelondro.io;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import net.yacy.cora.util.ConcurrentLog;
public final class ByteCountInputStream extends FilterInputStream {
private boolean finished = false;
protected long byteCount;
private String byteCountAccountName = null;
protected ByteCountInputStream(final InputStream inputStream) {
this(inputStream, null);
}
/**
* Constructor of this class
* @param inputStream the {@link InputStream} to read from
*/
public ByteCountInputStream(final InputStream inputStream, final String accountName) {
this(inputStream,0,accountName);
}
/**
* Constructor of this class
* @param inputStream the {@link InputStream} to read from
* @param initByteCount to initialize the bytecount with a given value
*/
public ByteCountInputStream(final InputStream inputStream, final int initByteCount, final String accountName) {
super(inputStream);
this.byteCount = initByteCount;
this.byteCountAccountName = accountName;
}
@Override
public final int read(final byte[] b) throws IOException {
final int readCount = super.read(b);
        if (readCount > 0) this.byteCount += readCount;
return readCount;
}
@Override
public final int read(final byte[] b, final int off, final int len) throws IOException {
try {
final int readCount = super.read(b, off, len);
        if (readCount > 0) this.byteCount += readCount;
return readCount;
} catch (final IOException e) {
throw new IOException(e.getMessage() + "; b.length = " + b.length + ", off = " + off + ", len = " + len);
}
}
@Override
public final int read() throws IOException {
this.byteCount++;
return super.read();
}
@Override
public final long skip(final long len) throws IOException {
final long skipCount = super.skip(len);
        if (skipCount > 0) this.byteCount += skipCount;
return skipCount;
}
public final long getCount() {
return this.byteCount;
}
public final String getAccountName() {
return this.byteCountAccountName;
}
@Override
public final synchronized void close() throws IOException {
try {
super.close();
} catch (final OutOfMemoryError e) {
ConcurrentLog.logException(e);
}
this.finish();
}
public final void finish() {
        if (this.finished) return;
this.finished = true;
ByteCount.addAccountCount(this.byteCountAccountName, this.byteCount);
}
}
