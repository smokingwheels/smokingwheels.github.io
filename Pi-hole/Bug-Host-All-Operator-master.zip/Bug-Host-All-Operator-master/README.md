# Scanning Bug All Operator Indonesia

# Created Boychongzen aka Xroot

# Scanning Open Port 80
![be](https://raw.githubusercontent.com/boychongzen18/BugAllOP/master/Screenshot_1.png)
![be](https://raw.githubusercontent.com/boychongzen18/BugAllOP/master/Screenshot_2.png)
# Scanning Open Port 443
![be](https://raw.githubusercontent.com/boychongzen18/BugAllOP/master/bug.jpg)
![be](https://raw.githubusercontent.com/boychongzen18/BugAllOP/master/bug1.jpg)

My Youtube    : https://www.youtube.com/channel/UCKdOPQ_iIXcqK17PB_2RMdQ

Link Tutorial : https://youtu.be/fZIBHfnKwTo

My Website    : https://hackingforlive.wordpress.com

My Facebok    : https://web.facebook.com/xroot.xroot.7

eMAIL         : hackingforlive@yahoo.com     

MyTeam HFL    : https://defacer.id/archive/team/hackingforlive

# Moto : Berbagi Itu Indah

# Regard Boychongzen aka Xroot

