/** 
 * Smoking Wheels....  was here 2017 woexplirkpdfdxbledhifauqgjkvdvlecoghoiltitywywof
 * Smoking Wheels....  was here 2017 ibizzemsuczpientxnexhdmytcnwqgnbvwnnpsksulcjdzcs
 * Smoking Wheels....  was here 2017 wbprpsqdmsbxrpngapuheupumhcdnuflmkiyjtksreeofjnh
 * Smoking Wheels....  was here 2017 bksdbdbugugxxwnljmbuvlrilpgptidcekxcyzhcfwnslfsy
 * Smoking Wheels....  was here 2017 scprhvjvycqmabecylfziqmzvyhkrfgbfnsxuibnvttfhavz
 * Smoking Wheels....  was here 2017 xlowjkhsvnoxhkjgdcuubhckanxbswrodmnjmybygftvnoiy
 * Smoking Wheels....  was here 2017 zabpstxahhrqfjhfnemfsmumuuwgrcwfvlgwyctlkyooevwo
 * Smoking Wheels....  was here 2017 mqvxzznscuvkprjmxugqdpcjbkhapwmshpfzinzlmxpnnbjw
 * Smoking Wheels....  was here 2017 gjueamqyescckkgujfiplgvmaipmrklcxpupzavqxgkhbsye
 * Smoking Wheels....  was here 2017 jngzzwabsavayswgfagabjaldriemgxsgfvtntmwlkxmnpcz
 * Smoking Wheels....  was here 2017 eprdhzvtevrpsdjbbbsyqzzeczjuschacmfuxbpiacedzslc
 * Smoking Wheels....  was here 2017 emttnzgxgrlollfvrirsangvvvvhlagvoteifowkvfokqfxm
 * Smoking Wheels....  was here 2017 hemepfwrwegvdpagfekxjqpvpfawxetdzohewdktizruasqm
 * Smoking Wheels....  was here 2017 nadarhlnggmrcwtkxdikacctuipaqdygwselmymheujaxwcq
 * Smoking Wheels....  was here 2017 fodbbdbzwdsnwsnojaggsdzpdokmjpfrchwmyhqdjitbhsyq
 * Smoking Wheels....  was here 2017 yqfkmvabjfvdcyvglwcugbwmopoddpgftopvjvrtcoeblmbo
 * Smoking Wheels....  was here 2017 ngklusvwtfxkxmgfebdrumnthkjheizwddwkflqsurgoxsqs
 * Smoking Wheels....  was here 2017 btxscmhvebhpnptoycuqshzduemjzioxuujfbguydbwfjbdo
 * Smoking Wheels....  was here 2017 vrfcvzlodxqelvnlfuwwrqonrhtbkhkxppbquprqdlbbxqdy
 * Smoking Wheels....  was here 2017 mvaqohozgftvkwynyfhqowtazmgjjhfppwfhocdeysfgtpqw
 * Smoking Wheels....  was here 2017 tiishvggoqtomtrmcqhpmpkbxrjmdnvbdcizurefbcyhlmto
 * Smoking Wheels....  was here 2017 tkkxbegtfdaoxrrjbrknvrnivasxhnnmtfcuakcpdacvsaxp
 * Smoking Wheels....  was here 2017 vqragfqesxdheebmjdhohgkqnzchnzqmiembgrlocdvxpeuu
 * Smoking Wheels....  was here 2017 nwweodrjriymcahjwayzrspgwfrrwxvuwitlndamfkksihic
 * Smoking Wheels....  was here 2017 rdaswfyncdpbqdbsrrrlerxmcrufppcltfkrhpwzxamsltrv
 * Smoking Wheels....  was here 2017 jtiggceaegjhbvfrarvuezjasoakgmnsnrdydfgzwjxprkfm
 * Smoking Wheels....  was here 2017 xggoermoiwyqwpykougbhthuihfynipdztxnaisraeujberw
 * Smoking Wheels....  was here 2017 xmoufbcziketwdsnbcwpkkexxoovleymhtzaaqcjpjmfwhxa
 * Smoking Wheels....  was here 2017 cmeghqpmbndrbmdtqyyarnwtsgififmtrfwgnxjvbdpqpidf
 * Smoking Wheels....  was here 2017 roknnatlsedorvddpuxemzjbdqdqqzkhuzfjejxwcxzhzzuy
 * Smoking Wheels....  was here 2017 wgsmhbqnuoxygtxznooclwzqxbxtdecpkccrwhfrqitecgmz
 * Smoking Wheels....  was here 2017 hktegxopzcelnywtffuelqgsxgqovvfkqwrutjbqwkfndkdk
 * Smoking Wheels....  was here 2017 tbpahxzwemddnlqhtcxarvzqlduhaftvtvlmflnlhgbtryzm
 * Smoking Wheels....  was here 2017 iolnnrtsrqcdnlfpnujkmjecxwxietvbjwdxvqwzoibplojs
 * Smoking Wheels....  was here 2017 kkunjcytvtryalryacxmmjfzyyvmcfvqhytjoirjrikbkhzw
 * Smoking Wheels....  was here 2017 lkhekiuyjgsiugnvcbmopenlpasrtqmkplnmncsauejixjta
 * Smoking Wheels....  was here 2017 jratpswkhvievujcvzifykaxbaxclgriqwwbcxzqicpvlhwk
 * Smoking Wheels....  was here 2017 fmexbvyoskxsjjetnlyhyzqzsdzgrnorzbpfxuwbblyjsvso
 * Smoking Wheels....  was here 2017 hkfldpcbedalzkbaugbxezsphuuwegpakbrhvdwmxynuuyyg
 * Smoking Wheels....  was here 2017 egxlmdouhonbktlnllqkotvwtrmwzjkdaehwbptgbnrkyxno
 * Smoking Wheels....  was here 2017 sbehauyxbgnoqhbynixigzsghskljeyadayuyapcykzrqeos
 * Smoking Wheels....  was here 2017 ydinwfaurekczjtikmkopmljicddvckyjikdcorwiyjgqoog
 * Smoking Wheels....  was here 2017 gbuzjhvdonsewktaprueglhdqhoqdzcmmepglnotcxwdzacy
 * Smoking Wheels....  was here 2017 eqhvfbqvltjmdfkmzbbmdevscxtwhsvjpxtsdpzclewoyudv
 * Smoking Wheels....  was here 2017 nxwhgzbahnlauslnqvldihvmxybcoqkrzakjmpbqxyzyzjwe
 * Smoking Wheels....  was here 2017 jfrbrqudgthzbftdwqlyfsicoodtlfaqhkfifraebqabxnrn
 * Smoking Wheels....  was here 2017 ccfxvwyuuqnvlemqffuzmnqlsevosdduhbgxdflyyzevsffp
 * Smoking Wheels....  was here 2017 fjgziwuxqqzitjcoorlpachsjnfnjmkxbhqsluditvslrtln
 * Smoking Wheels....  was here 2017 obtocywpskuizugqxhrkxcchqmqusmsayrypnicyxlhlhomn
 * Smoking Wheels....  was here 2017 fnyhgtzifwiejqwxrrxeoicvbgtvfoglmbwpyyrtcgtnikuc
 * Smoking Wheels....  was here 2017 nghzfddspgdglmbrjowcqzogigjkqolqolkcryivhweptiab
 * Smoking Wheels....  was here 2017 adnspgsroydhzailvbplzjarifqmakylfdtruayqrhzxxncl
 * Smoking Wheels....  was here 2017 ofrvgmdjbqjgyghacmivtdimhawfpjrvttkesanvsssygnem
 * Smoking Wheels....  was here 2017 ftxyjjidhhgkrkwjoilcjelkrxrdxyvdtacrcbigcnfjobrt
 * Smoking Wheels....  was here 2017 hisxiwfssbjdpbgvumuhkothegyxrxtvbbuoumzdukrfwcha
 * Smoking Wheels....  was here 2017 jtwttbeyzjoeowvxoyguurshstuoyffttetixzevzhjqjxxh
 * Smoking Wheels....  was here 2017 hciwnhradzxnmwgkzcdfqeeunjmfzdawdxlxxjbzclydqarw
 * Smoking Wheels....  was here 2017 drhvtgpigsvkshnhikxijxenbhskgdlmucpijuvnwegkldcg
 * Smoking Wheels....  was here 2017 eahlxtxmxvxfsqsxgsghozzhaxivpzvcnsfzfpbpggjktgtg
 * Smoking Wheels....  was here 2017 ayawoyxlrtzsgrhsndekeuehixjlyrxolemkolppkprkvqpw
 * Smoking Wheels....  was here 2017 nnmkpeejpdexijyofxxhhzmyeghmplnvwzwmudkfujuufuuk
 * Smoking Wheels....  was here 2017 rawpecnpwyvxgzokspysiiaxbdpkbvxfjyehowvhdaoirkti
 * Smoking Wheels....  was here 2017 xbsjrpxvxjohmzhpmazwwbaaqyfxcnkftdietzkajgbzeoen
 * Smoking Wheels....  was here 2017 slsutssyjufrveoplhbawmbnwkfytnuqbwpsmdxtsyryalxx
 * Smoking Wheels....  was here 2017 yewegxlchyxcgnbgqqjulgysylyufdxnsrlsdckfohzrsofu
 * Smoking Wheels....  was here 2017 rpjciswtvtzsagsmkrjzzfsjifbwbuxcfkoikcehruwxarlt
 * Smoking Wheels....  was here 2017 fhtlkcblljbbrxrrhevtcmpgtejwzghxkbzwcmsbyblqytgn
 * Smoking Wheels....  was here 2017 easgccievgzuzeiidfsjrmfqcazucnqtjzyxkuxaqbaascqd
 * Smoking Wheels....  was here 2017 iwgygddbycwxybkezcgmxtiwprhwowxqktwisatudzgnxdsw
 * Smoking Wheels....  was here 2017 ucpabvkmyubouwuhfjxwcgzpshwnyugwceneqfngffzxgqwg
 * Smoking Wheels....  was here 2017 xjejwabdipdhbbqxjwlryamtcionzydxhgwubtuotmhdsqvb
 * Smoking Wheels....  was here 2017 ekubiwlxuwaunjjpgqvfimjltmntslepbievcgidysojqimh
 * Smoking Wheels....  was here 2017 mhklircxgiuaeurdzzicjhkcwramkmhzrzxafpeqicjcnfah
 */
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.sorting.ClusteredScoreMap;
import net.yacy.cora.util.CommonPattern;
import net.yacy.peers.graphics.WebStructureGraph;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.visualization.GraphPlotter;
import net.yacy.visualization.GraphPlotter.Point;
import net.yacy.visualization.PrintTool;
import net.yacy.visualization.RasterPlotter;
public class WebStructurePicture_p {
private static final double maxlongd = Long.MAX_VALUE;
public static RasterPlotter respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
String color_text    = "888888";
String color_back    = "FFFFFF";
String color_dot0    = "1111BB";
String color_dota    = "11BB11";
String color_line    = "222222";
String color_lineend = "333333";
int width = 1024;
int height = 576;
int depth = 3;
int nodes = 300;
int bf = 12;  
int time = -1;
String hosts = null;
int cyc = 0;
        if (post != null) {
width         = post.getInt("width", 1024);
if (width < 32 ) width = 32;
if (width > 10000) width = 10000;
height        = post.getInt("height", 576);
if (height < 24) height = 24;
if (height > 10000) height = 10000;
depth         = post.getInt("depth", 3);
if (depth > 8) depth = 8;
if (depth < 0) depth = 0;
nodes         = post.getInt("nodes", width * height * 100 / 1024 / 576);
bf            = post.getInt("bf", depth <= 0 ? -1 : (int) Math.round(2.0d * Math.pow(nodes, 1.0d / depth)));
time          = post.getInt("time", -1);
hosts         = post.get("host", null);
color_text    = post.get("colortext",    color_text);
color_back    = post.get("colorback",    color_back);
color_dot0    = post.get("colordot0",    color_dot0);
color_dota    = post.get("colordota",    color_dota);
color_line    = post.get("colorline",    color_line);
color_lineend = post.get("colorlineend", color_lineend);
cyc           = post.getInt("cyc", 0);
}
final long timeout = (time < 0) ? Long.MAX_VALUE : System.currentTimeMillis() + (time * 8 / 10);
        if (hosts == null || hosts.isEmpty() || hosts.equals("auto")) {
hosts = sb.webStructure.hostWithMaxReferences();
}
final RasterPlotter graphPicture;
        if (hosts == null) {
final RasterPlotter.DrawMode drawMode = (RasterPlotter.darkColor(color_back)) ? RasterPlotter.DrawMode.MODE_ADD : RasterPlotter.DrawMode.MODE_SUB;
graphPicture = new RasterPlotter(width, height, drawMode, color_back);
PrintTool.print(graphPicture, width / 2, height / 2, 0, "NO WEB STRUCTURE DATA AVAILABLE.", 0, 100);
PrintTool.print(graphPicture, width / 2, height / 2 + 16, 0, "START A WEB CRAWL TO OBTAIN STRUCTURE DATA.", 0, 100);
} else {
GraphPlotter graph = new GraphPlotter();
String[] hostlist = CommonPattern.COMMA.split(hosts);
for (int i = 0; i < hostlist.length; i++) {
String host = hostlist[i];
double angle = 2.0d * i * Math.PI / hostlist.length;
if (hostlist.length == 3) angle -= Math.PI / 2;
if (hostlist.length == 4) angle += Math.PI / 4;
graph.addNode(host, Math.cos(angle) / 8, Math.sin(angle) / 8, 0);
place(graph, sb.webStructure, host, bf, nodes, timeout, hostlist.length == 1 ? 0 : 1, hostlist.length == 1 ? depth : depth + 1, cyc);
}
if (post != null && post.containsKey("pa")) {
GraphPlotter.Ribbon rAll = new GraphPlotter.Ribbon(post.getFloat("ral", 0.1f), post.getFloat("raa", 0.1f), post.getFloat("rar", 0.1f));
GraphPlotter.Ribbon rEdge = new GraphPlotter.Ribbon(post.getFloat("rel", 0.05f), post.getFloat("rea", 0.1f), post.getFloat("rer", 0.1f));
int pa = post.getInt("pa", 0);
for (int i = 0; i < pa; i++) graph = graph.physics(rAll, rEdge);
}
graph.normalize();
graphPicture = graph.draw(width, height, 40, 40, 16, 16, 12, 6, color_back, color_dot0, color_dota, color_line, color_lineend, color_text);
}
graphPicture.setColor(Long.parseLong(color_text, 16));
PrintTool.print(graphPicture, 2, 8, 0, "YACY WEB-STRUCTURE ANALYSIS", -1, 100);
        if (hosts != null) PrintTool.print(graphPicture, 2, 16, 0, "LINK ENVIRONMENT OF DOMAIN " + hosts.toUpperCase(), -1, 80);
PrintTool.print(graphPicture, width - 2, 8, 0, "SNAPSHOT FROM " + new Date().toString().toUpperCase(), 1, 80);
return graphPicture;
}
private static final int place(
final GraphPlotter graph, final WebStructureGraph structure, String hostName,
int bf, int maxnodes, final long timeout, int nextlayer, final int maxlayer, final int cyc) {
Point pivotpoint = graph.getNode(hostName);
int branches = 0;
        if (nextlayer == maxlayer) return branches;
nextlayer++;
final double radius = 1.0 / (1 << nextlayer);
final Map<String, Integer> next = structure.outgoingReferencesByHostName(hostName);
ClusteredScoreMap<String> next0 = new ClusteredScoreMap<String>(false);
for (Map.Entry<String, Integer> entry: next.entrySet()) next0.set(entry.getKey(), entry.getValue());
final Set<String> targetHostNames = new HashSet<String>();
int maxtargetrefs = 8, maxthisrefs = 8;
int targetrefs, thisrefs;
double rr, re;
Iterator<String> i = next0.keys(false);
while (i.hasNext()) {
String targethash = i.next();
String targethost = structure.hostHash2hostName(targethash);
if (targethost == null) continue;
thisrefs = next.get(targethash).intValue();
targetrefs = structure.referencesCount(targethash);
maxtargetrefs = Math.max(targetrefs, maxtargetrefs);
maxthisrefs = Math.max(thisrefs, maxthisrefs);
targetHostNames.add(targethost);
if (graph.getNode(targethost) != null) continue;
final double angle = ((Base64Order.enhancedCoder.cardinal((targethash + "____").getBytes()) / maxlongd) + (cyc / 360.0d)) * 2.0d * Math.PI;
rr = radius * 0.25 * (1 - targetrefs / (double) maxtargetrefs);
re = radius * 0.5 * (thisrefs / (double) maxthisrefs);
graph.addNode(targethost, pivotpoint.x + (radius - rr - re) * Math.cos(angle), pivotpoint.y + (radius - rr - re) * Math.sin(angle), nextlayer);
branches++;
if (maxnodes-- <= 0 || (bf > 0 && branches >= bf) || System.currentTimeMillis() >= timeout) break;
}
int nextnodes;
for (String targetHostName: targetHostNames) {
nextnodes = ((maxnodes <= 0) || (System.currentTimeMillis() >= timeout)) ? 0 : place(graph, structure, targetHostName, bf, maxnodes, timeout, nextlayer, maxlayer, cyc);
branches += nextnodes;
maxnodes -= nextnodes;
graph.setEdge(hostName, targetHostName);
}
return branches;
}
}
