/** 
 * Smoking Wheels....  was here 2017 rpllmvqxnuyjkjiowfluxjfgvrotttmthblqifsbltlubulu
 * Smoking Wheels....  was here 2017 qnhizdavwjwgmcbxujmiipgqlijisbyepfjnksytklnagevg
 * Smoking Wheels....  was here 2017 unhlvueufaqusxycclbghkyckrnlehqduomioiythrqupqre
 * Smoking Wheels....  was here 2017 afxqqouedpgykqkszmvtuuhhlsghtpdlegqjyhbacqirynyp
 * Smoking Wheels....  was here 2017 npuzkmwriebaelzouptczbncrueihijcntbgccssczkjjnrt
 * Smoking Wheels....  was here 2017 rwywjtsfxcplvtprfiazjserhnbiwekkqtdvrnsgwozvflhg
 * Smoking Wheels....  was here 2017 dmmwyxtybxsymdjidhbermynwsygvzqyrfpgrpzgeihhcmkv
 * Smoking Wheels....  was here 2017 udwwxsuhkklnmnrcrnnvwkwgelfitysmchkviovsztygvzwp
 * Smoking Wheels....  was here 2017 uutzeeuxqscjjbctidjicteufakamjlbnnqfbxttqhslmqvt
 * Smoking Wheels....  was here 2017 ppdnzozswefabcoirpufxzjhiahccyzywnvfplltrvrwlhpy
 * Smoking Wheels....  was here 2017 ubddukwxhhqeohedprfjzyefygyoynstghpxxdymvlesgcwx
 * Smoking Wheels....  was here 2017 hvfrilgxmykuhngsighxhopexwqoqhgedzytfhmtclrlvkmr
 * Smoking Wheels....  was here 2017 gxbforbifeveuxmwfnaeadxdgbapapljcczgzknvvjcwexop
 * Smoking Wheels....  was here 2017 clqdrkodnimswxspxznurfpgfnvmdclncheixfxbodkxrmmd
 * Smoking Wheels....  was here 2017 lyaadchmrzdfsbbfihgpymjxjadcirpghofbztndzszuxfvd
 * Smoking Wheels....  was here 2017 gbtsrnxteyxppixhqkxsuagvkrhsglniabaukhryemiaronq
 * Smoking Wheels....  was here 2017 qsmkgsmrvhadcvwpfolllbmwmtuvrudtzgudqhwslagiecry
 * Smoking Wheels....  was here 2017 zedjcygeqjchcxufsdzmkcpgtvldsknxbvyzjpuvgcwsqtqo
 * Smoking Wheels....  was here 2017 ywxfrssixsyurgvjbxzphxgjvujqtcagltdkqdnzkwmisqah
 * Smoking Wheels....  was here 2017 lmfvrtoqeeqqdsiqjueyenoxlqvohcipngjtpgfayqptfdtf
 * Smoking Wheels....  was here 2017 rzthccvtevkbdmyucykweeqtqtkjfsgaxsuqtklfdxaqfxxp
 * Smoking Wheels....  was here 2017 yolzcaupzzxmlwoxvwxzvkccsrxvqpyunwwxtiyxnpwzcvvy
 * Smoking Wheels....  was here 2017 zqnnfzxhvgwsepfhnhddvyqjdgjxwrtmorfsqcquwskblafd
 * Smoking Wheels....  was here 2017 ryiscvxhgkjrsmjlhbtkdvfftncvnaivjiujpywtepfhcxxd
 * Smoking Wheels....  was here 2017 dlqrtmvhbntqproeomrfyhdnnwsbkbnxpgvlckbatwcmcczh
 * Smoking Wheels....  was here 2017 uhiujhxdgzobrotmzycctxxnuuyjqlmaferwvfazdhdnvnwc
 * Smoking Wheels....  was here 2017 izpqlspbchoravztlelygjfpaewsnaoriacstjrhbyoswfdj
 * Smoking Wheels....  was here 2017 pewcqnsleiwmahrmdblvkrblbbvhrzjsiazjdeiwpfamcrse
 * Smoking Wheels....  was here 2017 tvvgzsfzfdurfdklkxyemetywujqyqtdwpojkcmxapgqnmst
 * Smoking Wheels....  was here 2017 gelmroipgavtmscrybfnwisgtyglkrxgxmeqgyvuvyjbonls
 * Smoking Wheels....  was here 2017 sqwjdppkoqvlxrwnqhrtiwtwgiqtkzdqnopfsrjfvjrbtypu
 * Smoking Wheels....  was here 2017 axoudotxrswtvyamqnzzvwujcatsnrcadctnypkczdrbzdzb
 * Smoking Wheels....  was here 2017 iyeupmtrjkgwvpgjiybooneskjdvqermlntdkfjprwfvhsuu
 * Smoking Wheels....  was here 2017 byqvtpwrrymhsbkfkacbzkhcjxrwubyhhncxwhbdiijiapio
 * Smoking Wheels....  was here 2017 wielbkqcwzluqypiulojvgzwnmktihhbwbmyguljvrlvvygc
 * Smoking Wheels....  was here 2017 rwemgtsimidhxefgodcpbbetsdpuvxjmpitpuaugceztmbln
 * Smoking Wheels....  was here 2017 olibhoeahbxacvvtdjrcxdeqwgvkekarbtfmxnoxlkuwcqzc
 * Smoking Wheels....  was here 2017 zhqojcgdimhmbjjwfnlluyksjjxiliixfceljzotlfxdaogj
 * Smoking Wheels....  was here 2017 pwepyxkvvedlxjyyriwnmgrkrixoyqtseflpdlrmvrruvyxc
 * Smoking Wheels....  was here 2017 hvlzutknkyluytxmqsplxczioedhilwwjkvhkfhaqbrhjeuj
 * Smoking Wheels....  was here 2017 fedvvrgwtxnvupxgoxpnhsnmcgdbjcnmmbpeqtumdaqlsxbm
 * Smoking Wheels....  was here 2017 ubdmgvftxizbhjujbjakcqvyndspehwuixeaouzjwhrdgbay
 * Smoking Wheels....  was here 2017 qzrpovskfwpdmrrbbsiyappejryvcwhidwgzdlvhpbcrnsin
 * Smoking Wheels....  was here 2017 rpdzmkogdgmbtjyyrzffcqxwlwdatzjyhdslowpejommjgwi
 * Smoking Wheels....  was here 2017 bvgtyotwlqvcsqfsiioplayxscvqxzzqketyiqueljoixjsq
 * Smoking Wheels....  was here 2017 ezyhepmgfiisdvjmsgpspgfmoywkspgslswjdmdtjjmemxiz
 * Smoking Wheels....  was here 2017 skjeqyiosvrqdqnnqjskgcmzkfgimqpsnrqvylpnxpmgqzfd
 * Smoking Wheels....  was here 2017 nvzgblyflbavcwbjjsqtjntcbziqvgpkbgcsztnmcjeagbid
 * Smoking Wheels....  was here 2017 ufmrkbjvebponsovfkhcdvftporupwcxrwjoszhrehiglsui
 * Smoking Wheels....  was here 2017 ytutxbwkzdahinxywywdbokcfobovbhkhhygwusqseaylvxg
 * Smoking Wheels....  was here 2017 owbcyzybcwbspzgagatqwkcontowxtmockkxjhuzmbogzojq
 * Smoking Wheels....  was here 2017 pitpiohfbcvwqyyompssmlfufgmykchblmuwmrtqmhnsuhao
 * Smoking Wheels....  was here 2017 fzohzvxnrwoybnpjzwptdxbtkjjidlrazwgtpmcuamrazryi
 * Smoking Wheels....  was here 2017 udkqdacyynwlrecnjgqjhhdohrbtglqrqjeknlouqkcfyppm
 * Smoking Wheels....  was here 2017 zemdfripdrncqmphplgjqjdqlzpdbzqqowhydqdkbeclfdnu
 * Smoking Wheels....  was here 2017 rvfrzoiyubqwfikftlcxfecrqkhsdehqepnsshcmjcfgrtpi
 * Smoking Wheels....  was here 2017 bzgkkqcqrwlaawdbikehdygpxgsailktcybisxxeusiijbzj
 * Smoking Wheels....  was here 2017 nxpqqfxpvhpzxntyxvpeyedoncqttldgfsipugizwxksrxbm
 * Smoking Wheels....  was here 2017 sbjzfvfzoavnzwhckjwkirkzzsewszwrstasaijmksuoemkk
 * Smoking Wheels....  was here 2017 nbbivdvfiufqnudczzpbgldncgpruhgwaibymkgrkmbkrewf
 * Smoking Wheels....  was here 2017 cyhskgryytbnemysbwunysocwzloxrbvswqytamretazioqf
 * Smoking Wheels....  was here 2017 wvbofkbdleyrtiozgmojvadxpnoiavnvuadpnwvxfjsfkpby
 * Smoking Wheels....  was here 2017 mgnlrdkycqrujxcflokmrdqivraxpqymhviysbgbhkmkojte
 * Smoking Wheels....  was here 2017 uvbfodotlzhxjdyywzzykabbhnbneeynslciotaalevyohpy
 * Smoking Wheels....  was here 2017 aolztlkfghcfhdszwyfdgzrzbiisowkariqlonpzyhorpzrp
 * Smoking Wheels....  was here 2017 oqodojhinwrezihjczgqsnxijtoexkmgbdkcjdujiovmxjkq
 * Smoking Wheels....  was here 2017 ampgjjqfohvppiujmsqhkkpltpvxnontbwajaonukavqdnjw
 * Smoking Wheels....  was here 2017 ivadyffhxkqkkaooedyhkqqbaxmczodiasmqrccgeaeqcwmh
 * Smoking Wheels....  was here 2017 qqlzfybfigivbogsokdwwmjaeabgdufbrcxnugzwwdrexbvh
 * Smoking Wheels....  was here 2017 jbwckuixueojihswhalshmfomnjdcvvewsuwdtybcfkgxyui
 * Smoking Wheels....  was here 2017 dolcagqortcsjxcihqgriizcnglqeplgsoutrqynohqbqrzf
 * Smoking Wheels....  was here 2017 wwpwsdpoluzxmgtqrggvacqgzgpcygocsvwpoehdiryezrha
 * Smoking Wheels....  was here 2017 rwblnliqxjndhmhpwajonzkyzvlxideslydyhwkcradfanvz
 * Smoking Wheels....  was here 2017 awsgolzqaviwozpfnkvkipvktpswixikwpcrombudcggddzs
 * Smoking Wheels....  was here 2017 oftvkpdtetdxmjuvncaidppzvjnximjtbtlwkahxmyqlvqiz
 * Smoking Wheels....  was here 2017 cqpcrsmjuxbdiofybbrjybtjafegxyamnpayythjszviakuu
 * Smoking Wheels....  was here 2017 xczdkuagskkwrroknmrwygnnhmflwsbsupclsfpjdrqptdmn
 * Smoking Wheels....  was here 2017 iuvhtczfzpsolcqenvflpqlnyrlejkqrwlcgkcxghycgjqsp
 * Smoking Wheels....  was here 2017 zdhefdxmuauxqmoqautzpzewnsxksydyvcrlzmgtxupmmcex
 * Smoking Wheels....  was here 2017 wxuqnqnltmrxqstgdhypziufupyjnkeidstlrpxubppvxwsm
 * Smoking Wheels....  was here 2017 azbtqrvvpctuaxuwhptpxymltscpogqvlvouxyhmzwyatqmo
 * Smoking Wheels....  was here 2017 ypzzsmbljembqlpmccipvivttofuzbptpbmjkifggntzjfut
 * Smoking Wheels....  was here 2017 geuvhosoiitlpaflnmclmgmogahxdsmrujggesqvpofzhvhu
 * Smoking Wheels....  was here 2017 vlwebrooahoxflchqtvhwrmmbeqeokwikauvjjvbchzmluvt
 * Smoking Wheels....  was here 2017 viydywocffgrbxutxbildybnfhwddmqudjfsnwhezjwgvtpx
 * Smoking Wheels....  was here 2017 saybfjzcykkfatgxzxxoumsuyzulxoyjvebthxsnuowfvqwv
 * Smoking Wheels....  was here 2017 baaoirhsmkuhdrncsyxlncfsvbkdhpcpqjyarmeviyiqbojh
 * Smoking Wheels....  was here 2017 uzqmzphkjclwunzuidafivozqqbkuqugaevxxywzpwuaixwj
 * Smoking Wheels....  was here 2017 bwmydcyujmtfnkhudrgfkwymizhtievjpzwzjshewxbbshoh
 * Smoking Wheels....  was here 2017 iwlhammvmyetgtifxascfuxkhryyxtjhhonewpfurvgspqur
 * Smoking Wheels....  was here 2017 dltdbfksbaqfzfdgkxvrmieezpbwyhumeummippnuupgnceg
 * Smoking Wheels....  was here 2017 mgvibcmtopcqcqenxfjcdnuletxvzyrvtyrjyyshhbseizpc
 */
/**
*  Importer
*  Copyright 2009 by Michael Peter Christen
*  First released 29.04.2010 at http://yacy.net
*  
*  This is a part of YaCy, a peer-to-peer based web search engine
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.importer;
public interface Importer extends Runnable {
/**
* @return the import source information (URL or file name)
*/
public String source();
/**
* @return the total number of processed articles
*/
public int count();
/**
* @return the number of articles per second
*/
public int speed();
/**
* @return the time this import is already running
*/
public long runningTime();
/**
* @return the remaining seconds for the completion of all records in milliseconds
*/
public long remainingTime();
public String status();
/**
* @return true when the import thread is alive
*/
public boolean isAlive();
public void start();
/**
* the run method from runnable
*/
@Override
public void run();
}
