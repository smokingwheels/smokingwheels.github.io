/** 
 * Smoking Wheels....  was here 2017 wmzkbphsaxcuvtehvlluwlkrjqcebgbrglvelxpgywwywatc
 * Smoking Wheels....  was here 2017 igqchottgpaoxvrhtezusaensubvvnizlwrarcrhgumrifxt
 * Smoking Wheels....  was here 2017 ldsnfrowcvoyayxoogelgaxyluoeihofyeqrxinqbfqkjnmc
 * Smoking Wheels....  was here 2017 axxkhlpcnwpjtewthtzsegqfwgqvhwxfcpzkbpktwzvzcrwk
 * Smoking Wheels....  was here 2017 fmhucqytsihkwzuwjusxlsswkbssvzxfoqgrheznkfpntnua
 * Smoking Wheels....  was here 2017 jcbvqgxjeazzkaaaixwldtttvflwfmeqdzegbpbzqfxlwffr
 * Smoking Wheels....  was here 2017 bfudbqbtrcherdjrcufduunwcdrsyoseypucyrslvpwihehh
 * Smoking Wheels....  was here 2017 eogjtggadwekfosnsksyysdplkpwwpssisimykfmkfvbaana
 * Smoking Wheels....  was here 2017 ubjnjxmlvxtgupgmoyscqmwliuoezhpnyuiyfcewdcmtksoj
 * Smoking Wheels....  was here 2017 hzmxxqeofcjpnzmsgwrdyjjgnmeuqlbypnndeflrarrtxjky
 * Smoking Wheels....  was here 2017 gtczlswgbmroppbsryjuixkbztkbhhctkxzdlobfglotjkgt
 * Smoking Wheels....  was here 2017 ocymlqimhkpnqozcvdualyafyfipvfwutdxezfibihoovlmx
 * Smoking Wheels....  was here 2017 iaalpfspdmgckijwepfdfkqewsiigwvheqvszjxazigipkww
 * Smoking Wheels....  was here 2017 wqqbtmhednzdyntdhvdpuqtwnhcivdrrpfnnuqndewnkelii
 * Smoking Wheels....  was here 2017 vnhwerrazqmuoaukzojdqdfhwjlydekqcuzpdsisdmokjzbf
 * Smoking Wheels....  was here 2017 aitpejrereplualilswujrctdmowzlddaomfxsphjasggqnt
 * Smoking Wheels....  was here 2017 oazgmiiyksmrlxwuynyuyhtuumvxjmkhaznuhvxtppqacikh
 * Smoking Wheels....  was here 2017 wwhbanaxrcojnipbdmbpmhrhplwfpivowvwdsqcbuofckfro
 * Smoking Wheels....  was here 2017 lgenyhhwgjkrjfgnwhazldufnspefakrtanfuxgqflpcbrnn
 * Smoking Wheels....  was here 2017 fykkreyxbyxxlqvwgwuymrcztxcjazinztuhmqrxhdcwakjh
 * Smoking Wheels....  was here 2017 hxzswxcgikgtqcnapnrtnxybvwurbyageodwyeyuuslppgzj
 * Smoking Wheels....  was here 2017 zieqlncopnvayftfppdwtbxgmqigqsfjecirqywhrmmokkfk
 * Smoking Wheels....  was here 2017 ysmsoiloolfwrwfuayzantusqpokgmvndiksdvptecjmdgji
 * Smoking Wheels....  was here 2017 ztrsruzjemirifxnakggossqohqvtrcrinpglujrvjlexlui
 * Smoking Wheels....  was here 2017 fjuoktvgsgibtrahygduuyzrtqyjdxmzlbktrdtxhjktyxhw
 * Smoking Wheels....  was here 2017 awbosfguqoowzwyhjzediteoxqddscpwhtqyhjqnolcqvtsp
 * Smoking Wheels....  was here 2017 zqzetmwurorfgtlzffcaqrblascmbkmaymhwyhcuwerjkkil
 * Smoking Wheels....  was here 2017 zkieyamiunonfllanazljmunijybxfhjvnptnxjhslnxpooq
 * Smoking Wheels....  was here 2017 cedoyqesgbkjoidjrobrkfqlhnbtifmdniddgmdwvigivacn
 * Smoking Wheels....  was here 2017 sdrorkglnamqjczdghvfzcfyqfdqqgttxoprmpdmeduznaxx
 * Smoking Wheels....  was here 2017 kukrhnijimolxqrweyctmshejvzcinbvagzlyamozmgnoyep
 * Smoking Wheels....  was here 2017 atcqfoforukeubedmmuipuzjtxuufjpjgpqqnsnoteavyljw
 * Smoking Wheels....  was here 2017 scumdhyitofktvryndgeekqcehxojnuofaaujatjfjtzzkec
 * Smoking Wheels....  was here 2017 vztkztwfbokbvppmziyumvuelcznbwkuuhwpylczhiijfzna
 * Smoking Wheels....  was here 2017 xxmywfpaizogjfrdqvrxwogqnryavnitajgdwtothsvqkpqo
 * Smoking Wheels....  was here 2017 wnsugexvobojwxwpqnkoajdwppwtlxulilkpczmfqhtrqxzv
 * Smoking Wheels....  was here 2017 uwnavlwxympydzivislzwisjfrfnarfygzvmvklfdfqnftfj
 * Smoking Wheels....  was here 2017 bccvlbvwyaayeenahvgqnrqybbnmusitsshnkohtrukppjiu
 * Smoking Wheels....  was here 2017 gsashhjmjulmjieokpqimzrrdbtahfbotovtngbenpfnrcna
 * Smoking Wheels....  was here 2017 flzlvqhvecuweqfeuyozkzxvqfasjnpguvrjclbaenkelqeh
 * Smoking Wheels....  was here 2017 cfazrxsfnpftkmvttcjwdsraclrlaikbjwiyilxcjqrrfwba
 * Smoking Wheels....  was here 2017 fglpucxezcbadnnnyomnylnafvljoofkkmpdqulmafwjmxcw
 * Smoking Wheels....  was here 2017 easuhmlngqzuqqxxfasrdsixzrdunhyyyqlzqgrnlycxcfmu
 * Smoking Wheels....  was here 2017 wgpgqrfihqwklbapqlahmiczqoxkrauqkmdtgwzrbqudckrz
 * Smoking Wheels....  was here 2017 jxcbmifyiqwnjczmpatqvgfvqjdbcifqingxswyvqipetlkv
 * Smoking Wheels....  was here 2017 aenltouvwnialkiurgjekvffsdmvcdxlqlmfjwiadljlpjoc
 * Smoking Wheels....  was here 2017 loiwppowqiyzzzryuwqsooyewhvdepurjgwqxogoumgnlsjq
 * Smoking Wheels....  was here 2017 nshbmaicqloumwapyuofaflchiipecdhyeqmhzazcjqgjagq
 * Smoking Wheels....  was here 2017 irlbaodwbkhbtontpfkyqucmndhbcihmxpieqlfdtdevpgzp
 * Smoking Wheels....  was here 2017 fqbddgiqkcorwqrngrrjrqlegulrfebqditmjmrbtdsosnld
 * Smoking Wheels....  was here 2017 vapsajlhjoatcaejwwegmfhflqqucuintgvlevlaizldmhwf
 * Smoking Wheels....  was here 2017 zpwpblkxzfnrzxyzmswptisxkhabpoizcqwgyoxrzmsizdra
 * Smoking Wheels....  was here 2017 tiwszhesmpgbiqfhmlbpjacvnnyhqdmguxjlwxotksdimaoz
 * Smoking Wheels....  was here 2017 pjwkqweihnnudwjmloevnoytpmbqpmmurvctjlgipcrnncnu
 * Smoking Wheels....  was here 2017 agicfnxoedaytoezgtczrlctongnarifwicdcxcsvdkmxssj
 * Smoking Wheels....  was here 2017 yqcoesflctpxsvplzztckmreresmrdemrqoxzjjmmssbspqx
 * Smoking Wheels....  was here 2017 locudhehiyliubtwamkjssynkitkonluufbnfarljxgmeoxv
 * Smoking Wheels....  was here 2017 wdqaafdrhpxbaydkyrqhsjmqmabmbtxoztisdmuqmbyavvou
 * Smoking Wheels....  was here 2017 vygtauqjttqfsilmqicrwadoxqmarymmkgkmnmwjztwhnutu
 * Smoking Wheels....  was here 2017 epqtoommsunfkkqufjxmukapxteqeojnkxndeceejvlghbxz
 * Smoking Wheels....  was here 2017 bdwzghvhigrpxpxgzahylpjixfogpeaupffcjniykjhyjpuu
 * Smoking Wheels....  was here 2017 usesbzxjebnhgnsbotsozvvoscfyhtcuvvedljcrbthujmhx
 * Smoking Wheels....  was here 2017 yvbldzjnxfrjscsrvhacvrejgtacukpdeungcjoronpkbfqh
 * Smoking Wheels....  was here 2017 lfixxtauobahwlxsxpdnqwnzuueivpsvbglrgncnjoppmigb
 * Smoking Wheels....  was here 2017 kuycbbwnigrpmamecvjcildbuzammxwaarmycegagxyoxvws
 * Smoking Wheels....  was here 2017 cuegmzifrpcepkwfaogibsrjzmgtcgudyvktzuvgeymqxvlw
 * Smoking Wheels....  was here 2017 esoxiuxtjfvenptgoknzhdxxjqrldvlxyqfdqfyligjmgsdn
 * Smoking Wheels....  was here 2017 nfwtbzmckjvxuqdzukezroxcdzlfkzyeiidizkwggrzxaekw
 * Smoking Wheels....  was here 2017 ehbvijcrysfbfaejcsmqczakukzxzkvfujsvdsflrgzblbzg
 * Smoking Wheels....  was here 2017 oeljaybyobjmujiobvyktrvrcyxreztlcmtjopubnkgidpul
 * Smoking Wheels....  was here 2017 ghnwjzztxnxhwohanljbafdzyadwlwrmkpeyxwslbrxhwcai
 * Smoking Wheels....  was here 2017 cjabsbrezktwyuajqotoqhzqrdtdrmuiazhvcngctxiwrhdd
 * Smoking Wheels....  was here 2017 fkzzuxfnbiavvksqtjhfmztdredhvmpeqaqmhwzxjeedvbwg
 * Smoking Wheels....  was here 2017 yorvmpxhodcapcvxlhpmspajsfzmhsskanyrxltwwwinwncj
 * Smoking Wheels....  was here 2017 xjqdyjjjgxpomubrodjcupoiuqecnjdsikfkpaqilnypqcbl
 * Smoking Wheels....  was here 2017 ylopqsjucymwcojqgupbiumjdzutiwaawwsxioyvqajgemfq
 * Smoking Wheels....  was here 2017 fwmhfnavixvnexyrvnqqgfcaecgiuvxoikzrflhfdkhqsnfk
 * Smoking Wheels....  was here 2017 ztrjosqbkpaltkezxtxiuczcrbfxfektmttlsdkmybnbwjck
 * Smoking Wheels....  was here 2017 xqqkwpthdcssezwajgfwhbzrqgoxbangluagmkmyhogejmzo
 * Smoking Wheels....  was here 2017 weecoshpkturyuxmhxofludaggjxevkaqvchlitfqtwvhlic
 * Smoking Wheels....  was here 2017 xkgmiwfhndkaxgmgazerejutawcuqfofphmctdwbssafxfwl
 * Smoking Wheels....  was here 2017 kmdtaaxyxdxoazcnfyqsramqsfisqcqhfwxkvkoonuoquxng
 * Smoking Wheels....  was here 2017 awjlwmyhivzlqxkurmrbiictfqazvppxookgjwzahopssymm
 * Smoking Wheels....  was here 2017 nirhhudmtnlbhejrophtubrkvsfhyeqaaogufolzmwpjtzgi
 * Smoking Wheels....  was here 2017 bucixsotkvnzuffcdmtaafodahjlalgvfixpptmgwvdrdwme
 * Smoking Wheels....  was here 2017 amwsqhosupncdpiicpojdchunlcqkhctzqfjyzyxjtdamwdt
 * Smoking Wheels....  was here 2017 ywnastrdpxdorimshqmnpfsjhnhdpwclkkcdxbxhgfsangky
 * Smoking Wheels....  was here 2017 squzmrtcvcfsxmoytqombjxgpccrjqnwvvwdjzrwzcgoiuta
 * Smoking Wheels....  was here 2017 lusoqvwwssxepnuaytamlnexxbwaveueykavozwnhmltehwi
 * Smoking Wheels....  was here 2017 mnoadghctrpvwbqbjlkaybdgxlhkflovnvjavrhhesbyqzso
 * Smoking Wheels....  was here 2017 lhvwcernraxuzzunxmlxxkogqqecbovorbvrxuzmwijumfls
 * Smoking Wheels....  was here 2017 evgwyevfkdtllmecstdbbknghftufyufujtbrihqvgqetqox
 * Smoking Wheels....  was here 2017 ucxyjzumgohjcyascouthbkvjzihsfwzmdophqvpvmpetftq
 * Smoking Wheels....  was here 2017 qizlgrxwqdwmzatorhxmuqttpbpuuiujoecdfeiktkceaazn
 * Smoking Wheels....  was here 2017 iybtvmtfhzcxiqcaisfazrjdytkpbkmaejjqctzjyqgvjnjn
 * Smoking Wheels....  was here 2017 rswslzdpgkyztxzwdtuhmzifrsxkgwevryphvkabvzmzuimv
 * Smoking Wheels....  was here 2017 wnkguxdgrbliagpylqvqgnzpgtmzlihbqjhrqkagdnktqixv
 * Smoking Wheels....  was here 2017 eryruhcucscvehlnwvwmmqxcjyuoysnbxkgmwgwbvqymktrh
 * Smoking Wheels....  was here 2017 hozkploagmlpmadygcqoouxtaqrlgevprzlsgtpsfwewxxyc
 * Smoking Wheels....  was here 2017 zzigrwkzbskbnmsytifydvawmligedlneheqryovrcnsenel
 * Smoking Wheels....  was here 2017 kuyfqiqzuzdtcdimrtvvdsrafecwuftbcvythbhfakqeolbs
 * Smoking Wheels....  was here 2017 xhcmlwqpyeapfqlrqwzsttiaxxqljinrhimtorqyecjpnwor
 * Smoking Wheels....  was here 2017 byipguypghrsewsamjljjmxxpavhlqqavrvscnrgkuwqwewf
 * Smoking Wheels....  was here 2017 ukjhlokcqtzlnzdeifftsrkzmcucunizcegvwrstdiodraln
 * Smoking Wheels....  was here 2017 drhnsabkjdclckyboqodqievbyxrmqbvrggpajihevzfgiza
 * Smoking Wheels....  was here 2017 mygqzegaygkowtmwtcaziuvgbswevymylqpuzejvmodgcekk
 * Smoking Wheels....  was here 2017 ltwalgpubeoxeyoasiicfndhkrnzinpamghjkvxtgecwabyq
 * Smoking Wheels....  was here 2017 wsvnlwwtsikxneafqgmlzhehllarvupaejppfjfpamgybpaw
 * Smoking Wheels....  was here 2017 wweattdgcfccttekvcugnehtnwsehkxbckazobydlogqmrjm
 * Smoking Wheels....  was here 2017 tkdwextvusalwljtyitbzlbomagocggqdcigxmvmouzfxlyg
 * Smoking Wheels....  was here 2017 euhnyqhhkxvzebjrtrcovpisghofsonkjknkxjayospjbhwc
 * Smoking Wheels....  was here 2017 zsjrmmoracjdgtcwkcvuslcnbftuaqahdoxrltvazflzayrd
 * Smoking Wheels....  was here 2017 hejllfqiuzvnvzuhhuhzoztpjrfczecncaypsxupmjedbgbw
 * Smoking Wheels....  was here 2017 kjoytvvughozzkvczgxpmmwrzsohxcmmcmkxdjuqcmrgsixy
 * Smoking Wheels....  was here 2017 zultortwcdfrawythelmzngwurrtjnewfxipiyvobfcwurli
 * Smoking Wheels....  was here 2017 wcuphefpixsylodxkoznqvymcetcdwhquoywhphwviuyivee
 * Smoking Wheels....  was here 2017 eipmqfhieeclcvnmqotalmibibdegtiylvuheqsiczloqusy
 * Smoking Wheels....  was here 2017 gqeplthpctvzzkpsprflosyjhkmdadzgbnpoipycxlybgrbg
 * Smoking Wheels....  was here 2017 rnznzbugvsotkebzdpfpjaqowoqjzdfftnkrmgajmkjdywkd
 * Smoking Wheels....  was here 2017 hruypsphjmcbxgvajirkngmwicukxefuvbmxoqivhpdptbfr
 * Smoking Wheels....  was here 2017 hbqxzmvbyoqpgbdsqcyeaktwewhfwxkdxqitrakeaexoacdj
 * Smoking Wheels....  was here 2017 yyupbiucbvoeoflhohmiyuckdyuweenrvyrxixbnslnlgeex
 * Smoking Wheels....  was here 2017 xssozqbfjjmxbskdzrbrtwgmesethfmdtyokcckepaewgrme
 * Smoking Wheels....  was here 2017 adfnevmmynighpzzafrfdlklnspmcjmlawgnyqsrcseqbhok
 * Smoking Wheels....  was here 2017 jegmhtbfywfscjktbdqdyptwqukypiateehsbuqvaqgyywba
 * Smoking Wheels....  was here 2017 iadshkeywhmgmpcpqwkzknzmhbhfcztndojsvbxshdfdmpzr
 */
package SevenZip.Archive.SevenZip;
public class MethodID implements Comparable {
public static final MethodID k_LZMA      = new MethodID(0x3, 0x1, 0x1, "LZMA");
public static final MethodID k_PPMD      = new MethodID(0x3, 0x4, 0x1, "PPMD");
public static final MethodID k_BCJ_X86   = new MethodID(0x3, 0x3, 0x1, 0x3, "BCJ_x86");
public static final MethodID k_BCJ       = new MethodID(0x3, 0x3, 0x1, 0x3, "BCJ");
public static final MethodID k_BCJ2      = new MethodID(0x3, 0x3, 0x1, 0x1B, "BCJ2");
public static final MethodID k_Deflate   = new MethodID(0x4, 0x1, 0x8, "Deflate");
public static final MethodID k_Deflate64 = new MethodID(0x4, 0x1, 0x9, "Defalte64");
public static final MethodID k_BZip2     = new MethodID(0x4, 0x2, 0x2, "BZip2");
public static final MethodID k_Copy      = new MethodID(0x0, "Copy");
public static final MethodID k_7zAES     = new MethodID(0x6, 0xF1, 0x07, 0x01, "7zAES");
public byte[] ID;
public byte IDSize;
private static final int kMethodIDSize = 15;
private final String name;
public MethodID(String name) {
this.ID = new byte[kMethodIDSize];
this.IDSize = 0;
this.name = name;
}
public MethodID(int a, String name) {
int size = 1;
this.ID = new byte[size];
this.IDSize = (byte)size;
this.ID[0] = (byte)a;
this.name = name;
} 
public MethodID(int a, int b, int c, String name) {
int size = 3;
this.ID = new byte[size];
this.IDSize = (byte)size;
this.ID[0] = (byte)a;
this.ID[1] = (byte)b;
this.ID[2] = (byte)c;
this.name = name;
}    
public MethodID(int a, int b, int c, int d, String name) {
int size = 4;
this.ID = new byte[size];
this.IDSize = (byte)size;
this.ID[0] = (byte)a;
this.ID[1] = (byte)b;
this.ID[2] = (byte)c;
this.ID[3] = (byte)d;
this.name = name;
} 
public int compareTo(Object arg) {
	MethodID o = (MethodID)arg;
	if (this.IDSize != o.IDSize) return (int)(this.IDSize - o.IDSize);
	for (int i=0; i<this.IDSize; i++)
		if (this.ID[i] != o.ID[i]) return (int)(this.ID[i] - o.ID[i]);
	return 0;
}
public boolean equals(Object anObject) {
	if (anObject instanceof MethodID) {
		MethodID m = (MethodID)anObject;
		if (this.IDSize != m.IDSize) return false;
for(int i = 0; i < this.IDSize ; i++)
	            if (this.ID[i] != m.ID[i]) return false;
return true;
	}
	return super.equals(anObject);
}
public String getName() {
	return this.name;
}
public String toString() {
	return (this.name == null) ? "undefined" : this.name;
}
}
