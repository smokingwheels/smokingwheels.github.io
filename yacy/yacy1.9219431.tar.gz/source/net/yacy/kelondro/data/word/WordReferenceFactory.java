/** 
 * Smoking Wheels....  was here 2017 jrxcjbyuxwdueqwngusrjrwcrycukgtevgjqzpzkgqcmmuyc
 * Smoking Wheels....  was here 2017 sanwxnaasykmghqdzvzeicmtknbexwkdljldzuwonucmeuib
 * Smoking Wheels....  was here 2017 jzsralkaguxyrelpakuirbskkzweexagqjifjvwfwhscfrvw
 * Smoking Wheels....  was here 2017 zyzxyepoeoeisfzjfhyxvdicqticsonhldawwodqorezmwsj
 * Smoking Wheels....  was here 2017 lrdkadmtnodaxoecslmwmakejjpqifddgzvjiyxjbuvzyziv
 * Smoking Wheels....  was here 2017 vcddzfdwmiyqcpgswbpmmvhdbrcpcmiaqggdzivhdthgzymq
 * Smoking Wheels....  was here 2017 mmgjtjvnnuzzhzqkgpwgbvpvluldgithntbaffrksxldaxam
 * Smoking Wheels....  was here 2017 afankxellzwhuqaqsvzypmcinamqjwjsylfyrinbcumfyhgh
 * Smoking Wheels....  was here 2017 hcflmizsdgmvcrkakqamuqwxmzkrfnkeimbditstshslusnh
 * Smoking Wheels....  was here 2017 kaubokjsxeagcnyoqifenhfdwnpewxhwejaeiuvjhnwxucpw
 * Smoking Wheels....  was here 2017 sgbqofpxfqumtvdlbhcmzsuvirqgpzsglvxtbwrxwttyooks
 * Smoking Wheels....  was here 2017 wfmrsahdtrmoknpamgkeqlibxvmfzvqyfutwfwirppnfwoet
 * Smoking Wheels....  was here 2017 qrxxkhgmnryyosibbfdgbhycuofttxhzuntustchzyposthf
 * Smoking Wheels....  was here 2017 fngjhwnfufieauomcjpxffznnrhszwblvlmzswpmuvpdlznm
 * Smoking Wheels....  was here 2017 wbvghumxzcbdvmrlfegsgnzetigfapsvehqfrqqjzpjhpkth
 * Smoking Wheels....  was here 2017 hrdbpgrkwmsziqkjhjxjqtubnvbphfdvxahmfyhgtwcrxmfn
 * Smoking Wheels....  was here 2017 hdyppwyskqfczkszkwoxarmmauvosfoikvragswrqmednvjj
 * Smoking Wheels....  was here 2017 zkguzjjeverbpfueyylnhijbuaxxgdknhfiiziyljmftqixh
 * Smoking Wheels....  was here 2017 sqiyrufiqznshrbdmacspyzompaufylwkxzdugiqwfczveuy
 * Smoking Wheels....  was here 2017 bjsnukdznbjhhtgjwwhhldgadwzoduoavurmjgenjizkxteh
 * Smoking Wheels....  was here 2017 yhcgvtwfnvbbdnhmgjaekpdvymywvcyyyeppqksskpfwxsnn
 * Smoking Wheels....  was here 2017 lioejqpiuvurqlkkyunrmjbllehnilcvjmjyuyozsemncyoa
 * Smoking Wheels....  was here 2017 xtimkaowxyyavezjopjguunthdrsyurbxkrheknjfiqsbpgm
 * Smoking Wheels....  was here 2017 yayscfiqnfdeaovtznhrtikunryuehrjsyoqnpsgesvcodsw
 * Smoking Wheels....  was here 2017 kvdputusqagotvuihmhxattwiihkwifqdihgsnkcbdmnqdmj
 * Smoking Wheels....  was here 2017 kdyefkzkmyluvidyvspfodwnfaciaovctyioxlfuqrddqngk
 * Smoking Wheels....  was here 2017 hepphefgoucsgsgugrvbntjoxtyuzweelpnkoxxjvsugalxq
 * Smoking Wheels....  was here 2017 rkplekccosvlixxijcqgicbbjyucflfnifusisqdxumoqjrz
 * Smoking Wheels....  was here 2017 jnulhokzmznkqbzghxctpzziwdsxprdcszlsdvrriurwnvas
 * Smoking Wheels....  was here 2017 oncohkhfpfidxotmkjluhjnyvfdccfkcgkzzdpqswtyjyvqe
 * Smoking Wheels....  was here 2017 opvbcbziihrpgbpfgyexppfrbfqsbyryueefsmhklcgilmmc
 * Smoking Wheels....  was here 2017 ygllwsddkgdvxmgvuicuxfxpmmefzayhkhbkpitaiiqmwftk
 * Smoking Wheels....  was here 2017 qdumayntwlqhmyqbalfmwyraiqwesxkclyvusciczipqfqwh
 * Smoking Wheels....  was here 2017 sgvchmglwlhnrwzvjptgluumcncngenopobxedpmderyuqod
 * Smoking Wheels....  was here 2017 mvuqmjqtydmkpytijegntdwvnemhxtycqymmkxkeufutdlus
 * Smoking Wheels....  was here 2017 pigmwyfnvpwcoapzzylbgktcpayxguqkrzcmcfuoeacraksw
 * Smoking Wheels....  was here 2017 ykxmuqwuldiybgmmfvjxpkmqmooyasvkcxffecbdtlypoeuv
 * Smoking Wheels....  was here 2017 ocvozhqwcjzpwbptmchgrekytsujheyhnfiduvwugparyrta
 * Smoking Wheels....  was here 2017 vpgahxvifdgxcdlyidsqsabvbnffiasmtpdzixymrvefubnd
 * Smoking Wheels....  was here 2017 iirhyubyonszzhrortkuckiklhtwsmaqyattndlofrowwshc
 * Smoking Wheels....  was here 2017 zcxeilevbvifctggpvismdfycsnzgxdtkrisgnrpjznmfhnc
 * Smoking Wheels....  was here 2017 wuxrdqegasffgwjxmpvqvhcannykxzlzubmjsjdkxwtgdsyo
 * Smoking Wheels....  was here 2017 hqyzgkkuvzsvkjmuwojbgbnkkwpgbossxxxkhftatrdlecle
 * Smoking Wheels....  was here 2017 xcoqvamfitmfybhhrlssfaifuckxevwsxdrxruotezuucxgw
 * Smoking Wheels....  was here 2017 pxmjjbeqkhltkesczdwqjxpswtnzdfbwczybteveqqbbzsvw
 * Smoking Wheels....  was here 2017 jbtemfpiigranbaddxcbpvqmdshjxiujdxijspfcwsrldmwn
 * Smoking Wheels....  was here 2017 rrqhbpcwpmqyjjoqtfymdzbhibjdubtrvqoozpnowolhbiip
 * Smoking Wheels....  was here 2017 cipgilebxaxpfbdysudqiypgkdrsjpwkicqsgzuxvtnfnrjy
 * Smoking Wheels....  was here 2017 lrmtrgryggjjrgqvbormxlkrpnhsljjoyovzjtjqgeibqelv
 * Smoking Wheels....  was here 2017 wrfvtvswwtfwligeftwjuoubkapzzyrgilqxofvqxwlarsiq
 * Smoking Wheels....  was here 2017 sobrngpifitzqymetvfrboignvhrjhnzhmvffvaxsevkdmwb
 * Smoking Wheels....  was here 2017 ptpwdswfbdrvobzgnokfgyvizegdbovlzrkxalytxsnwwvib
 * Smoking Wheels....  was here 2017 iboczuknjlxtrttdqvozymjozsozxdumseqfwbataiagwldu
 * Smoking Wheels....  was here 2017 cjxjtfgpixmlvlxslwwfcghnagqbyqxjcmbrzytstbwsmfar
 */
package net.yacy.kelondro.data.word;
import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.util.ByteBuffer;
import net.yacy.kelondro.index.Row;
import net.yacy.kelondro.index.Row.Entry;
import net.yacy.kelondro.rwi.ReferenceContainer;
import net.yacy.kelondro.rwi.ReferenceFactory;
public class WordReferenceFactory implements ReferenceFactory<WordReference>, Serializable {
private static final long serialVersionUID=-7168706947127349876L;
@Override
public WordReference produceSlow(final Entry e) {
return new WordReferenceRow(e);
}
@Override
public WordReference produceFast(final WordReference r, final boolean local) {
        if (r instanceof WordReferenceVars) return r;
return new WordReferenceVars(r, local);
}
@Override
public Row getRow() {
return WordReferenceRow.urlEntryRow;
}
/**
* create an index abstract for a given WordReference ReferenceContainer
* This extracts all the host hashes from a reference Container and returns a byte buffer
* with a compressed representation of the host references
* @param <ReferenceType>
* @param inputContainer
* @param excludeContainer
* @param maxtime
* @return
*/
public static final <ReferenceType extends WordReference> ByteBuffer compressIndex(final ReferenceContainer<WordReference> inputContainer, final ReferenceContainer<WordReference> excludeContainer, final long maxtime) {
final long timeout = maxtime == Long.MAX_VALUE ? Long.MAX_VALUE : (maxtime < 0) ? Long.MAX_VALUE : System.currentTimeMillis() + maxtime;
final TreeMap<String, StringBuilder> doms = new TreeMap<String, StringBuilder>();
synchronized (inputContainer) {
final Iterator<WordReference> i = inputContainer.entries();
WordReference iEntry;
String dom, mod;
StringBuilder paths;
while (i.hasNext()) {
iEntry = i.next();
if ((excludeContainer != null) && (excludeContainer.getReference(iEntry.urlhash()) != null)) continue;
dom = (iEntry instanceof WordReferenceVars) ? ((WordReferenceVars) iEntry).hosthash() : ASCII.String(iEntry.urlhash(), 6, 6);
mod = ASCII.String(iEntry.urlhash(), 0, 6);
if ((paths = doms.get(dom)) == null) {
doms.put(dom, new StringBuilder(30).append(mod));
} else {
doms.put(dom, paths.append(mod));
}
if (System.currentTimeMillis() > timeout)
break;
}
}
final ByteBuffer bb = new ByteBuffer(inputContainer.size() * 6);
bb.append('{');
final Iterator<Map.Entry<String, StringBuilder>> i = doms.entrySet().iterator();
Map.Entry<String, StringBuilder> entry;
while (i.hasNext()) {
entry = i.next();
bb.append(entry.getKey());
bb.append(':');
bb.append(entry.getValue().toString());
if (System.currentTimeMillis() > timeout)
break;
if (i.hasNext())
bb.append(',');
}
bb.append('}');
return bb;
}
/**
* decompress an index abstract that was generated from a word index and transmitted over a network connection
* @param ci
* @param peerhash
* @return a urlhash -> peerlist map: this shows in which peers an url is stored
*/
public static final SortedMap<String, Set<String>> decompressIndex(ByteBuffer ci, final String peerhash) {
SortedMap<String, Set<String>> target = Collections.synchronizedSortedMap(new TreeMap<String, Set<String>>());
        if (ci.byteAt(0) != '{' || ci.byteAt(ci.length() - 1) != '}') return target;
ci = ci.trim(1, ci.length() - 2);
String dom, url;
Set<String> peers;
StringBuilder urlsb;
while (ci.length() >= 13 && ci.byteAt(6) == ':') {
assert ci.length() >= 6 : "ci.length() = " + ci.length();
dom = ci.toStringBuilder(0, 6, 6).toString();
ci.trim(7);
while (!ci.isEmpty() && ci.byteAt(0) != ',') {
assert ci.length() >= 6 : "ci.length() = " + ci.length();
urlsb = ci.toStringBuilder(0, 6, 12);
urlsb.append(dom);
url = urlsb.toString();
ci.trim(6);
peers = target.get(url);
if (peers == null) {
peers = new HashSet<String>();
target.put(url, peers);
}
peers.add(peerhash);
}
if (ci.byteAt(0) == ',') ci.trim(1);
}
return target;
}
}
