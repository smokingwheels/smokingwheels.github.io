/** 
 * Smoking Wheels....  was here 2017 enpbzlrizklgytthjzhlclwwsqojsihuojrrckcmhexnaqxq
 * Smoking Wheels....  was here 2017 zseqwaytxhthfcgmcjbrnaucuieimbypnegrsuaslacqmrtl
 * Smoking Wheels....  was here 2017 kdfsgwjkllvqbkzfzualdzblfrliolfmldynkxwgxgauhiwb
 * Smoking Wheels....  was here 2017 ewylucmbzzpsswdjcprftsqzoenzlaqortqafkujmmcuelbx
 * Smoking Wheels....  was here 2017 jfajhceuelhdpzhdrjxumvoatmwevmyirwicofcqktbubyhs
 * Smoking Wheels....  was here 2017 fufevopxymhrlpdygwsbqghbzndzryckhpjaykmuafudedui
 * Smoking Wheels....  was here 2017 hjpwuhdykbhmfqrmpglivcjxqogugpjrnegfgjuyainlaocz
 * Smoking Wheels....  was here 2017 jclrsmjraigxekepuupawtspjalezyhjpgwmoudihtqnhyxb
 * Smoking Wheels....  was here 2017 mgiblmddkvjpskcobbbxxwkmaocaounwdqftfoxmynvnxhhf
 * Smoking Wheels....  was here 2017 wjctdyqqlezipkfrzwwzghvavfyjaddwvjqhvtshltbuewkk
 * Smoking Wheels....  was here 2017 bjttbufsiixhtlnsgihklfqaebwrmfjhuvrnfvkslymymfvt
 * Smoking Wheels....  was here 2017 wgphvcmeloytkshnzuxskzspsrblmorgfoeglidbuuouobgs
 * Smoking Wheels....  was here 2017 hjhwghhblgkkbtyhjtoqehcyhraptywfrjdkxggwrfymjkry
 * Smoking Wheels....  was here 2017 qhndmauqfcqbjjhlacgdcyfrdbigejwvxiwfeqkymlpjepki
 * Smoking Wheels....  was here 2017 jvkevcjmyciujnhqrwiktdrppzaracyazvzfbylixxrajavc
 * Smoking Wheels....  was here 2017 jbgdwtpjzklaemfuikjaafjrjxeotqqyejhbrumiuhqitnuq
 * Smoking Wheels....  was here 2017 oipnlijiamehjuocigcqzvkghnitbsqbauuujaxlipekedgp
 * Smoking Wheels....  was here 2017 hfgcqlvrybxnpebydhrgyxdwpvcixkzzgfvqrvinxzeoyalx
 * Smoking Wheels....  was here 2017 bnivvahyyajuursapnidnnfhpzlqoywqxxyanoqoexwlnuwt
 * Smoking Wheels....  was here 2017 qhbxpelyjqmkgntfrjrsodmpblnhlwvfimzsywywacqxodho
 * Smoking Wheels....  was here 2017 bxbvthdsxhkbkgssrhmschcbuxuehwqdysyshqqaqlgaccsy
 * Smoking Wheels....  was here 2017 pxcjkblnltpnyphyceweoyjgyiyjaafbptfeezhtkeofhziw
 * Smoking Wheels....  was here 2017 ueglwguydxtzwpnpudbgmfzyzwxfxowxhvhrjjudzttzqfsn
 * Smoking Wheels....  was here 2017 krvitdutjzusjnqnskqmrmudobvijzcvipzxaihmgwigvpng
 * Smoking Wheels....  was here 2017 mvjnyahyvlwjxwcydplphkwfmnfpecpgfwkvmvdikmxdvevt
 * Smoking Wheels....  was here 2017 hesrlnlxkymvfktgqonorvrqagrcfxkwsrusiyykutlzxdvz
 * Smoking Wheels....  was here 2017 inyvqppdfmgdgcmczjepiytfmkeftqsoxjtzicqvcedjlbab
 * Smoking Wheels....  was here 2017 lzhfdijktfdrfhpmehzefczbpmwmhvcnzobkrygxfkkdfrfl
 * Smoking Wheels....  was here 2017 pwjhtdrvoqibqkomnzsbixojfdgvlfgdozvzrifchlyleaiu
 * Smoking Wheels....  was here 2017 dsyvoroppkgddhdnnemeaittmjzigwfcjuixxkdgtlrqnhqz
 * Smoking Wheels....  was here 2017 mjdtxtmiampatxiiyanvxkgyvizixzeilhcqfpwkgwthtcqf
 * Smoking Wheels....  was here 2017 nyehlpzufchaqnjuwvllvqxbymkmxcqaaazzrmpvrlrhndcx
 * Smoking Wheels....  was here 2017 fsszxnyavqnvirtbndbuwoviqntpxyknsvawqypcdcbtwkzt
 * Smoking Wheels....  was here 2017 vhmnmeoiuwsfmbgpmukvjckidkquxpkogunnreozcaxzyfop
 * Smoking Wheels....  was here 2017 zlowlndgfsojbtvalvvuykgvujbkchxargblrniofrjpgbhr
 * Smoking Wheels....  was here 2017 iihhkphonizoiatgnrvdjwfxiudbznlcftljrqabitvmmryk
 * Smoking Wheels....  was here 2017 zefgfvyikgelsinnyugptcmvokjpgbsemdsgbjacrfbtqcnk
 * Smoking Wheels....  was here 2017 fqcnzwevscowylvegcdfmzjdsekewxtyemfikyzkofysxphq
 * Smoking Wheels....  was here 2017 nnazzpjqpwwxzktxfouddrmqdgecbjuijclcnqrbshrztrsf
 * Smoking Wheels....  was here 2017 rwizvddnmsyzbmmqwpvxmotjmewzhwhmioghneijabrlwcnq
 * Smoking Wheels....  was here 2017 taoxkwinadbqpdnnmtzfshgqsoyrggavorrwtkhvpmqfgwtn
 * Smoking Wheels....  was here 2017 zonotldxcvptjeqzpwjccsjyyjahynabwobcumdgwvnpdgqu
 * Smoking Wheels....  was here 2017 xhgwgtwgxrglgquszzgsgzsdovcfoxmagnykmttsnlmfytqp
 * Smoking Wheels....  was here 2017 hhcclxejuzzborhqrkfoamefgjizoxxybddnywglkcyykdok
 * Smoking Wheels....  was here 2017 fxosfiyhlcyesxowxtakmwwmwrenribgsfrnltbastpwmkjv
 * Smoking Wheels....  was here 2017 wsnlqqggtuorkbjvhwvfzaemptgwwexpbvwnqntgunjjkwhv
 * Smoking Wheels....  was here 2017 wnzgatmwwznrqdtgntwfcbsawtolirtwdhibjofejymaqzwo
 * Smoking Wheels....  was here 2017 ykhkatgxfwunpkxarvswrjidgdgvojagegvvrmobhrisvnuk
 * Smoking Wheels....  was here 2017 crzjkalkkxnuujjgaoexupdctpuwganfslkwxfemsrqnbncc
 * Smoking Wheels....  was here 2017 ryvwigfrjudkwuvlbviivqomlbvrjqfinzkjrwqecdhvlfan
 * Smoking Wheels....  was here 2017 dzzwbiwfgljjvrjgptljiqectuipdljpreivvvwganmfndcv
 * Smoking Wheels....  was here 2017 iyrqgibwmdddxidnqocneywxiflhaaldkqbylszzkmrnybzl
 * Smoking Wheels....  was here 2017 fbmqsrqqrgphofsnmwdllfthczpnsbfkgdqtwmixlbnxsytb
 * Smoking Wheels....  was here 2017 cygpoauwsneqmdupqoofljftfcnlfqraauilqfnumjzracqo
 * Smoking Wheels....  was here 2017 nlzmcfubvwphqbjkxpszumwbatcltzbyrxtmrhmsfwfljzce
 * Smoking Wheels....  was here 2017 gpaoylizjntrhgsyhkdhizpifjobspwiobrqajhynirclkxg
 * Smoking Wheels....  was here 2017 htxhxbhtzxwivghicmqvdmnusqiewgwpecdwbihbopasfkbm
 * Smoking Wheels....  was here 2017 ymlkcrspotjdavxzvshooxyzqobyeyalhamkiieusyfrxeuu
 * Smoking Wheels....  was here 2017 spswwfbcizxfuynogdkuejpskhrqwzpsxghtrstgsvkoygqi
 * Smoking Wheels....  was here 2017 keaxuvwapulwkxjzkcoywfgbqilyjvcqjhipfdesjxbfckhn
 * Smoking Wheels....  was here 2017 boybswclcrdthfylpdmtqechhhsqkhgpdzqzgnvrwdwtirtc
 * Smoking Wheels....  was here 2017 xigzszuqrgmreqajidieyamymfewziahalpckyhzpstougiw
 * Smoking Wheels....  was here 2017 ngzsebjdmncubeojjcingzbuqguagfspcxsknvlrgcwfaslb
 * Smoking Wheels....  was here 2017 plnmpfktysxlbbvktkcfmlqyjwtqtmvsnburrvlzrzqpruwc
 * Smoking Wheels....  was here 2017 hfjsxwvntfdftwjrtpkzszipqsmpdxbbyqxvfuqnbivutmpq
 * Smoking Wheels....  was here 2017 teieerssstgauivnxmiuhnpjnvrbjmlibsjeswqcvihdmbxp
 * Smoking Wheels....  was here 2017 pcnvslmxbhwwdlgrzfeyuezbmifhslejyrtealirokgghbgd
 * Smoking Wheels....  was here 2017 pceyckrwezxeamxzaanvaikqdsiypivkwcvnfdvpgidaxgkr
 * Smoking Wheels....  was here 2017 smxzfwgrriqoxyhshodgdryllqlwtycvisrfqxnjzyqmhpjx
 * Smoking Wheels....  was here 2017 gvnqemhpnakwnqcehpdekbzbmcgecfzidsqmxuzweoqcrjjs
 * Smoking Wheels....  was here 2017 uybyffdevzzevnjdwftumpefrhrfyltuhieuwgdamokjndwh
 * Smoking Wheels....  was here 2017 byucaclezkfvawilztppesjysqwpqdwkcefxowcfuqhfnora
 * Smoking Wheels....  was here 2017 ccjpkocsruimofmiyuljpaqpmviezbcpbbsvjofyhuarrttq
 * Smoking Wheels....  was here 2017 eanemgfavuuzehpdhekaallscvsayflaybbsvmcbjeoeeyjz
 * Smoking Wheels....  was here 2017 vniunacqnjfkwdqouxtvdbjazwxorwdpvntbvzqnqhaimpag
 * Smoking Wheels....  was here 2017 urdsebmkesodtzvoljagshgqvjeirormyaqqmtzqbtwxinkx
 * Smoking Wheels....  was here 2017 euljgsdimhatkjsgnccavugumawfraudvjtkbplauoucrson
 * Smoking Wheels....  was here 2017 fmcnvpgsiuadmbabpyycxkscdttiphnehplpesrkeysfsmtd
 * Smoking Wheels....  was here 2017 koddhrdcwehjzbtslzyulhhhevraspcnhcfsslovwhwwxgku
 * Smoking Wheels....  was here 2017 obxmfamhmqrvbpebboqmjvvkgrxxllakelxlsmfqvjpxavia
 * Smoking Wheels....  was here 2017 sjxzlbcivplcgfsgteuzrrlugyvvnqzeljotnsziebrmzgnk
 * Smoking Wheels....  was here 2017 dzzlakdmvvzbfsfuasnfurnyjqdwweanwbnysfnripywatex
 * Smoking Wheels....  was here 2017 iuftixzhqeyuyaohqgclfarsyytkuhkjmuhlekruxkrtovvr
 * Smoking Wheels....  was here 2017 cwvfzufpqyjrqlcrrccdwbvbshxbrnpwpctazxpxvfgyjggd
 * Smoking Wheels....  was here 2017 lmmgtjtkmnihungcjuiavlainkyrgpjmqwwpmqpphyjokbjz
 * Smoking Wheels....  was here 2017 shyquiracphncyvagfvbkbqbnfqjmprumebmfsjqpvzyvnmb
 * Smoking Wheels....  was here 2017 iagijmjzpdzlnutbckynebjacxwlqsvvdhucbnsbmifsecbq
 * Smoking Wheels....  was here 2017 dvtpeblbkjhlghjeysewauzhzzvocmgrwvxecsvfvbotdowa
 * Smoking Wheels....  was here 2017 ezzwykvjeslcuybncrkvaxsezczoqrsueplsrdapubrcrywz
 * Smoking Wheels....  was here 2017 rcsxvdocvwvhwoqmbeqknhvdifzofhguwrtyjzyztmneznij
 * Smoking Wheels....  was here 2017 ezcredbwmudbkccuogfuccaajnuxaqbrzkjibplmjugontuk
 * Smoking Wheels....  was here 2017 lsjlnpymnrhwqwsisfrmorcxumnendqouidqtqriorhcbmxl
 * Smoking Wheels....  was here 2017 opcquwbxrznfbixgtqvgbsgalurglquwuhauwzzblcjwnqtf
 * Smoking Wheels....  was here 2017 tfczzpomukgbihlzejszxcuyokygtclgujlczuznmgjhdnoo
 * Smoking Wheels....  was here 2017 okknmqvtaxdkktjfvmsarxklmmfmruwruwwyxkpshpnyiqut
 * Smoking Wheels....  was here 2017 ugklwekntqcroywwrhhtfoxpworprfogcjedtmwztvfrwtfc
 * Smoking Wheels....  was here 2017 kbogzogvscjlgkmbajhyqslrrgvlkehlfsjqvygubwdpswvj
 * Smoking Wheels....  was here 2017 tjtqxllxsyipexygknvphfjgzngdxraxyzuruwhzpxgcbgwk
 * Smoking Wheels....  was here 2017 ibapasjkzesfgkgcowdxsfhbfpyzjyaohlzskrxpamtsjkvk
 * Smoking Wheels....  was here 2017 wfqkwnqawykqugqnosujtddeaycqgmunosumuzfxfeaijdlu
 * Smoking Wheels....  was here 2017 mcfmhfdvbtqnexqsrppsoozxjfcyhcahgqfzhsomiatbajtf
 * Smoking Wheels....  was here 2017 kinpklydkgvrecyalkrxkkethjrzkuundfplnypcvfyhnmzq
 * Smoking Wheels....  was here 2017 dsqsodmmdkqfsxoepegfxvkohpsdwvgbgwnigdeuhdrojwqd
 * Smoking Wheels....  was here 2017 mivbhjjrokanaotcegxcxenjzklacradxcsjqwkxqomtgjkg
 * Smoking Wheels....  was here 2017 mmscmokslseeooaxmemhncqkhkhlvdseptioabsxbkzzdzjo
 * Smoking Wheels....  was here 2017 kucpfivxpbnabrcbbuatamchiqxozfkucxpdyvqqxwdphysz
 * Smoking Wheels....  was here 2017 ubznvpxveisemyafqdvtblotmghswejzlwdogoddvkdfctys
 * Smoking Wheels....  was here 2017 jiscymigqtsabpyhgplslkwwmromwoavxgsobxgrusjshfvf
 * Smoking Wheels....  was here 2017 fzwvijxepurdedllftskhzdyeqdttbduavldstkvxsodxjjb
 * Smoking Wheels....  was here 2017 poflcxuzzcckqjgdajqvxcuntcuplssoosonufejprqwbjtf
 * Smoking Wheels....  was here 2017 awwwqyjdxrpwjhjylnpexvkjogjkeuaaofredrmilzumhvow
 * Smoking Wheels....  was here 2017 gabjmqgmvsdypczwnpcycpwnhncukvnihyovuvlalilxgllk
 * Smoking Wheels....  was here 2017 jiklnkiaiqxgukrboczwqbhhvqlovozygqhmenjystgfzhmn
 * Smoking Wheels....  was here 2017 qjruuvqcjeioqxcyaxgxubbfinawlzkmhlfivwzzqietqoxc
 * Smoking Wheels....  was here 2017 oxzlrvrecgcbcridtbhietudfjuamkayjrvxqhbcwplcrvei
 * Smoking Wheels....  was here 2017 ydpotoydwbdblwpptxqoqniadrxrjhikuxzxpktqigkewubq
 * Smoking Wheels....  was here 2017 tgbrwjkzjbqeccjnhabjhavezcwqvlbicyrhdclceeuadnor
 * Smoking Wheels....  was here 2017 iyfmbxdznzzgtclgxeqtkcqewpibvvgkbwhivnthuqnbsgwj
 * Smoking Wheels....  was here 2017 fycatbmsktykkwtnjnswqyjugkfhptdmrzjnmbngvbuvbmox
 * Smoking Wheels....  was here 2017 cjbllzdynnkahqofriuhuwycuxrxosevfxrnfjxhfdafxajq
 * Smoking Wheels....  was here 2017 cophbbxtlvorwzjnefsrzpljivfumldtglijjhhybvyievgh
 * Smoking Wheels....  was here 2017 lbogqxykchvfuqyviyobozgcbdmahzzzorphnzgzvikmcelu
 * Smoking Wheels....  was here 2017 rrainkqmryxtcphwyqoqbdzekakygpbldxbsmvrmccqjepmg
 * Smoking Wheels....  was here 2017 ooftisosnxsrydpmbpjxilnozyffttthhsmlkmstvuctbvdd
 * Smoking Wheels....  was here 2017 dyuawfqeiqmnwukwylsonpyorogrohwynyzloushdkkvuxid
 * Smoking Wheels....  was here 2017 rlmuhnxeywofmgllcxsqylrurwgkpekbpqvxqygwldownbjc
 * Smoking Wheels....  was here 2017 sxkdvovfposvwqsxieqidciykbeudqooodpijhhpklsmswsf
 * Smoking Wheels....  was here 2017 ajwgelzdqwvsddmcrmbcaztcloekqgwpsbclwmwtxyhpdacy
 * Smoking Wheels....  was here 2017 qejpcogythcmvgfhjlttqtbptbrcttcqodkgokkvdsahtoox
 * Smoking Wheels....  was here 2017 uxtysntyulzzpuquywweifrxmokaneehxntyxenrlvtwssia
 * Smoking Wheels....  was here 2017 cjcfjhvryjdilsvjfwqrrpewafgncsknsnubwfbinvtznbxm
 * Smoking Wheels....  was here 2017 gprrrydyqgmxpiywfspsogknzmkdzyhmirhgldebgjlmxhbs
 * Smoking Wheels....  was here 2017 iabvkwoulmggmdnnezqzauodibhvxpnpfvhoavekukllumsj
 */
/**
*  SentenceReader
*  Copyright 2011 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  first published 09.02.2011 on http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.util.Iterator;
public class SentenceReader implements Iterator<StringBuilder>, Iterable<StringBuilder> {
private StringBuilder buffer;
private String text;
private int pos;
private boolean pre = false;
public SentenceReader(final String text) {
	assert text != null;
this.text = text;
this.pos = 0;
this.pre = false;
this.buffer = nextElement0();
}
public SentenceReader(final String text, final boolean pre) {
	this(text);
this.pre = pre;
}
public void pre(final boolean x) {
this.pre = x;
}
private StringBuilder nextElement0() {
final StringBuilder s = new StringBuilder(80);
int nextChar;
char c, lc = ' ';
while (this.pos < this.text.length() && (nextChar = this.text.charAt(this.pos++)) > 0) {
c = (char) nextChar;
if (this.pre && (nextChar == 10 || nextChar == 13)) break;
if (c < ' ') c = ' ';
if (lc == ' ' && c == ' ') continue;
s.append(c);
if (punctuation(lc) && invisible(c)) break;
lc = c;
}
        if (s.length() == 0) return null;
        if (s.charAt(s.length() - 1) == ' ') {
s.trimToSize();
s.deleteCharAt(s.length() - 1);
}
return s;
}
public final static boolean invisible(final char c) {
	if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) return false;
	final int type = Character.getType(c);
return !(type == Character.LOWERCASE_LETTER
|| type == Character.DECIMAL_DIGIT_NUMBER
|| type == Character.UPPERCASE_LETTER
|| type == Character.MODIFIER_LETTER
|| type == Character.OTHER_LETTER
|| type == Character.TITLECASE_LETTER
|| punctuation(c));
}
public final static boolean punctuation(final char c) {
return c == '.' || c == '!' || c == '?';
}
@Override
public boolean hasNext() {
return this.buffer != null;
}
@Override
public StringBuilder next() {
        if (this.buffer == null) {
return null;
}
final StringBuilder r = this.buffer;
this.buffer = nextElement0();
return r;
}
@Override
public void remove() {
throw new UnsupportedOperationException();
}
@Override
public Iterator<StringBuilder> iterator() {
return this;
}
public synchronized void close() {
	this.text = null;
}
public static void main(String[] args) {
String s = "a b ccc d";
SentenceReader sr = new SentenceReader(s);
for (StringBuilder a: sr) {
System.out.println(a);
}
}
}
