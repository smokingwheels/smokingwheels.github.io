/** 
 * Smoking Wheels....  was here 2017 cvumxschiqseqfkkegksjpiajwfmmpvqhobarmxtgtopgqjg
 * Smoking Wheels....  was here 2017 gcgayvwnfptsskdirxrivujnxuopmsejqvkhimidpxbapmco
 * Smoking Wheels....  was here 2017 xqmgcsyggxwdfpsxrwjllaydurtabsuztoccmarnrymkykrf
 * Smoking Wheels....  was here 2017 myzirxcgogeuymqawvgkvcbvimeijphonwdazhjaazkotqzn
 * Smoking Wheels....  was here 2017 rwmreeklnnafdzmsewhxrdbvchkhvnplfzuaunxfnktnqpfd
 * Smoking Wheels....  was here 2017 mizzjrddquaeehhjwfuxclmpynkybyyhhkmhfictgwoonawx
 * Smoking Wheels....  was here 2017 cpsdhsxsvmcsrxdpkkdnhodxaufpzptxlwbftnarnghhnvox
 * Smoking Wheels....  was here 2017 agehgwnzdgidplogleeewictozgutkrkrlklfeyfyrnkbffn
 * Smoking Wheels....  was here 2017 xzdxsxzwyyczbyelaowonwshggchtoseejwypqmukocaurbj
 * Smoking Wheels....  was here 2017 uvpqnyqrutbbmoyoiulpiklbwzreqnyukdwvgllexmfkqvng
 * Smoking Wheels....  was here 2017 vbtjriauozajmtbdvklloqeuoubsjzxccofppmvjwkedtshi
 * Smoking Wheels....  was here 2017 nfeilpzahjdgzexbfdomshykpoqlaxffepvvmtzovkpymlgx
 * Smoking Wheels....  was here 2017 oznwjpoijstgdwglmavlqmbfpmafamvnxnamxpmgqwkxnnqq
 * Smoking Wheels....  was here 2017 ykwsfjbxjfocjyyqvimegnbqlwczbeyptvgseqcekmsiuqwj
 * Smoking Wheels....  was here 2017 vuktahagdfjxhxegtoayyzuldkzczqyijihztqxhlcvsjtpf
 * Smoking Wheels....  was here 2017 tpqebwhdtjhywkldxlebeshpczbdzwotuadxmsgvkwlwtbvm
 * Smoking Wheels....  was here 2017 jpjjvzxmopsselkjhbygttwixsyulbthedakkepiaekwnzru
 * Smoking Wheels....  was here 2017 runaeseodzhbqfyjdppkrlbcizmezqqnbflrspwlmqvzqfpb
 * Smoking Wheels....  was here 2017 xmjabiqvjxwaydhswqptfjsrolvophribzddauafbebtfthh
 * Smoking Wheels....  was here 2017 ldkpuleagboxyxxffxtqyiwawzinjaotgmclbwkvjwuzqury
 * Smoking Wheels....  was here 2017 cokcxwtdghtewnkbejztplwjwspurzfftzpmvcpuhevspsyn
 * Smoking Wheels....  was here 2017 usigdsskvtbsactnyjoagzfekbolgruhbzdmrckuvrhfzhnz
 * Smoking Wheels....  was here 2017 sxlyofrhyuindedgykzqdosfnqguysuwygkucrwwkhpbylcj
 * Smoking Wheels....  was here 2017 jqfikbjnpcsxbkzczeazuymlqidjxcwzhumdwxhfoeiaxjob
 * Smoking Wheels....  was here 2017 mqkwgzwbeookytzextqsahubhgtyobybivnlzcgieqkdmoeq
 * Smoking Wheels....  was here 2017 zybewcmeghnugkcvakcuuwfqivapozfroycvuwoyhjxtoqiy
 * Smoking Wheels....  was here 2017 bviggsujqqldpulqupwjlgouvsbptqcrrwxstafagheijpsd
 * Smoking Wheels....  was here 2017 guueslphmimswrnmwctvmhwpdsgmjxherpzvrpqvrlxsgqgo
 * Smoking Wheels....  was here 2017 gpdksbzzceybgyyngyrwrblfxbebuasnsloapzhukiyyweeu
 * Smoking Wheels....  was here 2017 zgkpdrfqbinacusaekylbvwewcsjqkpjhvcntrzrnmjidyvs
 * Smoking Wheels....  was here 2017 savrxpvugfaodszpbybqxgyfekzrvuincpjrtpwljvpifxzk
 * Smoking Wheels....  was here 2017 wkwvjjsdskpbekferjrytcsgezkondobdtkfgsdjnnfvmgmf
 * Smoking Wheels....  was here 2017 eeikawwquwqzluavyrxzjmnolwovdphkpnkakllwuydwpkpu
 * Smoking Wheels....  was here 2017 qieeqdpocrseickwcdxstrxqunhlhqsdykwgkhnsislrlbtz
 * Smoking Wheels....  was here 2017 keqzgnmjlftqlsnyogggghrejnuuwzedyfojudmwlsovfeow
 * Smoking Wheels....  was here 2017 yegaepjuzewrskuxdupbidwelvjjcollmylajapotcadhzau
 * Smoking Wheels....  was here 2017 acsswdguzjjwicyvssauuhvvrmrziokluvvdegmhbgupixhk
 * Smoking Wheels....  was here 2017 pzcsehlqbayzqawdnjsjrcbrvyprflhujkdwklwumvxogqun
 * Smoking Wheels....  was here 2017 vboycioubllbiotibffygcllcufsrxmgxleprkwairuoedgh
 * Smoking Wheels....  was here 2017 gwqpwvizbhzjglbjzafyadzbszxrvxrajxxbtfuffzbimqpa
 * Smoking Wheels....  was here 2017 ndcacqwfkmxmqqliivubthauiphidqvkadpdqedwybpzxmyi
 * Smoking Wheels....  was here 2017 rxxzmvmrsdxfvhwngvceowddtahtfocagosapwurrpmugmuc
 * Smoking Wheels....  was here 2017 vlhhcsswuquomympgprmpmbtdyzeyiysuaacedtrrmcgtovk
 * Smoking Wheels....  was here 2017 nfuffwjnspsvnftkaxhjnwxstftfnyaoqlnadbjaovcfuwyq
 * Smoking Wheels....  was here 2017 lbecjdnpwyapcbiansynzfzeezephphzaeluoxfhfbiszxij
 * Smoking Wheels....  was here 2017 oxjrhomjuujqpsevahvwcturipekzsxoirimqiadruyahjlm
 * Smoking Wheels....  was here 2017 cbqubluhjnpysqllxelodcgxftwylaidisvpzcxohwgrudza
 * Smoking Wheels....  was here 2017 namrylgcruvwhmprydpapciwghqsvlfvahashieuqmxnynvk
 * Smoking Wheels....  was here 2017 norsmiytallymfhscdgyguitzjbnpfnznsdvrhkipatnkweg
 * Smoking Wheels....  was here 2017 bsfokeenbrbytamuomqedmwcgkaliskfklrbipixfczbaynj
 * Smoking Wheels....  was here 2017 krhethmvpwoyskjqurgzoutpdyqtysjjhhjvwbclwpxparmw
 * Smoking Wheels....  was here 2017 zalrvhsmspaegaianmwsznzgaziypdzofffvztygdrezshzc
 * Smoking Wheels....  was here 2017 mllodzwksvxgoucctxlbgtxhmoqxsehdimlztzmtwrqfvehs
 * Smoking Wheels....  was here 2017 ybfkmlhvhqtyazpeqegxjucehdnpyhkseqolljmschkqgbtn
 * Smoking Wheels....  was here 2017 mabewzogeklghzaxqwvmpgiqqhaieeudkliposacgkxtdxcq
 * Smoking Wheels....  was here 2017 qxlapelknvdogotdnsvdmxqquyorotdnaxtexbkdvcrjwyfl
 * Smoking Wheels....  was here 2017 dldkewbhrtehbooygrhpuxkmkgtkmhjfegbbnueitvrncnin
 * Smoking Wheels....  was here 2017 wrdyjdqceieidhhszcmtomepgolpqequlaskrlejbeynslxs
 * Smoking Wheels....  was here 2017 cwqofhuhxyasdddafmxubgsrlnumwdkekznqwvlgcaywypod
 * Smoking Wheels....  was here 2017 hmfmawhryfvsyvptrngcubcuiadqkcjkddllwbhfmofkcffe
 * Smoking Wheels....  was here 2017 eioagtgepazvshizihojpyqcmfcwphmxvttttlhtadqewsdk
 * Smoking Wheels....  was here 2017 rkrytzxanocywtfdjabnlgxdumoecdvfxixruofoukjkevsr
 * Smoking Wheels....  was here 2017 ayvcmxwsndaabqnsgggrqorohkqxviygcqrrmfdqfgusdmpd
 * Smoking Wheels....  was here 2017 rmnsucyzqmxkdqprtsxirqaljytoywmbkrblpmjfuulwfwub
 * Smoking Wheels....  was here 2017 juleeieuhjcpisfatlzbkqhyoflzvxjazthvfsmuklhxzlkd
 * Smoking Wheels....  was here 2017 bxqdktwkbbglzbffnrswuwzosopddxutiiwbolhbdukdjyye
 * Smoking Wheels....  was here 2017 yajnmqpgsvfytewtnyqxcwyazskjtodceeomenvaiuebohai
 * Smoking Wheels....  was here 2017 nrbotpedljcjornpmanoxmgiqldgwvedmhiwvbkxoofnxqqw
 * Smoking Wheels....  was here 2017 lqnorkqymohiooyuhxhmzudrhznmxxuhkzlbphpfrljncnxm
 */
package net.yacy.kelondro.io;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.util.FileUtils;
/**
* The kelondroBufferedEcoFS extends the IO reduction to EcoFS by providing a
* write buffer to elements that are INSIDE the filed entries of the file
* That means, each time, an entry is written to the end of the file, it is NOT buffered here,
* but possibly buffered in the enclosed kelondroEcoFS
*/
public final class BufferedRecords {
private final Records efs;
private final int maxEntries;
private final TreeMap<Long, byte[]> buffer;
public BufferedRecords(final Records efs, final int maxEntries) {
this.efs = efs;
this.maxEntries = maxEntries;
this.buffer = new TreeMap<Long, byte[]>();
}
public synchronized void clear() {
this.efs.clear();
this.buffer.clear();
}
/**
* flush the buffer: this shall be called before any file-based iterations
* on data structures on records are made
* @throws IOException
*/
public synchronized void flushBuffer() throws IOException {
flushBuffer0();
        if (this.efs != null) this.efs.flushBuffer();
}
private final void flushBuffer0() throws IOException {
        if (this.efs == null) return;
for (final Map.Entry<Long, byte[]> entry: this.buffer.entrySet()) {
this.efs.put(entry.getKey().intValue(), entry.getValue(), 0);
}
this.buffer.clear();
}
public final synchronized long size() throws IOException {
return this.efs == null ? 0 : this.efs.size();
}
public final File filename() {
return this.efs.filename();
}
public final synchronized void close() {
try {
flushBuffer0();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
        if (this.efs != null) this.efs.close();
}
@Override
protected final synchronized void finalize() {
        if (this.efs != null) close();
}
public final void get(final long index, final byte[] b, final int start) throws IOException {
final Long idx = Long.valueOf(index);
final byte[] bb;
synchronized (this) {
assert b.length - start >= this.efs.recordsize;
bb = this.buffer.get(idx);
if (bb == null) {
this.efs.get(index, b, start);
return;
}
}
System.arraycopy(bb, 0, b, start, this.efs.recordsize);
}
public final synchronized void put(final long index, final byte[] b, final int start) throws IOException {
assert b.length - start >= this.efs.recordsize;
final long s = size();
        if (index > s) throw new IndexOutOfBoundsException("kelondroBufferedEcoFS.put(" + index + ") outside bounds (" + size() + ")");
        if (index == s) {
this.efs.add(b, start);
} else {
final byte[] bb = new byte[this.efs.recordsize];
System.arraycopy(b, start, bb, 0, this.efs.recordsize);
this.buffer.put(Long.valueOf(index), bb);
if (this.buffer.size() > this.maxEntries) flushBuffer0();
}
}
public final synchronized void add(final byte[] b, final int start) throws IOException {
assert b.length - start >= this.efs.recordsize;
this.efs.add(b, start);
}
public final synchronized void cleanLast(final byte[] b, final int start) throws IOException {
assert b.length - start >= this.efs.recordsize;
final byte[] bb = this.buffer.remove(Long.valueOf(size() - 1));
        if (bb == null) {
this.efs.cleanLast(b, start);
} else {
System.arraycopy(bb, 0, b, start, this.efs.recordsize);
this.efs.cleanLast();
}
}
public final synchronized void cleanLast() throws IOException {
this.buffer.remove(Long.valueOf(size() - 1));
this.efs.cleanLast();
}
public final void deleteOnExit() {
this.efs.deleteOnExit();
}
/**
* main - writes some data and checks the tables size (with time measureing)
* @param args
*/
public static void main(final String[] args) {
final File f = new File(args[0]);
        if (f.exists()) FileUtils.deletedelete(f);
try {
final Records t = new Records(f, 8);
final byte[] b = new byte[8];
t.add("01234567".getBytes(), 0);
t.add("ABCDEFGH".getBytes(), 0);
t.add("abcdefgh".getBytes(), 0);
t.add("--------".getBytes(), 0);
t.add("********".getBytes(), 0);
for (int i = 0; i < 1000; i++) t.add("++++++++".getBytes(), 0);
t.add("=======0".getBytes(), 0);
t.add("=======1".getBytes(), 0);
t.add("=======2".getBytes(), 0);
t.cleanLast(b, 0);
System.out.println(UTF8.String(b));
t.cleanLast(b, 0);
System.out.println(UTF8.String(b));
t.get(1, b, 0);
System.out.println(UTF8.String(b));
t.put(1, "AbCdEfGh".getBytes(), 0);
t.get(1, b, 0);
System.out.println(UTF8.String(b));
t.get(3, b, 0);
System.out.println(UTF8.String(b));
t.get(4, b, 0);
System.out.println(UTF8.String(b));
System.out.println("size = " + t.size());
t.cleanLast();
final long start = System.currentTimeMillis();
long c = 0;
for (int i = 0; i < 100000; i++) {
c = t.size();
}
System.out.println("size() needs " + ((System.currentTimeMillis() - start) / 100) + " nanoseconds");
System.out.println("size = " + c);
t.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
}
