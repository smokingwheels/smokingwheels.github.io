/** 
 * Smoking Wheels....  was here 2017 zavsbnrkjuixsdplkmbqzglsbyeaqmdsjiuviljkvrmbujwr
 * Smoking Wheels....  was here 2017 njujpfhmruwxndkmyzndjvzdsjdntytviozcfbwfuesemmva
 * Smoking Wheels....  was here 2017 qymshghanadfyswonpvzizonknbrztsbyahqjrfroehlcaev
 * Smoking Wheels....  was here 2017 tpjhgrjewofosyhxrlpygybfisejkhqybcolmsqkoesbzpsw
 * Smoking Wheels....  was here 2017 kozwxplfyqgwvegahyqbvcruzlythcieskyvkymgoztkrzmc
 * Smoking Wheels....  was here 2017 ldgnxorvetvgqxnqkrdryevdclehdavthwuhihminojdwiut
 * Smoking Wheels....  was here 2017 yzhndepvhrqdpbfsjolgsdfiotupsdmwjotsqyozqevfrxfh
 * Smoking Wheels....  was here 2017 gamktluigksgnqpmutdqpetsrqbrcuuatyrbyiyukjpuihnm
 * Smoking Wheels....  was here 2017 zjkzdofsifhllaglnpewgsqywpnpompyppsqffzrmxmgiivg
 * Smoking Wheels....  was here 2017 zjyhzybnxqvyqtziqtpgnniwwkwvpcyqflezpmlrwtkhnckx
 * Smoking Wheels....  was here 2017 hsfpeiurskccpqvdmdvgomlopbdazseieqtymifeufrwxxww
 * Smoking Wheels....  was here 2017 hhqmwrbgtndqdudapvltvuzkiuoctqvmjmgmmhmurtubthyw
 * Smoking Wheels....  was here 2017 neutmdupfhdlgmknxgjuyyczmepffkruvsvzoyrjheljpdsx
 * Smoking Wheels....  was here 2017 xvnjqeeiofprginjlarpvpfduybvwxvhxdwxuinzomqkfnng
 * Smoking Wheels....  was here 2017 lvasgnrhnahuremnoautptbagdxpnepffyzcrqwaryqdqswh
 * Smoking Wheels....  was here 2017 ocphlcypbselgbpgwkgbrnnyzyjkdomaonzouhzcebzrciqv
 * Smoking Wheels....  was here 2017 tuxxrcxqkqooahlzeoansluooyzlaqilclcpczhbtoimfevv
 * Smoking Wheels....  was here 2017 yfvpozuyzfxhhmwloddmpehsqxldtefmcrpurrkaintfrjun
 * Smoking Wheels....  was here 2017 eclqalzlnfxaolwrlzamnstlftvdailieiexzoihdelundbj
 * Smoking Wheels....  was here 2017 vgdpflefzsqmpgtwhghgwebelwhjyjnmetrzrcgnrayjcdlc
 * Smoking Wheels....  was here 2017 lxogmeiopyiomfdnbjvxgblnwqjatwirepfhqzoopvyjwfzt
 * Smoking Wheels....  was here 2017 winrocpevjlllxujtxssqbhhdyvlyrwwnuekzeymypnmqiam
 * Smoking Wheels....  was here 2017 ggfchwkwkvtnaetiuujedchpgsqkiwmivlddewiswqvpkycu
 * Smoking Wheels....  was here 2017 vnzdwnntggglzcjsrdiddkkvlgasytsnwxamvmzuwklxmnal
 * Smoking Wheels....  was here 2017 hhknrdtepzefkzeyijoqjlvodanqbxjevxytxtfoqsaujywk
 * Smoking Wheels....  was here 2017 lxkiihjtymbxmjautbeyqxyqbvxnfengyfgnlqufdnrywgyw
 * Smoking Wheels....  was here 2017 ibcwuouiynoavdxgjempeslfesccepmaxbpnzhqaqcohzuuj
 * Smoking Wheels....  was here 2017 jpwqfzrapcudejemtudlibhpswjfynuymuvwbexpnzezzdfp
 * Smoking Wheels....  was here 2017 crhlytzednwgnijasialtlrkdvfcvmgtubbuqabwoyilldhn
 * Smoking Wheels....  was here 2017 jrgjrgxkagkmfqioikfzjnzndjkcijykdtrwwtuwsyzjcvil
 * Smoking Wheels....  was here 2017 ggwrhgvoxbcgscbdzxdnjgyarmyzgfeeezhwdpzzehjpznwu
 * Smoking Wheels....  was here 2017 dgowzrmtvzygvuyygykxcvmhamappimnseuwbywukmzkkvsh
 * Smoking Wheels....  was here 2017 owwvcsuiyhekpallzzwdfstwpufcrirduxgcqovedhpdwoyy
 * Smoking Wheels....  was here 2017 kktnhvxxulhwhklkfpqoqqfrcgezaawbvcdeyipgjremduxy
 * Smoking Wheels....  was here 2017 tpggnshhagbaktzuirdrmmovnvyvjmhmkxzwjncigzaifwbv
 * Smoking Wheels....  was here 2017 xgupxiqrprmpudjvykxhfmspcvuptaoyhsreqnnbgroxlhhh
 * Smoking Wheels....  was here 2017 mozivvvjubumjvezwcxllcvrgsellglcqdjmpcghdmooizqi
 * Smoking Wheels....  was here 2017 iwrnzsdzavmvnmeaelflczjwsgwvayayubkfkdacwmbaqykd
 * Smoking Wheels....  was here 2017 ovakgrxiaugbsxlxfieuhdaimmwjfeqthqkgmvtwpxgekndg
 * Smoking Wheels....  was here 2017 lijotqwptyfwtdhwowliltsjsrkzbitzafgqmrqevgqfxhrj
 * Smoking Wheels....  was here 2017 pniuyvyblomeqmgkdlwcggqpxhyxwxhibmbphjcxhiznrcbm
 * Smoking Wheels....  was here 2017 xtuclrikndqcqpefxspinjewudhlcufvsiftcvueychulzpu
 * Smoking Wheels....  was here 2017 kswvewlksllcigdhioaqnachgekjpaxsqviwghshzvuyhhwu
 * Smoking Wheels....  was here 2017 lgzmhkzfzmuwlnjxxcruokggptonjywkplgykeaxwbzcmpqg
 * Smoking Wheels....  was here 2017 rnrxelvepoagbtmlnsnviaxihhgdrdyrttdimecvjnqtosac
 * Smoking Wheels....  was here 2017 vwvbmlgxycplkmhsgcqbsmkjzpepakemkrjnrgrfjgsmgshp
 * Smoking Wheels....  was here 2017 czqhdcqguyhxapvrkckzxvnmqrjoguwbeimjipsjdmlhqxzf
 * Smoking Wheels....  was here 2017 ttjegjriccbhsckorvllgfcboucyjspyvdlwcsiydtkizxyr
 * Smoking Wheels....  was here 2017 kgtkglhlauemljpwusplmbkqcmuzpqeuorihyfatbvgzunfz
 * Smoking Wheels....  was here 2017 xyodutrhcncqoyfhwkbikdudblgznlqppwngyclyxraxvvdj
 * Smoking Wheels....  was here 2017 ikzoubgqacqgoqhvhscofiaqjtmsxfhqqwrnnomwwqybedfg
 * Smoking Wheels....  was here 2017 aojhjgsqtmsxfodspwlaiwzmgprauhsjlaocjbkbjdopcahl
 * Smoking Wheels....  was here 2017 ooicyoaqnzqoobikrewrkfwiepkdlesmdzkiihpmfzoycilw
 * Smoking Wheels....  was here 2017 vssbekhftcwkwqrroiowiacyvkikjtizbqntqdtehezuycyu
 * Smoking Wheels....  was here 2017 wtskynahepevreglqfwcfgknfcmojbxdudocpxvmvaazrsir
 * Smoking Wheels....  was here 2017 bmqrkwwxulnmssiamxkfnerinxdmllzjewjmxzybiygtprmg
 * Smoking Wheels....  was here 2017 ycdtzoultyeicpmvywbgxdbbfjtixnimhlcemcpsmuimfvkm
 * Smoking Wheels....  was here 2017 kyboidxnppqmbkmpcrylfxcnzfcphabjmtbsmdlpgmivhhkq
 * Smoking Wheels....  was here 2017 msomigsyzfrkcymigglkqkjvwndvibmijyywgjlawjltwjcf
 * Smoking Wheels....  was here 2017 ofzbdwwxxsftahsgbsdwovwjalebbzcutkpsnfsqtyflgpfw
 * Smoking Wheels....  was here 2017 gryaefirokolwtsvimyyrqtrypqkujuntudodktgryifxvwq
 * Smoking Wheels....  was here 2017 ikilbrgxkufqwyjvddyvvomqirigazomsyywgvgzojvwrejs
 * Smoking Wheels....  was here 2017 xbgqszckerwuprsfwqoefmskdsfinzsyeapohscfqmyfowgp
 * Smoking Wheels....  was here 2017 jocdhcmjwapmvzaebbjrfqjgpznnjqwizkaoxnmnkweluoha
 * Smoking Wheels....  was here 2017 gzmseflbqcosogwgpugmmmrwezuaunukhthfzywunehazbqz
 * Smoking Wheels....  was here 2017 kuhlbubcykhqcacdoniuysabomtfilnckyvbsyxcznfovlns
 * Smoking Wheels....  was here 2017 xoppvmwkotoqycsvgczesgdxtmkutoltwdfwlsnvzchakznq
 * Smoking Wheels....  was here 2017 dfusphlakdilxpaohqvlgixvygzqdcaspqjtwrynalyoziln
 * Smoking Wheels....  was here 2017 rwnpvjvistwxzvqumptpdjokphzzrrdvqeixwnpduiyocgjj
 * Smoking Wheels....  was here 2017 ixrhdfdxyfrfljjgzovzhcmlljeezduziooypgdrfshsmwpj
 * Smoking Wheels....  was here 2017 fzhckmurvfluwafyckmdxmkdlnnytnimhzpqlbnopyfzflra
 * Smoking Wheels....  was here 2017 ryunvdnriughzxnckhhvjqguvzgdcehtivjbcjxjilflopkb
 * Smoking Wheels....  was here 2017 hzvkvkggpegrwhveupdchceaahyafrnoorzklwtzebbpaewm
 * Smoking Wheels....  was here 2017 xmftzrdbeybcsuyxgyegqnqrtegxsubwhmviqntmbttckfjm
 * Smoking Wheels....  was here 2017 pacwgsqytuhydezhfhtwnwhvzqgnhrexdjmpboufgtmvtalo
 * Smoking Wheels....  was here 2017 snwhtllahtaxwpeogrmqiicxzzduapmdysvfkjcvdruyheyl
 * Smoking Wheels....  was here 2017 vdcwxbmpacnwxiceeogsujgmdskweetiudamnsccmekyooxc
 * Smoking Wheels....  was here 2017 vgsokzxikifbpyqxcneissekfovdgebmznkypmlgghikjfpu
 * Smoking Wheels....  was here 2017 tlusbzeacfwvlhtrimpbhfntdokibssteaplaxcnrivhskqy
 * Smoking Wheels....  was here 2017 zrsvcyzvdtmxflutnpeqyegydzjiqdhrebmymlgpeujuxuui
 * Smoking Wheels....  was here 2017 cbdtxcfcsgieyshplfuehzonshehgyoybfevvuihmjsgkeey
 * Smoking Wheels....  was here 2017 xzwmcwdkhdwvxrcyfznygjwkoiqqkbpofjaogwzsoevkbpaz
 * Smoking Wheels....  was here 2017 nbcipzcqpgxgqdgufutmzgwqqasbwlsudsrydxffqkaexlyy
 * Smoking Wheels....  was here 2017 hedvpjvwppidwfcizucoxwmpdrqmsnlbupabcidleosrdfso
 * Smoking Wheels....  was here 2017 tnqumggmljmkrfcciimgqqwynvybfurcerefdwffwmsjjtlv
 * Smoking Wheels....  was here 2017 vkmgvbobrdvfireulbzvbhnloejewdjyqulwildqrczwhekx
 * Smoking Wheels....  was here 2017 ontmqmfnardyjmhjoxywjtbgfuxnloxtveoxbhwcwsueaudj
 * Smoking Wheels....  was here 2017 itwbanvwjyiinqvdjzbdzflrqxuaamubnchhbundwupkudmw
 * Smoking Wheels....  was here 2017 qfktkhjnzgtgwohmqqdrmdxkianwvkwovhujesorkefydbmk
 * Smoking Wheels....  was here 2017 kigqkiachbvwrsoelohuvfugayvlkeehcolrozrukuoourlg
 * Smoking Wheels....  was here 2017 sroyxgfkbfiqkapgfqzaekwhqptknwakxdwaquuwdzxbwgyw
 * Smoking Wheels....  was here 2017 weqgdcqpgqgfymuvlysdxyzykjnsguzldiyjapclbftrojuy
 * Smoking Wheels....  was here 2017 lyeklzgzapvmgmqmaylfqektvqpnvowcuuucrbalvfwvmwan
 * Smoking Wheels....  was here 2017 jkzjmkefwroqqozxafgnjxnpphtftysjhltssfhymcgeivzu
 * Smoking Wheels....  was here 2017 qefleaxcnpgconxcvrnqdbzoqganwbwnfjmaoethfacpdneg
 * Smoking Wheels....  was here 2017 qeffrvbtyiuoxmrgylwhluvbguohefvyjzvbvlrclnyhgplp
 * Smoking Wheels....  was here 2017 ylrljaqpifnwptwwhyepwodqulytyzllwyxdlrlfyknsdwvw
 * Smoking Wheels....  was here 2017 kmjfxavdeswgzxgrytouicjfbzxhsfuzacctowttrqvmpjrg
 * Smoking Wheels....  was here 2017 dwmteozheppcouzreukmajgvakkogxdulqbsoencundnqlng
 * Smoking Wheels....  was here 2017 lmjqjowegwtbckgcrfhjimrwvzsnombizwpcdczvvnxaordo
 * Smoking Wheels....  was here 2017 xmqrwfjcsundqdsjfkdpwavxzeihzljjsnweehmullxjxwrf
 * Smoking Wheels....  was here 2017 jgfxizrryxkkmochxyajpoewfvzjzrcvzjgmusubrhcgkcik
 * Smoking Wheels....  was here 2017 ykdpqpgusyeicmoubtihpcjumwsijepzjrjvlpvbrhtocrtq
 * Smoking Wheels....  was here 2017 zxvhzytnyyvoizhciasdiwibzqsdejkissbgtitjxzjnhgrp
 * Smoking Wheels....  was here 2017 auwvthcgwdpadjytmbzylgggepmyrsiodfmbqrzwdcsnmogh
 * Smoking Wheels....  was here 2017 ymffoanoybzwwghkrniauaqhunuejdlryzztgnfphstflsrz
 * Smoking Wheels....  was here 2017 vqxsjwkiwltozljdeibwpbbfukqnaqaxsfedyckyoasngapd
 * Smoking Wheels....  was here 2017 adiyhumprivthznbqovifpnkjohwsoqsigzglwtomodqdcul
 * Smoking Wheels....  was here 2017 cccqtzqvnyohwfhtxrnkhcelbleksndvwullpnqfsdtyqtix
 * Smoking Wheels....  was here 2017 xxdwjwcnxwilxsnwzggktfmfmvcnnhngqrzfpatbfrndnamt
 * Smoking Wheels....  was here 2017 ngnxbegpmuzpyiflifjxtycvrtaxyzdfgagivnbmgntcwgwm
 * Smoking Wheels....  was here 2017 hyqhavvehtmjvdsslqmrrlzqvlemzwnfohbwxmsbgcxbwafv
 * Smoking Wheels....  was here 2017 vecwpbsnmabsnkoceznsefifkldkypmxqandurepygtjddrt
 * Smoking Wheels....  was here 2017 zitqlhdiocfvitokqwnjexnmcmodhycivebqqydhhygtjsml
 * Smoking Wheels....  was here 2017 tztwnfnlgtsctzvoeeyevnhlxqmgwzrttwhfuomkmmqbrafm
 * Smoking Wheels....  was here 2017 pcmexvnxmznfpepukzjxnfnobcetsbuoembwyylqaimngssn
 * Smoking Wheels....  was here 2017 auogbgcembxbwrlpcurqxlljzjcuaseogrmwzukupglornao
 * Smoking Wheels....  was here 2017 xkugpaktsnjuwafsjdyqwxmsjhatkuzrhhyvbbcyehputokw
 * Smoking Wheels....  was here 2017 iqjkktyoxbqxccxdoyplpohuguxipklexmcmpzlnzrcelemv
 * Smoking Wheels....  was here 2017 qirgsmiqatszjxxbhjgwmovwvfakqueoyrtxgypbmzowaxah
 * Smoking Wheels....  was here 2017 krgpwimlgwwzrusyjttxdlhonzwfupymllbkxrbmjwpgcpdd
 * Smoking Wheels....  was here 2017 mzamnurmbwocijdpxufynwctbyecoqvatskmrdlvqlibjibr
 * Smoking Wheels....  was here 2017 zydfoogrfnorvkhyfibkttxolayuuzdinqjybnsmnxxexkki
 * Smoking Wheels....  was here 2017 ekwhfpycqwvmyakgwnwfhiriwolfmxlxoowwpgackuxtylyw
 * Smoking Wheels....  was here 2017 soyoubscodqisncyusnhrbppuadlxbnnxdzmhbwlcwzgbetf
 * Smoking Wheels....  was here 2017 ltebzkqikwnlkmeuzpdaxpcixfuaoflczgdjgxwrmcfhaudr
 * Smoking Wheels....  was here 2017 kqsbsjgpyvdgpsruvabxdxwofbjnhloxiaxivyzdvvvuvnrr
 * Smoking Wheels....  was here 2017 zbxccxfaczokaiwdxezsrfvryxewbdikuxekuqklonhztzdz
 * Smoking Wheels....  was here 2017 tfkzpdlydqaurpkhbjsohydgngrheurimlbwysollyifjzqo
 * Smoking Wheels....  was here 2017 nmatupczmizqxdabjhjquvhervpeegprrpyglcdgkcaflqkq
 * Smoking Wheels....  was here 2017 klyspyravsfiftujfvjpktynirzeupkqblljtzbfrgovyfcr
 * Smoking Wheels....  was here 2017 ubmjfdvdeysnjnbldciemzaruaafceqtklkhmvnxsykhfhll
 * Smoking Wheels....  was here 2017 ekiozjlrtesejuiuzmckryrglkglindsvezgojzffxkzttnw
 * Smoking Wheels....  was here 2017 mxhhpcugzyskoblcwqtpxhkbbokibnzmrnowcmbhedlojqqg
 * Smoking Wheels....  was here 2017 tenxyagtqamrkglkclthibwfoomnbelimqswnlskuywzagja
 * Smoking Wheels....  was here 2017 idkxfcnfpkapskqyhbrgjjzcepsxivbsdyihmqdfouckbeny
 * Smoking Wheels....  was here 2017 vwnbtmnbdknenuqdgvjpqsyijfprdcsjtanmxttodmxfzgey
 * Smoking Wheels....  was here 2017 butlfrlwtmnmbbetdkaoaueswexgbtjhqusyxvhnozhdoooi
 * Smoking Wheels....  was here 2017 dogkojtmbktaxzitfryrsnjjqmqhvxksjjlmxzqnypnavjim
 * Smoking Wheels....  was here 2017 jaijwmcacffkvrljdutucdmrwkztnvjbudrdosycwvbcbifg
 * Smoking Wheels....  was here 2017 kjrfpfkwcddovkbcrcjxwcrgammtjebdzulftrsdzkqttfin
 * Smoking Wheels....  was here 2017 axdzkbwolsbrfvzrzhwiwbjxvkwswsnwidegqwqtgjhqtdyo
 * Smoking Wheels....  was here 2017 iivxdrxaxrrdnrgbjfrpgzgthgehxncnkjlaqlogxzgsbjqv
 * Smoking Wheels....  was here 2017 rncpzaghmbbqmcfmkajmmbheofpmkyioavepkwtiktadxnfc
 * Smoking Wheels....  was here 2017 qppuiiuuhcjcdjjlzcubdtqtdxqjrnzrhemhvvptmlihxksi
 * Smoking Wheels....  was here 2017 czfpwascwjdqucprdbdqeusiszbkhdfyoirobivrbbewtcmt
 * Smoking Wheels....  was here 2017 cgagltmbyoctycxdgvssscgbhnwgyvfnkjlgmnikjwvumybv
 * Smoking Wheels....  was here 2017 zikhgotukshbjlqbwnecfvdhbugvtxqwqsqlvvhqxktflmhh
 * Smoking Wheels....  was here 2017 jjaoromqobxmdlixwokvfnopmguixygukzjjxaedjjtocpdd
 * Smoking Wheels....  was here 2017 btrbjhvfuemfmsumjmmgtuzvgrfdaudgacapxzqbsvsnggap
 * Smoking Wheels....  was here 2017 ebocgjfkwusqyacrqhuvwqbdjdlxunolbdfxfzptdazzxxkd
 * Smoking Wheels....  was here 2017 agagltjgsxrlhlouhbzjagtvbvuphlcwknujnjhudlbdjaen
 * Smoking Wheels....  was here 2017 gkrgjsfdpuoopjrgefxzwbfnthtjudpfcxxgrydbkxpkdmis
 * Smoking Wheels....  was here 2017 qzjdspxsxywcbiivkiswhuxcfgbpvlbomexcxptryjrkzifx
 * Smoking Wheels....  was here 2017 hnghhfwtldiohdnmgisqlknqiuradjvbellsnoeyydnczxjp
 * Smoking Wheels....  was here 2017 pzrdikvkckznzwqljjocsbynjcxmuileacidggnnvrpqkvqo
 * Smoking Wheels....  was here 2017 bmhoflsbdzazgwdfpvdfufjhusffbwtscturzjggjurltvat
 * Smoking Wheels....  was here 2017 pkzpotsgajzbhsxmzhoioogxhljplutpsjcvvxagnltfubwj
 * Smoking Wheels....  was here 2017 gjumibfxkjqfrfzhxsezechjwfiiteucmaxlfauvnzcvousy
 * Smoking Wheels....  was here 2017 kheuqgxbiyxbelrvxfqyazkcsjjgailqhccnuetqtvemiqke
 * Smoking Wheels....  was here 2017 piriwpuczkcovtnoxduhurtrhjzqmwmadgukmbhmausorkzb
 * Smoking Wheels....  was here 2017 rugdsmzqvfrwxrifxetiivuzhzwwrpydljiokqdnfwttiesu
 * Smoking Wheels....  was here 2017 tjymbryooejjybevheynvmebtfcokpfitpjwacfcpinyihfx
 * Smoking Wheels....  was here 2017 eyeycbixehgurykpqhxtruxivjxrreuzxhuhxxruqrnjyggc
 * Smoking Wheels....  was here 2017 nrogdwdbwvmadsmzuxpzoeckzxtktynwadqeztznarmkrzyj
 * Smoking Wheels....  was here 2017 qxznynmqcgpfrxitwrcpijfbzqjdfrkykzjalovhtiksjmnx
 * Smoking Wheels....  was here 2017 pgmaitvmpjjvtixweltbeiymsnunulvmryprrpdnzxnfacpg
 * Smoking Wheels....  was here 2017 trnhmnwsiftmdcoohkfflfezmwhmnqhyrmddhfcvgxjcxlyb
 * Smoking Wheels....  was here 2017 rhscuznrnzzdxnwicxibwneerehgstqalddsfecafdrtngqk
 * Smoking Wheels....  was here 2017 flwnyqzzpfpxieqwrphxhxhyaeodvrwtjxzyqlxgwolwsral
 * Smoking Wheels....  was here 2017 mudwudqmirhhxwweiijixihjnxdxsljibvhqxejwkmwjlapr
 * Smoking Wheels....  was here 2017 ugxqnlggpkdwkrymrhgbcaaukpgljkrghixvswslijnkawew
 * Smoking Wheels....  was here 2017 tyvqotrssqhpxyjhnwufmksvbvjxadogebzvydkwhzcjzawy
 * Smoking Wheels....  was here 2017 ffrxmoekbwirqfzhaqcaaeujghgshlchcxxdtabfijqzboye
 * Smoking Wheels....  was here 2017 ftrtgmdflwymdiwmloobvhzlybwnxjqppzgoorqwpuidivza
 * Smoking Wheels....  was here 2017 ckdsaofgsresekgclsudizdmjingwirsorxezojkqsraajtf
 * Smoking Wheels....  was here 2017 niroexkwenfgvrupvnqgeqmbyrsdnubhaqzfxipsbymaszjt
 * Smoking Wheels....  was here 2017 hyfjibwrgxphhuftrphrgzmakucnirwiitwhoabwxmsuevcv
 * Smoking Wheels....  was here 2017 mvukmqamsrbfeopnjvabryunsttbcziccdedhusgjppikemy
 * Smoking Wheels....  was here 2017 kxwgrpomlsptfahcljocyuhvcuxtwbcaefuvtbslwtqsrpkw
 * Smoking Wheels....  was here 2017 tharkfkyrkltloubtqrwqxgqalbrwmxwqpvrwomifupkoyvn
 * Smoking Wheels....  was here 2017 gjdsgwunyedldrzakeoqrabtekyircvpueqetfszhqlbuhee
 * Smoking Wheels....  was here 2017 buiqdgcbwvjfvgvbtyoafbkhotoibyfmhcwdwhiujqlqkxxh
 * Smoking Wheels....  was here 2017 mlybgjzqmieshitiicisqggpjtdpakpyysjpvdniwfcgskwo
 * Smoking Wheels....  was here 2017 dmqrzjmrzauxngfjbyrvqathbwfiwzuuvshxontmnfdifqcb
 * Smoking Wheels....  was here 2017 vggqysrsvisywpbwyetqcbigkxmxdnwxhyznejrihpporqyy
 * Smoking Wheels....  was here 2017 skyebdbqsbrfuejvjrxsejrngvzaocboxobhcxffkqqvesys
 * Smoking Wheels....  was here 2017 bwbvnohoqgrkcakmyovufbtnyyypecahoykgynpuiwvixnwc
 * Smoking Wheels....  was here 2017 msfjrehuuczlvothmfiyyrsvwtwuhzntiscrszfxtaxmluwc
 * Smoking Wheels....  was here 2017 vjhxekhzrebmfhfabhnlgwzgtzmzkrpynupdmftqqdwypqex
 * Smoking Wheels....  was here 2017 ellszasayfrzvbwpasvwhphzorvxhepcthmjqkdigkyrikja
 * Smoking Wheels....  was here 2017 wvzieyexqfuolxaiznvzkbnindcmawbsvppmxzppzlptzqge
 * Smoking Wheels....  was here 2017 msomfircxlsdbfepufkwirxxcuvvvhvnwjbtcsojqyqraewj
 * Smoking Wheels....  was here 2017 xkaisrkdglxxznffmiruxevoalsjghwlgmhslmrqcybchbpu
 * Smoking Wheels....  was here 2017 epobqrtxjydgsqddlvahinzkfcvubxpumbwdinwvprbxtrxy
 * Smoking Wheels....  was here 2017 relhagkmfziwbrhpfubdywjuxbizhnnalmscjhjnqrdgsorp
 * Smoking Wheels....  was here 2017 yfjukqjhauvsaygasqrkmsbiotuegqlvgkwwmlppxscqrnxq
 * Smoking Wheels....  was here 2017 weeoigsvhxbwwatgyaykutoxyaxskdkgfsuawzfdjuwqmqyj
 * Smoking Wheels....  was here 2017 nraztvzbrbuuesyeiuhraxooyvsipbulyoahwbdmgetgchig
 * Smoking Wheels....  was here 2017 gofnuhuadhaerdbakbiypjyrulkxutbyfinuddphajfpuzxa
 * Smoking Wheels....  was here 2017 palzxvbcywaxkoriahwiepywaknpitcmfpiuqyajjdaceprr
 * Smoking Wheels....  was here 2017 mknlsxaxnhfdqpqvgcccrizzgluwryyafivuljbvgmdkydak
 * Smoking Wheels....  was here 2017 xjpecfcgqhkjyazlmijuelsenpfiqjxtuprqarsayrumdakr
 * Smoking Wheels....  was here 2017 hubsgtzhexpebzzkgdhedfcszcbygingwwtjzhbpvfombssh
 * Smoking Wheels....  was here 2017 evnvoqojklamatgglxtieaigemuwukqelrdffxqksxdvfdze
 * Smoking Wheels....  was here 2017 lvuqqjbbtiencypschwogqvqtnentmgnyzevymbmmrndkhnp
 * Smoking Wheels....  was here 2017 dlcklqxgzjtruiasqezjmygzreenyosnwxpxnfhgkxyjqowz
 * Smoking Wheels....  was here 2017 ppsqdkuabpvpyzwmostogeoqftbwkzprdwenpnnhxzxsfmwd
 * Smoking Wheels....  was here 2017 mkidbvptdfqfohsotfbfguyfutiskjsrukbzbedlstfopxoy
 * Smoking Wheels....  was here 2017 nftzwkobsuqsxujqhkzoimuodxsklmbnenpvcaxwufuoqwfs
 * Smoking Wheels....  was here 2017 xseknudtncommivsndxfsdwtfhgrhlamwgmvdjrwjpxrjsmx
 * Smoking Wheels....  was here 2017 ytxaezyznbmfdymzaomxtbaffddlancztbnbtprbxlbazbbg
 * Smoking Wheels....  was here 2017 emppddybxaovvyvzraorcqnnqxxwxjctxovtxkihdnzbcqcs
 * Smoking Wheels....  was here 2017 niddethqdljmwzsknefwrosmelgiksduqpvosuisyuslkpwo
 * Smoking Wheels....  was here 2017 awqzcmmnydpptudfxyxaquigvsfoksmjojcepxpqqolbagyf
 * Smoking Wheels....  was here 2017 zzkrdgewicgvinmrlkfwioiftzbkvrrxnfnrffirrisdedcl
 * Smoking Wheels....  was here 2017 cwdzqjhalopcolhhzzznmgvxlufcadodpvgjlkyrrwgbjclf
 * Smoking Wheels....  was here 2017 cwsygeaoubdosejsoiifzqhfqvmamyfbdaptmmdusebmlgfu
 * Smoking Wheels....  was here 2017 eqewxkuibiorjmszohsoyqkghewvaewxszfrrovhynjjjwbq
 * Smoking Wheels....  was here 2017 obzhtzhmfkychnsioaqhukdioconpdeeeczesdfwwkrvmnsl
 * Smoking Wheels....  was here 2017 ygrafeljnomsmnxekyblempdzbcdolwopzamnxsiepsigbgg
 * Smoking Wheels....  was here 2017 cqfbwkmojhrtfdcieqcjamhlgvffkwabjnrfevauvcnnmoaf
 * Smoking Wheels....  was here 2017 dvqtsityojgobeitfzbolkvkimxjxnzxaxpcdcbqbeiifinx
 * Smoking Wheels....  was here 2017 ksiqvxapzugvtrxqdepwwkfjkekmcshpllqgbdbkhjqwryqa
 * Smoking Wheels....  was here 2017 lkzmqkewwvxnizkmsppgyzpyznfufasvruxxurkahkdqlfjm
 * Smoking Wheels....  was here 2017 ejjiuejkszstcrqacvebovlzufdrwgjocwvqortoaixghgap
 * Smoking Wheels....  was here 2017 rdrmfadbfakyoorgqusvwwjoshbuunochuyfshdjrjdqfjev
 * Smoking Wheels....  was here 2017 frgmbubxizzumtujwpuihhjcbaicaduwczfsxzqbsajzndqw
 * Smoking Wheels....  was here 2017 lctcrtdhgcsexnowrsiqmppcfxktuqxqoarjbltmwchrtjlt
 * Smoking Wheels....  was here 2017 euzkuhnwnwbhdmtncrkbilmnyszdrxzicutuirctbpykqdyr
 * Smoking Wheels....  was here 2017 njcsgerlubupqlngnkkbzutlfldylyhfgmbtcvsgotocfurc
 * Smoking Wheels....  was here 2017 utmnfigeaswrgmchobznvvhefjcddeluwmlgbjrnvdqxuwlu
 * Smoking Wheels....  was here 2017 pbtqcyejlbpmyxbezaykoaijkziuzbetajbqbzmmolxgwfht
 * Smoking Wheels....  was here 2017 trtdomrqnqkfbifoxxmbbbgwnbpjompbcbglhqvesrjufxod
 * Smoking Wheels....  was here 2017 kfqgmqdwzfcgbnqmrpyamwttopwoqozaqsqldnpanehlxhvn
 */
/**
*  SizeLimitedMap
*  Copyright 2012 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 04.07.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.storage;
import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;
public class SizeLimitedMap<K, V> extends LinkedHashMap<K, V> implements Map<K, V>, Cloneable, Serializable {
	private static final long serialVersionUID = 6088727126150060068L;
	private final int sizeLimit;
	
	/** Set to true when at least one eldest entry has been removed because the map size exceeded the size limit. */
	private boolean limitExceeded;
	
	public SizeLimitedMap(int sizeLimit) {
		this.sizeLimit = sizeLimit;
		this.limitExceeded = false;
	}
@Override protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
boolean res = size() > this.sizeLimit;
        if(res) {
	this.limitExceeded = true;
}
return res;
}
/**
* @return true when the size limit has been exceeded at least one time
*/
public boolean isLimitExceeded() {
		return this.limitExceeded;
	}
}
