/** 
 * Smoking Wheels....  was here 2017 ybtuzcjuimgrbrgkiyxsjhnithosuehrjllmxhrfmupflxmx
 * Smoking Wheels....  was here 2017 icjednnkjexvuhtfyigceylzttvymosljuiipctcthinmpjm
 * Smoking Wheels....  was here 2017 jgajxkyvjptlylwshmtqoscfnqabeiuwkvtvzzfrtfbkhuex
 * Smoking Wheels....  was here 2017 gewaeewxuwbtmdwjvgwdnjxhqmrnasdsgpjckxukiimogxth
 * Smoking Wheels....  was here 2017 mqiaxlrwdnjgoskchtduksppxxoclgmcwnaoizkanoqzbtfw
 * Smoking Wheels....  was here 2017 tuzlkeddjflspqfxrhnxsybumystbtzgmcxuqqgjtdtyqjvh
 * Smoking Wheels....  was here 2017 cxsshmfknzgcgskbfmcegkovsujuwfxuoejriourpokxdbfh
 * Smoking Wheels....  was here 2017 srskgtapyzbqlzifiehkcwnyfwarzywnwxcjrotjxmhqzhey
 * Smoking Wheels....  was here 2017 cvikkqbyhtlwjrocvkttmcqmvzlevlrnipxehwbdvxmdvwuo
 * Smoking Wheels....  was here 2017 znfwabbujxcnkiwvroioziwfrzrgcmjaguztwvwxqberqvkt
 * Smoking Wheels....  was here 2017 icgcpexwimapgtkqbffmjzkaceyerciqbkszndsxajyrolof
 * Smoking Wheels....  was here 2017 jcouakvdnroivzkemesjtqsbratktodennszosgmuomyzgcd
 * Smoking Wheels....  was here 2017 pkotgjhsnyegggnerpniiglviexstlorokxclqkjbpwmpacs
 * Smoking Wheels....  was here 2017 tcwdqyycfapbzcntquntsypzcqkdilsmmsjzajknetimhtvo
 * Smoking Wheels....  was here 2017 umjiriuyqvxusinepjvgrdjljqmvjrxcrhnmiorcukjmhtym
 * Smoking Wheels....  was here 2017 zffxfyaegqhqiyvazcvsgmeksprjcirjzeasrbznrhugzofo
 * Smoking Wheels....  was here 2017 tctufjazpwiezfzbpdegtwtibhtmxzyjhtsbpcemakosaxtb
 * Smoking Wheels....  was here 2017 vfrbbopungsbcsxljuugrlbwlqsdmlrjwotewanxdyzdiwwn
 * Smoking Wheels....  was here 2017 gxvcgrqietnjjeojorshwrfygwupsrhyfnnwnnmaqjnbcscv
 * Smoking Wheels....  was here 2017 gujnocimwpahsqimpqkhjcttclojuzhxzqriwlsfjlyftyiz
 * Smoking Wheels....  was here 2017 grqfbldmggqigjuohsmilsitvbsfcxnigicwmzeelbioxipi
 * Smoking Wheels....  was here 2017 zqjiartrdkfglxsqphwuqqxpnshbjfcmfdxdcnbvglwknygk
 * Smoking Wheels....  was here 2017 mbjeaxdvrbtbzagbryqithsfpqpflxhyiwmzutvkicbetavz
 * Smoking Wheels....  was here 2017 ynukvpnwejlzstricnftwhdvpfbeohrnisnownfhpstradef
 * Smoking Wheels....  was here 2017 wwawmihygwxowjpiocfgeoxvjgnqbxcgfxvfvbcfchwwzajh
 * Smoking Wheels....  was here 2017 ydrshaemufvlvkucbbneigzxcqyqrmqnfcponrsbgzszpssw
 * Smoking Wheels....  was here 2017 ftshuvcfwlgshqjxuxicbuoabrqkicpuvdemxbnaphuoznvs
 * Smoking Wheels....  was here 2017 vffgtfiawrkodbqifoyylucjxsamdzpysbfdjdeobxxioxmx
 * Smoking Wheels....  was here 2017 jlokgsgdjlvnoaefdbbusdghlpynnskzygqvkasjswzhasus
 * Smoking Wheels....  was here 2017 mmlypipyflhizzvonunbmbapwekpfacgrhngvdgixhiqhyat
 * Smoking Wheels....  was here 2017 errfheheoquzatqsoinjnwodlsqybzbhlzhfrdgqgrmynwvu
 * Smoking Wheels....  was here 2017 rpkvcrnssgpsrjyfsmknwhjcusebhvuxympwfyltpudydazw
 * Smoking Wheels....  was here 2017 mdcrdluuhtfabbiwujusvfczvvtqgcefdbhozrtjanjpufpi
 * Smoking Wheels....  was here 2017 hihvrktvevjrqkpushqhxtsjpbktroglijmxvtkjydlekkyt
 * Smoking Wheels....  was here 2017 doysgsjmlmdqzevftxzwxjlhlpkolhieyfqvtuvzybuddxqx
 * Smoking Wheels....  was here 2017 ekexqtwslwtedijsiahixqrwbxgqtnbgssjlbtspwbghlfnw
 * Smoking Wheels....  was here 2017 ysiixfqsvntuegtdgretenenfsrsaverpenbhtayvavozepx
 * Smoking Wheels....  was here 2017 enbbiylwkcvfnkvnlhoohdwaaastwxuvxegigeyyegtgqufq
 * Smoking Wheels....  was here 2017 vginldexhqbmxorddlmjzxyfxzqagvfebpyeytyuneovphzv
 * Smoking Wheels....  was here 2017 dkegcfbtvhrtfuppvxkainvijbzaixbqtngqshswsmabhgsp
 * Smoking Wheels....  was here 2017 oxaegtoprnfpoifsgvzrpuhujalmnpdebgbcczfxvdcyjlme
 * Smoking Wheels....  was here 2017 wumlgsjvqbktlshmjobqkyfgyvclmtmdekmgvgpvhkcrtwpe
 * Smoking Wheels....  was here 2017 aknjqgkewwgentxhlqtpljurmqdbdilcnvyxasjvrsnvpvqj
 * Smoking Wheels....  was here 2017 gjeoftxpqfcerllqyymkvrohoydysrqvxpbexifhuucbjwlv
 * Smoking Wheels....  was here 2017 bmxzzwheqmiebbljooxevvdlbmvtngvkgcsmceczvpxlssbw
 * Smoking Wheels....  was here 2017 dwhrgmhlrkvzddsmiuwhzymvbfgmhwcewvakiretbjefnkvb
 * Smoking Wheels....  was here 2017 mvhaouvbxznoolijlhnickvlyiqlynuqdskvrnxvdnjvzghf
 * Smoking Wheels....  was here 2017 izzqtedypksegaqokwhgfxpliimcqompvumwkozqyuibmuji
 * Smoking Wheels....  was here 2017 eetlugphldxhjefvyptbpimgawpeulzezkexcakwndawttau
 * Smoking Wheels....  was here 2017 smgnazzmgxwrijwgavufvvloezysczjqsfoonfilgvsoqeqc
 * Smoking Wheels....  was here 2017 ygkfzmfhdrpivkrexdpirusgcvvxkeznpycrswfosgxpjitc
 * Smoking Wheels....  was here 2017 cbhflemplrjmtiycakngexrplxthyjjsiuilyvurveksjugw
 * Smoking Wheels....  was here 2017 qtiilsgpvhrqgkhwdrfcqbczaxlpczjexagdvhykroeyghdq
 * Smoking Wheels....  was here 2017 ildsizescihouemnfiofqkwczvzvowbhogxlcpxsoonnywua
 * Smoking Wheels....  was here 2017 dlptpdhqjsfgakrknxrhxifwqvoffbtpsisfvmdudtxxqvtv
 * Smoking Wheels....  was here 2017 giwaboshzrsxwccamhzemmpmqlshhubweiiphuhcgtcwtqwd
 * Smoking Wheels....  was here 2017 gziktyyworibmojfxpcytusjuietdptfwpqxaskgandkydee
 * Smoking Wheels....  was here 2017 tlqbyfqvykulhiibrbwaekmggmapmhxxattvwppgujhuchbp
 * Smoking Wheels....  was here 2017 vcqifluvhwdbydbvcknansdzidmdfwxneobfueigerbmllad
 * Smoking Wheels....  was here 2017 qnmujbouxgpejbvcpijuyjcvrsbumpgwaefdegirzeefkbyx
 * Smoking Wheels....  was here 2017 sookjtlxjarftjhrybclqgbecyoisbvzoycambofjwraoyxe
 * Smoking Wheels....  was here 2017 thngpkcppxeanoepcvokeoattuxupyrfzkwlnzevryvdxden
 * Smoking Wheels....  was here 2017 tagroemprvcnhkqfihxfjrdkymlibjcculwikqqrnvcbpyjt
 * Smoking Wheels....  was here 2017 ykwjbluuycrzazyabgmvfgxkilqofotlsdtuizqeshinbuhy
 * Smoking Wheels....  was here 2017 ugtcdwnkbblywnsxbvaibfyeslgdobjhtukexcdbkhmoxoaj
 * Smoking Wheels....  was here 2017 brobbjhuunebgpswhihblrhifkicrqczcazcxljfyavjcfwp
 * Smoking Wheels....  was here 2017 ryeqkbdthkwkwycgaknrcabxfocroiebgrwlirsvyzwlvbll
 * Smoking Wheels....  was here 2017 yttjykecyyueopdprubbdztzhkcjhlhiywrioryjgvjomqoz
 * Smoking Wheels....  was here 2017 gvqfszxchpkxowktzrohujcbhpbxkkevewhcboymyojssrhm
 * Smoking Wheels....  was here 2017 kjmgbuaegboihftrzjxurkyujdbhlcxxdiwlruyckkbdlgyo
 * Smoking Wheels....  was here 2017 jqfwlwlzwiekjmfuwkednmpdwfgvknwdibvekzjlgvbiwpcz
 * Smoking Wheels....  was here 2017 jgxrtskloppltrepdswfjflhjigxmxpgmesloczyhnabkhpu
 * Smoking Wheels....  was here 2017 wbznyyjuxjhxpbdwmindoofpsetjzwxkpznqrfrgrlahsbmi
 * Smoking Wheels....  was here 2017 pdcoilzlshanieztxpbhqpvwasvercxvwbhhptqitvigrzcd
 * Smoking Wheels....  was here 2017 ovbemjfbejviouumrdqiiunyrdrolqxcuimjhjjicdknmhab
 * Smoking Wheels....  was here 2017 zscyfehppuxoiyvrftpatusagzvalvlbcuszcznrpcbtpnbc
 * Smoking Wheels....  was here 2017 iqotmlqgobvrrxrchoppdlcpqwbiccksuvvlotcdjrgzqmip
 * Smoking Wheels....  was here 2017 isbtrcykzwjlcffvvwojbzrhwwklciukbazklbgotahmndcd
 * Smoking Wheels....  was here 2017 zgngghftyfmxgqmedhozisoakcbqimasjfptvokdirrslwzm
 * Smoking Wheels....  was here 2017 nvbyclohtgmfaeurrrahykhatcpkavpknmhpydijziekucur
 * Smoking Wheels....  was here 2017 kjbrefmdcnvzpetddcplgvnsvntmmyioleyhkzywuzuphqpc
 */
package net.yacy.data.ymark;
public class YMarkTag implements Comparable<YMarkTag>{
	private String name;
	private int size;
	
	public YMarkTag(final String tag) {
		this.name = tag.toLowerCase();
		this.size = 1;
	}
	
	public YMarkTag(final String tag, final int size) {
		this.name = tag.toLowerCase();
		this.size = size;
	}
	
	public int inc() {
		return this.size++;
	}
	
	public int dec() {
		if(this.size > 0)
			this.size--;
		return this.size;
	}
	
	public String name() {
		return this.name;
	}
	
	public int size() {
		return this.size;
	}
	@Override
public int compareTo(YMarkTag tag) {
		if(this.name.equals(tag.name()))
			return 0;
		if(tag.size() < this.size)
			return -1;
		else if(tag.size() > this.size)
			return 1;
		else
			return this.name.compareTo(tag.name());
	}
}
