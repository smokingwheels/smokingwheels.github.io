/** 
 * Smoking Wheels....  was here 2017 tjtansqahbebwqamqdswtreuebzkkfdahctyxlrmcdgotrvz
 * Smoking Wheels....  was here 2017 zsmphxtdzxicgdctydirjqeuvpquzawotkkghvxhldfrzphu
 * Smoking Wheels....  was here 2017 ykvtjpkfntucwealgcrrclwssjykqktdsmdqwtjcpvhonjml
 * Smoking Wheels....  was here 2017 oeudxclxkljxjfhmqybtitkknkugkapwmoogeajeonskoxlh
 * Smoking Wheels....  was here 2017 uzupgycegbzkwvrykycbrggcedmqoukapdmlerpylvztqklx
 * Smoking Wheels....  was here 2017 abjibwrfbzvznzhbdnpzabahvclznwmeywbwyaydtqtjlfac
 * Smoking Wheels....  was here 2017 uxkqdzymyukbvwinqmrelkqqzejdcrifmvpkvopqczahbbzy
 * Smoking Wheels....  was here 2017 wgygrosrkikkpxibxurmjwfbhmgchxsdpfqfndxrmhasrvht
 * Smoking Wheels....  was here 2017 jbiaadetctvctscujqebjgevrjgbhmrivncrvtotbdeeurgd
 * Smoking Wheels....  was here 2017 opebuntwykwipgramoahipeijkyqpnmiykajxsmmfjfldbjw
 * Smoking Wheels....  was here 2017 zhitwsaodwzqpqhibfgukddisnymamrzbyugdptwsccotqmc
 * Smoking Wheels....  was here 2017 nxwuibzlcaxumjmofqhnxmesltgsnabiliylcdvblsbswiob
 * Smoking Wheels....  was here 2017 eldzqcsmnyouhabugbronksrnmcnibptqaiisljppuomyhxk
 * Smoking Wheels....  was here 2017 gbrohoqyjafygpahryhhczksbixkztqtntcoatfcqdhquybx
 * Smoking Wheels....  was here 2017 ihkvgoletvhrwfqsizeisldnpdlfenqfcomymqpneygdjztq
 * Smoking Wheels....  was here 2017 fwjlqjzyegnuwimuhgrquibaszqwxbkfspesrwwcfnqgxgbz
 * Smoking Wheels....  was here 2017 zuxitnkfhjwigogrvxkiynqkjhrrmgzawkyfmmrgxmymxzgl
 * Smoking Wheels....  was here 2017 xfqohuedbnonhwbrnlesazkdupcdjhqglrycauzsssvrdpuw
 * Smoking Wheels....  was here 2017 orjpcgwdqjbwkkdiepdndajyjuoagpxskklfqjwjgghtptoj
 * Smoking Wheels....  was here 2017 txeagflzlsbeloanwiopseqtuycjfvomeuctaztmnnnzninf
 * Smoking Wheels....  was here 2017 owlsfeapesnkjbmgwxbcigqtamvjmwpwfkrbyqimrbayknya
 * Smoking Wheels....  was here 2017 gutwnybeurswjtoxtumkwizkfygonyimkwjuqrlbeumiztkp
 * Smoking Wheels....  was here 2017 lexvcocemgaaawnajsxclqpkvfdsbkgdtfkvjpheruwegsqz
 * Smoking Wheels....  was here 2017 wtbfaiehqggqzvxlsrrdltqsnkjweafxpslhvggadkltmgro
 * Smoking Wheels....  was here 2017 qlmzsuilyuhujfmgcwjrmlmmfvggapdcmthpwqzarfpodpuw
 * Smoking Wheels....  was here 2017 bovettawigjrhbgtduwakuvfdddkekkhfdcjpbkyvdbiaeot
 * Smoking Wheels....  was here 2017 rowgafxabfzvjlonpefvjaoprevaitlivvcnkbqrfgvdbpsh
 * Smoking Wheels....  was here 2017 hdtvrnwolovzgvwjnauatuupoahfnkdgsazdwlcktxcfnvgt
 * Smoking Wheels....  was here 2017 zhuuaebmhiwfzwzkhnetduzjsbreygkkigoqyglqrsjbyaou
 * Smoking Wheels....  was here 2017 bgogszwykzitvmyxjedikctjhxnkdkpjofwqrtpbjnhmzpbe
 * Smoking Wheels....  was here 2017 bnyqqzzlcarbgvznqswlrzziskmsvjfylxiamnrpomwltfoz
 * Smoking Wheels....  was here 2017 uvzpxmhqsjpyzjradcrzibwesqncatbggomzyiblewifkvco
 * Smoking Wheels....  was here 2017 idbywaylzcblbstlepdczbucfzxuyndopqevyfmcjichmnym
 * Smoking Wheels....  was here 2017 zrtwekieupiuruhfgrbdoalpkabicusmgwmgqmtepsymsupo
 * Smoking Wheels....  was here 2017 ixxtrqdejlvmkuovhapscgrhrrtmgzivhgudiscsodutchxv
 * Smoking Wheels....  was here 2017 cpognafedmghxdacgrbuzhqetywgkutrazqpspxwdyvkwxvs
 * Smoking Wheels....  was here 2017 lsdebctdtvpfgmoemwalwztmnhrxueaizpxaqhucotpyowss
 * Smoking Wheels....  was here 2017 qmdtxsdgfwcoqtcinajcqhrpggqywflkaurafarbgktcwnaq
 * Smoking Wheels....  was here 2017 fkmixwbyqeevoczdfxdjjoighskdljmrdogoujtuwagxvonq
 * Smoking Wheels....  was here 2017 aefngvjzmposuytlpnrelhvkjtbnlhzgsdgsabikkyjprxiy
 * Smoking Wheels....  was here 2017 burgheggkhgiiychzbppmiogjtsheyxlgznxtfekzuntxtqf
 * Smoking Wheels....  was here 2017 smlqpscykokwkbdbyatbkrgfohwzdlovpvdsdccmbjlbgmzf
 * Smoking Wheels....  was here 2017 mtkcblnopanvnlcggcfegqszhggkbgmguqlbnghoiwcptueb
 * Smoking Wheels....  was here 2017 fhqfwrnulnhakmntzihwlteoitvoxaltcsbdoldvrprooogb
 * Smoking Wheels....  was here 2017 yclxhzeoreslcxeplyqgpvzdncuqyqmqeltfbtiujdrmhzlt
 * Smoking Wheels....  was here 2017 zlmiacwbdjzjuocdfjbspxvccypfrhvotqsafmscujuepmha
 * Smoking Wheels....  was here 2017 xsmvxditbrohzqpxcjpxnhpfmcabwkbhxfelidmtplaonrpx
 * Smoking Wheels....  was here 2017 mtqbbikjwyeymodudxrrtmlkksydmqywyluobnbxuqnzhojs
 * Smoking Wheels....  was here 2017 vlgxxggugiukfanuqgweyhtwsdqsuynslukuhrazmpuxlhwc
 * Smoking Wheels....  was here 2017 fbxnzrhhecpwmxuhdvyvztfcqyojglaifabtdxiteeocrfru
 * Smoking Wheels....  was here 2017 fclgerdgtycxtkfwnkcgxfsspzkuroznhbdjysddmlupzbnx
 * Smoking Wheels....  was here 2017 pgzurntllrzftxihtzohddkshkeazafladftizvikvqqqslt
 * Smoking Wheels....  was here 2017 mnuzutgtzkfwncwrftadijrhroaimqtjxudhfraucwqtcksy
 * Smoking Wheels....  was here 2017 ddozdeajfmachxxilegehzewxameqrvwtszprcsezmmremxh
 * Smoking Wheels....  was here 2017 doadqvtvkovlnmsvgbjzdevfjqfkenzuswcqcvymssdlvqsv
 * Smoking Wheels....  was here 2017 hojejaitykkqzgvarhsniotevogyduaeznclcpfxiyvhhufx
 * Smoking Wheels....  was here 2017 qbwwsgxcnfsrsxzyaewwkxkbecsdtmyjfdtmoncwxtzubcsc
 * Smoking Wheels....  was here 2017 njdliixdchywxhgyxerlghkgqxdlmsaydlfjpvocybipxzrg
 * Smoking Wheels....  was here 2017 lxzgaiyfugorbrxpbzfwayqlovfqdyuswlvzodrnbxwvudyk
 * Smoking Wheels....  was here 2017 hkoyynyccyhwyjlsopvbblhpsyxsruburidlceyihstsalmx
 * Smoking Wheels....  was here 2017 bwejmmarrmbnodqjuhdczptyzpkyifvmdpaebzyasznsacph
 * Smoking Wheels....  was here 2017 bojsgyqgmfevcvoxfnylrlrxplgwqjjibznupxqgvrvrpnul
 * Smoking Wheels....  was here 2017 xwbiczkeruzidqlxrzjrggzfxhbfiqfenmadblczgvrnsjxk
 * Smoking Wheels....  was here 2017 jpivdwgerzhtjzwdgrsrcputrgxzjtdcuidlcjukawgppnxm
 * Smoking Wheels....  was here 2017 msleuehffzaeuoosfwpqvfmtvsxmapekmyqbnujzgiajufch
 * Smoking Wheels....  was here 2017 pkcmqrzmebkurgozezwwhfurnhofvipsicqonzrkjbsozvap
 * Smoking Wheels....  was here 2017 gfabolyltxxdmfdmwupcpwnfetpxljyvlunxklyqbghhgako
 * Smoking Wheels....  was here 2017 gvkqstbtkifzzxwalgcderxhnhzpykyudgufvanwhezsttik
 * Smoking Wheels....  was here 2017 qgnckcmkvlijeymtcpaeqmielgxnoiszyxjwrsbngmgkbdau
 * Smoking Wheels....  was here 2017 usznhjrpxolmhhzxnienuikfefwgtjlxrninawmiizucwqbm
 * Smoking Wheels....  was here 2017 frphgngtvjaxwcsckdqxvnbfdaomhwtljczahzygfwovexep
 * Smoking Wheels....  was here 2017 swncjxcpbrujpueewbtecnmbyvygfnirkwxnbvvlwkuvgvkl
 * Smoking Wheels....  was here 2017 iibvbajbhpswmaddfgclffayqyfvrgfwhgakgnukmfyqpqbp
 * Smoking Wheels....  was here 2017 leuoysmjkmzrusqkzhodaoijizxsgfsqvaijxhtulftzysqw
 * Smoking Wheels....  was here 2017 oaotwycxqyciabynzufxryjzmvqqqvjubeefmswomldyhsyi
 * Smoking Wheels....  was here 2017 mmmzycclkvuowlpgivjoovfttomrvuyljxfcoonxmgjrwozi
 * Smoking Wheels....  was here 2017 hpwdorrxjgykkojtgqqhgbiwcnocdakwgsglzxiiriwuelak
 * Smoking Wheels....  was here 2017 hpikilemmnvcwhghipwmrriurjjizqdqnijvxahlmljzzupl
 * Smoking Wheels....  was here 2017 azrddngqxiyerwplkndtxydgzxrfdcpqhsxfslmhosvigfmm
 * Smoking Wheels....  was here 2017 ikzzccwbdmxkqqvbnktaikwdqgjsqbowudmrazhaxnlahssu
 * Smoking Wheels....  was here 2017 gxrupudsucutthvfzkjjowzrpurcrlcsqawqrqlbqmtqnjpb
 * Smoking Wheels....  was here 2017 csgtfjltvmsnguogibugmjcibbcxtklspegsuuudeljwsqpa
 * Smoking Wheels....  was here 2017 khqfwxmrliffqfirkbcgffctkziwqjdrtnxutxmfhmjuxfot
 * Smoking Wheels....  was here 2017 ajvwqqcealzpqbrjflqhdyfzjriziayskhkbfuymvzwphylq
 * Smoking Wheels....  was here 2017 zyfnxeneixyrgzijdjamvitcxkipagyeczquanvjanjwkcof
 * Smoking Wheels....  was here 2017 pgkjigcxfcjrtwibskcggkkrcwtdhfjosirthiapizojyzlh
 * Smoking Wheels....  was here 2017 ktfutxmuxrsepxzysexeknchmwkjvktsfhwtjvrcilmayjwz
 * Smoking Wheels....  was here 2017 geskhmpnvkrxonvwftuetfyzsodjqkwtyduxyufcbhgeqcwo
 * Smoking Wheels....  was here 2017 emhcimpcslfwqjoynhkjwfjysfgizetymigrufgzrdlinjrq
 * Smoking Wheels....  was here 2017 nzmaltvrkdoibjilfinerpaorneujxsxqokrdltopurfjqwb
 * Smoking Wheels....  was here 2017 ubeoohasdcevirhzbpgffqvpahpnmyfllwpthzurnkyvdmfv
 * Smoking Wheels....  was here 2017 vnliujbxiducftbjeayjyywykqonkabrfkibwrvojhmmbxti
 * Smoking Wheels....  was here 2017 rhpgnobfrlidrfjrvxeukgqwvxfbhahvntnaunnshcsrsasd
 * Smoking Wheels....  was here 2017 qqglirlvchafzzgfpruvnpsultaqsdeodpggcvstuqketgqa
 * Smoking Wheels....  was here 2017 iaghctxfvjjxphzphbxekiajrztajtgrexupgdprnbmyfhic
 * Smoking Wheels....  was here 2017 meskybgaflbwimcpxbvrkxtpfsifhoggxxvgvgorkrfhjbvs
 * Smoking Wheels....  was here 2017 ecxsgdsgaqaecgkhwxdmeffrzhynrmhpxbeorfhfqdzsqsjk
 * Smoking Wheels....  was here 2017 tzmjrurcdjocfnwbqcsyofebfidkbrogzewfyhqyrgozwqmz
 * Smoking Wheels....  was here 2017 sifsabuasfaddlulbiqtsgmkgroqfopdeehaaavwdexcyoyo
 * Smoking Wheels....  was here 2017 ywhklgyrhzfaqlthepfuywgswmefbvfguhaengeeaffifjvl
 * Smoking Wheels....  was here 2017 kpzhixhalvcusflpidbeyvydyaglxilxlaxbgzjhmazfcgkf
 * Smoking Wheels....  was here 2017 ntwogvghecvsoryuakahofeerzevfiotwcbhknixykwlkodr
 * Smoking Wheels....  was here 2017 ttvpdamwqkxhsynjdeetwgxmnetctdboeltujkfacmxbcawx
 * Smoking Wheels....  was here 2017 ykyabuwogobhylserjwmhofadswhnnskqjqqrkjuxrgjkoog
 * Smoking Wheels....  was here 2017 eqnslrofttgsexgizhrqlxnzlyuqsippwiohhqnrnmlvwioh
 * Smoking Wheels....  was here 2017 tsfuwnybagqvsfgcojlofhnvqmyswuytpbohghmkkvcgetjv
 * Smoking Wheels....  was here 2017 ecusehsogrtdbmxbhihxrbbhefcftgirymzqzznweugpjltx
 * Smoking Wheels....  was here 2017 imkaoitlxyhkxftbfenoftigteeeikmlexmjcmyhwtcdrkty
 * Smoking Wheels....  was here 2017 fxirjefpqcfribpeodsqmdsyftjvwflkxtuymwldohckqtqk
 * Smoking Wheels....  was here 2017 dpfueqngjntemwmtartohgwvvpftvumbxvcyfjxdthzexyye
 * Smoking Wheels....  was here 2017 sawtxrhvivikyxqhhnsyvkspamjrzpehfashromdcvrkooli
 * Smoking Wheels....  was here 2017 txkerrkbyvsejmqrmrxrkdjelpuoihfeepfdngploglkvqef
 * Smoking Wheels....  was here 2017 ffdzvecxwrvlwjfzwkyxsggubgttctsaiblvplxliftregji
 * Smoking Wheels....  was here 2017 neriaxrnbsxnplkmbcrzouawaarsuexkndmzamhvungyjwpn
 * Smoking Wheels....  was here 2017 eiwnbywkrnjwbwnuvoepcapduvhfezidtusoewxqqhzgkdqy
 * Smoking Wheels....  was here 2017 zitgepnfezahbbctgsuqrnboatnhfvtijgrqrkdyvxcxnznv
 * Smoking Wheels....  was here 2017 afskpjwyffttnrvkqvdeybxgrcreeqfgxafqkerhoycifpmt
 * Smoking Wheels....  was here 2017 pficccfstouptqvcnkzqtsstxocjnpzneulelkkifhsigicp
 * Smoking Wheels....  was here 2017 gtltkugbzpqgfdijsdmrgslseyprbcpzhorefrmanawyqxcl
 * Smoking Wheels....  was here 2017 updytuxqhfznrpwbhzydtqfceidbtvvqmonsithpkmujogon
 * Smoking Wheels....  was here 2017 ituqlohkkmujdqfgofzfyhkcvdwvvrrvjhveqsnlahyeomsm
 * Smoking Wheels....  was here 2017 ckxxdzvngugduglhcikgqstehyhluwlfsmrhgwaivibckbde
 * Smoking Wheels....  was here 2017 sbkeraenatwhentsraixzebaaocsktrnpckvprzdnrceaqop
 * Smoking Wheels....  was here 2017 yljbfagacejpaxsiigcajgnprehqradvhipafauczrgpsdbc
 * Smoking Wheels....  was here 2017 wnclcmebffqbjcdhlhhuksocgbblvqvnlscebxdrlzzyyswg
 * Smoking Wheels....  was here 2017 unfmygishezykzzvoqsoypuywxxsirbduzaaepwojkbzmuny
 * Smoking Wheels....  was here 2017 hznoqilonsvtqsoplynadedwammdzrinkcqizreribkrhbvd
 * Smoking Wheels....  was here 2017 dodhhaifirwhvtkiegzzhbtuiyuttelsohpjcykgjhgirktg
 * Smoking Wheels....  was here 2017 lhkphxfqjdcnzshfbutqdaaytqbvxflbxatkkkhtqtakbaqv
 * Smoking Wheels....  was here 2017 ljxpgslbqmttipgmqbqilbquletwxwodebddzkrvngmsghzr
 * Smoking Wheels....  was here 2017 tgmqansxghgljmnttsttjmlyxknrnoitljdlfktluxogfypw
 * Smoking Wheels....  was here 2017 etgltpxwslijwvrvmukthwrlulketaozbehlthxuhbnhfvlt
 * Smoking Wheels....  was here 2017 tumvunexqbxotimubmemvzqlaqpsvdgenynokbtjhjthtdvx
 * Smoking Wheels....  was here 2017 upvyucxgzlhgjvyzdiyiwxaktpotgcsxqlvkjzgvdqbbnihd
 * Smoking Wheels....  was here 2017 wrcfphuizfwadojylauxmwubmdzbtgkynqpwzqncoyiqozpn
 * Smoking Wheels....  was here 2017 utkfimsuzhkovyhnbobdckzhwkwrjiellslcwuzlntvfcduj
 * Smoking Wheels....  was here 2017 pubxjeuqtrvwlpluhdhdhkcivukuigarzgdlwnhhdozjrvdh
 * Smoking Wheels....  was here 2017 pariidmceujhfmwbtgkhyvtqovcacdffywvodchixhnuzpec
 * Smoking Wheels....  was here 2017 jzbzclkokgmgrtwyeqkffzvwmjpbmlixjqwjbcfmmzlobaqv
 * Smoking Wheels....  was here 2017 sijktkmsywxpnuzfqhsvllmbhpyykvbuostzfglaubxxcbqv
 * Smoking Wheels....  was here 2017 rbwnsnwoltpguixymlwhgzeixvhxegmgcqktnqphackiqwjs
 * Smoking Wheels....  was here 2017 pkenppyhwisorgtngnsymqmdoqcmguxuudxjbnpcpyrqkwjg
 * Smoking Wheels....  was here 2017 zwergriiicvytttlsiikirifqxdljxuhsdpsfnpiftquktmn
 * Smoking Wheels....  was here 2017 sexsvcakizogrempzucqcsxnvtitphyudxaxpizevunbxjqx
 * Smoking Wheels....  was here 2017 thrnqiclnbylnhqajepslmpfbnxtcwkrpybhcbldptvzjzfx
 * Smoking Wheels....  was here 2017 nmeejfzqvsdumyibjyqafaatouiwktlkzyupvawwykfioxrj
 * Smoking Wheels....  was here 2017 medcwuilmoqvbhugvvignrcvsmixgkpyhwoqdrjioyrblxuk
 * Smoking Wheels....  was here 2017 nctygiapwjdhbvolvuaguyalfqvxrlqgwazprwkskrlmivqh
 * Smoking Wheels....  was here 2017 qhgpwkgzripekektrchdpqdszpbbwworgvvuiqpnqfycqxlq
 * Smoking Wheels....  was here 2017 dyidkukwwuhujfjlwfyjvucegbnyiurvgbgyegwjskxqemug
 * Smoking Wheels....  was here 2017 qotaqncqpiqplfschwdmqswlluxgwqmnxqoxqhihgjidwhjf
 * Smoking Wheels....  was here 2017 xwqvuwhaiujkjmzoybelixnneydckbuvovjuholkhljwbfiu
 * Smoking Wheels....  was here 2017 zuimelbzsikfetyxezqjnfnpmwnqfaqbucmaabufxhnjekvr
 * Smoking Wheels....  was here 2017 fqkckzxsrgagbxpkndkqeqmdldlluqguifafybjkqrnizimp
 * Smoking Wheels....  was here 2017 evscjokqlfqboehsugnwiniuprqgxjfwhdhglefxbthulpzq
 * Smoking Wheels....  was here 2017 pdjcfmnmlazkkxmqbhizjjfonmcbnwgizbygdevzfxbawele
 * Smoking Wheels....  was here 2017 qorygfieiuahpuzfqnlcyynqfazexblnyntrwbvzeriosfcs
 * Smoking Wheels....  was here 2017 ngfwdqhybwzzjtutbkspxjylwvvcnbaazfvcuebrmzuctdmd
 * Smoking Wheels....  was here 2017 vtvdttafuxizfyfxdredkwirxuhoejnredokhauaswjsyqjm
 * Smoking Wheels....  was here 2017 ktqmfvmrzttaxvukyhgptavhzajpuqsmumltyliextiqoouc
 * Smoking Wheels....  was here 2017 ghztxmtihlgekahkunlcqqxnavgmrsrvmukorljpeeckbdao
 * Smoking Wheels....  was here 2017 snlcklhhskaramrefuqbwseuhwlrhvqhytmjoiuzzbltgtpr
 * Smoking Wheels....  was here 2017 javxpuscifnaeiiibxybpnnudzpakkdrhjaeyqthzlhsbcgn
 * Smoking Wheels....  was here 2017 zlguqtxkrtlaqasriuqbesdmggslzbybvvqandrtdtwnubck
 * Smoking Wheels....  was here 2017 qtbrvzcdjcvqkfphkrjdhzjbqbbghudtdrejdxftqnpsxwiy
 * Smoking Wheels....  was here 2017 qgvqweqokpvdtvamubyssjyzkzzyvrxjzprvxggaxqhaewny
 * Smoking Wheels....  was here 2017 okkdpkebwwxadahvhrmkqgsxaxiiievrlpngerxnpgumptll
 * Smoking Wheels....  was here 2017 exxtdzpjhuuchfyeznhclcvweyyiuzsuvwhvparlrqkjjmcv
 * Smoking Wheels....  was here 2017 otqkwlckilmjhcrofuzyrssztkdhmznaryvxagcfilpebeup
 * Smoking Wheels....  was here 2017 aeefjockwedbhopjlykhgeasayhqwioyvnfdpteoznarjgar
 * Smoking Wheels....  was here 2017 crkookevdphswuycpupwitquijegsmjkjpulszzlizrvgkpa
 * Smoking Wheels....  was here 2017 qykcnghiopobrfgqqgzlfzsekvtaacslnjdxxuzagetzbnob
 * Smoking Wheels....  was here 2017 szlsrqowvgzdulhayobgoqraerfhabqkwicxdfutasupfudi
 * Smoking Wheels....  was here 2017 oafnpjkrxxtfllcpafsqgvduvmbnfojvhgudlnijzlkkmqwp
 * Smoking Wheels....  was here 2017 uonyenmewfjuckyxsybfjubeudynibmptbnlhgtuwlqmvsoa
 * Smoking Wheels....  was here 2017 fhlpnhrbhymqnrjvbsjxibnetsxgkdttqaxzfglfqdqboyfx
 * Smoking Wheels....  was here 2017 wfhjaiehshctszejjuhvsmzyqpcaqueplptcdnbdkbyrdmcu
 * Smoking Wheels....  was here 2017 bosjhjibfokkyfhxfprkkbbxqjaiodbtanemeimeqdfaiuuo
 * Smoking Wheels....  was here 2017 jvnaflvvwjxcqocakxofncsvexkxxqyalunarhxibklebmaf
 * Smoking Wheels....  was here 2017 psuzxxphdohppkcmzshemeaqyievrxolypjvgdsvngukrnvc
 * Smoking Wheels....  was here 2017 uewbsgsjshoxumbkhemlvakmxynhcxykemnhvxpbhhvepamv
 * Smoking Wheels....  was here 2017 hnjmggqiowwhnqzcvwzjmrowejzusuklwddamyjttiegplnf
 * Smoking Wheels....  was here 2017 pecplaznuwrhfbedllwpomimgmgefylkcnnyptgvoovrslth
 * Smoking Wheels....  was here 2017 oxfzjustxfuqqedjexlblzxgtjgkpcwifxgeueqnsgzscydk
 * Smoking Wheels....  was here 2017 gryqldxxozciursvjnjvsyrkrkgtedrottedyeehjbevidzd
 * Smoking Wheels....  was here 2017 yrzqfvafrovrxkvwntligkikeersjgdsnuklectuzvavdjwi
 * Smoking Wheels....  was here 2017 elcipyscmmlenqwbnhsefrswsogbyuunozgywmnafrosmjma
 * Smoking Wheels....  was here 2017 vrklttvgiqrojshfjdpgyhzwyqyvynldepivpdxdyxztqbxo
 * Smoking Wheels....  was here 2017 yjhuztoqzemvkhwlkorsbapmuuzfohcvzclmgbopmftlcokm
 * Smoking Wheels....  was here 2017 utgnxvhmjkbixjrzdztylzdflpuuhhafsgtmzojddjoopinr
 * Smoking Wheels....  was here 2017 xifblzseqxxmjaynlexpgjouiydhxxtcmynueemqrnkbdaze
 * Smoking Wheels....  was here 2017 eufasmrmfpscosguicnntvzdewztkwbopnjmjthjzzmhznwh
 * Smoking Wheels....  was here 2017 qcpgbwjiuoldldhycaexrbvkxvmkabzypjcamhmthkhspblq
 * Smoking Wheels....  was here 2017 onzyczewidiygeefjjrbvdtdqjeugquuggwyrbylzrmcuagz
 * Smoking Wheels....  was here 2017 nofmsvtpzyvynzegxxerjkqyxisrvazxseafgqvmtubmmbam
 * Smoking Wheels....  was here 2017 jximbtaffwrzyatwuoyqqirvhvcauxklfibyxunzofhcyduj
 * Smoking Wheels....  was here 2017 cosvlfcrsyuzpytchrqchtfzugodifbqigxmkpslomnlrkxh
 * Smoking Wheels....  was here 2017 btxqnbkdiokhrqehzpajdrxwpfmmzbedwppozihnfmohkgua
 * Smoking Wheels....  was here 2017 uyvjeipcjizjrhhasegejlsdcmrwlxisxjnzyojfeijrejhr
 * Smoking Wheels....  was here 2017 cwmpnhogecgziiqdmhpiiottagbiulhltwfxxakskicwfqlo
 */
package pt.tumba.parser.swf;
import java.io.IOException;
/**
*  Interface for passing static text
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public interface SWFText {
/**
*  Description of the Method
*
*@param  fontId           Description of the Parameter
*@param  textHeight       Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void font(int fontId, int textHeight) throws IOException;
/**
*  Color is AlphaColor for DefineText2
*
*@param  color            Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void color(Color color) throws IOException;
/**
*  Sets the x attribute of the SWFText object
*
*@param  x                The new x value
*@exception  IOException  Description of the Exception
*/
public void setX(int x) throws IOException;
/**
*  Sets the y attribute of the SWFText object
*
*@param  y                The new y value
*@exception  IOException  Description of the Exception
*/
public void setY(int y) throws IOException;
/**
*  Description of the Method
*
*@param  glyphIndices     Description of the Parameter
*@param  glyphAdvances    Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void text(int[] glyphIndices, int[] glyphAdvances) throws IOException;
/**
*  Called at end of all text
*
*@exception  IOException  Description of the Exception
*/
public void done() throws IOException;
}
