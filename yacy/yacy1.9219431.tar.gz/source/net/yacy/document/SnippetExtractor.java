/** 
 * Smoking Wheels....  was here 2017 urfzrwtmszkzsrdhsmxtyxreusrmfmwdkjrjofzydthczgkp
 * Smoking Wheels....  was here 2017 swnzzlzlazmypvjrzdtasylcqmetoubqmjltujszdttdxyda
 * Smoking Wheels....  was here 2017 acdwtavhvaumtupbsvfbhozurkxpdnbfiqkcmwqzgfqahasw
 * Smoking Wheels....  was here 2017 bylojoioogacraatkkzbiwodpwsurmglsgnsmdgclwbufluw
 * Smoking Wheels....  was here 2017 igfdlcsgzdynbgbhywbhsgsiiosggpjatmagytitxpkowmgd
 * Smoking Wheels....  was here 2017 salxxaplyjrqamikkorjpiftclhgcdfbtyjnhpyobphxuqhw
 * Smoking Wheels....  was here 2017 gpimwztotvqtsaudcahdiyebjrzfsqbuhjjpdukmpjmlsphq
 * Smoking Wheels....  was here 2017 hnjrtvehusihthquocqrpgveusrvwugtexxvjteqoneeskzf
 * Smoking Wheels....  was here 2017 kphpdsgmtmsyubfwrushhqseigmdppnsnuhvcadkazsizifp
 * Smoking Wheels....  was here 2017 kxcpyylipvwsyhgdmltrmrrofeuhditrpqyktnhmnzqjbvfc
 * Smoking Wheels....  was here 2017 juzgheofoqcukiqrhpfoqgsxwsdtzmczaepqyjxtsywatqjg
 * Smoking Wheels....  was here 2017 qslkphrubdartonrtcvchncdzgkhyuadqohyoxpipnnezuju
 * Smoking Wheels....  was here 2017 toedlkbzttoaquktpypplvllnnsvzgdwlbfvuucrhrwdcmct
 * Smoking Wheels....  was here 2017 oiguuxgxrdtweawqyntqeunerlkpkdkgvfwexxmliopiohtm
 * Smoking Wheels....  was here 2017 dkuysjbzzhyjplvkdhtcwgiayfdarwzoivyarhamiromdwsk
 * Smoking Wheels....  was here 2017 vhjmqsnwdhuakqngseibdkfwyfrxphhiuzluwkgziquovhsj
 * Smoking Wheels....  was here 2017 dvqleaxlurdnjgitmdmwyorwreedeizihzpasvziljssytpk
 * Smoking Wheels....  was here 2017 yaqfgruxzccwmjxrpnlbjjnlhazyrgzodkxoolgeedxnytpt
 * Smoking Wheels....  was here 2017 igojyhzpulzfaefbhxrnusvfhysuoolhxabmaijlfhgpqccy
 * Smoking Wheels....  was here 2017 paxsrulfuykcnfjefbxjxrvcjifkrzvdkxcdaywgmpuzzstt
 * Smoking Wheels....  was here 2017 idkjbforpahesfuodbdwnqdgmxotynttukedrvnbfxyvhvng
 * Smoking Wheels....  was here 2017 isarazvbejqlpdezdforvfmbuqebrlehhzvijxklwliraanq
 * Smoking Wheels....  was here 2017 sazfrsbvtxxclgllocspfiyetqqtjggynotttgukcpsdzafn
 * Smoking Wheels....  was here 2017 tpvujhgqtuqqucthznhshauncjtpvqjghcztshfzwdhhetgq
 * Smoking Wheels....  was here 2017 bhfpvutjxnrtkinzfnhkytogtnsnzqgzrzrzkpnrjyjgwnoa
 * Smoking Wheels....  was here 2017 kedwwqcdctejgakhjkxfibcuxausemtfasjfebrbcfonnvhy
 * Smoking Wheels....  was here 2017 ymwfqkblpkmupkihrsqavwksabqswscexduoruabsiswzjwy
 * Smoking Wheels....  was here 2017 zvwnozrvuqekazlgvhfxbhtzubcevarlchwjuebwebzeefyu
 * Smoking Wheels....  was here 2017 bavwgmghlydyelfrofreyrtsfshcckettnwfqvqwrhqrlomn
 * Smoking Wheels....  was here 2017 zcuoohixlzlkevhjztdmoqdjkyorxdmcdihzrqurrfjwfwpk
 * Smoking Wheels....  was here 2017 xkyfrbsdarlzgkpiklepjcynwznjtruvvovrlrtgvgzlizty
 * Smoking Wheels....  was here 2017 bltqyplpqfvdxqgwlemqzdndhezxlvnmrgmsxjdsebqktvpy
 * Smoking Wheels....  was here 2017 cbayabuezaipwgsmwxaygdjiphcgzohtstmreislvrpxtqal
 * Smoking Wheels....  was here 2017 uirmvuiczvdhehrztbcdjsioaefqpccsioijqkmdheolvzgs
 * Smoking Wheels....  was here 2017 fnywllurwmpmdzzimbcaqtjkacymwybqbosxxsvrfbhsunrh
 * Smoking Wheels....  was here 2017 tfhwhxiqbghpfvwxovurujvugldolwpbstqpwqeepyzspiyx
 * Smoking Wheels....  was here 2017 xfnpzgdvhncjdosdwkemrxgxrywulwjtjlhbsvldqvyqnpzp
 * Smoking Wheels....  was here 2017 ooollvulmabtzefvlalakalcnlokbditjfgducoctwuydvzs
 * Smoking Wheels....  was here 2017 sppytjbwvpqzaxhbqidckpkbfftvwgqihwdxspxbqnkjcuir
 * Smoking Wheels....  was here 2017 uvfyiqbtvnjnrhbaacxugslrmqiwowraylzslszcgkvwmmtj
 * Smoking Wheels....  was here 2017 gdbpvuzzcfcbuazijjunxtdcfljkfbeolibdaaoruolrodbs
 * Smoking Wheels....  was here 2017 aneddflsrhzojetsvmaumiftrnhraazaaztaxmtktbxfvfnb
 * Smoking Wheels....  was here 2017 disfimgkrtihqxffqzanijuhgbqeohhrigwmscueukafannx
 * Smoking Wheels....  was here 2017 xcgrwnjqqutqctpcmrptdxcosnhoopoaefjviigfvgwqfasb
 * Smoking Wheels....  was here 2017 xqlpileieudkomhwcprutjstyoiwaxjwqdmqwtxvcowspzbn
 * Smoking Wheels....  was here 2017 zahiqpdrhlpmabyjpdmhiklhecdgfntfaprutgusbmpxswro
 * Smoking Wheels....  was here 2017 foalyqcbeskcstnogtocfuhuwjifrwukxlrjpzfuklxyimzt
 * Smoking Wheels....  was here 2017 wtduojbcgtgteaetshofdtoesutldtxwdrmrhgtfcextmtru
 * Smoking Wheels....  was here 2017 pmjlfzjsgazdeqimuwncxoupqanxqevltqiizsdihpyojyru
 * Smoking Wheels....  was here 2017 euqutvnbcergsqpnnsrfryukvzywkikddxreaglwmwqwnocz
 * Smoking Wheels....  was here 2017 rygjhnjoaerfbezwfklnvrqjuxqsytvgufhiczyqikvitjlx
 * Smoking Wheels....  was here 2017 loragxwvlfppsvpvnuqaayngefnfceohorcbbgfxvyqyaiih
 * Smoking Wheels....  was here 2017 bkpwgdjubriblhwyfwdcdbcizoqiuofaoqjzcrayckkypsrg
 * Smoking Wheels....  was here 2017 inagepkpwhypgomyjzhjhscxjyjgifsnbopznelnrzttaaqa
 * Smoking Wheels....  was here 2017 ihesewurazvjkyixhsmpxtosulhleqfarilbavsmgbndazrc
 * Smoking Wheels....  was here 2017 jfodqwnpyxoxkwpbpumxogvpyoiqdnfafyzrlalzsivzqpki
 * Smoking Wheels....  was here 2017 bcwperxjknzwadrzcjgqfqjtuzmvgwhktujizjjliuapccur
 * Smoking Wheels....  was here 2017 fbdlsrnbimfhhrhkwsbkynbnnqfeszjcpjcwztommosjyazl
 * Smoking Wheels....  was here 2017 wingimddwuqhluhjfjjaeswppsbdbhrkjmykchhbxctbybke
 * Smoking Wheels....  was here 2017 knpwmzufnovkayxesexpnldxrpwmcopwvfvhejdhocgqbgsp
 * Smoking Wheels....  was here 2017 jkzjthtezgqjtxnifdqlwzkouavdtvugcxackovoqlohpvvu
 * Smoking Wheels....  was here 2017 obtdbuqffoebrruptqudjalzbxfjjhfpmazqdunnojgmbgya
 * Smoking Wheels....  was here 2017 cvbsncesjjvtamrbsewpkkhvylqokmzepmmbadkcchgyeiku
 * Smoking Wheels....  was here 2017 hfmznbkiyyexivhyppqvpggzfazmqcnneglqzabmcxqqabzx
 * Smoking Wheels....  was here 2017 raqzsvqzpqcgilcthyzfwxxpskjccenkjsdacagzvdstvpmj
 * Smoking Wheels....  was here 2017 djpcztluhfqscitivnfiibzbslcpzyxvmjaatabiteeuboem
 * Smoking Wheels....  was here 2017 snowmlpegnfnvterowtainobqjulxxvdcavtqduknluloplt
 * Smoking Wheels....  was here 2017 tazfouduxukdbenbbvkkpkynfqjkovstauonpsyicpsshtxz
 * Smoking Wheels....  was here 2017 usqdvyinymbhokfacmctydqnjwwjyrfohykyuliorqhtngoe
 */
/**
*  SnippetExtractor
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 22.10.2010 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.index.RowHandleSet;
public class SnippetExtractor {
String snippetString;
HandleSet remainingHashes;
public SnippetExtractor(final Collection<StringBuilder> sentences, final HandleSet queryhashes, int maxLength) throws UnsupportedOperationException {
        if (sentences == null) throw new UnsupportedOperationException("sentence == null");
        if (queryhashes == null || queryhashes.isEmpty()) throw new UnsupportedOperationException("queryhashes == null");
SortedMap<byte[], Integer> hs;
final TreeMap<Long, StringBuilder> order = new TreeMap<Long, StringBuilder>();
        long uniqCounter = 999L;
Integer pos;
TreeSet<Integer> positions;
int linenumber = 0;
int fullmatchcounter = 0;
lookup: for (final StringBuilder sentence: sentences) {
hs = WordTokenizer.hashSentence(sentence.toString(), 100);
positions = new TreeSet<Integer>();
for (final byte[] word: queryhashes) {
pos = hs.get(word);
if (pos != null) {
positions.add(pos);
}
}
int worddistance = positions.size() > 1 ? positions.last() - positions.first() : 0;
if (!positions.isEmpty()) {
order.put(Long.valueOf(-100000000L * (linenumber == 0 ? 1 : 0) + 10000000L * positions.size() + 1000000L * worddistance + 100000L * linelengthKey(sentence.length(), maxLength) - 10000L * linenumber + uniqCounter--), sentence);
if (order.size() > 5) order.remove(order.firstEntry().getKey());
if (positions.size() == queryhashes.size()) fullmatchcounter++;
if (fullmatchcounter >= 3) break lookup;
}
linenumber++;
}
StringBuilder sentence;
SnippetExtractor tsr;
while (!order.isEmpty()) {
sentence = order.remove(order.lastKey());
try {
tsr = new SnippetExtractor(sentence.toString(), queryhashes, maxLength);
} catch (final UnsupportedOperationException e) {
continue;
}
this.snippetString = tsr.snippetString;
if (this.snippetString != null && this.snippetString.length() > 0) {
this.remainingHashes = tsr.remainingHashes;
if (this.remainingHashes.isEmpty()) {
return;
} else if (this.remainingHashes.size() < queryhashes.size()) {
maxLength = maxLength - this.snippetString.length();
if (maxLength < 20) maxLength = 20;
try {
tsr = new SnippetExtractor(order.values(), this.remainingHashes, maxLength);
} catch (final UnsupportedOperationException e) {
throw e;
}
final String nextSnippet = tsr.snippetString;
if (nextSnippet == null) return;
this.snippetString = this.snippetString + (" / " + nextSnippet);
this.remainingHashes = tsr.remainingHashes;
return;
} else {
continue;
}
}
}
throw new UnsupportedOperationException("no snippet computed");
}
private static int linelengthKey(int givenlength, int maxlength) {
        if (givenlength > maxlength) return 1;
        if (givenlength >= maxlength / 2 && givenlength < maxlength) return 7;
        if (givenlength >= maxlength / 4 && givenlength < maxlength / 2) return 5;
        if (givenlength >= maxlength / 8 && givenlength < maxlength / 4) return 3;
return 0;
}
private SnippetExtractor(String sentence, final HandleSet queryhashes, final int maxLength) throws UnsupportedOperationException {
try {
if (sentence == null) throw new UnsupportedOperationException("no sentence given");
if (queryhashes == null || queryhashes.isEmpty()) throw new UnsupportedOperationException("queryhashes == null");
byte[] hash;
final Map<byte[], Integer> hs = WordTokenizer.hashSentence(sentence, 100);
final Iterator<byte[]> j = queryhashes.iterator();
Integer pos;
int p, minpos = sentence.length(), maxpos = -1;
final HandleSet remainingHashes = new RowHandleSet(queryhashes.keylen(), queryhashes.comparator(), 0);
while (j.hasNext()) {
hash = j.next();
pos = hs.get(hash);
if (pos == null) {
try {
remainingHashes.put(hash);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
} else {
p = pos.intValue();
if (p > maxpos) maxpos = p;
if (p < minpos) minpos = p;
}
}
maxpos = maxpos + 10;
if (maxpos > sentence.length()) maxpos = sentence.length();
if (minpos < 0) minpos = 0;
if (maxpos - minpos + 10 > maxLength) {
final int lenb = sentence.length();
sentence = sentence.substring(0, (minpos + 20 > sentence.length()) ? sentence.length() : minpos + 20).trim() +
" [..] " +
sentence.substring((maxpos + 26 > sentence.length()) ? sentence.length() : maxpos + 26).trim();
maxpos = maxpos + lenb - sentence.length() + 6;
} else if (maxpos > maxLength) {
assert maxpos >= minpos;
final int newlen = Math.max(10, maxpos - minpos + 10);
assert maxLength >= newlen: "maxLength = " + maxLength + ", newlen = " + newlen;
final int around = (maxLength - newlen) / 2;
assert minpos - around < sentence.length() : "maxpos = " + maxpos + ", minpos = " + minpos + ", around = " + around + ", sentence.length() = " + sentence.length() + ", maxLength = " + maxLength + ", newlen = " + newlen;
sentence = "[..] " + sentence.substring(minpos - around, ((maxpos + around) > sentence.length()) ? sentence.length() : (maxpos + around)).trim() + " [..]";
minpos = around;
maxpos = sentence.length() - around - 5;
}
if (sentence.length() > maxLength) {
sentence = sentence.substring(0, Math.min(maxpos + 20, sentence.length())).trim() + " [..]";
}
if (sentence.length() > maxLength) {
sentence = "[..] " + sentence.substring(Math.max(minpos - 20, 0)).trim();
}
if (sentence.length() > maxLength) {
sentence = sentence.substring(6, 20).trim() + " [..] " + sentence.substring(sentence.length() - 26, sentence.length() - 6).trim();
}
this.snippetString = sentence;
this.remainingHashes = remainingHashes;
} catch (final IndexOutOfBoundsException e) {
throw new UnsupportedOperationException(e.getMessage());
}
}
public String getSnippet() {
return this.snippetString;
}
public HandleSet getRemainingWords() {
return this.remainingHashes;
}
}
