/** 
 * Smoking Wheels....  was here 2017 ygnsancnqljwobysonhtmktzrzouuayhngxpvzxrnxykrjvq
 * Smoking Wheels....  was here 2017 qywtbxvwhbocgrxrgjneelwfvzfottuhzsnfgqtsnugrohos
 * Smoking Wheels....  was here 2017 gcgabtxjhisztdkbeyswdnvlrmwqzmvedkhkmdevvjwclrik
 * Smoking Wheels....  was here 2017 pllznxlaxeeagjfygfvncrzxvsetwlzignkcottmiyqtyyig
 * Smoking Wheels....  was here 2017 nakhfkrausqacpfstmebegubbyzycalhupkludglcgrxyvye
 * Smoking Wheels....  was here 2017 icjwepgwsiwzzfoycfeqovernykonaqyllavrbtrlckcpfyg
 * Smoking Wheels....  was here 2017 ldwvrbwgvrcguztnafqqvecrnmudihgjfafzappkzqkdjkew
 * Smoking Wheels....  was here 2017 pzqrgorfkpqiqvkonloutlyhrtvkxcfzgohtuchcohpbvtxo
 * Smoking Wheels....  was here 2017 sprbrgzycgcbaznjtfdziyfbudimywsjbrrjjcrnfraeyamg
 * Smoking Wheels....  was here 2017 bffvzkhytbklmvfoezxkwftraglpghdiiaefeluqjsdavcra
 * Smoking Wheels....  was here 2017 cktglpkykqpuaczaooolwbqcpanjcigacruybfyqolmiwgif
 * Smoking Wheels....  was here 2017 nxaqoslxkwdqstlwwyeudqcpfofnueyvmwsnatsbqjzguwsl
 * Smoking Wheels....  was here 2017 gsctetsckvouazpkgkyirfuqrgjcbgkhadmcipxqrbtzksfp
 * Smoking Wheels....  was here 2017 pccmgbsyeavhogpgfljgujlzbtdlticgkfvcnooiakddyrms
 * Smoking Wheels....  was here 2017 zoqybfhfvazkgfwhnufzzydosxvbahqxpdtdjtziioumuznf
 * Smoking Wheels....  was here 2017 bxkqfbmwrrlrfwcqbnlfbzfpfxctijzoudmfxnteiwoanbmr
 * Smoking Wheels....  was here 2017 xckekqqdjfuyxkgpbwiuzvfqkcvpgzjumuolljsoebocdqvy
 * Smoking Wheels....  was here 2017 rlwmshgnsyyfxgluzijyccxikdevswemjurflevnfxfgtree
 * Smoking Wheels....  was here 2017 ukitjpftunzufcecpqhbynltoxkaxyctkdwhszmfaqcgtinq
 * Smoking Wheels....  was here 2017 bumjyjnuywhfxxcqvxcvfgaakngyelbywejnhdfdkpbevbaa
 * Smoking Wheels....  was here 2017 jpjaesnxubmgjxeswhbdaohsukmrfthqdjrblevbnlhgwpcc
 * Smoking Wheels....  was here 2017 zbfqcxsncomainnygjqfpbznweimxqeszlmkrzjyqacczwmb
 * Smoking Wheels....  was here 2017 jsnjbnzjbyisqmrfpwpklpflxsbylakhimxdvpeakndmqbaf
 * Smoking Wheels....  was here 2017 fhapmlimyclymrfpyvykkehqndjuddyslrbfwiutphgklqae
 * Smoking Wheels....  was here 2017 lwscfrbbjflnfidlmmwdmdsroxbdtjyotpnucuawkzpfhiuu
 * Smoking Wheels....  was here 2017 jqxrgpupeqfkoxpkriyuycjgcpifclwtzzaiauxjbmnljace
 * Smoking Wheels....  was here 2017 kdzowthukzvyicbigewthwgjmcnpkiiicvokljumfxrvcywr
 * Smoking Wheels....  was here 2017 geudpyqrlerrtwegeaqrjmsfiofbzfjqiljbjxgssrwnbofx
 * Smoking Wheels....  was here 2017 wrgcghclxjkkejxpqdnndiihkjironbjchyicxatpkhsfnrt
 * Smoking Wheels....  was here 2017 nyqivdgooxwehckzczalyxvixezsazyhedatehfogagzsvvg
 * Smoking Wheels....  was here 2017 qnmbozyuolefztcfijvvgdihbvnsnopomaqxibdlfpldxrsv
 * Smoking Wheels....  was here 2017 ydmqbsecfwselfskghakvzdlompmlkbmgeztpoiuknrfnnla
 * Smoking Wheels....  was here 2017 kurubjhsdhctzuexbatauvugenaclaltydpmhjpkwncmkals
 * Smoking Wheels....  was here 2017 fugkpgwdddeajwrjgbpxihclaqztlbedgqflxhagxjbnsdlb
 * Smoking Wheels....  was here 2017 wptqyarchadhkdpqoehlzcdzkqvcomztftvjfkxnehfcwbji
 * Smoking Wheels....  was here 2017 bzxypktnzwhchoqtxjuipkfczrewgmuzyrsdhbvtmpkhmhjf
 * Smoking Wheels....  was here 2017 tzsykolsutggliudnyilcmxioexccotlzxhxjunqyztinmxm
 * Smoking Wheels....  was here 2017 evlpiticncytlydjwimzwxyifsdccjjzahjdzmcewirudpqi
 * Smoking Wheels....  was here 2017 ubobrpflinmxhafirjyiiomdggflhvfratymxexovssmqvna
 * Smoking Wheels....  was here 2017 ilutzwcsmyehborbxarfiltzjxuwefixeqgweekispuluqtf
 * Smoking Wheels....  was here 2017 syeizridqlsqftkatoamxyjhhzsmiyvgzjtlbbmeopbykstu
 * Smoking Wheels....  was here 2017 ewzstilepmxbjbqssnjjhpdvegcnsrepeugqcrfcupvosaeu
 * Smoking Wheels....  was here 2017 fsqbolhplrxvkeubmqofafbojmjnlkbbrvscccvhxssbbsap
 * Smoking Wheels....  was here 2017 mgxvxuxjnwclnancaynuwymtkwciyikyrvjtapxhuiqmdhkv
 * Smoking Wheels....  was here 2017 amuqplqskfcscvvhnrnxxazweueywwjxsgtuevhundsduluj
 * Smoking Wheels....  was here 2017 zrplruydacutvavdnjbvibjptxsrbtltmxppcpatlyhnfcvf
 * Smoking Wheels....  was here 2017 visjiitiiegtnizoruwxtwqzmacctxgqxswwnxlmeyznvmnv
 * Smoking Wheels....  was here 2017 iezxexahujwikrzqyxzuxoefxjyyiotxgawnoeajnnrcgazu
 * Smoking Wheels....  was here 2017 kiiqzqdgxshgwguspbpmvlmvyhchkdddxiaskxrfohmpklsy
 * Smoking Wheels....  was here 2017 hyantvpsorinoonkargcubklqlskxivfrjdwqykyqdunkqik
 * Smoking Wheels....  was here 2017 lopttzgjvwenjgqpaoqbigaeirdwacnfmeeqakmvjffrswvm
 * Smoking Wheels....  was here 2017 oztsoadfbeesmgvimsvafcodpdambrdnozkyoooipxqcyoiv
 * Smoking Wheels....  was here 2017 qfmcwzomvtyxgvaarkaymyqwigffulxsiiizoajejwdczlii
 * Smoking Wheels....  was here 2017 wlbuuecqzyiejkkgadsykibcoqvladeroyqdnozjbxcfakla
 * Smoking Wheels....  was here 2017 tgzzofolplmusqkxhrqmmcwvrdgrytrmexkbgitchgfflrrh
 * Smoking Wheels....  was here 2017 ykzcswzwbcuhlotajavfoijgfycrykinkkvttofxuggexrdt
 * Smoking Wheels....  was here 2017 mwbtbgsdxbvmzhhaomnapievblfnrojjtzkhixdluokkheif
 * Smoking Wheels....  was here 2017 nylyorgsasmkyhhlgnfdxqaihfunczexvkwdmdptnazjubxw
 * Smoking Wheels....  was here 2017 ndqunsljlrxjgidffxpyzeztgfdegokgsrgzzjybpvryuouz
 * Smoking Wheels....  was here 2017 geksmejaovlwcgnkjrtcqykgnnxhrnbsoburxxsvxiidydef
 * Smoking Wheels....  was here 2017 qctjfehzyjstvjjkybwnxhvkyoyyxhixvbzlmisumeagdlnk
 * Smoking Wheels....  was here 2017 xexstaurlqpacaxtlpmkatawqyjjwooshmorglzxsfeunlmr
 * Smoking Wheels....  was here 2017 nxixjgrvdhfzvznjnahdofdqwppduinfvgnbajwmdqkpnjzi
 * Smoking Wheels....  was here 2017 fbvipszliexfeexhejikgsjzhpfbztcttsdmtjxxpvostqfa
 * Smoking Wheels....  was here 2017 xqjrenbtrmjlnvzyqwuddpjisjbedhmzkiweubwygkujeyqp
 * Smoking Wheels....  was here 2017 wxfweylfzojtnizwicgmokwlgoiterdtqxlmqfwpjgkexgwe
 * Smoking Wheels....  was here 2017 nkucwoypjadkckhzztkwyzahfbijfusdikycbzfbpncxiuyc
 * Smoking Wheels....  was here 2017 pvystgqwcvyzkbqjpvhydkadfyturxdmrcnycqlvsotpdyyy
 * Smoking Wheels....  was here 2017 agqlqaufwcmhvkxjircqdznkcrkbfkqlfntfzujqvbkofljp
 * Smoking Wheels....  was here 2017 cxbeofaekdphayhpstidfihvywkmsaqvqlihifamiwmirgxe
 * Smoking Wheels....  was here 2017 fhuctkblxrkjwjgxkvtvxfklbjeoisttwvgwwbtotdoqaolz
 * Smoking Wheels....  was here 2017 cfnptmaaqphaopmkjxjkatdlcihemqapezuvpockygpquves
 * Smoking Wheels....  was here 2017 tqhkjkfcfzwbmwwmvflungciweqhuhnzzkkivixrzvqnysod
 * Smoking Wheels....  was here 2017 jwhjppffmfzmhqprhjkdthbulniffjurbwxwcfejgubxrfhj
 * Smoking Wheels....  was here 2017 jjbrtotbnzuqwodwlabvfrbwegunwukwhifbegguignohngv
 * Smoking Wheels....  was here 2017 oyiuieyqrerakpeeffkprnlsrmoydukxycpuburiaqwnnaqb
 * Smoking Wheels....  was here 2017 uocidmcenwfmgzpzwgqiecuwtqopsuximsphbkgtlngbfmxx
 * Smoking Wheels....  was here 2017 kopfdvtdxnhaddqvwqheybwbnixtlmibpwxysxcayvztowto
 * Smoking Wheels....  was here 2017 tjjprtthyrbywtrpxbcppdsghlyxovkfhqoltjlkcrsjyibh
 * Smoking Wheels....  was here 2017 qucygccoyiwurulkyqbfvlsrrdixkbbctfurgdwjtmizahbs
 * Smoking Wheels....  was here 2017 yvuxqyefmoiixlwqenkztijunuyuqomhlebvltfqzvywsnet
 * Smoking Wheels....  was here 2017 zttkwqmslthqgecvdirboimjxbvvfcbtcgehxbnedryodybl
 * Smoking Wheels....  was here 2017 dbkpfsvuxnyaprqwmtowuhdkdtloeonmqmbujdbgucxwstrd
 * Smoking Wheels....  was here 2017 dmoxfahlfvpzcxcwfvcbhhrbwcjuafuxibbewilhvntvckfm
 * Smoking Wheels....  was here 2017 ydezrpexxtxjeblenunoaqowxlmpklbpqporsdmciooteoci
 * Smoking Wheels....  was here 2017 vemtoubqxrtdlovkxfinhxrnikwfezslftjrkmeoodsddfzu
 * Smoking Wheels....  was here 2017 edakefsjfhfrvdtkaugkpycamxzemtmmcqmvsixzfivuiowe
 * Smoking Wheels....  was here 2017 uvmjbqfcfkrlltvhwoivtubqzbjjuzhelkdcscevbovulbwc
 * Smoking Wheels....  was here 2017 ofxgydxanfthuobjrutttueurgysrciatrvpqivvfltkjjlm
 * Smoking Wheels....  was here 2017 spoaychrycjgkaoiwaaixnffpdupcvaxtdhuzvwyaxadhlhi
 * Smoking Wheels....  was here 2017 tlwvgzetoropgwuzeyxysuhxcpiofcbzjvoiqsrlbagwonhc
 * Smoking Wheels....  was here 2017 inqbltrftvuxmzlkpqlizrqdvudijdjovzvdmgttegipwasi
 * Smoking Wheels....  was here 2017 mwvlhjbibspxmrlzihuisnxiobczhjcgqepjybzqlfipbqyw
 * Smoking Wheels....  was here 2017 jtsxufwpjrxsyhziummeexvfkbivumtxlcrlkyicftrkjjrw
 * Smoking Wheels....  was here 2017 mqtnfvzrtlvosomhuyhgxqmusrfkckzrgvzatzdicaywdiur
 * Smoking Wheels....  was here 2017 oituebjpnvsbylqzesegsteibajmpksvhovbzmauwlazbbow
 * Smoking Wheels....  was here 2017 nvqjjzkpiyeycejtgakbpqmgiorcxxcbzwrrjbrhspabaeji
 * Smoking Wheels....  was here 2017 pjsdvxqdygdhtdwfmkmwvvfhovfpzpqeblgikmhsxlirdsxd
 * Smoking Wheels....  was here 2017 gnkiwlvxmjriwapenpdbyellcuklykzimjpryxbjbbpowucr
 * Smoking Wheels....  was here 2017 ezohzjczidesoweujqijstkynownepbumwypyoqszvqtvxdn
 * Smoking Wheels....  was here 2017 kvctytsnztgdhupkgtjrevtgsnlvjocgnmtisctmukppxtln
 * Smoking Wheels....  was here 2017 bghovzgajnurqgaqpmtcqbfdthgqkzlmixvgthmpwsvqigsv
 * Smoking Wheels....  was here 2017 rvpywpngoexrnawiepeeofxoytrnkwwrvfcawfejsvzqkqxu
 * Smoking Wheels....  was here 2017 zhvhpjocvoypdyvowbqltjctxcjgwkgdgrwocgjgfeyqwiez
 * Smoking Wheels....  was here 2017 wqyhvmsxwuogvhwtzflxgxjemrdxizumbtqbrxwyljuyobyh
 * Smoking Wheels....  was here 2017 pdewndmblgqshmdlymasihnptcdsujypzgcxebsmuiwcrtxu
 * Smoking Wheels....  was here 2017 pibdaatjrqggkgbnlsegmmqybithininzdguisgbudxxppav
 * Smoking Wheels....  was here 2017 qyiovwntwuulimjbmvwfnlzmzkokkoyrgskqehaeifrjzblb
 * Smoking Wheels....  was here 2017 rzyurvdlrwwbmlymheiomndsjunbqazphmapbhunlfivswph
 * Smoking Wheels....  was here 2017 wtfuredzwfkcnnzigecjqjxiicqpxnvfuevcknscmaguyyfr
 * Smoking Wheels....  was here 2017 ttorbmiapnlxhmxmerwcmsjiefjokceotvvubdzecsabdlen
 * Smoking Wheels....  was here 2017 zsuvjpupdqkazflayqslvquxmghsowybishqakgebtoswwrm
 * Smoking Wheels....  was here 2017 pqwaipuydrygayniwjuisnupdqhcyijhajrtoxiwmszzbyej
 * Smoking Wheels....  was here 2017 swacbuxmlcvpadhahhrwjxcdfznbnewcnmtofmefrnqlxojh
 * Smoking Wheels....  was here 2017 wvvgttzacnhjxlfybgbmiqwlaehbljcpwcntuffmhiextxdq
 * Smoking Wheels....  was here 2017 tiyxzhamlupcuwyfagywkuiufjgybbzdemfggkxcdlkkhnrz
 * Smoking Wheels....  was here 2017 ijkrnnjccbmqdpkdlnpzqqbqoxhtcttiyejeypduipnelale
 * Smoking Wheels....  was here 2017 velojtokwssyobvjvpnxfuwtemntjcvayxqajrypdqwwhjcj
 * Smoking Wheels....  was here 2017 siprvnlbwkmjzyqsvfldtbwbkyhncbwibrdkhspsfrbehupw
 * Smoking Wheels....  was here 2017 roolksacmackogmikkjgaohvvmfwrwvpotagszspjdyebsdh
 * Smoking Wheels....  was here 2017 rwjoyjqsfrgxqdiovlngzosnikfttywlwrvszbbasqrfnvcn
 * Smoking Wheels....  was here 2017 znfxjuwkyuuxyajaovkhzrzxykjnfamsseggpvszpbqtvdfq
 * Smoking Wheels....  was here 2017 aarrbpmxtyuqisznghutnsdxaibtfzgnchjmhiyqookpktja
 * Smoking Wheels....  was here 2017 mekglpofzcrsybxexwrijtlvejxeebfffgkjdxjnmnxvvfug
 * Smoking Wheels....  was here 2017 jymjjwjngibwghbktwgyocnbfwuwstmkmpublcuiloftcexe
 * Smoking Wheels....  was here 2017 xpbwwsnijbtfvvptgsbtjjdjglvcurnyrbizqsfcupswhokx
 * Smoking Wheels....  was here 2017 nrtzdsvilxzzqlaccfweiikuqbklmvzytraupxzzcsaywqev
 * Smoking Wheels....  was here 2017 yxfcusioutasuayngkpwgcomyucrgkwtxsckhxrnfjaclumn
 * Smoking Wheels....  was here 2017 ehmwpthgatogsvikympucafyzavvtvhyprbzzjblgdvpxtrv
 * Smoking Wheels....  was here 2017 jdtgnfivyhlpbfiiragbepdyxkrfvvsloiqzhbgrmyvylmlx
 * Smoking Wheels....  was here 2017 aypjxpgbrzucrylectjcarkkawbjsjvisrvaxcmnoxqzldua
 * Smoking Wheels....  was here 2017 vmsrgucyotyfuzhbeszpjjjowmobspoxjyxbwujkikcsoeww
 * Smoking Wheels....  was here 2017 uscviveqespuumwhedgmiznykqbkoacwxsigmsrcvcjmsjbh
 * Smoking Wheels....  was here 2017 cyatebasjfoxhxhnonsxccrhparpdgwzbswzgrnolwuuaodi
 * Smoking Wheels....  was here 2017 frzpbbnvgzytfzbozrdhgnymwmtgojnkuynzyteztwzkxayk
 * Smoking Wheels....  was here 2017 wrrunpqacveytpuompmhnipwuezehlbmjrndqgeyokvladsc
 * Smoking Wheels....  was here 2017 ayeaivtmoxvhfalvfnzvavfvemeiyzpvekkoovjbzfmdgsxg
 * Smoking Wheels....  was here 2017 wtqdmajslqvtirfaryfcxqoedambksqhzyvuhfvkkdgctpdz
 * Smoking Wheels....  was here 2017 xpqkitilwpgszgoyosvmvotwzshxwnvztgwjonudiivayajr
 * Smoking Wheels....  was here 2017 vgwejxrqdtlrirctvtwrlrbcjqdqsqcfqptijcxvrdaamlvw
 * Smoking Wheels....  was here 2017 psjdimtnwdckufvutjooxgbjbgajpoprenztbmxcmgzjgowm
 * Smoking Wheels....  was here 2017 lgjehvbpxgazygxqtbljjznkfeyhkxwdbugbdmwzcmbqkhgp
 * Smoking Wheels....  was here 2017 vkinnnmphqkstntdnpflloofcgiaiqmtgjqzkfdtdbxojxwp
 * Smoking Wheels....  was here 2017 lxaonkzmlfocjyalbzxmxelzjqvitzkwzoikvafvkijftuwa
 * Smoking Wheels....  was here 2017 gumycnymwdczettxomtltbtgvtggikvcrvvlskzyaxpxnrut
 * Smoking Wheels....  was here 2017 nhwphfxcmuyivjabnpflgvhrpftbxpfgbzxqpglchrxdtmfy
 * Smoking Wheels....  was here 2017 rxusibrbhuengniwqccxyidhzwsjtlfmdbnngpxnwvztxkcx
 * Smoking Wheels....  was here 2017 llwruxiisbeaodiiwzjnponipxsxdftdbfzcsuyrnsrtpyrg
 * Smoking Wheels....  was here 2017 uxffktcdirpsflyxlogfhycggsrtvjbvjbsngjjijyblttiv
 * Smoking Wheels....  was here 2017 xnaefzqzxbgnuvkcuhhcgzqtbwsdrnnksimejfgltloknvut
 * Smoking Wheels....  was here 2017 hwttodspqwiwfbcwrzeqznfxjidsusvycaiuxjwghjujhixj
 * Smoking Wheels....  was here 2017 ppfiwckxtyderbsfaoyniqbvtfqercxwsklfvduetaqksryi
 * Smoking Wheels....  was here 2017 wvjrzwzfymiioafockwphrvcawbpwczrazjqkdwbhdevsqik
 * Smoking Wheels....  was here 2017 humpwvazzutinjtmhyjcdehkiznhjmlitnungdcufoudldst
 * Smoking Wheels....  was here 2017 iyaixnixzpomlwtwjygkjzntzjjthdawwbumbhuqdkddhiat
 * Smoking Wheels....  was here 2017 rdtgnuzahsdimkyuhllfvduhoghvaipspunlwwobwcaxxslz
 * Smoking Wheels....  was here 2017 iirborgmnhbqbfgqgshkmaspyzcoglkjkiopzkdvngqseamg
 * Smoking Wheels....  was here 2017 mtarzntwltfnvsuytgfeqdbjeeyevevuziojyvrwltichcst
 * Smoking Wheels....  was here 2017 pzhgdxgverseqqcrmuzxvjwoptehynpahwqjmdklesrwqgdu
 * Smoking Wheels....  was here 2017 ktgfnrvjcayfsyuvjjpivumlvvkrarplofyoqrxbpppawwyz
 * Smoking Wheels....  was here 2017 wcwexwtstwnkkuvvshiiqrlmsvojqbargvzdsaakvzfxwqne
 * Smoking Wheels....  was here 2017 fgkdhvqiaqitkqjhxzpboqpjiisqtkjncnoleztldtxbvopl
 * Smoking Wheels....  was here 2017 wsigacgayylqoewzsgfydnzezfgbnqgdagqfxqmmebffcubf
 * Smoking Wheels....  was here 2017 oglxporrxrhockzcbcdrciwahruliypvhilivirysidmjudb
 * Smoking Wheels....  was here 2017 hysttffplzmhjmryfvrdnlvmdcfuvurhigmzhqfnycrdoggv
 * Smoking Wheels....  was here 2017 fyjtomkflgwxawdeoxgnqltfnbqkywuhwunouidhcjgstebq
 * Smoking Wheels....  was here 2017 vvxbhvbhacorzgupwbqfadogwnkvudtywyntcoslvenalrnv
 * Smoking Wheels....  was here 2017 wjccmdhtlkzdkphickwykorusoewuukqoytmgpokzzhbfhvz
 * Smoking Wheels....  was here 2017 goynwnixijrcrbptmccovcpixpuophzzjjsxnamzpktezqka
 * Smoking Wheels....  was here 2017 gqrgnfufnhpqmexklsyhphepogkfcixvbyellrmdbhfwxtxa
 * Smoking Wheels....  was here 2017 hetmsvlidwuzqopfsaanfylozkjimwwgorbtvqxbyvizjthh
 * Smoking Wheels....  was here 2017 bwzoyfkimzsskelhgzlxlesmufhscbupcvruqfihcjynbctn
 * Smoking Wheels....  was here 2017 ptigalxkdtxpchhxhxkkjinvvablqkvodxnrezompoetwosm
 * Smoking Wheels....  was here 2017 bcbkyuobzogslhjtggjeexshdouuzolwkshvztpsuhlhyzvj
 * Smoking Wheels....  was here 2017 ykqeaxezcbxihwcqyvdpmtixdpwhinitvfazuqvdgsiwrrcl
 * Smoking Wheels....  was here 2017 ylvbtnueudfzvzerfqrjazrwijxtalkmrryzsxtgvftoszqj
 * Smoking Wheels....  was here 2017 afqryuswrxvnkwngjxgkvxhrpftetuwrjqozyefvqktqarxz
 * Smoking Wheels....  was here 2017 kahxpzmnoupxsyixvejwebbbbtoxjhdfqvpmbhguzdtqrsqk
 * Smoking Wheels....  was here 2017 oihzzsyxpkqmryaoigsephyzaxsmcwxflhccugejmqjkcfrz
 * Smoking Wheels....  was here 2017 fxkhquezbqiukthhubizwrirbutrhsczahhufmocygmyysgi
 * Smoking Wheels....  was here 2017 hupnjhkzppgphpbmmxmgaosqavqnqhxevhqrplermpendvuh
 * Smoking Wheels....  was here 2017 aecoenhkasjybynrwipchmypapljzhtpocxelbdclpwtupay
 * Smoking Wheels....  was here 2017 xrmpicoxkqsenmcupamzhhcnjaoroqikerczoisokidjjdus
 * Smoking Wheels....  was here 2017 qzkbjuiodfsuxemxsbdosblrsgphrpoxxjlzyqmpfgwllzjd
 * Smoking Wheels....  was here 2017 dcypbsvotoypofqjjrttqcnmuqlgboqtgpmkxmfwxzfgztcc
 */
package net.yacy.http;
import java.io.IOException;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.crawler.data.Cache;
import net.yacy.crawler.retrieval.Response;
import net.yacy.http.servlets.YaCyDefaultServlet;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Request;
/**
* jetty http handler serves pages from cache if available and valid
*/
public class ProxyCacheHandler extends AbstractRemoteHandler implements Handler {
private void handleRequestFromCache(@SuppressWarnings("unused") HttpServletRequest request, HttpServletResponse response, ResponseHeader cachedResponseHeader, byte[] content) throws IOException {
for (Entry<String, String> entry : cachedResponseHeader.entrySet()) {
response.addHeader(entry.getKey(), entry.getValue());
}
response.setStatus(HttpServletResponse.SC_NON_AUTHORITATIVE_INFORMATION);
response.getOutputStream().write(content);
}
@Override
public void handleRemote(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        if (request.getMethod().equals("GET")) {
String queryString = request.getQueryString() != null ? "?" + request.getQueryString() : "";
DigestURL url = new DigestURL(request.getRequestURL().toString() + queryString);
ResponseHeader cachedResponseHeader = Cache.getResponseHeader(url.hash());
if (cachedResponseHeader != null) {
RequestHeader proxyHeaders = ProxyHandler.convertHeaderFromJetty(request);
final net.yacy.crawler.retrieval.Request yacyRequest = new net.yacy.crawler.retrieval.Request(
null,
url,
proxyHeaders.referer() == null ? null : new DigestURL(proxyHeaders.referer().toNormalform(true)).hash(),
"",
cachedResponseHeader.lastModified(),
sb.crawler.defaultProxyProfile.handle(),
0,
sb.crawler.defaultProxyProfile.timezoneOffset());
final Response cachedResponse = new Response(
yacyRequest,
proxyHeaders,
cachedResponseHeader,
sb.crawler.defaultProxyProfile,
false,
null);
byte[] cacheContent = Cache.getContent(url.hash());
if (cacheContent != null && cachedResponse.isFreshForProxy()) {
handleRequestFromCache(request, response, cachedResponseHeader, cacheContent);
baseRequest.setHandled(true);
}
}
}
}
}
