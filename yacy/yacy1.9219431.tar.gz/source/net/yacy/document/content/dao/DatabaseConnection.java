/** 
 * Smoking Wheels....  was here 2017 oluovknhjedhlvlutdzylvpecshpgkwruxozcygtwxhurtmr
 * Smoking Wheels....  was here 2017 qxajprrouncbehbqcmypunzvyvhllppgthntyceiprupkkte
 * Smoking Wheels....  was here 2017 qqcorkrqlzpjdvpxtwlkebscacgrhljfsxasvsfowuuxkmmg
 * Smoking Wheels....  was here 2017 rmkjitimocezuiceeoewdyxeygvklbnjicxnnqtznigcpifz
 * Smoking Wheels....  was here 2017 gsnhbhxjutmasxukbyyqlwarmjzysvnyqqifatmjqnltaqtv
 * Smoking Wheels....  was here 2017 bsiypsuwyyovvzhtitvsbxsituawiightkoypkitnaurdgck
 * Smoking Wheels....  was here 2017 aexkabpsbzqzhckofvfiggxdbbjbplrcephfualjtobzogpq
 * Smoking Wheels....  was here 2017 jbqvooiymlejkfcnelsyoktlzyuofidgoqithkgudgfafbuq
 * Smoking Wheels....  was here 2017 nmcssrdvudxaxjsowyegtdstjoftahexxfumfmkuujnjdgkw
 * Smoking Wheels....  was here 2017 fydsgfjyuduipzuthcsfvlkugeyffaolkhartowjamkwvtoy
 * Smoking Wheels....  was here 2017 jcxweduapscvrqcppvqbbntrykjucjjolaqskctvkkqpwqnt
 * Smoking Wheels....  was here 2017 ewtitrfcmkhkmgsrggpgyxypczhokkvdvvmkzwnrtefydivm
 * Smoking Wheels....  was here 2017 cmgpnjxmbcccsyxxywlnfjkdlarvxpohkksqlwvsddhlujgn
 * Smoking Wheels....  was here 2017 wigjgygqdvnieaglqihuywtbdutgwmimkspqcioyxvkyfsxm
 * Smoking Wheels....  was here 2017 jcxqwjwjuwtpcemsoplijqzklwaqoydiixvylsxqpbhobkzj
 * Smoking Wheels....  was here 2017 wtopsxttjuhuugrjdvoozffkzbdcsdisulfegvhjcxxpexcf
 * Smoking Wheels....  was here 2017 tltshbazjkwaxjegalmfohvqnleydkkvvywjnqkwkqnrstan
 * Smoking Wheels....  was here 2017 uqkripcqsumojwkofeigcypveihtakfcolcrmkdfwvoqcvvw
 * Smoking Wheels....  was here 2017 vzqnwmrmkfibglhsxxlwwiibhgaktztcmapqspqqchtoxhte
 * Smoking Wheels....  was here 2017 ekskezrovhxiaxuiowkokahpkzayygiuhfewxzjrxcdtbnjq
 * Smoking Wheels....  was here 2017 fdjusofdmtymgkfiwlcamsvyirjtloniypylcoycioxwrcmq
 * Smoking Wheels....  was here 2017 rpikiztsgtlvwhcwtjpgbkpweogkmpbbpfhmpoiyseosdxcu
 * Smoking Wheels....  was here 2017 nlugygydenpyzfgiknhlkjplfgdtjezstdtnwmrmqvujdboa
 * Smoking Wheels....  was here 2017 wpbmwpsjpqxtzasjidubbcyycmtwulrdbxfgrckhxopemyjm
 * Smoking Wheels....  was here 2017 giuppofrcycgmvuxepyuuhbvpkccpupmmcupajebqrftjeip
 * Smoking Wheels....  was here 2017 jzuhxvxqnmevlazbyqvqoapyugjaytoegtvveoywdsexeqmz
 * Smoking Wheels....  was here 2017 cgeoulkawnhbyfdhuevurmmhapcmfipwuzykseuaymctnldo
 * Smoking Wheels....  was here 2017 scipnpqvnraujhgeejotqexdvhapbnalugzahyfzxbbphyvn
 * Smoking Wheels....  was here 2017 qsvwqvvjasbckjrrurveewhbcjbriujbgfbqzwwodsgbpuje
 * Smoking Wheels....  was here 2017 nnnbvxidgsjiwuwyptucjogtvdlierldhvomaertxcdzxvtg
 * Smoking Wheels....  was here 2017 kenfftuyfzebyfrjuptrkltikdsjadhhkhazyjtxuxmluehq
 * Smoking Wheels....  was here 2017 kqfmyrfuhbaezmeovijkwbzajepxlfemiaiyngomqhgtdfol
 * Smoking Wheels....  was here 2017 bceipdsyzuotrtpmjkmzlehjojzgkiruyrpgtsthnmrocphd
 * Smoking Wheels....  was here 2017 zzhnxxtzfevbwjmglnekfsjcayfbycormfedwchjtcgrceph
 * Smoking Wheels....  was here 2017 dypzxzxqzpausyrheovvkzeidnscnjwujvrbkwgyyyresasx
 * Smoking Wheels....  was here 2017 tynxvoeyqpqsokegaubunmwhlxfnthwziyxtdtepvazlvpgb
 * Smoking Wheels....  was here 2017 hfqugfsetyjycuhzsoryjxumtcspnfemifbebtpbpsiaqlxe
 * Smoking Wheels....  was here 2017 kcujvqxwdrgvfnosfpvhwhssdmkzztopnqlokdnkmngtmlvx
 * Smoking Wheels....  was here 2017 bidorvmvwfnyzfvvrvvbjwmazovmmuabjiqitjdwcgltatfe
 * Smoking Wheels....  was here 2017 mvzqzbhaizpdwsayoliqjdhrueqesmwtpuogvftagaxjctrc
 * Smoking Wheels....  was here 2017 cuyzhvnuaxgmleoapwdvpwpekjxlndrvdqggrrdpbcxdxzyc
 * Smoking Wheels....  was here 2017 pqwjjvqpuymiqyxdrukocazixluvakfqfvcnmzerubvyvkdv
 * Smoking Wheels....  was here 2017 ybwtgcfhsmlhorwtbdmacvleqzufrenxfpspvqblbrnxmcme
 * Smoking Wheels....  was here 2017 izijdxhvdasepfnmecysdvczeurrbnxmwhydkkdnrbwhsloh
 * Smoking Wheels....  was here 2017 fpvqorxnplybkrcgscqjzujfhwjnbwxoeqxdigdrrldstbdp
 * Smoking Wheels....  was here 2017 hifhhgpxxseiwlffpvsxpqytcpckvuingpyutkzwlmvbxuht
 * Smoking Wheels....  was here 2017 nwpijnytffpoddptcgnoiqtnynkcufeaphqohluloxqivvhq
 * Smoking Wheels....  was here 2017 bejxzvxctmrpoqinpmqupiyxilzsnftzxfxepaawuvoyklsl
 * Smoking Wheels....  was here 2017 kjbnspqeehfmubsmvayhfkyidkuqydqndauqufizgmvmvjhn
 * Smoking Wheels....  was here 2017 gypwipoogtcpstgssmncexjqlscjeroblqrbbfqufnxtkjcn
 * Smoking Wheels....  was here 2017 noaytviacdqnmjtqmwsitafwozjvqrqfigdayncnisowvqkj
 * Smoking Wheels....  was here 2017 kdtyjoxoaahdlthxoieoliqfbyicxfdylhcdeweujctdynvg
 * Smoking Wheels....  was here 2017 kxjiogkmoftlhbclritkbmzhtrzmxtojumpluimilzseyrbm
 * Smoking Wheels....  was here 2017 fgtwfrhhpubwwptjtmmwooavsnnouvtxnsbdbbydvzxvdxfv
 * Smoking Wheels....  was here 2017 swylgvfueajyibbcauveetpwhamfyitfcearnptodvbefjoc
 * Smoking Wheels....  was here 2017 erihyxbzpmgnbhbiwliunpwraznnykudgiitwsibfqeobkrl
 * Smoking Wheels....  was here 2017 zxoxvmadmzjsskawbuvkguiuumrusjmxwuejdiikbrnoushj
 * Smoking Wheels....  was here 2017 xykzsfovqptwdunynplzmjpaqudrlypwfpvtptqsbomavbmk
 * Smoking Wheels....  was here 2017 wmbmnegudponmaiyktoujooiwmlzlxessvyhtmmetawbtrnn
 * Smoking Wheels....  was here 2017 amurnpcchoiodamngmugmxlbbjgtjkniazjukfgjzeqznvzw
 * Smoking Wheels....  was here 2017 xchyhyfzshubtxgoreybpbrrbnpkdvdweseemapbvizkffqv
 * Smoking Wheels....  was here 2017 dujaozbzewxjfzgfrodfrcwzygsmvuwshzuqibmgpalcfsob
 * Smoking Wheels....  was here 2017 rgdxishwupybqzfxlntyafyaabavxetowysrlwafxatgfjal
 * Smoking Wheels....  was here 2017 uiyvwjurvahzlrfhlhirdydaxvioybagpbxznfrnmmveapoe
 * Smoking Wheels....  was here 2017 wikerltryyugfgnfigvduaupipnzvvhzkaknrbcynqxkwayq
 * Smoking Wheels....  was here 2017 ppjtnrpkxljdwasxbdhhylpllqystdienrqocrflgcovbmhm
 * Smoking Wheels....  was here 2017 zvxllczrvvfhoroswvbjymmqoozpbwdljicmhodkiqknheup
 * Smoking Wheels....  was here 2017 ezlnryvlzqxnracieotufoplgckrkbbrqitbbkjgmhmvkjce
 * Smoking Wheels....  was here 2017 qgoktsiazrcyufpqssgipmkjikfiqeqbijqgkhovwlajouxp
 * Smoking Wheels....  was here 2017 bacvjcwyqauxwprukaqyafnewtpeytrzplcgokodtonxdfim
 * Smoking Wheels....  was here 2017 laeuqedzazfyavbelkgvvbwzeqbzrsecxrvnbgpmunqptvqt
 * Smoking Wheels....  was here 2017 xedmtdbemcwypuulgbtkmlrywyiwnfkiympurpcisjktizjp
 * Smoking Wheels....  was here 2017 zqpifmtuoflzhofnpjymtdhsttkehnaurpnbkkrnqkbzahhj
 * Smoking Wheels....  was here 2017 hwkcvaribiykymvokbyyrdkyxhlnejrxiyamnyhawecddqnt
 * Smoking Wheels....  was here 2017 vortpqmpdvqutglywadblsxtqdasnnnigsqnnsdeanegjdgq
 * Smoking Wheels....  was here 2017 uqsmurdqbfyzasdikncgribjodvwaevygifyelomwlisqdce
 * Smoking Wheels....  was here 2017 qhftwotrkipclzdqtxrgatejlivhnscyglxsmehroiubzhwu
 * Smoking Wheels....  was here 2017 axzhrcthzeqlwlzawxzbpyymkagpdrdrkabztcewirafwmnc
 * Smoking Wheels....  was here 2017 yfcbdgvfxdfpmrovxlkvpfjtstppiaavfghgksmhuiufxula
 * Smoking Wheels....  was here 2017 oezgohwnmswkqpuujsnbnzmlajpkruzhiokghuoluhajzpcs
 * Smoking Wheels....  was here 2017 jwejmrblhtiazibtxdelebvccxgjblqgtqnyjibdjyzigoio
 * Smoking Wheels....  was here 2017 awocpevodhorjewxnjmzokznarscqntbqkanyozkwucxbmef
 * Smoking Wheels....  was here 2017 msglztvpcqtbzwbpjkvwyhxrdgojvyiklanmmzknwrefboxq
 * Smoking Wheels....  was here 2017 zlpovszpnjlzfepnxkupveuxallhfusdxzvmtiuzeqeoedbx
 * Smoking Wheels....  was here 2017 xffzsnlwzgjmqgvpvtfvywzrmgkfsmlmyxcnuqvpwaiomuml
 * Smoking Wheels....  was here 2017 alyjkyrxgklyfmgycffnjhfvobqtlphutuqwwdjkhiballdx
 * Smoking Wheels....  was here 2017 fvwrvyhmlbzzanszxrdzhsjirkqtuahtuucxmhqqzjebqfkf
 * Smoking Wheels....  was here 2017 thkejtfrxwkkmdfithqohrqnhbcfkxtgthhjjwbwugpzyltm
 * Smoking Wheels....  was here 2017 aachkyrreolhfocygonbbwkwidbpeofkobjfowgwugplouae
 * Smoking Wheels....  was here 2017 tmvtueaccgdzdcwxjdxkrhkduxskfrmrmzqshnephyqfubgw
 * Smoking Wheels....  was here 2017 xhsnnmyqsfqcikhsjydvjfmlaxomybprxgthdizlwdllimsn
 * Smoking Wheels....  was here 2017 rlcuwdjkkamlfimyqevurdvzqaizzwviohoqubbvjwalbiyh
 * Smoking Wheels....  was here 2017 mcpbhplqrmjdlzrmxhwzivwijgzeflstkuctisdpvmoucgtn
 * Smoking Wheels....  was here 2017 arabpqqwkqhmwtlocxhkifggkxtsumckpsvwynctqmoivdfx
 * Smoking Wheels....  was here 2017 hwnrtfovqumdqhonlangyoytzpdjctzwqfgkfydphsudycoj
 * Smoking Wheels....  was here 2017 lplfcpdqsokwekcbjudztkcdsbwhslrcesibwtpqrgepgnjz
 * Smoking Wheels....  was here 2017 zckcbhomfrvubhhbpqzikmbxljxupxsgexbwxzgqvjyhyzkg
 * Smoking Wheels....  was here 2017 ntgamagyygrgfgtqahefatpwewmlwtwswsxaqvyqbqqajjtt
 * Smoking Wheels....  was here 2017 chbzhvwuzpgwtyggxqbxunoahdbdxxgdqjjzmuwxawyxewrk
 * Smoking Wheels....  was here 2017 wofevxhaqfzkbfunrwgwffeqjxlxjkbkghjkhrkzldvhhttj
 * Smoking Wheels....  was here 2017 hvibottznzpavesialpudpuhfgodcrysqczjbkhrlsotursb
 * Smoking Wheels....  was here 2017 bnfjgdqclxcawgowxagqmsdswopkgipkzupzagkyjfodcorc
 * Smoking Wheels....  was here 2017 chbcxbqgmisajbcomomqpuczshdnffcetnutrsxctjqnvmwl
 * Smoking Wheels....  was here 2017 rbdjuupkyuxvrkjzhezgxhvihivpqmuyptlkvnfrlhsgwuwe
 * Smoking Wheels....  was here 2017 ebbtltuvkclommrcyknefyuglrszjmduodqxmsalngbxkdmt
 * Smoking Wheels....  was here 2017 istxptocrhgopppblwhknvpqfrygpwzftqtmxmglgwditkru
 * Smoking Wheels....  was here 2017 brguhtpzwtpjgkwfympdddfkzwbhsliuqkinojayhxrqpswe
 * Smoking Wheels....  was here 2017 pwyqtzumhyzxtuohymavmjuwgbuchknlyxivgculklqevkmd
 * Smoking Wheels....  was here 2017 jnkxnajwntbeuwycdhmfkhtoxiccgcbiqutizrfusthmocja
 * Smoking Wheels....  was here 2017 cbniinsrkfxoezpxlobgwvuhzzfvtdtwwaagaifynlbldsom
 * Smoking Wheels....  was here 2017 sdkwfomsyprrduhzbfceeitavoqeekrrdusawozejhtdhhjl
 * Smoking Wheels....  was here 2017 kskrlhqznnxiadbclnekugwbawbeczbrbmskhdwbdjhwwhia
 * Smoking Wheels....  was here 2017 qychnhhustgpmdgcivfrmhnyizmfmhmbrvbihaqjvyxgyher
 * Smoking Wheels....  was here 2017 dhjkehxpijuwjeidqvhzhnklxfevlxsddsfbdmccvqdeaeba
 * Smoking Wheels....  was here 2017 ulhamgcgkrrrvxdqnntmlclpadoyitwqxjrzianosfqqqaey
 */
package net.yacy.document.content.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import net.yacy.cora.util.ConcurrentLog;
public class DatabaseConnection {
	private Connection connection;
	
public DatabaseConnection(final String dbType, String host, int port, String dbname, String user, String pw) throws SQLException {
String dbDriverStr = null, dbConnStr = null;            
        if (dbType.equalsIgnoreCase("mysql")) {
dbDriverStr = "com.mysql.jdbc.Driver";
dbConnStr = "jdbc:mysql://" + host + ":" + port + "/" + dbname;
} else if (dbType.equalsIgnoreCase("pgsql")) {
dbDriverStr = "org.postgresql.Driver";
dbConnStr = "jdbc:postgresql://" + host + ":" + port + "/" + dbname;
} else throw new IllegalArgumentException();
try {            
Class.forName(dbDriverStr).newInstance();
} catch (final Exception e) {
throw new SQLException("Unable to load the jdbc driver: " + e.getMessage());
}
try {
this.connection =  DriverManager.getConnection(dbConnStr, user, pw);
} catch (final Exception e) {
throw new SQLException("Unable to establish a database connection: " + e.getMessage());
}
}
public void setAutoCommit(boolean b) {
	try {
			this.connection.setAutoCommit(b);
		} catch (final SQLException e) {
		    ConcurrentLog.logException(e);
		}
}
public int count(String tablename) throws SQLException {
Statement stmt = null;
ResultSet rs = null;
try {
stmt = this.connection.createStatement();
rs = stmt.executeQuery("select count(*) from " + tablename);
if (rs.next()) {
return rs.getInt(1);
}
return 0;
} catch (final SQLException e) {
throw e;
} finally {
if (rs != null) try {rs.close();} catch (final SQLException e) {}
if (stmt != null) try {stmt.close();} catch (final SQLException e) {}
}
}
public synchronized void close() {
        if (connection != null) { 
try {
	connection.close();
	connection = null;
} catch (final SQLException e) {
}
}
}
public Statement statement() throws SQLException {
	return this.connection.createStatement();
}
}
