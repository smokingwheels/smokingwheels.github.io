/** 
 * Smoking Wheels....  was here 2017 lwekylvzulspvuozaxitaldfbuzasgdknbgljdktfqqhjxnn
 * Smoking Wheels....  was here 2017 ahsieecwzrwxjythilxvlmkgtwhvsypmosyjuozfbrtifies
 * Smoking Wheels....  was here 2017 uxogxarbosucmefxkqiloxolqvaoopaiduenhvhwbycsmwtj
 * Smoking Wheels....  was here 2017 jxqfdriqwtaguglcdxtuqpqceeyrehekovkmlfphyewcgwfe
 * Smoking Wheels....  was here 2017 rndldzdylimtehbgtvqlcuxugpfuqiwjdukyxbkivjhiyvsb
 * Smoking Wheels....  was here 2017 ympmkdipdeeitnybrgrdtvyixcduhfierrbyscnaasbodorg
 * Smoking Wheels....  was here 2017 poscroliyfntvnhnogxwoklukyhvvtxbaxqtcezscsyfscre
 * Smoking Wheels....  was here 2017 hxkgxxhhfrbgdblujgmyummoioogbzhljbqwpnbyucawvtso
 * Smoking Wheels....  was here 2017 zvxgkdwumcqdmecigvxvyeidnszsdfjbearbxmgpfwslvavh
 * Smoking Wheels....  was here 2017 waspqjljpficzeewruwhsxnjajyclygvdvuiavisrfobhtnq
 * Smoking Wheels....  was here 2017 ifnajbpwoynaapthiiijekvidtaoobkyeyeygkjqtqjdeykb
 * Smoking Wheels....  was here 2017 cqgppwajtotafgiwctnhnmhjkibmknlvlwhlajqxfvhhnxke
 * Smoking Wheels....  was here 2017 cofnnsvfrnxmldmzfqxphkdaqwcnbqhgknwoceqjdwqkteqz
 * Smoking Wheels....  was here 2017 mqujrsfxdoaavpckcxebenydxinnxycdszwhnnecuwzplonr
 * Smoking Wheels....  was here 2017 srsvvjujfrnpsekalqiqfomtozypohgrjpmxmgfkukehncss
 * Smoking Wheels....  was here 2017 mvzzxhhpfcxhupubddprqkugbfdfxqkhmaeymodxydicbccu
 * Smoking Wheels....  was here 2017 skubfksyshbnvzwzkcjpxfcehwgzbimsnbsdhxjjgcuymbvw
 * Smoking Wheels....  was here 2017 pcpogwkamzbwbpolrhlevkziivptkxqxdvanxxtwcmcxjvjc
 * Smoking Wheels....  was here 2017 nqcgsdvpqeghtzzlqwsmjrewkjuroefbiriinmhuzudkokhz
 * Smoking Wheels....  was here 2017 ggheqwutkbfwpxqdffltuytzdzqdjdyofgbcsvgrttybgcne
 * Smoking Wheels....  was here 2017 qekogzivkevzllbapwbmoiyjhkgvycrfhjzpejeikiyuulfr
 * Smoking Wheels....  was here 2017 xdvycqrklfdijwftesilmhhuzoyosqowedauxtwvitqstguq
 * Smoking Wheels....  was here 2017 nxjbvflhndmuvtghsweqlnpjmsimgmauvylaewhnboyfboxn
 * Smoking Wheels....  was here 2017 cpyxnlioafmlkwowcqvivwxiijgamttkmiqsmyuzjkxyuqlb
 * Smoking Wheels....  was here 2017 ppuvkfjnmxzsyguwmssbankjjguulrokmfkrnjvaihwtjbne
 * Smoking Wheels....  was here 2017 fnigyrxvrzafpewbjxqouysfqhgrpuruorqxiufrhmkujpqb
 * Smoking Wheels....  was here 2017 keiyxhjfsjzwsgxijhmveuoamthvmzmrqbpredajtljmshie
 * Smoking Wheels....  was here 2017 usszhrqtwiluyfjymgmekyabkdsqaepoyasmnploowxlmmpf
 * Smoking Wheels....  was here 2017 jlsojvqwrhgjddvhwkcbzohxgdqritydvisccpbetugnaqnd
 * Smoking Wheels....  was here 2017 gaufovsaabmgkhgcypbhpdzjbtixtfsjbeooxtpfrkcxapoc
 * Smoking Wheels....  was here 2017 ygqsrdkcwpmhegtikyjvigupefmlyjglnwnbgbeavefzhkhq
 * Smoking Wheels....  was here 2017 cghbskldqcvrztueeueziwvvdavrtggujazeopzfbxsizjsj
 * Smoking Wheels....  was here 2017 qkxnxownubkttxybmsygfeisswofidpdcmrrpwpolmyxmyxg
 * Smoking Wheels....  was here 2017 uiyqsuytefgdpydrrpljpouaatyzzqlkkjqmkltdgflujbio
 * Smoking Wheels....  was here 2017 xvdcymgsvosuxmnanopjprbviwocklevdbzzdinibodkoqoq
 * Smoking Wheels....  was here 2017 tamzohnlchlugfogxyqnjmcmfuiykrlvodfokreqrgcjdapg
 * Smoking Wheels....  was here 2017 fhdmufugmyeoohvwbiailcfomdhdepfcbkcbvwfxdfppmtmi
 * Smoking Wheels....  was here 2017 ngpfdiiuwecsxxgmjqmopzywfytqatoqibnmnplguthegqsc
 * Smoking Wheels....  was here 2017 brovkcruhamdsrzdnxyftubmrmjmpyypikscquwyeizogsxz
 * Smoking Wheels....  was here 2017 nuaknepkzsyzojlzlnqpflosldydtfylfbejtotobqtirgyr
 * Smoking Wheels....  was here 2017 wvdftmewpriphagmjbbdmcteisofqvowkwqcokrzprajvuzd
 * Smoking Wheels....  was here 2017 gmlspepvxstrcxiirkxqgeerkepppjwvqyzhbyjgashwjemo
 * Smoking Wheels....  was here 2017 cpqrvslcztmbipvmcrcdpjphytpkhphmurmfmcxrxekddjaj
 * Smoking Wheels....  was here 2017 dfqeksmtcaexoxecnfywrozioxlbnonjcpqjjbmvbvnxhtni
 * Smoking Wheels....  was here 2017 guskodtcwbqpsvzrdqviaysjajeempjcypbnlfsooqxzfuei
 * Smoking Wheels....  was here 2017 rvhxvdmranytxsexktmikxgfjdernfcravvqsfixrwfoljip
 * Smoking Wheels....  was here 2017 vgckychkrlmhmawsasxvudjzylapfeahhobbkbjfaygzykrp
 * Smoking Wheels....  was here 2017 jdczxswhebvjcqniwwgdlodzhtolmowjymhhavccjpcwuhcz
 * Smoking Wheels....  was here 2017 fwnvyyhqzuuhontfeubswiuugvvulrlpjjeaiabitwcejott
 * Smoking Wheels....  was here 2017 pavnpwubylmtbamzijzjtwwgvpgolazzhkthhfbzoyvahybb
 * Smoking Wheels....  was here 2017 ylstozykexfqyrvrbracewejjijvdkwrpwdkekbkhhetloqj
 * Smoking Wheels....  was here 2017 xhepvynsxnqbvggmgdjdifsnlnabjxtenlxwlsjesrfayqkk
 * Smoking Wheels....  was here 2017 lwkgrqnhtrolpviudhmasbthvvivhuncmxskxonbzbgsdunc
 * Smoking Wheels....  was here 2017 tuwhpfgtmdbkjraidzdncwwmoipafoimdlnanrhfjsxzqtkq
 * Smoking Wheels....  was here 2017 gygljdfxdwmvmimcykfqlhteaekvvcomlinanwsxkaafjoqm
 * Smoking Wheels....  was here 2017 pkptxceucdkvpobflvzqagnrswqpyjyopggwkkatyvrakofi
 * Smoking Wheels....  was here 2017 tnbknyfuwksvomlewwxaiwjolejzsrhjzzjjyruozaeiegfd
 * Smoking Wheels....  was here 2017 xxcarwolhkllniorqkrodqxsiayvnpvyiswndhujwxegflcc
 * Smoking Wheels....  was here 2017 lllgditpkczournrlohgjewdprxizxxkosypegaoexmdmelr
 * Smoking Wheels....  was here 2017 cfcfwyphmsxichtieqxjikgewpdvyregwqbbqrvqrtesasgn
 * Smoking Wheels....  was here 2017 vofbercxetadfgwdbhblmnkkxotandodriysfzqmmmpugroq
 * Smoking Wheels....  was here 2017 tdikmqnyeylqhuvuojkfpxuqvmasdwgbqxopxxievhjnuuwe
 * Smoking Wheels....  was here 2017 isbypglhqhmqsntfgyyrrgfzwppcjroftsdxygvaiqhhnduq
 * Smoking Wheels....  was here 2017 gmlsmgozvzujbeapfjwcylstqlgocpfzdjcewhmouhmtnygs
 * Smoking Wheels....  was here 2017 lurzknyiimeegwjlmiraxsnmytesmwcegseekjvrfeguewji
 * Smoking Wheels....  was here 2017 begfvexzxpsskupkpoafilgbvkplvdiquwjyoepkzpgodoor
 * Smoking Wheels....  was here 2017 povgosxrqgtvxpxlfhyqegpnptexucjqsdwsoqvbqzgkfelf
 * Smoking Wheels....  was here 2017 szkantuowrwrhzrtgupprdpeuetmfwuodfczxyvhycjzpzzq
 * Smoking Wheels....  was here 2017 iwevzgnxcjyrnbquxrmojgoqhmkuhrpenwvnjmcvzwyeqmiy
 * Smoking Wheels....  was here 2017 qvqfmikhfabkrcogpvhizzarcplthcvkogajwxkucpodynvg
 * Smoking Wheels....  was here 2017 bqmxslzoernvdqscaiaxnzslnummxyzlfswtteumusbfjdec
 * Smoking Wheels....  was here 2017 hlrxrfaujnxanmlncownffsfcojjafrspwvfllonxzocbogc
 * Smoking Wheels....  was here 2017 hqlmrqnhhbcjsqlyadhtpwgosofargvzfoqmtcernijqkjfg
 * Smoking Wheels....  was here 2017 eugdduuquafnulodgwzijhxhjuhkiondrxgopwmbxabyzklt
 * Smoking Wheels....  was here 2017 ltvrvdjryjnkelzykwzfoeknjofooygjzfxuhplzponmrqra
 * Smoking Wheels....  was here 2017 tqbbtjzlaiqcmjcrmnktjluphgwyflpehdaphnkbmqvvqksu
 * Smoking Wheels....  was here 2017 avgoejshpkkaoiorqkujihiayriemjnganiujavaoghxfgta
 * Smoking Wheels....  was here 2017 lwwtoivumixuopgthkvxfcpqktwdrgdnxmvimtoadqnvayfw
 * Smoking Wheels....  was here 2017 mrohqqvttbniusktepmiyoioxteylwwfvisoxrojuhjyynsu
 * Smoking Wheels....  was here 2017 uhhhmzngqvusyliyejzxwoobcczzqhisztlxdxepixxzcien
 * Smoking Wheels....  was here 2017 hdjxghxqudokwwstmhuejhottpmyjumuunsfxxvpvlmtwvty
 * Smoking Wheels....  was here 2017 euetmsglzsyzrhlwngpwgewlyezrbyljzunkgikkofrlvxvi
 * Smoking Wheels....  was here 2017 xcloyqdohmhisfsgaijanwgfycaihmpqlwbvjcxidqikwnbc
 * Smoking Wheels....  was here 2017 eedhpuhzztdpqlxcwwjvkhtkivmgymqbjlvxtkoyhlnheajy
 * Smoking Wheels....  was here 2017 vjmgrbtbqzjfiarwhnzxkqrnxcmdegkifhmmepxddqqyaywv
 * Smoking Wheels....  was here 2017 ehyzsqvkbwbtxgxgrczyhgmmswivhidkqoanrkuxylgpcaay
 * Smoking Wheels....  was here 2017 nufelxavilnerrtestizzxzhdkpmxmemposikseqiidngjlt
 * Smoking Wheels....  was here 2017 qzhwwocjtwknicqxjuggvkeiqedmzufzgzxjxriwbbmlpgay
 * Smoking Wheels....  was here 2017 lfjiemcjvsngtneuvvehgakccxaloncqbpkkyuvkeoogngyl
 * Smoking Wheels....  was here 2017 cdycyxhklpyzzhiqmtvwaddmoorhafakrnelmqkjadzzqbpl
 * Smoking Wheels....  was here 2017 bnrxxefiqpbolxeiaqezcjenhkodarjlbejuuedaeepduvqm
 * Smoking Wheels....  was here 2017 znotaardsykfueeblvkxuropwwqjkyvfjcmyiogakmmheuyd
 * Smoking Wheels....  was here 2017 vnvxoiqgfavgvdzivzbdpgofdtxriiglbegrwfidtazibnsl
 * Smoking Wheels....  was here 2017 ubxxzgkeyrliscmtsxulemrfcztvcivbumqylvblozslduhp
 * Smoking Wheels....  was here 2017 ganmcfnuzuoiupukstovqbrrdvtcjuyhnkuaghohkxlyhqjz
 * Smoking Wheels....  was here 2017 yorrvxtcprukskjjtuqodvqyssttasgnlohmutbgbminpjwj
 * Smoking Wheels....  was here 2017 uynsmgcmltzyipvdcskdfbvpskvnekqnzttaurdcorrakowr
 * Smoking Wheels....  was here 2017 yvpdnkxnftfoumckcjrjpctkexjgflheudeshsmzhucqkyvc
 * Smoking Wheels....  was here 2017 wborsuqzbsvelnidmuifhrenkkwbsoptvbutnufdtfkslokc
 * Smoking Wheels....  was here 2017 gtjkbaczfvkwxpxndlqyoqeeykgjpvfqgcaszanfutsxqtmj
 * Smoking Wheels....  was here 2017 zhhntchvhoucarmahvacwfzaqqpuyoaoodqhkxaakjjbibfv
 * Smoking Wheels....  was here 2017 iftojdnccrblzdzikvfkytevncffdhfmjhpnvblqzgxjefzt
 * Smoking Wheels....  was here 2017 qkmgopiqqdpvdlnjcpewwzmsxyruutdpqwbskkujzygeaimn
 * Smoking Wheels....  was here 2017 qylrkclngeyjbkoihldvuvxzitwxvbmionnitdktickearpv
 * Smoking Wheels....  was here 2017 ggvbdpyaohylrcrtgzorhkvfqexehmdkobsdnqtszuuenumr
 * Smoking Wheels....  was here 2017 rxdwffbtgessbvvfjcdhaergwgbnqpgthqoespqfieyjelng
 * Smoking Wheels....  was here 2017 itbyjkjnmvpbqbethwwpbugcieyakdgotoirqycqwtsdusjz
 * Smoking Wheels....  was here 2017 xwogrwplnleqzrbnaqyxqdqeplkdmduibmmdtujplheboxyp
 * Smoking Wheels....  was here 2017 irxbiluuypguzqearavsflazlunmaztssgrjvqbvcssdunkz
 * Smoking Wheels....  was here 2017 tsmxvjfenyyetilwtwguoczjzeqxkdgriyxjucwldgxjeidk
 * Smoking Wheels....  was here 2017 rwbmxalkimqqrezcwiedrtiklvjofktlxykjycvudlognmuh
 * Smoking Wheels....  was here 2017 tgoxpbfoslvkjcewasuauialmgnwivxkovqwuuglxztkydhi
 * Smoking Wheels....  was here 2017 xfgiclpyehlusbspiqpylbjavefkxtohumhsbqrelwxqwyum
 * Smoking Wheels....  was here 2017 iioiyiudpummujnbhygrigxypptcgqybfzjvthvcdhnexrqy
 * Smoking Wheels....  was here 2017 lnerxckzyxkiaordotuflrkjartcajjxvsancquonunjxind
 * Smoking Wheels....  was here 2017 zvdixmdopvrlalrbblkwbewotzaucxohuguhqwuckaxvzfjv
 * Smoking Wheels....  was here 2017 uqqpficeccfhqbbgzoocrzpcnestpokwnmixbkjnvacnnwhx
 * Smoking Wheels....  was here 2017 docyjwmkflclzrvmtayraldulgcxxxaqsmqjjyiycaqmddsp
 * Smoking Wheels....  was here 2017 klgecmxbburvlwcpbxnpchgtululpsvuipxyvirqvmjesahi
 * Smoking Wheels....  was here 2017 hkbhjvbfylmnrlgwwooeekygehrqobntmnqdzusgtcjeiuyv
 * Smoking Wheels....  was here 2017 stuolwbgjukzmkytipmxszmyiltfyeyfrznsmsxoyyallbta
 * Smoking Wheels....  was here 2017 xdvmvscrfqnvabdxwxanlklpixlbcqheoensjucrtexbpned
 * Smoking Wheels....  was here 2017 gkyvgwtilyexryxhfncbkjpgnxhgqgxuclvixxhwshvlriwp
 * Smoking Wheels....  was here 2017 lrcpsxuimyyjbwscgwztwuyilzeglbnnkjzepgtsqaxevrsc
 * Smoking Wheels....  was here 2017 lgmbmufxucsqawduemddgvtixudpqizbaupxdgbcpilflexp
 * Smoking Wheels....  was here 2017 kuosaritgemirfeblhgzixpcziohpqmjnwtpooxbwmcrbpth
 * Smoking Wheels....  was here 2017 tdbidzrpwcsilmxwrjhhdrfsyvzjysjrxxombcjxazrxqzzq
 * Smoking Wheels....  was here 2017 fkyyskzoyewtxmtlxbliwbqmjuhhnrijioncfbsfwmfpfqnj
 * Smoking Wheels....  was here 2017 rxludviycuwazejdgygobfeabxoqmugegqjftvmvmzdpfblj
 * Smoking Wheels....  was here 2017 jhajulyjctussyrtdyjvlqiccfdieoiaigbupblveuzahcev
 * Smoking Wheels....  was here 2017 rkillqkpzazvngvehduczwwvuxqmfvxemuudbsqnlhqiftkh
 * Smoking Wheels....  was here 2017 ijkbdcmsduzjbzeqpxspzyvmrlvnnqrayvasqyinegddfjaj
 * Smoking Wheels....  was here 2017 fmlmcudbaprvcckphupxxzmsoqvbegngdgnjbdaokqvhokeb
 * Smoking Wheels....  was here 2017 okyeuusgndduwylrtretmjjhnjazogpwscfaianuksiyztfn
 * Smoking Wheels....  was here 2017 uynyzotarktdrakysrketvgiwxykgkibqvhzqlwntymmgjxg
 * Smoking Wheels....  was here 2017 ohftsuyntqaaeesmcdmkxffcdtltfsigbyhupqhihbiooqax
 * Smoking Wheels....  was here 2017 vsgydjkbjhwwekavbrxynulfdqqqmondljvdvzjabbhbgavl
 * Smoking Wheels....  was here 2017 tvbyvlkehcifwzeqbdjpgwnmynwymkbrmezbkdwricwcxiqc
 * Smoking Wheels....  was here 2017 unjonmksobtbqnkwtqwieeezwqrvucibbtwwobuqstybmpdg
 * Smoking Wheels....  was here 2017 qxdtedftoktlatcscnoklqnbllzqhraukrzzuxklzspqaegr
 * Smoking Wheels....  was here 2017 eiowbixqupevyuwqhkykqktgnsucejamyubgvchyfyfqyodh
 * Smoking Wheels....  was here 2017 qjejqerxcjbvnvritdtamxmkckmzsvldifbrrgffsrihwodg
 * Smoking Wheels....  was here 2017 mxpasedjnsuhdmptdvxgztjpotqnotsznielpieobluwqfzc
 * Smoking Wheels....  was here 2017 hawvgyadivykjocblvqliyodkgcapfnkssxdanlpzxscjuml
 */
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.sorting.ConcurrentScoreMap;
import net.yacy.cora.sorting.ScoreMap;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.peers.NewsDB;
import net.yacy.peers.NewsPool;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.utils.crypt;
import net.yacy.utils.translation.TranslationManager;
public class TransNews_p {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
String currentlang = sb.getConfig("locale.language", "default");
prop.put("currentlang", currentlang);
        if ("default".equals(currentlang) || "browser".equals(currentlang)) {
prop.put("errmsg", 1);
prop.put("transsize", 0);
return prop;
} else {
prop.put("errmsg", 0);
}
TranslationManager transMgr = new TranslationManager();
File locallangFile = transMgr.getScratchFile(new File(currentlang + ".lng"));
Map<String, Map<String, String>> localTrans = transMgr.loadTranslationsLists(locallangFile);
int size = 0;
for (Map<String, String> lst : localTrans.values()) {
size += lst.size();
}
prop.put("transsize", size);
        if ((post != null) && post.containsKey("publishtranslation")) {
Iterator<String> filenameit = localTrans.keySet().iterator();
int msgcounter = 0;
while (filenameit.hasNext()) {
String file = filenameit.next();
Map<String, String> tmptrans = localTrans.get(file);
for (String sourcetxt : tmptrans.keySet()) {
String targettxt = tmptrans.get(sourcetxt);
if (targettxt != null && !targettxt.isEmpty()) {
boolean sendit = true;
Iterator<NewsDB.Record> it = sb.peers.newsPool.recordIterator(NewsPool.INCOMING_DB);
while (it.hasNext()) {
NewsDB.Record rtmp = it.next();
if (rtmp == null) {
continue;
}
if (NewsPool.CATEGORY_TRANSLATION_ADD.equals(rtmp.category())) {
String tmplng = rtmp.attribute("language", null);
String tmpfile = rtmp.attribute("file", null);
String tmpsource = rtmp.attribute("source", null);
if ((tmplng != null && tmplng.equals(currentlang)) && (tmpfile != null && tmpfile.equals(file))
&& (tmpsource != null && tmpsource.equals(sourcetxt))) {
sendit = false;
break;
}
}
}
if (sendit) {
final HashMap<String, String> map = new HashMap<String, String>();
map.put("language", currentlang);
map.put("file", file);
map.put("source", sourcetxt);
map.put("target", targettxt);
map.put("#", Integer.toString(msgcounter++));
sb.peers.newsPool.publishMyNews(sb.peers.mySeed(), NewsPool.CATEGORY_TRANSLATION_ADD, map);
}
}
}
}
}
String refid;
        if ((post != null) && ((refid = post.get("voteNegative", null)) != null)) {
if (!sb.isRobinsonMode()) {
final HashMap<String, String> map = new HashMap<String, String>();
map.put("language", currentlang);
map.put("file", crypt.simpleDecode(post.get("filename", "")));
map.put("source", crypt.simpleDecode(post.get("source", "")));
map.put("target", crypt.simpleDecode(post.get("target", "")));
map.put("vote", "negative");
map.put("refid", refid);
sb.peers.newsPool.publishMyNews(sb.peers.mySeed(), NewsPool.CATEGORY_TRANSLATION_VOTE_ADD, map);
try {
sb.peers.newsPool.moveOff(NewsPool.INCOMING_DB, refid);
} catch (IOException | SpaceExceededException ex) {
}
}
}
        if ((post != null) && ((refid = post.get("votePositive", null)) != null)) {
final String filename = post.get("filename");
File lngfile = new File(sb.getAppPath("locale.source", "locales"), currentlang + ".lng");
transMgr = new TranslationManager(lngfile);
if (transMgr.addTranslation(filename, post.get("source"), post.get("target"))) {
transMgr.addTranslation(localTrans, filename, post.get("source"), post.get("target"));
transMgr.saveAsLngFile(currentlang, locallangFile, localTrans);
transMgr.translateFile(filename);
} // TODO: shall we post voting if translation is not new ?
final HashMap<String, String> map = new HashMap<String, String>();
map.put("language", currentlang);
map.put("file", crypt.simpleDecode(filename));
map.put("source", crypt.simpleDecode(post.get("source", "")));
map.put("target", crypt.simpleDecode(post.get("target", "")));
map.put("vote", "positive");
map.put("refid", refid);
sb.peers.newsPool.publishMyNews(sb.peers.mySeed(), NewsPool.CATEGORY_TRANSLATION_VOTE_ADD, map);
try {
sb.peers.newsPool.moveOff(NewsPool.INCOMING_DB, refid);
} catch (IOException | SpaceExceededException ex) {
}
}
final HashMap<String, Integer> negativeHashes = new HashMap<String, Integer>();
final HashMap<String, Integer> positiveHashes = new HashMap<String, Integer>();
accumulateVotes(sb, negativeHashes, positiveHashes, NewsPool.INCOMING_DB);
final ScoreMap<String> ranking = new ConcurrentScoreMap<String>();
final HashMap<String, NewsDB.Record> translation = new HashMap<String, NewsDB.Record>();
accumulateTranslations(sb, translation, ranking, negativeHashes, positiveHashes, NewsPool.INCOMING_DB);
final Iterator<String> k = ranking.keys(false);
int i = 0;
NewsDB.Record row;
String filename;
String source;
String target;
while (k.hasNext()) {
refid = k.next();
if (refid == null) {
continue;
}
row = translation.get(refid);
if (row == null) {
continue;
}
String lang = row.attribute("language", null);
filename = row.attribute("file", null);
source = row.attribute("source", null);
target = row.attribute("target", null);
if ((lang == null) || (filename == null) || (source == null) || (target == null)) {
continue;
}
if (!lang.equals(currentlang)) continue;
String existingtarget = null;
Map<String, String> tmpMap = localTrans.get(filename);
if (tmpMap != null) {
existingtarget = tmpMap.get(source);
}
boolean altexist = existingtarget != null && !target.isEmpty() && !existingtarget.isEmpty() && !existingtarget.equals(target);
prop.put("results_" + i + "_refid", refid);
prop.put("results_" + i + "_url", filename);
prop.put("results_" + i + "_targetlanguage", lang);
prop.put("results_" + i + "_filename", filename);
prop.putHTML("results_" + i + "_source", source);
prop.putHTML("results_" + i + "_target", target);
prop.put("results_" + i + "_existing", altexist);
prop.putHTML("results_" + i + "_existing_target", existingtarget);
prop.put("results_" + i + "_score", ranking.get(refid));
prop.put("results_" + i + "_peername", sb.peers.get(row.originator()).getName());
i++;
if (i >= 50) {
break;
}
}
prop.put("results", i);
return prop;
}
private static void accumulateVotes(final Switchboard sb, final HashMap<String, Integer> negativeHashes, final HashMap<String, Integer> positiveHashes, final int dbtype) {
final int maxCount = Math.min(1000, sb.peers.newsPool.size(dbtype));
NewsDB.Record newsrecord;
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(dbtype);
int j = 0;
while ((recordIterator.hasNext()) && (j++ < maxCount)) {
newsrecord = recordIterator.next();
if (newsrecord == null) {
continue;
}
if (newsrecord.category().equals(NewsPool.CATEGORY_TRANSLATION_VOTE_ADD)) {
final String refid = newsrecord.attribute("refid", "");
final String vote = newsrecord.attribute("vote", "");
final int factor = ((dbtype == NewsPool.OUTGOING_DB) || (dbtype == NewsPool.PUBLISHED_DB)) ? 2 : 1;
if (vote.equals("negative")) {
final Integer i = negativeHashes.get(refid);
if (i == null) {
negativeHashes.put(refid, Integer.valueOf(factor));
} else {
negativeHashes.put(refid, Integer.valueOf(i.intValue() + factor));
}
}
if (vote.equals("positive")) {
final Integer i = positiveHashes.get(refid);
if (i == null) {
positiveHashes.put(refid, Integer.valueOf(factor));
} else {
positiveHashes.put(refid, Integer.valueOf(i.intValue() + factor));
}
}
}
}
}
private static void accumulateTranslations(
final Switchboard sb,
final HashMap<String, NewsDB.Record> translationmsg, final ScoreMap<String> ranking,
final HashMap<String, Integer> negativeHashes, final HashMap<String, Integer> positiveHashes, final int dbtype) {
final int maxCount = Math.min(1000, sb.peers.newsPool.size(dbtype));
NewsDB.Record newsrecord;
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(dbtype);
int j = 0;
String refid = "";
String targetlanguage ="";
String filename="";
String source="";
String target="";
int score = 0;
Integer vote;
while ((recordIterator.hasNext()) && (j++ < maxCount)) {
newsrecord = recordIterator.next();
if (newsrecord == null) {
continue;
}
if ((newsrecord.category().equals(NewsPool.CATEGORY_TRANSLATION_ADD))
&& ((sb.peers.get(newsrecord.originator())) != null)) {
refid = newsrecord.id();
targetlanguage = newsrecord.attribute("language", "");
filename = newsrecord.attribute("file", "");
source = newsrecord.attribute("source", "");
target = newsrecord.attribute("target", "");
if (refid.isEmpty() || targetlanguage.isEmpty() || filename.isEmpty() || source.isEmpty() || target.isEmpty()) {
continue;
}
score = 0;
}
if ((vote = negativeHashes.get(refid)) != null) {
score -= vote.intValue();
}
if ((vote = positiveHashes.get(refid)) != null) {
score += vote.intValue();
}
if (translationmsg.containsKey(refid)) {
ranking.inc(refid, score);
} else {
ranking.set(refid, score);
translationmsg.put(refid, newsrecord);
}
}
}
}
