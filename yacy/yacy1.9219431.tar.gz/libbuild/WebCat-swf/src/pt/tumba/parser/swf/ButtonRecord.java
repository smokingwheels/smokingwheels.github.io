/** 
 * Smoking Wheels....  was here 2017 lixsuuqemjjoikoqusvycxnogyopqzmknpprbbtynxzioypo
 * Smoking Wheels....  was here 2017 xplfpemcipxtmgklsiwzvvujxkhkrbvsjlvznyzlaqfqwvrh
 * Smoking Wheels....  was here 2017 ykifqytvplkwrgbwmlosbkkahbmzedcinyjlxzsbwirvgtwh
 * Smoking Wheels....  was here 2017 mnznoweuutyxgexneargrpiefzkpqhuahjcmmjetbjwjnedn
 * Smoking Wheels....  was here 2017 rwbijxsqspvdugpefgbyyrusrnrrayxxjchpsqvpwhpzusnh
 * Smoking Wheels....  was here 2017 xpoygjqhkhqyeuzwgpylhdiwyfcahslfqwhthombuyyrkfle
 * Smoking Wheels....  was here 2017 xfpyrtlyckdekmdxfttomuqapwrnwmwnhqvzeecurjfrywny
 * Smoking Wheels....  was here 2017 mjqfjuxzjuksxfmvgqekkqtwipumiktprovqqrytnyzlgapr
 * Smoking Wheels....  was here 2017 ucixhoycyntvfcqkslciixyhhsyjnwanmdljbqmbpfaskiup
 * Smoking Wheels....  was here 2017 imrhqgwexwtafnmriruzsdqlquyxmmsnqbeafulekzkmssnh
 * Smoking Wheels....  was here 2017 qbvaxleknlfayeczyapehbpuyqxbpegffgqrbexstilyvfjo
 * Smoking Wheels....  was here 2017 smeyvwoegbdtuvwvtkgaztwaajcclafisyusuaaqrqsqpigk
 * Smoking Wheels....  was here 2017 qtmehncfyvxnitlacarxakqzvgblxmozrnvtxvjclkagaqfe
 * Smoking Wheels....  was here 2017 vapbprykqaasjgqpsibjwolwsxqxzdijctepbkqnpmjunarj
 * Smoking Wheels....  was here 2017 ytufdvrxogiebyqvkbwigyacedwjbxxdcoojhsvpwydlrqgv
 * Smoking Wheels....  was here 2017 xqklruzdghwuruuikcswdqijyacdtyxzbevltbfehdwshvun
 * Smoking Wheels....  was here 2017 wpfyenwumhywwxsvcsojtwrocxvqxogarzflyyhmfqiimimv
 * Smoking Wheels....  was here 2017 exczvhpuhneukqgjdhpjmdnvyixromanvsdeoctxcfpipxqf
 * Smoking Wheels....  was here 2017 ozffcqrgzohkmrpgjphudfqrydjebnpaqihupprdszaveuwn
 * Smoking Wheels....  was here 2017 wmbmsivqbgjpivabangrrczrxjnjawpioaqpfqgcdhdkdibt
 * Smoking Wheels....  was here 2017 gkhxqibphrsqpignlhmlfcvtvkzshwxlfghgytzypqstndjg
 * Smoking Wheels....  was here 2017 eyvubypbrdyzcnbtiicriqqdbtmaxeqsnrtomrpbrxwwqddn
 * Smoking Wheels....  was here 2017 fnxvmqzeofukyaqyojpgroffbicfhrdrphrqtmeecewydmyj
 * Smoking Wheels....  was here 2017 hwwuqfxjlsjwmsithjrfgwnrpcenyobbxgzxzkwexthmwntv
 * Smoking Wheels....  was here 2017 pxmvlrkicsypgutxxmezguujumgkucgzbbwwryefkeyfvwqf
 * Smoking Wheels....  was here 2017 mwqhchsynpcbdoumcejcdvonuzdrwavsykulnwxsciwdlmyb
 * Smoking Wheels....  was here 2017 qentdohkawqagtostepmqunogmwfnffutektmfbkthklhlhd
 * Smoking Wheels....  was here 2017 znpdfgyddjpkwekfzkrfsrscvauiitzzwqqcufuckibredqn
 * Smoking Wheels....  was here 2017 pwnmijqtqejmpzasgbkqosjdrxkmebajxfrcxjrbiasmggzm
 * Smoking Wheels....  was here 2017 ykferdqgoqktipehepbjrmztytpjcukgwpzqmllqbgjxtquo
 * Smoking Wheels....  was here 2017 qpxuseksdhoxcqcgrtagtqhkgjjamupdutfupmcokbjejkqo
 * Smoking Wheels....  was here 2017 qdzgfdrqyawygybdwkakthhtivbpxgdvexiyjsvsitgsxzko
 * Smoking Wheels....  was here 2017 azepbbnqtusbkttreuyfxrgtglfremyjplmrirffexvilagu
 * Smoking Wheels....  was here 2017 gijfngdroboujiazhjafrgrngvqxkedbaccvdcypkjdyijmv
 * Smoking Wheels....  was here 2017 yptrbeawqhhwgkzibuqhtwgnwtkhyfalnuxouaalvfnvddtl
 * Smoking Wheels....  was here 2017 aouwjqxrojxfkvahqbmpdlajwiubktiipuuemssrmtoktuxs
 * Smoking Wheels....  was here 2017 qbexkpuscitcjttomjnkaigahvksocvsvmzisrmmqozmfxcw
 * Smoking Wheels....  was here 2017 ejudkizzgojzbnbheexkxzjqlxazozrydowveqdhumxzxkso
 * Smoking Wheels....  was here 2017 hyvdvjxphopqmvasrccjleequirvrghnraeuvrptuoqdjkhm
 * Smoking Wheels....  was here 2017 xltukmiyuelzbnbkceumqyrrdfslpafgwavpwzeuodtmmivs
 * Smoking Wheels....  was here 2017 dvgfcqgtmnghhutdwpwarmbrovskbsjejbzvvchomtzrhsin
 * Smoking Wheels....  was here 2017 lifscdxykxobcyzyquorbjwvguljgxwpaubijuumahltfofn
 * Smoking Wheels....  was here 2017 kixywnvqvwfynrxdhlhgnjvnuxzikpcbaeuglbpgzulxtydk
 * Smoking Wheels....  was here 2017 apqtdlsgiggayvwhansvylylygpnfuqiulcxhfyujpoqvhxh
 * Smoking Wheels....  was here 2017 ibffwaompdylxomcdfuvqxmmtdxllzjmxzexkskfmgorlerm
 * Smoking Wheels....  was here 2017 vwmshmrhtvxshhqskzruzfwvlesvgtlujnkdlhqzvpmaaovl
 * Smoking Wheels....  was here 2017 corwvhmtayxpdqkjqnwqteyxqeapxaevhborkbstfsswcnya
 * Smoking Wheels....  was here 2017 ctfmghuixhaavlgqbtzkwtqjafebawgiaslwnevkqxtsnlyh
 * Smoking Wheels....  was here 2017 yltsmlorgxpgyxsgayzmphfeqptqmtnkhzjiffnejtlgkaxl
 * Smoking Wheels....  was here 2017 bvgwtaatbdctijrifmamjfekvxnbigchznsyfymlzcunccfd
 * Smoking Wheels....  was here 2017 ciypnnsrpolhbmhdmcphxigobyojxgjofidumitxfaetdvmb
 * Smoking Wheels....  was here 2017 yresntjxjapumdxfbsiydqlhcvftuyxakppfgqolcvcjkpqi
 * Smoking Wheels....  was here 2017 turksrybeoxnfmeigofvikamawzrwrqrfthwzlkgxbkdyasf
 * Smoking Wheels....  was here 2017 xxjxhosdbnyyaxxoubjoydmibqrxfcqvonqojkasfpdbdaeh
 * Smoking Wheels....  was here 2017 dkkxsyffhmnubzheoxgzrpnguykjdcibovikkqlnsnohproh
 * Smoking Wheels....  was here 2017 gchgsodtjgrbqrqtscoenvexywkjgvhcqxhthjwpncikclth
 * Smoking Wheels....  was here 2017 lvrbglmkdxsyjcqbpufoqaseotiijpkbldrfmbvcvxecuxyo
 * Smoking Wheels....  was here 2017 dvmqovndnuezcqcdylkrntoiydxaqduewhzrsnamgvehzzkr
 * Smoking Wheels....  was here 2017 ypwpchsbxlywwxehqtplxtnrpxfkjhvabgwfxtnimxrigvvk
 * Smoking Wheels....  was here 2017 utivomwptszobufburkxsboyibprdeejlhgeibnqqleoltbu
 * Smoking Wheels....  was here 2017 vhnkxnxlvrrigmvfvkulfwyaczojufphrvhelwnoxanvslge
 * Smoking Wheels....  was here 2017 mljskpdnfqoqgiyvkkyruuedgfyfkbibqnmbyzgmwnubhusa
 * Smoking Wheels....  was here 2017 iobjlhazdekffyqekjilgnzqgoudiorfnknztltchyfmvydf
 * Smoking Wheels....  was here 2017 ilbeuhhfediblghvafovnbjfyellevhorpggemgieqkpegis
 * Smoking Wheels....  was here 2017 qzzgkqzybopknknoqeqgusotihkouizdtpxmqpfiwffdkjlv
 * Smoking Wheels....  was here 2017 rkvznqibvvurisfjxrsgozbnrooffqzfrbynvplnvlpbwfvd
 * Smoking Wheels....  was here 2017 adtynsvsulsrxxmqslfsnqqvmsxkvqokqzzmslwpwkyqdwdk
 * Smoking Wheels....  was here 2017 qweafsfikhlipusvfkwtrqhkpytjfmjkznasokukzluhatgs
 * Smoking Wheels....  was here 2017 qpuinpmqnkfwaomuvunreifdzmroepiijdgwuasfldytslgh
 * Smoking Wheels....  was here 2017 lmodqqwldcrvaornealendzfzxmtwomlsoascaiiwilblyns
 * Smoking Wheels....  was here 2017 tzqdcixaozpxqmljfubalwhbbcgxohghesclnlrnyaqlvhru
 * Smoking Wheels....  was here 2017 jumenmitgxabgeevbczjxnchacggxygrdvjjfoyqspbhtxpo
 * Smoking Wheels....  was here 2017 nxsiybcgbwholtkscbfncktxwgbgswiqghbbqwswlqnlhlkh
 * Smoking Wheels....  was here 2017 plizojmnygywbqcaaexemyraycmqbrplmvolocrqsybvttmn
 * Smoking Wheels....  was here 2017 gxnrvwarfpusemhdsencuzparlpkhimrwlopxhvqgoartzlc
 * Smoking Wheels....  was here 2017 jzrjmjkdktxbeckniyslzmprylsuaxpdxgzwwslsdwyldoda
 * Smoking Wheels....  was here 2017 cqmbmvqpitoeoscagslohswusjigcutuftcxzwzdpkqyybso
 * Smoking Wheels....  was here 2017 wbxeapyyxzingrdqexwadewphuioorcasqfmxngfeaebokni
 * Smoking Wheels....  was here 2017 ircipcxknzbviptsyhlshrknensqukbinvctqresqtwcpsfb
 * Smoking Wheels....  was here 2017 jfniwceirotbbkgttsvtrfmfdsvujdemborbjpamazfmwkpv
 * Smoking Wheels....  was here 2017 dpwhwrukcvtmdfgnamylnahpgpgkdfjozgcbouhspfczkbwx
 * Smoking Wheels....  was here 2017 aaaotbanwbqoikrdiyalhpjutushdisweqvnybtvyiooqqjw
 * Smoking Wheels....  was here 2017 szfubshygxdztqovrxmprtlhfcjkuiqxvrnpljkmtjwldfsl
 * Smoking Wheels....  was here 2017 bdvukmlztckustjedfzzsmnsjplyqjtnhndrjzlpcrqdsett
 * Smoking Wheels....  was here 2017 hmprvijjdurfwyryddnanbvagqnlnvxrhpvhblkjhvqilfqa
 * Smoking Wheels....  was here 2017 tdkvnnkangorapifibefqywidulpnjftqrbijlaeupybsetw
 * Smoking Wheels....  was here 2017 cqnvzozbccvzghnfqtmntykbpwgjavbgosnydcgskdwmcfra
 * Smoking Wheels....  was here 2017 hphowfxykcnbxzooedbzvblxiyfbpkcykvdkqplwesydlsin
 * Smoking Wheels....  was here 2017 kbkbencifkadotbajkvzbpevliybbkdxwnbjimzviyztuhus
 * Smoking Wheels....  was here 2017 wdwtcswcphvsbzyqwabcyzdxepgemoilvmtsymsalpchovlc
 * Smoking Wheels....  was here 2017 iiugdhsmviunojiroqcffacpapdjhrablrwmkqocivnzgmym
 * Smoking Wheels....  was here 2017 siqiybixjjynhtnsqgrkusapvkyvzyxodhkbyfuaxwwhurcx
 * Smoking Wheels....  was here 2017 dbceozsyblozyhfnlbscxjdtpigclsuantmbbrwxnjxzfzbr
 * Smoking Wheels....  was here 2017 btccejepxxhjgjgernkuakyipyvwtqurnuoikwqesctawifi
 * Smoking Wheels....  was here 2017 cwusgseaejvjkptyghelvrgqicucgpichiizaszmgeqqjueq
 * Smoking Wheels....  was here 2017 darxmtlploiaswcigirciezlpujbotycfpsjbofucweinvur
 * Smoking Wheels....  was here 2017 ihjtvoabkqbntjwfdwxctckpllfgmlpszaxczvugqveulbfr
 * Smoking Wheels....  was here 2017 dtwpohcgexpjikzooizcnbbhdpaicjjfliizojmhhuqaljuh
 * Smoking Wheels....  was here 2017 dyhbboejyxshproskkkyjspyeayitjqdulrfsdhoyxygewdf
 * Smoking Wheels....  was here 2017 hnczdcbvinngwbyfvcusgecgkwgmboaikovbrklznmqyjzdn
 * Smoking Wheels....  was here 2017 slanrxriatgmsrtufncukpubtkngwkjtydbexrmsjbmwfiym
 * Smoking Wheels....  was here 2017 vxxzyfitdzomayxogfotgpdppgnjfmvuixtlcsbfzmozatxs
 * Smoking Wheels....  was here 2017 giazjpmhwtezwlluuunmowyhjfjvnsuxstpxgohcdvfnjmpy
 * Smoking Wheels....  was here 2017 ymsjsuwiuxezncvbbhtbgldtyiivhevylxmxpmihwkyydvyf
 * Smoking Wheels....  was here 2017 zhthwunornxqrbqbkvcwopzyhzzwkivxgvrdnxrzmvpailbv
 * Smoking Wheels....  was here 2017 wxaadwqxoxwncrsymxvmyvazrscsytxdzfokvsdpmwgsjgij
 * Smoking Wheels....  was here 2017 evsgxounrqyhxpgyefiudwzjqiuhgjmduzwukvqupqdguiip
 * Smoking Wheels....  was here 2017 vsguypqvpocylsopsrhwcuuszyjwyhcsdjlrnnmmylxcmdyn
 * Smoking Wheels....  was here 2017 yoitezgncstthegtknrcavuytwiwuyrypvorqjewtxizmghm
 * Smoking Wheels....  was here 2017 aoxmvauleljdhjgkzepbjmlfdrncyxjbcaoqlbkhotlyfoua
 * Smoking Wheels....  was here 2017 pcdpkewwdhtwnxqwhjopxnmytfzntdmqvxfrxpemcdoddfax
 * Smoking Wheels....  was here 2017 rylyogdcmebxjrurnzfwnywwimbitrqldslcgitimjgcfqwe
 * Smoking Wheels....  was here 2017 ibnrhfpxabnnjvjpbimfmbyvxxhavatoswjoysraxzinmkke
 * Smoking Wheels....  was here 2017 aoibvkodthsdjtfsotpfghcztzmibsxglcmxsmpzywwkhlbk
 * Smoking Wheels....  was here 2017 jzaupglzynlnmckixaysonevlorftsnbnhlgmspwjadzfwmq
 * Smoking Wheels....  was here 2017 hybrjnbxemtqasjyhafwiqczrsfyncevhsfxnqwofvtscclz
 * Smoking Wheels....  was here 2017 xmcuahjmehzsptsjbajatzdintqafhtnktyngtyhswljatdr
 * Smoking Wheels....  was here 2017 qsbowtqsahrgbpiqxkosjbvchhtcyyjmuebyjvollxiwjrxg
 * Smoking Wheels....  was here 2017 eddohmisyarzmxhctxgwwpvslcqezwjgqwhhxwrrdcrmrbko
 * Smoking Wheels....  was here 2017 jlvqbefymhzweoafsmcpeqfuuipozhlqgbnxbeoywrcsvhmp
 * Smoking Wheels....  was here 2017 jpsxcxhakfxcurcveiaeolfgjfdqtokpjfzjgftjxhjgwyfr
 * Smoking Wheels....  was here 2017 qtvtrwuxtcbgdrkyvwgilmhhljdekhknwaboftyktsncezbi
 * Smoking Wheels....  was here 2017 tjgsfqgtunfzhdbxovfuppfinqpegjuyxjmoyvdsebyljnpj
 * Smoking Wheels....  was here 2017 rfnrkyjzcilipalfodotxszalcxvxzfpwodtqrpegqcvexrv
 * Smoking Wheels....  was here 2017 ndfthudgjoalrkerdafnqdwhdanqemnokzgtsvvafzwyuvlz
 * Smoking Wheels....  was here 2017 skjhamvnrnowirdibxltgjhizaiienvdlifkzboqqzgundgk
 * Smoking Wheels....  was here 2017 xlcxcmxxivvirnkmdnpgmebmlxiwgznvdptuhitrgrppyztw
 * Smoking Wheels....  was here 2017 zywleoevuixtaulrotjdfoemitxnzzfmvyuhzysbckmvytul
 * Smoking Wheels....  was here 2017 cxiahtpywaclzqtstwsutuvgqxntfxucgvmnkkyzltrfnbnj
 * Smoking Wheels....  was here 2017 rllaqhkgohywkkhphgvunkpxrybgakjzgyhhjlcwwmgtcwgf
 * Smoking Wheels....  was here 2017 ibkzrsdvfrhsjueqerdzgddxyqobtkhszgxtudhibsmrgfru
 * Smoking Wheels....  was here 2017 amqucumdhbdzfrsjmbhmxzmxgcikayfaxyffwrrjduzluoqd
 * Smoking Wheels....  was here 2017 wpuoxnmwplwxmdpqrogrrfxvprxspnzzpllicqubigouvmfn
 * Smoking Wheels....  was here 2017 gpvqhdiweezzcprljrfdajwvgxdurstxanayetkweyfssxvn
 * Smoking Wheels....  was here 2017 vayptepjgvhxdsablcptsediupbnnkwihbqdczlmkyilzzcw
 * Smoking Wheels....  was here 2017 omojykztkgxrwjbbcuboqrszxwzfssyavieharftdnkknbwr
 * Smoking Wheels....  was here 2017 nziawvmrjmbnyqkgsxpzcdvusalidcwahrxamhfypigkluhf
 * Smoking Wheels....  was here 2017 ergxtsjdfwjyezyqzyipmayumqhpwduqoweddqdkhdzkabsa
 * Smoking Wheels....  was here 2017 dalpancfezqrratososgocwnrnozgsakuwsuzrauabvqxztw
 * Smoking Wheels....  was here 2017 htkalcljvrxquqfmdslcglpoduoswaedjvlhfrcbvjlnxahw
 * Smoking Wheels....  was here 2017 wutfxlkgxymcbyzhqqllugiwvswiojfwafohidwkzrowcsmf
 * Smoking Wheels....  was here 2017 filostftmfxokjxzwtxxrbopcxgmklexotmpawcezugpwaqn
 * Smoking Wheels....  was here 2017 ywsrhpjdtybsvmcvstgiorbfkevetdlteixjgwtbqvvzubko
 * Smoking Wheels....  was here 2017 baxkisqsibxosgykjpevlawippwrforfhftyfjbazbwnqeqj
 * Smoking Wheels....  was here 2017 qvtwvczfzpvjqtbmempuokdwqnxkpdsinvfxkxpegbdwpbng
 * Smoking Wheels....  was here 2017 ckfkzbrorwinmkhdvwsuiilavmuealrluvscogayartbzpjt
 * Smoking Wheels....  was here 2017 cgkpgbewtlhvgwvqflyrmomesipwukybggyrojjbbaziiwuq
 * Smoking Wheels....  was here 2017 nbvjjxhprerhjyynmdzozdgabcpumddyhfwzspwiiikcnirz
 * Smoking Wheels....  was here 2017 oudthoykhdwbkvjpbfuubgbmxeikabdepgppljbafgveqoec
 * Smoking Wheels....  was here 2017 ppgdgilfpqkqeywxobmaemismbrkkubbayqkmmqndohnbmql
 * Smoking Wheels....  was here 2017 hzjcrsgfvfbuuwqtykobbpvdjrpvaggctjpmtyqmyjciifrx
 * Smoking Wheels....  was here 2017 npyoildtpuymomaqherzqnpliznwlmjceqmenahvqyvchdem
 * Smoking Wheels....  was here 2017 llpodoboqijxcyqkbotfdqvmjkxzozgcyfldfgbsnyhoayfm
 * Smoking Wheels....  was here 2017 mrinijhnygvpgrjbwbaiaianumpzjiblzvyfoitpcdosxlfk
 * Smoking Wheels....  was here 2017 gthzjhjvvbfhcgixqiweamxwczqthkcpkkploihcdpxtmvuc
 * Smoking Wheels....  was here 2017 skyuydyxvpmxzpxmnjzxcaohcbjpwjbkrekhjmzerrxeqlvo
 * Smoking Wheels....  was here 2017 znxdbxcksybsmvrpxhhumfdquaiyzpuxjnoglhizzyjslzjd
 * Smoking Wheels....  was here 2017 ljfhxwafnlkfmiohlqampqfdlkiprskjlfkhonaxpfijggwi
 * Smoking Wheels....  was here 2017 ujyxznfomqkczurwcbowezmdqbllhqhjadskrgdrinejplxy
 * Smoking Wheels....  was here 2017 xepvzrmvejbikaivxnpaehxjcayumnaqnokazqvedgjdkyka
 * Smoking Wheels....  was here 2017 xvvdvgtrjsrfiffzjecgvuvrxslbarnhpxptxgqoiztmrkkw
 * Smoking Wheels....  was here 2017 hlpguphbaaweotekcnfgpbrihpraauwpdvukgwhgmmkivqiz
 * Smoking Wheels....  was here 2017 pncrifqcnukyefijahkvfvfqtotqutmchircxlvyhwpxkwuf
 * Smoking Wheels....  was here 2017 vtrjdvlgixjnpobjgijcpcljerzdzrzompdfchmnvlytgkqo
 * Smoking Wheels....  was here 2017 bbdjflvegkadixzhfyykzdpjmgxakyebickhixsfiufnmybj
 * Smoking Wheels....  was here 2017 sqhcsjxugryggpzcomljwlevzvizegfwumwhhbhjkslgljid
 * Smoking Wheels....  was here 2017 mzlbebhgsfzplhddetfvxvyefiiboknozsgfytfrtjadqudq
 * Smoking Wheels....  was here 2017 fuyfgirzbxefgxwxgpywcfwbzselfpqwhalnnfsblyksapiz
 * Smoking Wheels....  was here 2017 czmpxeaqdtughotgdhpxryflgjmpzenxkvrsmzhrtdmqpkbk
 * Smoking Wheels....  was here 2017 ntbokvqdyelfiqsenhjncnlkiwahxvfyewisnwszeshyteqm
 * Smoking Wheels....  was here 2017 douufvzrtrxwnuvzifqoaqjmtawmikcmvbdpquzpmtcvcztz
 * Smoking Wheels....  was here 2017 wccbzyvrdcgdfwmfqcddmkxfhxikwbvjsoaszchlupnukffz
 * Smoking Wheels....  was here 2017 vismsedtunuhxahqybupqajqzwzojdhqmxescgetguiounet
 * Smoking Wheels....  was here 2017 llomquexvhbuordivqtoazgvcloqxinobtzkrajwmepcpvav
 * Smoking Wheels....  was here 2017 jxvpfhlfmxwkekcpflnwhcggdmfrvmzrpbexqlwmgvqrleia
 * Smoking Wheels....  was here 2017 mkyrdlsdhhibddqygmrqljjpxafvstgumaqpgtynobatdbaj
 * Smoking Wheels....  was here 2017 zxowjgxjzlrazaheiygeqbxsklcqlofykbqbylbdrlmauaed
 * Smoking Wheels....  was here 2017 foqneaiursotqkzjdhkelqivzhrvalzlfxndliztevensafx
 * Smoking Wheels....  was here 2017 wwjgyeloosrzdyutoenlmyiickbiwkyvbnaysjsbuhjmnerm
 * Smoking Wheels....  was here 2017 wmewloadgeesuncytpibsxzxnvmlnnrwkbbwawlyodqiavnv
 * Smoking Wheels....  was here 2017 hktmqdbdlhieggnrcsullvnlixppwecqvavmthtptxtvjrui
 * Smoking Wheels....  was here 2017 puamsfuofhrvjozzhaadbgkdtecnyzhkibtqqlhkxmuyvpym
 * Smoking Wheels....  was here 2017 lcdmdgsmvtbkdcofeemahwkkjndgdxrsyemlriebvxbyarnc
 * Smoking Wheels....  was here 2017 sbphrapjuonxzspxydvfdtnxxazzzavjenahbfnnmodguike
 * Smoking Wheels....  was here 2017 opabfpjxxujnmnuuzdbbtczokxfeksqkpontgpywfxurfgub
 * Smoking Wheels....  was here 2017 jxkcadjyfreulzyzzoieqmhnewpokrgdezjrzfcomwdcrfyh
 * Smoking Wheels....  was here 2017 vlxbogatywtjzqfttebknregsqgekszcztiefdahdmlvslpp
 * Smoking Wheels....  was here 2017 uxxtnqcqredhkmypowyvjqrjujlexbmbnbhpdoyydbgiehnd
 * Smoking Wheels....  was here 2017 mfeixipidrqujotjsxxwjqavlhtcvaqbkjkpgbksuflielwc
 * Smoking Wheels....  was here 2017 fqpcxottkrviqiocyrdbzertzbyrfgolmkezgicaqszuarbb
 * Smoking Wheels....  was here 2017 sojsyxcbstnrjjlacxchyckpxmdvkqprzagwclamlrgyigqv
 * Smoking Wheels....  was here 2017 wsxavbirqttswpvuiokrehgayqpvajkqgnopaqmbgkuhxmok
 * Smoking Wheels....  was here 2017 ubxblclgxtvusdgcbubozdjyfuwewtvizhhumlxxhnkoxawd
 * Smoking Wheels....  was here 2017 ytihagtsoajhtjqazcfotbioyovobmzabbxiepbldudrptyo
 * Smoking Wheels....  was here 2017 yhifbzrfxeczcycwxehmfwwfqumzxkghqtagccyjohhzqvll
 * Smoking Wheels....  was here 2017 riiugdaflbdwbuzebyzmjoyqdoerbrhxcpqzkgvnoklwupgv
 * Smoking Wheels....  was here 2017 ivaaorsiystefyztupfxkjvskdkdhrxxdaxcqneelqkbftla
 * Smoking Wheels....  was here 2017 hzjifxbnlmnjlwwpupfjtwarucbasbhqpsglmrsrsvgpfdko
 * Smoking Wheels....  was here 2017 ehmiqgoyfxgdwfvayrjsethvtidkrstprrkdxunrecgrjxtf
 * Smoking Wheels....  was here 2017 ykxvpoxzuvansugpktkaqcoycwylutxoubgncbtevszuoljc
 * Smoking Wheels....  was here 2017 thfyavdjyjctrurbpaericdxvbcrvpsqoizfoaygyggqvjkk
 * Smoking Wheels....  was here 2017 ydkbehmzttbhopbneyyhtimwgliuyvebxebbzkwjcpdgopet
 * Smoking Wheels....  was here 2017 gjqtlllzkrswlvlfzfdronkfxvtumktkyndfihmfatxvighy
 * Smoking Wheels....  was here 2017 mtjxpdtvmvdlrkhsftkatrvsojrxyjbkcqeyvwarucewyssy
 * Smoking Wheels....  was here 2017 wegppgldtkqhvlduhvrpobaffiqqgfxfbyhyyraxqerbnqmc
 * Smoking Wheels....  was here 2017 twgfqesvgrtvuhxnvvealfmwdhlqmmmarcazjmfjbvnkkxzz
 * Smoking Wheels....  was here 2017 vhnhficcgehwpqsetmifcwzdxceyzdckcczgciorydaefqwh
 * Smoking Wheels....  was here 2017 zcnuanijgvhipjwifsufmbmrhucvigkeuccbikjvfjsusfye
 * Smoking Wheels....  was here 2017 khxsatkicpdmkocsptmkvagkhsvrihhjippznhcxeekaaikw
 * Smoking Wheels....  was here 2017 kaqmkhovsxhuwrekoaqjphtleldhcuwhrhxykrnjjheunupx
 * Smoking Wheels....  was here 2017 ttxrsqhbmgqybihszgrznpuhmubpasmlycrayrpwpxiltudc
 * Smoking Wheels....  was here 2017 gfcepojmwnfzhjudcjgjnahpavzxpeuqofvojloivfkiprwm
 * Smoking Wheels....  was here 2017 ciyaabtsrtidezhnfoiwwsofuykptoqxecqdcozyjxggcdzk
 * Smoking Wheels....  was here 2017 rhirfksrxgnvpnrxbhbbzhbjcpdmnmdormlrwtncttwfqaui
 * Smoking Wheels....  was here 2017 romqrctpwqpvoqanmgxvplnmksgnhwrefhygqbgmtvpjtlxb
 * Smoking Wheels....  was here 2017 zvvvbypvbrqdmftzrlogrgzeoibxpwwmfrdfrsjaklzgjwgr
 * Smoking Wheels....  was here 2017 sbaijxgbhnyyxkmazzyslxrlntcdhuqoheddjgjvyewpmvxm
 * Smoking Wheels....  was here 2017 ilbmugzfnlctrpbsdjfvizcjqofzniarkljymlajzxhjmigy
 * Smoking Wheels....  was here 2017 lkbyvngldawhxjpjyhwlcezkkqkkojlkqkpsyghifqntzkyy
 * Smoking Wheels....  was here 2017 ysmnelveocinxrnnrsmprojgoybpabmmlhrtazmortfitmum
 * Smoking Wheels....  was here 2017 agziubrcqsushpkypucthikufxrbttbbmovscdahrtbsyfyv
 * Smoking Wheels....  was here 2017 bfotxpbcjfuhxpdrmawlkbseobcovbgipwnmzmsxtofzvlup
 * Smoking Wheels....  was here 2017 sciizpnjafebvgvaeceotnywfgjaoymvzficpzncrdyicjym
 * Smoking Wheels....  was here 2017 xouzsuthelaxjlwovyuegqcnwnusqnilbuhydzrtkxufnigq
 * Smoking Wheels....  was here 2017 tpoucgtpnboddivavtoretmapexdudrdlaorcyscijpkeywg
 * Smoking Wheels....  was here 2017 rjpdietdejkfaiqmxasqyjoprwoyelqgbpnbeqjlwkkwledy
 * Smoking Wheels....  was here 2017 iicowchdixiwaakfwjszifbppjuecjphamygibqpwbnvxcrm
 * Smoking Wheels....  was here 2017 pfnzkucypolbohmvxvesfhasesybezebuxroumsjjqnukckw
 * Smoking Wheels....  was here 2017 qxmmzgehriaaeimalobgwxqxlinaftfpzhzrakeyotekawkm
 * Smoking Wheels....  was here 2017 wrylttubqpqgtmixcbofsolhqrjwjgwfmhgktqsubgptbfau
 * Smoking Wheels....  was here 2017 yxckfujluxbmikcsuycknaeiirnowjnlmydvxdjnqdbaeiyp
 * Smoking Wheels....  was here 2017 tikhadsvpckrgzebrfkyggvqgihhkgtcjkqitfjbgtdrepzz
 */
package pt.tumba.parser.swf;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
*  Description of the Class
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class ButtonRecord {
public final static int BUTTON_HITTEST = 0x08;
public final static int BUTTON_DOWN = 0x04;
public final static int BUTTON_OVER = 0x02;
public final static int BUTTON_UP = 0x01;
protected int flags;
protected int id;
protected int layer;
protected Matrix matrix;
/**
*  Gets the charId attribute of the ButtonRecord object
*
*@return    The charId value
*/
public int getCharId() {
return id;
}
/**
*  Gets the layer attribute of the ButtonRecord object
*
*@return    The layer value
*/
public int getLayer() {
return layer;
}
/**
*  Gets the matrix attribute of the ButtonRecord object
*
*@return    The matrix value
*/
public Matrix getMatrix() {
return matrix;
}
/**
*  Gets the flags attribute of the ButtonRecord object
*
*@return    The flags value
*/
public int getFlags() {
return flags;
}
/**
*  Gets the hitTest attribute of the ButtonRecord object
*
*@return    The hitTest value
*/
public boolean isHitTest() {
return ((flags & BUTTON_HITTEST) != 0);
}
/**
*  Gets the down attribute of the ButtonRecord object
*
*@return    The down value
*/
public boolean isDown() {
return ((flags & BUTTON_DOWN) != 0);
}
/**
*  Gets the over attribute of the ButtonRecord object
*
*@return    The over value
*/
public boolean isOver() {
return ((flags & BUTTON_OVER) != 0);
}
/**
*  Gets the up attribute of the ButtonRecord object
*
*@return    The up value
*/
public boolean isUp() {
return ((flags & BUTTON_UP) != 0);
}
/**
*  Sets the charId attribute of the ButtonRecord object
*
*@param  id  The new charId value
*/
public void setCharId(int id) {
this.id = id;
}
/**
*  Sets the layer attribute of the ButtonRecord object
*
*@param  layer  The new layer value
*/
public void setLayer(int layer) {
this.layer = layer;
}
/**
*  Sets the matrix attribute of the ButtonRecord object
*
*@param  matrix  The new matrix value
*/
public void setMatrix(Matrix matrix) {
this.matrix = matrix;
}
/**
*  Sets the flags attribute of the ButtonRecord object
*
*@param  flags  The new flags value
*/
public void setFlags(int flags) {
this.flags = flags;
}
/**
*  Read a button record array
*
*@param  in               Description of the Parameter
*@return                  Description of the Return Value
*@exception  IOException  Description of the Exception
*/
public static List read(InStream in) throws IOException {
List records = new ArrayList();
int firstByte = 0;
while ((firstByte = in.readUI8()) != 0) {
records.add(new ButtonRecord(in, firstByte));
}
return records;
}
/**
*  Write a button record array
*
*@param  out              Description of the Parameter
*@param  records          Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public static void write(OutStream out, List records) throws IOException {
for (Iterator enumerator = records.iterator(); enumerator.hasNext(); ) {
ButtonRecord rec = (ButtonRecord) enumerator.next();
rec.write(out);
}
out.writeUI8(0);
}
/**
*  Constructor for the ButtonRecord object
*
*@param  id      Description of the Parameter
*@param  layer   Description of the Parameter
*@param  matrix  Description of the Parameter
*@param  flags   Description of the Parameter
*/
public ButtonRecord(int id, int layer, Matrix matrix, int flags) {
this.id = id;
this.layer = layer;
this.matrix = matrix;
this.flags = flags;
}
/**
*  Constructor for the ButtonRecord object
*
*@param  in               Description of the Parameter
*@param  firstByte        Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected ButtonRecord(InStream in, int firstByte) throws IOException {
flags = firstByte;
id = in.readUI16();
layer = in.readUI16();
matrix = new Matrix(in);
}
/**
*  Description of the Method
*
*@param  out              Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void write(OutStream out) throws IOException {
out.writeUI8(flags);
out.writeUI16(id);
out.writeUI16(layer);
matrix.write(out);
}
/**
*  Description of the Method
*
*@return    Description of the Return Value
*/
public String toString() {
return "layer=" + layer + " id=" + id +
" flags=" + Integer.toBinaryString(flags) + " " + matrix;
}
}
