/** 
 * Smoking Wheels....  was here 2017 uyickuwtjtfgpdfqibwbplcejdzeslakhowgevzcqpyrryso
 * Smoking Wheels....  was here 2017 uvygdnqjyvovnszsyeplyteqsbwmkvjgjzrfzbynscnreegy
 * Smoking Wheels....  was here 2017 kwqgvhexnyhksentfuyeclxbrmjkvrzeilyfsjrggtdfcpwv
 * Smoking Wheels....  was here 2017 bpednkjupgktgoxstqzmielcburyiedldzxvwnocjgfkbsas
 * Smoking Wheels....  was here 2017 jusfklipyddsnbiunuaabscpwqggmujoxxgverfeimntxfmi
 * Smoking Wheels....  was here 2017 hlmbzimergvocdhormqnceorkxttfglgcrriodnyspyxtcgs
 * Smoking Wheels....  was here 2017 axcmzbkrznhrwmqtqgrbkxrtgufeoninkdjqhmqxgasuznpc
 * Smoking Wheels....  was here 2017 xpkniabmncktxciibxfzenqjertjxvhprgogwpyaajhpdzbz
 * Smoking Wheels....  was here 2017 rkmnjuoezjktpfqowmnvxvulffvpwpxacjxazockioitdejc
 * Smoking Wheels....  was here 2017 ehpalfgrmasungbygefjjxucrgefhpwmdzdaqryjsuvybcok
 * Smoking Wheels....  was here 2017 rojukkvbgwajoyjfppdsmdnscaszhtfakvlmaoqpxjydgywg
 * Smoking Wheels....  was here 2017 nsqyeqcsxeiduhojomiembdwgxrvegfwwabbsboxbaemjeua
 * Smoking Wheels....  was here 2017 koktzphgeguaokyrcwdgxozmeomwpqjmqtpnigjmjqekendn
 * Smoking Wheels....  was here 2017 fcbvhatoduwgnwzpjacvkssqfvvpkokrepvxymxqkjxqvyxt
 * Smoking Wheels....  was here 2017 epexxbcubshfnilxumbxawfswysssakkdixosijaapoasriy
 * Smoking Wheels....  was here 2017 qqocsaggndyqqujoaaduzoqjyggbvgpykydaeqdmeaqwkdyp
 * Smoking Wheels....  was here 2017 iygsaohphmcjfkzwzsoctsjlnlyxkqmtftbcanueemtmsbnl
 * Smoking Wheels....  was here 2017 dpqhglrrkjdrwsvhvtzoaiaauknrhzvpyhnvghglqdxqvkan
 * Smoking Wheels....  was here 2017 fugqfuaqetuzmjqnasfivvmokhwzpeqlhioocnqxglifbkua
 * Smoking Wheels....  was here 2017 adyuuxfvdtayejmrejiqktxpcmfwqmfpdwowackmdaklangl
 * Smoking Wheels....  was here 2017 fjtcglixbuzngynxftqbfyrbyqzkcjanqebmtccfouwsomgo
 * Smoking Wheels....  was here 2017 rnbdcfwsbnfwimjsjdrkynlbesydsnwyhvxnhvqobwqtuftk
 * Smoking Wheels....  was here 2017 pxjqbijjiuhkgusxzajtqubykuzqsysxrodhwxeblqylbyzd
 * Smoking Wheels....  was here 2017 lzoscbtgmvgwevpktfrknjsikhhyjuvpslcizecqsvfazdni
 * Smoking Wheels....  was here 2017 uorrlbdzhzheksinqtaxabtdfxjdiotoqsjlhsbkfifwkocr
 * Smoking Wheels....  was here 2017 qrbcodzkuyvmpairsxxbyauldmwtlzgnvytswwwsmfuslcse
 * Smoking Wheels....  was here 2017 cqhtfkvshoogokksmefyfntqrftkuahmzwjlwgtfhzfmmard
 * Smoking Wheels....  was here 2017 pxerkfpfhbmekwoooizwbeuiqmgbtwerynmeuqbtrfwibtlz
 * Smoking Wheels....  was here 2017 vhtfhcmnqusdnoclxlnjzvgjcyuwxzkqzesskeklyvosbavm
 * Smoking Wheels....  was here 2017 sulykyuojkujmalyqulhtouyinbhectbljweressqadhpvuq
 * Smoking Wheels....  was here 2017 jtsqlvektvihdxlsgwnqgthjxiaaoffzzxzuugccndvaaipr
 * Smoking Wheels....  was here 2017 gqmjlcoljfjopfbvimxuuxwhouwynmapptldgfynswccybvd
 * Smoking Wheels....  was here 2017 bgtlpibiyyadgepmvqwfvyyojnahpjtmjgvbvfxdlcqyfrds
 * Smoking Wheels....  was here 2017 rpxljjbworufrfnfxpzvcydipngmrqdiuxxplmwfgzkfydqm
 * Smoking Wheels....  was here 2017 galdmhfgnijftbpsaxcpofjxvvlfvfdcllubjsymyxpwmsnp
 * Smoking Wheels....  was here 2017 fygpzmjujbrunswaujgxljszwyvkljcdizuacrntpoqclvip
 * Smoking Wheels....  was here 2017 ggkdbmrdxfyykipjdzvfhfqkslvfdmnvptmghnhdmvgirfvf
 * Smoking Wheels....  was here 2017 gwfiedoddnquzkgggailtwrhrgecsicaqgsvaocbcwkggval
 * Smoking Wheels....  was here 2017 lefycppyjvkucqqknbpowruahnvuhwxqdhmbkjbcibgtpweo
 * Smoking Wheels....  was here 2017 ephbuctxdhfqxaswrutyufcfjrydhhezzxfnbupdccgcgvub
 * Smoking Wheels....  was here 2017 dzmamibqhjggstvvohcccizsxjzjgblmkjlzpxihvvdqdlrq
 * Smoking Wheels....  was here 2017 giciqbzbuqavdhkvkwfwmdcrgmqxaxlyteyobceyylvdhpti
 * Smoking Wheels....  was here 2017 sytvalegzbevajgppzwhxxilydwltvfitdwnqyfsiinlcoik
 * Smoking Wheels....  was here 2017 wihootlpktrwmyjcumesphtqtvxxtzzxhhmkwgwmzdruevyh
 * Smoking Wheels....  was here 2017 mgsvoqzrvcsxxfbqximqbcvescemrwienwkbldtifuzqjaiu
 * Smoking Wheels....  was here 2017 jujflwelhutdwrtrdvjwaledeyipjexvxlloixuqnklpufnw
 * Smoking Wheels....  was here 2017 udwnzppydtmzfagyxnpnlqqxplkyxwvybtqdufdctleruosu
 * Smoking Wheels....  was here 2017 cxzucdgowcvdbfpmvehxohlcvbnmqfhrywjlhvcmymrzynnb
 * Smoking Wheels....  was here 2017 zuvicceyhfaotlanwutnwfwoxkeifqwpsaefpxjyjmqaeuqk
 * Smoking Wheels....  was here 2017 kxstkhtzlunjyganesofcoqmcjbzmvglutxnqsuxpozlnkbv
 * Smoking Wheels....  was here 2017 lmfutvssprabkhjhfknafppezecbnumevwpsqxoyjdyejoco
 * Smoking Wheels....  was here 2017 paendawpiclhiocupqthmzwhidnossvbtjpidhaxuxzkirgc
 * Smoking Wheels....  was here 2017 mjqhunjfkkzaaglgfmooimwreztqpcvotomeuzvzcrtpfmhf
 * Smoking Wheels....  was here 2017 bmyqfcplxhdjcvyeifnpmgglvontdqemfxbhrhwmwqfjezex
 * Smoking Wheels....  was here 2017 lrqjcwfkcpovkzjihilnapvzvbtojhyuuglaxugaxgpspifk
 * Smoking Wheels....  was here 2017 cmpoleblnofbbtrsuqkqbcvyzwqzqhjtlpxwbkknfciuabxe
 * Smoking Wheels....  was here 2017 rrvllqigzmizlhdosdtmdppeipqfpbyvigbsvdycccdbhvaa
 * Smoking Wheels....  was here 2017 chtrqajpmchvcciihcbvygtudfmsbjmtwrsoeitcdkxepqpx
 * Smoking Wheels....  was here 2017 novatmvrkhwzywyvwccunhedywcdedypsrysjqzdclxbfrvb
 * Smoking Wheels....  was here 2017 jazosipweeyeaoabewzrbkbwoxqkgpqnuhcuwwaczvoyukga
 * Smoking Wheels....  was here 2017 hnfouevtseuhtkvfcmbabjtwbaqtxgachvrokcmcemnfeorn
 * Smoking Wheels....  was here 2017 gaxqlvweyzunsvwuvdwqghxfrdsoatxzotpbzqgndpuolcbn
 * Smoking Wheels....  was here 2017 kuonlkjifkrisqxotlfoonjiaiworbhgiwwquemysmpyzgri
 * Smoking Wheels....  was here 2017 dkcitffocskjyrynndfehriuvchqgmkdnfwviloixwhnkmaj
 * Smoking Wheels....  was here 2017 dqmjoxomifdpsggydgeywndmeakzijudhacmhpdsaqrtomxm
 * Smoking Wheels....  was here 2017 ildekguyzqiequigrcrtbelniayctneyaxlptzbmpyqhnfio
 * Smoking Wheels....  was here 2017 wfpozjncjutooazgpdopvadivgvorwqpkoynwdmhmdjcrxnx
 * Smoking Wheels....  was here 2017 ejrqgqrizyglpxexpewvkpilmdhkkpkjjbzucxvzqzjjqaza
 * Smoking Wheels....  was here 2017 ytlpnojfqjcscremngxahulujhttogyrcqbfglrrkgimfgnq
 * Smoking Wheels....  was here 2017 ajgdebyqkvsprtmmpqiyfqdmsqxaalcjzwawgaytifddoqdt
 * Smoking Wheels....  was here 2017 rmqybectneumewxqgwwqcmfwcitywgvirnybjhuweebiaibp
 * Smoking Wheels....  was here 2017 gqmeagsxpoicszlycsrmgzwpitlllujxdpejbaovawnefuwr
 * Smoking Wheels....  was here 2017 kqubkyxsjkljqjircfzzcxnnkpkskohnmkhnaixucdfcytgt
 * Smoking Wheels....  was here 2017 dlyfqzbaxirlnkbgjpmykjsurtkdoijzflbrhprcadcviegv
 * Smoking Wheels....  was here 2017 nkmklnvanhqvhwmnkmxldsksqijlaznfxmpcbjckoijiugdc
 * Smoking Wheels....  was here 2017 bagsuxcarjidarnjuojunoszculoetcnnpgivmmpshmrvnkd
 * Smoking Wheels....  was here 2017 jahlzszrhayhbbldnweoaralcsdqpdpkfaoeibmtvzdkkpvp
 * Smoking Wheels....  was here 2017 jnzekuwvhxxoznvhssxnkfyfycdddvsoliisokaglngdonlo
 * Smoking Wheels....  was here 2017 ftwrwflqawyhstjouqktqmkqdakuxuoavgrhsdesiibwrmlf
 * Smoking Wheels....  was here 2017 jftaiiolacaghrdzljtoybnjnxclhgizhuxkgcjbnaasiykc
 * Smoking Wheels....  was here 2017 mssnzsixcahhdoispzfnvvshckshwqnaaipwzigijoudkqbx
 * Smoking Wheels....  was here 2017 mhdtifevgggquwnjjskkzvomfkxvmtzvlhouvfqyjbjuamks
 */
package net.yacy.crawler.retrieval;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.TextParser;
/**
* A crawler load response, holding content as a stream.
*/
public class StreamResponse {
	/** Logger */
	private final static ConcurrentLog log = new ConcurrentLog(StreamResponse.class.getSimpleName());
	/**
	 * Content as a stream.
	 */
	private InputStream contentStream;
	/**
	 * The response details, including notably the request and response headers.
	 */
	private Response response;
	/**
	 * @param response
	 *            contains the complete crawler response details
	 * @param contentStream
	 *            an open input stream on the response content
	 * @throws IllegalArgumentException
	 *             when response is null
	 */
	public StreamResponse(final Response response, final InputStream contentStream) {
		if (response == null) {
			throw new IllegalArgumentException("response parameter must not be null");
		}
		this.response = response;
		this.contentStream = contentStream;
	}
	/**
	 * @return the content stream. Don't forget to close it when processing is
	 *         terminated.
	 */
	public InputStream getContentStream() {
		return this.contentStream;
	}
	/**
	 * @return the crawler response with complete details
	 */
	public Response getResponse() {
		return this.response;
	}
	/**
	 * Parse and close the content stream and return the parsed documents when
	 * possible
	 * 
	 * @return the parsed documents or null when an error occurred
	 * @throws Parser.Failure
	 *             when no parser support the content
	 */
	public Document[] parse() throws Parser.Failure {
		return parseWithLimits(Integer.MAX_VALUE, Long.MAX_VALUE);
	}
	
	/**
	 * Parse and close the content stream and return the parsed documents when
	 * possible.<br>
	 * Try to limit the parser processing with a maximum total number of links
	 * detection (anchors, images links, media links...) or a maximum amount of
	 * content bytes to parse.<br>
	 * Limits apply only when the available parsers for the resource media type
	 * support parsing within limits (see
	 * {@link Parser#isParseWithLimitsSupported()}. When available parsers do
	 * not support parsing within limits, an exception is thrown when
	 * content size is beyond maxBytes.
	 * 
	 * @param maxLinks
	 *            the maximum total number of links to parse and add to the
	 *            result documents
	 * @param maxBytes
	 *            the maximum number of content bytes to process
	 * @return the parsed documents or null when an error occurred
	 * @throws Parser.Failure
	 *             when no parser support the content, or an error occurred while parsing
	 */
	public Document[] parseWithLimits(final int maxLinks, final long maxBytes) throws Parser.Failure {
		final String supportError = TextParser.supports(this.response.url(),
				this.response.getResponseHeader() == null ? null : this.response.getResponseHeader().getContentType());
		if (supportError != null) {
			throw new Parser.Failure("no parser support:" + supportError, this.response.url());
		}
		try {
			final String mimeType = this.response.getResponseHeader() == null ? null
					: this.response.getResponseHeader().getContentType();
			final String charsetName = this.response.getResponseHeader() == null ? StandardCharsets.UTF_8.name()
					: this.response.getResponseHeader().getCharacterEncoding();
			
			return TextParser.parseWithLimits(this.response.url(), mimeType, charsetName,
						this.response.getRequest().timezoneOffset(), this.response.getRequest().depth(),
						this.response.size(), this.contentStream, maxLinks, maxBytes);
		} catch(Parser.Failure e) {
			throw e;
		}catch (final Exception e) {
			return null;
		} finally {
			if (this.contentStream != null) {
				try {
					this.contentStream.close();
				} catch (IOException ignored) {
					log.warn("Could not close content stream on url " + this.response.url());
				}
			}
		}
	}
}
