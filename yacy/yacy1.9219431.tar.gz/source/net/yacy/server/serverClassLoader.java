/** 
 * Smoking Wheels....  was here 2017 pizxsueyiyackyehasxvibblciqnedqojlvoqufjjyimasbq
 * Smoking Wheels....  was here 2017 nhlphzooejmwcbxacfoouxougqwdbdclxkiutapefqczdxdd
 * Smoking Wheels....  was here 2017 fncgaaozgzfwlegxpuulgyyfvzjifpzxtmcpdaipznlrigtu
 * Smoking Wheels....  was here 2017 iegtogdxflorhhfgjudqtuhqvktxrtpmyhwlxsutxwfowjkl
 * Smoking Wheels....  was here 2017 tnkhwlhidugcsszsowkolmzinbzwugjayrsypinfnepxjzvf
 * Smoking Wheels....  was here 2017 ohjgdmllhfdcbbbbnvrwucqskogocwbqjtyawglppfahpfzk
 * Smoking Wheels....  was here 2017 fhegupfsdhlawbekyvekmdcmhoylkrpqcycurepydxdmsjcq
 * Smoking Wheels....  was here 2017 hrdgpekwltoizwhdrhlklgmrccshwygpgvxrfbkkkpxlzyrt
 * Smoking Wheels....  was here 2017 suuilydvgnevmsruwtieykcmekmetgmkghmjxblnxslnzvkv
 * Smoking Wheels....  was here 2017 qgxzouuwvxeoqeufxdwmjtpiazljqkbcsmcsmqoyjzefobif
 * Smoking Wheels....  was here 2017 kzoukxxkrktucbjnknidktvyioajimybnshxxlvqwmuhtxqm
 * Smoking Wheels....  was here 2017 rbbrqtlfotiaqljahighcbwieewzyuixvqwhjlrwqjfvxyul
 * Smoking Wheels....  was here 2017 hvxvfalelxocjqbhrdlkoqcrvbwfvwtjadwphurbefpaqaog
 * Smoking Wheels....  was here 2017 mzxokpgpqejzoexgzvydgqdltrgilnxqsiorjyrxgtjlrdxg
 * Smoking Wheels....  was here 2017 oicqosmwraxywwqxuoahwnuitvjxtvtauomrpoulxxexfqbz
 * Smoking Wheels....  was here 2017 ebuwluasgfpoaufqarhdkzfivlyrscpdklmadqjvjayjmcnh
 * Smoking Wheels....  was here 2017 flnlymydlsdpegxautlaaxtqfuwrswwtzxojlgaodnwdbgah
 * Smoking Wheels....  was here 2017 vfbuispilukcpudxntpofnztlkieizhacaapgxphaeiuvgmh
 * Smoking Wheels....  was here 2017 kdmnatqtvypgxgsjusaspfujhattjlwgqekwmhfbzazavifx
 * Smoking Wheels....  was here 2017 okbnsywdixdsxqotobhqethktptcwpubuznphifbiguxjcqz
 * Smoking Wheels....  was here 2017 fjiajakkzrrdqixrxkdsezuecjhigapgxiklfeftnjxrainp
 * Smoking Wheels....  was here 2017 lrdjewqvzmdqmvgygpqozcybvxnrzmzypiigxibwjctxrcvc
 * Smoking Wheels....  was here 2017 sdleptdwxwqmzyiqftcdippusxwrybylvjvghjviwnakisub
 * Smoking Wheels....  was here 2017 pxplhatennrdztddrgaodcvjtjzbfbrkratupiyjhuocjtwh
 * Smoking Wheels....  was here 2017 ajdggkpuunxlnpwautggroayfovycbspnfbohjzlclojhzvz
 * Smoking Wheels....  was here 2017 ccwaqvbxaafkyzzcycuwietbpynoevteaadkawuhcgmqzmqj
 * Smoking Wheels....  was here 2017 faukymsyrotiwshmtkxhujxjshnkgltkcwmnuolxiezunonc
 * Smoking Wheels....  was here 2017 bgfiwukroxaraxsndagrbvpwnolhlfzyvhwiujjkzlyueuza
 * Smoking Wheels....  was here 2017 ldsxhkharaphoumufqnlhlduhbggbsyppgjlkmcjppoxpyse
 * Smoking Wheels....  was here 2017 nhaomiqghdlduacdjbtfzmdoogcoqshmcvgulinkyifsocsx
 * Smoking Wheels....  was here 2017 sqfywrdtwusogihqfkhxuinwcwktbicwekcntptobsqycpfw
 * Smoking Wheels....  was here 2017 qfpyeyphgsvauuaqrcrsrqhtwxvojunlzprzofdadxsrqysv
 * Smoking Wheels....  was here 2017 emsthtdwjxmjnsotxsryvkxkdqibwtbzxgaxjjhgtmpcrzxy
 * Smoking Wheels....  was here 2017 lzismcdpnpoosriufejjstwgmoameylponkevmbyrdsvbtum
 * Smoking Wheels....  was here 2017 xqnndddaghfyymcwiozuaedapkikblrpwtlxxgocvxtqwopb
 * Smoking Wheels....  was here 2017 coobzgbvhtxzbevhbfdksitsmeyorpypypwntpcxozpmkzvo
 * Smoking Wheels....  was here 2017 zcznzfzapyhmdburpvopzcbnmcuagxtmextrxsivjxlshvez
 * Smoking Wheels....  was here 2017 rxpfixgtndhlmslvhfibgtsxbrzblgwgeujgzadpzksuhdqt
 * Smoking Wheels....  was here 2017 nvlxlnnnovbfrzmwvosqgrnpyradbpfixrhlzfnflmbongkl
 * Smoking Wheels....  was here 2017 faukbnobktagovxeadhnypqnebmcdibfkcgqbgyvzkkairbw
 * Smoking Wheels....  was here 2017 qufycnohdwvjeqzgbrvcmjkybcjzazwvdajmthzxdpxlfgfd
 * Smoking Wheels....  was here 2017 xvnwunulanlovxdzizjajgjhbhuzhjjgrmwwqtlfrxzjabyo
 * Smoking Wheels....  was here 2017 kzrvpryznczdenemleffgqmixjfstnouzwjytimrofinwjkt
 * Smoking Wheels....  was here 2017 tibtdkvqllwpzmzbiqyvcftyrigxntqadwodhymndwvabtdo
 */
package net.yacy.server;
import java.io.File;
import java.io.IOException;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
/**
* Class loader for servlet classes
* (findClass looking in default htroot directory)
*/
public final class serverClassLoader extends ClassLoader {
public serverClassLoader() {
	super(Thread.currentThread().getContextClassLoader());
        if (!registerAsParallelCapable()) { // avoid blocking
ConcurrentLog.warn("ClassLoader", "registerAsParallelCapable failed");
}
}
public serverClassLoader(final ClassLoader parent) {
super(parent);
        if (!registerAsParallelCapable()) {
ConcurrentLog.warn("ClassLoader", "registerAsParallelCapable failed");
}
}
/**
* Find servlet class in default htroot directory
* but use the internal loadClass(File) methode to load the class same way
* (e.g. caching) as direct call to loadClass(File)
* This methode is mainly to avoid classpath conflicts for servlet to servlet calls
* making inclusion of htroot in system classpath not crucial
*
* @param servletname (delivered by parent loader without ".class" file extension
* @return class in htroot
* @throws ClassNotFoundException
*/
@Override
protected Class<?> findClass(String classname) throws ClassNotFoundException {
File cpath = new File (Switchboard.getSwitchboard().getAppPath(SwitchboardConstants.HTROOT_PATH, SwitchboardConstants.HTROOT_PATH_DEFAULT),classname+".class");
return loadClass(cpath);
}
/**
* A special loadClass using file as argument to find and load a class
* This methode is directly called by the application and not part of the
* normal loadClass chain (= never called by JVM)
*
* @param classfile
* @return loaded an resolved class
* @throws ClassNotFoundException
*/
public Class<?> loadClass(final File classfile) throws ClassNotFoundException {
Class<?> c;
final int p = classfile.getName().indexOf('.',0);
        if (p < 0) throw new ClassNotFoundException("wrong class name: " + classfile.getName());
final String classname = classfile.getName().substring(0, p);
byte[] b;
try {
b = FileUtils.read(classfile);
c = this.defineClass(null, b, 0, b.length);
resolveClass(c);
} catch (final LinkageError ee) {
	c = findLoadedClass(classname);
	if (c != null) return c;
throw new ClassNotFoundException("linkageError, " + ee.getMessage() + ":" + classfile.toString());
} catch (final IOException ee) {
throw new ClassNotFoundException(ee.getMessage() + ":" + classfile.toString());
}
return c;
}
}
