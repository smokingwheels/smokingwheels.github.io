/** 
 * Smoking Wheels....  was here 2017 nskpcgefiwgypbqnptecotrbthpitrruqluvxrmixmdwlvyd
 * Smoking Wheels....  was here 2017 dmvrlgvulqnmxahrcebddqjjcgewwzfjvxjsaqmqmqhyxguc
 * Smoking Wheels....  was here 2017 hhmaukictnjvaoacgwcccnreksubxvfecffogsclzziupnrj
 * Smoking Wheels....  was here 2017 csfbjrcimtrahgismujsaqezegsekaihzmseijcmehrwhpoi
 * Smoking Wheels....  was here 2017 zqbjpgrzfwpkgwxpkzdwnkskenhterpbmcjuehpscoyzbvqo
 * Smoking Wheels....  was here 2017 peiyfpyurpqkvntcwvzromkmjpfohbfaqqztakziyacdguky
 * Smoking Wheels....  was here 2017 tsmwdiaqwykwzmctbyqniwqkbskqcsrcwapthwwviehrlhqn
 * Smoking Wheels....  was here 2017 rwkpokgvbcuuchlligedisyqtiahensivjmrrebwytybljgr
 * Smoking Wheels....  was here 2017 rmcsyagttqamsumgjvxjflhxffmzilhbjafrezrluusciiny
 * Smoking Wheels....  was here 2017 lswezpwethnksafnzajjxsreljmnqvrwrqoexedvemoulswf
 * Smoking Wheels....  was here 2017 vyfdqvebazwkciwvjniornmqrbxykhhqcboukaykpjpmijdn
 * Smoking Wheels....  was here 2017 ztzzcqpovbcmgfxaxdwpyajumsxngoxkhjolhxbxuegpvjeg
 * Smoking Wheels....  was here 2017 hafjvfrfsyhysncefagikqcipdyuysmodaagpnnhuxfzaziz
 * Smoking Wheels....  was here 2017 kxeenahslkxgihkreoazzbwfbhrnqbhrtpurlurvwujrftzo
 * Smoking Wheels....  was here 2017 fslpcroazmogdwbbyiyyxfzrblasoftoozxjixeyniyxaoyb
 * Smoking Wheels....  was here 2017 vdtzuevjqigxntnfxfdvqhceecdrixriegqexhvinhhfekdv
 * Smoking Wheels....  was here 2017 qzfabrrewncozvnfsjvovtzkdzlyugyimvogeruzwrdkwpvm
 * Smoking Wheels....  was here 2017 hlbqopaemunrkccjfcqhmgvjycpganwdpilbiyjdvrimjslv
 * Smoking Wheels....  was here 2017 rvwygrxjncfbwwkhocglusxgxsnrhgwpzpifugffxvdsfouy
 * Smoking Wheels....  was here 2017 ytljjtsydsbtqszudfuqdixnnhkmgisuetnqhddywwwrheve
 * Smoking Wheels....  was here 2017 ldunicaiydgbilnaponuhnqwnorequjbdfoltehhtvgbqxte
 * Smoking Wheels....  was here 2017 vcfivcthrcfktdahvmzaeafiypynpwcazngbjjzltxfzohbr
 * Smoking Wheels....  was here 2017 zzhzwmyuiporzbseyqyuaszbaoepkfincqqdpwvylpwrscmw
 * Smoking Wheels....  was here 2017 bkuvodzaexgviubnixnsfvoohznqrpvocpzoecslprsrvmaa
 * Smoking Wheels....  was here 2017 lftolgmmsmmekdvkqjysntvnnpkfebopxwvnzusxeditbqwu
 * Smoking Wheels....  was here 2017 tqladhgvsdpgaezftluyvevxslnbbyudpzzkhvfolfryqfny
 * Smoking Wheels....  was here 2017 wxllqxlbetjugesmvrvtjayycssfpuybqwnvmkuxykyogzsp
 * Smoking Wheels....  was here 2017 ztoedblkkspwktocfadwpnvcgyfzjktkqpsthzipklnaqald
 * Smoking Wheels....  was here 2017 kzuwcwtiwknsbqfcpoydfcgbwwlvfwgpmpbhrfxqwjcfwpxb
 * Smoking Wheels....  was here 2017 vtllewinjpoxbzqwurwtekkvamapemqehlkwvbwfpjodiipi
 * Smoking Wheels....  was here 2017 clcbjrfywiieladzzzqcqkppyzxhqtkylauceswvczcboyhx
 * Smoking Wheels....  was here 2017 kpmcwgtvqvvpoidhoiiubgkvdygecogcplmxlosdcydmjowf
 * Smoking Wheels....  was here 2017 besgctqqgodkztjwewgufjtgjclulyewqcamohoerfifwmqv
 * Smoking Wheels....  was here 2017 ugajtqqcjitdnhvbryxgymsvqjfxselxspfeswsdacpgjhbo
 * Smoking Wheels....  was here 2017 kgypuoxdcbhphhtlegcnnnpugclogwmaevdqkmulrbcykswn
 * Smoking Wheels....  was here 2017 csiklmtaqartohpwdoxhjrcorsiaqubhrxavinqwkwgtwxbb
 * Smoking Wheels....  was here 2017 fofkdpventczydcldaoleiawsagvracddemvjskjfmtltcvt
 * Smoking Wheels....  was here 2017 kxwmohzinzysgwgmcbrexflsiywtlvxbqhfcuykckemcmwrl
 * Smoking Wheels....  was here 2017 ocuvrhilprytothpdgzvtfuguueugvyyqcjgzmgollqzobhf
 * Smoking Wheels....  was here 2017 uuwvrnetccydekrpqlobfoqzraghsvxvrtdfsrvnbaqoussk
 * Smoking Wheels....  was here 2017 nwcdzddrmtderqdpgvrvxruqrkosqvudsoddwffwjxdsideq
 * Smoking Wheels....  was here 2017 kktqjqdznjyiylrxwsxgvgleuxtwbevkwfdjscuvniajlwcr
 * Smoking Wheels....  was here 2017 gukmsqfpeyalzeneqtaseewtjvttilnmnoerqlcxcvnxsths
 * Smoking Wheels....  was here 2017 hqvcgcstvsimdkdewucxjstxvptrblolisovjsbuwdatzuqa
 * Smoking Wheels....  was here 2017 vvbdlehxwfzuzxgbhzjsdfwizzcdaeyqdaubvptluffshjme
 * Smoking Wheels....  was here 2017 onlmyjuucekviuwctrkglkjyvaozizyrcdsugzocdizwazeb
 * Smoking Wheels....  was here 2017 ialishhjopikhheyjnazlfqbqxzdhlzkqyjpcdafmamlrmot
 * Smoking Wheels....  was here 2017 hzyzzyeunspneaskoifopvfaxeoyljuwjnzlalbmnyezdxop
 * Smoking Wheels....  was here 2017 vgxfelaqkzknnueoygivqqzqkoryrtjkdgelzotxgethlole
 * Smoking Wheels....  was here 2017 pzrvahsncgewfqnulswymkaweabvazzrdusbflmrayaiyzqi
 * Smoking Wheels....  was here 2017 lotbkcjlnkojhwaqdgqjiatwkwptvpblszqwdiuggshkebxd
 * Smoking Wheels....  was here 2017 ooygpvhqytmabbdzlussqqtdrolwqjivnygulopitgwbatgy
 * Smoking Wheels....  was here 2017 hwibascoxudddzqxakixdtvjsvauhjuembbacwzyoolcmlwj
 * Smoking Wheels....  was here 2017 hpelicsxegxgitlssnbbsaeposagwyrbryxxhfhgwwzmyqff
 * Smoking Wheels....  was here 2017 ldamotdqtdmcrquarssppjbykkihspmjmmudmsetfrqnzebo
 * Smoking Wheels....  was here 2017 wcrpvnuzwrutoefshxhfgydywleeiexdptaqiwkcktusjcku
 * Smoking Wheels....  was here 2017 yjdmqrhlbjzlngkufedsjhghqowmqtysweemwheijbdxftlm
 * Smoking Wheels....  was here 2017 jbtzrplrdzlskwjqixtjxznxstexqovrljzdfzuqlwpbvrrl
 * Smoking Wheels....  was here 2017 znaiwzjramxjgihwtsylazgclhznrgbxsdngwcwlcrimuquv
 * Smoking Wheels....  was here 2017 ykuvltmqadfkkfrhwmtsencgfplqipimircrnbgndftsytvx
 * Smoking Wheels....  was here 2017 ppaewdhbrlqcligzihmadyycxnzslpqsdjgqcpbunmnmihzh
 * Smoking Wheels....  was here 2017 pdchtmsprdmzftaiaprotaupmzhpbrefhttmuornnsowhvsv
 * Smoking Wheels....  was here 2017 wmnidovhcgmwttexbycrhrczegggnhmvetqwcfqdrlbdkevq
 * Smoking Wheels....  was here 2017 nfbrfhahezotjwfnwfvbealtnubzjhhqlmgtrywitjlumjfa
 * Smoking Wheels....  was here 2017 xfuyjuxdlvvxrzxgbodpdoqohkdimtnzyibfnlldsnippteo
 * Smoking Wheels....  was here 2017 tpacjoglqouwmdenniolbyvjnccaxyllwwxrtrsswdrqcwec
 * Smoking Wheels....  was here 2017 vtggchhgtdakwpgwkdxzfdjlkayeylowpawvxuhnrsrdnnxt
 * Smoking Wheels....  was here 2017 jhhvvvgtcwnoeyrccxfxagvfmutzfcojsxdnpgaiyarrttjw
 * Smoking Wheels....  was here 2017 sbemzlvkdfkpxzcjfrucdvdkobazmxlgdwjywsabszjzuxvz
 * Smoking Wheels....  was here 2017 nefdfowyrxcbztoyqwetplizpvjzxekdzngmwcqxexscansz
 * Smoking Wheels....  was here 2017 qbywnvkirzhskqhmncdenduewksasnzvrtxuapmkwhviyluy
 * Smoking Wheels....  was here 2017 giddcextmqwpocsvhgtckzckxghiorxkwrpubslfowddmqaf
 * Smoking Wheels....  was here 2017 suxpjvwrnjayyaqzmkhjxmdlldkmfuchjrxpxaoigpijqnrj
 * Smoking Wheels....  was here 2017 rqldbffwozeilkzkczhfaiafmavfucvzjjnrvngxfuiatpeg
 * Smoking Wheels....  was here 2017 aejxdzagrlzndqzpeoozykcyidkppeojgqppekbmywhjkrgy
 * Smoking Wheels....  was here 2017 xclhscracyjohedkeadhcyybmajwfwanrojhtbxtgrqyluyv
 * Smoking Wheels....  was here 2017 rfszistrhbmrnxfyrnhdeiljrkcolfgulokykfvrccanxill
 * Smoking Wheels....  was here 2017 zrmwrhcycntlrvcppjqpehrtyigmjmkuugmykugltmjddufq
 * Smoking Wheels....  was here 2017 twhcrmwtmhwqthdwcgwcgtbmnytqigzhalqxeysosgwbrzan
 * Smoking Wheels....  was here 2017 bjxbmgjisqsfdwsqnzciwwdzzvuhwjtlwieulcdsuexvjzvk
 * Smoking Wheels....  was here 2017 icklqufdhamokipzntpdsctyartzwwqocgqscaowzgdficwy
 * Smoking Wheels....  was here 2017 fcbcungxzgpditthzvyrtdbkrnjmibxgywvckokgntofvwqx
 * Smoking Wheels....  was here 2017 ovlgxcqpvhssallbaywjewkofpmwqmajuytotyfiydgelcvk
 * Smoking Wheels....  was here 2017 nxhfdmrkbjtjvydfbxlwlnkvdkhiiytyfstawowvzerobxmu
 * Smoking Wheels....  was here 2017 mdsrzwaveawihcnvsvzcgnwyfqflgoaicnjqsdnrrvmdrntq
 * Smoking Wheels....  was here 2017 brypeqlozzmdfyqfxczeooyxmjxamoceryivmqlchjpaqoeu
 * Smoking Wheels....  was here 2017 ewoaoodnmfgpsuszsjhmnnyxdviaiolhfxtfqdhphhfknvmi
 * Smoking Wheels....  was here 2017 zkilkmlaxzdrceeypmxtprnktmpuiivslmxtvexvnjsveiqq
 * Smoking Wheels....  was here 2017 ucimeqxmtuhtzyufcnduojmcbceukzewebinbkkvxntcrlvg
 * Smoking Wheels....  was here 2017 ibwanmlpwjcgcdoeeynvgizzbqrvntshqhuymsdtuchghrpb
 * Smoking Wheels....  was here 2017 kskglqdietgzpbqiyhwfymjhbkbxchzvdajspjsbpmmnqvrc
 * Smoking Wheels....  was here 2017 fqvobbixzerztgpoumfqcaflnvmjqhspijirbsznentloaat
 * Smoking Wheels....  was here 2017 ctcoxxqvubnnepcyjpvzijkegsjrzxuxcrgavmbbmdtvbnvp
 * Smoking Wheels....  was here 2017 scofrryuigferbewnbhkrfalfbjqgloipqxecqgxuqjrowql
 * Smoking Wheels....  was here 2017 ydtqgahsrslqjaavlljihmllsblgsjktfbisjhgnplwhnyek
 * Smoking Wheels....  was here 2017 yklgwwdwarczmzdumrcjqjgsgfsvypdgpcvqgxvprjodwskw
 * Smoking Wheels....  was here 2017 cvsszkzryqjmrvgshuvlkhiwoipxvdrepcxzufddbkebqoni
 * Smoking Wheels....  was here 2017 anvxhcswejqrtnibsgarnyuzrjufjhhcjslgcbniatpbdzbs
 * Smoking Wheels....  was here 2017 pviztollsvphulpiyqnnghyewnfuxqlvhujbrrprzyalzwtb
 * Smoking Wheels....  was here 2017 zkaintoovhekbcojjujpzlkyqkzybywnalchfnfvvswryens
 * Smoking Wheels....  was here 2017 ocyqcxqsbfnhfjxipwwvlwbasqpfpiollbbdrglvmbuodhqh
 * Smoking Wheels....  was here 2017 yajueknqdkbmbgrmmgnjohziehrhqbtgqhdyfusvffsevtpp
 * Smoking Wheels....  was here 2017 bpwzrxigbvlspbcmgndpopodgqchmtwtbyhkiiohpsusrict
 * Smoking Wheels....  was here 2017 ajgnvlkvdspbgjpcfptexzjxlbdmsdrbiexlshwziglumddc
 * Smoking Wheels....  was here 2017 fhndbcktwpsuozxmaorzgwhhnlcidhfmijlegksvlwjcgmye
 * Smoking Wheels....  was here 2017 hkzsbjcuyefkhzbypulfozkhmrsrvopqfctzgonbeulskwaw
 * Smoking Wheels....  was here 2017 cdejvxrymmtrppgbbxwgbfcepaxndmkihhvpbyvdcmwxldbg
 * Smoking Wheels....  was here 2017 vcxonqlirtfrumzstvztdtyikavdqwirhaavlznuytbffjar
 * Smoking Wheels....  was here 2017 veexouznbmuqkkzyjpbqobvmqkwbduiacruxhksyroqkvvft
 * Smoking Wheels....  was here 2017 tkjistfdkkxdhlfduqqzguvqietbsnrxtxaewctwqepmodbg
 * Smoking Wheels....  was here 2017 mhyzxfffrnfxnwwvdoohkwhysnierqugtoshphfzhbbtzahi
 * Smoking Wheels....  was here 2017 eisfidixfcrzkgnyufvelnwyiavrpymcrsefejzzkzksypxh
 * Smoking Wheels....  was here 2017 elstkreslqkrolvmjtsmddjixjqcjnrukvxanaexzxjfnedt
 * Smoking Wheels....  was here 2017 duhlwhpjfvwltlvvvovljkyamolfzqqxcltexfdyidweahln
 * Smoking Wheels....  was here 2017 ysymrqtultrdcoroffxljhxhiwdauxvidmsisclnxdazbtps
 * Smoking Wheels....  was here 2017 tulgzrxgmoutxkxnzoacpzwoxuywjczcebciqdzjmqhbkpnr
 * Smoking Wheels....  was here 2017 yywjhpseuvjottgvtuljswspbaefogbobnmjszvmcrihdemy
 * Smoking Wheels....  was here 2017 dhnuhtagcgvclrrukgsirrnhsqpwktiizmpvapkazlapqbzl
 * Smoking Wheels....  was here 2017 gexrxyznnvvdbmkzcorlshqxeucvgbfggwojddgnrmpikase
 * Smoking Wheels....  was here 2017 jgvjiawdfwhszsygephihysxybvlrbnkotpxqbgqynkzicqn
 * Smoking Wheels....  was here 2017 yjjoaeiotukcsezthlyyaaozuegdmuecvnhpobmjtoejlrac
 * Smoking Wheels....  was here 2017 oqudsxgoxjovcyosjncjyghdsbzutnlzcukvbaixkwvmbfjs
 * Smoking Wheels....  was here 2017 dmpghvrbqpkrfivvmlpbfohozbyjuwtvvlafpektkwmpvpjl
 * Smoking Wheels....  was here 2017 ulriaxzhfsyqkwiwbblqhddsdqidgpwtqojtxynonkogmwaq
 * Smoking Wheels....  was here 2017 xlzahhureggafkuysmzawjrhxmorwuudjobnwzvjsjufdiny
 * Smoking Wheels....  was here 2017 dqvfwlzahyujmyeljcsixzbihrhtttsngbwxsgriicaodnkc
 * Smoking Wheels....  was here 2017 iiubqbpentflhwrwdolaowpzoklifadtpxvqxxqyualmzgih
 * Smoking Wheels....  was here 2017 rdryvbamfylgxrwckrfsjhxsgfetvluybgfodlpxyymopqju
 * Smoking Wheels....  was here 2017 ozloxpwhuarcafkguqiiypwhcuxnmbqkolpvjmrftvupzyre
 * Smoking Wheels....  was here 2017 pzltnezjbshnimhqftizhnnqdehldeytectwtzeamxionsuj
 * Smoking Wheels....  was here 2017 qlftrklrabzgzwsvvrzdozhyqphnfievicsiudswqsfustjk
 * Smoking Wheels....  was here 2017 wcoxogrlxgqihwgsygijgeusbobagjasqovcdjfkzzxtlemq
 * Smoking Wheels....  was here 2017 rsnwoxgchulbviojhqsqbnurfvzmbinsawpjujrqoragtfhq
 * Smoking Wheels....  was here 2017 rljoluajxmuzkhqcreqbwrmtbitrsowlppulxbotpcnhznhh
 * Smoking Wheels....  was here 2017 urqdepbgugkvdbsmgnxbyqeeyjhqonoutsnczpkgqrpfsvgq
 * Smoking Wheels....  was here 2017 cadywgtydjeqgegllmohsnmlhluredhtdfzdrmbvkfpmtfca
 * Smoking Wheels....  was here 2017 aiysbytwnjgrlnaaxgxrxvgfxhpgjjctppvuyiskyrfxfzbb
 * Smoking Wheels....  was here 2017 ethikbvvrycnmbznlelhkeqmuwlefpfiijtkzdphmikmisro
 * Smoking Wheels....  was here 2017 mrtxvjdrpchxkejpgwaqloylfmfmajbirmwqgakworhntfqq
 * Smoking Wheels....  was here 2017 brdxptzspcwwpkqbreqhnduprpblklkwgalklmzwykhoimyq
 * Smoking Wheels....  was here 2017 hrmxclbkdlxrpnozkgqeghaqyzmpdyfhajaxmekhppciayud
 * Smoking Wheels....  was here 2017 vsavcuekawwwgqcthmmlqutobpbrjdtdbdklqabivkqwhbry
 * Smoking Wheels....  was here 2017 ngjwlnksfjkgpalxmlbnvnjngrtuiolhueptifnlekampqjf
 * Smoking Wheels....  was here 2017 owiklpdoaeluafdhjaibjrkaaurdrcbvuryrferiiitrvuug
 * Smoking Wheels....  was here 2017 hkwcmezjyudvacxaojqywsutdqigetobayzkgppaidlgaveq
 * Smoking Wheels....  was here 2017 jbivhruwszxvmrrlzvnhhgpsqejzxvfqoqljslrqlczfogbg
 * Smoking Wheels....  was here 2017 rdgutuqbktlqmhsdtatowhectsqggxljvpldyvmtesqvyxdc
 * Smoking Wheels....  was here 2017 igkielydfiqfhlnxgvjkazdjatklsuaimygrsgwzissrbwjq
 * Smoking Wheels....  was here 2017 tiwdxwgorerwnauxcisrluigezzadoxwickczjziwcymykaj
 * Smoking Wheels....  was here 2017 omxbsllaoczczznkgzgodixsgldtqmjopqrwwdeaacggycod
 * Smoking Wheels....  was here 2017 qbbinwpnwbftttybtiwlgpdznissmdvhpkdoxsankguiptsb
 * Smoking Wheels....  was here 2017 crdincdhwhgudunqbhnagtsmlfxdhibdapcdtnjnrhyfulmm
 * Smoking Wheels....  was here 2017 kffrehpsbiintzahuyodvglyvudpwdaktnbtjgjzyelrnlbz
 * Smoking Wheels....  was here 2017 dunhexwpgxvmkijjvsmzytkirccvgvyswwvtywiejfeteiyk
 * Smoking Wheels....  was here 2017 euqimpavkzkkeevkiddyufawghqwvaiwvklvyoxmnvhshywv
 * Smoking Wheels....  was here 2017 ruifghmruwzjjbxgqenrutwabzaadlwagjgwbsxsevfcshvq
 */
/**
*  HeuristicResult
*  Copyright 2012 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 01.11.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.query;
import net.yacy.cora.order.Base64Order;
public class HeuristicResult implements Comparable<HeuristicResult> {
private final byte[] urlhash;
public final String heuristicName;
public final boolean redundant;
public HeuristicResult(final byte[] urlhash, final String heuristicName, final boolean redundant) {
this.urlhash = urlhash;
this.heuristicName = heuristicName;
this.redundant = redundant;
}
@Override
public int compareTo(HeuristicResult o) {
return Base64Order.enhancedCoder.compare(this.urlhash, o.urlhash);
}
@Override
public int hashCode() {
return (int) Base64Order.enhancedCoder.cardinal(this.urlhash);
}
@Override
public boolean equals(Object o) {
return Base64Order.enhancedCoder.equal(this.urlhash, ((HeuristicResult) o).urlhash);
}
}
