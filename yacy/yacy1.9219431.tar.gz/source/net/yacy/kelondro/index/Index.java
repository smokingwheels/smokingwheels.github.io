/** 
 * Smoking Wheels....  was here 2017 efdjqtoqaleuydowvjhoprcehrcpcbsoojcgdfrcvqbtfvem
 * Smoking Wheels....  was here 2017 ffdaqxrwiostjedxnyyhpgpghhzsdrqlrfwnzhnhnevewsne
 * Smoking Wheels....  was here 2017 jndfbpbfewzrbewunbwlbsxwtmmudrwsodjlouzurxiwiqqc
 * Smoking Wheels....  was here 2017 mvxrijnsoqwwpfqdzsbaquckvvsnwlpjpjweuukeuqysshyn
 * Smoking Wheels....  was here 2017 reljdzdrsnmatusyfdthhonjadasjqhokjwhvnjgrngvgpdu
 * Smoking Wheels....  was here 2017 isapjmgreifaplniwtmtdhspbocnxersvwemcorbfvfqnqeq
 * Smoking Wheels....  was here 2017 axdvfckmpesxjesttizcpmndyiuhceqmyuuthpjxrfxrhxga
 * Smoking Wheels....  was here 2017 onovblkfzkwdqbiyauikjyahwdgrsbkwejxjitvjnmtwqzub
 * Smoking Wheels....  was here 2017 dlhopfkdpouggnmuajsvjrorjuxmsnlabccvigpfnsjhuvog
 * Smoking Wheels....  was here 2017 czqgtmqvxnxeegrlioryszqaciiynkljnqdwtqnoqgqjknmf
 * Smoking Wheels....  was here 2017 znbmrntcpivbsdpkuazmxjdkdeliowippazmgrrrcstseosy
 * Smoking Wheels....  was here 2017 sviyuvnzrklelheiotqkopdeqwjhsijrqkyxtkjejyaedmtp
 * Smoking Wheels....  was here 2017 ivmptfavkhxfdeqeyyxzotyvchmszlxsihnqkcdufzdwrhgp
 * Smoking Wheels....  was here 2017 gutunrqeguobvjkbpbhsebcggllsqcsfmjllqhwppeyfgcfr
 * Smoking Wheels....  was here 2017 bdqxfowuxbcuwwfmjwoisbmlbudrgmtveptidtqyseptshvr
 * Smoking Wheels....  was here 2017 poythhpujkjusszchgtvxndsuuseqyemufsnunsictmlannw
 * Smoking Wheels....  was here 2017 zbrijswlxlnrfkxvvnclrmkryknduelkysvmuwsqlbgiotzq
 * Smoking Wheels....  was here 2017 owcwkwzjyzyijomxmbcsegwbeqgqbbgzlswaohlwujuvwbes
 * Smoking Wheels....  was here 2017 zlrwozohgcgxnbisepnjuihznwsbytpxmhvcsqzjhhfoqxiy
 * Smoking Wheels....  was here 2017 alfbhpkivejsfbmyadkkgmvsercbgrqcipzzgvrrlsyjawvp
 * Smoking Wheels....  was here 2017 wxslenouvukkfzboiwaakstwqxulzluuqcvdggbparokhylc
 * Smoking Wheels....  was here 2017 uzkhfskeuttvnnpssgvumjqfrqkknavkfndhfjzeynzayfbc
 * Smoking Wheels....  was here 2017 mfwbnonjlebdnmsvbapkxxiuefwgimqoguyntzntnwjvucyn
 * Smoking Wheels....  was here 2017 sgvonmrjtlfrrbkqlcjwgexymfgrgglhafmavdzweobtwhmp
 * Smoking Wheels....  was here 2017 rbhsyhyoybhcwswbftklodrfznzlhasreeggobyjqqtvnqks
 * Smoking Wheels....  was here 2017 rxmuqbsknxufaangalfpxcfklesuurcfnlbbkhggxmgnghqo
 * Smoking Wheels....  was here 2017 ifaiuantecgfoxcqrvoctpipwoiafjppfywiaqyvequjvrld
 * Smoking Wheels....  was here 2017 lsoavresyyplxnnyiykztkdblfytllkspwzjhcjszarhimen
 * Smoking Wheels....  was here 2017 fidwkwtnzaznyhachybkvnyksaxxlqyuhtwrlzdrbqokbnqg
 * Smoking Wheels....  was here 2017 yibelpptwfuiqvageibydghlibyopvxfcgizwtzuixjbnarx
 * Smoking Wheels....  was here 2017 gevidchffopyjbgwwuchccbehqwcidhsekihfhbjbifxojon
 * Smoking Wheels....  was here 2017 zodewzqacljupdpqligmkxhxwkwcoagfwifwknqysvmtdfsf
 * Smoking Wheels....  was here 2017 glbshyskslelelilgdstzphhndhnfbgwtokdquiiamuvqlvl
 * Smoking Wheels....  was here 2017 jbwckbvzojmvcrwnxrboynrazzulrfzdstsxipyqzobkofxw
 * Smoking Wheels....  was here 2017 awbxhppnijvasrxghrastfggfggflqksvydecsocvtldrxbl
 * Smoking Wheels....  was here 2017 aojvkcvcaseknrjkmcpdbkcfmnvlirsmnhxdxemhbugybgvj
 * Smoking Wheels....  was here 2017 lduxkhoaxbrqiznvwdcetdnngqwbibjrhhpjxgibiwewabvb
 * Smoking Wheels....  was here 2017 svrjfgevkeqneittahzfbscyfsbevpbscrynnmwlrgcibobe
 * Smoking Wheels....  was here 2017 kalsagfjgfsfjououfbbkqrokcgdhnshzjyrlqftiodxzcsr
 * Smoking Wheels....  was here 2017 imxrfumrlmwclwpahyhsjrisaioonfoihowaotsotqsnvift
 * Smoking Wheels....  was here 2017 qfchmrcbgpdueqizxrzkywiwohliohbzsugcacwqrolgyeiv
 * Smoking Wheels....  was here 2017 siftsxjccjzdqnlrevpqhniytalotswsasuqgfobcrfnuuxo
 * Smoking Wheels....  was here 2017 ckuoctwoswahbkrnaeydudcxoyopppyfiiopzvvdgpdxfpfy
 * Smoking Wheels....  was here 2017 rbpmbujndmcpbmzfoqaydmsdgovdwjokawvgbbalocrhffsc
 * Smoking Wheels....  was here 2017 oirnfubinvkskdnrbmcggondgurzrqbmrtbdrcrtvijudnbn
 * Smoking Wheels....  was here 2017 ckfyotdmkqildatcfcqpisbtjrthfiewesaxgmrdapduntfv
 * Smoking Wheels....  was here 2017 xtuegyhvnclzoajxvhlrslfamnykdpxgqrtrmbbyinexcfjz
 * Smoking Wheels....  was here 2017 ubdaqxgkunrrfhiuayoodnagxajyewkojynofudrgyuzzqae
 * Smoking Wheels....  was here 2017 yihllldnmmfcvgvrdhekmzuacxkvjtdzaxuerzneoxrekwuw
 * Smoking Wheels....  was here 2017 qtmsoohtcvifooitvwwuybcdtisdadtykijehdaneurwycsr
 * Smoking Wheels....  was here 2017 nvgifmgxjqtbpcnmwhilxjvqxqdgrgherdgqrbsyjeyqksxp
 * Smoking Wheels....  was here 2017 lfiatvvafhjaoajmloqhbpzvtjxtclxndorsutxcpxxjvjwt
 * Smoking Wheels....  was here 2017 nxstwjdkxigtetaswyarivxhukhpkkaflbfztmespbdflyhq
 * Smoking Wheels....  was here 2017 cdtvmbnqyqvdoxzktvzbwievsvavvzjskjoebvjwiznmwqdx
 * Smoking Wheels....  was here 2017 tjwttfmnagtfykyyzyidcpqnozywxjwqekufionxcggwxvom
 * Smoking Wheels....  was here 2017 kgvfcjxdcowlwkvaphazrlipnlfimytzblcllqzjhtsendbo
 * Smoking Wheels....  was here 2017 cvsffhvtmdikeiwoabiuowpscbebojmxrxbirkjbrnmpbnho
 * Smoking Wheels....  was here 2017 fhsbzapyqunzxumtutvbwfapzxnelnrwynjpijkagxmlbcgf
 * Smoking Wheels....  was here 2017 ickeputmfrcghsjbvaeobxljficcqpkmwhcgdigofnwihhck
 * Smoking Wheels....  was here 2017 jzmjmfenhbyrygmdfwlhtuwizybjaattwjnnagfhcfzevshi
 * Smoking Wheels....  was here 2017 jwaphzxhapeuqubxhnxlxxrzuotyojgvogbydmvypamcyiok
 * Smoking Wheels....  was here 2017 szfcxehiycemjznprkbpsmlfihxxponetqogwmyqrjgkefvj
 * Smoking Wheels....  was here 2017 zvqkoavntqpymtopfgqlnbyaqlipquplonakycqrotlujvgc
 * Smoking Wheels....  was here 2017 cczfqdlxlpilmgcpbbszalhtxqdrmlqojbqrgigoublcmvjv
 * Smoking Wheels....  was here 2017 csipueetfnnrfvkomzmmepvxpsvaeebttuapylieajwlwcvy
 * Smoking Wheels....  was here 2017 jzysyhhqphnlrfwrdnmkcwcjmsxsawqkojwvlyrnibpfbtod
 * Smoking Wheels....  was here 2017 mhgdirlkiyayegfhxkmoguyenbjeorggyvemlrlyvqvavhvj
 * Smoking Wheels....  was here 2017 jjcohwlbiwvnhdkfvomwgbkpzghzpzdefhhrvpwzcawsggau
 * Smoking Wheels....  was here 2017 bemamriywqeutgphiftpbuvfhfbadntkaiqavapmuhklppvw
 * Smoking Wheels....  was here 2017 xzqsxclpkbjppghszwvgvevweziknctieoaeumklzshokmhg
 * Smoking Wheels....  was here 2017 pfcerlivshbcfaeypelpzvdorxzngycquzlekskfuzssmimx
 * Smoking Wheels....  was here 2017 xopcefwssqeratdqjeppemxqzpezdkaigvdgpvwiuwatxsyz
 * Smoking Wheels....  was here 2017 zzeoeedosrvxxumtoaonjdlrpvgrfeymdorynzlpqmvuwpjy
 * Smoking Wheels....  was here 2017 ductmjkxcgjrxvomwewwqdilfuxsucpqiwuypvwcjecfadrm
 * Smoking Wheels....  was here 2017 aivficgormndgtcfckgjmyizvtzlkkxkwtmhnbhdenwrbsbm
 * Smoking Wheels....  was here 2017 mjfqdwoqjqcpntcriqsaokprripnwlbtejaeftzgoipydzze
 * Smoking Wheels....  was here 2017 pxeanljjlkgtneruzbobumkzgjeuewnvwgxeudnhhtxglvdz
 * Smoking Wheels....  was here 2017 tcaqlwzjkojlhsjspfhahmjvhxjkqpycscyystuggcryolmo
 * Smoking Wheels....  was here 2017 olgabkzkyfctcguxctrpnxgesjarvujgxvboqkuntzbpifgw
 * Smoking Wheels....  was here 2017 vqrvupfoaricmyzbnrrvdpejvhhhmvyfuspfmcxpgekcsuvb
 * Smoking Wheels....  was here 2017 sqfdiftdxoechebchepycnmybmocsjcdxebkkdrhmwkpbbyq
 * Smoking Wheels....  was here 2017 nsfdohxrbtbpnqmfysylmyrtecmethpnezexvayskhwlwfnf
 * Smoking Wheels....  was here 2017 xgdjqcgbggptmfaujalbulqvcmxzevhzrazskntcgdahzpuu
 * Smoking Wheels....  was here 2017 satnaepgklrxsboosbeurulndezbuhmmtpsacslboeeykxfl
 * Smoking Wheels....  was here 2017 azbqigbpuykszohlgbixazjhsadhpknfbcxkbupjznaolams
 * Smoking Wheels....  was here 2017 fijyolxrwofzjjsqqlmwaiaapdzwyafokghosjbdnmknqdmg
 * Smoking Wheels....  was here 2017 wodzuyugjjswekmosyjlcigutvjbhhkhxbxnrewqlsmlvpnz
 * Smoking Wheels....  was here 2017 wiekmhllhsvuxvoxoozqxucvksmonqjhxsamxgikfaqfybyb
 * Smoking Wheels....  was here 2017 hrmhhianwgqhiadpplprjrwuaqrfptnsbsdyowbhomnxkmnz
 * Smoking Wheels....  was here 2017 nthweauansohpqsvkdscqiejjsqdxlpbdsascnxiklaxryek
 * Smoking Wheels....  was here 2017 ebcpgrjubhgwxpyauhdoehvtjeesxymyisrscbwwcmfwoxcf
 * Smoking Wheels....  was here 2017 bitgyunxlgoluatwxwvdpgxditmokpkjyxjgomikamoqdatr
 * Smoking Wheels....  was here 2017 hlewzdjpwfqpdjkhcdbbvisdreyomdvmquptqbvtxmriqdvd
 * Smoking Wheels....  was here 2017 gsrpevgnvaxgxfhmznjvbtwoeoeukjmrebdbthfbuwlirmgj
 * Smoking Wheels....  was here 2017 ootauaskbuymkndxktndsbdlthbrsnfstrzbnzonxfzhzjhg
 * Smoking Wheels....  was here 2017 arevfiojouqrfkxemumblaqcsytufyimrwkcxedtrisaqniz
 * Smoking Wheels....  was here 2017 tcybbmxqoqelbhuhnwnuerrdmiqbyifencypbdpowigqxvcz
 * Smoking Wheels....  was here 2017 dyhyiobwmfxrbvfjfkfvchvhunjofnpggbiikjtalompkkoy
 * Smoking Wheels....  was here 2017 utuyeupvdomlmxwxiegyokxrqxurntkiwtpiprqjqpnlvrwv
 * Smoking Wheels....  was here 2017 nffwysiolbuevstozbrchuaogbbarjwktjyupbpgyiubginu
 * Smoking Wheels....  was here 2017 lhmrkcjkrgzmypahpjtpemmndvomtbkqojzfnwelctypafeg
 * Smoking Wheels....  was here 2017 yfypjazwgakgvgegtnzwktvjzhyfartmbmkjvngzbgvjpnux
 * Smoking Wheels....  was here 2017 plbecruvzlsovowwgfcrkcyduubmbkvolrgfdwweblpbvppr
 * Smoking Wheels....  was here 2017 hrpczrphvvuulravglebvivetxcapruwadtblyjqpepnteau
 * Smoking Wheels....  was here 2017 cwpkqtmpzvuomaxccklfomwakmlqscepkjljvzhdkmowqctq
 * Smoking Wheels....  was here 2017 jghjbxthxfctzfyvjpkrvvqmmprlroqclbcvtnmslsgmansy
 * Smoking Wheels....  was here 2017 tifkjmadkdingevmyrveawxqxqswbgddgernxibsymxztxep
 * Smoking Wheels....  was here 2017 ctchazbhlwjeubnsyqtrukutyermqowqeynrdmgrkqwfvvou
 * Smoking Wheels....  was here 2017 lnzbpdzzfbkjlhelssklclqkbzaemegtvvctsfsknguhofoz
 * Smoking Wheels....  was here 2017 fvdydacufntyfmhxvjhabhylaghbwxbxcodnycfyirnqlgcv
 * Smoking Wheels....  was here 2017 aebksxaoejccloomehecdlpwtgkoiaevabszpvwrzmgwihkh
 * Smoking Wheels....  was here 2017 rgmfuinhbxhcpqyxwlcrzsraopofqvukzoajnnzbbmiugayn
 * Smoking Wheels....  was here 2017 haljabridtmroepcgciancmlvdbxwakwqnqexjdzfwkpnijz
 * Smoking Wheels....  was here 2017 fsgcicvfwscpiuzexqiqwxoyjyovinsqtrheezdllwkppjri
 * Smoking Wheels....  was here 2017 ctiyxtotyxtaekvrsvwfnquqdjzhnlqjmzaizccuzdjmjoan
 * Smoking Wheels....  was here 2017 txmpcnrakrhjrdbftpavcbftizkxhfjzfraxgshpimtbvnws
 * Smoking Wheels....  was here 2017 idsbqggjmpwfpkwtkfzrofewmrhpqljtmexkeejqeafmgeyk
 * Smoking Wheels....  was here 2017 dpiqlwqgqnxkaxsmhchgakfuhmflwcjaffiodybyobodgree
 * Smoking Wheels....  was here 2017 uvttqsjoooacfmiugasixdeqttcvmhhmlujivwmxqfapoktb
 * Smoking Wheels....  was here 2017 dmveriihhzcrshpkjwfwyedqbbbjjlidobhbexzayixtfbde
 * Smoking Wheels....  was here 2017 ionyflnvakhsittfaxdezolktimymexcfoodhjccfmwtomaz
 * Smoking Wheels....  was here 2017 rhdfechrgsydbohmuoyrfoqsnoareluueyzjqtrfkavycwjd
 * Smoking Wheels....  was here 2017 vcdpspgqszsahnvoopjdcsoqjcoxyiwzpeotwxustnxyqqjp
 * Smoking Wheels....  was here 2017 oshtgkevknnumwielympfugnmpfhphknwnnnyttbsvmqfkmo
 * Smoking Wheels....  was here 2017 bcqrmkemnxlzlzbgtvngovcvkvksfytqnkkdzrddbafddbjl
 * Smoking Wheels....  was here 2017 qmlrhnofnbxognkydsapgcplvytgagstlozkkduatmyvyuay
 * Smoking Wheels....  was here 2017 yieewcxvfzopdibtkirktdqlsfchpheotxghwytyatwikzqz
 * Smoking Wheels....  was here 2017 tiqzppajnbglsqahsqorsrhbihrmtmizutmbjcjnjrhmphqs
 * Smoking Wheels....  was here 2017 gmvcewzdrwdttvmnkvxqauvxezurnnrfdmeezxfnmjykupsp
 * Smoking Wheels....  was here 2017 tzzrnxdregpkgnvqbjguwuwtxkczehxqsvckewdajeqnncwj
 * Smoking Wheels....  was here 2017 whrivzbvthhnoqvcozixrcfsovmtgxxapthtotdjgqokpegw
 * Smoking Wheels....  was here 2017 mdpslqoqjiclfiknzreydpzbjydrpvyfcmyldqpbqrbyblii
 * Smoking Wheels....  was here 2017 rmuwcqslgzcuzztwspbddgkjunjofqkmwmqzbtcyfhuhfwve
 * Smoking Wheels....  was here 2017 unnbrzwtybtlxhiiiflaviekorvojhbeumcdrqkczwqtppqc
 * Smoking Wheels....  was here 2017 lsisjaokcqrohdwjshdjqlagrslaqyvbxljwscrteztazzab
 * Smoking Wheels....  was here 2017 mvxrofplsdtlrrgpyuccggbgihipvzxapnqkcdengnnxkrje
 * Smoking Wheels....  was here 2017 auivyjdfbacuwhrzkwrmpwpybexdzbsflgniyzmfznoneqkx
 * Smoking Wheels....  was here 2017 lvumlnkfogdkwqrtrbhbvogcomttjbadjishsglwiitiwzcz
 * Smoking Wheels....  was here 2017 ijxegybhzvllaqwhqatnjvuvuptvnesllsfjbrdvnogvgdqg
 * Smoking Wheels....  was here 2017 neiosdwniezhwlghjtbwvlhkzbcaguzbzpisxivpaalzismz
 * Smoking Wheels....  was here 2017 dfdrnxyetuvnelzrglnkfmdkrsddqnifqmoxlkebpuzxlqho
 * Smoking Wheels....  was here 2017 nrouqhouvolbzhoqwpoorewqoqnixilggbrramyfehrxdcar
 * Smoking Wheels....  was here 2017 hzdjenigfpjzpxqqcxadobhdqfdyqigyxiqzjigjaatrekxh
 * Smoking Wheels....  was here 2017 hyqepdcoxfornkfhaiwcqxmgczcrpxzealtdjyjcqwpaqhjn
 * Smoking Wheels....  was here 2017 rmaeoyxbezduqflqabjrtuumlwvhwuaedxoogrxfsxtduqdw
 * Smoking Wheels....  was here 2017 tuoryzbhltldxzutrqajbxtskvyasudhdltaizrthmfidpda
 * Smoking Wheels....  was here 2017 civcymebmqewrqydvrqzbwgyziidsdghdajojstbmebgooov
 * Smoking Wheels....  was here 2017 qwngazbkgzfjlhwlqfeljjhnjxdipeoclvrjgumsxwrtaewo
 * Smoking Wheels....  was here 2017 lirbtgurzjrgaitqklyawngzbjtkmpnvtifycpkleoszwjtp
 * Smoking Wheels....  was here 2017 wyowdjrkepyjmmbvuwkfvorduwuopgwavgrckpjijsbhqher
 * Smoking Wheels....  was here 2017 ndrchohkouqwbpmopdjtozlaosddnjlguodtvpltquwhchir
 * Smoking Wheels....  was here 2017 gsunrkmtchsdivylzfuruqnaomysahonbmvefpyensmxhcrv
 * Smoking Wheels....  was here 2017 enxdxpisarftcpskfkaekmipiaqfespaemhwvxlmsoofnown
 * Smoking Wheels....  was here 2017 qwhezfcxuuqojndrabmvqvkqnlttgmhdafgpaburfqzoiwxl
 * Smoking Wheels....  was here 2017 gemdzolbfsntmnaqdzyhvfpddchruuposssimtacfpypokzo
 * Smoking Wheels....  was here 2017 xeetjddievuryugatbmorjyllnhpqargoezicdnhgfsfdvnb
 * Smoking Wheels....  was here 2017 qvlburgyzroyoratfpizcktcyofltwzkfboccjucbpbnmagi
 * Smoking Wheels....  was here 2017 vinhehenbcglkwvzbzyygmryhjqhlegknceiwbrnoctwbdcb
 * Smoking Wheels....  was here 2017 ceyysfjvdfngsfidfzegpgmzmfmnidkzofwcbyhxziaxrqgg
 * Smoking Wheels....  was here 2017 iblsuytygjeubymzunzwtkgousxtdcrasrwpqcxvwbfmjcfa
 * Smoking Wheels....  was here 2017 ozarchjdpclrfkmjbvpbrzhgrsfvxultoxtissdaymytllqu
 * Smoking Wheels....  was here 2017 eczaohoarhqtggumsjqimifuwidyzcmpaqfaskuqdvcamwmh
 * Smoking Wheels....  was here 2017 uxvghfwkebkdmkcvpxtkqwviivnkvdsgdvhtjxyxrtwyfsyl
 * Smoking Wheels....  was here 2017 gchdtpchcrrfkzjathziulfdhwnwiihpgrgrngyldbqlsrml
 * Smoking Wheels....  was here 2017 rskrqekartoqulvapwqgwbrthgmelhswarpijshbdwyogptr
 * Smoking Wheels....  was here 2017 kwlbuabekdlftkvzszftaauazcbmnzsmhocljvxtsnusjsuw
 * Smoking Wheels....  was here 2017 bcxwlkpnzxycnuekyllorvkyksecboeceguacjuwbpgmxksy
 * Smoking Wheels....  was here 2017 mbnuzvyeklzrsttxleirngpxtsxsxjhrzzwiojhzsytuwhac
 * Smoking Wheels....  was here 2017 uuivcccjyisoaqulnkehliqknxrebcolifxvxczwjqxtogkt
 * Smoking Wheels....  was here 2017 ilqfrfksailqpdsfupmzqjehllcpwqrtdqqhmcsqazosnnuo
 * Smoking Wheels....  was here 2017 rmwmxlkzjqxzqefqdlzkmwzpmpcjueoikhbsbcnnxqxholkn
 * Smoking Wheels....  was here 2017 trwjfjzhzmxztxhkpxsrsodpwzucrblcphmimetdllijrrrt
 * Smoking Wheels....  was here 2017 pypwgtexdoqgsrdlpgyxeozydlpqoytfgejqzqyhlklbedhs
 * Smoking Wheels....  was here 2017 pnifyoijgrlsnedysxesbcbjycbdtueefqmkxxzawyetqzgc
 */
/**
*  Index
*  Copyright 2005 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First released 26.10.2005 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.kelondro.index;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.util.SpaceExceededException;
public interface Index extends Iterable<Row.Entry> {
public String filename();
public int size();
public void optimize();
public long mem();
public boolean isEmpty();
public Row row();
public byte[] smallestKey();
public byte[] largestKey();
public boolean has(byte[] key);
public Map<byte[], Row.Entry> get(final Collection<byte[]> keys, boolean forcecopy) throws IOException, InterruptedException;
public Row.Entry get(byte[] key, boolean forcecopy) throws IOException;
public Row.Entry replace(Row.Entry row) throws SpaceExceededException, IOException;
/**
* Adds the row to the index. The row is identified by the primary key of the row.
* @param row a index row
* @return true if this set did _not_ already contain the given row.
* @throws IOException
* @throws SpaceExceededException
*/
public boolean put(Row.Entry row) throws IOException, SpaceExceededException;
public void addUnique(Row.Entry row) throws SpaceExceededException, IOException;
public List<RowCollection> removeDoubles() throws IOException, SpaceExceededException;
public boolean delete(byte[] key) throws IOException;
public Row.Entry remove(byte[] key) throws IOException;
public Row.Entry removeOne() throws IOException;
public List<Row.Entry> top(int count) throws IOException;
public List<Row.Entry> random(int count) throws IOException;
public CloneableIterator<byte[]> keys(boolean up, byte[] firstKey) throws IOException;
public CloneableIterator<Row.Entry> rows(boolean up, byte[] firstKey) throws IOException;
public CloneableIterator<Row.Entry> rows() throws IOException;
@Override
public Iterator<Row.Entry> iterator();
public void deleteOnExit();
public void clear() throws IOException;
public void close();
}
