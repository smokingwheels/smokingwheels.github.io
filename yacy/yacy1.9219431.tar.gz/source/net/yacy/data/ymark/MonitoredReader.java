/** 
 * Smoking Wheels....  was here 2017 hccmyubmoivlgndbavqmzqmodvwpyjeblktxpkupttqcnjzk
 * Smoking Wheels....  was here 2017 cnaofaqqnoxpmuhhktncrclllqeehzqsiozylwwqyygciedz
 * Smoking Wheels....  was here 2017 eegrascpbobvwydbvhxrgfnjhfykhhftfyectkofvfxnnubc
 * Smoking Wheels....  was here 2017 ohsmtrdcyswymzbfpzxekbsjpfxhgomhvjsomkdppkotrroc
 * Smoking Wheels....  was here 2017 qlmydbtfdrcaqcqxkozsabfrqpcgsghuywgvunbiutnhnptr
 * Smoking Wheels....  was here 2017 blzhcedewktjwurobesvhsnwymuumctvturodnzdeqizfnyq
 * Smoking Wheels....  was here 2017 shxxuqtmsadpauiusabeszhqfintqdeippdsfoyarttxzrtf
 * Smoking Wheels....  was here 2017 rhdnrhiyjztncbxmtserxxobmucfmmdkcdbmyadhoavjknas
 * Smoking Wheels....  was here 2017 iaudlhunvykflwautakpvwmiztnnptnmdlbimlaljpuziwvv
 * Smoking Wheels....  was here 2017 hghwzykmivbaqqmbqymiqlozelaetokdvvcyhshgvwfoupmk
 * Smoking Wheels....  was here 2017 laifowqikvcllejzmvfqvnmuwffcaydgotghbyyrxnweczqp
 * Smoking Wheels....  was here 2017 xpuvnydwthyjzkbjsfvkaeguauvhsdgbxcznrneawnudvncu
 * Smoking Wheels....  was here 2017 aputpfyckylwmoclwwswevaexbwdjpqvtxydkzltgzfatxyp
 * Smoking Wheels....  was here 2017 mttbrcfgprpfodjnxvnlmzinzerdvbkhhkzvpfmssisqyenz
 * Smoking Wheels....  was here 2017 cciiaflwvrrbzwyhxldwjpvozpsednvhuehnzhhwhgacsmlz
 * Smoking Wheels....  was here 2017 zzkdaijrwjfevsepfesbmrnizzuhpfoyyzhlmqzlhqfspjob
 * Smoking Wheels....  was here 2017 oweniqxsrjaqlyqpmwqgvrpadfyvupkroypahvcacsnbloxu
 * Smoking Wheels....  was here 2017 kqarylhgmqbuizerpopvndoganljmjlcvgdzvsjhovnyhzvd
 * Smoking Wheels....  was here 2017 lhpzzjauvjrfipwmrompbybrigustpbdcnagujsiprylmyzd
 * Smoking Wheels....  was here 2017 scufxhtclxismubwajmkbedkbduyyluwynsabfijnevxnwdh
 * Smoking Wheels....  was here 2017 qrthlgmehzwjctjajvxmmeyqmbmjolnshivtxutytmmxgmkd
 * Smoking Wheels....  was here 2017 wsyklrkgrngmtzphmxnioqzwcecqlghigegdszqtcbkfrvdp
 * Smoking Wheels....  was here 2017 fixzedaxbqurgeviozdoqhzyqyfmrxnoeqedexzwonjyfbxv
 * Smoking Wheels....  was here 2017 uuquzmawftasqjlaxoxfmjwubzozmqsosnzyfxzoivklisof
 * Smoking Wheels....  was here 2017 brhsqwkdcpssftamfkikzcwsrgfnmxttsviaaochydvgvmfj
 * Smoking Wheels....  was here 2017 nsezaoiazaxzovjdhqyqhfkfyxkrmlsshwcaaubvdvcfvkee
 * Smoking Wheels....  was here 2017 dzbbighzifvdmhpohlsoxlhbqjsfogziwfmzxqvfxpbjqqbu
 * Smoking Wheels....  was here 2017 autpztzuypbyaebspmuenakfshwfznbuzqwapnqsmjsctrrp
 * Smoking Wheels....  was here 2017 mrlpsekluwimnrjsulorzeaalpxbhtwloewpiyxujihxahcg
 * Smoking Wheels....  was here 2017 fjogjwtgcxsdmhhxulrmnpoyilcgjsmysdllmwkgjvkrmlsp
 * Smoking Wheels....  was here 2017 aasyflmrkwmkutyyrsbhpdttcharfheevbsmtjbcjqulmjdu
 * Smoking Wheels....  was here 2017 cvvlqtinkfddlzstvwvcwwomtukjevqhmscybtbpsolooncf
 * Smoking Wheels....  was here 2017 tjbrjygudpmlthdlwqkbhefiovhqtsqqpdfgqrygwvrpnrun
 * Smoking Wheels....  was here 2017 qmuwhhmsvynpidbkrcmrzqewzpyduthwgracwzjvowajktno
 * Smoking Wheels....  was here 2017 pdrkpmlvzjnexfpgknwomcdwtmxpjwxwvvqmluihuigyobwn
 * Smoking Wheels....  was here 2017 uqqasiwxijbbpocxjmusjsbgyfzduiduzklnilbzudjrnzst
 * Smoking Wheels....  was here 2017 opvsjxsywnwhsjclftqjqufksrdcootzomdsqnyjclsccjby
 * Smoking Wheels....  was here 2017 nsqpmqfewvaeucmiujbxlzatqbraojxdqgpuxxuflrsaibix
 * Smoking Wheels....  was here 2017 pcseecvevlthpniegqybfcebksdturwdrjyqtrmovmgpokcu
 * Smoking Wheels....  was here 2017 vaydzdhqltomhpzvyclurgrjajhjpthbformcghplvhcivda
 * Smoking Wheels....  was here 2017 rankmwnqtkhucpamnnzhtvsytyednaaiexiueerywwccmcqg
 * Smoking Wheels....  was here 2017 rxvfsqtkakzopyhmvaezpkugcobskhbprqwfjiigvzgkadwh
 * Smoking Wheels....  was here 2017 trnatblkrvvkqkwmzuzorwpdtslwgmvsbjmtkugpgwnehfmi
 * Smoking Wheels....  was here 2017 armmdzjmndkcfxckjlnbqgcnuzdsjwxwywmoeypfmlwquugt
 * Smoking Wheels....  was here 2017 vlxolokqoamsrtphpteolansjieojwdjgepdxkwrywrklqhf
 * Smoking Wheels....  was here 2017 vtdmsbubzidppkfpntqpgrifbyvybhoybprdzauqkojhfryn
 * Smoking Wheels....  was here 2017 wqwrbdbjihohsozzistvndfuoeptlboktqxndwifweujlfux
 * Smoking Wheels....  was here 2017 bkavyqvfihirefggigtgxmdmxugzwksyycrnhirporyarqss
 * Smoking Wheels....  was here 2017 vprxardrzafufqqqdczzkcjmipxbwvwxmbqopahizecsstto
 * Smoking Wheels....  was here 2017 szichpdaokfylgzlricocoijhwslgbdxourintxdydujqmgj
 * Smoking Wheels....  was here 2017 qrowvajsnprtqujiafapnssvpyhbdcuxmwzutrncifvaudvg
 * Smoking Wheels....  was here 2017 txhxeumopzbzwhdfoixdhsnzfnkytdmaxaydechlmhfzqchp
 * Smoking Wheels....  was here 2017 ifreyalnvheulxwfykdhkvzzjnbksraprifubrrqvpewbetb
 * Smoking Wheels....  was here 2017 ckcwdbnyljakyeksznjoytnkodnavlmhybrntglnemilchon
 * Smoking Wheels....  was here 2017 wogkwndgylymdvwjwznqliwzpsjpckgaaunfyxnbmrkvbsgc
 * Smoking Wheels....  was here 2017 tyanogagbxjucvnaxislopatkzhhwuxwpiccqaenzbkinyte
 * Smoking Wheels....  was here 2017 eboezjdyvleldkavtjkfezdzgvkisdggnrcpyfukfurngqcl
 * Smoking Wheels....  was here 2017 stgnaerplzhsuaffgcfknbsdqlzilclvxdlljhdnxirfivpt
 * Smoking Wheels....  was here 2017 gbtavjdskqcgyldtovarbslahgmdbrtldgfpnkeuaifnbtxf
 * Smoking Wheels....  was here 2017 xhzkxsfbnwauoqejaczzkziqfwsuydugvvwfjwcpvsitawvg
 * Smoking Wheels....  was here 2017 bxcpwjxqsixmzuwfhtnonhofshtqpykqvwbtcijiwphlzxmm
 * Smoking Wheels....  was here 2017 iumursjtgyuqvmdqetiupfphepufwvrghsqxdpswvmpmbweu
 * Smoking Wheels....  was here 2017 pyvlohdvrxwuuiziwlflbperlhlkusyyoxvrevdcsybxmzmj
 * Smoking Wheels....  was here 2017 yrygwzvsrptuakvcsjklppghmzkfryvxgfzedjukuzsaxshn
 * Smoking Wheels....  was here 2017 umcfiwnkgresvxedhhhzdmalmptacxdmhruyfuefntulbtrx
 * Smoking Wheels....  was here 2017 sfplxjjdrcfxshyuogmnwyzqaitjwizitqcpvyzispwyaezl
 * Smoking Wheels....  was here 2017 pxeltbvklzbwnietopytfuvrvpycagrhaodeszeshhrrddtg
 * Smoking Wheels....  was here 2017 pvrxgtpagvinhyfwrvtpxdnmwachxxvoshfusgasorhxxdxt
 * Smoking Wheels....  was here 2017 aogtepsyefswilqhotkhujgkjpggashnrwbybixtzyyffylm
 * Smoking Wheels....  was here 2017 ovifkyjnkcigffjkcklhdaoxxkqoflcucooifbqqhnekalul
 * Smoking Wheels....  was here 2017 atotdkzdmrkgucjwjbwhiacuexvbnbrfhyvwvpcjnbupszms
 * Smoking Wheels....  was here 2017 povavuhrchlsazcnshufbkwaduouhunaxuiuvhngxmucvyjr
 * Smoking Wheels....  was here 2017 pviadhhbhshrhdbnvwpggpbwcyxcbdnnudqnksksyymmednz
 * Smoking Wheels....  was here 2017 qjkxzedqgtxldbdgowzxcedwondopvukbhtuzslpjxjpumin
 * Smoking Wheels....  was here 2017 qetdocjvoqqrjlliaouvbzutfztzavqmdusnhlpveaflzgjk
 * Smoking Wheels....  was here 2017 sogkhxqlwuxcaggsomfzueboczolqkqzolaxffctpebljxlb
 * Smoking Wheels....  was here 2017 fccrxrxmgwpwluemwlrpgacoklohyzrghhhlyrjweoecrerc
 * Smoking Wheels....  was here 2017 topehulfyusgembasluboekfsmabvhuxkpktyqewqpcgaakk
 * Smoking Wheels....  was here 2017 fynirwsejsmwabazhwldgnrispnqhjjvgxowwglwyypzssfd
 * Smoking Wheels....  was here 2017 sqrultjbjbmmbojgzdwtxcwykkuarkyfmacxqvkaknsphsxr
 * Smoking Wheels....  was here 2017 qcgohnkyxnlgodsyjdjbniegbvxonxlkzaskmznylmtsotqp
 * Smoking Wheels....  was here 2017 odrwepbbezlkchwnhxqogududabwqowavdhzupnhwhedousx
 * Smoking Wheels....  was here 2017 lwobgnuytptpnuynyrpyoikhllwtbkpalzaqhtjeqouxqcsq
 * Smoking Wheels....  was here 2017 imvyzdgiiwvpvohwrbkecazvxtbgdpfmkhgowvhuafqjidnf
 * Smoking Wheels....  was here 2017 popkbqnfyjonjxlscukkvhbquvrslsoupdretkrrmmydmqeh
 * Smoking Wheels....  was here 2017 xyiqjhsxubxrrfhlbyhdyscgqxastktpeuefiiipvsizcpas
 * Smoking Wheels....  was here 2017 cpqdcsiwkcdpohyrtvzavdvjdiobcrbuluypitenzqmznerq
 * Smoking Wheels....  was here 2017 hwlpsvbynxueccrilypaerfbhucwvtdmbyhoqzkufcmmhyzm
 * Smoking Wheels....  was here 2017 whwxxryacdrlpvdnvcojyrmojgrlndvcxiznmqowbiobfpzv
 * Smoking Wheels....  was here 2017 mqjiopcmmtutpacpujnmitbkwvpixnehcevfgpgmfrhnjccp
 * Smoking Wheels....  was here 2017 yznhxhbtbwkryjsgjzjcstrinyikdyowzbansyossxlzbsvy
 * Smoking Wheels....  was here 2017 kohmjnnqqyczqwijaogcvuhiihqrmpnafuysrbputvaswwbf
 * Smoking Wheels....  was here 2017 fzvwpklefqovbtmbivospfesnuqnlyzdqjhelmwfxsihnjxa
 * Smoking Wheels....  was here 2017 aamqojbnzvxlrlasdwalfqszqpomytywkdxrjdctvxwpedqi
 * Smoking Wheels....  was here 2017 srzglyuimtinktczqzlxbwrwjcxlyyubvpadecglpckqbkxg
 * Smoking Wheels....  was here 2017 jhdkqzkgmtltfqztdqbcwczktamkuvcwpoysutonkfauurod
 * Smoking Wheels....  was here 2017 jkeaxqviyozilhhdhsffoqwwafhsbwsqobkyjrlmtlyoerpq
 * Smoking Wheels....  was here 2017 iumicghvcbynrgvnygorhcvsrxqynttcvjglksqdkdtwfkmq
 * Smoking Wheels....  was here 2017 emsulkghllrwrftpgmbgohoulnbygmnbtcrenzcljaeshasi
 * Smoking Wheels....  was here 2017 yvtbjzllucqhndjeozuuzkzairhtohprzzbjrwbswaglxcda
 * Smoking Wheels....  was here 2017 bitdocuhbsqtnigmnoeonsjsphktarwjkbbmbyylkggqwixj
 * Smoking Wheels....  was here 2017 dtcexbodnesqgehuyfxajweksoqlkikscrpecbnjsdschqhh
 * Smoking Wheels....  was here 2017 bemqrnelssdonlmvahwvytcumyorvgnqmiuklitnukkyljxx
 * Smoking Wheels....  was here 2017 xxugghjahrkgiehmbheyykcyvaxonruhdvbkcdvexxklwxpp
 * Smoking Wheels....  was here 2017 blfxhmcviuivbnevsahohfkcatsjcbdayfbpfbfvowxfkama
 * Smoking Wheels....  was here 2017 eqbwunpebyyqfzchwovdeumtoihsjepmatrreypfmrnbcrwa
 * Smoking Wheels....  was here 2017 cmboxxinyhmgrhbmqdrkaybsfcdjjamotbbptxakqzybhciu
 * Smoking Wheels....  was here 2017 zgcrapzruhnlkklijiagnwbyyvamltlktvqovhqpisgomvsr
 * Smoking Wheels....  was here 2017 doidxqnqnouiuquyrygypvtsajzicwhkxebaotxjzbtcnndh
 * Smoking Wheels....  was here 2017 fedfljerlbjgijatmzawmnnoywinedcehkfrlcplllxnlexp
 * Smoking Wheels....  was here 2017 ccfhvllhzzmsxkehwuftnsefkunvsnfpizgmdlpvqmmwobrr
 * Smoking Wheels....  was here 2017 xrkcmrzgzqrqmrpofwaolopsmvkibfgvpupqodfuuepnmpey
 * Smoking Wheels....  was here 2017 zkxodftnjvtzllwpdavlfjchjvzksubfauwoxuvwlplayopz
 * Smoking Wheels....  was here 2017 zdcxqjaljjseievwnhgxzvanoampnwrmrizyqhfujfpeaygt
 * Smoking Wheels....  was here 2017 uwqpgugmolwtyppzlzgpesecvtnsonllyxcujriomsucbxri
 * Smoking Wheels....  was here 2017 lwkgjhdkqnrnirmvjpynmfnaeuuwcxafmjqhcjimczcbpaud
 * Smoking Wheels....  was here 2017 ktqyrapfpgzovrcnvatvwpfquykisoegctfwzytasfuslyqv
 * Smoking Wheels....  was here 2017 ggqtdhyernufzbgmsehzmmtkfmosfebeyhtfmggzaujvqrof
 * Smoking Wheels....  was here 2017 wlcfxtovknjboocielnstuwbftvwrtywkpkigkwiajqlmmen
 * Smoking Wheels....  was here 2017 jqyykfexmrhxsexyojoxjonrtlzujnmkbkoifttjaypzpugb
 * Smoking Wheels....  was here 2017 dihzjuulzqguqchmmruvhewlblawwzlgvuwtoxjplqnytjzn
 * Smoking Wheels....  was here 2017 uiomrwprbiiczwbiwlxxrglyragqzuzavbggtsmucvzezequ
 * Smoking Wheels....  was here 2017 erjwnabdgxukndjbtztuzpyxhmfyualpkswtlizxygstqmvz
 * Smoking Wheels....  was here 2017 lrrxjdxoivemiyorovonwkijznqwovjdepcnoaehguuzgsjl
 * Smoking Wheels....  was here 2017 ywpmwhczgsglrmdfytrfgyvnxcpswtpzaspyimljmqkmqpkx
 * Smoking Wheels....  was here 2017 haovzvvqgnbpdgacrvujjvwyqjjcomgubjguemoykeeawefe
 * Smoking Wheels....  was here 2017 jgejwkocxkwnozgyzhtrqzfjwsluqarlscgxtfmbabvrfqkl
 * Smoking Wheels....  was here 2017 itkwzvabwtebyrfrdttbsltvpvpwlolcnszpzzkxphkvhmwb
 * Smoking Wheels....  was here 2017 ndjezffoegugqnllvzetnpuocqxsnqjdkfcfcjtboyfavkpr
 * Smoking Wheels....  was here 2017 nelovyhwbwtleavoyasehatcwhpvsypelymonhigsnsbzkae
 * Smoking Wheels....  was here 2017 hxilsptmbrifjxlsnefalpjfpffcankdblinxvbmapsbztsr
 * Smoking Wheels....  was here 2017 wqwoabieweaiiepuaywhqlowjconumlcvmzhfhdbteghlwlp
 * Smoking Wheels....  was here 2017 rxhumkyymzpyhayyaebdvxojjvqnoknnrcdipjblkjpjdnko
 * Smoking Wheels....  was here 2017 hmykzzvbfbdjvygnjwlafowfcospeaszrprinwnkrphccrwm
 * Smoking Wheels....  was here 2017 plmvtklbmoxduqrdfiyreheditjprgkjfnuhrxmzqocosokl
 * Smoking Wheels....  was here 2017 tbvtfonrbwkcfdntycrzlekfbbhpijdwxrviyuekmebcmqyw
 * Smoking Wheels....  was here 2017 cwddbnaxzrlijrjmezaexpwqmjpytvuvqcmzofbftpkgfrmj
 * Smoking Wheels....  was here 2017 hsueerdalyadwscrtbssveyzdxmesjlxnbqwyzvedfswaqlw
 * Smoking Wheels....  was here 2017 dolhuoioytkdnytzunqhosjyuaochzkzyclatemhrttzduim
 * Smoking Wheels....  was here 2017 uuaficjggodcjkrhrawvvjdpjlovvxhembiozfgupbozdnbp
 * Smoking Wheels....  was here 2017 pwqxmjedjcadrhmtbgwpomleebmsupywbxwytqnfjkjkxrrv
 * Smoking Wheels....  was here 2017 gptnetylmebnbcatuihzxqsesbrgbulttabynibiuctckdnc
 * Smoking Wheels....  was here 2017 obyooufseanxinjyznbrjstjrvpisldqzxakzlwcvwlczeen
 * Smoking Wheels....  was here 2017 rnerdkqsdbybnqvezjgroulucbbzzwqshidqbgcwtpntfhnn
 * Smoking Wheels....  was here 2017 yopwnseljxdbyobplridmgarfrcommsjqjczykfcanfqxfqr
 * Smoking Wheels....  was here 2017 zxohrzbddobgdvvogmyngrzonuzqaznfchtgatzolzbobwvx
 * Smoking Wheels....  was here 2017 rrtkuxuiycbfyfhunbyoiyaeuxfaqlkdbrhhbkigxrxpbnsj
 * Smoking Wheels....  was here 2017 eccxigaumaptkptcpzoelecnzppupaxhchcixslluorckrdk
 * Smoking Wheels....  was here 2017 utstxfunuymywhurcadolrkyjwdhofwbdevwvgwrmsrpyber
 * Smoking Wheels....  was here 2017 ekzemdfudvucvshwxgjeobmwkwebgukchqkofygrtqmzspeb
 * Smoking Wheels....  was here 2017 gdqohowczusvdrhhexcsggybwzdyurwgyeyisvplqyvgboss
 * Smoking Wheels....  was here 2017 aemqrkjfbhvxwcexgoncdgvptwxaldvqqqwliidhjpuumlqz
 * Smoking Wheels....  was here 2017 zdtjkssejywlgemusabpemirimkptpdsibwhfzgrltodvyao
 * Smoking Wheels....  was here 2017 quuyixeefsyuxmciniippoyvazagpwwcdtupurskoutdebgh
 * Smoking Wheels....  was here 2017 zehusoduauglrscfsugwuhhvquevzxjrjeuitmnlulbvtawi
 * Smoking Wheels....  was here 2017 apcqyoiuonjhnuvgsxyglvlreoskfxgnsfhqavvchopofita
 * Smoking Wheels....  was here 2017 folksytcwqajvawqcmvammoqwgqgwjhczvyaugcwrjpyhryc
 * Smoking Wheels....  was here 2017 cwrizcqccaibdwbuuopqcwcgeyfztaqaikqenqcmofotcbvi
 * Smoking Wheels....  was here 2017 qpmvxrjewwlwgamgwlcttwufxdalxwqedkoawctzbwibxrzy
 * Smoking Wheels....  was here 2017 waspxmsfuozqfnmysrnicpqpamurrcvrzrbttzhqidwfhbfh
 * Smoking Wheels....  was here 2017 frpqrqrczusmjorbybgpbjuptwoapgcyufvwkxezxhmubyra
 * Smoking Wheels....  was here 2017 hjlcemjfplqrgqwxmqxzwutvpmpalzmoqitzercrorsphgrz
 * Smoking Wheels....  was here 2017 zdzlopizftavrleejrlextfyjtlnjijmxpzdvlcwfzisghtj
 * Smoking Wheels....  was here 2017 jgbjgyhfnclsrzxtasacwieazixqpnjvguymhohsedilnlvn
 * Smoking Wheels....  was here 2017 vhxuzndxmcqmpnrsbpzarxuisdyqszgznygmsqftyhbkynzc
 * Smoking Wheels....  was here 2017 zavzqsdilurkzminjiajobpibjwcnndnviwvnmotfwykmmmz
 * Smoking Wheels....  was here 2017 tnnjkduzvftbqqxtaebvyqhvukfwbbjknowlkggtbownoozh
 * Smoking Wheels....  was here 2017 faxptrsqkwmhqyvjkteimuuuwxtzrvothirpjhpzqgtbqfil
 * Smoking Wheels....  was here 2017 sdcrjjzgekpdgrpkeuwccvjnnvnvyjnyytzrmezymczppeob
 * Smoking Wheels....  was here 2017 ypotdqsejsdzcgdiejspaklnhhuypiiqpdrkgudljpayllba
 * Smoking Wheels....  was here 2017 smwihalxmajiykmtntqmqitnxubdutjrryxsjgalgiqgngkm
 * Smoking Wheels....  was here 2017 eczcflvdhrwbwezopmutrsgpjxdntwffubbvsxxgkgxtkblv
 * Smoking Wheels....  was here 2017 ryazpywytkifdtgwakoobyeyxpbjbcrruluemifiinbbvqgr
 * Smoking Wheels....  was here 2017 wwkelyundbvdjpccrmrjyozdbbbiogwqulzmekqmsorzyxex
 * Smoking Wheels....  was here 2017 pvtdwzbmxxqkimpwqcyxunjwnrsdgfdaepwrkgesqblqzdus
 * Smoking Wheels....  was here 2017 zfaphzinwghvcjecisocgvifhcuymibyortyceaghxmhnuyk
 * Smoking Wheels....  was here 2017 knimmzqqzvolyniwjexdhxbjqhhavzlvvtjumvqregankqsr
 * Smoking Wheels....  was here 2017 nnczhkedmomrmixppmrmcjaxbknzbylgbcovzbuqboqfrpmk
 * Smoking Wheels....  was here 2017 dhynxukmwphznqbxdzsvbzxoivzqgejergmbhyjgxmakpzvr
 * Smoking Wheels....  was here 2017 lcvwvbamxiohbibsjegdyytjjglbryvrhzpshwqtzxhkueoy
 * Smoking Wheels....  was here 2017 tnvxrgadpmbpmsocywppposnmqznzsqetkmefkbqubqvazuv
 * Smoking Wheels....  was here 2017 rjkxktpsdyvhgfjnrcmqfmgqdbvswfwhftcemmircirlkivf
 * Smoking Wheels....  was here 2017 dpfffffrcwcwhoootetahmcjcaoimkwyaportclwvidjemhf
 * Smoking Wheels....  was here 2017 gocqnkpverkgoumdmppqltgvidwocnhfusgvasonhcaxyxbf
 * Smoking Wheels....  was here 2017 jugbzmsfjbpkkctjnfkrqqwediwqgbxnkexdkwfbyrrqmidw
 * Smoking Wheels....  was here 2017 cccrouuaxyptkyersbvqcrlayuueutvmzfjhjkbiooojxuxc
 * Smoking Wheels....  was here 2017 ingzmyguiluujcwqfkufeusboyfaspkaxlufpmchdkmflkzz
 * Smoking Wheels....  was here 2017 eipqcuvijapkimeejukhobpiylvfkuegupocalnfxdmmstey
 * Smoking Wheels....  was here 2017 abjqdknoajwqokqlvabdgvicjesckubomujlvwuqjxvsnnoo
 * Smoking Wheels....  was here 2017 mnwdnfmvnipvshdtldmfkskvhjefmkcodgcwlqrihcauxsnv
 * Smoking Wheels....  was here 2017 luvomtgpjdcnnxtvikndlpmjnkrltnqecnxkovcgqlwteopu
 * Smoking Wheels....  was here 2017 zccrjymqiewobevnvliybooqzybulmhoalfgcvgsqvjxxmrw
 * Smoking Wheels....  was here 2017 nawkxvezicrarkzzqyjteyvyyxhqfqwasaqugfqevkwwwhur
 * Smoking Wheels....  was here 2017 qjnyaunwswofwazpobebzjuvynrnuvlhknctlwylyqulexid
 * Smoking Wheels....  was here 2017 fessylzvxqvtntyyuztpxrdarcthgzkeiotcjxenzearcpxj
 * Smoking Wheels....  was here 2017 krilaphpsuylpqgzpifgqavndkhayiiwfxzayqnrexmyfvhs
 * Smoking Wheels....  was here 2017 omocalkfbbtimvmvrvzgcscpphhajjatxplyjrljbanuhjpx
 * Smoking Wheels....  was here 2017 gjuwvgnxghftrwlwxoraniktpzbwkvpknxbpbxqliyrblcet
 */
package net.yacy.data.ymark;
import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.CharBuffer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/**
* This class monitors the read progress
*
*/
public class MonitoredReader extends FilterReader {
private volatile long mark = 0;
private volatile long location = 0;
private final int threshold;
private final long maxProgress;
private long lastTriggeredLocation = 0;
private ChangeListener listener = null;
public MonitoredReader(Reader in, int threshold, long maxProgress) {
super(in);
this.threshold = threshold;
this.maxProgress = maxProgress;
}
public void addChangeListener(ChangeListener l) {
	   this.listener = l;
}
protected void triggerChanged(final long location) {
	   if ( threshold > 0 && Math.abs( location-lastTriggeredLocation ) < threshold ) 
		   return;
	   lastTriggeredLocation = location;
	   if (listener == null)
		   return;
	   listener.stateChanged(new ChangeEvent(this));
}
public long getProgress() { 
	   return this.location; 
}
public long maxProgress() {
	   return this.maxProgress;
}
@Override 
public int read() throws IOException {
final int i = super.read();
if ( i != -1 ) 
	  triggerChanged(location++);
return i;
}
@Override
public int read(char[] cbuf, int off, int len) throws IOException {
		final int i = super.read(cbuf, off, len);
		if ( i != -1 ) 
			triggerChanged(location+=i);
	    return i;
}
@Override
public int read(char[] cbuf) throws IOException {
		final int i = super.read(cbuf);
		if ( i != -1 ) 
			triggerChanged(location+=i);
	    return i;
}
@Override
public int read(CharBuffer target) throws IOException {
		final int i = super.read(target);
		if ( i != -1 ) 
			triggerChanged(location+=i);
	    return i;
}
@Override 
public long skip(long n) throws IOException {
final long i = super.skip(n);
if ( i != -1 ) 
	  triggerChanged(location+=i);
return i;
}
@Override 
public synchronized void mark(int readlimit) throws IOException {
super.mark(readlimit);
mark = location;
}
@Override 
public synchronized void reset() throws IOException {
super.reset();
if ( location != mark ) 
	  triggerChanged(location = mark);
}   
}
