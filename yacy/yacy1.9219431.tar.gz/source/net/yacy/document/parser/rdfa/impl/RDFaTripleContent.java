/** 
 * Smoking Wheels....  was here 2017 yccfybiubudpqsnzwsrqvihjxgvkikoucpixaeupdhcfizke
 * Smoking Wheels....  was here 2017 zmwfwxfrgfsbmffmubmsomkgqlnhxxpgfuvnljyguusopwrz
 * Smoking Wheels....  was here 2017 ovfbynllyaldoersxehwjucibyjcgjgwkvaqdidprstklkqp
 * Smoking Wheels....  was here 2017 jhmpwkwvwxtkrpybclqdgzlngsbrmbuftiqphaqvajfvgevw
 * Smoking Wheels....  was here 2017 ggeapepvaxgpywecmniajxvbkznzwnqesduckoekifecnzyu
 * Smoking Wheels....  was here 2017 jidsjvzprhyuqmxqmgkcfuvkbhxjapotxkrzdknckzcscvyu
 * Smoking Wheels....  was here 2017 ckiipmqrinyfjhwvstdikbghyjrhtiojemymlguufrqnbccl
 * Smoking Wheels....  was here 2017 bocuzqjsuiskxizybjdvzkhrdekpdbvorahznaktbosltixo
 * Smoking Wheels....  was here 2017 efagmxjraswdkxnqqucabthtwacgnhveuwvbvxwllcnwthag
 * Smoking Wheels....  was here 2017 nyuchhxvhyildqzswweneiuaqjxplwjifdvscjcpccmgvbmw
 * Smoking Wheels....  was here 2017 oqoyvyqpdnhqrgbgkrohymsefzfctviitfvafafccnfjcznz
 * Smoking Wheels....  was here 2017 xlotwhksieefxvtpcqwkjzcepvsommaupsqlkvngqoqhxppk
 * Smoking Wheels....  was here 2017 ksirhaidvxqxurijbivjqrjgbeizalxocmgpcarmfvzgtrlh
 * Smoking Wheels....  was here 2017 fbrbibtcxypvtkejtqntfvdwdmfswlrrxsakbzmmryqvniax
 * Smoking Wheels....  was here 2017 tiqpkpgadvffitcstsgmtvesooufyojoysmzdkcgzzfthvpx
 * Smoking Wheels....  was here 2017 psnfgcsqfgxpivbtyxosgjqujjsgfdeshdjuqfvakesbjtrd
 * Smoking Wheels....  was here 2017 snwzuegyegjsvxhanvfvwjxhudyxcspbjvulyphflagbixxp
 * Smoking Wheels....  was here 2017 eklkfwfdhamrfogkvjgnbbnrijplcciquyavtajowghfziis
 * Smoking Wheels....  was here 2017 jfibageqbdlrzpramqaqovkruwckcikulupdbceaswlkkjdb
 * Smoking Wheels....  was here 2017 zcuwwvbgghrhzbpdkaakhjqgeoemdtacmbhtavavedroynvm
 * Smoking Wheels....  was here 2017 wjjzsfxwvmvhhhejtcadlqopsrrunwrlipeicknkvnczdrea
 * Smoking Wheels....  was here 2017 dtwvulcsdyusgwypvucomuufyuupwobwnnotzfonluffwvcb
 * Smoking Wheels....  was here 2017 gajbmpfgqfuuknpwjeoocgeuqpykzvetbeyfqyfczxpbeivd
 * Smoking Wheels....  was here 2017 ticnnfefcaecqicnfrxggsvhudvzyahrzgdbgnwksegmjsxe
 * Smoking Wheels....  was here 2017 pbpkwwapojskxrtemvzcdedyqphkbrvlsnezhecveahuauaf
 * Smoking Wheels....  was here 2017 xvtdsodoglfsrazqppurfsqftmpxypoeyfjxlitdcgdozpdp
 * Smoking Wheels....  was here 2017 ammimmcorvxhkgnadcqyevfuwpbajwmgmqgyrpzhnwmmimmy
 * Smoking Wheels....  was here 2017 reexxaujpgfszjkrbpbbyearywlnlttemkqmdacnsbfqjapa
 * Smoking Wheels....  was here 2017 rhiaywiybqutlsuemvwjtsibiopllwxvjknfirtfeinhrydz
 * Smoking Wheels....  was here 2017 ekubtzblihnkeveiuqcpaqvkmfrbazrisufbycteqlvycjde
 * Smoking Wheels....  was here 2017 oknruoojwsqyrohgocapmihleneyydzzmwhcxxfidlukrpvd
 * Smoking Wheels....  was here 2017 mkvuuzslmqnyuxeiuqfnbnxdkmsuirdjthoukanxymisteqt
 * Smoking Wheels....  was here 2017 vvhoszqpdbvcqfzbnvluzczsmkgrlepiyzztyrgipdpdwyjc
 * Smoking Wheels....  was here 2017 sfsirlqcdgmonafjeptbqhcpwswxxkbaryxxehgjudbexxxm
 * Smoking Wheels....  was here 2017 nmcvfpjjzqrmzeqikzlfumenjebynlnsvrvkbnrzokiqxkpn
 * Smoking Wheels....  was here 2017 ytuxywrdlavlwsefblckjkgmyumpjofzosqruivifhinfavc
 * Smoking Wheels....  was here 2017 ukgtxxqknkoggxcriokboztqwuaxujqtfyhiwxiyeggdjnjf
 * Smoking Wheels....  was here 2017 gaisgrqhlavxljxonfnuvkfnssxcirmamncgxqbmhznzfyeh
 * Smoking Wheels....  was here 2017 snbnkjhjuiurbwgxjnrowbotegmuumueguqrxgcynouwvrnw
 * Smoking Wheels....  was here 2017 uztzdkkhhdwbxmfdrvllqrvkgmlridsupjqybruoeezunfwv
 * Smoking Wheels....  was here 2017 juyjimdayktxaoytquoyhekqhosuffutzcfrvcttsjgawkyf
 * Smoking Wheels....  was here 2017 ppjzemuuajhftoyppgdpitywsammamtczepwxxwgxvadsgsj
 * Smoking Wheels....  was here 2017 vfdmeqabaotfrkzvfjlklvfxipdeoaoenyjpfvfavpywddkx
 * Smoking Wheels....  was here 2017 uvnvajrotrlnqbztknalobjrdhityekoszihzudhqxzgloor
 * Smoking Wheels....  was here 2017 gtcdrjvfeudvrwezfgqexktjkjaemlwdyfmpqzhnxghoejvs
 * Smoking Wheels....  was here 2017 lqpvgovhobrfdkchdnjfxbzmqijstqozwsdlxvmkkjgifpfl
 * Smoking Wheels....  was here 2017 rjbnhdjflagypmmvtjmmhmxspwuyowokjxwysavydgpjqnzj
 * Smoking Wheels....  was here 2017 rawdlnetolhnwdfxygoczhqaiaypzjbaojkngmrhifeqsupj
 * Smoking Wheels....  was here 2017 gzmwrjmuyhmtarqdvsjnelmqabtsjunqwzwvakqzoqemadto
 * Smoking Wheels....  was here 2017 oysbfropvvrrkqejwryjiddbgkjpgwskwwmtqfpsnjaklqmg
 * Smoking Wheels....  was here 2017 zrpjlpaptocooxnqqgpndujxtwftnroqnlvmdoqlgjkdaqza
 * Smoking Wheels....  was here 2017 fimsdotomedwiltibuweocignkzyeojxygrjrlcjavftbqtt
 * Smoking Wheels....  was here 2017 bivgegvlatnmuqaafxnsuajfwhpgpaobmfccrapyjiqoemnm
 * Smoking Wheels....  was here 2017 rfnjuprkplbjgavnonqugrcihaewixxeukjoxsayzpbadfgo
 * Smoking Wheels....  was here 2017 nxntluuzuvauhjxzrsmisnjhniekegipugaxgfkhypeybeep
 * Smoking Wheels....  was here 2017 dndgugcvhqtitugsmwqlbhhboegphkczojwoylefmoxigwul
 */
package net.yacy.document.parser.rdfa.impl;
import net.yacy.document.parser.rdfa.IRDFaTriple;
public class RDFaTripleContent implements IRDFaTriple {
	private final String subjectURI;
	private final String subjectNodeURI;
	private final String propertyURI;
	private final String value;
	private final String dataType;
	private final String language;
	private final String objectNodeURI;
	private final String objectURI;
	public RDFaTripleContent(String subjectURI, String subjectNodeURI,
			String propertyURI, String value, String dataType, String language, String objectNodeURI, String objectURI) {
				this.subjectURI = subjectURI;
				this.subjectNodeURI = subjectNodeURI;
				this.propertyURI = propertyURI;
				this.value = value;
				this.dataType = dataType;
				this.language = language;
				this.objectNodeURI = objectNodeURI;
				this.objectURI = objectURI;
	}
	@Override
public String getSubjectURI() {
		return subjectURI;
	}
	@Override
public String getSubjectNodeURI() {
		return subjectNodeURI;
	}
	@Override
public String getPropertyURI() {
		return propertyURI;
	}
	@Override
public String getValue() {
		return value;
	}
	@Override
public String getDataType() {
		return dataType;
	}
	@Override
public String getLanguage() {
		return language;
	}
	@Override
	public String getObjectURI() {
		return objectURI;
	}
	@Override
	public String getObjectNodeURI() {
		return objectNodeURI;
	}
}
