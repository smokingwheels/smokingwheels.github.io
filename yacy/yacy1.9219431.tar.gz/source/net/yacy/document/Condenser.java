/** 
 * Smoking Wheels....  was here 2017 xshbzdvbxsqkhbxkscavslnopwgxdwsrrwwfghytkcrauotd
 * Smoking Wheels....  was here 2017 wrbijyxumjgvzdumiotqfgbiurgjsrccdtfqvbxgzcktwehr
 * Smoking Wheels....  was here 2017 gmpcvjdymlcyxjhukmsdidgzoeaiisuvizmfvrhjnjrcylay
 * Smoking Wheels....  was here 2017 jqaiymmlwrxvlaaloqgnzkivckqdmnpicpijnqoqndwowazo
 * Smoking Wheels....  was here 2017 xxugrqeqxzrudovwqcbhksshzlhjbuofqypvivluuslapxnl
 * Smoking Wheels....  was here 2017 skmhgmrabntmvstrudzczxfexsnvbnbjhmmmwjxwfwemnigs
 * Smoking Wheels....  was here 2017 xibdbwrhbrqqmletihgwlcsmvyepuyswqcjpdqdddldieuzs
 * Smoking Wheels....  was here 2017 vhrsvvenzeckmarfykgwqplmczfawnieptypieqbaqodkaud
 * Smoking Wheels....  was here 2017 dbrilvizzxeakycnmlpnvbxrdbyqazzxgubeuxclpwasezbw
 * Smoking Wheels....  was here 2017 srthcjrdqadezwngctfnlitwsoxgjjayzsxhhxnhwvgcwxjz
 * Smoking Wheels....  was here 2017 qmukgjwuqynpiuhhbwgvdnaaudvafvblljwdtnbwckhrbhoy
 * Smoking Wheels....  was here 2017 iyyooxxxzjcjszaucodqvywkrtufcwytmtpeijfrutkamwrj
 * Smoking Wheels....  was here 2017 jwqazjauyexwtxmdbxljtgununakvgsnfeablhrmqhexgpcc
 * Smoking Wheels....  was here 2017 qjndriqyzoeqfiwyaeetihmezxclmytqafguvklhrtikrrlh
 * Smoking Wheels....  was here 2017 hqmscrmdwymmedkejxksedxidntjidpgnosojbtidzxxhrmj
 * Smoking Wheels....  was here 2017 qhrpxmniqzpnxquwtxpmifhhojanzjetojcuhwzfoeexxgjy
 * Smoking Wheels....  was here 2017 icncbcywlpobahulafjmxadntofmeinthwfearxpqtrhpkkx
 * Smoking Wheels....  was here 2017 gdposdhewypqhvnphdplincvlmvcbaydcqhsfpnojjecrkek
 * Smoking Wheels....  was here 2017 nqxtimfcpmhdtfhdyemhjtdfqwrjwrccolspuzyiaysrrrou
 * Smoking Wheels....  was here 2017 ndoppfsorvjpustfqelfvcnxoqtsftuyoicfaltkcropkyqs
 * Smoking Wheels....  was here 2017 unyhksyxhxxixurgedbsaesmtxipwzcjgqkigvopiygrzgsb
 * Smoking Wheels....  was here 2017 itthzolpaxeyxdfwsjhkhujqxcyyxjkgzvtvegkwsknzqujz
 * Smoking Wheels....  was here 2017 ddvhtpwkngrgwurxplgijcmkayjuqdgsjtnztblnmbmvyanw
 * Smoking Wheels....  was here 2017 rgjgkygjwpehczqpncjpdkhbkhrlpsndgkkfewfbezivtsej
 * Smoking Wheels....  was here 2017 nvujvzssgwtledzggkiswjgcmibnqyhevdifwnjfnqqtbvti
 * Smoking Wheels....  was here 2017 ozrcghuyefqgwatnzrykxvbhbmduurwrkmjxndwalretgptw
 * Smoking Wheels....  was here 2017 wyzccsfwlbjogqhhbklnzwrqblpjigwvqfznabzthbybvncl
 * Smoking Wheels....  was here 2017 xhwjakwlycslqegsdlejawikvbnoxcdajjunpxdwnwgiqhvq
 * Smoking Wheels....  was here 2017 fvscarazafteodjeauwiekndtpfyfytvtfsprnbewppisxhj
 * Smoking Wheels....  was here 2017 soesfddydosjwfviwticykxorjdjkucfdjxryzssjxueipcu
 * Smoking Wheels....  was here 2017 mudxcqydaqdwplyabxurywlrndcwtvrgeptzishrfrwecwbf
 * Smoking Wheels....  was here 2017 ycurhiiosauscbgjfzpgdgktotcuuokjrxyxzghpxcbwvkgi
 * Smoking Wheels....  was here 2017 rfmetmpmkrsgwmrvfalfsbgiikmrjtievpigknlhfpxdogca
 * Smoking Wheels....  was here 2017 ogywrufkqtfasmgadkfidgqemnskniuoygdwfoqrdvfapocl
 * Smoking Wheels....  was here 2017 slamncvbcstxtaiukpbnavogdupapokrrqraktdcyszwnwdy
 * Smoking Wheels....  was here 2017 njwxxlknwddygjmipkkaighwkbdvcyaxxurdcslabknfdwhe
 * Smoking Wheels....  was here 2017 puxkuggzcakltypypwvfgbemxoqlwdrwtazxuhfghihxlowa
 * Smoking Wheels....  was here 2017 vutjjbsajnvzdosjniivfcbxhspryetmowtgcpkspedavenq
 * Smoking Wheels....  was here 2017 hqjocupjjaykkcfktgavynudpdwoqgvwycllayhugwbxvfcj
 * Smoking Wheels....  was here 2017 kwwwpnvadgmuwwqgynhkhrrlcujmnxtkvurxsahwtnjcfjpx
 * Smoking Wheels....  was here 2017 uhrnwqqgxaolbiwhxcuandcigulzkvpthfihppduupnkcqlc
 * Smoking Wheels....  was here 2017 gykyarmodpjywezcuhliatwnuqpxizstsyopjvuoltiytgec
 * Smoking Wheels....  was here 2017 zdzwoobtqkldhliqyrkilrwctyqhpqspssvaybllxxwatrrh
 * Smoking Wheels....  was here 2017 jjogeiiuiaqbqhmzaaaevgigjpomvgjpeqsznxpxrfigxrzh
 * Smoking Wheels....  was here 2017 ymngskoznlwbnhhowkajgbtocwqbtovmfzefoeytndijgfmz
 * Smoking Wheels....  was here 2017 qmoiljeurunsrcvzqbhoeyvttblwmolcegiqsbmzlgondmto
 * Smoking Wheels....  was here 2017 oroftbxaombvftleroytibnvhyrxhltosholxvjvqpcabapj
 * Smoking Wheels....  was here 2017 cpqvipsqeggnkktgpskcpsbbzilptsqhscodiddwrgfkxoeb
 * Smoking Wheels....  was here 2017 wbgjcjuytyeavqoohoibfowzgmzlsddxgagjlulufqloraum
 * Smoking Wheels....  was here 2017 scahhxpltubahczuwjpioksiyuvhdprhsoscxzhrimnnsrav
 * Smoking Wheels....  was here 2017 tzwhhdxwzdmgwuiusskwijndzwtflltosnknqzwsfropnzsl
 * Smoking Wheels....  was here 2017 khyivcqhkrewwzftlicwlvnqrsuocbgeeyzcwlqmkiskzsyz
 * Smoking Wheels....  was here 2017 guppufaxhjecucmaxikudkfillfvyggsdchozfisqyqscvch
 * Smoking Wheels....  was here 2017 foookangcitpnxffgzeivxgacmoybydbapotrjykwdarfnsp
 * Smoking Wheels....  was here 2017 iwrwblvdqamebjsgvvnkdlpspnpxtjljlddzyhqvkwynwirf
 * Smoking Wheels....  was here 2017 afdoloymvbcwtsqhgqyhcjoremicoaaahwrrwpwnrgqxwyau
 * Smoking Wheels....  was here 2017 xmhsnsbpykqadlurlmajuimjjmcahryqqzcmydkfmtrqhjdf
 * Smoking Wheels....  was here 2017 wqwxmnqamfjfaggblqsiteepyzjoafpdxcojvzeyuauskvpq
 * Smoking Wheels....  was here 2017 aasssukmfxvhmejhsqcepyojvqyuazoqrzlomnkyxzaovugl
 * Smoking Wheels....  was here 2017 sdzexsizcduhvjtpviqbgbvyhjvzxjqowqlnciotftrsiaeg
 * Smoking Wheels....  was here 2017 ovcmbpqukwhnpkfhqsymycnvwijtldymnkkxbijdovhzzlry
 * Smoking Wheels....  was here 2017 mcsbgbtlqepqqyvahbzccyhugzzyshvicvmrcotbxvolbikr
 * Smoking Wheels....  was here 2017 oftpayksnpfjyzarezvwjrcvlyoozawfesdackzvmspledfw
 * Smoking Wheels....  was here 2017 euhazjonbrzwwthkwfyzsreftdbzwvwopazlhlmxupqocpcc
 * Smoking Wheels....  was here 2017 ypupcrmgmlwkysmphuyyimalpttuelzzodxpcozdpxfoxtmg
 * Smoking Wheels....  was here 2017 tqxtoloihzfoartwnbtjpahiufftxvniiockfvllxjcpxtyn
 * Smoking Wheels....  was here 2017 sfmetponhtmfdnkdynmggjzvgeeakgcuqcydnrcexvjyrchg
 * Smoking Wheels....  was here 2017 fxtvkfkxjkljpnznezpufxhfhosvgenthubegpjtdmfeynqc
 * Smoking Wheels....  was here 2017 vnbwlqirwxfjyekjcmslrfsajnbvfhwvkxkhvoazjtgdwahx
 * Smoking Wheels....  was here 2017 macublvjgjzuafskvitxadyzgmtvjqnykacjxpzxniewsvxw
 * Smoking Wheels....  was here 2017 guthropsgfhmwohltbvcauydydpwakaevxopmcmtxcbtakgj
 * Smoking Wheels....  was here 2017 ohdhyaouwcyntnrqmljgnoysrjohtcgyqqlmrqzaaffiqnlz
 * Smoking Wheels....  was here 2017 yjsavgzvjzzeinsjwobutzkgxjzrilhwxmqsycfmodckpcwq
 * Smoking Wheels....  was here 2017 jacxnuiifaqbihnharsldaamlnjvvlmwzyifzoceomncfjam
 * Smoking Wheels....  was here 2017 xpfrmnhaeqlavwkhjipcjrtmhnnwpgkboxvfskxigfmrawvx
 * Smoking Wheels....  was here 2017 yqffiovzgmfbdkanniabiiwlqhkbdlxvlixdhgbleniuwhjn
 * Smoking Wheels....  was here 2017 bwmuagemrmypvldihsrrhquxzaiagrbutojrfxhiztnevqxf
 * Smoking Wheels....  was here 2017 fkrvtfuyyuxcsswjwulsqkgqdbvpbzfwxdludnoztpvydccd
 * Smoking Wheels....  was here 2017 lmrayhkfvwrmudonobncbteqadruvoyfmumrzkcqsajlkeur
 * Smoking Wheels....  was here 2017 dsrihoyghizulauxajgzmbvexdxzdwddkrdvyfjvidiglqbl
 * Smoking Wheels....  was here 2017 yvcytlrjpcwifulzesixbwrtigustswjtziwktahjjgdhkfj
 * Smoking Wheels....  was here 2017 swnilmzafkpsxenhalqmhcjdzwwuualswhfudedbvlyghtwo
 * Smoking Wheels....  was here 2017 oewdvorzypssoelubbjtvvyixrxjnaljljfubuvlzelvydxk
 * Smoking Wheels....  was here 2017 xgikquritjalmbupviwvqkpqhpxsnfurhixihgpwgvznchin
 * Smoking Wheels....  was here 2017 hxhgtnefvqmfgfjcfjuevltnsuekphmipkhchjedmuccufnw
 * Smoking Wheels....  was here 2017 qfkdjirguolorlgxikcoxvetvrfguhxdqelathngpsprjccm
 * Smoking Wheels....  was here 2017 bkouxcwdgpjkusvxpawvmpujrywjlkqidjuhqivmvmmoilwv
 * Smoking Wheels....  was here 2017 ybydbysyiibsygshozohoewpnmbbbdnewczkcdpitjaioaxn
 */
/**
*  Condenser.java
*  Copyright 2004 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 09.01.2004 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.SortedSet;
import org.apache.solr.common.params.MapSolrParams;
import net.yacy.cora.document.WordCache;
import net.yacy.cora.document.analysis.Classification.ContentDomain;
import net.yacy.cora.document.analysis.EnhancedTextProfileSignature;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.federate.solr.Ranking;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.language.Identificator;
import net.yacy.document.parser.html.ImageEntry;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.data.word.WordReferenceRow;
import net.yacy.kelondro.util.Bitfield;
import net.yacy.kelondro.util.SetTools;
public final class Condenser extends Tokenizer {
private long fuzzy_signature = 0, exact_signature = 0;
private String fuzzy_signature_text = null;
private final Identificator languageIdentificator;
public LinkedHashSet<Date> dates_in_content;
public Condenser(
final Document document,
final VocabularyScraper scraper,
final boolean indexText,
final boolean indexMedia,
final WordCache meaningLib,
final boolean doAutotagging,
final boolean findDatesInContent,
final int timezoneOffset
) {
super(document.dc_source(), indexText ? document.getTextString() : "", meaningLib, doAutotagging, scraper);
final String initialThreadName = Thread.currentThread().getName();
Thread.currentThread().setName("condenser-" + document.dc_identifier());
this.dates_in_content = new LinkedHashSet<Date>();
ContentDomain contentDomain = document.getContentDomain();
        if (contentDomain == ContentDomain.IMAGE || !document.getImages().isEmpty())     this.RESULT_FLAGS.set(flag_cat_hasimage, true);
        if (contentDomain == ContentDomain.AUDIO || !document.getAudiolinks().isEmpty()) this.RESULT_FLAGS.set(flag_cat_hasaudio, true);
        if (contentDomain == ContentDomain.VIDEO || !document.getVideolinks().isEmpty()) this.RESULT_FLAGS.set(flag_cat_hasvideo, true);
        if (contentDomain == ContentDomain.APP   || !document.getApplinks().isEmpty())   this.RESULT_FLAGS.set(flag_cat_hasapp,   true);
        if (document.lat() != 0.0 && document.lon() != 0.0) this.RESULT_FLAGS.set(flag_cat_haslocation, true);
this.languageIdentificator = new Identificator();
insertTextToWords(new SentenceReader(document.dc_source().toTokens()), 0, WordReferenceRow.flag_app_dc_identifier, this.RESULT_FLAGS, false, meaningLib);
Map.Entry<AnchorURL, String> entry;
        if (indexText) {
String text = document.getTextString();
if (findDatesInContent) this.dates_in_content = DateDetection.parse(text, timezoneOffset);
insertTextToWords(new SentenceReader(document.dc_title()),       1, WordReferenceRow.flag_app_dc_title, this.RESULT_FLAGS, true, meaningLib);
for (String description: document.dc_description()) {
insertTextToWords(new SentenceReader(description), 3, WordReferenceRow.flag_app_dc_description, this.RESULT_FLAGS, true, meaningLib);
}
insertTextToWords(new SentenceReader(document.dc_creator()),     4, WordReferenceRow.flag_app_dc_creator, this.RESULT_FLAGS, true, meaningLib);
insertTextToWords(new SentenceReader(document.dc_publisher()),   5, WordReferenceRow.flag_app_dc_creator, this.RESULT_FLAGS, true, meaningLib);
insertTextToWords(new SentenceReader(document.dc_subject(' ')),  6, WordReferenceRow.flag_app_dc_description, this.RESULT_FLAGS, true, meaningLib);
final String[] titles = document.getSectionTitles();
for (int i = 0; i < titles.length; i++) {
insertTextToWords(new SentenceReader(titles[i]), i + 10, WordReferenceRow.flag_app_emphasized, this.RESULT_FLAGS, true, meaningLib);
}
/*
final Iterator<Map.Entry<yacyURL, String>> i = document.getAnchors().entrySet().iterator();
while (i.hasNext()) {
entry = i.next();
if ((entry == null) || (entry.getKey() == null)) continue;
insertTextToWords(entry.getValue(), 98, indexRWIEntry.flag_app_dc_description, RESULT_FLAGS, true);
}
*/
} else {
this.RESULT_NUMB_WORDS = 0;
this.RESULT_NUMB_SENTENCES = 0;
}
        if (indexMedia) {
Iterator<Map.Entry<AnchorURL, String>> i = document.getAudiolinks().entrySet().iterator();
while (i.hasNext()) {
entry = i.next();
insertTextToWords(new SentenceReader(entry.getKey().toNormalform(true)), 99, flag_cat_hasaudio, this.RESULT_FLAGS, false, meaningLib);
insertTextToWords(new SentenceReader(entry.getValue()), 99, flag_cat_hasaudio, this.RESULT_FLAGS, true, meaningLib);
}
i = document.getVideolinks().entrySet().iterator();
while (i.hasNext()) {
entry = i.next();
insertTextToWords(new SentenceReader(entry.getKey().toNormalform(true)), 99, flag_cat_hasvideo, this.RESULT_FLAGS, false, meaningLib);
insertTextToWords(new SentenceReader(entry.getValue()), 99, flag_cat_hasvideo, this.RESULT_FLAGS, true, meaningLib);
}
i = document.getApplinks().entrySet().iterator();
while (i.hasNext()) {
entry = i.next();
insertTextToWords(new SentenceReader(entry.getKey().toNormalform(true)), 99, flag_cat_hasapp, this.RESULT_FLAGS, false, meaningLib);
insertTextToWords(new SentenceReader(entry.getValue()), 99, flag_cat_hasapp, this.RESULT_FLAGS, true, meaningLib);
}
final Iterator<ImageEntry> j = document.getImages().values().iterator();
ImageEntry ientry;
MultiProtocolURL url;
while (j.hasNext()) {
ientry = j.next();
url = ientry.url();
if (url == null) continue;
insertTextToWords(new SentenceReader(url.toNormalform(true)), 99, flag_cat_hasimage, this.RESULT_FLAGS, false, meaningLib);
insertTextToWords(new SentenceReader(ientry.alt()), 99, flag_cat_hasimage, this.RESULT_FLAGS, true, meaningLib);
}
final Iterator<Map.Entry<String, Word>> k = this.words.entrySet().iterator();
Word wprop;
Map.Entry<String, Word> we;
while (k.hasNext()) {
we = k.next();
wprop = we.getValue();
if (wprop.flags == null) {
wprop.flags = this.RESULT_FLAGS.clone();
this.words.put(we.getKey().toLowerCase(), wprop);
}
}
}
        if (!this.tags.isEmpty()) {
document.addMetatags(this.tags);
}
String text = document.getTextString();
this.languageIdentificator.add(text);
EnhancedTextProfileSignature fuzzySignatureFactory = new EnhancedTextProfileSignature();
Map<String,String> sp = new HashMap<String,String>();
sp.put("quantRate", Float.toString(Ranking.getQuantRate()));
sp.put("minTokenLen", Integer.toString(Ranking.getMinTokenLen()));
fuzzySignatureFactory.init(new MapSolrParams(sp));
fuzzySignatureFactory.add(text);
this.fuzzy_signature = EnhancedTextProfileSignature.getSignatureLong(fuzzySignatureFactory);
this.fuzzy_signature_text = fuzzySignatureFactory.getSignatureText().toString();
this.exact_signature = EnhancedTextProfileSignature.getSignatureLong(text);
/* Restore the current thread initial name */
Thread.currentThread().setName(initialThreadName);
}
private void insertTextToWords(
final SentenceReader text,
final int phrase,
final int flagpos,
final Bitfield flagstemplate,
final boolean useForLanguageIdentification,
final WordCache meaningLib) {
        if (text == null) return;
String word;
Word wprop;
WordTokenizer wordenum = new WordTokenizer(text, meaningLib);
try {
	        int pip = 0;
	        while (wordenum.hasMoreElements()) {
	            word = wordenum.nextElement().toString();
	            if (useForLanguageIdentification) this.languageIdentificator.add(word);
if (word.length() < 2) continue;
word = word.toLowerCase(Locale.ENGLISH);
	            wprop = this.words.get(word);
	            if (wprop == null) wprop = new Word(0, pip, phrase);
	            if (wprop.flags == null) wprop.flags = flagstemplate.clone();
	            wprop.flags.set(flagpos, true);
	            this.words.put(word, wprop);
	            pip++;
	            this.RESULT_NUMB_WORDS++;
	          
}
} finally {
	wordenum.close();
	wordenum = null;
}
}
public int excludeWords(final SortedSet<String> stopwords) {
final int oldsize = this.words.size();
SetTools.excludeDestructive(this.words, stopwords);
return oldsize - this.words.size();
}
public long fuzzySignature() {
return this.fuzzy_signature;
}
public String fuzzySignatureText() {
return this.fuzzy_signature_text;
}
public long exactSignature() {
return this.exact_signature;
}
public String language() {
return this.languageIdentificator.getLanguage();
}
/**
* get the probability of the detected language received by {@link #language()}
* @return 0.0 to 1.0
*/
public double languageProbability() {
return this.languageIdentificator.getProbability();
}
public static void main(final String[] args) {
	FileInputStream inStream = null;
try {
final File f = new File(args[0]);
final Properties p = new Properties();
inStream = new FileInputStream(f);
p.load(inStream);
final StringBuilder sb = new StringBuilder();
sb.append("{\n");
for (int i = 0; i <= 15; i++) {
sb.append('"');
final String s = p.getProperty("keywords" + i);
final String[] l = CommonPattern.COMMA.split(s);
for (final String element : l) {
sb.append(ASCII.String(Word.word2hash(element)));
}
if (i < 15) sb.append(",\n");
}
sb.append("}\n");
System.out.println(sb.toString());
} catch (final FileNotFoundException e) {
ConcurrentLog.logException(e);
} catch (final IOException e) {
ConcurrentLog.logException(e);
} finally {
	if(inStream != null) {
		try {
					inStream.close();
				} catch (IOException e) {
					ConcurrentLog.logException(e);
				}
	}
}
}
}
