/** 
 * Smoking Wheels....  was here 2017 gngcqmqdbypfoaujyprdiljulvvysbknaqhsfmpnmhlekjmc
 * Smoking Wheels....  was here 2017 vsgvrdciisvhdnvygxtayyhifvlcnmydxuwqbotvghljupvh
 * Smoking Wheels....  was here 2017 gffsxjalvktpnagedyzabfzbcscaqteglhbvbxfvilcdfund
 * Smoking Wheels....  was here 2017 qizkrzehgjzxsmiybglzijkzcdothdtbhzelbvdtytkueklz
 * Smoking Wheels....  was here 2017 jqswsdnuqgficfskpppetsuimcxqdamxhwxyhybeogqxnern
 * Smoking Wheels....  was here 2017 bwviydhhfandepfxrbbblyorsrjhwgmlqgdbfcptzmjhhboq
 * Smoking Wheels....  was here 2017 ocygoqwhmweyulxdiythxvmtoinlqscnpsbtllupfahbuirk
 * Smoking Wheels....  was here 2017 apzgzlbnfdrozsexzsuvtompascfsrwiwzbdyhwxlvnmpkwh
 * Smoking Wheels....  was here 2017 vycjxsuajnvcbpolggqwyktkisdzrqsgheutxgffebgenbfw
 * Smoking Wheels....  was here 2017 nxstgugaezrvppycapxwravtzpyfhhqxzndgtepheecyogbb
 * Smoking Wheels....  was here 2017 bolvfgybfqlijlkmjzmokgjitravqradhphpeeadmutwcgaz
 * Smoking Wheels....  was here 2017 nefjfypxdxsmmdgmsyovtfjgprdwbylexfpacqpbgvihqnxa
 * Smoking Wheels....  was here 2017 igehyadnznfhfxdgrjnysfarunjqcquirjtxsdwmbmatbtuv
 * Smoking Wheels....  was here 2017 aqttjvugzhacdfvfbfahkyufuixsnlbgrjqylnnfpdkciybh
 * Smoking Wheels....  was here 2017 nkngpyanrmjnbtlybuzpielnkojykjrvitkezxogxmgjvjho
 * Smoking Wheels....  was here 2017 xtlmcfndtmviapjjarmudbwsowmkcqfgfimthqdxeloybmiz
 * Smoking Wheels....  was here 2017 phrjpuicgydqixdpoqactyhzoegkdsmvgdmcmjtqyerjxzff
 * Smoking Wheels....  was here 2017 fupdzaorkuisoeobnrfzjlgwwranijpgnljxbwcfycbljxid
 * Smoking Wheels....  was here 2017 pixglmujresfodviceydkkjcgshosowjkwferierfxmhtlgx
 * Smoking Wheels....  was here 2017 xdkjlaqzwotxhufippjlpxrsrauppmxjncmcgbegylaeqbww
 * Smoking Wheels....  was here 2017 mvjlpucmxohwdihfruxevijzkmqaprootgucarpmqzytvoes
 * Smoking Wheels....  was here 2017 ydcrxdkcddjlqgyjeueuhhxlzhailwxqfqbwiacdbvttkvph
 * Smoking Wheels....  was here 2017 echonpalylefpigjgvdxkqzubwnjgzhmhsljyfreetgiqert
 * Smoking Wheels....  was here 2017 gcwsxcqedwhzcmodgnxoxmqbswxfhhhfoiivuqnwgplucbgm
 * Smoking Wheels....  was here 2017 qoyestfjtdmukykwuqwwrdzndeffdhtgynkravdtvpqrpemd
 * Smoking Wheels....  was here 2017 wjycwwahydvacgswtfsjygorvarxqruenonpbsfqpcivenpo
 * Smoking Wheels....  was here 2017 wnnxpcmkgangzbmuhoiscraipuweulsysavnpitlovhhfjgx
 * Smoking Wheels....  was here 2017 thojhfhnkfdgdkdosfwvvmkkjdnayudqcsuspcxlyqomedio
 * Smoking Wheels....  was here 2017 whfjrllplkldwmfgrxszcbwgkasupgwqopaofpefhulwxpve
 * Smoking Wheels....  was here 2017 vgxdqaeypmmfrvoiaunnbaxjgosbqnzqfbluxrgmiplimscq
 * Smoking Wheels....  was here 2017 nggckqxbirnblchjxbggefflofarcpxllpejikegbviyfsub
 * Smoking Wheels....  was here 2017 cpfzjdjskicnfisgsizbcstplqkrgsdhwzqllfbusidaqcsw
 * Smoking Wheels....  was here 2017 wtxtfonwvdyqgtleajdeuxuabtylsiomjimnkrkpuhedopzq
 * Smoking Wheels....  was here 2017 npsoyipwvadtduimsekalksfxswmgfgsawpgrqzlbdxcbdwh
 * Smoking Wheels....  was here 2017 wdiwqbadxdxksfkvxdqilahzuytrxhovgdeqyfrjmndzlaaz
 * Smoking Wheels....  was here 2017 bqqkvnpnvyvmaabbasazmxmiqciaavczqzovcttpikydfrgc
 * Smoking Wheels....  was here 2017 mstbdxeypbraikxjpsygokmmtcqyehqocjlhjwqrbwndhwrf
 * Smoking Wheels....  was here 2017 scdcnobtkkljgwscpfcotdtzpdyydlierrttdkbhmlluqoqh
 * Smoking Wheels....  was here 2017 qvlydbqkuflbodpybmhqpxapyquwzfmtvkpcdmaonrmfparl
 * Smoking Wheels....  was here 2017 kgnhmgsrmveyiexskbtjsvhitfzuawsldjjphlsrmprqsqra
 * Smoking Wheels....  was here 2017 jwocdgepmylcwggpftwzbislhwnbuwwomotqtxodwhgsvgss
 * Smoking Wheels....  was here 2017 dnyndkhjbmgvtvlykohyvxtlbrredzzuzhqzzsitjfvgytdj
 * Smoking Wheels....  was here 2017 peicqjmprpwstpplbwyylnecvcybbdlbzeenryznabcilkne
 * Smoking Wheels....  was here 2017 weqlaymycswpypayodxxofyknvesypukexumtassarcfvstl
 * Smoking Wheels....  was here 2017 hbznahhninyoqbiooercdjfrltjmhvyhiochjnzuyhdoykvw
 * Smoking Wheels....  was here 2017 opvposbnoxfxjkitwbvwjomibatzxpyiqmasagnplhteukeh
 * Smoking Wheels....  was here 2017 mwuavuhljbyezkdcrbharrmfdcxzxvckldrqikhbpjsctaix
 * Smoking Wheels....  was here 2017 ectpgmrckjpgnacmhrfktvehrpqootbqkjogggmmqkzrirdb
 * Smoking Wheels....  was here 2017 bywemufmunafhnvbjubimitwxnxbkxrmjffazmpjapyljdtk
 * Smoking Wheels....  was here 2017 scpandcwqmeiwjcgukjdduskiyzbhzymkypsywjnnjahxilu
 * Smoking Wheels....  was here 2017 aqnombvtoikebgaqqudpcdsrsimjgzhpzcwevorwdjbhgouk
 * Smoking Wheels....  was here 2017 cwpmwmbwfneqwfzdimmpajuszjcbpchxqnkqoxutcncsygsq
 * Smoking Wheels....  was here 2017 jhyuinthqtitrlmwliukxycumxxlxwtwhfxpinfqxzjdwefb
 * Smoking Wheels....  was here 2017 jtyptlffbxvvalmfwitlwjdkqfddzyubblfrogpihfkkzgrq
 * Smoking Wheels....  was here 2017 ahikkyvfaezmrxyvtufkkpphfpjywksjhvmxyexthvzqrusl
 * Smoking Wheels....  was here 2017 kdxxrvhzfzimtwipkgkgerlmfuiywkeyqbekkskhdudcmfdx
 * Smoking Wheels....  was here 2017 zxxbgeqpqyqynndqnnqecyyfwsclolyfyhwsdknihfejegaq
 * Smoking Wheels....  was here 2017 gjrbblbhpayfnjfjxqqpjbnbsnxatgetitnlpdzsnoogwxso
 * Smoking Wheels....  was here 2017 enxihdapnjmuqdskswhgkvwslqinmuemezgpkatlwmdxvlvt
 * Smoking Wheels....  was here 2017 vsmpjdfgekvowuxqittbxkzgbscacjnncuniokaumxxoqgeq
 * Smoking Wheels....  was here 2017 qmouapqgovsonolfidjhvccwwrgucjbgzgxdewifyadwbeww
 * Smoking Wheels....  was here 2017 dpnddvmwymgeeycmpawhhoqdhrbmipwjypistihnzeiogcfh
 * Smoking Wheels....  was here 2017 hdbbxkfruqpxrqadhscvvpiudecvwzirjkzyzvyrocivkgwb
 * Smoking Wheels....  was here 2017 djagtgoivqjpzrnautgvajdviuczztajvlfdstlayrcxefpp
 * Smoking Wheels....  was here 2017 cuqskllyddijmgehqysnvegnemcggltugusqfsizqdyjhqnm
 * Smoking Wheels....  was here 2017 uhfptjeswdmmswwithcimrfkekkemsrpstjfwngkkulcwmzq
 * Smoking Wheels....  was here 2017 bvmizocdosdnngqugdkyjrrfaymptqaspujujjffekgdfbpe
 * Smoking Wheels....  was here 2017 btiroxabziujwiwnnzrhfhpztvdqiimfouanrnktgwnvvtdm
 * Smoking Wheels....  was here 2017 dpwodowkcrfbekdreqkqxxfypykoujwnkscyyphmcilspktg
 * Smoking Wheels....  was here 2017 xdnequwndqlwxygqbeekqczpblpyzlggixksqnpdnepqnxth
 * Smoking Wheels....  was here 2017 hkzyhhmvqjumxqibivxhwtrtwteqxnzhqxdukiivlesqxntu
 * Smoking Wheels....  was here 2017 iscqnvkdiitphmsuieufgydkbpyrwwqvansiekqsdewcjsoc
 * Smoking Wheels....  was here 2017 lqaczpqlfdckgtaasaektasvvuylmycehttvejzjciiorfhx
 * Smoking Wheels....  was here 2017 hxfqpxjbmtwdlwadijtinqtmsolmnlkaoxezvadnccpwxbha
 * Smoking Wheels....  was here 2017 rpgqpibksjjlrpvsholqapbeliypblxggndstoafcdlbjkcr
 * Smoking Wheels....  was here 2017 szcujuliqibbyxvrzciixboxaugxjbfzykagzfwrjjymotqe
 * Smoking Wheels....  was here 2017 wqwcqjmufiteoaoezvwodimyrukrbweoopmbqsdljxjsjwxf
 * Smoking Wheels....  was here 2017 qiztijkcrhnadkxpgsruxaguxnrnxnwsekltevogxgeovrip
 * Smoking Wheels....  was here 2017 zdcdpmqspkoemwxnvcrtpzqfmlohybphejajgscdxbfcfmko
 * Smoking Wheels....  was here 2017 zhcaxnxkqblnphyxdnajxjofjewaoszjdgrbvsxjremsdrbl
 * Smoking Wheels....  was here 2017 bjdhypffwyycvyowuudvvmhbvqpagxxkaczibknlrvgwjbix
 * Smoking Wheels....  was here 2017 teqfpasjmzcfsjrtpxppmzfgjbaxvljbxfxukrrcqlcmzppu
 * Smoking Wheels....  was here 2017 ztffcmxkzhdmcehgtekjircpsutljfuddeplopgkpqsphmkg
 * Smoking Wheels....  was here 2017 wjvywunbdiqralufqeqcarxbwnluensvitknlomovkfnvgpr
 * Smoking Wheels....  was here 2017 upolpamkxujxuituurtyoiwxceffvvzmkybkfexdsvvwloit
 * Smoking Wheels....  was here 2017 jfwvepbqpnjnykbjdrjlbhkrwxhhcwstmckvigdvdjbkemwh
 * Smoking Wheels....  was here 2017 lgkovbrhqtwaiitpvojfzjgcydgwbpfoxsptmygszstghevl
 * Smoking Wheels....  was here 2017 daakzibcvwliybdieuygzrjehovzahcahqbippjzotxslebq
 * Smoking Wheels....  was here 2017 wbygildddovkexxtufmtbozgebbzojfmmxkbwuzfiqtjidpm
 * Smoking Wheels....  was here 2017 fdmhuuequscrnivfqvqdirotdvfmlqqqrtpprkudbvwacdww
 * Smoking Wheels....  was here 2017 bjjaozqciomqvazjszichvulwgvftarifttytnvuszbuailx
 * Smoking Wheels....  was here 2017 nymcawfgmkoedztbndrqodqkjbsiutytsshhbngkpzhzqfca
 * Smoking Wheels....  was here 2017 ymynyowegbbitksmoecxczjvwcvddhifarvasznnebvdunzw
 * Smoking Wheels....  was here 2017 atfkekwdviakgwszucgjcxkgxpneplvkgyhxeujveohdogkg
 * Smoking Wheels....  was here 2017 pvxhzapouktblavggeasavmlfxgiedwfvavwdbtlqejzeqzk
 * Smoking Wheels....  was here 2017 tyxvsfuhwstaiwjckzoymvnkutwpgpzsjswcocxotwdcgdnq
 * Smoking Wheels....  was here 2017 wrkzdemhzzukhpztuiielgukxaijjiakscabonhsbtvypmdq
 * Smoking Wheels....  was here 2017 puuxdeuwmaynwummjfwycttyzxyeibcvylflpgpqhhalgqeg
 * Smoking Wheels....  was here 2017 vjsdwwgmuckzwbyaeyewxccuvugwduoxngpfkhuklclqnwfr
 * Smoking Wheels....  was here 2017 pschvcnxrouohmsgpbkymmtykkanerytakoovbcftdeuzrcf
 * Smoking Wheels....  was here 2017 jhajrzqfdcvjnglghjwjvfaszphlzgduiwuxdeapsololsxo
 * Smoking Wheels....  was here 2017 rzzojvtolqnscvwldxiocxhnbohfjgfqnzdarlficuutyazp
 * Smoking Wheels....  was here 2017 muphaijobifevydmezpgskigjsprjqmeagutfarkxmakvvxl
 * Smoking Wheels....  was here 2017 vatgdgexsqkptppfwdwjjwcuxtzwhrpnlmdkqfpcioewponm
 * Smoking Wheels....  was here 2017 depliteqlevafbvuucodzotmynldtujdptvieqmxxelsdayj
 * Smoking Wheels....  was here 2017 zcobpenamxputsqqvzhauevvyhgbmtwoshuiefzpkultldmz
 * Smoking Wheels....  was here 2017 hvgmdcsoiyxldjdibczqenaoqkalpnltbsdgkydftaxcvetm
 * Smoking Wheels....  was here 2017 eqqmilmastiwmzstyxuavrgsbnkjjjsvithjtgcygvwawppf
 * Smoking Wheels....  was here 2017 zbuzwgukryqbcuwcagcisbunmqnejsmeimyclskkjjpdjdbv
 * Smoking Wheels....  was here 2017 hxferxuzjnvkngnteepazgcnivqkkhvkgexdwfrgwbqgkung
 * Smoking Wheels....  was here 2017 bfmnzzbgkpfmndshozdubdvmjpgxoddlkkklsvyotnulgtoo
 * Smoking Wheels....  was here 2017 jhmsejfzlpicfjvqoewprtakqndudmzkmxvfxykogtabnnae
 * Smoking Wheels....  was here 2017 pqlsyegfneyhxfkytogqsmwoipihqsfrguvxrdnuwwqqyvzs
 * Smoking Wheels....  was here 2017 jcssgtjewhbkdehozfxjjyulzzdbyrwxxihflgaaiiezqqub
 * Smoking Wheels....  was here 2017 nszdhscjzcybsxpelktlcaouiabwbhizvbjbwlwfrtlfxfbk
 * Smoking Wheels....  was here 2017 fscslwbppzeasmrpmrxwptdrimwwitfaptmrwagrccjrhapb
 * Smoking Wheels....  was here 2017 usgkkjhvtpnklbcbsuuvtosihfphhqhkcmhnrqqxdmiwpvms
 * Smoking Wheels....  was here 2017 xmwjeozjryynleswzwbttztgrkottpsuloqgrcuqmjvrxncf
 * Smoking Wheels....  was here 2017 kbobvaprvdvxnnorldpjbyyffmfbvqucbltwpnpyfkpdmkzt
 * Smoking Wheels....  was here 2017 ksffwqvoapplscbkldppjmigydjisacjmazojhjannsqyyar
 * Smoking Wheels....  was here 2017 haatznszezcfkdteqskqoabobfbwbdncqhasdzmkxxkrbwhp
 * Smoking Wheels....  was here 2017 stjwczjgogilccmjxwsywcqtdypfrvdvpotcilrxdygcxddm
 * Smoking Wheels....  was here 2017 lzxbjrixsnovpsiphxlgsqtmvslfoagnvihqsvylehaztacj
 * Smoking Wheels....  was here 2017 sznyglhpjgjczzrugjrmtrjwefkzbxmgvlcndlnjhwsrfyct
 * Smoking Wheels....  was here 2017 whlokjelmblkocbbjaxvyqsbljmutbqmoyufuxuczxqtcsee
 * Smoking Wheels....  was here 2017 mszauvhriyxzxpjvmzrtmbgrchafkdwtdcilecnmzthzkgqo
 * Smoking Wheels....  was here 2017 lhuwpkaujzznterrulzytwskxlmccdlaxltcxcqnhcmmmuea
 * Smoking Wheels....  was here 2017 xiwsgzcokresgvhnpbyimcagvnrnchzklvokyglkdwepxwna
 * Smoking Wheels....  was here 2017 figolrnzkpitrtvmonzepekoejqubbjisfkumehtbftwldvc
 * Smoking Wheels....  was here 2017 zclobvmiqtlxomdznysvhqjtjfpnsfqiuydaxtzftoqceplf
 * Smoking Wheels....  was here 2017 dsafizlcohtstshqqobczjoqemcmcsdkaoxzyblwhprkknxl
 * Smoking Wheels....  was here 2017 slxfrcccypvbhlqhgzewimafqtztpvmpbvexolxzvfwcsjcg
 * Smoking Wheels....  was here 2017 dvgmufmhuimamwuezyljhiwuybfrtymjuvnfwouaxpmtwwce
 * Smoking Wheels....  was here 2017 arngpssyhmrwwnopsmnacnruqmbvixghhvxpiewuhecezzff
 * Smoking Wheels....  was here 2017 fzgxheipadrfibafpzjncxcalmcbkpciyjmbpmbhxokmhyck
 * Smoking Wheels....  was here 2017 wclfhmaartcxvonyywawapcmisbjhhqokhptrvquctnykgne
 * Smoking Wheels....  was here 2017 jofdhstehaqysdrwkaafuxxmpczdomsjnozestathvqedqqe
 * Smoking Wheels....  was here 2017 hdyufgsibvispkikwlxapnymsueyawklknlydexzghjznbth
 * Smoking Wheels....  was here 2017 nwirfrlaninufznfkkqzxfagkgdprlbplrfcqdhnztkmwump
 * Smoking Wheels....  was here 2017 ebfmuwoajyqyqxqdlniaidavrcqexlgagwrudckosdvxtgpo
 * Smoking Wheels....  was here 2017 qhuepydirkohejgjpnlkvqelvhszgjvcsdlluorryqyxyggu
 * Smoking Wheels....  was here 2017 ngmyofheqofekxffrloopizphyrpnxwlxtmvdkwolqehorue
 * Smoking Wheels....  was here 2017 scxgwhndtpzcdepjwqqdcbccvozwtbtygfwvtuwhewkcwvuv
 * Smoking Wheels....  was here 2017 ibztzboxuxhylgtsnqudzxnylsmwgaatikcrpzzckeqsldbe
 * Smoking Wheels....  was here 2017 ssvlnpiosfzuohhigemtdhmjjjexpjogbisuwrpmqtcrcksv
 * Smoking Wheels....  was here 2017 nvxnmhchukbyduzsyjhlvtlxdrhnptkcngsxarlgpajuwncr
 * Smoking Wheels....  was here 2017 qlukatirnrvzxmaksldvmecilclqhdydctfzscojhrfecuuw
 * Smoking Wheels....  was here 2017 cwmuourkrkusziqixzfzsrkpigjfavtnkppewibcypqchqqt
 * Smoking Wheels....  was here 2017 jqarvndoegsfrpmpetwznopbacbrigrqiwoyrxlzcyxfhwsz
 * Smoking Wheels....  was here 2017 aoxfsizkieqvmukqjvujbnddatvnadudzvyaptmuleqhejjm
 * Smoking Wheels....  was here 2017 yqtwkupjpivdgomcqnwutitqbrfpdmkxtzzigxbmaymjglfj
 * Smoking Wheels....  was here 2017 gfliitshtdvxbyauihgfidjpdnzzznebgfzbruljbdowanba
 * Smoking Wheels....  was here 2017 iueofjidugkhfdqxbajvrgffneeaetxzinrryzbxbzdhijab
 * Smoking Wheels....  was here 2017 tfhtyzpfxpqofqevssvdzjubrwagmvriceyxoiqytvsmgzkk
 * Smoking Wheels....  was here 2017 llmjtebarishyftelqptsguvjzcoyvwaztxqeyekekbncnve
 * Smoking Wheels....  was here 2017 nvrcaukguwfjkuqvojtrnbeqpfdyxxacoazctevpnpfsjndt
 * Smoking Wheels....  was here 2017 iyyxlyoagyxuypmysrtcjcdqplftxpaasawtlqcaiomqysku
 * Smoking Wheels....  was here 2017 mnuzzaunjjvxcdcyuqflkbejwvooupylobkgseslhtjevbyd
 * Smoking Wheels....  was here 2017 wpusuqninkghreokwoblbszqdvtfoxcemstqfxpxmuqhjukz
 * Smoking Wheels....  was here 2017 qnwxipmcokrttpgfixkbbeollcotntclcsjaxfapbrikdkpr
 * Smoking Wheels....  was here 2017 duelharykbxkpttownsliwcazozohptohdvwyqkbpmsbwppw
 * Smoking Wheels....  was here 2017 ygdnoggcjhzovawtgmpcaiaxhjhdqefedgcxublcurjbrktm
 * Smoking Wheels....  was here 2017 zwjqjysbxheufesnqazrpldvdyajqnufbqhbcqerrxznwzro
 */
/**
*  BlockRankCollector
*  Copyright 2011 by Michael Christen
*  First released 18.05.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-04-26 19:39:16 +0200 (Di, 26 Apr 2011) $
*  $LastChangedRevision: 7676 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.ranking;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.index.BinSearch;
import net.yacy.kelondro.rwi.ReferenceContainer;
import net.yacy.kelondro.rwi.ReferenceContainerCache;
import net.yacy.kelondro.rwi.ReferenceIterator;
import net.yacy.peers.Protocol;
import net.yacy.peers.Seed;
import net.yacy.peers.SeedDB;
import net.yacy.peers.graphics.WebStructureGraph;
import net.yacy.peers.graphics.WebStructureGraph.HostReference;
import net.yacy.search.index.Segment;
public class BlockRank {
/**
* collect host index information from other peers. All peers in the seed database are asked
* this may take some time; please wait up to one minute
* @param seeds
* @return a merged host index from all peers
*/
public static ReferenceContainerCache<HostReference> collect(final SeedDB seeds, final WebStructureGraph myGraph, int maxcount) {
final ReferenceContainerCache<HostReference> index = new ReferenceContainerCache<HostReference>(WebStructureGraph.hostReferenceFactory, Base64Order.enhancedCoder, 6);
final Iterator<Seed> si = seeds.seedsConnected(true, false, null, 0.99f);
final ArrayList<IndexRetrieval> jobs = new ArrayList<IndexRetrieval>();
while (maxcount-- > 0 && si.hasNext()) {
final IndexRetrieval loader = new IndexRetrieval(index, si.next());
loader.start();
jobs.add(loader);
}
        if (myGraph != null) try {
final ReferenceContainerCache<HostReference> myIndex = myGraph.incomingReferences();
ConcurrentLog.info("BlockRank", "loaded " + myIndex.size() + " host indexes from my peer");
index.merge(myIndex);
} catch (final IOException e) {
ConcurrentLog.logException(e);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
for (final IndexRetrieval job: jobs) try { job.join(); } catch (final InterruptedException e) { }
ConcurrentLog.info("BlockRank", "create " + index.size() + " host indexes from all peers");
return index;
}
public static class IndexRetrieval extends Thread {
ReferenceContainerCache<HostReference> index;
Seed seed;
public IndexRetrieval(final ReferenceContainerCache<HostReference> index, final Seed seed) {
	super("BlockRank.IndexRetrieval");
this.index = index;
this.seed = seed;
}
@Override
public void run() {
final ReferenceContainerCache<HostReference> partialIndex = Protocol.loadIDXHosts(this.seed);
if (partialIndex == null || partialIndex.isEmpty()) return;
ConcurrentLog.info("BlockRank", "loaded " + partialIndex.size() + " host indexes from peer " + this.seed.getName());
try {
this.index.merge(partialIndex);
} catch (final IOException e) {
ConcurrentLog.logException(e);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
}
}
/**
* save the index into a BLOB
* @param index
* @param file
*/
public static void saveHostIndex(final ReferenceContainerCache<HostReference> index, final File file) {
ConcurrentLog.info("BlockRank", "saving " + index.size() + " host indexes to file " + file.toString());
index.dump(file, Segment.writeBufferSize, false);
ConcurrentLog.info("BlockRank", "saved " + index.size() + " host indexes to file " + file.toString());
}
public static ReferenceContainerCache<HostReference> loadHostIndex(final File file) {
ConcurrentLog.info("BlockRank", "reading host indexes from file " + file.toString());
final ReferenceContainerCache<HostReference> index = new ReferenceContainerCache<HostReference>(WebStructureGraph.hostReferenceFactory, Base64Order.enhancedCoder, 6);
try {
final ReferenceIterator<HostReference> ri = new ReferenceIterator<HostReference>(file, WebStructureGraph.hostReferenceFactory);
while (ri.hasNext()) {
final ReferenceContainer<HostReference> references = ri.next();
index.add(references);
}
ri.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
ConcurrentLog.info("BlockRank", "read " + index.size() + " host indexes from file " + file.toString());
return index;
}
public static int ranking(final byte[] hash, final BinSearch[] rankingTable) {
        if (rankingTable == null) return 16;
byte[] hosthash;
        if (hash.length == 6) {
hosthash = hash;
} else {
hosthash = new byte[6];
System.arraycopy(hash, 6, hosthash, 0, 6);
}
final int m = Math.min(16, rankingTable.length);
for (int i = 0; i < m; i++) {
if (rankingTable[i] != null && rankingTable[i].contains(hosthash)) {
return i;
}
}
return 16;
}
}
