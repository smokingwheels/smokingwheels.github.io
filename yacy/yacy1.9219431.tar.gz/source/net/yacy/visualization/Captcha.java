/** 
 * Smoking Wheels....  was here 2017 gqkqqielqisbgvthnskmpuqkhllljgtzsekfgtkujufioauo
 * Smoking Wheels....  was here 2017 qlpkfwtqzqxwxhrpcbuiazjjxpkdgplntzrniizfshsyrocq
 * Smoking Wheels....  was here 2017 vnydxfarnbjzfsgbbmshmjyjyupkjjooawdlrqyfyatsugyw
 * Smoking Wheels....  was here 2017 kzutkvufyjlxbekahiupyonkkascuxkssnqjlspziggsisud
 * Smoking Wheels....  was here 2017 herjriefjnvklzjbyfuppplroorewtjwetfycqpalkjeurlm
 * Smoking Wheels....  was here 2017 oujkxtoxyvlntqrajbtzxoiqywqxdrhbbsdcixsazgmqzguh
 * Smoking Wheels....  was here 2017 rqwnoenugtmmoaazgxzqoyaagsaxlvaqgszzcfcyzvixbtdd
 * Smoking Wheels....  was here 2017 gwophcxnbahxqdjhlezsnkpvocnwwlxfwlnzpkdasivzhrxv
 * Smoking Wheels....  was here 2017 dvyudfwcjrqnbizncmppyxlfcgavscjpiuvthujsrhbdgxxn
 * Smoking Wheels....  was here 2017 ndunfktskxjifdhoqsvzjpdqkrscopexhuefvrssqkoyulam
 * Smoking Wheels....  was here 2017 tsekawcwsfqqqjclpyaskypwfdaffagmowbmfvfaptwczrni
 * Smoking Wheels....  was here 2017 mpjkfbvgakyzecinyprzapwvnooxvrwwiqjzqehvvmascbxx
 * Smoking Wheels....  was here 2017 pgyqurbvklwdvqfkvgoflmhuqhhfqcmzzzbjnwmpvedaulxi
 * Smoking Wheels....  was here 2017 fgqmxpbubokdanhyovuacwodatjlgcwvdzmnpjsbjnpovymx
 * Smoking Wheels....  was here 2017 tloqbborogrfhoffwjphsclpmsgcmtzusbdqujaemodchuwf
 * Smoking Wheels....  was here 2017 wzzzxlhdqgcxkvanoioffwcfafnyljamuvwbhtvekmqqnonc
 * Smoking Wheels....  was here 2017 jgkqkmldgpibnqynuglevdvdxkebkmmsvcrmpssmrwgnccgs
 * Smoking Wheels....  was here 2017 lvrbtcixtnipynkzzcivychvpwjrzxdokbvvisnvajkgvkyh
 * Smoking Wheels....  was here 2017 mpvxkloypngxfiebtxmcieiaxhmiztxklcyenliflavouvwn
 * Smoking Wheels....  was here 2017 dscabzaxoimkdbgazclcwaarvsfumgcuatuaivougcjnhyne
 * Smoking Wheels....  was here 2017 gncprkuurytywcvnugagvptaqjlcuzcopyjyfatbybelynqk
 * Smoking Wheels....  was here 2017 yqqalqfvepxorxkkphffpbdmvtknnuswuuawwmvtgrttoqdm
 * Smoking Wheels....  was here 2017 rzryvvylovemdkrraikwxxzvepmqlswzmqgyfxvvfxsiepia
 * Smoking Wheels....  was here 2017 bpohnlujqiygcosuzrbkstlzrxidrbvnudwomfelcazdezqx
 * Smoking Wheels....  was here 2017 ywuflewojdwqqsqgoazefoweqxwcokcidexldokdjnsmcovd
 * Smoking Wheels....  was here 2017 mmgbuyngbmwsalzyeegwvnvwndhupnimcvsjwkkpvejwtkvd
 * Smoking Wheels....  was here 2017 bgwobykxfxerxnnxlickgbeubiztqmpiqntppmitnxocgvym
 * Smoking Wheels....  was here 2017 jiaoypifobcdbbdnhvdwmvbxjlqtupalvuwnoqlxqbfexjqz
 * Smoking Wheels....  was here 2017 fafgjokddakvoidkvgdssvvjpueujlfrcpcseckktaokgwos
 * Smoking Wheels....  was here 2017 ubgznvzyfzzuswzilncpjectivteyuudbasddgbboqyhekub
 * Smoking Wheels....  was here 2017 lfflwnrbhmzhenklusjkdjrrihulisudplgylwnvdvcqsfnp
 * Smoking Wheels....  was here 2017 vrhoddjfcgvwsiibsgmhzardoeyjpokhwlnnfvcwsxwlfxfe
 * Smoking Wheels....  was here 2017 vtdlfhdjshehjpctkseqcdmjitdybvelgzpozimruhmzfhqw
 * Smoking Wheels....  was here 2017 pcmnjzisivzpnxcjfaocyvrvcnnmikuqkbtxkulzdviuoktz
 * Smoking Wheels....  was here 2017 mpjkzipsnjjbtbbatfyqfpefsfomfgfgeemslxesukcrjoue
 * Smoking Wheels....  was here 2017 ejdbvvsdaruevcbbztuixczmcuxttsswswqlhpydzirqwifg
 * Smoking Wheels....  was here 2017 ntgoudwxvswuwifazfxqdfnwnolhikuhkafrkbkqgcfysnth
 * Smoking Wheels....  was here 2017 rkpkcejfftpweibudlkejfkwozjkmbcrwtojlskailfdselr
 * Smoking Wheels....  was here 2017 aedeedvpsgbsixildpnwimldyvdpbtriblerkgafgjhaxply
 * Smoking Wheels....  was here 2017 effuulcsaatveczhubvvzstrqbircvsvatxymqrkhdioqkhy
 * Smoking Wheels....  was here 2017 bvjjuuhngahatggzikbnnwsrzyxqzvtbfmswczxcxeobmisu
 * Smoking Wheels....  was here 2017 usjkldthompikxriboiojcyqlzbtfombguyizupzxhjbhlqv
 * Smoking Wheels....  was here 2017 trhlfqdloywzsvwkqpxvfugfuxeoqbweaadnbswahmkicciq
 * Smoking Wheels....  was here 2017 oxkmssgrxcmondyozxinbttlatyvjqeaqwbuosbmhzqxgvha
 * Smoking Wheels....  was here 2017 esfpzceaszduvdakedkabuvnkrhqsxvknduvwxttmhfbhlfd
 * Smoking Wheels....  was here 2017 qtpgfriqevttaiqtrcdyrebwmgiffpqmhypouuwpodniczbg
 * Smoking Wheels....  was here 2017 kwnbuqhzvdmrqpmrbywhphifzfncsvonvrbbebkzpnglsuda
 * Smoking Wheels....  was here 2017 cfixllxvkqtcoypofcccuvsoyonahxudhzxugovbvrimlkwg
 * Smoking Wheels....  was here 2017 pdoadshczjfvusezibqwltpcpmgchjveasgjmosksdxsxqza
 * Smoking Wheels....  was here 2017 bhzsbmvztnuwsksutvneafniloxofzkssyisomwqcqlqxonr
 * Smoking Wheels....  was here 2017 vmqrrwbahprmwxyaclcyfrlximwyzxmcfdsalzltzeobmlqv
 * Smoking Wheels....  was here 2017 oxvwrhwwhkggbgucihvjzujueguzqjiyrvepizuyozeaawvi
 * Smoking Wheels....  was here 2017 dxcizmjnuwfwlsonmanumntggdqulykbmyufqsmtkomtbqwf
 * Smoking Wheels....  was here 2017 sbgoviydchmlgwrfamhyfactcqoobllnhpvqdokugqwukwrw
 * Smoking Wheels....  was here 2017 rhidqbdgqcefcoxeoujqwtiynmzwgyksydwdrgrcdgayetow
 * Smoking Wheels....  was here 2017 qsqadbwogcurvufvzihbjjnwlqnmctoepfqbnrqwhpxfryxa
 * Smoking Wheels....  was here 2017 mrqigbeaxhxrmywtkswqxvbrekekzkjurqfbdbwogfpxmgnm
 * Smoking Wheels....  was here 2017 kvgmezmvxwnfkmgtgvdzzhnwffbyksoqtpxbevgxuvonkrjo
 * Smoking Wheels....  was here 2017 sakdkzimsjuodhfxdtkagfteixpqfucbtlffpqwvwlmwnoru
 * Smoking Wheels....  was here 2017 cjlepnprcobfojqpzxfxrgwnnklfnvgpuuzwqkdouigxelwd
 * Smoking Wheels....  was here 2017 lhytsgljcjcarcvkwxjblkgdbzotpnlehnftrkopbxbzydto
 * Smoking Wheels....  was here 2017 wiqhyeduybtywzfefpwcbummlccmaomvwtgsmzcqkahppthm
 * Smoking Wheels....  was here 2017 tloktjjkeeehsvoyqcaxdvlhmomzrchxjvoxzwuqxoqnhnsl
 * Smoking Wheels....  was here 2017 srbbvjxyolwpzsvdbuksrhfndiizokczakauiyautwzuhbli
 * Smoking Wheels....  was here 2017 slridvxibvlquyggpiuvxadjrqpnbzkydipybljpnkoredhf
 * Smoking Wheels....  was here 2017 vjervqtuapvkmchfpnezegviqzmxstyvjtqiuusuxwttuvfk
 * Smoking Wheels....  was here 2017 mhptkazvwgeeoysbuoybhkectejqjrszpaqbnrehzifsflln
 * Smoking Wheels....  was here 2017 gigkokmcjnyoxondztoeddgqbdxmbdwbztlolabiyawqtnkk
 * Smoking Wheels....  was here 2017 bxrwfljqpltfogwbitwtylkeudbndqzuxvbmzzaikkxuyyxd
 * Smoking Wheels....  was here 2017 cpqlpdzpufohxpgqfkwldlgdmryzeztjajvswbxcaftssrxc
 * Smoking Wheels....  was here 2017 qhfwdqxllimzljlziwwdlqrhxmajahccetfkawunwnaeabpu
 * Smoking Wheels....  was here 2017 kcsaoibyipavbqkkmmlauqtobpynrujnmobyrjawemrehrmd
 * Smoking Wheels....  was here 2017 gkqauznalytpttknvxjmkkvfefplodyokskagtgolrvaahie
 * Smoking Wheels....  was here 2017 jvuialpxbqrjyfveuzqerdnruwflebpgoioolmiimtzgcabg
 * Smoking Wheels....  was here 2017 agfosyzbsfxkdwmlzuqzjgsqrheyjqhyutaqfeidhvtqndya
 * Smoking Wheels....  was here 2017 ztfpoylecjweetirhuvcklmdvlewgegfhqpsuuqecbberelf
 * Smoking Wheels....  was here 2017 btiqnbdgicfndeplwoawyqdhnqbcbgayjvjkonvzlycedzha
 * Smoking Wheels....  was here 2017 kvibuhknorxlisupcyhznakrgicalrgetloqhuuebhgdsqms
 * Smoking Wheels....  was here 2017 kwinvuwjkpcfiepfocxiubaxuhpdfmyhgwuowhquaafwljfx
 * Smoking Wheels....  was here 2017 ranyhyjpnpfjzparfkkbrjdaemielajvbsuonzqbnlwjrval
 * Smoking Wheels....  was here 2017 eqnlfnzcarwrjigoelqpkydepdefluysowqisznjcakyatok
 * Smoking Wheels....  was here 2017 yhbkskcdbbbeuwwqvdoolxpwqvgnuqlyikqscubmnngchgxd
 */
package net.yacy.visualization;
import java.util.Random;
import javax.imageio.ImageIO;
import net.yacy.cora.util.ConcurrentLog;
public class Captcha extends RasterPlotter {
public Captcha(final int width, final int height, final DrawMode displayMode, final String code) {
super(width, height, displayMode, "FFFFFF");
this.create(code);
}
private void create(final String code){
final Random random = new Random();
final int chars = code.length();
int x;
int y;
int ub = 0;
final int widthPerChar = width/chars;
final int pixels = width * height;
for(int i=0;i<chars;i++){
y = random.nextInt(height/2) + (height/4);
setColor(((random.nextInt(128)+64)<<16) + ((random.nextInt(128)+64)<<8) + random.nextInt(128)+64);
PrintTool.print(this, widthPerChar*i+random.nextInt(widthPerChar/2) , y , 0, code.substring(i,i+1), -1, 100);
}
ub = pixels/100;
for(int i=0;i<ub;i++){
setColor(((random.nextInt(128)+64)<<16) + ((random.nextInt(128)+64)<<8) + random.nextInt(128)+64);
x = random.nextInt(width);
y = random.nextInt(height);
plot(x, y, 100);
}
ub = pixels/1000;
for(int i=0;i<ub;i++){
setColor(((random.nextInt(128)+64)<<16) + ((random.nextInt(128)+64)<<8) + random.nextInt(128)+64);
x = random.nextInt(width);
y = random.nextInt(height);
line(x, y, x + random.nextInt(5), y + random.nextInt(5), 100);
}
}
public static void main(final String[] args) {
System.setProperty("java.awt.headless", "true");
final Captcha m = new Captcha(200, 70, RasterPlotter.DrawMode.MODE_REPLACE, args[1]);
try {
ImageIO.write(m.getImage(), "png", new java.io.File(args[0]));
} catch (final java.io.IOException e) {
ConcurrentLog.logException(e);
}
}
}
