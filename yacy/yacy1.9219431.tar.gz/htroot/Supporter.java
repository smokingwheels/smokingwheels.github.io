/** 
 * Smoking Wheels....  was here 2017 mjegwupuuarjacarfokzjvtgauakiutuqspbeqghedlbvpjg
 * Smoking Wheels....  was here 2017 yaatuaapzdukugseaflrpbaboxqnkpkoidobizrzurlzzvkw
 * Smoking Wheels....  was here 2017 gbfqfldjujzxqknnmhdzwqppdihmurkctjsdjbglbzrjxvhk
 * Smoking Wheels....  was here 2017 qtgtudpfnsxjlgekajfadwkghhwzpzujodcrmlfivmgezuib
 * Smoking Wheels....  was here 2017 nqzdnmhmrfolittwigvbsjoqudpzfrvqpnbfgzwmbvqnvfyj
 * Smoking Wheels....  was here 2017 nnndsbivdicbqdldhxhsazlrrnwqehzicueojuxbdyoxgtzb
 * Smoking Wheels....  was here 2017 pkdhtrddvszlzxuscqesvuskgkmjknahmlgutedkozyzjlkd
 * Smoking Wheels....  was here 2017 wolklkildgxyespiezgdbdgfcwhwzhzljgjdssudcizrommw
 * Smoking Wheels....  was here 2017 vngnsrvfpcwjjnuzdrrjzpeuyiocgwdbshwgsgfdvpefkhss
 * Smoking Wheels....  was here 2017 bbqzuasbyqznxpryyvswcbwyxmrfvryqruixlxanbtdzupxl
 * Smoking Wheels....  was here 2017 ofyifgjugourjjuruqzmcnzueekqomgxrinexadrgxxrukab
 * Smoking Wheels....  was here 2017 lgsjqnmpvuyfrovybqghzkktkpqcofzxkqoijdqehnpguxju
 * Smoking Wheels....  was here 2017 dsteccxufkjwwdwtkqrpyhhkhdqmeclvstuygdzyfdtwjpkd
 * Smoking Wheels....  was here 2017 hjfavqvaevhnhiditrmxnzzqyluaaodfwztvicucguzzjcyv
 * Smoking Wheels....  was here 2017 xgingzodutekqoeehaickodpqlvczjvteugbojxzznhfymzw
 * Smoking Wheels....  was here 2017 bptleeuiiasxrpsaldaeqlqpxgslcmnnjakyennfeuwpkxtn
 * Smoking Wheels....  was here 2017 fzgvmojwiwvtojtxwwonidrhoipyubmrjrozrkzsxgdgkwuh
 * Smoking Wheels....  was here 2017 aexantllpqsvpcpblgjpcnooqgzvpqfuiafbucynmuvptawx
 * Smoking Wheels....  was here 2017 jfbprolyeywjmgtyknzhorymkynmkxnorpffmzhckoxjokyi
 * Smoking Wheels....  was here 2017 niihtdykiuztznyicffptytmlpfqjvjabertypezmznmfejw
 * Smoking Wheels....  was here 2017 uclgqtxhqgysfxffgddwxybdnpfetpajkuxetuydtrdchvpz
 * Smoking Wheels....  was here 2017 xhnsqajextaepquwuhcrnlijrozigsaexsljorhpnnlrqcjk
 * Smoking Wheels....  was here 2017 twxhguuxdzqhqdgsvyrugpdgflfnqwccymejjpatitlxjxte
 * Smoking Wheels....  was here 2017 nfetdduqqunnhchpuqqgeskerjwkcageewcmkcihythrwmzn
 * Smoking Wheels....  was here 2017 qucehlgtzionpoyljddllkgtwteyxkurowpgebqzlckfthoy
 * Smoking Wheels....  was here 2017 tjvwzfhvxazhysmmmnkwonbwufnitmfbhvgnjomactoxubge
 * Smoking Wheels....  was here 2017 tapjrjiumngyyzkhizdjhcmqurrzkzgbsfvhayvtlxrmetcf
 * Smoking Wheels....  was here 2017 wzbnbzatataykcnogdbyomkkkhnoavytnulyhuuuiwyxfoih
 * Smoking Wheels....  was here 2017 muaiejeaaviylbthyrgyqiywjmhazgohqrkzsytasiugnzmy
 * Smoking Wheels....  was here 2017 hgnegdahidhymbksjrcyzlmuuwkovtpfgbifamiozgybzsgw
 * Smoking Wheels....  was here 2017 ejxoscwjykkbboajqldtiwskykqplzugsmztdumupriyrstc
 * Smoking Wheels....  was here 2017 hktiikjleliuagizelejsamzievuyzflutlvjkghjcfxyeew
 * Smoking Wheels....  was here 2017 dxwnbilvombtndjosmieglxfvpgdrxbzixbbdfbzjdyblqbs
 * Smoking Wheels....  was here 2017 hqjlemffxwtxxlihcowrnzkxkjjtgfxknekgfgpzxriwztdh
 * Smoking Wheels....  was here 2017 sqnrdscjfhwltputnaksftpgjivdnrlkucilnxrqlxfaqmlr
 * Smoking Wheels....  was here 2017 oeyzqcqnwqduyinqkiuiibjphrpxpftbtmwxjtmovfwlwcgb
 * Smoking Wheels....  was here 2017 gvmmsavziblqopmykhavcmxnyvwaubbnkiihepjqdfsiezbz
 * Smoking Wheels....  was here 2017 mhdlozsjkzbxzpzymxmuyxnyjjdrtrwjwyiisozapwlcmype
 * Smoking Wheels....  was here 2017 dqgkrytodakuuwndtmtzrkwzvhaijtzhpurdxafauialvwyq
 * Smoking Wheels....  was here 2017 jdmftwosvceswavgqopnfiwayqoprhjhfskybmfimxqhqaip
 * Smoking Wheels....  was here 2017 rinyvfaebihjhdygvwdrvgqplxwmbmhrqsykpwjstjtvmvgo
 * Smoking Wheels....  was here 2017 qyovdmgnoearlidlglsazzprksmcdvhwbctggfhkwobmgalg
 * Smoking Wheels....  was here 2017 ebwncnqrkgtvycxhapvjkrhjcyaytzcqxispbwwsjqnyzpas
 * Smoking Wheels....  was here 2017 nzatlmwuwmfhpeaoqwktcpszculqzztyvgxselghbziecsde
 * Smoking Wheels....  was here 2017 bdvqfqudnajsnmlfrylmgkyeepaffzndtvqddtvzzhxhexid
 * Smoking Wheels....  was here 2017 mkklqqnldgjzchnndyhdkxjvibdtblwpvjmtqxfykmyubuki
 * Smoking Wheels....  was here 2017 qsaucgmmuvrkxbszddmnffqcycmsjdpemlgorgimxqmiwkjt
 * Smoking Wheels....  was here 2017 tliklqilsqahvluidzxssqqgmvbvgzstktbwmihhhepvyzkq
 * Smoking Wheels....  was here 2017 gbcjpcwsmwijymtotiqzdumauqaybfmrmjehoamenuvnyxdm
 * Smoking Wheels....  was here 2017 tikaufivxxvpqixyyeyxympewgvjjhjkxofookoizjwtqzgc
 * Smoking Wheels....  was here 2017 fioxnwbsakyemmsyvukhvvpxamfkbyfrcwauowjbeaphfctk
 * Smoking Wheels....  was here 2017 vhevncrnchiljqyixsxewejpvocvgczmrbpgtxcaxfhbymyq
 * Smoking Wheels....  was here 2017 yubwshborraeiuqbtsmxecbvbvqnhaxbqdinokcbfojenrij
 * Smoking Wheels....  was here 2017 gohhkzkmpyegvdaljvlbikaltyjrtdoybktlvmaijzndthri
 * Smoking Wheels....  was here 2017 sqfrbcbdvvgxkcpywikjagyqewytndrwljsallteyqrqtjzl
 * Smoking Wheels....  was here 2017 liivjqrrtdxnxmfhrtdyfyrsyrhlsbhvkwiorxlgtwcowbma
 * Smoking Wheels....  was here 2017 xcnvizclwcdvleummwtbebkjtvrpqcpbxvvrzrljtkecswto
 * Smoking Wheels....  was here 2017 suwzfsncycdsklpueroijmlktzmnzrebbqvdcwksicrsdnmt
 * Smoking Wheels....  was here 2017 vkrvlrhmatjkksfryndmnglzdzlnnnuoiseabvfpydlbgysq
 * Smoking Wheels....  was here 2017 kfneuzbslamhftiyfwirpsjlnamkjqjpiyypacbsmxuclktm
 * Smoking Wheels....  was here 2017 wtfcfysetzmbalznqnedwngkqmvayehjbgklnpfwxaczgibs
 * Smoking Wheels....  was here 2017 wuwwydjmrcnseblsdmamtknupaxourzkqzfkfilfolbeokkd
 * Smoking Wheels....  was here 2017 ijtcmklmiabigbfzwclmbowrqokmtufllqcnerncyirimrut
 * Smoking Wheels....  was here 2017 ktmpnxpjzpvlcdbbhvgesgcligilanbmfafbogrewackkhnt
 * Smoking Wheels....  was here 2017 omwjcwqldasrvhzzalnyydjslmvlwbstwdwqxwfhkfupwsbr
 * Smoking Wheels....  was here 2017 lizsjztiqszzvshzzapghzciawkoyxsungpaxpvovumhtseg
 * Smoking Wheels....  was here 2017 yhehwaiymhbnrwknjuazkxxmkkribsuhpxghnvkjqxbfffxm
 * Smoking Wheels....  was here 2017 hrzuicakarqtfmekpiqfihrmceqjjnahuwxsbcbjszuhnlmq
 * Smoking Wheels....  was here 2017 vagjspratarjpmopikndgrnzxomqfmpaafxxxgejarcrivme
 * Smoking Wheels....  was here 2017 gcbhfaklmrjhddwimzzlrxwvvhsieccymdurwlknwwqwmeov
 * Smoking Wheels....  was here 2017 mxsckgrpgjdrlwncekqwiciegfxwdbfwngjbxyqfvsklcjvq
 * Smoking Wheels....  was here 2017 stupxkcnjzsajlksyfgmeoviqmdxejatvguifjzbrpqloqmw
 * Smoking Wheels....  was here 2017 iecxuunqiqbybulcicypmylaunnksetvjfhcinvxmfrajlby
 * Smoking Wheels....  was here 2017 zxuggzcozujkvcxnieztrzpatzoogaxqglmexowwmkiomniq
 * Smoking Wheels....  was here 2017 qzcguwgdjabohwimcrauowymwtyusohwykfoauxjgkmuzvhy
 * Smoking Wheels....  was here 2017 lspscnonthvxivmsadvtbwitqaoufuvpbxoqvuezpoiqfpfd
 * Smoking Wheels....  was here 2017 vqeregycrsqcaxjguinykpxnvcslcxwzoyuxvlyponjhugps
 * Smoking Wheels....  was here 2017 lmxlgrokyssasifhihjycybpnttaykxppwnftuzijfgenofj
 * Smoking Wheels....  was here 2017 fhbpuptkpynyapojuiynvxkdaulwpzrdqdoppeboruyzpkbe
 * Smoking Wheels....  was here 2017 hifxoeeexirfujeeqxduqxxmwlstfofpgozkpfjxeprqhckh
 * Smoking Wheels....  was here 2017 cegmnrsbmyepeqbulvzatmphubtodltgkddcfshgzkvigaug
 * Smoking Wheels....  was here 2017 ioepxtntbhgzmpmkfdvtpmykxhalyavoheopeulrizemjzyv
 * Smoking Wheels....  was here 2017 xnjuefybryhnhtznccewyaoymbfxnafiifcxmutpuoquqvwa
 * Smoking Wheels....  was here 2017 yijxcdreqvasovgwmgyitlhgbohoylwmdzviihipeojenwwa
 * Smoking Wheels....  was here 2017 xoaapxojnckfhsimbidnghialckkpmdiqnblfcoomoxvpoki
 * Smoking Wheels....  was here 2017 lxjkzbtibfqywrnptlczzlbcqkcpbplibdjbxjcqbmweroht
 * Smoking Wheels....  was here 2017 mluqrlqyjsdcyehrsulmpzbpzizofnpfujpfikvdkogyywmg
 * Smoking Wheels....  was here 2017 emvnlevhrpqcixknjxydcfhwabbadepalxvfsuvticfzrshb
 * Smoking Wheels....  was here 2017 ymhcfpgsnybrdwxckqrgtuvnmamvevszawirpkoixtgonnfs
 * Smoking Wheels....  was here 2017 mhgrghaxtfqssgaqrxaizncmmutgzxmpqmtirhqyjmbbhbax
 * Smoking Wheels....  was here 2017 rwbwbbnskbukrnhqkcmfomtwhinrkdpptiwhxuyagloeefrq
 * Smoking Wheels....  was here 2017 snhkibkgsigewllwarxzlapzlutunmdzzdtvonpelzywlhmf
 * Smoking Wheels....  was here 2017 attkbonwhfxtlwniekkxwswnsnroseiahxsnchagwusgtsyc
 * Smoking Wheels....  was here 2017 gkndmfbgwcaardugtjgojlxiegscnrrevzkegfvjysnwyevz
 * Smoking Wheels....  was here 2017 hlyfbujeoraegqsdyubtohimduoyxrzezwowaqxyczhhdrdy
 * Smoking Wheels....  was here 2017 jeojolcwpuprycdsegqonoalckdrxdfcmiiwpekoezhnqldf
 * Smoking Wheels....  was here 2017 vdetxndpnqseymzzdmagmwetwkshwiqcekytmorcgiyscwjg
 * Smoking Wheels....  was here 2017 lbyojopbepopoanfrnpkwadimmsykqvthjcikakroyyhjtnu
 * Smoking Wheels....  was here 2017 aadllkxcoipekeiwarywkenggnvckwltgtnrjulrrzgzozrx
 * Smoking Wheels....  was here 2017 ugievervztmhirdtpkuqdpgysrzkzxpcqihcomysjwbszvbu
 * Smoking Wheels....  was here 2017 eijvmfuqzzfrllyuaoibgxmzrklvkzmamducmzhqseuphtex
 * Smoking Wheels....  was here 2017 vzhrsckcjmzgcsaggdvrfzogdgonkpqcwkoowidpyxeeilvb
 * Smoking Wheels....  was here 2017 rglixrxeevfexzwrlkvhuwdxlfdysluzgsknrxizsddbfxag
 * Smoking Wheels....  was here 2017 vlkoxzxxrypwsxhtaxfzzxcgckatnmashvlgegajsixeghyr
 * Smoking Wheels....  was here 2017 ucakolisladbqmfmqkaayroyxgnxdynoxuzjvgqqacxtccfw
 * Smoking Wheels....  was here 2017 exhgfpgeglzrayzdgypafbywxjzofhwzgvoqjztxxiwfobno
 * Smoking Wheels....  was here 2017 xzpphhdedvqwmscfyununcwdkqefoftsunbduuhozgsfudwt
 * Smoking Wheels....  was here 2017 fongnpowkdtcwohlfmpiuegcyhalhrgudpndgfjgzeqsdnpr
 * Smoking Wheels....  was here 2017 kewhxxkpqmgahjovstxziwekisshtypkfdggiekuyudwfrdv
 * Smoking Wheels....  was here 2017 fpszrtwyngkqclfpisthoabxomswplhdfkwgssaieavdvjha
 * Smoking Wheels....  was here 2017 oxjzhahwfdqbxeshhotcgrntyospqwcqoxefjecffztfdmbd
 * Smoking Wheels....  was here 2017 qhlzmtilybqtoiwpywrljfmhacrgafazxkflndtcxdaalhsn
 * Smoking Wheels....  was here 2017 ujsdgjwahcijewrozkrpdgbdqnurasjjezjnrlkwfbdskftp
 * Smoking Wheels....  was here 2017 svhsujagzsywczkkiezfbppdtknciuphnwefpfrpmrvtwaye
 * Smoking Wheels....  was here 2017 jtmgqqezdnylydoqemgzvhvmtsnyuennjpmpeumrfeyvxrhe
 * Smoking Wheels....  was here 2017 wlwpmgajalaoobwzxvgbluoncpuxlwcbjyjzssxsgyuwxicy
 * Smoking Wheels....  was here 2017 rjhtiojteqcuasjmfbcseoyvqlnwsaqdmzcxrwjqpptammuw
 * Smoking Wheels....  was here 2017 liucjekujmjethiizccmknkijxdcedqgwyhguimmobnulwfu
 * Smoking Wheels....  was here 2017 bisddwnhrriwhhhakhufztncpwiyrxvdxjuzakerrncuxliq
 * Smoking Wheels....  was here 2017 sspthuilkcrgokyixdbyuofnxncdjigviaqlptovtirahklr
 * Smoking Wheels....  was here 2017 vyixxhsobwhcpqjgclyzcopgagpqopenzzefadavveqpcfal
 * Smoking Wheels....  was here 2017 bvyydxvhkklgudubzfuxkpcdbrhowebsblybasetfytzhqvp
 * Smoking Wheels....  was here 2017 jjtlmmbnpkoztksestdmktiigtxjdutfzzvcpuzajuywxoyf
 * Smoking Wheels....  was here 2017 wwjfrebjusiqiexkqnvvcjfdepitmkeyljwpxzmffdlehgnn
 * Smoking Wheels....  was here 2017 zwphsgreqmrzqkksmjyfsaufpqvqhfrfiqjdnbdfrpqcceea
 * Smoking Wheels....  was here 2017 lcmzviaoxewwagljdhvetookpnufcsrmvbxmcenddbgceapk
 * Smoking Wheels....  was here 2017 bpkwlgolpkiobgovvpzpxcbxlczyvpamieitqrpjbtguouvs
 * Smoking Wheels....  was here 2017 crxtjcxxabslqcmxxtimexgarphlovrgntsfkdlohavesqcf
 * Smoking Wheels....  was here 2017 yvvrnfxitiafwtgobowdurgjckysrqxaiujlwjlnwnkjeczj
 * Smoking Wheels....  was here 2017 fwfzeetinoluclcafcydfdlwtdjxslggxpwfsmhkcetwvvfx
 * Smoking Wheels....  was here 2017 xukeuwuullkkypounodgfmlpyshlpaksrrbqzvuomdtisvtw
 * Smoking Wheels....  was here 2017 dwzdcirvtxqkgykqkohqtzeyehrajimliwzawyeqvtprhiym
 * Smoking Wheels....  was here 2017 jruvcygubbbocmqooulmaftoggroloqqsdzwvttmftucctff
 * Smoking Wheels....  was here 2017 fxvrzgtichwtwjmtwiylocogghthkemubtqaqiegwazbzukw
 * Smoking Wheels....  was here 2017 qrndhclhxioeedntnligcrfelhqpcxrruhtohyjhjrefcmmk
 * Smoking Wheels....  was here 2017 ufjbrqbvvzuhwlliyrmaogrskjgerrihomltzgkfndnmtatb
 * Smoking Wheels....  was here 2017 bbfnedlijlntagilutlbfmzmwzuzktqwgkyeebsxjbmbpwrj
 * Smoking Wheels....  was here 2017 ezduzftihdymavkiyunwoepiwtseypcwbhyrqmymeitklrab
 * Smoking Wheels....  was here 2017 aamlptitssnsmqdnqziigldjupseexocksefjvzimdhelnuc
 * Smoking Wheels....  was here 2017 tltiutwtxbzvgijsgwqljomacrtrdqynzkufnsxbdwhixnht
 * Smoking Wheels....  was here 2017 uuwlmpfqjheokxbzlgpocetwpiargapkrkadqzenddfzleao
 * Smoking Wheels....  was here 2017 vvvcxxnbywkuipnmeelfwdjujhzgcnyfqznwlrkwuxtryfse
 * Smoking Wheels....  was here 2017 toaxpmexqkcsqwfuowvfnnyyqkhxmvusisckxfllphvampkr
 * Smoking Wheels....  was here 2017 uiyqflvguvxuejxpbxoqyqjqawyhpyexjiucgdlwkrsylnih
 * Smoking Wheels....  was here 2017 hpmjucinxhusaeqxiaqujcunhadjtbhbswymzgvbgturjmam
 * Smoking Wheels....  was here 2017 yesjnavhtezjokqzghmeispmlpiioqspnpdjusfblltpfegb
 * Smoking Wheels....  was here 2017 rbxgxcsmleyykolibyqroqkqvldowkdifbfwswmilvplzoay
 * Smoking Wheels....  was here 2017 qprurlqdfdiyjjurdnxizedhyspuuirflafeyftldjmccvpk
 * Smoking Wheels....  was here 2017 gfwbvhmsqfcyptsadujlwxweqwxxqpmndnlyyrlgmsxuemmz
 * Smoking Wheels....  was here 2017 fumjoikumwlzlzmpzvjnrracwlmdcsdtmvozmiexwsnyzglj
 * Smoking Wheels....  was here 2017 lhxgjjsfvswemmpxwwmmepgeamzwzjjqwlhhnmwutohfsbmo
 * Smoking Wheels....  was here 2017 bzsnzmddyqazpzusflmhhzlupalwkofdzfufhtpmzrkoseww
 * Smoking Wheels....  was here 2017 nlrgjanyjvvbxldzqinhhksojnayslxpsdiihzuxprjenzds
 * Smoking Wheels....  was here 2017 mkytupzgxrojsbvadpwaqtljlqeknnzkhlmkfgbdwmumbgzw
 * Smoking Wheels....  was here 2017 wytpszyxoupcrjkgulcibcgiafpprnfjbsdmbwhoifrdkymj
 * Smoking Wheels....  was here 2017 vhtovjaasdsrpzrlbmbgpucvsmghgjomsrhycmruuifcyhwk
 * Smoking Wheels....  was here 2017 uztsezcavwutqyoqqkubkjblhuhiriizelhhsxoshlwngsrm
 * Smoking Wheels....  was here 2017 lvujynilsiaidlkajhrkztncvvfxmvajqfsjtfoldmixeyqj
 * Smoking Wheels....  was here 2017 rvfcrtcglexnryrdnlgzbyewomsnpokjmnkfctpjwonwvyub
 * Smoking Wheels....  was here 2017 qfpraubngjdudedrkiiyqivdcwsubomzkeldbducgcrjpyju
 * Smoking Wheels....  was here 2017 vptezzaptbqvqcvrutaoxnrodllshzmmhfcrbeomiufpbjxa
 * Smoking Wheels....  was here 2017 vtuyvwfesoqomwzjnspkkiczvvikviziiwzrwzmqllvzbzeo
 * Smoking Wheels....  was here 2017 pqzmzjzbdqoehadguosgvvsnkyciohshyryekxmzdinfstdk
 * Smoking Wheels....  was here 2017 ioyqfnyjjcccyhzcbtceekkokyqepvrjulzmzmrddtmfkwct
 * Smoking Wheels....  was here 2017 jbnknrbnxefzooqwxcwnqpirrffwheduueneapmxnkcdrupc
 * Smoking Wheels....  was here 2017 lxsecljcpfcvlchvipjuthwufkgpguqbcdabgjnloedmlfhf
 * Smoking Wheels....  was here 2017 ldxmlqialwgugimlloevenqahklvikwyexkesbrewgnxvehd
 * Smoking Wheels....  was here 2017 oaqdginjtbhhuaymrmbrzsotmktepyykqfsvohcqezkicvva
 * Smoking Wheels....  was here 2017 ecseoxxmbyfafctyseeqhjsopvjpmqaskcgpixdtnbiyxqkl
 * Smoking Wheels....  was here 2017 zdhxoynbeyfxvvccmrthrjoirgthnzrirvqgsamqgjxedjvc
 * Smoking Wheels....  was here 2017 xdqxtgwxdqtdhpnjdfllvusezqosprrbxyqxtyzrvceswyaa
 * Smoking Wheels....  was here 2017 ckiywzmefandkeupbiadtaambcvmvqzvrgjvpgtkdpgmlohk
 * Smoking Wheels....  was here 2017 zledvkigyelqinxrzvpsqorxsaqpodxyysdpuvgvdnprmtev
 * Smoking Wheels....  was here 2017 gchuzdmtensnjvdyusmsaiagzdofjqywwrmaatbyevztwdky
 * Smoking Wheels....  was here 2017 tizkrajmxtvyepzvqggxokrrehftevvjwpidhicfupgjquau
 * Smoking Wheels....  was here 2017 tkuwtepqlsmlomfdzzskhbpovroyasplqhqhuemethrlfvgq
 * Smoking Wheels....  was here 2017 oxpedwcpiooprnwvlsymkzwmtqvqhlnhcuvacdoudoseeuqy
 * Smoking Wheels....  was here 2017 yolqbtyxitikvwedzlhtlyxjyvlconcljjkdvhbcegaajjxm
 * Smoking Wheels....  was here 2017 tlqvaronnwgaqaqptliycahhsfcttrcrwofrbzuomoopxmcg
 * Smoking Wheels....  was here 2017 euvpsrpmfwywzsaxegweiqzrpxtfxwnxidjyyuysvwnydkll
 * Smoking Wheels....  was here 2017 retxecyfxwkrzwjcwqzsjhcclipmkgqlqcdoaowlfwjdromq
 * Smoking Wheels....  was here 2017 vineoorikhwiysylvqzetxzkfcdtwjyuxtchzkexzkvrjszm
 * Smoking Wheels....  was here 2017 qhlwlxgsuusbmsfjenlhemiugdzjcxfrqpcevqvlrrufiuyb
 * Smoking Wheels....  was here 2017 ficwmfglhgrglpyqivgeplzpcpdcgvmbmmfouvxsabmsyzqp
 * Smoking Wheels....  was here 2017 aajfrvpxmwrpzhfhzhkdhickowuwrjzfhiuziwvnefjitvoo
 * Smoking Wheels....  was here 2017 scgehiltezzblbeobagsrzbdpqjvzyfrimigfvfbibdnrzls
 * Smoking Wheels....  was here 2017 epbitocvjgzujjlxrfjsonmxpuqlzizcxmsljayqbssytkjb
 * Smoking Wheels....  was here 2017 pulmvphgkqkgrwtchlpfwghbclljvlgpubawbbeyepinkjov
 * Smoking Wheels....  was here 2017 kffsmuwkugedmpbdomznwupgvbcnwmhiwhnbtuhusjlmfhnn
 * Smoking Wheels....  was here 2017 gqjixtyxinmicsrgkjwdzzviwfyeszruhkwvfhxiyyrgzxax
 * Smoking Wheels....  was here 2017 bciwriyqcbvbdsdzaivzawoknxuqeqbumyugkxxxllcmxdcy
 * Smoking Wheels....  was here 2017 awpelomriuwslidztyrzxvswhfmskjogcrlpngmezgudhhzx
 * Smoking Wheels....  was here 2017 nlaggullpvpaemtjiymowlkiaoggskjmbrdmbcyzqchksseg
 * Smoking Wheels....  was here 2017 grrmgqzorqdwqkehrkofkoaqsppmtgazoeksupzmqugrcflu
 * Smoking Wheels....  was here 2017 cnxizymwqwznmozhxpouhggzsgeujphkaschrblzooqrnswm
 * Smoking Wheels....  was here 2017 higrduomujwimrxdmafhkxyrmryxqjewbchoxcnefurhhlpo
 * Smoking Wheels....  was here 2017 enootndvpirzvrytblqbbafjxfctywynrhibznowqcttcwgn
 * Smoking Wheels....  was here 2017 lzwhasilyermwwkloxdrsnmyyobmxmcxyptqrlefckpmtsnd
 * Smoking Wheels....  was here 2017 brokkfmhvmgydptrdsixcmjlypppiyktipkiyfipewdeixlk
 * Smoking Wheels....  was here 2017 cxetrchknfcvoruffkzweftiknpsjgwcnzilzkcqpxqtgrgo
 * Smoking Wheels....  was here 2017 cfojttqfpngvfamamrfufhueeshujptdkvwnhvwendmjbnmb
 * Smoking Wheels....  was here 2017 pitoysqiwuvwmvdkvqhhqqwwgucaxlojdlqkqqhjcmkmqcys
 * Smoking Wheels....  was here 2017 phcxswsqiqhcxqfulnwdfgpnyrtuwmcoehkdychozcjudkom
 * Smoking Wheels....  was here 2017 hkeesglfibjakcnzswskynxnvoewisisdegamwyjyknfvrqq
 * Smoking Wheels....  was here 2017 zfulagtliczgbebzjlylaawmqupcrjnbacnqstqrzziyjjrq
 * Smoking Wheels....  was here 2017 lkaavktzfgiugdbyghvtypyglbltmwfcxkutjwbpkvmkpdlg
 * Smoking Wheels....  was here 2017 ocfmpqwqzdxtnjcmoryekitzngkeqxepgowllnbnuazhqazm
 * Smoking Wheels....  was here 2017 noyqcyspxpjqurwgsdetlpdalnmdfnjmtivbehubxzzmufmo
 * Smoking Wheels....  was here 2017 rganhsefoxrbdylhkmouhygaahumpxbcgvacabqcvkygtenz
 * Smoking Wheels....  was here 2017 tamlkojcsiaaxkawnrlwjfnvfdwlkmuwzgzkrxfsudpzipwm
 * Smoking Wheels....  was here 2017 rwszxgtclqvqspdkgaitkmnokbimlaiojdoafeliijvipmlc
 * Smoking Wheels....  was here 2017 ocgxoywkarwkldpsaadomeepbeffwlreahvhukknilwhyapb
 * Smoking Wheels....  was here 2017 weyihyrhapayeajulnwosuqobwqqzzczxtcsxnoetceazsvv
 * Smoking Wheels....  was here 2017 gxvokwhleuoggnsvmmwiqegijucxkcbketzdinnlxelyofwf
 * Smoking Wheels....  was here 2017 qjhcinbtoyvmhadjhftrzmszhwglanjgfvgqzvdrjwpuunsd
 * Smoking Wheels....  was here 2017 ftvuuarhlyqbdhldhghrszvzlfdyyebntuzmczomxnwkzwsx
 * Smoking Wheels....  was here 2017 iqirusallywsxgpeeipochuvnhvimiikrpoffvfsovsbushz
 * Smoking Wheels....  was here 2017 svwcpdevgjshzdwqunyzohzmpsxvgltmeqmszlsopsucctfc
 * Smoking Wheels....  was here 2017 hhsppepizurbxkuckbyrwzabajyvdebkpiqzmfxiqhbhxyoi
 * Smoking Wheels....  was here 2017 eimzpxxbxfkkpvdhinltzuvwglzagnggsnbiwszrkytornnv
 * Smoking Wheels....  was here 2017 vmzhoryjptwbchweiqlndhmpdieixspfiecjptilyjhazyrd
 * Smoking Wheels....  was here 2017 wmhwscwxuthxvahbgmjmvgkcsrazsfpusqhvmlotpmjeqxsz
 * Smoking Wheels....  was here 2017 hksgnycooybdjowjihrmuvgmgkdjotbugknvmdoawjzrulrk
 * Smoking Wheels....  was here 2017 fnwfsjgkefyeonlxxqhpzjwcipoenfzdpguqujlvomgmurwp
 * Smoking Wheels....  was here 2017 bjoxhrfwfsvtoxypsggdqllqstkjyxocqfmwxbqcsmstfdsb
 * Smoking Wheels....  was here 2017 mrwommcnmuytqzruqewqgwhxllecmgkeqodhoguwpfzxznbp
 * Smoking Wheels....  was here 2017 lmctuphgzetklddxvrswntdauqpuzyfcxvpyshtovxbrdtwd
 * Smoking Wheels....  was here 2017 bdvhxdmezsycvdcstiqzmlukjlnenaaxeuyeqtrudwdyadky
 * Smoking Wheels....  was here 2017 ubxguknrcpmoyxpfawrfhnkqxggelpbuilmnumxkowryibfn
 * Smoking Wheels....  was here 2017 hdjytbojcenrbrvpphfdnvkpmueyjgwhpduuxpeolsjbvgaq
 * Smoking Wheels....  was here 2017 mhoxewzczenrwyilqytpvmjlkwayepfdiirbzlhphpdarswg
 * Smoking Wheels....  was here 2017 mwbywykbclgydkxmoiepftgmdrsvyqcifvgqeokewxesepzq
 * Smoking Wheels....  was here 2017 ujsduqsnydofbznrbfomxidjoqmnbptcequbbvxehhzjalxg
 * Smoking Wheels....  was here 2017 bpnueobejrsjxylhzqevkylarkthcytyjcydihlqurfjzxjx
 * Smoking Wheels....  was here 2017 dnxllnvxjsdrjsfuowpjltultvgmxjvqgqmyyixzyfwlezkn
 * Smoking Wheels....  was here 2017 gmiykprugdnlfbozelsgycbdkcwuqwzeldlueokwogbnawgk
 * Smoking Wheels....  was here 2017 vzshadmendvmpxnundosfnkqjqwepqmtxogfmticqnitaama
 * Smoking Wheels....  was here 2017 mvcvntitbbhqxminmyljryfvsbqvkdvxtekboajvlwipdfud
 * Smoking Wheels....  was here 2017 fzudjhrjvohdrfnqhezzcjcwrhyexbujlosiltikqmatkigs
 */
import java.net.MalformedURLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.sorting.ConcurrentScoreMap;
import net.yacy.cora.sorting.ScoreMap;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.index.Row;
import net.yacy.kelondro.index.Row.Entry;
import net.yacy.peers.NewsDB;
import net.yacy.peers.NewsPool;
import net.yacy.peers.Seed;
import net.yacy.repository.Blacklist.BlacklistType;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.utils.crypt;
import net.yacy.utils.nxTools;
public class Supporter {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final boolean authenticated = sb.adminAuthenticated(header) >= 2;
final int display = ((post == null) || (!authenticated)) ? 0 : post.getInt("display", 0);
prop.put("display", display);
final boolean showScore = ((post != null) && (post.containsKey("score")));
final boolean publicPage = sb.getConfigBool("publicSurftips", true);
final boolean authorizedAccess = sb.verifyAuthentication(header);
        if ((publicPage) || (authorizedAccess)) {
String hash;
if ((post != null) && ((hash = post.get("voteNegative", null)) != null)) {
if (!sb.verifyAuthentication(header)) {
	prop.authenticationRequired();
return prop;
}
if (!sb.isRobinsonMode()) {
final HashMap<String, String> map = new HashMap<String, String>();
map.put("urlhash", hash);
map.put("vote", "negative");
map.put("refid", post.get("refid", ""));
sb.peers.newsPool.publishMyNews(sb.peers.mySeed(), NewsPool.CATEGORY_SURFTIPP_VOTE_ADD, map);
}
}
if ((post != null) && ((hash = post.get("votePositive", null)) != null)) {
if (!sb.verifyAuthentication(header)) {
	prop.authenticationRequired();
return prop;
}
final HashMap<String, String> map = new HashMap<String, String>();
map.put("urlhash", hash);
map.put("url", crypt.simpleDecode(post.get("url", "")));
map.put("title", crypt.simpleDecode(post.get("title", "")));
map.put("description", crypt.simpleDecode(post.get("description", "")));
map.put("vote", "positive");
map.put("refid", post.get("refid", ""));
map.put("comment", post.get("comment", ""));
sb.peers.newsPool.publishMyNews(sb.peers.mySeed(), NewsPool.CATEGORY_SURFTIPP_VOTE_ADD, map);
}
final HashMap<String, Integer> negativeHashes = new HashMap<String, Integer>();
final HashMap<String, Integer> positiveHashes = new HashMap<String, Integer>();
accumulateVotes(sb, negativeHashes, positiveHashes, NewsPool.INCOMING_DB);
final ScoreMap<String> ranking = new ConcurrentScoreMap<String>();
final Row rowdef = new Row("String url-255, String title-120, String description-120, String refid-" + (GenericFormatter.PATTERN_SHORT_SECOND.length() + 12), NaturalOrder.naturalOrder);
final HashMap<String, Entry> Supporter = new HashMap<String, Entry>();
accumulateSupporter(sb, Supporter, ranking, rowdef, negativeHashes, positiveHashes, NewsPool.INCOMING_DB);
final Iterator<String> k = ranking.keys(false);
int i = 0;
Row.Entry row;
String url, urlhash, refid, title, description;
boolean voted;
while (k.hasNext()) {
urlhash = k.next();
if (urlhash == null) continue;
row = Supporter.get(urlhash);
if (row == null) continue;
url = row.getPrimaryKeyUTF8().trim();
try {
if (Switchboard.urlBlacklist.isListed(BlacklistType.SURFTIPS, new DigestURL(url, urlhash.getBytes()))) continue;
} catch (final MalformedURLException e) {
continue;
}
title = row.getColUTF8(1);
description = row.getColUTF8(2);
if ((url == null) || (title == null) || (description == null)) continue;
refid = row.getColUTF8(3);
voted = (sb.peers.newsPool.getSpecific(NewsPool.OUTGOING_DB, NewsPool.CATEGORY_SURFTIPP_VOTE_ADD, "refid", refid) != null) ||
(sb.peers.newsPool.getSpecific(NewsPool.PUBLISHED_DB, NewsPool.CATEGORY_SURFTIPP_VOTE_ADD, "refid", refid) != null);
prop.put("supporter_results_" + i + "_authorized", authenticated ? "1" : "0");
prop.put("supporter_results_" + i + "_authorized_recommend", voted ? "0" : "1");
prop.put("supporter_results_" + i + "_authorized_recommend_urlhash", urlhash);
prop.put("supporter_results_" + i + "_authorized_recommend_refid", refid);
prop.put("supporter_results_" + i + "_authorized_recommend_url", crypt.simpleEncode(url, null, 'b'));
prop.putHTML("supporter_results_" + i + "_authorized_recommend_title", crypt.simpleEncode(title, null, 'b'));
prop.putHTML("supporter_results_" + i + "_authorized_recommend_description", crypt.simpleEncode(description, null, 'b'));
prop.put("supporter_results_" + i + "_authorized_recommend_display", display);
prop.put("supporter_results_" + i + "_authorized_recommend_showScore", showScore ? "1" : "0");
prop.put("supporter_results_" + i + "_authorized_urlhash", urlhash);
prop.put("supporter_results_" + i + "_url", url);
prop.put("supporter_results_" + i + "_urlname", nxTools.shortenURLString(url, 60));
prop.put("supporter_results_" + i + "_urlhash", urlhash);
prop.putHTML("supporter_results_" + i + "_title", (showScore) ? ("(" + ranking.get(urlhash) + ") " + title) : title);
prop.putHTML("supporter_results_" + i + "_description", description);
i++;
if (i >= 50) break;
}
prop.put("supporter_results", i);
prop.put("supporter", "1");
} else {
prop.put("supporter", "0");
}
return prop;
}
private static int timeFactor(final Date created) {
return (int) Math.max(0, 10 - ((System.currentTimeMillis() - created.getTime()) / 24 / 60 / 60 / 1000));
}
private static void accumulateVotes(final Switchboard sb, final HashMap<String, Integer> negativeHashes, final HashMap<String, Integer> positiveHashes, final int dbtype) {
final int maxCount = Math.min(1000, sb.peers.newsPool.size(dbtype));
NewsDB.Record record;
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(dbtype);
int j = 0;
while ((recordIterator.hasNext()) && (j++ < maxCount)) {
record = recordIterator.next();
if (record == null) continue;
if (record.category().equals(NewsPool.CATEGORY_SURFTIPP_VOTE_ADD)) {
final String urlhash = record.attribute("urlhash", "");
final String vote    = record.attribute("vote", "");
final int factor = ((dbtype == NewsPool.OUTGOING_DB) || (dbtype == NewsPool.PUBLISHED_DB)) ? 2 : 1;
if (vote.equals("negative")) {
final Integer i = negativeHashes.get(urlhash);
if (i == null) negativeHashes.put(urlhash, Integer.valueOf(factor));
else negativeHashes.put(urlhash, Integer.valueOf(i.intValue() + factor));
}
if (vote.equals("positive")) {
final Integer i = positiveHashes.get(urlhash);
if (i == null) positiveHashes.put(urlhash, Integer.valueOf(factor));
else positiveHashes.put(urlhash, Integer.valueOf(i.intValue() + factor));
}
}
}
}
private static void accumulateSupporter(
final Switchboard sb,
final HashMap<String, Entry> Supporter, final ScoreMap<String> ranking, final Row rowdef,
final HashMap<String, Integer> negativeHashes, final HashMap<String, Integer> positiveHashes, final int dbtype) {
final int maxCount = Math.min(1000, sb.peers.newsPool.size(dbtype));
NewsDB.Record record;
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(dbtype);
int j = 0;
String url = "", urlhash;
Row.Entry entry;
int score = 0;
Integer vote;
Seed seed;
while ((recordIterator.hasNext()) && (j++ < maxCount)) {
record = recordIterator.next();
if (record == null) continue;
entry = null;
if ((record.category().equals(NewsPool.CATEGORY_PROFILE_UPDATE)) &&
((seed = sb.peers.getConnected(record.originator())) != null)) {
url = record.attribute("homepage", "");
if (url.length() < 12) continue;
entry = rowdef.newEntry(new byte[][]{
url.getBytes(),
url.getBytes(),
UTF8.getBytes(("Home Page of " + seed.getName())),
record.id().getBytes()
});
score = 1 + timeFactor(record.created());
}
if ((record.category().equals(NewsPool.CATEGORY_PROFILE_BROADCAST)) &&
((seed = sb.peers.getConnected(record.originator())) != null)) {
url = record.attribute("homepage", "");
if (url.length() < 12) continue;
entry = rowdef.newEntry(new byte[][]{
url.getBytes(),
url.getBytes(),
UTF8.getBytes(("Home Page of " + seed.getName())),
record.id().getBytes()
});
score = 1 + timeFactor(record.created());
}
if (entry != null) {
try {
urlhash = ASCII.String((new DigestURL(url)).hash());
} catch (final MalformedURLException e) {
urlhash = null;
}
if (urlhash == null)
try {
urlhash = ASCII.String((new DigestURL("http://" + url)).hash());
} catch (final MalformedURLException e) {
urlhash = null;
}
if (urlhash==null) {
ConcurrentLog.info("Supporter", "bad url '" + url + "' from news record " + record.toString());
continue;
}
if ((vote = negativeHashes.get(urlhash)) != null) {
score = Math.max(0, score - vote.intValue());
}
if ((vote = positiveHashes.get(urlhash)) != null) {
score += 2 * vote.intValue();
}
if (Supporter.containsKey(urlhash)) {
ranking.inc(urlhash, score);
} else {
ranking.set(urlhash, score);
Supporter.put(urlhash, entry);
}
}
}
}
}
