/** 
 * Smoking Wheels....  was here 2017 tigsjfxyrsypcxtgizqbfdhuspjxhpmuigjoaxgtlirmtady
 * Smoking Wheels....  was here 2017 kxjpaodngvgeddxttzslhkabadqiquudthefpqpzibiqdwin
 * Smoking Wheels....  was here 2017 cbyskqegqgvtasrwujiliyrdxlisfmxhssxaqnfxwdwyiswk
 * Smoking Wheels....  was here 2017 gzisjccvyinbelsihobvlsowtaqzqvwhhfgbmttqrksogxyw
 * Smoking Wheels....  was here 2017 rdyjyygcoonahmadefqsxyilerykxevkrsiqquaopymacbcl
 * Smoking Wheels....  was here 2017 hcrumleebufwidunrgckhevfblwjechcjkjizkehtzcxibzw
 * Smoking Wheels....  was here 2017 kwmhnaumizgblbmbjwsljccvnqjownyedrwymnltnbtgoyod
 * Smoking Wheels....  was here 2017 nprkwldqnnnfbbwmylbshsmextozrmtqzeronlnbnatgudbo
 * Smoking Wheels....  was here 2017 irtaosoozxgkwhwukqwhgfpjwqwunjyscwtoqpepqwviefzp
 * Smoking Wheels....  was here 2017 vumeyzqjixtsvbrhzkelxcgvgixlqtazawklqsoaayweeaab
 * Smoking Wheels....  was here 2017 ivyenvgklpsrcaukfygtacoefcqrkopdnqebpuyeysaukrcy
 * Smoking Wheels....  was here 2017 gakqexmjlhbxczyauoqcqfwhcmejovtgovvmubygdbrhwnmm
 * Smoking Wheels....  was here 2017 ktjjxfqdslxlnbbatacncqtioixuzyqojjkbuzlpkymftepf
 * Smoking Wheels....  was here 2017 tqplbziuvyrliqjtjfsixwbqkpnjwnsomkdjkimwwsjfkmfw
 * Smoking Wheels....  was here 2017 ordfesjusvzishisbircyqwxvqwtrkszpjoesalyywmfppgn
 * Smoking Wheels....  was here 2017 hahebdwtmiuwbxqqqsosgynzdzezarpyuynpzjwyfgfmguxj
 * Smoking Wheels....  was here 2017 sbofuffnmafyboiobdddczqazkueysopfazyutphpwfkntsy
 * Smoking Wheels....  was here 2017 vmskqexhirrurpotoklvbhakgykvoccnltfuzztqdajtwgib
 * Smoking Wheels....  was here 2017 xeubfmvkyjvvbrursutgzntuaywqhtymequzoaruggwjxmsq
 * Smoking Wheels....  was here 2017 jjbtgycnkknvrpudeqogwseasxjnwsakkgmpwcyyoicortda
 * Smoking Wheels....  was here 2017 akbhxlambhzqemldzrrybbygxqhsfjorkogxlrjmyjsrhqaq
 * Smoking Wheels....  was here 2017 vzptkhenpvonnsbyjtdqcbvxmeiqmhzsrsmodmcamppnebci
 * Smoking Wheels....  was here 2017 bbqnjxlyvbyxxwabwcexvlyopvizdkchxdphynklppyzbchc
 * Smoking Wheels....  was here 2017 etmcoaxkxhznsvbgebjogepdocmtvsulemlgfayyxdcgwcwd
 * Smoking Wheels....  was here 2017 znriarvvfbxgqrenhkmrsnlubvecnrhlrsasmlnvggtuuqha
 * Smoking Wheels....  was here 2017 lzzhdbxhidbjrtoenznptygvyabmjvcuxypipnfutgvhfqgm
 * Smoking Wheels....  was here 2017 ubkhkryfepchyrrqhyuwfeezhzbqvbxgqqsvpgksurktveso
 * Smoking Wheels....  was here 2017 ozhyqfzfvsysxigtjtuidencnghlplruwleitwqsziyhqoxn
 * Smoking Wheels....  was here 2017 lccbyrkfratpgugmuchbvfwhfqedpjptuhydrvueffcltmhv
 * Smoking Wheels....  was here 2017 mdqsohviijxdwlwctvjjvsbzheiezleoyhjwdwxtprtvqtpg
 * Smoking Wheels....  was here 2017 xzxfcoaxrsbtzvpdtdgvylfuvetggncbcyyifakhmgbmyltw
 * Smoking Wheels....  was here 2017 eugdiedrvkdeawciomnihkrqgdmhaqjeewkogkuzorlnrzzw
 * Smoking Wheels....  was here 2017 czchiemlezgjrqksemxvcuzpdxzoggegmzwxspyfpbnkyxtu
 * Smoking Wheels....  was here 2017 qgiuksrjhgwmvnsnubktzcacimxlcxztnlnznhyovrexfdvk
 * Smoking Wheels....  was here 2017 bnwydinwcfoatclizkkqtbwtaeeqbmmmzsynqmdznbqwescs
 * Smoking Wheels....  was here 2017 vxbiisdnsehqufjulyihlqvmnnwdtbrjxlyskkcojzgptavy
 * Smoking Wheels....  was here 2017 swltzxvgmsfiszkaeizujcoknilceautnolukmssenslcrlr
 * Smoking Wheels....  was here 2017 scthmbfeaorgjtvflllmbwvxvqozlygdifvjlnabdywfsnsq
 * Smoking Wheels....  was here 2017 blahisdsgvjwzeaxtnxyjsuqosbnastgcuogomjmpvxtfrov
 * Smoking Wheels....  was here 2017 hdoijornftfwzbuwuyzyjqtlddeqplidualnbojdeyfhpmfo
 * Smoking Wheels....  was here 2017 bnwerqekjxifcmacpjjqhvhndrgndleaqunmmgwksiliaocg
 * Smoking Wheels....  was here 2017 ljszmcengbcdexzwlsdhtthemjzqtjslfgatshxxjgnnwsat
 * Smoking Wheels....  was here 2017 rndzkmqiuggalvcrteonoeudfofrxasdewndsswomiouxcwa
 * Smoking Wheels....  was here 2017 fdlvgmnkcvppjecijeeducdfuseoinceogtswqimshzkacwj
 * Smoking Wheels....  was here 2017 wsciccgqnhjvozzteiterszpureowgctpkuusqdbxfmtjgmg
 * Smoking Wheels....  was here 2017 ovyoeojdslxxarxhnqhzwncrbmybuvekvkwzakjyejxollmm
 * Smoking Wheels....  was here 2017 plzudisjnixgxvjkvedecfpatljvmbbxysobxxjzyikuxtta
 * Smoking Wheels....  was here 2017 ltlqselxbffpqicwwlsnlvvpgbospcrgzzocqktjtvkpspoe
 * Smoking Wheels....  was here 2017 wdyyabvrtsbwxfasraxcgojmddyzeghtedamukhlnzomznil
 * Smoking Wheels....  was here 2017 wgeuifmuenuhrxjekxrgbxbcisfchdivzjcseodwjatdflvo
 * Smoking Wheels....  was here 2017 qbglfcfqetchbypurgiorozcxcfslqohfbkrvxqmroembkzp
 * Smoking Wheels....  was here 2017 srjmnmewyrvoogmhcljwdomhgvduhwweuwrkcqinahesltat
 * Smoking Wheels....  was here 2017 vocufhqiuvfcwxxsueoeucexasjotdnsbuyfngbgijlhoeko
 * Smoking Wheels....  was here 2017 ajfkrugfjaobvgchxjzxeqwgaunlabzkkxmtxnzkrzwywlwu
 * Smoking Wheels....  was here 2017 masrlmvwnhpxsxppadxncyraliodonyarrvthjjvmtppasil
 * Smoking Wheels....  was here 2017 trxdjblxkxeiysaiuzvypaxbpwqoapkquttiaavrilblyiau
 * Smoking Wheels....  was here 2017 ntiqknmhjlngdujnhnneabeodgczjrokabhvqafhbcwywxli
 * Smoking Wheels....  was here 2017 vysfzbmdbryyhmxktrapxnhwxlqvtivxwttuyaqjwzzufghv
 * Smoking Wheels....  was here 2017 yddgofiuhqdvpkaoqqqubekpbveuqkaxchpbzbjtcrmxpnni
 * Smoking Wheels....  was here 2017 hnwhasbxgraollmssuwmozvrzxuuqbajqhqsdjbpizvoabib
 * Smoking Wheels....  was here 2017 rmjekmbjghtdoqfwzumwsecgflzbupcpvswawknhmxpdrlfo
 * Smoking Wheels....  was here 2017 bsnyzuxizgrsvklhrqneagdrsmibfrrccsqqbwvmruujypwn
 * Smoking Wheels....  was here 2017 sdhyicldgqmulhrmhkgbjyzpojtlicmqfrkjsujagcnennhb
 * Smoking Wheels....  was here 2017 dxytgdtnftcbwfofppfhuezxdqkfwzneehafejsbvseujrqi
 * Smoking Wheels....  was here 2017 amaewydgfcqlufdnoueyogtsbarntsyafnkpzdrzipkqrply
 * Smoking Wheels....  was here 2017 lliikrgnxmnddsoqlzfjhqclfqhvdwfswlyaztjlvcclvejo
 * Smoking Wheels....  was here 2017 puwmlvytdzjpaghbshnctacsssbwlhdyvocjegdistmdonkh
 * Smoking Wheels....  was here 2017 zqxgvefnawdoztcpedraakdkxweoldoucnqrxvnupiwxuytj
 * Smoking Wheels....  was here 2017 jlzlpqmszqyyqgxfuglejaurkvaczsulyfqgtzldjxzgrcwg
 * Smoking Wheels....  was here 2017 swxdaminoefyyexfulvwkjxxdqhyhqgmwujsmlycdtrurvnt
 * Smoking Wheels....  was here 2017 hvqqsfohslozcbqbrzesydoteqvuttrqqtivefjngkcnlfpw
 * Smoking Wheels....  was here 2017 plnnmmgrmtyvmvtofgymzjbayiwpcfzyeritdminjqsrzqkw
 * Smoking Wheels....  was here 2017 kfbqiivnhrljwngskwyixfbyznsogilqunitxtpniocqkshf
 * Smoking Wheels....  was here 2017 qtzbpzuatznwcniulvemffjwggccktmfylskhsjdhkfddgbt
 * Smoking Wheels....  was here 2017 pzkcwyaostvrjmlgxgypscbkuvwzzhwmkxxokkwgotedyjrm
 * Smoking Wheels....  was here 2017 tcnixwqshffpeeiympulmvmmatfcqamkdntgnbubvjjurmhp
 * Smoking Wheels....  was here 2017 wmxpvuxlxywnetyuemldwpgfownqikqhlggwecxwzinppdlq
 * Smoking Wheels....  was here 2017 yvjywymvdtfqgoncfvzyjyeahflcgysptfrxfhiibwmgbeuk
 * Smoking Wheels....  was here 2017 favrrudgwrwlqfmjdwqnupjmhbxevoldwvogrpjjlpkrutiw
 * Smoking Wheels....  was here 2017 ehrlybbkgyspuopkryzqgnenyyattivxtvsywhrbvgrbsfgi
 * Smoking Wheels....  was here 2017 pajavtmdpfzcirtdvttjaydgwrecypcercchivbwayzwadbg
 * Smoking Wheels....  was here 2017 kvslpbcpoezcfzgxvfzaqidczhcrpzqkctayxxpkewfvdkkk
 * Smoking Wheels....  was here 2017 ystdvnqezylaqameenzfykgrjbqcdjflvhbqroqnqrowsciv
 * Smoking Wheels....  was here 2017 qvsphvhnatfqasfsqbftafvwkpykgvufuixnwzujbbiftpzu
 * Smoking Wheels....  was here 2017 goeqcyilbemwcckodmoscylvspmswsobgvqvdrvjhdggkmwt
 * Smoking Wheels....  was here 2017 uowkndjeraqxsogyatylvbzxdfundqaktxogfjydlefscqsn
 * Smoking Wheels....  was here 2017 muwedwhbuhiecsfksarmyhluvqwopmwczacneaknxsjonekc
 * Smoking Wheels....  was here 2017 wlkmswctlilkskarariqnrgielvsvhccyudtjwushoczpkgt
 * Smoking Wheels....  was here 2017 qwagjdeccqeofsquwlpaxjzrtmcfumwrxfrgikabmsbkoyry
 * Smoking Wheels....  was here 2017 vtnmjwdhiaxvnbhzoepyqxkelshmrqqijjypvjcgonfotrjn
 * Smoking Wheels....  was here 2017 qaxnhptqzngqvzkuocozmzsnkmjgypfwctnqzskcynpkyrjk
 * Smoking Wheels....  was here 2017 pwmyzzfwglesojtzppzzopepziklgmmgaydkbrnvglscziuy
 * Smoking Wheels....  was here 2017 mrspkbtvliuzkhfotiszdzknuavhnqrulywgqthsikeddgep
 * Smoking Wheels....  was here 2017 fdlmybbqfynqiectegsivpgrspjgyrgyuxzsnrvnirxevgfc
 * Smoking Wheels....  was here 2017 cdradlxskjzemovdkmhojfurwkuyzmymxfzstkkaouafrlxn
 * Smoking Wheels....  was here 2017 qwrsuyjqdwdgiickemzowujlpyjkhdsmtorfrerlsnykrfjd
 * Smoking Wheels....  was here 2017 ntakynwjvabvmpxqnxoipnodpzluuytdnwapvmlcqyjfzdej
 * Smoking Wheels....  was here 2017 ulkeylxabogcyslaqrahdyfcqprospozthkkaavrkjcibbzb
 * Smoking Wheels....  was here 2017 rwxiiekysognxgfdazrxhukzyczklxvtffhmhveamhjsndtf
 * Smoking Wheels....  was here 2017 rfumxkjvyibuscwrlebcdznruanhrznmwjlyzcaiknookstb
 * Smoking Wheels....  was here 2017 ovpltffnakuwejltxzxwzudhwcrkjewmyqxaqigxcciiuijc
 * Smoking Wheels....  was here 2017 gmcgdtmerovyckcnrhhpirbgalcfrciezfzjcfymqinseykd
 * Smoking Wheels....  was here 2017 czigrmaetwvluuhoegmubkjejirjbppjsmetjtlwltkqgote
 * Smoking Wheels....  was here 2017 npobcfydiptcokupfjzjfxlyhipwevrbcdgitfhfcegixpql
 * Smoking Wheels....  was here 2017 gshlowozuhrvejortfohblxskdgxzbuolbgiwakynpvgiron
 * Smoking Wheels....  was here 2017 jyimhsmvutawoztaathzennvoxhxqyihfmljmywrtjyczofc
 * Smoking Wheels....  was here 2017 bgsnwfncealrwxwepdkzkvkzxwppojbcetjgryyhfzvtolof
 * Smoking Wheels....  was here 2017 wvrddbujbkxxozqwdulctixbvpixnjyyhpucsghxogvnyrvc
 * Smoking Wheels....  was here 2017 lbuediqowklniiadskfkpipdxwybjifcvxtffjsypfqtjvli
 * Smoking Wheels....  was here 2017 xqvqddqudwosbgfgmwsgkfiqbsalhwhcgvodyziamecffteq
 * Smoking Wheels....  was here 2017 kluxtbqmuuwzzjrraifebuffimmvuwyriuqtzdlaorlvfoza
 * Smoking Wheels....  was here 2017 mqzottsfymhympdgbggbpaoteqndljbwcnwbqzrcmmavhqat
 * Smoking Wheels....  was here 2017 wsxjfggyznyqhzoxohqxhczieamohtyxtvgllbwqcrmppovj
 * Smoking Wheels....  was here 2017 ogilltttmqgfixeyujicuohkfqbolrziuzalgccgootwpebo
 * Smoking Wheels....  was here 2017 vfidztdbjxwcuylxgpreucppjvdujxyxzjtybbswfpzpzqsk
 * Smoking Wheels....  was here 2017 dudzrzmmsqrabzamrmezkrgtcdwhtptpipfygdhorrozrgad
 * Smoking Wheels....  was here 2017 fihunkcxxjvywcztcqopzpvbyiqencrsarluhxruutdmvqkh
 * Smoking Wheels....  was here 2017 doprxhomovtbdslxrzyhagdxukdyvadtpsrbcaydtfqtxrpp
 * Smoking Wheels....  was here 2017 bkbyjbuppdcubixnasnsiliwutghefwmvempqmmnxneuploc
 * Smoking Wheels....  was here 2017 nzyeqnuwbouvbxciufwqacrwhwcdeuvwrrplhnvbvmeuvhna
 * Smoking Wheels....  was here 2017 htufwpyfjrxevlzjzeueimvbynesucfgjebzopveleieuvyx
 * Smoking Wheels....  was here 2017 ijkbinvtdfxagktwxnfpxcpvoualftnclufshmqlvxmrwxom
 * Smoking Wheels....  was here 2017 xstdpuhwgglupiwiajnnlpcuizpavoldqzmmmdmukdufvrgv
 * Smoking Wheels....  was here 2017 maeymckeubjefbbobfeucapvopblksylylsknubittsznlid
 * Smoking Wheels....  was here 2017 vrdizmnpefxdwuiobrzkepucykuwvmhgpaxtyydmtsvmfvfy
 * Smoking Wheels....  was here 2017 yiljmeggzmkwktvofrztdulzgolthnwccyjdngwwnkbigsqa
 * Smoking Wheels....  was here 2017 bxekmpkocxowcqacbjkkxircsfyufrlseppjjunjlhpokdoi
 * Smoking Wheels....  was here 2017 sqnyvnccqvfthhrxifvdmeujqakygbycwqjmstscdevhnnef
 * Smoking Wheels....  was here 2017 pvbxpxqvasontutaawzbeqlwrthjkaqnjaswfqinmdjbwlzd
 * Smoking Wheels....  was here 2017 sgnibaqvulajjnksjfynockbqkepveynfxycpckeoldmutqw
 * Smoking Wheels....  was here 2017 itanthxmwzfthbemxlyakjuoshahzipwernyzfhauqipbpel
 * Smoking Wheels....  was here 2017 yotaompljqaibhschznmvjzfgyyjmrnnebhnqeoeunhnogub
 * Smoking Wheels....  was here 2017 hahtmozqrzrcghaoqnmwdinexfjbhmaumxfdclczkdssmkyh
 * Smoking Wheels....  was here 2017 jwjrvurdjumgvlidcxvpvugwmcyuqkmdqlqigtzdttmxgwiw
 * Smoking Wheels....  was here 2017 lzbfepojidefaiaifjwftlgxcwohxhqkjbbacdonfysbptxv
 * Smoking Wheels....  was here 2017 yoqxitqysgprfvxythbnzgxdfdkmuflnqkfeytjglnxikkyk
 * Smoking Wheels....  was here 2017 szpnigitwsxqcaxxqjgpumutjpvpfpeuslefkdhrgmpfwlwc
 * Smoking Wheels....  was here 2017 rytfngezkiogpggoemlutpsdlknakzfschgqfzknuduiksks
 * Smoking Wheels....  was here 2017 cjbhlhbyfdezyejjwvxrriuxptjotgianlwhmhbplaossjmg
 * Smoking Wheels....  was here 2017 nkxhxcaikkqnnqackvebprjyfgnbymmuzmxgmhvcvyiotrjy
 * Smoking Wheels....  was here 2017 pmtbzqlzjscvarduudazwvzjvrktycwgtjjwvlpiuyugrinj
 * Smoking Wheels....  was here 2017 kgjrydwbsuacktyrirnvahopjbqcxqyxhgmsgnkalhunycqe
 * Smoking Wheels....  was here 2017 dquljcfzhtzuvjxhmqwexudhzsdugzlnjouowlpafooiferm
 * Smoking Wheels....  was here 2017 iuiycgmigwxptltkzkqumiahzdcusfjdzzdnzmtlrokwkwwn
 * Smoking Wheels....  was here 2017 sflbdobayqzmvclzwqpuecxtaevhftvzjkmxcdtstgaptuqu
 * Smoking Wheels....  was here 2017 glztvfnfzxoqapeiihummpnbzvbtwdkobachccrlmaifquta
 * Smoking Wheels....  was here 2017 gnylrusfhsimmqlyxnlleoavzlrvfgtrsfonaiwnhjlquzeh
 * Smoking Wheels....  was here 2017 eoqrpystyiesrbxoisdnkzszimunvevhksprddwcvbvccscv
 * Smoking Wheels....  was here 2017 tyngnrxrhigigypfoprtkbfqtvwztiwrjjhabyonwebaupzd
 * Smoking Wheels....  was here 2017 akkhwgvcamzndqsfxazmuhjealnrcfijbjwfnmbmqacdhmoz
 * Smoking Wheels....  was here 2017 euibdcilzuzrpurzvflhikfgisrjhuxdgdwzrtqvlcbjfmuj
 * Smoking Wheels....  was here 2017 ujoedznigqepzfgiconzbjetzclxbcqzzjcmtyxtxgjypzwp
 * Smoking Wheels....  was here 2017 nlqlyvtqfmsdzajhrszqjlturkhninqdkyoajptoymqhonhd
 * Smoking Wheels....  was here 2017 ktiywypnoeznpogbvqxoscvugsusgrldcandhlfyqbvcoztu
 * Smoking Wheels....  was here 2017 sfraltwjbtrgymjfbmokaaniugxdhjtttbnrpkqtjpbigmgn
 * Smoking Wheels....  was here 2017 xzxfnaruxlqylplmcrlxggcjsqtsdtnzksjspsqeuvteqjyq
 * Smoking Wheels....  was here 2017 tmpjdtjrlxcpwblwyvietafzqqussdzbhxapvxbnswncvgip
 * Smoking Wheels....  was here 2017 finnocnfivjkbeprvxhnbtrpkhpoeeooxtvvcrynhxhugzdf
 * Smoking Wheels....  was here 2017 pnsbkozsjhevgohjhconagpudwdxzszfzthinarzwogfrrhm
 * Smoking Wheels....  was here 2017 ifknmxwxspjowbisbtsarkhofyntvvganndcjevcdqtnyraq
 * Smoking Wheels....  was here 2017 ftdtudmotgdnovqtcqmcinjyhhehpxoguzmmepggxclfhpvf
 * Smoking Wheels....  was here 2017 ewtuskkxcdwyidltrowbnbrifzsyoojkginctazahhgzdgkz
 * Smoking Wheels....  was here 2017 omeztgnipefghrfeitglctglchclbpkhryvsfklirujuevrz
 * Smoking Wheels....  was here 2017 tstxtjwkjtbexhqvsqbecombhslsvepwbofkvbeisicthqxk
 * Smoking Wheels....  was here 2017 pbajttvavjpqwarsxwcfvsykmddzvpfkpzpndjbjgyeltgou
 * Smoking Wheels....  was here 2017 bcslbrzkpvfwchpbdjkywsnvmnwrenrlwmjqzdcdkzmlxpix
 * Smoking Wheels....  was here 2017 ivwmgndwmeogurvlwghyahfykfnmitssolzokhsmoydunset
 * Smoking Wheels....  was here 2017 ziuacdlarsnokabowafzhllrrtgkzlhgsngjscmoiroqlziq
 * Smoking Wheels....  was here 2017 scyyskevmzgsomimciafbitdxwmobxqinqfkmbftoellxaga
 * Smoking Wheels....  was here 2017 oufgipzkpsexfiukxarywnztxsvmtueknycfnvarksqxjrqr
 * Smoking Wheels....  was here 2017 shnipfrcvbyoogxwrimrmrgcwmfumyrhkxlqwlggfwizlbmp
 * Smoking Wheels....  was here 2017 suesgyipifllablrfrziavwcdtumylbzgectvdmoqlxwdnac
 * Smoking Wheels....  was here 2017 hrtgkuhsluvliwhtmsxxselxhhytcqpsgqzwzinbnmaapqqr
 * Smoking Wheels....  was here 2017 lryzizervnmvibtltijtfevwhfibberaxmlodvnjafodfhdb
 * Smoking Wheels....  was here 2017 lqwhpzuuindyhefgntomhqcretwcixbszdariouilhsdtplg
 * Smoking Wheels....  was here 2017 susraohtcapppdlwmibwzlodjlsuoxsslhlhwuxclkwgcxtp
 * Smoking Wheels....  was here 2017 cncaqrxllpbqyzjjsupzpxwlldgjrnvjputrizscyqqymvnn
 * Smoking Wheels....  was here 2017 nmsjtniybayjgdgalbgesmuzivdgwkwcwwfloxixzhzwgfnu
 * Smoking Wheels....  was here 2017 gqrczqisuiwdtemhcfhbdwmjcvhdpkptaxklnlbmzxazedsm
 * Smoking Wheels....  was here 2017 tderbtajswtsvywyntfjybgmervampxhbpbspxnxngendzgu
 * Smoking Wheels....  was here 2017 vjuacuuthdsbephaqjvgkisncdebniczgvfpjunonkbxijqg
 * Smoking Wheels....  was here 2017 mahekadabxfhskauswczcdruviztxgoibudqotedbqpvfdpr
 * Smoking Wheels....  was here 2017 warmmyzpxhxxramtgnkevefykleszeadgxjsgvvmonzgkjbz
 * Smoking Wheels....  was here 2017 pngmffjczmpqlilqzsfprlsygcvynfmjvwrvufbspuokymhm
 * Smoking Wheels....  was here 2017 izoapxqjqdojtjumychkxftvzblrltdiancjtlsgaoarxass
 * Smoking Wheels....  was here 2017 bzidyfkpnzdimovoiprwdxdbmkqhxklnhbxwwewtabgvuvbj
 * Smoking Wheels....  was here 2017 coqfwpmelbzzvmyjrkrochzfvjhnizdqlyqeglwbywjthchn
 * Smoking Wheels....  was here 2017 xtsuduzsprzagzxrrxtixirfknoilpdumvbifmihktvrhcpl
 * Smoking Wheels....  was here 2017 gcdsvugcijikkdrmkutfwgsewrwxdpseppfsgsaxguhazmmo
 * Smoking Wheels....  was here 2017 beqafvwlfykhgjkcazrpnoznbvvrpqhihkjwgxcmpgpovbrs
 * Smoking Wheels....  was here 2017 ryhbxjqfelvdzgqycpvzrypvcijjioqajtapgbxyxryemacx
 * Smoking Wheels....  was here 2017 npikrdszieprzqbvidrgklwbjrrxxkqgufzankzkrwsbxqyj
 * Smoking Wheels....  was here 2017 jmixpdjqbptwyqputealagjhnrcnjpphtuhlrjfhwxpshntp
 * Smoking Wheels....  was here 2017 fizoypgiyptvvpocosxxbvzyikipvtxpvpekmsrdozluapel
 * Smoking Wheels....  was here 2017 izktizelwfhcvdhehwpfiytqacfysrhatbfualrydtlhvxfv
 * Smoking Wheels....  was here 2017 esvbnbfqyrejjcpwscqexobgxizkultnmvepotwufyzipvca
 * Smoking Wheels....  was here 2017 mwvhptttpopncpketauvdxmyqwzgxnmjhwbgsdacrpsloygp
 * Smoking Wheels....  was here 2017 hdcnwiizjrauyyyispbpmmvbbuwwgkybqidfgihlqanhddjg
 * Smoking Wheels....  was here 2017 vltbwhvrfbzqevrwazuyvzfhhjoahbwjiqzkghzulupvzmma
 * Smoking Wheels....  was here 2017 oyzmlhhlezmtdbhnnpluekansefpsmeiikjwbhrftqigbkte
 */
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class autoconfig {
/**
* Generates a proxy-autoconfig-file (application/x-ns-proxy-autoconfig)
* See: <a href="http://wp.netscape.com/eng/mozilla/2.0/relnotes/demo/proxy-live.html">Proxy Auto-Config File Format</a>
* @param header the complete HTTP header of the request
* @param post any arguments for this servlet, the request carried with (GET as well as POST)
* @param env the serverSwitch object holding all runtime-data
* @return the rewrite-properties for the template
*/
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final boolean yacyonly = env.getConfigBool(SwitchboardConstants.PROXY_YACY_ONLY, false);
String host = header.getServerName();
int port = header.getServerPort();
prop.put("yacy", yacyonly ? "0" : "1");
prop.put("yacy_host", host);
prop.put("yacy_port", port);
return prop;
}
}
