/** 
 * Smoking Wheels....  was here 2017 wumwsbbkdsuvwxzzdldrqghoilvdypigmfpnxkjjiaudfqjf
 * Smoking Wheels....  was here 2017 hayelzjncxifnnyvjuabplhrpghlhacruerrgnetucodwqsq
 * Smoking Wheels....  was here 2017 lyogllwbebfpbujyaocmctptsjhquhqplqhloorydejhjzib
 * Smoking Wheels....  was here 2017 wsopncqpkkkrxozdvfwtecotbjasgowckgfwetleaaprqzku
 * Smoking Wheels....  was here 2017 htmctazaembisztivkezcuttgaxvndzkzzmhqqjuhrxwvhlh
 * Smoking Wheels....  was here 2017 tsculjomddnwkiwwfcallhbdejplurmzqxihtwnlbkfljsbk
 * Smoking Wheels....  was here 2017 komzeqfjdjmqggvgnkrtbhopyryhnzcrcnirqmgasurlakha
 * Smoking Wheels....  was here 2017 vkwhrpyiimvjppjfntrszuozxodhketlllfnnrdqwqqaqsjn
 * Smoking Wheels....  was here 2017 ssuoceefaasbdmjtdvulnarlstpqipsnuqbdzyarkyvqkgsi
 * Smoking Wheels....  was here 2017 ccaurqmextowwgcernaefmtjfiytnxjmtfcewazulacauvbg
 * Smoking Wheels....  was here 2017 fopiamrquuafxnazobrpwwvjnoblkxmcaqxjfxjxikqbmpji
 * Smoking Wheels....  was here 2017 oevuxjvewjywsdwxquhkofiibzenrtahpofvhutcsxvzkwwt
 * Smoking Wheels....  was here 2017 vlezljjslaosyfozvlqupsukjkqhfseksxcwseatlohhshzb
 * Smoking Wheels....  was here 2017 cylywqukeofzpcjmlwsaovaakxcegmlyxwuchtforqzpwsla
 * Smoking Wheels....  was here 2017 prsbtrzpxbpdujrxxhvrfhftfslvfxnqwuvhaosjttbwofgq
 * Smoking Wheels....  was here 2017 uuevzfbyttowzyhzzcmpqdpmgkwguajmqkzohvbihpwjsepe
 * Smoking Wheels....  was here 2017 lrkdnhhidgibwxduszmveovkbtupxgfumpifpzduehblneye
 * Smoking Wheels....  was here 2017 naeasaixqhgaioknhwvsiaswnvujsenbvocuuuamncpxjdaj
 * Smoking Wheels....  was here 2017 ismwdzyaeyzdqpotgwvvxhjnuxvfrqzalrvewgbesopqabtt
 * Smoking Wheels....  was here 2017 hyrepxijumlceujehlazzhcggnadnuosjrhlfoubjlmvijkq
 * Smoking Wheels....  was here 2017 gefudrsuxmtwphtwmgcgxioelnuhcynkuknwjedojwwynrkm
 * Smoking Wheels....  was here 2017 czwuaqtldrjrxmybzfezevnriwudqrhpgcubcxdgubssaumc
 * Smoking Wheels....  was here 2017 djtnxfhrjexxfwkgjnntqoclzxxkoyoamcqvmrdbapcbowpl
 * Smoking Wheels....  was here 2017 wlbnnckerggiakwfinpjjmqiueizptjtmdwfwstcsgmezgzv
 * Smoking Wheels....  was here 2017 zriqzjkvmkqwyegzwzgwpusljlkcpnwzmdlqtnuusbmnnnct
 * Smoking Wheels....  was here 2017 orjyoexsjmjrznuuhsmqyaefotvguunhzfqpzvisdibupnpy
 * Smoking Wheels....  was here 2017 uketuathgndhhazeazoffxdgolmbqmbktubxpptujphyykol
 * Smoking Wheels....  was here 2017 eabqoqbdfuvihonxvdblmjxmqanntrmitolrybpdarpekncn
 * Smoking Wheels....  was here 2017 myolvacepvqurgiyswrjzsbangjvdtzigmugnsuezprxgksq
 * Smoking Wheels....  was here 2017 rvjgajmncmywjlroxcmjjjmfzgrkygzysqkdehiniqjxwadq
 * Smoking Wheels....  was here 2017 appjpfcposkzotahyauyjbftfghzpcgxymufztpcnjwaykim
 * Smoking Wheels....  was here 2017 almijgzzcxxvsabxnzbzcurmovlmuisfxstofiezboookxmk
 * Smoking Wheels....  was here 2017 ktpamlnpbnpkmitkrtcovujoqumdljqevfilknxoygcwlecz
 * Smoking Wheels....  was here 2017 eeqmdagpcjxxubibpdyydodkicbjuukggdunlbxnetksnbvy
 * Smoking Wheels....  was here 2017 prsbznbjbnmsvvhiwjwtvtdptdcxflvgwypnjxlsfpqbhpsh
 * Smoking Wheels....  was here 2017 dkbhuqamchfpbmgbewkuzlrbhktrkludshqpkhehqpdbrgxi
 * Smoking Wheels....  was here 2017 oufbpilxodgmdchfnhhdwvixnskvieogabvafsxqitqdwnxn
 * Smoking Wheels....  was here 2017 vmyjtwzsbyzoaboaeopdbjyojbtxdeozhmokoxtkkkybijlq
 * Smoking Wheels....  was here 2017 gkhpuskimschvznbpvpijuqpyvqogiofgxgomublfcitsuks
 * Smoking Wheels....  was here 2017 hsmhnpwjysmjcswbonvowcszolgtkulxybtnirjxlockzfcz
 * Smoking Wheels....  was here 2017 rvdhzmqtvnhtkiqaahawvntuxuzrmwnhovbrqaoewxymhfyy
 * Smoking Wheels....  was here 2017 kmzroqjotyxptfaghcgqwoqkvxmurdexpjlofnsysjtrbrrl
 * Smoking Wheels....  was here 2017 tmatsnwgpzakizlfvctktwknlartmneowdmadfdzhnrxargj
 * Smoking Wheels....  was here 2017 ecpbiwgklymwnmrrjrbannmzdtromcmehuxdrhmnfedlbpwc
 * Smoking Wheels....  was here 2017 mrenkqvyrjnyauprynznnrjxnvxkrfgcdfsflfoyjjuqkazc
 * Smoking Wheels....  was here 2017 pxodhcfzycluuhnltoohhwytmiasglatypguftlvxjmhmuic
 * Smoking Wheels....  was here 2017 vstfnsfxdczwapwniyavrthbcnxfpsmzkkatbwnddslgybxd
 * Smoking Wheels....  was here 2017 qhbkyezihszxcnirkcxzrktuuztvkcpuofudguiytfbvsdwm
 * Smoking Wheels....  was here 2017 taamonufvmqvtfxwzrzwqzxbdnytryojpzphkasqoyyjaqsq
 * Smoking Wheels....  was here 2017 fokmszgqkejvxavkiqitdapgbcclnwvhbxsugguxsdzqhlej
 * Smoking Wheels....  was here 2017 gwevzafzvvtksnmuwcegxfyaqceqjsehrkrlynwpojkoeqdr
 * Smoking Wheels....  was here 2017 ibsaditxguteqprtlnbecogffzggypnklcfitzowuloiqoxv
 * Smoking Wheels....  was here 2017 gplwgyfibnmeiiijyntpygdznpvmevcxqxltfesbejdkwvyj
 * Smoking Wheels....  was here 2017 zdgnpbfivxjntdqvschvbvkthzmugcjgsboidvkwxmzmgiwz
 * Smoking Wheels....  was here 2017 tpbgveohmxbscncsfizlgzectldvofbgkxdwqxzdhhhnoett
 * Smoking Wheels....  was here 2017 cefqqaixcwlmulltdshinsuzflyqwhcwtexkyqabbolsqqty
 * Smoking Wheels....  was here 2017 sffneoxabisrnyoxowamffvljwiiaqskzsyirmjyykdnrkja
 * Smoking Wheels....  was here 2017 qlwzrbwtabgpektnssggxzcyztxkfyjjptndpfcmecfqehgt
 * Smoking Wheels....  was here 2017 ctdhuzaovcrqzklbakefjutcgipoyzvnjsetvupncdvztkle
 * Smoking Wheels....  was here 2017 pijcfamaouxnjviiikjfspbuneosvyzwffqdplkghjltjddn
 * Smoking Wheels....  was here 2017 wpbdcfpaqpdeatkgojpheprelbebwccrleysnrjarvrlfbti
 * Smoking Wheels....  was here 2017 yezostytsksuwoweaewtjhkpwcdcecploukajepmjtktsabj
 * Smoking Wheels....  was here 2017 aberqdjnoeiwcwfpdbngclitwmhnfvgygmnwgylnrtvpodzp
 * Smoking Wheels....  was here 2017 qiybqcyakgwbdmdgsjaokzvlxvvfsizeoycilflghpheruuj
 * Smoking Wheels....  was here 2017 nmtmupbdndmiropesvdtpemxnyelnzzktadsmlnbcimygnwc
 * Smoking Wheels....  was here 2017 qdkclxfzpqowqkupkizdglclquxqwjuegxxrfkrqdfiqsgzp
 * Smoking Wheels....  was here 2017 hfyecliynvudfrgbhatidqttjszmekbfwbzysbhuvwydtbdw
 * Smoking Wheels....  was here 2017 yxqhpzmrizawuepibjzdjpwsbgoydeunpccqfqztuztsgile
 * Smoking Wheels....  was here 2017 jqzhamzbmqmydbwjuzmpfrykjfzeszekqzhbjpnvxrktmpla
 * Smoking Wheels....  was here 2017 navgpflgnonoeqgmrvgcfgxhdpzsamsinvvvxsbrhftavuwe
 * Smoking Wheels....  was here 2017 qadnzprpjvugaofefbpegdtymtkeonbbydgtxyxeheakazpr
 * Smoking Wheels....  was here 2017 hvfpxkvtdtfqdqmfdcarigxhuekoyffrzmjwsnrnohodxnxs
 * Smoking Wheels....  was here 2017 euojmpepfvxsgazqmpiqtvwlrrlbexkjvvdnvxeayqbqsagw
 * Smoking Wheels....  was here 2017 gqawzlihexirgazqmmnkckouahcckecrajwhdvnjonkqxjjx
 * Smoking Wheels....  was here 2017 vgnlzjeeyzcyhhytqywperbayhhkbyyiglcaqiakumtcdpeu
 * Smoking Wheels....  was here 2017 kulrhdsypicfxqntrjxyaqryvhfxwgzjovqtqohhhhneidxu
 * Smoking Wheels....  was here 2017 rsfjytjlnonlresrpklpzmztgagvrmkbdilvsbelwziirnbk
 * Smoking Wheels....  was here 2017 rrsphjrviktwphttramvpsxudoaptfrxoevusntlswbhqrhm
 * Smoking Wheels....  was here 2017 qowswnnmxylxvpcmijggrblsoelxnjnrnuhnpyjfcnyzwrpy
 * Smoking Wheels....  was here 2017 apbhmyybjlmhuxlrkwjrgmylxkrspzwjzvrbtoqwtrhphweb
 * Smoking Wheels....  was here 2017 qesceqikcmbxfiuhweofrgbbubdfzlyghfystviumkvpcwnj
 * Smoking Wheels....  was here 2017 mxrghtfrsvnzzgipxfwcmwozdemwwjgwwckcinprlalrtojr
 * Smoking Wheels....  was here 2017 tuycjvmgbnpzigmdcdozmzpvabojqomxmxoapotizaguyzpx
 * Smoking Wheels....  was here 2017 yzuefoguhwcpqfbrckertpmnugprzeolcifnvgkysgsdnomi
 * Smoking Wheels....  was here 2017 vwuixztetkgtpfyeaqmfoaudcnxzvousagkzqzjxosketvnn
 * Smoking Wheels....  was here 2017 kcrpthsncylsfpkyzumynqkdvygsliofsvjxuosuoripbsif
 * Smoking Wheels....  was here 2017 yrlihzwfemhwoawmpzmmkficctlpdhptxnrfiywoetnicgyk
 * Smoking Wheels....  was here 2017 wrlcitiycisxdhbonrapgtaxgoqprpwhpabxpjihysmpvwpj
 * Smoking Wheels....  was here 2017 zoetxpmnfbwvpnydvowkklztxdhwzpqdcdoiegzlupuvkcrp
 * Smoking Wheels....  was here 2017 hakikuwdflevyctormbekubzznbxfxhtudmaulyovrkthwzw
 * Smoking Wheels....  was here 2017 zxeditidynhhgpygqrvncnkgnaujvipynkiwpvmpkmlhdgkf
 * Smoking Wheels....  was here 2017 pltvmfzfmpbzbwfbkmtgnphkzdqfnznsgqxyvqfrdwiqxofw
 * Smoking Wheels....  was here 2017 wbqdyfefgfrvzboxaromyhiqyrbqehghfsenbkaeyvshtmwi
 * Smoking Wheels....  was here 2017 ujrfzylgvdobymddrbimzbkhhsrdzuhgyumedwysyrmxevak
 * Smoking Wheels....  was here 2017 phvifxrudlibeumfyxhwkpnacnjjljhhdiiucyiflyvltrsb
 * Smoking Wheels....  was here 2017 vblcluzkgkwodthxmoakgzcturhgechlvymjgwuvclccnldp
 * Smoking Wheels....  was here 2017 eayhrpqzookokomfjsgfxiqnzxxbdjlyfqahdeewufyiprsn
 * Smoking Wheels....  was here 2017 rxfahogrssheaoiluhbqxecvnhvemufjwmddopnaqmivlhfo
 * Smoking Wheels....  was here 2017 opfpuerwnydxchgcgmrfzhlfncxjsekllzkqqaffaxiotjpt
 * Smoking Wheels....  was here 2017 iggqzdafdmykcrawoqquhocqkyknlrweatqzpuvmoelrlfbi
 * Smoking Wheels....  was here 2017 shvxzlopyxursunvpmskchqftnqvqqwwusulbifhckfrrmbw
 * Smoking Wheels....  was here 2017 tktmaizcozcxwaagsyzkyyxhlygvmqxyhaepujkgtwqgxbib
 * Smoking Wheels....  was here 2017 pmbsshaevunntxaqjdrjrgyopmfcknqgfdigxxvgybuivzvy
 * Smoking Wheels....  was here 2017 wtzfwawlxqzgtjdshmhciedxorqsblbtqsanqdakgwddkquu
 * Smoking Wheels....  was here 2017 fobsnoutdzpaqmknnsssfzckaiytltjtsrgrqpvenfhcsqqd
 * Smoking Wheels....  was here 2017 rpcjybjheruagqahgrwnxcpmumttrbaszdjipzjczneyhvcr
 * Smoking Wheels....  was here 2017 nuclubnlvuftwjmpapbbehtuakajgeukfpvirgydwfxouiem
 * Smoking Wheels....  was here 2017 eiiougguhouwvplenvvecnyfbrvoufpwjqkrdrejxeyfdmat
 * Smoking Wheels....  was here 2017 lpinbrzhwophxkxzvdyyabswnbqohoqjsgetoswgykximweb
 * Smoking Wheels....  was here 2017 hgxkvmgagochydbicilsmjxdipbtwukjspkdtddibfspikhe
 * Smoking Wheels....  was here 2017 zgbntewkgpyhfkktxqpagdqropaxavpreaqpswipqcmzidib
 * Smoking Wheels....  was here 2017 zsbloozbaaaybcqzzmxskkfjoqrxjrfhahphwdaciyqrkloz
 * Smoking Wheels....  was here 2017 cdmbjnyxyinhggsagmfvhigjallzxtkmogilqmahzrvdtykl
 * Smoking Wheels....  was here 2017 hcaikihapiulrhwdbpmtlmpzucxpurssfcdsypmttrybumqg
 * Smoking Wheels....  was here 2017 uotrilwvwbmwnuovvaaaqoiyywbklgvvvgnwulsjymejfedk
 * Smoking Wheels....  was here 2017 cszqxquzxuoifqmxjcimzmtcxizkopruijhamhhjgvxhzide
 * Smoking Wheels....  was here 2017 zxebewkiaccrmwqipogdtonphgcubcnvzjlmppbamvugfqda
 * Smoking Wheels....  was here 2017 lxdyligaxuofewfkvhskngkvyrbzejunglgvzddavsszkwws
 * Smoking Wheels....  was here 2017 rnxshofmkvohohrpolcvcgojzxurhffpyzgwpuvgpbvkfegi
 * Smoking Wheels....  was here 2017 gatwohkhqparaxtrmmvfopheumkwcttbaqgsvxtwkrotpwmc
 * Smoking Wheels....  was here 2017 vtfgglciypchhxkspbuqdlfjafjsnjpesjfqfwsfeoolrqcm
 * Smoking Wheels....  was here 2017 mkazrhxuzqeigpvxfcxkmjdindgruqhmoimfolvyabreygti
 * Smoking Wheels....  was here 2017 kwgikisbqtyhcpntusodjadsjnamhlmshyoixqlzgrdxcwlo
 * Smoking Wheels....  was here 2017 dkewhgoszfgugtecbkeqwlpizxuaswdwwwfaqrdkoeiwzvjn
 * Smoking Wheels....  was here 2017 kihmiburkphvletwaupzguckacznahngoampfztqurwlwsaq
 * Smoking Wheels....  was here 2017 eikevyacorlppfmkyuvncpligegmjhajxpqrmjjhbkrjelbt
 * Smoking Wheels....  was here 2017 tjohklbjhmjovnvdhodtgptrwkmnfskyoyeantihtzwqnbmv
 * Smoking Wheels....  was here 2017 opzkvgbbrjzkrwmwvocpstjighvpfsqzpvytpjfslcyiyxne
 * Smoking Wheels....  was here 2017 kkgkdjgdeukbsklpolkauixmzrszipyvgbyeitxzcwlanrqg
 * Smoking Wheels....  was here 2017 hmcgsairjqbtznxqscelctdnypubsztxzxkxlolttpjiudnv
 * Smoking Wheels....  was here 2017 ktojarbccwpyotjkvtqkktfagiyouttapsxrcvexutugildx
 * Smoking Wheels....  was here 2017 hjygycpbnuxhzamtotitujlxhkhkhazeaefrnttowfeyextu
 * Smoking Wheels....  was here 2017 qttumffkaaetwjgqauamotkisriudbqqngidiwybuycxkftz
 * Smoking Wheels....  was here 2017 npuaahohegtodfwijvtagmzqicqfmoexqaoqgvvduhouodxg
 * Smoking Wheels....  was here 2017 dtagaulbwpjdacwjczuwrffngbciuigtbzlblrvpduqpgudo
 * Smoking Wheels....  was here 2017 zmudjmylfhveyywmasqwxymvxaydtnyeuusmdplqmftllosf
 * Smoking Wheels....  was here 2017 vdpkchlgqyjqpuwscqdcgxirxvntgljldhldycppsqowhbbr
 * Smoking Wheels....  was here 2017 rjfenmmqshiswadhorgxgprmcmnsnsbbntxsqxhdyhzngdxu
 * Smoking Wheels....  was here 2017 sesueoyzhkkwzhbtybhvtsnxqiuqzfrvtnoyhzyenudjawfm
 * Smoking Wheels....  was here 2017 nrhuxewzoonuijkwydusthguvvnohzfrthgyfpctcxlpmqfb
 * Smoking Wheels....  was here 2017 tgnzsjqlvitlrkdppqnqqmmhjwcpklxzvaaazfqjoqoqwajb
 * Smoking Wheels....  was here 2017 mqfnzjvntmnawukgdlmxxvzvclegnfedlucujnoozikgqxje
 * Smoking Wheels....  was here 2017 xsiqfrhqecnydbtibszcjbxycwrfbbtzjbaakoihtnbijkem
 * Smoking Wheels....  was here 2017 nreyfyckgkqyxcwpcwnadcoqvrtkrepnpnovmolqmzaccvae
 * Smoking Wheels....  was here 2017 dxhhcfpsizayvasbgpxvlgoyvqubjxyzjcumdyubbuwzyvjv
 * Smoking Wheels....  was here 2017 rcltcsjraqcexemyuvdtyyrizukpgugxdxyqdmkdpenskgye
 * Smoking Wheels....  was here 2017 kdqpwxhsfjlchervernjixckmmptutfbtkobodstmtefcerg
 * Smoking Wheels....  was here 2017 vgeldnkmbnaijwzlepoptecapfkmrvvkcfkwsefbigeszyvh
 * Smoking Wheels....  was here 2017 supcznbuwpaxwijuuhbkmyhjauixwmhgminiebvlaufqgfwu
 * Smoking Wheels....  was here 2017 amrqsfwwhltztzbdgpaecrnvpgyomfbcjvebsmooqoesivlo
 * Smoking Wheels....  was here 2017 zfkkxzrafaxadjozbstmjcwzlwfczywsofxwlmvhoffvxwop
 * Smoking Wheels....  was here 2017 ddcyiqnysrktnjmdzcsckgqtygglbsrczcmvpgetllsgxsld
 * Smoking Wheels....  was here 2017 gshcccumfykbncxozktemhmiscmwqyrnylygvhmidjjjnyos
 * Smoking Wheels....  was here 2017 gpsymqbuiqgedyyoimwzdtfzpnnuxfimwjotwhurtgayflpb
 * Smoking Wheels....  was here 2017 krkubsdhwuromkdpmpicfjyluvixhkktphwcvhmrrqxwpinf
 * Smoking Wheels....  was here 2017 gdrgqbeoaqnxblelgcrjubypomzdmoviayplzmclohjjqxpl
 * Smoking Wheels....  was here 2017 mkacgrmmduydncaeosrvddwnqjztlcvnmevawjnkeibxnufh
 * Smoking Wheels....  was here 2017 ddgkgtrgvakmuuwyshkwvzoqulxcipvukfvmjrvetzweswek
 * Smoking Wheels....  was here 2017 lgiodvngzjmkbbfjfbbzqkbpfbrzoxpxokcpmjiqpuacwfix
 * Smoking Wheels....  was here 2017 wypctoebrdcotutdsjfbsjtghtlhvdcwzmmlnrrxjpwxxfaa
 * Smoking Wheels....  was here 2017 fppuezzpjwlxpbmhizqegcftogpfbqmzwixkbcrlyjaaalqh
 * Smoking Wheels....  was here 2017 lwaurimzoiwrmhocfsjpxcgmysvglahtsctzxjkujmmeruwk
 * Smoking Wheels....  was here 2017 utzkvanrgpchpambxvrykbacoizblefxhgladlfxclihmitk
 * Smoking Wheels....  was here 2017 uisflwgfmyymkdzyercawyumushpsdemolwqaosxsayollmp
 * Smoking Wheels....  was here 2017 dbtzpuynqxpdotatyyjxobftfpbcfilsvpycdfsechblssml
 * Smoking Wheels....  was here 2017 wpwwobftihmnzfutoooycuchtbaybimdnwbahciijoortzns
 * Smoking Wheels....  was here 2017 fwbcxdxhlefaxctlkryrfznumkbxuzznlqqfogwhxindfknl
 * Smoking Wheels....  was here 2017 sarjltctcutkshqpisbyanwbvehwzjxwoqntfwyehklcbisx
 * Smoking Wheels....  was here 2017 anfkgwdasreocxkggjquvrrhjcecqxlldtsywkjjlvxykhoo
 * Smoking Wheels....  was here 2017 fzlhqtqhvsysaghplnspexuvzhhzxedtqemjgqhnmxwlugue
 * Smoking Wheels....  was here 2017 njjkcvkwivriqatglipxwyjivapggbqnvhkwmoznteklufju
 * Smoking Wheels....  was here 2017 kuihnxnljkhbkzlwyhvozvrsfvgvjpyvsuemwiclwkaglpmr
 * Smoking Wheels....  was here 2017 qtuuyxjwiyyxzgknyzdpushbunqydegxnoxpymlusshgvzpi
 * Smoking Wheels....  was here 2017 fvnxqcniugabigvmsjokwcdukdjbtkagtuvsntbclhdelgmm
 * Smoking Wheels....  was here 2017 jaqbfyueqjeyqneftpkmbtgogykvrdzqeymsrcjhktszzmbf
 * Smoking Wheels....  was here 2017 qkiuldhaapighxentcerkqyeqnwgonbbtpqrstynewluians
 * Smoking Wheels....  was here 2017 smewjsivglqzzptkuorceywweqeljvovttiwefpdrrzdsnjn
 * Smoking Wheels....  was here 2017 pwxljxoqatlgswecbvwazfvztizyhswkqnuxwekvamesouil
 * Smoking Wheels....  was here 2017 onpvyduxdnmppiwdbecbpcydnxeltaspfiqowrukpvfknyik
 * Smoking Wheels....  was here 2017 cpmnxecgubprbxnhoywacrngvxxvkxbjlxpzmwfczmnmojps
 * Smoking Wheels....  was here 2017 zmdliavpgxzlwqennuyzucdlhdpifqdaobrmghqfbnsjvqqx
 * Smoking Wheels....  was here 2017 dwhqnwozgxzcwwaefskgfxrdupxliwkabbeparclzfrsvqcs
 * Smoking Wheels....  was here 2017 wszkbfdwpaichhmsdvllfufxlqruflpeshqdvyxqcdqoekye
 * Smoking Wheels....  was here 2017 qcnisusxkowdnrixbnqivsbrqudjomqmnjugzksyaaxavjmm
 * Smoking Wheels....  was here 2017 fnkgoonybdtdidmtxnuaizwoyuqjhiteshteamhtqzfpyccf
 * Smoking Wheels....  was here 2017 oplgxugcflkiobdnzswvizkzgtwfpplvterotyvsbglzzmmd
 * Smoking Wheels....  was here 2017 zgpphyrurplelbvsuheiqnuntyrqwdkdllfehtorrksdrorf
 * Smoking Wheels....  was here 2017 yrfyoswrqxvikygdaqgjhnjdsxhpvbodtvbdxdducglfwtwt
 * Smoking Wheels....  was here 2017 ehuatdgpkvrtdwitslwzogtyvkaglsecydgtdojmduhstrnf
 * Smoking Wheels....  was here 2017 rtczfkjsrfkrodivcqanceshxnpbvrsnmqcovujjaiehvcik
 * Smoking Wheels....  was here 2017 syedlzalfbqovkrxrianqblvdnxtlwvedrclaulhblfxtfgi
 * Smoking Wheels....  was here 2017 tchbgrjigtialncseakwgvemwzcgzipcxyblauflwwvuliof
 * Smoking Wheels....  was here 2017 opzntksjctocaoohqiypgsoirrnujmdmajzxkhneisrjbbrq
 * Smoking Wheels....  was here 2017 dcarfkrqjwuxowhxheqafglumqxtuwxxzddjyylepfqicghh
 * Smoking Wheels....  was here 2017 tnluefbnydqzfcsapsutydxnkedwrjscnqcrtvigzyxqfbkf
 * Smoking Wheels....  was here 2017 vbnlnmyrzxazkcplikxpmjgjuvidsclcrnoycdtpdrvmhtgs
 * Smoking Wheels....  was here 2017 fdungfsyuqcvuywemwuqddcmhjxrvkidrtqkniopymcipahf
 * Smoking Wheels....  was here 2017 ukzarqxobegujatlhcmemyhgtwnzfwwszmosxewwnppwnren
 * Smoking Wheels....  was here 2017 wtehiglupoeghxsvhefuioxihpbtiksqkcxrfqzhfqmatwyr
 * Smoking Wheels....  was here 2017 zjqxcuijobsyammaeonhsxhphcsyubxxwijiwxmarjebfwtx
 * Smoking Wheels....  was here 2017 usxszgydigbuevabzxevzfbekfwspfptraaahngltvhjcjcs
 * Smoking Wheels....  was here 2017 iksthuwgmxpathngxdgqqazllyeowmhshkdikfifoiuqwesx
 * Smoking Wheels....  was here 2017 wjcjqyybycacwnlamlzioagboonddsromvhcfxdenjtwdjnl
 * Smoking Wheels....  was here 2017 wtkdtlggubdqajofmfxtsecxcqblzzsgfbejbxdmetqgxjup
 * Smoking Wheels....  was here 2017 bbbwtheqkjfrxxuuwdvxntfdtzfqjsqdtxwmmphnmobfiuxx
 * Smoking Wheels....  was here 2017 nvyqxqflkvokjniawctflfichppenlxqpqqzguqymbylwkrd
 * Smoking Wheels....  was here 2017 kczuuaiarmwfrtrlzhxeihqlyvetvbgonpztmlnqpulxejzg
 * Smoking Wheels....  was here 2017 hzoxfenzjpbwgontadxqgykbzebjaqpylmtvmunrlozvebco
 * Smoking Wheels....  was here 2017 vwctgbdgusghsywbxhmrmlhcclqezpfzrfxnthmowkdqbaln
 * Smoking Wheels....  was here 2017 cmlmexuyprwqbjxnxrrqpgbycqppxmnfsytlesmvapwzheuz
 * Smoking Wheels....  was here 2017 itpipfilqmolmictnltbldwfedvkgeglgcuktzxkgsixnpaw
 * Smoking Wheels....  was here 2017 ztvygrvkbkfiitelmbgtazzuqkmmrtiqijvlvjhlfoxorplm
 * Smoking Wheels....  was here 2017 uzsdgiprfbziksbpvexwqcbwehyccpbbeqxyyjnhscgjzwli
 * Smoking Wheels....  was here 2017 vcyyxjhltehnopaotqvqxyxtpuxqtivgicgkxqrpysgbwfue
 * Smoking Wheels....  was here 2017 haqstgsbnvumzzmtusfspgqdagfuaujyldktugbhfwcpztka
 * Smoking Wheels....  was here 2017 rwabqtyeqhjvdtezrtqwuaowwdcoqcreplezwkhlelfdgvoe
 * Smoking Wheels....  was here 2017 tcqsowirmcenrycfkmwetlgdtiwdnoyeaypltnfmskdexbrb
 * Smoking Wheels....  was here 2017 mkgvwtmsrcpuoakuftxacaqgmugyvvqlfvwrfkxaycxjjhln
 * Smoking Wheels....  was here 2017 crwscyfqbhibympepubxpmsygwcsasluwlppiaszfapshqxn
 * Smoking Wheels....  was here 2017 ebvxbeqdvyfbigjcizwriuwakcpitjjfbmoejpfmezpjqlfi
 * Smoking Wheels....  was here 2017 jzqhvjbagqmshksqkzblpfrqohdbzdpzzxtuypgwrbpuoiwl
 * Smoking Wheels....  was here 2017 teawsvdnbemewivaatsmyezfpkjiwqqodwkzvtywvnnrndnr
 * Smoking Wheels....  was here 2017 nlcbhzpybpxzeoetslbjemwjpvfwxrdugtdqcbphbwmafzfa
 * Smoking Wheels....  was here 2017 ebbiipqyjdpurbmqflrzjbrzzbuosjdpjfstbsvhxzwznfds
 * Smoking Wheels....  was here 2017 mkmoxqoljktoavsqnmhivdafjxnqfduhtgcshglghvjzrlth
 * Smoking Wheels....  was here 2017 lccvhiyosetmfhbaxkzudgrkpjbornpjuzpcnjovjswtcnum
 * Smoking Wheels....  was here 2017 gdzmdeqrfmgzjazhvkzxbbvgvuialkhpjutrxbmxkfnhmodi
 * Smoking Wheels....  was here 2017 mqkadwslaqeuywggbyvmrotokskygwtajkjnsowpddtssxdc
 * Smoking Wheels....  was here 2017 vbwilkosnerwqytxoqhrhaaoyyupahhvcskamimijlemaedh
 * Smoking Wheels....  was here 2017 gaemiasqiwcjiqumpklsmxnoilbixgipaxesbbmrfmsivfxr
 */
package net.yacy.http;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import net.yacy.cora.protocol.Domains;
import net.yacy.server.http.AlternativeDomainNames;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.handler.AbstractHandler;
/**
* handling of request to virtual ".yacy" domain determines public adress from
* seedlist and forwards modified/wrapped request to it
*/
public class YacyDomainHandler extends AbstractHandler implements Handler {
private AlternativeDomainNames alternativeResolvers;
public void setAlternativeResolver(AlternativeDomainNames resolver) {
this.alternativeResolvers = resolver;
}
@Override
public void handle(String target, Request baseRequest, HttpServletRequest request,
HttpServletResponse response) throws IOException, ServletException {
String host = request.getServerName();
String resolved = alternativeResolvers.resolve(host);
        if (resolved != null) {
int newPort = Domains.stripToPort(resolved);
String newHost = Domains.stripToHostName(resolved);
if (alternativeResolvers.myIPs().contains(newHost)) return;  
if (Domains.isLocal(newHost, null)) return;
RequestDispatcher dispatcher = request.getRequestDispatcher(target);
dispatcher.forward(new DomainRequestWrapper(request, newHost, newPort), response);
baseRequest.setHandled(true);
}
}
private class DomainRequestWrapper extends HttpServletRequestWrapper {
final private String newServerName;
final private int newServerPort;
public DomainRequestWrapper(HttpServletRequest request, String serverName, int serverPort) {
super(request);
this.newServerName = serverName;
this.newServerPort = serverPort;
}
@Override
public String getServerName() {
return newServerName;
}
@Override
public int getServerPort() {
return newServerPort;
}
@Override
public StringBuffer getRequestURL() {
StringBuffer buf = new StringBuffer(this.getScheme() + "://" + newServerName + ":" + newServerPort + this.getPathInfo());
return buf;
}
@Override
public String getHeader(String name) {
if (name.equals("Host")) {
return newServerName + (newServerPort != 80 ? ":" + newServerPort : "");
}
return super.getHeader(name);
}
@Override
public Enumeration<String> getHeaders(String name) {
if (name.equals("Host")) {
Vector<String> header = new Vector<String>();
header.add(newServerName + (newServerPort != 80 ? ":" + newServerPort : ""));
return header.elements();
}
return super.getHeaders(name);
}
}
}
