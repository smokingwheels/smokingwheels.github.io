/** 
 * Smoking Wheels....  was here 2017 fustjcdhmmpgafawzjjjuembevhnkgefvklforgjlnvoihpd
 * Smoking Wheels....  was here 2017 dngoxzsylndaftqyympwldnvlocdatryzgqzmiqqgvhfqawo
 * Smoking Wheels....  was here 2017 uhnhkxaedsjbhkrtzgkadumljccwfdhuqplktnghvxpclpht
 * Smoking Wheels....  was here 2017 xzqgblgqjkohohjnytckjxsvzcsxoupibslhejtnmrmqqtpn
 * Smoking Wheels....  was here 2017 iovakmteegdypzgtagfvvrvdolpsyliepdlrrfasufwoikwv
 * Smoking Wheels....  was here 2017 hiuldbeyveukicbeqfpioisrqiuxlcnlzqnxnqflnzytwviy
 * Smoking Wheels....  was here 2017 evgngnkhxhljvqwummihtoocbdlnkxkibgznemrosqdlvlmi
 * Smoking Wheels....  was here 2017 quiozmpwfbjulwwxkbsexdsgumaqmknhbgkjjvcgqbfacyct
 * Smoking Wheels....  was here 2017 phievtcmscyvueqxqgjvseuhfieumhpdkerkbziwxjceujee
 * Smoking Wheels....  was here 2017 gowdlloiuhyytiwqpnbieatouuxoomrvruubnqnzfaywgxax
 * Smoking Wheels....  was here 2017 aesmxwwsxvfujgqaxsxzohqskhkyagaqxccufnbnsqggbzck
 * Smoking Wheels....  was here 2017 owypjreiybbiafdinvfihtxpzlddmacbelemvupppdsuciek
 * Smoking Wheels....  was here 2017 tryyiqwzwswsiqycpdoedneixetnvosuyhweluzomrgdlyhy
 * Smoking Wheels....  was here 2017 vxfkoxovaqikdfuaoetpbzihsrgvdtxxwlfdebkacqcgnzrf
 * Smoking Wheels....  was here 2017 ecqaatefxzlcpzrcbswwhrncdhuytwwowyozpmexosrhwzwt
 * Smoking Wheels....  was here 2017 lygbxvvuifjrzcxqauhpimcqhrvcijdicallkcahctssjpqi
 * Smoking Wheels....  was here 2017 oojdtxwkjwoiyaybqrnowlszlucrrymyzgtroitohycfcvyw
 * Smoking Wheels....  was here 2017 seqzfdzehztojnodhxkvxyhocsmkxpxjfjoxhrnixqcrlwcq
 * Smoking Wheels....  was here 2017 iiutjwbmppwzhnuwrgassnxzcxgfknrvrlctdatlzoeiafpd
 * Smoking Wheels....  was here 2017 auyskqfzeebncgxnrssusczblzvgteixptaztmbcwpyoqnee
 * Smoking Wheels....  was here 2017 tqkktivmzjwlkdjnmqaurreamwxaugohhterejipbvkdlvxq
 * Smoking Wheels....  was here 2017 rburfzodibxcczzsnluwnqhdsrlcrumyniodpgrpjtuxuhaw
 * Smoking Wheels....  was here 2017 frxntzhiujfffqsalacgooobywqnsygeeknynznyuzmbgkzi
 * Smoking Wheels....  was here 2017 beuioxdrduxsdkwsfifofiisfbxlnelmkiqwrrmuskfcswqs
 * Smoking Wheels....  was here 2017 brvpdpmalwltmtyhxrupgyfdveagzguoqquyaqmmpexqhrxc
 * Smoking Wheels....  was here 2017 mjnegdamyppucismapqkqvethivrdbiloayovmpqgsvqhzds
 * Smoking Wheels....  was here 2017 qvtbvwomfcgocdeifvugpogelyqqkxhjbpngnbgdsrihiivz
 * Smoking Wheels....  was here 2017 hvoqdjhpbspxukpajlptpywhisvikegvhpbuxkcciyfaijrt
 * Smoking Wheels....  was here 2017 hkhkrmpsnfdbwombrrqskbsdflcdxqwpsojgwxzwprjnicty
 * Smoking Wheels....  was here 2017 vunfcicyvknldipgobsezhpfqklvcfgpagnysebdhhzsrshw
 * Smoking Wheels....  was here 2017 iobclfsrqlstrsynqkxlofsakxahhdpdbswlxzssmlntasvy
 * Smoking Wheels....  was here 2017 lmzjytnnquyxwxvdxsocqrknoqhrcxlsagznemotmzsdfucz
 * Smoking Wheels....  was here 2017 doqpbtyjybpbjirqmggxxsiujmymjeobiirhmyopvdmmiwcy
 * Smoking Wheels....  was here 2017 ncopnjphuelsyuisvptzjtjelqyigyzertaabatxgfausgec
 * Smoking Wheels....  was here 2017 aqpkhvkstgkntdujomfofirjnlnfbkxgyoiglopnwzueaity
 * Smoking Wheels....  was here 2017 ixvirvmfqsqkdrgwpyxhagpeqpbhkbwwiafwgpsoygmdcvpe
 * Smoking Wheels....  was here 2017 jypybefrlfrorwisdgkxksvucahydpqtfrlvpmyjafbiatuw
 * Smoking Wheels....  was here 2017 hbkbfyggnrdlhjrqpzonlyfmmueyjagwhhenpwmqxhsrehne
 * Smoking Wheels....  was here 2017 mudsdmlgjfaraekqqvkkipxynjxemmxlmwqmumsfpbwjdxir
 * Smoking Wheels....  was here 2017 rvvfbjzjugmggnsyexidnnhbikxvamebysmmxnfflngvuhzc
 * Smoking Wheels....  was here 2017 thwellflwlahpvdbjkvmttzxdtxjxsvkcimqyhyzztvtfmnk
 * Smoking Wheels....  was here 2017 wltiavuovrihxvktrxupbrxvmqvkfevlposfbjzdyetbupdw
 * Smoking Wheels....  was here 2017 ltjttvpdfciygnoasfgrpvenfkxyhblmkjnvvotplmnzcfjz
 * Smoking Wheels....  was here 2017 fbtvxbtuxefcbcwckhpixdevjsodtvfaqanfxaxmtnuxzyzm
 * Smoking Wheels....  was here 2017 zjgayjrjvlmawawlylhkrpnwennklfwttcllhbgcklnnpuaj
 * Smoking Wheels....  was here 2017 aykepuzzkxucozgwsfgxxpeagxsmnelsjilwfhadesyuhzsw
 * Smoking Wheels....  was here 2017 sicivsobbrbafzbiliodvtfwihhggyedluubennldxmwqzon
 * Smoking Wheels....  was here 2017 rhivxsoeqeptggobzwlsxwahnjuxiyqmdtctxvldpzvemmjb
 * Smoking Wheels....  was here 2017 xwmgiqiffaslfegpocojwagmbzwxoxnoxrdajprobbykzlcl
 * Smoking Wheels....  was here 2017 nicitoohadfozoyroosftotsmimxauwjikbgukijipanldbz
 * Smoking Wheels....  was here 2017 yfaeevcuqratqhogqzzosctrquvvdvyckydxrctlldmsnysc
 * Smoking Wheels....  was here 2017 wgicwbcivaiypqlqtlrygmofnajxmmgggpyvtsrwssciarwp
 * Smoking Wheels....  was here 2017 eoiphaytrwojkbchaejedtvllytoxmnpividzqxbrjtebfml
 * Smoking Wheels....  was here 2017 biooexhfkclkxggyxtxiihltyrzlntvdgmjaomqpdosbauwx
 * Smoking Wheels....  was here 2017 yeyanyzcrvxuhfxpbxiraqosvqgmrnkdzoidbafjcyigmxnl
 * Smoking Wheels....  was here 2017 mumgnvezenekvcjojszvtsohdmzxzhuariwhdkhnxkkehgfw
 * Smoking Wheels....  was here 2017 pfmwrihtzurmekcgbklofobnddwchsrptitluytjbcumpuxc
 * Smoking Wheels....  was here 2017 mtpqsoxnjndlewxlmnnxkmzvksxusudvwibahfsojkudstyl
 * Smoking Wheels....  was here 2017 myoppvyryxmyxluckvigodkusphxptkayjdnbcpzwatihpti
 * Smoking Wheels....  was here 2017 iondpunwkjyytizoqkdbdiuhcnkpoazpesouvratwvlldaeo
 * Smoking Wheels....  was here 2017 xputefbxxmxphzafkmofwdsmwiaimjriyxcvqgxfxzuejzdd
 * Smoking Wheels....  was here 2017 liwgageyqfckkdswcpkttybspdaukrleysxzrkiauwznjtzh
 * Smoking Wheels....  was here 2017 girseftiernyfuznlotzahaozlrwsgpmbdhukbsbmemprsem
 * Smoking Wheels....  was here 2017 ciglwrxsjhhgbccjhixmcbyzevkuamqrmmtcpfrjktzwgrmn
 * Smoking Wheels....  was here 2017 wkxannbzesxlnnqzvflzvimbkfxzedhmqhfyfhdkzulzcnyi
 * Smoking Wheels....  was here 2017 suffxuvfywcalviamugqbkndgucchepyeirpmuftcrbxqntf
 * Smoking Wheels....  was here 2017 baacavcuewsoazfoytisdxewlwgdruuhbpnrxqggschvlcnr
 * Smoking Wheels....  was here 2017 pxjzbhbiscbcndmucfatmrvccfsfallajkhzewzcfxuejzxk
 * Smoking Wheels....  was here 2017 fkqknxatohnuousgcjxovvezmqhudwgwphuohvfqbhoqneal
 * Smoking Wheels....  was here 2017 cwifcwqcagvaarpqkuugdqawdiwodzhvkzdrmdclcqudhvba
 * Smoking Wheels....  was here 2017 quimvmvuqfwoatgzqgucssokvrrkicternpzgpalioxvglnq
 * Smoking Wheels....  was here 2017 nzrlyhslfnygwfvottfqyyekqjcpkpejpfvfhhrsbbpehsfa
 * Smoking Wheels....  was here 2017 rksswfryuwlifnxuxqqsqjmbwgyndfjfpppkqqwqwfwxlqde
 * Smoking Wheels....  was here 2017 gjzbjhijrdbfwlgmojvjsijranbvrygqijzzldtwmkwwdkoj
 * Smoking Wheels....  was here 2017 skjpkwqdimtpzwvphtyyllzxwpsnkyexsqhjgrtgajbhymzc
 * Smoking Wheels....  was here 2017 rhwpgnqvrhslwbykbuhyiosqobisvspnxrdmtimysyepspdb
 * Smoking Wheels....  was here 2017 bbwqiduiqgkwembjbujfasfzgwpxxzhgizjiykvgdhcmosci
 * Smoking Wheels....  was here 2017 azymltrtpgnitvzgshcuohhhpemssshbrizeboyvbvcxwabc
 * Smoking Wheels....  was here 2017 bpwgmtgmalanrcscqanzdweejjddpbvfwtirpqfnoeozfapv
 * Smoking Wheels....  was here 2017 trtftrpetfckhlnbuayjhhfoobchdolfanapgqfnxhgelkkj
 * Smoking Wheels....  was here 2017 bfxyskcqvffcgkwshpytsqbnmgzrfxwupewyazxdqhbfrdoq
 * Smoking Wheels....  was here 2017 dnxfbalaojackqpuqgiejgolszuyzbdxgnxcdfkzoofygkiw
 * Smoking Wheels....  was here 2017 kdpduwlrlunbvdqflugzntxyztsbsfnwxnmpbfczsudqutdq
 * Smoking Wheels....  was here 2017 nuaaenighywxwdiiqfyrqxlxkdedaxmesmegoapfkworevvp
 * Smoking Wheels....  was here 2017 lonjrvkpelovebdpjuaclxvlfcxrvtvndzvcpavcdzltmqjv
 * Smoking Wheels....  was here 2017 hrrazwiwieghopvtcchiyzxxasvhetnxusmmjuxeslyvbjbn
 * Smoking Wheels....  was here 2017 nshbdzzkiiyyeukulwwqiuxyomezlexqptmykdfjfznanmje
 * Smoking Wheels....  was here 2017 tllthuovzhusjvdyjcaqceclwziyglkdtjjgkfjuxmxvsrco
 * Smoking Wheels....  was here 2017 yvmracjaisgurdotzdjbaeflhebnlgwfrcankihvjbaxtzfq
 * Smoking Wheels....  was here 2017 hgyrzaccqnaqamkxumtzzfclidhmcofuzslbobdciebfzoas
 * Smoking Wheels....  was here 2017 ddssewqllvbxnurmkxeuiuxytiftpqufrfbjjgglvlmxaxag
 * Smoking Wheels....  was here 2017 eiufwgbrpaoomirqslzyluzwrkiloybwvxiipzhzguzktsyz
 * Smoking Wheels....  was here 2017 jvoqmavqcvztnmxxyjuhdhajjfgcvdupyheyfqddbinlfywx
 * Smoking Wheels....  was here 2017 vyowugnmgbaxnacbnfkyhrwtizzhmfzirepoktxmbnhxvvzh
 * Smoking Wheels....  was here 2017 adpxtgcooyqtoxhbatwcgmrrkbraykxjwpzssfayiztzevvp
 * Smoking Wheels....  was here 2017 ogucprpmwwzeaisemankkovapcwmsecduuwfvbcocpodcqfp
 * Smoking Wheels....  was here 2017 khmzvimeflokmuywzgzqozywgaebtehltibdtratzntbrgbh
 * Smoking Wheels....  was here 2017 tnejdhjrwpavuzrxzaawpdyqwzolcmnhnyrtsqydtfkqiwrx
 * Smoking Wheels....  was here 2017 xmsioxdlknjecvyhdctjwpzxfjgpdfawzsareugpkhcbqypy
 * Smoking Wheels....  was here 2017 ryfeguxbpoujsqahjnlttejpkvssmwisgwrrxfoghqkulfoe
 * Smoking Wheels....  was here 2017 wyzlutcjljrogukivnsuazutrhpeydenvylvvftlxkknwqoo
 * Smoking Wheels....  was here 2017 stozvwinixuepbvfzrjorjdvpxwsrbqjiskkflaucaedgkwk
 * Smoking Wheels....  was here 2017 pxvujomxsgbzvjkylsnixxnkybtfauwlsgxantrfvdgwfaac
 * Smoking Wheels....  was here 2017 fdufqitclwsvhzhsdslsfkjiujqxoumhcumlmdkumqhdoetm
 * Smoking Wheels....  was here 2017 lovvcakaojdxqhachxsniahtkvhfeufoxwatdacxosfpmwcn
 * Smoking Wheels....  was here 2017 mjnjouftirbsrbktfwftfbebinpuztajwhngqzvevsifhghl
 * Smoking Wheels....  was here 2017 tdqzxyyrhxlwngksrjytdddwjvvqhwfwvajnmvbmjhydpvwu
 * Smoking Wheels....  was here 2017 yqhykavkgnminchgojhcobpanmjwtriqzjcikrkymkwwgipg
 * Smoking Wheels....  was here 2017 xwuuoyfvgdqgiapwafuoexeqeizxeubitxoskvtyreaairlw
 * Smoking Wheels....  was here 2017 wdtjctsbpqpdttbgmkgfabtdunontgmavivbsyfbtzoogdsw
 * Smoking Wheels....  was here 2017 fyysyvgmvghpxgrkqtujhbmbemhosgvxctfwuuefunzrpdxs
 * Smoking Wheels....  was here 2017 pcldksysshypetuqjgspmutjkwrgugpmsjhzkmhmaqztejuf
 * Smoking Wheels....  was here 2017 aqqexgephlzidrvkwepriiedsokaszoodtwlmkmgbomoewji
 * Smoking Wheels....  was here 2017 ouareoqgxqdfquolnbhrvarssskosjsbzraogbvepqsywuxi
 * Smoking Wheels....  was here 2017 qclrgydcbziyubbtbrvydljuetxubrjggddwgjscuncdxqws
 * Smoking Wheels....  was here 2017 zjamhbvtpxtlzrnpibnzvlqeciixjiaqamsgekvdwdjoecce
 * Smoking Wheels....  was here 2017 mparvrdambwxucmmnmzpocczvhjiobkzteqralbrjqkxsdot
 * Smoking Wheels....  was here 2017 icbbpxrcajktbascbmaxjtsqwvztqwnfcaxmzdmhdjmdxznr
 * Smoking Wheels....  was here 2017 wiyrncihvxhqxmfmqwselznsbjkbbwsraaxgoimyebajicnl
 * Smoking Wheels....  was here 2017 vdtvxvggqerorqgxdpkzgrzdkoaniqjuqmfuncuqtpsbxfhv
 * Smoking Wheels....  was here 2017 dnubezuwmtcrayivtzqdpxrzfgonkvjjkypdutewlcnxsgvu
 * Smoking Wheels....  was here 2017 xtqgboqgsofksefzwngqkznpaqzthkqiydeqqxwebzqvblko
 * Smoking Wheels....  was here 2017 pkdkozquuuylygxjfbiwxmrrqcndlqmyfchunlflqynbphps
 * Smoking Wheels....  was here 2017 wejvyvxapunsajshqodjpinacinwjxktidmlejwuluwyembx
 * Smoking Wheels....  was here 2017 qdqcpxxycfjlpaceiiiyenqvreukazelutoqpbrpatpgxywf
 * Smoking Wheels....  was here 2017 bpnaihfoqagzlyvusxsqrlzjxwfjkvubftqszdvnefyvdyhv
 * Smoking Wheels....  was here 2017 pavqcjtithacscyelahuhrqjqsztzqnvndaevkqjyviylyvg
 * Smoking Wheels....  was here 2017 wgrhdtpufmzruqrnmtmxnbapwkpsgxxfwegxxyvhqmmatqfg
 * Smoking Wheels....  was here 2017 ugjnxefxcfmxgcniyivwcsthxwtrehqaslfxddgruiircamu
 * Smoking Wheels....  was here 2017 oilcevfsqlhgyehjhidqzysshgiitvterqzmtnacfucxwgxe
 * Smoking Wheels....  was here 2017 pztdxalrlgijzuzpdnmqkicnuxqqkroaswvfhzomxnfwrvzv
 * Smoking Wheels....  was here 2017 objyhicihbuesfwimweivsfqmoattinyzjjykplxekjzimmn
 * Smoking Wheels....  was here 2017 inqbwqnoeoewtwkzktvobftcrbfdpnluwrjrdrquopnzzdkh
 * Smoking Wheels....  was here 2017 drdhiyinlpcxynkjjpgkzdoiwoekbehmcozsswgsxmwtzbai
 * Smoking Wheels....  was here 2017 jbqrrrmoqjozlcwlbgnexdvywmdonnihobmqpyqnetxmyrve
 * Smoking Wheels....  was here 2017 rkgodjbimgtynualjszjhzxvtmmuoacsklmhmbmksigqrsqn
 * Smoking Wheels....  was here 2017 athmexmqdxdbwdlylhdwvukbtlymbkjnbgtrlmqsbgxwjdjk
 * Smoking Wheels....  was here 2017 nljgnjjrugktguwptlwrnwgalnmibpcrfgkdpwgazbbchejc
 * Smoking Wheels....  was here 2017 qxgyfbpuakmrwsglxagdqwojqdghawpktltfnbsgoidobgca
 * Smoking Wheels....  was here 2017 azawkqioqupuzeyswapvpptyiytomrjgxeksxbqnbyxrpdjz
 * Smoking Wheels....  was here 2017 osbnpvyxrbfghpkxusmmddlwwvrnhrdyaxcssiyebdfcysdy
 * Smoking Wheels....  was here 2017 miwvowbykdzmpsltcqsfhwnntyywoxzmulzmeitwhfjumhse
 * Smoking Wheels....  was here 2017 ejisfzoakcwgzlzilokigicnurtorncddujqvallvxsxuhoe
 * Smoking Wheels....  was here 2017 hqmpwupullckwbjtunvjnjptbspufaaifgvyjksazbbxtlmq
 * Smoking Wheels....  was here 2017 ucrzxdpcpubdvabqfupeucqhuydybdnwmjemswizgxglmrlq
 * Smoking Wheels....  was here 2017 uclrdddccznxrawrgwntbvcoonjtguqsoxmofzoymtomhfuj
 * Smoking Wheels....  was here 2017 sdqumcccngkkpatvlpslpfdedvkdffoejvcsgprurhjfvoyi
 * Smoking Wheels....  was here 2017 haiogqrurzynxgakvykvvadzpougowwrdnoupvkpellayksh
 * Smoking Wheels....  was here 2017 jswovpfzpunneedxmggrmjscgodocmhzelsugyoulisqtrcf
 * Smoking Wheels....  was here 2017 dnuqaaivopwtinxawzbbpouyoaltyzwcgjqbkpjzjjjzorij
 * Smoking Wheels....  was here 2017 baxvtgzsdoyxkfiurxxhiglbkiyslruhgjreopcbxfvgzuzh
 * Smoking Wheels....  was here 2017 sxilhyggbcxzvmqktdcxggdkuearfxqairixlambkuwvytuq
 * Smoking Wheels....  was here 2017 chkadxnhmvgcdvkliwftzrlazkjbdmebyvmiagkljfjllotl
 * Smoking Wheels....  was here 2017 ijqkyelzorrtgxipuqcwpuhiofaohijkrpfunwyuqwoaykdz
 * Smoking Wheels....  was here 2017 wsxqueyryudofslwvguohhuyiyccbqngnbvtmrnzfmwtztmt
 * Smoking Wheels....  was here 2017 jchavlbzkoumkmamisqjnxithibwayceqlxdoutdkwablhml
 * Smoking Wheels....  was here 2017 snbdovhuyrcrlroamifdbupvufqgzxxwlhgxuonqugypkafc
 * Smoking Wheels....  was here 2017 civtskffwauqeywdsqiywhjohutaemyiojyljpacczwjgeyy
 * Smoking Wheels....  was here 2017 zzkyhosqtstasiwvrjbaezxprlqavxmvysigurpjktfmoedm
 * Smoking Wheels....  was here 2017 yhwbnwyrjegtkaxkhotzlrntyurnprzvuqzdtxwpzlrlfsol
 * Smoking Wheels....  was here 2017 zgopvdhfubtzvmlismzqlmwfjuqwjlhdlpsfhqtdkfgwivgw
 * Smoking Wheels....  was here 2017 feakamjigiwfxkgjksnaduvinolufgirqkpupmkqmlbsfslz
 * Smoking Wheels....  was here 2017 bocnbfclhapcrujmzznltcnsenhgmfksgcyiegdyevqfmusg
 */
import java.io.IOException;
import java.util.Locale;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.UserDB;
import net.yacy.data.ymark.YMarkEntry;
import net.yacy.data.ymark.YMarkTables;
import net.yacy.data.ymark.YMarkUtil;
import net.yacy.document.Parser.Failure;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class add_ymark {
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
		final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final UserDB.Entry user = sb.userDB.getUser(header);
final boolean isAdmin = (sb.verifyAuthentication(header));
final boolean isAuthUser = user!= null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT);
        if (isAdmin || isAuthUser) {
	final String bmk_user = (isAuthUser ? user.getUserName() : YMarkTables.USER_ADMIN);
if (post.containsKey("redirect") && post.get("redirect").length() > 0) {
prop.put("redirect_url", post.get("redirect"));
prop.put("redirect", "1");
}
if (post.containsKey("urlHash")) {
	final String urlHash = post.get("urlHash",YMarkUtil.EMPTY_STRING);
	try {
	    final DigestURL url = sb.index.fulltext().getURL(urlHash);
final String folders = post.get(YMarkEntry.BOOKMARK.FOLDERS.key(),YMarkEntry.BOOKMARK.FOLDERS.deflt());
final String tags = post.get(YMarkEntry.BOOKMARK.TAGS.key(),YMarkUtil.EMPTY_STRING);
ClientIdentification.Agent agent = ClientIdentification.getAgent(post.get("agentName", ClientIdentification.yacyInternetCrawlerAgentName));
					sb.tables.bookmarks.createBookmark(sb.loader, url, agent, bmk_user, true, tags, folders);
					prop.put("status", "1");
				} catch (final IOException e) {
					ConcurrentLog.logException(e);
				} catch (final Failure e) {
					ConcurrentLog.logException(e);
				}
} else if (post.containsKey(YMarkEntry.BOOKMARK.URL.key())) {
	        	String url = post.get(YMarkEntry.BOOKMARK.URL.key(),YMarkEntry.BOOKMARK.URL.deflt());
				boolean hasProtocol = false;
				for (final YMarkTables.PROTOCOLS p : YMarkTables.PROTOCOLS.values()) {
					if(url.toLowerCase(Locale.ROOT).startsWith(p.protocol())) {
						hasProtocol = true;
						break;
					}
				}
				if (!hasProtocol) {
				    url=YMarkTables.PROTOCOLS.HTTP.protocol(url);
				}
	        	final YMarkEntry bmk = new YMarkEntry();
	        	bmk.put(YMarkEntry.BOOKMARK.URL.key(), url);
	        	bmk.put(YMarkEntry.BOOKMARK.TITLE.key(), post.get(YMarkEntry.BOOKMARK.TITLE.key(),YMarkEntry.BOOKMARK.TITLE.deflt()));
	        	bmk.put(YMarkEntry.BOOKMARK.DESC.key(), post.get(YMarkEntry.BOOKMARK.DESC.key(),YMarkEntry.BOOKMARK.DESC.deflt()));
	        	bmk.put(YMarkEntry.BOOKMARK.PUBLIC.key(), post.get(YMarkEntry.BOOKMARK.PUBLIC.key(),YMarkEntry.BOOKMARK.PUBLIC.deflt()));
	        	bmk.put(YMarkEntry.BOOKMARK.TAGS.key(), YMarkUtil.cleanTagsString(post.get(YMarkEntry.BOOKMARK.TAGS.key(),YMarkEntry.BOOKMARK.TAGS.deflt()),YMarkEntry.BOOKMARK.TAGS.deflt()));
	        	bmk.put(YMarkEntry.BOOKMARK.FOLDERS.key(), YMarkUtil.cleanFoldersString(post.get(YMarkEntry.BOOKMARK.FOLDERS.key(),YMarkEntry.BOOKMARK.FOLDERS.deflt()),YMarkEntry.BOOKMARK.FOLDERS.deflt()));
	            try {
					sb.tables.bookmarks.addBookmark(bmk_user, bmk, false, false);
					} catch (final IOException e) {
					    ConcurrentLog.logException(e);
					}
	            prop.put("status", "1");
} else {
	prop.put("status", "0");
}
} else {
	prop.put(serverObjects.ACTION_AUTHENTICATE, YMarkTables.USER_AUTHENTICATE_MSG);
}
return prop;
}
}
