/** 
 * Smoking Wheels....  was here 2017 ofvwkbgigztfdsspnmihznowcrbauksbtvbqigjxevnvwmop
 * Smoking Wheels....  was here 2017 xnpqazfptpetekaekjkolywgxrxslzgwhpsauuvwmccwlffq
 * Smoking Wheels....  was here 2017 okgzksjhaizrikrwxkfdtunkjloqzqwdxjdqkqzdqbfgvzzv
 * Smoking Wheels....  was here 2017 erxftuvcxokyaxxwwrbojwvfpqmzzvblvkxizvluxrnkypox
 * Smoking Wheels....  was here 2017 riwvobavjywrukgrnjnpbilsvelehgqlkgvekucgwcaauyax
 * Smoking Wheels....  was here 2017 gqsroqnqujcjnqmbfbkjukijrghyaxofjqalzbcchtxauhob
 * Smoking Wheels....  was here 2017 hdgvtvgxqzarinpasnveuuntvfidozdypqutelugffpqobtv
 * Smoking Wheels....  was here 2017 lqooigjgtfwoogvtvubnngltksxalyvdgmrvrcwvzlugxzia
 * Smoking Wheels....  was here 2017 rdzlusfndrbdujtvvdtgsxtlrruzpnloutotniedbomoyahp
 * Smoking Wheels....  was here 2017 dwcgxjlvcihxynbxbcqljdihegxtcryfwemwxswwhavmbkxv
 * Smoking Wheels....  was here 2017 glsdomzpfhnobsubfkvjtlhvrvlfhpqhkvushdivrkhgvosd
 * Smoking Wheels....  was here 2017 rpxicqxkgzzyndgnedrqgtbyhcxouuajnyaclreforpgdglj
 * Smoking Wheels....  was here 2017 ijzkxtqdfabixhxseotzrcfvgxxflyvdsbabjpiilyqebkcl
 * Smoking Wheels....  was here 2017 kaneuwuxmhndcvmmqfvnzvrtdllxjadppzwzfpxveqqzyhzr
 * Smoking Wheels....  was here 2017 gcksrigcnagzfuctdvaojopksctoxgdacswiomhptkcvlhpm
 * Smoking Wheels....  was here 2017 pjqiutfhepmxpixvrlrpjcipbnehrcjwjoqybhdsldqekerr
 * Smoking Wheels....  was here 2017 jvonrxzklpqzvxmdkkhnroonkpnqogpxwzyxskipvzfrwxgf
 * Smoking Wheels....  was here 2017 sutezygoqaltvhonsdtjihdnjnsepswdgvxntkzvsjchhsoi
 * Smoking Wheels....  was here 2017 aubhtfxdiywupkewhmdklvefrsxyerjvkcviremhdyreeadp
 * Smoking Wheels....  was here 2017 zpngfgargvcdpnombmsgqcclktoayqrkoahdesncjortlntr
 * Smoking Wheels....  was here 2017 ogmnuybdngnwjagweidqncojwokyrgmrbfcahlxqzlategkp
 * Smoking Wheels....  was here 2017 vznzgjqpjfxnurztbrdsdgkioijionwppkjgfxvnszyctkjp
 * Smoking Wheels....  was here 2017 hilrpvpmiufszkuckewssctzhkrcwrcldqjlkzqqrtvytldf
 * Smoking Wheels....  was here 2017 pdiwazdigkokgmyfbyqgtlbfdntmhdqsuesjqsacctmtabmd
 * Smoking Wheels....  was here 2017 pjneappbesmtgixphfzcxmybjmhxpqgdzofcwmugoctfrfkk
 * Smoking Wheels....  was here 2017 ohojivqujqqfurnylntiflgzmngbzezrlnzyiwetwewfcdef
 * Smoking Wheels....  was here 2017 vmhnyzdwihzmbnsgeqbfyzdoizvvsxbrzeglnrmlaqizxihc
 * Smoking Wheels....  was here 2017 cruyaqgyycslhzvvmpdjmyzqyomllianwssldbkmjltywlov
 * Smoking Wheels....  was here 2017 hxkedqiwfsgifqhclrqppklkqdxhbepalrczfhuekretemyi
 * Smoking Wheels....  was here 2017 pmqbzcbukajppdxvoljyirkexxbdpkvelxmixzufytsjdrsx
 * Smoking Wheels....  was here 2017 jxjqnihbcfyvplsblpjrvjapoedvlezftjgctaukaiwzjlka
 * Smoking Wheels....  was here 2017 izrfzzdibrfbnuyzafakpiqnqropgaoqnjycmllyyiiatntm
 * Smoking Wheels....  was here 2017 krwiwubkiapkaqccmovyjqwclhbwuqieekkiapqdfxadjwte
 * Smoking Wheels....  was here 2017 sinvxyplgevjxsyfferhdqrrnephfzhvkhrerblrrkeiostl
 * Smoking Wheels....  was here 2017 slltcstvhivoizmgxvpvdxewrshwwgrwdbcdwsiijogsznet
 * Smoking Wheels....  was here 2017 auskptoeivvyqpamlnybvisoypstiybtmygbjqxhnfwtkauv
 * Smoking Wheels....  was here 2017 qkrjzvliijgskdbkbphvyyyxorlintegxmyzcdaytocdacrr
 * Smoking Wheels....  was here 2017 qoxlxcblqvvhnfiucnlemcufedninqajbmhfjvwwvzavdbao
 * Smoking Wheels....  was here 2017 nufqkwhxtiljbvvphcnkqkidmkcsqwwixyohpouxuceykijz
 * Smoking Wheels....  was here 2017 xxrirsghnjjwkfwbnitcxraoobrpovgrndicojmgywfypqmq
 * Smoking Wheels....  was here 2017 tvpbfmimymzzdvytynvbbakotbwmbgwbkpmpertgukbnxyio
 * Smoking Wheels....  was here 2017 eyppsiephrbedjuiaemiaumonorzheuoedaetauneczpqlga
 * Smoking Wheels....  was here 2017 ptmafmraebmbmumvkcvfbohdsxhcpshkutijsgzycrkjkpsm
 * Smoking Wheels....  was here 2017 tzhrxpyjjzmpojfnzhehqegfiveypkvcksyyulypwzagbemr
 * Smoking Wheels....  was here 2017 mskchnknwenzzmnvybcjmsawseaadyfikosazzpxbdtytcpp
 * Smoking Wheels....  was here 2017 zfibcirpanhrnyepsxlmpnmmjctzhhkencsvokamkqwktpgo
 * Smoking Wheels....  was here 2017 sayrhjqyjesikqesyqhyeetrcbptlqsvphfaxpqdzbsutcaz
 * Smoking Wheels....  was here 2017 hwigcfkfqmawxuunogyitofhyqanfmpuwlwjwpbbcicnojqr
 * Smoking Wheels....  was here 2017 qvthaslgyeqmqxnmtaymzsonftrslnwvrdlxiugphoxghjdo
 * Smoking Wheels....  was here 2017 xdvquyhfodhqmqdhxmejxzprkpobgtoxubazosgjigiaigty
 * Smoking Wheels....  was here 2017 ojkjjgxlzlxynararlrjtzmkknulzivhahycahmhgzwxfozh
 * Smoking Wheels....  was here 2017 ggntzgkocprkdgiwbwuazoqpdfybfuhnqcucmnpkkqekvzqj
 * Smoking Wheels....  was here 2017 xwmjdtelwfbextrjdcbehtshzppjvurgzzjbwvmcglfeilsd
 * Smoking Wheels....  was here 2017 qlxanvvfpeusrhmfjqjutynymttayhzotuthmtgbrsfeafmx
 * Smoking Wheels....  was here 2017 ynotexhfwrtrpuslkgsgmsgejdqywomqwmhhtdhcqeonmtkc
 * Smoking Wheels....  was here 2017 lxpyhlrdlcfazmqiezmcbxhusjqjharamjnykbgimsatqthn
 * Smoking Wheels....  was here 2017 bphbikjujbowmvuhvcfeeqgyvknrzkikayhglwbeslmloedd
 */
package pt.tumba.parser.swf;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
/**
*  Write XML text to an output stream
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class XMLWriter extends SaxHandlerBase {
/**
*  Description of the Field
*/
protected Writer out;
/**
*  Description of the Field
*/
protected boolean started = false;
/**
*  Constructor for the XMLWriter object
*
*@param  outstream  Description of the Parameter
*/
public XMLWriter(OutputStream outstream) {
out = new PrintWriter(outstream);
}
/**
*  Constructor for the XMLWriter object
*
*@param  writer  Description of the Parameter
*/
public XMLWriter(PrintWriter writer) {
out = writer;
}
/**
*  Description of the Method
*
*@exception  SAXException  Description of the Exception
*/
public void startDocument() throws SAXException {
try {
out.write("<?xml version='1.0'?>");
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
/**
*  Description of the Method
*
*@exception  SAXException  Description of the Exception
*/
public void endDocument() throws SAXException {
try {
out.flush();
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
/**
*  Description of the Method
*
*@exception  IOException  Description of the Exception
*/
protected void completeElement() throws IOException {
        if (!started) {
return;
}
out.write(" >");
started = false;
}
/**
*  Description of the Method
*
*@param  chars   Description of the Parameter
*@param  start   Description of the Parameter
*@param  length  Description of the Parameter
*@return         Description of the Return Value
*/
public static String normalize(char[] chars, int start, int length) {
StringBuffer buff = new StringBuffer();
for (int i = start; i < start + length; i++) {
char c = chars[i];
switch (c) {
case '\'':
buff.append("&apos;");
break;
case '"':
buff.append("&quot;");
break;
case '&':
buff.append("&amp;");
break;
case '<':
buff.append("&lt;");
break;
case '>':
buff.append("&gt;");
break;
default:
buff.append(""+c);
break;
}
}
return buff.toString();
}
/**
*  Description of the Method
*
*@param  namespaceURI      Description of the Parameter
*@param  localName         Description of the Parameter
*@param  qName             Description of the Parameter
*@param  atts              Description of the Parameter
*@exception  SAXException  Description of the Exception
*/
public void startElement(String namespaceURI, String localName,
String qName, Attributes atts)
throws SAXException {
try {
completeElement();
started = true;
out.write("<" + qName);
if (atts != null) {
int count = atts.getLength();
for (int i = 0; i < count; i++) {
String name = atts.getQName(i);
String value = atts.getValue(i);
out.write(" " + name + "='" +
normalize(value.toCharArray(), 0, value.length())
+ "'");
}
}
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
/**
*  Description of the Method
*
*@param  namespaceURI      Description of the Parameter
*@param  localName         Description of the Parameter
*@param  qName             Description of the Parameter
*@exception  SAXException  Description of the Exception
*/
public void endElement(String namespaceURI, String localName, String qName)
throws SAXException {
try {
if (started) {
out.write(" />");
} else {
out.write("</" + qName + ">");
}
started = false;
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
/**
*  Description of the Method
*
*@param  ch                Description of the Parameter
*@param  start             Description of the Parameter
*@param  length            Description of the Parameter
*@exception  SAXException  Description of the Exception
*/
public void characters(char ch[], int start, int length)
throws SAXException {
try {
completeElement();
out.write(normalize(ch, start, length));
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
/**
*  Description of the Method
*
*@param  target            Description of the Parameter
*@param  data              Description of the Parameter
*@exception  SAXException  Description of the Exception
*/
public void processingInstruction(String target, String data)
throws SAXException {
try {
completeElement();
out.write("<?" + target + " " + data + "?>");
} catch (IOException ioe) {
throw new SAXException(ioe);
}
}
}
