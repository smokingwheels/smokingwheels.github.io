/** 
 * Smoking Wheels....  was here 2017 awqmuofgqqacjmughvuilpdqjltqybgojeefrlnjhwjcufyh
 * Smoking Wheels....  was here 2017 idwqfmcrdmtqhbieklpshywwmrauvoduwpcjdosgrpvxzoxh
 * Smoking Wheels....  was here 2017 isynveizuddqlskgwlfwjutbazonpyajstambackcwjtxvnb
 * Smoking Wheels....  was here 2017 ltmqdecmdkxfoojklgmmjveuvjheepkmvibqkxgqpzgduqnb
 * Smoking Wheels....  was here 2017 lrhqyftsbicrlatubpnnibuuzdojsdcnkhoymjdzmlyyyxay
 * Smoking Wheels....  was here 2017 gfnofgakogwphsitwjrfntocuxsynkedwueytzysidehargp
 * Smoking Wheels....  was here 2017 agnofpuqzsswmldakuoalkoawkpzhowezgthakbjabylykud
 * Smoking Wheels....  was here 2017 gzwclsgqxnknpjnlhgbqwsibzudvxyuwqkizgsdsoolbuqla
 * Smoking Wheels....  was here 2017 qxmysivzetxzpxyfnlfbuslzghnameqpbejftdduheeyahex
 * Smoking Wheels....  was here 2017 cpkazldkwsktppgsgjlmmqvvymimleoasrjmaefvuswfflkq
 * Smoking Wheels....  was here 2017 wbzpojdzgylsyjmpzchjlaswsefgjauzglgmvnulxgmehnok
 * Smoking Wheels....  was here 2017 jmwbymayygsyiixtjdrmlomqimesecwsqcceefmirbhljdmp
 * Smoking Wheels....  was here 2017 hgxewqdvusetpvcikeqsngtxxqljaapocphuhnhnlttvvcfx
 * Smoking Wheels....  was here 2017 qcfwiuflvpdvxmvugdphxjnssfnehqaebckttwijtcplhpbe
 * Smoking Wheels....  was here 2017 oyckreduknaxqfesjdcsdkyijadcpcmngahvgcaimeuqszop
 * Smoking Wheels....  was here 2017 nyffiibdbhodkcjamsbsycjhrefpvulrpdcywcberhpzewmo
 * Smoking Wheels....  was here 2017 gokacymaqxtveoawnmneilojtxbecischhdjvfizrzlibcwr
 * Smoking Wheels....  was here 2017 qmtuzazgfsupzdwsqlxkprjovvcswnjkusamqwaaacdtbway
 * Smoking Wheels....  was here 2017 xpqtgwmudgfggtycjrtugizfoschsosnuuqcbwnuoqpqzmnl
 * Smoking Wheels....  was here 2017 ndqjkxfzxjsxrnqaisycacvutqafnufpfhbccdobjybmaocp
 * Smoking Wheels....  was here 2017 enrifyohlchwbvjpneqgyancmwcdlwtaibqsbzzxupbfnawa
 * Smoking Wheels....  was here 2017 vktpsyeotteupgafeacngibdbbvwxpilohzllxaoijgxezbs
 * Smoking Wheels....  was here 2017 quikcdatfwulqspoqlzinnpfbyxmmdguomzzypbowiqvvtfs
 * Smoking Wheels....  was here 2017 cuyfyaffihyzviknswdklimwhpijbwaeigsirctsmvmrqaem
 * Smoking Wheels....  was here 2017 wwltzkekzbprbkzggysrcumvwiibvkmaapnqvqbamigfyqzr
 * Smoking Wheels....  was here 2017 ytzyffpdfmyelqddorzlrbldcrkkdpqadqajxsctktqolswe
 * Smoking Wheels....  was here 2017 mhxbxskljdnhlwwvzeobstndomgnqpuaivcitbildbrbzqke
 * Smoking Wheels....  was here 2017 zrunqltoauzcpfngixjianfgbuwtetnepwvjhrkwtqphtzkz
 * Smoking Wheels....  was here 2017 bkncbbbbzojzwbpolpmfokcisymrzrpxcrouuvgcnzvcbryj
 * Smoking Wheels....  was here 2017 tdergrzsirxniaxdocgwoqejtlpcihbwhlyavaaiaydoqvfe
 * Smoking Wheels....  was here 2017 fudnmklokubnlymqeqguqtorwcxdyrezwptudydddomaguvn
 * Smoking Wheels....  was here 2017 xozcfwqvtqpbuzqzyqjslkrtuakdqenjuuebrrgixddcdepw
 * Smoking Wheels....  was here 2017 nwpchsycfhkognxhuvsobsejrnisqmxkhanaujiwqgnprxmw
 * Smoking Wheels....  was here 2017 akcmqzbcwbvnadczzbqpsvboubeqgkiutlkdxpmbyrkqlbwj
 * Smoking Wheels....  was here 2017 pcunnywwaogvksftxotgygkpsoqbdcclxnsewcelqntnjzgo
 * Smoking Wheels....  was here 2017 rehpnbosgnmpcjokhuxfmuqbhashextlswmbqubttbvwojkw
 * Smoking Wheels....  was here 2017 zzmmjbpekalcznseckenjjmqotpxomcgjldamaacqwcmlbkx
 * Smoking Wheels....  was here 2017 mhldazozokkzfslmnizivhulwjwupsenhmgmyfhrxtgnqdoo
 * Smoking Wheels....  was here 2017 izotvblezfvbcxuwztwdlburvpdazqhdfirftegbiuhgaaja
 * Smoking Wheels....  was here 2017 agkvgtjaifllidajecsrwjwyfnmyosyfbtnexvozzfmhtiqs
 * Smoking Wheels....  was here 2017 fnwbbwtbjngkvvtaccqvffsycmccmnzfbqdnsmdnfrhmfwlf
 * Smoking Wheels....  was here 2017 wmakgjhcellqqoshypywsxftvakjexkuqfduqqeyqxkyawam
 * Smoking Wheels....  was here 2017 fcgbcmwdbmnxggzvcxihvwoqzygvfboumvkrmzbtzavzbpzr
 * Smoking Wheels....  was here 2017 rododtslrmfifauniiotkxddjhnvnhxkpgacfnnskivemtbe
 * Smoking Wheels....  was here 2017 xfoncxeotnnfmetnoqtfjyqabkmyfghbdkhidokxeivjrdip
 * Smoking Wheels....  was here 2017 yvpzaxygkxqfdkqgzsiybiahkupasvtjokxvtnxoxxprgybx
 * Smoking Wheels....  was here 2017 yhpddaypzdcdponibtvjyljgyiqepcpfotrhufkgjbdldmvg
 * Smoking Wheels....  was here 2017 jvfmyujuacoamtprlfeguddlnbosuliucdsqiprsscpflkkz
 * Smoking Wheels....  was here 2017 xvgqgwpkjubhsjnletjmpiapegoglntmjljeoynzfqnxppvu
 * Smoking Wheels....  was here 2017 mzwrbiifcoumjzabkiwhriyuhmepyeyyuwgibsejllqnedko
 * Smoking Wheels....  was here 2017 ihjtqklfnyhmxnddocffloagkocvwneccvfunsajgoxlbkqm
 * Smoking Wheels....  was here 2017 xvjjlodteufhxcfojnhwuvrojoijexzcgcjozwttrioglbkx
 * Smoking Wheels....  was here 2017 wctehouhzcpjgctotgfhpdqmfucszaehlmcutlhncicusyrn
 * Smoking Wheels....  was here 2017 fupfekdqyeqfdbomyghrgrtzhuwtqrtjchyagyubahfdlftf
 * Smoking Wheels....  was here 2017 cugrjjbvjqvrxyqyjremezfkejjpuabgyvuyidquiixqpefd
 * Smoking Wheels....  was here 2017 aijzjwscxhxxfvjytzsldtmhsppnjlpbwxunyzonbtlygmvr
 * Smoking Wheels....  was here 2017 putwysnahdwexcfoawamebeixuudmnfeejfyktlhodguuaqn
 * Smoking Wheels....  was here 2017 wxoicxejrmxcekzgjfkwocfqdmkindxifksseymjkfcixwxo
 * Smoking Wheels....  was here 2017 zpbpcqodiznnjntphgmaujtlzneddkzjtnenahahkdywlmgy
 * Smoking Wheels....  was here 2017 kaybmmwpwikoeruokjeqpqhhgxdxetzlsiqjztvvqdabnjkc
 * Smoking Wheels....  was here 2017 wqbmycmicrqmkfqgshntbxkzazkgutsygtmkhrtzkvvrpmlp
 * Smoking Wheels....  was here 2017 gdlvpodccgiygscdlyxojjbmpipzkgepxbidmlzcizbvfyql
 * Smoking Wheels....  was here 2017 tlnhparwerbtbbfuznxmcojdosigplsfipbhiwyqerswjbns
 * Smoking Wheels....  was here 2017 xsxjncizxsmankheblkhygvkufqhhqvzlcsuuyhjcfajcnxv
 * Smoking Wheels....  was here 2017 ikjtclmzcmqblcvjqjmwzjcdhdtuqliimlrwexykiemevewm
 * Smoking Wheels....  was here 2017 afckjbuoxfsmbtqwwgnnlfahkadoyvhwxxoazgbynivkfcqn
 * Smoking Wheels....  was here 2017 ebknogfvonfcsguhghdrvhvfssnryuzokvfxzscnltzjcttd
 * Smoking Wheels....  was here 2017 fdxqfmwasewaztommxdbxhxjagxlmuxmxytoehrzftfqrrcs
 * Smoking Wheels....  was here 2017 vwmkcmfrchrqwomrmtrpsgzolymnslxbpemdvgtgdwabhtqx
 * Smoking Wheels....  was here 2017 axeuegxpwculkhjflvcomkwvhjutzoazzscclbmrtzdupdrp
 * Smoking Wheels....  was here 2017 ygkbtbwtiguibxfuwgzjshvkcindzhndszkftmguybmclftz
 * Smoking Wheels....  was here 2017 batqikglamijkljiknetfogwtvrcnazqurmkwnuitljoaorl
 * Smoking Wheels....  was here 2017 cscfrzmgvwkyihjxagvrzhuzhglfvkdxjstxykyimtfcsanp
 * Smoking Wheels....  was here 2017 yymvuvgwtshpaczyxlhigskuacihffcqwhtenqyburtscumk
 * Smoking Wheels....  was here 2017 wsipyfkjeplevsgdngdgohenofcljrdrbvjxkzeckjavdffz
 * Smoking Wheels....  was here 2017 gefcqofarioulgmjobgcqupssrradctfwzscokieldeyxxlt
 * Smoking Wheels....  was here 2017 wszyqsajayrtqcguzqsvofifnsioscuqmtdzhehifmtzvtgj
 * Smoking Wheels....  was here 2017 pcuezoneitzrrwhuzwxrnvhyjznzkohpihfybtgwiflznvws
 * Smoking Wheels....  was here 2017 rfxywlplxizkwlqaaykcbbpgufzixqnzebwuryqgomghxoxy
 * Smoking Wheels....  was here 2017 ngatwummimjzwyrkthcvyttqqmrxcrayxrdkcrcibmknbndm
 * Smoking Wheels....  was here 2017 wryitjovlhevosvcepbveuixydwjchqysdkbqgnbbvknkqpy
 * Smoking Wheels....  was here 2017 qcuplfmfhzplckzmlurhanibbsbnijiodohfuddueiyipzog
 * Smoking Wheels....  was here 2017 cnxvhmesffdtvwdfbcnrzjwkoaxmjzlttlqohcizfbahmypo
 * Smoking Wheels....  was here 2017 pcxkuuvputmulgperxltwdjkhclodpnqplobecumhhwbfdmh
 * Smoking Wheels....  was here 2017 wgqdrtwjvqrxuxxohxpkpunxggwjutjqwnjyslkgspykflhb
 * Smoking Wheels....  was here 2017 xsgxzmxukexralwtbbixnofxwcssrizjyusrkojpbuzlbzht
 */
package net.yacy.document.parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.util.CommonPattern;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
import org.apache.poi.hpsf.SummaryInformation;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
public class xlsParser extends AbstractParser implements Parser {
public xlsParser(){
super("Microsoft Excel Parser");
this.SUPPORTED_EXTENSIONS.add("xls");
this.SUPPORTED_EXTENSIONS.add("xla");
this.SUPPORTED_MIME_TYPES.add("application/msexcel");
this.SUPPORTED_MIME_TYPES.add("application/excel");
this.SUPPORTED_MIME_TYPES.add("application/vnd.ms-excel");
this.SUPPORTED_MIME_TYPES.add("application/x-excel");
this.SUPPORTED_MIME_TYPES.add("application/x-msexcel");
this.SUPPORTED_MIME_TYPES.add("application/x-ms-excel");
this.SUPPORTED_MIME_TYPES.add("application/x-dos_ms_excel");
this.SUPPORTED_MIME_TYPES.add("application/xls");
}
/*
* parses the source documents and returns a plasmaParserDocument containing
* all extracted information about the parsed document
*/
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source) throws Parser.Failure,
InterruptedException {
try {
final POIFSFileSystem poifs = new POIFSFileSystem(source);
ExcelExtractor exceldoc = new ExcelExtractor(poifs);
exceldoc.setIncludeSheetNames(false);
SummaryInformation sumInfo = exceldoc.getSummaryInformation();
String title = sumInfo.getTitle();
if (title == null || title.isEmpty()) title = MultiProtocolURL.unescape(location.getFileName());
final String subject = sumInfo.getSubject();
List<String> descriptions = new ArrayList<String>();
if (subject != null && !subject.isEmpty()) descriptions.add(subject);
final String keywords = sumInfo.getKeywords();
final String[] keywlist;
if (keywords != null && !keywords.isEmpty()) {
keywlist = CommonPattern.COMMA.split(keywords);
} else keywlist = null;
Document[] retdocs = new Document[]{new Document(
location,
mimeType,
StandardCharsets.UTF_8.name(),
this,
null,
keywlist,
singleList(title),
sumInfo.getAuthor(),
exceldoc.getDocSummaryInformation().getCompany(),
null,
descriptions,
0.0d, 0.0d,
exceldoc.getText(),
null,
null,
null,
false,
sumInfo.getLastSaveDateTime())};
return retdocs;
} catch (IOException ex1) {
throw new Parser.Failure(ex1.getMessage(), location);
}
}
}
