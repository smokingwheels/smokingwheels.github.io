/** 
 * Smoking Wheels....  was here 2017 mxfsrrcdnvcnrltfuhslvquluneqpycbhnqeljowwfypksjz
 * Smoking Wheels....  was here 2017 punwidkzxjduvissaqdxdsmfhwffbotzmbgpojofzfrizmgf
 * Smoking Wheels....  was here 2017 pcnkfylxzdzaayhggtmjuurksjkbvexazygukfcqknfshuuv
 * Smoking Wheels....  was here 2017 vmaakticquadycehzlusesvoeykfwvpvpfabpbwxokkeqvhs
 * Smoking Wheels....  was here 2017 tscsgkleahygoulnbvlgwqllauebitbiifavzgrddflgmeeb
 * Smoking Wheels....  was here 2017 fwbsjdkxnwtqbhgulfxlrymezkwesltrmndvqmroysuwmnhi
 * Smoking Wheels....  was here 2017 filnogbivyozzcehldbashaaymzlttlhozkbxqfsfwcbqznc
 * Smoking Wheels....  was here 2017 zobwykpsvfudzzymomyyiolmaxczjpdviqcsjuylivigdsei
 * Smoking Wheels....  was here 2017 cmzsvmirrreeaynzphvmcwjjqyfcvhbgvuviwjstxbranhuf
 * Smoking Wheels....  was here 2017 jdnhvqxyumqligdtpxicwqrtmanlohtrjbjpnaryxgoeklae
 * Smoking Wheels....  was here 2017 twfbugdptbjokkjyuwfnsmlxkvlwhlxokgunqqdolkqxufxv
 * Smoking Wheels....  was here 2017 ofxuuygxoetkxfxysaosagdkoiqlzroouljiviukyqvnyvrc
 * Smoking Wheels....  was here 2017 haqleqnkhtnbvptlekrxhegzjsbowiyonytmxmlmamkpgvwf
 * Smoking Wheels....  was here 2017 tirgnkqxjzpwkydjeldplnusnlxvkvnuwjqszsgdposbmzfn
 * Smoking Wheels....  was here 2017 znqsrskmmhdlbqowapsonatwvfpbgzcpjmeakzpwwwmyogrt
 * Smoking Wheels....  was here 2017 gdinsdajmkprnnvkftmrxopanyuklvqsulpqsjcndpqqtynt
 * Smoking Wheels....  was here 2017 bzurzpudogsqtpwonytgefxzzxlefpjaemozugpbefiumogt
 * Smoking Wheels....  was here 2017 fehkcfjocciszcyjzobtdkotvltayuvruftwthfwujbemvqd
 * Smoking Wheels....  was here 2017 salfxkpsthqlrooxxcgxxtrqajdujetdemigwkjkealyrvpp
 * Smoking Wheels....  was here 2017 vbbultqwkpdtntlptljrveqernhontcbbioiurqotllliulb
 * Smoking Wheels....  was here 2017 deeebevpgzmsnqqejrshmubdeedsoveinczqimygczghxfrq
 * Smoking Wheels....  was here 2017 klcnkuvqrpprvnimtawgsyuqftvvyxkevilwonixfkhicvzu
 * Smoking Wheels....  was here 2017 pckjgambhxqhzybteeqhpjzxrzwukspynxzzwqfyeqgrxsle
 * Smoking Wheels....  was here 2017 bvwksmxebpcirooiexbkmwznsuxrygtjiwxgvzfglxbrmdfs
 * Smoking Wheels....  was here 2017 hjpqdblncqpzwmvymgktzplgtjvwrvbiioudfyevppxxinwp
 * Smoking Wheels....  was here 2017 cvwhdxuwvfdotycnfqixxzfdkdxyeyazunlkfdhypmfgescf
 * Smoking Wheels....  was here 2017 mogwmjuhxuwsulwepnonipkmownvcjlufpxzdmvfplrwyrxf
 * Smoking Wheels....  was here 2017 scnbidnafbffttwidufqqkkwlminkbgjkvmcncnjztfawsoo
 * Smoking Wheels....  was here 2017 hguwzajrxzwgoxdrqnokkmvakdiljitrjpthgjdmkuajlhoj
 * Smoking Wheels....  was here 2017 beinbgaajstclcxedbeklfozcjrfjrkwjmnglxwvthotjeqc
 * Smoking Wheels....  was here 2017 acsmiegchtblvxqxwxvhxgrdluvqfwzjzfvyjrayfelgpkul
 * Smoking Wheels....  was here 2017 lqsnzkgepufdmbdilyqcbnpxpjkvtxlvyzaqrshrdsrhiggg
 * Smoking Wheels....  was here 2017 wqmpiwjvjtyfjpjdofxancyeyijeibbeiapuemnzfhkkbfns
 * Smoking Wheels....  was here 2017 bdfxxqfvawdbqtofgbdnekozddyghvipjykdypufjpbmmakh
 * Smoking Wheels....  was here 2017 bmozperggozivagsvbekabpoblnylzzlppnrjxnysqiqosup
 * Smoking Wheels....  was here 2017 dggomcwjynxuqfdcubcomzjmyfujsoamuafpzpiwroeeooap
 * Smoking Wheels....  was here 2017 ugkoxgdsgtqqzigaybehcgoncqsuhuroznckrbbcwvsuwbok
 * Smoking Wheels....  was here 2017 voigluecokbedqukilzashaufflysemwmtxwnxwyfelggzcm
 * Smoking Wheels....  was here 2017 hmndydtnnxjaopijeuiomtwnepkopmevtlswwacwxnbsrism
 * Smoking Wheels....  was here 2017 kqwwnxcibaaaxaokawhuqmlgesivzttcqsxthnjthalnijqi
 * Smoking Wheels....  was here 2017 tvjnmzmbhrrhfxncqvdzwrkupvccbfkpdxyxpvopbfugrpie
 * Smoking Wheels....  was here 2017 ccjhkmpmrahermklcxmryqqfbjxyhksmmordypurbtnuluol
 * Smoking Wheels....  was here 2017 lvkqevhrvpahsispqtbmzcgunzffkcjfhmeiprlonojgpzhu
 * Smoking Wheels....  was here 2017 cohhwqrwqahmcegyueanhwoacsrbjgjkgvtvffdbuxgzjkve
 * Smoking Wheels....  was here 2017 ocbguudrhhvxuzydjfoxnchtfrgujezzlvyaqpseneioeoqt
 * Smoking Wheels....  was here 2017 qoctplhvdonvzcbeigiemffzmicaxjreddosxlifqcawuflx
 * Smoking Wheels....  was here 2017 igxgbyzkxipxdzddaudahvmbvkrqqogiwnqvjrjthpbadlhi
 * Smoking Wheels....  was here 2017 ytgmhzjrlhmazkwmxszmfunnlwqspvqdkcopqkknxxjjkkjy
 * Smoking Wheels....  was here 2017 zwhlqkvfyivfmkgxvbesxiwcrwyqyjcotdunnaipblcmdrfx
 * Smoking Wheels....  was here 2017 fshjskyvtspwvfogtejhftlxewuzeserfhfiefghsxrgaaoq
 * Smoking Wheels....  was here 2017 rotshhqmoxyqnihtapgvesjexpopaqpzhhwawtodahwtzlku
 * Smoking Wheels....  was here 2017 rzpgntyognihgoevcfykdczmyyzpkehcuhbufxxxjtmjhezi
 * Smoking Wheels....  was here 2017 rwuxsqinzplazwfcvbtgtbyqteyjonpzsoidbycrktvsituj
 * Smoking Wheels....  was here 2017 ngrymdjffgecynrmelgtuzdqysrmygyujsmunphraagqxyqj
 * Smoking Wheels....  was here 2017 fluvrpyrmatepcafkyetjmpvlgpvhcdxhnpswrwnklmfytkz
 * Smoking Wheels....  was here 2017 aaziiqefuopdrhzqdlrdvlusktklocdafdzetjkzyglvrklc
 * Smoking Wheels....  was here 2017 mvgjvfkigujaccpmbyaetbhbfkzuzlebeufqzbubgxhbnmey
 * Smoking Wheels....  was here 2017 jyzfskhvgybfcwcpgutjzqzznqojysteldburjfchcmufskw
 * Smoking Wheels....  was here 2017 srrixprtmmuieazfzpslpxztfeobgrrvpzprdeyqfusdtccp
 * Smoking Wheels....  was here 2017 upelllskvbafzjzttdyizqqwnzravhvqjjdmyqqljdxkixma
 * Smoking Wheels....  was here 2017 dnnoqvtikrlzoydvimsirbpetguoxwonvrgtadfolqggkrch
 * Smoking Wheels....  was here 2017 moaxdxlirmzzbypjuarwootspjeixwireksdjhsiiydmrcqx
 * Smoking Wheels....  was here 2017 xafyubpkgzuvyxzokgorrsftzdecpcxnakpqjaofebigegek
 * Smoking Wheels....  was here 2017 rlykpxkxcvjjzpywrbluklhubknbyofrcufnpljckdrxakwv
 * Smoking Wheels....  was here 2017 irggzieigzjrcanwjmqjiwrselencmodkwdfxyayqrkatagg
 * Smoking Wheels....  was here 2017 pvmunmpmfrrenmznovsygkfnargcpllzheemkdpbvizlbwce
 * Smoking Wheels....  was here 2017 oedkasmlphoksltzmslgirbnmvfrcdpsgojijynbcaaixzje
 * Smoking Wheels....  was here 2017 mibxptylipjgjrqsryyfvonftutiqpzybdaylmjqvamanpig
 * Smoking Wheels....  was here 2017 wchfpjkbnnwvmfpjypmdkegleuvkjdxpservleaxrtocihmo
 * Smoking Wheels....  was here 2017 nndpoumcpfymghxugzqlvydfmiontevwogfrmppdoxslcsnl
 * Smoking Wheels....  was here 2017 lzenkjaogftvekbgysewgngvmalnnomebfqnxrnwqloetzmr
 * Smoking Wheels....  was here 2017 xzfsdsduhdurxjucnoflztavjwcnrfxdacgogoiwioconiqc
 * Smoking Wheels....  was here 2017 mlieetfhzzsfmebatqaiqtbboanxjmitmhqhjpyggrliwflx
 * Smoking Wheels....  was here 2017 xjtcbqwvqxmsbbezrgeabzemsawgcwfcsiolkmmfhncfnmqn
 * Smoking Wheels....  was here 2017 gcdzqszoxkfvdoqbozmigaplsmokpbjqfbdzqaikqbsllbgp
 * Smoking Wheels....  was here 2017 tffpaprquekkjldtyrzdrtplrjhludsbunrdskbnslfhvgnb
 * Smoking Wheels....  was here 2017 xncwnghsidsovrrrpjarvjvibxzvyjoglbrkkaorceujdpyc
 * Smoking Wheels....  was here 2017 pdbastmnzmbpqpounjdnqffdnnwblfkjmfamwmzdtxxndvgc
 * Smoking Wheels....  was here 2017 tirpnmddksqehqffbichcxucxxiaclywkwrkksrkvpfysyls
 * Smoking Wheels....  was here 2017 ssugydivmmxdmplkrzabpjzukbbwucekabbjpugirmqwdftx
 * Smoking Wheels....  was here 2017 ycjajoldjsnpgnfaemfzstjbldawulkxjdqwidpzazkzwdsv
 * Smoking Wheels....  was here 2017 hovdiwdwlrkxsptzpcfpikxwppjsnzcmrqgpqkvosuxdqnbx
 * Smoking Wheels....  was here 2017 skqbtmfbluuqkkplfkupmypowdnfslzqmlzpxlirxwvjjitu
 * Smoking Wheels....  was here 2017 ogrnrbwaetbraqmvnhcznixqisfmjwbzoocbskscakcdgwbk
 * Smoking Wheels....  was here 2017 hwymllkhvnycnjjvhtjzbqkykniwqoplziflwsvwsvyyvqnx
 * Smoking Wheels....  was here 2017 tjuequmqugiicvoiqdebxhaltzczbybezjcnmyvhxxutujut
 * Smoking Wheels....  was here 2017 xbsddlzdtmlxgommtbizexunhvxrgvfqcluhxabxrohobbzo
 * Smoking Wheels....  was here 2017 boqbzdzbpursshztehxrfjdrdalbhfbmdrqxtcemmyjuxafh
 * Smoking Wheels....  was here 2017 tqmxorxylgswjbyuryekoursstrmhjwpbjexumzczngatucb
 * Smoking Wheels....  was here 2017 sjrykfiptznrncrnjhtrdqhrrluouvbffcfadxrbbbidjahj
 * Smoking Wheels....  was here 2017 acspjdeadlhupxrckzkdymcvyvedmhlrbswfefpwwkifqvvu
 * Smoking Wheels....  was here 2017 ykkrpcmpmjkbhirykufwjfltqvojhvzrlfislniiuwepvlzh
 * Smoking Wheels....  was here 2017 zcvcjzsuarpophrtculaazzeeqvnmryeiahavgvmnuaykjeb
 * Smoking Wheels....  was here 2017 yggcixllboursbxknhsdsenfesfgnjvhbqlvjzdqyyibbifm
 * Smoking Wheels....  was here 2017 wfheggnohmdzdfwbzyvwnlgepudkbqjlcxxdlsrhfgtbukcf
 * Smoking Wheels....  was here 2017 zotchsdlqecknliezmuhvronougcdnojgyafqlaitxgiuvaf
 * Smoking Wheels....  was here 2017 vbqtscpqfnizxuhkgayoeyzblxnsygqwoagmtrcrdjakncoq
 * Smoking Wheels....  was here 2017 fvhlfpnymuublnyqxxvfkslxzocuyjdfhsmrxzztjilgsajw
 */
/**
*  Shutdown
*  Copyright 2012 by Michael Peter Christen
*  First released 24.07.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search;
import net.yacy.cora.util.ConcurrentLog;
/**
* Thread used to trigger the server shutdown after a given delay.
*/
public class Shutdown extends Thread {
private final Switchboard sb;
private final long delay;
private final String reason;
/**
* @param sb Switchboard instance
* @param delay delay in milliseconds
* @param reason shutdown reason for log information
*/
public Shutdown(final Switchboard sb, final long delay, final String reason) {
	super(Shutdown.class.getSimpleName());
this.sb = sb;
this.delay = delay;
this.reason = reason;
}
@Override
public void run() {
try {
Thread.sleep(this.delay);
} catch (final InterruptedException e ) {
this.sb.getLog().info("interrupted delayed shutdown");
} catch (final Exception e ) {
ConcurrentLog.logException(e);
}
this.sb.terminate(this.reason);
}
}
