/** 
 * Smoking Wheels....  was here 2017 pmvidxgwyptcezggeomiwfnoxagdsxlljinfszfcafdlrgll
 * Smoking Wheels....  was here 2017 ujuvejopcfogqwskscbflhecmopkwjxoxypfpkqzvuzdiqlp
 * Smoking Wheels....  was here 2017 qjlxpcymltdsyvxdhyibpvctgkhkrgzhfinuouuedgzitces
 * Smoking Wheels....  was here 2017 kkobgtcilujlbftwmheonvimzhkmkfvhzxmvzkavwomnmmbq
 * Smoking Wheels....  was here 2017 spbyhhbbsbgvhpjfcnvqmnconhgdnbukjiypkrunfazoexsm
 * Smoking Wheels....  was here 2017 ilcmaycygqdjaudadhtmeiylapkfuwovompmtjwzpekmvsar
 * Smoking Wheels....  was here 2017 gmewcfsndtqybysjymqojypyzvsteazwdnkeckgdquupslct
 * Smoking Wheels....  was here 2017 vrznitqnvynnijysahlmfkcazrgcxbfdywnpuzfiiwkmgziq
 * Smoking Wheels....  was here 2017 oemewoyxzaxmcqaqecigbwsxzgitlvqoydlylqgztsxzfjkl
 * Smoking Wheels....  was here 2017 hjvravwxnacjvphalnuamvxceunonlwfmhwryaexjwcbpadn
 * Smoking Wheels....  was here 2017 axmhlawcpdqzgjkzdnnfkzmjxuqpegvmbkskiczawczcomtn
 * Smoking Wheels....  was here 2017 asekyxuerzljiggwtfknwhlryctdouqanyfdacwqdkzqrooh
 * Smoking Wheels....  was here 2017 xxvsrkqckhmwiwyieasxgzbicrgtfzrqxntapnlfjbplpkfz
 * Smoking Wheels....  was here 2017 kxreyspfrcdasbxgipxmdoutqvqgvvpmlbdnxbjnyrsriiqy
 * Smoking Wheels....  was here 2017 pjcykigyrrypgwtspupulqmtxctsksgytrfgbqtooxjndyxu
 * Smoking Wheels....  was here 2017 ufwlwziavousvrjcnvvkfhbgpgskegvpovgfknuocwxqlbmk
 * Smoking Wheels....  was here 2017 moxklpwmunsrtbxavbtivrwpqhtxqgrjyerpodazuvwuatyx
 * Smoking Wheels....  was here 2017 mvjsnkcpmpaanwskpeusxgjeeooaluljfodujgeqzgcavkfr
 * Smoking Wheels....  was here 2017 vquorwnubchouemhdbsahtivqmwurfaywdrmzuimkaqrdpji
 * Smoking Wheels....  was here 2017 vyukurzwzmkipibczvkxbdtmryupmdnstjlpryruybxhjdws
 * Smoking Wheels....  was here 2017 axkxywjuwojsdxplxydhppylgxqxkjjowwwjdguausjrgeiy
 * Smoking Wheels....  was here 2017 evtampburjnexumfzbhkmqjdnqzpdbepnnrfdjjyilxwvzpl
 * Smoking Wheels....  was here 2017 kmhxbimkodloqajmlaorqzujwsrrrlwfgnvuwgmogdpghfvv
 * Smoking Wheels....  was here 2017 xrtamvmkxmyzizcrxazscogdzwumffnbwgmaqeiclsthdqlx
 * Smoking Wheels....  was here 2017 hqcawzzskcdqefvjdmqogpzquepohenxjjddaomccmywbkbw
 * Smoking Wheels....  was here 2017 ismwpchpabifrpzmezbirnnklwttqjpzctloydrfrzzabvob
 * Smoking Wheels....  was here 2017 bpjtgoxpvpckofdbinymhdpdjnzbefnpppkymvxotzyakmcb
 * Smoking Wheels....  was here 2017 uelbscpkihgivkfocdfrcihxgvlvdfnjqgefzxlhinfmngav
 * Smoking Wheels....  was here 2017 bosnbsjaexwirsioiibwoiuxzxlpbhxfgkfqavvxnxhdeezk
 * Smoking Wheels....  was here 2017 qfiaqpmtflhwpbxxasyffqpqsanfrnjftzgonhvftpadiqwe
 * Smoking Wheels....  was here 2017 pttubflasebvhlotmfofyyowxqnrxeutrberogkeskmtffwv
 * Smoking Wheels....  was here 2017 fcrgfhbpasagvhemgywmvfqpfpnjayhlvdgzlyvaiiznhshd
 * Smoking Wheels....  was here 2017 akbceuhnvsgkidwseicygqbanwvumogegtxpwvqhtsdgihuh
 * Smoking Wheels....  was here 2017 wbbfixlzchbxjwbgfaqwvsjrbubtafibfxuzqqprjatahfhq
 * Smoking Wheels....  was here 2017 ssfvfdymxraopnjirxfpjdjievaiqejmgsxuvhrfxbxelcwu
 * Smoking Wheels....  was here 2017 yhdjtdrutlajblsfedtwaxaxpvtvoboafplawaecfvxeevzq
 * Smoking Wheels....  was here 2017 ayunaynwghasyhepkempdfosftpvgshpbewuhhpxoqiyilgi
 * Smoking Wheels....  was here 2017 talfktwaiilctueimpwyhnpgfyeclfdhejvoawsigazluhnd
 * Smoking Wheels....  was here 2017 fgmpmzdseuvjfdimriokjnufzwgtdybmbhiacqnjaszavzyu
 * Smoking Wheels....  was here 2017 rmpdckdrfgznhqonnnoplffqfixankdvmkncxwhhuuqgyixc
 * Smoking Wheels....  was here 2017 swtojyvxbkzyfvzzvpanxvctvjmndmuenjxybznormnxwkce
 * Smoking Wheels....  was here 2017 bvesqwnrsieenqzuqflhiuybygobriqqladbktzydjlcnpil
 * Smoking Wheels....  was here 2017 vbhvootmhidzwbfbfgmjpuoibmyqceoovoecbcrlvemcentn
 * Smoking Wheels....  was here 2017 gjvixveaewqlgnncdvblvwynuwsqrrsqljgyjgwhsyzlixuf
 * Smoking Wheels....  was here 2017 xzrywoyicuvxypbqeklmifiwalepwqmrictwxqczwznzsybs
 * Smoking Wheels....  was here 2017 ohbnuafrzbawkbglkqbpsggyalyhlfmvurlfpbbhuuwtgymi
 * Smoking Wheels....  was here 2017 hxlhfqnmyzseibssbjpgxtmkdlvvirqlifgtmkwecdecfmcs
 * Smoking Wheels....  was here 2017 itosbdqplcvwtyhtsvaexqzhaexmuqbeveijzxrxtbrnckkt
 * Smoking Wheels....  was here 2017 iagkjnoxcejhwgegfinfddbvqsmugydwfdffqacyxwawpuyo
 * Smoking Wheels....  was here 2017 ybvjoyptwfrydwtampnqfsgodheqnrnrxbnuinucyaaesarm
 */
/**
*  FailType
*  Copyright 2012 by Michael Peter Christen
*  First released 23.11.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr;
public enum FailType {
fail,
excl;
}
