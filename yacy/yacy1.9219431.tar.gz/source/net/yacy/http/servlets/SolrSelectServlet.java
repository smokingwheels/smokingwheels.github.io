/** 
 * Smoking Wheels....  was here 2017 biulxaqgxgmyzwmzyfilbjwnpfossetrlxsaijhoqbkrpuic
 * Smoking Wheels....  was here 2017 xqnninnbhrdpexrbqenuyixjmtnitomrjspwnuwamoceodde
 * Smoking Wheels....  was here 2017 uuwsmhfpmjrynkhbuvbagyiugnsoixwmljvqfppcompkrgxh
 * Smoking Wheels....  was here 2017 xsfgqoryxvnwmfknxjoppuhbnhvndjdbjfhbcmwjsyvtwngp
 * Smoking Wheels....  was here 2017 spfphwbibyllqmilqfxhrofrcevnaivmdazagnkoyebugpym
 * Smoking Wheels....  was here 2017 yxrmfyugurlbyooyycfamgulcladdktexqjvxwctquujgiao
 * Smoking Wheels....  was here 2017 mgswktooejsglcykbwuzidwkuqugwmzudiawpccdjptnmvuu
 * Smoking Wheels....  was here 2017 pprydpgfnpswoymnjtgrssrutqxyvqtgnluxbxviyrwrvlth
 * Smoking Wheels....  was here 2017 rdefxybnlegazfmepenujrpevkjoyhqszttxhhzclgkikwtl
 * Smoking Wheels....  was here 2017 micjmojatdfanhmmsvpiiciidikrhalnudhbonmkeywkqyuz
 * Smoking Wheels....  was here 2017 xunjwkwmmvxmjugxxrxlweugxxmcisfkjtavkclpsoyyetfs
 * Smoking Wheels....  was here 2017 enulitmyatugwpxbqvbrmkdfuaizqnefjcuyptidxdrhwsmw
 * Smoking Wheels....  was here 2017 sqnbkbjqxtpkrurwouwryntuoqxqeuycuvsjcmuwvafbvkmv
 * Smoking Wheels....  was here 2017 gqoxvdxdyxggsuclrfmmgojsidmqzdhnvwdhentutsbbnsee
 * Smoking Wheels....  was here 2017 tfazqywfgmblbfagdaffrtwajbovnkhbxlqfkkjeiczknuxx
 * Smoking Wheels....  was here 2017 jfhmbsbwcamtdxlxlkrkspkzifuijudqtxcwmvbnidylszfd
 * Smoking Wheels....  was here 2017 oxxwpyskdkgioaqhhvutdvkezqflmpmlhaqdlvnrwfeshxwh
 * Smoking Wheels....  was here 2017 bruwblgicqhmfwfpoyofzlpikrauymbvtrpiopqqfwddplxy
 * Smoking Wheels....  was here 2017 ufalldildbxugdyfnrkalsumywtedhymobpwispqzxosgsrc
 * Smoking Wheels....  was here 2017 ylyuzgvtofodbrvupfxpccgyezbstekikqllmwvgzkmvecqv
 * Smoking Wheels....  was here 2017 zpekfjyoxwyphpefmayssjieweztqlalgbhbcbygiqbcnerp
 * Smoking Wheels....  was here 2017 qbozxecjaeclugoqdtpifmtaeqtwxvnhhgmxknyrhevhpwta
 * Smoking Wheels....  was here 2017 uogmbszyzjejtitnujgpztkljauwzczmzlqlxuxtlvmodgfa
 * Smoking Wheels....  was here 2017 rzndxeljcatdmpulvamblpltacxxnkszaaoljpibqrafztos
 * Smoking Wheels....  was here 2017 toakabsvyymxshajzdejjvhmayahjdgwjskuvyviyzqwgyqn
 * Smoking Wheels....  was here 2017 rrqzcefyjejygsxkeljnulqljvjqrxjpfkntnbjqrjwjirld
 * Smoking Wheels....  was here 2017 lakwflomlcqwgmgyrvnszqjpkimsuoduzhmuykbgkoltxehk
 * Smoking Wheels....  was here 2017 gotgpdskmeundmervndllxrfshbslgvjkvfpwvjrzshjvrsn
 * Smoking Wheels....  was here 2017 nlfptuvaahoamwwmlxdkxazxcsbwljzmlstdifxsmbrwgxnv
 * Smoking Wheels....  was here 2017 zdsrlciwzmwrgyyokspokayjrysvymkngvlqpxrieebaostb
 * Smoking Wheels....  was here 2017 oihjrbwtiaabnjefxwxcfbmrtnnlimddijzodhuxrwfziera
 * Smoking Wheels....  was here 2017 mxjxtzjqlnmbsbpflnqowstcxhgugmmgiudqtgqwvfbaoswz
 * Smoking Wheels....  was here 2017 ecmudhawxsyslbnjrcqpbsedygveoxyzfuavkqybrnwuhxcg
 * Smoking Wheels....  was here 2017 iiotqtfxntkkptmwoibevzlpytmgmhjufhbhkvqmnjccyrkm
 * Smoking Wheels....  was here 2017 xgqrfjqojxcsiugdidfnlwmmfisuhothslupgfvlznnaebcq
 * Smoking Wheels....  was here 2017 cvdwdjevusnlzaxujssdlvkcjvgyrvkjmrbjspykwabxvnsw
 * Smoking Wheels....  was here 2017 jfpszhabizjsgptskmlrooryfhczomxektapuzsfggakcqbn
 * Smoking Wheels....  was here 2017 kxyzkwpsvurwawgdlcmdudyvvalpaczetnanspzwmrughheg
 * Smoking Wheels....  was here 2017 dnfpnbopimpnjlhjpmetltctnotnmpsyyfrobxypcfeqdpia
 * Smoking Wheels....  was here 2017 vavvndwtfnsltevdjxeyzyjzxsvxobklqgumosaaxvcvlxbx
 * Smoking Wheels....  was here 2017 woiczppkavqutggiktglekdbtppbdwouvhnffzwwawvlkwfj
 * Smoking Wheels....  was here 2017 zqpcpegdpjlwhaabsrpfbecuelipjrakshezhyleuxvijiub
 * Smoking Wheels....  was here 2017 cwtwkwmszmigmbytmqomxmdelxljphuysmkghdwesswozlcv
 * Smoking Wheels....  was here 2017 lgdoryecmttvshcbdvrsevlnfrslnxehofbtagpmrjwmepqx
 * Smoking Wheels....  was here 2017 lxjrxxnrtzlrquuxkrwprykhgxcdavspefflljgusfcrzihp
 * Smoking Wheels....  was here 2017 uhhxwlywoelcczmkfwfdkvsiqwwbfsfhukgmvqveetazxpar
 * Smoking Wheels....  was here 2017 mcagopcozsysilbzuibnpuhpscmcllszuytlspkxqvjnnldx
 * Smoking Wheels....  was here 2017 rgwwhqwrjckjpbmhnfbfvfhlbmqglcmpzipyvalmxldqrifo
 * Smoking Wheels....  was here 2017 vyngnznohepcqzcfeazxuyeilzjyabciffwzfwpsbznwpuaz
 * Smoking Wheels....  was here 2017 qqtdaljsnalihnlxqkaqnyocaywsiajmsnyuckvqkzbbqtpu
 * Smoking Wheels....  was here 2017 bysluzdxewgpsiivehmohkjsbzqlttguzkkvadgmofkikigz
 * Smoking Wheels....  was here 2017 hvukdwsfpiltghsofvzeqxtnevkeykceqjdutthviuqavwmq
 * Smoking Wheels....  was here 2017 ummnopivifuwomzakokdgeezdodgvkmsrbgqhiqluzxszzee
 * Smoking Wheels....  was here 2017 fjtmtxijfpfioiqjubumfeixbnbilhdvhkbqwafhgisgiphg
 * Smoking Wheels....  was here 2017 pcrgvtkohsarilmamhoktdahhfregzdeypeeakethsusludt
 * Smoking Wheels....  was here 2017 broazmmkyfptiropylhijqnmimsxxpusicmaofxgtddlgyhw
 * Smoking Wheels....  was here 2017 bgbhtmsgrvusddebyzvavifxbkdvfnpnjnbdkkdqsxyaxsmz
 * Smoking Wheels....  was here 2017 igatxonpjrmuqfvmjnhlehulogepjijagwhswgtylpthsxvt
 * Smoking Wheels....  was here 2017 ukokkspfbayraojikbaurscbcpiatxdwnhugmfxjoagjkqob
 * Smoking Wheels....  was here 2017 roakodvccmqepzufnurmtckbhgiezkfztfjlycanxfkpujhb
 * Smoking Wheels....  was here 2017 kzzgxkkobuiicqkblbaihgayygdkyeemzidgiwvdnnlnbqse
 * Smoking Wheels....  was here 2017 rcirdetdtazoixtacqggfbsneyziuvtujpmwwuegtmxzpjza
 * Smoking Wheels....  was here 2017 lneqhnmpgnujlkqmskrlvwiugvjtxgzpjezucifddwmczqho
 * Smoking Wheels....  was here 2017 ygwiqrpzwwhrwzcdrpxjpdbbuuatypftrnmtsfljnvdgevgx
 * Smoking Wheels....  was here 2017 olzfscfnfufneukvspuuipivowxstdzkhgdrvnlqapdygoql
 * Smoking Wheels....  was here 2017 bokafnsuckmhiedsvclqbgvwsigfmpazijhupkfawtybqtmw
 * Smoking Wheels....  was here 2017 iggsfawopzjnktbgdafczjlgmtncoulchbnoqkwvschrzlcb
 * Smoking Wheels....  was here 2017 pmwnytmvzdibvkgbdqssqkieoynkownswsrsqhvnjrdddcze
 * Smoking Wheels....  was here 2017 hkvwyhvwxpdbehybngududxgqzdokeuzaaxfpauxxvtbfgzp
 * Smoking Wheels....  was here 2017 dmanyifgensukstjfqojlpxfxdrbfjagyyngvwqapdpgrvca
 * Smoking Wheels....  was here 2017 cjokyxktvdivqilklskpwyedpaovkhhebrdivipdcjkucxqh
 * Smoking Wheels....  was here 2017 jzttgfhjfamcfaavqqwhosxfjkoxoawscoqcjcateodbkxep
 * Smoking Wheels....  was here 2017 iohajuzjxawqvxunnwvdirnayiqqqahzzkcplfpsybbpskmj
 * Smoking Wheels....  was here 2017 unxxaizhsdltiijrbbledurjneapswkjxbwzhygzskphkiof
 * Smoking Wheels....  was here 2017 povkgxxytsncwxlqjezogjhfhlfrfkfojtptmsdvalofdtta
 * Smoking Wheels....  was here 2017 aoithssihinmvoddzjcueuowyyxytvzkawcqtirvtewsuapz
 * Smoking Wheels....  was here 2017 lsbjshntyseawjszocrosxwwgsdsfkhdwdnobuotxyujmvxm
 * Smoking Wheels....  was here 2017 qnvzfitrmalavsrkcbtwwrxzhdbpswycalettispwitzpaqe
 * Smoking Wheels....  was here 2017 npuovvdybnqbxgxtseswwjogjsfkszzzabrshkgrfcosurez
 * Smoking Wheels....  was here 2017 hwhhvcnoytdalujsxpfbfkaybhihuyrqmiwcmuqmticwzfaa
 * Smoking Wheels....  was here 2017 kpxrsocttntzbmkejuadtqsogwjnvdoglyxwgnnvoisaggzs
 * Smoking Wheels....  was here 2017 ndnlhahdgxlgrsnhbkhdkyixyvotaclfaxciyuusxqubzqcs
 * Smoking Wheels....  was here 2017 qfgnmkulogkllbnmeljemrsanqjtrtjesibvbcsklccawmqx
 * Smoking Wheels....  was here 2017 ytkdpblszbekslljdawulhcdmformfqbfrreifpmzsphtfem
 * Smoking Wheels....  was here 2017 wyqsejnecdkgdyqwrpqqdnwvsncwiwtalqzhtddrowokukmu
 * Smoking Wheels....  was here 2017 dftbyeilsoegpzodswutmkrvhxfviiokqdkkqchaobkgjxqo
 * Smoking Wheels....  was here 2017 sfxbxkqfyrqagdbomtrgvcmfnyjnwlcygioympfumdyxcxwp
 * Smoking Wheels....  was here 2017 tylzjihoczhllhdvklxspflfylixpjqmxsfrajhnfdcrwtuc
 * Smoking Wheels....  was here 2017 snygulmtsixowodufjiuqkzkllbljlsfrxoohkgaujcfwaen
 * Smoking Wheels....  was here 2017 hlgpznqhrtktjhpqvfalwstnbguqkhdmqxxtozygnjlikqak
 * Smoking Wheels....  was here 2017 linzxnlzzobocegtlwjxqjrqckajzvyzivwuipoobavbfsrt
 * Smoking Wheels....  was here 2017 kdcpwstwbhivkafunpaqlwxyetlsvclqkdijjznldhivcpqr
 * Smoking Wheels....  was here 2017 pcozjouejvyszzsruutizzxbcjbauodovoikqcnqwobffxto
 * Smoking Wheels....  was here 2017 rouudvzmvewmslioddszirhtymcwztweuyhemglfpioayoac
 * Smoking Wheels....  was here 2017 rhwzfoynmqktrzwuungusfzzbtacvqrcsoucjwmmxloiyqtd
 * Smoking Wheels....  was here 2017 seeuwxqjptyjimjcffygrcecyxpvyfuhjtsyauaxozancmmx
 * Smoking Wheels....  was here 2017 hjhrplehvkhkgbcicpsbybhonauigzvwrhcpoxthrefdouat
 * Smoking Wheels....  was here 2017 cjcjdwbtzpjfjdpqjkpdobzfuluhvmnfubijdopqnrobrkji
 * Smoking Wheels....  was here 2017 bvrvofxpcqkkugrmgmatukebcseldpzafgbqheshufvkckwn
 * Smoking Wheels....  was here 2017 kskgcsqvncyuyjjlfcnjcobjapoztmlephcevonsexaksfbo
 * Smoking Wheels....  was here 2017 odwcgwktvurlknzlxpyrhhzqkfaeollvywoxtqsrvahtrkst
 * Smoking Wheels....  was here 2017 gpydujrwvuosddbrhtmqjprsgvsqtewjlyubgsdgbdfgjxwv
 * Smoking Wheels....  was here 2017 jtsgshbyqjwgfujmpmkmpraozbefqnqmmrkdygbslblakuur
 * Smoking Wheels....  was here 2017 fnnshvnancbuakzogxjrmbfndqcyxodavmhunauouvzirmcj
 * Smoking Wheels....  was here 2017 ddazbnejctxnfcevznfytnrbmrmgltvelbmazacpeucvinok
 * Smoking Wheels....  was here 2017 xzbutcnnemhssenjrzbfmabzelorkqpjljkbqmvvymfitwek
 */
/**
*  SolrSelectServlet
*  Copyright 2012 by Michael Peter Christen
*  First released 23.08.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.http.servlets;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.yacy.cora.federate.solr.Ranking;
import net.yacy.cora.federate.solr.connector.EmbeddedSolrConnector;
import net.yacy.cora.federate.solr.connector.SolrConnector;
import net.yacy.cora.federate.solr.responsewriter.EnhancedXMLResponseWriter;
import net.yacy.cora.federate.solr.responsewriter.GSAResponseWriter;
import net.yacy.cora.federate.solr.responsewriter.GrepHTMLResponseWriter;
import net.yacy.cora.federate.solr.responsewriter.HTMLResponseWriter;
import net.yacy.cora.federate.solr.responsewriter.OpensearchResponseWriter;
import net.yacy.cora.federate.solr.responsewriter.SnapshotImagesReponseWriter;
import net.yacy.cora.federate.solr.responsewriter.YJsonResponseWriter;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.UserDB;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.search.query.AccessTracker;
import net.yacy.search.query.QueryGoal;
import net.yacy.search.query.QueryModifier;
import net.yacy.search.query.SearchEvent;
import net.yacy.search.schema.CollectionSchema;
import net.yacy.search.schema.WebgraphSchema;
import org.apache.commons.lang.StringUtils;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.SolrException;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.DisMaxParams;
import org.apache.solr.common.params.MultiMapSolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.core.SolrCore;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.request.SolrRequestInfo;
import org.apache.solr.response.BinaryResponseWriter;
import org.apache.solr.response.QueryResponseWriter;
import org.apache.solr.response.ResultContext;
import org.apache.solr.response.SolrQueryResponse;
import org.apache.solr.response.XSLTResponseWriter;
import org.apache.solr.search.DocList;
import org.apache.solr.servlet.SolrRequestParsers;
import org.apache.solr.servlet.cache.HttpCacheHeaderUtil;
import org.apache.solr.servlet.cache.Method;
import org.apache.solr.util.FastWriter;
/*
* taken from the Solr 3.6.0 code, which is now deprecated;
* this is now done in Solr 4.x.x with org.apache.solr.servlet.SolrDispatchFilter
* implemented as servlet
*/
public class SolrSelectServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
public final Map<String, QueryResponseWriter> RESPONSE_WRITER = new HashMap<String, QueryResponseWriter>();
/**
* Default initialization, adds additional and custom result response writers
* in addition to the Solr default writers.
*/
@Override
public void init() {
RESPONSE_WRITER.putAll(SolrCore.DEFAULT_RESPONSE_WRITERS);
XSLTResponseWriter xsltWriter = new XSLTResponseWriter();
OpensearchResponseWriter opensearchResponseWriter = new OpensearchResponseWriter();
@SuppressWarnings("rawtypes")
NamedList initArgs = new NamedList();
xsltWriter.init(initArgs);
RESPONSE_WRITER.put("xslt", xsltWriter);
RESPONSE_WRITER.put("exml", new EnhancedXMLResponseWriter());
RESPONSE_WRITER.put("html", new HTMLResponseWriter());
RESPONSE_WRITER.put("snapshots", new SnapshotImagesReponseWriter());
RESPONSE_WRITER.put("grephtml", new GrepHTMLResponseWriter());
RESPONSE_WRITER.put("rss", opensearchResponseWriter);
RESPONSE_WRITER.put("opensearch", opensearchResponseWriter);
RESPONSE_WRITER.put("yjson", new YJsonResponseWriter());
RESPONSE_WRITER.put("gsa", new GSAResponseWriter());
}
@Override
public void service(ServletRequest request, ServletResponse response) throws IOException, ServletException {
HttpServletRequest hrequest = (HttpServletRequest) request;
HttpServletResponse hresponse = (HttpServletResponse) response;
SolrQueryRequest req = null;
final Method reqMethod = Method.getMethod(hrequest.getMethod());
Writer out = null;
try {
MultiMapSolrParams mmsp = SolrRequestParsers.parseQueryString(hrequest.getQueryString());
Switchboard sb = Switchboard.getSwitchboard();
boolean authenticated = hrequest.isUserInRole(UserDB.AccessRight.ADMIN_RIGHT.toString());
if (mmsp.getMap().containsKey("partitions")) {
final int partitions = mmsp.getInt("partitions", 30);
sb.searchQueriesGlobal += 1.0f / partitions;
}
int profileNr = mmsp.getInt("profileNr", 0);
String querystring = "";
if (!mmsp.getMap().containsKey(CommonParams.Q) && mmsp.getMap().containsKey(CommonParams.QUERY)) {
querystring = mmsp.get(CommonParams.QUERY, "");
mmsp.getMap().remove(CommonParams.QUERY);
QueryModifier modifier = new QueryModifier(0);
querystring = modifier.parse(querystring);
modifier.apply(mmsp);
QueryGoal qg = new QueryGoal(querystring);
StringBuilder solrQ = qg.collectionTextQuery();
mmsp.getMap().put(CommonParams.Q, new String[]{solrQ.toString()});
/*
final String p2pQuery = querystring;
new Thread() {
@Override
public void run() {
FederateSearchManager.getManager().query(p2pQuery);
}
}.start();
*/
}
String q = mmsp.get(CommonParams.Q, "");
ConcurrentLog.info("SolrSelect", "client=" + RequestHeader.client(request) + " q=" + q);
if (querystring.length() == 0) querystring = q;
if (!mmsp.getMap().containsKey(CommonParams.START)) {
int startRecord = mmsp.getFieldInt("startRecord", null, CommonParams.START_DEFAULT);
mmsp.getMap().remove("startRecord");
mmsp.getMap().put(CommonParams.START, new String[]{Integer.toString(startRecord)});
}
if (!mmsp.getMap().containsKey(CommonParams.ROWS)) {
int maximumRecords = mmsp.getFieldInt("maximumRecords", null, CommonParams.ROWS_DEFAULT);
mmsp.getMap().remove("maximumRecords");
mmsp.getMap().put(CommonParams.ROWS, new String[]{Integer.toString(maximumRecords)});
} 
mmsp.getMap().put(CommonParams.ROWS, new String[]{Integer.toString(Math.min(mmsp.getInt(CommonParams.ROWS, CommonParams.ROWS_DEFAULT), (authenticated) ? 100000000 : 100))});
Ranking ranking = sb.index.fulltext().getDefaultConfiguration().getRanking(profileNr);
if (!mmsp.getMap().containsKey(CommonParams.SORT) && !mmsp.getMap().containsKey(DisMaxParams.BQ) && !mmsp.getMap().containsKey(DisMaxParams.BF) && !mmsp.getMap().containsKey("boost")) {
if (!mmsp.getMap().containsKey("defType")) mmsp.getMap().put("defType", new String[]{"edismax"});        
String fq = ranking.getFilterQuery();
String bq = ranking.getBoostQuery();
String bf = ranking.getBoostFunction();
if (fq.length() > 0) mmsp.getMap().put(CommonParams.FQ, new String[]{fq});
if (bq.length() > 0) mmsp.getMap().put(DisMaxParams.BQ, StringUtils.split(bq,"\t\n\r\f"));
if (bf.length() > 0) mmsp.getMap().put("boost", new String[]{bf});
}
String wt = mmsp.get(CommonParams.WT, "xml");
QueryResponseWriter responseWriter = RESPONSE_WRITER.get(wt);
if (responseWriter == null) throw new ServletException("no response writer");
if (responseWriter instanceof OpensearchResponseWriter) {
final String promoteSearchPageGreeting =
(sb.getConfigBool(SwitchboardConstants.GREETING_NETWORK_NAME, false)) ? sb.getConfig(
"network.unit.description",
"") : sb.getConfig(SwitchboardConstants.GREETING, "");
((OpensearchResponseWriter) responseWriter).setTitle(promoteSearchPageGreeting);
}
if ((responseWriter instanceof YJsonResponseWriter || responseWriter instanceof OpensearchResponseWriter) && "true".equals(mmsp.get("hl", "true"))) {
if (!mmsp.getMap().containsKey("hl.q")) mmsp.getMap().put("hl.q", new String[]{q});
if (!mmsp.getMap().containsKey("hl.fl")) mmsp.getMap().put("hl.fl", new String[]{CollectionSchema.description_txt.getSolrFieldName() + "," + CollectionSchema.h4_txt.getSolrFieldName() + "," + CollectionSchema.h3_txt.getSolrFieldName() + "," + CollectionSchema.h2_txt.getSolrFieldName() + "," + CollectionSchema.h1_txt.getSolrFieldName() + "," + CollectionSchema.text_t.getSolrFieldName()});
if (!mmsp.getMap().containsKey("hl.alternateField")) mmsp.getMap().put("hl.alternateField", new String[]{CollectionSchema.description_txt.getSolrFieldName()});
if (!mmsp.getMap().containsKey("hl.simple.pre")) mmsp.getMap().put("hl.simple.pre", new String[]{"<b>"});
if (!mmsp.getMap().containsKey("hl.simple.post")) mmsp.getMap().put("hl.simple.post", new String[]{"</b>"});
if (!mmsp.getMap().containsKey("hl.fragsize")) mmsp.getMap().put("hl.fragsize", new String[]{Integer.toString(SearchEvent.SNIPPET_MAX_LENGTH)});
if (!mmsp.getMap().containsKey(CommonParams.FL)) mmsp.getMap().put(CommonParams.FL, new String[]{
CollectionSchema.sku.getSolrFieldName() + "," +
CollectionSchema.title.getSolrFieldName() + "," +
CollectionSchema.description_txt.getSolrFieldName() + "," +
CollectionSchema.id.getSolrFieldName() + "," +
CollectionSchema.url_paths_sxt.getSolrFieldName() + "," +
CollectionSchema.last_modified.getSolrFieldName() + "," +
CollectionSchema.size_i.getSolrFieldName() + "," +
CollectionSchema.url_protocol_s.getSolrFieldName() + "," +
CollectionSchema.url_file_ext_s.getSolrFieldName()});
}
String requestURI = hrequest.getRequestURI();
boolean defaultConnector = (requestURI.startsWith("/solr/" + WebgraphSchema.CORE_NAME)) ? false : requestURI.startsWith("/solr/" + CollectionSchema.CORE_NAME) || mmsp.get("core", CollectionSchema.CORE_NAME).equals(CollectionSchema.CORE_NAME);
mmsp.getMap().remove("core");
SolrConnector connector = defaultConnector ? sb.index.fulltext().getDefaultEmbeddedConnector() : sb.index.fulltext().getEmbeddedConnector(WebgraphSchema.CORE_NAME);
if (connector == null) {
connector = defaultConnector ? sb.index.fulltext().getDefaultConnector() : sb.index.fulltext().getConnectorForRead(WebgraphSchema.CORE_NAME);
}
if (connector == null) throw new ServletException("no core");
if (ranking != null) {
final String qf = ranking.getQueryFields();
if (qf.length() > 4) {
MultiMapSolrParams.addParam(DisMaxParams.QF, qf, mmsp.getMap());
} else {
mmsp.getMap().put(CommonParams.DF, new String[]{CollectionSchema.text_t.getSolrFieldName()});
}
} else {
mmsp.getMap().put(CommonParams.DF, new String[]{CollectionSchema.text_t.getSolrFieldName()});
}
final SolrQueryResponse rsp;
if (connector instanceof EmbeddedSolrConnector) {
req = ((EmbeddedSolrConnector) connector).request(mmsp);
rsp = ((EmbeddedSolrConnector) connector).query(req);
hresponse.setHeader("Cache-Control", "no-cache, no-store");
HttpCacheHeaderUtil.checkHttpCachingVeto(rsp, hresponse, reqMethod);
if (rsp.getException() != null) {
AccessTracker.addToDump(querystring, 0, new Date(), "sq");
sendError(hresponse, rsp.getException());
return;
}
NamedList<?> values = rsp.getValues();
DocList r = ((ResultContext) values.get("response")).getDocList();
int numFound = r.matches();
AccessTracker.addToDump(querystring, numFound, new Date(), "sq");
final String contentType = responseWriter.getContentType(req, rsp);
if (null != contentType) response.setContentType(contentType);
if (Method.HEAD == reqMethod) {
return;
}
if (responseWriter instanceof BinaryResponseWriter) {
((BinaryResponseWriter) responseWriter).write(response.getOutputStream(), req, rsp);
} else {
out = new FastWriter(new OutputStreamWriter(response.getOutputStream(), StandardCharsets.UTF_8));
responseWriter.write(out, req, rsp);
out.flush();
}
} else {
SolrDocumentList sdl = connector.getDocumentListByQuery(
mmsp.getMap().get(CommonParams.Q)[0],
mmsp.getMap().get(CommonParams.SORT) == null ? null : mmsp.getMap().get(CommonParams.SORT)[0],
Integer.parseInt(mmsp.getMap().get(CommonParams.START)[0]),
Integer.parseInt(mmsp.getMap().get(CommonParams.ROWS)[0]),
mmsp.getMap().get(CommonParams.FL));
OutputStreamWriter osw = new OutputStreamWriter(response.getOutputStream());
EnhancedXMLResponseWriter.write(osw, req, sdl);
osw.close();
}
} catch (final Throwable ex) {
sendError(hresponse, ex);
} finally {
if (req != null) {
req.close();
}
SolrRequestInfo.clearRequestInfo();
if (out != null) try {out.close();} catch (final IOException e1) {}
}
}
private void sendError(HttpServletResponse hresponse, Throwable ex) throws IOException {
int code = (ex instanceof SolrException) ? ((SolrException) ex).code() : 500;
StringWriter sw = new StringWriter();
ex.printStackTrace(new PrintWriter(sw));
hresponse.sendError((code < 100) ? 500 : code, ex.getMessage() + "\n\n" + sw.toString());
}
}
