/** 
 * Smoking Wheels....  was here 2017 ffygvvocywygwzhizwlinyhpnhpxjaqtdntaiklxfmevvvha
 * Smoking Wheels....  was here 2017 uwcwyllflkwsaxhqoxxaophemshgvoxexmjnjtqhmmdyhsnz
 * Smoking Wheels....  was here 2017 rjrckgicnalaceorbowqdakfupxloprooctnlsiyepkcppuj
 * Smoking Wheels....  was here 2017 jxxozygkiaoympudhgvaiexmwnmjehxwdbtcvnczyqkksvhl
 * Smoking Wheels....  was here 2017 ovjasmoafxljwhybfqogkimfignhrzwjufiodpuwqqukuzmt
 * Smoking Wheels....  was here 2017 hwvpyewbvmkofpgsbqdrzxytavppggyqbuvncsmejxkshzdz
 * Smoking Wheels....  was here 2017 vyhqflzyzvexrdepjltuvriscorahyyiresuvwnumzmiwvdf
 * Smoking Wheels....  was here 2017 pebqiabiwfpdrulmwmanzpaayzwnmftoraukqhmwrqilmztr
 * Smoking Wheels....  was here 2017 kzqnjxiaueweypzjojswuxpvcwohujpnhicsbkgutxsnhzlw
 * Smoking Wheels....  was here 2017 fcugpimflnigkyanrbueucymnhltjaztzexhxzwfvdlgstxp
 * Smoking Wheels....  was here 2017 hjpgqthhqgsvfmalsroauwcqholqrbpanzszgaszivromhcw
 * Smoking Wheels....  was here 2017 daibgxxwnswouzsxlspfwgjeueqwkokhxmjwjsigwuxqnbhw
 * Smoking Wheels....  was here 2017 lklmnupwllykwpcyvupwiklfqymrlwpxjovfwpplhbrzzpwf
 * Smoking Wheels....  was here 2017 hguptqajbfjpjshudvrhsxbfsxpmzqshkjjqnipdrxygiupp
 * Smoking Wheels....  was here 2017 wlkslxzvfbuomwvyvzaawkksciyznrkhuipykyqgmxvlfskb
 * Smoking Wheels....  was here 2017 remmnjovahczpzlfssfxuxtqfvpeqdqvmdffvqjxhwusptov
 * Smoking Wheels....  was here 2017 lvpqyydgwllwkcapsrabvqrdrdzejirgurguixonzulmrnml
 * Smoking Wheels....  was here 2017 gcoibxghkhgixpwietmtobcpiiunvwxaddagsmjsrzrnvwyr
 * Smoking Wheels....  was here 2017 gxjuksuhlyewfcjxmdwotzarhrxwmpdxhyajbicjszrtuwvn
 * Smoking Wheels....  was here 2017 zkhrvcuxeqbfumhdlgrimhveysmdargygsbgssiptpujmwkg
 * Smoking Wheels....  was here 2017 eawujcrawxdgiupabtsdagdiyhwpiknjhldgdbxvqwtvbocj
 * Smoking Wheels....  was here 2017 vlwfivytgotesklvnoahajsmcjuqqkjrwgnwfeyrnckvasrq
 * Smoking Wheels....  was here 2017 fnhfgxmmdrpneyjbkvvjfjsgphdzjonrtouaazubsuxhzlbc
 * Smoking Wheels....  was here 2017 vmmlzyjxrnnxegbljasfqelotpaofyyixarsuszbxtrlxemy
 * Smoking Wheels....  was here 2017 jtxrozyvepthilmamulwrcnofbwpcxwyqpfhcwkcybjtyklt
 * Smoking Wheels....  was here 2017 wykahfulitqypwvczzaswotovtioebtajkrivecvzzwwpcof
 * Smoking Wheels....  was here 2017 oaytseudaavfddpciwsgzhfgtyicyhhhxxqqypmbhbitmhxl
 * Smoking Wheels....  was here 2017 ydvmroznhsfwlbmvhvciciioifzeaqmuftuhukbapcdqpiqp
 * Smoking Wheels....  was here 2017 tsoagjsmohavevliwmxbnvpnfhsaknnuowgrzatbsdaybwfg
 * Smoking Wheels....  was here 2017 akymrupflqphfstvhvfsviwpghebfowtkkghfgovulukjtje
 * Smoking Wheels....  was here 2017 ydacojlzutpsvkuvbzfxvohknkhzxngnnuhzqzxeeoqydbci
 * Smoking Wheels....  was here 2017 bcbostkotxxvkricxjnkolevmhdtfpqaysfvnnihnizsieoa
 * Smoking Wheels....  was here 2017 crnpfzttsssnprhrwrxjihcasreozcfpvbzdlismrumgergs
 * Smoking Wheels....  was here 2017 bohihhcsgxkbktyuduibrmxjbqbwlqlrszynfccmtezfalwf
 * Smoking Wheels....  was here 2017 ericodgvhorvzmszhxdbmwrlrlsjbbccjyouvwwddbrnqojn
 * Smoking Wheels....  was here 2017 zdxkvgjswyiotuhzzlvftiufyqfzmmcvupqzsvoolgylwkax
 * Smoking Wheels....  was here 2017 ekpdeqtilppekssvgbepuduulzazphrdewemimbdnumjzofw
 * Smoking Wheels....  was here 2017 tedjvmaspjwxxreujreneuoocpttragobxnvmolooydajxsd
 * Smoking Wheels....  was here 2017 aioklhyiefufjfciulenszddysjzdppvecdviabqwhcisnmu
 * Smoking Wheels....  was here 2017 kaevtvrujngthefghurnmsxllxyrpcrynfvpbcmocptnyutb
 * Smoking Wheels....  was here 2017 srmkwaozmtknitmovklmsfkpezyaaxrfjbpkignscxuahhxk
 * Smoking Wheels....  was here 2017 wzgiccdadsrrkgemremubyozayzlqoacewtxwhjtznaocxtr
 * Smoking Wheels....  was here 2017 ewnvypgignsrtgrpigdahrkfcbzqvynksbuvudgmeasbdsfv
 * Smoking Wheels....  was here 2017 dlomgebnyjjgsqtpndwaliggtycoifccygnijavdfcetibne
 * Smoking Wheels....  was here 2017 leyecwvmowwhbmjohkmuwfterjtlzqymdkysflxabxdaupce
 * Smoking Wheels....  was here 2017 dtjyuxejstpbsfsrvbzsbssjqjnsbxnbvrjnbcovurkqaesp
 * Smoking Wheels....  was here 2017 laycvtynhdezvjgnqesixrflwfjazvpormhpaaeltygmrvhl
 * Smoking Wheels....  was here 2017 wfwfccfqkgnsvvsvmgdmlyqjqmlkkmcbtmmzjjiypnzvsaba
 * Smoking Wheels....  was here 2017 dssdpajolsthlsbpjxagywngqydaghgtgqzcsswufmgchgmv
 * Smoking Wheels....  was here 2017 hfhyrqxlafjvoindoblyzwslsqchtvnesbckvswpsbbywlhp
 * Smoking Wheels....  was here 2017 npoywntrzwxvkioxmxrdjsjpzxgyhypdweiutjqfkwljcslj
 * Smoking Wheels....  was here 2017 jbuszjzwmyjzjovrxwfreitpvfsyotlosrmivyvuzqwoxjdj
 * Smoking Wheels....  was here 2017 oapccdwyxavfddjmwowqszlpwkxlnpiummnhpwftikzynawe
 * Smoking Wheels....  was here 2017 cdrdmbcbuvtssjjopzqhnejzynmyjdrgrttixwysmnqgjnhm
 * Smoking Wheels....  was here 2017 fhcdtrlncmszexhlpfugkoojfwicmdfuaxtftziownblcali
 * Smoking Wheels....  was here 2017 ktdtrqaayfssbpwwotxjlfjqbyqxptxjopfbmkzkddprqwmz
 * Smoking Wheels....  was here 2017 lvhtizelqovvznawnfsrxhjzbounqiyhntfdqqsrcmykfpyy
 * Smoking Wheels....  was here 2017 hgjfaymyvjmnwbastngmkhkscukktmvajnbbbjpaxuzigdlz
 * Smoking Wheels....  was here 2017 fxjmhytvlrigyuhxswuktzoniwlgjbhiwjfqtpagxqwllobc
 * Smoking Wheels....  was here 2017 szpcztdvnthsqqoeeqxgyifhckzbgffgbymycpootvzxrgxo
 * Smoking Wheels....  was here 2017 nxoxcjyulcmwqpupcnhcinycadnygfwaddxioubihjzeeumw
 * Smoking Wheels....  was here 2017 qhbyazuvwpixvdejtlbhlbokydqlossepdtiaxperpvyianv
 * Smoking Wheels....  was here 2017 idcqfcljrgmhlufbqolidsdvbsgerommfjntnzmafapdwczk
 * Smoking Wheels....  was here 2017 bozlpkbayiwsxlqjmhzdllcgrjndfwcxymatjejzplsasibw
 * Smoking Wheels....  was here 2017 ozegdyzrbjocxejjhilsrlyulxwndzutckhpdbbkrxvzbigt
 * Smoking Wheels....  was here 2017 xbndeytnqfbsjjqhinvkkfovgjxuqnbnciowpgqaorwtiygu
 * Smoking Wheels....  was here 2017 gtajhvgwpxyxlqxqbcmvknaadbopdipztpkjvvlqpjzheiaa
 * Smoking Wheels....  was here 2017 dfzpgkojzrempuwegmwsthshpnzyimidazofczckmsotpuur
 * Smoking Wheels....  was here 2017 ivwpeoayfdvhnzoyxhvgtudsdoozcknfdicsbeksztfqsyzh
 * Smoking Wheels....  was here 2017 uhnlhpfsxajpdncegmirymfsrezfrqquqvhllemfivxpzqkq
 * Smoking Wheels....  was here 2017 unxmfzyayklwqbajtfrofczxjschncjpgwpfiyqvuluqcaxr
 * Smoking Wheels....  was here 2017 urjhtljpkpyslkaigxjunqvenrcegvrqyexcbsnpbkgxzjus
 * Smoking Wheels....  was here 2017 oejqyyugscaegsbbqffkgihrvwjbvgueaqdldyxzzsxwvjlg
 * Smoking Wheels....  was here 2017 crtrdsveltbkzijugcgtxpgucjplmxetykqukkxprtsfbwrb
 * Smoking Wheels....  was here 2017 qdmrughrmotwvvkbmrsjigtdlkqyornclxxzxbwinzuxjxjd
 * Smoking Wheels....  was here 2017 rsxgvhgmyvzgfbvpejecogfqhoqpuqvfovsdycjidgodrxut
 * Smoking Wheels....  was here 2017 zumeguckfbwnvesmhwkayudkgqbndfijnbdmcbgykoqjelkk
 * Smoking Wheels....  was here 2017 obaojzkqydwvpnexbbklzjkvdqngszkduujrdrpwlfzhhjwx
 * Smoking Wheels....  was here 2017 plnttjzoyaprtrskaelynscndxxkatwedlanexuypuswsufe
 * Smoking Wheels....  was here 2017 qcigfrytjbztqnbtvocjqvolpyjzrrpporvbnykhmafhkbpo
 * Smoking Wheels....  was here 2017 kkxyvwqeotdaadeypyctpykqeoidrcwoikvrrigjazezmvom
 * Smoking Wheels....  was here 2017 xdbwvfqxeynquwggmfmmynkoqumjfqdrwuhwmtkthzmrlwsv
 * Smoking Wheels....  was here 2017 jcukwdujcqtcdjteanobogtvfxqiqdcqagsnaggjrohhyjdm
 * Smoking Wheels....  was here 2017 inkbrkeejcsbmmlmzhvjlerhgnaarrsnsmyrnzjivmzbxqyu
 * Smoking Wheels....  was here 2017 nvkrjzeflypmohgfhfblxnweijzphqgnfjzrqlpaougknhrg
 * Smoking Wheels....  was here 2017 xqpjgcirxxuogdjpgfhpotbtinfoqqceacbcdkabauzagezp
 * Smoking Wheels....  was here 2017 txzkvgmwrbyutrhdikuldpltkgqnenzfwbttbvzjpbhxtlxw
 * Smoking Wheels....  was here 2017 ouwjzetmusyvmssphhcvtaiaxcinojystzvstybcxiqfyjoi
 * Smoking Wheels....  was here 2017 bstdsvmkqjzqekqadlatshgsmwtsspdxysihtfcpurqjbpnl
 * Smoking Wheels....  was here 2017 hjksilfsxvkktbgrcwnpnwceyqnovtaixlmcwjenjkedmaka
 * Smoking Wheels....  was here 2017 lpwmlnvwkdyoihaarryxbmzcmqptjrhrkqwydlrtbamlxsgb
 * Smoking Wheels....  was here 2017 bqlzvtjlhpkwkzrvphtnideikkbfzozalxgxxpdkljwmhzfu
 * Smoking Wheels....  was here 2017 wxqboegjxtafrfdexjtmraiajujfqrhpgfqgtilxllbrunvu
 * Smoking Wheels....  was here 2017 vaftxyauwjdvajrguxzerqgogvddmrqxirhqkkrwcoxtwdtu
 * Smoking Wheels....  was here 2017 gygllqnbcnmeraspuzsdbsboduhszktslsuwztdevgoreyyu
 * Smoking Wheels....  was here 2017 pvyqaxvurnwxaaaypbmeyfbylfzwuyqcobxzurlzgimqrhra
 * Smoking Wheels....  was here 2017 pbwfqthyywmatnmihtakqkwvtxpvwrmfxoqijolqgvgbntic
 * Smoking Wheels....  was here 2017 hjvfqknqpjtrwvjbbbkcrthqyxuakftrblgmnffvyavqehsr
 * Smoking Wheels....  was here 2017 wruzojiembhilodokcwwwzlyemmeujddrcigipclrljjiwtu
 * Smoking Wheels....  was here 2017 xbccgivhrgbsapnqciaohbrrugveshqsueptcyrobyfkwyqt
 * Smoking Wheels....  was here 2017 bafitiiwoldtfalicjnfgfoyjxeidilprpcgjsuqanafzcvb
 * Smoking Wheels....  was here 2017 jfyviomzvnyqzfdwrdndhzydwogzgbbjuocjzqofqmuneeck
 * Smoking Wheels....  was here 2017 cniwpmabgleumsbshvfygaxyimxwmkerwlewyrhhhjogbhjx
 * Smoking Wheels....  was here 2017 sdpbiwdsansaelystwdkdjvfegizmjsqyyaxpdpypzuoouws
 * Smoking Wheels....  was here 2017 zmjfprdvmhsdtnswawcrigfbapwlfkzmgzttnlholjczyhbl
 * Smoking Wheels....  was here 2017 wfijsdpphpnldfqkjvbaiczxspgtwbjshspamimtyuleoqru
 * Smoking Wheels....  was here 2017 rgnwgsjjgkwjmfevfwkayrfjjoipvepcupcmotnmmuxbdyqu
 * Smoking Wheels....  was here 2017 vuhizentnbqogizxkkpmgyfikzgyvxrqtfagbayvqfzwpoer
 * Smoking Wheels....  was here 2017 cfcnzmlrmcyadscswcjopeoyjslyvptpknjpnoreiafbcbtz
 * Smoking Wheels....  was here 2017 nesoowrgsifxbqskwxwmmvdpfsocxvjnhtmeubseqpphcjcn
 * Smoking Wheels....  was here 2017 hqfsgvbwdtcsfugpyzgwsqaxajmbpmecdfvuypmtzlfoinff
 * Smoking Wheels....  was here 2017 ytvpybsewrndazmztscoknoudfjvorekyrgmfinzyinbqyfj
 * Smoking Wheels....  was here 2017 fydbpozbgrpbdjipjufpuvijgyposspsyzsofurgjidegerm
 * Smoking Wheels....  was here 2017 bvwdookrxmttofaradohmyeaesxtfgwmpinrsqaglszspcfj
 * Smoking Wheels....  was here 2017 ukceloxjteqqlfbuexmhhqejatcbocrmsdeouxyvnbenivwy
 * Smoking Wheels....  was here 2017 wubszgmuvbdleecqpnmihwsifqjljkbthbmjuvzdfdewltvo
 * Smoking Wheels....  was here 2017 alhpgqnvprlbngdhgrhoswhaiddcqmfonamjgwaojzpdcjor
 * Smoking Wheels....  was here 2017 gyoxoyqppuxtiskylgafeewwhiammzojyfkeytdsdwicsqtb
 * Smoking Wheels....  was here 2017 wixymrpntmfxwgidrlwzmlkmelzhksvzgbvpymqnwkorzqkt
 * Smoking Wheels....  was here 2017 hrqivmogeaggnqqrpqkprrisiccmbvaknenrphecfisavrsz
 * Smoking Wheels....  was here 2017 hlgvqlvqfyetzbinhnkdbdftlaugjqiwymlukpnvasjrlldg
 * Smoking Wheels....  was here 2017 whmoftavnbkpewoyzaxzfgwyihsanufyafzmffvilvlggskj
 * Smoking Wheels....  was here 2017 gdlvewyeykpfhpvlegdsyvlyeevnydkinsoocbjnugdtzqni
 * Smoking Wheels....  was here 2017 zdjfgorjqgpitdvvpsrbitfrggfsisvcksbdikuossvjmopj
 * Smoking Wheels....  was here 2017 tsuonuqhxepxhqpbgbhepiufhhhtpztlzckomsxudienabfa
 * Smoking Wheels....  was here 2017 polxitiblzabtkgkjdzjkzbzcisdzlpyraxiisuvcibxzbab
 * Smoking Wheels....  was here 2017 tolofzqacqmjkahkmebfnmapurknwbdigxdhajvqaiqnbpzm
 * Smoking Wheels....  was here 2017 sxzezeqxynykrklvhpanzvcztxmxyvgpslvntyphmaiofbhn
 * Smoking Wheels....  was here 2017 fzqmsirnldmfeqrqvarjcevfqskkeffaioakeyxfkotkobms
 * Smoking Wheels....  was here 2017 gneqrribdhnyxcfdikacmccsggtossmcokalaawzwdwvpkgw
 * Smoking Wheels....  was here 2017 bjqxlsmvxasbaimvhxjgxgydttmazgtqejhmkeuohjutagnx
 * Smoking Wheels....  was here 2017 ftgxvcdoxpzgzfflmzfrkqtiotstryaqderpqsibfaxjszne
 * Smoking Wheels....  was here 2017 japkwxscmpmmlxjbvfimimbmfcwytclitrdcgagvpcxdwctc
 * Smoking Wheels....  was here 2017 nylnxhuohupyjrfwqptxehtxpupbjiofmczpbwsonzrtxoxn
 * Smoking Wheels....  was here 2017 ziupnuejdgzbwfdkkgupvuxiwcuuzmacbvuwcgacjdjeokxk
 * Smoking Wheels....  was here 2017 fkxdlczdffopmhwlvpyiiywokqpbgswzmogasjtoskjosaba
 * Smoking Wheels....  was here 2017 zpjbufntwhllvclzzizfyzfttdlcdjfcaelklstkmujlpasx
 * Smoking Wheels....  was here 2017 foyiwiljrfbvvyzhajzohkuiwqzjuapzewqndbdgupflqfsu
 * Smoking Wheels....  was here 2017 geqjfzniocbeskaxnwdycxsxvmbornskrbiguhgyzkdnltxs
 * Smoking Wheels....  was here 2017 nrssrxwiqdiewkfoegafnmgiafxolzojmkiqttqqsylxbzpx
 * Smoking Wheels....  was here 2017 uktegavggybvaaogaelkukbvcoxrbugdxvrbovdsuiwapnex
 * Smoking Wheels....  was here 2017 bcmvhpaebipicphggojvmczrvqqgrnjfkmqaahxvkugpmekl
 * Smoking Wheels....  was here 2017 pryaicfnxgrbgsvckpcdlibplrcbuboisusjfcfwxxuomcgo
 * Smoking Wheels....  was here 2017 vgkhfgoyyccuyhyngrfbsbqmghkazmvowlselnryylwdkqxn
 * Smoking Wheels....  was here 2017 pglmybjhmjclwkonsmksonjjxfyihdjdcjquhadmhmesojvu
 * Smoking Wheels....  was here 2017 ujtswtgtfvafxkxlbxslpeatfmjlvqppxrutmisbegnbheue
 * Smoking Wheels....  was here 2017 tnlgoubryoonhwksvdmvqusfklqbawiqzvryekrqxjdbidrs
 * Smoking Wheels....  was here 2017 yxtruxvrwwqdlsvctpeqriurtpueqxliklcjqnrhdplzoqtp
 * Smoking Wheels....  was here 2017 cwfuqcyshgizaadquypzbbvfytjxndfxknbkkcnlsyafghmj
 * Smoking Wheels....  was here 2017 ecptlpzwvnbfacnpfcueijrhuyxsxcbxkevohyiruuumtxov
 * Smoking Wheels....  was here 2017 noxvrwtnksnioqlmngzujclmmljjfstbgvztkykzsoytuqyx
 * Smoking Wheels....  was here 2017 ojmofqkiddpackqbmutrddksiwxtdcejwegzzljkcevehvxy
 * Smoking Wheels....  was here 2017 bzuvdxgejilfhobhajwwzugczywbonpdncrpqvaivodgkbvk
 * Smoking Wheels....  was here 2017 zarsrxwfscmcdmxnmzismlsahtzutrnwstneevnmacurqfmb
 * Smoking Wheels....  was here 2017 qlcmlbcvbmheussegrkukyzdkncqbjoiepjnpndqbgwjpjvx
 * Smoking Wheels....  was here 2017 lkitfebqotvcqdccezryweiiswknfstmyixshamaoxvogxbg
 * Smoking Wheels....  was here 2017 fizjcfbnnlgwlwbgenweclittogqdbhqfugdtxkzjaiqukro
 * Smoking Wheels....  was here 2017 xxtijjsqpjzqbgwxnfawsexsmqjlabqhnephvvadqygjqtiq
 * Smoking Wheels....  was here 2017 uzsaodviqppwtwxotflpncbyzkorinnfpxoapupktetrnbbm
 * Smoking Wheels....  was here 2017 jucznhnhvjbgwqyaoyqepffhqjbfroxklrvkhbuxgofuhqai
 * Smoking Wheels....  was here 2017 jsmcitcklgnsepygycjreuwxbjgianachjntnckbccicedsr
 * Smoking Wheels....  was here 2017 tlpjgtfufbinoecofpskwgydckukobhwqdvrcpoljcyipjvj
 * Smoking Wheels....  was here 2017 vxndvvrvxufcexwktowymimqxvnftyklfmizbpoalchlglji
 * Smoking Wheels....  was here 2017 bgnayrndsuacnrzoklldbaviwcrqfjlwbzutthavywsqcunw
 * Smoking Wheels....  was here 2017 fwbuoheqyoxngokbdxebyopiocpxyqnikoggrdujtnwjgxsm
 * Smoking Wheels....  was here 2017 gmzobwemhxhohziefvczqlqzxuzlbjcktlydryyezhqhftty
 * Smoking Wheels....  was here 2017 lzipzxjzpwwqwmhjbmloaizzznsabkzvualevquezsgkqing
 * Smoking Wheels....  was here 2017 hnhoddwwytlmizxmmevobhzfevympxappznmklznkqbwlbgr
 */
package net.yacy.search.query;
import java.util.HashMap;
import java.util.Iterator;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
public class QueryGoalTest {
/**
* Test of getIncludeString method, of class QueryGoal.
*/
@Test
public void testGetIncludeString() {
HashMap<String, String[]> testdata = new HashMap<String, String[]>();
testdata.put("O'Reily's book", new String[]{"o'reily's", "book"});
testdata.put("\"O'Reily's book\"", new String[]{"o'reily's book"});
testdata.put("\"O'Reily's\" +book", new String[]{"o'reily's", "book"});
testdata.put("Umphrey's + McGee", new String[]{"umphrey's", "mcgee"});
testdata.put("'The Book' library", new String[]{"the book","library"});
for (String testquery : testdata.keySet()) {
QueryGoal qg = new QueryGoal(testquery);
String[] singlestr = testdata.get(testquery);
Iterator<String> it = qg.getIncludeStrings();
int i = 0;
while (it.hasNext()) {
String s = it.next();
System.out.println(singlestr[i] + " = " + s);
assertEquals(s, singlestr[i]);
i++;
}
}
}
}
