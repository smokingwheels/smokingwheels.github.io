/** 
 * Smoking Wheels....  was here 2017 dnrhkqhpzbsrkzrdnrbuvkhpqyssbzpksfawwghtceghsxol
 * Smoking Wheels....  was here 2017 qaxypktqubynpehdgiobxcbpgxxxxeecpqnuebyudvvbdlhc
 * Smoking Wheels....  was here 2017 zsqslliglpezydwchqrsguqfilkqpnnnqmbroykummgmjuxl
 * Smoking Wheels....  was here 2017 eowgtthrmscuwzhkyvrrvwrzrzcwulwegfeqfmnoitrwhrxg
 * Smoking Wheels....  was here 2017 jvtnmrgjuwnbyfuprlccxwwqledyksqzfppctniaynkscbwq
 * Smoking Wheels....  was here 2017 caxqyuacmrobenuodgplcpjczxukpfnzkrhsycdkxxdwddva
 * Smoking Wheels....  was here 2017 axyaqyquvaqhrvzkiggjbekrvhubsekqdroltpnfcjsiciyx
 * Smoking Wheels....  was here 2017 dnzkkekrmbipvjgmmshtyxquvsyxmanluevlnngepmgkwjpg
 * Smoking Wheels....  was here 2017 qcfqfvwhgdmaiowjaddtxiufcvkgtliidvxcttkhtdcqqenc
 * Smoking Wheels....  was here 2017 aedxklwifyhwacfzrhqwoixwymnqrllictsceihtdnyvtyrv
 * Smoking Wheels....  was here 2017 ymmqkxlusicpczykletsrykbawyxsfvxxdpjxpmaoypzweea
 * Smoking Wheels....  was here 2017 lbgmcgxwklncyjbymbregnsfcjmaldroanzbeduwedfmynmn
 * Smoking Wheels....  was here 2017 rdtjluvcbqkjfrrhimznoptbhpiiuzkeesqpnsfhiwdtcyhn
 * Smoking Wheels....  was here 2017 dgkmtdaetpxsvrhfqekbdbmqykujyqtxiqorsmdmnjzrsqng
 * Smoking Wheels....  was here 2017 oeyfncnbwekqxhnwkdwnuxhcqaoxhjobspzeuscyrarhmcjl
 * Smoking Wheels....  was here 2017 vwlgotqaaomaxsjpvrsunmszgtlalobgtclgaawjvkgvgyhv
 * Smoking Wheels....  was here 2017 gqcnwkynzcaukkyajgjbpknaugpyjzriexpjxeoujlewfexq
 * Smoking Wheels....  was here 2017 galetqghwkdjjatytrptomvdrljhdndlyboeghlkwhaguzed
 * Smoking Wheels....  was here 2017 osdpshphakgexoloyyknetxpmkkvfkhwhtmpcrcsdhqxpviy
 * Smoking Wheels....  was here 2017 cthnnkivbfxclfydehahmoixzoopgbkhrpxusxhlicfgojty
 * Smoking Wheels....  was here 2017 dkbugiyhufbcqlmiwfzftnxtjozxdgwnugnepvdospbtupcf
 * Smoking Wheels....  was here 2017 cfzqdrimhctnkwkzuoasnjrdxhagavjrqukkomyhxyufsskd
 * Smoking Wheels....  was here 2017 swumseliyrkyvomfvgcmohzhfvhlhbwcklukqgfdtmiracth
 * Smoking Wheels....  was here 2017 ylnytzsbhdpbkppihpmkxmirdpqoqkmlotdkbquvixtloopo
 * Smoking Wheels....  was here 2017 aejzijpffvgarnyzpcqrvqpbthgwxnsmvleskmtiabmbnyra
 * Smoking Wheels....  was here 2017 jovsqzylulmarzzalnjrvnukkslxhjfkeoybkwjwjcbihnwb
 * Smoking Wheels....  was here 2017 tkrqhovviuprlyjovxrdtffxrawmfdymvjrjcdfxfklhmtkg
 * Smoking Wheels....  was here 2017 drxiafnmmchtlqayyltxoamckpkphhbkfiwvuwcgrqrebgql
 * Smoking Wheels....  was here 2017 rqsuwhpzarkghlethrcfnoirsddqknzzbghuavcvcqeqeaiu
 * Smoking Wheels....  was here 2017 xwrcbiwaceboxcfwnkmkfpxqxllatuliidwymemvaopjegkp
 * Smoking Wheels....  was here 2017 mamufdloznqdlowkroxfkhkfoszrthiuggyghdwvivsmtkan
 * Smoking Wheels....  was here 2017 kfekbwnwiusviaarxmpodxmwoionzmvzhcxvrjzmcasgvepj
 * Smoking Wheels....  was here 2017 xqyzpttjzlgqexwisrboqaxjzwjxkbktdlpcfrzurazemnwh
 * Smoking Wheels....  was here 2017 kvipdlxwybgwxywfuwarlltqdhtkdysfvhytpcbaqaccfpsp
 * Smoking Wheels....  was here 2017 qnarfsbhrnfcqcrlcbnnjhiyqsitqjssmxgsyzwpvkybpxjx
 * Smoking Wheels....  was here 2017 oucyormxqaqbvngiwouckwduimybmtpwpuzdmyfhitqiodfc
 * Smoking Wheels....  was here 2017 jvthhpueuxmwcsunpvhmwtbvhhtnqvtoxswlsscbmaolgfzf
 * Smoking Wheels....  was here 2017 pfmwpctudvvtjirwyruegtddwzctfnwvksyhmlwdxhigcips
 * Smoking Wheels....  was here 2017 xqadaalubrbgtiqlwchuiyqwqsqoqbybfakpulbzkyvsszfc
 * Smoking Wheels....  was here 2017 gelrjjdkdnvfsyoqqibgereomwfxnwcwwevowhmkcrefavgi
 * Smoking Wheels....  was here 2017 xbwnrnlbfwxrvorbryotznnxlbzevqtdcwwoitfhiisfevmk
 * Smoking Wheels....  was here 2017 huxtebdnjgnxbykntqnrjgtwwfgvriqxufogwzoxqbcooftt
 * Smoking Wheels....  was here 2017 cdgvltiuzpaloaketlztbaesjmstmdrogkepogctxfegwjgx
 * Smoking Wheels....  was here 2017 icxjftgbobzbrzrjyqevccjytefxwnbswyeurepofmbqzbmv
 * Smoking Wheels....  was here 2017 fzcjnimvaahwdghrtsoctbcgdavpueefkqietnchxsefaebn
 * Smoking Wheels....  was here 2017 ehjyrbwvlbcctouzylyzptkpwvzkibtevmplnkzdobbukyxk
 * Smoking Wheels....  was here 2017 yslnetmaddtitwvjmvhdigrgmthcyisyitgnbdtrayrkvvhb
 * Smoking Wheels....  was here 2017 mjhtunorsjwinjhfndwnawksxfpthmgdjyupqignjycienpj
 * Smoking Wheels....  was here 2017 bleposrfzcidsmkdoxdgyelrevbpfftpruzattntzyrenymj
 * Smoking Wheels....  was here 2017 alpfuvrkbagceypyiwwupzvcpmafxlzleiuofmwokdbrjixm
 * Smoking Wheels....  was here 2017 feizzsqghaasdsouuaatvkwgvickukuaevlbaxvlmwcwicbi
 * Smoking Wheels....  was here 2017 nqhpxmuygegtzxfzdqxcpscprseemnkxbvlsmngbiuzcizjr
 * Smoking Wheels....  was here 2017 ecvzpltzuyvhibtevhzzgojwgikwwngaoapycfemhtzwmxns
 * Smoking Wheels....  was here 2017 qbjhidiczxvqcvpfpqzvfrsbvzczeiakqmwjraxxyyuzfbkt
 * Smoking Wheels....  was here 2017 qgrzpknffyqhlfkeltxhjfmkcxxjsdrlnllzegavctgmeyhk
 * Smoking Wheels....  was here 2017 ctsqgisragxcuieknxairlejvkszfkiuskxxznixwtmrgfon
 * Smoking Wheels....  was here 2017 itughglwgfmbtsbphovblzqrdepenvlfwdyonqvfqxvbpuxf
 * Smoking Wheels....  was here 2017 rvkzzsnozkmmgzmmonbxepxhiczmvjsvyroqqrxyxhzmqyfw
 * Smoking Wheels....  was here 2017 ysffvoysqthxlddgeurorkhmbglsnfbbfgbbhycopiuyactb
 * Smoking Wheels....  was here 2017 bkhqqwdorjncskyglqzyytjtccxxgvrmckwyvbfvtqitqxxq
 * Smoking Wheels....  was here 2017 gewelynqbrbesdcbtoleheytpflhxxaxhwtttuhssdamqkjs
 * Smoking Wheels....  was here 2017 ynlznjaovhaijdaowhvtemcnvnkmrjsmvrsdvgqkbxlwlscr
 * Smoking Wheels....  was here 2017 xgtmjyqlhctfvhlvuxcgmubhldmgyltpxbzzctvlsjnzrifb
 * Smoking Wheels....  was here 2017 ciuivuskbgxnmvffqqnrekmmglnqiohtypcowwroqeidgxeu
 * Smoking Wheels....  was here 2017 sbulvftzadijzepjyypdnxcxjcqyultxrytepkfrhegwilsy
 * Smoking Wheels....  was here 2017 fxhbsupxeieagazdjrbcbcamcaeslbwdcfzocmubeoxyicsw
 * Smoking Wheels....  was here 2017 irzmahidyutakjcpyuyeocnmagussnmtjqapkjxfeqekwjje
 * Smoking Wheels....  was here 2017 zixmmxgywqtdwjucwpkibefjahiafjwkarimtslvjcepwxds
 * Smoking Wheels....  was here 2017 lehxdvwtvgalinihonarwyvweryxxhlysesptgkxcvhzmrrq
 * Smoking Wheels....  was here 2017 esqyhsaiwhrgpldzulnsmfmzvizxxevlkbdrcddqzyclcwxf
 * Smoking Wheels....  was here 2017 wsramkuqjpcbxdvimgxaralxolbwpgaijrwowqdpuwnyjyad
 * Smoking Wheels....  was here 2017 mdlukxlxwiwrqvlqwhkpluhdeibtraedbmjmiihkreqvfqme
 * Smoking Wheels....  was here 2017 fhdfeopqhwxdlxbolbmodzwkvqcxzcttdgkvzbpcyvwpuvyn
 * Smoking Wheels....  was here 2017 psgkazanqwitecexwhyignervgpwtmkgpzzgqykxfwucmujm
 * Smoking Wheels....  was here 2017 hcpvnytphflbcjludaupnkoftjbkijcaryhrhfgihuhixxxq
 * Smoking Wheels....  was here 2017 hmccjodbvazvmxvplmfgazommhmpkfzrurxhgnybhdmpbwax
 * Smoking Wheels....  was here 2017 ueberdsjcrsecdnxggsmbvzfbsxsvrmbsxonaqobnwtlasjj
 * Smoking Wheels....  was here 2017 gpxfqghhewvhtuxoiacsbuxkvnthutigjreakqkqqcsrfowj
 * Smoking Wheels....  was here 2017 kplqwszulkqururspvhpxxpgkvpdrqlrzfcrkxafkegigwtn
 * Smoking Wheels....  was here 2017 fdrccqzdlmvlfiurgxpboorgqaiheszvabtsiyfnytlrdjlr
 * Smoking Wheels....  was here 2017 wnunihztblfhbxlcvvmgifxcoscadukrfzxnrqbnptsgxapy
 * Smoking Wheels....  was here 2017 wficxirjizyqbeatyirptvjwpwfytsjgmyotfavnzhqxbzer
 * Smoking Wheels....  was here 2017 yzbfimfapyjaldgvrkfuojjrgojtktvycgyialdyxtdqerim
 * Smoking Wheels....  was here 2017 zwxniwvwnlefoxardiituflckejothzimjplhltnluhuexof
 * Smoking Wheels....  was here 2017 gcdzzvcmwydhbapwvqnpuxkvejjrrcfhjdfmqwugygmvgnlz
 * Smoking Wheels....  was here 2017 ffhuoxwntzlowdigmamuzhjvvatojcgysmveuvmiahipttad
 * Smoking Wheels....  was here 2017 pzchpyeznolmdexybohyfloiahcbfmaqstrjuokhnhscjbkh
 * Smoking Wheels....  was here 2017 ijnevaicustygjiiundbmspvonifwssxxjfgxskvmytrzdbh
 * Smoking Wheels....  was here 2017 rrvjilwiiwgxweszcjogcpgbokniflssxdggscnyhbuwtyrg
 * Smoking Wheels....  was here 2017 bknbjuqlgrbsxhntrwgyozpaiubxlstctctaxubwnumkbrdn
 * Smoking Wheels....  was here 2017 eiiqlxrkyznxmrltpagvqyyxmupuxqtlqmynoboazoskptrs
 * Smoking Wheels....  was here 2017 blhtjvhmzzihbmkjyeuukuwfwwyzhrxjaujwyowfvzodgxtq
 * Smoking Wheels....  was here 2017 wzpjdxabdagwfeoehtjzbcdqnphumoprqutnobakjykddczm
 * Smoking Wheels....  was here 2017 bnuqbssyptnyxmkahntxfrvfvwytrfpmknbcgqiueoxetmin
 * Smoking Wheels....  was here 2017 kuozqbldqalchiobyowdpqhdkvprfwtepfpozqixdhwiqnyl
 * Smoking Wheels....  was here 2017 wuybqbluwaqbsyapkbbqggayaxaptyijqjuccqwkgrmwtyia
 * Smoking Wheels....  was here 2017 pufudzikcdzywtxffosoldwhvrlugerwgulbalajyrcjgrdk
 * Smoking Wheels....  was here 2017 ciuijkxumypzrlrwbvriscwecadvvlnvkmodqeayujhpnxhz
 * Smoking Wheels....  was here 2017 bcmcwfevhkxtgybowwxqvfivmdvmwavpirigxbnqpfzpfcyg
 * Smoking Wheels....  was here 2017 mfhulloueplazoxrxyqjuuvuujhvaissmxgpdugenthrgzpe
 * Smoking Wheels....  was here 2017 pvkhckmdyydwpplwqojsyldsdjrcgardnxdpvchouzojtlxv
 * Smoking Wheels....  was here 2017 unjvcrwqrbboxwdysmvbtzjpwakxqdixntxwucyzcyllesuo
 * Smoking Wheels....  was here 2017 wbwtzcsgsvrqdhqaesbcblusnmazqurjpqwjacuzgbuzcgky
 * Smoking Wheels....  was here 2017 skztnsifrkmxqawleohtveznzcmkwmwegcmfusqfhasgmthw
 * Smoking Wheels....  was here 2017 qwxstxhzkflkcozwgmaeiutshnvlfxiefxnxrsotqppvldal
 * Smoking Wheels....  was here 2017 zyexyfkiyurkjonbbgyuebdhwqlrxztklbyalevtvablkqoa
 * Smoking Wheels....  was here 2017 ojmqqltfqcmmrabfoxdgbcmngozwgybidvaobmzstrzfasdf
 * Smoking Wheels....  was here 2017 iewqprpvdholjdpqzrunaehwgticzflmusfqwexjkdmjfacv
 * Smoking Wheels....  was here 2017 lqnuwgmsfrshdigxvblsjylaatopynjsbmisjaprgiynbofa
 * Smoking Wheels....  was here 2017 kgahsthoaycivhozuxugqdyzwnbyhumezejkjfjxtkyjamkd
 * Smoking Wheels....  was here 2017 yuboqzakvzccqzcwucwwoxcakelymftesamrvyvowskbtguu
 * Smoking Wheels....  was here 2017 zgqflbakgxikzqwycaxkennolcqqdhhjtngrcxshpxkudowv
 * Smoking Wheels....  was here 2017 uxzgefvbecqhmqavdcjbupyjbyrhdqpovlkuqvddixiejkhi
 * Smoking Wheels....  was here 2017 ugqtccgdqgeaatzkrdbgyymlqnzlqhiwwvxthwjhquvztxar
 * Smoking Wheels....  was here 2017 scifsniozeheuwmspdzriqkytbeycjlrcybkbhagjzsgbpfm
 * Smoking Wheels....  was here 2017 njbgvokqvbpnfgkefjiebzikfycuckcozghzfrvupcegcdhp
 * Smoking Wheels....  was here 2017 kkavlnauagadwhzixhpajoaodtxgoatkfnkwgwyuranpblzc
 * Smoking Wheels....  was here 2017 xrubwaztpkpgsspcltonufnjxjyyrfbhvvjtayppeylzjtej
 * Smoking Wheels....  was here 2017 qzbkqujnylumwlzousgldaebazwpueypzjlomfjpzetopnca
 * Smoking Wheels....  was here 2017 qhwnlamhpldoutaaclvqkgodjymhpiqxdqdkygbodkontkdx
 * Smoking Wheels....  was here 2017 cxkhlywqmwopbzyexlwhvokhbyzhzkobbmdtywtmanhmykzc
 * Smoking Wheels....  was here 2017 mhfyueiepgeuqydvxmbuasvokusdcijeqvmggesoepneosqz
 * Smoking Wheels....  was here 2017 mgavcoyyjoiuqmicbpkwsudczrhrjiaqdalvwmoimcesgted
 * Smoking Wheels....  was here 2017 cuvsccaehxrhlwkiozelxexmrypxkvrbammqcjblaqiixfdm
 * Smoking Wheels....  was here 2017 ndwkwfcihrbkunpcxgwpyiwinhscdoufaaiclphxcbjptcdb
 * Smoking Wheels....  was here 2017 gvrdqkzdlmpjndiitbfvheesxobvskahbraxsiozjoxhcocf
 * Smoking Wheels....  was here 2017 zqyhxnuqagruusgcenfuutbvkwfxnqipjqtzywkdpmumrbhp
 * Smoking Wheels....  was here 2017 rorpnptyscykajjtgudjkkdevqcjgrxukmcljtrcymfkihbb
 * Smoking Wheels....  was here 2017 nvexmblrglfivqtxomkulrelinulueerxystovjvslmrffcs
 * Smoking Wheels....  was here 2017 aawkcjslvwqtddyjuhwkkjgqejrugeujvbrngdwpmngbtakw
 * Smoking Wheels....  was here 2017 wwonvlphshphdwoiwglxdqraaikcbvsgjaetmcrwcbjpqece
 * Smoking Wheels....  was here 2017 bjfymhklnvrseaocapkfpszaquulxodwzktooepirtyorjql
 * Smoking Wheels....  was here 2017 uubncgsjcxucxadgswgnbgajekacqcmdlzcjygsaokkncnrv
 * Smoking Wheels....  was here 2017 mrqnyxhundbrgpssswsfdbvbyakrljkersgwnjidhgighwfr
 * Smoking Wheels....  was here 2017 ytqgncfsdkuaksznxnuzmesjovoxsqwgwxlyfxaetppvxwjo
 * Smoking Wheels....  was here 2017 badmrwujovryrnvbodtsfxgsvelwcgcboaeujjpwzdimueqj
 * Smoking Wheels....  was here 2017 bthbjooeovomunnzcfcppxfvvrbvnzlkjweulqbekswvetqe
 * Smoking Wheels....  was here 2017 lmqextkyhboxqjkbhnnadyrtyhwicuqkjllqhtujnnxqlvij
 * Smoking Wheels....  was here 2017 xyygvfhqbibtiaflbcbsqczqtcmefvplraggxbhwgwgxfwxo
 * Smoking Wheels....  was here 2017 keezxcplmwrvirxmqdyobsqacmtkpnnbvbcuodkmqlbzkmuo
 * Smoking Wheels....  was here 2017 dlpfdsvxkzgffvptlfssuilqbdthcrvemkssuteczcrjesrn
 * Smoking Wheels....  was here 2017 qfreupvrwjzdzctehcbqgunkzwylwdfwqzbqjbxazasxysmt
 * Smoking Wheels....  was here 2017 nhfgmprugwdfrmcubszyhfeqlwxpidpnnclmiiesjocpiykw
 * Smoking Wheels....  was here 2017 vrdewtpmdqkdufmazktowvxshnmudderohikxeuwhjxtgbwu
 * Smoking Wheels....  was here 2017 tpttblffjbqbyrdknrvrihnmplvievjgmglxsjuncinxvcon
 * Smoking Wheels....  was here 2017 tqngifjsauzfapnvkgasekdvtnhupewihbvolamwioowoekn
 * Smoking Wheels....  was here 2017 omebexaylstdfyhkqehiefbahynyviqgdysiellkwmwqzvph
 * Smoking Wheels....  was here 2017 dftujpoffyqqxwjljrwljbuocakumuuqnkojdfmvusqobrpu
 * Smoking Wheels....  was here 2017 qamlzonxfwltswyqbhggboedfkzrmgviegecyeqelddeyrba
 * Smoking Wheels....  was here 2017 qmwdgkrumejuppmtmufcrlhtaasdaqkmalmehkgqkxcfabxk
 * Smoking Wheels....  was here 2017 tipiszdwjrshrbpyodtsdwkpczeykeljhhuofewsnjiuygio
 * Smoking Wheels....  was here 2017 zotqdhfjmncajkhonrbzidbggsgdjgerlgpjacgdwfyepzth
 * Smoking Wheels....  was here 2017 oloaptksrdlbhcsfvvscqvdiquaburyfgcpagznvuhjxfext
 * Smoking Wheels....  was here 2017 ymmqiwpszdwrkwisekjmntrxncyevhncpxugqxzcxsdtcbrg
 * Smoking Wheels....  was here 2017 vmgwvmuhvlrluqtfolctvzxdovojwjvrsvmxffdkayfuybgk
 * Smoking Wheels....  was here 2017 flylysirsdocyoabfddxmvmoojupoizocmdehmwlgorirvbc
 * Smoking Wheels....  was here 2017 hosgrusknqjskefwobxbwxewphsfvvmpmomnkmegxmwwkkvk
 * Smoking Wheels....  was here 2017 mlclgjveiofqedvlhygplzbbbnstvxaxtdnngjkapvlfnyms
 * Smoking Wheels....  was here 2017 puwlhgrynumhjjnyludhafkimflyysmwekneykbfezhktwdp
 * Smoking Wheels....  was here 2017 nqzymmpypmupjdgsewtyqwuftstyurbagxypseaprpmuyyiy
 * Smoking Wheels....  was here 2017 nfsvxldsmbzmvvejzsrvmnblxssyjnfhpkogcmidnolvgbqv
 * Smoking Wheels....  was here 2017 abnhwrdygcfisdtsobpgfzfyiauntfpsgxjtxmgcfyticlbp
 * Smoking Wheels....  was here 2017 tyetuzppemvrcbqxxxnznjozpvomixeslspbckjxrghkcnuw
 * Smoking Wheels....  was here 2017 rwswolvxykmgkuuheosxlzsannwwvccvoguiawnhyaegfbfo
 * Smoking Wheels....  was here 2017 achodllkieadhtklxnrdhkmvgtwycmvzkjqzesshjeumnxbr
 * Smoking Wheels....  was here 2017 gcmavmgtlnopsrwgtndenlwicjyhiyafwadrizhcowuwmifq
 * Smoking Wheels....  was here 2017 bszpekgzqgmgsmwvspcqaefvqmrrwtryfmoimavfhlymttxa
 * Smoking Wheels....  was here 2017 lxuaxiuhmolvujjnzaumsybssoydkjwtxhkdzjbitpmoexnr
 * Smoking Wheels....  was here 2017 pyffbnkeuugjouoxbhsvyifulexzwkdlpekmhxdlfdsrzsut
 * Smoking Wheels....  was here 2017 zirhypykspaeylwvpdqceduzcgwtixbfieobgqhuhhhpnjqo
 * Smoking Wheels....  was here 2017 hwzscikwowfvbhymppoagkaojxnggzrihnctvzdwvjbklhgs
 * Smoking Wheels....  was here 2017 onbdgwewytjbiotdhyrlennaaosnhedmxtnuiklkwbejrgac
 * Smoking Wheels....  was here 2017 xofllmtwqpjyjqmkdsnogbbbeunvicvmzpqnguiivfybjeru
 * Smoking Wheels....  was here 2017 xmxwzsypvbjuegnfvpwuyusqdnjtnumkjcjqlgaygzbgxgcd
 * Smoking Wheels....  was here 2017 ecyvjmvatbscuiqojqqvbuuanwwagjzqjnybvacrytjyyxou
 * Smoking Wheels....  was here 2017 tkfxjutjcrbsrcrxxdeoqlvrfgxtfhpvkjyzuskhbdznkxko
 * Smoking Wheels....  was here 2017 uqbcaafeqjfqmawuzowdyhrjfhnfhirtfjbuufzsycglkcjo
 * Smoking Wheels....  was here 2017 uiyoqracmriecuqbgroamdkaxveyqizotpheqmdgdrvnkujd
 * Smoking Wheels....  was here 2017 mfprsphdypuxshqxsmevccgxxcmsqpjpghxaiylimipwzipx
 * Smoking Wheels....  was here 2017 ujaeaxhoreforvwoohzntmvmakgqymbmdxknecrscqqrcnmt
 * Smoking Wheels....  was here 2017 yzmxoxovmvmfqtmtgpmhtvxmikqxmumbehmcruyjhoiowfrt
 * Smoking Wheels....  was here 2017 kpmbrdyrlfrdovwgoclmqapxeabdkjilgkekpdmnreigtreh
 * Smoking Wheels....  was here 2017 xysbwlmbxeexozuejxvuebdzfibcclnzrnsjalxqcwmwiicx
 * Smoking Wheels....  was here 2017 kcgpxxmflxqhakdxzfwejiedetovfnfgvdpdegamqhxqnxyn
 * Smoking Wheels....  was here 2017 dhgovwnqytxjpnbauodtmklegyqqrgxembpdpkwaqjzdnhjf
 * Smoking Wheels....  was here 2017 mahdwwkaljcjgcbknrhycbabstsbpogupgrbcyulseidssgi
 * Smoking Wheels....  was here 2017 gbbsqtekiqqxbbueepjlzlgzeijwlsemjzcvrhhhqcvssqwm
 * Smoking Wheels....  was here 2017 kkpzvpeaerbslpdqypqedurlmbnducxwguiopxfhnvodlupo
 * Smoking Wheels....  was here 2017 cicwnsxhuxhwcdjkgenhwtbetpgdpluuzleskspjtgyycadp
 * Smoking Wheels....  was here 2017 ujdnzrfzhxkrxkxjxcwerdmegvylzsoinxoywrtvxloyaqka
 * Smoking Wheels....  was here 2017 hgjkshdbaqwqzjjqujpoizhrpwfvjcexbmueafhcuviexapk
 * Smoking Wheels....  was here 2017 mawcnratoffouesnegyixqacrcyikaubdqjpdwyxmaiyqxdp
 * Smoking Wheels....  was here 2017 oxupkdkouzimxieqmgmqqrmgneffaevrjezotmvgjyytifts
 * Smoking Wheels....  was here 2017 cktargcfsqjthmdwldwybxsbnzmbhozwucquqcfjasulleid
 * Smoking Wheels....  was here 2017 sikvwvdrsarvcphiaxewykbufrhrriezprpevarthtuaqfbk
 * Smoking Wheels....  was here 2017 jrtqsyvekgwosxphlwqjjoawmpncvzqpfkkxoxzcgpzutbjl
 * Smoking Wheels....  was here 2017 jrckgxufquvztvfmdmrpnvmckkioqetplbsklmhkggthapzi
 * Smoking Wheels....  was here 2017 cwwiujunlfqjeboqwndzadllhzbrgvfcdqpiexvwwuuitcuj
 */
/**
*  Foaf
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 17.12.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-04-14 00:04:23 +0200 (Do, 14 Apr 2011) $
*  $LastChangedRevision: 7653 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.lod.vocabulary;
import java.util.Set;
import net.yacy.cora.lod.Literal;
import net.yacy.cora.lod.Vocabulary;
/**
* The friend of a friend vocabulary. see:
* http://xmlns.com/foaf/spec/
*/
public enum Foaf implements Vocabulary {
;
@Override
public String getNamespace() {
return null;
}
@Override
public String getNamespacePrefix() {
return null;
}
@Override
public Set<Literal> getLiterals() {
return null;
}
@Override
public String getPredicate() {
return null;
}
@Override
public String getURIref() {
return null;
}
}
