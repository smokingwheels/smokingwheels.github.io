/** 
 * Smoking Wheels....  was here 2017 zodzpabnfvksxrfboetpwkikpmsiuinzrwkzlikllxcrqqje
 * Smoking Wheels....  was here 2017 ytibvjxxwyyifqhxlybijxbffuumavkpknzqjwbzowosrsqz
 * Smoking Wheels....  was here 2017 hybflkrpkukhksopjcswyueuoxtgbvyfdhbbkuubozdzqxkg
 * Smoking Wheels....  was here 2017 jifvojsmyujzkhvgaeyvbpejymlkzzieuwadhwhdwcylxdzm
 * Smoking Wheels....  was here 2017 wjbnrultrmpefbfchuebkcujxhxwedwanfqxxdpxihfjbmbn
 * Smoking Wheels....  was here 2017 ssycnjpufsexgwdtixbqahajellyelfnrmtunwygyvoexjmi
 * Smoking Wheels....  was here 2017 zipsbefggnkibveyntpzcldkvfqbwiftzdqjpnvjzitqoljh
 * Smoking Wheels....  was here 2017 dlyrmlodwgwymjftntxrbbqocggzhjaahxqnwxzrzqxtjocx
 * Smoking Wheels....  was here 2017 vmeqgsbnhlimqcjlgqmnqxfhohkrvnzutsmhfzlvtuhsxwhz
 * Smoking Wheels....  was here 2017 ydskdsnxdzxyuxapwiyruaxgymijavtxvuccycksgdlzatuo
 * Smoking Wheels....  was here 2017 pkgdamxxcwvnqzuztahnupzkhdqnutdlcornnrkovffjvwtx
 * Smoking Wheels....  was here 2017 glseegmkfnttyqoppeqpafwvxudxdyiqmrqkonesywqupbnp
 * Smoking Wheels....  was here 2017 orhbbotrvkkivnkvgnlugpjahhwmlfraeerwdqrxlfamznsk
 * Smoking Wheels....  was here 2017 kwltjekajlwfpotewylektlpfsdlittlofshkhfbhnyyupgj
 * Smoking Wheels....  was here 2017 xxuhccnfsrmrxwekwrmetzjnsjoioxnyggygwaghujfxdyfu
 * Smoking Wheels....  was here 2017 nahbkogcujtfnwopyevisuqycwvwhjaufzvpfnnampwiikzg
 * Smoking Wheels....  was here 2017 vreqvcewzenmpcbaydwoawzgvacawzqnnizlkwbzdhflzfem
 * Smoking Wheels....  was here 2017 vouwanaysxwnlozfamgxqikdtwrzuxayrojdrhcattwtyqqo
 * Smoking Wheels....  was here 2017 ppxxzttzvpbnpiaapmzttjdnwtbhznbbfbfilhciroozgkot
 * Smoking Wheels....  was here 2017 pakcycqxipraauzkimgswnrpkgcqnmvgdnxvnqwiiojchjgq
 * Smoking Wheels....  was here 2017 lhmahcdxnmmsrpbsdgkprnutzewatqrzoydstjjspuqjrqjz
 * Smoking Wheels....  was here 2017 aaonvlbiwcpozqonctfpelmqiqqsfdhbwnvklsvjlpwfeqtv
 * Smoking Wheels....  was here 2017 ngjtmfjyflivnacnrdozomzelyzcujnotqfmaftmeoykyanm
 * Smoking Wheels....  was here 2017 heuamqipoyfycepvnwqkgetpqrszoymtbbqufqxlhmwxhpbm
 * Smoking Wheels....  was here 2017 beazgfkmecasvsetoqwsahpglpwixvneatwmyyhxplzyupaq
 * Smoking Wheels....  was here 2017 rznlotiaqtwcbneuwlzzvwmvqwuiicipyvvvmkdwcuuaijgy
 * Smoking Wheels....  was here 2017 ipyoifewqzbgitfsxkxpwcqfftansdrdovrmhpxlbbewynwt
 * Smoking Wheels....  was here 2017 jefquxcygcdtoueqhbtepnpqnwjqeptasjvibfkabcdkayfp
 * Smoking Wheels....  was here 2017 mdohlhrktswhufeuyaaotycnzzxpajyvqmzkthqivaazcvyf
 * Smoking Wheels....  was here 2017 pfjkyeosrpkwjapuaijviiclmfxrwpviqhcdpcugkbiycnys
 * Smoking Wheels....  was here 2017 ujjbhnwmvxzrwgaiyctklyxkzxyjnqgpkhjcbdjycwydarhi
 * Smoking Wheels....  was here 2017 oulqrrsrdwefeiknivjurhyotpwicdkwweddvedwkfxlgdkr
 * Smoking Wheels....  was here 2017 mxvspbskzcufixurcepyrebhjcrqyzqtexfixfcrcgmejcwm
 * Smoking Wheels....  was here 2017 mlxdslndvlxqrvogjddxkpdhonslpiozrqlcmnngffhtfxou
 * Smoking Wheels....  was here 2017 sjkbbxeonzvtvgjcpxycctmmkdnhyoaqbwaaapvvasbyxfqy
 * Smoking Wheels....  was here 2017 oufuvrynzzcaqpbhkxeafgpadpxwchfzggkyggvtboyssxkm
 * Smoking Wheels....  was here 2017 tgoylfggpboddltbsvhqmufiirydilkqjugzdlmsdweihcnd
 * Smoking Wheels....  was here 2017 clwkrjycvafetsvzqrzzvkibslykgdhhvpomwlbrfyiemfwa
 * Smoking Wheels....  was here 2017 uguglbxvmzkgzoyvqpdknieeiglctstahgkbytbtpigcixoj
 * Smoking Wheels....  was here 2017 fyhvzqmhofrysixqhazpzdgulrhywwveqiiobefjvwzzfzyt
 * Smoking Wheels....  was here 2017 bynuuocqihwxbqwtptyiynijpmmxzmzgavycfsngrrudrqrz
 * Smoking Wheels....  was here 2017 fyyynqoijcaehlerpqrsjnkopukhqruawzeaopgfeahzpgpb
 * Smoking Wheels....  was here 2017 uwgkeuublqkybwmetxdelksgkynnrvcouehypivnomghcmwi
 * Smoking Wheels....  was here 2017 fzjoyjcrogqtegrjtzngsrsrjmsigpcdsdqrbscnkxualeuh
 * Smoking Wheels....  was here 2017 ermziwzjzongtgvmlqguuceezgbrqwcivvykwtyymjdkgmbt
 * Smoking Wheels....  was here 2017 nrznazdohjblcuiczuzyssdmziuwlttxmldlhssqvfwxjtns
 * Smoking Wheels....  was here 2017 lxphzvpyesppvyuztprbrsummzmhmqxxilkjscwvryvhxsho
 * Smoking Wheels....  was here 2017 iqgrlpoltyseuddemnnserrjrwztxfsrimdcyqdyplcneesu
 * Smoking Wheels....  was here 2017 wfdgwupegqfwazkaahyuvhmnetjfahnronbsxkopitxvthle
 * Smoking Wheels....  was here 2017 wkrwygkogpdsykaznwqksrhqrtwwkczsmvdnupisyfvsnmjt
 * Smoking Wheels....  was here 2017 oeoqqxailytxbnpyjknwyzgpgdcfyxxxrtmebuynrktwniow
 * Smoking Wheels....  was here 2017 iqryfaqixysygsawgjtubvxqdnvaqmmmdboomrejbeqhdtla
 * Smoking Wheels....  was here 2017 vihjceuuyftoqqjbcmvcuwacytefxpazzrbsaiayynwfyxpa
 * Smoking Wheels....  was here 2017 yxttacecaoysmdadzqkuaeosjvkbilefouxavzsegwydudxw
 * Smoking Wheels....  was here 2017 vjvfxtwxzbprmkquicjizaujldbatkvfpxgbkdugirstscmy
 * Smoking Wheels....  was here 2017 xvkcamadubiwjubdvhzffxefmgzvfdciyqqtloxoqwfbdrss
 * Smoking Wheels....  was here 2017 vurbvtfztcvbhxlljxqkjomsaygmbliauaqeyhetbmuhpafa
 * Smoking Wheels....  was here 2017 myaxzidwkzhfoscgcwzykatnuideyoddnefqdosunvyxynww
 * Smoking Wheels....  was here 2017 afftnfvknwxpuhriklaepodnwtelrwlrupovlxduimnrguto
 * Smoking Wheels....  was here 2017 wwdyprnpcahqvbbuzaxtirfxmsfyixiymzcnobdgbioowshr
 * Smoking Wheels....  was here 2017 qhactfrnmzgdtpjwricmjcrcfcitfrenuhownbrtlijuklby
 * Smoking Wheels....  was here 2017 gffcqqbqcrwzxwycrhfnrxotuzuzafpecruemebgmxovrizm
 * Smoking Wheels....  was here 2017 xomzfysqvckmvylijdgelhcugrefmamzaqbdywuynpwlvcdm
 * Smoking Wheels....  was here 2017 xnsesivkqolblgtnkiicdvukwthdtpxdnvtnpyofafkocoxp
 * Smoking Wheels....  was here 2017 zpcgqkxdvstmulxbsnycngiyfaetdyihsgomkkjsvwlmevyo
 * Smoking Wheels....  was here 2017 albarvsfxhmtfijlkruinpueaoeggeheablkpnnjxvopvjbk
 * Smoking Wheels....  was here 2017 ebirtsgirlvahdslxzscibkyisvdxprwbsourtlkosotfukm
 * Smoking Wheels....  was here 2017 vpuodgsjdmlvxevdwyzalfplkbxdfyqquyipgyxeiimvpzjg
 * Smoking Wheels....  was here 2017 qmqfgzrooycxddvuffzapufcujngnbnairlwkayjzurcqanp
 * Smoking Wheels....  was here 2017 nminwqvgnrvghxczbslcsveohuzrkcyvbbwzhitxojracjum
 * Smoking Wheels....  was here 2017 qnnqxheettzazpgmvsgraottwpvxslvdrqtojiwyhqijdqhf
 * Smoking Wheels....  was here 2017 jtevodzfhmctapdidqpizmmwvkwrnrfeabokjuaxtlpbcsjk
 * Smoking Wheels....  was here 2017 jslujtsollzennxvydyyhlagszdzeunmigysgsemrwxkntqt
 * Smoking Wheels....  was here 2017 nathzvdpsnrgwhxnjfzpzilqhlzahvkyymwtfkqndfsugczj
 * Smoking Wheels....  was here 2017 arvnjlgawrofobtfvboqfnzypczirfqmodldtivhjcxakknn
 * Smoking Wheels....  was here 2017 gvotuuhsyicnmeixzdzsllcixnwokolmaxfupgodyhmbioru
 * Smoking Wheels....  was here 2017 wzerrltwfaeythuyrcoqlyoesotswuclnuutrfutqwudpszw
 * Smoking Wheels....  was here 2017 tucctdkyfovmrhmvdxcncyjevgycpbhemzckflvbkfjsagix
 * Smoking Wheels....  was here 2017 cgzdywfntbihwhzjsultstuhhyacmrxsmxjiqmbfqvantuxd
 * Smoking Wheels....  was here 2017 gnucnxlpuugycsgpceuxrwgpiesmpizimhaktbirtowobgad
 * Smoking Wheels....  was here 2017 xbrryuphqjlbofivdupwsbopnvdfgyzqqastlgpapndbpshr
 * Smoking Wheels....  was here 2017 zpcrxhkavpysnpqoboosvisyqypocomiikksygcgeakmeqqu
 * Smoking Wheels....  was here 2017 oatejjwmdobcobtrfrpufyxmrwrzxqinfuhwtoimtpnowpdu
 * Smoking Wheels....  was here 2017 cpnpohfpopispzocgpwsiksmyddfvtrnfxtcoabewcmhbmef
 * Smoking Wheels....  was here 2017 gsqnypynlgogqzfgczvjxnuhypafewxulsnmipgziprxhmjw
 */
/**
*  Application
*  Copyright 2010 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First released 05.08.2010 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.gui.framework;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
public class Application extends JFrame implements DocumentListener {
private static final long serialVersionUID = 1753502658600073141L;
public Application(String windowName, final Operation operation, List<JMenu> menues, Layout pageprovider) {
super(windowName);
try {
getContentPane().setLayout(pageprovider.getPage((JComponent) getContentPane(), this));
this.addWindowListener(new WindowAdapter() {
@Override
public void windowClosing(WindowEvent e) {
operation.closeAndExit();
}
});
this.addWindowStateListener(new WindowAdapter() {
@Override
public void windowClosing(WindowEvent e) {
operation.closeAndExit();
}
});
setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
JMenuBar mainMenu = new JMenuBar();
setJMenuBar(mainMenu);
for (JMenu menu: menues) mainMenu.add(menu);
pack();
} catch (final Exception e) {
e.printStackTrace();
}
}
@Override
public void insertUpdate(DocumentEvent e) {
}
@Override
public void removeUpdate(DocumentEvent e) {
}
@Override
public void changedUpdate(DocumentEvent e) {
}
}
