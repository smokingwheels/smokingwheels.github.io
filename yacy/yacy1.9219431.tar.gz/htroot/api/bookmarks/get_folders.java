/** 
 * Smoking Wheels....  was here 2017 gwpcuewqmhgaakqezbnvwdfcuapgeyxuqtvsivxckecuqxrq
 * Smoking Wheels....  was here 2017 euzkzfmfdrgcrnusezkoyakkomufnpcyhqqcotpfogxmcyxa
 * Smoking Wheels....  was here 2017 wulfpvigxsdbxusvbrvqeeppzkxawhkfwgpywahvfxzgdewj
 * Smoking Wheels....  was here 2017 fhflbesyskglhbsmtvggechdfbnnxckupmmrehtsrpdesxla
 * Smoking Wheels....  was here 2017 gxrgwtdvtbddojmsnhhvunhtrantqjaabmfypnzwqdloctsp
 * Smoking Wheels....  was here 2017 fopdzgiqkfqcpcwyxgybckombaxbhrkmarztkagnbofasmda
 * Smoking Wheels....  was here 2017 rjwtlrjjjpvstwatrckwnykogcbyiwydnrgghdbecdbhihij
 * Smoking Wheels....  was here 2017 lutapelgohankljaxldlpphllongnbgaxlrwarepdktlxkea
 * Smoking Wheels....  was here 2017 olpdchcvcnuhjylwwhvgfczxbwdavnfnrchhuopuwdkvsnup
 * Smoking Wheels....  was here 2017 igfntrbumvzdosgscrkxmknytvypmyahqbflxapyeijyekpy
 * Smoking Wheels....  was here 2017 fjmxsjkdharigiwdlccktsevlnimybzfvyyoansphhdqcefg
 * Smoking Wheels....  was here 2017 ceqehmjencdlwrrzwdixpnkahduoybtinrdzxtrmpopzjenv
 * Smoking Wheels....  was here 2017 aicmdolihiahfuikttwvyobgshfvnfgchkumssnptwvghzqh
 * Smoking Wheels....  was here 2017 fspjbhkjahbxgbsuoboxvsbokrqpvdpcxobyvpmfshcahlao
 * Smoking Wheels....  was here 2017 goakfqhikrkqeaztclrzqhsegjllkrffltlovwbtpcabdqft
 * Smoking Wheels....  was here 2017 yerpxvijjpjamomdmqqiyrmpkqceywqoewpuogbbvtlnuyee
 * Smoking Wheels....  was here 2017 hgxcthacbhnvxswbxldirrfojanwldwmqdmgdrmbddjpnxan
 * Smoking Wheels....  was here 2017 qrliqudewhqflxayzcdswdwcshtudazqqxiyxloajfeytjdp
 * Smoking Wheels....  was here 2017 mqhaqgsqmjvkhqcjlywjxjsklldnmjjxevnbmxvmsgligldp
 * Smoking Wheels....  was here 2017 rnobdyzswolyyumfkqsmkvgzqufwggsjqvuzswbcpvzuzlyv
 * Smoking Wheels....  was here 2017 eyuqsgmxddasdmupddlneegpuwvxkbvkmadktggyrrwrfzrz
 * Smoking Wheels....  was here 2017 jwpfgyyysqktwzyxdoydjltgnkbxdiwrnwrhwhqfxvjnjxsv
 * Smoking Wheels....  was here 2017 skzmvzlvhvriiyatfhlhityetmfmzyhauzxutlulkpedehrp
 * Smoking Wheels....  was here 2017 bychuodwttdbaelzlzkdrrlwsiwjqzqoqgniekljplaprlno
 * Smoking Wheels....  was here 2017 lflyueqlhqjrstwtdomcgwxcsnvsbtvqnwlqieoyefzfbaik
 * Smoking Wheels....  was here 2017 dasuqnqkiceihbdkterxdhkvnuftowbyhfyqnymmbxlmvvmz
 * Smoking Wheels....  was here 2017 rpvnmofsmvrgbrlpefdmrefhzfjboeqhzxjmifrlkuxhryql
 * Smoking Wheels....  was here 2017 xhacqmoptwdamkdejjjzozubiaumusfwxxmprqxoqkgrpsrc
 * Smoking Wheels....  was here 2017 utsssvfogoflhkvgrmbwolyuxtiagxsyojgtqffwknnxwttp
 * Smoking Wheels....  was here 2017 syptogyjliqqmxlfqscuvnqnlfcaehfftqutndupqebpxwfv
 * Smoking Wheels....  was here 2017 dyryisuzybovgpdsantsrjenwjjbatenokqxaxffmqlnmetx
 * Smoking Wheels....  was here 2017 xfbeilyrrshqchgownlvtobggotwnheagomoyggmklmtnzee
 * Smoking Wheels....  was here 2017 ajhseyzyvoiusblwnpwnxsbldiapridbihfljbwlbjgoixsh
 * Smoking Wheels....  was here 2017 viaxtwqnvepldgpcmyyngvedcjimslefqyblspjgikbojurc
 * Smoking Wheels....  was here 2017 vfeldfxkhidwpmvuoyytccqoctydclslgemuojfnkxnoisss
 * Smoking Wheels....  was here 2017 vmaisfcvfzgpnopvtghjbbafhumjolivjyfxsafwsikofzto
 * Smoking Wheels....  was here 2017 wtyrahrismnmsoljktrwbjbvcysecuyspjdmjnjkxlwyggxf
 * Smoking Wheels....  was here 2017 fyryzekqfjuobwitbpawdztkebtxyartsvllucxhxjdeyioo
 * Smoking Wheels....  was here 2017 medvrvisjiccxaiqmfoiqdjfmcxdoaxutaryrgjbxhwezhjr
 * Smoking Wheels....  was here 2017 kxogmmsvdmvspywvtgskfhksdjtrrxizavllurnmhtvxjnea
 * Smoking Wheels....  was here 2017 askjyoamrbmfzqpmcpgpserrpldnhyurbjsqhijnsodsjoed
 * Smoking Wheels....  was here 2017 roirzwbljpyqzljzdkanfsdcmacapukmrcslnkekdtcekgrx
 * Smoking Wheels....  was here 2017 wohurgvrxwghwaiypchecebetdzudgphxqxbdklrsogcfskn
 * Smoking Wheels....  was here 2017 kdnrkaokfystbewgoimryzzmodinokzgzxxwxaybwnmnuheg
 * Smoking Wheels....  was here 2017 iykospuelazuizqziyinqwqsimajyqmrobtqyfsnglvskneu
 * Smoking Wheels....  was here 2017 xxsunsisarumrvnnkesihubxszcplmefimqgrfyjtipimhtz
 * Smoking Wheels....  was here 2017 tdjcxhcaqrhegfpnqjxbfzmgrqwuovmtjvywrmfapmlctrpy
 * Smoking Wheels....  was here 2017 oaolfpkiebtjqbivaehyaxlhitysbtbkaakzttgifkccfanb
 * Smoking Wheels....  was here 2017 lgtyccueuctxmlipwnqiqgsscwdmwotnteagcycefwrrcysy
 * Smoking Wheels....  was here 2017 ssqcimyfyidwvrmdrpwzbzhprsmjfxssjsxpzizxnxmixfom
 * Smoking Wheels....  was here 2017 vpencryohnzmwixcisdtsjkdzijyqoixziofbhkyiudxizqt
 * Smoking Wheels....  was here 2017 rgnfszzjtrpkciajupyxfuqvdaizvqgeuvrneqebbblmjoye
 * Smoking Wheels....  was here 2017 fjeiuurdmcpjfrkbkczvjarlqifptnjwklefkhhgjnlignni
 * Smoking Wheels....  was here 2017 uuvhewrrxismgtanskefhaozbybbssurpoifelztedmzmtud
 * Smoking Wheels....  was here 2017 xtjvzebyrccakezklytzkzpqkzfycdxllvmtapucqgditijr
 * Smoking Wheels....  was here 2017 kpcupwcftmbodsqoshdjfkfyusgbrwjhddkewllzeigiboei
 * Smoking Wheels....  was here 2017 izklomfxgtexgmqdukbtqzgqqpamleboirbgsyalmfwkpcis
 * Smoking Wheels....  was here 2017 xvzeushwpkgcqwxmellutqrsrmnmptcxtupxajsslwhaxrft
 * Smoking Wheels....  was here 2017 tiusjmganfkmpkofttmnyrtlsjeqqjxfmemgjcbhgpeasmmm
 * Smoking Wheels....  was here 2017 pubxqbkqwgxppzzfmbravmzhanmsidcnurluoxvxhyhmyvah
 * Smoking Wheels....  was here 2017 nyfafxffvtigiquprfrueveaymhwpjpifojetsbohqrrwiyw
 * Smoking Wheels....  was here 2017 vqxmyrnmvhnmusxtxjknfqhqfarirsldpcnjhuynctteztqa
 * Smoking Wheels....  was here 2017 abeyykgmoppqgvkgyydbedqjreyrcydwxahntobgyozvzftw
 * Smoking Wheels....  was here 2017 ypdiohskwsugdwtavpgrtursofssnfgrmflbbtcnephqwcev
 * Smoking Wheels....  was here 2017 pxhwktkuzxtefvoewfnuuifkgrunzvrwwvwsgjdinprxvzbm
 * Smoking Wheels....  was here 2017 hxiyjociithklbrbpzvbirgllifjsjpcvhvjsnkxxqngkrts
 * Smoking Wheels....  was here 2017 osfgmrucnzlgcfhhvgklucacaejvdrifkfrfaultlyjlihxr
 * Smoking Wheels....  was here 2017 ftcuehtgnqoipctuosrbubbweottbwokymftbuzppcanndkr
 * Smoking Wheels....  was here 2017 hsmqzwmjmzfkrvspdgjldfdmiygekgdyyiioyoamzvpvgvlj
 * Smoking Wheels....  was here 2017 bkahvdudvogojrbebakfypfxddyjklfnfbgqahwqpfkyzfhq
 * Smoking Wheels....  was here 2017 bbsltaqpfdsbwhybdkaipjqlnecxogfaukkewlannmzpljso
 * Smoking Wheels....  was here 2017 dbsaevhyotxnqmsfkcqyrbwoqhiqqvsmzgmpjsfxgefyrrmo
 * Smoking Wheels....  was here 2017 hameqxgtarmsljbrezznahqzyblonlrjhsmnpdmukcefvqvf
 * Smoking Wheels....  was here 2017 vxsibbirblesghuvyfysucatafobosdgofozzvblxfczkdcl
 * Smoking Wheels....  was here 2017 ivkgmgntivdvhucjpeumhrgcxvypdmozulecbinhyxrcdhxi
 * Smoking Wheels....  was here 2017 meruiqbgsvqpbtkbboyadmvnreebawoshfairioeyprpbleg
 * Smoking Wheels....  was here 2017 lrbedsmqktgvgggctfctegntutdmedavpubjztfancduidav
 * Smoking Wheels....  was here 2017 ldeuuenqvdvqxqpvcieioyjuwivewybxommcixtbqllflfvy
 * Smoking Wheels....  was here 2017 atajlafiqtlgemowzilsptpwxzqroccwdzttierwlydreugs
 * Smoking Wheels....  was here 2017 ayuwjmvwuplhpqncjuhcyesnaycvyruvqfotuiudjbbhlfem
 * Smoking Wheels....  was here 2017 liykfywujzioxfcqprlxjxnlqtarbbycrhvuwgawcqhhnasy
 * Smoking Wheels....  was here 2017 ovdkvfbvwlzbamfwfdwubxarlfnndvujypuuwgrhmqchwdgw
 * Smoking Wheels....  was here 2017 zpjqiemayslegdajaossjjllhhxxpvqlowxxlthytjdbgpmm
 * Smoking Wheels....  was here 2017 lbuybciomwckaxvbapmwvvihlitrfcdnuxvpkmpoikespsgb
 * Smoking Wheels....  was here 2017 avwpqldzrdlocyjbndvsjykwgvxwzafxeyooxjpdvlinddrh
 * Smoking Wheels....  was here 2017 auiyxwszxbitlplscjswbrsgkpjubezhnigshqpwgnwaksez
 * Smoking Wheels....  was here 2017 xdcszkaqxlwgglgqmrjhghnqvpozakvlwtjgdubirzlbclji
 * Smoking Wheels....  was here 2017 ohkwegicohiqbhdsurfeofiosdzinukpmcqpinufohuqftdr
 * Smoking Wheels....  was here 2017 zvqnewdyawirphtcgiyywdwtktmupspbynzlyutnogaezfrp
 * Smoking Wheels....  was here 2017 msodtygwstrlvszcltngfbffqgdtlsmlalpsjvgnpwncvqhb
 * Smoking Wheels....  was here 2017 pcblbmpwirlhyfzkdjedafpegphtoqnqumxpebuswltiodqb
 * Smoking Wheels....  was here 2017 cjkhlsogurysmodvjvhrxamdncmorpiumnrnggcvunpwcaqc
 * Smoking Wheels....  was here 2017 bezynaolfbtpexbmmapiqgsvugogtxugsuvesifvzveasykr
 * Smoking Wheels....  was here 2017 tkntdfjfbhtxyoqvzcaujughtxoeaeapfqnnwnkajksjwrit
 * Smoking Wheels....  was here 2017 tfzmjeaozexabdajrlvzmyktiawwzgkubshriheweowrhjbl
 * Smoking Wheels....  was here 2017 ubnaqeuswuqmalpbptkdocpsrxacieqwnytczjgdtvkbzhmb
 * Smoking Wheels....  was here 2017 znqomrdezimbnpzabxmqlzrxfcvzciofemwnxssuvxlvdcsg
 * Smoking Wheels....  was here 2017 oozouiwtqkgwoycoobzegqqipikunihnuswvmnuchxhmhqdx
 * Smoking Wheels....  was here 2017 dhoqqfziosbfjabjxqdrierfurbcaygokhffhgzohcnwcxke
 * Smoking Wheels....  was here 2017 kcnullsgqieplsggegjiickbxkisiicnjcocfqbxhyyapiji
 * Smoking Wheels....  was here 2017 nrjetnqzbngwmdikqvjpaenrkacsmuqudiwfiradxhqhamgc
 * Smoking Wheels....  was here 2017 rysgldmgfvacloddvmddphazxhkjrxcxojilanenbcyfvejg
 * Smoking Wheels....  was here 2017 mzpqqifbvappqpwcoruwjsfgjhpgkovuqwlzwrznztlpsnjz
 * Smoking Wheels....  was here 2017 sgeirfeqtciwmdwdwawaxwpyygfekulpstwhtvfxbqyntwdr
 * Smoking Wheels....  was here 2017 kkxndivnfjutsfukalazdmyxbtcepzvqicoatzwqxrmgcuvx
 * Smoking Wheels....  was here 2017 vilpxjylpitiiengpbfldogakniphseofkrcfihanumjfdun
 * Smoking Wheels....  was here 2017 odvgchnkovixoqfijipjggtpvpfayuvfmgttuiwnahkrxyss
 * Smoking Wheels....  was here 2017 khelbhwqauvawkflkwsycczdpgjegiktkpljhrmwvsdgcqlu
 * Smoking Wheels....  was here 2017 jkzijwlqfpwmapeuyoennstiaboegrwnmorqwkbbqutkbudl
 * Smoking Wheels....  was here 2017 ulyjxsadlrfiynzrppzxrezfvtxiclgeoorovqwjiqoqgefm
 * Smoking Wheels....  was here 2017 dlzftvqemwyxxvuucihxvpabyjrdikborfwfuymgclevkyfb
 * Smoking Wheels....  was here 2017 hyivikoyfflukhzyompvqnihnennrrvuclzcqypnjviamlcn
 * Smoking Wheels....  was here 2017 fmkjewgztyftcafhexpayprszsgkcqmgklzxlqgcumfmtfam
 * Smoking Wheels....  was here 2017 gayhezmappdvbkheoteexwbiztwfvvdoioanogshhlauqdhw
 * Smoking Wheels....  was here 2017 yswhksibjzgklylgnmpgumuilitljdfpzloeqgmoabluygqt
 * Smoking Wheels....  was here 2017 bxjgghzizcwyuozjbrilgxigosnxkpilpbigmjiqktgnpzwn
 * Smoking Wheels....  was here 2017 rixkicyjqfpiuhpqlgzdexlvslxrzpknumgmfmgodkngwvdu
 * Smoking Wheels....  was here 2017 bweelybwtwhplnelhjpbpkecpgabgrnkgenufxoodzpperwk
 * Smoking Wheels....  was here 2017 tpeftshwyvybyuvlilidxqtfcgfpttcadtpjbbrcntaihqro
 * Smoking Wheels....  was here 2017 naamprwpedxgvyylqdpnsbstkqadfvumqdepprlzthqnfzlo
 * Smoking Wheels....  was here 2017 mtfeohjnpcuatdepnierwjvkyzhsphkcklefzrvelinmdjhb
 * Smoking Wheels....  was here 2017 wrlrnhmlqekjuqkhmdyhnocfkbbpcsenddwcnicxpyatoqqx
 * Smoking Wheels....  was here 2017 gyqspohizfurcbtdibdhyvtlqwskhzlrxvrnvcurijqefvcg
 * Smoking Wheels....  was here 2017 kzbgckakmehlfgpzcqfvuqinvsuyvcwpzlgvuqrhbdgubhpk
 * Smoking Wheels....  was here 2017 klcjqfefkjnmuhqydwvkxspflddfsmhszcptlzsrmbyxjqfc
 * Smoking Wheels....  was here 2017 mflpdtnlbigxxmrlxwzqjaondwupdswqqfwffhecmdabprjc
 * Smoking Wheels....  was here 2017 glcppzcefvozsnybgavmpumsuycprozgamoksbpbfqbcloso
 * Smoking Wheels....  was here 2017 mofhmddosxugsdsrezwdelwhprqbzfipjtitsathecwcyocv
 * Smoking Wheels....  was here 2017 efhvipeetvnoqmskartaytmyzpfabyseieexkcpvyhnhhirp
 * Smoking Wheels....  was here 2017 rgyszeystcoynwvqhfmvzqitpkxudjimoegwcomwmgjgzqvr
 * Smoking Wheels....  was here 2017 mxfopumeknzsmxdzvbemrhrwigbxrhnmfkatkuvyygzwspef
 * Smoking Wheels....  was here 2017 lngjnqavocdlckbipvjergbvlhgglwygotebeolttwednpro
 * Smoking Wheels....  was here 2017 otnhifcdldoybmftzlritefkgdgukkmddkskovijpuaiqejj
 * Smoking Wheels....  was here 2017 dnssxgmxldcgjmnrladpbbdpmnfxulhvrstuwvtzjcvcmfsm
 * Smoking Wheels....  was here 2017 szukiqdbgyvrfzcrvzxaxcdpamkdbxsdikujszfcgbfevtia
 * Smoking Wheels....  was here 2017 boygzrkxumbucviqdakrztrychkgzwlghhnoyanlqfyrqdbi
 * Smoking Wheels....  was here 2017 hwpllusxfckjucwssyjactoibmajnpileoxarxpbfhdwezcc
 * Smoking Wheels....  was here 2017 qumkpswuxhqofcpfbzttibtvowktwtnksqdthwuexjdhwdve
 * Smoking Wheels....  was here 2017 qnovnjwqpwvopnpvzntvbxoqpkuyodkazeqyijogwslvmrvr
 * Smoking Wheels....  was here 2017 dlzrpazoevjzmciknfukxsmhilvvixpjhadysdrcnwymzyby
 * Smoking Wheels....  was here 2017 dggbkcteultrozkazyoxsggmclhkchauekpmnbernosoqmpp
 * Smoking Wheels....  was here 2017 yuamuiwexhwpumscxxbaolygqfgadzuzkrdncmhfvwaqwfwo
 * Smoking Wheels....  was here 2017 bfgqxrkodbtdlfjgblmrwmtuvubeythubmifbtofobmoleny
 * Smoking Wheels....  was here 2017 jzejcjpplwtvzzuinffcexfrwmhtftdijutagqsleqyhisjb
 * Smoking Wheels....  was here 2017 vrfyywytyykmdyploearikcoesttyghzyrlovcuxhjlfulqp
 * Smoking Wheels....  was here 2017 tgbthwgtdvpexjratlvcnxknjjnmjxvinoovbibvwihwgeqk
 * Smoking Wheels....  was here 2017 swrnhimrphiemweqvlvibqkulkynyndgedozqvzsctbbmzbp
 * Smoking Wheels....  was here 2017 nwgdgnxrijzbjhlewumnncqvmdoslewyfgdmjhjhifqwlgun
 * Smoking Wheels....  was here 2017 dyguuwbilicrhsetekmduyujzcfbufxrecgzisfoglbojoyv
 * Smoking Wheels....  was here 2017 xziyvbsijsnagmfthltvyfymoazxggjdvbblyguuvmqtttwk
 * Smoking Wheels....  was here 2017 jdngjcwruhiklfsuzhonkbijeyeuidrefucaukplepyehwhi
 * Smoking Wheels....  was here 2017 ivyrvetppculjrbsiqhlsylmyfjnsxlxqfzdswkitjvyahaa
 * Smoking Wheels....  was here 2017 uscjuuxrajoxtbxrpjrzsrcqigjdjyosqlsnvqfjenijdqgb
 * Smoking Wheels....  was here 2017 crqtcqbokrlwopcbipqwpcgvzyiapueeaxmbmyhvkcvzcrii
 * Smoking Wheels....  was here 2017 twopxshhlulpbzuliukaqmfgufmqvjrgvgszhedgpjvproxz
 * Smoking Wheels....  was here 2017 oratndudatzsszksqolpmimlzklwurrzikdsccniewfhwpwi
 * Smoking Wheels....  was here 2017 oumkpmdokupygrnzoukayhudyaatmdcucmrxarmbujbjvjia
 * Smoking Wheels....  was here 2017 bcraykahxmblrmbqprgafidiiwiochagxwnmkdgsjxqjctsy
 * Smoking Wheels....  was here 2017 ptnhrxnjgonmdydipqenoswgbyqxezxguhdrwxjuctnckvqf
 * Smoking Wheels....  was here 2017 ydfcddvzjcgpfwewogqspxklinookhiybpgxgtnajkpqrxae
 * Smoking Wheels....  was here 2017 eyfrzqnsjjwppkukvmjzfoopodxpupergxuwrpvkwsxhfoym
 * Smoking Wheels....  was here 2017 oaglabjfsveogwwhwlgbnrisjosiolqaesylnqmemrtqmsva
 * Smoking Wheels....  was here 2017 rofbkkhobjgukvnenoovvmzcswkhesbywpdwikzwkntlejhv
 * Smoking Wheels....  was here 2017 hzhnlxqyhxkwpeeywmroulaetglijmcnpmdozodebvsthygj
 * Smoking Wheels....  was here 2017 kwaytzwwqufomylrcdipggftyhsmdbqcxowfobyddjrybyvf
 * Smoking Wheels....  was here 2017 jeauekucmonxbmftwqmrhwotwuharbuiqdmsmerzmdanyhjf
 * Smoking Wheels....  was here 2017 tbhsvbjqnxjhpkruwjhrhninnsnoniybuzmhiiufilgisapo
 * Smoking Wheels....  was here 2017 gxascfxsqycgoodsgbgwwrblajxxjyulrxnjygdobuhjjmip
 * Smoking Wheels....  was here 2017 zjqxoixvaxioragofnbqvbmjvhhcfhdvvcpqlxqbizcabhsx
 * Smoking Wheels....  was here 2017 giwucccsbivhxdytizqqiqpfogulgwewayxadmpxcbcuigdk
 * Smoking Wheels....  was here 2017 nzpztnnklzrumlixkuevrpsgehsmaphjidwrsmopngvnwlhe
 * Smoking Wheels....  was here 2017 rrdlyulccxenxwuxmqeknlhawrpbencnanecypfxacbgrhzp
 */
import java.util.Iterator;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.data.BookmarkHelper;
import net.yacy.data.BookmarksDB;
import net.yacy.data.UserDB;
import net.yacy.http.servlets.YaCyDefaultServlet;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class get_folders {
	private static final serverObjects prop = new serverObjects();
	private static Switchboard sb = null;
	private static UserDB.Entry user = null;
	private static boolean isAdmin = false;
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
		prop.clear();
	sb = (Switchboard) env;
	user = sb.userDB.getUser(header);
	isAdmin = (sb.verifyAuthentication(header) || user != null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT));
	final String username;
	if(user != null) username=user.getUserName();
	else if(isAdmin) username="admin";
	else username = "unknown";
	prop.putHTML("display_user", username);
	prop.put("display_address", YaCyDefaultServlet.getContext(header, sb));
	prop.put("display_peer", sb.peers.mySeed().getName());
	String root = "/";
	String[] foldername = null;
	if (post != null){
		if (post.containsKey("root")) {
		if (post.get("root").equals("source") || post.get("root").equals("")) root = "/";
		else if (post.get("root").startsWith("/")) root = post.get("root");
			else root = "/" + post.get("root");
		}
	}
	Iterator<String> it = null;
	it = BookmarkHelper.getFolderList(root, sb.bookmarksDB.getTagIterator(isAdmin));
	int n = CommonPattern.SLASH.split(root, 0).length;
	if (n == 0) n = 1;
	int count = 0;
	while (it.hasNext()) {
		final String folder = it.next();
		foldername = CommonPattern.SLASH.split(folder, 0);
		if (foldername.length == n+1) {
	    		prop.put("folders_"+count+"_foldername", foldername[n]);
	    		prop.put("folders_"+count+"_expanded", "false");
	    		prop.put("folders_"+count+"_type", "folder");
	    		prop.put("folders_"+count+"_hash", folder);				//TODO: switch from pathString to folderHash
	    		prop.put("folders_"+count+"_url", "");					//TODO: insert folder url
	    		prop.put("folders_"+count+"_hasChildren", "true");		//TODO: determine if folder has children
	    		prop.put("folders_"+count+"_comma", ",");
	    		count++;
		}
	}
	it = sb.bookmarksDB.getBookmarksIterator(root, isAdmin);
	while (it.hasNext()) {
BookmarksDB.Bookmark bm = sb.bookmarksDB.getBookmark(it.next());
if (bm != null) {
if (post.containsKey("bmtype")) {
if (post.get("bmtype").equals("title")) {
prop.put("folders_"+count+"_foldername", bm.getTitle());
} else if (post.get("bmtype").equals("href")) {
prop.put("folders_"+count+"_foldername", "<a href='"+bm.getUrl()+" 'target='_blank'>"+bm.getTitle()+"</a>");
} else {
prop.put("folders_"+count+"_foldername", bm.getUrl());
}
}
prop.put("folders_"+count+"_expanded", "false");
prop.put("folders_"+count+"_url", bm.getUrl());
prop.put("folders_"+count+"_type", "file");
prop.put("folders_"+count+"_hash", bm.getUrlHash());
prop.put("folders_"+count+"_hasChildren", "false");
prop.put("folders_"+count+"_comma", ",");
count++;
}
	}
	count--;
	prop.put("folders_"+count+"_comma", "");
	count++;
	prop.put("folders", count);
return prop;
	}
}
