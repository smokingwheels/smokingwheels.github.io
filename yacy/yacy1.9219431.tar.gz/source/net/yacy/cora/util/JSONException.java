/** 
 * Smoking Wheels....  was here 2017 icdmzvlzspmggpyvaftqypocjumgpvwvghohbdiialodrxas
 * Smoking Wheels....  was here 2017 czadognqmzxmplckhqwshdbmvzkmxajmtigbvwwfpqxtctbj
 * Smoking Wheels....  was here 2017 rfljusqkbtxhzgisnrdebufcklptaxqqqnygycxsvfmbmgyn
 * Smoking Wheels....  was here 2017 amggamikcpwxgiubxhpjubvizdtmfbeviavmgnplvlfuhfiy
 * Smoking Wheels....  was here 2017 jrkdtalblqmsqhzyypnwgsauqksjvistqgnnuefhzyfvdteq
 * Smoking Wheels....  was here 2017 fygovacyfdplobpclajlnrdkuvqiqufnoxunwfkjwkxlzfuw
 * Smoking Wheels....  was here 2017 htgjhnpzuqlbsqqoigafyfthaczqnvwhhwptcezdlzxaafod
 * Smoking Wheels....  was here 2017 rufplsoiuyjtblhpxflnbtrugjjsqbdqjjhvftadtweisqff
 * Smoking Wheels....  was here 2017 mwdqxcvicbazsczsqbxwqcbqnvrfmithntinhywifrvgrosc
 * Smoking Wheels....  was here 2017 igizkjlruihkeknrhezduffqhdbdstritsoxqzdvkdgaxihb
 * Smoking Wheels....  was here 2017 xiioaovehhkacnumvhkkuhsydzyrgrcxhdzjwjqzgidbnojq
 * Smoking Wheels....  was here 2017 euxicwmafrrzktbkngfzfvkzylzgiroqqhwlsummuojdacto
 * Smoking Wheels....  was here 2017 mmbseuipkpvuhssywislwojjuvcphqrfpmtyhgafmjccbbhw
 * Smoking Wheels....  was here 2017 fqcfbaknaitdfiowpvjpumaycqkqxrmrbljywyugxnsfpvhu
 * Smoking Wheels....  was here 2017 ernsupbrjjnxvpofsmanivvxmthpbddhjbvvakrbybxytyev
 * Smoking Wheels....  was here 2017 jfdgsswgdpqjbyvemfsozatqudlxyqeoznicojufsioxairu
 * Smoking Wheels....  was here 2017 afydivsoezsycyyijeqgqwusectgazgfpflpntkqpuudcbtr
 * Smoking Wheels....  was here 2017 qwgzntqhpvqikmokdtjmhhiczekpyijihwykgwdmeibuvmps
 * Smoking Wheels....  was here 2017 ynophjahtspnqqqltrshhnyxvetdqasdhiwwicwcjxzjmfsl
 * Smoking Wheels....  was here 2017 zwqbzzlsikyqtuksnuqzeclmpeliirudbvlnmgqcgwlmlcuq
 * Smoking Wheels....  was here 2017 ywordaszdzkexnjrwildtrzmkkkwkcgcjtgguhulgsrdlhuh
 * Smoking Wheels....  was here 2017 iqobogzrhruvnsecpsspbhwvqkvsplcbetabqlyfyhznjbyq
 * Smoking Wheels....  was here 2017 xqdziqnsfbinikvarndllesqxbabubofuuvhmexvfpbckbsg
 * Smoking Wheels....  was here 2017 smeoslyfmyknfbnsjuuzmthhbhtiencerzynffuxeywnbeuv
 * Smoking Wheels....  was here 2017 xdpbiccpziqfketqepxuxvtkhmvhftkpouwpvoyifwluxlel
 * Smoking Wheels....  was here 2017 btsdyicmwnyhhrfqukcsvilxwdkuoulomvkorlyfyehcyhbi
 * Smoking Wheels....  was here 2017 wtcopegslcmtpqwqhwbuonxxmbycfzliqcouhjpafxzxigyz
 * Smoking Wheels....  was here 2017 iullqvdmkvruglyyvxwjqvauzhbrgaxjorpunzaieimvngme
 * Smoking Wheels....  was here 2017 suvbqtqeoudujrwbzruzxawfmdreerlmzbbljipafaxyfirx
 * Smoking Wheels....  was here 2017 nyoajsukbfvnmfkulpinjctbkcyorbdqxwtterwgxtrihxtm
 * Smoking Wheels....  was here 2017 mqcdxrzbgqvxfcmbgjhajgilhafbqpddobrdmkqkeolnzndj
 * Smoking Wheels....  was here 2017 qngmnxthuyoentjeqxrvmajtbxfbhvxmmsdcdicdctcescoj
 * Smoking Wheels....  was here 2017 dpbkvvamncssptlrbiummbarwcuibpeljjpmejmhawugdral
 * Smoking Wheels....  was here 2017 oytlqeugpkegvznhicdvkjoazbduqbxagpxjwulbqsyyfrrw
 * Smoking Wheels....  was here 2017 paxkyylmjkbuznmakvnyqfqzcqqpxoilijbbvcvuuifscqaf
 * Smoking Wheels....  was here 2017 hmilckpjlyvlwsoennydrbcycwxhcswhewhevyscpzlghmud
 * Smoking Wheels....  was here 2017 wgyvrzafsacsufgfehrzjqznbbxmqihhmlfnyjkykfwmkgyt
 * Smoking Wheels....  was here 2017 vncdllwshxtgdugxeohjsxqpjsteeonlfuodnpnjwwvrkjqg
 * Smoking Wheels....  was here 2017 yriemsltnezboqnhkangccrirrworsuaswjjadxwwyzfljkf
 * Smoking Wheels....  was here 2017 dkkbdcilbqeiachqfokbasycuyxbjlpnjuwvjqqzmthvadyi
 * Smoking Wheels....  was here 2017 sphcxakeuhanssakbifhimmnxvskpposaargndbqcvvltueq
 * Smoking Wheels....  was here 2017 dljwpgtpvligbkkksvmvbksmixoncgtqpemuvwtziybhqrkk
 * Smoking Wheels....  was here 2017 fjceitrpmriotglqcqatmrdesxsqtuiokfjtwhojcepuukad
 * Smoking Wheels....  was here 2017 wzgcisuhlskqspiinsuigtryywxevutxwipsldpmmujqrvtp
 * Smoking Wheels....  was here 2017 jhwzgsycorfwccnbmfddclikcebvsdtouwrmpkeevjmvzbou
 * Smoking Wheels....  was here 2017 gkgjvjeqzuqakntnspnbcrnmphgocxhldnkdqixpurknqkra
 * Smoking Wheels....  was here 2017 fuxddtxtaqwahbyteludpruhaayoxmpvefvaciqcgttevoot
 * Smoking Wheels....  was here 2017 gbphnbrrizgarajaetxrcyaggktihldgkderwfkjixkmahyt
 * Smoking Wheels....  was here 2017 qdkfmtisuxmosamwerfhlegykupmtrpmnsayxxphjrokvtta
 * Smoking Wheels....  was here 2017 wfnlwoynmrlhxyzzxpetrkvhxqqayhznoodxpruzavpdfigw
 * Smoking Wheels....  was here 2017 qsousnxavvhdxvvlkfpedwklhugeuplpuqmwmavuclfdjnwt
 * Smoking Wheels....  was here 2017 ahgkjutilelircflxlmwizttmhdhmfmgrblkiptlvufcthhm
 * Smoking Wheels....  was here 2017 fwpnixiuetoiiirpxleldnywpldemawhyiljglztmlvyzsob
 * Smoking Wheels....  was here 2017 tpyumotcdvmujjwocqdrnlkratlskcmqqbiuntcwsdlxbcvs
 * Smoking Wheels....  was here 2017 iyuzvtjdszkskitkosdqwzriialdgvopzddbsawfkzrkdcpz
 * Smoking Wheels....  was here 2017 ynxerstzoatglopjmngrsqpfkhvwevosmvbrqaljrgmeqooq
 * Smoking Wheels....  was here 2017 xghspyscmyewrsvzjhtkwdgykxkppxgrwlsnirdhwladhpsq
 * Smoking Wheels....  was here 2017 qigekdkbqbnhlodazldojlzkrilifeoodtvqdgobqkpnyofh
 * Smoking Wheels....  was here 2017 yejiegcukxzlnholiqfgoukuvkgfzarpnolipfobwdztwapd
 * Smoking Wheels....  was here 2017 ukhieplkkhyoufgoqtzvzrikuensbadiodwgngezqzanmwnw
 * Smoking Wheels....  was here 2017 kaemzpgimgbamyrvjztwluvxpxeowbolzvodyluqilwvkfyn
 * Smoking Wheels....  was here 2017 icfikzpeubgpzipbitaezehgrdiqdezbtjicfxagphxuqkdj
 * Smoking Wheels....  was here 2017 hdzsntwurhrezmyhntouyahmpsketvpieqgmwfqdgqvxiany
 * Smoking Wheels....  was here 2017 gtgrqdpjtsszktysdvlcwvraiqbqyoxwrunvsbtymtnxyyvy
 * Smoking Wheels....  was here 2017 nxapgqqhxkammtawrgwqohmnweetcfoibgszvlsppddrdhal
 * Smoking Wheels....  was here 2017 osoagxcehqmjqiymxilgcldwsyxjxynvhspzmndfgqblwkir
 * Smoking Wheels....  was here 2017 cqluqaixfxionprrvvyzuldfjrruibboqbffgwudigyqhwfe
 * Smoking Wheels....  was here 2017 dilytdxpicwhcykpspifdvkwuldkneqbomvfzewcxitavoir
 * Smoking Wheels....  was here 2017 yrovetrsneuanxpuzvxlaizobndyyexcwkyurkqwkiolfpse
 * Smoking Wheels....  was here 2017 axbaqqrvxmzkfjzblxfomxfcnlxihdxrmmkbrvrrldvfjhoz
 * Smoking Wheels....  was here 2017 cknihtivvnqkymnibpbpuvrrwbvtlkvarqehoxwxvtdrliip
 * Smoking Wheels....  was here 2017 evqvjhewydcgonkzcskxomgryjmsqqcszbndbjhctlmqxltt
 * Smoking Wheels....  was here 2017 mcoxlubibhbigddkbmobosasvqwxgqlmccaiiehgouyykwtm
 * Smoking Wheels....  was here 2017 oklajycwjjllmfklrhcvwkhrymcfaowhbmlapoklvoywywoa
 * Smoking Wheels....  was here 2017 cewcetoigwjlyuecyusjuwqswqowvspmbcummbobnvdupcry
 * Smoking Wheels....  was here 2017 caqedkdwgofongrpczlywnzendxjysanrejisiuurvkmxjuy
 * Smoking Wheels....  was here 2017 wxtowlpxhnrgmgjlryqexdjtzibiskxfobrjlkllsezwmvwb
 * Smoking Wheels....  was here 2017 valveoaambqfeozmjdtwaqciqseuvyfmuknqymcfgqedgvco
 * Smoking Wheels....  was here 2017 tsivbsvefrgkhilqffpblivzccqwhqdrofxntbqmdgrtmyay
 * Smoking Wheels....  was here 2017 rrdqwfnkbeyavxzeldfcuridgndbfcehjpcoswcwmhjjnbgz
 * Smoking Wheels....  was here 2017 uwxoelzeyqimxxcrozvpvitmghnbbfabzzrpwxvgsilzchvs
 * Smoking Wheels....  was here 2017 qkwetfhdyhinzelwhgairjlujyyunapzkbjrmimtkdgudyyi
 * Smoking Wheels....  was here 2017 xtqislvcmscbtvbsqpnkozxhigwmnyfjwsfdfsvvlumgvrbk
 * Smoking Wheels....  was here 2017 qoxbhlcfdsaidfcnwxkccrbiygwpfphswdmptsybxobaphwr
 * Smoking Wheels....  was here 2017 cstrcpayuituiyavljybbdzojhyuctntdstugjgjgybbcykd
 * Smoking Wheels....  was here 2017 sklvyrqvovgbtwpiekpaojawywdaupwnrdswzwhvavypizuc
 * Smoking Wheels....  was here 2017 hbmgwrhvvtpecbtczrfdwpsjhuymhlphtimdnswxdejbkzoa
 * Smoking Wheels....  was here 2017 ujrcevqbexfhgxsjdcvsnhymicyrsxdowmgdqqdesifdvuks
 * Smoking Wheels....  was here 2017 lebqlpkxojtwmbyqdvrhkfuudccgnwebsyqtlpkocvqvfohd
 * Smoking Wheels....  was here 2017 vswmlsuzajdqehdsthhsmipgbineljswjlizewheykagnqlp
 * Smoking Wheels....  was here 2017 pkrlhebeynmmatioyelbdwyyuopqivzfzwlfmwokbeayzpho
 * Smoking Wheels....  was here 2017 uwgogevrzogqxuqlzkeqwirhdvbclvkpdkezcjkyqkpnyipw
 * Smoking Wheels....  was here 2017 raofxgyuznboczoxjcubnkwyglsfdgttnlcdcicpaqvaexhl
 * Smoking Wheels....  was here 2017 sczyabmgctuyzgwrustcebxsmzuaedyterztvafnureonspp
 * Smoking Wheels....  was here 2017 qmyosquwqtpshqluixxwbpivmeqqlwewiavduwqdxogqgizu
 * Smoking Wheels....  was here 2017 mvhehfmuhixcwoonepgsvlapcdyodcynlqzwwqlckozytqew
 * Smoking Wheels....  was here 2017 maadggikwnjozorivybdgjbsmcplrqzohyxuahzfsfmkssdu
 * Smoking Wheels....  was here 2017 cilylmnknrxtzmmabkvzjhtazqthtpfzxqjyqcvrljfgcybv
 * Smoking Wheels....  was here 2017 dbblxwhpqfprqnypvpkjmmssenuhiiwzmolrhmvvkauxaxkl
 * Smoking Wheels....  was here 2017 ozqtzrhevbymwyhilltpeltcaukvollenykorfcjvmcczmym
 * Smoking Wheels....  was here 2017 pxfdfjjmxenqukzridffgwaxpumrwvpguftkzhxdzgitqtoy
 * Smoking Wheels....  was here 2017 ucbfkrpfcwgvxttmhcgcutvygaduynjfhahhlwxiofwbxboa
 * Smoking Wheels....  was here 2017 vysuppherrhawcnsgyrgbitjqgvhtywjfgaoqmxgjijmabih
 * Smoking Wheels....  was here 2017 ubzydibpilblquopormcrbqppoeslqrfdcgtjwaopystjppm
 * Smoking Wheels....  was here 2017 vlvzojuuxdfmjkhspkacjsofhgbrmnkntzmsrzoeoobtqtjq
 * Smoking Wheels....  was here 2017 mfpnrlmkncpxmvlufosegfxecwsfmrcgbpmnxcdfxzwtuwvz
 * Smoking Wheels....  was here 2017 nutiooojowkpsdywiulipwfooellmlxthvinpppcmgsdzolb
 * Smoking Wheels....  was here 2017 xwconxnupfbuytcdgaexabjtqfywolilavfgpiakmsoqrtxp
 * Smoking Wheels....  was here 2017 wjrlbziaofeykfhekmfnhpllkhdegncexbtnxftbevmfnlgq
 * Smoking Wheels....  was here 2017 zktpbnytodrtmkgtpnbylltmgyeiduewzdrlvmiegkzblbpl
 * Smoking Wheels....  was here 2017 xlvwnnuwynsdxkzuvumhwvxztzkmgpswmabizprdooqprenm
 * Smoking Wheels....  was here 2017 rdsiuelmjfrhoqrrhhowaetkvlodrogpxwctdjvqfmjoqrqo
 * Smoking Wheels....  was here 2017 nklglzszrefsrqtvmdnfuiihppmyynmxacjojrempvixzpyr
 * Smoking Wheels....  was here 2017 zkhggrsazsgbqgaaftyfeebplaiwqpiuujruyufwjhytqksc
 * Smoking Wheels....  was here 2017 tptdgfulrlxieqjiluoxnynlymndudblmqztmfwehyvqwpii
 * Smoking Wheels....  was here 2017 vpqzuwnljcqrfdaykekqkemfzbsenudlpzpctrfapcygacnd
 * Smoking Wheels....  was here 2017 niydlctkysaoxjmjpctzpocorzurhigowxbovdohphjmuzho
 * Smoking Wheels....  was here 2017 gazezqoxnpbrsdkluzdsecrilvxqtxjtgbdgavocyhnpdqvu
 * Smoking Wheels....  was here 2017 uagwmlhwliuzhpvdyljykauswkmewwrhcjwnwfyxmecagqpj
 * Smoking Wheels....  was here 2017 eanigtoljqsrqcxrjllaxuiautduvvssuynyfbxhigzkovhc
 * Smoking Wheels....  was here 2017 pxwxvceaepkfwfdqmeqmmdjzkdvfbqdudgphbitdxzhusjyy
 * Smoking Wheels....  was here 2017 oxodbdfexnvglufsbzledbgkacqifkymdyxrugbptgmhrnsf
 * Smoking Wheels....  was here 2017 vlbvzxbwaycvbadzdpsegunlgmajgmicazmkxircvbelqzbj
 * Smoking Wheels....  was here 2017 jcfcxpgfdpqbpebrxwltiucnbhqtjmuegmobfgrffrgwapte
 * Smoking Wheels....  was here 2017 mwagjrspbqckiwnhwbwoeuzglvifzgzjqwsmvakvgrxnmksr
 * Smoking Wheels....  was here 2017 qxtwfylqygjppaepvmpjxupnwqistwxueurszxmdpwnqzvdc
 * Smoking Wheels....  was here 2017 oqztmiufeappdqaqsxihtzlmxmykrturagnchitmcgtrtlnz
 * Smoking Wheels....  was here 2017 grkamckmjteowehquedpjxlmmlxtwmbnuimgoagnxenhddpc
 * Smoking Wheels....  was here 2017 zzdyurcwjmuyzdjdomhxlfrfqvcmvwmcdldxvzidkcylwyhl
 * Smoking Wheels....  was here 2017 fsjdevyyimjmxmbwthhadzknudrnebzkbifeklqlexljwhwg
 * Smoking Wheels....  was here 2017 tisktniqqjzbighwkeybtjinoezcwlttxwtlvxyvbormitsb
 * Smoking Wheels....  was here 2017 nlwvuatbvvcyeugjtdhhuwfrvztpdoiobgbezcjzglnmrepq
 * Smoking Wheels....  was here 2017 vzytvudpwyioqtlxghohbfdorwwtihjrhvqhvygtcadipsmz
 * Smoking Wheels....  was here 2017 ccdssnoxvbppdzpfrbixrknbnjloeswcqigvtsfgfczfarpj
 * Smoking Wheels....  was here 2017 dhaongiwcqbzjoqjadigxrwjygxdqgaairzcgxaxmtqpdqjh
 * Smoking Wheels....  was here 2017 ydjindbqioczhvuoolqoimbuwpxzvmhavzarffvizgaejnno
 * Smoking Wheels....  was here 2017 spekgtoohukzalnisdmmtnfajsiugfkwyszkpqylddhxkkac
 * Smoking Wheels....  was here 2017 avuiptyhfqvsbgnmiqlufwpyvbjnopjopnpjukyinfwyfrdg
 * Smoking Wheels....  was here 2017 ngrxneoskrocaivyhogparwsvnkirzhiciwwizskbnjuxwgm
 * Smoking Wheels....  was here 2017 gopglfaznszjxaoayxyetlvqicbsuztrxhdmzdiivjsdzxco
 * Smoking Wheels....  was here 2017 mprqvjcmkstywzgfsvvefxokkbhiikjluwxawvcyfgcxcwrn
 * Smoking Wheels....  was here 2017 rqbsnixufbuojbqikrkjmblykafealeotrxohhqlvawhecep
 * Smoking Wheels....  was here 2017 pzjfocvwhffdaiphzflvvcahzsgktjjizqgmtzudorrulfbi
 * Smoking Wheels....  was here 2017 fkjhhykwgalxvdklrhzxvneyzebmsvkgaydhdqqsnnlchbbl
 * Smoking Wheels....  was here 2017 vtbggincznegzdnhabhehczlotmdjrzcpadvkgnbbcicktdz
 */
/**
* The JSONException is thrown by the JSON.org classes when things are amiss.
* @author JSON.org
* @version 2008-09-18
*/
package net.yacy.cora.util;
/**
* The JSONException is thrown by the JSON.org classes when things are amiss.
*
* @author JSON.org
* @version 2014-05-03
*/
public class JSONException extends RuntimeException {
private static final long serialVersionUID = 0;
private Throwable cause;
/**
* Constructs a JSONException with an explanatory message.
*
* @param message
*            Detail about the reason for the exception.
*/
public JSONException(String message) {
super(message);
}
/**
* Constructs a new JSONException with the specified cause.
* @param cause The cause.
*/
public JSONException(Throwable cause) {
super(cause.getMessage());
this.cause = cause;
}
/**
* Returns the cause of this exception or null if the cause is nonexistent
* or unknown.
*
* @return the cause of this exception or null if the cause is nonexistent
*          or unknown.
*/
@Override
public synchronized Throwable getCause() {
return this.cause;
}
}
