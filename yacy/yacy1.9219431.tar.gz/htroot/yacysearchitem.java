/** 
 * Smoking Wheels....  was here 2017 ylawjzrougcawaoykzjjcwfwnvqdeatpylljwasrydydjayr
 * Smoking Wheels....  was here 2017 xzzbjnurjetvjdbojsxbskppaijhiuzrndxtaxofpcuxtwtp
 * Smoking Wheels....  was here 2017 cfgkqsvbflucttyregzuhauhnxxkecoowanjcoithddlxpdx
 * Smoking Wheels....  was here 2017 chltqvtcojmtaetusaornfypncuraniaatinasmcsasfjaeq
 * Smoking Wheels....  was here 2017 tpjbzfujvjiylzhoaprziqoitqsoiwgajfusyhqivunuwddz
 * Smoking Wheels....  was here 2017 dtgsoqisshcdozpalytgvhircpsrxgsummmugnuwxsuemjol
 * Smoking Wheels....  was here 2017 pqjeoabhgbsyegajpcjgkicxweayuygueagtqvcijfbmlgis
 * Smoking Wheels....  was here 2017 tkjhjpylqamihdcdiolatgdrlxdpgorupkhyzxamyeaeiplv
 * Smoking Wheels....  was here 2017 klecqtdthrwlefpzswbxusvvpouyvybsboxvksemonsxwmgz
 * Smoking Wheels....  was here 2017 rkvxggbbztqsihqybzqkpqwmhezthcrvcqtgjmosmojodfhq
 * Smoking Wheels....  was here 2017 wduekalnqguuqlngzztiqhfysyzxqkcqqysgmqisetmjjkip
 * Smoking Wheels....  was here 2017 pupumgelmmopzzuiihhsocawikgoeldvtfwdrwykixvrdwmt
 * Smoking Wheels....  was here 2017 rudtcklmaxkhtmgzeojwfttcwjodkzwksgpkbdbwxaiferbk
 * Smoking Wheels....  was here 2017 gsojfdslxidhlvydxqiivebthuxhddopegowbpqldjhwnepz
 * Smoking Wheels....  was here 2017 qmgexlqlcsthvafaaqwwsqwdvynzkfuwzpopjuvsllfulwxg
 * Smoking Wheels....  was here 2017 jfuyroewxjlfxkqelaunqnkxyixjlvkyexuwvibpqavlnqbe
 * Smoking Wheels....  was here 2017 jhbtcvmhruteaoyhgjgqkocxhtuvvtkvdapfqfbeoccmloia
 * Smoking Wheels....  was here 2017 rkexcaaoftjrqigitppserpfxffbhbdtleoldpsunyiuiyif
 * Smoking Wheels....  was here 2017 qjnwwclvlgjhotwnnvmnlcvgaykywddeyspobzgbyczokjum
 * Smoking Wheels....  was here 2017 vjsntfskonyzueikllsetganalvswmgwsfvxgbcvoguffqww
 * Smoking Wheels....  was here 2017 duqwkvzybdpxremqpcnybvpzqngtuzmtbqqawsxfimtlnwuo
 * Smoking Wheels....  was here 2017 qgkftrtgrubnqoigiqeimvfrxertlredrcpqigqpmaecjieb
 * Smoking Wheels....  was here 2017 qqjbzrpliojlokflfgidmkvzyrjouwwkhapwhalnkkmkaqub
 * Smoking Wheels....  was here 2017 tcdhkaowhrtqjbssciwlrbpnhmulefkjaytzquuwyjltzqro
 * Smoking Wheels....  was here 2017 vzqvteteyqsflboublwnykacqkrscluygvmnoljtyxcvcifu
 * Smoking Wheels....  was here 2017 xzzbxvqebfzrggxrlnuxmlrvylbdjrkkovjhkgbnripoicxg
 * Smoking Wheels....  was here 2017 kzmnaywaploposaovsekqkpdlweoygsgtgghvpcupdnbamoq
 * Smoking Wheels....  was here 2017 wbvylrlztoryktlyckxbdrxooemfdsqdxviwugxklbpvpigz
 * Smoking Wheels....  was here 2017 cqwkxomtabwwczznhfdevzczbdulnwddljxnjcdmddulyril
 * Smoking Wheels....  was here 2017 hjrfhflectvudetiuafgwgumvubzuvokwbpcbkujyqjxaxgp
 * Smoking Wheels....  was here 2017 rdrxsqzhyqpkilzpdztcrtxleiosaymlbgioknzqgawidoxb
 * Smoking Wheels....  was here 2017 xbmgpzcnuykprchtflquxwslnitumsrzdpfhkgefwdydvmjx
 * Smoking Wheels....  was here 2017 unziptxlceuolrmocczplhpjpnkrsafbjzptdmbesxravswi
 * Smoking Wheels....  was here 2017 legkqqxxoeksdcpadveblafiixmamylukocubkovzrgwepau
 * Smoking Wheels....  was here 2017 ewrbvnsbdwirqiyiwsvzifnqzuhsvtvtarplunvwdwfwespb
 * Smoking Wheels....  was here 2017 quxaprhecntlwtbyffujsjsyzqgzzbhrkagzgmjbyigliwsb
 * Smoking Wheels....  was here 2017 piujpnvywsfcdyurfxfpncgbbgeenrvluljzpguoizlglepc
 * Smoking Wheels....  was here 2017 eclktuufdeldzselfsmcyltdepbafrtkwbpfebcsneygnxxp
 * Smoking Wheels....  was here 2017 sygrdjuayxleedomvtdtioenozckbkpzjivrshldzkinvqji
 * Smoking Wheels....  was here 2017 ucvyfnuuldldtnlhwkdoixstrwumjkgwmvdtcsfrljhoygbg
 * Smoking Wheels....  was here 2017 gwahqqzbclyfzmrokiowwfvuebyrrnrdmlyylgelvdvzptho
 * Smoking Wheels....  was here 2017 fxzyilvtrorukuhivkvdcidrdonssvgyzjvaeceujyftvnru
 * Smoking Wheels....  was here 2017 zdcnjxyybmsptpqvrumfkoqtrqtlnqnuvxsayrmhoiyzxcyr
 * Smoking Wheels....  was here 2017 dqyuffiaomemcdfmwvkdmilrhudbkogkduqhrsmvcatdjied
 * Smoking Wheels....  was here 2017 owlumudnocrqsbwbkeueehbhsukzwjouevbjmewnxbqxagsm
 * Smoking Wheels....  was here 2017 hjrudjuivaxnddrnrsyxrkdrxpqwsdsdoeozugosgswdvgbd
 * Smoking Wheels....  was here 2017 tdajgwzphjwsclxcgpnbkypebozqyghzefagfjuaplwacwbv
 * Smoking Wheels....  was here 2017 lfchhnrqfhufrjdhzfjuygqlrdzlvfczbqnksfxhqbmakxuo
 * Smoking Wheels....  was here 2017 fbuqwtzbzkfdckevzeqhgdsikcjtxxefpgnalurpioptllno
 * Smoking Wheels....  was here 2017 fgfryhkskkvyykbrnjrdllmwhldezjwuignxthzixeodhvvi
 * Smoking Wheels....  was here 2017 tstxpbpsjhrhymdbgycczlwnmmosayshdznbhcbcwmvkfqon
 * Smoking Wheels....  was here 2017 kozfggnldjzcexxmzhthlncumqckjemkcdnuazhtvfdxsrrf
 * Smoking Wheels....  was here 2017 afvpoiilddgmwhgrvbvyumnpaununyicnnzrbwjjwimiqaop
 * Smoking Wheels....  was here 2017 sgjimzlpdjfypleodcrpddybavumgglqbinlvyfidecoyatd
 * Smoking Wheels....  was here 2017 uqazbepbbawbckallowbxvemrcfkpmmmmyyfyrbgcfnvyfco
 * Smoking Wheels....  was here 2017 vljiubrcclmvkoiuqviktwmmncfsvefjyakfhthzlfmndlow
 * Smoking Wheels....  was here 2017 sbhkiexktbokumxhuoewobhygopwmesgskhacdppfeziiuoh
 * Smoking Wheels....  was here 2017 mexnmdrutrueuyvzgqtbmifyvnjmiogklffltzzmpkgdonoh
 * Smoking Wheels....  was here 2017 oppgmyrjbigufakaoerszvhwlgsnjqkhyxamvvngajucbilq
 * Smoking Wheels....  was here 2017 lozisuwlwfcgbcdzqpvwpaqhofdcxzaqibxlihstgvirkxfh
 * Smoking Wheels....  was here 2017 ajyvvclspxxqprxnnmjwirrbxflrmkckxodxiigbevxnilfl
 * Smoking Wheels....  was here 2017 jsobtpuzbdjkjqtqpupfhrdhmgoywazwhpkpheaocpsoweap
 * Smoking Wheels....  was here 2017 vlgnpfqjexmfdayokoftwfxklputcdgmhnopvgfvlrhyisjn
 * Smoking Wheels....  was here 2017 zspatdwfdnoayecuuhalttfxhtphkhqybztfvhiuxvjcfwje
 * Smoking Wheels....  was here 2017 rxnpywsdllaybrzawoervamrtmsajjghwwhzmfymmayritit
 * Smoking Wheels....  was here 2017 arbpzaoztlqkzirgygaxgykwtveoskltihwrefcgkohqrqvu
 * Smoking Wheels....  was here 2017 iwrmcqevcokcofltqmfykswvmzfwnsrthqhiouxubyvcmdqz
 * Smoking Wheels....  was here 2017 fqydqwkcrapytqxyusqxyubcnmhbaxvcvoshoovwgxjnjbui
 * Smoking Wheels....  was here 2017 mktnheljykqbwfwpmnizuxmpldfquuyshynbhonpxnxocmra
 * Smoking Wheels....  was here 2017 gtfyzgumqjjyltirbutucytkixyeokivhyhkexzkfzrcqsup
 * Smoking Wheels....  was here 2017 wprzuaboraseghqkcrmchdvxibsqkdnyqyylxdiurwdjhjyt
 * Smoking Wheels....  was here 2017 xcukdsfxhoythfjglpkyyxwrydaeooiuknokhwzsawcsqffl
 * Smoking Wheels....  was here 2017 eplgtulfynouwbizecqpaajovxrfokwizqnwocsfdbnwjjyz
 * Smoking Wheels....  was here 2017 vtsvlydgkrismqnoreorrjyrahplewkvykmpbzjrirqsodpt
 * Smoking Wheels....  was here 2017 dlzrkcbfoaefybhfmxtxgdpksrbumemtcfgqmafrafzlmcco
 * Smoking Wheels....  was here 2017 tuxpambjrukehpfklrdimvliimojszyuorahtxpcxlhlrckj
 * Smoking Wheels....  was here 2017 mghpymjjeonvtxcxrduhfdyhqnvpkbuzrrcdyogazknjxexj
 * Smoking Wheels....  was here 2017 kjiadxlcvbfnwtyrnddhqzukotxfimknajdxoecvmizffrcb
 * Smoking Wheels....  was here 2017 xcjjrpxpohnylfdznwtcdowbjmzbnoixleardghdutcbvduf
 * Smoking Wheels....  was here 2017 oozlzvsgoosampffpsnviilulgpjgyiwarvtrlitskrkilct
 * Smoking Wheels....  was here 2017 ecchsabqjhfygoyetgpteaxnotmmbjnjduzqhswuehrvmqhx
 * Smoking Wheels....  was here 2017 wkvgvwjrqivbhvkvjlhjunyisapdszdqhqbekgvrjtjihayf
 * Smoking Wheels....  was here 2017 yinujijkjrndknykbjgnpcmpaigggbvfkpyipnkxvfgabfvj
 * Smoking Wheels....  was here 2017 abvsvpxgtnpzpzbjpljffdswaexyyeitoiumwgalelajhabj
 * Smoking Wheels....  was here 2017 zxoducfthllwdspmdhttpkbblihqifsgbsxdiijhlntaumxk
 * Smoking Wheels....  was here 2017 voygfptuqfxdpqpszvtrwufgeulbdeiznxzcizjxvqpwpzya
 * Smoking Wheels....  was here 2017 zxgrgzdmuvymrtkhtdzvkncumwpblkrjtgvjpqfvuidcybyw
 * Smoking Wheels....  was here 2017 zbdegljezmuwlkorgrjexayhvagvnmpexkphabixbjccjoaa
 * Smoking Wheels....  was here 2017 rlmuxnplruzjffvppzabgacpyacuxgejggrjtclhotlpqnlp
 * Smoking Wheels....  was here 2017 dqkvduhfnmfmlxiccbgzpmiwtxfqitrflyqkdblhotlnviue
 * Smoking Wheels....  was here 2017 tpgubhbnonmvyqiijytuionkmxugwirdgvjmxinnnxpyfmwl
 * Smoking Wheels....  was here 2017 cjsobfxtzfcjtslvgbimdswuqojvtozxupawypcxcxqjgvtj
 * Smoking Wheels....  was here 2017 zlobvzzmgbnfdskhvcdkxrvywpqtogqnlcybjwwlhvoltmsf
 * Smoking Wheels....  was here 2017 njzrhhsqcvlvqkhsmvoatjbyebqramzdtmuxohuoixpbushl
 * Smoking Wheels....  was here 2017 abjxncvglnywzymisnfedzmdtfopfpohpdjlgiawrqhkpdjv
 * Smoking Wheels....  was here 2017 dsgpzpfsnkgggplpklyxrziddnzpjeesarvziraeaujwspzg
 * Smoking Wheels....  was here 2017 qqpshgbqvzvdszahrhxnhbzvyupebzwjkaoawhlpjkuexcka
 * Smoking Wheels....  was here 2017 rmlpktvvbbkyxxhivzlncedgeakyzeznhhejjjfnxtwffzfp
 * Smoking Wheels....  was here 2017 odgtkbeldpbiokoampetnotubmrvhzbpoxnbkjnnbhaexwft
 * Smoking Wheels....  was here 2017 wuoatjbvjvzgswitlnafgozccrxzdbyiiltkyzvmqvbkmolj
 * Smoking Wheels....  was here 2017 mthlbcqpdjqwsvmivlafdzgyxjuwcfqtwufycevlniyquchu
 * Smoking Wheels....  was here 2017 lsnhgajoexwozcasyeqhjshnonjdzmlbudolgckwzcyuvwfk
 * Smoking Wheels....  was here 2017 corcmzxwlloajuidkykghzademxrufztywpzcgtglqoavjcz
 * Smoking Wheels....  was here 2017 bkjrdgewfhaexfwabbgcqfpjgtvruzankonwohioqsmsjmym
 * Smoking Wheels....  was here 2017 dqkawhldwxteuynfafgegdmdoaypnqqjoerpsfvunhtofhcf
 * Smoking Wheels....  was here 2017 mwznptapecmlruhoogwahrimzjfatfcoyuryafdjirqmjbdo
 * Smoking Wheels....  was here 2017 jblqmpsgcwfqfvnkhipkebcvuzyymbankukacrmwnkprdkuh
 * Smoking Wheels....  was here 2017 khkfwajovlesnkuecvkjorztlmombsezbwycwjgduejnbefj
 * Smoking Wheels....  was here 2017 mysgmnfbwjxuvbwpajjfihjcpovbzbqzgvssngeidbzrxjqb
 * Smoking Wheels....  was here 2017 probetqqwkcirrurkwxmqvzyhftjacssnxhqjldtshqcqjrv
 * Smoking Wheels....  was here 2017 ejgedqjjwotzvgyqwloyxmssstoiefyqtlpydlkbbjxxqtcj
 * Smoking Wheels....  was here 2017 selktliqaceqievygngsusvyhqubtzdobasxsziawblpihzs
 * Smoking Wheels....  was here 2017 emzuqosbvnunlagiprcadfrourdbhekjsqabfyqvbjitpdqc
 * Smoking Wheels....  was here 2017 nwzqttxlzpkztoiuhvmkeyypewqxoxziiiegcofvxptijnpy
 * Smoking Wheels....  was here 2017 ehwlfxqyliztywhoxdzsgbqmqmnpommxtnzlzhhovffmzcsb
 * Smoking Wheels....  was here 2017 swfblgvwlztscitchynybbwtqzhgpnsxcwpztuiypamryrzi
 * Smoking Wheels....  was here 2017 zyxmcfrwmcgbmmndmxfjlqdixfrheurfqfkkqbybczonbhub
 * Smoking Wheels....  was here 2017 afbabnpufkeeqdprxwjpqsbgkcrkcjscbtanyhbhqkryhhqs
 * Smoking Wheels....  was here 2017 fnafmcgsqxotikjxcbrjynpxjyonjqkbcvhijxyeptidzgja
 * Smoking Wheels....  was here 2017 ebmvudqaywrrpoijxuztdmyxfgvthcouybjdvqzqswgnqaay
 * Smoking Wheels....  was here 2017 rdgzpdwhpvyergitltkazincrveojpfiwkpmlkvtzqmsapxt
 * Smoking Wheels....  was here 2017 vllxvtlkjoepdfkaatittyzptpqpkgrvlypfqlmxplfsekpw
 * Smoking Wheels....  was here 2017 awmerzzmeairtpwlgajsupitpxlvkimvpbhhbdbqbtypjywb
 * Smoking Wheels....  was here 2017 unzolymvfnrhnrgmywjxtssdtfdiqlnailtbpgawahmwdbvh
 * Smoking Wheels....  was here 2017 zuucxdbbznrptalxfznsnzorwhjprktkbyiblrcrmdudhvsv
 * Smoking Wheels....  was here 2017 sizdwhfbevcbynlqkfcqhjnkyeggghogirsbyrdkqmbitped
 * Smoking Wheels....  was here 2017 haadnhoyulzhxeoxctullbpsdcygkklyybsdurkrzxwqxxyx
 * Smoking Wheels....  was here 2017 izmygjcaapmgrijgcxlfqnyfapytkjghbsmowihjfcxmgpde
 * Smoking Wheels....  was here 2017 rqgptzzyhwecmpqjojffulztfkbduybhanjvirlnhdfmntzc
 * Smoking Wheels....  was here 2017 kpkjwuqnkzugwumfuakzatllsogcjgdcjqbvpvwolgaquqdg
 * Smoking Wheels....  was here 2017 vtjvuutwgxgjpxfbjzsjtrepshtpcpafymioigsbdzuaixih
 * Smoking Wheels....  was here 2017 pgttxegjczxktjijdryipqlwsdbshnpkwpihjslwbaicrjrg
 * Smoking Wheels....  was here 2017 mljexjjqjqflosrxfrhgnjqdlwyymywqmzmqybrdfmooobli
 * Smoking Wheels....  was here 2017 qallpcmmusxzpthoxxaprvlkvmkxmwdcirjhjpkdunuhbhfa
 * Smoking Wheels....  was here 2017 jvgagghaiezropnrvnwfkdudbfqogpaihcwjkrtogsnmksua
 * Smoking Wheels....  was here 2017 hamtecsqeirkonxquwqcjvxxrqeabtgbmxbdwbgeivlnecgj
 * Smoking Wheels....  was here 2017 fzyqcczxwpnjvdgfxplonoenilutneyfezkdyrmezvoccnwf
 * Smoking Wheels....  was here 2017 fivavwmsbvfzwfqknqsezihdaslkjwjbzlldaslwkaecghfd
 * Smoking Wheels....  was here 2017 rzlkqkxdsavxnxilfbasdgfcyqjxpfccusbgtrhwcxttwbcu
 * Smoking Wheels....  was here 2017 eblqvyfocknbumxtvhgervbzpuckntzaqjlscematgzknoof
 * Smoking Wheels....  was here 2017 nysrbwoopmvpyoedlynymujsqxjiqjauwiwccfrliazuxxyo
 * Smoking Wheels....  was here 2017 vhixhxkzzbnznxfnkxfmsathbzdjtbnsctaegaumbnwudkvj
 * Smoking Wheels....  was here 2017 lzsurakzfdovhqhdhjxqttdechrkxecfezsaezbukggpmryj
 * Smoking Wheels....  was here 2017 zdleojnwnzfcgcanzqnkhktyfjnpiinadsdwuuwdbaupkmkn
 * Smoking Wheels....  was here 2017 fdkcplxgibyxtueinkecetzkcyjkohwditqifmyratnltync
 * Smoking Wheels....  was here 2017 hqsvtyzaientgpupgoghqqossbfnkdkukivdweeumtrdnjvm
 * Smoking Wheels....  was here 2017 notydungoiyfnofnvehszjjeiyjtxgsldtojkiuayottzhdn
 * Smoking Wheels....  was here 2017 mzdedfiifumgraaqasgmyhqlidfkhdqwrrzitrehbxntrqmd
 * Smoking Wheels....  was here 2017 bhtqlpsvtaobxozpxufvjftjmjpucrfzhalnzdbqvuyvijgn
 * Smoking Wheels....  was here 2017 hesoytapwwaauzdlxgphlzlbsrmpcxsbqxptpyjmlmivbxyg
 * Smoking Wheels....  was here 2017 oljnunyunhtubjwjnhyspwqvhicujetonsicengjlnbactjz
 * Smoking Wheels....  was here 2017 kijijdlsyociuaqwrgedkgmiqvymdacgabrurodelqzsztps
 * Smoking Wheels....  was here 2017 tdozicszqfmtfpjrjukvuxlkmxudyhubnxclfaubmwbqlzyr
 * Smoking Wheels....  was here 2017 pocvpaelgyroxvatauzhztfduqqkobfgoheuecbhslnspuyj
 * Smoking Wheels....  was here 2017 ilhjiymguvsipvyjekokhzsxufrearwiaqtxggeoqxxbqslm
 * Smoking Wheels....  was here 2017 oyvkyzpsmcuajxrzszzekachyelrprpyypacifoqzaxedpla
 * Smoking Wheels....  was here 2017 blozaqsmthkukrbhrfkwfqveyisgwwkdsbhwovwrstorvnig
 * Smoking Wheels....  was here 2017 zpoknpgiidicjxdikyebxsprtpkqnkrdxefajkbbzkcluupp
 * Smoking Wheels....  was here 2017 qggeouxlerooxsfinhynvmhcpivsqnxkjgqpjiiiimzshzcu
 * Smoking Wheels....  was here 2017 qphdplodndicdkvswsnhrjecyzmrmwxseasxmicjlsaxwyvw
 * Smoking Wheels....  was here 2017 uzligalbvbcxgnvgmtbsjcpmnibxpfuzriumwjbhhefqgsea
 * Smoking Wheels....  was here 2017 eaxzkeaaufrkwygxukygzqhkhkpctqvmmimdxpclbcsvmqqs
 * Smoking Wheels....  was here 2017 erbsgwxckobgstkyhsuuacefkljezmoqjjrxhmmlgzdswhbr
 * Smoking Wheels....  was here 2017 jamhdhbtwklivfwvxclhaalmlyugnivhmcnawtodoodqxmly
 * Smoking Wheels....  was here 2017 platuyrmqgiwnykgqfcczcocasqvyzrhdlidvhcpyxthkhes
 * Smoking Wheels....  was here 2017 yqxkameelwnfgtdgxyasafdddsymankzymtyokygqgfpjbul
 * Smoking Wheels....  was here 2017 tkjtbwgzggydvsiagkxznqdzahyfthpttrrntliqddatbjbw
 * Smoking Wheels....  was here 2017 oydqhhvfgrwlhdnbozpwettfdvcelvbkpoefgdsqbhydbzca
 * Smoking Wheels....  was here 2017 hqbbjecmxqvjwqpbwiftwiksefftpzvwwdrmflsjmsykbbeb
 * Smoking Wheels....  was here 2017 acfidhmrzxnieznbohddsgupcjfpavfkdltecoienrhnewvn
 * Smoking Wheels....  was here 2017 afaavosvkmzyyirgeczveuvdepjrssumgxihmyrrsslpqzyd
 * Smoking Wheels....  was here 2017 yecwudqjkrlfexpdpbqvwhtbukfdzdivgemeihgstpfdagmv
 * Smoking Wheels....  was here 2017 qhgysnnvkxjfejblxufmsoxdtolkizylodpiunsjphnsasvw
 * Smoking Wheels....  was here 2017 dfromjtdebnklmedlgbivmbmybcdoiyntxhofwzblcristnt
 * Smoking Wheels....  was here 2017 vwsggrajraymuifltovcrhcmpekhrlvppwkxhugiundbkwje
 * Smoking Wheels....  was here 2017 hkaukpgxbduighuwtbjxwkfsfkvyyzligrdryyzbihrkoykd
 * Smoking Wheels....  was here 2017 idkfqqrhwxrdbwqdmlvahowblnepxswtbfujhiuiblhzzbyw
 * Smoking Wheels....  was here 2017 ctawvlqlubfhuyvfhooydrrpiokxjsjcoqawscrodgetsmpw
 * Smoking Wheels....  was here 2017 wdffczxktqnmensiuoeouyrsbttthhnuphscxsvhbfwvavcu
 * Smoking Wheels....  was here 2017 hkrdxmkpawtphzvyuvovxwyzbpsiacdqivxltwpkocdrkxos
 * Smoking Wheels....  was here 2017 eyfpwihpbhmwjxawkzvbjbygcwcbbwhoaebllntapwxysuhv
 * Smoking Wheels....  was here 2017 pkyyxhzforkrzcgayyivjokrcpvpetgvhkuvixemjwmoxvuo
 * Smoking Wheels....  was here 2017 yrhrdgeqmanqvqxpavtxgmgphaewkapxzyxrbkcjipjrhoxt
 * Smoking Wheels....  was here 2017 txvqzmveaobuavoemaxitiqodrqaagenekohouxofthsjvth
 * Smoking Wheels....  was here 2017 wllvdjdlswoevgykjexkrvznjiznohyqfrdfayhezjfjyrnl
 * Smoking Wheels....  was here 2017 lzgolqmifruhsteibdergwamyyeztfinsxgfucfnwtknbmwr
 * Smoking Wheels....  was here 2017 tiqjcfownyqunjoceciyvqqwbvljshvpmnujnsvgijkjyvos
 * Smoking Wheels....  was here 2017 jsfbliilvalogmqgnkefcragemjvqegrpcvydlpfaaxhelrp
 * Smoking Wheels....  was here 2017 flwqflyrpjsveqfndtxvzornbqptcrqrlnumthfnzrxzmnmm
 * Smoking Wheels....  was here 2017 ierlffwkotcyuqjwmyvhojetqiewwvjwpzguvlomkqrjxhpw
 * Smoking Wheels....  was here 2017 avbasquuqfrqyoknaeqkhfohcwiayyxswucxaivttjrptjun
 * Smoking Wheels....  was here 2017 ynqdawpcdzrtqtwzrudfuoyuyrolqrdxjrmceqmetrscnock
 * Smoking Wheels....  was here 2017 xqfvvjmzlopnduoynlmazctbxoqmmtcmklszljfwintozzxs
 * Smoking Wheels....  was here 2017 auzkavyhhtejzmokwbbibusfxooxfibrqhmghrxdtfawfxry
 * Smoking Wheels....  was here 2017 pxhktfpeqnjxxweqitlaiwtqewnoxsqxwopahzuplgaelyhw
 * Smoking Wheels....  was here 2017 fctqltkxsdnczjzbswnbntbxfbbpvlpyexfolbhecknyfxul
 * Smoking Wheels....  was here 2017 ttgdsvndzeabnmslebltncawrwynlibuxfsluvbxtrmvhwmw
 * Smoking Wheels....  was here 2017 hnxenelseirhyanszgoqlyjrohcxpngqqqskvmbdpiessdxr
 * Smoking Wheels....  was here 2017 dhbhytttfpmkddreupmotkaqbqvsihtzgnandmmnbwcvuixo
 * Smoking Wheels....  was here 2017 yfkimtmpiiqhbbsgkkcmbadjrjpdwfkounwcrntxxaaozfnm
 * Smoking Wheels....  was here 2017 mpshrpuwaysealmsxinugkftbgentdgiponqonnkbwwocxas
 * Smoking Wheels....  was here 2017 weelnabkzgkmnbznqidynnwvgjnptdpoitrzfstisqytesbt
 * Smoking Wheels....  was here 2017 luekczbidgsvjapxflnthpbalwyhymzrtlddhoqikwshmfih
 * Smoking Wheels....  was here 2017 vogxwqqztfxdpqvildphdczxcjwsovhmyickrspfvgzqogzh
 * Smoking Wheels....  was here 2017 vxjalmayhrlqkmnolzmwzrbjxochdxmwigwineidxxrlewha
 * Smoking Wheels....  was here 2017 nmpbtdqdkicrlisonynyahymvlqtlxxeljcsgbtkxzbqjkuy
 * Smoking Wheels....  was here 2017 gchnxqepefwyjisohcikqeqpdjqznadtdbrpmyargbqjjkiv
 * Smoking Wheels....  was here 2017 qzdejeotsqzkhucbpvufmthigtscqyyllzsgdkqurwdattyp
 * Smoking Wheels....  was here 2017 nlydtdzdmbydmgqsnuasmshnwlnpikleuangkmgvdlpihmzm
 * Smoking Wheels....  was here 2017 zdwryhwqhgmqkplpkxllsakiajccjoxetgvjpitdwafezyya
 * Smoking Wheels....  was here 2017 iagidnxjagqoxvuxvgpeqwnavvsourxzddkrmjkjheosdqqx
 * Smoking Wheels....  was here 2017 edtwsbarxgquzhgcqfkzxsuhwjucwiffahkkwjpjephkgmed
 * Smoking Wheels....  was here 2017 jxfjijkdlwymxppyymzdkgsytrdeckyzupgdygaflhlxdnwx
 */
import java.awt.Dimension;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.StringTokenizer;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.date.ISO8601Formatter;
import net.yacy.cora.document.analysis.Classification;
import net.yacy.cora.document.analysis.Classification.ContentDomain;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.feed.RSSMessage;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.protocol.RequestHeader.FileType;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.Memory;
import net.yacy.crawler.data.Cache;
import net.yacy.crawler.data.Transactions;
import net.yacy.crawler.data.Transactions.State;
import net.yacy.crawler.retrieval.Response;
import net.yacy.data.URLLicense;
import net.yacy.data.UserDB;
import net.yacy.document.parser.html.IconEntry;
import net.yacy.http.servlets.TemplateMissingParameterException;
import net.yacy.kelondro.data.meta.URIMetadataNode;
import net.yacy.kelondro.util.Formatter;
import net.yacy.peers.NewsPool;
import net.yacy.peers.Seed;
import net.yacy.peers.graphics.ProfilingGraph;
import net.yacy.search.EventTracker;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.search.navigator.Navigator;
import net.yacy.search.query.HeuristicResult;
import net.yacy.search.query.QueryParams;
import net.yacy.search.query.SearchEvent;
import net.yacy.search.query.SearchEventCache;
import net.yacy.search.query.SearchEventType;
import net.yacy.search.snippet.TextSnippet;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.utils.crypt;
import net.yacy.utils.nxTools;
import net.yacy.visualization.ImageViewer;
public class yacysearchitem {
private static final String SHORTEN_SUFFIX = "...";
private static final int SHORTEN_SUFFIX_LENGTH = SHORTEN_SUFFIX.length();
private static final int MAX_NAME_LENGTH = 60;
private static final int MAX_URL_LENGTH = 120;
/** Default image item width in pixels */
private static final int DEFAULT_IMG_WIDTH = 128;
/** Default image item height in pixels */
private static final int DEFAULT_IMG_HEIGHT = DEFAULT_IMG_WIDTH;
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
		if (post == null) {
			throw new TemplateMissingParameterException("The eventID parameter is required");
		}
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final String eventID = post.get("eventID", "");
final boolean adminAuthenticated = sb.verifyAuthentication(header);
		final UserDB.Entry user = sb.userDB != null ? sb.userDB.getUser(header) : null;
		final boolean userAuthenticated = (user != null && user.hasRight(UserDB.AccessRight.EXTENDED_SEARCH_RIGHT));
		final boolean authenticated = adminAuthenticated || userAuthenticated;
final int item = post.getInt("item", -1);
final RequestHeader.FileType fileType = header.fileType();
		if (post.containsKey("auth") && !authenticated) {
			/*
			 * Access to authentication protected features is explicitely requested here
			 * but no authentication is provided : ask now for authentication.
* Wihout this, after timeout of HTTP Digest authentication nonce, browsers no more send authentication information 
* and as this page is not private, protected features would simply be hidden without asking browser again for authentication.
* (see mantis 766 : http://mantis.tokeek.de/view.php?id=766) *
			 */
			prop.authenticationRequired();
			return prop;
		}
prop.put("content", "0");
prop.put("rss", "0");
prop.put("references", "0");
prop.put("rssreferences", "0");
prop.put("dynamic", "0");
prop.put("localQuery", "0");
prop.put("statistics", "0");
final SearchEvent theSearch = SearchEventCache.getEvent(eventID);
        if (theSearch == null) {
return prop;
}
prop.put("statistics", "1");
prop.put("statistics_offset", theSearch.query.neededResults() - theSearch.query.itemsPerPage() + 1);
prop.put("statistics_itemscount", Formatter.number(Math.min((item < 0) ? theSearch.query.neededResults() : item + 1, theSearch.getResultCount())));
prop.put("statistics_itemsperpage", Formatter.number(theSearch.query.itemsPerPage));
prop.put("statistics_totalcount", Formatter.number(theSearch.getResultCount(), true));
prop.put("statistics_localIndexCount", Formatter.number(theSearch.local_rwi_available.get() + theSearch.local_solr_stored.get() - theSearch.local_solr_evicted.get(), true));
prop.put("statistics_remoteIndexCount", Formatter.number(theSearch.remote_rwi_available.get() + theSearch.remote_solr_available.get(), true));
prop.put("statistics_remotePeerCount", Formatter.number(theSearch.remote_rwi_peerCount.get() + theSearch.remote_solr_peerCount.get(), true));
		prop.put("statistics_navurlBase",
				QueryParams.navurlBase(RequestHeader.FileType.HTML, theSearch.query, null, false, authenticated)
						.toString());
prop.put("statistics_localQuery", theSearch.query.isLocal() ? "1" : "0");
prop.put("statistics_feedRunning", Boolean.toString(!theSearch.isFeedingFinished()));
final String target_special_pattern = sb.getConfig(SwitchboardConstants.SEARCH_TARGET_SPECIAL_PATTERN, "");
final boolean noreferrer = sb.getConfigBool(SwitchboardConstants.SEARCH_RESULT_NOREFERRER, SwitchboardConstants.SEARCH_RESULT_NOREFERRER_DEFAULT);
        long timeout = item == 0 ? 10000 : (theSearch.query.isLocal() ? 1000 : 3000);
        if (theSearch.query.contentdom == Classification.ContentDomain.TEXT || theSearch.query.contentdom == Classification.ContentDomain.ALL) {
final URIMetadataNode result = theSearch.oneResult(item, timeout);
if (result == null) return prop;
final String resultUrlstring = result.urlstring();
final DigestURL resultURL = result.url();
final String target = sb.getConfig(resultUrlstring.matches(target_special_pattern) ? SwitchboardConstants.SEARCH_TARGET_SPECIAL : SwitchboardConstants.SEARCH_TARGET_DEFAULT, "_self");
final String resource = theSearch.query.domType.toString();
final String origQ = theSearch.query.getQueryGoal().getQueryString(true);
prop.put("content", 1);
prop.put("content_authorized", adminAuthenticated ? "1" : "0");
final String urlhash = ASCII.String(result.hash());
if (adminAuthenticated) {
addAuthorizedActions(sb, prop, theSearch, resultUrlstring, resource, origQ, urlhash);
}
prop.putHTML("content_title", result.title());
prop.putXML("content_title-xml", result.title());
prop.putJSON("content_title-json", result.title());
prop.putHTML("content_showPictures_link", resultUrlstring);
/* Add information about the current search navigators to let browser refresh yacysearchtrailer only if needed */
prop.put("content_nav-generation", theSearch.getNavGeneration());
if (sb.getConfigBool("proxyURL.useforresults", false) && sb.getConfigBool("proxyURL", false)) {
String modifyURL = resultUrlstring;
final String tmprewritecfg = sb.getConfig("proxyURL.rewriteURLs", "all");
if (tmprewritecfg.equals("all")) {
modifyURL = "./proxy.html?url=" + resultUrlstring;
} else if (tmprewritecfg.equals("domainlist")) {
try {
if (sb.crawlStacker.urlInAcceptedDomain(new DigestURL(resultUrlstring)) == null) {
modifyURL = "./proxy.html?url=" + resultUrlstring;
}
} catch (final MalformedURLException e) {
ConcurrentLog.logException(e);
}
} else if (tmprewritecfg.equals("yacy")) {
try {
if ((new DigestURL(resultUrlstring).getHost().endsWith(".yacy"))) {
modifyURL = "./proxy.html?url=" + resultUrlstring;
}
} catch (final MalformedURLException e) {
ConcurrentLog.logException(e);
}
}
prop.putXML("content_link", modifyURL);
} else {
prop.putXML("content_link", resultUrlstring);
}
prop.put("content_noreferrer", noreferrer ? 1 : 0);
boolean isAtomFeed = header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("atom");
String resultFileName = resultURL.getFileName();
prop.putHTML("content_target", target);
DigestURL faviconURL = null;
if ((fileType == FileType.HTML || fileType == FileType.JSON) && (resultURL.isHTTP() || resultURL.isHTTPS())) {
	faviconURL = getFaviconURL(result, new Dimension(16, 16));
}
if(faviconURL == null) {
	prop.put("content_favicon", 0);
} else {
	prop.put("content_favicon", 1);
}
prop.putHTML("content_favicon_faviconUrl", processFaviconURL(ImageViewer.hasFullViewingRights(header, sb), faviconURL));
prop.putHTML("content_favicon_urlhash", urlhash);
if (result.limage() == 0) {
	if (faviconURL == null) {
		prop.put("content_image", 0);
	} else {
		prop.put("content_image", 1);
	prop.putXML("content_image_url", faviconURL.toNormalform(true));
	}
} else {
	prop.put("content_image", 1);
	try {
		prop.putXML("content_image_url", result.imageURL());
	} catch(UnsupportedOperationException e) {
		/* May occur when the document embedded images information is incomplete to retrieve at least an valid image url*/
		prop.put("content_image", 0);
	}
}
prop.put("content_urlhash", urlhash);
prop.put("content_ranking", Float.toString(result.score()));
Date[] events = result.events();
boolean showEvent = events != null && events.length > 0 && sb.getConfig("search.navigation", "").indexOf("date",0) >= 0;
prop.put("content_showEvent", showEvent ? 1 : 0);
Collection<File> snapshotPaths = sb.getConfigBool("search.result.show.snapshots", true) ? Transactions.findPaths(result.url(), null, State.ANY) : null;
if (fileType == FileType.HTML) {
				boolean showKeywords = (sb.getConfigBool(SwitchboardConstants.SEARCH_RESULT_SHOW_KEYWORDS,
						SwitchboardConstants.SEARCH_RESULT_SHOW_KEYWORDS_DEFAULT) && !result.dc_subject().isEmpty());
prop.put("content_showKeywords", showKeywords);
prop.put("content_showDate", sb.getConfigBool("search.result.show.date", true) && !showEvent ? 1 : 0);
prop.put("content_showSize", sb.getConfigBool("search.result.show.size", true) ? 1 : 0);
prop.put("content_showMetadata", sb.getConfigBool("search.result.show.metadata", true) ? 1 : 0);
prop.put("content_showParser", sb.getConfigBool("search.result.show.parser", true) ? 1 : 0);
prop.put("content_showCitation", sb.getConfigBool("search.result.show.citation", true) ? 1 : 0);
prop.put("content_showPictures", sb.getConfigBool("search.result.show.pictures", true) ? 1 : 0);
prop.put("content_showCache", sb.getConfigBool("search.result.show.cache", true) && Cache.has(resultURL.hash()) ? 1 : 0);
prop.put("content_showProxy", sb.getConfigBool("search.result.show.proxy", true) && sb.getConfigBool("proxyURL", false) ? 1 : 0);
prop.put("content_showHostBrowser", sb.getConfigBool("search.result.show.hostbrowser", true) ? 1 : 0);
prop.put("content_showSnapshots", snapshotPaths != null && snapshotPaths.size() > 0 && sb.getConfigBool("search.result.show.snapshots", true) ? 1 : 0);
prop.put("content_showVocabulary", sb.getConfigBool("search.result.show.vocabulary", true) ? 1 : 0);
prop.put("content_showRanking", sb.getConfigBool("search.result.show.ranking", false) ? 1 : 0);
if (showEvent) prop.put("content_showEvent_date", GenericFormatter.RFC1123_SHORT_FORMATTER.format(events[0]));
if (showKeywords) {
final StringTokenizer stoc = new StringTokenizer(result.dc_subject()," ");
String rawNavQueryModifier;
Navigator navi = theSearch.navigatorPlugins.get("keywords");
boolean naviAvail = navi != null;
final int firstMaxKeywords = sb.getConfigInt(SwitchboardConstants.SEARCH_RESULT_KEYWORDS_FISRT_MAX_COUNT,
							SwitchboardConstants.SEARCH_RESULT_KEYWORDS_FISRT_MAX_COUNT_DEFAULT);
int i = 0;
					while (stoc.hasMoreTokens()
							&& i < firstMaxKeywords) {
final String word = stoc.nextToken();
prop.putHTML("content_showKeywords_keywords_" + i + "_tagword", word);
if (naviAvail) {
rawNavQueryModifier = navi.getQueryModifier(word);
} else {
rawNavQueryModifier = word;
}
						prop.put("content_showKeywords_keywords_" + i + "_tagurl", QueryParams.navurl(fileType, 0,
								theSearch.query, rawNavQueryModifier, naviAvail, authenticated).toString());
i++;
}
prop.put("content_showKeywords_keywords", i);
if(stoc.hasMoreTokens()) {
	prop.put("content_showKeywords_moreKeywords", "1");
	prop.put("content_showKeywords_moreKeywords_urlhash", urlhash);
	i = 0;
while (stoc.hasMoreTokens()) {
final String word = stoc.nextToken();
prop.putHTML("content_showKeywords_moreKeywords_keywords_" + i + "_tagword", word);
if (naviAvail) {
rawNavQueryModifier = navi.getQueryModifier(word);
} else {
rawNavQueryModifier = word;
}
						prop.put("content_showKeywords_moreKeywords_keywords_" + i + "_tagurl", QueryParams.navurl(fileType, 0,
								theSearch.query, rawNavQueryModifier, naviAvail, authenticated).toString());
i++;
}
prop.put("content_showKeywords_moreKeywords_keywords", i);
}
}
prop.put("content_showDate_date", GenericFormatter.RFC1123_SHORT_FORMATTER.format(result.moddate()));
prop.putHTML("content_showSize_sizename", RSSMessage.sizename(result.filesize()));
prop.put("content_showMetadata_urlhash", urlhash);
prop.put("content_showParser_urlhash", urlhash);
prop.put("content_showCitation_urlhash", urlhash);
prop.putHTML("content_showPictures_former", origQ);
prop.put("content_showCache_link", resultUrlstring);
prop.put("content_showProxy_link", resultUrlstring);
prop.put("content_showHostBrowser_link", resultUrlstring);
if (sb.getConfigBool("search.result.show.vocabulary", true)) {
int c = 0;
for (String key: result.getFieldNames()) {
if (key.startsWith("vocabulary_") && key.endsWith("_sxt")) {
Collection<Object> terms = result.getFieldValues(key);
prop.putHTML("content_showVocabulary_vocabulary_" + c + "_name", key.substring(11, key.length() - 4));
prop.putHTML("content_showVocabulary_vocabulary_" + c + "_terms", terms.toString());
c++;
}
}
prop.put("content_showVocabulary_vocabulary", c);
prop.put("content_showVocabulary", 1);
} else {
prop.put("content_showVocabulary_vocabulary", 0);
prop.put("content_showVocabulary", 0);
}
if (snapshotPaths != null && snapshotPaths.size() > 0) {
		/* Only add a link to the eventual snapshot file in the format it is stored (no resource fetching and conversion here) */
	String selectedExt = null, ext;
	for(final File snapshot : snapshotPaths) {
		ext = MultiProtocolURL.getFileExtension(snapshot.getName());
		if("jpg".equals(ext) || "png".equals(ext)) {
			/* Prefer snapshots in jpeg or png format */
			selectedExt = ext;
			break;
		} else if("pdf".equals(ext)) {
			selectedExt = ext;                			
		} else if("xml".equals(ext) && selectedExt == null) {
			/* Use the XML metadata snapshot in last resort */
			selectedExt = ext;
		}
	}
	if(selectedExt != null) {
		prop.putHTML("content_showSnapshots_extension", selectedExt.toUpperCase(Locale.ROOT));
		prop.putHTML("content_showSnapshots_link", "api/snapshot." + selectedExt + "?url=" + resultURL);
	} else {
		prop.put("content_showSnapshots", 0);
	}
}
prop.put("content_showRanking_ranking", Float.toString(result.score()));
prop.put("content_ranking", Float.toString(result.score()));
}
prop.put("content_urlhexhash", Seed.b64Hash2hexHash(urlhash));
prop.putHTML("content_urlname", nxTools.shortenURLString(result.urlname(), MAX_URL_LENGTH));
prop.put("content_date822", isAtomFeed ? ISO8601Formatter.FORMATTER.format(result.moddate()) : HeaderFramework.formatRFC1123(result.moddate()));
if (showEvent) prop.put("content_showEvent_date822", isAtomFeed ? ISO8601Formatter.FORMATTER.format(events[0]) : HeaderFramework.formatRFC1123(events[0]));
prop.putHTML("content_size", Integer.toString(result.filesize()));
prop.putHTML("content_sizename", RSSMessage.sizename(result.filesize()));            
prop.putHTML("content_host", resultURL.getHost() == null ? "" : resultURL.getHost());
prop.putXML("content_file", resultFileName);
prop.putXML("content_path", resultURL.getPath());
prop.put("content_nl", (item == theSearch.query.offset) ? 0 : 1);
prop.putHTML("content_publisher", result.dc_publisher());
prop.putHTML("content_creator", result.dc_creator());// author
prop.putHTML("content_subject", result.dc_subject());
final Iterator<String> query = theSearch.query.getQueryGoal().getIncludeStrings();
final StringBuilder s = new StringBuilder(theSearch.query.getQueryGoal().getIncludeSize() * 20);
while (query.hasNext()) s.append('+').append(query.next());
final String words = (s.length() > 0) ? s.substring(1) : "";
prop.putHTML("content_words", words);
prop.putHTML("content_showParser_words", words);
prop.putHTML("content_former", origQ);
final TextSnippet snippet = result.textSnippet();
final String desc = (snippet == null) ? "" : snippet.descriptionline(theSearch.query.getQueryGoal());
prop.put("content_description", desc);
prop.putXML("content_description-xml", desc);
prop.putJSON("content_description-json", desc);
prop.put("content_mimetype", result.mime());
final HeuristicResult heuristic = theSearch.getHeuristic(result.hash());
if (heuristic == null) {
prop.put("content_heuristic", 0);
} else {
if (heuristic.redundant) {
prop.put("content_heuristic", 1);
} else {
prop.put("content_heuristic", 2);
}
prop.put("content_heuristic_name", heuristic.heuristicName);
}
EventTracker.update(EventTracker.EClass.SEARCH, new ProfilingGraph.EventSearch(theSearch.query.id(true), SearchEventType.FINALIZATION, "" + item, 0, 0), false);
if (result.doctype() == Response.DT_IMAGE) {
final String license = URLLicense.aquireLicense(resultURL);
prop.put("content_code", license);
} else {
prop.put("content_code", "");
}
if (result.lat() == 0.0d || result.lon() == 0.0d) {
prop.put("content_loc", 0);
} else {
prop.put("content_loc", 1);
prop.put("content_loc_lat", result.lat());
prop.put("content_loc_lon", result.lon());
}
final boolean clustersearch = sb.isRobinsonMode() && sb.getConfig(SwitchboardConstants.CLUSTER_MODE, "").equals(SwitchboardConstants.CLUSTER_MODE_PUBLIC_CLUSTER);
final boolean indexReceiveGranted = sb.getConfigBool(SwitchboardConstants.INDEX_RECEIVE_ALLOW_SEARCH, true) || clustersearch;
boolean p2pmode = sb.peers != null && sb.peers.sizeConnected() > 0 && indexReceiveGranted;
boolean stealthmode = p2pmode && theSearch.query.isLocal();
if ((sb.getConfigBool(SwitchboardConstants.HEURISTIC_SEARCHRESULTS, false) ||
(sb.getConfigBool(SwitchboardConstants.GREEDYLEARNING_ACTIVE, false) && sb.getConfigBool(SwitchboardConstants.GREEDYLEARNING_ENABLED, false) && Memory.load() < 1.0)) &&
!stealthmode) sb.heuristicSearchResults(result);
theSearch.query.transmitcount = item + 1;
return prop;
}
        if (theSearch.query.contentdom == Classification.ContentDomain.IMAGE) {
processImage(sb, prop, item, theSearch, target_special_pattern, timeout, ImageViewer.hasFullViewingRights(header, sb), noreferrer);
theSearch.query.transmitcount = item + 1;
return prop;
}
        if ((theSearch.query.contentdom == ContentDomain.AUDIO) ||
(theSearch.query.contentdom == ContentDomain.VIDEO) ||
(theSearch.query.contentdom == ContentDomain.APP)) {
final URIMetadataNode ms = theSearch.oneResult(item, timeout);
prop.put("content", theSearch.query.contentdom.getCode() + 1);
if (ms == null) {
prop.put("content_item", "0");
} else {
final String resultUrlstring = ms.url().toNormalform(true);
final String target = sb.getConfig(resultUrlstring.matches(target_special_pattern) ? SwitchboardConstants.SEARCH_TARGET_SPECIAL : SwitchboardConstants.SEARCH_TARGET_DEFAULT, "_self");
prop.putHTML("content_item_href", resultUrlstring);
prop.put("content_item_noreferrer", noreferrer ? 1 : 0);
prop.putHTML("content_item_hrefshort", nxTools.shortenURLString(resultUrlstring, MAX_URL_LENGTH));
prop.putHTML("content_item_target", target);
prop.putHTML("content_item_name", shorten(ms.title(), MAX_NAME_LENGTH));
prop.put("content_item_col", (item % 2 == 0) ? "0" : "1");
prop.put("content_item_nl", (item == theSearch.query.offset) ? 0 : 1);
prop.put("content_item", 1);
}
theSearch.query.transmitcount = item + 1;
return prop;
}
return prop;
}
	/**
	 * Tries to retrieve favicon url from solr result document, or generates
	 * default favicon URL (i.e. "http://host/favicon.ico") from resultURL and
	 * port.
	 * 
	 * @param result
	 *            solr document result. Must not be null.
	 * @param preferredSize preferred icon size. If no one matches, most close icon is returned.
	 * @return favicon URL or null when even default favicon URL can not be generated
	 * @throws NullPointerException when one requested parameter is null
	 */
	protected static DigestURL getFaviconURL(final URIMetadataNode result, Dimension preferredSize) {
		/*
		 * We look preferably for a standard icon with preferred size, but
		 * accept as a fallback other icons below 128x128 or with no known size
		 */
		IconEntry faviconEntry = result.getFavicon(preferredSize);
		DigestURL faviconURL;
		if (faviconEntry == null) {
			try {
				String defaultFaviconURL = result.url().getProtocol() + "://" + result.url().getHost()
						+ ((result.url().getPort() != -1) ? (":" + result.url().getPort()) : "") + "/favicon.ico";
				faviconURL = new DigestURL(defaultFaviconURL);
			} catch (final MalformedURLException e1) {
				ConcurrentLog.logException(e1);
				faviconURL = null;
			}
		} else {
			faviconURL = faviconEntry.getUrl();
		}
		return faviconURL;
	}
	/**
	 * @param hasFullViewingRights
	 *            true when current user has full favicon viewing rights
	 * @param faviconURL
	 *            url icon of web site
	 * @return url to propose in search result or empty string when faviconURL
	 *         is null
	 */
	private static String processFaviconURL(final boolean hasFullViewingRights, DigestURL faviconURL) {
		/* Only use licence code for non authentified users. For authenticated users licence would never be released and would unnecessarily fill URLLicense.permissions. */
		StringBuilder contentFaviconURL = new StringBuilder();
		if (faviconURL != null) {
			final String iconUrlExt = MultiProtocolURL.getFileExtension(faviconURL.getFileName());
		    /* Image format ouput for ViewFavicon servlet : default is png, except with gif and svg icons */
		    final String viewFaviconExt = !iconUrlExt.isEmpty() && ImageViewer.isBrowserRendered(iconUrlExt) ? iconUrlExt : "png";
		    
			contentFaviconURL.append("ViewFavicon.").append(viewFaviconExt).append("?maxwidth=16&maxheight=16&isStatic=true&quadratic");
			if (hasFullViewingRights) {
				contentFaviconURL.append("&url=").append(faviconURL.toNormalform(true));
			} else {
				contentFaviconURL.append("&code=").append(URLLicense.aquireLicense(faviconURL));
			}
		}
		return contentFaviconURL.toString();
	}
	
/**
* Add action links reserved to authorized users. All parameters must be non null.
* @param sb the main Switchboard instance
* @param prop properties map to feed
* @param theSearch search event
* @param resultUrlstring URL of the result item
* @param resource resource scope ("local" or "global")
* @param origQ origin query terms
* @param urlhash URL hash of the result item
*/
	private static void addAuthorizedActions(final Switchboard sb, final serverObjects prop,
			final SearchEvent theSearch, final String resultUrlstring, final String resource, final String origQ,
			final String urlhash) {
		// check if url exists in bookmarks
		boolean bookmarkexists = sb.bookmarksDB.getBookmark(urlhash) != null;
		prop.put("content_authorized_bookmark", !bookmarkexists);
		// bookmark icon check for YMarks
		//prop.put("content_authorized_bookmark", sb.tables.bookmarks.hasBookmark("admin", urlhash) ? "0" : "1");
		
		/* Bookmark, delete and recommend action links share the same URL prefix */
		StringBuilder linkBuilder = new StringBuilder();
		final String actionLinkPrefix = linkBuilder.append("yacysearch.html?query=").append(origQ.replace(' ', '+'))
				.append("&Enter=Search&count=").append(theSearch.query.itemsPerPage()).append("&offset=")
				.append((theSearch.query.neededResults() - theSearch.query.itemsPerPage())).append("&resource=")
				.append(resource).append("&time=3").append("auth").toString();
		linkBuilder.setLength(0);
		
		String encodedURLString;
		try {
			encodedURLString = URLEncoder.encode(crypt.simpleEncode(resultUrlstring), StandardCharsets.UTF_8.name());
		} catch (UnsupportedEncodingException e1) {
			ConcurrentLog.warn("YACY_SEARCH_ITEM", "UTF-8 encoding is not supported!");
			encodedURLString = crypt.simpleEncode(resultUrlstring);
		}
		final String bookmarkLink = linkBuilder.append(actionLinkPrefix).append("&bookmarkref=").append(urlhash)
				.append("&bookmarkurl=").append(encodedURLString).append("&urlmaskfilter=.*")
				.toString();
		linkBuilder.setLength(0);
		
		/* Delete and recommend action links share the same URL suffix */
		String encodedRanking;
		try {
			encodedRanking = URLEncoder.encode(crypt.simpleEncode(theSearch.query.ranking.toExternalString()), StandardCharsets.UTF_8.name());
		} catch (UnsupportedEncodingException e1) {
			ConcurrentLog.warn("YACY_SEARCH_ITEM", "UTF-8 encoding is not supported!");
			encodedRanking = crypt.simpleEncode(resultUrlstring);
		}
		String actionLinkSuffix = linkBuilder.append(urlhash)
				.append("&urlmaskfilter=.*").append("&order=").append(encodedRanking).toString();
		linkBuilder.setLength(0);
		
		String deleteLink = linkBuilder.append(actionLinkPrefix).append("&deleteref=").append(actionLinkSuffix).toString();
		linkBuilder.setLength(0);
		String recommendLink = linkBuilder.append(actionLinkPrefix).append("&recommendref=").append(actionLinkSuffix).toString();
		linkBuilder.setLength(0);
		
		prop.put("content_authorized_bookmark_bookmarklink", bookmarkLink);
		prop.put("content_authorized_recommend_deletelink", deleteLink);
		prop.put("content_authorized_recommend_recommendlink", recommendLink);
		
		prop.put("content_authorized_recommend", (sb.peers.newsPool.getSpecific(NewsPool.OUTGOING_DB, NewsPool.CATEGORY_SURFTIPP_ADD, "url", resultUrlstring) == null) ? "1" : "0");
		prop.put("content_authorized_urlhash", urlhash);
	}
/**
* Process search of image type and feed prop object. All parameters must not be null.
* @param sb Switchboard instance
* @param prop result
* @param item item index.
* @param theSearch search event
* @param target_special_pattern
* @param timeout result getting timeOut
* @param fullViewingRights set to true when current user has full image viewing rights
* @param noreferrer set to true when the noreferrer link type should be added to the original image source links
*/
	private static void processImage(final Switchboard sb, final serverObjects prop, final int item,
			final SearchEvent theSearch, final String target_special_pattern, long timeout, boolean fullViewingRights, final boolean noreferrer) {
		prop.put("content", theSearch.query.contentdom.getCode() + 1);
		try {
		    SearchEvent.ImageResult image = theSearch.oneImageResult(item, timeout);
		    final String imageUrlstring = image.imageUrl.toNormalform(true);
		    final String imageUrlExt = MultiProtocolURL.getFileExtension(image.imageUrl.getFileName());
		    final String target = sb.getConfig(imageUrlstring.matches(target_special_pattern) ? SwitchboardConstants.SEARCH_TARGET_SPECIAL : SwitchboardConstants.SEARCH_TARGET_DEFAULT, "_self");
		    final String license = URLLicense.aquireLicense(image.imageUrl);
		    /* Image format ouput for ViewImage servlet : default is png, except with gif and svg images */
		    final String viewImageExt = !imageUrlExt.isEmpty() && ImageViewer.isBrowserRendered(imageUrlExt) ? imageUrlExt : "png";
		    /* Thumb URL */
			StringBuilder thumbURLBuilder = new StringBuilder("ViewImage.").append(viewImageExt).append("?maxwidth=")
					.append(DEFAULT_IMG_WIDTH).append("&maxheight=").append(DEFAULT_IMG_HEIGHT)
					.append("&isStatic=true&quadratic");
		    /* Only use licence code for non authentified users. For authenticated users licence would never be released and would unnecessarily fill URLLicense.permissions. */
		    if(fullViewingRights) {
		    	thumbURLBuilder.append("&url=").append(imageUrlstring);
		    } else {
		    	thumbURLBuilder.append("&code=").append(URLLicense.aquireLicense(image.imageUrl));
		    }
		    String thumbURL = thumbURLBuilder.toString();
		    prop.putHTML("content_item_hrefCache", thumbURL);
		    /* Full size preview URL */
		    if(fullViewingRights) {
		    	prop.putHTML("content_item_hrefFullPreview", "ViewImage." + viewImageExt + "?isStatic=true&url=" + imageUrlstring);
		    } else {
		    	/* Not authenticated : full preview URL must be the same as thumb URL */
		    	prop.putHTML("content_item_hrefFullPreview", thumbURL);
		    }
		    prop.putHTML("content_item_href", imageUrlstring);
		    prop.putHTML("content_item_target", target);
		    prop.put("content_item_code", license);
		    prop.putHTML("content_item_name", shorten(image.imagetext, MAX_NAME_LENGTH));
		    prop.put("content_item_mimetype", image.mimetype);
		    prop.put("content_item_fileSize", 0);
		    
		    String itemWidth = DEFAULT_IMG_WIDTH + "px", itemHeight = DEFAULT_IMG_HEIGHT + "px", itemStyle="";
		    /* When image content is rendered by browser :
		     * - set smaller dimension to 100% in order to crop image on other dimension with CSS style 'overflow:hidden' on image container 
		     * - set negative margin top behave like ViewImage which sets an offset when cutting to square */
			if (ImageViewer.isBrowserRendered(imageUrlExt)) {
				if (image.width > image.height) {
					/* Landscape orientation */
					itemWidth = "";
					itemHeight = "100%";
					if(image.height > 0) {
						double scale = ((double)DEFAULT_IMG_HEIGHT) / ((double)image.height);
						int margin =  (int)((image.height - image.width) * (scale / 2.0));
						itemStyle = "margin-left: " + margin + "px;";
					}
				} else {
					/* Portrait orientation, or square or unknown dimensions (both equals zero) */
					itemWidth = "100%";
					itemHeight = "";
					if(image.height > image.width && image.width > 0) {
						double scale = ((double)DEFAULT_IMG_WIDTH) / ((double)image.width);
						int margin =  (int)((image.width - image.height) * (scale / 2.0));
						itemStyle = "margin-top: " + margin + "px;";
					}
				}
			}
		    prop.put("content_item_width", itemWidth);
		    prop.put("content_item_height", itemHeight);
		    prop.put("content_item_style", itemStyle);
		    prop.put("content_item_attr", ""/*(ms.attr.equals("-1 x -1")) ? "" : "(" + ms.attr + ")"*/);
		    prop.put("content_item_urlhash", ASCII.String(image.imageUrl.hash()));
		    prop.put("content_item_source", image.sourceUrl.toNormalform(true));
		    prop.put("content_item_noreferrer", noreferrer ? 1 : 0);
		    prop.putXML("content_item_source-xml", image.sourceUrl.toNormalform(true));
		    prop.put("content_item_sourcedom", image.sourceUrl.getHost());
		    prop.put("content_item_nl", (item == theSearch.query.offset) ? 0 : 1);
		    prop.put("content_item", 1);
		} catch (MalformedURLException e) {
		    prop.put("content_item", "0");
		}
	}
private static String shorten(final String s, final int length) {
final String ret;
        if (s.length() <= length) {
ret = s;
} else {
final int p = s.lastIndexOf('.');
if (p < 0) {
ret = s.substring(0, length - SHORTEN_SUFFIX_LENGTH) + SHORTEN_SUFFIX;
} else {
assert p >= 0;
final String ext = s.substring(p + 1);
if (ext.length() > 4) {
ret = s.substring(0, length / 2 - 2) + SHORTEN_SUFFIX + s.substring(s.length() - (length / 2 - 2));
} else {
ret = s.substring(0, length - ext.length() - SHORTEN_SUFFIX_LENGTH) + SHORTEN_SUFFIX + ext;
}
}
}
return ret;
}
}
