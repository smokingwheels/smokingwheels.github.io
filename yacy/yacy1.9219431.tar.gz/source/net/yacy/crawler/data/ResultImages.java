/** 
 * Smoking Wheels....  was here 2017 lwaskqhngpbkifhkmhckbxddqhmhoeevlevlyntureqfvxrh
 * Smoking Wheels....  was here 2017 xcmrgnyoygulugubcmiinxwzzklbbwxynwraciqupljpbaih
 * Smoking Wheels....  was here 2017 ykzughqioftuzhqkamrqjltgbfxdqufyumypelcahczlzwcr
 * Smoking Wheels....  was here 2017 exsofrnmgswfjfndzupfrkfsggzkzccxhpjejdsqjwxynufs
 * Smoking Wheels....  was here 2017 fbhweqwxjjippclizzxcsatpdibdbctagdzdivjzsuupxjdy
 * Smoking Wheels....  was here 2017 enksmmhunymfqjpehaqpbwhhqmutajrueicbvhdulgnbnloc
 * Smoking Wheels....  was here 2017 gfelrpqkpmzmpomgjbainowjvabyhvobvofsymiwxrhhbele
 * Smoking Wheels....  was here 2017 xiusotznthucaothznqceevtdlcqpojtdmcgyrojuyllmwbm
 * Smoking Wheels....  was here 2017 zgvfeyrxhwzzmmlhdcgziwupdofcvxiekavykhqrxbsbyevn
 * Smoking Wheels....  was here 2017 jqcdxjhtwbakzqsnarwgmepgsldtfmxvdjqjdbsljhxuwxla
 * Smoking Wheels....  was here 2017 jlosfnsmiwotsrbnfluonuhkzisgddvnaxbifabnpggozfxz
 * Smoking Wheels....  was here 2017 mvnpzdzrwqltblealvnslsgwivdpizaediwzxjhcerdpekkt
 * Smoking Wheels....  was here 2017 kemoffmftwwitbabqlwtpdawjsuyrjscqodovphoaqeirclt
 * Smoking Wheels....  was here 2017 ffhsgythrifsrvvwdgvaopnszzhujxjvcsbstkbmelhnxdsu
 * Smoking Wheels....  was here 2017 bvxjrvrgnddiakcyjkrcbutbgzpuwltbfhfesuaucoranrew
 * Smoking Wheels....  was here 2017 ndqbfpisinowhqmdcjzugsdvpfvywctxaxkccatqjwrclbbg
 * Smoking Wheels....  was here 2017 iqzqafbqobqicpyjismejpfdqnlkhgqnslpuknajvjyfxvvl
 * Smoking Wheels....  was here 2017 lztfiykbtnswjrtyilfqzxvjexzrhlvmvedvlaarqilzixee
 * Smoking Wheels....  was here 2017 cbybsghlvznzimjinsmqyjbdkqmjhobnckmzgoajdjglkjbn
 * Smoking Wheels....  was here 2017 wbwuawtlysxhkvljtxtchzhjriznasiroxlkfiqrzfvtapts
 * Smoking Wheels....  was here 2017 ljafhtcwjgbuhwzzxswbhzbeptyhlguejnbjvvrxbxujjeqh
 * Smoking Wheels....  was here 2017 vsfjvdawvkjswxfmibvvovgzbxacquzoclpmytgtluazyyny
 * Smoking Wheels....  was here 2017 gylqeogxdflljppkmcxzxgxjedbsdfoombonoctbnjtojbht
 * Smoking Wheels....  was here 2017 ghaoerynkygsfuulcfqjiglghyhaoomfmcuqbcrzxlihpvfy
 * Smoking Wheels....  was here 2017 nclzwnlraeylcpwqddubfbjtcdbgwfaujlfbxgyxmckpvwsb
 * Smoking Wheels....  was here 2017 cdmynhhlqswxxiyhyujjadohjubwgtpuqgflagpmjowfmanv
 * Smoking Wheels....  was here 2017 ffeuumjhbnslwpnwyhswrfcmhdendcyzazgojczoxjycflph
 * Smoking Wheels....  was here 2017 jpucjvstmzjwlhidwbijdhifgtnfeiajogcmiariujylzler
 * Smoking Wheels....  was here 2017 ipxskhtvfpzbgniduuyzuowpulocjuaelavpknodvpoqzqsn
 * Smoking Wheels....  was here 2017 azfreczoxdzfgqscwkqadombwgxrvblzfkskkispdismqwyo
 * Smoking Wheels....  was here 2017 uqvhgtijlszuqeynrbraayigolmpabznoxguljlrdcnvqhuw
 * Smoking Wheels....  was here 2017 aszfkavxyoxnvctfxdpwmutzfolwqvquocfuuxklkskyxfmq
 * Smoking Wheels....  was here 2017 oqeetuvbsfyimlddojdovghmnldpqtobjzqszlihvgagqgmk
 * Smoking Wheels....  was here 2017 jbghnjxymnlkpogpxqjnpvubhchidlgvoqvewrkwoxhmggnx
 * Smoking Wheels....  was here 2017 ryfxjexyambficpcldnfrhjkruusptlxvohznqycxihnlinf
 * Smoking Wheels....  was here 2017 zkhoaazsmkslcxwkwgeobojjactrsucgekvffmnbngnqdwuo
 * Smoking Wheels....  was here 2017 axbcoujchvobpbamgrcobwkczvpmlxjewbkfmtzehsofnlrl
 * Smoking Wheels....  was here 2017 vchpiutiaoagtyiquhhpftfzjaanxrudksjmedlbibizaxzq
 * Smoking Wheels....  was here 2017 qwajwmxrnqrludfjzhafkxzrkyvopabxnufyjqepzuzxijqe
 * Smoking Wheels....  was here 2017 ylmzyoywyinjbmjlodwfqhabjdgldzdnfxsohmvyxryekewg
 * Smoking Wheels....  was here 2017 meghrbftqfqziduwpkosfeygxkrmnyfgsbxupdgmyvwfjzcl
 * Smoking Wheels....  was here 2017 fuciiehmhallmlrxgbdbsanqxvtbxnupojbcbjmwfmptspdm
 * Smoking Wheels....  was here 2017 lfblmjzkrwqgsznbahxsypywmqjxtophlgrirdxydfjsccvj
 * Smoking Wheels....  was here 2017 rnjeylmfzaablpacsmjqzulwakryrdnjjjppwrcwgunilxmk
 * Smoking Wheels....  was here 2017 pgokthatoawvjldaiihucyrrcxcjrqwcqrvfclxangsaypnc
 * Smoking Wheels....  was here 2017 gzlfgfgebrmulwbdatspwlmtqfhqxrazsipsfejbzywnbbre
 * Smoking Wheels....  was here 2017 wravzrzvhzpjvkixjwyncbxsspdmvcttismyhxxwbjdtliwr
 * Smoking Wheels....  was here 2017 ympytjilkhbgzapdcdlmvuimsquvbzamlngapubojhywaujv
 * Smoking Wheels....  was here 2017 furhphpuucakosvuefbnkwjdhbqwptakkryftirntvwkzcqe
 * Smoking Wheels....  was here 2017 riazxskcbfxamxgdxbtzjsubgzjbqyfaqivdmhvkjfwavajm
 * Smoking Wheels....  was here 2017 pasidbpscsjozfisstwjndsyuqwcoljcxykoxqxdozcrdtnt
 * Smoking Wheels....  was here 2017 mzzydcfhyvhsllugkuwpybnrgphybijredlpipltyzyoxpig
 * Smoking Wheels....  was here 2017 aqjqzurscdvkospuzvorxssifqbtczmztvapgqitlgbdhdfl
 * Smoking Wheels....  was here 2017 grqlzkmcbllwhkypqtzyaqfjpvtbvadncfkbomprcajbthze
 * Smoking Wheels....  was here 2017 lzvsqiovutrovciewtkabmcinljmrhccyrcxhdqljwziydmj
 * Smoking Wheels....  was here 2017 augavkyojkndoqlglfjrbhrfhbzzkwhriyxcsvagupiduaaj
 * Smoking Wheels....  was here 2017 umjepozeexcpeegxkwpzjhnbqkbuvdynlwvbkapkhgcxoobq
 * Smoking Wheels....  was here 2017 trahgzhvvbucrayixoehoxnijofigsnevqdiflkozccjppgy
 * Smoking Wheels....  was here 2017 cjeqigrwfyhdduabnnjejxtqoviialtkfskrddwqfsokpgoi
 * Smoking Wheels....  was here 2017 jsewqafzkumicjfwydrlyhovrspsvkofprjhogntqwvinwha
 * Smoking Wheels....  was here 2017 hbmsghizvensevlufcxfngnbhblrqyfvfnbjyhfgcqqmnbvn
 * Smoking Wheels....  was here 2017 wexhmhncbwumiozaohcsshmuhxlsqtdupkupeabwsguqcrxp
 * Smoking Wheels....  was here 2017 ixmywnqqazzascfdlxmqhdnotmolgpbwlsashjjkwinswvmh
 * Smoking Wheels....  was here 2017 flmffrvgusybujxwripsiuzhckxxdqyaudpvpptafpfxtwvw
 * Smoking Wheels....  was here 2017 gekzqukxurwogmaffhgbdklcykxfgezpvpnhqeacocmqakiu
 * Smoking Wheels....  was here 2017 kvbfjaxqopdsasumhqlagoukdofwtwsbdgbqfwghbfgrahtw
 * Smoking Wheels....  was here 2017 yhmjaxgwaplygtpdkplcnybwvetpdntejntslpwmcjrylpac
 * Smoking Wheels....  was here 2017 jsxxkemfiyqakkgyjovfznqhjupgaidypbjooqjuhlephtjs
 * Smoking Wheels....  was here 2017 koxsntzpudwvevryceijynbxjegdjnbqauxoelqqmljdsihh
 * Smoking Wheels....  was here 2017 blgvtygeaapomhckvkzxylfasjhqjvztexsgcuuqurefcemn
 * Smoking Wheels....  was here 2017 piyppeghzplsnmzudjckvaeinrrmlaqcuuhlipcqqrtvejwl
 * Smoking Wheels....  was here 2017 njgpxfzosehzrgaxtndrqghrdrmpgfyqvdjfgcfwpfnewisi
 * Smoking Wheels....  was here 2017 nytqrzuypiihsqftpnyuridfgcfeuueqowayjvyqokbrjpmr
 * Smoking Wheels....  was here 2017 quevhuhmgvyvmbsozgmdnsoiraksfjtqndndnmjpqljacbwg
 * Smoking Wheels....  was here 2017 dtplhbjrprtbgbbxkycfyfqrosbwxtkjkjjqtbwrfynftvvc
 * Smoking Wheels....  was here 2017 lbgcloabsgssjoympzhwbssdgthpqcdwffknjuzyxryjggpk
 * Smoking Wheels....  was here 2017 jcrowfqoyayrprhinbuednjujyncgsbjfppdycpvosiatyqt
 * Smoking Wheels....  was here 2017 woqzviuizuwfvrjtmaslscmcvgivagtlwsfahutzihnvttrw
 * Smoking Wheels....  was here 2017 fifqwiitqqcsfgqeydghqedrsbsmhowtzyvbkuvgpzrtxuqu
 * Smoking Wheels....  was here 2017 xpqcvyjlbvpygftlqtznzsqkkwuavrjkmzfgrjluyogzdjtt
 * Smoking Wheels....  was here 2017 rtkfuffhqymuprtmpnreayoknlyqnbmqrsiyqzjzgcwyqdng
 * Smoking Wheels....  was here 2017 mnjbahllysdmezuqbljqhjvcxwvuogsxaiotcjsmrxkkvzqc
 * Smoking Wheels....  was here 2017 qunycsyhwfgletkjmqilrslctljdjcsaggjlcnvenlaglyah
 * Smoking Wheels....  was here 2017 qsdlueumotskawgmrmbkeyuhjrrrqtlakendyqiempesikyb
 * Smoking Wheels....  was here 2017 estjfrhwjvrikjhypsiqchlujjfohnfcsybcggawjjlftywy
 * Smoking Wheels....  was here 2017 gldurlbpxhojhruamggkaggarpphobjvruhztazxjbtmcmmr
 * Smoking Wheels....  was here 2017 ewhcryybadzzvjdgvfaitniqkpsovesxzdsoozpeuehlbbti
 * Smoking Wheels....  was here 2017 jdoucyaxxrvxlhdkkaegjdymwztguadksocxyjkugolhobyc
 * Smoking Wheels....  was here 2017 qqksxkpaxlibworlfjnfdhtrtmcqjxyoccmjmphergvnvclo
 * Smoking Wheels....  was here 2017 ybqynnjmpgvqznarlebnqmorxekdumnxpvenzmizemjugzak
 * Smoking Wheels....  was here 2017 nigvkvbuwdzczuporpcurlmbkiollopdyfqdmyvacwgbnwpr
 * Smoking Wheels....  was here 2017 xqpxlaumxkrdigeypbdvhcwtsntnbgejfyrjiglmbevnpdlq
 * Smoking Wheels....  was here 2017 vidaqcymzodsryrtffyswtgwjmjpnyluowjmbwysymtqqhzv
 * Smoking Wheels....  was here 2017 gdrghhcyulrayhhhuzptwwnugiaaafwxofxbnnmkwzzcchyy
 * Smoking Wheels....  was here 2017 myfxabafeaanjvobvoioddteoirpayenwjxyseileipwpehb
 * Smoking Wheels....  was here 2017 zyaopexygraximdvairxtphwoalgefipozbfycdxogbdeifl
 * Smoking Wheels....  was here 2017 morbcoaajxwcoizpkzkwaksbyesdkkmmwalevtsfvuziyjgn
 * Smoking Wheels....  was here 2017 zkymumzqfnxiyrjqflovmcwcpwetybfpgqikdveadhhfidad
 * Smoking Wheels....  was here 2017 tmvchlqcpnwasfsmywliykvqoktufddsngftxkvewgdqbsoh
 * Smoking Wheels....  was here 2017 hwqnidbbrgpxhtsvjqnemhyoggnewqhxpmygmphwplxwambf
 * Smoking Wheels....  was here 2017 iavpbnplvfgxhjktmmqlkzvahhycwzvktimglzjkezgjlazk
 * Smoking Wheels....  was here 2017 wqgjsxwiqggftmymmhtngzhjonqbjtgsnxdhogfnvccutfar
 * Smoking Wheels....  was here 2017 dpxdxrqezjgiurvoxffwvzlgegoswvhopqkgwjcavkpcpeea
 * Smoking Wheels....  was here 2017 qccnkqboawdxwutsmsmkfappmzuayhwaafcetoqcvpdmxgqs
 * Smoking Wheels....  was here 2017 dnhihtlkchcxryryeljesgkmdouepmfiznfksircsuilyaxf
 * Smoking Wheels....  was here 2017 qoiqwfkvukmnclvoihxnwfqjzaeqaauzbtbmolhrpgeqbjrj
 * Smoking Wheels....  was here 2017 idfurotfbiyfjzrbiliznqkueqvdquitxhdgjuvrwnszzjxc
 * Smoking Wheels....  was here 2017 ukfholpfzglrxjxeahgkslasayzodwtrpwgulsxickltplus
 * Smoking Wheels....  was here 2017 ruwbnyhsxvcvjrnziojvsydgftzdkqiziikkipiyeyzidcvs
 * Smoking Wheels....  was here 2017 byycyfkvmthysitqmdtqdooupdmirrnfpxxrweeegkfmbhsw
 * Smoking Wheels....  was here 2017 dultiutzodrkdwztbfqjubkyhijvjvacezflcnvyrjhcyblf
 * Smoking Wheels....  was here 2017 lnspmimuhffybfzbtdpvrkyrqxvodftqbfeuitwicqqjvtfy
 * Smoking Wheels....  was here 2017 rogmnxwcapzmektnprkdevvahqhszeadmouzdlcuifxvwamq
 * Smoking Wheels....  was here 2017 wnulsrocjalgkvkmtqapuvxldpivajfcydjrhgrwnjzblsya
 * Smoking Wheels....  was here 2017 gjkvpdjegnfrxdnjvhvujbfngbxmspcgekjqwfwnbsachxpc
 * Smoking Wheels....  was here 2017 jgjfaakzsmflectamahnypdebodstzqqeaqyenhwoaldjzre
 * Smoking Wheels....  was here 2017 woekaizieipovwaktlewvqfocxlscxznfxdyuruhxiwpuoos
 * Smoking Wheels....  was here 2017 varmyhrkhytewtquwoneprjaidmwwxrkufffmkllexfealbn
 * Smoking Wheels....  was here 2017 mouuhjjpvhitklarimqzakpgwodynxjbpjjnjrpfthrvttco
 * Smoking Wheels....  was here 2017 hgxwwhdoatfzytwvxqaefvhbaspvtzbmsaiasswrhipuxxxd
 * Smoking Wheels....  was here 2017 bpmoubhdevpvctehormtldbqljfummzxhdfzcabhqaqlrkxt
 * Smoking Wheels....  was here 2017 sghxiwmmxhwmwvdiopzcgxrizorgxboxxvfahihrxssnmewd
 */
package net.yacy.crawler.data;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.LinkedBlockingQueue;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.storage.SizeLimitedSet;
import net.yacy.document.Document;
import net.yacy.document.parser.html.ImageEntry;
import net.yacy.kelondro.util.MemoryControl;
public class ResultImages {
private static final Queue<OriginEntry> privateImageQueueHigh = new LinkedBlockingQueue<OriginEntry>();
private static final Queue<OriginEntry> privateImageQueueLow = new LinkedBlockingQueue<OriginEntry>();
private static final Queue<OriginEntry> publicImageQueueHigh = new LinkedBlockingQueue<OriginEntry>();
private static final Queue<OriginEntry> publicImageQueueLow = new LinkedBlockingQueue<OriginEntry>();
private static final Set<String> doubleCheck = new SizeLimitedSet<String>(10000);
public static void registerImages(final DigestURL source, final Document document, final boolean privateEntry) {
        if (document == null) return;
        if (source == null) return;
        if (MemoryControl.shortStatus()) clearQueues();
limitQueues(1000);
final Map<DigestURL, ImageEntry> images = document.getImages();
for (final ImageEntry image: images.values()) {
if (image == null || image.url() == null) continue;
String url = image.url().toNormalform(true);
if (doubleCheck.contains(url)) continue;
doubleCheck.add(url);
boolean good = false;
if (image.width() > 120 &&
image.height() > 100 &&
image.width() < 1200 &&
image.height() < 1000 &&
!"gif".equals(MultiProtocolURL.getFileExtension(image.url().getFileName()))) {
good = true;
float ratio;
if (image.width() > image.height()) {
ratio = (float) image.width() / (float) image.height();
} else {
ratio = (float) image.height() / (float) image.width();
}
good = !(ratio < 1.0f || ratio > 2.0f);
}
if (good) {
if (privateEntry) {
privateImageQueueHigh.add(new OriginEntry(image, source));
} else {
publicImageQueueHigh.add(new OriginEntry(image, source));
}
} else {
if (privateEntry) {
privateImageQueueLow.add(new OriginEntry(image, source));
} else {
publicImageQueueLow.add(new OriginEntry(image, source));
}
}
}
}
public static OriginEntry next(final boolean privateEntryOnly) {
OriginEntry e = null;
        if (privateEntryOnly) {
e = privateImageQueueHigh.poll();
if (e == null) e = privateImageQueueLow.poll();
} else {
e = publicImageQueueHigh.poll();
if (e == null) e = privateImageQueueHigh.poll();
if (e == null) e = publicImageQueueLow.poll();
if (e == null) e = privateImageQueueLow.poll();
}
return e;
}
public static int queueSize(final boolean privateEntryOnly) {
int publicSize = 0;
        if (!privateEntryOnly) {
publicSize = publicImageQueueHigh.size() + publicImageQueueLow.size();
}
return privateImageQueueHigh.size() + privateImageQueueLow.size() + publicSize;
}
public static int privateQueueHighSize() {
return privateImageQueueHigh.size();
}
public static int privateQueueLowSize() {
return privateImageQueueLow.size();
}
public static int publicQueueHighSize() {
return publicImageQueueHigh.size();
}
public static int publicQueueLowSize() {
return publicImageQueueLow.size();
}
public static void clearQueues() {
privateImageQueueHigh.clear();
privateImageQueueLow.clear();
publicImageQueueHigh.clear();
publicImageQueueLow.clear();
doubleCheck.clear();
}
public static void limitQueues(int limit) {
while (privateImageQueueHigh.size() > limit) privateImageQueueHigh.poll();
while (privateImageQueueLow.size() > limit) privateImageQueueLow.poll();
while (publicImageQueueHigh.size() > limit) publicImageQueueHigh.poll();
while (publicImageQueueLow.size() > limit) publicImageQueueLow.poll();
}
public static class OriginEntry {
public ImageEntry imageEntry;
public MultiProtocolURL baseURL;
public OriginEntry(final ImageEntry imageEntry, final MultiProtocolURL baseURL) {
this.imageEntry = imageEntry;
this.baseURL = baseURL;
}
}
}
