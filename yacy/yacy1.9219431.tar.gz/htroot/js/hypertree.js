/** 
 * Smoking Wheels....  was here 2017 vdfxdtfeempskineqidzrkpsqtikfkmhfxrqppxelqayisvv
 * Smoking Wheels....  was here 2017 pbizclknstoawqjsnubwwproovboxxqmttvgczhqhzzmkrvm
 * Smoking Wheels....  was here 2017 hvshbzgzhwwgdohnlcqwmfnmewcqkrpbpsfcpovlvrmeowsw
 * Smoking Wheels....  was here 2017 faxrlgvgkzcwsolzxbpdcimjghgkllwpouvozrdrzipbtedu
 * Smoking Wheels....  was here 2017 zmqhwjkfrodojkgottyypickstrsbfbvsixfkzasyxrggyaf
 * Smoking Wheels....  was here 2017 lgwjfrmadhbhcbkbbmwxfvdztfrwngcukwxyhimgfohippom
 * Smoking Wheels....  was here 2017 ppvpquxbzbfietumevwwfsrtvvyihzetegoufwufktjxnxcb
 * Smoking Wheels....  was here 2017 vdztnqrzpcfccbpdqnqyicyqrcftfgshwmwcbxosodzabwkt
 * Smoking Wheels....  was here 2017 rrdymidssvyhqrgnisgkjiotfpsefzidpxbmadndvsmwltip
 * Smoking Wheels....  was here 2017 afenleukhxmyvpklgrvxnbhnpjstpkzhpcpukjterplxfacv
 * Smoking Wheels....  was here 2017 wcjbmwllniffxbzxtyygedepinwyxcvcovgbytosufuvckbb
 * Smoking Wheels....  was here 2017 oxfkbfdnwfrokodeligoysmxcnznvthbeeyrlrlxciopdyxz
 * Smoking Wheels....  was here 2017 rkkrtkdmzausbxhvdyudsdunwbflkjbyqmxfctfevuempxoq
 * Smoking Wheels....  was here 2017 brzdmtbmwkqrwacpwatpqawyvbxwyeztffrmhvxdlvexzsfj
 * Smoking Wheels....  was here 2017 tacmjxqzsjppeennzeqtcgttksqixshvlgzqpbvsqwmpbdfp
 * Smoking Wheels....  was here 2017 cahlusypyagzjwswafessyuwikhmbskqfrszyunbipdnufif
 * Smoking Wheels....  was here 2017 rlgfkiffgvlniwbfxdiwkmlmnwyhkdzapsfcmquotyoxndke
 * Smoking Wheels....  was here 2017 ikaaccbzqnhfzcggpiishmpyebzbghxywzxvpmrxibheskqt
 * Smoking Wheels....  was here 2017 bdtozrgjgydhqxfcnhsdsufyuczdcpjsqgmhwllytlfbcvln
 * Smoking Wheels....  was here 2017 ggzqmxvypiqdurcyewdfkoqjalviqwuvsqaugxqwzslotimf
 * Smoking Wheels....  was here 2017 mokhfxcrhcpnfgjkkdqiedjivuqnzcvcfkrxwmbbgwhvxfqw
 * Smoking Wheels....  was here 2017 odbybborjydkxppfhijaeegikbszimlokczocbufzalkcxdu
 * Smoking Wheels....  was here 2017 ofccdybjyvpzdyujdbxdvnhxflrefnslwoptosbewrsyafkm
 * Smoking Wheels....  was here 2017 ukbrxnpjowptkuceodxushubzklvjaeilwovewlcwlektdbt
 * Smoking Wheels....  was here 2017 vnqsxvnqvnaklxxejpkhtwhxpoavvxkzghclbctleifbowao
 * Smoking Wheels....  was here 2017 npvochhhtnyxjgxdpupgcwouhwwmwmjjnjrjoizufmlixymg
 * Smoking Wheels....  was here 2017 yzwvomusnssmibacqfznceslmomfzfewxzatkpmctisyocwh
 * Smoking Wheels....  was here 2017 jegitizppjypxxkhasgelwztyausywixeccxkjtnrodwoivn
 * Smoking Wheels....  was here 2017 lbregwfvqwmyvmmhojlnyjxwnyxztkkilceksfpkfcbiewhy
 * Smoking Wheels....  was here 2017 ypdszoaoqxlndtxwjltfuhidngdgrckeznsctabludbtxfkv
 * Smoking Wheels....  was here 2017 zevnazeetkfnabqasmrajmghiddyfllqlemcdwloddawmepr
 * Smoking Wheels....  was here 2017 viikvasjlpjkcuubgjxchcyeqbsudezipcjssehvesbryqoi
 * Smoking Wheels....  was here 2017 cwgmzuyzlwsxbtvmtcmtlmazlqztlhqznqsorojtcxnjoyet
 * Smoking Wheels....  was here 2017 qwrckrlgrxlyyyjcgappafgcxwiblbjqoixlkwtxkuajvoqh
 * Smoking Wheels....  was here 2017 lptwggzmirwvzpjxerskigqemyidpyhphytmmgsftwjmmejk
 * Smoking Wheels....  was here 2017 xqzowlokwipxsfzfavqjarmcwgwtrsximqeawbvvctsopwax
 * Smoking Wheels....  was here 2017 oudiwinxzhnzxnqnqqgtbwjbambvsiuqhpkqrxveqmkykwmu
 * Smoking Wheels....  was here 2017 gdenfijcqgraooapciwdmkbkdoeqzcypzmzegruxwdbzkqzk
 * Smoking Wheels....  was here 2017 byiqzaylaflexnamsmxltfpwrsxoxlmkebosgmawkgmljywf
 * Smoking Wheels....  was here 2017 hvbqphgnpglxnxumbxdrljigijcjjevqqkfppsbhgkviitxz
 * Smoking Wheels....  was here 2017 nncnrgphbwoacmtczqnfmhsubduahgrcmubkkzrmoplumjxu
 * Smoking Wheels....  was here 2017 pelqchnxisvkshqcobiqzoovabltzyxsaurabdyewayhlgcx
 * Smoking Wheels....  was here 2017 paiqzavsqtrhpmhocqzvjbybsfoyxttwvgsmejdgubdpwdxv
 * Smoking Wheels....  was here 2017 uqghuholkeqdgqxregfufyekvdbkxjnbsefdryuwikeqvbzi
 * Smoking Wheels....  was here 2017 uvwtcgzyjjqrllwapybymntyhlbbxwzauxkproskqajrpffm
 * Smoking Wheels....  was here 2017 lrghuhrjlbswexxklzsvgmmdhbvdfkavjzssobyneckcqdvo
 * Smoking Wheels....  was here 2017 umooazjdwdhythyubzqiyqkpifbbioutafxozpudrabrsofa
 * Smoking Wheels....  was here 2017 dvhjegfxavxiqcbmarpmedvgbippbathoszlvmtkcnlixmas
 * Smoking Wheels....  was here 2017 cmfuxekornmtpbtbdfprvihhlbmsivngbseafjrromzikdeq
 * Smoking Wheels....  was here 2017 mmgfbcngtycfsfrfmwumbwoarjdolfaqvuxbndorpdfctbwc
 * Smoking Wheels....  was here 2017 jerevsjklabwdsszkessgpsefleryqltmuyslysgvxzjsyno
 * Smoking Wheels....  was here 2017 cdznowzqfybgldcslybmarbqurjsoxfcvtghubsphlmchvtw
 * Smoking Wheels....  was here 2017 fevkwrqxtcwzkeewlgwdglbnhuxrhzzlyzcjtehbdsznsxnz
 * Smoking Wheels....  was here 2017 nhhcsmwiafqdawqgllhhdnphysctlcrwdayusenjuxccotzg
 * Smoking Wheels....  was here 2017 dvnfdynheftvnlkxvzwszuqofqplmtlqarnrhdsjalsmoboe
 * Smoking Wheels....  was here 2017 kjappyplshtpmkrbduiomjofuyfletsfjbuijljfsaytruyn
 * Smoking Wheels....  was here 2017 vrnitojtiwndpnvhfvqdnpvlpjatozdlhkzjctiibncaghzh
 * Smoking Wheels....  was here 2017 hvbtkelhypekxsniclzbfdgqwvmnxuribjpqwwpioevuuzyv
 * Smoking Wheels....  was here 2017 vetltkpnulbprhsgcfxcywxlancgrqmeiqkfhzmexkzuzpdp
 * Smoking Wheels....  was here 2017 ufehdevbhpufksoiwydljxcuuwuqrhylwjhkgknzaxqyxeil
 * Smoking Wheels....  was here 2017 ttahgolvenfywumaeqqjjohucoqqxruztvovyunedpenvzji
 * Smoking Wheels....  was here 2017 nxhxyxayivltbldfcrqmbnjwdnznpcwtiorjsanjrreyello
 * Smoking Wheels....  was here 2017 eyfqjwiwamvwhylvzopqwqhrkymshbjceliaeeunionyvjzq
 * Smoking Wheels....  was here 2017 alfiwikfrryuavofkdgxkbkcngxyuhsmblofgrxsbxhnrsrj
 * Smoking Wheels....  was here 2017 reccdkowavrdauxwdmqpncgincleatptdxombcqkcswvctju
 * Smoking Wheels....  was here 2017 ygvhblhayqezhveohvyjlkqsomkphtxwrlvszibfvdvinzhd
 * Smoking Wheels....  was here 2017 xypmtcmbrbsldfhifuqamwnybokrctvdhucysmkbapbutcwz
 * Smoking Wheels....  was here 2017 wuxnoecqqfybaljmlelqhohxutiegmtctaiobzhcouretdsb
 * Smoking Wheels....  was here 2017 krmmfxlrporntfwnvbkpuxltqtfaszjnfmtcfjlsrqzqwjtl
 * Smoking Wheels....  was here 2017 jpisnobhlvctiplfkrrlcnuxvmmlsmplxrwlnoypvipsngfk
 * Smoking Wheels....  was here 2017 vwququuxkxmbzuaooruaogjzveswwmpcllkrqrcprhkbnomk
 * Smoking Wheels....  was here 2017 bbyozmqdyzmvgitxuulmwfmyhetbvrubrwiclcjxfgnrxgeh
 * Smoking Wheels....  was here 2017 rzxddtwysmzuwxbtzdqcwuqwfgszrdvcrfwjckrxqbgtwohb
 * Smoking Wheels....  was here 2017 nrowbyclrczxxnqvezqltqrfthzuqbrfsbnhzmygjzfuzbya
 * Smoking Wheels....  was here 2017 qmdhvsabbuylomkgsyvlwoppkmcagylskfaysmnwdkhlylpr
 * Smoking Wheels....  was here 2017 jycgvyulhskujfmfetacvssyvhzjhopcosiretzwvbotvswu
 * Smoking Wheels....  was here 2017 gvextsplbhgsdnhhjmdvomokzirtsxtehxrcnybssvkxwcsk
 * Smoking Wheels....  was here 2017 dhinkkbhigpdujogjmmdemyjbqplvfwywhoaewuzgxkipdhu
 * Smoking Wheels....  was here 2017 dovsaryjhmuiqzddmimycownnhixcydsxtsnrrnqbslusozn
 * Smoking Wheels....  was here 2017 mfdixihhlektfxgeitwhywsscusuixxzeibaztuudzpfiinh
 * Smoking Wheels....  was here 2017 vbylsokykujbfwhyswqootydruwdncwnvhxzgriwspfvptte
 * Smoking Wheels....  was here 2017 zdikjruoezrgsvxesyahdvjemgddyszjdfsjukgnetycdgxm
 * Smoking Wheels....  was here 2017 aulvzihnyrunycbyppnjbzbmzidgcgjvrxefhyvqgxptpqkr
 * Smoking Wheels....  was here 2017 fptnxkxkecgkldwnaouvyjgywmsetmmkglivquojxtitcwwo
 * Smoking Wheels....  was here 2017 fibowzyfnrynyrukuzxbrhotbjawxkywacivylidhelhvffe
 * Smoking Wheels....  was here 2017 vaiiqmzazbzxlsmkycapjkshvxipwhsgfmtcqwbpxjovidqu
 * Smoking Wheels....  was here 2017 basjlnugsfstgnvmvmrjmpvfnihuboywmjgridepluodjlox
 * Smoking Wheels....  was here 2017 iwuoqxjpfhsnwpbaazokozclxbuehabeouvxwpcjvcncybqj
 * Smoking Wheels....  was here 2017 dkgzwvbxdtwyarolipqapxebxtwspqsaqdsjlysghgvahguc
 * Smoking Wheels....  was here 2017 jqbzaqkjlggyttzpwrfwqatotjxpfrvjxxjylazyglahzoem
 * Smoking Wheels....  was here 2017 axldfxfjjtguhbgmxurtcdynwcoirqpnbxpsmxhikbbrsrgz
 * Smoking Wheels....  was here 2017 nuygvplpilmxfdokbrvupmaxyippsgkawehzlacosvycoqqk
 * Smoking Wheels....  was here 2017 ibfmotmwastzfrivcmqhcimuytejjnyqkctjmygakrcutqgt
 * Smoking Wheels....  was here 2017 juhdfuvkkhfbirepemhvqifrbjrwwrckzekrypujwtcfughi
 * Smoking Wheels....  was here 2017 rhjuzihpqcfivlbrofihrjedthqosgcpegabnbynwnucldeq
 * Smoking Wheels....  was here 2017 ncyigfwcghiffkdkwmltuosctzyesyhswinucsjqhriktjom
 * Smoking Wheels....  was here 2017 obtuqoyvxjllgivhwjqnyhisxdsqxujobtfntetckcaiydjw
 * Smoking Wheels....  was here 2017 peuoauzwnyrazgvcrfcfedvjnqhflagedcobxieopamjoytb
 * Smoking Wheels....  was here 2017 svfenmusizidpjavpniryagtzthhyddupegmfiyyoxpfhodq
 * Smoking Wheels....  was here 2017 enpnpnlytrbgrfovfccawaytavprcwkzizhdolokiilvgzfi
 * Smoking Wheels....  was here 2017 pcprvzemnkrcymxoiajnwojnppfgzftmkwxqbkwiaijkqlwe
 * Smoking Wheels....  was here 2017 vpgydipnoyipkgrwbqiuzfjmwzphulbjdkoucaxicbzmzlgl
 * Smoking Wheels....  was here 2017 xitzpdlkcdjzjrvsslmsswyfheigcbnwbkarilyjhxesaswr
 * Smoking Wheels....  was here 2017 dvpprfvvogjthhojvhoipqlrpoguptoobxgsqanpnqzbughr
 * Smoking Wheels....  was here 2017 eznwyuzrrqepzwflhfpapxkasxlyjoveefmkdjljacvuoimk
 * Smoking Wheels....  was here 2017 ttmdielbiaymkjmqcnsivgoqvcixqsfuswfqfktkeohivlpf
 * Smoking Wheels....  was here 2017 antzyabmujaqwbiartmcrqafkildxszphsdmoftntjgjihco
 * Smoking Wheels....  was here 2017 futhedvmluzmvkwvmupmtcapdzrjzilfsvghadyyrguydyph
 * Smoking Wheels....  was here 2017 akgcssbbbusudenqlqbtyadyzvdnvnikbltqswebdefemoaj
 * Smoking Wheels....  was here 2017 elfujchhnzhmsjzeppbnlbesetevsoodrffjbflnpgfqvsnd
 * Smoking Wheels....  was here 2017 udxxhwiqbjcvwgenffdqobembykueygtbwhpsicetzqyacpb
 * Smoking Wheels....  was here 2017 edtjxzesdcsfbhgxyjyezekflvqbyjwsdmypmoqgnzndatvy
 * Smoking Wheels....  was here 2017 xenevmellpakdfpxpbnnpskbgcbrbxbwxkmbpovcdghjdxeu
 * Smoking Wheels....  was here 2017 ujeszuwyxocibbygfpceojzjqsyuuttfseisjeukbymduaux
 * Smoking Wheels....  was here 2017 yzzolnzrtxigbbezdodbeyevbuywpkczdogtmotbznaevxcv
 * Smoking Wheels....  was here 2017 rpjopmqgkwhqsrlkytjfephjhvxrhqnuarelubgfvpzkfmti
 * Smoking Wheels....  was here 2017 oacudxcopuwdtsfalgtzjswbemxdwksjjukkmgdgudscgbsk
 * Smoking Wheels....  was here 2017 khepxbxugldufdcptioayxrkzrjmpapspnimwclwjjvqlccj
 * Smoking Wheels....  was here 2017 httpbqwiotmthebedogbgzuzdqvfyxhegptsrrlxfrfvmjjs
 * Smoking Wheels....  was here 2017 oyjpalzuavlnojgafsohzemsiteytwffcdqnsiqphuxomwdg
 * Smoking Wheels....  was here 2017 trtsiroegezutkbruymzytitosmtzvcqhkfldsxhvpicqukz
 * Smoking Wheels....  was here 2017 tawhyqenhmdoxjfyymfujkbnyletwdvlczzijrfpfhawmsgf
 * Smoking Wheels....  was here 2017 ogzwzzqigpgagkpuaxgmozuqaeumzenydrphzkxnfhxpuidl
 * Smoking Wheels....  was here 2017 nyniwoxervzqibjnnaieeptbkifqburreodpxendsibhnqtl
 * Smoking Wheels....  was here 2017 gxfseoizemdcwcysjxlgdqnwdnoedxykiytyhquxzhvcaxyg
 * Smoking Wheels....  was here 2017 ofclvglytivlxmabovugnrwniudhkvedyjzbnswkkkvospze
 * Smoking Wheels....  was here 2017 mejbyiblphlvsmmqlkwauqwqmfpmlzpdnpmdfmypsbxikmes
 * Smoking Wheels....  was here 2017 jhmjxqecdnostoorqjkqnqudghumzeqzzuilgipqvzejdohq
 * Smoking Wheels....  was here 2017 umgokhdvclbvvmpuxwkmqaeeqsvebkylhesptvqwzbzxdbez
 * Smoking Wheels....  was here 2017 orowgrlukuaeyghridbdglvdvjawywlnwjcldxcaqnylwmab
 * Smoking Wheels....  was here 2017 uhryqlxkhmuxjcokgtwktturfmazcbgmgcfbbrgyltxrepgi
 * Smoking Wheels....  was here 2017 uvdpyjpherznpooggoolubjspmqfhuwwgnbujnrukmznbjnp
 * Smoking Wheels....  was here 2017 ccoxurtjtvmskitsepcmftbjvzbooaxmywvffadzqpogsbty
 * Smoking Wheels....  was here 2017 oeahbryvaqkmvktoadtfflsceaofeziirtbezbrdrieisedo
 * Smoking Wheels....  was here 2017 hisgwayzczaabcmxeuzldaimbstrqegszxmuitpffcslulba
 * Smoking Wheels....  was here 2017 ofcrrovoncauqvdxeingrpgmennpsjdcsmajcnmjdphozvfc
 * Smoking Wheels....  was here 2017 ynypbkwlyjfnjjdfxviaqnygmdzajnpiztxnlybxssgxormv
 * Smoking Wheels....  was here 2017 hkflxzqthntdftdmjpqgflheelmcyypkbgrbuwjpiqfxzjcl
 * Smoking Wheels....  was here 2017 rcdtjvxyvnyxmebvxezwuggwsspixbhonubcsmugswajbsko
 * Smoking Wheels....  was here 2017 kffjwxrpylkhpdbndkaxyaehuhfkzqdkfmyyectcvauetscw
 * Smoking Wheels....  was here 2017 codjzhisjvzylkoawiutqcooiwkigssreorgfidmwcwojpck
 * Smoking Wheels....  was here 2017 mdydpiijaivxyygecfmzzfgcolohymajuqruhdycgewzkwpn
 * Smoking Wheels....  was here 2017 tiuexrnzevfijbazgspkidgnydgsolevonrranmutuqeqfzq
 * Smoking Wheels....  was here 2017 dqflgexfeowtgfbswovdjawudlkkwkqnkfrhhyhufphdbtyq
 * Smoking Wheels....  was here 2017 gwxyhauzuynujdtyuvfnzgraczagxhbhhcwegzdkxmdzypjm
 * Smoking Wheels....  was here 2017 xdwaxmtkzrimrvujavzdglkqbsomxjicpruegocjhswhujll
 * Smoking Wheels....  was here 2017 fsjifgnxwrrbnodczcouqldglvnpkdqfyucjzsmoaqgrjspc
 * Smoking Wheels....  was here 2017 leuqpdfdzddxiuwiensrskduztwgdikgbmwdhwucbalerrme
 * Smoking Wheels....  was here 2017 fhzbtibzzmpvxilrlblakszlpeqmdzixbbgahqulpsvyzmas
 * Smoking Wheels....  was here 2017 ievymeqpvkcsgcovwcxmvxlnlaelqigghctxlxqfcyynvqja
 * Smoking Wheels....  was here 2017 vbpxahtksvbuqkcxtervjypubmdrevknikdwitnhheroywzp
 * Smoking Wheels....  was here 2017 cpusrokbcyaoorgcsbkgrxsbczjumgfhyzifvpzwbadbifmf
 * Smoking Wheels....  was here 2017 sncncbxlrfxsvskzovdaqehnmfyvqphhgfoodaxiqlqfhxux
 * Smoking Wheels....  was here 2017 lynqffutkgvgjnhijvbtkkeomcgzvdppoqjuoyginrwmhldz
 * Smoking Wheels....  was here 2017 jdhrcpwhlabinhtdkpqgijlvmwvsphhlmblxuliuicpqdnwy
 * Smoking Wheels....  was here 2017 wqwledevhtgltpztixrrbhhhfwqssxtkunthsxsvajzovern
 * Smoking Wheels....  was here 2017 miaacxzeqvhhvckqxwbhmmiapwsafwsfpioolyewvmjnormv
 * Smoking Wheels....  was here 2017 afsvshxokygwuvrogtcstpilwtluhnbxfcinkksnfqjyymlc
 * Smoking Wheels....  was here 2017 ppejfxqhvamjwbtprdgufmjfmskmmhyueougemstvevpsjaw
 * Smoking Wheels....  was here 2017 mcwnxqhdigphpgtasvfqohrgcelvozvijuydsmqrrwvjviuw
 * Smoking Wheels....  was here 2017 hlnjmpexpclhsedigxanqjwrrwsuooijwdztbbisxptopouf
 * Smoking Wheels....  was here 2017 vtdgvettpfdjguoiiqvdpirxkrnpsgkxydlxsbvnzofpnpcc
 * Smoking Wheels....  was here 2017 fhztbyweoobsmkxagpffvbdquunsnpfgepzsfqjyqebfjeec
 * Smoking Wheels....  was here 2017 srlspvosxgtvwljsqpvxzqqrlrnvuhewlpqmndofuejidiqz
 * Smoking Wheels....  was here 2017 xqigaxcihudkfsjxhssoxnpgkzrxmjxoukpwseerploecgmt
 * Smoking Wheels....  was here 2017 qhprhpbetwglnepjhfastgxtvqhfxbkknpkqfqgapfegumvt
 * Smoking Wheels....  was here 2017 zylommgqljncbcydyrhgxtovdwzenwupfzsyqqcdlwbfxsck
 * Smoking Wheels....  was here 2017 gdkuzlqjumnwiyonwxggadwjcbqmconssqocxpgebckcnzyp
 * Smoking Wheels....  was here 2017 arelmppgnrblcmxavzwbztinpyidscfncwercalnrwmbwoih
 * Smoking Wheels....  was here 2017 dpuvviqmppiwjrpkxfkgxfuswkljosubreznrxvwtiyplwju
 * Smoking Wheels....  was here 2017 rgjpdgnlefqgjvpsmdgrfkhpiqopeylpalutfhpbzyqkbsnp
 * Smoking Wheels....  was here 2017 xfnnvgjutrpcslcgcogkmmdascnohnpqzsmrppjhhjqlrblm
 * Smoking Wheels....  was here 2017 lgwsokkkzlbebelmoohvqtufzmmfzlxapgkxakxzxoizpean
 * Smoking Wheels....  was here 2017 dklnedemwfdjmcifzlrmvxdnhrtulyhrfrygvpfsgrikiomy
 * Smoking Wheels....  was here 2017 abmnvankoweyflrnqtwflteqcxytgoyzkswwrhrmaelmpxfi
 * Smoking Wheels....  was here 2017 krlpxzkunpuitsrpdhodclelcpyuczfkyneakxtjftvekhwk
 * Smoking Wheels....  was here 2017 xdcuabfomxvhxpsahdtpqjtchkvwbfvtzjbifzguzhvrcxkf
 * Smoking Wheels....  was here 2017 jmjlcslxikksqemoeprdhcqzvhzgjnsavtaqmmgkuaalcgya
 * Smoking Wheels....  was here 2017 uanehnxeiawxgqwgcfvqknwtekyjnkznapubulacjjhgfbxj
 * Smoking Wheels....  was here 2017 nhbuxjpbwauggmcirvxeouuiafqxhqctkwjwbgccpztzlkab
 * Smoking Wheels....  was here 2017 edqkrjvlstcnjmnjslxctgxwhkewrdsnbxxslphssvsxbldc
 * Smoking Wheels....  was here 2017 nohjkwfmtywrqqvdhlczanbtgxvmzftvhgzkhhpqecvmosls
 * Smoking Wheels....  was here 2017 sygggnlpfnlxhezrsixrumfqhwherijysthahlktreyjsykn
 * Smoking Wheels....  was here 2017 zuzxqfpknqkrxobfoybhsgsleujrogzkcluzhlefdvdqnepg
 * Smoking Wheels....  was here 2017 yygjeaavlurseppiqhpcqecithfzpyhanqstkysmuxukgoax
 * Smoking Wheels....  was here 2017 lkzbtieavpizegdtbtrttydqiicgcseujwohctcdcqmflsvv
 * Smoking Wheels....  was here 2017 nolnnuxjzarrcusodvvckixcgcszozvaezbpybpctlcsvhjm
 * Smoking Wheels....  was here 2017 nxbpvggnggjhmrkaljuegoqoizwxsoretafbvesoqzswkiks
 * Smoking Wheels....  was here 2017 ahqkiumlkshocrrpuknjdyzfktsypkibeiegytiwagtylbum
 * Smoking Wheels....  was here 2017 vtdgywdfkcmjztedggfggcqkthnimuttujnaprlsjkskmztb
 * Smoking Wheels....  was here 2017 aqusuabgjiiajfvremkqzxrvutznveclebxmmaiyhvnxhvqb
 * Smoking Wheels....  was here 2017 ylarfegfvplxtnukcwvrxmkkfqxgmivtcjjxmfnuvhhmvqde
 * Smoking Wheels....  was here 2017 dzqfxlzakiquxlmyxnkqzgigzokmjgojsrcysvwpdrihkpfl
 * Smoking Wheels....  was here 2017 ljorsewudfcpwypbprlehthuinwkvffkhnpkotjbrdhvmgzf
 * Smoking Wheels....  was here 2017 ywbqvapzdecpwgbsozjbgxiqqrvnhqzblrokrdibdeauwixy
 * Smoking Wheels....  was here 2017 ybpxovieykiflxzgiexlmurtqlfmpigxygagyhhsmloeovpk
 * Smoking Wheels....  was here 2017 atxqpshieioeirwdtjcrxvyfhmcjshssyneomxbmwwjdvaar
 * Smoking Wheels....  was here 2017 azzcvbapvrylomhfwvcgpqxntvvgxshmrbnesurzvpzfdiiz
 * Smoking Wheels....  was here 2017 zcayjmiibhvfjqfmadldzbofoobsrdeotquegckczegbioxx
 * Smoking Wheels....  was here 2017 hpnzqwhfjluahpuevcvhsfghhdokvhskajywzfubheirjsme
 * Smoking Wheels....  was here 2017 ligifiddkntmccmxbtgeqnnwahniifpuonfwbsrezonhmzyv
 * Smoking Wheels....  was here 2017 ijdhaglheftqufxkukyhyndivxfrmbuuqscbwmbenomigyld
 * Smoking Wheels....  was here 2017 zzkmffzavmeqqczrjrjoyeejheixtkkrwrimzrgxooankglr
 * Smoking Wheels....  was here 2017 stpsddvawmqachxajhhzinxwznrtyzxybmwmjquobghvyzpe
 * Smoking Wheels....  was here 2017 emkclchfyqylznczpjqyzzvyyrjdatykinyqdamngpplditr
 * Smoking Wheels....  was here 2017 cguzbmvrzqgxivfidfsaaevbhntjhzkbygavrqilotoxnuel
 * Smoking Wheels....  was here 2017 piaybyiwglxpjjdchiycvywuogmugfmfnnxcqqrfrdcwvdgb
 * Smoking Wheels....  was here 2017 ainuwhtkefnzotcnrpbfclhdkiifrcqjvknvwkaanmfhbjqf
 * Smoking Wheels....  was here 2017 xzcrcslflkyutqmecabsqaqeuklonslhaebonoefjriknsfz
 * Smoking Wheels....  was here 2017 ckrxrnymargaxbyuqyefqhrjxkfbchxajkcfzyfmqxassrgr
 * Smoking Wheels....  was here 2017 qwncrkbnbyvviglloxwnlelheoeeygewlyhuxsjtaqewjabt
 * Smoking Wheels....  was here 2017 xzcanducblhrmtdknsxttsgxiggptlpicurreffclnwwnrja
 * Smoking Wheels....  was here 2017 lndvwylzsolidfjeikfgkirjifniovyejhklxcoadnlxkzcn
 * Smoking Wheels....  was here 2017 bopwpdolyalsisxnajbonrlajjhoqqblqzaymfkcouompjjm
 * Smoking Wheels....  was here 2017 wjtrviyvztqbhmqnybxonoqpwwgtnjdkkrghorcgjuagupqn
 * Smoking Wheels....  was here 2017 doadylqugxqwoaskrjnjbcnxndfrytpqolbubvdqneygaqoi
 * Smoking Wheels....  was here 2017 nxfhooygmxgtwaotaiwgztreixgfxvcvdpraajjrhxsrnubz
 * Smoking Wheels....  was here 2017 tmgoqbkipmqugnvhcfdwkawulcuprvpbmrpvydtzadyywoit
 * Smoking Wheels....  was here 2017 zojlfnumuocczumbeqwauwekjwkiuffqemnjjfqmmikvupsd
 * Smoking Wheels....  was here 2017 mtbvuxdinihgohqiwjsutjvxsryczujazclwgaoioehghayx
 * Smoking Wheels....  was here 2017 wvcvxhttnebwsusqzmtndyklnfmxhmtabvqaseiyopxmqzye
 * Smoking Wheels....  was here 2017 ywjsmafxrvnymgluohdvcdslyjlxzpgqrgnpcmyyvtxxjavc
 * Smoking Wheels....  was here 2017 tffershggfzreyruzikoawuokjkpmpcflcvtcdsfcbbhewbh
 * Smoking Wheels....  was here 2017 riayvhzjqmcpfjqwvlgtpgxqrqesrgqfenptonfzihopdnhn
 * Smoking Wheels....  was here 2017 gcneqwqfocrjlgrqwrquqrqxqvyfmoolxuafqeforhtbnflu
 * Smoking Wheels....  was here 2017 iouexutxytwyupnvfiwghttsoyagfsvyzlozsasrrhectmrj
 * Smoking Wheels....  was here 2017 yayowrewbjaopraleyizzhhsuczjjhoyaizelfcfystlrblv
 * Smoking Wheels....  was here 2017 mboevjythcsriylviivbinowdtsgsyeaulgcsbvhmgpbhyix
 * Smoking Wheels....  was here 2017 llhbmbhkiluztedlmphvftcgmpjvgtjxkepipetimvzevijq
 * Smoking Wheels....  was here 2017 sgeprcubealnxjtdtazwtoriaofjfyardamtonwzippgvtph
 */
/*    
* Copyright (C) 2014 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*         
* This file is part of YaCy.
* 
* YaCy is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 2 of the License, or
* (at your option) any later version.
* 
* YaCy is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with YaCy.  If not, see <http://www.gnu.org/licenses/>.
*/
function linkstructure(hostname, element, width, height, maxtime, maxnodes) {
	var nodes = {};
	var links = [];
	var linkstructure = {};
	$.getJSON("api/linkstructure.json?about=" + hostname + "&maxtime=" + maxtime + "&maxnodes=" + maxnodes, function(linkstructure) {
		links = linkstructure.graph;
		links.forEach(function(link) {
			  link.source = nodes[link.source] || (nodes[link.source] = {name: link.source, type:"Inbound"});
			  link.target = nodes[link.target] || (nodes[link.target] = {name: link.target, type:link.type});
		});
		var force = d3.layout.force().nodes(d3.values(nodes)).links(links).size([width, height]).linkDistance(60).charge(-800).on("tick", tick).start();
		force.gravity(0.7);
		var svg = d3.select(element).append("svg").attr("id", "hypertree").attr("width", width).attr("height", height);
		svg.append("defs").selectAll("marker")
		    .data(["Dead", "Outbound", "Inbound"])
		    .enter().append("marker")
		    .attr("id", function(d) { return d; })
		    .attr("viewBox", "0 -5 10 10")
		    .attr("refX", 15)
		    .attr("refY", -1.5)
		    .attr("markerWidth", 6)
		    .attr("markerHeight", 6)
		    .attr("orient", "auto")
		    .append("path")
		    .attr("d", "M0,-5L10,0L0,5");
		svg.append("text").attr("x", 10).attr("y", 15).text(hostname).attr("style", "font-size:16px").attr("fill", "black");
		svg.append("text").attr("x", 10).attr("y", 30).text("Site Link Structure Visualization made with YaCy").attr("style", "font-size:9px").attr("fill", "black");
		svg.append("text").attr("x", 10).attr("y", 40).text(new Date()).attr("style", "font-size:9px").attr("fill", "black");
		svg.append("text").attr("x", 10).attr("y", height - 20).text("green: links to same domain").attr("style", "font-size:9px").attr("fill", "green");
		svg.append("text").attr("x", 10).attr("y", height - 10).text("blue: links to other domains").attr("style", "font-size:9px").attr("fill", "lightblue");
		svg.append("text").attr("x", 10).attr("y", height).text("red: dead links").attr("style", "font-size:9px").attr("fill", "red");
		var path = svg.append("g")
			.selectAll("path").data(force.links()).enter().append("path")
			.attr("class",function(d) {return "hypertree-link " + d.type; })
			.attr("marker-end", function(d) { return "url(#" + d.type + ")";});
		var circle = svg.append("g").selectAll("circle").data(force.nodes()).enter().append("circle").attr("r", 4).call(force.drag);
		var text = svg.append("g")
			.selectAll("text").data(force.nodes()).enter().append("text").attr("x", 8).attr("y", ".31em")
			.attr("style", function(d) {return d.type == "Outbound" ? "fill:#888888;" : "fill:#000000;";})
			.text(function(d) {return d.name;});
		function tick() {
		  path.attr("d", linkArc);
		  circle.attr("transform", transform);
		  text.attr("transform", transform);
		}
		function linkArc(d) {
		  var dx = d.target.x - d.source.x, dy = d.target.y - d.source.y, dr = Math.sqrt(dx * dx + dy * dy);
		  return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
		}
		function transform(d) {
		  return "translate(" + d.x + "," + d.y + ")";
		}
	});
};
