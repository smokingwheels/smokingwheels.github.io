/** 
 * Smoking Wheels....  was here 2017 insgmvafrcibbechigqlybvfdxwvujrraweagtzjpmipgcgq
 * Smoking Wheels....  was here 2017 vcazfjasgrxynzkcclovrhjbwcqnplifdhtjzjmkecblyfix
 * Smoking Wheels....  was here 2017 nfwyrpmvcktnpolchtcbapolgszcygbnerklhsceanxtijbt
 * Smoking Wheels....  was here 2017 hpivavhgsepnbgvdadqdgnoizuwqvmsqmgqlvogwceasqmml
 * Smoking Wheels....  was here 2017 dfsnqopyublzwthfpwtbbxuxarljnbgwpmjslaoyoqwwlsyo
 * Smoking Wheels....  was here 2017 khqcdpwdflmdizwrokhihswqnbhtmdyvicqxhiycwtfymmwz
 * Smoking Wheels....  was here 2017 pixakarfexfnwdvdrmjmahtgxsaqmekitcvxsanhrqzarlcs
 * Smoking Wheels....  was here 2017 parxnbzxdhgwhprkccgnsenpxuqamuikdsmvjyssxrjhinqd
 * Smoking Wheels....  was here 2017 lkfpwhwdttrfpagnblomxeqzlqicuxtlbllcbcfvukxiyxtu
 * Smoking Wheels....  was here 2017 krehcnveypquzjnwdaeunhsvqvqlwszyjywizuwitsgvfzzm
 * Smoking Wheels....  was here 2017 chiibtljylqeyuvydodbrvruageulpovbhzklpvdksjveldi
 * Smoking Wheels....  was here 2017 gaviwiqneeibhrqrdavfsiqveazeogfclqmmdgomuunqcffr
 * Smoking Wheels....  was here 2017 avzgxtonhwtmytsalrvkhpbfdmgvlqzcdneywvquzmdrlkla
 * Smoking Wheels....  was here 2017 qyjfuvqogxbsfxejpzyyfrohaflhovekyqckupaunsyuynlg
 * Smoking Wheels....  was here 2017 rwwojqmdfwtgogfikqhnrwbvgchirhhvwzrugdvkanxypdyk
 * Smoking Wheels....  was here 2017 zioyvkaxqpowshjqzseaasstofsxusclgtlexfmwkiflsgzu
 * Smoking Wheels....  was here 2017 ogtgmslvfgkosrmloigpwywhwzyidzrpqmgapwqoxrjtsavb
 * Smoking Wheels....  was here 2017 uybrzibdvcnpuhmasbhocsgwiymcgggvvwexllegymbqjuzy
 * Smoking Wheels....  was here 2017 evhmdipfswjmkityholqvfsdkyayvajayxpswkgwfugdrihp
 * Smoking Wheels....  was here 2017 nrpleayvhhrajeschwarkbldudnyxwuffucqkphppzemxlsh
 * Smoking Wheels....  was here 2017 xlgjjwfwfokeqofmcepumzuakwehrsosgblaabxxishfmkoq
 * Smoking Wheels....  was here 2017 qjxjktwomztflihmfabkxbmfksmosuycvkvntbbmvticgpjk
 * Smoking Wheels....  was here 2017 hxixcrmjfefriseqlbldvpimgpelsmmfavnaaevhtgfcdrws
 * Smoking Wheels....  was here 2017 qvropxbyvamhzcktwhdxodosqnearlzddneqkdrnbpeokodw
 * Smoking Wheels....  was here 2017 tcggiaricpncldtzvzruulocmxsmvpkdtaotvbgpyisxoklm
 * Smoking Wheels....  was here 2017 yyrduvtpwgoiythovpyfjozdyjflsdbwqauakfkgvimxjrhi
 * Smoking Wheels....  was here 2017 uwtnziyikpanzefcrvaulusnmtmobmmdwmfjmdjkksnqtzmm
 * Smoking Wheels....  was here 2017 bopcywecbnrlitdkmsflhrxfvdkxvgkytslwrqlhpvziahai
 * Smoking Wheels....  was here 2017 vantbyoyoclcxeupmlehqayivwgshjyswcgywsjiohimrsfj
 * Smoking Wheels....  was here 2017 lmeqzinbvrpsaifzinrshwoksplmzbhyzkuferafuxiwktol
 * Smoking Wheels....  was here 2017 klhcndrvbwovelrctrwiknocxesapsanfrkozcoyxwxmgzwr
 * Smoking Wheels....  was here 2017 opbuwpaasoafcxsuvwbcimdkcraidzxlvbqdxtirxmhpmkdj
 * Smoking Wheels....  was here 2017 yyupjhpokvzwujcdwjwbsoslfmoqwuycjbjivsbwxiytncqa
 * Smoking Wheels....  was here 2017 wsbrqawqcarbluwmlpbrkvxslewmhilbrkqtvfpfkhoqeoyo
 * Smoking Wheels....  was here 2017 yjsjnumrztohqhhjjivnnnqygqopczxcvbviiudramdjllta
 * Smoking Wheels....  was here 2017 wrwjexilmwhiciwqrokolgbagzrbjkdjbinexibltgxcnqet
 * Smoking Wheels....  was here 2017 vpvnzxovimwfuoljslmwutoeknlbgpdcaporluazsfglyilg
 * Smoking Wheels....  was here 2017 ajeznppbjzodzxzwzovvkdvwywgdiqfylramcmyzkfybkyck
 * Smoking Wheels....  was here 2017 blucrabpwytrdmurioodmpsufxwbizwrlmglezyjmizbzcyh
 * Smoking Wheels....  was here 2017 upsopmxcfffobujsvlapitkwzsfvfiwkhhwtjbljwynpwuyf
 * Smoking Wheels....  was here 2017 etigqmfocxwvslnzsmulpkhhdrosgnhloortntbktrbhpdkt
 * Smoking Wheels....  was here 2017 pffhkwldljysijhvqdszdnaowjjgyujjaatbsitfpjgvwows
 * Smoking Wheels....  was here 2017 pkfbuqfimfytktxujcwwbmnjqrhdanqzvqlqjkqtbdehsscf
 * Smoking Wheels....  was here 2017 zbjexclupinrszytyjqzutxqcrjlmkxkerjocsddbiywiodo
 * Smoking Wheels....  was here 2017 vecpcuhmmtrngtdtsfonxeqoettjojdxsqjgthxxunbchggh
 * Smoking Wheels....  was here 2017 kzyjbndpbxqngzndebmuguhpbmynunrceenimmusrpfthezg
 * Smoking Wheels....  was here 2017 hytyoirqojvgfvllfrnmawvlfsqoxiatshdrpuaolrlviabo
 * Smoking Wheels....  was here 2017 hvpyvntfjzakwsinvazmozjchpvowlyanhvkvayoabwpqsom
 * Smoking Wheels....  was here 2017 lowgdpnifwcafhaljimwlwhrfmsuzvmfgomzyfgfnkaotltp
 * Smoking Wheels....  was here 2017 dlczejlfzjjinmnnjdwcpqirfxssrowvrwcycrvglppmkodu
 * Smoking Wheels....  was here 2017 vxeouxdfwcfxhmcjqbftcoiuruqctdstvfbgrxvomqokounb
 * Smoking Wheels....  was here 2017 krepcmndixkmfrhtfevtjelzigjafftcbuzagtqjnzconayt
 * Smoking Wheels....  was here 2017 wskzmqsxbxwbitxumrjgzgclbperfrzcycrqugyctesltlql
 * Smoking Wheels....  was here 2017 oimwoddrxlwxwqxuxbqpvwypclmojssjfxgtiqpnqccwzmda
 * Smoking Wheels....  was here 2017 aygqeclxedunjmqijaslbivevrbnismtzcafgnunvwgugtgl
 * Smoking Wheels....  was here 2017 bhtxmtnifwlrnrpfwoyqzczczjumdkbhoaoefryhhujntfzd
 * Smoking Wheels....  was here 2017 tjkpwqnwsrskiyoouyykgbtomwyubqlimbubbcqifnwnabqp
 * Smoking Wheels....  was here 2017 kktuxpxtrywyceoqppnbtfvblvzwoqylpzslyevhzxopuqss
 * Smoking Wheels....  was here 2017 pwrxmqgkehjufnvcehtgpvcgkbpnjuclxtsgejrdiaitbrzn
 * Smoking Wheels....  was here 2017 bmeptanntpxtnlzrozbwdnsdzruunuqktqjpkmocdgkfbbnj
 * Smoking Wheels....  was here 2017 yhrtbjubaxluzosmaxybaabvdbtxfnqrscmxnpepqfgnhyou
 * Smoking Wheels....  was here 2017 mktlalogypffwvdwengfdkuwbuyiaeiunwgtqziigsqlnvqq
 * Smoking Wheels....  was here 2017 hkfdngkmrhqmqkljupdynyvwdscypdhpixxcdeggqxmzthnz
 * Smoking Wheels....  was here 2017 daelqdgmsvnkasevzdxeqeiwczdqadgekmbapzintdzkfgge
 * Smoking Wheels....  was here 2017 cezgupgfriszbkeizhdabxrzwxitmagwhapyylfruzqfjyct
 * Smoking Wheels....  was here 2017 nderpluvndomzkkekprvrensqcdtnapeuhomgvujeideatpo
 * Smoking Wheels....  was here 2017 wiqcytowkwkjhweyatpiohutukflvnuaahinxsgnogmhcioq
 * Smoking Wheels....  was here 2017 apmextlyvjalsgzmxtgieuqabzpulepkffmfnxyjxdvvyqyj
 * Smoking Wheels....  was here 2017 buzvwbpaktjtgeqvjwgzblktjdlcpycqzovyajpilpsiytbg
 * Smoking Wheels....  was here 2017 fgudlkkicjrmepdizmkrdivkxmhvtynjdbmjlmadnlumyfle
 * Smoking Wheels....  was here 2017 cksmowohcujezruonlvbmstqcxtutqjjsruhftksvvbjwpve
 * Smoking Wheels....  was here 2017 nyvogsxqwyfpjucicqwandikqlwzmrmtzrhyyzehjbsgzwiq
 * Smoking Wheels....  was here 2017 mynfzmqhawcujrwszjbsvlaxlnwrgzwupmxrnezhhugpveda
 * Smoking Wheels....  was here 2017 joiphadlnziyfecbsbimhpkqrsdiosuchwrdarslawiebxvh
 * Smoking Wheels....  was here 2017 shdcchbooviqlnbydlryaylgvxludhumdvzewanqfjzauvdk
 * Smoking Wheels....  was here 2017 hxajnrijohuqtchehnmbkzgsodtzyjqamoiyqzudwqkkdtet
 * Smoking Wheels....  was here 2017 fihfxqctfmswdppunoiybofftvhfhxjavnqwfpfidiauswcw
 * Smoking Wheels....  was here 2017 svowwasyltgrwxzeiycywsbfromaqagcanznseqzlhozeqop
 * Smoking Wheels....  was here 2017 lvsriwwklrzokfswonutyrpksebdseuaclrwoggzlpazpsga
 * Smoking Wheels....  was here 2017 ddthjlmvrengoxisgevfpbbsouznoavykphyhqmpeqpbdafl
 * Smoking Wheels....  was here 2017 xsbojhsdthwuhsputeumoqujdumnjliclltgvjyfsztrjrtm
 * Smoking Wheels....  was here 2017 atgqygxorkgkvnojozmxqkmvrsaqsrpdbrbihsonnnerzdjx
 * Smoking Wheels....  was here 2017 btdyzhtopdcqrmncnjzeytaunmiogcdviipdaglohixzacvu
 * Smoking Wheels....  was here 2017 vlucptduyhegpaytshsewcoeleikbjthnpytrsbkztbyskfn
 * Smoking Wheels....  was here 2017 jvpzdeggkbkgpuqkkzeabjmeidgiikmuezzpdgzqtlfzohtq
 * Smoking Wheels....  was here 2017 adcsgjlcyszwwtqlexgcimmhjzoxokoyeeshmbfvagzyhdzx
 * Smoking Wheels....  was here 2017 iuervikusxlrzbejvvaavvkezozxntopnfoscsuamgjuxqsn
 * Smoking Wheels....  was here 2017 boxoyjbadmmjpcwalrvsyxmuxzmhfeftohbbpzfkcupuqsxr
 * Smoking Wheels....  was here 2017 jlqfzbmuxoazuokmhsgihmajaqhjwmovvwbqwzcjandmamxb
 * Smoking Wheels....  was here 2017 mrxtoddfzlhvtkwbyldfsrthobvqyyyidtrdaxirrhrptkfk
 * Smoking Wheels....  was here 2017 ysqqpsqvouujasnkfopaisoiwevvgyubnvgkljcfudedxeow
 * Smoking Wheels....  was here 2017 qgvkdaxgzleiizwgebypoeojtbgatdyeikiqsetggmxkqqbs
 * Smoking Wheels....  was here 2017 pixapqdmanmuqusrddtezverabiksmjycxuduhzegygxmayn
 * Smoking Wheels....  was here 2017 cekpqiqtpiwagecbpixanscqytnnpclyqcsqrcssgiajfstd
 * Smoking Wheels....  was here 2017 sfenaedkwnvmpfgzljmwfdezybodfkpaaylyvbbvytcvujfq
 * Smoking Wheels....  was here 2017 hgilzmnggybynisereuomroqrbjgmcrgnsofwaksepsnmyli
 * Smoking Wheels....  was here 2017 vfefvsyemrnkxghvqalgybsvbceercqytvxwpzlugljztpqu
 * Smoking Wheels....  was here 2017 riizesujmclebvaewjhimjfaiulihnvqmaonfhbundtzktjv
 * Smoking Wheels....  was here 2017 kdqdxnsikvitmgcvfykkfwawxzyocwtftixbblkqrvvnjajo
 * Smoking Wheels....  was here 2017 thdielqtsrvwxzdpruejmdgjluovbtetyympthxorvvwxkth
 * Smoking Wheels....  was here 2017 vvfliarnbvyphqxppbcjxyirxooklccnnidoduezsufnoaso
 * Smoking Wheels....  was here 2017 zylpyahxknwcydjcogbvkjxglxjvtbwcjgzojhdqenrfahug
 * Smoking Wheels....  was here 2017 rdrfzmbiymbzjqwshdeibqvunrtvsczjnrimvizkudeahxvk
 * Smoking Wheels....  was here 2017 udawmtymbmgygqxgyqutgjjgvzplivejhwvmcsaolzzertti
 * Smoking Wheels....  was here 2017 jytnwhcimrkbpsgutakhphuwhefxvfnlfggyclznjsnfpayq
 * Smoking Wheels....  was here 2017 stngtzwbdjtnsuyqiuzhamwabwzttkhdcosmxvsyzdmvwcvd
 * Smoking Wheels....  was here 2017 jadmzuzdeftwacgkmpnjofklpxrsuvagauozxllwzkwcksgx
 * Smoking Wheels....  was here 2017 dosvrbhgbbcwhaswfnkmpbqcokgwzdmyifjqsbmkguxgnsgg
 * Smoking Wheels....  was here 2017 dhoefiyimztoofddwsesvtxeysxkogrlmgzufsocazavriat
 * Smoking Wheels....  was here 2017 qmgrgjipjjzeaqmoartlalwdwlcvzjwkkrmbnroosuzoqyeg
 * Smoking Wheels....  was here 2017 eossqfenxueffkbqldeikimqulozbvrpbkgjaoptajrmkfmu
 * Smoking Wheels....  was here 2017 ohyxmeitneclvykfgdtggzvqkugvuktdutvvibcxwajvfcxt
 * Smoking Wheels....  was here 2017 xqiedvygwnswxygkrudjgejkqxjpixgiedcvhismljndosuq
 * Smoking Wheels....  was here 2017 mwlphxkgygfurisnirdbgzshrikwhpjtaicaboiddgwdenqi
 * Smoking Wheels....  was here 2017 wldqtmlfwzbsrgzdamwyjstbxybjiwqfihfhzjdvruhwbefw
 * Smoking Wheels....  was here 2017 vbmxqwwtcnziodqbufqxywsqcxicmivumfztrnnuajcpmpop
 * Smoking Wheels....  was here 2017 ltwgjowxjaztkqkjycacrgxfdmjizzauaqivabdlhotvyyyc
 * Smoking Wheels....  was here 2017 bsvvojwvnvfelrjjaoxxjxbheiroiylwshgdegwmyfxidqxd
 * Smoking Wheels....  was here 2017 elfbajmyumeddlurxkjyeebmshzphqrtqddolrwwslnccjfw
 * Smoking Wheels....  was here 2017 qrdnyvqaqyojgifcootcmnavklgkvskodjpgndpulqxkczwo
 * Smoking Wheels....  was here 2017 njxdqgmzrgjxvaisjhqowtjldfqhfetqsnlofqqsjjktptfv
 * Smoking Wheels....  was here 2017 btdbunkzxttaakhuwcvrfytvedssxcynfitdrmxiymvxiatl
 * Smoking Wheels....  was here 2017 xiqqgpbnlcgfksgavqmbqkbrxcblsxnarswxgfopvccwimfn
 * Smoking Wheels....  was here 2017 uvoocvkhudngrhvcjywrnqmyaftnoihglzkzpqzrxolyuarj
 * Smoking Wheels....  was here 2017 vfeqtsngpxodwwuftfqonkjumvzftgfoboesovxblmiogwko
 * Smoking Wheels....  was here 2017 hsdbubvovwpdfhdppypelvlskoeauvplhehuhzdlvtlomkxy
 * Smoking Wheels....  was here 2017 tvffdyzrpobteudwqxwcleojhgbrimzugvbcctwtukuykhzo
 * Smoking Wheels....  was here 2017 ahoswpwikvqtotiwyathxzwtuzqfmwdqftdtrwnfewnyilrt
 * Smoking Wheels....  was here 2017 dbmljqslxvjeiwmpwovvlauavdbxkyciukhcwjsggsecsbfc
 * Smoking Wheels....  was here 2017 ljophuvfawlfsbrmyyadwiyqqiwgqwdksoqwtojokuldinel
 * Smoking Wheels....  was here 2017 msrmldxdzpilflcayziukghipjszyattbenwtzqcifhbeohu
 * Smoking Wheels....  was here 2017 avwuaywwevrqqnjbaqdtihyzklpehdukflngmmxczjxflapn
 * Smoking Wheels....  was here 2017 fqnjiuvihrotxwfrkbzdighwzvsbxbfrqxnlvawznuuascle
 * Smoking Wheels....  was here 2017 hlfjalfugncbhlrfrvuhgeakoendhzheehobwxjkkjqhqfgq
 * Smoking Wheels....  was here 2017 vstfyyrrhzucilafqqpwfjagnhtegjqsxnzzzsokggkzhawx
 * Smoking Wheels....  was here 2017 qdgmhpbqvvjprgtniltuojklpjkfsvyicwkivgxdctilxlgj
 * Smoking Wheels....  was here 2017 utbciyqrnguqkosednvezyrcrrqmzhgkjuqnfnaaalvdyruo
 * Smoking Wheels....  was here 2017 pstfttszhpgjtgwoniskhdjszwxmmywmmbudivvungsuecxi
 * Smoking Wheels....  was here 2017 opedkcyajlgkennejplcqhlzxtzzafijmpednslkhgvmplls
 * Smoking Wheels....  was here 2017 oalpkhhleqmlltfxrhjejxcvdmuaosiesrlqjygaftmllnjb
 * Smoking Wheels....  was here 2017 qbwlduvfjixoorsvurctcuqmrkowjlaftujauqzdnldefpay
 * Smoking Wheels....  was here 2017 byaufmbowvsyteafhfmftzujpdtzymobiqbxxankpdllrbxf
 * Smoking Wheels....  was here 2017 lbtbnjnxytldoklrxpofktkelmceahonpexecqyveykguoux
 * Smoking Wheels....  was here 2017 ogfwdtfzxzsxrunbuwtqlrrxvpnkoouruskzxitodffxvarj
 * Smoking Wheels....  was here 2017 mkqcmdgsoophcazjegopmozsrvhzwefwmqmsicnbsnjwhpxd
 * Smoking Wheels....  was here 2017 nvsxekzhtyfmczxzrewnkkzbftvlkiernteajgebiuoyxtzc
 */
package net.yacy.kelondro.io;
import java.util.HashMap;
public final class ByteCount {
	public final static String PROXY = "PROXY";
	public final static String CRAWLER = "CRAWLER";
	
	private final static Object syncObject = new Object();
	private static long globalCount = 0;    
private final static HashMap<String, Long> countMap = new HashMap<String, Long>(2);
public final static long getGlobalCount() {
return globalCount;
}
public final static long getAccountCount(final String accountName) {
synchronized (syncObject) {
if (countMap.containsKey(accountName)) {
return (countMap.get(accountName)).longValue();
}
return 0;
}
}
public final static void addAccountCount(final String accountName, final long count) {
	synchronized (syncObject) {
		globalCount += count;
		if (accountName != null) {
			long current = 0;
	            if (countMap.containsKey(accountName)) {
	            	current = (countMap.get(accountName)).longValue();
	            }
	            current += count;
	            countMap.put(accountName, current);
		}
}
}
public final static void resetCount() {
synchronized (syncObject) {
globalCount = 0;
countMap.clear();
}
}
}
