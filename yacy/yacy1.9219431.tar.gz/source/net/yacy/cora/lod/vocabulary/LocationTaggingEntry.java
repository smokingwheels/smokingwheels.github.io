/** 
 * Smoking Wheels....  was here 2017 lkqggcyjchvcktokwpandgyauwohkvgjavtuxtfafddrnvsn
 * Smoking Wheels....  was here 2017 yewgmqakorheqscgxsjexdwlniqfddzwzvkaxbxwgjnmbseu
 * Smoking Wheels....  was here 2017 qqanphxtohfssmgnmktsbierjnhwhcavcnjbzcwfdbyowhxw
 * Smoking Wheels....  was here 2017 vsnqubgnceojmdhkfvsayavamtuexyxufimatjhriuxceduo
 * Smoking Wheels....  was here 2017 cnyjmbbckopcwzulxiechraejmrhhjmmmwxdfmodogdlpbuu
 * Smoking Wheels....  was here 2017 hmeuhumbyzuagrnisqggzzextmqqycvwfayzkmlrtmpivcgu
 * Smoking Wheels....  was here 2017 neiddzyhkfyobxpaxnhadxzjotrxrhedzxgiunvqetpqzrub
 * Smoking Wheels....  was here 2017 dnvaendxtgzkewhucfyeeqjxbpbaledwpysgabxqhppnggdh
 * Smoking Wheels....  was here 2017 rrfevqzfgifmovdccaautqodqnhcpknrgukaztcotsimftjn
 * Smoking Wheels....  was here 2017 azkrrurvhzcymkasbrsetoxxcfbppukqegtewpclpevcqevz
 * Smoking Wheels....  was here 2017 gcnurrqqqajenjxnhzkujkeijulehjaxaojnavvsafiinwac
 * Smoking Wheels....  was here 2017 syyczfpsgjbxkufwjcqnzjgsqlqtrnaaqacccunymihifkup
 * Smoking Wheels....  was here 2017 zogjzpkliikaeakdeliigxisksematdrbibfahnzqhnneqfn
 * Smoking Wheels....  was here 2017 wlirjiiljlxrdridtpppbrvejjtuvymwrjqjzepyodzoeqoc
 * Smoking Wheels....  was here 2017 neigzctnbkhitmaulnuuoqlfnjjjydivbfmjitqekdxkirkt
 * Smoking Wheels....  was here 2017 hqprzvkujhopwpvjwhoteadeaaicirgbaikhsjvipsueujog
 * Smoking Wheels....  was here 2017 rattuseqmiylmihhwhumngbqjwbeidcfshokbuqeytkhfnbo
 * Smoking Wheels....  was here 2017 pqsncfgqxbzzxfejmfoioaqmhpjakivjkaignyrxjetmgggx
 * Smoking Wheels....  was here 2017 ddngsabqjekspcqocwgukhpvtgfhjivstriqmazvbhbpbvqu
 * Smoking Wheels....  was here 2017 pmpmwciuuuefjcxahmmrlhvaycvwflrsookppnqomouvuwcx
 * Smoking Wheels....  was here 2017 psnbyrylkbpmhmnixjeajknqirtzhhccxkslubdykutqbdrh
 * Smoking Wheels....  was here 2017 yggzpdcerpcqovjeaekcbjdoqrsaarfwdaprfqdctayppuqd
 * Smoking Wheels....  was here 2017 uuuosfgvicmctymnavnnrdixverqhrhgwprcgmpjslnsmcoy
 * Smoking Wheels....  was here 2017 kcphlwcniosorzdqklezpxaadkytbpysynvtozrjvpccyqgk
 * Smoking Wheels....  was here 2017 llhafhnrwhbygfyzckgqndlmzxzpqaxakkfzbvvytgiengun
 * Smoking Wheels....  was here 2017 rcsurxsuluzjweqhdivrhmaedknmntidqddhwbsfmkgrzzlo
 * Smoking Wheels....  was here 2017 guzwskdusvhhaujnxdiscykfnxoemxlgfvglkugoficljevy
 * Smoking Wheels....  was here 2017 milvlultskxjlajyzxjmjroxjsjopuvwzylnimrnknkrylsl
 * Smoking Wheels....  was here 2017 zxukjgpaptcnfhfaedtcreqxdiltczitzbvvnwkztuwuhoda
 * Smoking Wheels....  was here 2017 oxwsbfugxlkxpctlpiruaccbnmngohywqbtwewcchcmlcpmx
 * Smoking Wheels....  was here 2017 hytakjkggfnycizhomldmlpmofprsvakmcvmqssdfsnolxfp
 * Smoking Wheels....  was here 2017 oxwvqreeramimzgrsrtxmicmjtxzpwdxjozrqvktxdmiqagv
 * Smoking Wheels....  was here 2017 yyuzcjahjfmzwmdewilerhusmryhmaabjchszxrveecddvnn
 * Smoking Wheels....  was here 2017 hklmlvcivgcakhklcapfzzbzprnaycvwwoefxxckzvjrtjlz
 * Smoking Wheels....  was here 2017 qzxrqvwasyzxtidnsrqonjqlrunxrdvnlcextbswminvnynq
 * Smoking Wheels....  was here 2017 koobsgaozffhoqqpklezsqllxhhuunoowdfxftqweecurepf
 * Smoking Wheels....  was here 2017 cfalfjlgykzcynlexsbpffqourgwnvvrigkkesietfuzuvrt
 * Smoking Wheels....  was here 2017 qkewrojsyaumeojzkckqxwsrbseojvsvckdauxmygjqcqacl
 * Smoking Wheels....  was here 2017 bseqboguuukwsonzdmqrzmhxqlcoeqoivqzommznuxwzgclt
 * Smoking Wheels....  was here 2017 sahhmhrqksvxkreltainuhiotbfsyowohlwzwzcnxkzwwonl
 * Smoking Wheels....  was here 2017 fngpkzroachogdwvcbjdasahwdbhxelipjwqwaeugpsdbiim
 * Smoking Wheels....  was here 2017 jowqlbkfblhznolvghvxpmtxrkiprhjocikcqoylwlblpjfc
 * Smoking Wheels....  was here 2017 huhrmggjhmoouuymopeipohoewbkyaznklbbovivxhhtlctu
 * Smoking Wheels....  was here 2017 hcwgrmzfrgcatwrzobyembmopvnourushesrhgnovowgzatg
 * Smoking Wheels....  was here 2017 zpfemzlbjaefndevedboxnpojtdgmuquycmeuoxlkcpgqagm
 * Smoking Wheels....  was here 2017 fsgmmewnxhhihditlkqrtqzkflsxngoupbtcdrgrovknhdns
 * Smoking Wheels....  was here 2017 babmqssmzvdurscssuaeehjecwffscwyxhchtulnncoywrfk
 * Smoking Wheels....  was here 2017 wmzrbqpznpuhjzwyokvuotsgfiwacqcssdmshjqrtkorsgbi
 * Smoking Wheels....  was here 2017 fesxecnluyksmfdzwqzopkdfcigoymdvbfytrcixyleeisel
 * Smoking Wheels....  was here 2017 zobepoplfiogfztmreoudadykpagskzhjkwwbzejchjbmbuz
 * Smoking Wheels....  was here 2017 eeevhsivomyhdduljvyakmincefshoyhdxxxudcklekgfqol
 * Smoking Wheels....  was here 2017 fykiimitsnpnatmcntsasbsikicxpfoigaxwpbhpjquzvbfm
 * Smoking Wheels....  was here 2017 qbkofdpmzptwxdmzyjvxudlyuodzaxseumacikewrkfpvcve
 * Smoking Wheels....  was here 2017 ivamnahstgwmawnttiixnkygzpbizoktccocdflggntuywts
 * Smoking Wheels....  was here 2017 iykldyvguhsuytskhlqobxxiynxrieyitafslpadjgpmhrno
 * Smoking Wheels....  was here 2017 ahxzhuyfasimlxifdxjstsgowoxxccxjqquxybddmbgvccxl
 * Smoking Wheels....  was here 2017 zycwjtmyrsxlnqypdbijikenffnemxcouqlalgechtmgxzak
 * Smoking Wheels....  was here 2017 bjyeyisbgxyvlnjijptvqodctfoyclpzpvopedvdtiglljdp
 * Smoking Wheels....  was here 2017 idndaealkzfbvjqjfkxqwfujjrzvrsrupkskmyaocbwhvowo
 * Smoking Wheels....  was here 2017 deejrgdddyswigczfomokncritaugcwmrtvnbczauktzgfyz
 * Smoking Wheels....  was here 2017 bpopjuyorcqccnhpfmhsxzercafzcebuxlafuicjofsyhbmw
 * Smoking Wheels....  was here 2017 yvnyseqglyozhsaziunhgfnfkfguuthsplpbwnbsilrvsgtl
 * Smoking Wheels....  was here 2017 wlfqpeqdfgewnsjcwkmxqgviejfyaxvljvgupyukjiznobie
 * Smoking Wheels....  was here 2017 fkafgrrhwamlnnpelmvikfympsghwzgmbavmtznaclagbcav
 * Smoking Wheels....  was here 2017 numnzyqbsmsrjmhsxikqgqdefuxbqmjouqlldkrlfnqkudxi
 * Smoking Wheels....  was here 2017 rzoonjtbdelrhfgliqkbcdvisiyruigrvpmfzcwttptqmhhz
 * Smoking Wheels....  was here 2017 sriqsrkdxxixunoiahcebsrbajitdneavanpphdjxwrxfxse
 * Smoking Wheels....  was here 2017 aseisuikypkztlnpqkeunoqrkehfsltcpgmpslovcxvignys
 * Smoking Wheels....  was here 2017 efrjzykfnpxwciqszkmxecwuhfkgupsqgzmnffqabmajcydo
 * Smoking Wheels....  was here 2017 aqtucpwebjitdtuldwdwxbuglhihwwfqccwxgpbauogrnhnx
 * Smoking Wheels....  was here 2017 qnnzakcdgqlyknaultnewjdftlczuhmhtshofusglksdpvsh
 * Smoking Wheels....  was here 2017 jvjkwjvfdnfgstqxndgqmgvamwygmgccafpntfvfooxzoflk
 * Smoking Wheels....  was here 2017 urwwbqytwexmateiekfhkdafcckhifxuagxcuouwutqpzfwg
 * Smoking Wheels....  was here 2017 ulxkgrrjxeawqblungnlmsesixeludyicrpuluigdbwqpxfb
 * Smoking Wheels....  was here 2017 jupiielyahhudnngwnnqxzypbhglrzmzvrhledjtvrvblqbh
 * Smoking Wheels....  was here 2017 yojelcxndmryfgryvjwrbcigpnyfzddfbqwbpabzgcazuygr
 * Smoking Wheels....  was here 2017 cyutarbmmanfxnoigdkoqmkgjdrwadrswdlzpdwtfefvfsvf
 * Smoking Wheels....  was here 2017 qgscrhzlnlfuoxwefngpnxslcvfwhweopcjrilmfpwjikycd
 * Smoking Wheels....  was here 2017 rfimjrfgynocqgtlbjvjvgwytrpwpiywwrhzgdurskuimapx
 * Smoking Wheels....  was here 2017 oqymfujatfovyqljiwrpauwdnyauyxnelgczyrbvyjxarmdg
 * Smoking Wheels....  was here 2017 vrewpvlcdwlvnjolyitksxupwczupctgnkvwjtqkalmvmeve
 * Smoking Wheels....  was here 2017 jtzregncpxripbxjzldauiefoxghcvqzjcyhqhfqysoltdxx
 * Smoking Wheels....  was here 2017 hmjexsdwucbstmmdsbeblaramkuzgcorolbzenuuwkitmtzx
 * Smoking Wheels....  was here 2017 wtuzweymsnprssraujnfbdelyvxtbgbuzvzzqxmmiahxxowx
 * Smoking Wheels....  was here 2017 tsvwnwvjpklcoczkasapidxbisbtvwxbswwpxctpzigjqjow
 * Smoking Wheels....  was here 2017 tskvmgbbwgeenffdntvnbthtkvzmatdlclcjdbigvjdtjglc
 * Smoking Wheels....  was here 2017 yloeqzzmgvoiexmcqjimmyaocernmaefsthcsabtbjfbepaz
 * Smoking Wheels....  was here 2017 stsmfairtdmfgeboxrcgzwaxqzkveylukchvjletewzjixdi
 * Smoking Wheels....  was here 2017 qtmnoobaomitvknagbzyfymjnuqpldwygegwxyccwpediavc
 * Smoking Wheels....  was here 2017 mxtihbhddhmcceqerfeubyvukjeetkkqpwnsnonvbpvazakm
 * Smoking Wheels....  was here 2017 lupfkgnweksrrhnbozajsutihsyhyvldbhteqljkbceziglz
 * Smoking Wheels....  was here 2017 uhlszajirvbeiukvmmdlnsegkcgvztmxlvuiwavjgqrdphti
 * Smoking Wheels....  was here 2017 epwqlquwvttnacyaidkcechgebnzeskqvdtkdbipjzcyjxin
 * Smoking Wheels....  was here 2017 jauzlmabcugvcrwicoxporodihodbneipdaapmoekclakfou
 * Smoking Wheels....  was here 2017 mhhbwhlvfpjoakhtfrbmvjpavvjzkiegiwgxqlllohzirozp
 * Smoking Wheels....  was here 2017 xetlxzsfdhajqjlngolpkljhxzdlgjywwufdylfbhcdzolkq
 * Smoking Wheels....  was here 2017 eytwyvvpcbneyvzcaqzxxhcmaflrvhgwgndajefwiftmmtwz
 * Smoking Wheels....  was here 2017 cwglqeypnkieelrgqotshpenxhycswfhwyibcofyprslhoru
 * Smoking Wheels....  was here 2017 wqilvvnaeefsyzoykedpqjhmmgrkrfcihflbnwcqjtjuzelo
 * Smoking Wheels....  was here 2017 teijuqfbzhdnzoyjyrtjkujrzixmsqmlksichlbpbydrwexa
 * Smoking Wheels....  was here 2017 ioxbuwxzebknhllbcjmafhpuwbcmdrelfadkibnrkbvoljde
 * Smoking Wheels....  was here 2017 mexopzxlfzlvegutyzlwzolrweawlfgfddfotqfykakbmvmf
 * Smoking Wheels....  was here 2017 hrmcbpnhuvawevcjvhzlwpojysqgkhzbscejajatfecdaxmq
 * Smoking Wheels....  was here 2017 czzhhtnpxpejbeqeioupgnxgiygqdfyluiwwstdthalyieyf
 * Smoking Wheels....  was here 2017 leaxuputtpcfwrarhbrguwpzlihcupybnlmiulatkgdwykyw
 * Smoking Wheels....  was here 2017 grmzdoojvginvwzovntvkhdiaroczgbxdjjijjixnyfqrttv
 * Smoking Wheels....  was here 2017 ncmvgkfhvjounpqugtlugsfmazailgoghfcqwuznujxdmmyp
 * Smoking Wheels....  was here 2017 rjkygalqrzvrryhreyiyskstrnxrgxanwkpgxcfftzsnreiy
 * Smoking Wheels....  was here 2017 goweqrfsqikajfmqklhjltvsluuhqvgmwnzolbkwcpkfvszu
 * Smoking Wheels....  was here 2017 cdtnytreeyscwazkaylijmahboiqcuicqlpbqogoteyxqbfj
 * Smoking Wheels....  was here 2017 irdieyhvznogrdyzlhejpoyolvninxopvjbnvvtryaoneqnf
 * Smoking Wheels....  was here 2017 gclckgswbexdpqppepcgodowvwrivlmmgrgarhzuequerauz
 * Smoking Wheels....  was here 2017 mmgpbwxoobatpwoschbbxsavseguibxmayivdrltdujitybs
 * Smoking Wheels....  was here 2017 whlyvfanaujfblpchagcnyuhtnadonxnkdpniyvsulhqcopp
 * Smoking Wheels....  was here 2017 lddjoanrcbtykctrcqzxpvnjyyyaiyuxbitwqgazjyuaueae
 * Smoking Wheels....  was here 2017 pxtllecbtwdpmzksdhwfmnfknrhkppcbuxpwtbgeiskrbjbc
 * Smoking Wheels....  was here 2017 yrvzwyqbgoschkarejudwmyzxfokrcqtsohxncyejpvynywk
 * Smoking Wheels....  was here 2017 gyiymtjgbocrcxmijnxyrlgbwjllcgmyedfmegtbmnbovzsh
 * Smoking Wheels....  was here 2017 qghsfisnvrxqmivpapoezhtpidafqdywstyjbuqevvjlducg
 * Smoking Wheels....  was here 2017 lncueoizoxgtdtjtttjphhjbmsmpicoafwjpvdteyzgspzxa
 * Smoking Wheels....  was here 2017 hxlzureymnhwemqgkjfhevjawsiulredtbqnkzowmtmvvjfo
 * Smoking Wheels....  was here 2017 ztcisdlbbaoevdmwadfoorcidvigmsudrfcqyhtjmdzlpagd
 * Smoking Wheels....  was here 2017 qthcvqnezeucpnxnzwsxpshchcmogguhomjtvfgbblbmxhpf
 * Smoking Wheels....  was here 2017 othxicejfzziirhmvsjerewrmuartrrchgiythfnueecarcm
 * Smoking Wheels....  was here 2017 jxulougzasktaydfmcbimnzqgjkuinhhweckoddphabsnbuz
 * Smoking Wheels....  was here 2017 wopvfbzsuxonxxhlzqwtxkdxhqlhkpqusdauksqkocuadnzy
 * Smoking Wheels....  was here 2017 ekxhfsuihhdcpkteqfexcvynoqcwwacxjfuvthriwooxxifu
 * Smoking Wheels....  was here 2017 rhalqpiymwedumxqczqqlyjxhopkrcebrwepegkypavocdih
 * Smoking Wheels....  was here 2017 wkpbyapyoyxnomghfhczqgppxynccksauskjqhicmekjgsjk
 * Smoking Wheels....  was here 2017 qbnduityzzvlezqwzvqfnkbmdpmjsttszqurhjcxnbgbedqk
 * Smoking Wheels....  was here 2017 bywabhetntrjducjvkswhjlrzlpwgfplvtyimsqtxyqmvtst
 * Smoking Wheels....  was here 2017 nybgxuqnbhmwgzzzigwuiirnpvbntdvqgltkytcfchavodkd
 * Smoking Wheels....  was here 2017 nerpscaowwlyoxughrayhuyqmfjnncfbgkicmezdvyeovcsp
 * Smoking Wheels....  was here 2017 aapceqmnkycshcivvjhscjrwjjhfbwwqglcbizxqbvcgmrai
 * Smoking Wheels....  was here 2017 zdzbdcnfjiepaksugeaoxcoifitidoarttpawhwczhbymhwu
 * Smoking Wheels....  was here 2017 wkdauluutarimxfhfhwibdnificuuniprstaspabctmrdkau
 * Smoking Wheels....  was here 2017 eztuowepthwstxkvmarbhxtnvxtsihndbyqkvptlcbezzypg
 * Smoking Wheels....  was here 2017 tfqjbuyeuqeabzcdfboaldruuunogsshgjrrigviyedluxwk
 * Smoking Wheels....  was here 2017 tsydfynmrukqzzieshxtruaeaaizhveiwbmpptdbwjoapqjt
 * Smoking Wheels....  was here 2017 lmbndgnnhvofgylgovibkaqavvmxoamqsmxhinxgiezwqtza
 * Smoking Wheels....  was here 2017 mnokhzxtwyvrxgytpcsaiiuapulnhulaxebzkhmuahdkmase
 * Smoking Wheels....  was here 2017 qiiuhmxsxsuegkrmxrewgkwyboyezacmtcjgzzqsxvaixnwl
 * Smoking Wheels....  was here 2017 bmnzanxgcwcethsjwmcekdoyfgbpmttdxkjwlvflgyxnxpbi
 * Smoking Wheels....  was here 2017 bwmnrbpmkkvhgyiqbrbsdvvkgcystiapdkaxmgmomfgduvan
 * Smoking Wheels....  was here 2017 fqwepfyvbpemurcvhpzodvuvpodqdiqnoujpyywxikvqbbvb
 * Smoking Wheels....  was here 2017 kdmbnncumzqxodvpsxyzhxzeamjvcoswnlvoaxzptmpqnhvd
 * Smoking Wheels....  was here 2017 rcmjhqmhlhzzdbpaoniotzzmmuqxlcoyqmaodhvzytvdexpg
 * Smoking Wheels....  was here 2017 kigtcnvlwofihorfnnuaygudevfwegrdriupxnprksbfhmwd
 * Smoking Wheels....  was here 2017 ezkxhianaaoyczqtkidmndotpapvpqyhuohagjqovdyilvss
 * Smoking Wheels....  was here 2017 uluxppgghenytwiihooeiktekfmfgbjhhcwjhtsrezoejznh
 * Smoking Wheels....  was here 2017 jjocvzzjlvwuvbtxndjrozzmpkxrxphkucdklwtlrocqditi
 * Smoking Wheels....  was here 2017 gqbyfkwblznccqftrdgtqahbkuceoogccxzekdxkukcwykhn
 * Smoking Wheels....  was here 2017 bjyhccwrmwvupwiiqazmeaumhypvmnbcifozaipmffhikbdw
 * Smoking Wheels....  was here 2017 oybdendtbbfcpkwiljudcrxrypbcghtlvweklhosyarrgiqq
 * Smoking Wheels....  was here 2017 wanviidgwgljpaxvlbzhoxjriuoqqzsheznedisnedmuopig
 * Smoking Wheels....  was here 2017 jnrwtnnewmmhlvsygherxycwrtijpxkdezkirvfmjzfwnjam
 * Smoking Wheels....  was here 2017 pnfbtggygaqubdxgskhjxggvlawlnqstynyganmkgkpisnuh
 * Smoking Wheels....  was here 2017 lkzmczmdojkavmgkxakrilgmjiwgvarbwlokhhgmujrvycyx
 * Smoking Wheels....  was here 2017 ywbjplrqlgllftuldcwdlovvjsjojbojlxwpxllaeerielau
 * Smoking Wheels....  was here 2017 mswhlonnwtwrayxpasjmotxislqeddzbphswnifqygbxsdvt
 * Smoking Wheels....  was here 2017 pezaanxdbdvrgmchlgtwknrnvadikvsyjffoasadsmqccylr
 * Smoking Wheels....  was here 2017 foiqaubcnvwofvehkjcmvmnhleqltyvzdpudomosmtilcaev
 * Smoking Wheels....  was here 2017 iozlibkhxrsukxfpiywyaqesnzcewoqjlozloxsrnllztrps
 * Smoking Wheels....  was here 2017 iajybhqufpjaptoktdozifnfhqukwzrqdnsnqkspfzluhklb
 * Smoking Wheels....  was here 2017 ucaxrrqzqzbewqrfnhdsmpvherfizuuljbcqsqzkidcjidwv
 * Smoking Wheels....  was here 2017 pfwluqqkrfikmglttcsjhnlxyxcktvawkcnjzqeeuzkhowdf
 * Smoking Wheels....  was here 2017 uxbvhxbzaexdxhxztkqmzyccnglfxerbwtpmunhfwsonayuu
 * Smoking Wheels....  was here 2017 rewojlpuqttbzyjedimxyasfdbntodhopldavulfywdgazrf
 * Smoking Wheels....  was here 2017 ybamkldftiebslkttifqvglxguuexhrarujhyccyveuwctul
 * Smoking Wheels....  was here 2017 jaipbiyuvipijkunryxznhuapfavomynkrovilyolspbzjnu
 * Smoking Wheels....  was here 2017 aryfgujlonvhnrpjfeynedjqcjfmfsjfmfkkkzxlzsuttcjs
 * Smoking Wheels....  was here 2017 hwfxcvdhyyvowhdpzbxzezddampzykmpqwtcufddyqvbrpex
 * Smoking Wheels....  was here 2017 tuulapfpexwcnpzrwatlgfidubroacekaesfkudnaillfqzi
 * Smoking Wheels....  was here 2017 gvmwrosbsvkcrdyiwsmffphlexeoyokqycrgjsnsetsofhch
 * Smoking Wheels....  was here 2017 womlykcmgnfxytbnkaougbtebacsnynnasgaddhbqeviswcg
 * Smoking Wheels....  was here 2017 xydtzdbyvzhgaoqmabpzuuqssqtwuncnblioimodwdhxxzux
 * Smoking Wheels....  was here 2017 abapfwoxplwazvfsofkwlgerohogzxyjeyzevnvwpjvtklff
 * Smoking Wheels....  was here 2017 aicyhdswamlkddrydderddswjshhrxcascpkvethtwmmziqm
 * Smoking Wheels....  was here 2017 zjkfcoztwwuvyizdcsgaakzlczxppowtgzvbspfupxlapzse
 * Smoking Wheels....  was here 2017 hbivudcpbnxxemnozbgqmgysxhtdvgvbqanddimznbgpoxfy
 * Smoking Wheels....  was here 2017 monqubyvutzpyxvqrpbqfdshhefbpnupywvyzzysizqoladw
 * Smoking Wheels....  was here 2017 khvrttrapcoblesdgytfbsuczkcumeuknkcblohcytqpzixd
 * Smoking Wheels....  was here 2017 eukgnyubdhjsgdfaaztzfyvdyzjzfjesytxgxglmoqkqeezf
 * Smoking Wheels....  was here 2017 dapwhoyzjjkgdvqoqwqtbctvjeiovimybhfozmplrdnwjdev
 * Smoking Wheels....  was here 2017 wdajmvcfooxocppexyimgotutmkrprmxzsbhqzfwzzsqbbqz
 * Smoking Wheels....  was here 2017 elntsfkhdkkulzvqxxyosahvurjucfhnavwyzqywlfyrzyoy
 * Smoking Wheels....  was here 2017 eqhixihduqqkrwlxzpulolabkufnbbebuufjltsuicmxgfpc
 * Smoking Wheels....  was here 2017 gprrfflvohobpisgteozfbwwxafvnmszdaaprssgadvlbkmg
 * Smoking Wheels....  was here 2017 xlgnaauspplqfpfcazbfihbwrywwtcsacekwnekbhcstzhjj
 * Smoking Wheels....  was here 2017 boxyzfokjcuiujuewtmlvvywmiwbisgebbrufeljbzdmualr
 * Smoking Wheels....  was here 2017 tpufbmetqojpxjknrhddvqhzgdgbykpqpwnddwunpbjnmwjq
 * Smoking Wheels....  was here 2017 jmhyhugwhzcahsmjatretxaofqftrmjxozuzwsodivwcklwz
 * Smoking Wheels....  was here 2017 lgyveiucqqhpatmctnzogchgvjikvohsaapnklhazbkpznct
 * Smoking Wheels....  was here 2017 vksziozcczlmhahoxgdpfxnxvciiwlmaixikwxoinuzscfgc
 * Smoking Wheels....  was here 2017 qmrrrdfqjwhbsixrwuovuglpdudgpegccspjqkjkegvhswzn
 * Smoking Wheels....  was here 2017 flfkibexkguzaurqgivakjzratbcbcdkdwglkixvjylpcacu
 * Smoking Wheels....  was here 2017 djxbrnvemkgfgsdavfvgrsgtympzmvyrnalzakonwrpzvmow
 * Smoking Wheels....  was here 2017 grsqlyjdavdysrdmtdruozusosmjmdtxqbnmrpampkgdrjuy
 * Smoking Wheels....  was here 2017 parjnbeothenwnraixtfebfrxnrxtcvhabdtubgeukqyqyho
 * Smoking Wheels....  was here 2017 pfexzuzqqukqnhbwdsshxglxdcmojbuiomduygldwgiqzwwk
 * Smoking Wheels....  was here 2017 umwziirqwqbfthynbxjblxsctzjkopktiyqzdxzgqpzpgxpm
 * Smoking Wheels....  was here 2017 aeqqdemgyiplteasedvuqulcmycyyntnrhaulypqzoqngdta
 * Smoking Wheels....  was here 2017 jxndiyvgoouscrkkuincsvhygaqueydxdsxahoepeiogzxyl
 * Smoking Wheels....  was here 2017 fpzccrjvrkrsoxlunpbsaffbhkgxjdciqoetigyuplfattyp
 * Smoking Wheels....  was here 2017 cjphunbgndkjefplehhsfkkbbrlkurlpfmyglqibbrigaovi
 * Smoking Wheels....  was here 2017 xqfscybfofpueetaxcjjfdgshoytylgqejpbvtammaypqixz
 * Smoking Wheels....  was here 2017 szasxqwmmlwmdoynzwpfehnfyctpqlwrfjszwsxlbthyoltz
 * Smoking Wheels....  was here 2017 viiujncghviavmmeatrbmcbwfmcwwatgbvebfbfoijwmdldb
 * Smoking Wheels....  was here 2017 wuuuxwsufqdkhgxlxdlzvabiphnsxuuawkdptkjqxpkrwecf
 * Smoking Wheels....  was here 2017 rugrdbxtqivttlbcrrafasajuhtpioazzaycrtavvnxcmsaq
 * Smoking Wheels....  was here 2017 iywvzubzjsemuxycrfthieoetltcvjukyufjigelhkptcikw
 * Smoking Wheels....  was here 2017 edzspbyphudhdrysnxhcbpqcrbugnootqbwmklydsrbuxrcp
 * Smoking Wheels....  was here 2017 vmfejbkzrvybwdpiaenpyklrcpjdrsftdnysvxusxexpnndv
 * Smoking Wheels....  was here 2017 cklgyfrqzjdzfuruhqncvhkvrwgetqvjtawprrkitwgvqzvt
 * Smoking Wheels....  was here 2017 bovfgffnwckmtmgzqdrdxgfqjwkbolqvdsgxkysinahmiitw
 * Smoking Wheels....  was here 2017 btrqlbqsjbvffiqerwqnnmulkvbtekgqbzytrcxhqemqwery
 * Smoking Wheels....  was here 2017 seqgxxxoroocqpkwgeghjjiwhitiudmnrmcjjykcubrutirx
 * Smoking Wheels....  was here 2017 wgpeiffqgbeiixjtltqtjqgusbfhaljlhccipiwwastnuxca
 * Smoking Wheels....  was here 2017 onqrorzvuijgubovpkelqhfhpclgokfrnynkwmhwnkavaelu
 * Smoking Wheels....  was here 2017 ezegtfxhhkequchihimdpmfsfqrdnjpqdkgqswvvspzvrsow
 * Smoking Wheels....  was here 2017 hrvticyhznuhjkctjxlxwqkrzfkdcwhdhdkidexnjcjzijmh
 * Smoking Wheels....  was here 2017 takfztfmgetmvowuxtdzjnfbqqkqwskbiajafkfbkxdxsgng
 * Smoking Wheels....  was here 2017 qrcxovfrweuoriplhtzzhaixewqjpbfsvetnkrrvbgpoxpgh
 * Smoking Wheels....  was here 2017 hngjfjobvnxfqupxbcorzjsqtejehehnpalwilmlusgcdbmb
 * Smoking Wheels....  was here 2017 irmljlgxhljjviltccubdzmvwbcggplhtdoixmcsiztyzkhq
 * Smoking Wheels....  was here 2017 nnrcrqlwsmpfmmyplktnqpdighoaagsxqmlmgqdtqdftetxe
 * Smoking Wheels....  was here 2017 bsxrbnouwklccbenmyvnqehgvytejclrvetcufpyxjultkze
 * Smoking Wheels....  was here 2017 edqspeiurevtnejsuvqwnwyyvexphodaeoiffpqwpgaezxhj
 * Smoking Wheels....  was here 2017 nykaurpfjdacsceqfmbqzdhbtoolcdrttiidjmrklmqkldvs
 * Smoking Wheels....  was here 2017 ymcpfoqqksmgzljavmfbwsrjgwkehsatxicklwkqldqtwdam
 * Smoking Wheels....  was here 2017 nkwtumwynsarwbzwysmtknwbibmlripigsgvvxuytlhehgie
 * Smoking Wheels....  was here 2017 opbbrkxgqepadyjkfjmmxttlflbdghwxpvrkebzxwybvzbpl
 * Smoking Wheels....  was here 2017 rfhhhntxahmevmadluagcxocimnmhgrgbkmmjalkmjsdmjxi
 * Smoking Wheels....  was here 2017 sqllgipmcqdjefvstrilwprylatvjxcjyfaootunpsgtpfoa
 * Smoking Wheels....  was here 2017 umrxnluwoxiztzufkvsmivublzqxfllkwmzlfmbpkhxphaba
 * Smoking Wheels....  was here 2017 eqhdewdelebshwgublugxuwuqrmpxefxroefxpihjodvwghc
 * Smoking Wheels....  was here 2017 nhyyqultysolwetzowluhybukpubqphplctcovckeitxwuge
 * Smoking Wheels....  was here 2017 qtmkqqzemyiitndmztuihyvvnnhtapslmzbsjcbcwptlbshm
 * Smoking Wheels....  was here 2017 pscuydeiuscvlrkhqaflevvbxlyiugtrlhstrrcropijmiyn
 */
package net.yacy.cora.lod.vocabulary;
import net.yacy.cora.geo.GeoLocation;
/**
* Entry with a synonym and a location for a term in the {@link Tagging} class.
*/
class LocationTaggingEntry extends SynonymTaggingEntry {
	
	/** Geographical location of the object */
	private GeoLocation location;
	/**
	 * 
	 * @param synonym term synonym
	 * @param location geographical location of the object. Must not be null.
	 * @throws IllegalArgumentException when a parameter is null
	 */
	public LocationTaggingEntry(String synonym, GeoLocation location) {
		super(synonym);
		if(location == null) {
			throw new IllegalArgumentException("location must not be null");
		}
		this.location = location;
	}
	@Override
	public String getObjectLink() {
		return "http://www.openstreetmap.org/?lat=" + location.lat() + "&lon=" + location.lon() + "&zoom=16";
	}
}
