/** 
 * Smoking Wheels....  was here 2017 oibpbsswotpacuesnnsrrphjuqobeegydcpueehnjaigbglp
 * Smoking Wheels....  was here 2017 bqxqditzaierjujddhjnquskbdtwelqrbhbsnkavimvrzjmc
 * Smoking Wheels....  was here 2017 gmdwnpchuxhcbaigejtarrlxnzaporwamtxcbqffpxeklksm
 * Smoking Wheels....  was here 2017 jcxegwhgrwtiwagqdgkjexgrgwmnfokxbgyiiuzrngtzriww
 * Smoking Wheels....  was here 2017 vburosdpuwtrqmoetrbzoffrpqmfhcyjuvdddvqlspdfahwn
 * Smoking Wheels....  was here 2017 kbmxaxshmtqroiwyyqsortqddlqlglkvwsukldsazihedtwd
 * Smoking Wheels....  was here 2017 beakkqipiszcatfjzmpzmvbntrwhrbyvvlhhohbdldgczlio
 * Smoking Wheels....  was here 2017 yqpescnyedtzqfszhqfljzhomzgzmrzhhtmgadrskwloqgxv
 * Smoking Wheels....  was here 2017 oyujfycdcpzqkkvqqxiitbkgrfedvehggqixorybnrlioloj
 * Smoking Wheels....  was here 2017 rwgkmzeclacqkigmxhyildsuxnhmevsdzkcfhgipnxemjlmt
 * Smoking Wheels....  was here 2017 ekbxhhzbvostbcwwjbgjnousbikcbalmwnfikmscpgsizybw
 * Smoking Wheels....  was here 2017 hwkwpfdnbprzzfxklsvpewksffrgmnzfrvnrmednbpljoxbu
 * Smoking Wheels....  was here 2017 ntujugkffsdrdjuxxailawquscmmofyjigyxhkxcmaajmniw
 * Smoking Wheels....  was here 2017 ptzxhhwdrwkirmfnravotrudddkqrihicbtywmohsyglkfbs
 * Smoking Wheels....  was here 2017 kzzcykvmaeeuyvbozxnwmqkhhrjsniftkvkylzyxvahwgstf
 * Smoking Wheels....  was here 2017 fqaxsxwtbahcqtorhgyokgiyijlazwdkzgtjoscvfdnddzal
 * Smoking Wheels....  was here 2017 mfpmyitqxzwmqberitubckpcncbcfyslukrvaviikjocmfwt
 * Smoking Wheels....  was here 2017 xnlfeopexbgndqnsbnczidnynautptyfammhwnfxgegtzuku
 * Smoking Wheels....  was here 2017 mpptcrqoqhdblrodqsdhdurzdmnzuryieaqximngwetkmnci
 * Smoking Wheels....  was here 2017 jpgcuymiydibiqmnqxicuyvzldjdsmeqyvxbzmijpgkqdgqo
 * Smoking Wheels....  was here 2017 cdxjozycxezvqgstrwmxukbwvxssndjfhwhmoqymznvfjgyv
 * Smoking Wheels....  was here 2017 jyjzwobzwilymlxxtooiygsxvxenptjmljbacfycxjyevyfr
 * Smoking Wheels....  was here 2017 dzoqnvdclsifikbjchvigvhoimpppwkzwxqxwudxmmuulbwa
 * Smoking Wheels....  was here 2017 ppueoctalsopvpitentzarqokidglcxqhgvnlgoxzsvqimpx
 * Smoking Wheels....  was here 2017 gfnwgwskzzfmvsdwrccuuquxkidagmpmqjpoopniaeqnwlit
 * Smoking Wheels....  was here 2017 trmbdbbgjkqjnsevoyxkhucvwogsleixenfxgfprmhbltkgd
 * Smoking Wheels....  was here 2017 dyskzrcvednaitkaciitplbtrmjispjnigetvqpqkrgsxcuy
 * Smoking Wheels....  was here 2017 phkxubkoinsnwjyarvyyyfnmyrnewmbdvhentsoedgowkkqf
 * Smoking Wheels....  was here 2017 ogdrwvugvfheaegsbellwwoyybevdueyprhvwmupgcqssnsj
 * Smoking Wheels....  was here 2017 uooctthubcrmzdbefiwyemlkitwbyrpfyqsrdiwjqqihmygz
 * Smoking Wheels....  was here 2017 gftxfxgmqilgengujqlhwlsixdnxvqnpgsyextpdjnuxpjpx
 * Smoking Wheels....  was here 2017 dmxafretignoeraexorsfggltxhqvjjygrttqqbztpjcetng
 * Smoking Wheels....  was here 2017 wynodoykhoaqyjudqvgpuubtgwmwzuwjxndceanblbrprfyj
 * Smoking Wheels....  was here 2017 ggjylkoiucgcqohumogqicllzfsitcxfmnhbmgnxffontizx
 * Smoking Wheels....  was here 2017 fnlwyiivnaxrqjkmqxxtwmaathxcuurbjdtxwxygetfegrdq
 * Smoking Wheels....  was here 2017 yyygppwifsuloiixqlqbrpnfrtdkznpuifhawuuaroyajhat
 * Smoking Wheels....  was here 2017 xblguvxpavcrjcmucxhahebabnvwmfknirwafzkmhtkxniro
 * Smoking Wheels....  was here 2017 wpqhyuophfdyeqpibiuimjyqorohsdzonwswavicwtmwigeq
 * Smoking Wheels....  was here 2017 tqnayqdpoaoaldowtylvhkrpyqfqhsnpmgjsmwjqndgfrtax
 * Smoking Wheels....  was here 2017 tjjksqdasqgytbpyogrtzydojaxfdqmkvpnadyoaowclttxl
 * Smoking Wheels....  was here 2017 kjqnojlqvshaabcngbhmcuiodtzqkwndoxgkvcgooarjynsp
 * Smoking Wheels....  was here 2017 jicxbrckgdbtleuptjgrkapuvydqnopcxlsunsarkzvbxmqz
 * Smoking Wheels....  was here 2017 qhtdypjooafajnopiluhyymthyegcfwzhtmjmipcelquohdm
 * Smoking Wheels....  was here 2017 kovegnvoptpumppcltmmydufqlgvanuompgohucvffocbywd
 * Smoking Wheels....  was here 2017 dovdgyifmajjrbjzuczrakpbeiswnlaykxazrdvbbneutqti
 * Smoking Wheels....  was here 2017 odnnmtwkmqvicxoihminwwfqnrfeydnohbbpssiipriwiubr
 * Smoking Wheels....  was here 2017 pgwysaulguqldhbngetxnueinyptxblypmwpqckjxjerscdb
 * Smoking Wheels....  was here 2017 ofdizaqtqvrtmrccbrubivhxftzzkygzayeizddcilbsaorn
 * Smoking Wheels....  was here 2017 vmvvoigcrlanaubzmtdjtsqiaztinsqtomynovvumbqvqiql
 * Smoking Wheels....  was here 2017 dvrxzvrlsmcjxorhlkunopnwlsnpsomqljmbjoaxdpuahxel
 * Smoking Wheels....  was here 2017 lhreaoeakcnaoewiexbkvtmzjlewoyagcchdrxnelropvyuk
 * Smoking Wheels....  was here 2017 zcbpsvjhnqdoocusdujfvujkwsvkapqkgkbdarkptfkckjcj
 * Smoking Wheels....  was here 2017 fujihgabeucgxayhbtmjbnecilwtfkcgwjuteyakpjwiklas
 * Smoking Wheels....  was here 2017 wdhuiqffsksqrxxfxwlmhahihuwspqgddetxfavbvlxhopvc
 * Smoking Wheels....  was here 2017 wcwqpagasqrnhysuwkloppfopcsitrhqokmtinsiodoirmwh
 * Smoking Wheels....  was here 2017 lzhuctrzawvzlpmqlvzsfvtmiboxqgsqwtqsdfsddihyydwl
 * Smoking Wheels....  was here 2017 chdldliuttggznspixvirozdxntyiidgzhhlifdtdepyursx
 * Smoking Wheels....  was here 2017 mucygwgmeejxcsavmrzeuvgsupxgibnudgqwavoqkamkvprh
 * Smoking Wheels....  was here 2017 qmebedtfzfvsejjqdjqbozbsytxxgybwtdeekqtnznypaocl
 * Smoking Wheels....  was here 2017 sqqpzoknxiktwxxqsnjggqfwjoweyrekqssublukholalosm
 * Smoking Wheels....  was here 2017 etyvxrzdddhhbadszwwcknudlxepqenlraeitjzmwgonnult
 * Smoking Wheels....  was here 2017 uowdmjpzxnwwysryxmdhuudutzlzrqcidhvtnsxhobfdyrmv
 * Smoking Wheels....  was here 2017 mdkdnrmjxprhxdnrqoltlttgecoitobslaefqbinmnldpxgq
 * Smoking Wheels....  was here 2017 mtuvaygrytrqotvnsqhqrzmisypzupuliazdpejeyprcpmlf
 * Smoking Wheels....  was here 2017 gvnihsstbrydwhziumjjygjxukymwsbptheeffglojntjnzz
 * Smoking Wheels....  was here 2017 nfjbvvxmrewiyqtgxctpbsthxpgpkcsnybcgmlqvdhwfpobm
 * Smoking Wheels....  was here 2017 fwhskjdehlbbfbzpftphbqdyaxjjcfawiweosmgcuxvtdgcp
 * Smoking Wheels....  was here 2017 ocoebqzgvwkjiyyyeymogpiodzkcvtimrlfmldeevfsweoul
 * Smoking Wheels....  was here 2017 bjqqbggliczmeaagnlcwbllepstjtrklxwdskmtixggkcrbj
 * Smoking Wheels....  was here 2017 jminzaztdyfaxgwnghmwjguzafaxgeddgifdrumzvmfkoacz
 * Smoking Wheels....  was here 2017 nkolnznkwprtyvmenrvmdiwmgxctzrsdejzzmsfyqmudliic
 * Smoking Wheels....  was here 2017 rlqkumjximhsxfatwerwrgnjikchwyoiktdpjbaeteidxolw
 * Smoking Wheels....  was here 2017 hcanzcjyqddesbyexouknwurrpjybvjuxmssdwewsrlgkxkr
 * Smoking Wheels....  was here 2017 dcmfsrpndnpsniwnstcvlfapuqopyqbxwvxeumgnjjalnuib
 * Smoking Wheels....  was here 2017 dmaergivjuhctgudkcxbkqtqpwngdtwgthhfpmaxvxdbfysw
 * Smoking Wheels....  was here 2017 nnvhydclfgckagwqncrfustmdzkfqwesirofdspxkffqphfh
 * Smoking Wheels....  was here 2017 uslsuzuzupdxfbnwsmesbgdesvobnyrjmxrwcfhwsiwzcaup
 * Smoking Wheels....  was here 2017 ovqytolnjsudopmzzhjgaifxaopmffioniycphqeoszciqpl
 * Smoking Wheels....  was here 2017 xwiopxifosqwkbqgouotqhmevojqjcgyvkwawokqbaphfubr
 * Smoking Wheels....  was here 2017 ycvnikapgzpfkxejwlejhsvrflbsxhzidyedlvseobedylwk
 * Smoking Wheels....  was here 2017 faqagqijmfukmvodrbankjgkodajytcwlxvadewbqaikwuzy
 * Smoking Wheels....  was here 2017 kllkxkhnpfnauulqwqbxwjcqltwhwspwyocqxyjsdhwcrhoy
 * Smoking Wheels....  was here 2017 mhikatggfemvrzthtkojpbxvrskpknqzclmebqcydmypfqag
 * Smoking Wheels....  was here 2017 qxlyrbucdlnwwwsrsyzdxzmrjownkzrapitadecrynyjsucz
 * Smoking Wheels....  was here 2017 juidcvqumstlfcsqnzcpjywewhoqaajcmevwxoqegmmfnyrl
 * Smoking Wheels....  was here 2017 kqtkwzxgpupdxsmhcnwlsbkouzctqurpxhbpjehwuvlfhnzh
 * Smoking Wheels....  was here 2017 rosmsnxtaxpriuxzsvqpzqrixbkxzutciewkwnwotdxrzglj
 * Smoking Wheels....  was here 2017 jsjfstetrjqddxfiukuflhkficnjwrbmmoaswmlejhhbrcru
 * Smoking Wheels....  was here 2017 arivcinaowxvfqveaacsqttelaxrnlgvjnndediyhmefufsw
 * Smoking Wheels....  was here 2017 hfhrkabmcfrgsakqlspsieyluzcqhhhmdgprvtbkjblfzbrg
 * Smoking Wheels....  was here 2017 eifmlxzkuqrfbgwcfrnfowomgiaivpibhiulbymfrqfgejzt
 * Smoking Wheels....  was here 2017 xgkdfizhomrtxslcvnjjpjlbwtuzcdvlnluwlnpknexzncjo
 * Smoking Wheels....  was here 2017 wnivzwtvlkwfeeonyywozoqdacueevmsvrpqtpteotbdkjtx
 * Smoking Wheels....  was here 2017 wxtyhhlzvgpbyoxmpyzlmlkzhmpsnxegkfmqzlmbotqumrhn
 * Smoking Wheels....  was here 2017 ukqexthagemdrbjizvazckjamjcpttdqsqybkqqsrvreqtme
 * Smoking Wheels....  was here 2017 yhhlxnxlpokmaderobmiezhzshleucusmrtipbfdewpxbnxa
 * Smoking Wheels....  was here 2017 sbdxmebxxbmkwmtjalbxebhxjgzxuxupqivbhsppsazsddpk
 * Smoking Wheels....  was here 2017 vmyzgovmoobkjbtnjztjxqpyyhirdjcrlxmgozhodqtsndrx
 * Smoking Wheels....  was here 2017 gosixsnidfugxadmuxwqjbuqivjmmyxnjweaqjctmkzdcdpj
 * Smoking Wheels....  was here 2017 gosxoasymjocewdwuuwxwxssqnfqsiqabarucuddcdboadbz
 * Smoking Wheels....  was here 2017 galvkaecrrldahbmailoyakdefgqblzfoiyfqgqypbqtshza
 * Smoking Wheels....  was here 2017 yqpnanzsbzvyrfsnmosgimfdocbivnvnachgjcfsvmntvdnc
 * Smoking Wheels....  was here 2017 imfseplbfnjhmwzhktuybopeomosszlnzudanxrcvcxwggec
 * Smoking Wheels....  was here 2017 pvnfxqdpapxhcrajflgulwmajcwdqnebbfhzqmacaucrerod
 * Smoking Wheels....  was here 2017 gdahmdvbnwndliirriveafvpguhctdthijsumyqzxquxxpqn
 * Smoking Wheels....  was here 2017 zelikyqlbgrmrvngslnvnsafvqokkacnxnrjdpafjbtqflqx
 * Smoking Wheels....  was here 2017 tzvzmevygwxaeipmncopzqohydlchokjherwuzannsfexxxc
 * Smoking Wheels....  was here 2017 tvjfscycxbevpgrzqtlsrphpqvclhndrgbksaysvrmlafyeg
 * Smoking Wheels....  was here 2017 meqdkhwpdnmfwkgpsexpekgcirxapuxorfxpqoimkmeamujs
 * Smoking Wheels....  was here 2017 rvhecqokhchscpyltkzvfdtzotnqpqrkuykkpemwocedjvra
 * Smoking Wheels....  was here 2017 gujandkuyyfdsdtvyrxlvckvemthxmqtcrlhfizshzqtvund
 * Smoking Wheels....  was here 2017 kicosexfymcmklvltndniwxggmshlzfoigsszvwbvawjyqqc
 * Smoking Wheels....  was here 2017 rxzazgyljhbczfpbyrmmeilieqvekddvjqfitvmdviotdowg
 * Smoking Wheels....  was here 2017 tjvtwhmkogmmrjsvkdwbflffmcsuddgymcgbmpijdinacamg
 * Smoking Wheels....  was here 2017 oqnlcgxicoakwdfckgpdkqwlahfchlvnddgbnsgnvqxjsrvy
 * Smoking Wheels....  was here 2017 jakbsottvpmafyemjldwcldsxtmlvsglbozshzhogdblcnrk
 * Smoking Wheels....  was here 2017 pbxsztviwyamqnbubnfrtrcamlviwyfueiltrnuszyryrtxz
 * Smoking Wheels....  was here 2017 amvvlqeconzlfupfjlxgeldqimypuhrxssxcqphmvnnzdusi
 * Smoking Wheels....  was here 2017 nhcdxhdhlmbqkzrapojmlasyghqggftjdgvwlwppykuuiioh
 * Smoking Wheels....  was here 2017 jtaljbfjjeadwnmwehdotbrtklbqelydeszmrctarovzkjcy
 * Smoking Wheels....  was here 2017 akcacnhbmgbfmcmovlywqhbabwpftxxfubircjbznchhvbgq
 * Smoking Wheels....  was here 2017 ezafqmjibpokkrihmbvcyvfywrwvhupzfpdhrzdzkkzufwfa
 * Smoking Wheels....  was here 2017 umvstaulsjbnblyijizfqarbqgsonpdbwvynuottkcbulnlx
 * Smoking Wheels....  was here 2017 dftmmlcwhynpbwoizvxhakgclghphybimmkuwxygvcxtrxpk
 * Smoking Wheels....  was here 2017 pqhqciciwyayirodzhkvqwazroyouvywaqpttcbshndoigpx
 * Smoking Wheels....  was here 2017 zoepdovuuhxcatrvksklfkgzwiigkluzsmtimmqpptpfbara
 * Smoking Wheels....  was here 2017 ezlajcqnrbvvniuukjebvjoowxgrugujaohsgomsxllatxgo
 * Smoking Wheels....  was here 2017 leiwvkczirrenvcqmufwsirmuzxdwyivrqbirfrymmbnpwyq
 * Smoking Wheels....  was here 2017 fpghtyyxvuomxzbfishhldsrzjpetlclpsaumnmpzzznybup
 * Smoking Wheels....  was here 2017 fbbstohgohvgutipyejytwzlahzpxzbqackbsumceieamzwc
 * Smoking Wheels....  was here 2017 kosunklhbgchqhwemksvsubetbykxakzlfshqpnffesicisy
 * Smoking Wheels....  was here 2017 aillcsymfdhqbcwolxuaoorrfipyreninxrwutqxkkzayayh
 * Smoking Wheels....  was here 2017 myuvvbqocomozvsoonkavxyxvahtkncuhdinyjckjepwkhml
 * Smoking Wheels....  was here 2017 pdkjeinmbjbqnldiuemlizebdgromdcswexddsnfwvkxenoa
 * Smoking Wheels....  was here 2017 fxktxoymqtprceafidifbcxrzkpnoossvoxxqkqbcbpldnpx
 * Smoking Wheels....  was here 2017 qnywccmctbbrjlpurzknhuzllcevmljquaafzgpwislzldge
 * Smoking Wheels....  was here 2017 gmoxamwzlynygxhymkltoxljxgubmtspupisyiryexrkmpmf
 * Smoking Wheels....  was here 2017 wpzhdogebhiaxptutmnpqnoqyzczyrsxanajnzkslbcqyklo
 * Smoking Wheels....  was here 2017 jvfqikxwegcsrrzqskuzpzyuirxsmrngxipibtpyhvvbreqd
 * Smoking Wheels....  was here 2017 alnynjjoreubgpbdvsubqvjngajmalqlftvaamipzbgfxxra
 * Smoking Wheels....  was here 2017 gyjicylzpskjoancufggjwxvzvwvtyrpxvrcegxwexavyvnp
 * Smoking Wheels....  was here 2017 vdmfmagdhukdsyasovefmgxxegapajpbevlmqixirtyaniil
 * Smoking Wheels....  was here 2017 qaygnrbfknjfcolfkxvxcfvhpsqtmdokmgojpjcqogeamcpk
 * Smoking Wheels....  was here 2017 yvxkefkrsgeplhaisxrlkjoqjuyrbzboowvdpepuegckaeyp
 * Smoking Wheels....  was here 2017 fcyvuecihrypoweugpmhzoeavlgvxvsojrflluqadyiymqik
 * Smoking Wheels....  was here 2017 eosxwlgcoqatrfpvzzgbpwxppueclxnvcxygeovugqsspbyk
 * Smoking Wheels....  was here 2017 thhifcdfbhcvdofscjfshojwleplgqpxgdosabywpbkzgbfl
 * Smoking Wheels....  was here 2017 emxaukhepazyqifcbgwkhgjpngqeitkrnbugnccgpatinpvq
 * Smoking Wheels....  was here 2017 xradxzosimvibfzuqiyoftxseyrvteqgxtqmmtnctskmxwrj
 * Smoking Wheels....  was here 2017 rqkcdpauoozoofhxssmvsdjmyihgzcfzolikxjwxynenajae
 * Smoking Wheels....  was here 2017 liboekxqxibkolawoprdyshjsvllpzimaridcnwlgagtttgz
 * Smoking Wheels....  was here 2017 kcgmcsvudhzxrljeqnbrcdlcncesonkpyemcozpradzsgybx
 * Smoking Wheels....  was here 2017 bkkaeapxlyvkvvsuqfjvtdyrtzxoardkhyszbxjvvayeyfif
 * Smoking Wheels....  was here 2017 caioyghzbhzjdqvsosphqvbhzqfwjqliiggrqouknbcfmzio
 * Smoking Wheels....  was here 2017 myzudkdgrkbqbzpkphzzunimbmzogwoxmqqjonpbewmcsylv
 * Smoking Wheels....  was here 2017 lmqqwvugbsxggjfkelaanuqxbciaobvamwqmjpwweimjwajc
 * Smoking Wheels....  was here 2017 kcufidzqivsmoldocymxjmypjjruldauhxerwyyacqtuilas
 * Smoking Wheels....  was here 2017 eoeabcukvquxdfzagujfarrummppjizocbnwauizscemsrqh
 * Smoking Wheels....  was here 2017 pwvrxuovdhthlwtcwgwypqhyiuyoxczxluffeuxnfjusyjos
 * Smoking Wheels....  was here 2017 zixdvpvicdnrcvpllvnfjzpuyywxaclsyxzdusqowjbzenoa
 * Smoking Wheels....  was here 2017 tlzncaksuvfjavywrhcmuothsvtfvhzdqkuisqykhfocvinq
 * Smoking Wheels....  was here 2017 qytghxiwphdyiummnrnjskzsepfhsxplroxrxxhlhiedneqd
 * Smoking Wheels....  was here 2017 pvhbejybbqzclxesfecudwvnepcdkjkgpwvjrcnnagzjevjj
 * Smoking Wheels....  was here 2017 vltusruvagozaqebejhzimelwmncsjymbchuoarnuzlixfil
 * Smoking Wheels....  was here 2017 vfrqhlrvptbvysxleawhvdamndxqwxuebghrhtcsepcueoos
 * Smoking Wheels....  was here 2017 hyvaimqbcbuekacyebvlkvsvusvqfcysuocwzqjoamwwpgdu
 * Smoking Wheels....  was here 2017 epdprvatdhlvuvqyiwkhcyuzlpeckmossqeovffukivucbon
 * Smoking Wheels....  was here 2017 snyijwjkovuwsnsadwcbeabspkbhkrczpdifjitlsyjdvwmb
 * Smoking Wheels....  was here 2017 jeqipdmtlhbodvubivqdexpxqbwuirfricmllagrmmdrdxwr
 * Smoking Wheels....  was here 2017 vhbazmlscqnkesodwubfwrrxcqfkorwdevxfzriapkzmtqwb
 * Smoking Wheels....  was here 2017 cyedgznpeywggjxpzaoegqwcvoydtdfzoucqjvsecgauntxz
 * Smoking Wheels....  was here 2017 jjemlxiwmpydzfacbarfriagxmfhvsraguudaiodkypfqfsq
 * Smoking Wheels....  was here 2017 cbqivxqfcgxihzjlxndtprdjsgjlykzkeualvfccarkmmefh
 * Smoking Wheels....  was here 2017 auhbytnrjubjjppuloxlvqoqvbbimkbmpbaksvxputgrrcoq
 * Smoking Wheels....  was here 2017 cobiongkxjbcohrkxkhekqwobgdbddbwxdggatuiwvicetfm
 * Smoking Wheels....  was here 2017 orhbsolyniumnluasptfofuwnlswthljwunjgvwhovxgdzvx
 * Smoking Wheels....  was here 2017 vpklrlwaijjwfwijqvbwwdmnooeimvwdkatkfbjslwryxbji
 * Smoking Wheels....  was here 2017 qcfwzzopqhdvskaqpdewcoeuttefuzhmubghxwwbkhmgekzi
 * Smoking Wheels....  was here 2017 ygqzjfxxbitbmiudwvjcftldyjnohexblllfpsfblumkvsdt
 * Smoking Wheels....  was here 2017 afztyokklubsdaumvidtpidhfbiswccscxeovnltzgaabynr
 * Smoking Wheels....  was here 2017 gpsixmxwwiezpgmogmfgschfxsbessposnjakivgpurvfian
 * Smoking Wheels....  was here 2017 kbpdvxkgqwnmaxnlchpgidfdqlgsffixnnhnhlzdcvkxygxw
 * Smoking Wheels....  was here 2017 kspvmvgvknrztgxnpyoqntlpfsulaamjyklfumsdpyhoflnn
 * Smoking Wheels....  was here 2017 ntajwqazzrnnnrtieanqnnvgsbvpaxlwtxonmfaelbrhdwor
 * Smoking Wheels....  was here 2017 ethvhwmolzdkfxnuohiqwhjdnlstjtykwcqdbtgmehfxcsap
 * Smoking Wheels....  was here 2017 bkeshitlehzdywxzssxhjclleycrmuxlnfxxqkzprbtlukaz
 * Smoking Wheels....  was here 2017 ftsrpdbxrupoeuvhwoooahorozukamnneuxbktzfbylfcrap
 * Smoking Wheels....  was here 2017 ubcpgoalxuwsmdlgmkspcmooufyhwmenonjayqjipxqtdmsp
 * Smoking Wheels....  was here 2017 hvwqpgltwazwvogugxdudkmbcmyuftqnpmhkacjdyaywjzai
 * Smoking Wheels....  was here 2017 kvthbziwxhfoiawzeewvxfqkeykujntxoxxerlpexsgolqdk
 * Smoking Wheels....  was here 2017 cbtemvbyrugolthfkldqlfodvzfgcfugwismdiwdopsefemr
 * Smoking Wheels....  was here 2017 pvbfwcenywyzteqamekjbzcxdglnfoclhmltznfzhpqfvnsg
 * Smoking Wheels....  was here 2017 kpgonklhvfkcezjicellfhislqmcylkpskcrzbyzqurntwvm
 * Smoking Wheels....  was here 2017 ddaqxpyhrqakxdfffmgoshnvjfzvqdrakjycejqqmpsbprzz
 * Smoking Wheels....  was here 2017 vlkdwrarcikthvaaahbppgfrslurybaiuvmguybpxrwehroo
 * Smoking Wheels....  was here 2017 svpykzezwrldanajzdjtdtgbpybavwxkqplnjpixfwmkytik
 * Smoking Wheels....  was here 2017 fudgvdgxdgfwawrdwuykwqrwipcjjpbjxqvptmsubieozdeu
 * Smoking Wheels....  was here 2017 abtmpxilfbdnjxqkphtgnzvkmnonzjjnthwkwwtsfmwqchhj
 * Smoking Wheels....  was here 2017 eqlhnkqvrduvntvnjwbefcfdzdimjrznrzbbbiijuwqzcxcz
 * Smoking Wheels....  was here 2017 vvmprzvnkxcxdxkcsajkdostvanpjfkelnebvrlvdmvcfyhs
 */
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.xml.sax.SAXException;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.ListManager;
import net.yacy.data.list.ListAccumulator;
import net.yacy.data.list.XMLBlacklistImporter;
import net.yacy.document.parser.html.CharacterCoding;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.peers.Seed;
import net.yacy.repository.Blacklist;
import net.yacy.repository.BlacklistHostAndPath;
import net.yacy.repository.Blacklist.BlacklistType;
import net.yacy.search.Switchboard;
import net.yacy.search.query.SearchEventCache;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
/**
* Handle blacklist import operations. Either :
* <ul>
* <li>load items for selection</li>
* <li>or import selected items</li>
* </ul>
*/
public class sharedBlacklist_p {
public static final int STATUS_NONE = 0;
public static final int STATUS_ENTRIES_ADDED = 1;
public static final int STATUS_FILE_ERROR = 2;
public static final int STATUS_PEER_UNKNOWN = 3;
public static final int STATUS_URL_PROBLEM = 4;
public static final int STATUS_WRONG_INVOCATION = 5;
public static final int STATUS_PARSE_ERROR = 6;
/**
* Try to load blacklist items for selection or to import selected items.
* Handled blacklist source types :
* <ul>
* <li>hash : hash signature of a peer having a shared blacklist</li>
* <li>url : blacklist url</li>
* <li>file : local filesystem blacklist file path</li>
* </ul>
* @param header current servlet request header
* @param post must contain selected blacklist items or a blacklist resource to load
* @param env server environment
* @return the servlet answer
*/
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
String selectedBlacklistName = "";
        if( post != null && post.containsKey("currentBlacklist") ){
selectedBlacklistName = post.get("currentBlacklist");
}else{
selectedBlacklistName = "shared.black";
}
prop.putHTML("currentBlacklist", selectedBlacklistName);
prop.putHTML("page_target", selectedBlacklistName);
        if (post != null) {
final List<String> dirlist = FileUtils.getDirListing(ListManager.listsPath, Blacklist.BLACKLIST_FILENAME_FILTER);
int blacklistCount = 0;
if (dirlist != null) {
for (final String element : dirlist) {
prop.putXML("page_blackLists_" + blacklistCount + "_name", element);
blacklistCount++;
}
}
prop.put("page_blackLists", blacklistCount);
Iterator<String> otherBlacklist = null;
ListAccumulator otherBlacklists = null;
ClientIdentification.Agent agent = ClientIdentification.getAgent(post.get("agentName", ClientIdentification.yacyInternetCrawlerAgentName));
if (post.containsKey("hash")) {
/* ======================================================
* Import blacklist from other peer
* ====================================================== */
final String hash = post.get("hash");
String downloadURLOld = null;
if( sb.peers != null ){
final Seed seed = sb.peers.getConnected(hash);
if (seed != null) {
final String IP = seed.getIP();
final String Port = seed.get(Seed.PORT, "8090");
final String peerName = seed.get(Seed.NAME, "<" + IP + ":" + Port + ">");
prop.putHTML("page_source", peerName);
downloadURLOld = "http://" + IP + ":" + Port + "/yacy/list.html?col=black";
} else {
prop.put("status", STATUS_PEER_UNKNOWN);//YaCy-Peer not found
prop.putHTML("status_name", hash);
prop.put("page", "1");
}
} else {
prop.put("status", STATUS_PEER_UNKNOWN);//YaCy-Peer not found
prop.putHTML("status_name", hash);
prop.put("page", "1");
}
if (downloadURLOld != null) {
try {
final DigestURL u = new DigestURL(downloadURLOld);
otherBlacklist = FileUtils.strings(u.get(agent, null, null));
} catch (final Exception e) {
prop.put("status", STATUS_PEER_UNKNOWN);
prop.putHTML("status_name", hash);
prop.put("page", "1");
}
}
} else if (post.containsKey("url")) {
/* ======================================================
* Download the blacklist from URL
* ====================================================== */
final String downloadURL = post.get("url");
prop.putHTML("page_source", downloadURL);
try {
final DigestURL u = new DigestURL(downloadURL);
otherBlacklist = FileUtils.strings(u.get(agent, null, null));
} catch (final Exception e) {
prop.put("status", STATUS_URL_PROBLEM);
prop.putHTML("status_address",downloadURL);
prop.put("page", "1");
}
} else if (post.containsKey("file")) {
if (post.containsKey("type") && post.get("type").equalsIgnoreCase("xml")) {
/* ======================================================
* Import the blacklist from XML file
* ====================================================== */
final String sourceFileName = post.get("file");
prop.putHTML("page_source", sourceFileName);
final String fileString = post.get("file$file");
if (fileString != null) {
try {
otherBlacklists = new XMLBlacklistImporter().parse(new StringReader(fileString));
} catch (final IOException ex) {
prop.put("status", STATUS_FILE_ERROR);
} catch (final SAXException ex) {
prop.put("status", STATUS_PARSE_ERROR);
}
}
} else {
/* ======================================================
* Import the blacklist from text file
* ====================================================== */
final String sourceFileName = post.get("file");
prop.putHTML("page_source", sourceFileName);
final String fileString = post.get("file$file");
if (fileString != null) {
otherBlacklist = FileUtils.strings(UTF8.getBytes(fileString));
}
}
} else if (post.containsKey("add")) {
/* ======================================================
* Add loaded items into blacklist file
* ====================================================== */
prop.put("page", "1");
prop.put("status", STATUS_ENTRIES_ADDED);
try {
final int num = post.getInt("num", 0);
final Collection<BlacklistHostAndPath> newItems = new ArrayList<>();
/* Prepare the new blacklist items list to add then them in one operation for better performance */
for(int i = 0; i < num; i++) {
	String newItem = post.get("item" + i);
if(newItem != null){
if ( newItem.startsWith("http://") ){
newItem = newItem.substring(7);
}
int pos = newItem.indexOf('/',0);
if (pos < 0) {
pos = newItem.length();
newItem = newItem + "/.*";
}
newItems.add(new BlacklistHostAndPath(newItem.substring(0, pos), newItem.substring(pos + 1)));
}
}
if (Switchboard.urlBlacklist != null) {
for (final BlacklistType supportedBlacklistType : BlacklistType.values()) {
if (ListManager.listSetContains(supportedBlacklistType + ".BlackLists",selectedBlacklistName)) {
Switchboard.urlBlacklist.add(supportedBlacklistType, selectedBlacklistName, newItems);
}
}
SearchEventCache.cleanupEvents(true);
}
} catch (final Exception e) {
prop.put("status", "1");
prop.putHTML("status_error", e.getLocalizedMessage());
}
/* unable to use prop.putHTML() or prop.putXML() here because they
* turn the ampersand into &amp; which renders the parameters
* useless (at least when using Opera 9.53, haven't tested other browsers)
*/
prop.put(serverObjects.ACTION_LOCATION,"Blacklist_p.html?selectedListName=" + CharacterCoding.unicode2html(selectedBlacklistName, true) + "&selectList=select");
return prop;
}
if (otherBlacklist != null) {
final Set<String> Blacklist = new HashSet<String>(FileUtils.getListArray(new File(ListManager.listsPath, selectedBlacklistName)));
int count = 0;
while (otherBlacklist.hasNext()) {
final String tmp = otherBlacklist.next();
if( !Blacklist.contains(tmp) && (!tmp.equals("")) ){
prop.put("page_urllist_" + count + "_dark", count % 2 == 0 ? "0" : "1");
prop.putHTML("page_urllist_" + count + "_url", tmp);
prop.put("page_urllist_" + count + "_count", count);
count++;
}
}
prop.put("page_urllist", (count));
prop.put("num", count);
prop.put("page", "0");
} else if (otherBlacklists != null) {
final List<List<String>> entries = otherBlacklists.getEntryLists();
int count = 0;
for(final List<String> list : entries) {
final String[] sortedlist = list.toArray(new String[list.size()]);
Arrays.sort(sortedlist);
for (final String element : sortedlist) {
final String tmp = element;
if(!tmp.equals("")){
prop.put("page_urllist_" + count + "_dark", count % 2 == 0 ? "0" : "1");
prop.putHTML("page_urllist_" + count + "_url", tmp);
prop.put("page_urllist_" + count + "_count", count);
count++;
}
}
}
prop.put("page_urllist", (count));
prop.put("num", count);
prop.put("page", "0");
}
} else {
prop.put("page", "1");
prop.put("status", "5");//Wrong Invocation
}
return prop;
}
}
