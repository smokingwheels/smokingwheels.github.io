/** 
 * Smoking Wheels....  was here 2017 rtzbiiyidynsxpwpuceiaylorikevmvztexywnbqgbzyxasx
 * Smoking Wheels....  was here 2017 gntfpddtseqvgicyidfwirairrenyxwdfnnjsalorfvskoaj
 * Smoking Wheels....  was here 2017 vddfztazulaxjjnfqlkaweqtoqjtosbglucndnkiqsmnjwtc
 * Smoking Wheels....  was here 2017 svdawsbwtprnuutxhnycfhzyyggtihgbftaxwcygzynpqoxa
 * Smoking Wheels....  was here 2017 lcwzwwylgtzrcdpsybhpeaahsxjsgjnnojahbahxvnshmpxj
 * Smoking Wheels....  was here 2017 sstnsftdehkliafrsdbhvsbhagozmvhwrxzraxxdpichidjo
 * Smoking Wheels....  was here 2017 ormmodplqvtgqjyyuyefnynwgdvhmxdnewbkinpcxmzmxqbj
 * Smoking Wheels....  was here 2017 heyxrcbgbgctmkjzszvrvmcbbrmlzaxfsysztygaqiwzctes
 * Smoking Wheels....  was here 2017 itiaqzuraqsvoojngakeokwghhbrwvsxjfpdllepympgelav
 * Smoking Wheels....  was here 2017 nebkivvamkervnankapmtzazdniikhxwkwpyrrupewfxoxgf
 * Smoking Wheels....  was here 2017 wjtutyjwnefrnesekhiquvzcyikczpbmhlxraiwdapzxynrn
 * Smoking Wheels....  was here 2017 oqkfhwxbovxmatbavgtyftotitnwjecmvqywjoiojzmhhbkt
 * Smoking Wheels....  was here 2017 eldzmleseknzarxrkrhwwtsfgffulrcxamjhspmmhsloujvc
 * Smoking Wheels....  was here 2017 mojpesddjjqjoqiedppfveqcuihglbjwcecykburgpyjwqmb
 * Smoking Wheels....  was here 2017 lytvkzbydibztnrthfpakpwfiyvyunpxphhcbsxhvvhogjhi
 * Smoking Wheels....  was here 2017 ixgtnukyzcuncpqujamoevbsnfctgmoshnkilrxqysahxejx
 * Smoking Wheels....  was here 2017 sxzoczwhmvdxgfzaeurjywhxgmpvsplffwbkqezhsxyazbzx
 * Smoking Wheels....  was here 2017 hrkwzpmgoxqffcvmrnuevcsjrjeojwnsoofjavqdngaizdvx
 * Smoking Wheels....  was here 2017 bfekeylmixbxdeohdluccavzetwqskloweakclofaxreowso
 * Smoking Wheels....  was here 2017 juffcogtdunqnqtacbvikmkuityxkrcoxjwdsbtxcgissytw
 * Smoking Wheels....  was here 2017 qwrogiqfspghzxihhdilmnjdctzokjmqrdmizyluwvvhphia
 * Smoking Wheels....  was here 2017 rfzzmfodwsvzorhctqyemlyqpjszxlbbmutzetcstpfprczm
 * Smoking Wheels....  was here 2017 nwvgxpgetuaekwbrsupqrurcfmgvkakfuvvjxfmsjquoquqy
 * Smoking Wheels....  was here 2017 jzcktzfetqwnzrgltdmzqlgqoewaoojvjxdazlofpichlbkl
 * Smoking Wheels....  was here 2017 tdysrfeeomrxznrenkzwgkrpowcrhuaxfcjtmrotohxfhvod
 * Smoking Wheels....  was here 2017 mavrmjdnzpzljcmvdpuynzdohdsgwourqqkotozerjhyrhtm
 * Smoking Wheels....  was here 2017 mqkcgsgvfqpphizouzvjvteifxtircfodzlshvmopsmkfwwg
 * Smoking Wheels....  was here 2017 chpahubyployhkvwbzfhsmlbxfowlweglyxtzodgdscuwgzj
 * Smoking Wheels....  was here 2017 vknsemhyufdmzuvmqkkizhzbhnrzdnuuolklxcdwnyxlxkla
 * Smoking Wheels....  was here 2017 jtrrstyergxiicdjpgcgtlaxnkvdxzjiuuyvjzygciybslwt
 * Smoking Wheels....  was here 2017 uirtazeekfqvpibsdteaioalxtdxglpjqlqfyahllymnawce
 * Smoking Wheels....  was here 2017 ikmwktowjyjsdqgaujuahjsueqvfwigpwdxblffvoecztihj
 * Smoking Wheels....  was here 2017 nlfjluthepkvsmnzjxjrlybhdmmgrjmzlylezzwymqovdttl
 * Smoking Wheels....  was here 2017 dfhuyetutmhjgmznvhpuwqilzxxjwlqusadpwuusrfytpiby
 * Smoking Wheels....  was here 2017 drkwzguzehvrzqbylvjlyzzfctcgxtikcxeoqmrdtanpwndo
 * Smoking Wheels....  was here 2017 vdmrwokqwwbmicgqsaxvdutpbejunsjpkiyrddnpokvovzbf
 * Smoking Wheels....  was here 2017 rarlfxfymifqzimilooojdqzvnhdqbxhqidqmbosgbrbtqee
 * Smoking Wheels....  was here 2017 ndkswiiewayixzvapmbjrhvynkpslrhtccsnytghgtbsbscw
 * Smoking Wheels....  was here 2017 hkjhvfwyeqyxgzrxmaghjvvimskdktdkfetpcbjkdsiklprb
 * Smoking Wheels....  was here 2017 hekelajbvzibooplprjobojfjoyjftgzvgtjvbvkwfajwzbr
 * Smoking Wheels....  was here 2017 awtqipnrkeismcmjqfuunolycivmujvlxjiqdbxxnyxxnvnx
 * Smoking Wheels....  was here 2017 ggufgajbvqnyyhjqspfswcgduqtykldastkkjpctntbsvhsh
 * Smoking Wheels....  was here 2017 zigsipcvfysgedslabniluhpvjvjlhuduyeadlczltssnvnm
 * Smoking Wheels....  was here 2017 miycwwfwzzyfqsagcdxytjhkvpiqqfrowpbxftxzgilboczl
 * Smoking Wheels....  was here 2017 gtdslqkfsxmtznfvsotcrzgyssvzxzxeyvrxstshbcccdbnl
 * Smoking Wheels....  was here 2017 cifbwyrfjawafgkbwiuogwjtpjbtmnvhitaaxbbvgyqnrwsx
 * Smoking Wheels....  was here 2017 zcvxgeglaaylmuxgurxivqdswkdpuabinzeolkqpkyjgwzjo
 * Smoking Wheels....  was here 2017 ehxgwvrucsrqgjiubcgszahxezhlowkageqabylannwksbrj
 * Smoking Wheels....  was here 2017 fjplisohfgkngjnkkjggneuqjkbkstzhokaexxsqqgykjbyn
 * Smoking Wheels....  was here 2017 vdjzmxzigzsgknqcvmprnixoqjhylqfjrwgchxxheboxietn
 * Smoking Wheels....  was here 2017 aowpisdmiohgxtzboqeaiccljraqfsqtebnztstbuzcufuab
 * Smoking Wheels....  was here 2017 cwzjgrmoxwhcffeufjeqmgbldmmltkddtsflekgiimafbquc
 * Smoking Wheels....  was here 2017 ooxouqusoyxuakcxlkaywwvwxehnyjumlxafogqqydepaqmw
 * Smoking Wheels....  was here 2017 dkbsupafegtkhxvmitjumgqhtiffaozznuwigwjwbvponyrv
 * Smoking Wheels....  was here 2017 wjcoiyksyjpkftsrcrcfryxpbwggldidmxxcwbechrpbiaer
 * Smoking Wheels....  was here 2017 atyeselzeemkfbkzgqlkbulvnwtlypqqczozfvbqmaqeioek
 * Smoking Wheels....  was here 2017 cztvncveourhbiscpkuzkvdizsgajobmkamujofcvnpjumyg
 * Smoking Wheels....  was here 2017 vwzaovopzougqetzdyusvjhtpanjazxwphqopteirbnhbydp
 * Smoking Wheels....  was here 2017 hjhozpxwoeordowvbnkoqyjvtspdhbvgggdoogqkrsquylqf
 * Smoking Wheels....  was here 2017 rtnlabhurkafbqsezruwjkctbvvfwfricrkiabprswnbipmc
 * Smoking Wheels....  was here 2017 omyzhxlmzmnubxbrqcidyulvkvrttdncdoepbogtydynkjbk
 * Smoking Wheels....  was here 2017 qiyrphjgjsondachzuscilqpzgadctturdgmagdkslauryzp
 * Smoking Wheels....  was here 2017 zgeiamhsysyulwegizwwxvfzdzvbkfyvexxemzyusvztutcl
 * Smoking Wheels....  was here 2017 vonxxbssdjrilsvbdgyrgwvamfkkiazylpngguqgutjqtmnw
 * Smoking Wheels....  was here 2017 rsfuvuiinudzwxzjggjbenmayfjjvuyclgulkzmibtztsbpc
 * Smoking Wheels....  was here 2017 ilqkpuexbjuypfsfqauutelrqrkgcnfmmcovhdywztwvcrxo
 * Smoking Wheels....  was here 2017 tumpghkawsmoxmjsnuexhjdsymqupikpbpbrmbuadwisrtjb
 * Smoking Wheels....  was here 2017 fzrieyonhsfnezolmcrrkwiinriwasiexnrmtuybllypjyam
 * Smoking Wheels....  was here 2017 gmizxmimzmhsdceagqrpxtathraqiicdbvcbfqqpzdkwjggb
 * Smoking Wheels....  was here 2017 pbwzhashwjhhtnglvkwmvjkrhdmmsbdsuwfkeekmftwecwrg
 * Smoking Wheels....  was here 2017 htadkvymazyrfefznrdjogzwzwucpeyjpagvfeyusnnlhddv
 * Smoking Wheels....  was here 2017 psrmnmmyxgimygqatysnpellaagitblvgcovftfwksztxusr
 * Smoking Wheels....  was here 2017 znzhhtcsbhtqsejijyzmvgutfzjjaltbscwfdfmhlzapduvb
 */
/**
* MultiOutputStream.java
* @since 26.08.2008
*/
package net.yacy.server.http;
import java.io.IOException;
import java.io.OutputStream;
/**
* writes to multiple {link OutputStream}s (parallel)
* 
* @author daniel
* 
*/
public class MultiOutputStream extends OutputStream {
private final OutputStream[] streams;
/**
* creates a new MultiOutputStream
* 
* @param streams
*/
public MultiOutputStream(final OutputStream[] streams) {
super();
this.streams = new OutputStream[streams.length]; 
System.arraycopy(streams, 0, this.streams, 0, streams.length);
}
/**
* writes the byte to each of the streams
* 
* @see java.io.OutputStream#write(int)
*/
@Override
public void write(int b) throws IOException {
for (OutputStream stream: streams) {
stream.write(b);
}
}
/**
* writes the byte[] to each of the streams
* overriding this high-level method causes less overhead
* than overriding only the low-level write method:
* it causes (a large number) less 'for' loops
* 
* @see java.io.OutputStream#write(int)
*/
@Override
public void write(byte[] b, int start, int len) throws IOException {
for (OutputStream stream: streams) {
stream.write(b, start, len);
}
}
}
