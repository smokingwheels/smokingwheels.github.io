The dictionaries directory contains files that YaCy can use to generate
- better 'did you mean' hints
- annotated content for search navigation (future feature)

These files are once read and translated into a YaCy-internal format.


To integrate dictionaries, you must download them separately in store them in DATA/DICTIONARIES/source
You can do that with the following files:


Korpusbasierte Wortgrundformliste DeReWo des Institut f�r Deutsche Sprache:
derewo-v-30000g-2007-12-31-0.1.txt
from
http://www.ids-mannheim.de/kl/derewo/derewo-v-30000g-2007-12-31-0.1.zip

