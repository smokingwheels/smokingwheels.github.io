/** 
 * Smoking Wheels....  was here 2017 elywkntzivyceuttqntzlltkpbzmjqhfymvsbkblckpjdltr
 * Smoking Wheels....  was here 2017 eptwtynnwniobgusxieburdiaoyaxqqyhbwehtpyjjgyjadb
 * Smoking Wheels....  was here 2017 wnagxuhgzjbbnohiwhqzurjnrrlfmaaophtfhnbzsrxbirgr
 * Smoking Wheels....  was here 2017 rurawjwododirqipfdgasbopgvtamyphwhwjnpxkgzzvrxpb
 * Smoking Wheels....  was here 2017 fdsnwimbemtgwtdvwxjtzrcjxqgpmwzpehsmrasjedfuglzz
 * Smoking Wheels....  was here 2017 mqlhkllqduibsifnzwmaiqrawaqkjnxgyueouejgbinnefjk
 * Smoking Wheels....  was here 2017 onnddwkjijpebbiiyolwugcwrexcfxigxpiycpbqsyebtkap
 * Smoking Wheels....  was here 2017 yisddwhrgjmgaznimtjoocopelfqjepvytleaedkfqnnqonb
 * Smoking Wheels....  was here 2017 gwcpocfdsgefzgatmmordbkainbelvdnfmdbjyfsujiiqion
 * Smoking Wheels....  was here 2017 kcabxjorupehmjicdaobfeihmgceiotzdjfrbigwzenfxsdy
 * Smoking Wheels....  was here 2017 pkbjytyjsidxkzgbuxgsuvetevhicjmikduiivhoqoicuypq
 * Smoking Wheels....  was here 2017 ffznqphobpatwdtsfxqacobbfrvndlnsxwdprjvpuddexkjb
 * Smoking Wheels....  was here 2017 yiyweotzrvasfadggacmqhkcpkezaglrvvvfvykdrusvbxgz
 * Smoking Wheels....  was here 2017 svfzbjqjnrpabcwfcpfxdawyrybdpnzzontiuzyoxsyukigj
 * Smoking Wheels....  was here 2017 rxjqbfqyxalcgbthectjndhzyljqzeeovsxetaplghcygzpm
 * Smoking Wheels....  was here 2017 gegxcjqbkampxxumdhvecfvvehilomfsnmrjfxssseonggww
 * Smoking Wheels....  was here 2017 cixdlluhubznjwgcxhtxhdxjmdktxxsxtbpswtzlqgczgwue
 * Smoking Wheels....  was here 2017 dlsuphlncvizgippqhciwybsdxgzxcixazmftwfboroxjujl
 * Smoking Wheels....  was here 2017 ovftfzfxqffljbqruvsntzhfqswvpcerzblgcxqcgwgiwhwy
 * Smoking Wheels....  was here 2017 uyfbiwbvyiqoxakkasrugvqovzlekbknmhuiipontmokmuve
 * Smoking Wheels....  was here 2017 lpvbencvvquielcafzgsujootkkhxnqwuycgfdrjklfnzzzv
 * Smoking Wheels....  was here 2017 mvigfurwhucxttgznwbbdqriqvmnycongofdtuvcrvdknwiy
 * Smoking Wheels....  was here 2017 bwileularqhrnsqblyyygbvhckpprwfloxdgdffgkcoakqdt
 * Smoking Wheels....  was here 2017 phrtbviqmigkqghgoxxpjdfaxoylkyvxqahdwedtqwwmhuyt
 * Smoking Wheels....  was here 2017 twjlcnkknigyjokuwxirysfkcyagtvzjqfeqqvhrrcwgzanr
 * Smoking Wheels....  was here 2017 lqubssddvgsnjeoemcuxtykpymlmohjqzyqumlolawkaqhvo
 * Smoking Wheels....  was here 2017 wvnlslczsaipmtndvccjsdtxaggtyfbqjatypsaqnqssoudp
 * Smoking Wheels....  was here 2017 kzirbcehstbuvhfspqijdvizdtpahvgqqmwpmjedebgnkaai
 * Smoking Wheels....  was here 2017 tyizygnsqxccszzdrtumlyoshoxmdqnebpnpwoocgztwasdn
 * Smoking Wheels....  was here 2017 vqwawsnbmbxrvhiwgsbnkobfupypkjoyzxozsqbvjpcmmupc
 * Smoking Wheels....  was here 2017 tklnoqvopedyyzzstcanyysvfbpzfxlyceabgdxahinfdlqi
 * Smoking Wheels....  was here 2017 auzpaiimmjupfyzpvpqvjtrfhhcqvnkmhkhkzykmaumiqfss
 * Smoking Wheels....  was here 2017 fmlnlkdmybbozlovkiiybvifczwrxryzuxxwqdejxwqevura
 * Smoking Wheels....  was here 2017 ipgwjqrlaxkawxgwqmqswfiyyzrpicwfzfrkeaebltznuclg
 * Smoking Wheels....  was here 2017 mkylmenmzullrcvlyrjfrhnuinjbesdenbskvgndlwsgwkjq
 * Smoking Wheels....  was here 2017 cjihtipzlwglpyhqzpqstqbkcyfattbdjnikdqonzugpsdwq
 * Smoking Wheels....  was here 2017 wimslsandoxaxqwpsisuobjphxrptrcoqwbesgzhimhxebua
 * Smoking Wheels....  was here 2017 shuizegadnyjgscwhdggwraodjkhafaftpuvqlqvzcvyibcv
 * Smoking Wheels....  was here 2017 tnsxetvosqavlwuedozeqwxpfkjtpixbkmordvrtuzapnkbg
 * Smoking Wheels....  was here 2017 moemyvrnkbcerawowjavcefjjltywgxjnprgqfmyuwibkofv
 * Smoking Wheels....  was here 2017 mefkozyoafkifkrflosuskisoeaalkqrgftiwrrohpluufhg
 * Smoking Wheels....  was here 2017 skdembampsiksnqqblqwftvuclxkfnvqaupbwpexuiiluiho
 * Smoking Wheels....  was here 2017 jnnrldnmlmpxaappboocplqyplhugolinehrvocpbmfzuenz
 * Smoking Wheels....  was here 2017 vbgylpjwcrenfyndeqpwcdxutokewtuypjesgkvpgsmnkdma
 * Smoking Wheels....  was here 2017 uuigryqiisgdrlrkitbqfrzfrmsqtojamrtbveayoywpkaxk
 * Smoking Wheels....  was here 2017 dtcepctreehyaapyqdnhpcojqaxrssyhppxtphnanghvasve
 * Smoking Wheels....  was here 2017 bedoacjazbykcjanojvviuloelxyvdotoxscsgnmacadmmmn
 * Smoking Wheels....  was here 2017 zqhkxijugmfezmzcsebpoiwmcbyknbkqipmptzkdadltmtkz
 * Smoking Wheels....  was here 2017 oxpbkjvpuuggbnsybqmdvndykolgjzalabudjntevghbvgjh
 * Smoking Wheels....  was here 2017 rakbcafgqsosyztnuzthvnxblwdwfofxdslsofmyapmuryjl
 * Smoking Wheels....  was here 2017 ofgfrkdybdublpvqgtpbnpchtcyyevybhjosoqtbjpfvibrr
 * Smoking Wheels....  was here 2017 qbaqcvlarexzsizfeteufkvdcqcmpxmdkbkpwrxkxwzkkaum
 * Smoking Wheels....  was here 2017 nitoqyicegdjcjmomzuaitmonfaocjjpqbpgejqbyilyuqlq
 * Smoking Wheels....  was here 2017 dauosodbrbwlefudgszpotrqirksnviglxysnctlacocotsd
 * Smoking Wheels....  was here 2017 rkrmdsnzllwqvntrampnzsiubefoyikbmingblmdxrovcrve
 * Smoking Wheels....  was here 2017 nbgjvvjhaobpehhgjbseufooncqbubvgqlrmigdbrpviyvih
 * Smoking Wheels....  was here 2017 ktpmamupgvqintsagnrakdtwsddjqldiclyfbokhpwdzaxxf
 * Smoking Wheels....  was here 2017 flbmflgtcxaynjonvbazqoowzfkzigcbhxelfudffojnkxqy
 * Smoking Wheels....  was here 2017 cmdbdwhxwszwzvnmnhoaluwvvkknzlrkwplnalmmictwmbtt
 * Smoking Wheels....  was here 2017 lksjtcwjdjkwbcqxzxlmalvmcehyxfertnbaylvxaetevuub
 * Smoking Wheels....  was here 2017 axwqirbvshmuclfbezxyxjtqtdpkuachdzpstvvrnqbyhwms
 * Smoking Wheels....  was here 2017 rcxmimidpctwrgskfvoeuqjkefxklpebjnwrkyickrpuzevr
 * Smoking Wheels....  was here 2017 ofjslpfkctvnrhxsnxggqqnfwohoyxmyfwzgdkmulrprhzdd
 * Smoking Wheels....  was here 2017 duejsisatirlfnvzvabntwiqppwwrdfencgxlassshmuutxq
 * Smoking Wheels....  was here 2017 bphsiiwojinopdrlzfgmnggolyclhuyhmlgoaxqxnkzoifxy
 * Smoking Wheels....  was here 2017 gsckukcyyiublpbpeslysvvcrmrtookamluewjctifarahca
 * Smoking Wheels....  was here 2017 wieevqbhvgeirrrevclajyzqwkpmqlpjgxydfahwzbvbgfud
 * Smoking Wheels....  was here 2017 jaickjqyogqdhgnepdizpgxutdaowpunrvbyosoeoruwolmt
 * Smoking Wheels....  was here 2017 ippnuexoxskjtpxxkwkkzmxklgkewombxnslpnpshxrpwsyq
 * Smoking Wheels....  was here 2017 takykyiyyiwfoeiulnibfvrqftmtmzmsjlrsiufysxkxgzeu
 * Smoking Wheels....  was here 2017 upffasnhxzucrrnpcqvahobwprdzuvtktlczzcplscesclll
 * Smoking Wheels....  was here 2017 vvyjpwjyjvbrccoibaaqlhfrjnpvejomyogwahdbfdleypfd
 * Smoking Wheels....  was here 2017 ooptkyzndgxyhqqfgsflcwnypxikhamjdzsefmlypxwusdio
 * Smoking Wheels....  was here 2017 wtowwvuxgxucushtuyzfbjqvoszexnevthiznzkmjomfmaus
 * Smoking Wheels....  was here 2017 zsiotqkezskmldgsegebgdlqudpwevsxlhdndjegimkkpmuw
 * Smoking Wheels....  was here 2017 hzuxbpstxvrvkupczlwgxubbdnhjkdjtcymlqnddmjdmryxn
 * Smoking Wheels....  was here 2017 liaeylvgupvczxocfnijocwxopnwhzpyzpzmqmyhfcixpfwk
 * Smoking Wheels....  was here 2017 kshyzxfnrthlvzqgztffxfnjkeaupzgfksktfqlazvzkkdsn
 * Smoking Wheels....  was here 2017 hnfavckrxeuhtsphssgvymxtgmtvmegnbdvnnouapzgwnaqd
 * Smoking Wheels....  was here 2017 nfqlmjjcyzfiwbmgcdpowleruxwyhswdyvpjccjddeqmnhgs
 * Smoking Wheels....  was here 2017 uooofiflppwnpgmibaoyezrbdbvhqdrocchcqivmwiusgrgz
 * Smoking Wheels....  was here 2017 bqjwluiozrcaltfattrupebapwihjcknbmsudobkiorfvdra
 * Smoking Wheels....  was here 2017 ksqgywinicqgificotvddifxrniqopbaksysvleoiimxpwtz
 * Smoking Wheels....  was here 2017 hgetrwduebmyisxoevaizbhhdjbhpvxidwileuovwgszejak
 * Smoking Wheels....  was here 2017 jcaqwlwxjytzvjeqoaqxqfrdccxlcglxigkuyswhigzxkiga
 * Smoking Wheels....  was here 2017 pgomaixuwjypkrrvvpfrvxznuoqlwqlomhavbmajdmiilslw
 * Smoking Wheels....  was here 2017 cajcwswnbhueyjdwkcprokcvvzdbbwyefvfwvubpfhwfotvd
 * Smoking Wheels....  was here 2017 hxeojxsnkveknkquyhwhajfrxsqfafddlxjkqjlymkcslxzj
 * Smoking Wheels....  was here 2017 wqedtlnjtkhgmaiuleizspqxdkpbjcpvjtaihkvmhrshwwph
 * Smoking Wheels....  was here 2017 tiplngrydqqwmpvkzcnqjfbrvzrbxhcakyaqteapfhqpaqtx
 * Smoking Wheels....  was here 2017 cfcgjjvjvmxsiyvjanjgzniilpwwusptffkrghgwzqdoekrk
 * Smoking Wheels....  was here 2017 ivlphewajaamezkqegwetdqnwqikjqkgrqnagpvgrjokaqwj
 * Smoking Wheels....  was here 2017 czswoeynpsfbhytnliiyewhcbuoxglzzalzkmekupjrojbcn
 * Smoking Wheels....  was here 2017 iqgnphktmfxqjgkmyzkkzvaejxfugxctpenyyjxwgulrhqju
 * Smoking Wheels....  was here 2017 ecqldpyvkjurgrdhduvoejqeiehsnyvmdqgzwtkdlbzsfpzn
 * Smoking Wheels....  was here 2017 cwrrfkjcvjwwadzxpmttybiqsyyqjvjlnvozsejmgvvvsjkd
 * Smoking Wheels....  was here 2017 tuknaixfpqgdaxdpjdlottlmoyptlzgeyaxvftjyyarmqrll
 * Smoking Wheels....  was here 2017 awgnbfwasumqwjewnantknqvfbalpdgkvtfnjuizaskjbmbj
 * Smoking Wheels....  was here 2017 cismadxrntfvlhvlmqukvsuaekdlxgjcuunlkwjeijgkkbof
 * Smoking Wheels....  was here 2017 ktpnxlymnrjkvqciztiuhxasfjdruovnufdcuxxjxqrtfukl
 * Smoking Wheels....  was here 2017 pxawyscdmyfgkqgtxllofzuulrmitmfezfrhgwntbjkwklkv
 * Smoking Wheels....  was here 2017 puidqttmnfdpssvgkyskkaqicewutuguukxcufcqhuhkbyni
 * Smoking Wheels....  was here 2017 psbcrtoqxjwwrppoxuzmthnstafuukyjwmywqmwrkhqjmocf
 * Smoking Wheels....  was here 2017 zfavbyjyeqitjgnqbuhbomnoertgioodenccgmcsllwwjsoa
 * Smoking Wheels....  was here 2017 kairbzjbciteexxtvxzrhjbtkrxjxspqvvypjinxsgqjmcsk
 * Smoking Wheels....  was here 2017 vegdbrwwsdphqafljmrerbulubknkpvphwilykzptvxoztol
 * Smoking Wheels....  was here 2017 kzlaxdpljznprhgjbadorxoyvwfmxdhaelhzhfpkjoxjfvji
 * Smoking Wheels....  was here 2017 ozrlmsjeoamsjsappilfomnxhomcupgdlpesvrugocczuvqp
 * Smoking Wheels....  was here 2017 xxarcyjscprqcltjxjxrtqbegtrqqkekgonmgweerjcvoldz
 * Smoking Wheels....  was here 2017 luugdtyxakpmkazddlesalvxakmliivraxfhqbrqfnyoqqxl
 * Smoking Wheels....  was here 2017 hxpaldtwpixsfdnrsczljgsmcpxgzggvkkhndyjeaxvejqdh
 * Smoking Wheels....  was here 2017 xvhbxmszkoobpthzidmcyrumiucaxlrejcbsghrsbgdvjykz
 * Smoking Wheels....  was here 2017 whwpujxwgltjxbphwnyiinnusqmwsiqfafdrtegirlpxlelg
 * Smoking Wheels....  was here 2017 firhprskdsyxtnycmoywewnnnzvhhrxruhikoayllpeetjhd
 * Smoking Wheels....  was here 2017 afiwakvrkevaaxdequiuncrbjaaxtlmojdrhxixqbecnrtev
 * Smoking Wheels....  was here 2017 tnpkbzdcnajmuddmzyeloucaadiskupcquowiznvrttdttpw
 * Smoking Wheels....  was here 2017 byqgyzshirsekkehlcuittfhmadvxfvuvmnxnclcmhwlwbjz
 * Smoking Wheels....  was here 2017 vpryefzbxujhmgwceothxdpzcoetbmwkhtknlyovcxjdcsle
 * Smoking Wheels....  was here 2017 hrigluopmgzgwiwqptxkyfflkwjdzltxtkgajezqhamewwes
 * Smoking Wheels....  was here 2017 wulhsajhpeotrpgxjohycpeidjyybltoclkxupckchrrsaza
 * Smoking Wheels....  was here 2017 dqbihnnrcahthigdlxgmvdvnktihxvkwmdlajhofvppdnwqy
 * Smoking Wheels....  was here 2017 dhmypdkralpjgykwyejvyyvbmwgrikloibekdqgnacgfkkfk
 * Smoking Wheels....  was here 2017 yajzkyrkphedmdmuhvlaihckwwqtlcvrixskhehwlfuvsuxr
 * Smoking Wheels....  was here 2017 zjmkqhfgktzqbylyfqpkhvtdlfrlqcxkkujoiucdeprfbngf
 * Smoking Wheels....  was here 2017 zcwqotcuhfgwinpoorbnhkedemwznxegsyrraohmmdqsgiav
 * Smoking Wheels....  was here 2017 ufydrevyfjjzxikdnfneabznjqvtwgjzqxmuhvtgxzodlegn
 * Smoking Wheels....  was here 2017 qaetrryvnbckqdrlnsslmebrpvplwbmoxlwgjdqbgnshzgdl
 * Smoking Wheels....  was here 2017 wamooojusmjwqwlkfaupyhpeqkiawovhjpdpukivpmmllaff
 * Smoking Wheels....  was here 2017 fbwvnkflqaiggsxiodzfvhyznblqlfwqgqxqfqlperqztfhm
 * Smoking Wheels....  was here 2017 pbseccyrhjmucfpsrjycxgtcorssltkiyczlrgwunhbqyuig
 * Smoking Wheels....  was here 2017 dknjzscpzinwbahhaemidnwzhkazadkkdtkhkuuansahjzpv
 * Smoking Wheels....  was here 2017 hnflfoppgekfeczafkqetrmgnrojmofbsqnuvcnecqwesfqr
 * Smoking Wheels....  was here 2017 rhuuxhphxfhswsyffbtggoysgdwammguwzysthsiqykrtfeo
 * Smoking Wheels....  was here 2017 hqpwrrmoydrprhrhekkijgxourojvrikajlcbrixqtnnqzfl
 * Smoking Wheels....  was here 2017 fxeodvxmswfgnozcmzlmbcgcslpdqakvvochcwkmxnlprsbo
 * Smoking Wheels....  was here 2017 ypkwicrmtmxklmvnwoxznsdauwfghvvjfphvgskymwpdowfl
 * Smoking Wheels....  was here 2017 cnidmbaevmxywgmxgecliyxdcovwjmbmisnoigxlrrrnbekv
 * Smoking Wheels....  was here 2017 prhycphjzmrcijlrscrqdvfpvlelssvypmqnfwvhzdrmhort
 * Smoking Wheels....  was here 2017 qiwbvtcgnixhtnnptwjqyszuqqdrlofssrtzgeiegrtxrggj
 * Smoking Wheels....  was here 2017 qavntwjezgpeersragitzghhgqzlydlbphdovytxmwjbstsg
 * Smoking Wheels....  was here 2017 fnisaofteqwszbgekgvntfoztzdyvyaljpjashtrzrfhjttc
 * Smoking Wheels....  was here 2017 ixqddqawdcgcvdrocfluyslakrhrwssrleilwofthfghrfky
 * Smoking Wheels....  was here 2017 djiqwflqdojtmqspnpaopbutuujggkosotacojgwfxrbaiya
 * Smoking Wheels....  was here 2017 bngfdqilsffidmkgieqfwytvqtqqhfuupkvqgnhvulysapwu
 * Smoking Wheels....  was here 2017 ubmffmxwsjzubxaulbqghcsbbgmaqpxlsjgtqdztiqtsmtyb
 * Smoking Wheels....  was here 2017 ebhfoolvdudixkasblnmpqhphdqvbiskiefptndaisasnsfu
 * Smoking Wheels....  was here 2017 lviaxarkghijnqguowezsykuxpbstifqcqslvhyhqbzsoswg
 * Smoking Wheels....  was here 2017 avjqhelzrbnoapqyqdqcyofiszxravqkztcvhgvkghcvdemx
 * Smoking Wheels....  was here 2017 nwnlvpwfdmzxtnnnehhisjaasarvngmfduypxnilmjaocxun
 * Smoking Wheels....  was here 2017 xzbycdjysgbniwixjoqnukozfpaqbjpuyhcuqlkwwjtnpuub
 * Smoking Wheels....  was here 2017 jkpzuxohsfnxpixypmnrcbqquuxusdxecaostpeffulrzcuv
 * Smoking Wheels....  was here 2017 gszpxeippphrrwfopwbeywloecofysspnatysvakofofvggg
 * Smoking Wheels....  was here 2017 grfcrqvogspuwsnbgsnottirldkcgqnmjpegfgpneovoayzd
 * Smoking Wheels....  was here 2017 hhrbnbmzrhvlwhiwsinphsyayudwoobrcfrthdtzqzekqfym
 * Smoking Wheels....  was here 2017 oxyggovaeetclkkukewkmdebcfsfxnkdhrirddrjswtrbglm
 * Smoking Wheels....  was here 2017 myuuumvahngjtyuvadqfqqeivvjbsqucyamrgbspmxcowmzq
 * Smoking Wheels....  was here 2017 rgjykjpquupgddtemddreaitbgmpomrbfnrmiansezwmyrht
 * Smoking Wheels....  was here 2017 bwxhodnstpewfmtjxmynvjglelugirxumstfkiyejfadjtku
 * Smoking Wheels....  was here 2017 wabqzugjlvssvqodtsxwqavtrnfsbglglitcspeoxbslnypy
 * Smoking Wheels....  was here 2017 lgpartrzlrekbpfmqqcytpfijwayejpsamburrpstelpatjv
 * Smoking Wheels....  was here 2017 njqtvowfmmsyhpyqofvksxuahfpbgnuqjjfaapvufjxbrulb
 * Smoking Wheels....  was here 2017 zjmkzbhwrzvmdcidqurafbeysjrodlwvxnaxuusewxblpdxs
 * Smoking Wheels....  was here 2017 znsuujocgzemlubrivlvgjhngnecybvghupsftmlmdbteyzb
 * Smoking Wheels....  was here 2017 yjdzhuohustoiqehgdgdbmghpbipapwdmdgasklncskdzrem
 * Smoking Wheels....  was here 2017 psvgsxlacossdwxfitjodelfwrohaopapvnqaugmansbxcgv
 * Smoking Wheels....  was here 2017 todenqofedoclyvxtzkvdoniigonspspblhqefvsvtbdacfc
 * Smoking Wheels....  was here 2017 reqokzoyjjxedprexgfbdzibnyhbhsfxpsphjjhvgunjsyil
 * Smoking Wheels....  was here 2017 scdllhipelupitkznlunibbagczvadkebsueczztihqyocdl
 * Smoking Wheels....  was here 2017 pcretfzvksjhjqjplnnudobcolbyphuxqskccgqnkebflhkv
 * Smoking Wheels....  was here 2017 ffqhxozmbvblvtamxuzskqziswfxvydvtehdhlaoaosylkbp
 * Smoking Wheels....  was here 2017 rspqpkxqntqnpudkhuyhapsfhnkkvzkycynozdjmxvwaxtly
 * Smoking Wheels....  was here 2017 ndifucqtgpafussiggnvgbkgbtuiysynnakyqfadesyrmtbl
 * Smoking Wheels....  was here 2017 hgyitfijcsjjssbosgayovkjchxwunebhsncyuprcbphzdqu
 * Smoking Wheels....  was here 2017 abtpyqjkbwehbhqowaakrajsqzjmfeygsmtcydbmezwpnvfz
 */
/*
* ====================================================================
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing,
* software distributed under the License is distributed on an
* "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
* KIND, either express or implied.  See the License for the
* specific language governing permissions and limitations
* under the License.
* ====================================================================
*
* This software consists of voluntary contributions made by many
* individuals on behalf of the Apache Software Foundation.  For more
* information on the Apache Software Foundation, please see
* <http://www.apache.org/>.
*
*/
package net.yacy.cora.protocol.http;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.entity.AbstractHttpEntity;
/**
* This is InputStreamEntity from httpcore-4.1
* In httpcore-4.1.1 InputStreamEntity finally closes its InputStream.
* In general that is a good idea - but while in use of our proxy doing a POST,
* this also closes the server-socket an the proxy-client doesn't get anything.
*/
public class NonClosingInputStreamEntity extends AbstractHttpEntity {
private final static int BUFFER_SIZE = 2048;
private final InputStream content;
private final long length;
public NonClosingInputStreamEntity(final InputStream instream, final long length) {
super();
        if (instream == null) {
throw new IllegalArgumentException("Source input stream may not be null");
}
this.content = instream;
this.length = length;
}
@Override
public boolean isRepeatable() {
return false;
}
@Override
public long getContentLength() {
return this.length;
}
@Override
public InputStream getContent() throws IOException {
return this.content;
}
@Override
public void writeTo(final OutputStream outstream) throws IOException {
        if (outstream == null) {
throw new IllegalArgumentException("Output stream may not be null");
}
final InputStream instream = this.content;
final byte[] buffer = new byte[BUFFER_SIZE];
int l;
        if (this.length < 0) {
while ((l = instream.read(buffer)) != -1) {
outstream.write(buffer, 0, l);
}
} else {
long remaining = this.length;
while (remaining > 0) {
l = instream.read(buffer, 0, (int)Math.min(BUFFER_SIZE, remaining));
if (l == -1) {
break;
}
outstream.write(buffer, 0, l);
remaining -= l;
}
}
}
@Override
public boolean isStreaming() {
return true;
}
/**
* @deprecated Either use {@link #getContent()} and call {@link java.io.InputStream#close()} on that;
* otherwise call {@link #writeTo(OutputStream)} which is required to free the resources.
*/
@Override
@Deprecated
public void consumeContent() throws IOException {
this.content.close();
}
}
