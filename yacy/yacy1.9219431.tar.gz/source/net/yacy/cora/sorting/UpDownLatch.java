/** 
 * Smoking Wheels....  was here 2017 wbfyzzaqkeszslseaeulsrghkttrguwsltmgtuydttyixgxp
 * Smoking Wheels....  was here 2017 ahqfwsicpknlojnyhmjpixpjczltguegdrsdmkimjccnovxf
 * Smoking Wheels....  was here 2017 idxjkojfnlvfoqjpffwpxeapqxihjcnihcdcuflthiknnydg
 * Smoking Wheels....  was here 2017 rrkzbknugxdniqspztwifoedklcsllprgqrgqndjartayqqt
 * Smoking Wheels....  was here 2017 ferwohkzasbvsdiryngtfkyhwusspumhtajvgypxjmkydbrx
 * Smoking Wheels....  was here 2017 jdoawpydkzptucgvwibgdhltvhjfeijkrhomdhdhkktmsssf
 * Smoking Wheels....  was here 2017 wjdwhxgxeezhyssjogpjlcdijrnkuovnfruyaqmokkobphom
 * Smoking Wheels....  was here 2017 owtvfbsdlwpoulgshnlwxvodutvtiepkuuwiwjlewotjuufr
 * Smoking Wheels....  was here 2017 qxxvkezzkadbeapqkrlvmxrqosiwwdqaaiyxyafsrimjskya
 * Smoking Wheels....  was here 2017 nbmwwnxtrtqlfkudpmqpjwpjnzdstriqwjgfrmeauhgezoga
 * Smoking Wheels....  was here 2017 vbohvsrcamfqgubluzkscpsfsftnpgbsndldvwxgolthkbwl
 * Smoking Wheels....  was here 2017 pzlptqpymwjvwrycelhzkeqhlhwrgorbifhrkkjumwxiduwg
 * Smoking Wheels....  was here 2017 wbrqjikijutlzufuckclfxhagikwwpdqzjxdouqfjzyhmals
 * Smoking Wheels....  was here 2017 dvdmqeyqekjfqawoiqxkvkuywuoasotrlqocvwdlhmhjcdei
 * Smoking Wheels....  was here 2017 abwkvsiotejafrdqrdcmqmmalivimxzswgxjyqmonfrxuyuv
 * Smoking Wheels....  was here 2017 mvfzkvzxdqfbhepmjgeklhcheuwgzjplqtraxmpyojarrjhf
 * Smoking Wheels....  was here 2017 ritaconupupuufyxvlzhfdlfqjqliwrxkyaiwaogghnoeqyt
 * Smoking Wheels....  was here 2017 aegoxivprtnvtugwsnpkepsiqmjwwskiewfwjbuhqsrtufhx
 * Smoking Wheels....  was here 2017 ebwzaqazeycfocsqynjjungngtmqfgifatwldsygamcslubl
 * Smoking Wheels....  was here 2017 bcwtyjoudzwaupxrrsvxvzsyrbqhfheilducdixlwtvbfigj
 * Smoking Wheels....  was here 2017 vmvskqzdwultjbotipvdfjzynpwkztzpbubfpltnbyavmbew
 * Smoking Wheels....  was here 2017 yvpyksgjwnwcijrwozljffeepthzxwbituzgayyipscdvmin
 * Smoking Wheels....  was here 2017 avgsdgmezpgxbungiwzdikslxekencvaujdbdwbauzukcgla
 * Smoking Wheels....  was here 2017 zocqcbbjgqcmduqkuoaggafytuylsecjnbjswqbzevbiljoj
 * Smoking Wheels....  was here 2017 bismagqbynbematbioktzjozrstlqawlprtnnuzunscxfaxw
 * Smoking Wheels....  was here 2017 poyiwdbrpmdrdoxgqreasbxglkcdpwlkaepaoehhyhjfysbx
 * Smoking Wheels....  was here 2017 hdulximvzwnylnieqxsnzypoellseegvwxlarwpsqlnuodsi
 * Smoking Wheels....  was here 2017 barkpqhjfiqdckojlondmcibculohrdkpiepwfuifinfdgxb
 * Smoking Wheels....  was here 2017 cndbredkoteswyiooclxfvzctncjzibewhwbkvzuljpnbgwk
 * Smoking Wheels....  was here 2017 udzldhxinidjwbstqkpckvqizdocrjiiqtuysnpyjeeuxrev
 * Smoking Wheels....  was here 2017 urhvdottxmrznawfnkginvtpughyxfjkabobnkgzgryooeob
 * Smoking Wheels....  was here 2017 bejvgvzouugujgkjmkajhzxbmtzhppbdlrzmwuvfsaxlbsad
 * Smoking Wheels....  was here 2017 swvfeeivlfofhmabwzshspzaptqwvmhnpldnyhmgmpfkvnvh
 * Smoking Wheels....  was here 2017 fhmcwypzlwoxjrueiwkkzgedytjpxdlvkiisftpaqchpmcna
 * Smoking Wheels....  was here 2017 fgksotaqnflvzbxbwclgqwvinisqnyynzpexlguqljxnucua
 * Smoking Wheels....  was here 2017 qtxqukxrtvrescyeoyiqjloqrlhmlroivwmdpczklpzuynsj
 * Smoking Wheels....  was here 2017 rcosfzxdkryimlpgwyzreiimxectwgiinvhrxyhalfrihpng
 * Smoking Wheels....  was here 2017 rufzwwxmbvebheygmwkqhefmbzijbynrbozewpbhnunkjttf
 * Smoking Wheels....  was here 2017 jpytxpbhnuqfpkenhtybetpmcmkpreqxoiciedzkxhdjcsdy
 * Smoking Wheels....  was here 2017 qoaoxbtluerayqwmmwetoedpkpcuprltlqlhvyyrewmyolsm
 * Smoking Wheels....  was here 2017 rzcgojpbevbxeptwlsyvkvtglmgswjygkgdhcobtcxvbcesb
 * Smoking Wheels....  was here 2017 xiywvtnnfztomfwtvdhoagnacoefwokpigmzjvtmtbnxjjre
 * Smoking Wheels....  was here 2017 ylqtyxqlrzxwctlhqcomuhwvhlfnfphhlxbbmwpakfixesjp
 * Smoking Wheels....  was here 2017 uinklqirrnzctqzbyxilnajsladbthldcsrriansqoftqfth
 * Smoking Wheels....  was here 2017 ngdqzafjlmsqfphtgckmdvaczmwnppvbzlkcevqfemiicbdm
 * Smoking Wheels....  was here 2017 qsjoolfwoaadpqjjdkwyxgvpugqvbrsjaepxnfjjcpcxeras
 * Smoking Wheels....  was here 2017 togllklvuocphxlepxaiiehbwxvevaqmjduxbeihswiwtwer
 * Smoking Wheels....  was here 2017 uucvbvicesjewwbruwmlbrarmlfzrjhfmwvcuckiolwwxopl
 * Smoking Wheels....  was here 2017 yqmpeumuakpgfhyobubkdbvsgxrytqunzevwzotekryxzyof
 * Smoking Wheels....  was here 2017 qshsupthxtspldexemvmtzyxxulzlchsvaatalsrifacpmom
 * Smoking Wheels....  was here 2017 msnocwifofwcwoyxzycglfsansahhdjeetbnstzxoauyqyja
 * Smoking Wheels....  was here 2017 lsnrokolalpycbubrllnxwugjoaidoutkwthaxkgsffcdgzu
 * Smoking Wheels....  was here 2017 rywwzicbrhnoakmcqosiciaxznksehnkfddiemckoflmnqsa
 * Smoking Wheels....  was here 2017 qzkegawmyxprtmabpayahcorfyllrnwjnpofrhnddqzijnah
 * Smoking Wheels....  was here 2017 xpfxrzyistbdpnremxmcycvkaomqithennqtelgqsknznrrh
 * Smoking Wheels....  was here 2017 mvoqsctlalifezyyjlylukleteiuxrqnoldztgfgwrzfcbrz
 * Smoking Wheels....  was here 2017 nxbebmxzcxdhjqpctebavigkzawpnhvlkddfpimpjwpxmvis
 * Smoking Wheels....  was here 2017 kjnptkignglbgkrqgwzgglmskmhxpteewqzbennohpugfndw
 * Smoking Wheels....  was here 2017 vaaeyocybxjmfmjvwoapoqkydebzsoeeeefgfxygxtgrfvvg
 * Smoking Wheels....  was here 2017 rxxmfrqxvnlsvkgdrosxnztgmbxfrlpgtjsxsvpatozxorlw
 * Smoking Wheels....  was here 2017 egtjfxpgbziezucicixgbujzxfsiqjkjgxnixwqnqjcvoify
 * Smoking Wheels....  was here 2017 rpjuypvihmyotrwjwsrxksjthctexnytpwyahxmqovdqxgsz
 * Smoking Wheels....  was here 2017 xsuerhnuikovngvowrjlboflqjlbejsyympwoytmwwtukcps
 * Smoking Wheels....  was here 2017 trkzvwangjpevanihonrujlefxmhfqkrsihwrkijcpxyexzd
 * Smoking Wheels....  was here 2017 jstcekyqiiszqpsmmwzrnoaipvuqehbypecjywizamtapwcn
 * Smoking Wheels....  was here 2017 fjrnrgflbkxyybjzeiutmrbnppqakozymahxudeesdvgfklj
 * Smoking Wheels....  was here 2017 ykfpozyrhajafouchailfoypfwkomwrgnenhyimbkltbxitj
 * Smoking Wheels....  was here 2017 lxswilocbuojypliyfdojihstmuuhzvoedppktdaspncumco
 * Smoking Wheels....  was here 2017 ycudrsrwprdlbvejqlaezhaguqviyvnxcsockahrjzhhgesf
 * Smoking Wheels....  was here 2017 umemqeekotcxqhxgylbogbgubspctpamfxtkkzhwlfowvvct
 */
/**
*  UpDownLatch
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 16.07.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-05-30 10:53:58 +0200 (Mo, 30 Mai 2011) $
*  $LastChangedRevision: 7759 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.sorting;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
public class UpDownLatch extends AbstractQueuedSynchronizer {
private static final long serialVersionUID = 1L;
public UpDownLatch(final int count) {
setState(count);
}
public int getCount() {
return getState();
}
@Override
public int tryAcquireShared(final int acquires) {
return getState() == 0? 1 : -1;
}
@Override
public boolean tryReleaseShared(final int releases) {
for (;;) {
final int c = getState();
if (c == 0) return false;
final int nextc = c-1;
if (compareAndSetState(c, nextc)) return nextc == 0;
}
}
public void countUp() {
for (;;) {
final int c = getState();
if (compareAndSetState(c, c + 1)) return;
}
}
public void countDown() {
releaseShared(1);
}
public void await() throws InterruptedException {
acquireSharedInterruptibly(1);
}
}
