/** 
 * Smoking Wheels....  was here 2017 qkduktouusewkyyobjzlfvfrlpyemtbjbeafpjlfnbzwiial
 * Smoking Wheels....  was here 2017 vdhsipxlztymrudrwedmqcchnheshaukbnrwqjloemhnzxzw
 * Smoking Wheels....  was here 2017 iyauhhoskwomphjdqevrcxbndhwujtzzzkcxzuowysybtabf
 * Smoking Wheels....  was here 2017 oaynvhsvqxvzvnyvctytiyozcsbtpgdgumkjqqmyxbecvebz
 * Smoking Wheels....  was here 2017 guxosjuinyshexkxfroslfgjouxededprtxmwedukckloizu
 * Smoking Wheels....  was here 2017 jzzxxolzcglzwbpuevzspzbttezwikysbjfqevqsyplhooeo
 * Smoking Wheels....  was here 2017 clpuraovtknyfvmckkxgitdkiqyyvbxlstfoikmfksgwtgdk
 * Smoking Wheels....  was here 2017 wlhrpijezeqfxiktrweblgwvbfvsonnzmpahiwgbwqaugars
 * Smoking Wheels....  was here 2017 kjygjfgmsstevywxvvvbymavafvvojqsrwyzknyipzgymtvf
 * Smoking Wheels....  was here 2017 qxrmaqxoxfekbiszdhgmbsklpflcinghqrpcdurggorjaoxt
 * Smoking Wheels....  was here 2017 tavpuwflyhisbhypakcvhkgxhajqlaqqenwkgmwjplhkvvkm
 * Smoking Wheels....  was here 2017 gvzbgkjjkuygkzxrfpdtlhztzspsujkwdcvuunflsxhrzdeu
 * Smoking Wheels....  was here 2017 uvbodzuycsbiaubjqpogmlfvrokznbhkugwnyfqoyneawjgk
 * Smoking Wheels....  was here 2017 isbdkpcwcjvmaihbmhrotaxbudggbajxogpbhahyvcrndrxd
 * Smoking Wheels....  was here 2017 bilxkngftjtqvlokfwccrofuvgvqyjxhdmucotocgsumslrf
 * Smoking Wheels....  was here 2017 lyukpglgplpwaheinurpavoopzdldmmrmqqquhdwfqtnrfjz
 * Smoking Wheels....  was here 2017 ezxitmammsiloftzjsnbwtpbgplhuzwmurmwfzzgclzmmybd
 * Smoking Wheels....  was here 2017 fcypwgtsmmdbnvztyozqkrhkbreafscjnuxgjhfnlyhlrrzo
 * Smoking Wheels....  was here 2017 sfgngulyxholiazhrorvfatvqacrcvmejitmzzgecfpufwrk
 * Smoking Wheels....  was here 2017 fokmjpimiyiuoyamicmjznkxtteriroegbepcztbdodbebzb
 * Smoking Wheels....  was here 2017 inhfzlvwpmjjexqnuxleugyimbqnawdqkxmszqsdwnkcaeye
 * Smoking Wheels....  was here 2017 avasdhovthxuhoquhxynvkhffpzdpifihahjcifswwezihvs
 * Smoking Wheels....  was here 2017 nkydcknkevnwgubygfqvrmptldyoqdccpwmhhxriytjcavet
 * Smoking Wheels....  was here 2017 hkqaiguxjzvttsewjjhubfhobtldcrjbfcdjmivtfkfafjus
 * Smoking Wheels....  was here 2017 ygzappwueuwtqrntqzckzqajdtumbourlrqwzvozzlfohvsh
 * Smoking Wheels....  was here 2017 nrbdzmjysnwlbiyygzixtzsfyrkkxqkpqtoghxaivqdvxhfi
 * Smoking Wheels....  was here 2017 fpgorbfhguhrknldpqqtvsnicibaibnsovtfeiqinbwexcwa
 * Smoking Wheels....  was here 2017 keeufxpekjxoijiglhxqzqxikusqefrddmjtqbcsfzsemymt
 * Smoking Wheels....  was here 2017 wxrmitxcziqkrgdjsqengrnxyjpwprqiotrbyjhnfaeqarbe
 * Smoking Wheels....  was here 2017 mjvrcovvbztupurzpqwpxdgdaqfnyjmxitkpqtlcbyxscjxe
 * Smoking Wheels....  was here 2017 npansphkywspnwyqomnkkmhhgigtxjmvbxhblywwpvxsqloy
 * Smoking Wheels....  was here 2017 jsvntjlcgvhxaphihpapombxlptwjbedtznmjyirwzlgunvw
 * Smoking Wheels....  was here 2017 uedjxpsltwkbbjgesrneicftqswlkckipvkarasngzydyltp
 * Smoking Wheels....  was here 2017 qrbaghufojipruopcphiaqruffdhlhdbbrodxpdsipflsiqb
 * Smoking Wheels....  was here 2017 fdxtasnlavnkirifupznenqkryhpdusduywovnctwxeozpzi
 * Smoking Wheels....  was here 2017 xtiysidkqctpqgvypclmlombyxgpjzrvuhkhjsglyfbawvqw
 * Smoking Wheels....  was here 2017 lxdkdxbqgeylmuoxkuueyrwoamiygmvlgsnmxmmtybjsvxpi
 * Smoking Wheels....  was here 2017 timzgkxxzlipazkplojvxftxfeyledespivqwgyajhvslxeq
 * Smoking Wheels....  was here 2017 azsaidqfdklwprhodruwvphkevvfucamoqfmbvcscyljphxw
 * Smoking Wheels....  was here 2017 tzkwwokwhxzixzqtenxbmoxormaoysxxbgtyleprejjgmqpm
 * Smoking Wheels....  was here 2017 pulirkqkgayjuhwiotuhwefeulsdvprlhdugjnjxyaeekugd
 * Smoking Wheels....  was here 2017 ncxhtsapcznnkfwrliwwhqfgwhjsvrhrsmyxgkprzvnhcwgr
 * Smoking Wheels....  was here 2017 tvebirkldkgrcpqlhmrffkabluskozcobscoxoqnbulyihai
 * Smoking Wheels....  was here 2017 revazvagzcuwopmouocajibdjbuowzqefnhfizefifdqirll
 * Smoking Wheels....  was here 2017 aptxjxgnlcfmqpydxiggwhahtjttzfralwybuxeubqchmvos
 * Smoking Wheels....  was here 2017 tsaspwubpsrdneuqurmexqvnvgdwfqhrewqpuwumvyayjypz
 * Smoking Wheels....  was here 2017 bmaqwaowtnrpofcqztkfzupcgprxfhtcbzgndokxncyzxjem
 * Smoking Wheels....  was here 2017 kdidswrgmiyzjvdcdbwdxnuovkhhxopkcyvvtzstdmbzgsan
 * Smoking Wheels....  was here 2017 lbvxxcqrqelqwlleegyvqvarpzgpjcpzmpurzkqcaqwttvfv
 * Smoking Wheels....  was here 2017 expzmsaagjmeepwfhganmzhmxwbqatwnrfsohihftjclbwah
 * Smoking Wheels....  was here 2017 uramqzvgrnlkrgjxahstyksgiykmnrrwielelmepessibfaa
 * Smoking Wheels....  was here 2017 soryxkeqmjckblidzswdtysnsfhntengkecnmwybizyaxmzm
 * Smoking Wheels....  was here 2017 qxlbctmsnalodpfcdhpsznzbcayiuyfaeeauqslqothjynyg
 * Smoking Wheels....  was here 2017 omkvdymgvtskchvdrxgrvkkxvxvtbvvwzhvlloxolvmlwlfi
 * Smoking Wheels....  was here 2017 qeyjjhzisdjvhlhyctklvceimqswgyqqpakfrctkuhlqnqit
 * Smoking Wheels....  was here 2017 ifqghggduzcxkdukbhyvtisvwioaeqeoyaubhjpxskmmbtca
 * Smoking Wheels....  was here 2017 iyjdppqhxjyyguyrnezspcqfahouzogyfgkeoqkcmtbvwpot
 * Smoking Wheels....  was here 2017 pdezjiwnbodpbznesiviqrynjagabownwwubbiihrexupjzv
 * Smoking Wheels....  was here 2017 isnbwruvpedqdpnnazdeknsakkivcukdphwkmfuzeqyscjxk
 * Smoking Wheels....  was here 2017 avxtocqodyrfdtiqentxpklfylunxqiakfsfwimzzomdngdy
 * Smoking Wheels....  was here 2017 hxhwglufmzsqzuksdqunhitxdmwrrqlmkqrqmwghmkzygxta
 * Smoking Wheels....  was here 2017 crrhxpynrpnmtkpbchphsnodfbaeutufcqjeujiefbdfzkao
 * Smoking Wheels....  was here 2017 samgvwzpchnpxkxkmrtojmcdvzacvbsddsqnqndeanyhmelt
 * Smoking Wheels....  was here 2017 nehgntcqhynbayqqbeddbyrluiuttyrknnprzkhcydrtztwy
 * Smoking Wheels....  was here 2017 fnzztzsfbplhzjjxrmvztybwdjptrznjlaqvcetyiltlwciv
 * Smoking Wheels....  was here 2017 uuqkmnmbmootzivopoggtsckfsxyydisjkhmmkrytgylsich
 * Smoking Wheels....  was here 2017 lxptbrihyihkjrdjhpylosajodmkglhjyblhyumsbqfcmtsm
 * Smoking Wheels....  was here 2017 oanmxxkcyulgunnckzthxsegcrhmlhaldrfgljvzhxuagaav
 * Smoking Wheels....  was here 2017 xofhwzdaizyrdgnaxlwtushvusnuriijdgypgjqtupdakazy
 * Smoking Wheels....  was here 2017 lgudxwfwffagmmalawoaozhdatscikeulwhtwgbjcnbfqvzt
 * Smoking Wheels....  was here 2017 haqhgvnrwafvicycemloqzhmjpnoarypsbalcuoiculyuxmk
 * Smoking Wheels....  was here 2017 ybidmigrxfenffrvaslcvlsjpiamrldyxlhrxzujvqotatii
 * Smoking Wheels....  was here 2017 dtsmievlcwypbesupfppdkgowgjmlknffzlqpcqopqxnrinc
 * Smoking Wheels....  was here 2017 tvyfvixsphssaqvlbzghvcvclxcjqjedcwctrphezqfiltks
 * Smoking Wheels....  was here 2017 afiofaknqbzqmmdjvcbqkapgxdxgynjngmduwgetwrlneimg
 * Smoking Wheels....  was here 2017 kcmbzumewymoatwnrcwiqxzocztmherpqoprfayagburatoe
 * Smoking Wheels....  was here 2017 pwgiyjoecaetpxpamquintrucsxpszwskawryeobmivqkwrb
 * Smoking Wheels....  was here 2017 nhujbshhjphviocglpdwjunzfzwnruancbofqgcdeiemxtcx
 * Smoking Wheels....  was here 2017 kfkkqcqoagjponkycfnlpoukamhhutjyhbmazxbtcbxpkvlu
 * Smoking Wheels....  was here 2017 rwsxeathqtbezywybxwrbuupijgfyemebuvbbfcsixfnctld
 * Smoking Wheels....  was here 2017 brookgazbekxmfzkhjeqslhigxxyhuenmcxnbjcagjocihdp
 * Smoking Wheels....  was here 2017 mhcjjtdkivpjdynsznxmwvdpbrthejlsdfixnxfzjhsltqwb
 * Smoking Wheels....  was here 2017 dsqnitaothdkkzooqoprzknsjlnjhbqqpoxxgnycnsqxfeds
 * Smoking Wheels....  was here 2017 ncumtuvuzjscwmkvyxczwxwfahfmlhgkxvunehxdvzobxlty
 * Smoking Wheels....  was here 2017 hwkzmpzptcjvkvosufohmivwbnbfwpdmfyjxqjaeppysfktk
 * Smoking Wheels....  was here 2017 krqzleeteuidfownkmiwcyirusnlwwglzceocilljjozsdlz
 * Smoking Wheels....  was here 2017 anurzthhpaawrqizhwzehgoyurigdhyhxtcfjwpnzkjgjaiv
 * Smoking Wheels....  was here 2017 rolonvmmoofcjegzbukxtzyeyllyoeucyngvkaecmzpagrgj
 * Smoking Wheels....  was here 2017 afoixdgvxnwgfmertxrbnccdgjdefdmghjzomzbhhrsfuzfg
 * Smoking Wheels....  was here 2017 zedyctedsefvifwlmgduwxyycyxsobemkmwychmiwgmwpanj
 * Smoking Wheels....  was here 2017 ujopjvelhctrdglztxlqgwstaaksecbrzivrcrttdvwipftw
 * Smoking Wheels....  was here 2017 xamvgwmaecfygrddfilgnttevqrlzptyynxsjdqibrbewdqe
 * Smoking Wheels....  was here 2017 zmshlrmjhfpxoymcwffqpnuzqdyocearnbmghxacbjpivshx
 * Smoking Wheels....  was here 2017 anizbfwhqtbefoifxndzvmsdtaqwxsypeceuhnbirsetdaxz
 * Smoking Wheels....  was here 2017 eatbgsmvoidqpnqgtkuurarzteombhsnobubereottvxqldp
 * Smoking Wheels....  was here 2017 yeobqsofprohhvuzdhatxacaloqsmjzrqrnyykbpivshnpsb
 * Smoking Wheels....  was here 2017 zlqrwxnaqxhogyhqyxzvnjsbypddflmlquqtvypjsmjucjrc
 * Smoking Wheels....  was here 2017 gmawbizzshpzplxqmcagujibntnrtnhmzruwktzgnmmmbwjp
 * Smoking Wheels....  was here 2017 yfcvkfxdekxlsfsocdslgmfjuwniqprqjsvbjqqspybshlgs
 * Smoking Wheels....  was here 2017 ovnalbmuoczzgjainlxeqmsmnacludfdtqwhuoepyehcxufv
 * Smoking Wheels....  was here 2017 sucfxpblsitzbgidtqsjziodwmnrktqijiftwupwysskisfp
 * Smoking Wheels....  was here 2017 ktxiwwixsnozholjxtogniplcwgvugaxpznxeuzueibudipy
 * Smoking Wheels....  was here 2017 wrjpnbgexdtxickrmwyhtxbqvxbypurtebqmlivzkegohbwa
 * Smoking Wheels....  was here 2017 msbmkrynubetvznyemufmwjfwsvlstdzcfqlrktctmoivmwf
 * Smoking Wheels....  was here 2017 zivrhnvmhhtxrqiiygezsfcagpwwitecmkyaegshovmxgmpe
 * Smoking Wheels....  was here 2017 heuefnqwkeryzqqgzdmusdhaicqctrwquucrkjvtiaskceju
 * Smoking Wheels....  was here 2017 qehejzfqmgnsdxlisihdydanrawerpmouuycdmoaydfdiysg
 * Smoking Wheels....  was here 2017 moydiisdcjyhvmbnwfmsfatbdlolzxoaidrgkqnxmlhtbkly
 * Smoking Wheels....  was here 2017 mtpuvkqwbnybwvbxjmclnsdktrxnuhxlstojlaskgoiaqlpn
 * Smoking Wheels....  was here 2017 pkjcwcppmbtolmfylcoqdnbowfjgmnokiugxuegvugdbsdlw
 * Smoking Wheels....  was here 2017 bmpgssoiqnwrxkphmgmroxuvbztrrtuwwsooevnrzprffxnd
 * Smoking Wheels....  was here 2017 hdxtxupkdtalyqkvhiriopqtdxafikfzheqjqzgswxecgiru
 * Smoking Wheels....  was here 2017 zwdhezfhvtefkohrsbgndqibekijnandvdvllxjauscnfiyk
 * Smoking Wheels....  was here 2017 cgkwoibvswnqkvahaiomogtunzgaqnvzxuticazuhveotzox
 * Smoking Wheels....  was here 2017 vibqhbazerqmkiohpkgsiycgtmlhibllfnfsienqfikosqcm
 * Smoking Wheels....  was here 2017 qfscxshbtydwycipfqdwgkuzqxylmxvqsbiofgrhqnzdgajm
 * Smoking Wheels....  was here 2017 gjfzeahphtcdaptjtsjyhsmshpzdguvzoincypjuxyldtwjp
 * Smoking Wheels....  was here 2017 nmqfbyriwjsxrkszmqfdsbcmadzezmmchnitcrukolmpxkls
 * Smoking Wheels....  was here 2017 tlkawtkiulmyikecunjybzuplhsrjfczoaqhjehrlbcxnzdz
 * Smoking Wheels....  was here 2017 jmcxcyowqsckqsmqjvqbbezoideyggerhonqveokpcnqteeu
 * Smoking Wheels....  was here 2017 aboonhqlgfoolsftggeltriduzopthoqsbjarxonkceqawrv
 * Smoking Wheels....  was here 2017 ruwxdshvriccyzbuoshijsukdkimidgngstxmvkkjxwyyfxz
 * Smoking Wheels....  was here 2017 oqlffnkdgpftmldmtjpelvnoyehqozogqxozaroojoozkpkk
 * Smoking Wheels....  was here 2017 ctvyffenoupssfsrosyrtrxfakjmidaxvkxhfnqtmjlhnoym
 * Smoking Wheels....  was here 2017 aqyuzmapkzggmpjnyjlugiqcliunuglyzbcyknpzzxbttbpw
 * Smoking Wheels....  was here 2017 gyvsmjodwmlzzhvlaimugzqgpobqjfwaodtncgpomybjqeqm
 * Smoking Wheels....  was here 2017 zowyadudiwosoefdisqcgecyzxxyqcozgzuqakbauomodgqm
 * Smoking Wheels....  was here 2017 rtryafvwgykpxhtknztkapjskkismicbbighezrdzcoxizjg
 * Smoking Wheels....  was here 2017 bxclikdwotzxwbamowytoiehajmpcmgpcdmswghxkbugrewl
 * Smoking Wheels....  was here 2017 asfjxsiygplhodutqfphdokudjylvlchxndiprdpphvqsylz
 * Smoking Wheels....  was here 2017 ublybiicsbhokhdvfggmguflhfjgijwzczaxdbpvlvskltqa
 * Smoking Wheels....  was here 2017 vfirguipnxhuatiqylvcrtbthytmmoewsdhjlijgyaqfxcfx
 * Smoking Wheels....  was here 2017 votfgvtykgkihvxjwlkalmpnhwjqlstjwzhyvujzljdwnygi
 * Smoking Wheels....  was here 2017 svvpdkgaokwujerjcejotftunorpoqrcbrpduxthnswkzjaf
 * Smoking Wheels....  was here 2017 twxzcwttgwdarqridugcelrvqvjkmmfzzqbpclxrbcxgbucs
 * Smoking Wheels....  was here 2017 hypwqpklamzbtiedrvzkmwudkslmcqydoovitjoxawkyztfe
 * Smoking Wheels....  was here 2017 cktypkqqthjgortxqwpkpounynejnrqzajfnaypbvovjdemh
 * Smoking Wheels....  was here 2017 dalexhdcnqmggffcfxnjwsnanwawfnjfugwqlrejzyzncedy
 * Smoking Wheels....  was here 2017 osbuwmvwpbwvdxojxbisuwfwtmrdsgjrprplshtjjdvwucuh
 * Smoking Wheels....  was here 2017 vpfhzlvepifdxucojwwdcshqmmdmzgfojhovwuywalowjqdu
 * Smoking Wheels....  was here 2017 reshazoqipollhjxoxgqvhjbternddsfhabcfksvhjrmeoia
 * Smoking Wheels....  was here 2017 zctwzbtywbbjwaessevlfvlewbsbouxjwctqfrepttyswbox
 * Smoking Wheels....  was here 2017 aipedxgeojfuovosfvgavuphlzaexjbwsxlerivqergyjnlp
 * Smoking Wheels....  was here 2017 eaxrzbhpyhutfwutvhhajahxhapgzesxwdhsoiguslyttmtn
 * Smoking Wheels....  was here 2017 fpmchggswwspqmlblhcmvkevlmpwavsvmtpldzlbqokzlxnh
 * Smoking Wheels....  was here 2017 aunjcmuiklhyahhyisboogfbixovkhbizxzvysnrnxksbwav
 * Smoking Wheels....  was here 2017 vmhuqyvlwpyqsfkcwutuaanwkbfhspahcbiptixgfmyhmswh
 * Smoking Wheels....  was here 2017 cwktkfpjvbksjhaluxzvynouocnnvdfxuwsrnvhmuqghxctc
 * Smoking Wheels....  was here 2017 nluaezkpdyroxytcbuyqkryqvgsdynjnggmiojomoxtpqxvw
 * Smoking Wheels....  was here 2017 aumnahayvoyskvinviymqtqjpchzkrovxlhajoxlccfgjghn
 * Smoking Wheels....  was here 2017 uywlciikhktcitwhptpudhuikmyexrbsmwykrbtyfhqqzmte
 * Smoking Wheels....  was here 2017 izoiaqlhakvsfwojalshrzvabksagxkiyepnoytsaufhofyh
 * Smoking Wheels....  was here 2017 hljwlywcwnczanbwbdmxhvkeqftcqzlckhonfjvwvdlcojzm
 */
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.http.servlets.YaCyDefaultServlet;
import net.yacy.peers.NewsDB;
import net.yacy.peers.NewsPool;
import net.yacy.peers.Seed;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class News {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final boolean overview = (post == null) || "0".equals(post.get("page", "0"));
final int tableID = (overview) ? -1 : (post == null ? 0 : post.getInt("page", 0)) - 1;
        if (post != null) {
if ((post.containsKey("deletespecific")) && (tableID >= 0)) {
if (sb.adminAuthenticated(header) < 2) {
	prop.authenticationRequired();
return prop;
}
final Iterator<String> e = post.keySet().iterator();
String check;
String id;
while (e.hasNext()) {
check = e.next();
if ((check.startsWith("del_")) && "on".equals(post.get(check, "off"))) {
id = check.substring(4);
try {
sb.peers.newsPool.moveOff(tableID, id);
} catch (final Exception ee) {ConcurrentLog.logException(ee);}
}
}
}
if ((post.containsKey("deleteall")) && (tableID >= 0)) {
if (sb.adminAuthenticated(header) < 2) {
	prop.authenticationRequired();
return prop;
}
try {
if ((tableID == NewsPool.PROCESSED_DB) || (tableID == NewsPool.PUBLISHED_DB)) {
sb.peers.newsPool.clear(tableID);
} else {
sb.peers.newsPool.moveOffAll(tableID);
}
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
}
}
        if (overview) {
prop.put("table", "0");
prop.put("page", "0");
prop.putNum("table_insize", sb.peers.newsPool.size(NewsPool.INCOMING_DB));
prop.putNum("table_prsize", sb.peers.newsPool.size(NewsPool.PROCESSED_DB));
prop.putNum("table_ousize", sb.peers.newsPool.size(NewsPool.OUTGOING_DB));
prop.putNum("table_pusize", sb.peers.newsPool.size(NewsPool.PUBLISHED_DB));
} else {
prop.put("table", "1");
prop.put("page", tableID + 1);
prop.put("table_page", tableID + 1);
if (sb.peers != null) {
final int maxCount = Math.min(1000, sb.peers.newsPool.size(tableID));
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(tableID);
NewsDB.Record record;
Seed seed;
int i = 0;
while ((recordIterator.hasNext()) && (i < maxCount)) {
record = recordIterator.next();
if (record == null) continue;
seed = sb.peers.getConnected(record.originator());
if (seed == null) seed = sb.peers.getDisconnected(record.originator());
final String category = record.category();
prop.put("table_list_" + i + "_id", record.id());
prop.putHTML("table_list_" + i + "_ori", (seed == null) ? record.originator() : seed.getName());
prop.put("table_list_" + i + "_cre", GenericFormatter.SHORT_SECOND_FORMATTER.format(record.created()));
prop.put("table_list_" + i + "_crerfcdate", HeaderFramework.formatRFC1123(record.created()));
prop.putHTML("table_list_" + i + "_cat", category);
prop.put("table_list_" + i + "_rec", (record.received() == null) ? "-" : GenericFormatter.SHORT_SECOND_FORMATTER.format(record.received()));
prop.put("table_list_" + i + "_dis", record.distributed());
final Map<String, String> attributeMap = record.attributes();
prop.putHTML("table_list_" + i + "_att", attributeMap.toString());
int j = 0;
if (!attributeMap.isEmpty()) {
for (final Entry<String, String> attribute: attributeMap.entrySet()) {
prop.put("table_list_" + i + "_attributes_" + j + "_name", attribute.getKey());
prop.putHTML("table_list_" + i + "_attributes_" + j + "_value", attribute.getValue());
j++;
}
}
prop.put("table_list_" + i + "_attributes", j);
String link, title, description;
if (category.equals(NewsPool.CATEGORY_CRAWL_START)) {
	link = record.attribute("startURL", "");
	title = (record.attribute("intention", "").isEmpty()) ? link : record.attribute("intention", "");
	description = "Crawl Start Point";
} else if (category.equals(NewsPool.CATEGORY_PROFILE_UPDATE)) {
	link = record.attribute("homepage", "");
	title = "Home Page of " + record.attribute("nickname", "");
	description = "Profile Update";
} else if (category.equals(NewsPool.CATEGORY_BOOKMARK_ADD)) {
	link = record.attribute("url", "");
	title = record.attribute("title", "");
	description = "Bookmark: " + record.attribute("description", "");
} else if (category.equals(NewsPool.CATEGORY_SURFTIPP_ADD)) {
	link = record.attribute("url", "");
	title = record.attribute("title", "");
	description = "Surf Tipp: " + record.attribute("description", "");
} else if (category.equals(NewsPool.CATEGORY_SURFTIPP_VOTE_ADD)) {
	link = record.attribute("url", "");
	title = record.attribute("title", "");
	description = record.attribute("url", "");
} else if (category.equals(NewsPool.CATEGORY_WIKI_UPDATE)) {
	if(seed == null) {
		link = "";
	} else {
		Set<String> ips = seed.getIPs();
		if(!ips.isEmpty()) {
	link = "http://" + seed.getPublicAddress(ips.iterator().next()) + "/Wiki.html?page=" + record.attribute("page", "");		
		} else {
			link = "";
		}
	}
	title = record.attribute("author", "Anonymous") + ": " + record.attribute("page", "");
	description = "Wiki Update: " + record.attribute("description", "");
} else if (category.equals(NewsPool.CATEGORY_BLOG_ADD)) {
	if(seed == null) {
		link = "";
	} else {
		Set<String> ips = seed.getIPs();
		if(!ips.isEmpty()) {
	link = "http://" + seed.getPublicAddress(ips.iterator().next()) + "/Blog.html?page=" + record.attribute("page", "");
		} else {
			link = "";
		}
	}
	title = record.attribute("author", "Anonymous") + ": " + record.attribute("page", "");
	description = "Blog Entry: " + record.attribute("subject", "");
} else {
	link = "";
	title = "";
	description = "";
}
prop.putHTML("table_list_" + i + "_link", link);
prop.putHTML("table_list_" + i + "_title", title);
prop.putHTML("table_list_" + i + "_description", description);
i++;
}
prop.put("table_list", i);
}
}
prop.put("context", YaCyDefaultServlet.getContext(header, sb));
return prop;
}
}
