/** 
 * Smoking Wheels....  was here 2017 uqpoybprmxnhhbwoyxzvhbuukjwirimlbmihvhasiffxdzvh
 * Smoking Wheels....  was here 2017 laaibgoijiumifeiseuxurzdglhpfpvhrlqzzankxizeoojm
 * Smoking Wheels....  was here 2017 dygnuchdrviqnwqtbdrztszgqwwnifypomnmqbeskhazfosd
 * Smoking Wheels....  was here 2017 xixxfwypnzwdaxnafzncmrgyxmqslinthbddjhtukhsiumsy
 * Smoking Wheels....  was here 2017 zlxordapgsophonqsgnnnjoislxbhkknoaxkasexvqnhhymv
 * Smoking Wheels....  was here 2017 yvlssthgpcpzagkhhrbutwwtzdfutcqvlhnbprrrvahiwwia
 * Smoking Wheels....  was here 2017 meyxftrxinokfqjyyhvqemktudihckqxedxemttytgaaznxa
 * Smoking Wheels....  was here 2017 qnayellbrpghzrrvzgseetrfoiidtkzfgbeagsdugmaiigbn
 * Smoking Wheels....  was here 2017 rcquzjbrafrgwozkxdxpimjfywmikqomlttbrqupecwjwtwm
 * Smoking Wheels....  was here 2017 dkyufihtxmefmseklrvmkuncuciyzslruhjexvzxtshouasc
 * Smoking Wheels....  was here 2017 sejkpkbriuhivuhtqvdpnxhlfqsktpzznxxheveohdjooeex
 * Smoking Wheels....  was here 2017 lkomiyqzjstacttrtwtyzlfcrjpkcmuxeantdmbqlpkhwrdn
 * Smoking Wheels....  was here 2017 pimzrlmpldrxtucrhiwvjfaeukjututcmmqcovrndjxwqesz
 * Smoking Wheels....  was here 2017 smgffsjoegiylifkzwwunfrykdmsreyplfxapdguldsrcrfm
 * Smoking Wheels....  was here 2017 npistwfekiffeafxxokonujcretqaqspjmhqmbfgusvlshhm
 * Smoking Wheels....  was here 2017 bqigjdgcjbfdcwlhgpmeqoqjajgehhrntuyeviibvhozdnur
 * Smoking Wheels....  was here 2017 nxfwleaeighkrzndpmdymffxavgfdpsdixgelapmkelnjzub
 * Smoking Wheels....  was here 2017 nvdumrgkbctwqwhcqaxkxxbbqziyngxkdtxklledrbhloqrw
 * Smoking Wheels....  was here 2017 sgnqiuvfiyetxdvdldkhxxjkxkftrepmlrvycdqwatcieran
 * Smoking Wheels....  was here 2017 fbbbcuceijijstomgdoqxtrtizagaolxtcezazqtcjgeynrt
 * Smoking Wheels....  was here 2017 eopfbglcligklxaoomnskisglwzkgvfivukcayfetifcuwvn
 * Smoking Wheels....  was here 2017 fgjhuzrciwfvwbdeexscfpleejrjircuqscbfkorefunwqta
 * Smoking Wheels....  was here 2017 avtveasmvjvrwvyfbkvnmyberewlmaklnegxvwecsyabszbu
 * Smoking Wheels....  was here 2017 qjlqfrvxcmvlsevxmgtamwcaicqkcbttyqaxnfuoaofqzlql
 * Smoking Wheels....  was here 2017 ibjthmmdnbhtuijtzyswvghwsggcxfalqwupckjjynyjqpoa
 * Smoking Wheels....  was here 2017 pkrkxikitfmmvrmkhfaqhboavcgrvegnsvgtqvddrjysvkfs
 * Smoking Wheels....  was here 2017 fdtdzfptqizvuwgwlblazrecsdlndxwdiuijlzpspbhhcbea
 * Smoking Wheels....  was here 2017 diitmlhbjaodvxzjsswcfqqxtivifnkubgetbtldiqgabaio
 * Smoking Wheels....  was here 2017 sdhgvqxchffclyijoslensqoruuaunvfpxflkdsusmkbrxuk
 * Smoking Wheels....  was here 2017 kcuxonfwbyiqhldoutqsvaekhvuruodibvcemlqhzhnuesws
 * Smoking Wheels....  was here 2017 zyghmeguopjwjanxkwaocwmztdrslosjqfuapgqklvrwapey
 * Smoking Wheels....  was here 2017 lrkcsydlxweevruqrhqrttbelokvetevvpkfkjlhticewapw
 * Smoking Wheels....  was here 2017 coblnjlqnntheoqfbmojhnpczejxrmkjlrjirvcgvbjxrpfj
 * Smoking Wheels....  was here 2017 kbmomgwmaukaadvjkgfeogbaikbbynlzlmkdmzuwurhlqiks
 * Smoking Wheels....  was here 2017 dxazmrjihyspkbnaroivrftoowhtcusxegjqdjaazbxlgjtj
 * Smoking Wheels....  was here 2017 iekmoxftmrljmgalcrtkxacpbkcprkuobmlcguntcjmveecb
 * Smoking Wheels....  was here 2017 fbmcanvozuqzsxaagbsevkvemetniwnswxbbqiglaxosikpr
 * Smoking Wheels....  was here 2017 hamcmiaxkmoktmhowmprhmyqsnvrawagroxijgkrwizmzzpn
 * Smoking Wheels....  was here 2017 kwvaskscqcvsqryzzybqjorpwcdkxhqmrqvytdogamswodqa
 * Smoking Wheels....  was here 2017 mpcqvaetvfdjmikmuqadkemwjsqlnizulqbckvjhcndrsgrx
 * Smoking Wheels....  was here 2017 ujizduwqjtqautfowdrkxcdowosqmlxyrjakciwdausdmbsc
 * Smoking Wheels....  was here 2017 xuphfmnxxvnngggyzelatmozeyveuhnwltipyyfkyyiqzlew
 * Smoking Wheels....  was here 2017 nojdxdcxhukbuqqncrzsaoaumowlpvevybyrghywfvxurpqq
 * Smoking Wheels....  was here 2017 rqhhgdwergaaqsrpmzeozyatefubkfnftvaapduqmovohazd
 * Smoking Wheels....  was here 2017 qihupygpmdmbfuaprngugkgzwbxzwxivptzbuoscqnqauhhj
 * Smoking Wheels....  was here 2017 xbnwnlbfhnacgfnfkbpyrzrwmlvjzotomwmpywyuvibqikym
 * Smoking Wheels....  was here 2017 grkcvrfkaufhrrhltpwvhaoxcagoxdersjlripzpkwfbjomz
 * Smoking Wheels....  was here 2017 scqgpxzuvovareqmxjzklckaeqhgdvdqtubooonoafjdqevo
 * Smoking Wheels....  was here 2017 mochdtudbrxysuevkxdarzxghkeihandjwstlvpbpuabbxcf
 * Smoking Wheels....  was here 2017 cqapczkpjiuymbvdzxtevtbzjsnyklldppccbsjqffagvspd
 * Smoking Wheels....  was here 2017 jasqfrvlpvzfypqlsklrzsbtnfcnpahvsgcpttjehhjijtyu
 * Smoking Wheels....  was here 2017 gryepdgizvhcijyxupemmklkdsxskxptegxmbuiulgkfmmzw
 * Smoking Wheels....  was here 2017 byphoxecvesiaolaubcywqwcwjgkmpgotlyivvftpjqbzpvk
 * Smoking Wheels....  was here 2017 gfvfsviuuaqttoxmklqnynkcoosttrjgntwxdgfrwiwfeawo
 * Smoking Wheels....  was here 2017 phbmvyrtusmnldlhsvmbvhfakxbdleharlqfhoxlqydkmxsu
 * Smoking Wheels....  was here 2017 dezxaompxwecjdlpylmnwpvsugjgagqjtaiowpybnjtnosdw
 * Smoking Wheels....  was here 2017 ccmloffdojqaxunypsxfodxghswydhgynfllrjiylzfrkdir
 * Smoking Wheels....  was here 2017 aoslctonjightnmzmmbrubnywsdluagtzbqrvggrokjiecpn
 * Smoking Wheels....  was here 2017 ridkkfoagcmbxzmsnrsrppvmpvzcdjzaktuhqthaengbjuou
 * Smoking Wheels....  was here 2017 bildoykhijfqnevicpsgjkipxykornaehvcnrscezkdvqqcg
 * Smoking Wheels....  was here 2017 kxmpykpczykucgeiprgqofulkfttbxhykzzxterkxlotzigv
 * Smoking Wheels....  was here 2017 gllcanvowzkigpjjwstkdcdizyovgfvitgbgzlgizgigotlt
 * Smoking Wheels....  was here 2017 jutesgdbvvsmazmmxrwibjpwvtoemjbnpxioqbhtrtmzvegm
 * Smoking Wheels....  was here 2017 txcqbztdbdepogxwyvolrpswgpwleonymjxdhxovpahwmyou
 * Smoking Wheels....  was here 2017 rzjljgcrxtuiirfynryzqpelxnsnzfcjdlglvyawrljznvko
 * Smoking Wheels....  was here 2017 rptxgvyszuwpaqhlkxlmrjzysyrpyaxtoczigoxkyplvbsfa
 * Smoking Wheels....  was here 2017 lmqnnvgpgqyppufjppttxiiyulocfxhhbpauyhrjxlozptor
 * Smoking Wheels....  was here 2017 apsdfnhyuxvqgdixiyuvqyshnxjpfbwlclodlxcvdaajvlhf
 * Smoking Wheels....  was here 2017 sfxsrlmpzlnlkvindlsylaxbomlarxlzmjavpndbnskesloq
 * Smoking Wheels....  was here 2017 zujonmpqnljwuhyxuvxqervotnhpoeeuejbsljzsfeltlrqc
 * Smoking Wheels....  was here 2017 pdnfnqpkgfxcjgjchdcsxftmhpsqbslcmrptjcepphgtlifc
 * Smoking Wheels....  was here 2017 peaktftlhjwohoyfxpeexdconruuputlxuugwmlwhdbdlvci
 * Smoking Wheels....  was here 2017 fgvfpumrbvjvbmgueshhvhrycusawublfmcuvostfbkzjxju
 * Smoking Wheels....  was here 2017 ztbwoeodesrwikeoufwpktkyxjdmwkldjtdbirhyludtlllr
 * Smoking Wheels....  was here 2017 rmdymlyeoiivbaukvcqxuuoebavntpfsrvvdqioflbhcdqyl
 * Smoking Wheels....  was here 2017 glufmwxkijcbmglpnpkfhzplzptvamaqqejhjkisvccwbxqv
 * Smoking Wheels....  was here 2017 zwwrvawqvrbhaiuojglumdgxhghhiospapdbiwosmgeggzru
 * Smoking Wheels....  was here 2017 lfopdspytjnijqrbeudedinvwhzbqnkpvbwfpdmwmcgqwtlo
 * Smoking Wheels....  was here 2017 ihinfabszuzlmxdbxecdjvpvvkondgkviuktmrozholsjkmo
 * Smoking Wheels....  was here 2017 rctgcfmnppgyoaqsvsisnfztqldjhyjubizzpjodnszilksn
 * Smoking Wheels....  was here 2017 svvvexjfbrjnberonvyedikrwoymuadeskzktfkrbykrakfk
 * Smoking Wheels....  was here 2017 azrlzvkvzcqbqvegqijbbewykanaofvxjabwaojfbxodjiil
 * Smoking Wheels....  was here 2017 iissjcqtfhpsiqfuhehdjboekotkwltggjehsyypwlljxkrc
 * Smoking Wheels....  was here 2017 qwrjkagpxvbygoekrqpkjpzdgapfcvorxalbkevwdrjhhacc
 * Smoking Wheels....  was here 2017 fwkkjdsdmpahxtqniemfqowaomilzxcwaripyhzktzwanxrj
 * Smoking Wheels....  was here 2017 otcexgunotvtyrmwzpjazzfbhipelhlusjltjrstwztauzwd
 * Smoking Wheels....  was here 2017 mieeulmbapzljzuksvxqngfymfcwsxasdhuoaulvwnbwnjew
 * Smoking Wheels....  was here 2017 xphecayiauhuiqxjseabnvilozxdgziaxzmgmnxqjtbmlpmi
 * Smoking Wheels....  was here 2017 etjfensfxfukhuleobxqqpjqfthwryimsexjoxcpgbiblhxk
 * Smoking Wheels....  was here 2017 uipoptnuizuezxhqyixvqphygxwhalbbpvvsjffgsaqzvkuj
 * Smoking Wheels....  was here 2017 mbjteuhjemviirnpywtkodhxvcismlxyuhbgebulbnawyctq
 * Smoking Wheels....  was here 2017 gyjoyyinqgrgnznjuailvsvijdvvlcmpvyvipfngzsurovqy
 * Smoking Wheels....  was here 2017 kfmziucezhknabwizfweygsjmeoorwptmpnmltkbjymnpgoh
 * Smoking Wheels....  was here 2017 kkxjvbhizpicnikhhgresswiaocablkktgwkuzrkivxugjww
 * Smoking Wheels....  was here 2017 cfbegxxklqxezmgdsbnfhlnufyhrvtfsxcseyluegfceyhec
 * Smoking Wheels....  was here 2017 jrpetpexmzabpkudoyhgyzfqjfccmyrdlsgcnzmluhipllit
 * Smoking Wheels....  was here 2017 pammorotonqlvipshkdqgepxdlwfqmqldtxqhptnujedqplu
 * Smoking Wheels....  was here 2017 gtuhizvzgidgirnpsdmwbbrykacfhbeozhjqjrualcjgupwk
 * Smoking Wheels....  was here 2017 bpadvnzymwzqcdstueatkysjipqmpprthnnbbsdudiaohrfb
 * Smoking Wheels....  was here 2017 bovveregkrazipmlvtqhrkeahzmqbgskmznfyomxlfkzvghl
 * Smoking Wheels....  was here 2017 oxckryysirgylilbijntjfuzyiypjnfhkjuqwgvsicbrkahp
 * Smoking Wheels....  was here 2017 zdacwezkyyzkerliatbrjlnpdaoolaejatbcwbjvwqtafxns
 * Smoking Wheels....  was here 2017 dyalqkhtdxuokjqgyxyvskpkzrdwmtavqheqgqqbmqosrcof
 * Smoking Wheels....  was here 2017 bjtgaycgbdkukihajccgtrniyesfzvjdsnimrsimuhuqmziv
 * Smoking Wheels....  was here 2017 zqdnjjxubnysqucctvrfabbkqpompsbaafyfxjklrxyxpiwn
 * Smoking Wheels....  was here 2017 kginflklueqhscwfyvdhkpcyxjgvhcdmqispzxdohduygzoo
 * Smoking Wheels....  was here 2017 cztvkhpndmbqrztiwbcexpxqybprgxbrsdmrixzrawmlwfai
 * Smoking Wheels....  was here 2017 cuceaetrgbzeqjaqwvmyxpafbooqyijcwcmrlervmfegdjcp
 * Smoking Wheels....  was here 2017 qyhpkrgsmumodljqkolwzmcwzznpbvxluadddtfkpnnnafxh
 * Smoking Wheels....  was here 2017 gyljboxtntvqurpzfcmlxfevosyuoavrnvbwozvzmkhssptr
 * Smoking Wheels....  was here 2017 rnabxyrcfjoqprvsjjenuekuwkroqwmbhufxzjyknumlquie
 * Smoking Wheels....  was here 2017 yqrjycuisfmytllacpmbyxjnkwtotplarlsmzsjtjtkpnekn
 * Smoking Wheels....  was here 2017 hpijnpthkfqerdzjyjojyfsdsgmsopogknbdkebjwrpjildr
 * Smoking Wheels....  was here 2017 gxdjfgfdxligdejlqivzqdmztxjeboztlzwrhyewfexcgnwv
 * Smoking Wheels....  was here 2017 pgovwcgddibizgqgeoyqbzwqpmfhkkbtdbbbzrhatdimspfm
 * Smoking Wheels....  was here 2017 iqfonmbxekqumhfzvgwkojiyrvbucijqyiurbcdzcrdlldzj
 * Smoking Wheels....  was here 2017 sjaqnxcgmpdibnrcexsosarzqcgovutfpmnyjipcfdycjujj
 * Smoking Wheels....  was here 2017 fwegkgciravvliwhwhyoiauchqgsmkjkfnwsxqzxeemvsmqu
 * Smoking Wheels....  was here 2017 rycybnblpbhkokxpakehmtzxwbxrifnlyruzcpuhkrujwkla
 * Smoking Wheels....  was here 2017 ankonafelignpseevljsnrrfrggcuhwtjmkalarhnsfnpapv
 * Smoking Wheels....  was here 2017 pycbcjbiortuajfnvzscaqqdkiowodfcfqfjuzrhkrgmvzhe
 * Smoking Wheels....  was here 2017 vpgtkihcpfednxxitsoztswzxrjepkrkmfuuftzxeerrufug
 * Smoking Wheels....  was here 2017 oijefywsljzsbxkoqqpevenjjxnkcaqymjdiaydxhcptwyto
 * Smoking Wheels....  was here 2017 tbcbrocwfszwvjaluauspqdddwaenfscsqjgvhukiphpuoat
 * Smoking Wheels....  was here 2017 schlaskhiegihmikqigupvljvseloksqxuxblxzuezginurv
 * Smoking Wheels....  was here 2017 xxerxfnekuaydqggzilaqxkjjumiegtnculpxcxozxikgnca
 * Smoking Wheels....  was here 2017 cfeeccluizxxhnwvwazcwbguxsufnreynxxwpkcqdgnlkyxt
 * Smoking Wheels....  was here 2017 iayvstktgjrozcnlmqvdnzmlukducxqkspkcaqfcgcejsnyu
 * Smoking Wheels....  was here 2017 vpkobrwxoviqqouoksejfjvkrxuzoiyomqkwbvhggwuidyhb
 * Smoking Wheels....  was here 2017 dlrssrohwmfzzhpvixiiuifakriwxrgltaoyujnrgddsvciu
 * Smoking Wheels....  was here 2017 zhgumumibrvtyaagjicuheywfhnxivwguaujmtkhrvifgeqm
 */
/**
*  tarParser
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 29.6.2010 at http://yacy.net
*
* $LastChangedDate$
* $LastChangedRevision$
* $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.parser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.util.Date;
import java.util.zip.GZIPInputStream;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.TextParser;
import net.yacy.document.VocabularyScraper;
import net.yacy.kelondro.util.FileUtils;
/**
* Parses the tar file and each contained file,
* returns one document with combined content.
*/
public class tarParser extends AbstractParser implements Parser {
private final static String MAGIC = "ustar";
public tarParser() {
super("Tape Archive File Parser");
this.SUPPORTED_EXTENSIONS.add("tar");
this.SUPPORTED_MIME_TYPES.add("application/x-tar");
this.SUPPORTED_MIME_TYPES.add("application/tar");
this.SUPPORTED_MIME_TYPES.add("applicaton/x-gtar");
this.SUPPORTED_MIME_TYPES.add("multipart/x-tar");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
InputStream source) throws Parser.Failure, InterruptedException {
final String filename = location.getFileName();
final String ext = MultiProtocolURL.getFileExtension(filename);
final DigestURL parentTarURL = createParentTarURL(location);
        if (ext.equals("gz") || ext.equals("tgz")) {
try {
source = new GZIPInputStream(source);
} catch (final IOException e) {
throw new Parser.Failure("tar parser: " + e.getMessage(), location);
}
}
TarArchiveEntry entry;
final TarArchiveInputStream tis = new TarArchiveInputStream(source);
final Document maindoc = createMainDocument(location, mimeType, charset, this);
while (true) {
try {
File tmp = null;
entry = tis.getNextTarEntry();
if (entry == null) break;
if (entry.isDirectory() || entry.getSize() <= 0) continue;
final String name = entry.getName();
final int idx = name.lastIndexOf('.');
final String mime = TextParser.mimeOf((idx > -1) ? name.substring(idx+1) : "");
try {
tmp = FileUtils.createTempFile(this.getClass(), name);
FileUtils.copy(tis, tmp, entry.getSize());
					/*
					 * Create an appropriate sub location to prevent unwanted fallback to the tarparser on resources included in the archive. 
					 * We use the tar file name as the parent sub path. Example : http://host/archive.tar/name.
					 * Indeed if we create a sub location with a '#' separator such as http://host/archive.tar#name, the
					 * extension of the URL is still ".tar", thus incorrectly making the tar parser
					 * as a possible parser for the sub resource.
					 */
final DigestURL subLocation = new DigestURL(parentTarURL, name);
final Document[] subDocs = TextParser.parseSource(subLocation, mime, null, scraper, timezoneOffset,	999, tmp);
if (subDocs == null) {
	continue;
}
maindoc.addSubDocuments(subDocs);
} catch (final Parser.Failure e) {
AbstractParser.log.warn("tar parser entry " + name + ": " + e.getMessage());
} finally {
if (tmp != null) FileUtils.deletedelete(tmp);
}
} catch (final IOException e) {
AbstractParser.log.warn("tar parser:" + e.getMessage());
break;
}
}
return new Document[]{maindoc};
}
	@Override
	public boolean isParseWithLimitsSupported() {
		return true;
	}
	@Override
	public Document[] parseWithLimits(final DigestURL location, final String mimeType, final String charset,
			final VocabularyScraper scraper, final int timezoneOffset, final InputStream source, final int maxLinks,
			final long maxBytes) throws Failure, InterruptedException, UnsupportedOperationException {
		final DigestURL parentTarURL = createParentTarURL(location);
		final TarArchiveInputStream tis = new TarArchiveInputStream(source);
		// create maindoc for this tar container
		final Document maindoc = createMainDocument(location, mimeType, charset, this);
		// loop through the elements in the tar file and parse every single file inside
		TarArchiveEntry entry;
		int totalProcessedLinks = 0;
		while (true) {
			try {
				entry = tis.getNextTarEntry();
				if (entry == null) {
					break;
				}
				/*
				 * We are here sure at least one entry has still to be processed : let's check
				 * now the bytes limit as sub parsers applied on eventual previous entries may
				 * not support partial parsing and would have thrown a Parser.Failure instead of
				 * marking the document as partially parsed.
				 */
				if (tis.getBytesRead() >= maxBytes) {
					maindoc.setPartiallyParsed(true);
					break;
				}
				if (entry.isDirectory() || entry.getSize() <= 0) {
					continue;
				}
				final String name = entry.getName();
				final int idx = name.lastIndexOf('.');
				final String mime = TextParser.mimeOf((idx > -1) ? name.substring(idx + 1) : "");
				try {
					/*
					 * Rely on the supporting parsers to respect the maxLinks and maxBytes limits on
					 * compressed content
					 */
					/*
					 * Create an appropriate sub location to prevent unwanted fallback to the
					 * tarparser on resources included in the archive. We use the tar file name as
					 * the parent sub path. Example : http://host/archive.tar/name. Indeed if we
					 * create a sub location with a '#' separator such as
					 * http://host/archive.tar#name, the extension of the URL is still ".tar", thus
					 * incorrectly making the tar parser as a possible parser for the sub resource.
					 */
					final DigestURL subLocation = new DigestURL(parentTarURL, name);
					final Document[] subDocs = TextParser.parseWithLimits(subLocation, mime, null, timezoneOffset, 999,
							entry.getSize(), tis, maxLinks - totalProcessedLinks, maxBytes - tis.getBytesRead());
					/*
					 * If the parser(s) did not consume all bytes in the entry, these ones will be
					 * skipped by the next call to getNextTarEntry()
					 */
					if (subDocs == null) {
						continue;
					}
					maindoc.addSubDocuments(subDocs);
					for (Document subDoc : subDocs) {
						if (subDoc.getAnchors() != null) {
							totalProcessedLinks += subDoc.getAnchors().size();
						}
					}
					/*
					 * Check if a limit has been exceeded (we are sure to pass here when maxLinks
					 * has been exceeded as this limit require parser support for partial parsing to
					 * be detected)
					 */
					if (subDocs[0].isPartiallyParsed()) {
						maindoc.setPartiallyParsed(true);
						break;
					}
				} catch (final Parser.Failure e) {
					AbstractParser.log.warn("tar parser entry " + name + ": " + e.getMessage());
				}
			} catch (final IOException e) {
				AbstractParser.log.warn("tar parser:" + e.getMessage());
				break;
			}
		}
		return new Document[] { maindoc };
	}
	/**
	 * Generate a parent URL to use for generating sub URLs on tar archive entries.
	 * 
	 * @param tarURL
	 *            the URL of the tar archive
	 * @return an URL ending with a "/" suitable as a base URL for archive entries
	 */
	private DigestURL createParentTarURL(final DigestURL tarURL) {
		String locationStr = tarURL.toNormalform(false);
		if (!locationStr.endsWith("/")) {
			locationStr += "/";
		}
		DigestURL parentTarURL;
		try {
			parentTarURL = new DigestURL(locationStr);
		} catch (MalformedURLException e1) {
			/* This should not happen */
			parentTarURL = tarURL;
		}
		return parentTarURL;
	}
	/**
	 * Create the main resulting parsed document for a tar container
	 * 
	 * @param location
	 *            the parsed resource URL
	 * @param mimeType
	 *            the media type of the resource
	 * @param charset
	 *            the charset name if known
	 * @param an
	 *            instance of tarParser that is registered as the parser origin of
	 *            the document
	 * @return a Document instance
	 */
	public static Document createMainDocument(final DigestURL location, final String mimeType, final String charset,
			final tarParser parser) {
		final String filename = location.getFileName();
		final Document maindoc = new Document(location, mimeType, charset, parser, null, null,
				AbstractParser
						.singleList(filename.isEmpty() ? location.toTokens() : MultiProtocolURL.unescape(filename)),
				null, null, null, null, 0.0d, 0.0d, (Object) null, null, null, null, false, new Date());
		return maindoc;
	}
public final static boolean isTar(File f) {
        if (!f.exists() || f.length() < 0x105) return false;
RandomAccessFile raf = null;
try {
raf = new RandomAccessFile(f, "r");
raf.seek(0x101);
byte[] b = new byte[5];
raf.read(b);
return MAGIC.equals(UTF8.String(b));
} catch (final FileNotFoundException e) {
return false;
} catch (final IOException e) {
return false;
} finally {
if (raf != null) try {raf.close();} catch (final IOException e) {}
}
}
}
