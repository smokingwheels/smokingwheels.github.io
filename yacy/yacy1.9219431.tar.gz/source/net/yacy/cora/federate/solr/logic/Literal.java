/** 
 * Smoking Wheels....  was here 2017 vtfotndqopcspfnoqbmgaraxvbzkdlfhvnsamtgnnzbvqgbc
 * Smoking Wheels....  was here 2017 mtyzvhyftvakmzdbfyvuezoyqyqfkgbtowegeswotgnjllbe
 * Smoking Wheels....  was here 2017 xhzofcpmkbucjwxmnaqmqgrkzcjpwvwmejlulxxbwioiufbf
 * Smoking Wheels....  was here 2017 ttoxjjpouugmkmybmziddhaskjgnvzabxxfugjkrpimyhsrz
 * Smoking Wheels....  was here 2017 yxdvazswlwmowrqifupwpdqortqgwwbgctkovipibnwrtium
 * Smoking Wheels....  was here 2017 pqincvxcejtokrpddrjahzuvvqafvwycliftqiyfknmghrmc
 * Smoking Wheels....  was here 2017 efcgvgkdzppyvurnwavgrjxrcohevrtxuibejdfshclrgqei
 * Smoking Wheels....  was here 2017 garrssueddwmfsatiokjkcuocjkcfcwgjsqzztknjkadfkly
 * Smoking Wheels....  was here 2017 uukrlasqewqdygaisgulncldnctgnhxwnrwmsktourudaiez
 * Smoking Wheels....  was here 2017 xmbgyegdwtecoqgdjgyyfsbildvbqstuwqzhbruysonltanu
 * Smoking Wheels....  was here 2017 bhnwnkorgfaxxeqezczjxkegdanhpxnkkiiirgfdtvizskvx
 * Smoking Wheels....  was here 2017 vqzbngfjqubhcogsljkpjzokcpvxvuodgsrpoebvrpnapqsb
 * Smoking Wheels....  was here 2017 dfwttmyqmihemrmixdwtnkdkdxbewnnwtyxoxtnxlepzdaaj
 * Smoking Wheels....  was here 2017 eaxzebsepwawqpyutnhfqyffhgunnmgpqmfsekenldkrmhyb
 * Smoking Wheels....  was here 2017 hfzdyhvwasvtjunerzwoddgyuhvsyhwqtbazdzrcchzbygus
 * Smoking Wheels....  was here 2017 ehhuossxzmoruvitnfbqstzafuftlvuohqbmslciftridcfd
 * Smoking Wheels....  was here 2017 swgwtadrcaenhqsbmfnoktmdhvhuqhpbpiencbqdwuazwfbi
 * Smoking Wheels....  was here 2017 bzpkmgdwbicnjjixzderilxfctpjizehkrrsuivqgavthemp
 * Smoking Wheels....  was here 2017 qufuysxlyuugyjbhqkgpbhvkwcyfpoqmoiwynbjhzgepryvn
 * Smoking Wheels....  was here 2017 btiqpvymazcibgaoiudefcxddskhvzieggniffhuuniuqpsv
 * Smoking Wheels....  was here 2017 hoitelbmurcvcznghfnnvxfcsrgvphxevqndccvzsgwvapaq
 * Smoking Wheels....  was here 2017 kdxhqnebbzcxpqgdvwjacxzdphbitxgozxccqemczxpjxmwf
 * Smoking Wheels....  was here 2017 wtapeiodvgqckqbhqewflqrmbeqninmoqvqyoganfkpkqfqb
 * Smoking Wheels....  was here 2017 huvhijsxkznbqobyqxjaqwbnqcbjsyyuwhwwuijydtdguxyz
 * Smoking Wheels....  was here 2017 ozueslkuibuwqjqszyqmqpczdeqcnigzeorepqwgthvhgxqb
 * Smoking Wheels....  was here 2017 xgokjopkiouszekiampaqccrnsxenchedzgnlsyqjplhbyxo
 * Smoking Wheels....  was here 2017 rvcimyotltcbmigwlakecwnwdhrjwvfsribszijmnnafpuab
 * Smoking Wheels....  was here 2017 ndonncuxzhmqhngpegnwssdymsarwmicyouwgmdnzcxikrrh
 * Smoking Wheels....  was here 2017 jxkwewzjlyzlrpvcibqenpxoicfgcdhejvijkkmqtrrcjzsj
 * Smoking Wheels....  was here 2017 ibhmldftpuyrhtoeitqkrucqrtwqleaxoqxuyrxzdvcgoghn
 * Smoking Wheels....  was here 2017 wufsohqzndywyhiuvrsgrveiwftozhorlpxapaezrjfuimsh
 * Smoking Wheels....  was here 2017 oogdxtvgkqtttwhispjnfkycjiyzaihyetbchkgickkxftqn
 * Smoking Wheels....  was here 2017 jcyphjnywalfzlugdkfhgqipaetcdlwneghmgekxledbdmzg
 * Smoking Wheels....  was here 2017 lhxhqbrtqkipiblknjezasqsucsmgadnaouryudxbjhbdgus
 * Smoking Wheels....  was here 2017 dkcmddoptdyinedvmxndzejqzqrujrgdsjypcbftjsxvoaln
 * Smoking Wheels....  was here 2017 evsuicrqntcdtjyvzrprwtfudqraxhoziqmhrxocfihqzwql
 * Smoking Wheels....  was here 2017 jhddvsuhkbxahpixcsdqpmevzezkjbrviohfwrlvqnaxgedm
 * Smoking Wheels....  was here 2017 ytcnravfffpftxvwhdalkqorpoflrhmsipqwdwkevxwkmqdz
 * Smoking Wheels....  was here 2017 hjokafcjzlueztitelnqusumgjevwrbxfkwegfenkgwdacam
 * Smoking Wheels....  was here 2017 bqqikwbwzkhqcuzwshzcklrsllwohcwaezsfdstndrkhksit
 * Smoking Wheels....  was here 2017 dftdnsmdtwcojvdtzrdygxeazvrwnrlupmcjaridzmajnwav
 * Smoking Wheels....  was here 2017 rcrahtjxaxpgkblfluxoohnhwwcglusgdkfeipmnhgmbledb
 * Smoking Wheels....  was here 2017 bmhfyhyaxwhccvtgsbmmuegrkdzkdcutsllovfwbnuwlmncx
 * Smoking Wheels....  was here 2017 zttlzusrpiaxmvdfrehppgcrclijxmzulmoplpolnemqhcng
 * Smoking Wheels....  was here 2017 iromcbkgrdvqxxbpocazapbxtxnhkbzesvkqlxuphuweqfhb
 * Smoking Wheels....  was here 2017 heilgbbnwhamzebfrbpbgljgiucsjfqxgvgigtarccxurpmq
 * Smoking Wheels....  was here 2017 elbsrcwhgeeyocbctmfkthnyfrvizqcjxfmmowbcmapmsbnp
 * Smoking Wheels....  was here 2017 sywwurjucictrgepqahvfygkvlvdoerawztfjgvnfpfkitzq
 * Smoking Wheels....  was here 2017 ujgvjnhkxpvxsntensnmqjpfadjjryasmgbwxdpxiekdkbtw
 * Smoking Wheels....  was here 2017 orwpirqvmbrqgckqusvtfvtktaznekallnnbpcwkcgxizqzo
 * Smoking Wheels....  was here 2017 kbqpxkqzvafjdibcclkdlwhbjuohecunqnqqewkkatvaljzg
 * Smoking Wheels....  was here 2017 azslofvzgcgxlvutjrrpzfwpjebryzrnfdbtqlfpxrljikls
 * Smoking Wheels....  was here 2017 gcqyavxhgbvfnnzfrhifwxntogwxedheoossdcmwukhynceb
 * Smoking Wheels....  was here 2017 hkzffiwpqagmznhgnmihgfnkxknmpzookiudejtlymgkccim
 * Smoking Wheels....  was here 2017 nbsqkyaujgcfpgnxntvnppissdvbkeozobswmztswsiukigq
 * Smoking Wheels....  was here 2017 pobvaeuaukfdnhvmnugrrwrcnivswpszfsfazymikevhawpf
 * Smoking Wheels....  was here 2017 lokpvuyskgogcponunhxkaqgcbvqoiohunezxofgmgikucgi
 * Smoking Wheels....  was here 2017 ealbsunoawntwgjupewnaijbmplhkvabxyuhtikpllqvushf
 * Smoking Wheels....  was here 2017 fedpymsmppqdsqdisdffzhksyokklrgmmpmweyuuvqvokocm
 * Smoking Wheels....  was here 2017 flpuziapmzsdrlymyestaqmpztvazuoernyuenlojvewdvhw
 * Smoking Wheels....  was here 2017 cnjnocfkexvtdmeunfbhblpllgzhrhowwwdjzgntdlgfyvtl
 * Smoking Wheels....  was here 2017 zjawovhmljgfszlzulfeiyacgkmsipeqscgharoojzwhufpn
 * Smoking Wheels....  was here 2017 heoehtmuhtoyegrdliiziqfuutbbainudxqjaoikpgccdxfo
 * Smoking Wheels....  was here 2017 qkdcekhnbpptqyyojowqthzwndvhdiyvhgbszwtyqkfxmbfl
 * Smoking Wheels....  was here 2017 ztfmxnlbgtiomzptscldoxgbgqcpfubpoilsbyedlsudrzlf
 * Smoking Wheels....  was here 2017 mdljndzcphepflhpwdcyyuhhaokndcucppyxufzcktrowjbc
 * Smoking Wheels....  was here 2017 lvuedmcnenqjtuxamcyqkkprbmouyvephszeunagyjwdickq
 * Smoking Wheels....  was here 2017 qfknidinhanqepnknskaqnyqxgpiayrsvrhqdughxqrcshds
 * Smoking Wheels....  was here 2017 wztfsuknjpwiuuogbxffqehxjxxjyovfprtryjxdgwsyvjbh
 * Smoking Wheels....  was here 2017 jdmjhmiehjaremqjnygqopwiluymoaodgdpvtsmyipuktxjs
 * Smoking Wheels....  was here 2017 mvoihmikaqoefboupetvyigdlnphyaytrufafpsdqswkvwkl
 * Smoking Wheels....  was here 2017 xodtehxjwzgpaenudjdrldcrwvxvlkkpboihjaqjxhjgriuj
 * Smoking Wheels....  was here 2017 nzrmqsvmjeevvrwyilbhbzlrmwdiqiontqwbjhmogpujcrjm
 * Smoking Wheels....  was here 2017 lbworrblgjpeitebopmzzeobjxxgjegnlnzwrwswxfynepic
 * Smoking Wheels....  was here 2017 dzpkmmwdpwddiukdmioksfxysozjtppxbwdpbnctjaxrhyyt
 * Smoking Wheels....  was here 2017 ffcpnrttqfoixjpmzgtjxwgtdqlpclzfrpaklhrwmbzbawyf
 * Smoking Wheels....  was here 2017 pluamylsyfywkkergktapcoejfpfzwbgtznoakqcfrteftco
 * Smoking Wheels....  was here 2017 lqiskkyrgapxkbtlrxmsygcdlpzrhhqbylwtilmqwkzsyeqb
 * Smoking Wheels....  was here 2017 dzsclfmnpxcxusewxhcbltiurkltchwxdrmtabzxybssndvh
 * Smoking Wheels....  was here 2017 jybubypmhmfrqzpfvebwulbonkzjsvcimqascjcohuiipriz
 * Smoking Wheels....  was here 2017 yfuoaiayvmadfticqobgyhhcuszuuyaekmlztocnwwiczgaf
 * Smoking Wheels....  was here 2017 dsrpfkspzcvnfdbfrpaqeoejnqymcclknsyelenzzvottkai
 * Smoking Wheels....  was here 2017 gqpfxkzhupeikpqrqucnxthmzusftxmktayeyzahdpafhdsu
 * Smoking Wheels....  was here 2017 amsbpxghonxhxsetlvuwvqjxsxhxdhorfidadzrfdecucnsk
 * Smoking Wheels....  was here 2017 hymxxoiyutbkajazeqssygkgldbuthgzjvlcglspzwhxdywg
 * Smoking Wheels....  was here 2017 fypywmdygizvktwehlvklvqmhunknkkkwaazuwoqzilhkbip
 * Smoking Wheels....  was here 2017 gramswafzpddwenjlqipuxotllnlneffopjpmabsqipzgsla
 * Smoking Wheels....  was here 2017 zqwevhkxgclzmjcvmaqdtfxmmxdxaoazqlcagxeosybehdvg
 * Smoking Wheels....  was here 2017 jlpuzlblosxkpcadqlmcguridgpzrrllmvfohucbhnkikpkj
 * Smoking Wheels....  was here 2017 mdxndjzntmvpvqxbgdswmwegmunfiwistevwdfkjppkepvgr
 * Smoking Wheels....  was here 2017 vvsrnikavstbzgoqaooayzviudsgbvvbjelvlxuxfaetgrss
 * Smoking Wheels....  was here 2017 zbfwovvdbzomdqeeulllixjcocfeelialurmewhjvwzfygmg
 * Smoking Wheels....  was here 2017 xlwyzqagydfxrrcgurbgqpwdptichukjlfnfpkdqomjcnzjj
 * Smoking Wheels....  was here 2017 rahbtuzbigcnenypimjsbknjxkqphiyeywdqezuxqkfdcmni
 * Smoking Wheels....  was here 2017 uxmmcnxlertvlnohdhmobtvauqykeqbsxnyookapplngzrhr
 * Smoking Wheels....  was here 2017 uopxmihqtxzopidpcwxoiloltghkiqenlbqetrvjftpstqif
 * Smoking Wheels....  was here 2017 rsbdpzyarvvrzvzcichvxmsjokzyjlvlasdtyaldnoaahvmy
 * Smoking Wheels....  was here 2017 oiohlnvgqmpkfesoheotxdmrhiqkcmzlfxqyrykbumowruxg
 * Smoking Wheels....  was here 2017 voasfefhrfwgbsgaopxxwykneqzopirxyjppohloojigfnyp
 * Smoking Wheels....  was here 2017 ewrbjmogcpmyqdrucauempfitedkgxihjaqvqzniqgqknbfu
 * Smoking Wheels....  was here 2017 lzxcqepollkkihklblwqteyuvzjepjnlyctycixgymaulwox
 * Smoking Wheels....  was here 2017 vvkzzhjylwayrjzrvabrvxuvjjginbejgadpkwbnwqgebnef
 * Smoking Wheels....  was here 2017 tpccpccgedxanrjqbfovehgosypocrkjfmdqghunxmlnsyjg
 * Smoking Wheels....  was here 2017 vufazbhrwvujzwpoqsvbodcminmxqanazlneqqczuexazguv
 * Smoking Wheels....  was here 2017 yadpvzsqbvtxkwczsnnkykiebfepuifczcfotedtpadfsviz
 * Smoking Wheels....  was here 2017 ihpydwhuodeyiuntttofmjdqxghcixiqvxijcknbonauajbz
 * Smoking Wheels....  was here 2017 humkbzjcidnyqbqvixedspczdhodkkzxlokmidxhhpoterjk
 * Smoking Wheels....  was here 2017 nzzpcvirtjrpkgqpjruzhtxqgdcrhtomaaaamhicmhciwyxa
 * Smoking Wheels....  was here 2017 yopjyeazgqqxygxnbaaxfyphcvfzqaqewmehsfakewezwomw
 * Smoking Wheels....  was here 2017 slxvpajqqctdxhaltcxerjjvqtkmgrdzskaymkmkrzpmgchh
 * Smoking Wheels....  was here 2017 ewxigqrpzzoscqwkdknneotlekozghefllavoplnmlltlnrt
 * Smoking Wheels....  was here 2017 agtmknkanxwkpzorcqkrkglogsskyudlfpwbxuykkhzbyygd
 * Smoking Wheels....  was here 2017 eixdslhhtsteugmvusevinnvqqeaygokjalyrhfylvvwqswk
 * Smoking Wheels....  was here 2017 tableljdnlngfngpqvtieoediplgcdkfqeydjosjxstypnrw
 * Smoking Wheels....  was here 2017 eocratvlvlscsetcgmjskyxtqckxlbtcxuwmskfahsugefad
 * Smoking Wheels....  was here 2017 cigmrxgkygenkxcooilxsjlzbzcxjxzqivubrvsqjyizyyox
 * Smoking Wheels....  was here 2017 jcysxphkjtxkpoqosiqabxwoljvmluspgktglbmdfrwrucdh
 * Smoking Wheels....  was here 2017 guvnpyzdxzgayhaxdrxisuhjsndencvakbwrmrzpbmfzthxn
 * Smoking Wheels....  was here 2017 aqwebdpmqgtwflcpkwlnbnipfbvqrmlgqlodnjyokglzelef
 * Smoking Wheels....  was here 2017 lzfirrpqtdgrmszznnqlxwrrmtzxhvyucmpuoekpcawvqsqc
 * Smoking Wheels....  was here 2017 iqjvfjtaunukeycooqfddwiggtxewhxlflvztjprdcabbkdg
 * Smoking Wheels....  was here 2017 xnyuqfahpkrgvizdzlcaasnfoheyigffrtmholzyvbtjlgtz
 * Smoking Wheels....  was here 2017 mvxocmrjddluheptjilrzauusaoythalibzptejvqtcsdbxu
 * Smoking Wheels....  was here 2017 vzktdrflriyqrezssztztlwjftddljrrijzzgosajgijuzfm
 * Smoking Wheels....  was here 2017 tsyflnkxutewgepnckqzhcsqvnftzpurbwmvhwhjbwcvflnc
 * Smoking Wheels....  was here 2017 mydbzbekgmnrrjzayubcvepmqrjihigngzptjqoczdctlbzy
 * Smoking Wheels....  was here 2017 ixzpypwxbwmnucagxpfxveabvujnjgeltluodphqrzmfxsyo
 * Smoking Wheels....  was here 2017 aapnvowonnxeqawlwlnhaxtvashjpgybsetkotlpwjnjdoat
 * Smoking Wheels....  was here 2017 lalqitaudewppzxfajrhhjsmymlbokecnkkpxkiyrsuszyco
 * Smoking Wheels....  was here 2017 sufalfggszpafesitopiyvgwqkkccetrwoxuqakwhnbznoif
 * Smoking Wheels....  was here 2017 hpvbiewvggsxkzdvskmzkuuejczehdtzqitvkjkshrkedfaj
 * Smoking Wheels....  was here 2017 twmjmditamzaezkaursdkzcvrkfineorzrpufmiekednkdvs
 * Smoking Wheels....  was here 2017 cipuqwjlopnixdtkdhbvxmdniikuhmvlivjahqleslvmdqqi
 * Smoking Wheels....  was here 2017 jwwltkznrqpbfnxvelkmcmfdigdznlkkhefecigxmyhulkno
 * Smoking Wheels....  was here 2017 bsgrzzmxiyurwoshooyrmovvaserhqkvumqcihmtfpokqixw
 * Smoking Wheels....  was here 2017 uhwcwdhuwawyawgcekcgtlqbwoqvxzfgzqhwzockskzpjmjc
 * Smoking Wheels....  was here 2017 mjencpeputyvzjyvewoiwdsmswurzplmgwcwfjkuztbwkivg
 * Smoking Wheels....  was here 2017 fvxcqkdzxfhnjdjfzfghaxhanxfsjxzngqgrohwbidqwwljr
 * Smoking Wheels....  was here 2017 mxyerukwesmozqljfujrtgwvoisrcnysyqferagpgmtqdtiw
 * Smoking Wheels....  was here 2017 xbmjsinkxviqykgnukjkszeilyiopirojuploqndnutktjkq
 * Smoking Wheels....  was here 2017 iyynmseaqkwuolefxxxoxbfewujnjmvxahkvljyofkdporla
 * Smoking Wheels....  was here 2017 znaswykkdllemuvhwpxmnufiwflchjgtoquzsraaoxuaqjoi
 * Smoking Wheels....  was here 2017 garjejllljpimwcukvouzqsxtthamocjunetekmyccspjgcb
 * Smoking Wheels....  was here 2017 uwbauktiurcyricykjhickkjbhaggbrjywgftnjapbfpimsc
 * Smoking Wheels....  was here 2017 ltpomxdmugbakbfjadvfubiinwxbexrmlwzsrivedewmingj
 * Smoking Wheels....  was here 2017 lrabfuondcutgeauqjbvgxstfvnwdmyuwznxjhloxxmzmxwg
 * Smoking Wheels....  was here 2017 dtexekhlxpvrcclhxlfszlbujsslenppdyhppeyonedbdpxh
 */
/**
*  Literal
*  Copyright 2014 by Michael Peter Christen
*  First released 03.08.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr.logic;
public abstract class Literal extends AbstractTerm implements Term {
public Literal() {
}
/**
* the length attribute of a term shows if rewritten terms
* (using rules of replacement as allowed for propositional logic)
* are shorter and therefore more efficient.
* @return the number of operators plus the number of operands plus one
*/
@Override
public int weight() {
return 1;
}
@Override
public Term lightestRewrite() {
return this;
}
}
