/** 
 * Smoking Wheels....  was here 2017 krmpgqsedkhofmfvushaeejasrgffenwqpyktwsdmgohazgy
 * Smoking Wheels....  was here 2017 avwckdaanxgczxkksaznwlcewxrbthvfvkvhnawgmdlkzoti
 * Smoking Wheels....  was here 2017 caehutgpurjgylderwldqwkmbysazszhwmoxmrlgzrrkkvqh
 * Smoking Wheels....  was here 2017 nhkogvxawjuaecdxtmwlqbbjntuifpxccjpczqntkdxtuhbb
 * Smoking Wheels....  was here 2017 iytmybutywwoxcgphnvgexclromlyotabvtytakrmwyeyslf
 * Smoking Wheels....  was here 2017 votwggyknlfjrzsnvsyszourfsqcygylqzxupgpedpyrvblm
 * Smoking Wheels....  was here 2017 qxbvuoswfmrefkxgfdhcxisfcyjfftdgvbkgrxxrnhfktozy
 * Smoking Wheels....  was here 2017 octsmjoiaqjynlnmndbbcxrknfbcafhlarpekxkuebkwfugw
 * Smoking Wheels....  was here 2017 rjzbkgheexqwwilicfsjxcryyqgcwfnhuriojijltjjtzkqt
 * Smoking Wheels....  was here 2017 hjguaczbblbkuowamfzeabasbswanlhhxanvmnhufyebaluk
 * Smoking Wheels....  was here 2017 zwhxyaywkrnhbvfcmfxugdgwvbzuzyghmbkoxebfsqeyqesv
 * Smoking Wheels....  was here 2017 pwcvakruehdlqfdiglqvvzevkrzqnyigvkmpzdqktsayiami
 * Smoking Wheels....  was here 2017 euwckxyfnggevxnuaoscclwfhskarxrmoumakmjfaonswvpk
 * Smoking Wheels....  was here 2017 bcdoniwtyrmwckprkhvsrrnyepeqeprmkijdzqtvlwvggmqw
 * Smoking Wheels....  was here 2017 vqohzvsjcbqggmtogtzalzufzaimbbbbohjoxepqhohutipr
 * Smoking Wheels....  was here 2017 ilerquaezbxihcrfpgkopbkjyyhsoltgggzeoazhxwmtwupe
 * Smoking Wheels....  was here 2017 pwfhruoptpogmogruhpfmtkbmnqwejwhcayaogesbdgwjrbx
 * Smoking Wheels....  was here 2017 yldymtjhwwfoihrfksfbsdcfhefqsmvtxqflvgrardtbgyro
 * Smoking Wheels....  was here 2017 zzqtquucbiuxpbiifpimfqayipdzeuijtlaalriqyuhqvvig
 * Smoking Wheels....  was here 2017 onubcfigfqihhxxwjfdzdwatvttcuphezzwpviegjfnaowge
 * Smoking Wheels....  was here 2017 rktlzsucptgxraitddclusbefusmciwmebmiqkmrpxgwftuy
 * Smoking Wheels....  was here 2017 reztqdfiqvbfgyujdeyzxgledduvwumvcsvmsfvdonpgvoqh
 * Smoking Wheels....  was here 2017 eqhaspxvzhsyujqeekrxiwuxqneccyuxxhdqgkzanayhrltg
 * Smoking Wheels....  was here 2017 zwqrdlktrwhcijpzhdnvefutwvdnbbtvviwrovzzxowmfygb
 * Smoking Wheels....  was here 2017 ddfhajmmvlcvbcpvwwyowcoighjnfpmvnqusiqdxjpgofvoi
 * Smoking Wheels....  was here 2017 aamqteeryftpodtylmsfasjqnhrxkikmuhxalfzyxuemsaiu
 * Smoking Wheels....  was here 2017 ejgwyavhsreepemwvztdnkttqodnpgfmrpkfbdhnsbalzwnl
 * Smoking Wheels....  was here 2017 kflingykbkkmdfnkdtjwmtmctzerapvynctdnhdggqjynuhp
 * Smoking Wheels....  was here 2017 uviopmilfkvtmnsprgyijrrijtjvgwkcypsxluvceybrbobu
 * Smoking Wheels....  was here 2017 sujkoqacpwblcogqajhnthoidjoqavimrdguuavelqfpqemu
 * Smoking Wheels....  was here 2017 ryhabuhfxexhtdpdzcjvnzrhbkwcjlivwcplqpawhqfxnxlp
 * Smoking Wheels....  was here 2017 nhbrziszdbngnfjwqujwvhwohxpknzhgvygskkkwderdgeen
 * Smoking Wheels....  was here 2017 jexalwcullgmpamuiavlbfdvhzlbzxkzdoxqsnhasrjxnubc
 * Smoking Wheels....  was here 2017 mejvwhlhhmrnnbdgqnlqwtuaucftnaanozopljfoyvmhjtub
 * Smoking Wheels....  was here 2017 lbcgvsbkjqrbbcstjleudijfrxamehxsgnmdtoyvznjkcggm
 * Smoking Wheels....  was here 2017 dxdohmmgrpibfcxbobinyprxfjfkfyxnmsceaynmjyouevqp
 * Smoking Wheels....  was here 2017 oarkigngigbtfiqfpxhrtksqurjacmfgvkeswqhltpzcifjy
 * Smoking Wheels....  was here 2017 cyfpjwfbvvjoqhbmauwhevvkefkbqrgleprdebuwccsirlci
 * Smoking Wheels....  was here 2017 hnmgamvowtfgftpksvatbhnigsklvnrvnruadttdpkdrjrsu
 * Smoking Wheels....  was here 2017 ztlselyxjsqtyqxtqgyqpkpvgdslxgkmfdcgbrgxrsuqznlo
 * Smoking Wheels....  was here 2017 fajnzjjoopahcgypfreudadnqoxmliprwugvqwpcblpxhqre
 * Smoking Wheels....  was here 2017 ivsnudccxqyiecvdzwjhigkibnxgdosxgsgetuiwsgrlgabk
 * Smoking Wheels....  was here 2017 xaewiwllbhhpzwzxtypmbnxknrtuaxjzlgiwnzgouchmdzoh
 * Smoking Wheels....  was here 2017 uquvjyyuaedampctqdaymkmdexvgjqnxvxyriijxufdmnyhd
 * Smoking Wheels....  was here 2017 zztadzjmygwwyncqxcdnzveenmtdrfizxmwuvzztjyadcssl
 * Smoking Wheels....  was here 2017 xqoiyvveisboxddxfnsidvglftkdskfsncbmxhqgnablwgmz
 * Smoking Wheels....  was here 2017 bjytnqovuzqvceqahorrxvhcflvfmfuxuatjrxdwkjqoevnu
 * Smoking Wheels....  was here 2017 hhwsrudojsprorgthmheklbnsmkphwbnavlgoroemeialyzd
 * Smoking Wheels....  was here 2017 sqotovitfxjfnwxemwzraookfcstpwdythuhesddlvznnhho
 * Smoking Wheels....  was here 2017 obnspsecusoaofuomnpfjgepjqrkezlpvmwukkkwgcszixdv
 * Smoking Wheels....  was here 2017 nhmsjnzluoztimhkblzdjykgcvimaerihtwhjiftdwwrebky
 * Smoking Wheels....  was here 2017 iklcuqiaedujyrcnialccfaurqcglrsdophsmlpnmibboegg
 * Smoking Wheels....  was here 2017 btokaryddkhdqadxqumxaybxmencybthcxuckuvzayeuhbdg
 * Smoking Wheels....  was here 2017 cwjnknwncmdlwbnwnotqshwlgymvgzfiuqlvzukjsihxissr
 * Smoking Wheels....  was here 2017 znqnphmbuwdblmtxujhqdpzoyocjjnsaselliafasltpxixp
 * Smoking Wheels....  was here 2017 nvgsnifwdelykikuonimimdrsasxpvgkebguxkgqnnehqlvh
 * Smoking Wheels....  was here 2017 vbmtghykkkjhyumpdpiatullbmxylmyttbqzhzucvxltevzg
 * Smoking Wheels....  was here 2017 fuwleargysopplcockajzsdurkoerffphhnjjfknpjpxpkzh
 * Smoking Wheels....  was here 2017 gvbwzqsknnvneyrfgajvzouumkuogztsuaenisxkyubaemul
 * Smoking Wheels....  was here 2017 tgbjooqxcoicqjxjssqavzfyrmyincldrwcgmgghkkjnjnny
 * Smoking Wheels....  was here 2017 uidnzjdgusjmgxsztbhuxvkvsuqzxzmdlozsobverplcygpj
 * Smoking Wheels....  was here 2017 rpsfryjbdeofocfkzwbexgrjiurdfkgfzfvejmddqajuytsl
 * Smoking Wheels....  was here 2017 byonhjofukuxgqwdeeyoqppslcfwmklfhcwhbczqosmtqeuf
 * Smoking Wheels....  was here 2017 rkqtrcgwsadplojymidnimyhgtpixeactvovbvjgwtklmczz
 * Smoking Wheels....  was here 2017 qgemzrgmcbzmhcovfwdxhussfvlzafbeydryytqzgqaqiesh
 * Smoking Wheels....  was here 2017 gbrqqaqqjpxaktrdwprueqhxavpoqibyqddzrhixrbjfcmrv
 * Smoking Wheels....  was here 2017 drvffgqgheuymgcjjptnxkdbpkdaslqfycfmiaflixvmcgss
 * Smoking Wheels....  was here 2017 bcrqqswntjrfnqngseospsbmfnlonvszeqkhivjhqjbwvybe
 * Smoking Wheels....  was here 2017 dqkkaabuzeazvdvxgvpdqkdxgicspzmoynknhvahixvbbhdu
 * Smoking Wheels....  was here 2017 rxnkubgtluivxffnolpzqqrflhacrrjmavfnckupjeiaujog
 * Smoking Wheels....  was here 2017 grstnzuiupojnqbrmbomnudosbgttwzmnvawwekrydvahjgr
 * Smoking Wheels....  was here 2017 raztecepahsqrjccbyrikljihpdwdvipscjjbzycmyamculh
 * Smoking Wheels....  was here 2017 bgpavbgzhwfuqtfxqrlhrmlepbjxiamcgmyefarvrbrdxknp
 * Smoking Wheels....  was here 2017 rwzixtzfbkqiweohucplzbpzjxsobgyowatpioezndzxuedl
 * Smoking Wheels....  was here 2017 duwwahtcblvzflouigcfemjznvivjlitszaeligzfdgbzjfv
 * Smoking Wheels....  was here 2017 hzhxbbavfpyrqnxfikfdlkpmgsnymxoqcyfvzcwmdgbbalxa
 * Smoking Wheels....  was here 2017 dtlbeqpusvhqkrmpdekaetifauyizcvootbqpbkibwipqfrn
 * Smoking Wheels....  was here 2017 btudsxprahmiakmehikayouaollrounazlowdoiuwsdqvpee
 * Smoking Wheels....  was here 2017 prcgjafjvlkmglinryelsfpbtkcagyiujiyftfmdvsukxxhy
 * Smoking Wheels....  was here 2017 priuaibzczdbdvrjhiywoknuvphoivexcyrlwxxdjazjjpfd
 * Smoking Wheels....  was here 2017 dzsgtlxzavagxsktmafdwxouhfqshyfqsdmqcsxpdcmgyljg
 * Smoking Wheels....  was here 2017 nftozguyadsobrtzwwtjixbatryfybwnaxjehczteqmzslkd
 * Smoking Wheels....  was here 2017 iedtjvawwjaqklcofxlxuuopeqjbfcujeqnrqpyypoguvvgt
 * Smoking Wheels....  was here 2017 kxxeuqcvlfbnyacgqlphkcvyvbflkjydkvmxmcvvxamexbbk
 * Smoking Wheels....  was here 2017 urfljfwgypekxpsdlarkotxrcddubildjhyzmtyjtnyuqyhp
 * Smoking Wheels....  was here 2017 vcpjmmiuwsasutckemkiwxdtrhzxxtswvdxgnxvqdruqclpd
 * Smoking Wheels....  was here 2017 cztauovixzkfldqrtwtjfwzhoevrzqmewpohtfhbgljymuwa
 * Smoking Wheels....  was here 2017 kjrvetwbyblwuvardmyeuhisxubjmfpavilznmiimahejngo
 * Smoking Wheels....  was here 2017 voqhttgjgymvdbelsxnnybdqfhgjazgthbgjnxhiqvkzmjgg
 * Smoking Wheels....  was here 2017 tcahykaxhtdqzhggbxdohgtzdbhmgrwubwyupvreonvkuimw
 * Smoking Wheels....  was here 2017 qwrwiwlorzhybirqzpupthrxqwhqhicagbuwxvhincxqqqvm
 * Smoking Wheels....  was here 2017 kvmlwlcmkgatlccjogtfltsvxoobhdwkcfgluvekxsfdnuni
 * Smoking Wheels....  was here 2017 bjsoruucsorhjwmmcklhtnyjkksewqjghccoyyrhmurpdnzz
 * Smoking Wheels....  was here 2017 zawbcunbzbwzhdzffyrwjtqlvtqtsozbovgpgngeeaiaowud
 * Smoking Wheels....  was here 2017 soqbunpgydmpbrzesviictifdjlswxkqaryduesleioqaazx
 * Smoking Wheels....  was here 2017 ccavrkpvoopaqmebqlsfcfubndlhpxozzfsaavetxxzvboqn
 * Smoking Wheels....  was here 2017 fwgbvbgfafnnitlyjihkuydqkggykcokbgginovzceljlden
 * Smoking Wheels....  was here 2017 inumsiqauhypoaackgtavcoxodtkbewkavnkfthiswagduir
 * Smoking Wheels....  was here 2017 cvkhxibfngsweahaqidhaasxvmbpodetyguwgbieyvdqkuza
 * Smoking Wheels....  was here 2017 hvbthmbweswjetxndvpxojhdngmudhjnfdnmyhzdfiizvphw
 * Smoking Wheels....  was here 2017 avymaijlzruitmvqfisrvakgaoqljbpyifllaooegtmbcyrr
 * Smoking Wheels....  was here 2017 olphnudojhddnrepkrdrkbhbaxkfzfhoepozhipkzusugwvg
 * Smoking Wheels....  was here 2017 nktijaodbzroebjzovxhhwovmywcaudduobtydwgpkjknqqq
 * Smoking Wheels....  was here 2017 sviwmigizmposrdnuefbnbywqqkjrzbtnrmpixkipsajmrhb
 * Smoking Wheels....  was here 2017 fapoaiynirfjluigjgnvnnnwxdqjnheqytmodsopqfpkwted
 * Smoking Wheels....  was here 2017 jmbfhysjotdkwvdmxwpryjptzwiyhmzhvvcbeywerpdlqwao
 * Smoking Wheels....  was here 2017 sckyahwujefltoztfclaqzrqvnryaoboignprfblxszsdhrk
 * Smoking Wheels....  was here 2017 cwpaasxyspojcantjffjtznxqbarytklsphbylfcuvvsvmjy
 * Smoking Wheels....  was here 2017 pcycmvreuynldlsprumorfhhwryopocfopbnqrqaajldmglr
 * Smoking Wheels....  was here 2017 nkwauoefalselgrnsrwtbveqfshhssqjsjwjrjwiozzycnqk
 * Smoking Wheels....  was here 2017 locvoyryemaeshvciwmguetcpyfxigrtgeycebrmopuizowd
 * Smoking Wheels....  was here 2017 fqqxrkumdumnanwapslpzxuchhaosjcimqsqmrcdollupwge
 * Smoking Wheels....  was here 2017 wxsvgphgdgmioeskuthsbvjhqxisipckznybihmdexvasffb
 * Smoking Wheels....  was here 2017 tzultifxpcrdxtnmousqqdunlgaczrcnoxqrmiirjsbajomn
 * Smoking Wheels....  was here 2017 lqpvssvigtvpuzstrxtsoenapzersptlibabeklejumzvdxp
 * Smoking Wheels....  was here 2017 uxeicesrawdtfxybfkooaoldhberspzepondtiwfqgrionsp
 * Smoking Wheels....  was here 2017 uernaipkcjwtmsdknuszkdoozqponeyaxgxxwhwuvqnvijga
 * Smoking Wheels....  was here 2017 wxpgwapcznrbbzlaezwbicedkfhaxcbndeeskqbzxoclfsgq
 * Smoking Wheels....  was here 2017 nzrqhjzrhrllsjinzyafqsvcmjkbwiakiqnfmydebzujkvqm
 * Smoking Wheels....  was here 2017 plyzdtiibnfvmylpaakyoshuldfwrdssudlfmefdtbfckenw
 * Smoking Wheels....  was here 2017 epowpuiklaklqxriqtnclwqwrplxwaiudprubjoqshfhbmih
 * Smoking Wheels....  was here 2017 ozaezkdpxjosqtfaizbvxjdgxhvweshbezehdytxwgwziutn
 * Smoking Wheels....  was here 2017 jlbzaqzudzolhfmcatalvpjccwoupfgjzqfiunnijzoilisp
 * Smoking Wheels....  was here 2017 jasqnwkdbnomojdltirmjcbulfyvktctwcgrkyyospwvzpju
 * Smoking Wheels....  was here 2017 rzdrrugayzvdtjcauilwyuhzkopldwbkkfznrihmqoreqidq
 * Smoking Wheels....  was here 2017 pyvzvfmdemawjuocuobqdukpqikknhnylalclcehaocjmory
 * Smoking Wheels....  was here 2017 ssnrqgmjlmziehwgnboevmwtdelppzedbvwcwvhibnlotlyr
 * Smoking Wheels....  was here 2017 wifazitwtrvneyugcccafmmxccbiqfwynfrhhkthgpjhyobd
 * Smoking Wheels....  was here 2017 cbdrzzbahyxqqyecvifaqqiryfwzcnwsmyqukyvbhhrfwqmv
 * Smoking Wheels....  was here 2017 totkcemmmovfbvfchlqhtcrykathuonxscsycubvcfnilrvp
 * Smoking Wheels....  was here 2017 koukwzhfawlwfihthphdlfcwkduhrknjhzehlqgyxjgvbxbk
 * Smoking Wheels....  was here 2017 vdfxgubhxqvqcldwxbmfvpiwdnicchucoeltxhlbcwlfcvip
 * Smoking Wheels....  was here 2017 epipjfndhskrajqllkqhhelqbjzfmrmjblijbwxdlezdkebp
 * Smoking Wheels....  was here 2017 tnnfocukqjsnkrytolnmnatzxcqjqiasrxsmvufhwzyqzyxh
 * Smoking Wheels....  was here 2017 cspynpdaqyqvcbmizebdjmudpkinogcxkvxsirdxpfswblvq
 * Smoking Wheels....  was here 2017 bfmbdcccgfhpcoyzvzovygimhgmxnrpzqujwyisqabwiebyy
 * Smoking Wheels....  was here 2017 rilfmelcrbaapjfslklkrdlqntryacsfyovaiyglwzhtcqrs
 * Smoking Wheels....  was here 2017 iqyeasgpiqlofbmujflzehknxjujwhvccggojwikcpbavdst
 * Smoking Wheels....  was here 2017 oysbivuozlkyqhetknowjbtilvwdzfqlfdwbfsrzxwolpuyb
 * Smoking Wheels....  was here 2017 fhtfiypcndzdwcyjrpbqichkizimseahpteifijutajlycpy
 * Smoking Wheels....  was here 2017 iaggdpnqeqojfssrnaiengblactwnofxwzwmaxrshkjtqvax
 * Smoking Wheels....  was here 2017 hqszetnvjdtberqylpfonriieozzefpuuvzwnseznuqhrzys
 * Smoking Wheels....  was here 2017 pzxmalzpvckymsdsijpcfsrfubdvscvtlptcwmqxqboijtgl
 * Smoking Wheels....  was here 2017 ddtdqcjameqafuxtfqsktywmanopjmwvexoylacfblshdrci
 * Smoking Wheels....  was here 2017 xjmmbhnoohumodvcladioizuiewtrvvgomgnwlwtmhzxumxx
 * Smoking Wheels....  was here 2017 ihqkuylwlqlubicaohmyfyhclkyajwdpkltfadnsxjldjfjy
 * Smoking Wheels....  was here 2017 xqxzjelvxrmqmbcalmvpqdimhxvjmqnpvbhobttmmomfcakn
 * Smoking Wheels....  was here 2017 mmgnthcqxbaavjoydxjwyoxkbqyahjvhcxjkjdsrrbromnev
 * Smoking Wheels....  was here 2017 dfyrazeposjdjkisyenpocbmftvkgogzuurwojqgeixyijbm
 * Smoking Wheels....  was here 2017 fhkfpcsmjwempuqsmadxbvbpmrkgfzffuughowbjyafipotf
 * Smoking Wheels....  was here 2017 golhctzcaxhsiewkoocckdmytctncojrcehfngvjfcbwpkfb
 * Smoking Wheels....  was here 2017 cczelioqmnvwnprpfcqtrrcxgzfleqrmcogntkxyjsycujog
 * Smoking Wheels....  was here 2017 ufhntkgnyrdclhziveitggyelnkmapgwirxhykradhvrzefk
 * Smoking Wheels....  was here 2017 slvejxbjvouxptzvypuevbjpzceijhokpqgwzrprlospdwwf
 * Smoking Wheels....  was here 2017 jpidzyhcxorzuscqjlbiglvixkqzfqfubtlvzunkokacoqku
 * Smoking Wheels....  was here 2017 qttvmwnvajwhzfzofzkvqzfvhkervyedyoaziqmuwbiotaai
 * Smoking Wheels....  was here 2017 peivzimamyubmlnpuvfnkqmrshiusrpqwxsnsittbxnumsdk
 * Smoking Wheels....  was here 2017 nmpzwehhqmzuuzybrthmflyvulzcrowxrumrygxldrrtsukt
 * Smoking Wheels....  was here 2017 blfitneogjhdqmplrvobxufkmogoqqsrknocfarhhhdoulsm
 * Smoking Wheels....  was here 2017 ycfgptsygixbazfnxiivqizvzqmkycazktlpxnexxwoudeiu
 * Smoking Wheels....  was here 2017 ivvimmrxwgcvhtsiqwzruxjsutibcmzbfevhpwqfuytcpsof
 * Smoking Wheels....  was here 2017 mdmkupcanjmwwfeelfiqarpaolohvoznsxsmgkqjudvlccdo
 * Smoking Wheels....  was here 2017 zvzoefigwczyofdoflhbeyhwgiizdgsbxgjvzuztdkeczoyw
 * Smoking Wheels....  was here 2017 safeorwtycqyjregyweokkerbjzliwbteufcdwrbiyjmspej
 * Smoking Wheels....  was here 2017 rymtzqnwxiudowghabjydxibltdbxwfwchzkktbezdghbygq
 * Smoking Wheels....  was here 2017 gegfyzhhezcyqgnyatriynbzcwrppapylusbrwqfcsznbpvk
 * Smoking Wheels....  was here 2017 zogqaunynmkdjqktscbbtrwnzlqalhwsirpsatfpwpwkyuus
 * Smoking Wheels....  was here 2017 sdlicltyvnvqtzpnejsrszodhkknryygclcewjvatznjfbjw
 * Smoking Wheels....  was here 2017 mfcxhotsizrscoyfucdcehemlypowmavgyzowtuilgudrcyj
 * Smoking Wheels....  was here 2017 qjqebapxlcotvvrdcdciutakdlavsrmyrffdxjpswevrhzfz
 * Smoking Wheels....  was here 2017 tjwgzynjxhknuofuynnulsqckrwjhlzkloapbtcogpyfjwbt
 * Smoking Wheels....  was here 2017 rirmysdiqgfyyseaioraguvzjmljudmfvnwruuinattfkhqz
 * Smoking Wheels....  was here 2017 kmjlcyeewxlhppnuruawqwqrmcjftddrmynnsqnnxbckdale
 * Smoking Wheels....  was here 2017 jlkzwmtnalqafqlkmbikgchblyltzhjhdwymsrhrvedspzbc
 * Smoking Wheels....  was here 2017 bznevmbhugquorhkqknayuljgsvvknvvypjdxmkkacejanlu
 * Smoking Wheels....  was here 2017 ifrkxitqdcppsptodevhvpuxbixsjdkjesghrxxiwzvvzbtn
 * Smoking Wheels....  was here 2017 hkcefpnzhwwsvstwjwuajkkkizfxipjdlajbsdckdgyufjku
 * Smoking Wheels....  was here 2017 fdhldemyqtamnnmqxicidhqstdqacqasonruvnmutorhrkcl
 * Smoking Wheels....  was here 2017 rfzeiexlxeysmsijnptnaryahkhdpgcuppjcgrxvxximsmsm
 * Smoking Wheels....  was here 2017 nqdurziqcusjtjzwjzygedesdtnkftmmwuathmjfalmwtbke
 */
package net.yacy.kelondro.blob;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
public class Stack {
private final Heap stack;
private long lastHandle;
/**
* create a new stack object.
* a stack object is backed by a blob file that contains the stack entries.
* all stack entries can be accessed with a long handle; the handle is
* represented as b256-encoded byte[] as key in the blob.
* The handle is created using the current time. That means that the top
* element on the stack has the maximum time as key handle and the element
* at the bottom of the stack has the minimum time as key handle
* @param stackFile
* @throws IOException
*/
public Stack(final File stackFile) throws IOException {
this.stack = new Heap(stackFile, 8, NaturalOrder.naturalOrder, 0);
this.lastHandle = 0;
}
/**
* clear the stack content
* @throws IOException
*/
public void clear() throws IOException {
this.stack.clear();
}
/**
* create a new time handle. In case that the method is called
* within a single millisecond twice, a new handle is created using
* an increment of the previous handle to avoid handle collisions.
* This method must be called in an synchronized environment
* @return a unique handle for this stack
*/
private long nextHandle() {
        long h = System.currentTimeMillis();
        if (h <= this.lastHandle) h = this.lastHandle + 1;
this.lastHandle = h;
return h;
}
/**
* Iterate all handles from the stack as Long numbers
* @return an iterator of all handles of the stack
* @throws IOException
*/
public synchronized Iterator<Long> handles() throws IOException {
return NaturalOrder.LongIterator(this.stack.keys(true, false));
}
/**
* get the size of a stack
* @return the number of entries on the stack
*/
public synchronized int size() {
return this.stack.size();
}
/**
* push a new element on the top of the stack
* @param b the new stack element
* @return the handle used to store the new element
* @throws IOException
* @throws SpaceExceededException
*/
public synchronized long push(final byte[] b) throws IOException, SpaceExceededException {
        long handle = nextHandle();
this.stack.insert(NaturalOrder.encodeLong(handle, 8), b);
return handle;
}
/**
* push a new element on the top of the stack using a entry object
* this is only useful for internal processes where a special handle
* is created
* @param b the new stack element
* @return the handle used to store the new element
* @throws IOException
* @throws SpaceExceededException
*/
protected synchronized void push(final Entry e) throws IOException, SpaceExceededException {
this.stack.insert(NaturalOrder.encodeLong(e.h, 8), e.b);
}
/**
* get an element from the stack using the handle
* @param handle
* @return the object that belongs to the handle
*         or null if no such element exists
* @throws IOException
* @throws SpaceExceededException
*/
public synchronized byte[] get(final long handle) throws IOException, SpaceExceededException {
byte[] k = NaturalOrder.encodeLong(handle, 8);
byte[] b = this.stack.get(k);
        if (b == null) return null;
return b;
}
/**
* remove an element from the stack using the entry handle
* @param handle
* @return the removed element
* @throws IOException
* @throws SpaceExceededException
*/
public synchronized byte[] remove(final long handle) throws IOException, SpaceExceededException {
byte[] k = NaturalOrder.encodeLong(handle, 8);
byte[] b = this.stack.get(k);
        if (b == null) return null;
this.stack.delete(k);
return b;
}
/**
* remove the top element from the stack
* @return the top element or null if the stack is empty
* @throws IOException
*/
public synchronized Entry pop() throws IOException {
return po(this.stack.lastKey(), true);
}
/**
* return the top element of the stack.
* The element is not removed from the stack.
* Successive calls to this method will always return the same element
* @return the element on the top of the stack or null, if stack is empty
* @throws IOException
*/
public synchronized Entry top() throws IOException {
return po(this.stack.lastKey(), false);
}
/**
* remove the bottom element from the stack
* @return the bottom element or null if the stack is empty
* @throws IOException
*/
public synchronized Entry pot() throws IOException {
return po(this.stack.firstKey(), true);
}
/**
* return the bottom element of the stack.
* The element is not removed from the stack.
* Successive calls to this method will always return the same element
* @return the element on the bottom of the stack or null, if stack is empty
* @throws IOException
*/
public synchronized Entry bot() throws IOException {
return po(this.stack.firstKey(), false);
}
private Entry po(final byte[] k, final boolean remove) throws IOException {
        if (k == null) return null;
assert k.length == 8;
byte[] b;
try {
b = this.stack.get(k);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
b = null;
}
assert b != null;
        if (b == null) return null;
        if (remove) this.stack.delete(k);
return new Entry(k, b);
}
public class Entry {
private long h;
byte[] b;
/**
* create a new entry object using a long handle
* @param h
* @param b
*/
public Entry(final long h, final byte[] b) {
this.h = h;
this.b = b;
}
/**
* create a new entry object using the byte[] encoded handle
* @param k
* @param b
*/
public Entry(final byte[] k, final byte[] b) {
this.h = NaturalOrder.decodeLong(k);
this.b = b;
}
/**
* get the handle
* @return the handle
*/
public long handle() {
return this.h;
}
/**
* get the blob entry
* @return the blob
*/
public byte[] blob() {
return this.b;
}
}
/**
* close the stack file and write a handle index
*/
public synchronized void close() {
this.stack.close(true);
}
@Override
public void finalize() {
this.close();
}
}
