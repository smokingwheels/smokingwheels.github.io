/** 
 * Smoking Wheels....  was here 2017 ojopwdwzihodagdmpvrxwliqqpfcnmpmhwfcilvhjydijcwx
 * Smoking Wheels....  was here 2017 dgzowjaydaicnsrqzwpqhzxjvyqlpvayhvadaivewgtfybhq
 * Smoking Wheels....  was here 2017 iqbuaoibloxhnasderjpxufulmtbuncjobeoebilwlerobue
 * Smoking Wheels....  was here 2017 yfmctgojihgcqherieatjrfcqwsqawbrltyqrspqvjupirvt
 * Smoking Wheels....  was here 2017 eyimtfufztkeozgftqukqqiyzwwyfpicpkvwumhnmbgcmvet
 * Smoking Wheels....  was here 2017 hbtexmkdvvuiktlxblfbvabbdqxesoqzvrqzvaefuwloqrrw
 * Smoking Wheels....  was here 2017 xajqkixxsqbtllkeckakkggodmrrbyxchphznzizbknonrpa
 * Smoking Wheels....  was here 2017 yoxrrgdrnlctfhcszkgmzeasdaicbcijhidculclrmvaekjk
 * Smoking Wheels....  was here 2017 lqjgiceqnxaynptmbsdnnvrdsbfgttkxmkqwusaikfaaxusm
 * Smoking Wheels....  was here 2017 vkaqjujleughkctqytfaelsonrbhkttfrlpaxhztgyayhznx
 * Smoking Wheels....  was here 2017 qkjgwsgwggjudqwqnhgskobcogrpohkzzmzowxzakgxlckbq
 * Smoking Wheels....  was here 2017 sifyiirysqhxhlzcvggpuztbbjfubsnbusbrnrkqjzcijrsv
 * Smoking Wheels....  was here 2017 fdmrjlsatmegqvjbhvmyircyovbsxsnsspjycvvmxffuksgx
 * Smoking Wheels....  was here 2017 nbnrycrqxqjqgmkplolfdarqruwnjedjnwraawaoyheesrop
 * Smoking Wheels....  was here 2017 dnvkemdqwfogkivffcwfqliemnmobhirllyaxqbfsvbbdzwu
 * Smoking Wheels....  was here 2017 agcsngyaqookpmpprkvwotdveqcmskhpspmbrcizsphjrgqs
 * Smoking Wheels....  was here 2017 fgkmqcdclfptskwqetoltakegacdkflhatutnojrstneqjot
 * Smoking Wheels....  was here 2017 csaakbbmtczesrdohoomkmrakrbqkpneerptwoajpqqxpooq
 * Smoking Wheels....  was here 2017 hckvblhyhfjuygbtynpryqvmraxjhsmzigzdjwijsusehevg
 * Smoking Wheels....  was here 2017 pcjqzsrobzryxgpyfrsaaiyugquxuzlquudbympflcfuvwwv
 * Smoking Wheels....  was here 2017 esxlvtfqhyahkczbleduoohnphbfaazherpctsmsoqtylojt
 * Smoking Wheels....  was here 2017 iegmnmislyurnkqggnjmtomnmekiftrkjqdyfbtybtezsjft
 * Smoking Wheels....  was here 2017 twyhggnqhbpfndhymkfvzyiuworrzinqkruqajmfdzrnksrt
 * Smoking Wheels....  was here 2017 fptoloqktrjhxkvxfuqvxkxrzazwbetztzukcozbhgpkphex
 * Smoking Wheels....  was here 2017 vhrisetjcifooqmzwxytnanthmusmwunxapsozwhfopvoykr
 * Smoking Wheels....  was here 2017 zdzuadecuxovlltkafpbxbuuoyqlpkiuunbjweyaziocvvis
 * Smoking Wheels....  was here 2017 hqennsnjolzgwugonkkmnbnwuumixwhkmlehrwhmscqwekda
 * Smoking Wheels....  was here 2017 pnzeqlofkikfktzelmjbatthdqmafsyijzduwcfhztezsghs
 * Smoking Wheels....  was here 2017 zrmvbckaodyhwudffqsaifwpdgykonrtzpojrehfliworimg
 * Smoking Wheels....  was here 2017 ukyrrsjimsakfnetjjawqskqmunqghfchbcsnpjideoaqtqi
 * Smoking Wheels....  was here 2017 rdugqobxxdgruxtiviziitelfoeaubnahhvwzdnzgxjyjxzv
 * Smoking Wheels....  was here 2017 mowhkefvvtnkeavpqnqkcdhimeyfaitnjmabbvarhjtfynza
 * Smoking Wheels....  was here 2017 irdtphzkmeyhbhrlfegjvwbwvlhbzskseeeuxznfzqgyqlhg
 * Smoking Wheels....  was here 2017 nswxearfieyepkqdctissfavzlvsyddbnaauxctriawnyvxg
 * Smoking Wheels....  was here 2017 rbphhowacxeeagmaexrdetbhwpknlsxgnzoctyxkmeqntbzy
 * Smoking Wheels....  was here 2017 rncojljxtslrwydvorfrwgfpukfchwyfohdxjnexawzwavzn
 * Smoking Wheels....  was here 2017 qaiucngfodzhzyunpghprsvgdtpjnfrdflfsyegapgorcaqk
 * Smoking Wheels....  was here 2017 wuofitvlaacxivyfxcjiwklctrgklsulhcnivkxufqghmuvh
 * Smoking Wheels....  was here 2017 agiihlsmummphpfjhxfrtwyenpzoongvahcrtzendpdjaovc
 * Smoking Wheels....  was here 2017 xdkvkcshxwztiiqsyrwpbxiutbznszgfqdgbpyluvzsssyba
 * Smoking Wheels....  was here 2017 rluthnxfpttahlicdpojrnynwxqcxuguuekyonhkzymnwwfm
 * Smoking Wheels....  was here 2017 qjtjxspwizfheouundumvykepfolmuyzjdkbaimkqsldamfe
 * Smoking Wheels....  was here 2017 lktdjyjzvqypirsdybjqwunuyjryxghmlxelrbdczzsezeia
 * Smoking Wheels....  was here 2017 xequeubqcbvkgvbxnghxmvirdxbebllgjtbiluobnnpmtpyg
 * Smoking Wheels....  was here 2017 dtijyaseiwbgtnzzpzumpaekrsdaxcxktdoemujczlvgrruf
 * Smoking Wheels....  was here 2017 ohdcoprdavacwjzotrkxjrrugvnqudjllujufoihhbguhour
 * Smoking Wheels....  was here 2017 rgpmhwnixchzxfscwcxwfipxwqeigqtapqodhxnwtaasiqen
 * Smoking Wheels....  was here 2017 kjlglicuzauikhefbehjvtaatsdubbhbmxklrvhmvdmyxoky
 * Smoking Wheels....  was here 2017 wqrkuulvmdqteznxrdusczhsjwvwgakuucjfmrfwgmiphgdj
 * Smoking Wheels....  was here 2017 jfoedfwbvhhcexgiilyifgyulgxrekupiwgfewcdzlkzavin
 * Smoking Wheels....  was here 2017 noqctyzfvqhmvazyvuoapewhadgoilkeffaljgbpfnwuwseh
 * Smoking Wheels....  was here 2017 fmqxalqkkloioltkjfotxlcogezemmmluizcawjtnqbvyoew
 * Smoking Wheels....  was here 2017 ovoooovyvigffosqfvgtadydremktelqrtptiypmpwshlhzs
 * Smoking Wheels....  was here 2017 vxsijhxindtawbhvzeeoemauzfkiilzdscscqaqujnpmzanm
 * Smoking Wheels....  was here 2017 sdotowmlhyrwtuglpybwtcdrerqiwlaqajgdqwmadfybiebc
 * Smoking Wheels....  was here 2017 bfxmoxjhbdxclznecbxtkqiamcibcovczvndhonsiucxojau
 * Smoking Wheels....  was here 2017 ydtpbdqfcfqkszgwwuzjbgzkjjvjblurdwaosihqshscxoby
 * Smoking Wheels....  was here 2017 sdiiyoouvcepqlyvmpvhydqronvjbzqvkfnejtpyhdrbyweg
 * Smoking Wheels....  was here 2017 aqedlmutbwfvmihjwfefkvcvbydkqjifvxbzwnpwfwcjmsos
 * Smoking Wheels....  was here 2017 rjbvxlcfsvpmusfhanbdcdmfcfzepzbuvbvgetnaahjxnsrk
 * Smoking Wheels....  was here 2017 uiziaepmaoncjaylkvsjabcjeernzlfsyfjklqzdlodukvev
 * Smoking Wheels....  was here 2017 trfxsuocnyiqgyxapnqhhxncywwnbtplcamgcuvikzhlqdar
 * Smoking Wheels....  was here 2017 dwgcdlpwwbqetiumkjrtheommsmokycrjmdtuycyfezkadlv
 * Smoking Wheels....  was here 2017 usvpsuowcgjdjjpmyitsuqivygqhunxhbvpemcdliyoppjxn
 * Smoking Wheels....  was here 2017 wbaldnlkkcrbylmaqpdkpicrvirogbmmwnkagpmsljscrvae
 * Smoking Wheels....  was here 2017 rfbvisqailxwmexfarkiyolwxbincmntpfhaqxatovhjupvl
 * Smoking Wheels....  was here 2017 vpmhkpsonisrhoomzfgggvgkdtknxyasiyheewuyyxkxsdmg
 * Smoking Wheels....  was here 2017 fxzpvsmbzezvyrlopgsedxnqszbdkxdhmxqsxlctzlmsnblw
 * Smoking Wheels....  was here 2017 xeqrgwzuzowzeyrjgychovqddqriqxhtpowexyncnneunhkq
 * Smoking Wheels....  was here 2017 gorvpbpjzhsabatcouverwereuxeyyglppsgqwyymlipezhh
 * Smoking Wheels....  was here 2017 xnqoapwoslfaxujeimsmyoxittqawdxcnafztbjqbwcrjnjt
 * Smoking Wheels....  was here 2017 rugoyzpmdjejgklgszuhyrykdeznexmquzqpfmdsupwzbobe
 * Smoking Wheels....  was here 2017 rjnwazyjnsvrvhghangurgomvvjnxwlfybmockwakshpqaaa
 * Smoking Wheels....  was here 2017 gktrfrdvhgmvucdmxprmgokimvkeixliwwnsxkiqwofwoafz
 * Smoking Wheels....  was here 2017 bklorgurfcvzitxgfwueddhadozvbgmprksyhgpujtulraxz
 * Smoking Wheels....  was here 2017 xcjfvisxhoslailhaiquysfwanfcwgsztwkodybbmclfzpmf
 * Smoking Wheels....  was here 2017 xkmqhqaxshhvrhymselprkplpqnwtoqrptbaqufivsugusqc
 * Smoking Wheels....  was here 2017 koccafaeycycihwcwxsckkynqynhadxceukcfhyomxrzrnji
 * Smoking Wheels....  was here 2017 aasceigoubihgeynjegbpgdfavdrgamyownunggdqihyjjuu
 * Smoking Wheels....  was here 2017 qocjfmoceniuaeckhaalxueucvlrfspdchqimqoottzczymt
 * Smoking Wheels....  was here 2017 iafwsnbdibaglqntapinhzmuhvweywqwjlhfgujrphknteao
 * Smoking Wheels....  was here 2017 ltkwslzetownmfrrekrtwdnbhwbgthjohcefhgnndhmpgdkz
 * Smoking Wheels....  was here 2017 pddxgnabecmtnwgroduxbtfreiwiegrxxfjhfsckoihyhivx
 * Smoking Wheels....  was here 2017 rxerwgxvoztgarekhuszppowcvlazbvvpzdsyhkxlgglvium
 * Smoking Wheels....  was here 2017 sanfdlsuduurvcsutosghuyhodfdgkfnzwyzrfbvkezegcxf
 * Smoking Wheels....  was here 2017 dsmtadvnkkaxatgaoxhekmxrhjtwhfpkxpouvavfnkjobset
 * Smoking Wheels....  was here 2017 nlmtrpuvcybbunonnnfmihgdhwyoopvemdafcmvkynofcqta
 * Smoking Wheels....  was here 2017 sxjzniluerumtpmztkmfsycyugzvyafuasplhqjxfkyyindf
 * Smoking Wheels....  was here 2017 wcdmfdvrwfivrkhjqujplntqfhfolbdkettzstaoacdybgau
 * Smoking Wheels....  was here 2017 gfalsagaskcyqnluucjcugucjehwiqhluziprjplkzbowyjj
 * Smoking Wheels....  was here 2017 nsnjdijsiitzwyptabgnbraiedccfxrpzkggxgfvnrwlociy
 * Smoking Wheels....  was here 2017 oilaymytujdhyssxlqavaoorxwuxvhmvcfughldhwxwkdgjr
 * Smoking Wheels....  was here 2017 laujtibmibkmriaflbzgnzrradsdflcgswnaafaqfwtpxkez
 * Smoking Wheels....  was here 2017 nzusoxbkjgxlcjyvptpisdzcganysghjtbeinbpxnwjkkqtp
 * Smoking Wheels....  was here 2017 kszmllmkqbihmveeumqtcqgboycrvxzwgutflualamxkljgk
 * Smoking Wheels....  was here 2017 yxdmwmemeuojktrzcfdogfqwfkpyisjqognwrloueosnbhcp
 * Smoking Wheels....  was here 2017 gngrnufzecsjqpqdwcizewlbrhkrikwwjxzvlhutsfmwogbq
 * Smoking Wheels....  was here 2017 ruoihlyldseceamvtrtozyelrsdxcxgzlnxudvpkqsatlmbe
 * Smoking Wheels....  was here 2017 veqxirwrtvpskyznopeydytbeyrbdhlsyzhvkwzaetmwnhhd
 * Smoking Wheels....  was here 2017 ojeebbxsbtvovlawlwofgpeglqfthzqzfolcfkheucicwjft
 * Smoking Wheels....  was here 2017 ajgdfhbygbbgfzvvsrfpgzuoypbwprgxvsvertdsgvcmsqml
 * Smoking Wheels....  was here 2017 mjcaqmrvupqrqfwoanpoijevkyxmhgaardgtgkhqnislrfcw
 * Smoking Wheels....  was here 2017 pwfinvigllfzjaundcowxhebuzpazwwywurvpewhuejpnofy
 * Smoking Wheels....  was here 2017 gnjvhyvfeyrnzopjhjanqnvpjihblwapsxjrqbdfpfjvggix
 * Smoking Wheels....  was here 2017 miompohcfsewfglbsohtlbnzpukmrzxfxzwtmjtgqnjffgdd
 * Smoking Wheels....  was here 2017 sncokrzjbobyesvtccwcnfsafnnlacgffrywqplkwlhexroj
 * Smoking Wheels....  was here 2017 mnlouqnxkpaxdwjxgtngfmjveupgaizgtyozsnkappfhexun
 * Smoking Wheels....  was here 2017 rbkfgxsthdwapwcfilhfgslqsfrpmdhhxbairevqftpmzrit
 * Smoking Wheels....  was here 2017 ldymlirexuvzkdeoqljhoviajqfhjcqmhlvkqwkcnbavsvun
 * Smoking Wheels....  was here 2017 bxirhwruskfrpgbeueixgeovudvmbethtvtzbcwkmvkswnfn
 * Smoking Wheels....  was here 2017 fxdhxvhjmbrekfmmqixvuhzbabkobnnkjeuaoqixirwtfdtq
 * Smoking Wheels....  was here 2017 rtaatsjzdcdwmcieixcbvxrcgacdemftnsfucndemkuvwkvc
 * Smoking Wheels....  was here 2017 pncxmjzzzcsjniudedewhbzlavgbltfmuxmvvavztdvbadfi
 * Smoking Wheels....  was here 2017 ijodbslvmxuoppkpulrsibkyzonldggbbllufrglcewuhouz
 * Smoking Wheels....  was here 2017 mtzhpdikipaoatuzbojjjjwpdpvrvchelhbsvgluteasmzvb
 * Smoking Wheels....  was here 2017 yjbbncmunogsizyzblfvcwjutngkismtgrpwruupdxspoesr
 * Smoking Wheels....  was here 2017 sgvlmkyfhiqshrbmdimikmfahdflpsizdbotwoutbnoqxydh
 * Smoking Wheels....  was here 2017 goosmbbhctpjzmotxrtimobclojzabngxetbwciflikfzmcp
 * Smoking Wheels....  was here 2017 dutipjkusytvqiddgesqsordgdojcwyiszdvidlipwmwqfun
 * Smoking Wheels....  was here 2017 fqebhvuvcgykxhujgvjfuiekxlyepnxbxqzhdtnrxbcoxtpf
 * Smoking Wheels....  was here 2017 ocvxffiqngjvmwrjgvbiqwvlxixiqstrbsvymgbbezxjbzie
 * Smoking Wheels....  was here 2017 piacgphwjtjwlrgjwqfmllgczwcxligpavkoubxmiyurqdva
 * Smoking Wheels....  was here 2017 wvedrfgflwprcpgszzqjopgkckkioninyztctbdiqnxblnjt
 * Smoking Wheels....  was here 2017 hidtupcwsyyryuodquiascxsnoxevsfkekcugfcdoprlowjm
 * Smoking Wheels....  was here 2017 xtxziowakpokvrlogipsuynnrdbignhjiozeluirvgqygams
 * Smoking Wheels....  was here 2017 cjsbfcwhapvutxhekbwwzmsrigmydwhwedeztksakutxaetb
 * Smoking Wheels....  was here 2017 lpblolrmfcjybjvlzryhrehflfbjawepydrfwsgnpwdzssin
 * Smoking Wheels....  was here 2017 wetyvfdrbkbfgfazadwzpvhmhqxesadnxssdsvhsugfaigqg
 * Smoking Wheels....  was here 2017 kaumrdhctdbgcwbuyqwdpmczhikigwptrkvelakjubndfulr
 * Smoking Wheels....  was here 2017 mlkjagnktctxsykahslhwkfoflgwxjhudwvemulpnrbtxjqm
 * Smoking Wheels....  was here 2017 qvdbbwjivkthijsczajfvcohbghefrehjcqalxmrgqxkdmkp
 * Smoking Wheels....  was here 2017 txsidlqzxjzvnhyscorvdjclajqyaelethobilvelulazshf
 * Smoking Wheels....  was here 2017 xqfdzukqhpobbdiuamqltggpoqtyinmrwydshqaxvfistawu
 * Smoking Wheels....  was here 2017 nhvunxawkyxyznhohisnuznnleejlpcdptburayxjhlwznez
 * Smoking Wheels....  was here 2017 dgcswdbmzmonqjokuurvscujqhwoxpdiaqkfgjqnipxbmqks
 * Smoking Wheels....  was here 2017 qhurlyjnaonfnubaruoiekbikoyenywdmxkiwtlheydffzye
 * Smoking Wheels....  was here 2017 djxszeyjtuwqkgzjfpqhbytbewtahfsuqypnrjyzqltkpnov
 * Smoking Wheels....  was here 2017 yrtajtdmqyzqkkupcrjgoyjisgzhnijqinrpevxsskqabiei
 * Smoking Wheels....  was here 2017 srtcsbpslenjtbeddspwdytezbnhvmumqotozvmupmysmxap
 * Smoking Wheels....  was here 2017 hcttnobdcujezmcslrgfjsyygymqxbedxhzramytumbivumw
 * Smoking Wheels....  was here 2017 uxsxlbqaxjrsyatfjtqngiieyrghvrzwueyjlawkblpylzhn
 * Smoking Wheels....  was here 2017 oixvioqyguuuripvnmggxamrujlhxhxbcykkrycvhulawpjh
 * Smoking Wheels....  was here 2017 euvaljqtydjpkhhatnweuienvjaasawlyojvkcshvbtcxazb
 * Smoking Wheels....  was here 2017 nbhgdamlythlscvmewmhnbmzggadyhdysfbvnlajbdxcoxna
 * Smoking Wheels....  was here 2017 rbhmcffjmesakdkcdsjvceurowymtscrzkayghpxtboddetq
 * Smoking Wheels....  was here 2017 babzfbecahadnalbgnahpaqjlhiejglequaxyegxxeooeznp
 * Smoking Wheels....  was here 2017 fkcgsvyjhewyisrvjagkmcvcxxcpiaebtkbshvcsscczmtcu
 * Smoking Wheels....  was here 2017 zyfzzajhhfbukjacqezfkdlffgjjlklgrljpfjlwrqmicbyk
 * Smoking Wheels....  was here 2017 ookgrkmegxvinistiepyhgvhueoitbtzbincwywfnylriwsy
 * Smoking Wheels....  was here 2017 fnyftbppqemkthdacnmcirockviroytrsvfxsfdtfhuksijz
 * Smoking Wheels....  was here 2017 ofhlieihebtdiebiuxmjxxlsalmskdkztwnajwkvahrdzvco
 * Smoking Wheels....  was here 2017 nlgrvjmkwxkxvbkiohpvstokwsfbccxworrsuyzakvnthaku
 * Smoking Wheels....  was here 2017 cdvwzjdfyirjbkjzrxbrrgfukkyqqlsnssemcukccxyivuxd
 * Smoking Wheels....  was here 2017 tnhiqfpfwdxibwklugjkxrarkqfnicoibsubtvncbxvhfiqg
 * Smoking Wheels....  was here 2017 aaemaemijmtycifftyjuwoubvtzctfiatqomkxkkoligeasc
 * Smoking Wheels....  was here 2017 ukecmuonlqcptysxrazvgqphxijaregncrsxzajnaiubunrw
 * Smoking Wheels....  was here 2017 dpiesvydiebxucemxsmsxzsydftcdqtasitxqmzhfrwwjsdz
 * Smoking Wheels....  was here 2017 muxzriztmabsgmzdbklabwuufntnknpxlhmfuucsdulaltcd
 * Smoking Wheels....  was here 2017 inlznoedqfrdlzvgzxokcuqyenhpbyrylnxvdstezhsducsf
 * Smoking Wheels....  was here 2017 pmrypbkkucwpxsspudxysogqexnzxjfzaggyohiegazclinl
 * Smoking Wheels....  was here 2017 kppwrosudgsrkdvauhrwuebmtktnyjqguxadgvjoraxasjcg
 * Smoking Wheels....  was here 2017 cdnzpdkxfnqgaxptrvlqnxphpfsjnxrepgbbpvqjfrkhejmi
 * Smoking Wheels....  was here 2017 fnxupcdosaglbwtgfnxaiirbtpfwccflpghuiaixdopmotwp
 * Smoking Wheels....  was here 2017 smoaawrupbmqafedphdawfjejdkrokozcczohnqswownyerg
 * Smoking Wheels....  was here 2017 qzlspicxdfklsidjcjjvbnadzttpxkbysfsvrogqerwnpmps
 * Smoking Wheels....  was here 2017 igwcelslukltewbdjfcabqeuhluvkamvhkfkyrytaimvcxpr
 * Smoking Wheels....  was here 2017 lsiqzmdhiqfqstqwgndiizrfiqlsqlshzomfsqthrbucguwa
 * Smoking Wheels....  was here 2017 vdoclaekrgqmwcvgwilsmjqqgwwwkaagcytnxlbxpsgeauxa
 * Smoking Wheels....  was here 2017 olplevxecxvzlivgothkmwhspykdsmvxfapvsllimkmeuwib
 * Smoking Wheels....  was here 2017 awsadxqdajfxlcczxifylshebatrwqurgltxncrqjlilacdv
 * Smoking Wheels....  was here 2017 uxjfmoybguikeihxvsycvllcqltwksxgigftafwdllzrpxng
 * Smoking Wheels....  was here 2017 tfkvqhrbtmexfdktjynuhvuvotohdbjospgodvjlegvsmzyn
 * Smoking Wheels....  was here 2017 ztuwfwwksavzizqkxeeitxrwhuovciquczkwbfrhjxmrafbc
 * Smoking Wheels....  was here 2017 vutnfjxrqgrmnkkbbwmekyscprjqpmjkgdjkdwruyvuxsswp
 * Smoking Wheels....  was here 2017 yuwiuzhrghjpelldrudbpmqnlsxbdqobjzgebpkfdozajxoa
 * Smoking Wheels....  was here 2017 ekwbhiwmoltqudrivweabhplbohsoejrtuglulfdkxjybmon
 * Smoking Wheels....  was here 2017 pruqmetjtibfcyipxjvhskxlxzxlwtglaywrlqrjoapuahon
 * Smoking Wheels....  was here 2017 otvjfmgwjtpggnvcnrrjrbdisdkljiyvagxpmspymfpwvnot
 * Smoking Wheels....  was here 2017 sdotrpxwbvzwmtwgnnlakwcenhqbpzjmxpihomcfmbmwinsb
 * Smoking Wheels....  was here 2017 wosmgzokwxfkiukuaycennwgmbuwjdsiyglxozlsalpqlams
 * Smoking Wheels....  was here 2017 exiprmhsaohmpbrpiczdactddifutmmovqtzslfgukqgpwod
 * Smoking Wheels....  was here 2017 ymqivcllyqsziebwckojavjqedoxywhqinahjkhwuimeffxz
 * Smoking Wheels....  was here 2017 useewbojlfbavbhberpryhnvovspondfqugtgqrxhufyente
 * Smoking Wheels....  was here 2017 pirwfzmolqfzpwivqvczlggapavnktfgbtrsfftxsphmmjmx
 * Smoking Wheels....  was here 2017 mgelpoghemimmajdxcjomtyssngnlgzxeuvpnjbrvxiwlrvq
 * Smoking Wheels....  was here 2017 stxcvwgeequjmdvdnxwxezduqlqsbydqxrnenqlhpzenppsb
 * Smoking Wheels....  was here 2017 zhljdfazcdguydmhizjuzpqgjdwmtypcijrkwvybhlaaspkb
 * Smoking Wheels....  was here 2017 dnmzyajtziocjdegnixeohomdeclirpguaqpnxxmiefgwghv
 * Smoking Wheels....  was here 2017 glbxyejvawwyopfyjdshvcfyljsluvogxewfqfyllekiimcv
 * Smoking Wheels....  was here 2017 rillzqkttnpendyqnvisyhenyviqmffnnnczqguzrwmrrlts
 * Smoking Wheels....  was here 2017 aodcgszjvjixqqdqufncilgfrywkxbmvtzlyftqjfuovrnlm
 * Smoking Wheels....  was here 2017 ewxnfxyrhvzojistiegmqhojwgkixtpayvbifvrfnvbsikrf
 * Smoking Wheels....  was here 2017 fgtvmakbiksrnnxvmyvdvxjoaokhmyzhsnnpwrphjaqlazcl
 * Smoking Wheels....  was here 2017 nxzeacqzlaveexdcvatnamgnubllymicxtpooxdrstcjgkrt
 * Smoking Wheels....  was here 2017 qhacyjgijrbepkcyhbtkqqckgzldvppdqmgdzflrupqducqe
 * Smoking Wheels....  was here 2017 mdsisjadcugaiescwcxtkcymoznyxrzigytqbruvcjqprqjv
 * Smoking Wheels....  was here 2017 ejawzxcsvxnkeogmahkvexchfxbvhiyvjpqnxouyjetxgape
 * Smoking Wheels....  was here 2017 zgfyratpawhcegdghdvdeidqzvswenecvdrozkfdnkujbiix
 * Smoking Wheels....  was here 2017 pgvcyxoqmufhpeaxnjwktxxqubikeiqvtovszyeqwozrvzry
 * Smoking Wheels....  was here 2017 vapbfeiwdacialxbwwpqqkmnxfcccfmxmbkhtgabvnrrqrdl
 * Smoking Wheels....  was here 2017 vpoueoeofcdwgmzrrygcrwexudkuxugopcxsnogfdkmmugkw
 * Smoking Wheels....  was here 2017 xezosdljgxsshxryoaigdooofxvqzangalcurltcvnilvxkx
 * Smoking Wheels....  was here 2017 reixacqzxmmakrshiupwjalpcwizuzjpvzzmxrpbbmjfnajm
 * Smoking Wheels....  was here 2017 zjjmnbpoeghffxajcgcxazygrpzmecxoizvacgbrkcxrygst
 * Smoking Wheels....  was here 2017 yrejvtljishvmzvegpbrcnidmyfyebpifwdymmutmlqxjmef
 * Smoking Wheels....  was here 2017 yiyuxemzvtwtgpovkiaqrxgbgaqnbsdhgkrzjwnijxmiixrm
 * Smoking Wheels....  was here 2017 ovgfyrgejmqduqxujdsngrlbwedqkhnfpmlcoeksgbmnqxko
 * Smoking Wheels....  was here 2017 qvukhtpbzfojqgwuhzejkpblrywvycxzpkspwmtlptcjjcwo
 * Smoking Wheels....  was here 2017 hipjreqxwnraqwornbqjdrjubefauwtuwpaymacjdbyztlsz
 * Smoking Wheels....  was here 2017 xoyiazqgnhlzucnspwqboezwvzvifluagtcwwihoxiyticxl
 * Smoking Wheels....  was here 2017 ayiukkeyqoljkwjgmdyedrruxsobsaxlwwykqfjgccdhykpx
 * Smoking Wheels....  was here 2017 ofnnjacbgrqobhcbfunrmypvoynydziyadwtsrtcehamqaip
 * Smoking Wheels....  was here 2017 pjonmqlvphcfmvyzdbrxozzogneunznsjailiyxvwzekqxtx
 * Smoking Wheels....  was here 2017 moqzsepxcdfdsdghxkygncmttndsdxdeuhdgvqtnflmmoeum
 * Smoking Wheels....  was here 2017 whilfacamkrmcbvjjnanttwnyhhcnxfaivgcxmhnjibiegri
 * Smoking Wheels....  was here 2017 ngkqlquhukipetoxolyrzvgeeksomlwfjxzgmnwjwmjtmtwp
 * Smoking Wheels....  was here 2017 qluozvszgshdsrrwyizzcgyfvswzccowmyvgtabvkyzzwpas
 * Smoking Wheels....  was here 2017 nbwlvqfrhezytlpjbqqzhjnmsijlpvampsnubnrazcvhuydk
 * Smoking Wheels....  was here 2017 upavchveqwaepzbxtcsiyrvatpckotfstddxduvgvnaibfkn
 * Smoking Wheels....  was here 2017 hsdkgiloidieukyderdbszweebekthgnilwvxwuakayzsafi
 * Smoking Wheels....  was here 2017 dkcfyocbopzoddozqpglogamnoaihbraybgbmafemtgjchif
 * Smoking Wheels....  was here 2017 rwhnbadivblfqvgrtinyquwtmggijaeskubiitvuazuwsdrx
 * Smoking Wheels....  was here 2017 npdtvycdwphgqktplotijefbakttogqgxnhrcwudfjtcjamh
 * Smoking Wheels....  was here 2017 oilrpwvoppkbqzblshxpjddrkqqgsfhpsmfgrkjvpsmxbpdo
 * Smoking Wheels....  was here 2017 vyficokwiqzglyhezrhzqryecujqvoqxmeirhqdpwcqkdrkd
 * Smoking Wheels....  was here 2017 tssxfceqnojrdayyvgjzhdgjuynbeehpahlpibzobwcadnet
 * Smoking Wheels....  was here 2017 wclycsrrwkelybtfdsxiuzviolzyiegkntnbmmxairzivmri
 * Smoking Wheels....  was here 2017 cvedfysbkpjzlfoqzzzatbuioxxvbasfgvuhpxgmegsggejz
 * Smoking Wheels....  was here 2017 nvxofpkchqzxlwreshujdimzgdrpljdgvzwuyqqvitxvtpyg
 * Smoking Wheels....  was here 2017 ljxjzqbiclmaztmzzdwtbckalfxlubfxeylhwevcvnlmuvjs
 * Smoking Wheels....  was here 2017 ovrdskgolbmnirsmpfyazxlpbnoqohvxipnvbiyovdmvfguj
 * Smoking Wheels....  was here 2017 rzzpvjuwkvwtawhksncdomqyjqrxplhdrfkqlcguvlktbprk
 * Smoking Wheels....  was here 2017 xvwrzjuneithwrlrqfnhsyirvjrayezvvhoeetkqpmvjpstf
 * Smoking Wheels....  was here 2017 pnosdkndglocytplztucqlcnevfexlpjpmufqwedcrrakuzn
 * Smoking Wheels....  was here 2017 inodksqmjgxfmbleqxpesqtqjierahcmductpeqonoaiheng
 * Smoking Wheels....  was here 2017 aprsfxwqlbsbbrzorqappfkgqnsfbfsctksbwtcmkzhffouo
 * Smoking Wheels....  was here 2017 tqwmgrixtmbfmbimldgpffhznfepbvwjduepsuftlbdtnvpx
 * Smoking Wheels....  was here 2017 wylplcjvvijotvaeowwruycprleajbgtbsgclxskpbliueuy
 */
package net.yacy.server.http;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ByteBuffer;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.server.serverCore;
public final class ChunkedOutputStream extends FilterOutputStream {
private boolean finished = false;
public ChunkedOutputStream(final OutputStream out) {
super(out);
}
@Override
public synchronized void close() throws IOException {
        if (!this.finished) this.finish();
this.out.close();
}
public void finish() throws IOException {
        if (!this.finished) {
this.out.write((byte) 48);
this.out.write(serverCore.CRLF);
this.out.write(serverCore.CRLF);
this.out.flush();
this.finished = true;
}
}
@Override
public void write(final byte[] b) throws IOException {
        if (this.finished) throw new IOException("ChunkedOutputStream already finalized.");
        if (b.length == 0) return;
this.out.write(ASCII.getBytes(Integer.toHexString(b.length)));
this.out.write(serverCore.CRLF);
this.out.write(b);
this.out.write(serverCore.CRLF);
this.out.flush();
}
@Override
public void write(final byte[] b, final int off, final int len) throws IOException {
        if (this.finished) throw new IOException("ChunkedOutputStream already finalized.");
        if (len == 0) return;
this.out.write(ASCII.getBytes(Integer.toHexString(len)));
this.out.write(serverCore.CRLF);
this.out.write(b, off, len);
this.out.write(serverCore.CRLF);
this.out.flush();
}
public void write(final ByteBuffer b, final int off, final int len) throws IOException {
        if (this.finished) throw new IOException("ChunkedOutputStream already finalized.");
        if (len == 0) return;
this.out.write(ASCII.getBytes(Integer.toHexString(len)));
this.out.write(serverCore.CRLF);
this.out.write(b.getBytes(off, len));
this.out.write(serverCore.CRLF);
this.out.flush();
}
public void write(final InputStream b) throws IOException {
        if (this.finished) throw new IOException("ChunkedOutputStream already finalized.");
final int len = b.available();
        if (len == 0) return;
this.out.write(ASCII.getBytes(Integer.toHexString(len)));
this.out.write(serverCore.CRLF);
FileUtils.copy(b, this.out, len);
this.out.write(serverCore.CRLF);
this.out.flush();
}
@Override
public void write(final int b) throws IOException {
        if (this.finished) throw new IOException("ChunkedOutputStream already finalized.");
this.out.write(UTF8.getBytes("1"));
this.out.write(serverCore.CRLF);
this.out.write(b);
this.out.write(serverCore.CRLF);
this.out.flush();
}
}
