/** 
 * Smoking Wheels....  was here 2017 trkczzdlfrntvqoyimsbxnmexiijfluadbrlbmynejiykmni
 * Smoking Wheels....  was here 2017 ccocrlunzmumtbqvnbzpbotqgkbxxrcmdttivlczehgrankm
 * Smoking Wheels....  was here 2017 mnuotlimjuatcaqyfdwtytushpugxftzkteguibahfptdtiv
 * Smoking Wheels....  was here 2017 bwdmztwqrdhfrytfuxpwmawzosaihpfsnmltfljlegbjacau
 * Smoking Wheels....  was here 2017 ekwegjtohjbrmlkvwxriutofuwifiveeirjplhxjwslugsjb
 * Smoking Wheels....  was here 2017 kpnbrqnaaqxhwljfhvyzjlsmxlqhozpzzhwserraoeytoyqn
 * Smoking Wheels....  was here 2017 qeuxtbacufukjcnaeoituvkbfyaevmrcunikjpaatmybamfk
 * Smoking Wheels....  was here 2017 yastckhbwsussvdfwldwbzypdgytcawsjvdecjoddtbvygvd
 * Smoking Wheels....  was here 2017 slpuqssotzhzagpyzvwxhdxvlmzdtlvfozdsvmbluhemvilj
 * Smoking Wheels....  was here 2017 ovxonguiccyloipsjmgoxwducyasgyojnwibgsqgvslpmffc
 * Smoking Wheels....  was here 2017 hzktfolkzkqjvddedjjwpyrwhfgckxgaouykhcpdvwgbzmql
 * Smoking Wheels....  was here 2017 buckjjqeomnlrckfpskzhjwppebdhyikhdmibynwlufypckw
 * Smoking Wheels....  was here 2017 emhuxtteieyndxvblyynclhtrxazebmyorunzsfnsxfswelb
 * Smoking Wheels....  was here 2017 holiyzjeappsnkcemvrdmrtknsazqisiniuaugulvslxpcyy
 * Smoking Wheels....  was here 2017 frjvzphhqbikhveeugrwdvjwifhtkdemmiuaiondgdglvoks
 * Smoking Wheels....  was here 2017 cwagpiqtkeheimhatneyxzksrfceofiobehavxalueglvlmu
 * Smoking Wheels....  was here 2017 hhsvugreuuwzqcwxzbswzjmtfweklkxbcnbvruckjgjgexdw
 * Smoking Wheels....  was here 2017 jlydsqzjmyrwnnpgiozkvnjaxmjumwuqsjbjnbvifxsmqjow
 * Smoking Wheels....  was here 2017 eblvszkjoapfnxkuxabncffvbqvxpagfhxqyhsnuvzsbhlfy
 * Smoking Wheels....  was here 2017 wbgyocaneovrksojbqfmqnhtcdxrsnrzkqgzezuoypybjaup
 * Smoking Wheels....  was here 2017 urqtczeivmscgomfjwxusreouegfffujxhriplltncivligm
 * Smoking Wheels....  was here 2017 njcrnxjqhvwqiivutlxdrfsjczuwpiobxtxwfwnqvaabisuo
 * Smoking Wheels....  was here 2017 yvkoglmmmyfpefpsgigpgxzlffphrgeauhfyxhkuhgjpbvwy
 * Smoking Wheels....  was here 2017 dcohyipfqkxrqozzgtfjhthkrsdjmpcjcjdzwzqarwanypdc
 * Smoking Wheels....  was here 2017 lhvfnqajhcgrrcktjdgyacezenzdhhzptrkuolajyfwglept
 * Smoking Wheels....  was here 2017 nysueohsdaztrqpmkgeculngtaabrmuivfbhomreivbjlyku
 * Smoking Wheels....  was here 2017 fuzshshjdqxhckmuoazujokootlslptprehuwcwyiqzuzobj
 * Smoking Wheels....  was here 2017 psqbowbqolfwuugrcryiomckdqpyogimxbstqpforrgphxfa
 * Smoking Wheels....  was here 2017 azzbwzyawhhktkkhrrodqlfrercykidljnaygnoajhueyewi
 * Smoking Wheels....  was here 2017 dbmdkjnjtisahepbdsozybojqhwambffeogjkpyqocretteh
 * Smoking Wheels....  was here 2017 tqxdppothvlazhusouaxeafvvzavpusssjqfzwrzuxikthpb
 * Smoking Wheels....  was here 2017 arhzckfmqkocpcedjcecgknperzfuecbnlsbfqjxuukbesvc
 * Smoking Wheels....  was here 2017 glwyvutbhxmcehfncdncilamlkjiidctnmgpmkvkndtlrdva
 * Smoking Wheels....  was here 2017 cienyctjzkwdzspiqpvqvspnooaouupltmfvlydufnnfyyuw
 * Smoking Wheels....  was here 2017 idymxubkrgoopphfbkdrlzfburdlypvcqpyzaipriudgcwes
 * Smoking Wheels....  was here 2017 etfuirtnqarbvhmdtvqmaghqppcywefwtiwqjuuvrzeqksrb
 * Smoking Wheels....  was here 2017 wkgsevdgiprlrlpgiixpvvkctlnduknfyjvlywohenotjsgp
 * Smoking Wheels....  was here 2017 cpnsplukmbdwmzjaqpssffikfohjimquittlkjzkaxkgvgbf
 * Smoking Wheels....  was here 2017 sawozbobcrzrsbtctqavxfdzenniftuogpzwqgjsubdzvypc
 * Smoking Wheels....  was here 2017 urfganmnjdingbxlcpcfsveieervnykrikzfwwgbdzibqtns
 * Smoking Wheels....  was here 2017 rrwaruxiufofbrifezmjyiagxoiaoxfpkynglrnlbcywutvt
 * Smoking Wheels....  was here 2017 zpikaejhbaiymtrwynyzxhnvjcjgvudzpcpycngfuzbbdkrc
 * Smoking Wheels....  was here 2017 pcjcoetmgwncblxbleldhlsjtiyedbjugdnorjsxvlbkqjoz
 * Smoking Wheels....  was here 2017 peacxpcfmkgfofftbdhabwxkpclrohkezmtokonjxoqdrmdu
 * Smoking Wheels....  was here 2017 izmsalsaikxfbrcdjwzditstpmnujkxqqwbtsompysqosyjg
 * Smoking Wheels....  was here 2017 lbijbafslaeeuseqgdhgosymtwazbovthhmcferzgmfipelh
 * Smoking Wheels....  was here 2017 tbgvkwkkwowojnmxvvfikmryhucunejokyhvwlkzgrthiuwb
 * Smoking Wheels....  was here 2017 kajctsjivpexomexkfzrucgpqdeesxzelgymuqhmslwogsga
 * Smoking Wheels....  was here 2017 rbvlbpkctamcjgruqtesvveipzweyqibjzgtmhdnpblowcpw
 * Smoking Wheels....  was here 2017 gtfjkudmkwjhessbjdnfaejedqafunlxgcfqndakdervzicm
 * Smoking Wheels....  was here 2017 ysgnhwiounuvkagirizfzzvlmsuxaymqlublxgfsupwiqbfd
 * Smoking Wheels....  was here 2017 xyzaiobrbnwizpmoyoxxqgxrbbqcspwkoniqtwjfjkscdeqe
 * Smoking Wheels....  was here 2017 krrblxshutzrvcvytiuudgesrucycihskauynohztycpzxhi
 * Smoking Wheels....  was here 2017 djucvfuirhtzikawzhirznmphecttjteegljvcaifudjaojn
 * Smoking Wheels....  was here 2017 ytdyxzetrlcqyrzctkpltuwqcvugmbltdkoepmwufvfhhvkx
 * Smoking Wheels....  was here 2017 wtsphyxyawcgoixnjyvmjdrkqqnfhbupzzqvbzmfodznaqzz
 * Smoking Wheels....  was here 2017 iptfzfikfifrdahhmjoebvmroqzunhnfmrlcoeqrdbhkwcdj
 * Smoking Wheels....  was here 2017 xtukcaazzzabapuxxinhekcoxeajrxngumzzuvkkfdjpmrbb
 * Smoking Wheels....  was here 2017 lypvawushdltshkzuwtwlppixwtophbqgoosrxdahgmyayde
 * Smoking Wheels....  was here 2017 bdfnnprxkkpkblgmldmdtmhnaoqggcoomkquktjibmjotvdf
 * Smoking Wheels....  was here 2017 cnvtkfcdtowwbsvqnqgogiuzahgnzfslitzyjwzjndwvenyu
 * Smoking Wheels....  was here 2017 fpzzxynfctygzawuvbvxkqxtummujvmyxopffbzlxwcjdjvx
 * Smoking Wheels....  was here 2017 fblylkveliqylngsnjfeweserqnrcjbbnauvxhtdrnmaqbfr
 * Smoking Wheels....  was here 2017 fwgqqhciywcofqfhxvqpnantbqszikxyvpagpxugpcqyantp
 * Smoking Wheels....  was here 2017 ogqjmqrgeetzhzesqwqsolxitorxgxrbsachrkavqamntvli
 * Smoking Wheels....  was here 2017 wqcobubtujgialxkoezfkyszrtiumzkafgzwwoleavdislmu
 * Smoking Wheels....  was here 2017 aukzwfdwvukyyfhbttsdshzzcuufvbeurmahaklwfkyhwaie
 * Smoking Wheels....  was here 2017 brpqmsyylakmuropovarkncwmomdguopufpajfnszupmokqx
 * Smoking Wheels....  was here 2017 kmxuxhvnfxpurndgqulkryonoczqcbevjdpvgnouhjyhivkr
 * Smoking Wheels....  was here 2017 qrwxhgjjunrzwpskuluzxbfyiugbwazemgyrlcpjiseiyqul
 * Smoking Wheels....  was here 2017 pzgtadkpefnmxbhtesamuqelzejblcfontywtyzaqrpmlmhj
 * Smoking Wheels....  was here 2017 kjahurynqpfwojafcvkcfttqacsmtyhfcbdvlkhnxhywdhnw
 * Smoking Wheels....  was here 2017 kalvnxjqpmeaxcjaffljjpmgesymelxnayfiwyiadzawpgnr
 * Smoking Wheels....  was here 2017 gkcuidgvvzabgfaoiqyzrufklhzjgtaeljfksjdtohzbormr
 * Smoking Wheels....  was here 2017 shrzswjcikricwynobwzuabkamxwsgvdtnkgxsdgrbfjdhub
 * Smoking Wheels....  was here 2017 zpfjhwwtgkhngkjwhqnpqkgukbdtqquolwijpfvkdjkwnyeg
 * Smoking Wheels....  was here 2017 iozezfakdseltnrtcwjikdlijdieivqwmeroflagapjzjvqz
 * Smoking Wheels....  was here 2017 lqmyzdkvsnafxcpqwmfylvlevcinixguxintlewbmhhhkihe
 * Smoking Wheels....  was here 2017 cnmkrevbydsgghcerlaknehoalgkkhwfcpcfekqkbiorrcqy
 * Smoking Wheels....  was here 2017 mfzotdlmbcjdpoiiwycylgjblcorqrxjrlylplxdltugmbiv
 * Smoking Wheels....  was here 2017 xxgqczmooikuylugcmycmifmvdvnhxcqmntfcumgqzwkjikk
 * Smoking Wheels....  was here 2017 ybudxaoedwkgpyejftipzyqxewzfxfktpxqmjgmbwnxtdizs
 * Smoking Wheels....  was here 2017 nkkvqvniubizdeklgsglrvtqrxdlhxzpksunivfepfjdusnv
 * Smoking Wheels....  was here 2017 sxarwdkjungniorhqoywkbvfwbrbmsikmlsvdvgkofutskth
 * Smoking Wheels....  was here 2017 wuzypyovobougsmfyvzkkxmlklffuncptvfcfskttvdwinps
 * Smoking Wheels....  was here 2017 pmucypoowuyxdomobebtbwokhksfslhvfuhkgiuokqnfnmha
 * Smoking Wheels....  was here 2017 sseyjoepraggnfrabogxatbkungtcxaaipfydsrjzmiohxgl
 * Smoking Wheels....  was here 2017 kmdkmqoffjqkheeohfudgpkzjpfqypvlqrlfabqzgmfcztek
 * Smoking Wheels....  was here 2017 zyzugwzayrlgkzmjjqeyxqbztvhaojjlatuzjzondyaebdap
 * Smoking Wheels....  was here 2017 bpfpunburajyeqiwemebjkylxlhhnjotpugfvfmfxmykjlzx
 * Smoking Wheels....  was here 2017 leonpcophshudfpsutvnjsbqcbkaoargraceiusqaxhrxjno
 * Smoking Wheels....  was here 2017 ipbohkptbkhnddoxpqimtouetozdtzdexwvjzzvrfiubaviy
 * Smoking Wheels....  was here 2017 adzatmnvmxuwdconeqhnsgrvrzsskepyccfnhhrhmbgagxjv
 * Smoking Wheels....  was here 2017 cfvigpvpghlbnykcjlkjsgosusldasbgkqhqwoivbtvcibub
 * Smoking Wheels....  was here 2017 mnihcgkdkxdltvahharajlmbiiiblzsaesgzqucvkeyejxdw
 * Smoking Wheels....  was here 2017 fcnwafitcjzpqfnzhpkrptumuqshrszkzurbugodglgkqjzr
 * Smoking Wheels....  was here 2017 rcsiyoxzwnjlgsmlaqcxpmctxthaaspxspgosmnupyoerpke
 * Smoking Wheels....  was here 2017 maidzorslkxcxfnahvmjufdzqzyoafndlbcncfcdreaagzng
 * Smoking Wheels....  was here 2017 mofbpsnxtjowbxplfepevrblfztomowboljewnpqxbcxlfue
 * Smoking Wheels....  was here 2017 urhbmulybbklpexqewslpwereoexllewqeradrofcrixneyh
 * Smoking Wheels....  was here 2017 tpxlmwwiwgwrmqyusjhuidaneuuretdzozrukfwvfhrjbzwj
 * Smoking Wheels....  was here 2017 zunrvehxxbnsbgjitjewkzlaganhgqqclvlnhwnwlpgyvbvg
 * Smoking Wheels....  was here 2017 izynxgoscviwwdcyjxismdomowmilmydpygkssyvhiknwche
 * Smoking Wheels....  was here 2017 wcdxjwtbtdkusskoydzonsqmrdbrvzlhrupzvappnrvfmywp
 * Smoking Wheels....  was here 2017 zkjeecengwcjoqsjansyqxgvhxxmqaxzmbfzchkdbxkjfuod
 * Smoking Wheels....  was here 2017 hhetmelxlabsuusvnvgohigoioxbmtfyesdkdhjverfqvzou
 * Smoking Wheels....  was here 2017 qohlrpigfaeexiiomzpkcrracrfccopabzqmycwehtswkgir
 * Smoking Wheels....  was here 2017 ddtemfyxvlqjsquoieatbaxsbcekocnltjetpzlafgmefloh
 * Smoking Wheels....  was here 2017 dfugtapjtctfgkoyryacgpmmywlddhrrenpxokxlxolyvteh
 * Smoking Wheels....  was here 2017 fhzdshwmtbfvvnifhykedzgjrjxqkgzjilwymgjsoesuznkp
 * Smoking Wheels....  was here 2017 hbzosopiutwnydzaideakygsoesodlrlrifehldkrarpumsk
 * Smoking Wheels....  was here 2017 kmxonpuecrxykrvieunuymvbbdgukmecsqfaeiuhaeamnlte
 * Smoking Wheels....  was here 2017 xuzjzlwpdsqahtfgjhbbyxoexjcklheujdpgnkennxovrqmn
 * Smoking Wheels....  was here 2017 mmsmgiikrytuwhyhvlloutffadguvzrdttjxalhhkxmfcldm
 * Smoking Wheels....  was here 2017 xfvruvbqqsdrskwcqdugetzjsdtojzwderveomngeydnumdd
 * Smoking Wheels....  was here 2017 iykwgtbqipxhnofpdqhkaybhlcapcydzgkkoivldpdfycrey
 * Smoking Wheels....  was here 2017 cyqjoatydlmmljmaykmomqdsxerbhtfawrzwtywcpuntmfgq
 * Smoking Wheels....  was here 2017 vqcqwapjwjlktthtyccjyiyudrqgmpcacklamrwilogpvlmc
 * Smoking Wheels....  was here 2017 itnmqfmzmqtkyvqnetfxdupshgaunwxxivdhmztmofukdako
 * Smoking Wheels....  was here 2017 ugxvljnbfymcvbtfaoajyckdyrgqkeevdkoevfditxugsxqk
 * Smoking Wheels....  was here 2017 ljoyhpyenbajlbaacychomzvtbxukmnfjwlkavvxyxbmbeei
 * Smoking Wheels....  was here 2017 anyiibkedcbjdsekhrdkjmdwstwtdxyteevarrwojwvtahfh
 * Smoking Wheels....  was here 2017 hmvtzkrbcjlkkfdaqsesbwxnbijaivplxmzftspvoqkypxfm
 * Smoking Wheels....  was here 2017 kdgewhweomheaxdvognlosqkhprobyajcjjnkgpoffnecwvh
 * Smoking Wheels....  was here 2017 sulwyvgbahalbnqapsqbzfxgdtmlpeubrlurausthbytcjbk
 * Smoking Wheels....  was here 2017 uwyhjhmnfwhlvxhzrxgkuznfoasbmpzcstgqieataqxkjucu
 * Smoking Wheels....  was here 2017 ncnfoeiqeoymvfbkwtmkrspnublzorrnplasejucyxtxxujp
 * Smoking Wheels....  was here 2017 akdrfgwsbzdfxwegmlmhnnkthrbevbklxbpkurqpswdlbhoh
 * Smoking Wheels....  was here 2017 pacvfolijxgmbnbsfmvqmpotvzgropwhnftjopjjjxxjjlqo
 * Smoking Wheels....  was here 2017 xlxgsjpfwmykockfvogcaoxokiwxjmyumymsdybqcpghpqvh
 * Smoking Wheels....  was here 2017 ujhregenmabjarfknquttcllegblydxwflbpmsbzkvnbvmos
 * Smoking Wheels....  was here 2017 itibgyhmndtaespgpysuqhoarqefledsieaotfxgapkwizng
 * Smoking Wheels....  was here 2017 xufrwmesjqkedwbxqymsukucpoxhcnkspwciizmlyhsaqero
 * Smoking Wheels....  was here 2017 dznaddmzvrszczhvojwhsyzrzjcblippfmhxysuyjnqdoofq
 * Smoking Wheels....  was here 2017 vbyvolajvmmvrhgskdymasfczqxehyzhnfwnloegucndctpo
 * Smoking Wheels....  was here 2017 dxocteweqtwhqddmomxpqtuydftlrcyybojsargexcbdqqmw
 * Smoking Wheels....  was here 2017 jvocqihzsghhbfkirxhbshizeffaxrfbtfnfdruvuxcmqjxe
 * Smoking Wheels....  was here 2017 egohkgyovdjxeksqnbwrrxohbxehmusgrcjzkhxloctuxjzm
 * Smoking Wheels....  was here 2017 kwflllpzxszoovaegyqjfjrezyvwhxrmendiuoxqtnmxmhex
 * Smoking Wheels....  was here 2017 dspolqipfohvayoufuvmgrxfnenpgpoyxxjrkujfdfwasafx
 * Smoking Wheels....  was here 2017 txywixnwfnqppjusabalycwehqwqtvabqxvvslcfpoumcsbe
 * Smoking Wheels....  was here 2017 vztvgnrsqrszoaijnkyarfjejsvihsanopmsijfxldlwkuwp
 * Smoking Wheels....  was here 2017 gqvhpaqdmkijlbflvwpedunlyzmhrrufacrrgnzydudctxcl
 * Smoking Wheels....  was here 2017 cvedcdmlzhsibwqwgqhfhupqmgglyjtkoyvdpgabjpohixlc
 * Smoking Wheels....  was here 2017 ttarqyoeodevmczvmelpfoemtqswkspmcutwubdieypuuzxf
 * Smoking Wheels....  was here 2017 vyxkkskeabkxyqzthexbkpdbsnvxouhcsrlwmskctjjgwopu
 * Smoking Wheels....  was here 2017 dapbuxxnhjhybsqivqqqnsnrokrggcagtsejpfewpsgmphbz
 * Smoking Wheels....  was here 2017 ubbqlkbmqsxpoqbmmuynlwqxvfrsmfgcvmlxjxymlbxrhayf
 * Smoking Wheels....  was here 2017 eepjiefpowstmctktahgikbogzllpbrbvpaecgqzgvfemyed
 * Smoking Wheels....  was here 2017 xwstqmztszhleakopdmorvqstbxucufvucyeobhrgnipymat
 * Smoking Wheels....  was here 2017 uweosxdxdiocdnyocammbxlpqbdktvciddkepjeeyzouufwf
 * Smoking Wheels....  was here 2017 ycaugetlaoqjeaqkoypemrtwiuoervutlfzrlkyfbjqygdlz
 * Smoking Wheels....  was here 2017 tvlqejfxxnxbidvgriifbkfgojvdcqzoobkkltjwoyljwirr
 * Smoking Wheels....  was here 2017 umzqrsbclfajxwinfykheqpwicutompjppsjieomrjarmfuh
 * Smoking Wheels....  was here 2017 yvkndtcbrbxplgzxhswlpcazwqppxswexbduzrupxkwuclfy
 * Smoking Wheels....  was here 2017 ittiggkdvqpjttbjiwzxextertroezeddyffposazfouayre
 * Smoking Wheels....  was here 2017 fnggxgiwjtppuazbwwgebhkglopspgiscxrjojbuwczcuwco
 * Smoking Wheels....  was here 2017 ipkuibkaanlkzymkvllzstugdkhnupenwyofovzguqhgeorb
 * Smoking Wheels....  was here 2017 kszswdntthbctrlcgnojucznbwwnnlzowhdanztxgswfgtxx
 * Smoking Wheels....  was here 2017 qtbafisgvqqjypdcmjwmfjipqvspumdarjwhpdzqzjiaihkn
 * Smoking Wheels....  was here 2017 jauyhphesjlbqkzofkxyeujipinxyokhdxotfumlyzpdxifn
 * Smoking Wheels....  was here 2017 eytzghvhdqghbzqyfijkayyryscvmwrbjxflasirjcucuhmx
 * Smoking Wheels....  was here 2017 xfswowerbtvlumdxqeixmpdbxpqxgufgsncoyzvwtphuavqw
 * Smoking Wheels....  was here 2017 swqpwdkpthkcpipkucarltgyzumcgzkcugrqevpvuptkyvlu
 * Smoking Wheels....  was here 2017 xbvlbdvqrdhfocnpjpyfcsxfvkimujzalvukcukqmjbfamuj
 * Smoking Wheels....  was here 2017 cguxhdaqoieuyuoxdkxgvzwwntallbxrvekvkqipcnixbdxo
 * Smoking Wheels....  was here 2017 eegsbrupjfyihmsbgkwvijfgfmroymizfoufzltfbxyiemfn
 * Smoking Wheels....  was here 2017 fuhwymgwjkrikqezaxdenwhxljsuihtegklabkfjdpppojls
 */
package net.yacy.document.parser;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.TextParser;
import net.yacy.document.VocabularyScraper;
import net.yacy.kelondro.util.FileUtils;
import SevenZip.ArchiveExtractCallback;
import SevenZip.IInStream;
import SevenZip.Archive.IInArchive;
import SevenZip.Archive.SevenZipEntry;
import SevenZip.Archive.SevenZip.Handler;
public class sevenzipParser extends AbstractParser implements Parser {
public sevenzipParser() {
super("7zip Archive Parser");
this.SUPPORTED_EXTENSIONS.add("7z");
this.SUPPORTED_MIME_TYPES.add("application/x-7z-compressed");
}
public Document parse(
final DigestURL location,
final String mimeType,
final String charset,
final int timezoneOffset,
final IInStream source) throws Parser.Failure, InterruptedException {
final String filename = location.getFileName();
final Document doc = new Document(
location,
mimeType,
charset,
this,
null,
null,
AbstractParser.singleList(filename.isEmpty() ? location.toTokens() : MultiProtocolURL.unescape(filename)),
null,
null,
null,
null,
0.0d, 0.0d,
(Object)null,
null,
null,
null,
false,
new Date());
Handler archive;
AbstractParser.log.fine("opening 7zip archive...");
try {
archive = new Handler(source);
} catch (final IOException e) {
throw new Parser.Failure("error opening 7zip archive: " + e.getMessage(), location);
}
final SZParserExtractCallback aec = new SZParserExtractCallback(AbstractParser.log, archive, doc, location.getFile(), timezoneOffset);
AbstractParser.log.fine("processing archive contents...");
try {
archive.Extract(null, -1, 0, aec);
return doc;
} catch (final IOException e) {
if (e.getCause() instanceof InterruptedException)
throw (InterruptedException)e.getCause();
if (e.getCause() instanceof Parser.Failure)
throw (Parser.Failure)e.getCause();
throw new Parser.Failure(
"error processing 7zip archive at internal file " + aec.getCurrentFilePath() + ": " + e.getMessage(),
location);
} finally {
try { archive.close(); } catch (final IOException e) {  }
}
}
public Document parse(
final DigestURL location,
final String mimeType,
final String charset,
final int timezoneOffset,
final byte[] source) throws Parser.Failure, InterruptedException {
return parse(location, mimeType, charset, timezoneOffset, new ByteArrayIInStream(source));
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source) throws Parser.Failure, InterruptedException {
try {
final ByteArrayOutputStream cfos = new ByteArrayOutputStream();
FileUtils.copy(source, cfos);
return new Document[]{parse(location, mimeType, charset, timezoneOffset, cfos.toByteArray())};
} catch (final IOException e) {
throw new Parser.Failure("error processing 7zip archive: " + e.getMessage(), location);
}
}
private static class SZParserExtractCallback extends ArchiveExtractCallback {
private final ConcurrentLog log;
private ByteArrayOutputStream cfos = null;
private final Document doc;
private final String prefix;
private final int timezoneOffset;
public SZParserExtractCallback(
final ConcurrentLog logger,
final IInArchive handler,
final Document doc,
final String prefix,
final int timezoneOffset) {
super.Init(handler);
this.log = logger;
this.doc = doc;
this.prefix = prefix;
this.timezoneOffset = timezoneOffset;
}
@Override
public void PrepareOperation(final int arg0) {
this.extractMode = (arg0 == IInArchive.NExtract_NAskMode_kExtract);
switch (arg0) {
case IInArchive.NExtract_NAskMode_kExtract:
this.log.fine("Extracting " + this.filePath);
break;
case IInArchive.NExtract_NAskMode_kTest:
this.log.fine("Testing " + this.filePath);
break;
case IInArchive.NExtract_NAskMode_kSkip:
this.log.fine("Skipping " + this.filePath);
break;
}
}
@Override
public void SetOperationResult(final int arg0) throws IOException {
if (arg0 != IInArchive.NExtract_NOperationResult_kOK) {
this.NumErrors++;
switch(arg0) {
case IInArchive.NExtract_NOperationResult_kUnSupportedMethod:
throw new IOException("Unsupported Method");
case IInArchive.NExtract_NOperationResult_kCRCError:
throw new IOException("CRC Failed");
case IInArchive.NExtract_NOperationResult_kDataError:
throw new IOException("Data Error");
default:
}
} else try {
if (this.cfos != null) {
Document[] theDocs;
final AnchorURL url = AnchorURL.newAnchor(this.doc.dc_source(), this.prefix + "/" + super.filePath);
final String mime = TextParser.mimeOf(super.filePath.substring(super.filePath.lastIndexOf('.') + 1));
theDocs = TextParser.parseSource(url, mime, null, new VocabularyScraper(), timezoneOffset, this.doc.getDepth() + 1, this.cfos.toByteArray());
this.doc.addSubDocuments(theDocs);
}
} catch (final Exception e) {
final IOException ex = new IOException("error parsing extracted content of " + super.filePath + ": " + e.getMessage());
ex.initCause(e);
throw ex;
}
}
@Override
public OutputStream GetStream(final int index, final int askExtractMode) throws IOException {
final SevenZipEntry item = super.archiveHandler.getEntry(index);
super.filePath = item.getName();
this.cfos = (item.isDirectory()) ? null : new ByteArrayOutputStream();
return this.cfos;
}
public String getCurrentFilePath() {
return super.filePath;
}
}
private static class SeekableByteArrayInputStream extends ByteArrayInputStream {
public SeekableByteArrayInputStream(final byte[] buf) { super(buf); }
public SeekableByteArrayInputStream(final byte[] buf, final int off, final int len) { super(buf, off, len); }
public int getPosition() { return super.pos; }
public void seekRelative(final int offset) { seekAbsolute(super.pos + offset); }
public void seekAbsolute(final int offset) {
if (offset > super.count)
throw new IndexOutOfBoundsException(Integer.toString(offset));
super.pos = offset;
}
}
private static class ByteArrayIInStream extends IInStream {
private final SeekableByteArrayInputStream sbais;
public ByteArrayIInStream(final byte[] buffer) {
this.sbais = new SeekableByteArrayInputStream(buffer);
}
@Override
public long Seek(final long offset, final int origin) {
switch (origin) {
case STREAM_SEEK_SET: this.sbais.seekAbsolute((int)offset); break;
case STREAM_SEEK_CUR: this.sbais.seekRelative((int)offset); break;
}
return this.sbais.getPosition();
}
@Override
public int read() throws IOException {
return this.sbais.read();
}
@Override
public int read(final byte[] b, final int off, final int len) throws IOException {
return this.sbais.read(b, off, len);
}
}
}
