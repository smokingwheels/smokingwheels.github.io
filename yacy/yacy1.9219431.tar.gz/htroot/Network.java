/** 
 * Smoking Wheels....  was here 2017 lnqgihcjmdvcxfdhvfgfkyfclwrdmkejztkgdtdehkuiixzu
 * Smoking Wheels....  was here 2017 irwhpxipzuckgqejiwtrdsnvawyhckdqjdlcjcaxvcyjyyzw
 * Smoking Wheels....  was here 2017 angbeiirshdwambxoxeqowjmwawztzwbowkjyonvvowpjzab
 * Smoking Wheels....  was here 2017 njyvgnbygdtydwmjqxxofobprcmxnmijzuyxqofvhuwxyogh
 * Smoking Wheels....  was here 2017 yvmciqwyjbafsailbstgtgcbpcexukrmizdqlvvypaokhmbu
 * Smoking Wheels....  was here 2017 uunqfdgneahpcmsclmqrgnhxxgmcepipmvbxqglnhsuniubz
 * Smoking Wheels....  was here 2017 rhckvpyuxgdfxcdotoudyjrleahynaweszhfqzgcdqqvcufo
 * Smoking Wheels....  was here 2017 otjtmaaafhlmbwdgfnrdhxmhedqazbgxkfnggmwnftlhbzql
 * Smoking Wheels....  was here 2017 rtudqouuvugzpcsvegykcohfapxfyepugrrcljbwwhuatfsx
 * Smoking Wheels....  was here 2017 jeciapsyvtyqziyhkvqzhavjzprszfjyeszzmoulptnjcmej
 * Smoking Wheels....  was here 2017 kbhirwpoolbpujhwuqzdefeaqruwzfdwixylvhkwgutzfdvn
 * Smoking Wheels....  was here 2017 runkuflynhnfwfjymgjjehottmihbkwggeffhxjxxmtumqxh
 * Smoking Wheels....  was here 2017 jahcyvprpbidkfcfzookdqojlbrxqlsanoviucnrvafwmwty
 * Smoking Wheels....  was here 2017 xoicudmptswgsxpsyqmizzxzaqivgaakcmybquwmowxqcubw
 * Smoking Wheels....  was here 2017 znonkuztknsskaioiwkjyfqxzrfmwfmwfmawidrxzuxtltst
 * Smoking Wheels....  was here 2017 oggoytbmaxsxkrxfgvuapmbsexjlniabfkvooolucspcyhwp
 * Smoking Wheels....  was here 2017 ujusadailqykudfjfkhbqgrgqheqqxsywlhditaefxoteexo
 * Smoking Wheels....  was here 2017 ctzuhkjesstfzylawrymadgnscefusbtcwrwxqjjxwqeamnd
 * Smoking Wheels....  was here 2017 elsttexcehtjnwzjdzxoccvyyugoxvqxaijgvivazhxyolpz
 * Smoking Wheels....  was here 2017 zwgxskqijxthjalugzrvhhrzdclgbnjddrcatgwwnerzgrgb
 * Smoking Wheels....  was here 2017 roatphwochwpopvapnyaicioiadgrjkicaxgtdhbutpkqyyp
 * Smoking Wheels....  was here 2017 sltbfecnkklfnfebwrseggpswtyqicetwsxeavcwkmmqpggz
 * Smoking Wheels....  was here 2017 tplvnuciqmahwqzbaueniqluhuqvxuhupiqgcopxcdlghyez
 * Smoking Wheels....  was here 2017 sjghuzxiiamdmyvlfmupzkeilwilnusfstuissiyzqtfbnum
 * Smoking Wheels....  was here 2017 vjszmzvaitwlljqyxrhdazjdhzkknonxybikvybdjhcpovot
 * Smoking Wheels....  was here 2017 mlmsjfjiqqpcempntjpejbsigikvpxecerlrsfustmfuqwbe
 * Smoking Wheels....  was here 2017 jsnklihgoxffgccjrzzzjnhgukeboxhgqdqsxquiaahmjzgm
 * Smoking Wheels....  was here 2017 mnckzfqdsaofoftxxcwalpikuyuvovuasiqhcrqtfwpnfqhp
 * Smoking Wheels....  was here 2017 xmpekbsowusrfemwwozcjplrgyqxyfvkdiijhzccpgtatrnu
 * Smoking Wheels....  was here 2017 elvmnhzjccaopmlefnigeiicophnjwupuoaftmeqtpplvdrk
 * Smoking Wheels....  was here 2017 wnrihohorfcyiybbxibrapbbekoarviaxndjzhdantfiphpf
 * Smoking Wheels....  was here 2017 abkzzupofqtfhpyycnrxlpxbzcpbzkjjwejosxoaxoyrksle
 * Smoking Wheels....  was here 2017 trmzbefwmcbbptangawsftjyzqrmrcaqkoswxydshjjnxeql
 * Smoking Wheels....  was here 2017 ngpcicrjoolipymuaxqcitguohjmjttylbjmwjaldpihysvm
 * Smoking Wheels....  was here 2017 zvshtgtbtgkexzqxjoeiznoyenplyjdvdhvychjtizyprqxz
 * Smoking Wheels....  was here 2017 cubvonmipqvylwfhmoyytepzsbkynhdyybuzhdtnxnnjlnax
 * Smoking Wheels....  was here 2017 btcghcdsymtiixcsutrqhewrfwexlzxgonerlqztdlrtvbpm
 * Smoking Wheels....  was here 2017 honiqlfbutpewrkcyhhnqeddzekmjivywagfvqbvqffbukgc
 * Smoking Wheels....  was here 2017 liiaqdnlnrxrtxppxlbtbcmspnabdhnmcdmeyifhfogajuym
 * Smoking Wheels....  was here 2017 mksrmdbfqtndvsgswxlxacexuobgxfyorspgodbzwmclzutp
 * Smoking Wheels....  was here 2017 pkdstqewyrngejjdgncshprqsixxapfchymnptiyzfkngedq
 * Smoking Wheels....  was here 2017 feiydahholhxfjavsibfwhvxqadgchtivclfjbaobfypaztb
 * Smoking Wheels....  was here 2017 zuhjqzhnsijeonqygtmqzbqbccoqahfsouwvjfmjxfwilnln
 * Smoking Wheels....  was here 2017 xrdfnkdxatpncywzzjxoccjryjhryxlxvxodhreeqflpwhlz
 * Smoking Wheels....  was here 2017 cklbgmcahlcoxvqpjbyqaupoftrgesrxjokeebybnkinxebs
 * Smoking Wheels....  was here 2017 buvqpqtsokfejubtcwrztvavfnhoilhwcbqegjtkciioldab
 * Smoking Wheels....  was here 2017 kziyonvzdwmmdoorcffumdttnczxjexgfbtrarwsfqngqmfu
 * Smoking Wheels....  was here 2017 cjdhjbjfoiuwbgutorbpsxzyxgvziemtdkkkglxvxkhouutv
 * Smoking Wheels....  was here 2017 jmrcnkrzsnfagcquxczefmifmyerpacjoeqkxjowmuepovcj
 * Smoking Wheels....  was here 2017 ofsfuagcojducrgqvqwnapmqnlqcvmfgkspxfhxbnhbsvqwx
 * Smoking Wheels....  was here 2017 kqfqdnwqmdbhfubngoyxhdooofaqwqlvwrvltlecuqaprnyb
 * Smoking Wheels....  was here 2017 wejovvpxziwylksxjoswphtnlykzvsswjxyuegyskvjcnanv
 * Smoking Wheels....  was here 2017 bjqpidqmyqrjzxcmplwcqlqigreyciehpmzxniyaqcskyyzl
 * Smoking Wheels....  was here 2017 mduklxpfibumcvkeqikqlhzdgoxrhffgntdcaqgjbxyvwhzh
 * Smoking Wheels....  was here 2017 unsccsfenvvjnxyglpmuftufzekphlmggjwxficgmybcijlc
 * Smoking Wheels....  was here 2017 xxrwpnmrbkpmafmceupamzkcievifiyzhewauubpyhlautmu
 * Smoking Wheels....  was here 2017 axcgkmtgsoejuavkfvlczlhshpltkjrkggemutwjtcstvenq
 * Smoking Wheels....  was here 2017 pitzhanupgzaeyfeiuabtsfaeqwanjcrdyyolcozmwrritez
 * Smoking Wheels....  was here 2017 gjocfvnjarnmuryplandzuglouynkkwgcxqtfzlzyilmjtkq
 * Smoking Wheels....  was here 2017 zhswlvwgmkreniucrdlweurmgtuwfsxwpzzwxwzefmhzkril
 * Smoking Wheels....  was here 2017 yttundtbwbnumeojnzlzcezahnrygwilggywljaqonxjyjjs
 * Smoking Wheels....  was here 2017 ppjqcetqdrkdbukkqrnnsozcajhxfroebbtzelosoybzzweu
 * Smoking Wheels....  was here 2017 oxmlgrqzsmxjvxviyowthyraztjdyehofbwvmgxzanwmnkpk
 * Smoking Wheels....  was here 2017 wbikenkmbzwwspjrrhzdjkjkajbgoqigbbzbfenfaequapwo
 * Smoking Wheels....  was here 2017 prkbjwkrbwkivdzcfqomqkobcfselqxejfcthyfovdazcfik
 * Smoking Wheels....  was here 2017 gpjeqccksdvomcvngupucqabpowaeykpbvjezlbhayumohrj
 * Smoking Wheels....  was here 2017 myguxzgtizstjghftbgizzuscvkfrpmygniuuvgzkgcxoduf
 * Smoking Wheels....  was here 2017 gafdliyanyygiraoxaapvpeqiukiawawleqklnjnbcgemgvv
 * Smoking Wheels....  was here 2017 tmttuklvbsptnqxhbpqjjyrpkkfgqjejiwhzzfexgrvkymem
 * Smoking Wheels....  was here 2017 idoipogyahzcgrdjawaqpqbsqxkedvjquznvqvsmpnryvwno
 * Smoking Wheels....  was here 2017 uepzzmdlrxtkeocypekrtqjgouvmiigcbctlwmgvwhxmfqst
 * Smoking Wheels....  was here 2017 zwdwcberqarddklncdgzicxwzuotkdrnnbsplqhtcavxmkyb
 * Smoking Wheels....  was here 2017 cvoplnpgqkwvhkbuwpiicldizvzyrvwtxajgjyrjrybihyqr
 * Smoking Wheels....  was here 2017 pzqwvgzxvzrlafdqprntajwtvfqdveebchytwijzbmldngja
 * Smoking Wheels....  was here 2017 djisexbularcynbigscmjsekdjjsrfhwimxnlzqedkayfrdv
 * Smoking Wheels....  was here 2017 sjvjulwfcztewllhaimapsgxrbhjjfcxzmykwgbtysesutaz
 * Smoking Wheels....  was here 2017 lopjdzrsoqyizgfghjlentrbngtygutbujaidwkutpmnxhlu
 * Smoking Wheels....  was here 2017 tvkmzyadxxpkqmocuywybnfyzfhozrqprnkqltrpeoutjhbp
 * Smoking Wheels....  was here 2017 jhdshbsolbiolxvcljbnnxxxqiurlxkyvmnuiaeuzifbiaud
 * Smoking Wheels....  was here 2017 ggbiiethsoyfhqsqkilnkczmfliwrvzuqebondkfgwaiedtj
 * Smoking Wheels....  was here 2017 mjqvpmjynepyhwcmeqsqkoanwlgadyncvrazatevhlwsmhjm
 * Smoking Wheels....  was here 2017 pmozwleizvnrufdnikvxowubwpdhkbkahjqgcumcrnopeqhy
 * Smoking Wheels....  was here 2017 fruubqxmjuknlmgzxzbpbzimtkvbjghchvizfkpmevfoilkl
 * Smoking Wheels....  was here 2017 hioombotfnbxdqbibyvemcwiiplzdtcyexwvdabwvhdojfxy
 * Smoking Wheels....  was here 2017 aajspvmtiunlybmfefwlmpzlscgycczorsdxwiriagxsvtdp
 * Smoking Wheels....  was here 2017 vqwcekdfvnfagfrqzvdldekvdfyavehcsqkkpfldhcljrduw
 * Smoking Wheels....  was here 2017 kgarfljhzyrusyatlfvjrsfxgjgrgxtbmgdvxwrykptfyptn
 * Smoking Wheels....  was here 2017 rgctyvdiiptcdhebrxltokrftiinmrfckkbzmrvnlsfdctfl
 * Smoking Wheels....  was here 2017 ugouwtsuseoqsncfduskorgouanlvzweefcwijsysskfrjnv
 * Smoking Wheels....  was here 2017 gbbotrsperkftewenangreuaqtkozrbnrbmtrukoubewoljd
 * Smoking Wheels....  was here 2017 rvqcnevuahwbycxdtweqdviywyugvsmoenrdcddyllqtyipc
 * Smoking Wheels....  was here 2017 bwlrngdsvovmcgwpzybalvcxhjvfklbaalktgwkxuxbtdolq
 * Smoking Wheels....  was here 2017 ovzteawxkejejarfseyfinprxyugdjxuzyqrepancqcztxgy
 * Smoking Wheels....  was here 2017 onyegxpfucvacwlxpqtdvqskczipqilcykoccgbcydovrksl
 * Smoking Wheels....  was here 2017 vcivtqbshpucxqqyoqteecjikxfnujhkbjrpoasfccoyajsx
 * Smoking Wheels....  was here 2017 gxhcxbismdbvsjvsvwjsvaxcplpusskkvtrwghotqokffijg
 * Smoking Wheels....  was here 2017 amjlgiqueluxpizytcipowunupvetzwbxqnzetjsxssuucdr
 * Smoking Wheels....  was here 2017 oufpmyoukngczbgpbmpvkhwqgqkwoxeofjkeqidllbiassqp
 * Smoking Wheels....  was here 2017 owvqpnvumocqkjzvsikrngdvoyhhzpxiyowzbefobiioalut
 * Smoking Wheels....  was here 2017 zbltxzmbabdxuiwdwiepmvvpmjmzdhycocodftbvumahcvsc
 * Smoking Wheels....  was here 2017 zamnvmuftummgevfygqkamovduiykonuramqcqliytaipsvu
 * Smoking Wheels....  was here 2017 zorremicurlhdmyzqhubcxbovmlflezqhtvtzvlkcqfdkcvh
 * Smoking Wheels....  was here 2017 rvzfwpvtkyqmdasqwsuxzaidbxsfbfabowbbiliqbwqhphoi
 * Smoking Wheels....  was here 2017 adpkfuinedwkawsqwdejeyrdsvdplxntxfxfwypwxjqrovfw
 * Smoking Wheels....  was here 2017 dcbusfcyxygtzhwsamphldqjuecgxwpsbxiirzbcxlulxnea
 * Smoking Wheels....  was here 2017 opacbhswridikwiububpsfzxpgehbwscxhnpxlssqozzojci
 * Smoking Wheels....  was here 2017 wtljhqwktncivinbvltqhetctmgdwxmjqzyncnwhxlgxoswl
 * Smoking Wheels....  was here 2017 bwovqgqusbydfubyqbdwrdelzpjjiiueswjyaraquazdibri
 * Smoking Wheels....  was here 2017 howzpgirjqvjpmxfumzaonvwkpwxxrvouzsuqmyuopsumfwe
 * Smoking Wheels....  was here 2017 araqxckwufbylzdubuefzzlkisjxfsarvtfkeyrdvqjgwfdk
 * Smoking Wheels....  was here 2017 xjaupkrlhbgyhcfvjjzpemcjhkrtbmyyzsifeenfivyeqkku
 * Smoking Wheels....  was here 2017 xzbswcerkqevbutvvvvtqdbickxaqhodrutajqzweevldgtf
 * Smoking Wheels....  was here 2017 ecqwgkefyqzewmqmzzmkdkvcvtkrgsadqamvtzvdrypeaprx
 * Smoking Wheels....  was here 2017 eokbmrewydawbpctlzwpqyeutpsuomrdtvsyncckjoctclti
 * Smoking Wheels....  was here 2017 omkhopzqugvcgzmudefokretmlsulrgqguyugecebulwodxd
 * Smoking Wheels....  was here 2017 hgvvscqyyohfirlbhdavxtblubniaooiotvfrqhivpyitehi
 * Smoking Wheels....  was here 2017 olcelikhhtlwlzxgiuxdypkvtkkgqswciujetdmxzfeihjib
 * Smoking Wheels....  was here 2017 tyzcntuowusxylzjxeynlwywqrasyxlgmitzsqsgbczfauqu
 * Smoking Wheels....  was here 2017 pvkpxzotzxpnlvdpzqhgsmsybjecuebdhymcdghyxbnrdrdg
 * Smoking Wheels....  was here 2017 zlqywzvhepzbvezisvkvfrzqugyahwoncmghrkrunzaoypaj
 * Smoking Wheels....  was here 2017 dkbqxwtqgqzeeukhppazrthtxhrkvlchpabpkurvgeezbipi
 * Smoking Wheels....  was here 2017 mplmtcyshxxtxgomfbcudmljsrzjbtcsuzbgnhhmqbtjkzpp
 * Smoking Wheels....  was here 2017 rculkieopsiyqhxapnvlwslutysiuvffuytundwfnjxjbtww
 * Smoking Wheels....  was here 2017 shfudmlmtnccfaakwptmgqnpwuxweyhlaswyerwyydxvkgqc
 * Smoking Wheels....  was here 2017 ssgbksabnbixtrwinfnseshqbeyxprolgmjulpcreojycffm
 * Smoking Wheels....  was here 2017 dhpzzmmczhifruotdkcbnnmzsjkoqujiinknqwpuwcdaytil
 * Smoking Wheels....  was here 2017 qcfovjotlmsdofnvtnswpbcyiwdgfijpnnnreopusniscdwt
 * Smoking Wheels....  was here 2017 fnidfjhglcidhykbnfvpwmmctifpkpnxegkzwfrowugzywyg
 * Smoking Wheels....  was here 2017 zdkdrqyfvvfuzibdvieacechavzmqdxgzxznrjoepcnwcuzg
 * Smoking Wheels....  was here 2017 ludixpbmrstzavsylyreguuolnabmszvytonvbiylaxvkxqd
 * Smoking Wheels....  was here 2017 fpnuxwlcfyowzhtuflphqinfoxfrvljaflmmwjfkgfpmaoup
 * Smoking Wheels....  was here 2017 gxssxkbkbzkvutuajljwswoxfspzunyqevodntulbrwshfqq
 * Smoking Wheels....  was here 2017 ujgqlkgyzqlnontkjtssfwnjlynxtoynpatouwuceqipwtok
 * Smoking Wheels....  was here 2017 euvigfmocvzvqcvwvmpveactpvpniiryjjfawqgreouqoefj
 * Smoking Wheels....  was here 2017 dhkuiopjrupwqhipsaglueiievqhjwwhqllyifmuvfkjotmg
 * Smoking Wheels....  was here 2017 pfehyioqhbdameabfzdcpposarttamkixedexbzggomteboy
 * Smoking Wheels....  was here 2017 uepinsrysgsygasyteynipfseihxrskzupirnundsupwcxur
 * Smoking Wheels....  was here 2017 bblrwdmdbmrniiofbtquzxejybvuxjhlhddtnjeuumoddhwy
 * Smoking Wheels....  was here 2017 dyqiyfthpwowizbbzalculkbxjevplsdoicwixdtggoelnrj
 * Smoking Wheels....  was here 2017 zejpaxnsxygkcytyuqwzgjeiwxmrxgouabxuswavfevwkdjy
 * Smoking Wheels....  was here 2017 tjexpjazulvtvnpnwkofdcaawsbfdjajjkmprxndylakpyjw
 * Smoking Wheels....  was here 2017 wjrdkavyhipuvituxlnulhtegamozombnuclmytzanzcxzho
 * Smoking Wheels....  was here 2017 ahyelorqswfrsbpxvdyzjwkdngqdgwohrtfypeyygdtpmoct
 * Smoking Wheels....  was here 2017 encjzwqkqmmtkuujvcihlzemofoncpfuhfnutypwrhsvqewk
 * Smoking Wheels....  was here 2017 lprfmczvxymszwgvjdimlcraiwpqxgomaeaazzouqgkybrbr
 * Smoking Wheels....  was here 2017 iljlrsfsmfokwtdgckzphvqwgjjphraoucwxnfuarktgpbha
 * Smoking Wheels....  was here 2017 mdccpjdduohzpiuwyfmvhdchuhrwcxfnuooywtqfootljqmd
 * Smoking Wheels....  was here 2017 wadknytlhkovdnxcceguxeixuirzlecamjvxtbockrukszua
 * Smoking Wheels....  was here 2017 qsyxwrjevnlootkqaeadxjwnimqwtduanrqufujvnzmghvpv
 * Smoking Wheels....  was here 2017 fbejkxmemwgcflkljhuyhjnfryerpmrsvvewkvbrkyqjzgoa
 * Smoking Wheels....  was here 2017 iewuejwnnrpotmiscxtlhcghkfduwhloqlxqykygyiikwnph
 * Smoking Wheels....  was here 2017 wlfljxooolhibwuxjojeksjjjapvrvzgiiowmxoidbxhigwp
 * Smoking Wheels....  was here 2017 bkqvnuwvjwmbfxtspfjxjqkgoixskslsqqcpbarbikzbadtd
 * Smoking Wheels....  was here 2017 hyxrjjhdzzlpqdjbnxspfodzilrnqrfflssbxphrbwkfuhxj
 * Smoking Wheels....  was here 2017 gfzbwhpptyudxiyfazpodkpxftrritydydytnxrvdcfhtzfy
 * Smoking Wheels....  was here 2017 xmbfinvnfikaxognicmhrhbqaacvmhpfpvkmqhkhqeuggtww
 * Smoking Wheels....  was here 2017 llpqfggmeuiytcduvbdnnrayufewpugkcvdfhlgewhsezjgi
 * Smoking Wheels....  was here 2017 gwhcgvlisixsvnswgzmitgixxppwfbiwimigsheuiwumtyat
 * Smoking Wheels....  was here 2017 ayeqmyccdfsntpmbnfsxowywwqdhecnbmllbjyorxsevssbw
 * Smoking Wheels....  was here 2017 tyklcnhczwqskjzsukiulsdkmbxtshrsbpflbxvsqudbgfop
 * Smoking Wheels....  was here 2017 oomdrthzcaszxdfpnkbtegmjvvfcccztqyojsvvyviihyhwd
 * Smoking Wheels....  was here 2017 wocjwbrmmsidpkhqjgvvscttefsnzivkgysdpoosauozrysz
 * Smoking Wheels....  was here 2017 kdffsbctmdbkdapahjwfifyydrejgbwbaceggihoaxytpmxu
 * Smoking Wheels....  was here 2017 cpbymrsarttcjaugmjqmnsjmnxthaoamkjqmkopjxrtkakrm
 * Smoking Wheels....  was here 2017 dncbqdtzvilxlruyiawjabngiyteqjkobubvaxedzhrfqpji
 * Smoking Wheels....  was here 2017 xubgyusjzvorrntconnxvxfgxztethloztqojgdguhmlhart
 * Smoking Wheels....  was here 2017 eowqjikhnmpotjbxceuheekwvoqqgjuwhwwexusgejgubaml
 * Smoking Wheels....  was here 2017 uctlfsvbztmynhjvdqdcpampwilgfxifkymllzkzenkdjcyi
 * Smoking Wheels....  was here 2017 ybfdxbigckgmbnpnbsicuxwjchnvakgocdjjylbnczlpvclr
 * Smoking Wheels....  was here 2017 dixnfuisalgauqxzqmhgvlkevsnphrxcftvfrbqdmegphzrw
 * Smoking Wheels....  was here 2017 zywpepsnaabtjkqkskgwwocjqbfwxuzgzlhmccmmexxtxdnp
 * Smoking Wheels....  was here 2017 mhgqzjkyqqpzoxnfnzqkllfnhbriaajswbmzzxbifdtyaadw
 * Smoking Wheels....  was here 2017 tzneehupscvlokkdmdfrimilwrivyxgmmririefuxbkhhnxw
 * Smoking Wheels....  was here 2017 gvlxmuhhihfytllbhyyrmkdgsdrnhfztuqbviuwdufqfnona
 * Smoking Wheels....  was here 2017 raywwnudsmgrsvchwtzrdbsfiyqvabgyyqezoykzsgpjwnva
 * Smoking Wheels....  was here 2017 zwgjqkfkmevaiqyejfwdvqjyovgherxtlkjwscidtgqotyaw
 * Smoking Wheels....  was here 2017 hyvwgqxskbaosbymhcgwhpogktwxdqedyepnvvjsdjhaspms
 * Smoking Wheels....  was here 2017 bejdlojwpddfgtfchpexnodfhzbtoskhjfcfcdozmckbrmwa
 * Smoking Wheels....  was here 2017 zpwffyjxiqvdoldhhatltlbeqysfhyhrxdhkbdgnpedjszcm
 * Smoking Wheels....  was here 2017 zpniwpyfebxsmfllmznbmlqrjlwylqrazvyxkhwfnptugoib
 * Smoking Wheels....  was here 2017 huvzvukjycmofhyihjflmykomjxvliufgjzsffhbpowmwcxx
 * Smoking Wheels....  was here 2017 gzlzwwfdrtwpahwvkfsrsrdwhajzvvzmtdqbrwlkipivmnoo
 * Smoking Wheels....  was here 2017 qjjiznfqrgqxqzoetyizlmwzjvdvnewgotjnhkswokfmefcr
 * Smoking Wheels....  was here 2017 ifvgkrkdnbrxvksuodlweovknphyqqlhdaxuvgnfiywiisue
 * Smoking Wheels....  was here 2017 nfhhrnahayafuvfleqvdqipbufehnuvmfbeygbsozmwmotyg
 * Smoking Wheels....  was here 2017 qdlfmkrwfvbtxvezjoktvmxxmzjzvkjaqglewthfbmciskgl
 * Smoking Wheels....  was here 2017 jcgzwbbzlajrsecragkzzxwjfisjknukreebcmosirpnzapj
 * Smoking Wheels....  was here 2017 rnyybkhxgyuhdynzijijqtqzsbhdklyhtsahssayxatyrbez
 */
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.kelondro.util.MapTools;
import net.yacy.peers.NewsDB;
import net.yacy.peers.NewsPool;
import net.yacy.peers.PeerActions;
import net.yacy.peers.Protocol;
import net.yacy.peers.Seed;
import net.yacy.peers.operation.yacyVersion;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.server.servletProperties;
public class Network {
private static final String STR_TABLE_LIST = "table_list_";
public static serverObjects respond(final RequestHeader requestHeader, final serverObjects post, final serverSwitch switchboard) {
final Switchboard sb = (Switchboard) switchboard;
final long start = System.currentTimeMillis();
final servletProperties prop = new servletProperties();
prop.put("menu", post == null ? 2 : (post.get("menu", "").equals("embed")) ? 0 : (post.get("menu","").equals("simple")) ? 1 : 2);
        if (sb.peers.mySeed() != null) prop.put("menu_newpeer_peerhash", sb.peers.mySeed().hash);
prop.setLocalized(!requestHeader.getPathInfo().endsWith(".xml"));
prop.putHTML("page_networkTitle", sb.getConfig("network.unit.description", "unspecified"));
prop.putHTML("page_networkName", sb.getConfig(SwitchboardConstants.NETWORK_NAME, "unspecified"));
final boolean overview = (post == null) || (post.get("page", "0").equals("0"));
final String mySeedType = sb.peers.mySeed().get(Seed.PEERTYPE, Seed.PEERTYPE_VIRGIN);
final boolean iAmActive = (mySeedType.equals(Seed.PEERTYPE_SENIOR) || mySeedType.equals(Seed.PEERTYPE_PRINCIPAL));
        if (overview) {
long accActLinks = sb.peers.countActiveURL();
long accActWords = sb.peers.countActiveRWI();
final long accPassLinks = sb.peers.countPassiveURL();
final long accPassWords = sb.peers.countPassiveRWI();
long accPotLinks = sb.peers.countPotentialURL();
long accPotWords = sb.peers.countPotentialRWI();
int conCount = sb.peers.sizeConnected();
final int disconCount = sb.peers.sizeDisconnected();
int potCount = sb.peers.sizePotential();
final long otherppm = sb.peers.countActivePPM();
final double otherqpm = sb.peers.countActiveQPM();
long myppm = 0;
double myqph = 0d;
final Seed seed = sb.peers.mySeed();
if (sb.peers.mySeed() != null){
sb.updateMySeed();
final long LCount = seed.getLinkCount();
final long ICount = seed.getWordCount();
final long RCount = seed.getLong(Seed.RCOUNT, 0L);
prop.putHTML("table_my-name", seed.get(Seed.NAME, "-") );
prop.put("table_my-hash", seed.hash );
prop.put("table_my-ssl", sb.peers.mySeed().getFlagSSLAvailable() ? 1 : 0);
if (seed.isVirgin()) {
prop.put("table_my-info", 0);
} else if (seed.isJunior()) {
prop.put("table_my-info", 1);
accPotLinks += LCount;
accPotWords += ICount;
} else if (seed.isSenior()) {
prop.put("table_my-info", 2);
accActLinks += LCount;
accActWords += ICount;
} else if (seed.isPrincipal()) {
prop.put("table_my-info", 3);
accActLinks += LCount;
accActWords += ICount;
}
String port = seed.get(Seed.PORT, "-");
Set<String> ips = seed.getIPs();
int ipsc = 0;
for (String s: ips) {
prop.put("table_ips_" + ipsc + "_nodestate", seed.getFlagRootNode() ? 1 : 0);
prop.put("table_ips_" + ipsc + "_c", 0);
prop.putHTML("table_ips_" + ipsc + "_c_hash", seed.hash);
prop.putHTML("table_ips_" + ipsc + "_c_ip", s);
prop.putHTML("table_ips_" + ipsc + "_c_port", port);
prop.put("table_ips_" + ipsc++ + "_c_ipv6", s.indexOf(':') >= 0 ? 1 : 0);
}
prop.put("table_ips", ipsc);
prop.put("table_my-acceptcrawl", seed.getFlagAcceptRemoteCrawl() ? 1 : 0);
prop.put("table_my-dhtreceive", seed.getFlagAcceptRemoteIndex() ? 1 : 0);
prop.put("table_my-nodestate", seed.getFlagRootNode() ? 1 : 0);
myppm = Switchboard.currentPPM();
myqph = 60d * sb.averageQPM();
prop.put("table_my-version", seed.get(Seed.VERSION, "-"));
prop.put("table_my-utc", seed.get(Seed.UTC, "-"));
prop.put("table_my-uptime", PeerActions.formatInterval(60000 * seed.getLong(Seed.UPTIME, 0)));
prop.putNum("table_my-LCount", LCount);
prop.putNum("table_my-ICount", ICount);
prop.putNum("table_my-RCount", RCount);
prop.putNum("table_my-sI", seed.getLong(Seed.INDEX_OUT, 0L));
prop.putNum("table_my-sU", seed.getLong(Seed.URL_OUT, 0L));
prop.putNum("table_my-rI", seed.getLong(Seed.INDEX_IN, 0L));
prop.putNum("table_my-rU", seed.getLong(Seed.URL_IN, 0L));
prop.putNum("table_my-ppm", myppm);
prop.putNum("table_my-qph", Math.round(100d * myqph) / 100d);
prop.putNum("table_my-qph-publocal", Math.round(6000d * sb.averageQPMPublicLocal()) / 100d);
prop.putNum("table_my-qph-pubremote", Math.round(6000d * sb.averageQPMGlobal()) / 100d);
prop.putNum("table_my-seeds", seed.getLong(Seed.SCOUNT, 0L));
prop.putNum("table_my-connects", seed.getFloat(Seed.CCOUNT, 0F));
prop.put("table_my-url", seed.get(Seed.SEEDLISTURL, ""));
prop.putHTML("table_my-location", ClientIdentification.generateLocation());
}
if (iAmActive) conCount++; else if (mySeedType.equals(Seed.PEERTYPE_JUNIOR)) potCount++;
final int activeLastMonth = sb.peers.sizeActiveSince(30 * 1440);
final int activeLastWeek = sb.peers.sizeActiveSince(7 * 1440);
final int activeLastDay = sb.peers.sizeActiveSince(1440);
final int activeLastHour = sb.peers.sizeActiveSince(60);
final int activeSwitch =
(activeLastHour <= conCount) ? 0 :
(activeLastDay <= activeLastHour) ? 1 :
(activeLastWeek <= activeLastDay) ? 2 :
(activeLastMonth <= activeLastWeek) ? 3 : 4;
prop.putNum("table_active-switch", activeSwitch);
prop.putNum("table_active-switch_last-month", activeLastMonth);
prop.putNum("table_active-switch_last-week", activeLastWeek);
prop.putNum("table_active-switch_last-day", activeLastDay);
prop.putNum("table_active-switch_last-hour", activeLastHour);
prop.putNum("table_active-count", conCount);
prop.putNum("table_active-links", accActLinks);
prop.putNum("table_active-words", accActWords);
prop.putNum("table_passive-count", disconCount);
prop.putNum("table_passive-links", accPassLinks);
prop.putNum("table_passive-words", accPassWords);
prop.putNum("table_potential-count", potCount);
prop.putNum("table_potential-links", accPotLinks);
prop.putNum("table_potential-words", accPotWords);
prop.putNum("table_all-count", conCount + disconCount + potCount);
prop.putNum("table_all-links", accActLinks + accPassLinks + accPotLinks);
prop.putNum("table_all-words", accActWords + accPassWords + accPotWords);
prop.putNum("table_gppm", otherppm + ((iAmActive) ? myppm : 0));
prop.putNum("table_gqph", Math.round(6000d * otherqpm + 100d * ((iAmActive) ? myqph : 0d)) / 100d);
prop.put("table", 2);
prop.put("page", 0);
} else if (post != null && post.getInt("page", 1) == 4) {
prop.put("table", 4);
prop.put("page", 4);
if (sb.peers.mySeed() != null) {
	            prop.put("table_my-hash", sb.peers.mySeed().hash );
	            prop.put("table_my-ip", sb.peers.mySeed().getIPs().toString());
	            prop.put("table_my-port", sb.peers.mySeed().getPort() );
}
if (post.containsKey("addPeer")) {
final int authentication = sb.adminAuthenticated(requestHeader);
if (authentication < 2) {
prop.authenticationRequired();
return prop;
}
final ConcurrentMap<String, String> map = new ConcurrentHashMap<String, String>();
String challengeIP = post.get("peerIP");
String challengePort = post.get("peerPort");
map.put(Seed.IP, challengeIP);
map.put(Seed.PORT, challengePort);
Seed peer = post.get("peerHash") == null ? null : new Seed(post.get("peerHash"), map);
String challengeAddress = peer.getPublicAddress(challengeIP);
sb.updateMySeed();
Seed mySeed = sb.peers.mySeed();
final Map<String, String> response = Protocol.hello(mySeed, sb.peers.peerActions, challengeAddress, peer.hash);
if (response == null) {
Seed peerd = sb.peers.get(peer.hash);
if (peerd != null) peer = peerd;
sb.peers.peerActions.interfaceDeparture(peer, challengeIP);
prop.put("table_comment",1);
prop.put("table_comment_status", "publish: no response from peer '" + peer.getName() + "/" + post.get("peerHash") + "' from <a href=\"http://" + challengeAddress + "\" target=\"_blank\">" + challengeAddress + "</a>");
} else {
String yourtype = response.get("yourtype");
String yourip = response.get("yourip");
peer = sb.peers.getConnected(peer.hash);
if (peer == null) {
prop.put("table_comment",1);
prop.put("table_comment_status","publish: disconnected peer 'UNKNOWN/" + post.get("peerHash") + "' from <a href=\"http://" + challengeAddress + "\" target=\"_blank\">" + challengeAddress + "</a>, yourtype = " + yourtype + ", yourip = " + yourip);
} else {
prop.put("table_comment",2);
prop.put("table_comment_status","publish: handshaked " + peer.get(Seed.PEERTYPE, Seed.PEERTYPE_SENIOR) + " peer '" + peer.getName() + "' at <a href=\"http://" + challengeAddress + "\" target=\"_blank\">" + challengeAddress + "</a>, yourtype = " + yourtype + ", yourip = " + yourip);
prop.putHTML("table_comment_details",peer.toString());
}
}
prop.putHTML("table_peerHash",post.get("peerHash"));
prop.putHTML("table_peerIP",post.get("peerIP"));
prop.putHTML("table_peerPort",post.get("peerPort"));
} else {
prop.put("table_peerHash","");
prop.put("table_peerIP","");
prop.put("table_peerPort","");
prop.put("table_comment",0);
}
} else if (post != null && post.getInt("page", 1) == 5) {
prop.put("page", 5);
prop.put("table", 5);
} else {
final int page = (post == null ? 1 : post.getInt("page", 1));
final int maxCount = (post == null ? 9000 : post.getInt("maxCount", 9000));
int conCount = 0;
if (sb.peers == null) {
prop.put("table", 0);//no remote senior/principal proxies known"
} else {
int size = 0;
switch (page) {
case 1 : size = sb.peers.sizeConnected(); break;
case 2 : size = sb.peers.sizeDisconnected(); break;
case 3 : size = sb.peers.sizePotential(); break;
default: break;
}
if (size == 0) {
prop.put("table", 0);//no remote senior/principal proxies known"
} else {
if (iAmActive) {
sb.updateMySeed();
sb.peers.addConnected(sb.peers.mySeed());
}
final HashSet<String> updatedProfile = new HashSet<String>();
final HashMap<String, Map<String, String>> updatedWiki = new HashMap<String, Map<String, String>>();
final HashMap<String, Map<String, String>> updatedBlog = new HashMap<String, Map<String, String>>();
final HashMap<String, String> isCrawling = new HashMap<String, String>();
NewsDB.Record record;
final Iterator<NewsDB.Record> recordIterator = sb.peers.newsPool.recordIterator(NewsPool.INCOMING_DB);
while (recordIterator.hasNext()) {
record = recordIterator.next();
if (record == null) {
continue;
} else if (record.category().equals(NewsPool.CATEGORY_PROFILE_UPDATE)) {
updatedProfile.add(record.originator());
} else if (record.category().equals(NewsPool.CATEGORY_WIKI_UPDATE)) {
updatedWiki.put(record.originator(), record.attributes());
} else if (record.category().equals(NewsPool.CATEGORY_BLOG_ADD)) {
updatedBlog.put(record.originator(), record.attributes());
} else if (record.category().equals(NewsPool.CATEGORY_CRAWL_START)) {
isCrawling.put(record.originator(), record.attributes().get("startURL"));
}
}
boolean dark = true;
Seed seed;
final boolean c = (post != null && post.containsKey("ip"));
final boolean onlyIncomingDHT = (post != null && post.containsKey("onlydhtin"));
final boolean onlyNode = (post != null && post.containsKey("onlynode"));
final long onlyAgeOverDays = post == null ? 0 : post.getLong("onlyageoverdays", 0);
final long onlySizeLessDocs = post == null ? Long.MAX_VALUE : post.getLong("onlysizelessdocs", Long.MAX_VALUE);
Iterator<Seed> e = null;
final boolean order = (post != null && post.get("order", "down").equals("up"));
final String sort = (post == null ? null : post.get("sort", null));
switch (page) {
case 1 : e = sb.peers.seedsSortedConnected(order, (sort == null ? Seed.LCOUNT : sort)); break;
case 2 : e = sb.peers.seedsSortedDisconnected(order, (sort == null ? Seed.LASTSEEN : sort)); break;
case 3 : e = sb.peers.seedsSortedPotential(order, (sort == null ? Seed.LASTSEEN : sort)); break;
default: break;
}
String startURL;
Map<String, String> wikiMap;
Map<String, String> blogMap;
String userAgent, location;
int PPM;
double QPM;
Pattern peerSearchPattern = null;
prop.put("regexerror", 0);
prop.put("regexerror_wrongregex", (String)null);
if (post != null && post.containsKey("search")) {
try {
peerSearchPattern = Pattern.compile(post.get("match", ""), Pattern.CASE_INSENSITIVE);
} catch (final PatternSyntaxException pse){
prop.put("regexerror", 1);
prop.putHTML("regexerror_wrongregex", pse.getPattern());
}
}
if (e != null) {
while (e.hasNext() && conCount < maxCount) {
seed = e.next();
assert seed != null;
if (seed != null) {
if (onlyIncomingDHT && !seed.getFlagAcceptRemoteIndex()) continue;
if (onlyNode && !seed.getFlagRootNode()) continue;
if (seed.getAge() < onlyAgeOverDays) continue;
if (seed.getLinkCount() > onlySizeLessDocs) continue;
if((post != null && post.containsKey("search"))  && peerSearchPattern != null /*(wrongregex == null)*/) {
boolean abort = true;
Matcher m = peerSearchPattern.matcher (seed.getName());
if (m.find ()) {
abort = false;
}
m = peerSearchPattern.matcher (seed.hash);
if (m.find ()) {
abort = false;
}
if (abort) continue;
}
prop.put(STR_TABLE_LIST + conCount + "_updatedProfile", 0);
prop.put(STR_TABLE_LIST + conCount + "_updatedWikiPage", 0);
prop.put(STR_TABLE_LIST + conCount + "_updatedBlog", 0);
prop.put(STR_TABLE_LIST + conCount + "_isCrawling", 0);
String ip = seed.getIP();
if (conCount >= maxCount) { break; }
if (sb.peers != null && sb.peers.mySeed() != null && seed.hash != null && seed.hash.equals(sb.peers.mySeed().hash)) {
prop.put(STR_TABLE_LIST + conCount + "_dark", 2);
} else {
prop.put(STR_TABLE_LIST + conCount + "_dark", ((dark) ? 1 : 0) ); dark=!dark;
}
if (updatedProfile.contains(seed.hash)) {
prop.put(STR_TABLE_LIST + conCount + "_updatedProfile", 1);
prop.put(STR_TABLE_LIST + conCount + "_updatedProfile_hash", seed.hash);
}
if ((wikiMap = updatedWiki.get(seed.hash)) == null) {
prop.put(STR_TABLE_LIST + conCount + "_updatedWiki", 0);
} else {
prop.put(STR_TABLE_LIST + conCount + "_updatedWiki", 1);
prop.putHTML(STR_TABLE_LIST + conCount + "_updatedWiki_page", wikiMap.get("page"));
prop.put(STR_TABLE_LIST + conCount + "_updatedWiki_address", seed.getPublicAddress(ip));
}
if ((blogMap = updatedBlog.get(seed.hash)) == null) {
prop.put(STR_TABLE_LIST + conCount + "_updatedBlog", 0);
} else {
prop.put(STR_TABLE_LIST + conCount + "_updatedBlog", 1);
prop.putHTML(STR_TABLE_LIST + conCount + "_updatedBlog_page", blogMap.get("page"));
prop.putHTML(STR_TABLE_LIST + conCount + "_updatedBlog_subject", blogMap.get("subject"));
prop.put(STR_TABLE_LIST + conCount + "_updatedBlog_address", seed.getPublicAddress(ip));
}
PPM = seed.getPPM();
QPM = seed.getQPM();
if (((startURL = isCrawling.get(seed.hash)) != null) && (PPM >= 4)) {
prop.put(STR_TABLE_LIST + conCount + "_isCrawling", 1);
prop.put(STR_TABLE_LIST + conCount + "_isCrawling_page", startURL);
}
prop.put(STR_TABLE_LIST + conCount + "_hash", seed.hash);
String shortname = seed.get(Seed.NAME, "deadlink");
if (shortname.length() > 20) {
shortname = shortname.substring(0, 20) + "...";
}
prop.putHTML(STR_TABLE_LIST + conCount + "_shortname", shortname);
prop.putHTML(STR_TABLE_LIST + conCount + "_fullname", seed.get(Seed.NAME, "deadlink"));
prop.put(STR_TABLE_LIST + conCount + "_special", (seed.getFlagRootNode() && !seed.getFlagAcceptRemoteIndex()) ? 1 : 0);
prop.put(STR_TABLE_LIST + conCount + "_ssl", (seed.getFlagSSLAvailable()) ? 1 : 0);
prop.put(STR_TABLE_LIST + conCount + "_ssl_ip", seed.getIP());
prop.put(STR_TABLE_LIST + conCount + "_ssl_portssl", seed.get(Seed.PORTSSL,"8443"));
userAgent = null;
if (seed.hash != null && seed.hash.equals(sb.peers.mySeed().hash)) {
userAgent = ClientIdentification.yacyInternetCrawlerAgent.userAgent;
location = ClientIdentification.generateLocation();
} else {
userAgent = sb.peers.peerActions.getUserAgent(ip);
location = ClientIdentification.parseLocationInUserAgent(userAgent);
}
if (location.length() > 10) location = location.substring(0, 10);
if (location.length() == 0) {
Locale l = Domains.getLocale(ip);
if (l != null) location = l.toString();
}
prop.putHTML(STR_TABLE_LIST + conCount + "_location", location);
String port = seed.get(Seed.PORT, "-");
Set<String> ips = seed.getIPs();
int ipsc = 0;
for (String s: ips) {
prop.put(STR_TABLE_LIST + conCount + "_ips_" + ipsc + "_nodestate", seed.getFlagRootNode() ? 1 : 0);
prop.put(STR_TABLE_LIST + conCount + "_ips_" + ipsc + "_c", c ? 1 : 0);
prop.putHTML(STR_TABLE_LIST + conCount + "_ips_" + ipsc + "_c_hash", seed.hash);
prop.putHTML(STR_TABLE_LIST + conCount + "_ips_" + ipsc + "_c_ip", s);
prop.putHTML(STR_TABLE_LIST + conCount + "_ips_" + ipsc + "_c_port", port);
prop.put(STR_TABLE_LIST + conCount + "_ips_" + ipsc++ + "_c_ipv6", s.indexOf(':') >= 0 ? 1 : 0);
}
prop.put(STR_TABLE_LIST + conCount + "_ips", ipsc);
prop.put(STR_TABLE_LIST + conCount + "_port", port);
prop.put(STR_TABLE_LIST + conCount + "_hash", seed.hash);
prop.put(STR_TABLE_LIST + conCount + "_age", seed.getAge());
prop.putNum(STR_TABLE_LIST + conCount + "_seeds", seed.getLong(Seed.SCOUNT, 0L));
prop.putNum(STR_TABLE_LIST + conCount + "_connects", seed.getFloat(Seed.CCOUNT, 0F));
if (c) {
prop.put(STR_TABLE_LIST + conCount + "_c", 1);
prop.putHTML(STR_TABLE_LIST + conCount + "_c_userAgent", userAgent);
} else {
prop.put(STR_TABLE_LIST + conCount + "_c", 0);
}
if (seed.isJunior()) {
prop.put(STR_TABLE_LIST + conCount + "_type", 0);
} else if(seed.isSenior()){
prop.put(STR_TABLE_LIST + conCount + "_type", 1);
} else if(seed.isPrincipal()) {
prop.put(STR_TABLE_LIST + conCount + "_type", 2);
}
prop.putHTML(STR_TABLE_LIST + conCount + "_type_url", seed.get(Seed.SEEDLISTURL, "http://nowhere/"));
final long lastseen = Math.abs((System.currentTimeMillis() - seed.getLastSeenUTC()) / 1000 / 60);
if (page == 1 && lastseen > 720) {
	continue;
}
if (page == 2 || (page == 1 && lastseen > 360)) {
prop.put(STR_TABLE_LIST + conCount + "_type_direct", 2);
} else {
prop.put(STR_TABLE_LIST + conCount + "_type_direct", seed.getFlagDirectConnect() ? 1 : 0);
}
if (page == 1) {
prop.put(STR_TABLE_LIST + conCount + "_acceptcrawl", seed.getFlagAcceptRemoteCrawl() ? 1 : 0);
prop.put(STR_TABLE_LIST + conCount + "_dhtreceive", seed.getFlagAcceptRemoteIndex() ? 1 : 0);  // green=on or red=off
} else {
if (seed.getFlagAcceptRemoteCrawl()) {
prop.put(STR_TABLE_LIST + conCount + "_acceptcrawl", 2);
} else {
prop.put(STR_TABLE_LIST + conCount + "_acceptcrawl", 0);
}
if (seed.getFlagAcceptRemoteIndex()) {
prop.put(STR_TABLE_LIST + conCount + "_dhtreceive", 2);  // red/green: offline, was on
} else {
prop.put(STR_TABLE_LIST + conCount + "_dhtreceive", 0);  // red/red; offline was off
}
}
if (seed.getFlagAcceptRemoteIndex()) {
prop.put(STR_TABLE_LIST + conCount + "_dhtreceive_peertags", "");
} else {
final String peertags = MapTools.set2string(seed.getPeerTags(), ",", false);
prop.putHTML(STR_TABLE_LIST + conCount + "_dhtreceive_peertags", ((peertags == null) || (peertags.isEmpty())) ? "no tags given" : ("tags = " + peertags));
}
String[] yv = yacyVersion.combined2prettyVersion(seed.get(Seed.VERSION, "0.1"), shortname);
prop.putHTML(STR_TABLE_LIST + conCount + "_version", yv[0] + "/" + yv[1]);
prop.putNum(STR_TABLE_LIST + conCount + "_lastSeen", /*seed.getLastSeenString() + " " +*/ lastseen);
prop.put(STR_TABLE_LIST + conCount + "_utc", seed.get(Seed.UTC, "-"));
prop.putHTML(STR_TABLE_LIST + conCount + "_uptime", PeerActions.formatInterval(60000 * seed.getLong(Seed.UPTIME, 0)));
prop.putNum(STR_TABLE_LIST + conCount + "_LCount", seed.getLinkCount());
prop.putNum(STR_TABLE_LIST + conCount + "_ICount", seed.getWordCount());
prop.putNum(STR_TABLE_LIST + conCount + "_RCount", seed.getLong(Seed.RCOUNT, 0));
prop.putNum(STR_TABLE_LIST + conCount + "_sI", seed.getLong(Seed.INDEX_OUT, 0));
prop.putNum(STR_TABLE_LIST + conCount + "_sU", seed.getLong(Seed.URL_OUT, 0));
prop.putNum(STR_TABLE_LIST + conCount + "_rI", seed.getLong(Seed.INDEX_IN, 0));
prop.putNum(STR_TABLE_LIST + conCount + "_rU", seed.getLong(Seed.URL_IN, 0));
prop.putNum(STR_TABLE_LIST + conCount + "_ppm", PPM);
prop.putNum(STR_TABLE_LIST + conCount + "_qph", Math.round(6000d * QPM) / 100d);
conCount++;
} // seed != null
} // while
}
if (iAmActive) { sb.peers.removeMySeed(); }
prop.put("table_list", conCount);
prop.put("table", 1);
prop.putNum("table_num", conCount);
prop.putNum("table_total", ((page == 1) && (iAmActive)) ? (size + 1) : size );
prop.put("table_c", ((c)? 1 : 0) );
}
}
prop.put("page", page);
prop.put("table_page", page);
prop.putHTML("table_searchpattern", (post == null ? "" : post.get("match", "")));
switch (page) {
case 1 : prop.putHTML("table_peertype", "senior/principal"); break;
case 2 : prop.putHTML("table_peertype", "senior/principal"); break;
case 3 : prop.putHTML("table_peertype", Seed.PEERTYPE_JUNIOR); break;
default: break;
}
}
prop.putNum("table_rt", System.currentTimeMillis() - start);
final String path = requestHeader.getPathInfo();
        if(path != null && path.endsWith(".xml")) {
final ResponseHeader outgoingHeader = new ResponseHeader(200);
		outgoingHeader.put(HeaderFramework.CORS_ALLOW_ORIGIN, "*");
		prop.setOutgoingHeader(outgoingHeader);        	
}
return prop;
}
}
