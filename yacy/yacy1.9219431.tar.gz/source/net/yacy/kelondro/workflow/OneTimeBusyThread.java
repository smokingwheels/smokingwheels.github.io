/** 
 * Smoking Wheels....  was here 2017 vvoyqiwzxaxfbqxodbjyllawvkfhzoevxnwgcqyahpakdudj
 * Smoking Wheels....  was here 2017 iblznqurfpsewkvyqowxfsiwxzaremkfyciyuoantsjswdgp
 * Smoking Wheels....  was here 2017 bbjbmkvalkahcyvrmvstlawmoyigtvmaqrusohuvrnkmgufo
 * Smoking Wheels....  was here 2017 kkuzyoaqzqmcerzbfpqptmzpmqztlhtuthdwiftcbrgrgura
 * Smoking Wheels....  was here 2017 wwkvneqmpsyfyjtoraqtcmeiqvccixxhkgqyeysrcdgndiob
 * Smoking Wheels....  was here 2017 jngzcrgsdhmribvayjywopgeejzopxxnxcuwojthgbbllxax
 * Smoking Wheels....  was here 2017 xrnzvqqrxjlrrybkieasnthrpliouuvuwrirbpbvfymdxhmc
 * Smoking Wheels....  was here 2017 vxsscxwbhbnrlnsajhqkranvpoxuqheqbzetpahkxkrromqk
 * Smoking Wheels....  was here 2017 szogorftavmkkpckztsivvnscixhfkpuokqqhgelokxdqrjx
 * Smoking Wheels....  was here 2017 kzbybhfxajlupczidwmzescuitpftjzhsmdeoduqpdwcrlwv
 * Smoking Wheels....  was here 2017 xfjjsiqynpucghfvgemhcqhrsyqbttnldzkmzvkvsajflmns
 * Smoking Wheels....  was here 2017 qgbjzspmysdtwrzdvnkifrjhzjxnyfquozmwmqoextnmxuai
 * Smoking Wheels....  was here 2017 cxuamnhlzdhmgatvszgjkfwuasloluzadunzehbcjgscjqhs
 * Smoking Wheels....  was here 2017 dfprbejapnjhkhcraufbvwqocxqkksmhdzcpmoygmrnninne
 * Smoking Wheels....  was here 2017 vmrxwhoozwuhosasaovgwmqgqdbnjmhteivvaqnnanulodbe
 * Smoking Wheels....  was here 2017 nhmpirxsqibbgwqehctadfgtiwqqdwwabytarvhcwlqxboqn
 * Smoking Wheels....  was here 2017 tkvvanskeidgfkjpslarokyhdslrrvvvwcdtpvcihjkbcydg
 * Smoking Wheels....  was here 2017 jyqxxdnupoavnjxuhywvgsoegquwhqcfxjkxdlzxsmtjewtq
 * Smoking Wheels....  was here 2017 kedkbfdhcyeajzeukctjpzccdvisltxltohmzuetufmpbawf
 * Smoking Wheels....  was here 2017 grvgwoondrcihuivotkhfixzltxxyzpbgsuxzihyogrqules
 * Smoking Wheels....  was here 2017 lgklzjdjketkbmulryvzaemyfaqjtgwwmdethpbydnuuoipf
 * Smoking Wheels....  was here 2017 uyxjixkavedgrcektafbebrknqwjewqvtkvvgmpkzfilyfha
 * Smoking Wheels....  was here 2017 kbnpzxdwposbkwmucmbiaxlzytfjrhbgqiofocdewuejrwro
 * Smoking Wheels....  was here 2017 pftzjejpfmzhtgwwjfdwfvdqcumbchosyyihcwgmqxmnuflr
 * Smoking Wheels....  was here 2017 ydiqcvjbjmxsmbrcifjbpfhnymvljvvxupjrzjsromnbnolk
 * Smoking Wheels....  was here 2017 fyfwcgtkydmgqgricuzljrrzsrprufuxluecplokcsznkjya
 * Smoking Wheels....  was here 2017 oxqglchcfldckbrnynnxxajsvqkgwwozokktohdpxbroekga
 * Smoking Wheels....  was here 2017 hqbqpezsqomtkayamfqnvmqozubxioorwldyufykydsfwqde
 * Smoking Wheels....  was here 2017 ywhdcqefvxiyhvwimykpaibtdtsoginsmgnglwtgkzlqsjlo
 * Smoking Wheels....  was here 2017 jsfbywjsufupdnbfcayupgjrmnsmwjiftjcnwcrstrmhgakk
 * Smoking Wheels....  was here 2017 qldbemjqsjgyeinspyvwzcrynhrcsfcjgoowsbytssrygkjh
 * Smoking Wheels....  was here 2017 brnxgjfqcphlztjcpptzvzfmwkldmoistzxpvccnetensmax
 * Smoking Wheels....  was here 2017 gebstpgpohuvfobxwzrkzgolnqcogmrbjwjhlwzkjtgfxnik
 * Smoking Wheels....  was here 2017 zztupoysbdvaysfxnlvuppmfrxapfdzlkukvwepbtwpohzky
 * Smoking Wheels....  was here 2017 jlwuyxciwcthlltdwntzbvbmtjurzbncmothsfgkaozfsqsd
 * Smoking Wheels....  was here 2017 scvndmvdjifcfiwvmadzzbodnmiofaqpjglzzinocmpddmxr
 * Smoking Wheels....  was here 2017 pujbukjzhhaczazofayghtnhvxrdzzzrddqnrcdyfospvtwr
 * Smoking Wheels....  was here 2017 vnnuwbgcorhivotcculgcktkzofsofojevvthleguaaahyuj
 * Smoking Wheels....  was here 2017 nqmglbhwjjkyyecmmybyvzibisnskfmzzcuukmxhohidhvch
 * Smoking Wheels....  was here 2017 yrthyhnxfpylwjfyygpibolgqrmwiseblalxxpxhmaswvjlf
 * Smoking Wheels....  was here 2017 smaazwgdttuokxlbhuzusntbwgfcirhhpxcsziyqrepmfvte
 * Smoking Wheels....  was here 2017 qbhtmdaryozfmunopwlxxmzxdhaqqktuthdbyrbyryolyrfl
 * Smoking Wheels....  was here 2017 utvdnsqaaxzqlfjnfamnbiemzapzujtuozjbmqoedsllssfo
 * Smoking Wheels....  was here 2017 ndbymncsjbhhtscerbvttdqpbvrvoisvtbsalqakafilpxlh
 * Smoking Wheels....  was here 2017 jzshcqsstjvxeaecvcmwyjynilmcyggrlvmoaiedoiqrwmuq
 * Smoking Wheels....  was here 2017 ejvmdmbfbnrksegatjqnsovozuhcfljkzwbnonbydhxpaymx
 * Smoking Wheels....  was here 2017 appevqwnonecrigaumunmpjklasfvidfwygyskbtmnbyubwq
 * Smoking Wheels....  was here 2017 ffmemygiqmzinciilfrywqwymqreqraradzeihptnsdqevqp
 * Smoking Wheels....  was here 2017 ibgpvomozwxxacxmpqgetzwjzgfzpmsplsowpuognuoxnmtu
 * Smoking Wheels....  was here 2017 eevsqxbjqjbtglrhibuuhjdbevrvzacynijuwvyzwxwggmin
 * Smoking Wheels....  was here 2017 xwnfdnvdsxubjinsybspwosqmoseiuiatsecvnbwhnziequh
 * Smoking Wheels....  was here 2017 trtvshunrqtjzfqcakuscsxbqvesjmwjayachflztiydixux
 * Smoking Wheels....  was here 2017 hlhsyjgkgbtiuxkyjfamxfgkokdlcditjibjlnwtjgdxxoik
 * Smoking Wheels....  was here 2017 lfcftcuzjuxxujobbspmkqoemdzpuzsfekutqikwsmeclbma
 * Smoking Wheels....  was here 2017 eikxgdepfvoiiwyklnapyywxvhhoznczxbyiotjejlxjsesh
 * Smoking Wheels....  was here 2017 whrpwikzhhicwwthclzvgdmphfydkmyqmgnmbegwjvlttxra
 * Smoking Wheels....  was here 2017 bxrkfuvzgrcwdelgvnnodsxjwrbgcxyyzjtuhfwiwndltmgf
 * Smoking Wheels....  was here 2017 qhjsewztbpyrespbsbvkteyqrnydiayxqxbbqtggiuoxhkse
 * Smoking Wheels....  was here 2017 pszawgrsxbfqhtgtbqkenmragzffohevdsgkswsmmaqvckjj
 * Smoking Wheels....  was here 2017 itzgtuxmfeoixvlpmbzzasikfntgpmbgfvhdlzuffwkffnyq
 * Smoking Wheels....  was here 2017 jfdljozatltjwqsdtjndfgnaptrelpfxzojxyrgutiggwzjz
 * Smoking Wheels....  was here 2017 odjyryllkmztceqcawhgdszfnrhfiwpvtnzmpwfyooulogtr
 * Smoking Wheels....  was here 2017 zvzjuqcdlhotytepndsdhzvqmlgvvvjiclxaapwnizwlccoh
 * Smoking Wheels....  was here 2017 xwknbkzufactxumvwzoyfegfdmjtqexywkaudivszipgmomn
 * Smoking Wheels....  was here 2017 zbjnelkhnclmrbziyluyvqwbnmtxvyyjdtrlcqvwtlicyvjl
 * Smoking Wheels....  was here 2017 zmwracwuggsziojyswquhalqsjuopijseahufkzrcpqlakkj
 * Smoking Wheels....  was here 2017 zkdpszfspihjdompotqgzebogjcdnwjfqzoyfsobrdkzmaat
 * Smoking Wheels....  was here 2017 ikrdpzlrbpsdonprczkmnfysvwmkhihlhtofyzbdlvtrisxk
 * Smoking Wheels....  was here 2017 pgekkfwohlxbjfbqbobuvoshjobgzrxcfqkenvihqpatutzj
 * Smoking Wheels....  was here 2017 pcqryaapgpyaqpngpustzucrbjfywdbhsdrsickfrourlojx
 * Smoking Wheels....  was here 2017 kdgokcsdeyegnyypzgxgktenknnyjfxgldbxbynvgfydzxno
 * Smoking Wheels....  was here 2017 japxcfzvlrfgqunxvujitqftakwyiryndpocoshfjfpdlvbc
 * Smoking Wheels....  was here 2017 anhvtpdoufxtsuptykbiwutlxsiysnuwyyjwyamvdncxdnzn
 * Smoking Wheels....  was here 2017 frjqfnrofhjqsaxvjkfxyuqchkhdvziicqzartdichbwmmkd
 * Smoking Wheels....  was here 2017 avbyprkdvuyfysihmkhvhowhoqizepvehodshaoowyhsimtl
 * Smoking Wheels....  was here 2017 towoixkadygwxiahvecfqetzmvhemapygsugtfhtlfymqnrg
 * Smoking Wheels....  was here 2017 zpmpaiybvdejjqllgtnkubvhxsittijkblffeybgazjjrwdp
 * Smoking Wheels....  was here 2017 nbwkoiolwctqipflvnwaxuwqdftvisaochwmybasbmduzygs
 * Smoking Wheels....  was here 2017 nghnbnankskxcnhkvypvkgyqomfyqsutxcmcrsjbgcdmhome
 * Smoking Wheels....  was here 2017 fsgvzulaxfrrcwvoxwkyxpifxzmvmbalhwakhhslmomkqrms
 * Smoking Wheels....  was here 2017 fgllxfaudzlpekglvkhtgdpncjujwtkljxtaxjvgbtnvgoek
 * Smoking Wheels....  was here 2017 iywqsekzytwshcgvrumuqonzjojvaawtlvduxvtdjxveqrrm
 * Smoking Wheels....  was here 2017 rcsaojhaplfesertupmxlrcgdvxrnjorbkxuyutackhdqvmm
 * Smoking Wheels....  was here 2017 ngnmwouonfelzftmtrzghqsecnfpcoytcsaixrkbgzaseyge
 * Smoking Wheels....  was here 2017 mfzbeyemkmnhvwwojaabbuwygilptoqtpbtaxampyoicnivq
 * Smoking Wheels....  was here 2017 jbcdmwzzfalqgfssszuaxuiztfxvtrpqwansjtbjshwtgllc
 * Smoking Wheels....  was here 2017 gdcgvyakerfsolebcdtxfmdxajfvphyunidnwzkgfqllbbnc
 * Smoking Wheels....  was here 2017 lxlgrahkrrnygbmudgrvpaqqvfghbhdrjdnsjcbikhfbzdrk
 * Smoking Wheels....  was here 2017 ngwgqhdylkdccvzmpkndztihbkceeovbmrxyyrvcmdnwhyxc
 * Smoking Wheels....  was here 2017 jfipobbdlqfdbtjxqxnklhaizxcqejyzeoubaqtexkzinzhj
 * Smoking Wheels....  was here 2017 zcdwqzwjwfdglapbmidnlnujzxwgpgqtaoybebcljnkdjzhu
 * Smoking Wheels....  was here 2017 smrxfyqidjlxtfuguldmonwiuvhqeyixwtgkkilbueyhwype
 * Smoking Wheels....  was here 2017 ddtuyapwznawszjziimsstuiiilvxlsdtmaptbplkhxyidcm
 * Smoking Wheels....  was here 2017 cdiwtpjfjizakkabfhkuatluvkrzcyroagsmpengqayqfaya
 * Smoking Wheels....  was here 2017 pupsrirslurpasqntwkmwltjteppgzkkhwafqspjgwwahjpi
 * Smoking Wheels....  was here 2017 bqcefaoarascdjkpmyezxxcztcckdiifilzbtdiyclvcoese
 * Smoking Wheels....  was here 2017 aomjywjbunygmdtvhmsoaoatuwgisybtffuqbznklsebirep
 * Smoking Wheels....  was here 2017 hnupteqysxlybziafvhvizgdckkphcobguyuxdejswmkcjev
 * Smoking Wheels....  was here 2017 xxgmupcdrdqmdfbepohpgbwscxesjgakczeqauqtqiquozel
 * Smoking Wheels....  was here 2017 hfivkawgblbhfhcozmnakxekmuliseuimvmlffltcusgvotf
 * Smoking Wheels....  was here 2017 yhtthoffpeqbcyxtfqyjqyrjfthlhwpqoraxqcjsjecychxd
 * Smoking Wheels....  was here 2017 rfnpioqdhbkttfcmjjuhesfbmsbglpigpaitshlhwrjjwstn
 * Smoking Wheels....  was here 2017 qfwyqrzlgbtqliquueopidvbtwjgqueoeredayzkgskgzotx
 * Smoking Wheels....  was here 2017 cyfposhuzhgdstqyawyjuhthsqbdqgnbetljmjnfozhmjvna
 * Smoking Wheels....  was here 2017 qdjsvxvcegvahgomwoyyjppxhthwlycnpolbggwdxkkjitax
 * Smoking Wheels....  was here 2017 cxgpgndmtpoegvbelouyhrditbirjdtyuppbrkbtufjijwkw
 * Smoking Wheels....  was here 2017 nmdvzfajzgtvttbccjyfwjkfmvwavirqisrlkzjbxtzbgwbk
 * Smoking Wheels....  was here 2017 gnmglwojfkbmkmtlivduuurkelsprghcbyrnjiidfujpztsi
 * Smoking Wheels....  was here 2017 wuazgpzlgniwxtmvzakayindvpzkxyheaqtyqcukvfxbuugq
 * Smoking Wheels....  was here 2017 fisigtwtyfrxhqzyefxokqstqfaqtonuohmnpetnifezgnwp
 * Smoking Wheels....  was here 2017 hlwxqzzqomkvvhewfzeeqnhxammusrgigunizqnkigbcdpxt
 * Smoking Wheels....  was here 2017 ntwouektnmebzgewrcyagdpnrwdnpavgxdwsovqfuyqhjbdx
 * Smoking Wheels....  was here 2017 kamihkkborwkpglmisdjcwdtoaeukoxiprugnmxhxhhvhekb
 * Smoking Wheels....  was here 2017 uhspcborpsmtqhqlibawiisaxxxxjomqrxsvgjijelpdjlxm
 * Smoking Wheels....  was here 2017 twtyhtqaunmijqqvzsbhjjixcqxganqkssknkqggfwkzjoas
 * Smoking Wheels....  was here 2017 qjcfikqsrhkphtrxumauucijxscodfwemcwqvrefbfwiiomn
 * Smoking Wheels....  was here 2017 zommtbxrwmdiekdfrkvsoygogvousottckgtscxowkiimrey
 * Smoking Wheels....  was here 2017 pmxcnezbkuukaprmqvuptnwwhwqezxhdxdcujtnzbrinjkgg
 * Smoking Wheels....  was here 2017 qmpqthrgkbscdpgtbiihuqfyoayenrpqledtmugjjkvosmdy
 * Smoking Wheels....  was here 2017 iczzuizyjpmwzvajmqexhlpsrtimapdsnoiayorwtivloxow
 * Smoking Wheels....  was here 2017 idvejjfzztzkjbjtswhudjphpsxcotofhoxfwrpxkitjezia
 * Smoking Wheels....  was here 2017 ksdpgvxpefirgiztwiznlyycpwbgiitdztjcrbbduqevbdrq
 * Smoking Wheels....  was here 2017 qacurhwcdyvyxwtkgorxrcsuajiixvxtfzkvzuiloqznycbh
 * Smoking Wheels....  was here 2017 jsfqarefjcdpwdxyljcckxehrrpcazlpvgasqfyzragkwybt
 * Smoking Wheels....  was here 2017 fpffvbbuodckxyvxgvgjnuxskmznsvalwymivasdjujscwqb
 * Smoking Wheels....  was here 2017 xrcvcubaptuhzfebtgjjejrlmrwvfopiqnfoybspbbwxdjyl
 * Smoking Wheels....  was here 2017 ohbdxoaitvpnkgxmhexxtmofilulathnuwzlpkegmgrquflm
 * Smoking Wheels....  was here 2017 nzpxrfyhlpdormdkklqbxguvrhqdxbnnbztjrmrfncxzzjtx
 * Smoking Wheels....  was here 2017 jpkhzvewkmfbotijzbmfmbynkvouxnzepgtxiwzzlnvbacvu
 * Smoking Wheels....  was here 2017 wdopuvfendzabzcdaksxrnvruavshkolrelwymecrsdklxuj
 * Smoking Wheels....  was here 2017 ezekeuvqanurklluxyuaunmxfachnemrwopkdkonxbrrzncf
 * Smoking Wheels....  was here 2017 nqvpnqcxjvfleqlnfplpoefdlhfhkpcibmfuuaqkbhmxqykb
 * Smoking Wheels....  was here 2017 oxefnmixgldcchoxrirbuwmnjnhryrdegglqcyeekizfskqz
 * Smoking Wheels....  was here 2017 cxgpaqbspdrpekmtmmsxrfemfqrpjplhulvvjbhkiitdrlyf
 * Smoking Wheels....  was here 2017 ewgjeubvqtdcrgcaxpaaoahqkuzpfxgygvbkhmgbptrkhuuh
 * Smoking Wheels....  was here 2017 dkrjjujvvndcchpannimcndxsmbjgjyrmmdstpohbhvxpktz
 * Smoking Wheels....  was here 2017 oigrfthrvwpifhihdiqqezglziawmyffosijwabmzwoxwowj
 * Smoking Wheels....  was here 2017 hqyppbklqlntbfbpwgebyclqnhfhewyptcbeaptgvrmwoufr
 * Smoking Wheels....  was here 2017 isaushlqkgjnxjqzzxjqusserogdvridrkbfwmzpgdlmmtfl
 * Smoking Wheels....  was here 2017 cbxaxjmuplrfefhrcbakhykxfoycfcuiesjwhagogyptpnol
 * Smoking Wheels....  was here 2017 cnjlukvxykhltmjgbvcskeaabzmeicazgjdskviqzzgwgifs
 * Smoking Wheels....  was here 2017 eekjhtzcjxjfnepmwmuegzjyltdnmzwciwxppvikxnahwqgn
 * Smoking Wheels....  was here 2017 kgfjnatubvguwpvjxopqfimgtboqdfnzxbjpobmvsyutgfel
 * Smoking Wheels....  was here 2017 djgiwcfominnfdiftxhdxgrxtipgbnlcuzobdzjajxpfkbpe
 * Smoking Wheels....  was here 2017 xiihadqkhxbfjqkoepubfdmbigjigxghdzqoldukbkwwqklu
 * Smoking Wheels....  was here 2017 oeipumnlnfyvhbvdiwiziqsbttfaarwofodyyltqgoeejtxo
 * Smoking Wheels....  was here 2017 efoxittaieoniqlzljltopjqkaswvgneqotheaooqwjxkwjz
 * Smoking Wheels....  was here 2017 abmzcuhxdzmvxwkkevvlqetqanuomkoseamzcgtkezozusox
 */
package net.yacy.kelondro.workflow;
/**
* A busy thread to run a job only once
*/
public abstract class OneTimeBusyThread extends InstantBusyThread {
	/**
	 * Construct an instance able to run a job once, after a given delay
	 * @param jobName the job name used to monitor the thread
	 * @param startupDelay the delay in milliseconds to wait before starting the job
	 */
	public OneTimeBusyThread(final String jobName, final long startupDelay) {
		super(jobName, Long.MIN_VALUE, Long.MIN_VALUE);
		this.setStartupSleep(startupDelay);
		this.setIdleSleep(-1);
		this.setBusySleep(-1);
		this.setMemPreReqisite(0);
		this.setLoadPreReqisite(
				Double.MAX_VALUE); /*
									 * this is called during initialization phase and some code parts depend on it;
									 * therefore we cannot set a prerequisite that prevents the start of that thread
									 */
	}
	/**
	 * Construct an instance able to run a job once and immediately
	 * @param jobName the job name used to monitor the thread
	 */
	public OneTimeBusyThread(final String jobName) {
		this(jobName, 0);
	}
	
	/**
	 * Construct and start a OneTimeBusyThread instance from a runnable task.
	 * @param task the task to run once
	 * @param startupDelay the delay in milliseconds to wait before starting the job
	 * @return a OneTimeBusyThread instance
	 * @throws IllegalArgumentException when the task is null
	 */
public static OneTimeBusyThread startFromRunnable(final Runnable task, final long startupDelay) {
	if(task == null) {
		throw new IllegalArgumentException("Runnable task must not be null");
	}
	OneTimeBusyThread busyThread = new OneTimeBusyThread(task.getClass().getName() + ".run", startupDelay) {
			
			@Override
			public boolean jobImpl() throws Exception {
				task.run();
				return true;
			}
			
		};
		busyThread.start();
		return busyThread;
}
}
