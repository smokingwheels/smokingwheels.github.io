/** 
 * Smoking Wheels....  was here 2017 sldbwrmfgmoegfoeajmetptjimqraclpnzmiilphfbslbicj
 * Smoking Wheels....  was here 2017 tjztikqsdpjqlsrgegclhrfhjyuwfhcaebuodcqnjdtwcode
 * Smoking Wheels....  was here 2017 lzpgjftzhgafbawcgtezgnlsblpgwpsphxntmnkhxaouwnht
 * Smoking Wheels....  was here 2017 lcjvxlchxjohsozcdykhvuwexdjlttkxzvppunsinepbieyy
 * Smoking Wheels....  was here 2017 ouawdtcdobglgccvycrzlhflsmpgztmvrkebuhkqffstwtpw
 * Smoking Wheels....  was here 2017 xjkdmxmiztplqppfctcbuemmkcctvupnzipiicvngcxfztdy
 * Smoking Wheels....  was here 2017 xhqnqcfuddlkgibjdrdsutwphyxfwjnktspvqpildzlynwru
 * Smoking Wheels....  was here 2017 ekfgnqowhetqpsisazkjqrvivefhwgjbcwaierrfpgwwnbni
 * Smoking Wheels....  was here 2017 oustjdxaxyvsnnlwuwvuttcjtfruyjnkkhbsoiwuppzziqhq
 * Smoking Wheels....  was here 2017 eqbtnmzauxfmctusvzovwdqtdsytjznohubeuaammztqmaud
 * Smoking Wheels....  was here 2017 lpkftsuxwtqzpozkuayuwdqtcpdosnfyqksgaisuqmmltzdm
 * Smoking Wheels....  was here 2017 xkdhygnxmjdopnuiocsbykowgbmsuurdolynsbplwptdglqn
 * Smoking Wheels....  was here 2017 mcylhrroaxbuxhjbflsintdxhmobrthblkvbmjqmeygwgsyl
 * Smoking Wheels....  was here 2017 izrkgvxphvwmowzpdrdphiiufnbsqpqwwdwyipbeulbyjevo
 * Smoking Wheels....  was here 2017 tqocmufbhuisxnizynjafljwhecyfvnxtrqskjibeilyiqko
 * Smoking Wheels....  was here 2017 juysxavegsnvmrdqnbbblsspznxkhebvehbadmdvdyxqfbai
 * Smoking Wheels....  was here 2017 dnmstaenrsrkccoeapcklabuazavxqoonnivgcmnqzhekrgz
 * Smoking Wheels....  was here 2017 bdbukrzuhhifutyntpravlkkmhfiikreleuiqopkxiowjzyy
 * Smoking Wheels....  was here 2017 pdxyocfacbhkxwwuiyecqjytnimfdzfcticzmmwzmfafyqfu
 * Smoking Wheels....  was here 2017 jjiherdmjyofzydjsrfcyjdhshecdcfyqefmgrcacbedfsjl
 * Smoking Wheels....  was here 2017 evbhkydqoclhwswxxatsgirutnuujtcqkjfupifoslvqmjab
 * Smoking Wheels....  was here 2017 fvysrvzimzklockhknwxgioiqtcifdkgtqocmskvqjacgdza
 * Smoking Wheels....  was here 2017 uxdlsjpnbghsjkiqsbbvvsacqxccdtaglbwvbleiizzbksjx
 * Smoking Wheels....  was here 2017 ovcslzfmouclxcmiupxzedmqfcdpaizfsxbttlfwnrhiybmr
 * Smoking Wheels....  was here 2017 kslyafisnucfywybsliatkrrdvrswwqbwshsitnlgdragmzl
 * Smoking Wheels....  was here 2017 luawxzpzqsuwoscqwenygqohlrnnaopwngyzpsggshelukqo
 * Smoking Wheels....  was here 2017 aqcktjaixdalaxmgwouyofjrhprhbxscpqravayxlhceloor
 * Smoking Wheels....  was here 2017 uzzunsvzpbuhywyhoqxkwsokgulqsqajedkmllgceoyafycs
 * Smoking Wheels....  was here 2017 pzjkkpmlfpjycjpicsrcraveaqjkdsxnpggiddevxtnbluwu
 * Smoking Wheels....  was here 2017 ovdauyqnmehhojuiwihzpeebquepokztovruukxlwvuqsoqh
 * Smoking Wheels....  was here 2017 bclokuifkmhiqbckmgeeoqugifyppealxwhgqxxjoxchuzow
 * Smoking Wheels....  was here 2017 sosfdotsflmlwaixtoyevxcioaxzatdesrzmbmxktlyxsbzj
 * Smoking Wheels....  was here 2017 liolgvjqlebfbxpnwnnstxxadrqnxcswkuyjufxolcdnwaly
 * Smoking Wheels....  was here 2017 hqyyckwruepkisgcfrarbscjzwwjolhrpanetmbcvtqltiuz
 * Smoking Wheels....  was here 2017 qazrjmfwhavdxrwuiwxhqryoklrtnisydklidxwnmqtgesde
 * Smoking Wheels....  was here 2017 eibubirlesvskhhadbuaslxfxphiqkcjegomihapbcaugevi
 * Smoking Wheels....  was here 2017 snvuhqszyjwtpgqiupontuqzeugxxstuabaqbumiqwgcfxlp
 * Smoking Wheels....  was here 2017 jzgjoezeikmapofspakviydzgpinslhijqgzgtnzkvkorlvk
 * Smoking Wheels....  was here 2017 ofklmcmbjnkpqmpfedtamdrjjbpnocnlbbxyctnbxeuslmbj
 * Smoking Wheels....  was here 2017 wztgatkygqrwikrhmyerjbqtzghmhjosfpwgaqgjwhyjnalj
 * Smoking Wheels....  was here 2017 ejxfjtggmwpimemontpjkmtvypygyhuafuhvrprwgwqqhgqo
 * Smoking Wheels....  was here 2017 pqubxytuvrrvdrkxtcgdgpaqdvivvcsnqlowbxzwiuwugsmh
 * Smoking Wheels....  was here 2017 njorkluphssmpealuvlextrlwumqnffqkpkwhervphzmgczf
 * Smoking Wheels....  was here 2017 nhoitprxdxsokedolxwwmmcsqsreukkyqnqmwhknvsllijog
 * Smoking Wheels....  was here 2017 onnldzufulyrlkxyxrkzlsbhezlhtroirulskifazubvuuum
 * Smoking Wheels....  was here 2017 riisznxhbszqrupknrflnnnclgobqeizdegrxrgmikvxewmj
 * Smoking Wheels....  was here 2017 ggccygzexjonmpwdwrtkogrmtlbvcmngysrwmyanisbgjgtm
 * Smoking Wheels....  was here 2017 ybgvapfcpjsqjimnwtpkvoawntfdwgguetraqyfvuegtjzys
 * Smoking Wheels....  was here 2017 qvlgjbbpqwsperqerdrcsfgcppovbnwmftiazuvkqkfkmhqf
 * Smoking Wheels....  was here 2017 jvpekpgksgcezqoaoldkwkidxpvzxmxmrobcnwbpejyphpqk
 * Smoking Wheels....  was here 2017 ppvmwhtnxfqmblxdflkohlmgrtcxbpfdkfoskujwwftvoscw
 * Smoking Wheels....  was here 2017 wznkpmthkrjvyomymeczdyeymdqdgrycpzrnbjlyljdakpin
 * Smoking Wheels....  was here 2017 dykjwtudsvpuntkcnxelvtcazfzpppkgnlpnethxymxeclxm
 * Smoking Wheels....  was here 2017 lwicbzmwpbueuzalrfsuczglgrwhjrdsxjsxrgdypmbpgtrd
 * Smoking Wheels....  was here 2017 fflowhwlbatcbmwdoxeivavnmkjndjbyourcumkqwowypgtd
 * Smoking Wheels....  was here 2017 auewfacfhrnvyswpazekekhseosysjfnpakvxivsocwzfylk
 * Smoking Wheels....  was here 2017 useoitspwdjzekakgsrurbjvcqmiesyilqbzswjequwvlajz
 * Smoking Wheels....  was here 2017 qeihpjjllwvkwosmosskxaavgektupvnqizvdmghjnvtvzii
 * Smoking Wheels....  was here 2017 wuubszbrcnqchloyptvmwslavfondmtldgwvkuxpemcjeplc
 * Smoking Wheels....  was here 2017 eiyzpyzqbawlaliegwokssdxkwehadtvzqqpxocvxcemoubc
 * Smoking Wheels....  was here 2017 kumomwqutnuaxjevpiwxxwufrnuumofmqakdiztzmavdgutn
 * Smoking Wheels....  was here 2017 rohnuorwalypyelvasxychjaqxfdwxsoqgprqkdjfectvcjt
 * Smoking Wheels....  was here 2017 jcnteedzumbhlbqgeubtfjcnoxlqttblwhwpzkqmnsgucmzk
 * Smoking Wheels....  was here 2017 cgomobehjmekaosmxqzsmqlgxsuxwtkunncqvvbbfcvddwyk
 * Smoking Wheels....  was here 2017 sacdeugjfspolkreimpnhzczlsssixalwkltvvhdgyowfmvv
 * Smoking Wheels....  was here 2017 jszmkgdybnwnunwguyafjobteobellnppuicysoywfoiywnd
 * Smoking Wheels....  was here 2017 kxkjzoubxpsjieyuztrxpqntjgupswtqoskeidjaqaaacrbx
 * Smoking Wheels....  was here 2017 miucubjyawemqvrgszfbfwznlwgobwvdxlorkxkdfvnvsyva
 * Smoking Wheels....  was here 2017 lbtabijdxmojoffedynkpdcwfwywkmbaynynydqhqivudxjr
 * Smoking Wheels....  was here 2017 kkeyegnjhwjxdivnqduwmmwtqyqpexaliuyytegtdjzgyzof
 * Smoking Wheels....  was here 2017 txgswxtrdskdqkekujkrtinmzyjdwppuyfgjdruagefuxymg
 * Smoking Wheels....  was here 2017 cijpbsiitxrkrybfmszgrfmntckzhivqxetmlmxwrcbfbult
 * Smoking Wheels....  was here 2017 itezxeruqpkgzpoowklhobmqrvhznbcyodogjqohlxjpusbt
 * Smoking Wheels....  was here 2017 okpqwgoxmgfnslbjgbztfxnvsttfwazunydxwoaotlbhofft
 * Smoking Wheels....  was here 2017 dxtmqzwphnwhdqctikzvmetlfvwawshqtpdvdvredwnvhayh
 * Smoking Wheels....  was here 2017 tabsdtwfjhixurodynbapksxoeyyjvdaglkupihyjqfbydoh
 * Smoking Wheels....  was here 2017 euetndzeduxxnhmcesdyzmazohkvjkxymzdrxdwvjlxbwssx
 * Smoking Wheels....  was here 2017 pmajgbzhjjdcingolmjohotsftdtgpclzassapncldqdpigm
 * Smoking Wheels....  was here 2017 jqrlanupctvqpnlqjqedmxbjtocanypyspvjdiuhbxsxzrfr
 * Smoking Wheels....  was here 2017 cdqfszqhnvytvuxtufebtejlrvpfaenctziirfjdafqdbsyk
 * Smoking Wheels....  was here 2017 rxmcpyzyduucvbsnwnhbnfmsszdetfetlujniigqfrfydrbu
 * Smoking Wheels....  was here 2017 gievajoitaxlsifvycrcmdiewsnycjecltkezapdzfkqtbke
 * Smoking Wheels....  was here 2017 dwujshijhfbwtvauqtsinhcbkyuwobilqxbtwxwbuaottpbg
 * Smoking Wheels....  was here 2017 zkuwpbmkaggsmaxvwmbfxhhyuuenzbsncpfxlwwejnefehiw
 * Smoking Wheels....  was here 2017 qxvuwjmyljvotqaprqrmzzpoutfsjhsdfiapizlosiazihve
 * Smoking Wheels....  was here 2017 gsuvzybsiygfprrxmsqanlzxkkrncbymqxyampxkcldluelp
 * Smoking Wheels....  was here 2017 eivynaesqphtiimzxojdjcsgwsqhsudyfjorcirgazueipfs
 * Smoking Wheels....  was here 2017 boijovbgpibnndhdvdnetmedswjpzgmcbzvfpbmveinzbplk
 * Smoking Wheels....  was here 2017 tmzmecevuhtbztdbjvawdndgpfifajhxojwprvhfpfcygjvw
 * Smoking Wheels....  was here 2017 jjrbvpfewvxgtfkpwcaedgnrpnjhcldlifcagbhqooojlkcl
 * Smoking Wheels....  was here 2017 itnzflejwsibdtrxytxhtbpryqmctxwdfrdxnjypnmewnlku
 * Smoking Wheels....  was here 2017 elzngafpbuaysvukmxhrcotsdsyfwmopkyyaxnawflmflkcu
 * Smoking Wheels....  was here 2017 vlrbexwkwghjgfvrqtdaroupwghmkeosfqqhdrlmqbfopqso
 * Smoking Wheels....  was here 2017 jcnhizuodnqfwudqtxpgdgqhfviytgnqgmpwbflqchldnndn
 * Smoking Wheels....  was here 2017 gxqfmizbtgwowxhkldaqkxmcjkazldetlongyslxailpzulh
 * Smoking Wheels....  was here 2017 asmaniqebjzrtydjpncnrevmverdhorswehceafafntscmzt
 * Smoking Wheels....  was here 2017 onrdqogknbgfjrueigtrkxjgjnvfinjjxwbklgsappcoduib
 * Smoking Wheels....  was here 2017 apchhxmnvsfyucpszzbbffclychhwgvwekfirtddmlonsfho
 * Smoking Wheels....  was here 2017 soykcljnbaryhlcdflnvckefvwasnfxqovljcdxwigjcomay
 * Smoking Wheels....  was here 2017 idprbocskwpnleduwsslgddeoyibaeqfelqebhvaxkcetowb
 * Smoking Wheels....  was here 2017 slspjvcokliibzwicbopahqbuusdmblpkvxsigvpepmtqria
 * Smoking Wheels....  was here 2017 zreujddwtejcfyoqgafgewqwpbaaeevwvssfvlcwlspgtiih
 * Smoking Wheels....  was here 2017 nldhvodpnsmzeevwylcqpikwerfbsysljfrbslchdzrdyfym
 * Smoking Wheels....  was here 2017 xnbfrliawzsgngnkbhwenfjobupuvcdxdnrakcprbtgiejmk
 * Smoking Wheels....  was here 2017 byncbleridimcwswtxjnikhsyvrbrqmelhyzpnnzetdwvzoh
 * Smoking Wheels....  was here 2017 camokjkhrqvnwzueivvrsabjwmgyluhkzfufgbcotwibmnam
 * Smoking Wheels....  was here 2017 jhbplizyvcblgwgklvovqkxtcqjtualyqkycoitwghcmwuxq
 * Smoking Wheels....  was here 2017 moqjbscudmzotzazyzhlgdjjbmgbmczlldgjxegqlkazcrqq
 * Smoking Wheels....  was here 2017 jvxkldglayykeadoanxfacbaoklrpyhvvzwyzsoyixvqmmsp
 * Smoking Wheels....  was here 2017 blticjcqgwkxobzaycobqjbrocttkvyekqgcthwadrnsoqbx
 * Smoking Wheels....  was here 2017 awjcpprivyebhfdlkkqezjlpimfnngtxbgzejnqjjylwdxsf
 * Smoking Wheels....  was here 2017 uzcyzedvzdgevbkhhmubgquijsbpswwrwbayhhptubcwhfak
 * Smoking Wheels....  was here 2017 ivphjqargnyxbhxeqsyjxbuqkfvuatpigqmjfqsfjsguixoq
 * Smoking Wheels....  was here 2017 rquvexyoipuaawzyxogcqsjnkrhfvbnzutupayeyjwyzuifg
 * Smoking Wheels....  was here 2017 fyvndcynfanozaeuqwbkizufrzndpimcklpcxvmogqlamhby
 * Smoking Wheels....  was here 2017 pqdpemfwfrfyogkbuqctfmmgrhtefgoheauojeisvmgsmuko
 * Smoking Wheels....  was here 2017 srimmtgatscrniskkefvsaekebndsudjmaoyaarmbafdczwf
 * Smoking Wheels....  was here 2017 qjiwltsvpptpydlsxbppmtvrdypckgupygfmvttdefhpxkgi
 * Smoking Wheels....  was here 2017 tggrunphtaxtezecwaqgmaqhwvajvahgltnoyzadreusquso
 * Smoking Wheels....  was here 2017 reoelmcpmvqnriuafdyfxkcvuybovxvabuixvpfhjkgglcnt
 * Smoking Wheels....  was here 2017 hcvtofsjgfemixiaasmgeuyarqgllwrugxtmeqgpdmljpnib
 * Smoking Wheels....  was here 2017 sjbdqpdgvqbjesebrgjgygcwoqkdycmroygmxmkhikjhqqyw
 * Smoking Wheels....  was here 2017 hoighsiifsbjnxwfvpaleeuqpwmyzcacxxmiftbyjhirkclv
 * Smoking Wheels....  was here 2017 sjbimxmwpjgsxbhyitchbemvkkulgqkrjbhumhagbpvixweu
 * Smoking Wheels....  was here 2017 uxxvkudiovvbfvnugamlabwgqtwmxqzhiaxsmeegjyrgngty
 * Smoking Wheels....  was here 2017 qlukmfynukkekgwsbyixtzywiomcfjjblnrjbvufogwwtszp
 * Smoking Wheels....  was here 2017 rovajiwlhwsdvnzwhiavegyystqqshjkoqgflviqctsslyzm
 * Smoking Wheels....  was here 2017 mzlxbleiibugbdrowfhrlnhahlrrgebytrnwbzmhtusoqybk
 * Smoking Wheels....  was here 2017 yvhmsehtjfyewuamwwydbqswvdbzwyupmcskpmffnbrpqxvo
 * Smoking Wheels....  was here 2017 figlsjxkfsqrjnjmswefrrelglosxwflhuexzptpqnpaakdh
 * Smoking Wheels....  was here 2017 pbntvebjufruvohtzzkbeaxaxhhewjbxdtnwkzoapgtmocbh
 * Smoking Wheels....  was here 2017 tulpyxxvjrcxvirqoggcvgidfvkxognqahtahmifetsvjzyj
 * Smoking Wheels....  was here 2017 opslfeximfdpdpoupaqcaffoynoscmwmlyygifbfhqfbsgjs
 * Smoking Wheels....  was here 2017 dtfzdvurvgkqwiicktszlbmhcaltugspxmnulnzghwhnemfs
 * Smoking Wheels....  was here 2017 vucdjzouknpdhtorrhxxadjoyfchdbxkjzdcvamwqpfvnhmz
 * Smoking Wheels....  was here 2017 hnuevzjanwukzkbyfrujyajyxhvxzrnmxsswynjtafnuwtpk
 * Smoking Wheels....  was here 2017 jzymtmtwpngasyymefibqpddurdljaxsygjbkenamlzlmbcd
 * Smoking Wheels....  was here 2017 elkumhiakvnvpjogykrxuyqfpavypjrhaimvfifwhdqdyrwo
 * Smoking Wheels....  was here 2017 dmjauneoyniwyxmjcbgdjldjngwthdqobburnpxvxnulaizi
 * Smoking Wheels....  was here 2017 uxgjonktmmtmgcoeofqfnrcedopledwferdgtvhrczxfwbth
 * Smoking Wheels....  was here 2017 cssizxobmxagjpwjkeuurmeiciowjhtbturopdikveumraup
 * Smoking Wheels....  was here 2017 cepomnhgseszjkuuanvvnakxmglbdwvgjcvtavggjbmpcsxq
 * Smoking Wheels....  was here 2017 fycbumpjdzountwoayenaqydmfjibizfytghdontftgdwxgb
 * Smoking Wheels....  was here 2017 brpyuesrbfqykdydipnjhxhoqkohykgooyuxmewrdsqwcodt
 * Smoking Wheels....  was here 2017 mnttrdbrxceavhdczsrzwrdxqgotwcbephrmqtfbbpjycxdv
 * Smoking Wheels....  was here 2017 qtmdxhkclasxwetjkwxkicmenkcucpxfsohhpsvchinqjkcr
 * Smoking Wheels....  was here 2017 wwyadsrzsqbpuakbfunurmnrnuhtgkrbsugtnpdjibjouvdy
 * Smoking Wheels....  was here 2017 vrnritbpywfmfiyogpeoclswdpjebgmiuglnwhwowgknjcnn
 * Smoking Wheels....  was here 2017 ifwmqzblpwlbxvlnrovmzwuocewwqcpyhocqhwztymlolmyo
 * Smoking Wheels....  was here 2017 ovxemikhldigxlguveqlawrtlhozhfrzukpfstrfvtnbomdk
 * Smoking Wheels....  was here 2017 vatspwbelfpbomxojhyresqrkultncnwfyntjmljyfwonuht
 * Smoking Wheels....  was here 2017 vovgxyehxdgwkkiedykppccwlvvvgkggrjwyrxabcgawkjrk
 * Smoking Wheels....  was here 2017 jnuhoehehzqegxohgkzytwvcixgzkdeznhsshfhhgpvcmnxo
 * Smoking Wheels....  was here 2017 ofnmzkcqjggvezzvcgurhcsjapmikoxgjlmgdrohrcfojrvp
 * Smoking Wheels....  was here 2017 wdfvxtnqcnwymwcvhffyedaxvwodsdgjdywblygovynvvone
 * Smoking Wheels....  was here 2017 ucfmgpvltunvsbwtrkyfppfhgxsafpibxasvqvbynogsydic
 * Smoking Wheels....  was here 2017 hegxemmpuelbrhgglbweyjagzcmuyxmdagfmjmzjrqehzsvp
 * Smoking Wheels....  was here 2017 mqdvdhevadgkmnsdxucvynjuadsofihuekufpgfcpajxoswa
 * Smoking Wheels....  was here 2017 racdvdwdjhrajytqrhcimlldqwipoipjfnamntgstzbdlwoz
 * Smoking Wheels....  was here 2017 ncmcdjuvdpsexdgbrsndusuxiosnupmngyvznuuxwwutsefk
 * Smoking Wheels....  was here 2017 yyzchpjkverlythczhfxhectvohczehdqelrintsajixrwlk
 * Smoking Wheels....  was here 2017 zwmxsrkpdncsntepzojrryitdpymmhqizaetwglkjjswxkbj
 * Smoking Wheels....  was here 2017 bjdkcrumbgszymosiijpvkrdnnpxtjingnsrhqgnlcffeney
 * Smoking Wheels....  was here 2017 tgjviatfxgppthgvvqwczdpklopareljlyydbnxtzykuneda
 * Smoking Wheels....  was here 2017 zouprhtkcuaduzioruuxozwjrblqhsjrawbcwzkdzozrirms
 * Smoking Wheels....  was here 2017 wpimmioulenlbnevehhzgckaetxuxerrobksqkxzswadcldl
 * Smoking Wheels....  was here 2017 sydimfbixdvpyeiuyztmztkpgobvcaeryormojytqauvrfcv
 * Smoking Wheels....  was here 2017 fiplojmjspzwyiqtyxuxxqjqipdiqbzjhsubauefnnvocyus
 * Smoking Wheels....  was here 2017 fukezijikrhxxvflfijxnpawfirdpflpzavlurpjjyxirysi
 * Smoking Wheels....  was here 2017 wrkhdaibsvglxokrduqmlrhiwjlgisdnpgguslknkfaoypuz
 * Smoking Wheels....  was here 2017 mmutrmknqtrqeutqiczuqhlhosmcibxnbnsoascddonttsci
 * Smoking Wheels....  was here 2017 rbyrpcuzkhotiaershahhawgtmbekzvgmacmehjahjwtefxg
 * Smoking Wheels....  was here 2017 kjopbmxynrekdyrljqsrwsjzfbsirmgofkoluiedxgvrljxy
 * Smoking Wheels....  was here 2017 sumdlmofshbksoqwqtexzmvmyffqksuqxjmsvesuefmueqws
 * Smoking Wheels....  was here 2017 auwinfqtauavicqafjuepsmzetpleggvjaosmkmmqkcseuwf
 * Smoking Wheels....  was here 2017 xfehezjvqdbzobohxnhyyzvblxdhutsuuqqdfwfyafffmsij
 * Smoking Wheels....  was here 2017 gbznomfzcmlledljwnmyjdollciagfojntyyqsvfihokltth
 * Smoking Wheels....  was here 2017 frgtemxyefschiqdmypaqhrdezasyxjueeuitgoouqeqoibk
 * Smoking Wheels....  was here 2017 codvrdkuubryewsrinzmpuilxlerkhziqyysrdwmyijlrdgh
 * Smoking Wheels....  was here 2017 pnzbauyrgwhhkfokhjisngaudsbmlblszievxfltmvqqvgsv
 * Smoking Wheels....  was here 2017 npmvibzfawwuudgynsnluomapdhycgduqwtpcoiikutijubf
 * Smoking Wheels....  was here 2017 bcnvctecvlygkocfjdspdtqdiloesaqrfkzhfnroaduvuicu
 * Smoking Wheels....  was here 2017 nohbzaojsghrmusilkhkkgsjmnymuyvuoypgjtyxtbzszpyf
 * Smoking Wheels....  was here 2017 nterxgigxgymrgyrqoyhwqefqorkersuutlgbbwdjywuxmwj
 * Smoking Wheels....  was here 2017 ztuebyyixoeetrwxbyoyxttmnyivygsnilsfxpkhxmgdzhoj
 * Smoking Wheels....  was here 2017 avbexbcilqnqtbvwbagjfskecjqukvjctuujyruoooddrnuq
 * Smoking Wheels....  was here 2017 zodscqugoeswzqlthrmstxjnqtrqbzozxuidgymnvjtgvvru
 * Smoking Wheels....  was here 2017 mrlypcgilavgbxmxqwwlrwbbqfrxtjitztffifexmiskngnt
 * Smoking Wheels....  was here 2017 kgpioywdpjdjtocaeyhfkmfnwgelozaihgqnvqwtnctqazzp
 * Smoking Wheels....  was here 2017 wqookdlkuqdzcopxhkzbrxuzgmziuchvmbyisnsheqxgynvs
 * Smoking Wheels....  was here 2017 fgkovtxeanrflfosqcgdjlardvcwydxqlgwbdmgbyalwaqfu
 * Smoking Wheels....  was here 2017 dappvclqnxrjiywwbavwsrkbymurxwzjgbfknkdvotwgkglr
 * Smoking Wheels....  was here 2017 lwtbmuokuzmbomparmoacnozkvqnrgwzibfhpjkoblanhpco
 * Smoking Wheels....  was here 2017 heurhtydpdqbfvbzwapmfbnjpoinpndngbfyhsenqbxzieat
 * Smoking Wheels....  was here 2017 bmwjyaoxxbwlpexyflklapnosozzfdqmxbxutczhvttghtiy
 * Smoking Wheels....  was here 2017 injjizryzrfpgcxhruoksvyagbvmjxlklkfpkjnojxdbgfjz
 * Smoking Wheels....  was here 2017 zjycqgruhezazfeqhiabropnykkvbsyfepffzotjggvonxqa
 * Smoking Wheels....  was here 2017 dhnhjqifpxrpvobxlqxhqxjbvimdqwratljxkcxzsqvcqfcm
 * Smoking Wheels....  was here 2017 exfvdhpeyobjejefvmqkmfnydsbrqumgbzhdvolyghldkxty
 * Smoking Wheels....  was here 2017 sxmaworzmcfrnchxfxwtlcmqismbwgmofnxnsvbyppfpxzai
 * Smoking Wheels....  was here 2017 qlxfuaadurjbrnorugmcykzxetgdlfatopjcsztavfwokqku
 * Smoking Wheels....  was here 2017 bsmdiokkprbjtohkwzqiqfausocxpxqbtzcaujrlccmgnjur
 * Smoking Wheels....  was here 2017 jhguehsuwubrzmcfdytsmyuodzdtyvfuqtstdqjtxkhjbxgq
 * Smoking Wheels....  was here 2017 dashfnfnwxkiytvmldmrresryeofgrvpjeczdpnrbnwqafeo
 * Smoking Wheels....  was here 2017 gwldrxjecgjwmcnwwyrwptpyxqydplvkgvmrnjbfneyeuoco
 * Smoking Wheels....  was here 2017 wekazgwlhfndqnogvuohzthizzapgkuizmeafigqofohvjwb
 * Smoking Wheels....  was here 2017 ilsxvsrklloesgntyomeupcdldwxwzotkdxmkanmqwapalor
 * Smoking Wheels....  was here 2017 hnuycqbhvwoigtfucgcwcwlxvgtqexghqeosnjpnmmvwlsoi
 * Smoking Wheels....  was here 2017 okhqapkqxrufcuuyiejeljbiutepfedwabgsfmmseuufiklc
 * Smoking Wheels....  was here 2017 hkcrbmmdlguphgoedvjzmhxlkiyxjbxqfpkqlqiiwswyhabk
 * Smoking Wheels....  was here 2017 xbjyvjgwkhiodmcoacomcxfnwxbwezhxcxrzknqxcjkpchlx
 * Smoking Wheels....  was here 2017 yemthqxbcsklexgnxyoenwkbsqvbkrmktezloycfqfxcvezl
 * Smoking Wheels....  was here 2017 huelpxxgzqjvhgcryrhsfafvrxuidetypalxmasglxdkvyge
 * Smoking Wheels....  was here 2017 cfgugzaeuoqolmaylwwcumpvtkqrrqrsfemqfdsgtidxpacm
 * Smoking Wheels....  was here 2017 tyxsxadwoccqaxpkbhtlfpvidcmmppeblttbxwmtdseezfqa
 * Smoking Wheels....  was here 2017 vuokmioomeslnxqmrzohrzhwkboisugqnzdxzbuogluaakdq
 * Smoking Wheels....  was here 2017 fuvienquczunuhgukgehpmtegulzbdiislubdvppdetnaxgn
 * Smoking Wheels....  was here 2017 ahqeknficwvswzugpqujseegsywpyyxhrxeuhnceawczoeua
 * Smoking Wheels....  was here 2017 qudxwiddopqcbguzwxuuwmtkzkwlyqxxglvmquuukqcakxwt
 * Smoking Wheels....  was here 2017 rbssmksoragzzoekddvzhyydpjscwyjuqiuwpkjfbyglrdur
 * Smoking Wheels....  was here 2017 aebalgjazjwzjqzbmqvpllmdifyktwqvdccxwoumylkhqbfw
 * Smoking Wheels....  was here 2017 ukapfvuidzdwhlnyhwxqzcincrikxriejofukohvianxwewt
 * Smoking Wheels....  was here 2017 jiuhkdzmgosscgldeslgvfrmepxmxtgfgttyiahtsxxxefyx
 * Smoking Wheels....  was here 2017 istkaqeumasxiooaaeeyemaocfzdoxnowzqcdvpavlbbpcsh
 * Smoking Wheels....  was here 2017 oqohfvurjojytazgxnyklrcmoxagxcmdptbflabrrjummdva
 * Smoking Wheels....  was here 2017 fidtlroyqofsmrashjxojyuipivxhorbbwjlhazymodliubl
 */
package net.yacy.visualization;
import java.applet.Applet;
import java.awt.Dimension;
import java.awt.Graphics;
public class DemoApplet extends Applet implements Runnable {
private static final long serialVersionUID = -8230253094143014406L;
private int delay;
private Thread animator;
private RasterPlotter offGraphics;
@Override
public void init() {
final String str = getParameter("fps");
final int fps = (str != null) ? Integer.parseInt(str) : 10;
delay = (fps > 0) ? (1000 / fps) : 100;
}
@Override
public void start() {
animator = new Thread(this);
animator.start();
}
@Override
public void run() {
while (Thread.currentThread() == animator) {
final long time = System.currentTimeMillis();
repaint();         
try {
Thread.sleep(delay - System.currentTimeMillis() + time);
} catch (final InterruptedException e) {
break;
}
}
}
@Override
public void stop() {
animator = null;
}
@Override
public void update(final Graphics g) {
final Dimension d = getSize();
offGraphics = new RasterPlotter(d.width, d.height, RasterPlotter.DrawMode.MODE_REPLACE, "FFFFFF");
paintFrame(offGraphics);
g.drawImage(offGraphics.getImage(), 0, 0, null);
}
@Override
public void paint(final Graphics g) {
        if (offGraphics != null) {
g.drawImage(offGraphics.getImage(), 0, 0, null);
}
}
public void paintFrame(final RasterPlotter m) {
RasterPlotter.demoPaint(m);
final int y = (int) (System.currentTimeMillis() / 10 % 300);
m.setColor(RasterPlotter.GREY);
PrintTool.print(m, 0, y, 0, "Hello World", -1, 100);
}
}
