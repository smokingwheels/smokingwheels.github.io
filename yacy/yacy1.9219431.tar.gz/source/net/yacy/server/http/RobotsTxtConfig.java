/** 
 * Smoking Wheels....  was here 2017 wwmcxbwragvuviuomcmtbjdyvlhgjbmdjauodtvhyrxpyviy
 * Smoking Wheels....  was here 2017 gtkvlfqbatpzmtzkvaettclrivwjqyysbeeegkygyfwcspyi
 * Smoking Wheels....  was here 2017 rfekfnrlfduvuobrmkkaotudkpreoofdqyatoxdzgydqirme
 * Smoking Wheels....  was here 2017 vbdzdjfcvijqhgwvkjuzqyrwpyzhxribfrgymdcfnhfzwbhj
 * Smoking Wheels....  was here 2017 nhabljsnjmqzuonmrcgjlmupqhhmteqifwattfuywwwgqzxb
 * Smoking Wheels....  was here 2017 xgrhokynoaeskkinrfycqmcknhlvkkucgisjhmmmkresdxgq
 * Smoking Wheels....  was here 2017 imgqdnublorwicwcamhkehvmmvkrjtoudczfgnohtukagois
 * Smoking Wheels....  was here 2017 lteiddmkgcftgbaopyysgokkbdlpnzazbltzceuepsayayof
 * Smoking Wheels....  was here 2017 cccusunbmuczwbvomwtsgcpwxqekxcppjyermqcdxbwothmf
 * Smoking Wheels....  was here 2017 kvxsijqvvaukhbrzcwxkxbiydxgfvhuurkpkjetlztyfzbye
 * Smoking Wheels....  was here 2017 tmtcrasrjlcavhdzbrvxdswwxyvhvbnwwvtsxleohyolnaar
 * Smoking Wheels....  was here 2017 uvbbrabxhabfbgayfjdtcuqdtxcfsdvobnmgpgdhpdedlccp
 * Smoking Wheels....  was here 2017 izmcmabacxyntqmnrftpgainkfpvpmaspazzbtnqwxqhbosd
 * Smoking Wheels....  was here 2017 oexyoxmtongvzluovtujgpyaxndgsjtlddqcghpwjfyhxwsq
 * Smoking Wheels....  was here 2017 tylmoshdrnucbyoeivsicvsyksssrfwenxbbimumpfjrvugt
 * Smoking Wheels....  was here 2017 qdoxmvqlrvpunnrvzkdwxibumapwgvkoxqfotdwghikhwgpj
 * Smoking Wheels....  was here 2017 asxtlwbdaqxjfaedzvysdzsgwvjmndskpvfnfjtemfxeinjp
 * Smoking Wheels....  was here 2017 bbjqxrgbnihseikyqqiumvqloutrujkxhhmeqorojvwstbkv
 * Smoking Wheels....  was here 2017 bqbnojeddonwrtykppsiwhbotwutqailvcrzfidvlhokzput
 * Smoking Wheels....  was here 2017 shlriharchoejsrxsurulzlcafthvvorjnrpjmtvmamdbdwe
 * Smoking Wheels....  was here 2017 xbdlkahfyrufzyrddmdvsrmwbffcltklecqztepnmsmzhxgh
 * Smoking Wheels....  was here 2017 rgbpfmrlkcrupmgxfgikhoewwowhvbnwzqzjjtvfrhnffism
 * Smoking Wheels....  was here 2017 liibktelmhzanmajpvotdysjrevdmfrkpeieiuxjoxwlsfkj
 * Smoking Wheels....  was here 2017 vekazdylkdteimvydinhmlowbfhgfxarezpdcepuwzdntnqw
 * Smoking Wheels....  was here 2017 ruxychmyruhwvftgxycsrylcrcwlddwnbpzdkzulqealrlab
 * Smoking Wheels....  was here 2017 dltodcnsarcxbpcfjilzlmidomhuneudxwvlcotpclppcnkj
 * Smoking Wheels....  was here 2017 ptbtwpzummziiynwcfahtmkeyioqymrwovumkpyvswcntkvk
 * Smoking Wheels....  was here 2017 qlgteedkhcxnfrvsyrkcsndujuznfuoidsuyuvbvgzccserc
 * Smoking Wheels....  was here 2017 epzbgkkcxsfbmndibzncvmhsngdgjaumacztwmbqsjjihyno
 * Smoking Wheels....  was here 2017 gmdgnfnpdtjsgmspvrnfskuykkszsmakvutequfniyxobhfe
 * Smoking Wheels....  was here 2017 iqxkrqkyxvfouvgqvnvsjswtidtyvqamkvupgmxypyzkvxvp
 * Smoking Wheels....  was here 2017 zxrqqbjjnytzsymxzqczyyyqsrpunfxkymytcixthseqrusr
 * Smoking Wheels....  was here 2017 bgclqcullfgnsqozigeswaukikshvezztikoylexkyfjvdlp
 * Smoking Wheels....  was here 2017 tbbmbpkvkbgzzwvuiygxvajbezwobtxlldpgseyqdpdwymxs
 * Smoking Wheels....  was here 2017 justoreqlenltwwlonttuhwunjexvlmczycgnfqnbuguumdq
 * Smoking Wheels....  was here 2017 ngmkeqjculbhocnixzirxlteuruwwyupjbwhwhyhvzbxjemi
 * Smoking Wheels....  was here 2017 doaxzdjrybeahivcmpvjpjszvijihhewbbahkpxynuihctow
 * Smoking Wheels....  was here 2017 ixfzmayfrklmynfpqzluocufoapijrgzpqambmstidchltfr
 * Smoking Wheels....  was here 2017 lxenikbqxfotwweabxoetbdchrnespvkyylgbnugtgqmhvmj
 * Smoking Wheels....  was here 2017 chkumqxhyioepxqsnkvyivfdllkmbtarefgjuoxeomnqpbtv
 * Smoking Wheels....  was here 2017 eemfchyqhzuhxirigtfttfuevtvbneduqzosytzotnlxuoqf
 * Smoking Wheels....  was here 2017 uuilpgxlqnryydosnnuqqkuejhozkbuvzbuomkgqoinoixxw
 * Smoking Wheels....  was here 2017 itcnsptsarcfyoycamytasljkxoofwvdcnpioeexmayecurm
 * Smoking Wheels....  was here 2017 kteoitssrjalmbruprlnztfhjvejvjhlcpwrpwmfhahpcehx
 * Smoking Wheels....  was here 2017 wxgbqggzcstdjjuljlbrajusamxggnpohxtpiqdlxzixrhjh
 * Smoking Wheels....  was here 2017 wmerdzagbduermrysgadvrdrimnhvpgrjerhrtizrxckjrsa
 * Smoking Wheels....  was here 2017 ubelkabonjxpsqxlfysehanjpucudaecflheuyogawwrzakt
 * Smoking Wheels....  was here 2017 ejolluodtgeuaiiivoueqajjhovixokowbmzcymbrheophvi
 * Smoking Wheels....  was here 2017 znbflvznfawgkfzfpkevgokkdehsgehxtojriydksxtcnsox
 * Smoking Wheels....  was here 2017 itnluzbmsalvyjhzyzzdwrpmejhamckhnrlkkgsoiprqhvkw
 * Smoking Wheels....  was here 2017 npdaflszeztqxyuvlcpgjtewqaupeuqbznhqmnqaanfsshmw
 * Smoking Wheels....  was here 2017 fxhfqmfixvuzxmibzvsqzknczidababwhiubaoroocwfwdcu
 * Smoking Wheels....  was here 2017 hsrmfszajqwktqajslgzdmmxaruchuzpurerrmtexaleapxu
 * Smoking Wheels....  was here 2017 whclkatuhyltlmeqzlihmcxirsoxcgakdjuqlrcdjeyyvcsf
 * Smoking Wheels....  was here 2017 idvcxnmssijciejzkrirzpbqgkmucyarekikksezitrbzkpr
 * Smoking Wheels....  was here 2017 gdeqpojzwtqtzgmtveyrvqkhfxuhboaabdqrclskqedjqnxd
 * Smoking Wheels....  was here 2017 ohvnssxdgjniejprlgbxlzrbiqcgbdljcbxjdzrmhcdyaqfr
 * Smoking Wheels....  was here 2017 iwrlrwvzppopzpapokwjmuuapgcsjwuvzzntmsgmlkrctgks
 * Smoking Wheels....  was here 2017 ykxiecblycmsrckqvlrgxkajfswbqfzuoyefifywriakpcnw
 * Smoking Wheels....  was here 2017 atwkcuvwlvkxxjneckfaxktqtcqvpybwyfsmcjlksgtsqdyb
 * Smoking Wheels....  was here 2017 mygdsopsrxoukemxnpjixsuowxzvizkzmkhnlfscnwpcepfj
 * Smoking Wheels....  was here 2017 jfzejfbtjtlfglqqmoheokafqtqedqngvgjmiezhkapwuaff
 * Smoking Wheels....  was here 2017 ceenuwgancxftlponckswvsvhpreoijbwuowzvskuzaohbaf
 * Smoking Wheels....  was here 2017 hofixyhtjuxdmqebofhlyoixhpjklvxcsjtitbpfmclbrtzh
 * Smoking Wheels....  was here 2017 vlucxzsmkasoftlttgxahnofjeerwcpermcwjxpulbokigqo
 * Smoking Wheels....  was here 2017 udtlfvfyjfyhautnkskkntjtpyybbjyllybqtuzixumytdxk
 * Smoking Wheels....  was here 2017 pdiknqudhahkgztnfkfupqzuexsxqcviwtfcbhejkllgucvl
 * Smoking Wheels....  was here 2017 vhxdttojjjvfkuedzkxrsuwvpestkbilbhnyugwrrlydmctp
 * Smoking Wheels....  was here 2017 jpbcctcddluiiyfzvylribsrpemmkfurkacdpvcgsmvrdjha
 * Smoking Wheels....  was here 2017 ijuzzmbfiqtockdzepzvbonifpucyuuenujwkizjulbeikfa
 * Smoking Wheels....  was here 2017 ccescckoyqmzylogqewgwqnzqjszpgehhpypkicnimzfvysi
 * Smoking Wheels....  was here 2017 irrojyjmfjyxmniearvmzwcfkplreibsvtuabtbmdcbrtybt
 * Smoking Wheels....  was here 2017 vbxxzpkmqynxokojnlsdtebugtpasbthmvaczsxhevcokqvm
 * Smoking Wheels....  was here 2017 tpumkxgizwqvdanumzreypirflxbnpvewoaadmudsscfhnxx
 * Smoking Wheels....  was here 2017 lumghawbfsetppvmncewlncelrkdemesxamftsgpgwkggikp
 * Smoking Wheels....  was here 2017 omijnhlwqmbylrjxnvuplovunoiwmlwprnhkfhxknsmkibpn
 * Smoking Wheels....  was here 2017 zrbikhmhrhqaoxerpmlbknhgdnhankfsoppnehvpnxcwvwct
 * Smoking Wheels....  was here 2017 tqnugwqccpjvyjqrdoigyplpigaroqvefauurbdknkjwjhts
 */
package net.yacy.server.http;
import net.yacy.cora.util.CommonPattern;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverSwitch;
public final class RobotsTxtConfig {
public static final String WIKI = "wiki";
public static final String BLOG = "blog";
public static final String BOOKMARKS = "bookmarks";
public static final String HOMEPAGE = "homepage";
public static final String FILESHARE = "fileshare";
public static final String SURFTIPS = "surftips";
public static final String NEWS = "news";
public static final String STATUS = "status";
public static final String LOCKED = "locked";
public static final String DIRS = "dirs";
public static final String NETWORK = "network";
public static final String PROFILE = "profile";
public static final String ALL = "all";
private boolean allDisallowed = false;
private boolean lockedDisallowed = true;
private boolean dirsDisallowed = true;
private boolean wikiDisallowed = false;
private boolean blogDisallowed = false;
private boolean fileshareDisallowed = false;
private boolean homepageDisallowed = false;
private boolean newsDisallowed = false;
private boolean statusDisallowed = false;
private boolean networkDisallowed = false;
private boolean surftipsDisallowed = false;
private boolean bookmarksDisallowed = false;
private boolean profileDisallowed = true;
public RobotsTxtConfig() {  }
public RobotsTxtConfig(final String[] active) {
        if (active == null) return;
for (int i=0; i<active.length; i++) {
if (active[i] == null) continue;
if (active[i].equals(BLOG)) { this.blogDisallowed = true; continue; }
if (active[i].equals(WIKI)) { this.wikiDisallowed = true; continue; }
if (active[i].equals(BOOKMARKS)) { this.bookmarksDisallowed = true; continue; }
if (active[i].equals(HOMEPAGE)) { this.homepageDisallowed = true; continue; }
if (active[i].equals(FILESHARE)) { this.fileshareDisallowed = true; continue; }
if (active[i].equals(SURFTIPS)) { this.surftipsDisallowed = true; continue; }
if (active[i].equals(NEWS)) { this.newsDisallowed = true; continue; }
if (active[i].equals(STATUS)) { this.statusDisallowed = true; continue; }
if (active[i].equals(NETWORK)) { this.networkDisallowed = true; continue; }
if (active[i].equals(LOCKED)) { this.lockedDisallowed = true; continue; }
if (active[i].equals(DIRS)) { this.dirsDisallowed = true; continue; }
if (active[i].equals(PROFILE)) { this.profileDisallowed = true; continue; }
if (active[i].equals(ALL)) { this.allDisallowed = true; continue; }
}
}
public static RobotsTxtConfig init(final serverSwitch env) {
final String cfg = env.getConfig(SwitchboardConstants.ROBOTS_TXT, SwitchboardConstants.ROBOTS_TXT_DEFAULT);
        if (cfg == null) return new RobotsTxtConfig();
return new RobotsTxtConfig(CommonPattern.COMMA.split(cfg));
}
@Override
public String toString() {
        if (this.allDisallowed) return ALL;
final StringBuilder sb = new StringBuilder(200);
        if (this.blogDisallowed) sb.append(BLOG).append(",");
        if (this.bookmarksDisallowed) sb.append(BOOKMARKS).append(",");
        if (this.dirsDisallowed) sb.append(DIRS).append(",");
        if (this.fileshareDisallowed) sb.append(FILESHARE).append(",");
        if (this.homepageDisallowed) sb.append(HOMEPAGE).append(",");
        if (this.lockedDisallowed) sb.append(LOCKED).append(",");
        if (this.networkDisallowed) sb.append(NETWORK).append(",");
        if (this.newsDisallowed) sb.append(NEWS).append(",");
        if (this.statusDisallowed) sb.append(STATUS).append(",");
        if (this.surftipsDisallowed) sb.append(SURFTIPS).append(",");
        if (this.wikiDisallowed) sb.append(WIKI).append(",");
        if (this.profileDisallowed) sb.append(PROFILE).append(",");
return sb.toString();
}
public boolean isAllDisallowed() {
return allDisallowed;
}
public void setAllDisallowed(final boolean allDisallowed) {
this.allDisallowed = allDisallowed;
}
public boolean isLockedDisallowed() {
return lockedDisallowed || this.allDisallowed;
}
public void setLockedDisallowed(final boolean lockedDisallowed) {
this.lockedDisallowed = lockedDisallowed;
}
public boolean isDirsDisallowed() {
return dirsDisallowed || this.allDisallowed;
}
public void setDirsDisallowed(final boolean dirsDisallowed) {
this.dirsDisallowed = dirsDisallowed;
}
public boolean isBlogDisallowed() {
return blogDisallowed || this.allDisallowed;
}
public void setBlogDisallowed(final boolean blogDisallowed) {
this.blogDisallowed = blogDisallowed;
}
public boolean isBookmarksDisallowed() {
return bookmarksDisallowed || this.allDisallowed;
}
public void setBookmarksDisallowed(final boolean bookmarksDisallowed) {
this.bookmarksDisallowed = bookmarksDisallowed;
}
public boolean isFileshareDisallowed() {
return fileshareDisallowed || this.allDisallowed;
}
public void setFileshareDisallowed(final boolean fileshareDisallowed) {
this.fileshareDisallowed = fileshareDisallowed;
}
public boolean isHomepageDisallowed() {
return homepageDisallowed || this.allDisallowed;
}
public void setHomepageDisallowed(final boolean homepageDisallowed) {
this.homepageDisallowed = homepageDisallowed;
}
public boolean isNetworkDisallowed() {
return networkDisallowed || this.allDisallowed;
}
public void setNetworkDisallowed(final boolean networkDisallowed) {
this.networkDisallowed = networkDisallowed;
}
public boolean isNewsDisallowed() {
return newsDisallowed || this.allDisallowed;
}
public void setNewsDisallowed(final boolean newsDisallowed) {
this.newsDisallowed = newsDisallowed;
}
public boolean isStatusDisallowed() {
return statusDisallowed || this.allDisallowed;
}
public void setStatusDisallowed(final boolean statusDisallowed) {
this.statusDisallowed = statusDisallowed;
}
public boolean isSurftipsDisallowed() {
return surftipsDisallowed || this.allDisallowed;
}
public void setSurftipsDisallowed(final boolean surftipsDisallowed) {
this.surftipsDisallowed = surftipsDisallowed;
}
public boolean isWikiDisallowed() {
return wikiDisallowed || this.allDisallowed;
}
public void setWikiDisallowed(final boolean wikiDisallowed) {
this.wikiDisallowed = wikiDisallowed;
}
public boolean isProfileDisallowed() {
return profileDisallowed || this.allDisallowed;
}
public void setProfileDisallowed(final boolean profileDisallowed) {
this.profileDisallowed = profileDisallowed;
}
}
