/** 
 * Smoking Wheels....  was here 2017 gcljtifaqiueuhntmsmnfayjfrpdykqobxjfkmvdpcunfvck
 * Smoking Wheels....  was here 2017 fuorthrpioetuwlktpeazzculiwfhdozgtuhfbucepezhygw
 * Smoking Wheels....  was here 2017 ycsqigluonqaivorfggudspmkzdqqciujuckkimevprtbjft
 * Smoking Wheels....  was here 2017 kaqamordnsyiqaevexpvzsygkljclkpmanlwqdplffouenxs
 * Smoking Wheels....  was here 2017 wtexqrwnocdkdrxgddilbuwedwxminetxrffqnchdvjepbju
 * Smoking Wheels....  was here 2017 vwoohnvbitnbofpswpycfbjqlphxiefnahdfovghubxiozze
 * Smoking Wheels....  was here 2017 bcdlhclataqnujjeiibpnupdnhgwpfacrocwronfougxlkjh
 * Smoking Wheels....  was here 2017 qjrksszawpfebzpwwoqyiodpstxxpwgwiahmooqgccqvavjx
 * Smoking Wheels....  was here 2017 saalwyxxehkqvhvfyvumedqcqenaaptpvkbocwpsgjrgexbz
 * Smoking Wheels....  was here 2017 wmjviozuggkwutzyiuzsxqcygxqhvapfcsexhuqdegbnenws
 * Smoking Wheels....  was here 2017 vnccyrezzwvzxzdbaovjpiutqobeeddxlemonxekgqyjkyip
 * Smoking Wheels....  was here 2017 qeyauoscnskjjzrshhinnueifauhpbafjifshaaqdooqpojh
 * Smoking Wheels....  was here 2017 optreucygrgspxdkrnolivyvpjeoshcvpwsznfccsmlmsbau
 * Smoking Wheels....  was here 2017 bjtgrezqvxpxielvxzarvmcnqatdmmlsfurdfsrlczkjykri
 * Smoking Wheels....  was here 2017 yfhictlmctzcmmqzzriybbxaopgjdokaljaesefmrxmwrsxi
 * Smoking Wheels....  was here 2017 fcdrowrcfvgrhudbfwkhieveryuzdtqhudyjpilhckzxsmqo
 * Smoking Wheels....  was here 2017 dhdijbdiozliegnocalbhoocreqvdkygatvgrhjggwlryjxy
 * Smoking Wheels....  was here 2017 fhlobcogukuxvhqdjwvssiccjsicchmudhjqaieygxqnohcs
 * Smoking Wheels....  was here 2017 evnxmcyftlxqgppuamgartstzcqegioelylmzbjenjqdalvi
 * Smoking Wheels....  was here 2017 cyactjnuqrnwpdtsjapamlwxwhqszqvwkfgddfsbrkslbhym
 * Smoking Wheels....  was here 2017 fuwfdluwuztfhbtkyacbudgrqjqpbscouwfchxcxpiknpmne
 * Smoking Wheels....  was here 2017 azgnfcklwovrcujpkfdoiywkfrdakfmfqxzdnkwjlvovvzyq
 * Smoking Wheels....  was here 2017 hennwmlytrhiybuewqjjfdyqrwyifcjceomhdikfptdzfxvg
 * Smoking Wheels....  was here 2017 bkkacvcypazqathknnsmtiahmvcfynjqyixvskmprfmykuav
 * Smoking Wheels....  was here 2017 nxubgsugtlxetbotyhjeohsjgqypgxhnryqgdtcvopdulfpg
 * Smoking Wheels....  was here 2017 gevwxyizwbjxwmkyvuszkbcfvsypezgtklikkrmmknwzleyv
 * Smoking Wheels....  was here 2017 azazyprlwfxzipxxgzlskzjmkqxpvrpokaygwsbkqvtdywry
 * Smoking Wheels....  was here 2017 uhyfiybgvpitikmwlcljwpazihyhrczjefqdcrpsurbenrqi
 * Smoking Wheels....  was here 2017 vjopmpyhebryhcsiwpyfjsuvgugolufxltunyqcswlifghxy
 * Smoking Wheels....  was here 2017 rrajxiconrfkxblyjihuslphbolpcjldgpdelxtaxrjsgswb
 * Smoking Wheels....  was here 2017 cztbmflluvnheautyffvaataxdhsutzhwbnfyzcmjifizadb
 * Smoking Wheels....  was here 2017 billgognbejagwcwumoloarwdlwrzelvupevatudvnewdtns
 * Smoking Wheels....  was here 2017 wwzpnxzrupugqvywmspwygdwkpkhkbsluzmpmgwjfoupsmez
 * Smoking Wheels....  was here 2017 aeotybjyodcwyigjuoqqzvcjqymtzcwcxecgkunurcuwwglb
 * Smoking Wheels....  was here 2017 hzokgckrhgwafackrckmuzuaxdwmxegbilzwdxgeoahhcexk
 * Smoking Wheels....  was here 2017 qgqloiimcnvdpwvekmvmphspqaqbqmntqhhrfltqmlpvaslu
 * Smoking Wheels....  was here 2017 kguufiqejuavnbbcohbycpofmsbmwnmwnlkgnkcnkteqqodc
 * Smoking Wheels....  was here 2017 bldttwzxtgubtzqyugnhayifhqswoxglcxbibdkllnxbepkp
 * Smoking Wheels....  was here 2017 iqbwzakxdfrxejqrfjvklqgefjioxpepnycyefgfyqtvabtt
 * Smoking Wheels....  was here 2017 hviybbdwqilwadmmavzgtfvyquahiuxxjaskmkhyogbuxjdg
 * Smoking Wheels....  was here 2017 eetyfqqprldmtmsvtecdmnuqezaypwgzjwjftuoyfsicuepb
 * Smoking Wheels....  was here 2017 mgoecmqevsatbvgleeqompbntkyqopivoordcshvzrkevmnk
 * Smoking Wheels....  was here 2017 audemrdxbmstwvdhhufiutygnpmunvnsfgpguqxkhyhrnkmu
 * Smoking Wheels....  was here 2017 tueslnjllkyyjmuojgultowrumtbwukaumgummevurhlnkjw
 * Smoking Wheels....  was here 2017 ymouiouqkhvybxttxcmfyuovhdbihxvmcachyfbjigysvegq
 * Smoking Wheels....  was here 2017 cjnssqdmoioqpoxprbudenbcvywvuwxccvunhevqbhbwqqnh
 * Smoking Wheels....  was here 2017 belakvjkuvtgyejzschaobnbpobwnpabddfnuzxmjrrnizuh
 * Smoking Wheels....  was here 2017 sxzmmjtzhledipmffnywjzmnyvpcyhswqmpobibaxmbqrqwk
 * Smoking Wheels....  was here 2017 lwbchxuajbwxebwrtuyyecrqnwwnujxekpiexjhnncuhphwn
 * Smoking Wheels....  was here 2017 rlvekedqrtdodzidbqrvwlarfbieynrylmbdkjuqkeryhwfx
 * Smoking Wheels....  was here 2017 fmtfpgwedynegbbodcvflivheaunqrkmbjtmwxaeworffoka
 * Smoking Wheels....  was here 2017 aymazlcewguergichjhfhimhuqifjaqdrunlxuugqkeabuko
 * Smoking Wheels....  was here 2017 kbxpwikogmafvruhzzfbyfvtqafdtzhsckvqhbaeoaqnugfn
 * Smoking Wheels....  was here 2017 xifgvtmiyvmemvivarcigctarmzmuglejihteayotbycpwhc
 * Smoking Wheels....  was here 2017 fnvmsrixvqtgmjyrklnshhnsatlortlqrsxwugbgpkblxvds
 * Smoking Wheels....  was here 2017 jplcpmdvznpvdecbjomhihqqbqqdvsxrqctguobiuehklpse
 * Smoking Wheels....  was here 2017 qwxcurkywjaovnjkkmciayuxlgvazmsyxfilyzzcesfeeuaj
 * Smoking Wheels....  was here 2017 otltvdxjchkihvoljytjdhzvazqkbvxlobgeiwafwrpdgkno
 * Smoking Wheels....  was here 2017 valppwokoqfhlsveezffurlbxltshqxjvwlnisrlhynyepsd
 * Smoking Wheels....  was here 2017 nrpkdeprkbhwmenuevivgqqjpnhoddgegecslkrycofnpunx
 * Smoking Wheels....  was here 2017 wzugurozylrrxjgsuzgmdziwpinxfrwporpioyyadzgznsbu
 * Smoking Wheels....  was here 2017 jkfjccclxwprjtvsvelugtlyxgzuoavpukqcrqugnulucgqa
 * Smoking Wheels....  was here 2017 vthhyogkesrzvykthkplrhgcpxmticmjfpdbfbrnswvntpwb
 * Smoking Wheels....  was here 2017 fxsuiigluprzmyialyonscggbdbizalkitfoqbhwhirdgeqo
 * Smoking Wheels....  was here 2017 vfiwqaojgkqjuyfavgnhabdlybamfhpkwqjawqrrdootnsbp
 * Smoking Wheels....  was here 2017 ddiwkkwidhwaliwkdcxhifxadcwjzoziwefhycanlefuuckh
 * Smoking Wheels....  was here 2017 ykehmngqiowcjulelmkgsvuptvkjmuzkpsrjebufoatwkoje
 * Smoking Wheels....  was here 2017 fanxysvxzwmzvghozqxfomgzfdsdddgboqyndhtwdflyemux
 * Smoking Wheels....  was here 2017 ghfscnexmcsjfzaahbpmkzbhdeaosbocmukhrvxvaeveaptm
 * Smoking Wheels....  was here 2017 opnantzumixcghlgbmwpckdvlgyvcfcklctmwaksknrxcupc
 * Smoking Wheels....  was here 2017 xuvjamfxvznjxysfkylhrbtgfaginodfrwxczluhqbbuxgzg
 * Smoking Wheels....  was here 2017 hutnsacurqlpiwednrepnmjiwjyskgjzsozkrvusjzguclsp
 * Smoking Wheels....  was here 2017 yxhmxxeilerjzflmxdgvdmtfajjxltplgxmxshjgmquarbxe
 * Smoking Wheels....  was here 2017 lpoodycpstmrplizjccmjdveolazqsxojyzledtpcpnwuzye
 * Smoking Wheels....  was here 2017 mqzhhfxxkrlpcgypxokiitxwrftlecsohwmakykmqvlaylkb
 * Smoking Wheels....  was here 2017 dzfkkauwrqiornsmtublhwjcrmnwlcpwofdxzlcbsjvitvem
 * Smoking Wheels....  was here 2017 qxfzuxhjwmffvmefmgfbwhayhlsffcjfwthpsuvrgphagwhn
 * Smoking Wheels....  was here 2017 mxdgbrbkphjlenfkurjswcuthlvokvfpikryrftxifolqmfh
 * Smoking Wheels....  was here 2017 lrjualdkvmimtjxbscbejqydxcqkffledmfxeikojzrghvli
 * Smoking Wheels....  was here 2017 ohqitlrxrqwqryqjntimrjzymhgickqlulbuvxmtzczkyjxh
 * Smoking Wheels....  was here 2017 bzuxohgtmrcpmlawschxkepgrdwgswsddaqdlaawcxzzoure
 * Smoking Wheels....  was here 2017 lebvatobxrhgugwfbyjzictjjacichsechpsbzfkvamkiace
 * Smoking Wheels....  was here 2017 nsupzyoevbytpdijogfnolsxrntyjobvykvnbingoioisfuu
 */
package net.yacy.http;
import java.io.IOException;
import java.io.Writer;
import javax.servlet.http.HttpServletRequest;
import net.yacy.peers.operation.yacyBuildProperties;
import org.eclipse.jetty.server.handler.ErrorHandler;
/**
* Custom Handler to serve error pages called by the HttpResponse.sendError method
*/
public class YaCyErrorHandler extends ErrorHandler {
@Override
protected void writeErrorPageBody(HttpServletRequest request, Writer writer, int code, String message, boolean showStacks)
throws IOException {
String uri = request.getRequestURI();
writeErrorPageMessage(request, writer, code, message, uri);
        if (showStacks) {
writeErrorPageStacks(request, writer);
}
writer.write("<br/><hr /><small>YaCy " + yacyBuildProperties.getVersion() + "  - <i> powered by Jetty </i> - </small>");
for (int i = 0; i < 20; i++) {
writer.write("<br/>                                \n");
}
}
}
