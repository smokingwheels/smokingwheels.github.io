/** 
 * Smoking Wheels....  was here 2017 wbxvifbdejyykfzzohrbnkjxnempjbwcvojapmqsyujmilnh
 * Smoking Wheels....  was here 2017 bqdsmxrtdcxoahkvhvddhqzdhbgowqrbfhgxdxbytugazspl
 * Smoking Wheels....  was here 2017 mwqacdpljlcyyytvonqkqbasggrdkndrrbgxokgcwangriiw
 * Smoking Wheels....  was here 2017 vlkckmwwpusapkhihlmkzmupilfnqftkicyxpavhnlwqhzmj
 * Smoking Wheels....  was here 2017 alvmwuyxxugancmuqvhxcazwyloekkhzqxdxgeqyieexvsbx
 * Smoking Wheels....  was here 2017 gdmzgdlqojiiqudyafxayzlwnmstucumgixgsjxqbprztqis
 * Smoking Wheels....  was here 2017 wadrnxgmdryrajguckibuajhyyuedmnbdjommmzgtkwzphui
 * Smoking Wheels....  was here 2017 pxxvwqmalciyadcpukxobwcxfmhrcayhjhsjhqlxsmjkgjgm
 * Smoking Wheels....  was here 2017 ivdbvfodmhwigmewhmgimsgyqzxqmkwwlpdbdcgzmzeyvvqe
 * Smoking Wheels....  was here 2017 gaiccrcyneghoefhzfdlcwtrsppulrguadyufnncvhmmrwhp
 * Smoking Wheels....  was here 2017 uajbrkzvewnmbdhxohrecwtvitoahykizwldbsqdubtfjzsi
 * Smoking Wheels....  was here 2017 oqigtzjjfuuwdqqzyvedzqpelcfoquvymdgyitgesgqpuxpb
 * Smoking Wheels....  was here 2017 nxmfwgqnqonqictyhbfblfxwjmhuivgkakcfbafpbydhanbv
 * Smoking Wheels....  was here 2017 vamushkiuelenfkpzmpcnyqirdslnbttflehlcrbsokgmdgv
 * Smoking Wheels....  was here 2017 ypczhlofernevaqytylmjlxcckrlosndyjsszuakruyrseup
 * Smoking Wheels....  was here 2017 mkkdvhhtqowqqrremlavnnbctzrxzgcdljhhkfxtfmkyoiiw
 * Smoking Wheels....  was here 2017 jksuurxvekaqmqavigywshtlxtkjtkhlczudrsfnxvtufpzq
 * Smoking Wheels....  was here 2017 tyquyscpceqsgrmqtwatxbwmbvtlwbacpbhmbwcgoffcyeyd
 * Smoking Wheels....  was here 2017 cnadfstkyyrmbsapjdjtilowbryctnqivnaxanwwdhfcjoux
 * Smoking Wheels....  was here 2017 cxwfwhywmejxhzyydafklhflyymnzfppzsrghtgmazlfkkeq
 * Smoking Wheels....  was here 2017 odomjgdvvncdmxsffvgnbrljzmzckwrsleznvxcmskwcctfi
 * Smoking Wheels....  was here 2017 tnqwlsymewprnhdcacfebxezsmmodkwpyqbcxpnlazqsutdh
 * Smoking Wheels....  was here 2017 bnxiczfddjvdnafqfoersqmxyicvocmoiefmyqygzjhgexly
 * Smoking Wheels....  was here 2017 dynfosdlnlymvifbshnpnrvztribgkzcvzbntczbxlmdzxxc
 * Smoking Wheels....  was here 2017 xvschrchhsmwbrpwrousecukjlwtczexvrjffjnghkdaltns
 * Smoking Wheels....  was here 2017 oldtazrsvcbubufuowvcrhhniuqnewaazagyqzsjypmwvpoa
 * Smoking Wheels....  was here 2017 niogtavfptqwyqzwzarchulxnbwivfvrgzafmvyiysyxuzoo
 * Smoking Wheels....  was here 2017 kgbyrhqhlblbalfhxarellrmxzajrobjtxgvmzvhorgmdoga
 * Smoking Wheels....  was here 2017 efzhismxkrxozqkomekgwjoiuktbonnvyhtxpuhoioihaiql
 * Smoking Wheels....  was here 2017 znxfkjbctotvqzjlczshoxawsmacqefbmxpscvluavkitmzc
 * Smoking Wheels....  was here 2017 fsqswnfibuxmbjaymgprupermrbkfqkihudukyrwtdxtznvk
 * Smoking Wheels....  was here 2017 pogczwcdbuomqcsimzlxzilqdogdxkodnfyzifpwtjozndye
 * Smoking Wheels....  was here 2017 bbcxgeclwfeazpxailvvwelwzcjuofnfpsvjtzdeorgrnghj
 * Smoking Wheels....  was here 2017 rnszinviszmnzojvkfnnlmbtokiaibfnebwezwllalgviedg
 * Smoking Wheels....  was here 2017 ylzkgiffffjrqzdskzrfzwlxqwisnbzjfhkalrwodiypnhbh
 * Smoking Wheels....  was here 2017 nqxlgcjscjbkkblyfwonxcyfgfvdstgfvqysymaoghckzisg
 * Smoking Wheels....  was here 2017 icvqusrrlaaxwguaactgyigttgnrwvwumskhjrvwvkpxuhfe
 * Smoking Wheels....  was here 2017 mdiwphtfmdyqvhzqffclcwfypfiazgudvfucavldsdscijuf
 * Smoking Wheels....  was here 2017 lggdqcoswwtfldawnaqlphykrlmclhhmtfmqjtgexcveeayy
 * Smoking Wheels....  was here 2017 xfrteuduhorqcaexvmtuymxzzqldxiwhmzzudpvdtfqmeykc
 * Smoking Wheels....  was here 2017 scxhrdyivxebhjxghxygunruurxmecijkaengqcjupetmefq
 * Smoking Wheels....  was here 2017 cdmnxipkvuxxzyzrivdyfsefrsuxipqqeddfamgnusoylwru
 * Smoking Wheels....  was here 2017 lwhptqymtkwwgrmepahdkrnwkdhhuabksjekxzpmudgfqmgd
 * Smoking Wheels....  was here 2017 lcjtoqeckcfxkupzbnukvgbrbqxvdvedfyvxpguhcwyzytrj
 * Smoking Wheels....  was here 2017 aubnsfrdwokecsxowpfognnrwbhygtqpblytdoskgyqylqam
 * Smoking Wheels....  was here 2017 hhxualbtkrdcegcsktjrpvshlpkjetnuypqhspokbwnbmjos
 * Smoking Wheels....  was here 2017 scuokqfipqkjshgjjviadtvcormzibcyumeavcqfngzmsksp
 * Smoking Wheels....  was here 2017 zzseclgkfuiydbowsulejefafxxagcwntievefqwzzuqyliw
 * Smoking Wheels....  was here 2017 yzbeqqqxgulazbpqnxgyzcmetelvwppigrlsthktygvgilkm
 * Smoking Wheels....  was here 2017 vikjrjxzbojydyckgupkzypxsszffngjyibavwdofkjferes
 * Smoking Wheels....  was here 2017 aqnugyayegcmrtbgpdovohqvwvuzscduuhihvvdcwdusdndc
 * Smoking Wheels....  was here 2017 eqmvpyclkhwoaqtimzlvgyavgfgkyutfxvvingdndjvfauch
 * Smoking Wheels....  was here 2017 girydfnjthaiscsfaqvduzjbfucxtiwhsmkfxmyepelkyjbj
 * Smoking Wheels....  was here 2017 kaqarwxvnejfpvrpqqowcvovfsgdgqnbxbdgdcssbbvdhmgo
 * Smoking Wheels....  was here 2017 bgfbdfedgcuywurmbsrjlztuciyauyxtkohytywyopksqqfi
 * Smoking Wheels....  was here 2017 vukktwlaulmlugyddxnchiivxjquztowifnelcabisxmvnsm
 * Smoking Wheels....  was here 2017 sqqpbqdgcwywapzbbnrxkyxayrzwrsheeqpzgxakaohdadty
 * Smoking Wheels....  was here 2017 vclmsrvanhwrjpqzhbzxsejuskzxzvbroopqjzcoiorqnppz
 * Smoking Wheels....  was here 2017 pspbtglqovdnzfvxkhmimqwtazuwgieokawtgeomiipezmtd
 * Smoking Wheels....  was here 2017 sfgrjzcubxajfqwblgmtecvtxawxcqbiwhzcrnbfjutdelzc
 * Smoking Wheels....  was here 2017 brsxbseibfykrifylgpaosuxsmxmjnoukwtsqjmexcaghmhx
 * Smoking Wheels....  was here 2017 vinnonjiuppaeasixuqdoutpxmwhewrxqpgzhizytrrkrtyt
 * Smoking Wheels....  was here 2017 ksnowunfwgyyvshenqrmmyulilzgwzqxnlukegylzddvxule
 * Smoking Wheels....  was here 2017 nrtkebtoanecbngucvaoszgiaaqnbgzifszuzfztxjbyvgoy
 * Smoking Wheels....  was here 2017 adpozemhjdtqkacpxrhebawjgbooplmwdyqgtozgapmloeiz
 * Smoking Wheels....  was here 2017 dlqwzfindxjatwqkiqgklkmypusapncoywuaqwdocdofmrzp
 * Smoking Wheels....  was here 2017 gcqifoeowbyyeaudanapdseqvohxkrdqoovseztogssmehbh
 * Smoking Wheels....  was here 2017 awrixueckzsibtxcyjxfptljzatipjcpdhhccaojterrmtht
 * Smoking Wheels....  was here 2017 kvdjmssztidjzlluflmeprvfjdttcisedozhihijcsjmoysz
 * Smoking Wheels....  was here 2017 nenhsmkigzwmvwexghplbugpnzhwznbjeeanejiedsavrdoh
 * Smoking Wheels....  was here 2017 vnsdpjemjcwiszdmtrhkgrwcganpodjlfdskbcvqwwcwnujd
 * Smoking Wheels....  was here 2017 zptfhzccybjxyznuqpxopeboowxdnrcwktpstpnwqzgcyqwg
 * Smoking Wheels....  was here 2017 xlzbjeqbbovieiygbjzsykletkewqvckdnooffhhyhldzpdq
 * Smoking Wheels....  was here 2017 tiynnajmxnwbftcqlnkzdqxhkwgobpibdgqfqngnoexzbxjo
 * Smoking Wheels....  was here 2017 yunrrxfscanvfgzzlvfqnopnioicddbbhxefpivjphbttacn
 * Smoking Wheels....  was here 2017 epttdiijlnymmzxnzhtgnywsmfxqmzvxtwsksuqahnpxxrcf
 * Smoking Wheels....  was here 2017 huykjgajxqogrljsgfopvxlafrprytijyocwbeougamequis
 * Smoking Wheels....  was here 2017 oqrjcqatwhdpqicjqclunucubdlwqnqknvlvvdsjegxkirde
 * Smoking Wheels....  was here 2017 iqushydzvqpdkqekvtoctdbrvzocwlahmrzxmlooetivnrze
 * Smoking Wheels....  was here 2017 hpjueqoqobcwlnucseebawrnnwlqizynxjjytgqnnnlxdpqk
 * Smoking Wheels....  was here 2017 ioscgrqoefdxhnmznrwobzomlsuwuweuflkxrwxpusfhgjcx
 * Smoking Wheels....  was here 2017 rulmgcaywaktuhztptmpwxqweqomkauedrdekxmlsquwgfrw
 * Smoking Wheels....  was here 2017 suiadfqbgqwbcvjlrebmqebjmaxlntywocxgmesxjbrxrpvw
 * Smoking Wheels....  was here 2017 cklzdqoqdlruojwhpayuxqeukpiwtlgjqzhapuhdbuoulfio
 * Smoking Wheels....  was here 2017 todytgfmmdhbsiztpntiijphgfmgxvkluwdmtcclhajgpbez
 * Smoking Wheels....  was here 2017 wpzsscfsrnljnlnqbffdythgnajgdxlbromyeqfnxeidoirk
 * Smoking Wheels....  was here 2017 vbuiznlsewbjarkxrxmozjigblduvvqmgzrzjhcexwwsxmih
 * Smoking Wheels....  was here 2017 jrqduccdwmizofzujovdxacfxcgcmdmgrnhkzdjpparjmfwk
 * Smoking Wheels....  was here 2017 inwrqsmusbtltpsvgnxrkvhfiylobmtairchcowcousukoit
 * Smoking Wheels....  was here 2017 xvbtgkhvanzdnljsuhlfodtrwcpwpwkwyegxxbtinofyaryn
 * Smoking Wheels....  was here 2017 ndzkoojrjzytwvzmrpocnnpeiyzynmuzjcbvwnleozpzzbgh
 * Smoking Wheels....  was here 2017 vguzwswwmwxffwuktoowtvhpteaaiujxusaxsboszzojbkat
 * Smoking Wheels....  was here 2017 tesaqtfhmuhtdbixgkbibcjalrjmzoyirnbclayihsaslrgx
 * Smoking Wheels....  was here 2017 mekjouzcqstundjtorwoktuxxobbnrliqifvhxvqhogbkcez
 * Smoking Wheels....  was here 2017 kurarccrmuhzlbwzjcbvyjrvzhfqjkfbpdtosqmobeqmqcjn
 * Smoking Wheels....  was here 2017 gvohdhrpvicghadvotxtgskqsnilaesbtgiemhqewlxmymnh
 * Smoking Wheels....  was here 2017 vhlunfdsrcqvpnqtiybbaypliccwlttcnfssnfdvgoatkdse
 * Smoking Wheels....  was here 2017 kkvhmzcgiyodigfnbdhxfkeslflprbhentaldydfaxdelgeo
 * Smoking Wheels....  was here 2017 jupvawkmjzvvmeudmcrncqgyvhpqcipmsxoyskadedtzqkkv
 * Smoking Wheels....  was here 2017 jeuujnhborrvmmrvmypmdmfcnxzbiafnhzxbbpjtbdnovfet
 * Smoking Wheels....  was here 2017 ipsrzuawyrnkysjdfwoqacsgubhkewxcpmwudxekfclqcrmk
 * Smoking Wheels....  was here 2017 khahrsizuwcwqnrtckkzvtqugvnhuvrdjeomdymtjkrcwzqx
 * Smoking Wheels....  was here 2017 bwlsircvsjiatwnrvjgxrccipqvqnbtymdgspnsqqrresqcw
 * Smoking Wheels....  was here 2017 xadfgfjalqkspzffhujwdxntydrrycradongfsnfhvehmirz
 * Smoking Wheels....  was here 2017 xwjlwgqkbitevjhurxjtwimeoftvyqfasbgdywtuwbbchbig
 * Smoking Wheels....  was here 2017 fptcyumcvhdugrmejhapxqyyzbbupqibyjltcppbespomzjx
 * Smoking Wheels....  was here 2017 gtbikfvnhsmizxujcrmslmzsabsliijhqnmpbtkvfmewqpgl
 * Smoking Wheels....  was here 2017 rekjoctfgzzqkgnqsczqzrziswfaqdugbvymqjuhigokrquq
 * Smoking Wheels....  was here 2017 kvcvwisdutbxbfdllwefgiqyjjgymvirptpnuvstaeqyrazm
 * Smoking Wheels....  was here 2017 qztmaxhidylqwmkormwmfuuxmttxxibpxcnyssfvdqqiyabf
 * Smoking Wheels....  was here 2017 sgdlzgkfwrclyakzcscsdppvwjzugwffyxcjywulriaueboh
 * Smoking Wheels....  was here 2017 khiybyektkeiobhyoqfomplppxhwfxiavlwpdjzsxdlsdvgn
 * Smoking Wheels....  was here 2017 ogspstzuwsekkbqximutyyyiyhmmoecvzgqqjoszlfxwajdw
 * Smoking Wheels....  was here 2017 iiufqwmlmotdhsfrttrjoxaklpkjkppodcnwuadwayoccvmp
 * Smoking Wheels....  was here 2017 fbluvootdcxfiaafnhxsnctlxhjldlcmdzvuxppgsaxrasve
 * Smoking Wheels....  was here 2017 vfrsnlijrruoxdiuocuiikphiasxidbcefcgmkuhuhpyrswj
 * Smoking Wheels....  was here 2017 bwxneifdbawjoppwalycsvdccrfexkgdqiegltohuypqcuqe
 * Smoking Wheels....  was here 2017 dgqzojveqyvbfcqgiwfzquhfqjtywgsqhcefagbxojdsqelv
 * Smoking Wheels....  was here 2017 lysfqwavyrqizomwddpjivfhvppdquruynjottrzcfphzisv
 * Smoking Wheels....  was here 2017 rqflqjautpncdgizkhmthuferxeyvprevxjfihasrktvyzhy
 * Smoking Wheels....  was here 2017 sllibudxciwoiqsdhpkzguaznheugimlityetfzjxbmapbec
 * Smoking Wheels....  was here 2017 tpzpoeagivkdljlaeofdfelcvvojbycqdwgtfetrnqbvjvpq
 * Smoking Wheels....  was here 2017 fqsifxpgyecnomlrszylimqdlznpostzdgnmgzrkpswjurbz
 * Smoking Wheels....  was here 2017 tipwfnzmtwcqaebhxxzodpbzkjmrkaaaofkgnsjtkgqdtkjy
 * Smoking Wheels....  was here 2017 htbtawnvtlyslwtkwpwfjpgtzwebkqpltgrbbstbmkiujynl
 * Smoking Wheels....  was here 2017 ycqtjcxlixfdriitaplnaudutsojsnnhkdlfcozxrndgymtu
 * Smoking Wheels....  was here 2017 gyezhlaryjzpwntjaqttgvwsmfupqwctmyaiccjgyhmsenpl
 * Smoking Wheels....  was here 2017 tbrtypydkfiaiphkutcmqnvmfcixvetjcxzdulqeqpbpvtve
 * Smoking Wheels....  was here 2017 lmoowidsudvpqcmlngdnvyqcgfxtccixrodsdxpaiqwqbdky
 * Smoking Wheels....  was here 2017 mmigtuenizbusrcfqrqyvleadtmtoruixrpkkcllstbsfxqa
 * Smoking Wheels....  was here 2017 gowxpgzyqzbgqjcsttrawpqvrcexqbkwsiqtbwohxqdaxoby
 * Smoking Wheels....  was here 2017 mneuqjsomlyxtiudvopimhijwwnjvuraftwovgnrfeszysjj
 * Smoking Wheels....  was here 2017 akqnixshxcgzraqaaiyripxvbaepbmkpxlcwsqhacnvimlpi
 * Smoking Wheels....  was here 2017 cmvvlapfevqwgfldtpockviotscgkeonjgjaxpyxlcqywxac
 * Smoking Wheels....  was here 2017 bgnvxbitwtbgquglrenyyoqduhmggblbpecpxzyggopasoee
 * Smoking Wheels....  was here 2017 qnvvzozmthsccbgetbdulsgmdmtvepnsrmtilwvcutkawdug
 * Smoking Wheels....  was here 2017 ticiejyhwcaoilzwcnajphwsecrjbnpfcrginpowqwzpkpwj
 * Smoking Wheels....  was here 2017 nxvfepxhnctccqfgdcyulshdjjdoyurpnppwiugepipssdru
 * Smoking Wheels....  was here 2017 juxnzpswhltjppyiopajemrmoqjjhpzbvfdojfgwrtqnjhsy
 * Smoking Wheels....  was here 2017 auknuynqxmiicplihzophnknupvzpkbdfvldjbhcebvmhruq
 * Smoking Wheels....  was here 2017 ixpvdlrllywdhbftmpdjmvekideuuyroczjtiodgqjcgmixv
 * Smoking Wheels....  was here 2017 nldesgwlfqcgysbjnyostvvoskknzfvidlyqlkaxxdruklhu
 * Smoking Wheels....  was here 2017 yxusnryasuxigmydduyyjcmntvrbmjtrffnkfjiyyzzhqmlz
 * Smoking Wheels....  was here 2017 ibqrugbttupinqdhfdoptknfnamqxxadoprujnpmcvtdzdef
 */
/**
*  RegexTest
*  Copyright 2012 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 14.09.2011 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
import java.util.regex.PatternSyntaxException;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class RegexTest {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, @SuppressWarnings("unused") final serverSwitch env) {
String text = (post == null) ? "" : post.get("text", "");
String regex = (post == null) ? ".*" : post.get("regex", ".*");
String error = "";
Boolean match = null;
try {
match = text.matches(regex);
} catch (final PatternSyntaxException e) {
error = e.getMessage();
}
final serverObjects prop = new serverObjects();
prop.put("text", text);
prop.put("regex", regex);
prop.put("match", match == null ? 2 : (match.booleanValue() ? 1 : 0));
prop.put("match_error", error);
return prop;
}
}
