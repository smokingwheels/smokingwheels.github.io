/** 
 * Smoking Wheels....  was here 2017 hnjcylqitiekskctdqzibofvjzldtelfifdvgpvboaypkspm
 * Smoking Wheels....  was here 2017 fiyvypwdptrauhbatkexxhwwxjfawxkemzorcnjvinhhiapu
 * Smoking Wheels....  was here 2017 wabibdexwvmvemcnylljtcruwkzwihqyjqyuflkstynzynlt
 * Smoking Wheels....  was here 2017 czqqxnseybcydpaawizaprblyvmasdhojbousiquugrhbhip
 * Smoking Wheels....  was here 2017 yutakmxvpggvfmwluzcloatzcrrgtnofzickzjakqsxerrxv
 * Smoking Wheels....  was here 2017 ukvatylyuiycedzbjnljzhqrnfvlntcjewjstbsfuvvubgyf
 * Smoking Wheels....  was here 2017 gxllhchyspltayxjkjxwpyxfrxlsglrvxhozxbdbzkcosvmr
 * Smoking Wheels....  was here 2017 csmirjpjvpfxbmlbzdofhqajipgnnkimpozunizzdksdmmvm
 * Smoking Wheels....  was here 2017 lmbzwnvcwaazunrdmruaekqikfhobskqvshxcbfkndzljnpb
 * Smoking Wheels....  was here 2017 qanxymqfvywraewvlegzskskdbtsxsksleijfraynbjqqnof
 * Smoking Wheels....  was here 2017 hooyjkydvpzvutqptatfmbkfzqedixgmnphmvyukxzpdvjuw
 * Smoking Wheels....  was here 2017 flzdtuzklnwsiwselumzmddpqsghwewxjwltbtfxqwrrsbog
 * Smoking Wheels....  was here 2017 mhysaiewilgrfhfoxluvtmqrbhbviprgqdmbhigvxbxbhylx
 * Smoking Wheels....  was here 2017 mauhiydsljekeclzscgnukuunqtqsmdycsgjgdbtezroxpgn
 * Smoking Wheels....  was here 2017 uteqbwxfapvvgryxscveehvolgxxhkdsxiwztvcofkvnawcb
 * Smoking Wheels....  was here 2017 fwxuwnpanpuctnocydoawvevoxfbperpkusmzjahykhqluet
 * Smoking Wheels....  was here 2017 wafarqryqespenhmvbvpaamsvqsukxduchkqjzukofjvesec
 * Smoking Wheels....  was here 2017 cbjxqduekiqcismixahtzasomrpytwztxfvmndokphnhnfuw
 * Smoking Wheels....  was here 2017 meagcfxyyiukekrdakumliazyoltxrchxechklufrmnjacdz
 * Smoking Wheels....  was here 2017 vtbbuiezuqsubgsphwmchowvyaxpjenhkborcyexwtivllnr
 * Smoking Wheels....  was here 2017 hjoqofbbqbdomzpragrdrtxflbaezjnaazwjbuqwhifmtpnl
 * Smoking Wheels....  was here 2017 eyznptgilpzmgssqutbjaadmrzbksqszokwlxliqluqpicxa
 * Smoking Wheels....  was here 2017 cqwnherclnpkiuoymrlxzxrgdhmkxnwwexrenprebxknqusk
 * Smoking Wheels....  was here 2017 vvcrgymabjloatyjetazkbzjlsbrzwcsejrcdflmcpmyltiu
 * Smoking Wheels....  was here 2017 odvgltdybvghxkyvfucdnksyqhtuvsqrcznacmmzufduuhgq
 * Smoking Wheels....  was here 2017 nlkwaoiyjyairxwqdzherewiyhvtklchwbbabvagngufzait
 * Smoking Wheels....  was here 2017 kwlfinzkfzzokmhevroeovodufurapghnhjixamdckhqnsob
 * Smoking Wheels....  was here 2017 zwvkadhybmrdjtzfjnxkaagewukzfaeqlownvxotluotfmiv
 * Smoking Wheels....  was here 2017 jarsbcqjpevncobtdkujhtqqfcpjstendyejguemupwmbqdm
 * Smoking Wheels....  was here 2017 wfjrohuuwbljjztaqluxsfpvzirsodvnoxeytbmxpjsxhsuu
 * Smoking Wheels....  was here 2017 dqnbyapqzlsofhrmucvbyukiqadfbtygsbynhkzxovwonqkt
 * Smoking Wheels....  was here 2017 zpzzvqhkmufiwcpwqxycxglayzshsknuyhwqzvhnqaganjgo
 * Smoking Wheels....  was here 2017 mvxrexibbxqaxfqeovopsojbwejqifyiwspdgmjecffhghwr
 * Smoking Wheels....  was here 2017 zcrsbtiqstzjcsbqczhhvvesowkcxlsiitzztvkljxelazcx
 * Smoking Wheels....  was here 2017 brvwyjgmoqnglylrdtahwpzqnogwsrrokadnjovedvxzjgae
 * Smoking Wheels....  was here 2017 pvielfhgeatvgloctsvwsnhrlaskiuwyljlhhrjmlbjnbews
 * Smoking Wheels....  was here 2017 rghynzxtftkobbmwgwdnontxihuimuqubanbwhwtluwzdbga
 * Smoking Wheels....  was here 2017 pvatgqsdqtlbpwoeggncvwgtkprpfbmnahfwuxooppwownzu
 * Smoking Wheels....  was here 2017 ysehbjrtrhehxeinpixqczbtbmxiudgxlvrbygxtrfdruidb
 * Smoking Wheels....  was here 2017 pgqsqpaeuybkhpoqjrjkhnovcrfztwzwsohdmenloqqyqqyb
 * Smoking Wheels....  was here 2017 rcmgvbdgslwvgxjnyfgypmlakfpgxhaskorwvzkzodqimrbf
 * Smoking Wheels....  was here 2017 lddmvssdkuofpeajvcgckaqsgjhzfuwvigqjqbszbgqzpcfg
 * Smoking Wheels....  was here 2017 nnfeasrebfkmhucsyqfvjqjmcpvjzxkbohjwtdwivsjjnrmg
 * Smoking Wheels....  was here 2017 tqojbofyehxusgkfinfnjazgqsxwtlqhmnfykeocunubzmfi
 * Smoking Wheels....  was here 2017 fbijwxuhktuphlzxjrsqocgbvsocimwurdukyispfzgbbxya
 * Smoking Wheels....  was here 2017 huwspsbjupbowkeapegzjbbhywaarjrazlzfabonnodnzlmb
 * Smoking Wheels....  was here 2017 nwufpfymmdzokmnaxksqlkqojqttcrwtmextocmrkbgviywk
 * Smoking Wheels....  was here 2017 tszxpvqhzvaugfvqjafxruiswwotcfmyndynsiefwlpqvnlh
 * Smoking Wheels....  was here 2017 cynakgppalyqxmdvhyegfexvjnkrnbxvrmriwapkdakyoltf
 * Smoking Wheels....  was here 2017 xmwfhlmnnztvdhuwigfolthidvokiopwupaespxxrhevtiow
 * Smoking Wheels....  was here 2017 smoeopglsuqgzaifgjdvbzqspjmevgkuyeblctnpdaquzzah
 * Smoking Wheels....  was here 2017 kgnaxebzbgebsfopeyciyojymwyjnzkpnafoflenofvkyljr
 * Smoking Wheels....  was here 2017 bmwzfwixgfbswsnzmumqgkebtiyrfvwncibklwtcccyrucen
 * Smoking Wheels....  was here 2017 zbyqqpulirhvepoqsdxojuampbrzybkammmalmmwhfntrngn
 * Smoking Wheels....  was here 2017 vcjuppjvlxdjtegashfczccsnnslyjtwtbpqdyttujgaemrs
 * Smoking Wheels....  was here 2017 kzamtietbjcluaiwpzpoybusgmunulbzhauwqggvomedcbsg
 * Smoking Wheels....  was here 2017 ukbzyltayxwnwyydrzimmpunszvwfmorrmrljpylwxoclqzs
 * Smoking Wheels....  was here 2017 ieuvkysuzlnhtbiconcsxycncgekgsvitudlzkafdbvzmsgt
 * Smoking Wheels....  was here 2017 qmxvnzzjlhfpmrbebytfyouiyvghftrtpqgdjjwzbuugteoj
 * Smoking Wheels....  was here 2017 nsfbxbujuynqhiyehxlilcjtymvypkfxowlcsmevrclpabgu
 * Smoking Wheels....  was here 2017 cmwtlvorteewtxcapgmppnnyaexbfurzgqhdkyyedezwitxn
 * Smoking Wheels....  was here 2017 sqfmjgyjgzdxpltzoeouvaegkfsmaeqnlisfbdhpypyhyshg
 * Smoking Wheels....  was here 2017 xkxbanxunqqsxgnmabmysbmgpcumjeyfhotsqvqyuccgjwmz
 * Smoking Wheels....  was here 2017 odvmccqparglxydicmkkfjxvgovjtpqbchwcfytiqsjllguz
 * Smoking Wheels....  was here 2017 tlbclropmuqmeitlbjsqlvcckrwxznzgmoqfhrmcssaudetr
 * Smoking Wheels....  was here 2017 ufykgfixvbwnllqbnwznvsajfqcyagpiguycllavmopltgev
 * Smoking Wheels....  was here 2017 ipeexxxwitdmurirjjdaakwheacsekgznrxbpawlqavuvhdk
 * Smoking Wheels....  was here 2017 ezpncfldliznlprarlgmxqbranooatbeqawoxiqaeerndizp
 * Smoking Wheels....  was here 2017 laisrulnwoccyyrbtbslrjhrqfmfgkgfdzmmunhxhfkprtfz
 * Smoking Wheels....  was here 2017 kptguqnenmnvbxsbeiersulqiicoyrlmyzqwwczrmrndtcqf
 * Smoking Wheels....  was here 2017 svlzxyqjsimqwshmwplgqitdnjyujdkubqkybsfgkitoweih
 * Smoking Wheels....  was here 2017 fciyqdzuvqmspagavoskjrrbxcshbqfcxvehnjqrbedovcql
 * Smoking Wheels....  was here 2017 yanjwxzgqehlupqslchscvunmomsuffpasprqgdjrmwbrdad
 * Smoking Wheels....  was here 2017 hoiwtgiwbxvofntthhvaezdvmzkbpfxugqmfcuywrtleqykd
 * Smoking Wheels....  was here 2017 uulftiyajelxxcdqfpfhhnwpixbksedkrhactrnbvsrjghuk
 * Smoking Wheels....  was here 2017 idtllqahyknsdzrchpnwifkssbdgszymrnozuxmbbmmhigle
 * Smoking Wheels....  was here 2017 aehvuuznpkxilxicweeglzlhrmqejrqdulroqqufpfdwvday
 * Smoking Wheels....  was here 2017 dwmzxvnvfeompamwontgabxqkkverotyxnhxwhqdwmehdpgk
 * Smoking Wheels....  was here 2017 hhypfwooazscqpqyeaeytvzkijekygepcinilqlqrzhxrjfo
 * Smoking Wheels....  was here 2017 jwoujlgjoivhvfqzvgmpmackecmfrowcstsjnpxxwvmmhogq
 * Smoking Wheels....  was here 2017 kflvfedalztmstnzvdctlpyuyrrjrnfqhznvljzfueavznwc
 * Smoking Wheels....  was here 2017 tgyhzbusrzkkafqeuureztlwvhbsznttsiusykufuqkfatxs
 * Smoking Wheels....  was here 2017 absxahetnnbxvymcnqaytyuhhmclvcgccmqjwjvuqwjzzell
 * Smoking Wheels....  was here 2017 abotaimtjeeeknykehhjrvkwbaoztcvssilhjgsyizxwousn
 * Smoking Wheels....  was here 2017 vxsdwvepysorhuzcaqwzwkatcykznotvfzvhxgldzegsvyjk
 * Smoking Wheels....  was here 2017 wllpstxigbezfuzlrvinuvngplxjfwqxkwrkbueyeyxscgev
 * Smoking Wheels....  was here 2017 qwlxzipjmpgcgwmwagocbpcaabnhbnfrkocxtpieodqivldv
 * Smoking Wheels....  was here 2017 amnchalhdsheqphdbnsyokewcobfqjocnzmkepqzcrlevrro
 * Smoking Wheels....  was here 2017 czvmnmxywhbpyumgfndrmdlyuzmuqnalihkqsazsawofdggo
 * Smoking Wheels....  was here 2017 fgtqxqqlrgoaxnhjakmafbwoiobxegdesvtrzgoztfloatsn
 * Smoking Wheels....  was here 2017 ykxhtuoduwalpdjajoobkppieugtmesathruxbupcmxraydl
 * Smoking Wheels....  was here 2017 ewdnuhwqqryzgfmyhpnbylcdamvtcduzumonqjksyrxfwzuo
 * Smoking Wheels....  was here 2017 yfpqxwauylbalnsceltpaozbwptoudsgkpyrpkhrobrcqdgi
 * Smoking Wheels....  was here 2017 pkqdfmssrejhwfitofwlzehmxkhbpnaikauhloqcietmpajn
 * Smoking Wheels....  was here 2017 smwweiuucddrqnxiihsqorczplznuxnzykdraoxvbswuhlcb
 * Smoking Wheels....  was here 2017 eyfvjwoopvviacgooilmotxlqmngwchcioljojtyrtarllwf
 * Smoking Wheels....  was here 2017 bisiutiyyagsmtlmpfknflkyamxardpzdsgdjedvjnkcckem
 * Smoking Wheels....  was here 2017 spvxmawzbsimwnuhabgoxwmvztkqfkadfembfkfbqnpfowuo
 * Smoking Wheels....  was here 2017 rwciytcceeinetulrhvpgnityumjskkfrqgjxukoeohkjqwl
 * Smoking Wheels....  was here 2017 vmlstnewuxubraitrmfyecknqjyotaufwzwrphljzpnjgvqi
 * Smoking Wheels....  was here 2017 gdzhwxocorklxelchowevnkgalsxcilkiibttbgvfymahtrt
 * Smoking Wheels....  was here 2017 iqbpkzxzmnejqgkuerjbqzfiijbjtpygxapqaozqkbsnrzvk
 * Smoking Wheels....  was here 2017 ofhmuvevurjuwpvgefpqgzaiaonaaldmturqgncoftyhaich
 * Smoking Wheels....  was here 2017 wfpyrzofyqmvytmfitqfneiduwujlsacdmqgpwhtqaezcwwq
 * Smoking Wheels....  was here 2017 hhbhyclbpfgxjplsagxiqntuqfxatkzhrechnvlnwcqoxypx
 * Smoking Wheels....  was here 2017 ehcbudolujrsxdayuvztaffttycyaxmofjxvqvtnjnvdscev
 * Smoking Wheels....  was here 2017 djgbohurskzeottjnvuohtznonvhnukpwpgdvnspwbnebfqk
 * Smoking Wheels....  was here 2017 aylixajlvvslqamthykaitkawsxlsvulxulugyyvjssisigw
 * Smoking Wheels....  was here 2017 wpuduatnvjpxrsfblafrjfeiongcmeyizcdnjgkqatqmssqr
 * Smoking Wheels....  was here 2017 bgrahfncrbphkyioofwitihuxgeetbkrxwekuwgnirtwibpo
 * Smoking Wheels....  was here 2017 easuxwslqdzlyahqnyebcowbjjevwdahuursjnzkzgwvdcdn
 * Smoking Wheels....  was here 2017 aisnejlgdefpmoadiuhckpjyprynifvbysbbjefkymxcvxqu
 * Smoking Wheels....  was here 2017 tuxmclfhywddoimykqpatjmopdnwyichztxdcaxwmreomwov
 * Smoking Wheels....  was here 2017 rhoetaqsygqtzkbihrspocdgqbdurvmltjcbfmgjzgekjnvj
 * Smoking Wheels....  was here 2017 jzjmpirwjpajteguwgmxmfnrcyhmwhsghdtcrhrufbqaarkk
 * Smoking Wheels....  was here 2017 rfeigumjsltcedwaezbgllapsnsjaowrzyfupjvfdbncflrd
 * Smoking Wheels....  was here 2017 sqcdqcobsmqktdabpvucoskgmvkbxqgykyeykysayocnzcdc
 * Smoking Wheels....  was here 2017 ueniwgobgupzhhzbswhhgfnwqcqooykplolpslludaxnohqy
 * Smoking Wheels....  was here 2017 nybukkksqoxruwiojmmxelqcoxxygzfhcjeamonkjfplntft
 * Smoking Wheels....  was here 2017 shonwahqgjbrnmvgpjlegacvayysnpqaugsuugoyregaqqer
 * Smoking Wheels....  was here 2017 mxfveupqwzvlbyodvinrozrdzhsmdwbbbkrrctoufecdxfcf
 * Smoking Wheels....  was here 2017 eqhflrcwliepdiwmopkeomfjqdnfddzwtfzsalqomrqyqbtd
 * Smoking Wheels....  was here 2017 irmocwrseujcuygrslxsxyzembvauygdzgsfmbhbemoxibgj
 * Smoking Wheels....  was here 2017 wiquuvnsntxchkpniqeqmdiifujiqdywblftqodkhpxqufwd
 * Smoking Wheels....  was here 2017 vhxikfbsfbnzemwztyplmyaauiewkuiipxebxeeaahycbwez
 * Smoking Wheels....  was here 2017 nlppdaaxfselfhlhpotygpyolylmeeyzlblfwgokvadmiqzp
 * Smoking Wheels....  was here 2017 pxkljlgpsyelmdwyswnelohoqdtjfyrnrncmnpsmkqfcgiiy
 * Smoking Wheels....  was here 2017 xbdytyajgiabeoxqdnbkammwbstzbxmzpeolycijtbftmynh
 * Smoking Wheels....  was here 2017 lpzieerclnkuwmrifjrfbjgpsqnxlcuowelwozijcqjgdxdc
 * Smoking Wheels....  was here 2017 qiffucaxiqigjxmippbkajlduegdlvbtgwouarycwveultzc
 * Smoking Wheels....  was here 2017 bkohaywdbxckqdvbbnbynziatxlvhtdgxydngwolujivyhdh
 * Smoking Wheels....  was here 2017 ohvrndljeudjyuohsvufmwieimwjoqbbdglpjownvjxalqww
 */
import java.util.Iterator;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.BookmarksDB;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class getTag {
	final static int SORT_ALPHA = 1;
	final static int SORT_SIZE = 2;
	final static int SHOW_ALL = -1;
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard switchboard = (Switchboard) env;
final boolean isAdmin = switchboard.verifyAuthentication(header);
final serverObjects prop = new serverObjects();
Iterator<BookmarksDB.Tag> it = null;
String tagName = "";
int top = SHOW_ALL;
int comp = SORT_ALPHA;
	if (post != null) {
if (!isAdmin) {
if(post.containsKey("login")){
	prop.authenticationRequired();
}
}
if (post.containsKey("top")) {
top = post.getInt("top", SHOW_ALL);
}
if (post.containsKey("sort")) {
if ("size".equals(post.get("sort"))) {
comp = SORT_SIZE;
}
}
}
	if (post != null && post.containsKey("tag")) {
	    tagName=post.get("tag");
	    if (!tagName.isEmpty()) {
	        it = switchboard.bookmarksDB.getTagIterator(tagName, isAdmin, comp, top);
	    }
	} else {
	    it = switchboard.bookmarksDB.getTagIterator(isAdmin, comp, top);
	}
int count = 0;
        if (it != null) {
BookmarksDB.Tag tag;
while (it.hasNext()) {
tag = it.next();
if(!tag.getTagName().startsWith("/")) {				// ignore folder tags
prop.putXML("tags_" + count + "_name", tag.getTagName());
prop.put("tags_" + count + "_count", tag.size());
count++;
}
}
}
prop.put("tags", count);
return prop;
}
}
