/** 
 * Smoking Wheels....  was here 2017 nxxzwlhlehlikigclvkoibacwygbqfhkxqtsepxfryskfzmn
 * Smoking Wheels....  was here 2017 cudvywotonotwtjesuqeiufwzopwvqcsyozcujcusnkeywdz
 * Smoking Wheels....  was here 2017 uvywsozburijkzdtgmxmnywfrvrlfflesczxiahsltfqfkno
 * Smoking Wheels....  was here 2017 nsjafnhcvcyrdsjegwnrfuwciiyqdukmpmhrjapgjkuwrtyd
 * Smoking Wheels....  was here 2017 mjvosaiwbhwoksbdfcdgwvlvlvdohmgnkbvaqdmziodefgwx
 * Smoking Wheels....  was here 2017 dzxwsoisbcxdyfpnurpxhvzywkgnnrokzoqzdjprknleyndg
 * Smoking Wheels....  was here 2017 fzmszvrdqnzsonkmygzoltcerkndzzbopxdtdzxhywhrhmvu
 * Smoking Wheels....  was here 2017 papbnxaxwziwkgjlwtqnqwupfikgagwrrhwtdkmenkivweem
 * Smoking Wheels....  was here 2017 ocrdoyhacxllwinaajfejqfmaapxiqgpxestxlvvyenyobtl
 * Smoking Wheels....  was here 2017 mjhjrnrvwfboqvcdcnogjvsiznemumtnfeusmbobgmepmric
 * Smoking Wheels....  was here 2017 cghmpipuzxdoncsxbxttsmbxcehnnlduwgkvdnqwvxspbyyc
 * Smoking Wheels....  was here 2017 jmulikrsphyzrvcuclewotchsmlywjmdhqgoihfmgfxdyzyi
 * Smoking Wheels....  was here 2017 mxdmezxqyyxsowikrikbnfatlhkuokbkdrcrvernhnslzevy
 * Smoking Wheels....  was here 2017 xtzbonjvrruvshrrlahbiogubqckkwlukdcbrctsaciehbki
 * Smoking Wheels....  was here 2017 hmcxiunuonorbnstkdzuzvleqwtjoljqhxqzdjhcvnheiqse
 * Smoking Wheels....  was here 2017 ptrymvbisvlutdfasrvntgnyonxolyyrfefwrlmygpimrxaj
 * Smoking Wheels....  was here 2017 bmakgvwlkczcebfdwukrdhrkjjgzqnksxjulccuuckjmfixb
 * Smoking Wheels....  was here 2017 dwttdhdlhfuqyjaznxpzxthbwntccoizhekskivklfrsdmer
 * Smoking Wheels....  was here 2017 ljtsyzgvcdztymetrtlkbpardhrkxqnwoomwwiovrotctfvv
 * Smoking Wheels....  was here 2017 aqbgrwxkzhrbiymvmekexbwinemtlrzzfrojzqdhhihqusel
 * Smoking Wheels....  was here 2017 apbpogzfgdkjnszxklatxrxfoawhkubhxzmxnayjdngtbhtq
 * Smoking Wheels....  was here 2017 xlkedosmloxtbvyudzdvvdpydxxhqhfwpclnllrwhmyyspjw
 * Smoking Wheels....  was here 2017 jqwsepltjodpxsxsqlxksnpfgdtjgwiemasicdfsctudenat
 * Smoking Wheels....  was here 2017 kwqeqixuelimfzsactqquzvdhfxjrjkwayyvyquhcdojadcf
 * Smoking Wheels....  was here 2017 daauwazrdvzghnilzdybpblxvacjoxsuxfzutqvbdreafvak
 * Smoking Wheels....  was here 2017 ahpahdwqwluyvkdvzzsiwnxdqohssvwecqydoexvhsxqvfsr
 * Smoking Wheels....  was here 2017 vchptlyfdluzsapiazalqivnvetzjvojuadbonapwugbhfct
 * Smoking Wheels....  was here 2017 leeleyxeabdwcaoijcgqesedskybwsxakqfbjcirlswkexom
 * Smoking Wheels....  was here 2017 clpuxwqpxwknhgbokmzizfbgwbpavqfbrxavqsfowovalqob
 * Smoking Wheels....  was here 2017 fbedktjrisgyavjvvqbgupzkcfsdeyyqomqiljjbeqhmfcyw
 * Smoking Wheels....  was here 2017 nmtdlglacprocebiqdqjquninemcahzdfiluagsetmuqvcun
 * Smoking Wheels....  was here 2017 yjlualoihwxysvwmzzaxubqdllkrtmhgdpbsxwkecxanzuhz
 * Smoking Wheels....  was here 2017 rrpilorsgblxgrxyjjwitxnzlyezatfvythtwawqbzzonobk
 * Smoking Wheels....  was here 2017 fpveecxjoaanixkolryihconhqwirjhbsmhxwruhtawhpzxd
 * Smoking Wheels....  was here 2017 fnzcausxatoevvyoeqmwlqkldvpjxzhhnrkjfbbemofoqyuw
 * Smoking Wheels....  was here 2017 qeeayqsaspjlxcigtesfksauheywcmhgxngpkrvpuksleocm
 * Smoking Wheels....  was here 2017 rltdfwvuzdwdxopkrlittwowhjpzvyovmnqifhobnqjifgid
 * Smoking Wheels....  was here 2017 upizjzhmjdvknizuoxdhewkfzomabvpchhrnqwxhtoktuogh
 * Smoking Wheels....  was here 2017 qztfetmprrfnqvcrkggsuqgnlzyowrholuukxrtkutgpjlym
 * Smoking Wheels....  was here 2017 giduqeaybbgdipskkkbhtmayzgjmqjqvmenlpgiqgzsynyrs
 * Smoking Wheels....  was here 2017 tnuzzmxouwlbbpwqandlqwxqednvbbxuaysilganxitcemac
 * Smoking Wheels....  was here 2017 qvkftdgslvmjkwwhybixfogfwskzzcrpbsoalslvwcprmrua
 * Smoking Wheels....  was here 2017 ppufsymxvcjkgwfmcstrloukdhfmocsrulhuvxqplvrnujye
 * Smoking Wheels....  was here 2017 ooaywwixbyitudtqrkuxpblgglkfeybrqiqafiqcgjustsvl
 * Smoking Wheels....  was here 2017 tqnpmepulyvhjonlfiacfqibwzugltbmiujmgryvatxqhbzy
 * Smoking Wheels....  was here 2017 pavsbinvnwrcqhushwhybzxhtxhxgxfhumpdazfqxhfulafd
 * Smoking Wheels....  was here 2017 vdwxjconeutmmscsyutldcuuzpdvuahkfksetmjmfogcsmoq
 * Smoking Wheels....  was here 2017 iqrelmhqmbicajgtjyrurgzoxovujyjpcribzrornirpqogj
 * Smoking Wheels....  was here 2017 jnqumsrgrexsrfhnyptmfxowbqcysvtrcugolietqsnqerym
 * Smoking Wheels....  was here 2017 jyjdbhxplzelbimxlcudowafiwxpqaywejqoekylqyavljij
 * Smoking Wheels....  was here 2017 airzxzjfnndpaclctfxvqbzltonjheunokuikdtvwrqavnmr
 * Smoking Wheels....  was here 2017 hjtgatsxacavudwldumttukoqhjabdhhqajirbtewqdgyith
 * Smoking Wheels....  was here 2017 jzxfswxqhhhzrhxqacchkmkuowfspatcesfgtykzlxkyrbpl
 * Smoking Wheels....  was here 2017 sjshluctwxsbistpbmogjylskibuufsdbckcqsjatvupflwl
 * Smoking Wheels....  was here 2017 zybfairtpzgmruzkgsboredcezbvuiysnehaoqnjbxrcwgoz
 * Smoking Wheels....  was here 2017 fkbylkiknvduudlnurylojlzfkuqygoozcnobgbhyzwnjraz
 * Smoking Wheels....  was here 2017 msbryiatzavwdocpdotjnboqckxixcunfhxkygkggdhfnbto
 * Smoking Wheels....  was here 2017 jzrybovbpjcthghmyujaiavoralgpfeuclpmdrfdbpftmaod
 * Smoking Wheels....  was here 2017 mssjnwgvcyxvdookfcykaezoapozbgouvnyayskwqacarkmj
 * Smoking Wheels....  was here 2017 uoizjfyxralrvcrsciurwvxqkqvjubxcxqmnxxeuperbrkvd
 * Smoking Wheels....  was here 2017 nmwyxwthndgdutrbctnjhluclaxmjuprahersaxkucygkidp
 * Smoking Wheels....  was here 2017 bpyuoiygieagpqxkvuzeeualyturrtdrcdallahmgccdavee
 * Smoking Wheels....  was here 2017 fkkedjwhwetledvvibhblvhmadtowqhlidmbidfbhuqoxtan
 * Smoking Wheels....  was here 2017 voicqxfffjrgrvituoufkvmgyufyihdsekbywwwlnxhrqgyn
 * Smoking Wheels....  was here 2017 dactigxbrkhnkqjwplcdnivzhlyysvziilrwwarcuobtermi
 * Smoking Wheels....  was here 2017 pyiptxcbwbhicqhamecnpasfyfywwpiltylthnhwcbdlpqlj
 * Smoking Wheels....  was here 2017 ytwjpofupkqbogpkkjviqwusxkjjyhzmrurvlqqsvxbniaxg
 * Smoking Wheels....  was here 2017 beubygyaxsqgzbdkpbsuxfzoootejszcmezpuwwznzmczycx
 * Smoking Wheels....  was here 2017 edmuageteorutyxrkjhjxmlzlmvmszqexngsdzldzhlomuom
 * Smoking Wheels....  was here 2017 stodjzbhytoslafdqsmtklrnkfopxnmxxooelxzajedkyeej
 * Smoking Wheels....  was here 2017 kovtsgcdbkglarpxevjykcfymcebbxiqqfgeazlpyfboszwg
 * Smoking Wheels....  was here 2017 fdlpbawcoszmpnwlgpgdercibseuobebpqzfjqzegdzcnhaa
 * Smoking Wheels....  was here 2017 hntxsoieuifrnkbiigvufrkwqugvcajbmhoygqzhebuidmdu
 * Smoking Wheels....  was here 2017 dujddiqqibremnlmbexqivqecmknmgktfvdkrzeruhuwufaa
 * Smoking Wheels....  was here 2017 kmcaddfbzxjhidpckcpqmejymaxmxhcqzfauwxkkkjmnvisi
 * Smoking Wheels....  was here 2017 bfcmsxtevenpfzgopyfzyyphdzentbmhhpvnkxxtocnkxznp
 * Smoking Wheels....  was here 2017 iysudydafnpynvomawlefqlkpfztqrwqulkjztbfcoxwxmya
 * Smoking Wheels....  was here 2017 qvnjwsnxsqjlxwsvmicycyixtshmlnuvlkxgrlnpdbxmynva
 * Smoking Wheels....  was here 2017 rikyszjidqtkflhsvzhepyzmpwiiieagmmqlsegyydzbkxee
 * Smoking Wheels....  was here 2017 jdlmrsianwalpecnhujdxvffoepdqnqphugipmkmdqwuyuhl
 * Smoking Wheels....  was here 2017 zdafafhcguqjmydziyxiqchjcluzbsxsqtorccjtmonxmoty
 * Smoking Wheels....  was here 2017 yptogxmuxhihlwtxqwvjmnpldtxelckukdrlgavodhfacuhc
 * Smoking Wheels....  was here 2017 xwmhdohqgkcnlhmmeffimctgrkejzhwfvuywhntxjijaekzo
 * Smoking Wheels....  was here 2017 wqgisejkklesnwcdcyjixbtvbycjzekrjyajsbfbtmuykmdg
 * Smoking Wheels....  was here 2017 axnxeaqdqzaqdlpmxgzxgwskxgjgdvgasasrikspcvkeqkgh
 * Smoking Wheels....  was here 2017 uvvmcohcpujkxfjlhovtgicozhajiszlurdtcnwgoslhaveb
 * Smoking Wheels....  was here 2017 xubufosucyfkslxefobuzknbjkfiqjkivxrvispcjqkcxoxh
 * Smoking Wheels....  was here 2017 inhtnapbetudsuzcvebiqixxldmznsnhhvxjnkcidkaszutu
 * Smoking Wheels....  was here 2017 eyxqievwdunngerupojstqmksjojpwqivxrbkkuosdgldvgu
 * Smoking Wheels....  was here 2017 zgnwcnqnqwfqarhggfwtdbpabbjvtdimkvcwarimdbjylifq
 * Smoking Wheels....  was here 2017 lwyfpvkokzvtwqhortrkspyqnoeacfigfnnbqmpfsvuajera
 * Smoking Wheels....  was here 2017 lmhoxatspnooxtoddddvvmmekmmsbztgtepbthvzbehtmlxv
 * Smoking Wheels....  was here 2017 gbzeelrbmzxupvcrbpvnzfhzioaafmvjrgdpcwkhaewmsomf
 * Smoking Wheels....  was here 2017 gsnmanivrfqqnzfaemrewnwpcwshnddtxjgptfzzpdsvecep
 * Smoking Wheels....  was here 2017 fxvgdacpyhrjoqljjotvolwsuswcbolvsmhixpmbeqhpgybp
 * Smoking Wheels....  was here 2017 aiakoyqdlmhqxkobwrjphfeltrwigqvfnuxgdldthmkwpgjc
 * Smoking Wheels....  was here 2017 xxkfonxlkiyfwdqvdceaphyzmoozsmowaswaeogqusyacisi
 * Smoking Wheels....  was here 2017 iwqbqgcumrifeyynwfauflrywkvmjlexdyjraypntrfqxwvq
 * Smoking Wheels....  was here 2017 zpnsnxotmpnapfbizravesybznykhemsclskyuaimwrnjrur
 * Smoking Wheels....  was here 2017 utfdhmzbljrdkotpsmmksgtjdnkoymnzjjnqmqtlodbvdxwj
 * Smoking Wheels....  was here 2017 ziandehusohmwwabmvczkqedxdxaxpoqqdqdifdiunhvcxqw
 * Smoking Wheels....  was here 2017 zmpjqorewyddsggnbbqgypsxdmkfbuetulfvpnxuhjrdkjxo
 * Smoking Wheels....  was here 2017 mrtjnhntsqdjtcxfhygfjcalwvfqotetdfnzlvyvjfrpkbqb
 * Smoking Wheels....  was here 2017 moplulnhjynwezvnljhaxkytkttevhoiaqgampltpvaiueej
 * Smoking Wheels....  was here 2017 dbnxtfovckukivabynjedatekauxloqjfefqkoubuiqpkbbo
 * Smoking Wheels....  was here 2017 yjddwcvrnuscwsvtmwhktruepugeiyyzrmnwfuroaavckicb
 * Smoking Wheels....  was here 2017 nygwxwthlffgsatubbfrvktodhlopbhqnnnwflahqlboewin
 * Smoking Wheels....  was here 2017 xlzcwnznxzonyjpnuamdokojhctxrtsyglvcxbymejadjvav
 * Smoking Wheels....  was here 2017 furabhliiqerzrjqfysjnejvqazhdemvprhibkyrmxtdvnte
 * Smoking Wheels....  was here 2017 yfzdzribezwwlalzyhszlmpnbcccxrellxamqlqqqjlfsogy
 * Smoking Wheels....  was here 2017 vctbjkaejbojgthuztqzjiyfosixdwodbcktykylzhodkxqt
 */
package net.yacy.kelondro.index;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.ByteOrder;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.util.SetTools;
public final class RowHandleSet implements HandleSet, Iterable<byte[]>, Cloneable, Serializable {
private static final long serialVersionUID=444204785291174968L;
private final Row rowdef;
private RowSet index;
public RowHandleSet(final int keylength, final ByteOrder objectOrder, final int expectedspace) {
this.rowdef = new Row(new Column[]{new Column("key", Column.celltype_binary, Column.encoder_bytes, keylength, "key")}, objectOrder);
try {
this.index = new RowSet(this.rowdef, expectedspace);
} catch (final SpaceExceededException e) {
try {
this.index = new RowSet(this.rowdef, 0);
} catch (final SpaceExceededException ee) {
ConcurrentLog.logException(ee);
this.index = null;
}
}
}
private RowHandleSet(Row rowdef, RowSet index) {
this.rowdef = rowdef;
this.index = index;
}
public RowHandleSet(Row rowdef, byte[] b) throws SpaceExceededException {
this.rowdef = rowdef;
this.index = RowSet.importRowSet(b, this.rowdef);
}
@Override
public RowHandleSet clone() {
optimize();
return new RowHandleSet(this.rowdef, this.index.clone());
}
@Override
public byte[] export() {
return this.index.exportCollection();
}
@Override
public void optimize() {
this.index.sort();
this.index.trim();
}
/**
* initialize a HandleSet with the content of a dump
* @param keylength
* @param objectOrder
* @param file
* @throws IOException
* @throws SpaceExceededException
*/
public RowHandleSet(final int keylength, final ByteOrder objectOrder, final File file) throws IOException, SpaceExceededException {
this(keylength, objectOrder, (int) (file.length() / (keylength + 8)));
FileInputStream fis = new FileInputStream(file);
InputStream is = null;
try {
	is = new BufferedInputStream(fis, 1024 * 1024);
	final byte[] a = new byte[keylength];
	int c;
	while (true) {
		c = is.read(a);
		if (c <= 0) break;
		this.index.addUnique(this.rowdef.newEntry(a));
	}
} finally {
	if(is != null) {
		is.close();
	} else if(fis != null) {
		fis.close();
	}
}
assert this.index.size() == file.length() / keylength;
}
/**
* write a dump of the set to a file. All entries are written in order
* which makes it possible to read them again in a fast way
* @param file
* @return the number of written entries
* @throws IOException
*/
@Override
public final int dump(final File file) throws IOException {
final Iterator<Row.Entry> i = this.index.rows(true, null);
	int c = 0;
final FileOutputStream fileStream = new FileOutputStream(file);
	OutputStream os = null;
try {
	try {
		os = new BufferedOutputStream(fileStream, 1024 * 1024);
	} catch (final OutOfMemoryError e) {
		os = fileStream;
	}
	while (i.hasNext()) {
		os.write(i.next().bytes());
		c++;
	}
	os.flush();
} finally {
	try {
		if(os != null) {
			os.close();
		}
	} finally {
		if(fileStream != os) {
			fileStream.close();
		}
	}
}
return c;
}
@Override
public final synchronized byte[] smallestKey() {
return this.index.smallestKey();
}
@Override
public final synchronized byte[] largestKey() {
return this.index.largestKey();
}
@Override
public ByteOrder comparator() {
return this.rowdef.objectOrder;
}
public final Row row() {
return this.index.row();
}
@Override
public int keylen() {
return this.index.rowdef.primaryKeyLength;
}
@Override
public final void clear() {
this.index.clear();
}
@Override
public final synchronized boolean has(final byte[] key) {
assert (key != null);
return this.index.has(key);
}
@Override
public final void putAll(final HandleSet aset) throws SpaceExceededException {
for (byte[] b: aset) put(b);
}
/**
* Adds the key to the set
* @param key
* @return true if this set did _not_ already contain the given key.
* @throws IOException
* @throws SpaceExceededException
*/
@Override
public final boolean put(final byte[] key) throws SpaceExceededException {
assert (key != null);
final Row.Entry newentry = this.index.row().newEntry(key);
return this.index.put(newentry);
}
@Override
public final void putUnique(final byte[] key) throws SpaceExceededException {
assert (key != null);
final Row.Entry newentry = this.index.row().newEntry(key);
this.index.addUnique(newentry);
}
@Override
public final boolean remove(final byte[] key) {
assert (key != null);
Row.Entry indexentry;
indexentry = this.index.remove(key);
return indexentry != null;
}
@Override
public final synchronized byte[] removeOne() {
Row.Entry indexentry;
indexentry = this.index.removeOne();
        if (indexentry == null) return null;
return indexentry.getPrimaryKeyBytes();
}
/**
* get one entry; objects are taken from the end of the list
* a getOne(0) would return the same object as removeOne() would remove
* @param idx
* @return entry from the end of the list
*/
@Override
public final synchronized byte[] getOne(int idx) {
        if (idx >= this.size()) return null;
Row.Entry indexentry;
indexentry = this.index.get(this.size() - 1 - idx, true);
        if (indexentry == null) return null;
return indexentry.getPrimaryKeyBytes();
}
@Override
public final synchronized boolean isEmpty() {
return this.index.isEmpty();
}
@Override
public final synchronized int size() {
return this.index.size();
}
@Override
public final synchronized CloneableIterator<byte[]> keys(final boolean up, final byte[] firstKey) {
return this.index.keys(up, firstKey);
}
@Override
public final Iterator<byte[]> iterator() {
return keys(true, null);
}
@Override
public final synchronized void close() {
this.index.close();
this.index = null;
}
@Override
public final String toString() {
return this.index.toString();
}
public HandleSet joinConstructive(final HandleSet other) throws SpaceExceededException {
return joinConstructive(this, other);
}
public static HandleSet joinConstructive(final HandleSet set1, final HandleSet set2) throws SpaceExceededException {
        if ((set1 == null) || (set2 == null)) return null;
assert set1.comparator() == set2.comparator();
        if (set1.comparator() != set2.comparator()) return null;
        if (set1.isEmpty() || set2.isEmpty()) return new RowHandleSet(set1.keylen(), set1.comparator(), 0);
final int high = ((set1.size() > set2.size()) ? set1.size() : set2.size());
final int low  = ((set1.size() > set2.size()) ? set2.size() : set1.size());
final int stepsEnum = 10 * (high + low - 1);
final int stepsTest = 12 * SetTools.log2a(high) * low;
        if (stepsEnum > stepsTest) {
if (set1.size() < set2.size()) return joinConstructiveByTest(set1, set2);
return joinConstructiveByTest(set2, set1);
}
return joinConstructiveByEnumeration(set1, set2);
}
private static HandleSet joinConstructiveByTest(final HandleSet small, final HandleSet large) throws SpaceExceededException {
final Iterator<byte[]> mi = small.iterator();
final HandleSet result = new RowHandleSet(small.keylen(), small.comparator(), 0);
byte[] o;
while (mi.hasNext()) {
o = mi.next();
if (large.has(o)) result.put(o);
}
result.optimize();
return result;
}
private static HandleSet joinConstructiveByEnumeration(final HandleSet set1, final HandleSet set2) throws SpaceExceededException {
final ByteOrder comp = set1.comparator();
final Iterator<byte[]> mi = set1.iterator();
final Iterator<byte[]> si = set2.iterator();
final HandleSet result = new RowHandleSet(set1.keylen(), comp, 0);
int c;
        if (mi.hasNext() && si.hasNext()) {
byte[] mobj = mi.next();
byte[] sobj = si.next();
while (true) {
c = comp.compare(mobj, sobj);
if (c < 0) {
if (mi.hasNext()) mobj = mi.next(); else break;
} else if (c > 0) {
if (si.hasNext()) sobj = si.next(); else break;
} else {
result.put(mobj);
if (mi.hasNext()) mobj = mi.next(); else break;
if (si.hasNext()) sobj = si.next(); else break;
}
}
}
result.optimize();
return result;
}
@Override
public void excludeDestructive (final Set<byte[]> other) {
        if (other == null) return;
        if (other.isEmpty()) return;
        if (other.size() > this.size()) {
for (byte[] b: this) {if (other.contains(b)) this.remove(b);}   
} else {
for (byte[] b: other) {this.remove(b) ;}
}
}
/*   not used 2013-06-06 
private static void excludeDestructive(final HandleSet set1, final HandleSet set2) {
        if (set1 == null) return;
        if (set2 == null) return;
assert set1.comparator() == set2.comparator();
        if (set1.isEmpty() || set2.isEmpty()) return;
        if (set1.size() < set2.size())
excludeDestructiveByTestSmallInLarge(set1, set2);
else
excludeDestructiveByTestLargeInSmall(set1, set2);
}
private static void excludeDestructiveByTestSmallInLarge(final HandleSet small, final HandleSet large) {
final Iterator<byte[]> mi = small.iterator();
while (mi.hasNext()) if (large.has(mi.next())) mi.remove();
}
private static void excludeDestructiveByTestLargeInSmall(final HandleSet large, final HandleSet small) {
final Iterator<byte[]> si = small.iterator();
while (si.hasNext()) large.remove(si.next());
}
*/
public static void main(String[] args) {
HandleSet s = new RowHandleSet(8, NaturalOrder.naturalOrder, 100);
try {
s.put(UTF8.getBytes("Hello"));
s.put(UTF8.getBytes("World"));
try {
File f = File.createTempFile("HandleSet", "stream");
try(/* Resource automatically closed by thus try-with-resource statement */
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(f));
) {
	out.writeObject(s);
}
ObjectInputStream in = new ObjectInputStream(new FileInputStream(f));
try {
	RowHandleSet s1 = (RowHandleSet) in.readObject();
for (byte[] b: s1) {
System.out.println(UTF8.String(b));
}
s1.close();
} finally {
	in.close();
}
} catch(IOException e) {
e.printStackTrace();
} catch (final ClassNotFoundException e) {
e.printStackTrace();
}
} catch (final SpaceExceededException e) {
e.printStackTrace();
}
s.close();
ConcurrentLog.shutdown();
}
}
