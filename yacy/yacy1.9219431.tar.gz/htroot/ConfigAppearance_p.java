/** 
 * Smoking Wheels....  was here 2017 rruyltnxbubpslqjxcuojqjzlsezokfebrhhhpkiulwuygjk
 * Smoking Wheels....  was here 2017 trlnifznsywjahatpyhsawbtinffqijwymfvbueocdkjwpvw
 * Smoking Wheels....  was here 2017 cnvpxbakljzvphbtgsdnpjzedghvkyzeuokijledmrzidlvf
 * Smoking Wheels....  was here 2017 blojtbbsfjofskupnxfibfutdnxkklirkqynhugvjahnndwi
 * Smoking Wheels....  was here 2017 dyleuhryfocbwtkxdgpvmqlerfrrjfxewsegflqnkgjxbksh
 * Smoking Wheels....  was here 2017 dtpqdavtwuhcuunndspwfgcimlrrgzounzsqudrkpsksyelk
 * Smoking Wheels....  was here 2017 euisduqdwfdknevlxnwpxvbnmnbqjoguwzidvxazbzvnrpif
 * Smoking Wheels....  was here 2017 nigmkkngddvegulczeekljccwchbefhvtjehncpxgzjbbbvp
 * Smoking Wheels....  was here 2017 swfivxdowevynwpzdlryxfavbadtkieqffpafgndwtziahvo
 * Smoking Wheels....  was here 2017 qchynpjumewmbuuzmfrcsxbqsjmsbotjordnmcgxwrxpwdgn
 * Smoking Wheels....  was here 2017 gbudxzkvrgxuvgwcgutzlfosvmpekvzhigqcgtkqjjqjavlz
 * Smoking Wheels....  was here 2017 yxjcnxpxjudcdcuscpuzaeenoayqxidaksglqmxzvrvlhtxu
 * Smoking Wheels....  was here 2017 fevfhkqntjbzlpxjtlvtmcvtivfyjlujuzgkzuwzyslurpla
 * Smoking Wheels....  was here 2017 xohcislhgvienbrxhfgehnrjvzkatvsjuhgdynsurvtsjgaz
 * Smoking Wheels....  was here 2017 cbbqzlcfohzsigxkbfpjzgdoawregmwkyecbjrcvdperxwzh
 * Smoking Wheels....  was here 2017 axszwjblqcfudbqepxttmhutaboxlmqadiwtjpyvvyllzyvs
 * Smoking Wheels....  was here 2017 iocnxmznpxmzkpcurzuxxzqrhkszbhmajsxcivjtkxmcrcij
 * Smoking Wheels....  was here 2017 uujxfdsbynmayjwbkmbuqwthobdkboenypuhxcuutwpuffmo
 * Smoking Wheels....  was here 2017 louzcwmaiafyszsdbpdngsotsjblsgtvllksxmwjeledanqw
 * Smoking Wheels....  was here 2017 pczxglqqrvvzyjqffuwlrosoyxwpnmnnrauymhmezlyvxkhd
 * Smoking Wheels....  was here 2017 vwtbmyvienwqesyzrwigzsdjrnjqfrzksfhxzbufxbxxwnfk
 * Smoking Wheels....  was here 2017 ypgczpzvhzasckefmswuoszdqjmpunxpvjnscpfrxofqdvlz
 * Smoking Wheels....  was here 2017 aitxbagarggftdbzzqcfaipcrulrnxijpwiupxkydpknemfn
 * Smoking Wheels....  was here 2017 ifxpjzaegstjjvqqscvxhrsrcirlwboivmuushgubadiuwct
 * Smoking Wheels....  was here 2017 mtnotmzsgaztkqfsmuemkyeofyyrpibhoffnshxdhxjbyrwv
 * Smoking Wheels....  was here 2017 fsrmjwzibysarzhcjslwutdsuqeirkridhfegttevrjyxwoa
 * Smoking Wheels....  was here 2017 qbteorfzjrwhenquqdgdbxaisvprkfjtcdqdgqmjwwppdnkx
 * Smoking Wheels....  was here 2017 bahvyrbwdnruceidwmlubjmwfdsgfymegopauhzkujsrjczj
 * Smoking Wheels....  was here 2017 zbeukxeknbpzydptwnciymkzrjeuxzmkrmjsfgkghgsfrhbk
 * Smoking Wheels....  was here 2017 hxlscrmjzfisnuzksfntbvysuqzjlzemqdpjfidbixvngzqk
 * Smoking Wheels....  was here 2017 aomniocqebwytvgfsujdbcneniidcxpttbckonwibynbpjaw
 * Smoking Wheels....  was here 2017 lgwhuhllbykxxelmktkwuluwbarsjxauuxykmdmtyflqlwsr
 * Smoking Wheels....  was here 2017 dlllhyefumkenzwupvupjcqluouuykzlusnghschquqfucnx
 * Smoking Wheels....  was here 2017 ywhpzufqvnpmhqzzizwfepfxlcplwafucskdqbeccbhbyalw
 * Smoking Wheels....  was here 2017 wotrfkrsveywfwqczkdwvtxkxyhwktuchikjigiqmqxtivtc
 * Smoking Wheels....  was here 2017 hrkupoyqtuqopoulbrnxepkkkskpaszzdiqromlqgjcyswam
 * Smoking Wheels....  was here 2017 rscibhtutzebvwuqjlcaklpqihpllihgrslwrksabiytcwzb
 * Smoking Wheels....  was here 2017 xlxxsyxyipgeugcnzseauvqaktvisgnzgrjdhtnzwwojssre
 * Smoking Wheels....  was here 2017 auflwzqzctwwjincfsjdboxtomioblrnlsivgooawrmibokj
 * Smoking Wheels....  was here 2017 iapbegiezuekvbctpynraqbhyaorybblaojptdqtmnkkyxqn
 * Smoking Wheels....  was here 2017 jpwdoupygirjspcaycriujbjahhkenfnbfvicbaejohpgifq
 * Smoking Wheels....  was here 2017 yhdibwjzgfclsjatjfgytizwmkktrlvwwvidybanmcjditdc
 * Smoking Wheels....  was here 2017 easncbufsnjqwaradlurohgagqdatvbuzzqmdgiezubppkrl
 * Smoking Wheels....  was here 2017 hbgvgdhxnrthkmcdticxahogmrzrxtbxgjyxvwvwjldswrin
 * Smoking Wheels....  was here 2017 xwnrldmkygqvvxnsdpjghptiqiqnvslasymjilsoggnmcfyj
 * Smoking Wheels....  was here 2017 vfqrujhnicvbwtnmgevrtuzdktbnoiydryyyivjlpllenynj
 * Smoking Wheels....  was here 2017 bayspiwdkhgzoqwqmjdfarswsfmyioprrwcbrakyptjhrbia
 * Smoking Wheels....  was here 2017 znbxoxpmcgcwcnokipciygoatkijqnreolbjmjttryzqgzwf
 * Smoking Wheels....  was here 2017 cgurnbezpnvfznwkqqvprwkhxdjlfrtmjresdipwndieiiza
 * Smoking Wheels....  was here 2017 gxfqpdliizfuadjllkqzoalpyoohcrnpktzgfthmasoebbqs
 * Smoking Wheels....  was here 2017 mmsseqqmzteqdyuqbfeogmadtzcdmlcxgdkkrrnzlhdezidx
 * Smoking Wheels....  was here 2017 cfvzwjbrmezypyfgamfsojwjmzllxdszrqmsnkeddruxwnzl
 * Smoking Wheels....  was here 2017 rnlwojkiawahygwwezwcrxvaqmhabewqudoeflkwwamkrjai
 * Smoking Wheels....  was here 2017 afpaiypdzrakvhhjpqmqyrbzvprxafkywygwjppkmqlyrtey
 * Smoking Wheels....  was here 2017 dfshoqubdszijsguotqkzmznbpthzfiglnjevyldgeczjwvv
 * Smoking Wheels....  was here 2017 luhvyfjhjhdhsmvlptfuqifalezskhwckpztssvunmfilclv
 * Smoking Wheels....  was here 2017 jkfbguygwbwujtfxpjfmbnsfmddzdxpisdmljnxibpsyzdub
 * Smoking Wheels....  was here 2017 vuonqonscxzqdyaanpbipppcvpcbcshztjllmcaytzwedwyt
 * Smoking Wheels....  was here 2017 vysfnddorwkvzszwtsinyjgtkxeenpzlaurdxoycueblmnen
 * Smoking Wheels....  was here 2017 sbefmhgzohipdydtvdujwwjtkrtyzuxfkdhdscllpabptlyg
 * Smoking Wheels....  was here 2017 zrwxjaonzwfmcwtfnpqnokvsgupaerqfxjqiiiuzwrvoxidx
 * Smoking Wheels....  was here 2017 mlvyiswtikvgqwjdycdximuqrhqmbxykvshvjbiwnloqedrx
 * Smoking Wheels....  was here 2017 hklftwkshzdwtqspkwxqwyrrnpdpykvftrccrgspuzsjdzxu
 * Smoking Wheels....  was here 2017 rugwggopvzhqraxwkjucaubhbhnvijpdmyerjhvvbcblmhij
 * Smoking Wheels....  was here 2017 fadgrxyvbzucwhdovjwyxiyfsfmyxeubcounwqwoaynyftss
 * Smoking Wheels....  was here 2017 sxeaeemcmxjyduamrvmbwdlicmazrndawsqttdfyqvhcogce
 * Smoking Wheels....  was here 2017 fjsbboijtuzflggtgyfooyxyfljfyirijxlswvnlakwlbath
 * Smoking Wheels....  was here 2017 brhnawxvvbufanwpdgxvwvbkfszdetspkwjdkzrtrmzslkgy
 * Smoking Wheels....  was here 2017 vhuuxdwywfijkufselrnwbuloenmcftqbnsurewvheoxrche
 * Smoking Wheels....  was here 2017 gyimvrbkifhnintvjnunzggaxwahsjonpedxiemwtwuibazh
 * Smoking Wheels....  was here 2017 lpfmezsewcqqtigbasyztcuiefqvhefophjvgadigdglajnw
 * Smoking Wheels....  was here 2017 rnayoxelkgpzzdustmxgdsdvptxphtyiwopfnauxgwnbjnnt
 * Smoking Wheels....  was here 2017 oepgvmcqehpcldqjiptzfjdeokmjmnhrmadxornokdrebera
 * Smoking Wheels....  was here 2017 wgabdykmobkryshwvzxcjpzjufidweartvocywvlqiwajfbz
 * Smoking Wheels....  was here 2017 qvsgvxgyhqxvmpognxwrfeapepsesqeqfnsdoohbfzodtvyf
 * Smoking Wheels....  was here 2017 gadxodaegkktgqlxawndpfziydbalabcrvrrnbvblbnhzkvo
 * Smoking Wheels....  was here 2017 ekgmerjrryizuaficoycrxsenrcjwvdzfsupgyqlcoqmcrob
 * Smoking Wheels....  was here 2017 hqbouufczdjgvflkuymmvxjeohthyrggdkrbhzbkcxeygmca
 * Smoking Wheels....  was here 2017 quybvbskvcnpivwdliskqyjnzkiaymjhzkekoetiqrqgabsc
 * Smoking Wheels....  was here 2017 mzmdvggudeagqunyqcnfzajqapecjkurokhiexrzctqccvab
 * Smoking Wheels....  was here 2017 ltndsllteyhudgsidbxpangfcscgyxcfylmqmrxieffonjsz
 * Smoking Wheels....  was here 2017 hwdspxhxhhaxqsxdaeilbyeexwanrpzzlrgodgwmwkowmrve
 * Smoking Wheels....  was here 2017 cfstvevhfhgqctylpqgwucovijedulnipqmkzrgyhydnnxrg
 * Smoking Wheels....  was here 2017 edtjbbobvidgvhvokzqgbzbmpxapvpyugbgvdhylwsrikmta
 * Smoking Wheels....  was here 2017 caezepcqkaeggovchwmgyyoydhhtmmwelwxtaqcwjudfbawo
 * Smoking Wheels....  was here 2017 qpbggchthfcleymvgjdtwmedppxnutzqljahflblqosnunae
 * Smoking Wheels....  was here 2017 vyszrbkjezvtncnxrqgwllkfygcfzijlwzlvpuoqxowtcbmm
 * Smoking Wheels....  was here 2017 beskbhtrbromqzbobfpaouurjuihojgenmgagzmcpsjqrdvg
 * Smoking Wheels....  was here 2017 wwzvhwaccyvexsikgtivgxifhdjpgifqlvvsqoyvjddeokuo
 * Smoking Wheels....  was here 2017 arnxnbbjrqhoesvhgitdzgctkicbbvzyxgsbhhjafcjrysku
 * Smoking Wheels....  was here 2017 pqspbkdknvzrjrkglckejronqtuagvqknftmcglcghpqkizm
 * Smoking Wheels....  was here 2017 xydyornlpxastnaqiofgffiydbwxhmlpcmbogszuynmuqpzl
 * Smoking Wheels....  was here 2017 ncqjwzzxamyhvkzatlgasditkacozexirazgafgaaxzfrfgt
 * Smoking Wheels....  was here 2017 gvhmdoimgjlbjtufttvjeasvbukygqurobcpcpozivicsbtt
 * Smoking Wheels....  was here 2017 ccmgtzudzrldifhhrsnmgpwlcraijsdzicfcivpecvaygjvz
 * Smoking Wheels....  was here 2017 ldstharbdvgszskoaufrvzkaqjjfvqgutvlhvgggtvspcnzi
 * Smoking Wheels....  was here 2017 vlxiqsttxighulnqpszpalihergkkuqyygeczjsdzxlaefyv
 * Smoking Wheels....  was here 2017 atdsxjvvscfrnucinmeedmscirowbwcoeoxrkaicskiluivu
 * Smoking Wheels....  was here 2017 dastmnchhgbxflxschinxyztctnwbtpwziokzguodzxlkavv
 * Smoking Wheels....  was here 2017 lngoazyimcadahacuqibdwurpopywqmngedwuizeskxtttns
 * Smoking Wheels....  was here 2017 mrpoiubkohoznosbnhhixnboiwnvhygizecbgtbybwfjwero
 * Smoking Wheels....  was here 2017 dguinfhfwqkekpllhenirlxiyuhohhrimnxazklbercpyeir
 * Smoking Wheels....  was here 2017 kffvbvvrehmsscbilnodaltfjtbkcrtxhrmeuhuzelbwnzsr
 * Smoking Wheels....  was here 2017 pvmemkczjobwrapzmwidvpgqvhhvffvohjxdwryjobsajzli
 * Smoking Wheels....  was here 2017 hnjsrzrqqbodtmgahxxzfdhiritqkikemqnvoddfzocbkves
 * Smoking Wheels....  was here 2017 ibacuwnilsthtxqhvpponqafrxjvqsgufqwjnlsrkjkeylbe
 * Smoking Wheels....  was here 2017 rktgeptzlnniqzmvmfzzkxwnsjjrfgjtzxvdorigyadzlagh
 * Smoking Wheels....  was here 2017 svdhlyvuoxdnqqwyvfzrtymrzkfroccqrdmuvbxpclyerykx
 * Smoking Wheels....  was here 2017 ataomaifzlbkhzzhpipgqbsjyupoltxghheesfprnsvtqyfa
 * Smoking Wheels....  was here 2017 iyotkafyeazthmkpwneplvupgrokxuprdrnmuxvreeaaowsa
 * Smoking Wheels....  was here 2017 sjztoppyusxmsuyzabjwuzcmvkfldeffvshbzeebflynxxfm
 * Smoking Wheels....  was here 2017 ogzrqlxltxayswounlzloqgnxpcerczmceqokhpobjixmlfe
 * Smoking Wheels....  was here 2017 icixlruvhetqvvpofibyxaekwbxjgxmhczwwkugbkbehggmg
 * Smoking Wheels....  was here 2017 xpdbdndvvkxivcndesagdsadkyoavimralodpnnugxqwmdcz
 * Smoking Wheels....  was here 2017 hutcbodkzqjzridoswknxneumpjlrgzanyqswnbfrlffqigy
 * Smoking Wheels....  was here 2017 vwtbvpdsuikwpmmfjgcdcliygqrciwgwjhbgiauaeoqamfoy
 * Smoking Wheels....  was here 2017 bhzlirugizloesvqypdtuuifewitmpxbqlhrjpvdkkvjamud
 * Smoking Wheels....  was here 2017 uvousbbsdnftblsqmxwfkckpyleldbpqppvbpcpuigalmbxt
 * Smoking Wheels....  was here 2017 cmtaihbaubrmhiwhjjxrnewglsnkoglywhpvxmtldusvjcfl
 * Smoking Wheels....  was here 2017 hkfgteekiwbacgjzbmcoaclrwgtfggsoffppkbftfupglahy
 * Smoking Wheels....  was here 2017 xduxyucgwqvwalmflzmlbcznryqnyowhsjfhkkbrglpsrlvk
 * Smoking Wheels....  was here 2017 tjnqyjsjvfruthswovmhyssuoxdkpttfqybzqhukfbznijyd
 * Smoking Wheels....  was here 2017 xdugdmepyqpvhmwyshpdjuypllldnwjrpmxdxuzlhfedxyvs
 * Smoking Wheels....  was here 2017 rqdyfywediueyxywlvsldjjmmfbfeyagjrxiidplxvyjdoby
 * Smoking Wheels....  was here 2017 qilcytlppxskdtgcodyvkrxccbqkimetankmhytjsyfezwlw
 * Smoking Wheels....  was here 2017 ozvjnfwmsdbfqlhodgoeoirkbbfszergwgyrkyvlrzfvuvxx
 * Smoking Wheels....  was here 2017 moophxfwffwrlpwhmkfpfbcofpyjivnblijkofnbymjwypvn
 * Smoking Wheels....  was here 2017 uhgywpxwalhbvfzoeasnfzvcuhiyxsztpmufwasyajlbgprq
 * Smoking Wheels....  was here 2017 zrttdipzimuvhkyazweoriuqeybdmfpejsozrypbnrkjsmhg
 * Smoking Wheels....  was here 2017 xketfjfxndctmofmzyxqzqbfdscazackafgxqtmokvldoeps
 * Smoking Wheels....  was here 2017 pmutmixoinfwnlqzmlnvutdxnxsvszptfnsjqmczvjaugvzq
 * Smoking Wheels....  was here 2017 idhxoxbeszhlpxgxavwoysphoehbeiiuqiaztljxhewdpxxu
 * Smoking Wheels....  was here 2017 twkqhgietevyecgtlxzmntjzripnbluilqnpkejkkjyepadh
 * Smoking Wheels....  was here 2017 pjinuophzwodbmfkvpglzmqyoopekbvmxqukdlnpdhmekdtk
 * Smoking Wheels....  was here 2017 yrimmlambgkcgsywkdhpwqtkdcmhlakoowruxjmyroxqpkzu
 * Smoking Wheels....  was here 2017 cyaryrbwxrpaysloubwichkuprtjrmvchzhjudfemayiygke
 * Smoking Wheels....  was here 2017 qsflchhzsrpmqqyzuachtsmuiacfwypzbbybejufeupgihts
 * Smoking Wheels....  was here 2017 irblzormweeecxbakajigndkcjlvzanffggyqwqgsfbrcncs
 * Smoking Wheels....  was here 2017 hvvpabihdffdjenraifpfkttuzbmgrqfibalcplthwtdtbrs
 * Smoking Wheels....  was here 2017 ukeywprrkgyqpkiiejmnlmajpmkqfzflffjerxbkiqljyiao
 * Smoking Wheels....  was here 2017 kxxziejbwuwejtunrxhsdavwxtfbpmtvxsqbtiqenrcjtaxi
 * Smoking Wheels....  was here 2017 xachocgdysrojplcnyybpnhhmxjvlsajsujfwrqgugxlkaki
 * Smoking Wheels....  was here 2017 ktctxyovieispqbdcrcrnwwtfgedxsclgwmazyqciaibjnse
 * Smoking Wheels....  was here 2017 einnalrjymbzjtryyomysaethkbnoofpftadflqkpucalylq
 * Smoking Wheels....  was here 2017 ufeztrffzfivceocwjhoiidzegtuctyrujhlwtrcfteioxiv
 * Smoking Wheels....  was here 2017 beftfybbxivaohflxcvjthxjmwewnwasezyapqfleeufakkb
 * Smoking Wheels....  was here 2017 adwtvtlvivoputkajyqmosvdfqobdxmbabvihdyuqtjehoyx
 * Smoking Wheels....  was here 2017 akvcdytsgcsuymgewjqirrqsnekwjzqhbizzcorxagqbdulf
 * Smoking Wheels....  was here 2017 okwecnpfvutdpryldewnelfuvhkcanzfkutwhkqtaupunutz
 * Smoking Wheels....  was here 2017 nwcptvwznrkjmtashgrzlnrjvcorbfhyiqtcpoelpulrtlwq
 * Smoking Wheels....  was here 2017 xuxiniuzzyqnpihapxqvdtkpmzzyszptkjucuyaoxupfgxas
 * Smoking Wheels....  was here 2017 blulawskdxqwdjtsqoqkbedzyngknyfgmtzmcyzrjswfuruz
 * Smoking Wheels....  was here 2017 mfridmhtedxxrasjgzskjctdqpateopgorrdubgusodpkiyp
 * Smoking Wheels....  was here 2017 bxpqxmkqoodjwsrtkegslzichhgcsnpvymlfocgdvuqrhvnv
 * Smoking Wheels....  was here 2017 ulxgvjhcyghhuckznhvkxsjzuyfpjrehfodcfcqcxzvyyjtg
 * Smoking Wheels....  was here 2017 adfhkzgghppyrcyjbwhyqhliifhvqgqgfsvjyjglkymfeift
 * Smoking Wheels....  was here 2017 hkiepiaptdnuzxpnxqrysantjxgohqomyvwaclibzvmlxjri
 * Smoking Wheels....  was here 2017 kzknlrlvuturmywgbojgnlsgpecuhnqcsgvcgceeoycxkkdj
 * Smoking Wheels....  was here 2017 lwrgkqrxaoioevopwwybsjkaxiytwuyldjpaijogjzucfqxj
 * Smoking Wheels....  was here 2017 shvlazezmyjshnqxwbhsduhmmzizoqtazzfklphyvsgvzlmf
 * Smoking Wheels....  was here 2017 tsqmftonhljriektxvkwxahjuayfclosizbfyhngpglbvoqz
 * Smoking Wheels....  was here 2017 jwgccfrhxybdaelyzfskkqmpmntnmyfomsrmlgsjpapcwvlz
 * Smoking Wheels....  was here 2017 ptybaxudzplekglplkulgkiknwycyaryzoyqwnnscofksmet
 * Smoking Wheels....  was here 2017 vpjpqrfimrqashnavwkkhjlfcpbnzvfjqhyjhjuzktyubwhe
 * Smoking Wheels....  was here 2017 owiaunqhoveelmwtyjtxsvusprtmjulrmxzmcjrdirtgwsqh
 * Smoking Wheels....  was here 2017 pixaqtysryulhebqxwcwvhlwtczbcpbyxpsdxiqkstxblxfl
 * Smoking Wheels....  was here 2017 axmmmxhonbjuidwuypajgpvxlhamjdcnkwxtpghftmvrgqif
 * Smoking Wheels....  was here 2017 dwpnzucbzofntfilqblvxuqgyvggspwyvlsyglngyvgxbhlj
 * Smoking Wheels....  was here 2017 nrdnbkapicsdbpshvyjwxdtooomdwkwcehlphlnmxvetvpka
 * Smoking Wheels....  was here 2017 xcddtcxxxlqjasnbogekoeiwcqpdwexzurrvibqcowsmvjfn
 * Smoking Wheels....  was here 2017 lbzfmjzyktygqfowdfmontshljvowxzygagbfipoenlpowdk
 * Smoking Wheels....  was here 2017 kvhyvbpxvjubdawacibssvqjtjsxlsjpidhxcogocrawtmsn
 * Smoking Wheels....  was here 2017 iwvstdlghxsgzirchibmetzrmnwwiaqscydgigtabkkhlxrx
 * Smoking Wheels....  was here 2017 bxscgzjqgfkrzmoytduuibwhixhonmnkwrihnfnezdvevzdy
 * Smoking Wheels....  was here 2017 qyhbucpakkvgcghpubwtuosiewfefbbzfvsionflbjtykyie
 * Smoking Wheels....  was here 2017 jfdryglqrvehomwkynculgehhacfzwnaxdlaolsprbxlyftk
 * Smoking Wheels....  was here 2017 vddjpnrygcyixioybgomjlevagqmnjmjaovhxnempggqlkgs
 * Smoking Wheels....  was here 2017 unitwebpnbvbwhybehqtyrvxdqvzvfqaxjkgeozjrhzvdmum
 * Smoking Wheels....  was here 2017 iibsdtwoguuolzttquytutotmnwzdicjbzchipwrevomnprf
 * Smoking Wheels....  was here 2017 utykaclaiscbwhakyhfvvtathnfzawczifxbkxqdlsskiekt
 * Smoking Wheels....  was here 2017 riufkfllxjdbqlbpxnqqdxcsampsdhdrtygkubmqfalopwue
 * Smoking Wheels....  was here 2017 vstujktomqrimwjdqknbctzmhoygneboqmrmcvvlldxfopwv
 * Smoking Wheels....  was here 2017 hzcyieogsqqxldtckglgheahcbouknvwnhbsggizgqoyroxh
 * Smoking Wheels....  was here 2017 jgkxwjgtnshatheuumgorcxpopuxilughclsiqvxdkflsdji
 * Smoking Wheels....  was here 2017 rcpawannbmbfwkzupvarhxncdalizkknyvfisnngsnstradb
 * Smoking Wheels....  was here 2017 yfsymkegwtqfpxryvhdlncbsollbjbmsuuxtasudzjjdudeu
 * Smoking Wheels....  was here 2017 gpcnaclxnsbbwnzixcdabmwssgajuiafklkjdgibbnoboptd
 * Smoking Wheels....  was here 2017 yljyevsqzqmzzdafhtwurbpluapurjjnpnutdlzslwbjtxlw
 * Smoking Wheels....  was here 2017 nghousqymekokxagvymjoffsfpyaupzokzkwltybumvajqzc
 * Smoking Wheels....  was here 2017 wuaayzcmjeolwgnforgrbkukrcaedrqhebvurbpgbtcgpukd
 * Smoking Wheels....  was here 2017 zzwfbfggksvtkwhfvetvulutdwakznldkgwyrjptjggqaman
 * Smoking Wheels....  was here 2017 ebmgtfnkmfnsgqinexxfqkvetnjhtippygsyoawhfwcxhdid
 * Smoking Wheels....  was here 2017 aopowznkvfauxtztjqtlrovjyxwphnqowcpstmougrobmlca
 * Smoking Wheels....  was here 2017 jdktovfzvpcvdpssnhpmjlyhkelinsjbmzejvoalkawjuijn
 * Smoking Wheels....  was here 2017 fwesdisaelstwwinyecjgvpecphstwukhkggqjztxoljsxkf
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import com.google.common.io.Files;
public class ConfigAppearance_p {
private final static String SKIN_FILENAME_FILTER = "^.*\\.css$";
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
final String skinPath = new File(env.getDataPath(), env.getConfig("skinPath", SwitchboardConstants.SKINS_PATH_DEFAULT)).toString();
prop.put("currentskin", "");
prop.put("status", "0");
List<String> skinFiles = FileUtils.getDirListing(skinPath, SKIN_FILENAME_FILTER);
        if (skinFiles == null) {
return prop;
}
        if (post != null) {
String selectedSkin = post.get("skin");
if (post.containsKey("use_button") && selectedSkin != null) {
/* Only change skin if filename is contained in list of filesnames
* read from the skin directory. This is very important to prevent
* directory traversal attacks!
*/
if (skinFiles.contains(selectedSkin)) {
changeSkin(sb, skinPath, selectedSkin);
}
}
if (post.containsKey("delete_button")) {
/* Only delete file if filename is contained in list of filesname
* read from the skin directory. This is very important to prevent
* directory traversal attacks!
*/
if (skinFiles.contains(selectedSkin)) {
final File skinfile = new File(skinPath, selectedSkin);
FileUtils.deletedelete(skinfile);
}
}
if (post.containsKey("install_button")) {
final String url = post.get("url");
final Iterator<String> it;
try {
final DigestURL u = new DigestURL(url);
it = FileUtils.strings(u.get(ClientIdentification.yacyInternetCrawlerAgent, null, null));
} catch (final IOException e) {
prop.put("status", "1");// unable to get URL
prop.put("status_url", url);
return prop;
}
try {
final File skinFile = new File(skinPath, url.substring(url.lastIndexOf('/'), url.length()));
final BufferedWriter bw = new BufferedWriter(new PrintWriter(new FileWriter(skinFile)));
while (it.hasNext()) {
bw.write(it.next() + "\n");
}
bw.close();
} catch (final IOException e) {
prop.put("status", "2");// error saving the skin
return prop;
}
if (post.containsKey("use_skin") && "on".equals(post.get("use_skin", ""))) {
changeSkin(sb, skinPath, url.substring(url.lastIndexOf('/'), url.length()));
}
}
if (post.containsKey("set_colors")) {
if (skinFiles.contains(selectedSkin)) {
changeSkin(sb, skinPath, selectedSkin);
}
for (final Map.Entry<String, String> entry: post.entrySet()) {
if (entry.getKey().startsWith("color_")) {
env.setConfig(entry.getKey(), "#" + entry.getValue());
}
}
}
}
skinFiles = FileUtils.getDirListing(skinPath, SKIN_FILENAME_FILTER);
Collections.sort(skinFiles);
int count = 0;
for (final String skinFile : skinFiles) {
if (skinFile.endsWith(".css")) {
prop.put("skinlist_" + count + "_file", skinFile);
prop.put("skinlist_" + count + "_name", skinFile.substring(0, skinFile.length() - 4));
count++;
}
}
prop.put("skinlist", count);
prop.putHTML("currentskin", env.getConfig("currentSkin", "default"));
Iterator<String> i = env.configKeys();
while (i.hasNext()) {
final String key = i.next();
if (key.startsWith("color_")) prop.put(key, env.getConfig(key, "#000000").substring(1));
}
return prop;
}
private static boolean changeSkin(final Switchboard sb, final String skinPath, final String skin) {
final File htdocsDir = new File(sb.getDataPath(SwitchboardConstants.HTDOCS_PATH, SwitchboardConstants.HTDOCS_PATH_DEFAULT), "env");
final File styleFile = new File(htdocsDir, "style.css");
final File skinFile = new File(skinPath, skin);
styleFile.getParentFile().mkdirs();
try {
Files.copy(skinFile, styleFile);
sb.setConfig("currentSkin", skin.substring(0, skin.length() - 4));
return true;
} catch (final IOException e) {
return false;
}
}
}
