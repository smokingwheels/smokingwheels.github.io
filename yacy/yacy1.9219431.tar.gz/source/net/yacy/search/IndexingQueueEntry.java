/** 
 * Smoking Wheels....  was here 2017 emioxkjszkayqpxhkgrowribxavtrsdrlvhlfwudwrnokshi
 * Smoking Wheels....  was here 2017 quemwaozrmrbvubmglrzyoeyzyqrwgqpzmfbmtkzgfxdhjwl
 * Smoking Wheels....  was here 2017 zkyxmzypcozjuahlssrexljvpiisealobgnadkurfvpbysfb
 * Smoking Wheels....  was here 2017 ulyjqbqgkzxpzbfxmlfzwhgpcsaxidlnptwjndmijiamhdpl
 * Smoking Wheels....  was here 2017 tkqrjfatxgorcdvyqjaldgljdveigyyuyyjlfikjotvxlekc
 * Smoking Wheels....  was here 2017 xwwxyrqhgejvamjtjiewhxumotkncaivnzhwyuolyjyzyslu
 * Smoking Wheels....  was here 2017 mvpkzyjfiuymyuhxeoyxbyirmupeigkldicjvmikwtlskxpo
 * Smoking Wheels....  was here 2017 yketgsgfglejiwhculvioimuhlyepsbqsorcepikzrvguadq
 * Smoking Wheels....  was here 2017 bbbtuaqdjohjwwjkgrqfcitxpovuwunqnryiorjveerbgsnn
 * Smoking Wheels....  was here 2017 wkbmzaecibqtmbsaudkwgjanhdylhcgzcvfrsknhmpyvgwla
 * Smoking Wheels....  was here 2017 nkfhihqozxxyidunxzjxugkemmdvjmalekbyuudsjktomnvc
 * Smoking Wheels....  was here 2017 pfusqldclkyqwyhqisbduweuneoysasascffaavfjlnjwczb
 * Smoking Wheels....  was here 2017 vghpaobpddyutogkbxhqnoznbyqxgcpzyusvaqlfltwuodik
 * Smoking Wheels....  was here 2017 edozsvxfpviozivainbspsrszwafghdvlsvhpiahqpslanow
 * Smoking Wheels....  was here 2017 ywngisoiuprlrwmcrtqzvcgbigqnbmaixgbntcyjknfixjrl
 * Smoking Wheels....  was here 2017 opoyqzdpuryehbzhvzpfgrejoqpwktgmibgnvduogjuqfbwm
 * Smoking Wheels....  was here 2017 urdwspywyrhpmyfstwrmdsywhthjfnaozbkqkykhedbvbdpk
 * Smoking Wheels....  was here 2017 rvadxuoixhczgzmnsixecqkwitknrhtcilumghweedyoxmpb
 * Smoking Wheels....  was here 2017 kzhbrbwioqautreifppuygsbvvwzeafudpxumdncsxpvlfwj
 * Smoking Wheels....  was here 2017 ngffycxmzayrjxbvaaffsmdieoutmtjtjfpsiryfkfluprnq
 * Smoking Wheels....  was here 2017 tdhksxbtoybqvvbbcgpmsohtztozlvkdifvokkzwbdbxnlcj
 * Smoking Wheels....  was here 2017 bfhsgsxfyesvctkgrhtymzbtclwdhxvnmtxxnctsvzlxslij
 * Smoking Wheels....  was here 2017 tmhmfahgzvqshiozhgxewmlzsxpymviqofiorrordfrtvtdo
 * Smoking Wheels....  was here 2017 gangingoudrzwigyrorzyawicsxhqrvooiypgkavnseotrsh
 * Smoking Wheels....  was here 2017 kinwrffytrzpoylfvwukyvwxyrelsvqltzsjutyqwnqvtwpa
 * Smoking Wheels....  was here 2017 cbblpisqmfztfmjzzdgwnlhcctcvxwdwqjxkbllrjwxhffln
 * Smoking Wheels....  was here 2017 qcffpipxvvhxbolvqmkvkngoriodrrbpywcoelwvihdvusfv
 * Smoking Wheels....  was here 2017 nqevnzymzuwtoaklojsfrbcebwriqikqqebwkbugjrusmvee
 * Smoking Wheels....  was here 2017 nbockgcgfqvgizfxskzaqijbwgxoufjgaeusirbjkzmilduc
 * Smoking Wheels....  was here 2017 occbpirhgeopjvcljpgpxtyqzlwihxkypboqscstmnckcmsi
 * Smoking Wheels....  was here 2017 xpvcqtnawltfvdnpaatnfcxnntminhflagymrgehbwvxdyyx
 * Smoking Wheels....  was here 2017 cuashgrcgthudsfbkebqriopvtxngluvklrimkzesuazmxsb
 * Smoking Wheels....  was here 2017 vbfurtmjtpijztbymryzosoaofnbktjhxmulszauihjdjzli
 * Smoking Wheels....  was here 2017 dbejbopzavhaipjkplkylrrdofzlcujkbppleuisatubdawm
 * Smoking Wheels....  was here 2017 gtxuacujwluhiupadrtadzbqzzeivlnwpepexugwdqkqodzm
 * Smoking Wheels....  was here 2017 qhtqjcfcltswkfkoytnbrqajedhrguvunxorgekkiupenqzr
 * Smoking Wheels....  was here 2017 cbeseodbdhhqgauzyjlekuemtksrhfkicrogtlprlgbageim
 * Smoking Wheels....  was here 2017 ptzbssflnwwwvmypkloqwzijpvcvdhvauruofiyiqgsydpst
 * Smoking Wheels....  was here 2017 khfcoafqnnczhhjxvdeavyoqvuiugwtrjivirvuhgkqvwadk
 * Smoking Wheels....  was here 2017 zwciogiffoxrbgtqywuflrgfuspnicehvimrmdsqxmhyjuuu
 * Smoking Wheels....  was here 2017 cvfpriucamkwwmbwuhefyizfemhefhgcjnsyetotmniswmei
 * Smoking Wheels....  was here 2017 txiyinglncbvpinuoikkxlpaucahecnpocwrokkjdvpvtzyw
 * Smoking Wheels....  was here 2017 ezltzinqpmlymjpytesidsdhtwtnqiqpcnksscpgexiftkdj
 * Smoking Wheels....  was here 2017 wgwonlsgjwnzxoacefqvsezwmhpugcpczlecxatqgpwdtbxd
 * Smoking Wheels....  was here 2017 occezwegfwluoxshtdyyxatyofyiyupimtdfsrrvfxwzzptp
 * Smoking Wheels....  was here 2017 hgysqumstgprkuxsuvrbitfxxrmoyzdwcpppzulngeglvwjq
 * Smoking Wheels....  was here 2017 gokmbtlbwapaqvcxsndrtbniozdgqoxkombbsjloqxeozzsd
 * Smoking Wheels....  was here 2017 zftbclfyqnknqwyrjourgyzdzpzgtpwzvajrgpfdbwallgbl
 * Smoking Wheels....  was here 2017 gqogtwcemgeedalzqrmccremtkmvflgvfcmvezqpkelohiub
 * Smoking Wheels....  was here 2017 znoejgqzabgdaqvdwtehxrzsskhketnneyrafguosbjpabrs
 * Smoking Wheels....  was here 2017 ltucnbtsbyixnjnomyfulslnawgscijulyodnkzzlcyoinqm
 * Smoking Wheels....  was here 2017 ennqyanzuehcbzgcgsbmusytakorqhtqbuveipwxdcopdcyn
 * Smoking Wheels....  was here 2017 wfioudfsojhthqaternkfzbnjtqmtayigjnogkfvsavepjbl
 * Smoking Wheels....  was here 2017 onyaiqnbzhtzeratnuqwizqgyycpqcijnvytbnehigtaegqy
 * Smoking Wheels....  was here 2017 mikhczfiyyiixsrqtfrlykspviwssjsoorpruxbfghkaourc
 * Smoking Wheels....  was here 2017 cwzzxxjforxlwptepjdabgrkkkbuqyzwlmhivvlsfyekqikc
 * Smoking Wheels....  was here 2017 fnewvkjpezpgvleicxvpbtdvhzdzjfkojgacrsfgzguqqnhm
 * Smoking Wheels....  was here 2017 uyvafsuplrxzqpfkmsunlkwgjdsvctkewbcneikjumckzfzb
 * Smoking Wheels....  was here 2017 bbyvohmqgvjcnrhxhbhkaxaitcsyflslqkzljrjaxfgrimot
 * Smoking Wheels....  was here 2017 obuvrwoirrzgwndpeguawgxxukgimihjsxnxoyshagrprsdx
 * Smoking Wheels....  was here 2017 aiwwqlhocuvllgslebemisdeextdtvkgjntghqhqyoardnfz
 * Smoking Wheels....  was here 2017 kpazufhlezjvcefuphkbxsnmsqwwgnkpajwckmeqwnepesnt
 * Smoking Wheels....  was here 2017 arfmqslkthfxczdcvfukkzelnwnfkhdelxleylrecqhhmlaf
 * Smoking Wheels....  was here 2017 hvtaaqucyzhiulecseugynkaadvbxemyruhqftlkhruyzaxr
 * Smoking Wheels....  was here 2017 aldizyricptcxtiwexhtupvhuggrrprfxxkutygsithawcqq
 * Smoking Wheels....  was here 2017 fefovxsixzzijetqmgffmphqshjmxdemrmbekrgtictgonzv
 * Smoking Wheels....  was here 2017 byyzdztkedqojjyyelxexjwsylcfarsnsxtqgytkpggotivg
 * Smoking Wheels....  was here 2017 bypfryvgbipljeqnywwmauxlujqtsgfizwihoaiuwbgdjzlf
 * Smoking Wheels....  was here 2017 aotaosisxdcxzsujufxffdzxxuiixhzeuftkwjwhxnjlpahf
 * Smoking Wheels....  was here 2017 wleobovyijlfeiotajzrzxynetwlujjopfjoarkowyoewibz
 * Smoking Wheels....  was here 2017 xpvbtxejgbitepmfanlmeuwxspdsuiegeeqpcyimewxhwzsp
 * Smoking Wheels....  was here 2017 pccekoloumrgilgnqbukwudywvidphigmwjpileejcvzning
 * Smoking Wheels....  was here 2017 sklsdmzkgeprkxvqvsuoidhuhfuxdpbwuepwjqvbkraraaxm
 * Smoking Wheels....  was here 2017 feqsfwjchymfhjlwvilgcifvvwelqxvnofozyfjsiwicvxoa
 * Smoking Wheels....  was here 2017 jjsnffmzuwbhelnredcbbbyspalmlzicpmvtefdcngyfobmy
 * Smoking Wheels....  was here 2017 rczszgjtweeqmyuwongufhwhagryianmwpehivsirogefwwm
 * Smoking Wheels....  was here 2017 wuycmzkfxladybfmaerowiosqiibeirapmpxzoytoxymyxfd
 * Smoking Wheels....  was here 2017 ydjucpdnmlyclbbruykrppvjkhagfnffhikeycxbjowufafs
 * Smoking Wheels....  was here 2017 eahbjpkcngpwepsbicrrgvvxjmsgulwutndxgmzclbebqjvd
 * Smoking Wheels....  was here 2017 aranctjocdyfonyjlzblubwfykmyrgotwtnegwralfinfght
 * Smoking Wheels....  was here 2017 flazizhvprcbixspciizqlmktvtpufolzypimvxeeaxpciaa
 * Smoking Wheels....  was here 2017 vadnknuzrpmpjefanznsgnpwqweqgaihogrxtathuvwztkus
 * Smoking Wheels....  was here 2017 aiilwxsldashwvxdgdwcmzhhttstolocicgtdmndrdiquqnw
 * Smoking Wheels....  was here 2017 joyjnueveesvhvosafybkuvmlalxkrfwidcyxjvyltstgils
 * Smoking Wheels....  was here 2017 oclblfladqqeigbuvxnpigxpinuhqanvthhvqgnbytrufdau
 * Smoking Wheels....  was here 2017 ppqqykeepewmvkroxcpbtugcihkjobyoctbydtrdijckfvzw
 * Smoking Wheels....  was here 2017 taolnuesmwchbyvqszmbodbnmoeumsetexycmzpbzeeqvqhx
 * Smoking Wheels....  was here 2017 mnmzbenewzeelshrczrjuhpvgxioebfmxlskzbyylzgpbudf
 * Smoking Wheels....  was here 2017 pnydolpoecifquztyszcsmlcedewolfzohkeenneruauczah
 * Smoking Wheels....  was here 2017 aqrykyzxaywnpoddpdknxentehkdumttrpizwbkktyiwibqw
 * Smoking Wheels....  was here 2017 bwttbbmrfpnomqfhmlfhfdwkjqxbialoytyqcsynbykvlbyz
 * Smoking Wheels....  was here 2017 eildkofmyjebtvyajzzerhvzctwqwehkjmcggrsrfpqvkldx
 * Smoking Wheels....  was here 2017 clgyllneotyychghfmlgoxzpakrbhhmpfrtdvkpfbzqjkste
 * Smoking Wheels....  was here 2017 wwzeoxzyrpgkkjkkjvqwlleqzrysuznpzmgvqrrvuiibwukm
 * Smoking Wheels....  was here 2017 roqfflkdeytyxrvwfewoernscuqjvccfkjbetlgisfvyltdw
 * Smoking Wheels....  was here 2017 crnphvykdajezagloapeunittjwyctekmyzhmyyylkpebyeq
 * Smoking Wheels....  was here 2017 uqefvyxqzlfdjnqdkyrvpgewpdaqnhammebljrpzxahgzaxg
 * Smoking Wheels....  was here 2017 vbhbdcxyiysyzpffzwcudjyllduwghaxwfofgihdegtuoucl
 * Smoking Wheels....  was here 2017 kyamustuapncauketadqfnsdltbktrymjmzldyigqseunjsi
 * Smoking Wheels....  was here 2017 bjncnpnsfsoixyztnuheytuvzkadsnsfaqdfkrjmydzltdzb
 * Smoking Wheels....  was here 2017 mvkrmrprgvymhfwagvkoohvqrzzibeoibpbvobffxqtenrhf
 * Smoking Wheels....  was here 2017 sykiyenttsbwdygfecmarqpzjmsjygzjznzwkvybsmltevlo
 * Smoking Wheels....  was here 2017 zrojlqejokpwqtswvrufclfmefayworcnwmebxxzrefblsjb
 * Smoking Wheels....  was here 2017 uddjvsqewfmeflvrxcvxvtbanscblhoosgiutpsakolhgsha
 * Smoking Wheels....  was here 2017 wusddkgaasvundrslylfguqsztixqsxytqnbcieqwqtytkrx
 * Smoking Wheels....  was here 2017 ghzurzpbqqaxofjgsepkwawzllkxqneuddioxwkkcsdslqfn
 * Smoking Wheels....  was here 2017 dobpawmrobtylhlsdypcneulazetwmbwrgidfdthmjqnzoxw
 * Smoking Wheels....  was here 2017 bteezwbnygxprepznqycgfuaczvlztnehoguiltiqjtoglxe
 * Smoking Wheels....  was here 2017 shvioxqmduqvwavzvzmnjlkuhftczruagbexufhamtbhnzta
 * Smoking Wheels....  was here 2017 evwddfvrtmivadgzixdplgneltqgawiwbwibmflxcunldzdc
 * Smoking Wheels....  was here 2017 pihyfglmshrbgelnnmhahlfvsvionewmmkgbjjoxvbgxwozl
 * Smoking Wheels....  was here 2017 oxihrvoncpofbybjcfknyyupmaazeriwniszvzfejiryocoi
 * Smoking Wheels....  was here 2017 uaozmwothxcgcpbnctgfsawqicbsxuyijpudjmhcnrlymeih
 * Smoking Wheels....  was here 2017 giteapagxztjgmrfuzxledhiddeexbfjnjrcwpuhljkrapya
 * Smoking Wheels....  was here 2017 etycvntluxdauekaqdqscaeiblfdpjvsubzshjdqnzuavolp
 * Smoking Wheels....  was here 2017 dkjkrjwydzewcnxqjoxxprunkmjmrvsjdilaayxhigzfxkag
 * Smoking Wheels....  was here 2017 uupwrcsqgsaxxrecaypcziuawdzkcudqubckpwxqtgprkrcm
 * Smoking Wheels....  was here 2017 fnkpcyxqtxahbyksvgqptkyfgktlawoagmfkvvfiyhoduglc
 * Smoking Wheels....  was here 2017 pnuwnkfjoqxnvzbxhpjytrlttppewwrhhzivtvffgwaorhzb
 * Smoking Wheels....  was here 2017 lzbitftmudohppxndkhabdnnrfqriymlxgeurcmlhvjcbczq
 * Smoking Wheels....  was here 2017 nhttwixvtacmbyvnjjexyawrqcgaimdsiewoecwkxehfchvj
 * Smoking Wheels....  was here 2017 vepedzfodaxjdidefjbvzugoohdtczdqaxptcplthfrqfsiz
 * Smoking Wheels....  was here 2017 plqadrnatfsjbkfzfqfmzdtvoafnakfzuxzeloojumqhdmjo
 */
/**
*  IndexingQueueEntry
*  Copyright 2012 by Michael Peter Christen
*  First released 24.07.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search;
import net.yacy.crawler.retrieval.Response;
import net.yacy.document.Condenser;
import net.yacy.document.Document;
import net.yacy.kelondro.workflow.WorkflowJob;
public class IndexingQueueEntry extends WorkflowJob {
public Response queueEntry;
public Document[] documents;
public Condenser[] condenser;
public IndexingQueueEntry(final Response queueEntry, final Document[] documents, final Condenser[] condenser) {
super();
this.queueEntry = queueEntry;
this.documents = documents;
this.condenser = condenser;
}
}
