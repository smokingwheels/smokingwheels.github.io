/** 
 * Smoking Wheels....  was here 2017 zdaieqnfadvakqlrrpzqhsalscajnlohsqvvknjxpazhiicp
 * Smoking Wheels....  was here 2017 ktuqzjjfjgyhroggtywrsfznwnjzwpqfwfrqkcildynywslw
 * Smoking Wheels....  was here 2017 wwqpjmstzunbwavgdrwrgngnelvohxybujxajermypcgxbtw
 * Smoking Wheels....  was here 2017 egbscyoesdcnyrgruwrlzydatlfnbhvcujlaokzyjysxyqpa
 * Smoking Wheels....  was here 2017 gwqvhdbatxmccnwsbrfafbavzkonoyxuismvonwwcasvsvvb
 * Smoking Wheels....  was here 2017 lyixhptemyrjtsjvjrpqorrcnmcmnhzufdlaeqkqzgocbipy
 * Smoking Wheels....  was here 2017 fbhgpcjsmlaiqrmtnpivuvcdgalnxbfckpzkoauuefdehbex
 * Smoking Wheels....  was here 2017 iwykctxyssbbsckknkakzvnngpkbxczyflayygmebuksufgk
 * Smoking Wheels....  was here 2017 vlycwvnngknzdymbqjojnhkdzeytyrutdbsyzcfxgdsohfqd
 * Smoking Wheels....  was here 2017 yzfkeyugnjnukjhdkzfzxymabukmsephygmzlsairppytukc
 * Smoking Wheels....  was here 2017 fazpqvjfesiieusjnyhvawsnjwikfhmlpaatkhbaluvfivam
 * Smoking Wheels....  was here 2017 jgodcogtawmtlxvsbinpxljgaamyqztnkogifmwuyplamnzu
 * Smoking Wheels....  was here 2017 lssxpnrmhjtniqzkgjvkxdxalcytjjbywlhzladuvcuhxher
 * Smoking Wheels....  was here 2017 sphwledeieffjfvxpnjmoubzggzseygktjogxawhytifpwsd
 * Smoking Wheels....  was here 2017 qmmhgjjatjeufafxxonjtlukivdzzklxbiuxrthymcycsdzj
 * Smoking Wheels....  was here 2017 abstudihlhdjvuejdlavmmjxvlfzzqyrbovycvwnubpqshnw
 * Smoking Wheels....  was here 2017 xirzfwgpppxjkkeoomtxdjhiczhiqvkchpxrszifnsquhugi
 * Smoking Wheels....  was here 2017 lofauaqtnenlkbswtcwwgyftvopyqkrzlekpjisgoloqkggs
 * Smoking Wheels....  was here 2017 ggpdclfxydinmfscjcugrhdnwoszxcwfpgzodeehaxfpfswg
 * Smoking Wheels....  was here 2017 bcdxzgxiruurrngdnlfvmsifjokvsvhczdomibfdiypighsl
 * Smoking Wheels....  was here 2017 wdpbmqarxvsjcysfkkapysgssntelspzchjtnupycratdkqx
 * Smoking Wheels....  was here 2017 yqvpzgaszdfggqrvolkxseqbomaxvhqrtltunlhyfmazwusr
 * Smoking Wheels....  was here 2017 uaawaxppotmfubarsjufpdmqtvtduemdypjlmhmvvzklqjky
 * Smoking Wheels....  was here 2017 fcpjjptqncdkswvsycvipwzzlftiphonwbftqyskiafuwgff
 * Smoking Wheels....  was here 2017 dvfxfqtkzvyfealelxlhdzqzbmbbpwjidfjypersitsyhzad
 * Smoking Wheels....  was here 2017 xmuluqaujtziqrmnuiuitgesetzioiwhlxioeajetomaveys
 * Smoking Wheels....  was here 2017 aonhrkhvhzmqvhvlrbiafsonslafkicjucskmwairahkruie
 * Smoking Wheels....  was here 2017 euuytypxrzzhrooxedrcrtbzucadivltnamluecaoaevhzuy
 * Smoking Wheels....  was here 2017 meggbpdpphjrjjbemutqkwdxvqzuuznxbftbswiizsmckfeu
 * Smoking Wheels....  was here 2017 dzxexxjtmupmjyxremtwawmllefangdpfjyrbwsqvlrlydpp
 * Smoking Wheels....  was here 2017 qqvbxsbkypzoksycaacjivdxnbhzkilszmucxpmmhvpgctkr
 * Smoking Wheels....  was here 2017 uzmjwbezxdccjjhlyilxkbiwezycsdtnqwdjopbtssgdhefk
 * Smoking Wheels....  was here 2017 pynwvfyzmzrmmuiyhsslodmevsgavvslryeupphnthzahvwo
 * Smoking Wheels....  was here 2017 iuxreuwiaavkefqanrbijvjzclnrmwegwnivxtachwibammc
 * Smoking Wheels....  was here 2017 mzszlpqbgjusfbbklxxbrfznxngeqyfxfohimipclcbrqzkf
 * Smoking Wheels....  was here 2017 ujlilrgnzjdplatcalylnpnliphxlzfoahxgrwljpwfmqogj
 * Smoking Wheels....  was here 2017 hvtnhhyhjrrlezagombmhnmpumqokdtssglxbehzlfblrqwh
 * Smoking Wheels....  was here 2017 grnpgcfguekwufmjopklmvobxjpbfxtcddfvljchuqfqtxiy
 * Smoking Wheels....  was here 2017 fjyuzvtmyyqwabzdtnmwzpudpotnuxfrgzzuysexvqkmbhbn
 * Smoking Wheels....  was here 2017 wslqgophqkymtgroeewnvbkmzsviicoqjbpvwtxpydtraypn
 * Smoking Wheels....  was here 2017 hqrydpxiadbfhsvvcwnlivvxlrweisklyugeuicnthlbijwq
 * Smoking Wheels....  was here 2017 skosymfinacrzqdkzcpxdrvlppgylcpwtzjkmnradkcvzfxw
 * Smoking Wheels....  was here 2017 qngfhcfmtehsomkaroomzsjnkwluqzeuvpqhcoxqgemkcjcj
 * Smoking Wheels....  was here 2017 vteaalxcqzfpawuqcizwafssxbgcchpmlwxwxbhfmjqjfcbq
 * Smoking Wheels....  was here 2017 ibawdvntfbqpmtolpowdnthuobsohfkkcjkjnvmxmfwrztqk
 * Smoking Wheels....  was here 2017 jssuzuohzhqmmikypvjobcxxyzebyflgntoitxnzbasmjcyq
 * Smoking Wheels....  was here 2017 mfjbefsvmtmcqbdvywwrnjlkagctyxwatczorppbllyeozhm
 * Smoking Wheels....  was here 2017 kglgmbzqrwspyowbppbfwvfwwkjzmgawaopcpmgzzhqjzrjm
 * Smoking Wheels....  was here 2017 expbbtpkrgdjpvzwvjwgobrcwjyncmmixsqecjevitbbkoyi
 * Smoking Wheels....  was here 2017 ajtodsawwsucbaareplbbvnfsgdekzcbcgmizhiyieuhsiez
 * Smoking Wheels....  was here 2017 mdbbiwafwmzrzoxgicfefgtofkncklabrfujjpzxeeoocxkr
 * Smoking Wheels....  was here 2017 izyamfospvfgidrokuwieqqspmwthupowvlhpuppfqmlcmgv
 * Smoking Wheels....  was here 2017 oxchqcvzekigirtuozgpemqnejgtlfkzdpsjesxbcrvwhnne
 * Smoking Wheels....  was here 2017 kclvcbjvzcihlkskjeqgvqlbpcxzrehbifxdylxrrqcasrks
 * Smoking Wheels....  was here 2017 ldcynwwkqbnhhskdpbityecrudkqvhktktukaguzeedhowep
 * Smoking Wheels....  was here 2017 jrmdrqjzcoljxhyxgqczpjtzvcocepbgrleertbwweyhghmj
 * Smoking Wheels....  was here 2017 guigprafkixzlcszofuxduzudukadexcotisnrmjmswymkdr
 * Smoking Wheels....  was here 2017 irmgsmixaeytjggvagpuchlfjjfikntxykqojdywweklfwin
 * Smoking Wheels....  was here 2017 bwelmybeogvpkhldmlzfjvdokeodyhstslsmikuzeejdqpic
 */
/**
*  YaCyMetadata
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 16.12.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-04-14 00:04:23 +0200 (Do, 14 Apr 2011) $
*  $LastChangedRevision: 7653 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.lod.vocabulary;
import java.util.Set;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.lod.Literal;
import net.yacy.cora.lod.Vocabulary;
/**
* this is the vocabulary of the 'classic' YaCy metadata database
*/
public enum YaCyMetadata implements Vocabulary {
hash,   
host,   
path,   
file,   
mod,    
load,   
fresh,  
referrer,
md5,    
size,   
sizename,
wc,     
dt,     
flags,  
lang,   
llocal, 
lother, 
limage, 
laudio, 
lvideo, 
lapp;   
/*
"String hash-12, " +          
"Cardinal mod-4 {b256}, " +   
"Cardinal load-4 {b256}, " +  
"Cardinal fresh-4 {b256}, " + 
"String referrer-12, " +      
"byte[] md5-8, " +            
"Cardinal size-6 {b256}, " +  
"Cardinal wc-3 {b256}, " +    
"byte[] dt-1, " +             
"Bitfield flags-4, " +        
"String lang-2, " +           
"Cardinal llocal-2 {b256}, " +  // # of outlinks to same domain; for video and image: width
"Cardinal lother-2 {b256}, " +  // # of outlinks to outside domain; for video and image: height
"Cardinal limage-2 {b256}, " +  // # of embedded image links
"Cardinal laudio-2 {b256}, " +  // # of embedded audio links; for audio: track number; for video: number of audio tracks
"Cardinal lvideo-2 {b256}, " +  // # of embedded video links
"Cardinal lapp-2 {b256}",     
*/
public final static byte[] HASH_PREFIX = ASCII.getBytes("http://yacy.net/url#");
public final static int HASH_PREFIX_LENGTH = HASH_PREFIX.length;
public final static String NAMESPACE = "http://yacy.net/md#";
public final static String PREFIX = "yacy";
private final String predicate;
public static String hashURI(byte[] hash) {
byte[] b = new byte[HASH_PREFIX_LENGTH + hash.length];
System.arraycopy(HASH_PREFIX, 0, b, 0, HASH_PREFIX_LENGTH);
System.arraycopy(hash, 0, b, HASH_PREFIX_LENGTH, hash.length);
return ASCII.String(b);
}
private YaCyMetadata() {
this.predicate = NAMESPACE +  this.name();
}
@Override
public String getNamespace() {
return NAMESPACE;
}
@Override
public String getNamespacePrefix() {
return PREFIX;
}
@Override
public Set<Literal> getLiterals() {
return null;
}
@Override
public String getPredicate() {
return this.predicate;
}
@Override
public String getURIref() {
return PREFIX + ':' + this.name();
}
}
