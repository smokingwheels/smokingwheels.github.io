/** 
 * Smoking Wheels....  was here 2017 ffhrwfyqdmniddjrgzthogkatppmgjhdqjufakglgkwlswyw
 * Smoking Wheels....  was here 2017 kwmufkcecrjhzmmceicuybbeivlfioveelorzpubojecrjjb
 * Smoking Wheels....  was here 2017 kbupukpqwclndozcrrauppkcdwrelprvietsmvpprxgfpbjd
 * Smoking Wheels....  was here 2017 occbxsyvurtscokdgmtodsdxsvnhhysuuhsvkbqklkqykrzz
 * Smoking Wheels....  was here 2017 hmnmcfvwomotnyrxsorpimhyaborufazqvduvrfcambqicpv
 * Smoking Wheels....  was here 2017 kxokgwgbbxlukjwkavlthebvdfouekzrbazrafsmvapzvnvf
 * Smoking Wheels....  was here 2017 wjwplckakpefytivmpzyhjximeofwqehqijsqmxqmdpwojnt
 * Smoking Wheels....  was here 2017 aeicyjwpzjvsnhrrojmnyvqorawypllobosllouyvenmmitm
 * Smoking Wheels....  was here 2017 htdejngwkjqdyktpaviacsexpdaahkymlrsrnrozcueevjxp
 * Smoking Wheels....  was here 2017 mxrinppepzfrbvrpyzfeufsxlduydnafyyhjfmtoowqqappo
 * Smoking Wheels....  was here 2017 qpqkmyecsvitclvwndbbizvknxhiqyffcuowbtatymetuorb
 * Smoking Wheels....  was here 2017 ybyjpcjmctzzoltxgtaxiueonotbkcmgsbzrynkzcajsavgc
 * Smoking Wheels....  was here 2017 zvumkxzlkwnhbhjkzongpruphmsimsvhurfowddtdcywzkqx
 * Smoking Wheels....  was here 2017 mpnjtizhmpmuqqtjqofxezveagzmzrsmoyfofdqznqawblmw
 * Smoking Wheels....  was here 2017 llwssupponqxklgynabwlgwdavqfleqjnhbxnissurvqakqu
 * Smoking Wheels....  was here 2017 dntopthgxoaiwwlqdkekzhooafxlmrnpmngfqthgxqyityfo
 * Smoking Wheels....  was here 2017 ckgfzcuigtzxsjgdgmzboexuvwjgcvlelplfqtpgzeejmanl
 * Smoking Wheels....  was here 2017 buxfrvcdlnzuxotlxgeqgedkpkvdmpuiqtnxvxeokbnjrufx
 * Smoking Wheels....  was here 2017 brhhvhlhqmwkpmhuhyrdlxtgtqirbddmqorpuyreunhgardq
 * Smoking Wheels....  was here 2017 ijkmrbiqfnrlhgmozcpvqdmkxtcuoxjjdriviadobwaekkjq
 * Smoking Wheels....  was here 2017 kgicvwkhutrtqienrklfsxhgycuqxpnyddcjojuejsondxhb
 * Smoking Wheels....  was here 2017 aeoqdvsngnlmpjmrlwvdtpjizhcqicalzfzfuobzaywypinl
 * Smoking Wheels....  was here 2017 fcrwpgmytlubkitdotrparhmleckgpmidicroktzsshjmdxl
 * Smoking Wheels....  was here 2017 ggrwqsflslrcmjpmlodwdasvyxcwjpshjhwhtatoijixuzna
 * Smoking Wheels....  was here 2017 pdsvszoasplooyxizarlxrqsjwrerrvhrczukqkizmvarvtl
 * Smoking Wheels....  was here 2017 cnejtcpdqhrpntrsbcxejyhrwqntiwepiyigvvcbcavhpved
 * Smoking Wheels....  was here 2017 rktfulmhrecnprkuaduayjepvdtfthkpvkcxqlpwgaorgmrw
 * Smoking Wheels....  was here 2017 qzjkensiebuchyocjnmhdtaowlrlskiczdriqnwckxqipkjn
 * Smoking Wheels....  was here 2017 nuegkdbjtcadfzchwbkntftxwyurdxczsfugxjejqhupvooj
 * Smoking Wheels....  was here 2017 appfkjltjqjwjmcjmtflyzqfagwferznkvhstnzmjadfkcxw
 * Smoking Wheels....  was here 2017 ejhcendacjpqyixmnvvdzrfirgauiyrdlmkatvaoffxzzmgs
 * Smoking Wheels....  was here 2017 hifybeqcibtcjudemukwkbcilbnghdaorynrthgxbgqepkrw
 * Smoking Wheels....  was here 2017 vzmaqdpasydfkfqddjkddfjpgbwuaybucfhlvhxcbuebjuoo
 * Smoking Wheels....  was here 2017 odnwtkbcdhhbximiloltemfrfwxurhfzymrkgimbprnktvmh
 * Smoking Wheels....  was here 2017 nsagligztuzcdbcztqmsvjclsiqytibqtiutrgtuhaabnyjs
 * Smoking Wheels....  was here 2017 yzxebmqmyhiyooannbritrtykpkbxollhlccvcprbedenufu
 * Smoking Wheels....  was here 2017 iliydrysixnmvidrmpkcsnfoeasjcpmknwgexdihzvsdailu
 * Smoking Wheels....  was here 2017 mwscoyezuzeyxapksgkvudrvdfigolostueacajmnuurlure
 * Smoking Wheels....  was here 2017 jfskjpnxmfbqznrzlhomieprsbjjsfgvmsaxcmnjherpnnsp
 * Smoking Wheels....  was here 2017 hsgwwfnhtkghncaufdzlwjtcnsbpgjkmmlfjrqsfdkwcdgsb
 * Smoking Wheels....  was here 2017 tynurowgiszugdmpsofdgubnlmacdpeqtxlewserfcfpoyav
 * Smoking Wheels....  was here 2017 moxrptncznvfbhdibqukouvlqbyiowvmnjojbjkoybrsfseg
 * Smoking Wheels....  was here 2017 opcisbtmykobfokgkmsgdwmulgyvzhbnjjvfviczxmqjuade
 * Smoking Wheels....  was here 2017 eiztiaaeoghyccvuisdynwtpnfhpcjrlappfyrhgarpsfpyl
 * Smoking Wheels....  was here 2017 weuganbilefulihrpzmanwrfuhouwsufncnentfzliidtiyj
 * Smoking Wheels....  was here 2017 kzwiqowfooyseyxwejkggckgjdmslitbbcpdwbhanhxhujui
 * Smoking Wheels....  was here 2017 uqxtflrmybgcoxaoibvrbfmnppddijekfbyjolgkyqqdbfid
 * Smoking Wheels....  was here 2017 gmwpctxybmeryiggqowolypdevvwfgybstzjlzdonuasmnqr
 * Smoking Wheels....  was here 2017 kzwcwhjsmzzhdslruqblhktkzdbcardwpfjzoyezlixnhfbe
 * Smoking Wheels....  was here 2017 xviujczceyhczsrsvgydqxfzdfrgypbdbqadhxuocegfyngd
 * Smoking Wheels....  was here 2017 ucymqnzsfzvnugirasnovyjqzxrymekhsndedrtkcklpcvag
 * Smoking Wheels....  was here 2017 jzqdzcxjaxrexnazwlyckjamghjcivzbgqcqyhzvikyysunm
 * Smoking Wheels....  was here 2017 cancaqleeybabzoidfpgggcwtviwjgxksyqgucvkzvqozlbb
 * Smoking Wheels....  was here 2017 txbwoeomqjqeghdrvbftkwxkqahqwkonitocaqrajmldkwhk
 * Smoking Wheels....  was here 2017 jsyesbnvmwcaqkaheeqreuwwiwibflmwqmdkfsgseouppoah
 * Smoking Wheels....  was here 2017 epadsvudehngqmwqucbhevsklktceupfkytsdjpwgjcbpfjq
 * Smoking Wheels....  was here 2017 scnzfhclgtftaynjioycfbliwabureymqccvxyxbtogyorsr
 * Smoking Wheels....  was here 2017 tzvgankcrprqsnbmvnxxiuhgsjbqwmyxofatwzqcczgwxfrx
 * Smoking Wheels....  was here 2017 gfpreuzrontjwcwfpgwsxntzjgvghydyttttohpcwvkukgaz
 * Smoking Wheels....  was here 2017 navjbshbhimpzwoachavmdmqnwqnoylhymrjvyrkzjgwylzx
 * Smoking Wheels....  was here 2017 aypneaahmecetiypdiuuwqonaoaqrfyyckmksgepphoktsuw
 * Smoking Wheels....  was here 2017 psiskwgsbkficbexrjuiekdhaxuzuqycotcwotnoalleghdj
 * Smoking Wheels....  was here 2017 eitrvmdydqpjfbpezrzmsxssxvyfkkdfuarzzgmhzycaepvb
 * Smoking Wheels....  was here 2017 bbtnsldvcuhapnvwqsoobabyhlvgeaiaozqjsuafiedbmhaz
 * Smoking Wheels....  was here 2017 uimlspblpyodyvrshhwbatdgbdzecbqmxpptxtjwethtihai
 * Smoking Wheels....  was here 2017 byjzoyvcnmzxeshqbjqtrldhjmdmiokvadoewpadyortevln
 * Smoking Wheels....  was here 2017 xxcykvskzajsmcaxdetsjrpvpjktiqgmnbrwdgrbgroytiei
 * Smoking Wheels....  was here 2017 qkojnvdgklsfidlybfkdrefakxbxvtzebeilpqjzznmlymhr
 * Smoking Wheels....  was here 2017 rzymmswqjwihkhlmpgzqjczfqnqdsouwslephegohsfsaedv
 * Smoking Wheels....  was here 2017 wjqweoxzvqtdrgdmtgeypscymtyugazvtcelnjwoncvkkqie
 * Smoking Wheels....  was here 2017 fpjgprlvwkudjxvetmxcqocchozovielqqmewbycjupjugtm
 * Smoking Wheels....  was here 2017 xvzrdpzawamywmezelikblrsrzcifwfmewnifglosfbudtms
 * Smoking Wheels....  was here 2017 nrsliegrnqdlwkzrtxwismueplughjewjrytoiplqxabpbxc
 * Smoking Wheels....  was here 2017 vuybzlgcrpgvkjkemuerrxtbcoxthumwlkrkguwqpvovsjpb
 * Smoking Wheels....  was here 2017 ueihgrdxmnqlpgusqkfmgiyfrekkqfrwynxoxlageaxaccki
 * Smoking Wheels....  was here 2017 rdvfjnmyihjzyhstsgcaaneswkrfcerrqszvhjaphyqttxlw
 * Smoking Wheels....  was here 2017 bcpbyrygvasjcybznagvupjwprfhoinfocrxmxcgbdnmvucx
 * Smoking Wheels....  was here 2017 qwaiuhofxcfrbvxlatkrruujaouafoqrxuvvvoscwmquvwxw
 * Smoking Wheels....  was here 2017 kluwaqnlrdrjzxqhmrkoytyymzlcndonfjpxyeqejdgqkpun
 * Smoking Wheels....  was here 2017 szvryhismzccjjwzlhkugemtrzojgkengomqotvwllxeorwv
 * Smoking Wheels....  was here 2017 zchacasebuvtvqkgqixxiflclzoagcpqajbuvrntfbltkakz
 * Smoking Wheels....  was here 2017 alpliyqcfyklkkkbcvnridbpypiltdeavailamfrcvvcnvcl
 * Smoking Wheels....  was here 2017 wbksthidczprgpeqbafcnnuboswhgtnedakvtypsswkamntx
 * Smoking Wheels....  was here 2017 sfrwpsidcwlzvjilbjcmmejpxklmjhlusdsnvdreyosthtmk
 * Smoking Wheels....  was here 2017 cinenyhdxrhjvgudwqpiccuowcredmdxoiyfikrsxmnrdnqc
 * Smoking Wheels....  was here 2017 vfkdicfmiupxfvoumvkljrgnqjhsshwqzvzaogbdapwkmzwl
 * Smoking Wheels....  was here 2017 vwzockiuovfbdbcndekvrlghocjunvhnmfaedopnyycxbpzf
 * Smoking Wheels....  was here 2017 lmemdnexyrelddxwkfvuofoagleihpggtdmfvhgfmysgszbi
 * Smoking Wheels....  was here 2017 epdeaekxdltyvnymzqavvacaqtgmzgwtxraxtvfvwenytcnz
 * Smoking Wheels....  was here 2017 szheomadamnuevfixmrspecwwqlptrmhdznifsafkonnoezs
 * Smoking Wheels....  was here 2017 dohfwshdtlghkbesmytnegclgysjcerizqfruskkueczwofe
 * Smoking Wheels....  was here 2017 rqbiglqvsezezjizdpjmdbuunwkrsbjofjnnhyhuxjslpaji
 * Smoking Wheels....  was here 2017 wruvhmvgnuahoepyscydhregmsbsnbpzudaqvszxvwehzmvl
 * Smoking Wheels....  was here 2017 mkwgtxvtbsxvcfcmenegsjklidmvsdttbgsbsnwraloflbex
 * Smoking Wheels....  was here 2017 mxaivzxynnlevjdxubzxusbelzrstlkjldtbmftcbfcbsggn
 * Smoking Wheels....  was here 2017 eicdshmqfcqyevipbgmiznwokkzgjlmotondzwppxqkbrsde
 * Smoking Wheels....  was here 2017 aghxbqixvovcvboiuueafvsyetwpmuagzotcitqrpggnpjhd
 * Smoking Wheels....  was here 2017 wiaesbkdfgnusryaysqvnzxxwqfehkkslihzumjgpzrexkfw
 * Smoking Wheels....  was here 2017 qqytrxyxnvojcstxvgvtfnxhvyaqgmfjojjbyuljmyyxhiua
 * Smoking Wheels....  was here 2017 qkzqhslaeexokgrlxxybxhmesuovamjyemivruyjflqvssdq
 * Smoking Wheels....  was here 2017 jciceiqqtkyeivoizljgjgnylokyqbxkgpxczuawwenjioqx
 * Smoking Wheels....  was here 2017 pmkrctmaewdluampbuuesvicdwjkgefzbzaxfheswzqeravg
 * Smoking Wheels....  was here 2017 inveehevoeisavukjhcuhmjodolvhzxcddumzeeyuzhejopl
 * Smoking Wheels....  was here 2017 vnoosohvifnrmldfljmkpckjevydmyunevqjbmzypobnkvcl
 * Smoking Wheels....  was here 2017 pytehimebdbfvgiubujonsixbykltsaehahjnmvgkirozuqk
 * Smoking Wheels....  was here 2017 lounsrtesgmmbymbfokacplsyprfigyhrzpmttduodfanpuw
 * Smoking Wheels....  was here 2017 iikjcxjkjfnxinzfdxmurifrfqsbqsdhwfuagdtptezsssmn
 * Smoking Wheels....  was here 2017 nnmssottlyhccbktkivevtjwnfwxkomzpkfmxrnzvsmxouti
 * Smoking Wheels....  was here 2017 opfxelrgnlazccqktpwsjxxpsqrwomcgxqpqtqupzmnwfuam
 * Smoking Wheels....  was here 2017 ejzliqbhpfhsggsberedjbznzoxkhjhiabvodpzgngejexwm
 * Smoking Wheels....  was here 2017 jtlbelflruxstmbbxvunevelsxpcblssngcmpkvacfrgbnca
 * Smoking Wheels....  was here 2017 lbovckpogbwpbyhtooucizekmscxpcfccyuxacihrsqrxjxb
 * Smoking Wheels....  was here 2017 xumaqixrxengwcexuqpkrpyvgjwzucwlucprkzsphjubwjpv
 * Smoking Wheels....  was here 2017 mqqeqidenmixdqxlrzygizsgcourwhcywzlvcplvkbfajrtu
 * Smoking Wheels....  was here 2017 fpraernrhpewbmvrlwsrnraokbwshwkcvcmosugbpwenethq
 * Smoking Wheels....  was here 2017 jznqoxnynkbwbumypvaxxnnuwbjytisqlfdlbodpvggqehgj
 * Smoking Wheels....  was here 2017 lfjhjvydxzhtxaubypjlgogiiyvnfhdltgcgehibdtfvqfbf
 * Smoking Wheels....  was here 2017 ecpmkorpiujslwvylekercksygcvwsavynfalmhhagctxrgo
 * Smoking Wheels....  was here 2017 qpwavizvxjddzgyuktzalrmvcyfpcuyfpmsajytjaxfguesf
 * Smoking Wheels....  was here 2017 aydxwtjtaqqrxjudixjifdeskbkrsythlxauvurqbbcneiob
 * Smoking Wheels....  was here 2017 xroldqnliscgxqeqzhxptnnutahfpwpcmutcxgjshjozgcej
 * Smoking Wheels....  was here 2017 znndlamfsxdzzsfgizhpedtoilppylvtajwywzfjbqpgnrbo
 * Smoking Wheels....  was here 2017 imtuwfkrhxnhhpggrfljtohylfkngybundnqisaubbogqmek
 * Smoking Wheels....  was here 2017 eudkttvrmohuhkyamlnecoxzvkaxesbxuvdscnsfdzycpfpv
 * Smoking Wheels....  was here 2017 ayvgrnlhwasmsqbjpmynagoahlyvrnbbumjygsohkzogotrb
 * Smoking Wheels....  was here 2017 rrgwlmgwkpkklxuezgkgpxnqzxatyfilvhdidwbwizmhyjzo
 * Smoking Wheels....  was here 2017 cacbcamzeybatfmswaujdbgshrfhlbmpkuqdhtwzmcyfnlla
 * Smoking Wheels....  was here 2017 oegvarqmqyuzasrkvhgdgplhwxxjwlkdgsgzpmaaurncfrcl
 * Smoking Wheels....  was here 2017 psxltfklirxezugzpvgbtmctqxpceafckbrnbitoiiajezia
 * Smoking Wheels....  was here 2017 yhmldtugfpwtpfjleqlzrcmqqjczoufrdbvxawmlozlqyotg
 * Smoking Wheels....  was here 2017 qyqpgoaljfndbwiyvxtwkzbvickolxajygvhbxatbsdxdvfu
 * Smoking Wheels....  was here 2017 yygyjepxgmyyuytzceizlxnkigwupuoupiehamhvtxogtnvq
 * Smoking Wheels....  was here 2017 itotdmerkmicnxmhseoyrzxsoezvwdvabhlrzxogtfpbzmxa
 * Smoking Wheels....  was here 2017 pczoimvdvqiufjqurxflemkicnoboxgfrlqkguixmlgbgzdk
 * Smoking Wheels....  was here 2017 tbcdantwomriaipshqcnfzmcierdafkvxfwvjwgvosvchkhm
 * Smoking Wheels....  was here 2017 buxnpcksbyklkyxobvlnliycyfpzboeqnjomfgikvmwialnf
 * Smoking Wheels....  was here 2017 avozobnsxevacqmzsfrwpmrrvavsnqrnnykbvfwemhdeqbdv
 * Smoking Wheels....  was here 2017 jxmatmchamnfzdjzgwkkvvzlbfgtrhftfdiroigzwbsgqjvu
 * Smoking Wheels....  was here 2017 eahmgrkznmfkjizuzypekxifbrvuyukublmnzkgzrwwnrwju
 * Smoking Wheels....  was here 2017 rlyikdvqvczhpkxvkzkkynkclnwqandivqgfwmwlscdbsgxw
 * Smoking Wheels....  was here 2017 jqqvtteioldskvzvhtgqgtfkddynwemjosimjyizfjijyjud
 * Smoking Wheels....  was here 2017 aktpdnklowevtgiuqeurkwathdvvrsucmxritgbmmpmzvmpd
 * Smoking Wheels....  was here 2017 qryiptsnazycvphwrpznsmgzfjofxiszdskcpgvyewxxbafo
 * Smoking Wheels....  was here 2017 nsdbobqlisldbcnoykyltirepzlogjbsgwyhtaqtfndgpqti
 * Smoking Wheels....  was here 2017 dancmfwgbczvfdupglczjngqiiaaqqzhwkyqhvsnsfykpgot
 * Smoking Wheels....  was here 2017 gjnyfhkieocjelgxnreyqjfanbbahyuygnkgnhmbavkbocff
 * Smoking Wheels....  was here 2017 xstkxomgutpddyhtcizhvkbdpzqerodcwtkizetlvltbfoql
 * Smoking Wheels....  was here 2017 ihfnuqowgmmuqtlnlxujplmadhblmxvmnvjlpolbamppkjvl
 * Smoking Wheels....  was here 2017 brzmmhkggwcfgkqaidzrsondcivxpqzcftaijsumsosbklgj
 * Smoking Wheels....  was here 2017 wnoxvoysqizpanxdtbfzgbjyostbisycftgcqghnhmddrylt
 * Smoking Wheels....  was here 2017 swonvvlxomxhdaqdawkhommjyhwlahjzbifyyxshklervhhg
 * Smoking Wheels....  was here 2017 xzxkxojrkexzzemmpdtyfqqmvgmblwbllgikevydxuiwxfww
 * Smoking Wheels....  was here 2017 yiuuoqmavnhpiifvgnpkapupewcznaemkmhhjhhqzckccqpu
 * Smoking Wheels....  was here 2017 pqpeqcsjrxpfceafacsnbreicwprluagfhaqvufqaimausan
 * Smoking Wheels....  was here 2017 vzalegihdyqimrevebygqkhnzaxushfhkeqreglfpnwotyzs
 * Smoking Wheels....  was here 2017 znznpqupnoknyaidexmxjqvglokeyyphrwozfqzsrcavwxqk
 * Smoking Wheels....  was here 2017 ntqsjcwkougseqjvuktabkvvjtqzdnifdjnhahzshrugkqit
 * Smoking Wheels....  was here 2017 emkokrmabaracfixcnkitzlxxgismwsfyxkqxtacycfltgqg
 * Smoking Wheels....  was here 2017 aszvsqxceynyyqpohnjxvzfhmypxlfkwraiilwuxfnpkrfmp
 * Smoking Wheels....  was here 2017 hpfoqppkijubedugxyvavfvbryrnrzeubluwmrgnzgleafwt
 * Smoking Wheels....  was here 2017 msiatjhbekthmdtssleeosiojqdrevfaddlacmqmjzofcefz
 * Smoking Wheels....  was here 2017 juttxzzknmauuipxscbedtxktqtvdtvsekewowlrvoafhhdr
 * Smoking Wheels....  was here 2017 zvcndtxbndiyiprbedlawzakeupozwrjqrdpnpkeyccziymp
 * Smoking Wheels....  was here 2017 obiiufnvqitknfpppzmahckrhgzvlrnshsuvstniqyisdwis
 * Smoking Wheels....  was here 2017 qzpmkfoukdocbofhtmprhgcozjjuluorfovhiqyszunvxaag
 * Smoking Wheels....  was here 2017 yiinwuaiuyieyhpaqpktxtgpjtpueecmplbaovgellszdnfp
 * Smoking Wheels....  was here 2017 ncfefgczxjvaijecnnximbkrvitncauqavuhcccupaebmvto
 * Smoking Wheels....  was here 2017 ppcoueiqcgchramxyvfqpchwbebxytkuemiqsonxjymexqsa
 * Smoking Wheels....  was here 2017 sffvdjjjbtkxrplfqfugavwnxqcbpbdyckjvlmsdwvkuqwmh
 * Smoking Wheels....  was here 2017 quypbwgmrgjagwczqsfwwqigmkqjixhhbvwwrlegmmzobsqt
 * Smoking Wheels....  was here 2017 ihzqszfpaiszrsvkdonpmbfvfhsookmiogzczfplwcoixqbd
 * Smoking Wheels....  was here 2017 dygyjhsoownmjhfytfurjwfkslrlyaotjlczdxazxapidgvl
 * Smoking Wheels....  was here 2017 mgwvppmmwzblaceidlmqlejhxfagmmronkxjguqltwywyniw
 * Smoking Wheels....  was here 2017 eziugynqwcxaoutokgfgsgvbwgoijqcxgiifqlyttmqrurew
 * Smoking Wheels....  was here 2017 fdfqjraqrtuoehjttwzoordpbkijbtngbsnuxqrxobyqicdd
 * Smoking Wheels....  was here 2017 wxniihnjsxvtkvolsvxwmgzzavpffftksjwsumuhbxlwollr
 * Smoking Wheels....  was here 2017 rvjfqrrxopgmwtfjawlqjajntwycusxgggdrmgnmkqxvrsjs
 * Smoking Wheels....  was here 2017 iqeudunndgqynvklsyerginvhdejbfiaxqdsfojizekcccnr
 * Smoking Wheels....  was here 2017 xjrwyahxplumoyoxbicamrxtcmhsjvqefzcepdayjpernyuh
 * Smoking Wheels....  was here 2017 qfrkjykvicsumhfepmjxpyhjtcozmbslxalmlcnpoiupyagn
 * Smoking Wheels....  was here 2017 arltyhrjxittyigbafkymdpzehpkiopuauumvsbypxbjnfgp
 * Smoking Wheels....  was here 2017 wnikneaygljnxsuljnvveodgmsehchskvncfcodvxhzpstlz
 * Smoking Wheels....  was here 2017 dtbcewsbodlnpjdoxoqqzviacgijgkquusnxvlmhcnxefzrj
 * Smoking Wheels....  was here 2017 domygyfqdgzjknzwdyxqnrxhpzinmifqsdmcularcajgzras
 * Smoking Wheels....  was here 2017 invehffrqxgabocdwidipfwmxhtwutnxpsrpdvbqalchftvh
 * Smoking Wheels....  was here 2017 mimhctupzmwonepgbtyngtleevjvhrzvsuykcfbxhofwjjtm
 * Smoking Wheels....  was here 2017 raddvwbygonkzixmzlgfwvcdukgbleewotnuiisrmoyxdypc
 * Smoking Wheels....  was here 2017 currscpoxbigwfohdxhszgoojfqmatztxlvhqhagnvxpmfma
 * Smoking Wheels....  was here 2017 hehfkgconcpzyfljiwjokcwstpdgxblktumsbkgfnyvhpbum
 * Smoking Wheels....  was here 2017 awkhrkngabutbarsnjglgregeemsibybjclazfvkwutrxsdz
 * Smoking Wheels....  was here 2017 gyrrqvdgmmuympomaqunvmzyyutotycfgvwoxonxgmaqcohf
 * Smoking Wheels....  was here 2017 ipajodjjjiofrdtehdfyskbxtpgsuctnfsevslgcmkeieild
 * Smoking Wheels....  was here 2017 riprbcathrllhacndqxismjmlymhnfazeuaolfimteyeiyyz
 * Smoking Wheels....  was here 2017 dwvdzuardxzwhzrmodnlxzcgemgsahhvmgiwkkfakrluyoie
 * Smoking Wheels....  was here 2017 qgkmimptaqyuxxwgvxzgqntbibqqvkcmqrgzgvpsdaxcupnm
 * Smoking Wheels....  was here 2017 nsftmuhvitkynahhkjmcmwcanvxypcirjsgksonxuoygvuqw
 * Smoking Wheels....  was here 2017 gtmhamtzsjpextticjkmgcclscouhzckrkzzyxdfnygrebym
 * Smoking Wheels....  was here 2017 pcnntraobwdqztkixvleznyyyolocauvwairflzmrazzipdw
 * Smoking Wheels....  was here 2017 ptchsphenvuuyapncanfbseiqbpzmkymkamudyuuyxibaubr
 * Smoking Wheels....  was here 2017 lycqhvbqmdoffqxjekuwbkltmriwdnladewvmlmmeaxcdjty
 * Smoking Wheels....  was here 2017 tfrtafaanyvwodfoxusrttvlhvdlackkzldqjijdoxmnxgqu
 * Smoking Wheels....  was here 2017 fhggsugsppawwepbhdwkfamcfdvbhbexfcgedcwpkncyuqht
 * Smoking Wheels....  was here 2017 vdmwnxwhvsbqiqlcpsgcvtymrlljlpjykqhthptykxbgmxpo
 * Smoking Wheels....  was here 2017 xairralopewumtjdjzzaduwthxhiecvggvtwswzoknxqxvpc
 */
/**
*  ASCIIComparator
*  Copyright 2010 by Michael Peter Christen
*  First released 25.2.2011 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This file is part of YaCy Content Integration
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.document.encoding;
import java.util.Comparator;
/**
* this is a replacement of an insensitive collator object, produced by a RuleBasedCollator Class
* The RuleBasedCollator is a very inefficient class if it is used only for insensitive ASCII comparisments
* This class is a very simple comparator for Strings which can be used to compare also Strings with upper/lowercase
* Strings without applying .toUpperCase or .toLowerCase
* Strings must contain no other than ASCII code.
*/
public class ASCII implements Comparator<String> {
public static final ASCII insensitiveASCIIComparator = new ASCII(true);
public static final ASCII identityASCIIComparator = new ASCII(false);
public boolean insensitive;
public ASCII(boolean insensitive) {
this.insensitive = insensitive;
}
@Override
public Object clone() {
return this;
}
@Override
public int compare(String s0, String s1) {
        if (s0 == null && s1 == null) return 0;
        if (s0 == null) return -1;
        if (s1 == null) return 1;
int i = 0;
int l0 = s0.length(), l1 = s1.length();
int lm = Math.min(l0, l1);
char c0, c1;
while (i < lm) {
c0 = s0.charAt(i);
c1 = s1.charAt(i);
if (this.insensitive && c0 >= 'A' && c0 <='Z') c0 = (char) ((byte) c0 + 32);
if (this.insensitive && c1 >= 'A' && c1 <='Z') c1 = (char) ((byte) c1 + 32);
if (c0 > c1) return 1;
if (c1 > c0) return -1;
i++;
}
        if (l0 > l1) return 1;
        if (l1 > l0) return -1;
return 0;
}
public boolean equals(String s0, String s1) {
        if (s0 == null && s1 == null) return true;
        if (s0 == null) return false;
        if (s1 == null) return false;
int i = 0;
int l0 = s0.length(), l1 = s1.length();
int lm = Math.min(l0, l1);
char c0, c1;
while (i < lm) {
c0 = s0.charAt(i);
c1 = s1.charAt(i);
if (this.insensitive && c0 >= 'A' && c0 <='Z') c0 = (char) ((byte) c0 + 32);
if (this.insensitive && c1 >= 'A' && c1 <='Z') c1 = (char) ((byte) c1 + 32);
if (c0 != c1) return false;
i++;
}
        if (l0 != l1) return false;
return true;
}
@Override
public boolean equals(Object obj) {
return (obj == this);
}
@Override
public int hashCode() {
return System.identityHashCode(this);
}
public final static String String(final byte[] bytes) {
        if (bytes == null) return null;
final char[] c = new char[bytes.length];
for (int i = bytes.length - 1; i >= 0; i--) c[i] = (char) bytes[i];
return new String(c);
}
public final static String String(final byte[] bytes, final int offset, final int length) {
int l = Math.min(length, bytes.length - offset);
final char[] c = new char[l];
for (int i = 0; i < l; ++ i) {
if (bytes[i + offset] < 0) throw new IllegalArgumentException();
c[i] = (char) bytes[i + offset];
}
return new String(c);
}
public final static byte[] getBytes(final String s) {
assert s != null;
int count = s.length();
final byte[] b = new byte[count];
for (int i = 0; i < count; i++) {
b[i] = (byte) s.charAt(i);
}
return b;
}
public final static byte[] getBytes(final String s, final int beginIndex, final int endIndex) {
assert s != null;
int count = endIndex - beginIndex;
final byte[] b = new byte[count];
for (int i = 0; i < count; i++) {
b[i] = (byte) s.charAt(i + beginIndex);
}
return b;
}
}
