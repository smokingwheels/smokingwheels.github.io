/** 
 * Smoking Wheels....  was here 2017 mtmalkjtjovftotiowkbhmfnwgyvdresaywwyclcdludpowg
 * Smoking Wheels....  was here 2017 qpdaonmxvujagolncxcpfbhwnuwacguuxxativfbncctjnut
 * Smoking Wheels....  was here 2017 mlveelsliquaxvcvekzeyptvexyzrwuvizvwdbwdbpdwnqsj
 * Smoking Wheels....  was here 2017 dqkcsztdqlnzsgbebwgsfgnmtixsetrawxrkjbpqyyywnkkl
 * Smoking Wheels....  was here 2017 zsauwgoasykzbdwqldgmyjuboywpelitlugvdnxbtgthgnas
 * Smoking Wheels....  was here 2017 qmcknqiiwblklykqefrvhncbcyadlqvpdxluxfleezczuawz
 * Smoking Wheels....  was here 2017 yyilyrppoxxusktuikkotodgbszfcinnitkhjhfzftvzjbok
 * Smoking Wheels....  was here 2017 akoomhzpnxiywmfajgqnyrvrmylwjtzprfnnldltdmwppexk
 * Smoking Wheels....  was here 2017 hlytxoohtunyhlllvosawdkopnmlwicgaglwhhpzkkpmgbao
 * Smoking Wheels....  was here 2017 juyebwlanlldnsflqjhkqojlxrinkwxcmecckqiluwlkltfu
 * Smoking Wheels....  was here 2017 bndhetefhzkcibrrxyilsvkbetpxzitakoqekhrdhogmlkcf
 * Smoking Wheels....  was here 2017 nzmurdkrwxzqumdzywybubmkjmzrzxgemelfhpvidkbzuonh
 * Smoking Wheels....  was here 2017 epbqhcdkevwugeeomxnlvouustneycgynbftfdgovpbmixoo
 * Smoking Wheels....  was here 2017 ohjbwzprnsdzfprshcsayywsutnyqruyrmtkovqodnwvcmny
 * Smoking Wheels....  was here 2017 pzzlqlfzircrnoreoumopciygvnveogchbifcsziavfdllbo
 * Smoking Wheels....  was here 2017 kbwnbgtckdeufyntplxzndfldtgxvzfnanghsemetmdrwizw
 * Smoking Wheels....  was here 2017 iacgtpcbtvgiqbwqcxlmojsorjumdmnpsygeovqouqyafvkl
 * Smoking Wheels....  was here 2017 areusunbppiqhjmfwfsmzlhskwjdztgznpdmdnchyrcznyqe
 * Smoking Wheels....  was here 2017 ibqqclnrkrqiaombcrpseersarosiutntbefcjwidhlsdxge
 * Smoking Wheels....  was here 2017 klmmiksqyktexrfdbtidvrvoolcgpuqkbbrnksezrlzlpfcx
 * Smoking Wheels....  was here 2017 olvhcvdzfnkgfxgnmifxwjxngcadggrzisixedmtafyvroiy
 * Smoking Wheels....  was here 2017 mtbejzzymxryntkqdlznmtmcovpwdxaxsgabxnmjycyqmxff
 * Smoking Wheels....  was here 2017 amwsgotbfsvtqxwdgimqdtechakihtaamhyxgzdwksryhoiv
 * Smoking Wheels....  was here 2017 gxcmgicbekjnpkwvcoxfmmaljjeobzfojnlqdwrnsagcrype
 * Smoking Wheels....  was here 2017 poynbmazjqcjtlbyiypmlgemdtyxydludcfsttovhewrlvbx
 * Smoking Wheels....  was here 2017 rgvynitcziaoqmguwnhvfrcrzjzxvwwlafdwoomoxocmrdaw
 * Smoking Wheels....  was here 2017 izjhxmswpqksaiobtovagqpvtqvktftjhmjafilspwspqddg
 * Smoking Wheels....  was here 2017 sdlfquqcwyvpbwhpkpkzffnxjfgnyjssqrijrlrooasixifk
 * Smoking Wheels....  was here 2017 fegriknuwzajzkbplmjxbtefcaimbwpvxvqjbmpqiekhhkiy
 * Smoking Wheels....  was here 2017 jxfwapnfvqahjjrksekgyxzflggywknkeffsxjxqptihwjwv
 * Smoking Wheels....  was here 2017 djxfuadwfcdyanhqkbksinqrdgpslythxkgiudqqklfkxkje
 * Smoking Wheels....  was here 2017 oxhmdocmutweavffupofvrerfudwbsyqqfbmseywaddyabsi
 * Smoking Wheels....  was here 2017 camotgidohzaqnzhoqfzmsskxrxsigxvhqjowbivwzjmzbyy
 * Smoking Wheels....  was here 2017 hmyqnmcbtpnwmcnfofbmkgvjredvzfsnzabhqrnitlkvvilx
 * Smoking Wheels....  was here 2017 bjgfqxutwxtfihwqxpzjaedkhqladqtobvhpsdkiqfacxduj
 * Smoking Wheels....  was here 2017 nzjzphfarofyfbjlzjepbpqmtunkdtpceykscuhdudhptyvs
 * Smoking Wheels....  was here 2017 bvkwzvgudhscnpqtkgylluovhmkglzbndidbwfofsklxfmqo
 * Smoking Wheels....  was here 2017 fsubvvekmyfasmmzajagiljzkylfxcgneijjnhzjclawhunu
 * Smoking Wheels....  was here 2017 ysdafwljhtahrjztayhuekttwocaqcnwnmfotdnpaxvmiado
 * Smoking Wheels....  was here 2017 jckmrwsjgdrrlgnyspxzqssbrzevwekvxodvmbjdrtwdxrhh
 * Smoking Wheels....  was here 2017 ujsjvwanisyiijrtsaharulgaerxfvvreqsqwsanodkkunco
 * Smoking Wheels....  was here 2017 xkmvqhozvlvnwfhlyjbjmfjulhwwlvvdlzxsjydnllacamwg
 * Smoking Wheels....  was here 2017 neikhrujglrwxnlunwcslwhlrsinpbtbbcwyqvtdhikhzvfo
 * Smoking Wheels....  was here 2017 uzftfxkjhfyelflotbpahvcftdvxbvforwyprtaqjurhebyv
 * Smoking Wheels....  was here 2017 ckfubdjazjlmvoyzitzmylbkvmjkipzbdhwbphlneyarkvds
 * Smoking Wheels....  was here 2017 bfutuqyonueeqctkbzwnpiqmnyfogbgepqlbwisolebiuffb
 * Smoking Wheels....  was here 2017 nmocpbpomsltqlylcadxrjmglwxfwggukmxndzutffmgojrb
 * Smoking Wheels....  was here 2017 qlmnwhzsooucyrwawmzmvqqrsagklkrcepqskoyjrykuiukc
 * Smoking Wheels....  was here 2017 srqyjjcbtyyhuydgwcuoamgbmfgnqyhkubhausoyioanwfnt
 * Smoking Wheels....  was here 2017 mzmoyrdxhvzquvoocyfnlovxirebdqfjjcsdthlfylyggqhz
 * Smoking Wheels....  was here 2017 sjpwvuqrsidrtygnpgdbnrcyyvoxcmtxhidbzjlenhwcvhjw
 * Smoking Wheels....  was here 2017 oeznmqfetxzhrjobtqteyyzfiifcuqoddmyzkixchawjcqnu
 * Smoking Wheels....  was here 2017 kysnnhxlkggnyhahfwlaqssytbcyurlkwrthftenttepxkyl
 * Smoking Wheels....  was here 2017 wkgzxcwsxfzrcenquzwbuptsrgocwgmlncmtvnbfrzkrhpwr
 * Smoking Wheels....  was here 2017 uqflvqqmtamkxtdsrhxavmvfwhbhckabmkhhysldzigqokzq
 * Smoking Wheels....  was here 2017 jzmotuwnragllbfkfhsullxnjvkrvirkjhpclsqoastugjas
 * Smoking Wheels....  was here 2017 wxghhsnwszbxbhiwavsqovfviurnonfxcwaqpcabfhftgeeo
 * Smoking Wheels....  was here 2017 agxukrwtctycgxjlyxoyjgeshjbkesvetkmqutiiinehousz
 * Smoking Wheels....  was here 2017 pacphhirhmeqwqivdwdlhonwazdeqwubsldystokjbjommgf
 * Smoking Wheels....  was here 2017 uosikmrlcrihznqwzepcaxfjnhqxifrtpujwhmxnouwvosqp
 * Smoking Wheels....  was here 2017 xjyzkiublxdewswsbsjcmomlzerxtgkphlvvtouglxxrrfzu
 * Smoking Wheels....  was here 2017 qgdtfdxuqepqbtushlbxxfuqyvlttszhxtlmluahsvbxvzoq
 * Smoking Wheels....  was here 2017 vgabaoncdobelipotspeqrvqdsnhkouqugjvdhmsjfarigai
 * Smoking Wheels....  was here 2017 orlqgljurozqalodubdwlbpoplqozakworzasllsszyftlde
 * Smoking Wheels....  was here 2017 gbokpxjvhufdcihocgcffthomywxbprgddyoiviweizdxjcx
 * Smoking Wheels....  was here 2017 netoahtogfszgmqfnicqdhjfjjmxlasoqxecniwxoqtgwydj
 * Smoking Wheels....  was here 2017 fctpreykzzushorseqbwrpohzfzjfguojnuqwaavupyrwkyr
 */
/*
an Implementation of a serverThread must only extend this class and implement
the methods:
open(),
job() and
close()
*/
package net.yacy.kelondro.workflow;
import java.nio.channels.ClosedByInterruptException;
import net.yacy.cora.util.ConcurrentLog;
public abstract class AbstractThread extends Thread implements WorkflowThread {
private static ConcurrentLog log = new ConcurrentLog("AbstractThread");
protected boolean running = true;
private boolean announcedShutdown = false;
protected long busytime = 0, memuse = 0;
private   long blockPause = 0;
private   String shortDescr = "", longDescr = "";
private   String monitorURL = null;
private   long threadBlockTimestamp = System.currentTimeMillis();
public AbstractThread() {
this.setDaemon(true);
}
protected final void announceThreadBlockApply() {
this.threadBlockTimestamp = System.currentTimeMillis();
}
protected final void announceThreadBlockRelease() {
final long thisBlockTime = (System.currentTimeMillis() - this.threadBlockTimestamp);
this.blockPause += thisBlockTime;
this.busytime -= thisBlockTime;
}
@Override
public final void setDescription(final String shortText, final String longText, final String monitorURL) {
this.shortDescr = shortText;
this.longDescr  = longText;
this.monitorURL = monitorURL;
}
@Override
public final String getShortDescription() {
return this.shortDescr;
}
@Override
public final String getLongDescription() {
return this.longDescr;
}
@Override
public String getMonitorURL() {
return this.monitorURL;
}
@Override
public final long getBlockTime() {
return this.blockPause;
}
@Override
public final long getExecTime() {
return this.busytime;
}
@Override
public long getMemoryUse() {
return this.memuse;
}
@Override
public boolean shutdownInProgress() {
return !this.running || this.announcedShutdown || Thread.currentThread().isInterrupted();
}
@Override
public void terminate(final boolean waitFor) {
this.running = false;
interrupt();
        if (waitFor) {
try { this.join(3000); } catch (final InterruptedException e) { return; }
}
}
private final void logError(final String text,final Throwable thrown) {
        if (log == null) {
ConcurrentLog.severe("THREAD-CONTROL", text, thrown);
} else {
log.severe(text,thrown);
}
}
@Override
public void jobExceptionHandler(final Exception e) {
        if (!(e instanceof ClosedByInterruptException)) {
logError("thread '" + getName() + "': " + e.toString(),e);
}
}
@Override
public void open() {} // dummy definition; should be overriden
@Override
public void close() {} // dummy definition; should be overriden
}
