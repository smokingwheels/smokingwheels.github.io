/** 
 * Smoking Wheels....  was here 2017 msejnuofphbfyvliistiyqbilycomtkjiyphwowusjxuptss
 * Smoking Wheels....  was here 2017 meujmvzmxbwvoffraucuvnlzkiywqvxuksqesabwqqkwxhim
 * Smoking Wheels....  was here 2017 xwmpatppqtnttwtjqhcxwvgtjmknahlndkfnlpapksmrjpnq
 * Smoking Wheels....  was here 2017 yvyfdqmhonjfcxrenmtdfvroitaclmymblnwnwheffyzzgmm
 * Smoking Wheels....  was here 2017 zgcmarukqrxsmswekugziygqosohbbmbenabqnpzpzvtednp
 * Smoking Wheels....  was here 2017 snebejbdgtazzxmqdyzkzaripedbdxltppjhupzskamfllgs
 * Smoking Wheels....  was here 2017 zjovhobxvpszxkvdwvqkdbzifebrhemjtwmvfkqipslvsoqx
 * Smoking Wheels....  was here 2017 atzvjetjfhiywinlbrdkzgkplcwpjgkzgvpihjbxmpniabrm
 * Smoking Wheels....  was here 2017 dximonjlldkjsbnphyszyflgonjoltkuaccqviaypnustwwy
 * Smoking Wheels....  was here 2017 aeujjclisttymgwxmitavqvscfpnwpulfrrvtgnbronfldsd
 * Smoking Wheels....  was here 2017 pjvhnrslqxlrouyxuuzpnopqvhxtgwgrgthhglveubihyfda
 * Smoking Wheels....  was here 2017 zjdlyhekystvotkjqnhcgfyzubwskzpottdqvijmenyskuhz
 * Smoking Wheels....  was here 2017 pkpdwdbermhvgqbjryxcndkxfcfdkpyjplpsetykkvmlbrmn
 * Smoking Wheels....  was here 2017 cykzuuwxctuluzcfutflacsvsgbaqpsparjpgsnofbgrpckl
 * Smoking Wheels....  was here 2017 kqavjyiztlkrmswkdyyhtcwkzosnqbnditkriljyrmvyvjwu
 * Smoking Wheels....  was here 2017 qlduprmdknjryzztdsayvkcobjsfhlezgawoumyqasyxvdzv
 * Smoking Wheels....  was here 2017 foqfsgogckhzzdihkmpavnxlhgxurjwlrggbkobdupsqxifc
 * Smoking Wheels....  was here 2017 tmtsdcancpxhrwzhwyckkebmcahfdryaskdidsqbuelisbbl
 * Smoking Wheels....  was here 2017 fwwdqbriyyjpkzjjrbgeolojjtftgoanvposefziauskbsmw
 * Smoking Wheels....  was here 2017 srsoddmiknyetsbgfazrlopzbugvvjyapjquznodtzgrbxor
 * Smoking Wheels....  was here 2017 qdfkvoqmmrelojzaeimopbsnmregatxvzjvlimcwnpfczosk
 * Smoking Wheels....  was here 2017 sqoggwtynywewqfykpdqsqqkcgaxdpfkcnuucaqfcsvxnumw
 * Smoking Wheels....  was here 2017 txdybvmdyecicjdocwrasjjgupedtbnpjcmdollcorsnlzub
 * Smoking Wheels....  was here 2017 ywrpgkvsqkfdtsksrgacwmdbmaditmrlmncdehxrczqtvvui
 * Smoking Wheels....  was here 2017 sucnzxcqparbtbvjsgjkpnmyodtgenvfglbpqgxjiorocctf
 * Smoking Wheels....  was here 2017 rbpkvvszbojwdbpwencxqfdilsawkchnxwarxkivykedtbkl
 * Smoking Wheels....  was here 2017 ukoajxmgowjngoatfcypzocwzwilzhtbvzzsfymabxparaod
 * Smoking Wheels....  was here 2017 dttorfjbxzxgstsvfcwxuxondweluobyqfbhblvbwowxypin
 * Smoking Wheels....  was here 2017 diahyypjdgpoiyqcvzzjoqblgjjoxmilhhshcqdkygytxtdf
 * Smoking Wheels....  was here 2017 mopxprsimgfdfwuwymtyzqjavdavqyycxeqvhokrbaevepoy
 * Smoking Wheels....  was here 2017 aexejdljmuwzrirrtnvqbvlyrgklqcmswzsfylwvgfdqommu
 * Smoking Wheels....  was here 2017 zcqggiucyyuiinujqhfvznodtcbxsiwiwgfbkuaatkqvdbaa
 * Smoking Wheels....  was here 2017 rntmknynwbqqavcxfhbegfetjdwyxhffurnhlkprekslgfof
 * Smoking Wheels....  was here 2017 vxjmifmtordrvvqqleumnrbfbhunqwwyudixbgplehqsndsd
 * Smoking Wheels....  was here 2017 hyybtfdfnrjkclwclxbwtxfeqpexmdmhgwnikqigxkbcudiv
 * Smoking Wheels....  was here 2017 gpekqmvpnbrbkvjbqqwsgewpbjqnfowhwjjezbfhohsicxoo
 * Smoking Wheels....  was here 2017 bbzueixupfodpjzprxjokzoqqfxdatfgngghmgaysuskwhuy
 * Smoking Wheels....  was here 2017 luoxvfuzarwiurwyljzixczrxybsepwtjowsxhtxczinplps
 * Smoking Wheels....  was here 2017 gmjnixgpihqqgqkscykcvndkppkngflnukdxkjqctecfetwy
 * Smoking Wheels....  was here 2017 rbauqlihidfgrlerawofgnhtvnozdavplhgjnaeqzzxdrwtx
 * Smoking Wheels....  was here 2017 btnaycezzmcsvkbwxpqhtqyvuigwxqcjgwqbyzdaietjlrod
 * Smoking Wheels....  was here 2017 daaxtijvqzetueforvcfzpvdaupexyrhjeazpinvmvyabhzm
 * Smoking Wheels....  was here 2017 snyfuzqgtkkiyryiklpaylyijzvbsbeeehgpshnboibrkcvx
 * Smoking Wheels....  was here 2017 afzcyzyyevfqwayzntbdvkoguhpcellbitpkujrvvexanthu
 * Smoking Wheels....  was here 2017 licxnqouwpbfkpbmscrdczddofrykqpgsgljnisptgnaudrp
 * Smoking Wheels....  was here 2017 phlgykzzdhutpbkfwgwwmzkkgpcprpahnsnmwfrzepgztkpe
 * Smoking Wheels....  was here 2017 lvlzxdyxnslgwhirdejlyklrqofiqljzdisebgtxcophhxzn
 * Smoking Wheels....  was here 2017 bvvekulhtykytkmrxzbfrmkxrjoocomifoebnylpurlslhyy
 * Smoking Wheels....  was here 2017 xnmfqqtzyhdhcutgveeuetvgtqybeolrrdlyabnkuuvfqlua
 * Smoking Wheels....  was here 2017 qkprbeifhjmbzcfrumcaczldhdkuejsoqydymqzbwazcjnfn
 * Smoking Wheels....  was here 2017 dcqmkeyiizneuggnaunbnehfdahzscvsmgelexbkbqotnxbl
 * Smoking Wheels....  was here 2017 npgrrrpbxfnybhnowjjenoolioddqdsgyltamkgrqfiyffle
 */
/**
*  Html2Image
*  Copyright 2014 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First published 26.11.2014 on http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.util;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.JEditorPane;
import javax.swing.text.Document;
import javax.swing.text.Element;
import javax.swing.text.View;
import javax.swing.text.ViewFactory;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLEditorKit;
import javax.swing.text.html.ImageView;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.document.ImageParser;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.OS;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
/**
* Convert html to an copy on disk-image in a other file format
* currently (pdf and/or jpg)
*/
public class Html2Image {
private final static File wkhtmltopdfMac = new File("/usr/local/bin/wkhtmltopdf");  // sometimes this is also the path on debian
private final static File convertMac1 = new File("/opt/local/bin/convert");
private final static File convertMac2 = new File("/opt/ImageMagick/bin/convert");
private final static File wkhtmltopdfDebian = new File("/usr/bin/wkhtmltopdf");
private final static File convertDebian = new File("/usr/bin/convert");
private static boolean usexvfb = false;
public static boolean wkhtmltopdfAvailable() {
return wkhtmltopdfMac.exists() || wkhtmltopdfDebian.exists();
}
public static boolean convertAvailable() {
return convertMac1.exists() || convertMac2.exists() || convertDebian.exists();
}
/**
* write a pdf of a web page
* @param url
* @param proxy must be of the form http://host:port; use YaCy here as proxy which is mostly http://localhost:8090
* @param destination
* @return
*/
public static boolean writeWkhtmltopdf(String url, String proxy, String userAgent, final String acceptLanguage, File destination) {
boolean success = false;
for (boolean ignoreErrors: new boolean[]{false, true}) {
success = writeWkhtmltopdfInternal(url, proxy, destination, userAgent, acceptLanguage, ignoreErrors);
if (success) break;
if (!success && proxy != null) {
ConcurrentLog.warn("Html2Image", "trying to load without proxy: " + url);
success = writeWkhtmltopdfInternal(url, null, destination, userAgent, acceptLanguage, ignoreErrors);
if (success) break;
}
}
        if (success) {
ConcurrentLog.info("Html2Image", "wrote " + destination.toString() + " for " + url);
} else {
ConcurrentLog.warn("Html2Image", "could not generate snapshot for " + url);
}
return success;
}
private static boolean writeWkhtmltopdfInternal(final String url, final String proxy, final File destination, final String userAgent, final String acceptLanguage, final boolean ignoreErrors) {
final File wkhtmltopdf = wkhtmltopdfMac.exists() ? wkhtmltopdfMac : wkhtmltopdfDebian;
String commandline =
wkhtmltopdf.getAbsolutePath() + " -q --title '" + url + "' " +
(proxy == null ? "" : "--proxy " + proxy + " ") +
(ignoreErrors ? (OS.isMacArchitecture ? "--load-error-handling ignore " : "--ignore-load-errors ") : "") + // some versions do not have that flag and fail if attempting to use it...
"--footer-left [webpage] --footer-right '[date]/[time]([page]/[topage])' --footer-font-size 7 " +
url + " " + destination.getAbsolutePath();
try {
ConcurrentLog.info("Html2Pdf", "creating pdf from url " + url + " with command: " + commandline); 
List<String> message;
if (!usexvfb) {
message = OS.execSynchronous(commandline);
if (destination.exists()) return true;
ConcurrentLog.warn("Html2Image", "failed to create pdf " + (proxy == null ? "" : "using proxy " + proxy) + " with command: " + commandline);
for (String m: message) ConcurrentLog.warn("Html2Image", ">> " + m);
}
commandline = "xvfb-run -a " + commandline;
message = OS.execSynchronous(commandline);
if (destination.exists()) {usexvfb = true; return true;}
ConcurrentLog.warn("Html2Pdf", "failed to create pdf " + (proxy == null ? "" : "using proxy " + proxy) + " and xvfb with command: " + commandline);
for (String m: message) ConcurrentLog.warn("Html2Image", ">> " + m);
return false;
} catch (IOException e) {
e.printStackTrace();
ConcurrentLog.warn("Html2Pdf", "exception while creation of pdf with command: " + commandline);
return false;
}
}
/**
* Convert a pdf (first page) to an image. Proper values are i.e. width = 1024, height = 1024, density = 300, quality = 75
* using internal pdf library or external command line tool on linux or mac
* @param pdf input pdf file. Must not be null.
* @param image output image file. Must not be null, and should end with ".jpg" or ".png".
* @param width output width in pixels
* @param height output height in pixels
* @param density (dpi)
* @param quality JPEG/PNG compression level
* @return true when the ouput image file was successfully written.
*/
public static boolean pdf2image(final File pdf, final File image, final int width, final int height, final int density, final int quality) {
	/* Deduce the ouput image format from the file extension */
	String imageFormat = MultiProtocolURL.getFileExtension(image.getName());
	if(imageFormat.isEmpty()) {
		/* Use JPEG as a default fallback */
		imageFormat = "jpg";
	}
final File convert = convertMac1.exists() ? convertMac1 : convertMac2.exists() ? convertMac2 : convertDebian;
        if (OS.isWindows || !convert.exists()) {
try {
PDDocument pdoc = PDDocument.load(pdf);
BufferedImage bi = new PDFRenderer(pdoc).renderImageWithDPI(0, density, ImageType.RGB);
return ImageIO.write(bi, imageFormat, image);
} catch (IOException ex) { }
}
try {
String command = convert.getAbsolutePath() + " -alpha remove -density " + density + " -trim " + pdf.getAbsolutePath() + "[0] -trim -resize " + width + "x -crop x" + height + "+0+0 -quality " + quality + "% " + image.getAbsolutePath();
List<String> message = OS.execSynchronous(command);
if (image.exists()) return true;
ConcurrentLog.warn("Html2Image", "failed to create image with command: " + command);
for (String m: message) ConcurrentLog.warn("Html2Image", ">> " + m);
if (!OS.isMacArchitecture) return false;
File pngFile = new File(pdf.getAbsolutePath() + ".tmp.pdf");
org.apache.commons.io.FileUtils.copyFile(pdf, pngFile);
String[] commandx = {"osascript",
"-e", "set ImgFile to \"" + pngFile.getAbsolutePath() + "\"",
"-e", "tell application \"Image Events\"",
"-e", "set Img to open file ImgFile",
"-e", "save Img as PNG",
"-e", "end tell"};
message = OS.execSynchronous(commandx);
for (String m: message) ConcurrentLog.warn("Html2Image", ">> " + m);
try {
File newPngFile = new File(pngFile.getAbsolutePath() + ".png");
pngFile.renameTo(newPngFile);
final Image img = ImageParser.parse(pngFile.getAbsolutePath(), FileUtils.read(newPngFile));
if(img == null) {
	/* Should not happen. If so, ImageParser.parse() should already have logged about the error */
	return false;
}
final Image scaled = img.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING);
final MediaTracker mediaTracker = new MediaTracker(new Container());
mediaTracker.addImage(scaled, 0);
try {mediaTracker.waitForID(0);} catch (final InterruptedException e) {}
final BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
bi.createGraphics().drawImage(scaled, 0, 0, width, height, null);
ImageIO.write(bi, imageFormat, image);
newPngFile.delete();
return image.exists();
} catch (IOException e) {
ConcurrentLog.logException(e);
return false;
}
} catch (IOException e) {
e.printStackTrace();
return false;
}
}
/**
* render a html page with a JEditorPane, which can do html up to html v 3.2. No CSS supported!
* @param url
* @param size
* @throws IOException 
*/
public static void writeSwingImage(String url, Dimension size, File destination) throws IOException {
final JEditorPane htmlPane = new JEditorPane();
htmlPane.setSize(size);
htmlPane.setEditable(false);
final HTMLEditorKit kit = new HTMLEditorKit() {
private static final long serialVersionUID = 1L;
@Override
public Document createDefaultDocument() {
HTMLDocument doc = (HTMLDocument) super.createDefaultDocument();
doc.setAsynchronousLoadPriority(-1);
return doc;
}
@Override
public ViewFactory getViewFactory() {
return new HTMLFactory() {
@Override
public View create(Element elem) {
View view = super.create(elem);
if (view instanceof ImageView) {
((ImageView) view).setLoadsSynchronously(true);
}
return view;
}
};
}
};
htmlPane.setEditorKitForContentType("text/html", kit);
htmlPane.setContentType("text/html");
htmlPane.addPropertyChangeListener(new PropertyChangeListener() {
@Override
public void propertyChange(PropertyChangeEvent evt) {
}
});
try {
htmlPane.setPage(url);
} catch (IOException e) {
e.printStackTrace();
}
Dimension prefSize = htmlPane.getPreferredSize();
BufferedImage img = new BufferedImage(prefSize.width, htmlPane.getPreferredSize().height, BufferedImage.TYPE_INT_ARGB);
Graphics graphics = img.getGraphics();
htmlPane.setSize(prefSize);
htmlPane.paint(graphics);
ImageIO.write(img, destination.getName().endsWith("jpg") ? "jpg" : "png", destination);
}
public static void main(String[] args) {
try {
Html2Image.writeSwingImage(args[0], new Dimension(1200, 2000), new File(args[1]));
} catch (IOException e) {
e.printStackTrace();
}
}
}
