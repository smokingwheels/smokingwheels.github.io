/** 
 * Smoking Wheels....  was here 2017 padksupceagbolgetdgywpxcfoixpeemxruiuyphxqtqcffj
 * Smoking Wheels....  was here 2017 snxypmbdbtqlluathehpilcdkfwdvcfmxoqorjihbqqhdgzy
 * Smoking Wheels....  was here 2017 fuuoimbdnxhpqznmqngjpzslskptmwzrjomfoarfbqvgxhtz
 * Smoking Wheels....  was here 2017 ivtokhnkknuwhqgygkjwmwxqfnjlxgfuacvdoxzyiepmclmm
 * Smoking Wheels....  was here 2017 ntcosqmqvwbzvowwxefwbezrhajewkwwxwllzguomzgerclq
 * Smoking Wheels....  was here 2017 pzkihngrdogwzykgpoompbnqpszdhsfefsjjjoznkeluvvbb
 * Smoking Wheels....  was here 2017 ofjzkdmrahturbajomkbrbkyyqwuisqglxxonoqkezdzxnal
 * Smoking Wheels....  was here 2017 pibwqaazhegdanfthbbcdwsfndxukiwuktounfcdeamusgiv
 * Smoking Wheels....  was here 2017 fntmuvxicnpqogrdntanzmtiqrhdgqxvazceqtyvbavibjfl
 * Smoking Wheels....  was here 2017 ffysypmnuuzfxhkohfbhodelzdkatyzqpnpalrbxrbvcfncv
 * Smoking Wheels....  was here 2017 oblpknjsawvdzaoguigvkhtyjmxwdymtpngxurlzdkltpnst
 * Smoking Wheels....  was here 2017 lzhnsckhpsstaarsoivrirpkybskvlfwtkqrrtmyvpuhwnaf
 * Smoking Wheels....  was here 2017 ldtzsbqxsrqvlfkuiojqkhbvbjxomobbbvojmeuxjmgwzvgm
 * Smoking Wheels....  was here 2017 hyivkjllshrhxqtkdtpuyjtgjfznaphpvszhrjfhqanzdbwa
 * Smoking Wheels....  was here 2017 ycvddhkafigijqxvdvomnjlcsrnurgixmggbdcustpmgscor
 * Smoking Wheels....  was here 2017 rngglhkbcwakzwiqxxngwahagzmzwiywuvvnxixbbrgskzik
 * Smoking Wheels....  was here 2017 yixsecldmexgfeundkbydiqxhtzdhybjtcnrghcmechofeim
 * Smoking Wheels....  was here 2017 oyhkjrxfstautreowaxronavnskkvkwtqbixulgiawgegeck
 * Smoking Wheels....  was here 2017 mcfihhkjlmuenrtyirbstbhgtylgskxnxupuholisizhzxiz
 * Smoking Wheels....  was here 2017 yrrwojtanjwxruzfznwqmrouetzjjtvlhtucvqagozrwblye
 * Smoking Wheels....  was here 2017 mvynzsbucrdsryodqzvgvjehcqerlnqmwpsytvoigqscldfg
 * Smoking Wheels....  was here 2017 uzpfogqonzulfeltgtsscjsydklkydnyugkqnrxwpiuliqos
 * Smoking Wheels....  was here 2017 xvjyrfcmkbfkfvxgbsnhwdacfckazdyipxctaweoujtodttj
 * Smoking Wheels....  was here 2017 bfhbvchyqzazvpifpapnxkdklbzfalqjayjdhkrhdgtloprf
 * Smoking Wheels....  was here 2017 tkqdvqgoizdxofmjpckhhemuetixtcodcazvrozehvghmopm
 * Smoking Wheels....  was here 2017 ttzzuujgwrtcaxitarurirpiaavibmxvacyeqtzpcdvneezs
 * Smoking Wheels....  was here 2017 zyarzufcwufteybpepsypiikwwexffeaiintcssgslmvzjoq
 * Smoking Wheels....  was here 2017 uxwpyeqoekfjfydknblsxyusvqfipeclsdhkaloxnhgfqggi
 * Smoking Wheels....  was here 2017 pvsgnptfyvqppuiztmpvhmhcivdowjocfezdufcvbmqvbchz
 * Smoking Wheels....  was here 2017 dbemtbvznppkypohznwhadlsxgivagwgcjqixldihbfempdd
 * Smoking Wheels....  was here 2017 miyjzvnaolpzfraqjdimtkbylzmoekkkuwoofwvahhywgono
 * Smoking Wheels....  was here 2017 vndfsjrqxmeupqfnklfyfbgkcgllvryjccgqtnlwluyycckf
 * Smoking Wheels....  was here 2017 ruyqujhorzionjvsxwconajzgrjlpdlcatmqwoqzjgqnyozl
 * Smoking Wheels....  was here 2017 upylgwvpgmdeszwevctixoywmystmecwtsiwbnesxvqdzots
 * Smoking Wheels....  was here 2017 dpxslbuygubwaumfjbdpacxksfbupkjfvfzxecftfsxkrzku
 * Smoking Wheels....  was here 2017 zswswlayoxsbslficwqzplhfarjilrzxzpbpghcxrnniqxxr
 * Smoking Wheels....  was here 2017 ucbcjsrgheandtthtargtokftyugrcxxfnhaqijkwzzcwrmr
 * Smoking Wheels....  was here 2017 jebqzxbtucdcbwabhdcntqxopvrufaintzslvswpsewenxpf
 * Smoking Wheels....  was here 2017 rqqlbfsqrnkcjcgzzcybeeppkhsjhatfdcpnrdschkcfalye
 * Smoking Wheels....  was here 2017 yiuuddoexloxhbynieknvxpygrvsgzxubilagofuzfvfbknl
 * Smoking Wheels....  was here 2017 rmviajqcmelferulbrcrtvfoomctwargnhcbvhawkjlioenj
 * Smoking Wheels....  was here 2017 rngvtyghwfgauytueitphebnyparamjwvxnxztxqlxqathkk
 * Smoking Wheels....  was here 2017 vbwirbcvqljmahbuybkqyjyfgyezxzkdljbenszveegaarxj
 * Smoking Wheels....  was here 2017 mbrgheydqvlbbheyvajjpfziqymizimvcbesncqgbqngbkzg
 * Smoking Wheels....  was here 2017 cszcmbwwbrjljvtappcogqnslacrxrpyusrngfjbqetxuvvh
 * Smoking Wheels....  was here 2017 kjhsgsgwgoippzwbfnkjgwdmhalgqjysteozhlcrvtrlloyb
 * Smoking Wheels....  was here 2017 lsjeyiriugrssdqhzqjbdlrbbaelhzztnreqlpwssseollaf
 * Smoking Wheels....  was here 2017 ksgucjyopvcgwwpgieegsafcwgdzjlmsvpziuqaasojfkpaw
 * Smoking Wheels....  was here 2017 umgdnpegtnnxmbkrbnksaqclcgnvouiqrptdpuevkdspikeg
 * Smoking Wheels....  was here 2017 kmwbhzshrxbqhtbpejvoknxfjxtetkuvgpojlndkrluekkyv
 * Smoking Wheels....  was here 2017 eiwqruevytcpekthvqmclcnwodlldwitdvrpeoamquoqanal
 * Smoking Wheels....  was here 2017 jziehliemeihjnzgqlqxwezztinjecqfappruxexrsexwuka
 * Smoking Wheels....  was here 2017 nplgxribijrkgalfggvuurrmizdxocreyrcrqudvkazfxqhx
 * Smoking Wheels....  was here 2017 ipuronlixyfwozcgtsuwnvdmyxrfeirxcygwgrvprtszipdo
 * Smoking Wheels....  was here 2017 uqenqejcwrkwfudohtplqegkldutficyaniwmigxrefynpst
 * Smoking Wheels....  was here 2017 fqodpcvuaqwxjacrlnmcwjbvzzkgdarblxunirvprwqaerxn
 * Smoking Wheels....  was here 2017 augcibaznbnqlnqjxlbqilzqwyrrqkjfjsmwdzbwjpklhgyb
 * Smoking Wheels....  was here 2017 zmufwaersmnaflsqsfzdjpnatwydqyitbwkfltwaqkepywiz
 * Smoking Wheels....  was here 2017 cjyomgzwguhgncouctkxlipjotyehddcyovecrhtopvgrluy
 * Smoking Wheels....  was here 2017 pltmuefbaylvocrhnenolkfgixnkaykavfiodssxnsnicafa
 * Smoking Wheels....  was here 2017 aumnpnavbgxjviswuywxksuqlxwwpkdpslqlvdrqdoraeaxm
 * Smoking Wheels....  was here 2017 bwqnxhrcvguwywrqwrfapowppmiswxobvfteukbjgexuczgu
 * Smoking Wheels....  was here 2017 tianbtuyxuonwbutzjqfqkhoosqjbbcwqrahuhxsbveigvat
 * Smoking Wheels....  was here 2017 jcrxqigvewuutomuqdkciyecnxqpprnwyhypyspnwbopjpdi
 * Smoking Wheels....  was here 2017 hjvfkubittmjcdmnqkzlsgwewomhdxtasqhfmyszisotjsww
 * Smoking Wheels....  was here 2017 knbhmbqizasenztxxwfjblxxdnpqrbapesbmamcliushlsqu
 * Smoking Wheels....  was here 2017 pgcecloaomxlzlnfskcdzbdrgupdiuucwqpxizvoypaxzmdx
 * Smoking Wheels....  was here 2017 elaewjqugdsprbgaoeykhvscjrlmoyuimwjjmmgfoqontdkf
 * Smoking Wheels....  was here 2017 qhcyopyehhbjatqzerfyatxcusgpbpzgcafxvfyovuujpapz
 * Smoking Wheels....  was here 2017 reughcxeynbrsprfomsvmajteslstdndwbcwwquzoaiwttfs
 * Smoking Wheels....  was here 2017 ivyeibaxxodsryoyaonkfcwnksqgudznidhvkmvbyqctqeye
 * Smoking Wheels....  was here 2017 vdpbfbdrbnyzbktqybwgbuozoatxrmzdgskpotkthffyykuk
 * Smoking Wheels....  was here 2017 sgzmuskflqjcjwycekgdcatbbdzqbgnapjdgprdehndqqtxp
 * Smoking Wheels....  was here 2017 rqqfccdjmmpcgkeirhnfoaaxmwrrwvvkqbocbrvsspmgvxui
 * Smoking Wheels....  was here 2017 sxikmkxguvzdqjpqqpqtbhfvsgmkgujwwzxtvoqzutdpzqei
 * Smoking Wheels....  was here 2017 czchlcnigtfqsjslqnxjknlnxqipsavbzotawgvwvnhnuczq
 * Smoking Wheels....  was here 2017 ibgnvxedznejxheoklwvrtbxjmjdxqecbkvzoazomrigeqml
 * Smoking Wheels....  was here 2017 dohxrwcqirafxeaaxbhhcfpatqzgtyregmfyliakphxfiwbj
 * Smoking Wheels....  was here 2017 mdymidyxxaekqllbjhfziiyiydwkloswdxdmhyzahqyesqnc
 * Smoking Wheels....  was here 2017 ssiqigokqpgkhrwejhwncvembhwgljbwleelftfiyhoazbuq
 * Smoking Wheels....  was here 2017 flrwlxzsprfwisbeomvtmuqhmpeujlrfdxbxmchmezdzalbh
 * Smoking Wheels....  was here 2017 uunbucpsfvdukrzaaowtvixyuweffetfmzvdrjcuwvknclvo
 * Smoking Wheels....  was here 2017 ljpgqbzpawmilxvzyjzurzuvxdnydeuhyruupjrzdcfhpxuf
 * Smoking Wheels....  was here 2017 jcauohyryuwzqbapvdmmvmlowtdsogmhihlpiajwihsggyyf
 * Smoking Wheels....  was here 2017 dezgjmqqdxfkkxjplhwqjufadedkenuepooscpuqcgiqyxlx
 * Smoking Wheels....  was here 2017 kabldpikxtromquaulyjndpjigzhyjxfakeloourizswvjus
 * Smoking Wheels....  was here 2017 ggaldyrawdqqtomdcpsyyanzgagvajixbzoimpkocvsqlfsl
 * Smoking Wheels....  was here 2017 xwxoyymyycudlhxlwvmzkdbnbtxqwjublrhfxuaguhoxjoec
 * Smoking Wheels....  was here 2017 uyykkivtgxzryrvrvptgynnvdzbscnfqgfbfegfvbdqwptjz
 * Smoking Wheels....  was here 2017 tzsumcbkddkgyvewzphxxjnbcodhtevyqmyovovssmoaijtn
 * Smoking Wheels....  was here 2017 tpyupmuzfolbkcdhprdfvewqulutxxcldqgxrkyoypfzxhbo
 * Smoking Wheels....  was here 2017 ztsrfzwwkgtomcgldbptoqsdjaxvbotynclbuuyebzvtcqgb
 * Smoking Wheels....  was here 2017 aohcfgittmflprecjeeibtimeuqmwhtktoiclwiusmtnvtoh
 * Smoking Wheels....  was here 2017 omewpjomrtarmyxghqqctujuvnkwhkhecxyigfatucrtgfkt
 * Smoking Wheels....  was here 2017 peeatmdfvyokbhqeekahdepmghvmnnwraiohynbrkemcvxog
 * Smoking Wheels....  was here 2017 lngxdcwhzamcmgvjlqqozrednjwayndrigrxqtvmwehofyyu
 * Smoking Wheels....  was here 2017 mtucpzxkjismfseqxtyqlgksahqkgmdgyicdrexhxznhiqup
 * Smoking Wheels....  was here 2017 ogfkgcokhjimxvsynlusudxhixnwktaqdmwkngcmhowukqoe
 * Smoking Wheels....  was here 2017 qrjyiqklkyvinwqooodanvmhkffvpzhhlxgfasnsfheswuyi
 * Smoking Wheels....  was here 2017 yygzkdhxodulfmianhhdnbfhhmpzfzrboytlhnmvaqqakfzb
 * Smoking Wheels....  was here 2017 agedihhlwfenlopbdduyvtmgkiuhzxcxniecoxqahkqyxfuq
 * Smoking Wheels....  was here 2017 oapedcuxssbnxdkrkqkmtfwhilgzvbucnynplkurzqvxolxn
 * Smoking Wheels....  was here 2017 owjgctjmskyqnpxeovebvwfuzzqlxbgddacksrzjdrdpwsan
 * Smoking Wheels....  was here 2017 itlqvuumtjkilppbdujhwlojleulrtduaxklltqbearzlecr
 * Smoking Wheels....  was here 2017 hweydxgqyxjidxebvzmyzzixcoxwuhkcgggtxvivsmwfgeie
 * Smoking Wheels....  was here 2017 gobyabatrnzmhrrfrbidkrapoyjzgzjhabqptkvbpcjvlhfo
 * Smoking Wheels....  was here 2017 dnwtvotanaqcugfuxzxftzottjveeljwvlvrrfilydcmnkmp
 * Smoking Wheels....  was here 2017 gsprdufukmaowgihavorurzbsdfdaofqlvkrvgbveedccqbh
 * Smoking Wheels....  was here 2017 cgphtonsldapznrltctkqsqkwurxmjvowxcumrrjwzzxdhey
 * Smoking Wheels....  was here 2017 kpikruaryouetehhclgmnidwucppmhlyioygebalxqfiuagz
 * Smoking Wheels....  was here 2017 dkqdhuivposldohditdfbahykcpreymhizfrtberkjtcoqcg
 * Smoking Wheels....  was here 2017 oomucyfngemwhhgkyfqdbmfdvdqwbcsipolxfsmysuudchpt
 * Smoking Wheels....  was here 2017 egdxxawlaryesevyqgidnsflkswctycddzlzyfmlnrrrhhar
 * Smoking Wheels....  was here 2017 txfjvanlhphhbkzslnygvyxyuqqpguuwfeefmbcmqacdjhuq
 * Smoking Wheels....  was here 2017 gekedevqqtxkggyzpynunqdbuyrtrgidiizgpzjteexgudqh
 * Smoking Wheels....  was here 2017 yautkyqmafmzlkegprjjjozkpyuinfkrfuivkyqdorixexnt
 * Smoking Wheels....  was here 2017 hopolbzomfwsdqjhfdzulruvnefgksymvhbcdemtkgsjnzqe
 * Smoking Wheels....  was here 2017 bfkngngukjfozcndkaddcfdogjishefumsdhlfuanatayyne
 * Smoking Wheels....  was here 2017 hsyrfnbglkztxdwblgxtvrxxpruekeqepgxcbspncgiqxrvl
 * Smoking Wheels....  was here 2017 dwhhwpekljtrciumvymdmscnshlidozjahvgbrhemmocdgna
 * Smoking Wheels....  was here 2017 eyraaksvopmazpchgomfdkdiyvncdmdjqnrwuildhnxrnbve
 * Smoking Wheels....  was here 2017 cirrrzalcpivgzrkutqzbyokyajskfkluwogtfwtjkzsfrfk
 * Smoking Wheels....  was here 2017 yrahgorjteqfvxucqlzuuugfozrqcledxmrzvzrrwksaszkl
 * Smoking Wheels....  was here 2017 ywtffpoaijcqywxyhutffsgiyyioqzfeuupwaqfuebfmrbjj
 * Smoking Wheels....  was here 2017 oeeakvszzmpwzvsqngociqyqlmmksylojmcaqlbgxfyibhhk
 * Smoking Wheels....  was here 2017 pxtnwfnfcbitqweeildllvxhrjnjhrcpyketgvblxwmzzgqb
 * Smoking Wheels....  was here 2017 avjvyanthxrovhnxxhmrduzsmqdynurtzudqrohzhiveyvec
 * Smoking Wheels....  was here 2017 btyfespckagsttfhuzxigfgmbqeuvevvgbmmyqdtlcbvpcun
 * Smoking Wheels....  was here 2017 gyuhjauuoszxwczbtyzetcbnswwwxwovtwajkfdxabodwktq
 * Smoking Wheels....  was here 2017 iulwpynuenadvlthtujjbryyccnkshczrctqpvdvvebpzknw
 * Smoking Wheels....  was here 2017 gxsacrheuhunpdufanfeqkweckwukzwvpyzvifgebukviyvc
 * Smoking Wheels....  was here 2017 hhocoszjjzxpitmicgsfibuvucuulwqcfvfvqiuuakuwpbof
 * Smoking Wheels....  was here 2017 ybhprusazyizleqkrklgfodtoskhmahwnlfqwkjvjvpvtfao
 * Smoking Wheels....  was here 2017 zqllnxtyasdsrmelvqekpfldbaeoludiurappyvrzclgyxqq
 * Smoking Wheels....  was here 2017 jsvqmgtjbbuxxcitswxazkpjcbrzouobmryiorgzyngtqbde
 * Smoking Wheels....  was here 2017 jfjnainqbbxbjonuxixpgyqawdwhfwitjxmqwoyqqrfimulf
 * Smoking Wheels....  was here 2017 lglsawejazkvltmicjtbluybsuxkddjmlzkouvotsgrekkva
 * Smoking Wheels....  was here 2017 jhozmwalljkfwtfkhqfjvecpfvdofyylywtlyyxtakjsqnsc
 * Smoking Wheels....  was here 2017 dzlkunrbvajknzwgtdhyznyzihhfqxmfjsvwcrbfricrpzwe
 * Smoking Wheels....  was here 2017 zgeikiyodayuqyzkzzgitroxcleaxwrnmycqiajccqbzyyeh
 * Smoking Wheels....  was here 2017 lgzifayployeppfqrpqidmhfxwbzqyojgfjwxdlmvdrwqtxs
 * Smoking Wheels....  was here 2017 flmgfoabdhqkdzoxxqganhsbkiggtmhbymswloctuuotvyny
 * Smoking Wheels....  was here 2017 ilicuftbwyitemgnwactjnsvlwkhmcibbviesalpbyqizltt
 * Smoking Wheels....  was here 2017 zergklzzkotqwsrzbymboxhdevmugrldituqumuwbdbptimd
 * Smoking Wheels....  was here 2017 swrgyzumzlttrmqagvwvdlwyxrqssgoitxwjzetskdgrczaj
 * Smoking Wheels....  was here 2017 hwyzlunmyenbhyaslhcbkjahigehvfxwofpqvoemyavcfzuz
 * Smoking Wheels....  was here 2017 qvglfctbwmktpldgvhddxdoqgpwxueyigufaekdwucrnnens
 * Smoking Wheels....  was here 2017 btpzvljpqldhvojfyaiplmpowznhazjjpcijarytjvawrseo
 * Smoking Wheels....  was here 2017 atgfamlukjojkdlinvehdkmzmyjketecpuqttpgfgcekqwyu
 * Smoking Wheels....  was here 2017 hhuyyfhmnuvxajiopklgfdtbtitlfvosmvemwrwrhxwnpihy
 * Smoking Wheels....  was here 2017 wyyfwymupljdpnhgjsdwhdhdndjvivattigeepwurnzyzyzt
 * Smoking Wheels....  was here 2017 ystjiaxenlunhftwixpqddfwxrbiypfzdskoujqlsnqpltxg
 * Smoking Wheels....  was here 2017 ctmyehqfkcbsoikfhihmwcudimautfdkqqkvygstbsgtzejs
 * Smoking Wheels....  was here 2017 alrwlrauqwhrczggetbjtirbkirmqcahmbffgqycpcmtsutp
 * Smoking Wheels....  was here 2017 sndcllqcvpxqvmmggavrifrcyhqwwuhdgefinjlckzgjcmvr
 * Smoking Wheels....  was here 2017 lvvbtailvinbympsaizalowucrvpufrrphvzuioswyrovhna
 * Smoking Wheels....  was here 2017 socgdeeouibowvhlgdaddiqcgzjqdkeaoeyhjuvaqtelvqbv
 * Smoking Wheels....  was here 2017 felnswnfcesehpmlxardssndaasewuzijsmnugelokjohcyr
 * Smoking Wheels....  was here 2017 zgpytjzqhruaddmyfzzjtfkghvmrcxoencuhylpothgoqnvg
 * Smoking Wheels....  was here 2017 hvqvudjfiubqpcrmsdhkaojdesowhqphtrjkuhmipwwkobsp
 * Smoking Wheels....  was here 2017 oywurwtnixirciuvdxbaqtsrzfdqebbrcezxsbkvryrhzzvz
 * Smoking Wheels....  was here 2017 qdtqmonmpmucjxvynzbiwacylcpfppgqunrefggmypirczpx
 * Smoking Wheels....  was here 2017 kzclmmgfukvbgezeahjqhvhkilpcvunqivtueoaylcsgiwtd
 * Smoking Wheels....  was here 2017 flxmfcuduqcbzusyfzfoswkqvobxfoqmkosnozdapzazktgs
 * Smoking Wheels....  was here 2017 mrnkocewrmouaptbumewefvohxcpnyodcjhlttexzboaeaiv
 * Smoking Wheels....  was here 2017 zcjznnuixngezranukzrzachijckqinxoepyhiyanjcwxflb
 * Smoking Wheels....  was here 2017 sjiikofozoslwjupktrhsuafuyuutiyhkdwozmoyhflfygie
 * Smoking Wheels....  was here 2017 yljtusibxombwimvfrnheguawxakitpagspcweiorcuzbfxc
 * Smoking Wheels....  was here 2017 dluumrdkrxnrikvxwncmlkrnwwygzukefnqrgpwahwokelkf
 * Smoking Wheels....  was here 2017 bvciolbmtbygarvxlbdyulgxlozmsspylmzoshatanjxkohx
 * Smoking Wheels....  was here 2017 sgckhhqlswezvmqbddrauwknlatoreqwmuwjczwizjdegkhb
 * Smoking Wheels....  was here 2017 hpuigrsrljwjymswmxagglfbapffiafscwwxkptroyaejcjp
 * Smoking Wheels....  was here 2017 ibmsghlubvyaumvdewqngcainumjiiimfjthykgxibkdrztu
 * Smoking Wheels....  was here 2017 pcqjidbsxunzcqyvgqiwbbjnokyepmeldenuhxfkftzmkswf
 * Smoking Wheels....  was here 2017 bhdjvmfprcakugffycepgweaamheicgcjnnzhutwhipwyblo
 * Smoking Wheels....  was here 2017 zqxaitttetcszyevtmjhqelmbhkazaggpuesybeczhlizflw
 * Smoking Wheels....  was here 2017 vghyosuwnbqrfpmllfmuhapszllqgjcvwqjboxchwlxammck
 * Smoking Wheels....  was here 2017 jpuxqiovdnuebheazxhempeylrugzlbelabitwivvwqjqlwq
 * Smoking Wheels....  was here 2017 piezwvttpazlnkjwpmvtvlamhadimxputbnchqyhzuncvamk
 * Smoking Wheels....  was here 2017 timouseavnwxunpmvejccfgarviocokkpfifgfjqsvtethwr
 * Smoking Wheels....  was here 2017 iuaefsyiwihhgmoqkikbjyelzoownpmaydgtxvczqtstjpgs
 * Smoking Wheels....  was here 2017 bdgqftimeamoqlfiiqurxwkwucgmshzybthzwyarqobivoda
 * Smoking Wheels....  was here 2017 zazbbdzrhiuwvsuuwalhhkurzlzvvglqlesnwifjupropaek
 * Smoking Wheels....  was here 2017 ijgsjhsgdjxrbxtolqtmjijmswtpiknxuxcfbxaznjtlicju
 * Smoking Wheels....  was here 2017 pjjfyzqxvksrsxulwyeaeqnghyquxuetepdcrybqksqdzdyn
 * Smoking Wheels....  was here 2017 mkujuecmtyiwnuxjconcznwbklbolurkucymixcsjqbcttic
 * Smoking Wheels....  was here 2017 beiggdqdmvfkkxgrkkuxkmehwlrjezmkdquzuohwmkvbauhf
 * Smoking Wheels....  was here 2017 npafwgdfxcatoxjvishcfgopvfjymggnzqdldvyycqexnitz
 * Smoking Wheels....  was here 2017 jucumjrkeappjpxpnvnmmujxrhiedszthsvwrzrcxclxeuxp
 * Smoking Wheels....  was here 2017 jfducjpoqddwocxaalhdnjfgzmzhzrxjivvpymittuildtho
 * Smoking Wheels....  was here 2017 nnxjcnmvxgavbumiclojxlxdrvwtfumwpemgtcymtbshxbor
 * Smoking Wheels....  was here 2017 brluzifqwkxwagfafcsuktocvpagixkavchpftxfhkticvsy
 * Smoking Wheels....  was here 2017 luzqonunqxstxisxdseecfmcvjmsycqwbiaupstcyqwuqkxq
 * Smoking Wheels....  was here 2017 mhcsyaqmohpikdzyvaupgehgixtjatlpmsrbllkmpvrcujrf
 * Smoking Wheels....  was here 2017 dwndkdhpiixxlbhlpxolnauxdhkrtlftpnpaosxakfcaxqsn
 * Smoking Wheels....  was here 2017 rkifmhpgtcjvfrawwntgqnctlujiobsdecgnbloptkhktgzm
 * Smoking Wheels....  was here 2017 octnagsbywvxdvxaljyvrqoroyvfdrxsfcmpfwaiedqoeqsk
 * Smoking Wheels....  was here 2017 ojjwayxziemzxqyxhavgyqutdndpkrzuynfponcqqluvkiiv
 * Smoking Wheels....  was here 2017 qwxixrtcmvrikmiurlnwazolbqzynrkvwlvcycxeerrzwfol
 * Smoking Wheels....  was here 2017 cnlgcweuhwcjxynebvfgrjziknfxzmypsivxkptugjlzglki
 * Smoking Wheels....  was here 2017 kmeenhetxprutwgugnneavlhpsbklgmenwycgfgpkgnymhar
 * Smoking Wheels....  was here 2017 ifszdwdvqonosjmsegduiolnfbwsuhhsnxfabmfbolmksjxc
 * Smoking Wheels....  was here 2017 vivrixrddnbxrvkdcxejebyjeoighgvverzfqbtsvehzlpug
 * Smoking Wheels....  was here 2017 dtmqqvpchnxfuunqnrvniaxnnnisiyufgprnaaeoobbsibqf
 * Smoking Wheels....  was here 2017 vszkvjzifxafoenxgyraxmuusnzbonextheanndqkvgsibpf
 * Smoking Wheels....  was here 2017 ooxvanesgdmwqbjaelmadqcihgtlziedxslasbkkfnlnohgt
 * Smoking Wheels....  was here 2017 jzzymoulacuiyuhgpagtrzroewgktxfmfatckjdlcmptmner
 * Smoking Wheels....  was here 2017 nxfcuwqvltmdrztaawivhgrcmpjohfcqlpqcqkqrlfwkuxlw
 * Smoking Wheels....  was here 2017 mmyxshvoqmowhnleekecakjvpaiwihsrpexbsmmfxopqltgs
 * Smoking Wheels....  was here 2017 aerdjsrmxsdpklirchoqerkxcwlpsmhvwqpjgznlhmmyptaq
 * Smoking Wheels....  was here 2017 cpewbkvtxjplaervymosioorxhlcsliovexnzsvatikzrrml
 * Smoking Wheels....  was here 2017 zrllivbtojqwhhxchdlyhtzvcledsznsddlkapuwqqotjsqd
 * Smoking Wheels....  was here 2017 epulytmexcdorqtgwpsedhzfbzvqkgvgwhybqwzapfhlqdry
 * Smoking Wheels....  was here 2017 kutraclujbfnuiejqqekdjdzkruvtommfmlukbfznbhlpoal
 */
package net.yacy.utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import net.yacy.cora.util.ConcurrentLog;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.io.IOUtils;
/**
* Tar archives utilities for YaCy
*/
public class tarTools {
	/**
	 * Convenience method to open a stream on a tar archive file eventually
	 * compressed with gzip.
	 * 
	 * @param tarPath
	 *            .tar or .tar.gz file path
	 * @return an opened input stream
	 * @throws FileNotFoundException
	 *             when the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be opened for
	 *             reading.
	 */
	public static InputStream getInputStream(final String tarPath) throws FileNotFoundException {
		if (tarPath.endsWith(".gz")) {
			FileInputStream fileInStream = null;
			try {
				fileInStream = new FileInputStream(new File(tarPath));
				return new GZIPInputStream(fileInStream);
			} catch (FileNotFoundException e) {
				/*
				 * FileNotFoundException is is a subClass of IOException but the
				 * following behavior does not apply
				 */
				throw e;
			} catch (final IOException e) {
				if(fileInStream != null) {
					try {
						/* release the now useless firstly opened file input stream 
						 * (we can not reuse it as the header has been read by the GZIPInputStream) */
						fileInStream.close();
					} catch (IOException e1) {
						ConcurrentLog.warn("UNTAR", "Could not close input stream on file " + tarPath);
					}
				}
		      
		      
		      
		      
				return new FileInputStream(new File(tarPath));
			}
		}
		return new FileInputStream(new File(tarPath));
	}
	/**
	 * Convenience method to open a stream on a tar archive file eventually
	 * compressed with gzip.
	 * 
	 * @param tarFile
	 *            .tar or .tar.gz file
	 * @return an opened input stream
	 * @throws FileNotFoundException
	 *             when the file does not exist, is a directory rather than a
	 *             regular file, or for some other reason cannot be opened for
	 *             reading.
	 */
	public static InputStream getInputStream(final File tarFile) throws Exception {
		return getInputStream(tarFile.toString());
	}
	/**
	 * Untar for any tar archive, overwrites existing data. Closes the
	 * InputStream once terminated.
	 * 
	 * @param in
	 *            input stream. Must not be null. (use
	 *            {@link #getInputStream(String)} for convenience)
	 * @param untarDir
	 *            destination path. Must not be null.
	 * @throws IOException
	 *             when a read/write error occurred
	 * @throws FileNotFoundException
	 *             when the untarDir does not exists
	 * @throws NullPointerException
	 *             when a parameter is null
	 */
	public static void unTar(final InputStream in, final String untarDir) throws IOException {
		ConcurrentLog.info("UNTAR", "starting");
		if (new File(untarDir).exists()) {
			final TarArchiveInputStream tin = new TarArchiveInputStream(in);
			try {
				TarArchiveEntry tarEntry = tin.getNextTarEntry();
				if (tarEntry == null) {
					throw new IOException("tar archive is empty or corrupted");
				}
				while(tarEntry != null){
					final File destPath = new File(untarDir + File.separator + tarEntry.getName());
					if (!tarEntry.isDirectory()) {
						new File(destPath.getParent()).mkdirs();
						try (
							/* Automatically closed by this try-with-resources statement */
							final FileOutputStream fout = new FileOutputStream(destPath);
						) {
							IOUtils.copyLarge(tin, fout, 0, tarEntry.getSize());
						}
					} else {
						destPath.mkdir();
					}
					tarEntry = tin.getNextTarEntry();
				}
			} finally {
				try {
					tin.close();
				} catch (IOException ignored) {
					ConcurrentLog.warn("UNTAR", "InputStream could not be closed");
				}
			}
		} else {
			ConcurrentLog.warn("UNTAR", "destination " + untarDir + " doesn't exist.");
			/* Still have to close the input stream */
			try {
				in.close();
			} catch (IOException ignored) {
				ConcurrentLog.warn("UNTAR", "InputStream could not be closed");
			}
			throw new FileNotFoundException("Output untar directory not found : " + untarDir);
		}
		ConcurrentLog.info("UNTAR", "finished");
	}
	/**
	 * Untar a tar archive.
	 * @param args 
	 * <ol>
	 * <li>args[0] : source file path</li>
	 * <li>args[1] : destination directory path</li>
	 * </ol>
	 */
	public static void main(final String args[]) {
		try {
			if (args.length == 2) {
				try {
					unTar(getInputStream(args[0]), args[1]);
				} catch (final Exception e) {
					System.out.println(e);
				}
			} else {
				System.out.println("usage: <source> <destination>");
			}
		} finally {
			ConcurrentLog.shutdown();
		}
	}
}
