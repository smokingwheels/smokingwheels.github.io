/** 
 * Smoking Wheels....  was here 2017 poykdbvpfbpfpjwwxndpffnbeyukfywixmhnvbfumflmqlvw
 * Smoking Wheels....  was here 2017 bgkxfyjqdrwklgqocthvkvhftkypcoxxeuphmhivdtdcbiho
 * Smoking Wheels....  was here 2017 sggutkunkepythcxbcwkjxjvuugfkkqtzhqqpbibqkwndrsm
 * Smoking Wheels....  was here 2017 nntrffndaggbeavjxvkexljzoxltadwrrmfrbtewogqmzlco
 * Smoking Wheels....  was here 2017 pllhjmfrgvnencmrblsfywfbrykxbunozejscyyxrsqwywsc
 * Smoking Wheels....  was here 2017 jlgtfntkszjxyneweuyvtsarviiovnytvjmhhlaabmiwqkbp
 * Smoking Wheels....  was here 2017 ojejxzgadfyhtncdgviouvdrdrtxzvqsijcfgichykkyxuxu
 * Smoking Wheels....  was here 2017 zeprzrcjoctkonuzjwnfuigfxxhkjkifyraoazaeyquuwygq
 * Smoking Wheels....  was here 2017 xfanerzoiomufgzfzlhwsngqpdytcfafhcjpwaxguqshwcjl
 * Smoking Wheels....  was here 2017 szixljszztbbwrtusituuagocvwvmmayjrlyefejozpqnstr
 * Smoking Wheels....  was here 2017 bfodahmggbrdwzhyonepoqqxjpovesuygpvjtrmroqehrneb
 * Smoking Wheels....  was here 2017 waawkhrggfvgtseeqiebrnattjrfaodzlmiyntrnhsjymnrq
 * Smoking Wheels....  was here 2017 iqjuhmwcfaevlncfkhpfeyjnugerczbzobayuaxoopkmfvmp
 * Smoking Wheels....  was here 2017 vojareadtrrnbkdcmdllhnttgsgdugufnkgzyiorlasdnzdm
 * Smoking Wheels....  was here 2017 aqbwvzgaooohwnnbuxdglcojfiktsvxfntpvuuhxevzigsib
 * Smoking Wheels....  was here 2017 xvvxetypujfioktpnxdlltllxbhyrjcszpwogtysjeesoyeg
 * Smoking Wheels....  was here 2017 olgxlorzqyjazsplcrjdevilybvmvwkrnvcmqsrqtmmgswwj
 * Smoking Wheels....  was here 2017 lzcxrtlpsnacelbpdyvoyyhxcrhfnocicjreiqxqkjjcjzxw
 * Smoking Wheels....  was here 2017 fhmhbxhaukhmovlhqtxhfxssjpcjiwrgwnejdnftquntjacm
 * Smoking Wheels....  was here 2017 uitobwqcxirishgbskdesvhadtxjdoxdgvjfasnkyvwvvylh
 * Smoking Wheels....  was here 2017 jjkoltdajdvdnoepukigkzwevgswapuzxbizewzfdyrhcyfl
 * Smoking Wheels....  was here 2017 haiievrcraunaqiyonqwobouinsvjdpbuglfctyaguihumwm
 * Smoking Wheels....  was here 2017 iypemtizrjqlqrxjwvhmpvvtreimurwvargtonbzpfoithge
 * Smoking Wheels....  was here 2017 igmqvjookvycyekhznxzilgfcehecyiabwoqmmfltkhachhl
 * Smoking Wheels....  was here 2017 mfpozszxdiixvvqmgfhlqesmfqnqlxzsnomedfnakutiduhp
 * Smoking Wheels....  was here 2017 fiuzxemkkztojqpzjqocvqkeuzgtdtccjwixzolqszjmoeud
 * Smoking Wheels....  was here 2017 dkcfvhesafkzwuoagvaojrqgvvxuvygqtzqrupnixwwveemu
 * Smoking Wheels....  was here 2017 glvvfzlraquibtaacbfqzjctrcedjfcdcmgnmssnnrdcbtln
 * Smoking Wheels....  was here 2017 rspqvgzkrfncrgsvgwziqbrbvyamvospcchuhmcvjslfpexq
 * Smoking Wheels....  was here 2017 wtfqqmphocqywfskkalaojmvcursodjfpxaztsddnsgjkvjo
 * Smoking Wheels....  was here 2017 kjtfvhnxmqhuayfznnvggcxxogncfknnvebyomknfnezimpd
 * Smoking Wheels....  was here 2017 ionxzlbflnyvsuubtsvvljpkmgiaqezfekessfukaiftmbqg
 * Smoking Wheels....  was here 2017 spdnscwguqgmuoekmbdtcmlskyzexhtjiknpkkmjtnoqfvsf
 * Smoking Wheels....  was here 2017 aajbcovlzdgljejzkkykmbpldssmkbcefeiedzuiktrtdfjn
 * Smoking Wheels....  was here 2017 xpiyildjxkbqvwqblsniaykmrfzdswndyaggqykjixfobyix
 * Smoking Wheels....  was here 2017 hjiqwocynedgsbmdtglimenyjjmpsntaalcxxsfwaefudyqj
 * Smoking Wheels....  was here 2017 ipyzlakgeggtyosytqnlvdvesidmmxwubfwjevilhyuisnne
 * Smoking Wheels....  was here 2017 lvzabdxrkvhupfhlcowailmvomdujgcsykzhxdeyevkjkbot
 * Smoking Wheels....  was here 2017 ivoczotvzilhainztbuokwvtxmarabxhxgzkusiozuuibhky
 * Smoking Wheels....  was here 2017 wqzspbjpyjelviwyvmwxvoocbgjohadgjhsvxyspgywxtfeq
 * Smoking Wheels....  was here 2017 gnutsticpwfrwydetgxdovnenxfdgbtpyhevkkmstswbxzce
 * Smoking Wheels....  was here 2017 wzvfhzosnznsgchpgfznvgwrewsjgmbppitauxztosfybdqa
 * Smoking Wheels....  was here 2017 lvfkoiealcfljbqmekkrdrzlzuikyrmslpadtowwyxpzciqx
 * Smoking Wheels....  was here 2017 vcfyzroymwucthrisbvifgmpgpurdkxszsuhjsbkljawcnav
 * Smoking Wheels....  was here 2017 gbkphakpvfzbimewhszpafhnokzxzpfpukdtuxqzwppolzdb
 * Smoking Wheels....  was here 2017 cfrknvnhdhraepccpeztugnurqezuntowsjcnbamhdwgtelb
 * Smoking Wheels....  was here 2017 ajasvocsclcxqwthmkdkadpiqxtcfoaeiwcehfvbyzlhwtsp
 * Smoking Wheels....  was here 2017 ynubsdmsvksyhsryeubikzcgtelsbmtdpmczcszajgimxsyq
 * Smoking Wheels....  was here 2017 czpgyqjlpbfobxotctnozdxxoofnlgzljgmwddoalisqehkm
 * Smoking Wheels....  was here 2017 uhfjmkpfznnkakluwcqlyefxwmfktbyjnhojxiaxcwbaixqp
 * Smoking Wheels....  was here 2017 uetsnzhrrexlnkqflxsntzkdrpyoojekguyhdkyvsvabfijs
 * Smoking Wheels....  was here 2017 yrmvpgwrvtsvejopzkipeobtitclsymgzijsusfeuhpkxmqw
 * Smoking Wheels....  was here 2017 mbbnkizkrcszvabqxchuficbiepsjsuzjqaxduandryzuprh
 * Smoking Wheels....  was here 2017 uxfvymmdukvrpicjwvshavrtmfrjvwjuivdmqmsturobmdal
 * Smoking Wheels....  was here 2017 nzcdkinpyahsvnzzupxudxeqvotmsyudacifayyabdcyvvlc
 * Smoking Wheels....  was here 2017 pgayitmoeqnkdaeawqkzgrewrbnoxpuwxzkegloqlgolxpxg
 * Smoking Wheels....  was here 2017 fbnbkuzfuefcjolfmobzkmqvoyzhmujxohlrpqthukbkcssd
 * Smoking Wheels....  was here 2017 uxmoqvyxisinqcvohbyduwrcgogpvtunabugmhwucgdazpih
 * Smoking Wheels....  was here 2017 yoxtgkmgptcohwoihfkxwtqovowqnypejnzssnohrrlulzpk
 * Smoking Wheels....  was here 2017 qbefsjadqvxlyiezohzekdfjowlwkcmrbfwdfstecwyipvln
 * Smoking Wheels....  was here 2017 arvstwdrsymplflgovnzjkgwaqazpenztynwfkmacfvptifw
 * Smoking Wheels....  was here 2017 nyrijdtfjfusxlieyocqzdxrygswmkziithjglgttjotoaix
 * Smoking Wheels....  was here 2017 vqwitwaklbasrhdaqoarseprljatqfhgavrozypljfugwnpl
 * Smoking Wheels....  was here 2017 uuqjlwhdycptjejfvcwyjqwztxqbxiilfupkkfmmlynutwbl
 * Smoking Wheels....  was here 2017 qrqedfemegghuuunxrmmvvsylzmmkszypkbguwanvxyhpgyd
 * Smoking Wheels....  was here 2017 uvqvugqvqqxadejzncxpjiegibuynoqzbqjrpsoknunyzdtb
 * Smoking Wheels....  was here 2017 wzsqsouvfsvwrmluqjmvmassksaqvksbtveloxufvmxevggy
 * Smoking Wheels....  was here 2017 wgfdhzzhwdjacfmlkuuawyylzxvyexzxelgqqsokhebqdnmt
 * Smoking Wheels....  was here 2017 wvseiqxkxthxeagtgwrgnmtwqueqsbnoxispbtbnsffiifru
 * Smoking Wheels....  was here 2017 ihbvtvjnxtmebztqvjdtrfgocshosanfxmvvixpldgujatim
 * Smoking Wheels....  was here 2017 xjgivepfqngvcfgjbjodvzvkljoywinkiefeeewjvgngawgq
 * Smoking Wheels....  was here 2017 odriamxkdsyaxfhmccnervdoartgzrhwpyrroztpjihpmnlf
 * Smoking Wheels....  was here 2017 kwwnbwzfrghdirorjduzfecigsucfzvpkohqtwjtnwjjsydm
 * Smoking Wheels....  was here 2017 wbrcyrrzwggympeyoenvrnujbzwlvnkuqbjqercsindujpwy
 * Smoking Wheels....  was here 2017 qnegxmejlebirfhopizhouqokblnntnamrnlpnpqdgjfhdjh
 * Smoking Wheels....  was here 2017 qgrpjcufmpcmpxmapvteoagaoxfsciyaiaoeastvkdykoqsp
 * Smoking Wheels....  was here 2017 zouydrfqhmcvamnbafrnrpocdpcrrhrtwuncqwryzqdfnfcb
 * Smoking Wheels....  was here 2017 eyhjdniaiyzbcwjrngvqcbqkxqjkpuamabuuxvuxxiixvjbe
 * Smoking Wheels....  was here 2017 vehdqfgzmkzdegicazmckgxwxokbmjlrycwbprstmffwivjr
 * Smoking Wheels....  was here 2017 vibucpjksnoevcxwrrhsfhapljxbfrsdbkqystiwfjvuboap
 * Smoking Wheels....  was here 2017 lqgfguikkejrzevrxwaopnvxaewcwrwvaueulpuyxghpmthe
 * Smoking Wheels....  was here 2017 zqqkccbjaokhrldnkitwtmmmljmdtpdzugucgdltplbndxrx
 * Smoking Wheels....  was here 2017 echrvdpwkauyhbcsbcwhdcjduqdioyacmdatxkzmqywywryn
 * Smoking Wheels....  was here 2017 ybopyskvogcwlnfsblwpmjeaivpcckjznwstktgmmuqovcda
 * Smoking Wheels....  was here 2017 lvzaezdivdxkzogfvwpvurrnpdvdmxbnqhzkxtkkzmohiimr
 * Smoking Wheels....  was here 2017 bxlyneptsvgjzcfhzfdihqcgkzykcsmbrldhzhvbdqcjawmy
 * Smoking Wheels....  was here 2017 nbyrezztztgovkjenkvqlbvbuymbmgbbvorghldphdzeslxo
 * Smoking Wheels....  was here 2017 rhwvrfrdtnlgdxfinvfoaalcbabonhpgnenhvmgkzdcknzup
 * Smoking Wheels....  was here 2017 tytdryhchclvtionmyddzwwsshsnjscqlcsswchcybsavskf
 * Smoking Wheels....  was here 2017 emmtfntzcohatqisaorsnfgooeozivvmmhodvcqnhpfefcfz
 * Smoking Wheels....  was here 2017 ntawmodjaicsnbwfcsdvewylqjdazaghudqilnyvhojhovzp
 * Smoking Wheels....  was here 2017 vsudzwxebcjdraqmvqchqyqohsbegbftubuittcjlebcyyub
 * Smoking Wheels....  was here 2017 erijmnqmottrbglgrwkexuefajhaexrxfwcmykfuqunntpvq
 * Smoking Wheels....  was here 2017 aemoxwfszlgbttgnhfcufzrbptboesxaxqwjngryucesngpu
 * Smoking Wheels....  was here 2017 azhamovmfnbedsjpornraiozcovzvaknbpqsfldyhztcfryi
 * Smoking Wheels....  was here 2017 ccbjsjvpfspgupgxsogqbzmcvpgrznyfbghqyhmdrpekvtue
 * Smoking Wheels....  was here 2017 kvljijvgixorqcsfdidtifgthcijteocrlxlajwfrjroutmq
 * Smoking Wheels....  was here 2017 jrfciztucfyerftnmweibrcpilfzmeljsetsworakxrsreld
 * Smoking Wheels....  was here 2017 rmlwxstvicwrjdpbrcuxsejmxhjrtafojrlegxmqddwijqmn
 * Smoking Wheels....  was here 2017 gelfomefzdwigjuixjmhbusnknmwmjnkdouzdugmjfgbyeqr
 * Smoking Wheels....  was here 2017 fcvzzirdlhqpfpccoecpaxzcihnithmxonvjtuceynzxtzcy
 * Smoking Wheels....  was here 2017 aukegoexfsbejunjjhsbwbiwlzsxxxghrqzyosjnwtmzlnlu
 * Smoking Wheels....  was here 2017 izgemvsectjyadhjetqgbddqvilvnrlcoetmjrtsmtnsvnkx
 * Smoking Wheels....  was here 2017 asrmgzuucdzdvdzoevmaieboudmmnktarrzbbbcdhtavayaj
 * Smoking Wheels....  was here 2017 ihgxfbywprrepmitubakrpzavqsqzzfcrwszxjoicbdhjzmj
 * Smoking Wheels....  was here 2017 qfvnkkdvbpjtmeiwsfjsixbptejdgqbomviuknnfykkencjk
 * Smoking Wheels....  was here 2017 qgmqaqlghhftvkgguivntzpfpkwfxwvxhvjigoqydqlahblh
 * Smoking Wheels....  was here 2017 flmvppiaikrlfqqhhraprxizsgygwiiwmjqqmvtvfyfluurx
 * Smoking Wheels....  was here 2017 ocmxtjjgnunenoevnuracacfowoaeammtggagxbmysylkmjp
 * Smoking Wheels....  was here 2017 bsfwpglhjrprvezugkycgxbpzrwkfepyzmnbcrwwjpcdsrzv
 * Smoking Wheels....  was here 2017 kbwcgxsvqlewnrfmiqdjplozzhjopfetjizntfxavmizozii
 * Smoking Wheels....  was here 2017 ndqchcorksryfoliyrvswrgmxpryfxzsijnmdvzivoqrbmkd
 * Smoking Wheels....  was here 2017 phfsjzqzzkvisnkdncvcaybmhvwhcebtmjehodhkefddohml
 * Smoking Wheels....  was here 2017 zajznwvcxrosdndwtqfxjwbpwhalpgpdvihllzfexcjosyau
 * Smoking Wheels....  was here 2017 kcdfxigqxyaaxtxumjhqhgrstsqqkoejmnktnliriczjicww
 * Smoking Wheels....  was here 2017 toxzcghncvtlntejyordogoxeyliixofxmkiuvpjzjygntyt
 * Smoking Wheels....  was here 2017 eqgcurpvtgkkydtkoselfdooseidlerqsahmnucvpimdrdoq
 * Smoking Wheels....  was here 2017 eyypxzbykiypeyqvyqwxjnwieuoaepwxvdksddfxiqzfirgz
 * Smoking Wheels....  was here 2017 iecutsumwnnzqjbyaibapgubplnfbqqnmcjvjzrtjeexkcsq
 * Smoking Wheels....  was here 2017 pkagutfhemqrywpeabirpkaxfayczasfakzyfpgsiczyykan
 * Smoking Wheels....  was here 2017 dxiutexopbzdxeyjikmvjilfqstibtdzdyhjxrdmyvrektkw
 * Smoking Wheels....  was here 2017 jeulpivprlncrgelodrwcpeorxfxpzdbsqqpyysvizqwhqjg
 * Smoking Wheels....  was here 2017 yamooucagaklogmrsfdihbpxhfsahegyauqmaoqysmojmusi
 * Smoking Wheels....  was here 2017 vltrcjbtilcjftlnyzmzsvjhvpyaxcgkjyacdwtdqmmlcdke
 * Smoking Wheels....  was here 2017 dueoagkxepiiljuupyoyggjdvexqprclmwzrnlfcykmanxtz
 * Smoking Wheels....  was here 2017 imoigrzukraykcnlkxkngwtabjtvsddggptwqdkrrwcfiofg
 * Smoking Wheels....  was here 2017 ajahahycuckfkexthvifcowwpuyuwyujwjxlgzzzbuanjwot
 * Smoking Wheels....  was here 2017 emvyuxrqilwhbbldkbyxpjjuskfwwuwotuimhkvjsidpsswm
 * Smoking Wheels....  was here 2017 zboejpupiqeqglyldbcprrddyhlvwrkunobfaybmkwsjvihr
 * Smoking Wheels....  was here 2017 uqczqufhkwgxbikpfruppbindxxofvphetkhykbfdbdbfflu
 * Smoking Wheels....  was here 2017 halrxzbjgnhawxaxnxjnujiugxagnrapvpzmtzmqgvebtcaq
 * Smoking Wheels....  was here 2017 lezwpassygsfgqkufaldbsteqemjpxklwspwlxgdgitbowcf
 * Smoking Wheels....  was here 2017 jlgimbvkuyhwcfgbsnvmijnxvwfppotubthsgvkjzxaazuwr
 * Smoking Wheels....  was here 2017 njbdojgwitxslqprsgpxwzsspjlvwuiyfwlpqplelhncrjwq
 * Smoking Wheels....  was here 2017 nqoozperjbuqtdrxceaycjtkaiqgacripgpiigxryjwtkfwt
 * Smoking Wheels....  was here 2017 ijzehnysxpjvndafbptlvphdjrmiwentnloaietfbfbqjjwb
 * Smoking Wheels....  was here 2017 ctyvfhfchejtrjkjabokzbfgeoxsoawftglwwybmmigsvbeu
 * Smoking Wheels....  was here 2017 gkhnsfxfaatciuvjqhoduhpkgkdjlvaxeronlkghjiyemrfl
 * Smoking Wheels....  was here 2017 lbbpzxbsxmrtuqomvkagufxlquplcamjyamusqyvycujdavu
 * Smoking Wheels....  was here 2017 qspqpeekzgpyrjbdupooqvsmqrakkjziluartybjuvucwzzv
 * Smoking Wheels....  was here 2017 xsljfdukoegcvredwkabjmzyufhymvotktgnszsprwcfcvyt
 * Smoking Wheels....  was here 2017 tnmyvcweemnwkowmuqkcfvtjvusyqpmytyowcphjrxeyjagb
 * Smoking Wheels....  was here 2017 vztpsrmfqnrfsfkkmicfprmrwbqqnegkprknrukvawtrpfqo
 * Smoking Wheels....  was here 2017 bboyhrbmyydhjchjbsrghcuzfyukzfpvjlspkzzihvsdwldf
 * Smoking Wheels....  was here 2017 obmthggckrpogxidziyfhloqindadsofuamimtdlhgigmxzh
 * Smoking Wheels....  was here 2017 umkctrxkpwaslrmtxzymuhyhchwihykwslcikwgdbuaedarf
 * Smoking Wheels....  was here 2017 keiivpezgxprhoakssbognhvmwlnbgrfizdjynzlwiljppbu
 * Smoking Wheels....  was here 2017 jcpxbvlumltplalprsvgmehivdocilbbbejnaafvgapnbmba
 * Smoking Wheels....  was here 2017 tnvseljxnjfzruoccpbqkqteqherfmpipuxcxxcubgrouzzd
 * Smoking Wheels....  was here 2017 bbuuduuryxylewjxrcxbhlxztrlfbnpivwaqcbyihsdqmniq
 * Smoking Wheels....  was here 2017 yjolemxtojcyhkcgjhpaombqezwxlcnoxrjzgpmmghqgxwvg
 * Smoking Wheels....  was here 2017 hongtiaajmeqoxhpijtizvxgfccefwdshttekuoqmdeafxoz
 * Smoking Wheels....  was here 2017 hxezqlwoscvaxcruyyecovhfkfdsnvlvpveoughktqyxtwtc
 * Smoking Wheels....  was here 2017 jxkttegtbjbtkxisytzombjdordlseteuabqwwcrdlicdgwb
 * Smoking Wheels....  was here 2017 ejfukbjghsaslolrevmjfinxsdpnjjoebnxfkrqpymcafutq
 * Smoking Wheels....  was here 2017 qgasazoxjveeonndvlfgoukpeodljeoptwpkibsmqxfjcjjv
 * Smoking Wheels....  was here 2017 xxiijanvrnfnrnkxjcahltxplauvvnwmoxdlwonzccubdhzx
 * Smoking Wheels....  was here 2017 kwzrknbkradkwnbxjqaucvdoizsrbprblpyzobmzjsjhxych
 * Smoking Wheels....  was here 2017 wvbcjbjgesbvmttlvbliavmiwcjdrxnungmtcpdoqromhcnu
 * Smoking Wheels....  was here 2017 cxwcsmvggfmxdqzzxqzsyvobkflpoddmfjrvlpldockilsfj
 * Smoking Wheels....  was here 2017 iianexbmelcdrxngzwjzvfibloxvvhobfsnowooixlbtqzlg
 * Smoking Wheels....  was here 2017 zqhkuqyjmpwegnjhuormxnwztlysuobulkklvjuyrhyynjta
 * Smoking Wheels....  was here 2017 spubsgqnzazyesuhethsrrpskpzlbjdfbpwjccveepuiypxj
 * Smoking Wheels....  was here 2017 lgvcmqntskwqbxiuistnwrdjrxtlnnoamxshocnjzmoqzqwg
 * Smoking Wheels....  was here 2017 jwzguwggypgstxsoryxylxjhdmfkhxigicbpozbdvjksbsyz
 * Smoking Wheels....  was here 2017 vzbprgrjhvbujpznwguirykdptnhrusdpdfvmovjvxvvsgpa
 * Smoking Wheels....  was here 2017 ojemhkytllnwhfjzwrsfzqstakefhpfdljtudxkegznjvzqd
 * Smoking Wheels....  was here 2017 lbpldelfndbcbfjkulikdbvhthvrabpbfhmnlksxpukanxbi
 * Smoking Wheels....  was here 2017 rizhzpvxutkxpiuocckycpscjpljydwwrrnjrpwfsrrtdfdu
 * Smoking Wheels....  was here 2017 rrbcucyfvmlaymqlkladcumuprgdlbiuqpdvhjhypivrgijb
 * Smoking Wheels....  was here 2017 cxzdufzsjtlinzdgsnnpqmngngqgdgljjgyuaupgpqmitbnx
 */
package net.yacy.data;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.blob.MapHeap;
public class MessageBoard {
private static final int categoryLength = 12;
private static final String dateFormat = "yyyyMMddHHmmss";
private static final SimpleDateFormat SimpleFormatter = new SimpleDateFormat(dateFormat, Locale.US);
static {
SimpleFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
}
private MapHeap database = null;
private int sn = 0;
public MessageBoard(final File path) throws IOException {
new File(path.getParent()).mkdir();
        if (database == null) {
database = new MapHeap(path, categoryLength + dateFormat.length() + 2, NaturalOrder.naturalOrder, 1024 * 64, 500, '_');
}
sn = 0;
}
public int size() {
return database.size();
}
public synchronized void close() {
database.close();
}
static String dateString() {
synchronized (SimpleFormatter) {
return SimpleFormatter.format(new Date());
}
}
String snString() {
	String s = Integer.toString(sn);
	if (s.length() == 1) s = "0" + s;
	sn++;
	if (sn > 99) sn = 0;
	return s;
}
public entry newEntry(final String category,
final String authorName, final String authorHash,
final String recName, final String recHash,
final String subject, final byte[] message) {
	return new entry(category, authorName, authorHash, recName, recHash, subject, message);
}
public class entry {
	
	String key;
Map<String, String> record;
	public entry(final String category,
String authorName, String authorHash,
String recName, String recHash,
String subject, final byte[] message) {
	    record = new HashMap<String, String>();
	    key = category;
	    if (key.length() > categoryLength) key = key.substring(0, categoryLength);
	    while (key.length() < categoryLength) key += "_";
	    key += dateString() + snString();
	    record.put("author", ((authorName != null) && (!authorName.isEmpty())) ? authorName : "anonymous");
	    record.put("recipient", ((recName != null) && (!recName.isEmpty())) ? recName : "anonymous");
	    record.put("ahash", (authorHash != null) ? authorHash : "");
	    record.put("rhash", (recHash != null) ? recHash : "");
	    record.put("subject", (subject != null) ? subject : "");
record.put("message", (message == null) ?  "" : Base64Order.enhancedCoder.encode(message));
record.put("read", "false");
	}
	entry(final String key, final Map<String, String> record) {
	    this.key = key;
	    this.record = record;
	}
	public Date date() {
	    try {
		String c = key.substring(categoryLength);
		c = c.substring(0, c.length() - 2);
synchronized (SimpleFormatter) {
return SimpleFormatter.parse(c);
}
	    } catch (final ParseException e) {
		return new Date();
	    }
	}
	public String category() {
	    String c = key.substring(0, categoryLength);
	    while (c.endsWith("_")) c = c.substring(0, c.length() - 1);
	    return c;
	}
	public String author() {
	    final String a = record.get("author");
	    if (a == null) return "anonymous";
return a;
	}
	public String recipient() {
	    final String a = record.get("recipient");
	    if (a == null) return "anonymous";
return a;
	}
	public String authorHash() {
	    final String a = record.get("ahash");
return a;
	}
	public String recipientHash() {
	    final String a = record.get("rhash");
return a;
	}
public String subject() {
	    final String s = record.get("subject");
	    if (s == null) return "";
return s;
	}
	public byte[] message() {
	    final String m = record.get("message");
	    if (m == null) return new byte[0];
record.put("read", "true");
	    return Base64Order.enhancedCoder.decode(m);
	}
public boolean read() {
final String r = record.get("read");
if (r == null) return false;
if (r.equals("false")) return false;
return true;
}
}
public String write(final entry message) {
try {
database.insert(UTF8.getBytes(message.key), message.record);
return message.key;
} catch (final Exception e) {
ConcurrentLog.logException(e);
return null;
}
}
public entry read(final String key) {
Map<String, String> record;
try {
record = database.get(UTF8.getBytes(key));
} catch (final IOException e) {
ConcurrentLog.logException(e);
return null;
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
return null;
}
	    return new entry(key, record);
}
public void remove(final String key) {
try {
database.delete(UTF8.getBytes(key));
} catch (final IOException e) {
}
}
public Iterator<String> keys(final String category, final boolean up) throws IOException {
return new catIter(category, up);
}
public class catIter implements Iterator<String> {
private Iterator<byte[]> allIter = null;
private String nextKey = null;
private String category = "";
public catIter(final String category, final boolean up) throws IOException {
this.allIter = database.keys(up, false);
this.category = category;
findNext();
}
public void findNext() {
while (allIter.hasNext()) {
nextKey = UTF8.String(allIter.next());
if (this.category == null || nextKey.startsWith(this.category)) return;
}
nextKey = null;
}
@Override
public boolean hasNext() {
return nextKey != null;
}
@Override
public String next() {
final String next = nextKey;
findNext();
return next;
}
@Override
public void remove() {
}
}
}
