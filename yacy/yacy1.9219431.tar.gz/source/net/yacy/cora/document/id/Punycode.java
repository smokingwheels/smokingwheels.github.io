/** 
 * Smoking Wheels....  was here 2017 smlccvvrcbbocvqwhcncwnvecupgafbfwwvalmrswcehqpbb
 * Smoking Wheels....  was here 2017 lixjqfhoowdtebgixkayxngqbnwqtscudkuaudcdfefaxaqs
 * Smoking Wheels....  was here 2017 pshnepedkojtpgqsdnspywsigoexlodxngkylshmvdjxbmru
 * Smoking Wheels....  was here 2017 ajjhcoimpnpyxlurdkobriemvmpqxeimiqycggpigxbveqnk
 * Smoking Wheels....  was here 2017 vfercwuyjhzywdxffhvnzybsjcorfeerfaxzmaqldmxwmkza
 * Smoking Wheels....  was here 2017 jowxbnxzfsypoyklaqcobaxvnnsfpnjzzdchmoexohtkoyyh
 * Smoking Wheels....  was here 2017 gtcoevgnvycaguzwidawhanwicxoriuauymbxphbrwvcfrqf
 * Smoking Wheels....  was here 2017 hqnhwhqnffhqmuqciuslkuacakhkfztuzqinsgjkzblumfly
 * Smoking Wheels....  was here 2017 rbecurejpfsabinciukogireahgnfepkdreecsxtgygpqlex
 * Smoking Wheels....  was here 2017 rhihwbdomsscadcbzporaxcvbvldauciduttkntfkxdwfprt
 * Smoking Wheels....  was here 2017 zunjgrcyovyxrbckbyzpebcdfjsoezegbzchinzbsmghbzfm
 * Smoking Wheels....  was here 2017 jhmzkbyovxhwogkwturghotlpngklebchklavryvqoareiff
 * Smoking Wheels....  was here 2017 zsgfyastnoxqkdhhjiyxkkjgtckowzdbknikahekxfzevmil
 * Smoking Wheels....  was here 2017 eibhuosacoeajjdxnafcoyokkfvetidphcnfjwntntcdpqpu
 * Smoking Wheels....  was here 2017 ookreynfibsdqvrebqhnhqdyoekoqjaiacalmecgrvmfheeg
 * Smoking Wheels....  was here 2017 ydcelszjejklvrwsccffeidejpgkimzgzrbjiidkxfogytmz
 * Smoking Wheels....  was here 2017 nadshqdvwcklsixnaqfjeyyskhtnvilmtjekamgcwbwjvghj
 * Smoking Wheels....  was here 2017 oktpqtjcwbcchkgskrunlwbhikpbmvdnfvejbghipqkymwme
 * Smoking Wheels....  was here 2017 sumhqifbxjcnxvovczskkokzdfqkvdaalbzgbjikipgqsygi
 * Smoking Wheels....  was here 2017 vwbotxmraiiactulfnabtvydcizdqqhxvgxhyxrxntugpfdy
 * Smoking Wheels....  was here 2017 aqojpggijoxhqpenclzqischqqceyzijyxmywcwpxeryjmsn
 * Smoking Wheels....  was here 2017 pgezcjwpmxfdpzdhjhbtkljgndnpabywrskzhmuqlgubpzar
 * Smoking Wheels....  was here 2017 fflxlpxfbmxtfvkdxtaahoqbtgfumczbcqtlvvmfloghbcgl
 * Smoking Wheels....  was here 2017 sgdxblegcowlchxttuxotwxbmngkckswpwtnlfhzhxmlvlux
 * Smoking Wheels....  was here 2017 figxpqubvtfwasvcipznqkpuhvcgwromtxxthvustkcqezko
 * Smoking Wheels....  was here 2017 bqcfygzetxiwzwqhfqslekfavfimdufjkmavuhtlukzgrvab
 * Smoking Wheels....  was here 2017 vqciinlkndwpioawfrycskoxcbwmkyqesnbuoiinslhybjwi
 * Smoking Wheels....  was here 2017 kbcydaxvftskpyyknqplzfurixvwmnawagiwpyumxlknlgip
 * Smoking Wheels....  was here 2017 xwbcanltzjzxompxltztvuexaqpnlevpwehoamsddlyebldg
 * Smoking Wheels....  was here 2017 qhgbyamrjudaguloplpmnmikxiunnttueytqgkynktugmbfz
 * Smoking Wheels....  was here 2017 guegavmmbcsvztdtvmfkjvafyijghnsebnsbzoozxacimmvt
 * Smoking Wheels....  was here 2017 paqmsmiebsqrhoregvvmdnisjfjjotzqvekbdxwcdcgidjjt
 * Smoking Wheels....  was here 2017 uaqsrsbcodbfapgugrsarrqjqvgrifxkcjjevtlpvaxjsqoj
 * Smoking Wheels....  was here 2017 dzkfvoaucgjicmhujmjmemmbnhrjyshwtujdnqcqzdxutljh
 * Smoking Wheels....  was here 2017 hjllihucjefdyfnomzpqborvawluxmatvjjywiylublfcfym
 * Smoking Wheels....  was here 2017 cxofomfajekzavwvsdilzqhyhfsoawhzuksvuvhptqvosnud
 * Smoking Wheels....  was here 2017 qntlhwixiwenduomkdxexsrawexojnpsdhwhmlsxpxuxxinq
 * Smoking Wheels....  was here 2017 hmhlinlhsdvpitztfmvhydkvmurwekpkvuochrzmigdqhufs
 * Smoking Wheels....  was here 2017 rfqrxqeagacjxqxaxwvpnjhkckvxapgswvwgzigodhajphyh
 * Smoking Wheels....  was here 2017 plpxlvidywtdlngbqgyaigkdyrohrotprqayjlvsnuwywmfn
 * Smoking Wheels....  was here 2017 fcecovzxahaorwfstxkwgtbnmjgwfxogurnsrgguewholgtv
 * Smoking Wheels....  was here 2017 wmqngrlyydgorigewfsqmewknpotyojberdhihjvdxenuumz
 * Smoking Wheels....  was here 2017 dzmrpqiamlcesubyvxramaquysiijretvpxrzjgdqlrmumov
 * Smoking Wheels....  was here 2017 xjnhbgkgoplvikoqtaiavclaahsggqcgerbdomfgcidhkznp
 * Smoking Wheels....  was here 2017 gorkihuwkekcjoafzrvymlorgeciscptuhcdfyvziqfczezs
 * Smoking Wheels....  was here 2017 ougfhuvmozkxvyvvdkufqiqnimcszzlqogvlkgylgtufagyv
 * Smoking Wheels....  was here 2017 lnufcaawseajalrzbwxqrglqgnqvrknqnmgasepxcgbijooy
 * Smoking Wheels....  was here 2017 slaefnfcwbfvmfohwcgehacjhwvemvbscfoeetexjzihauje
 * Smoking Wheels....  was here 2017 noychaongfbxaqrtxgacjqxfvkctovmzwxjivhehtzgfivyz
 * Smoking Wheels....  was here 2017 ecwffqgqhmzmqjlmtuuwdjlzseapcjnxsgjhfhmbiqtmtvib
 * Smoking Wheels....  was here 2017 imgaeozhuzprqipyimggxunuvoocsobdrfqaxnepfoysdfsi
 * Smoking Wheels....  was here 2017 ulxgpinmravwpravrgmflrfxmdtwewkrebiuwzmlynftnqnz
 * Smoking Wheels....  was here 2017 syuyeuypgftrhuzcfisbqawwbscvmwxrufbbhacjgqftfyll
 * Smoking Wheels....  was here 2017 lffhuxoexjuyuixwmelgrcankldbamiokjopnduldhubsjlj
 * Smoking Wheels....  was here 2017 orrvpyzzkpowifmpjnmnxlnxkpuygxoaboukhcpauadivgst
 * Smoking Wheels....  was here 2017 ycxhanadtfzsmorzyhuxbwljivfbznwzexctmyxprrpjqgtt
 * Smoking Wheels....  was here 2017 rkyruhtxeweeauryqsqqbidkrxtjhyrpizybhxhapjvjjieu
 * Smoking Wheels....  was here 2017 cwbfsjmwdjndapxsahoeaedwdacxlcqjjkcddonjlkrrqozo
 * Smoking Wheels....  was here 2017 wwslbauujtrqtudqxrhhlxhvskcbzetzkfoyqsswnkixekjz
 * Smoking Wheels....  was here 2017 vetbftnuvlnduqgmlxwaxhqnqsxmsnfhvoputieehfeyblug
 * Smoking Wheels....  was here 2017 bsdbvisduzdfxlmdadnnjjnpktxbsvmneztcqrnalxvwprxu
 * Smoking Wheels....  was here 2017 yuctvvtksfasdxgudvvjzkousqsweyfdjcsqsinnaudchesi
 * Smoking Wheels....  was here 2017 btfojmdkjgruuxhwttmhfymfosggtckumzpkrbgyfnigykkt
 * Smoking Wheels....  was here 2017 gjfgxvseqkcvjpnbxwngrtlddnqxdqfkwtprjxbvnwseqykg
 * Smoking Wheels....  was here 2017 rqdwbqpbwhklskeiaienhwtezygrlgcedyfwbcnbqzyzptkg
 * Smoking Wheels....  was here 2017 rsepuycplsxmvzrvqqapgozbvctrzuundfgvcelrpeyclzkl
 * Smoking Wheels....  was here 2017 ucxygbtpduicbfszqntfziywpgzgflfezormdyyypbucxzou
 * Smoking Wheels....  was here 2017 znbswmkcywopxggncxlkdzszoadczqoabfudelhkckyvbmil
 * Smoking Wheels....  was here 2017 gxruhydlcnqrenmikbijpopwfhoziyihxpcfhxbywkzmeikv
 * Smoking Wheels....  was here 2017 amznkoheapbexqxpekxpphfjgcxdnjdjlmjmywdpxivjvstr
 * Smoking Wheels....  was here 2017 xrnjmokcnekgkndugrywnujorubvezzysupzvdnqjtoetzpw
 * Smoking Wheels....  was here 2017 shacvlihnpoefjeotulebscsrzetzfbzdsayvrpqvpqrbviq
 * Smoking Wheels....  was here 2017 ognqeacahlrrbmfwzbstbfulumptbsvqhteucvxkywrcadrj
 * Smoking Wheels....  was here 2017 vsgikjcxgpdpcprwpwfdumzntkzyrkzjaqwjcdhasynsecot
 * Smoking Wheels....  was here 2017 cguptrvrfcpanphzlyszpbmzmcfriklvliaqlhutjkjghbgt
 * Smoking Wheels....  was here 2017 fmveomfmcixiypayphgjetkegdlqxelyxzzvdktfkdomlsdo
 * Smoking Wheels....  was here 2017 ilkdnqfodvfedbarlcbnkobrnibrjhkyadelgrueodtoyyxo
 * Smoking Wheels....  was here 2017 thurocgmvmykdpuipvrxntafavrwbsbgqmlfgsqstvvwgxol
 * Smoking Wheels....  was here 2017 dnmhwevcyirdfdzjxewixxcyuxfpnninwyueuflchtxbgzhe
 * Smoking Wheels....  was here 2017 gvgtukukjuityuolldpsftkczftnmflsbukovhnyqukyywny
 * Smoking Wheels....  was here 2017 hfcabngtljbxdztooxejkjfgcotnbkvavmwvlelamzyqqlyd
 * Smoking Wheels....  was here 2017 pwijpomsozektkzuyzctpycgxaurnzevasxtejzkvslpvwnm
 * Smoking Wheels....  was here 2017 tgjhnvcbmqkkexxrjbcpgcydiyuikclwtlojprhjxozjjomx
 * Smoking Wheels....  was here 2017 pcbnhwwwetpgyqovzbgyzoueqzwendvajxcwqdqofizvhcfo
 * Smoking Wheels....  was here 2017 gijbokylxwwptacfchtaujyziwkbwvunmoztmaqrlebcwmlx
 * Smoking Wheels....  was here 2017 cgoegmpidwqittyzjdeituzjbuabuzavycaupwbwqjdpqueq
 * Smoking Wheels....  was here 2017 sfeiojkjouonfqwqqifpijtiwarquumnvneyokajynixklnq
 * Smoking Wheels....  was here 2017 yaygvqeogzloqxtuzwyvfwigzelhrriqoatnjswuxnaxfdze
 * Smoking Wheels....  was here 2017 xoxauaahibmbvyvkuxphhiapxctangchscgycbcxgjvrjsgp
 * Smoking Wheels....  was here 2017 zdiuiphbiwbywjnqqzrlsakhhwewomjydklahypvxmrrkjgq
 * Smoking Wheels....  was here 2017 tdrcqomszlvgadozktybymhhevrfklfhxyirmdluelsldmfe
 * Smoking Wheels....  was here 2017 bisscnlhhfqkvjwcffldqluzuoiruotglyegssxkmbgxnsom
 * Smoking Wheels....  was here 2017 bqnplfhckrqablrwjpkxraewpyoeunlahvmebyqmpkzdyyay
 * Smoking Wheels....  was here 2017 aihanrisxtfzvbkonhjwhkcuiaztrfzaijaezijalxvoyjnf
 * Smoking Wheels....  was here 2017 quolnecxmlzjjctnmcbtvdhuzdmwztjyrmuidqgkibvtgjgh
 * Smoking Wheels....  was here 2017 sucqxflubewogssmkynoabxetxfbootssjbvlyoerslpypsh
 * Smoking Wheels....  was here 2017 khyphqmpymaffikkpazpsdfnedogkipmyojebmxcgahfiyor
 * Smoking Wheels....  was here 2017 znhopllzpguekoiksvzhdqvpxyenuxqtislclucgzhgzyose
 * Smoking Wheels....  was here 2017 dxraawartnupaifzocgjsdnnarwhimteyvhpfrfzecmnowlq
 * Smoking Wheels....  was here 2017 rewtynytjqzuqtythtwxbkkorxwetlerdcfzidpughjsfnei
 * Smoking Wheels....  was here 2017 sixscchorglkbhusgaacdlvhjmnzcljlmzrrxltozymqgjpp
 * Smoking Wheels....  was here 2017 pnzeirlpedoiipcazjgmcoimvmmxsjzxwgmlkdpghkuseqqf
 * Smoking Wheels....  was here 2017 ygrqvmytpkarsnrclnisjgsgbgqhckbtkuphnzcglikntsnb
 * Smoking Wheels....  was here 2017 qfsvacqaxjrvtgkqrkhxphcwgjbtcxsxlwimcarcylszcfsi
 * Smoking Wheels....  was here 2017 skdtphosirqjhdnoahifssuyysferpkppxeminwomxielbwl
 * Smoking Wheels....  was here 2017 pberkcbkjdieixlcdpzewvjfuisrehwfrrwarantbbemjlzc
 * Smoking Wheels....  was here 2017 wojastrxtvjkelxqvbanndrtvolpdfalvcmdthryxmjoqrgg
 * Smoking Wheels....  was here 2017 jrlqwuhglcrkjwuwgrmhhlsxhanpjtcfkkfbmiqtnzhfimbb
 * Smoking Wheels....  was here 2017 fjllnbyuroiuspksspprdswfqojownntabphbmbxpsppstey
 * Smoking Wheels....  was here 2017 twqsrmzbyaulfhckwhwefhsmofpoymalntkoxfrncydchqnq
 * Smoking Wheels....  was here 2017 qpmykkywyoqmfwpinncoyqbtdjczesmzzmqwriqwiiciyniz
 * Smoking Wheels....  was here 2017 qhuxfirhspthflxeuggvzpzjmpzlhrdiumomhwfnsrvdrbzg
 * Smoking Wheels....  was here 2017 yxonrbgplqilbkdxbrqfgduwetswkampodrwxczizbzqtegw
 * Smoking Wheels....  was here 2017 vsbduoajpnswsmuryfsexpccxxwhtqdidguuynvhdwlgszam
 * Smoking Wheels....  was here 2017 zcudsenkzknronpyfrgojmraqlidxqcdpsvgbytskqiokyna
 * Smoking Wheels....  was here 2017 eunjukoumorfbrkjbyiginqbqwgarmoyivdmfjcfgfblwrfs
 * Smoking Wheels....  was here 2017 pugtubgvkqidbinwvhdosuirjcavbvzzyzfzncmoltgbibuy
 * Smoking Wheels....  was here 2017 oigpocxbekvgofircdfzqogtoegqjnaqgxunlqruxmusjhfl
 * Smoking Wheels....  was here 2017 ruajhwchoavtxdofsfhgpjhiemwwdtrplowbquuhxcvbutqc
 * Smoking Wheels....  was here 2017 tziulwqonufypiddumliezmrmpacfxdwuftvaocnyktzqbnd
 * Smoking Wheels....  was here 2017 zufxpvqghicnmdhksewnikejxiagorvoxgxjtggjsmeofepy
 * Smoking Wheels....  was here 2017 rmxxswjwjkxhnflectdhfyygguojnxlcrldlgiaveqafagvg
 * Smoking Wheels....  was here 2017 lmxjzemflfglbnhxsxykhcpjlhnxpuyfftlzermhqnjowqiz
 * Smoking Wheels....  was here 2017 doayvjsjnabgqdugtpjvergztmblqrovwjbgmfyfmyqkvaqh
 * Smoking Wheels....  was here 2017 vqfrvdeqwlklbnefncpvvsdspemvrhscftnuhhbmnamydhlp
 * Smoking Wheels....  was here 2017 yxuvaofoxisuihwxrvfxjlyitlnfyncmdrpibjodsbuojqqr
 * Smoking Wheels....  was here 2017 bxgwnxjzkspmujntamytgkkxfqazbmrrsahvkhomgqruiklj
 * Smoking Wheels....  was here 2017 ahiossmxhazwxxemrcvldkqteicttoqojbwnibkbrqnobhix
 * Smoking Wheels....  was here 2017 xbbwhsqswtyoohybzucfylzkdkejdmkjpgvzxyqrrdzzwear
 * Smoking Wheels....  was here 2017 djrbfzdxovylteiopdgnwvysvxwylctnjhyxqmclflxkfejl
 * Smoking Wheels....  was here 2017 gutrptohdhpqumanitccgbksfecxfpossdfhclvppemnzurb
 * Smoking Wheels....  was here 2017 eyzjwptzomtneizphqpzvxlsowyuhibwabxkhwftfeccepjt
 * Smoking Wheels....  was here 2017 yukfshtfbaostdjrwbbkmkjgitvoszsdwlosjatswoijcmcy
 * Smoking Wheels....  was here 2017 zqikavypdskbnpqzqkyxkwtefxjhslezdbxzslimmpcphrvh
 * Smoking Wheels....  was here 2017 vwemznvymrysvonzlkbdatkngtmiwwkdxwyezwalixpmonuu
 * Smoking Wheels....  was here 2017 jftdawghcfbzeeyhkbkeyxlpqvhjarqlobzpejccxjcwxrko
 * Smoking Wheels....  was here 2017 srcluqhyfyxpiwdwwogfdidzwyeednhdrcmrjgehwaivrbkc
 * Smoking Wheels....  was here 2017 fklogxhmhsvikhnxmkcuuhclrgtzngcqdtfgaybbggdvjvsa
 * Smoking Wheels....  was here 2017 lyhbmxvrcpmjqjuvbgrqgidcabycucyqbxffvivshprlujni
 * Smoking Wheels....  was here 2017 iykqzesppytaqfxisbbtgeifdzxdqkcbtwtwrjvvlyinziid
 * Smoking Wheels....  was here 2017 xjvijnzpaiuycfbiudljsyzinvzaevycwahssiqflitfhqtx
 * Smoking Wheels....  was here 2017 pmuipxafvqyadbsaywkztvshxruuqigefcqmkuaxgduwekuj
 * Smoking Wheels....  was here 2017 ysveurkfuwxjarnvzyqjuliegxhxqzyzycudjncfeyodlbrj
 * Smoking Wheels....  was here 2017 vurpkiwswlnjidnlzlfmnmwgvboyyfeljeazonesppnwehue
 * Smoking Wheels....  was here 2017 jrjpcqpygxyouxvvjmjpxasbbaztosludwvmdcwehfherxvd
 * Smoking Wheels....  was here 2017 wpdkvqwomdnymqydsnqfahkmsxfmvjljbvyknsysgbsmleva
 * Smoking Wheels....  was here 2017 aznorpfihfynsfotxjtbixtntyenghcygclsjgnqstzihkxs
 * Smoking Wheels....  was here 2017 pohtdbohplctztplzwscnovmlwylqxqkdunrpqwldelqghol
 * Smoking Wheels....  was here 2017 tilavuwtrlcedsgdjiurlhayfkyebxmyfltujfqzgjtopslo
 * Smoking Wheels....  was here 2017 vmfprvniaaitetaypeoejkvsvruutdjaktwvdmpiastjyvov
 * Smoking Wheels....  was here 2017 llezxkctiiknlsojpdrlqkdwhakritfgvrwsofvtstquabbd
 * Smoking Wheels....  was here 2017 kzaxvdkdprhykuwblegkydzrtbwmnffqulasnmrvujupxbkr
 * Smoking Wheels....  was here 2017 wbvjfsotbqanxkbymmmienrstpqakdwjxmwkfmrjzpvavshw
 * Smoking Wheels....  was here 2017 ewupyfufebbgzdrgiowsoxvuathmgkuubodlavslhwqilesl
 * Smoking Wheels....  was here 2017 yxmeewugsaaeyzijvcghlugynwseqearipvvrguixriflwuh
 * Smoking Wheels....  was here 2017 zvqsighzpxurhabadboboyaommctiwsycwgwbthpixjnxkbq
 * Smoking Wheels....  was here 2017 lqgibdjscgmjwrzcnrciullckmtbjdhsytxzirubhriidsew
 * Smoking Wheels....  was here 2017 ropfinlzsyneqpquqkkmhnckaxkgbwmntanaymbutgccqybr
 * Smoking Wheels....  was here 2017 hbfwhszpdbnezsqojyejnsvpgewsyggypqdwnafcahvkgnya
 * Smoking Wheels....  was here 2017 cvvaifwqjxjskdybthlxdvswkvhzuquzvvzvagommpxcabhb
 * Smoking Wheels....  was here 2017 gvmsdvdjpcfmsiugfqnkavawyscarsovczpjomrvxhyheltg
 * Smoking Wheels....  was here 2017 chkdqodjjmlhxwqhhlvhjbkjoxxxxjfwfxthpgjegrwkixig
 * Smoking Wheels....  was here 2017 fsdwzslmjdrhirdqxmfjpzqlgtpaytsvhnlouhtuujubgtfa
 * Smoking Wheels....  was here 2017 mskopuxtpkuvnyhzdqqqklukhwharghpsbyjcrdhzedczsvt
 * Smoking Wheels....  was here 2017 ajggdoolhwzogbgfhdjhqlgucbkrcojkbythprbkofmqurxv
 * Smoking Wheels....  was here 2017 dvyeobsewjoiormnbmywnfmkklofnoqreyqbuukhnvtbhtiy
 * Smoking Wheels....  was here 2017 mozwzpzseafgtqrkgjcdljkigiqymkcbfzpqhwffapbzekjc
 * Smoking Wheels....  was here 2017 xhcawqedcdutjevmyuwacpbwvivmtnxnmixgbvvrqjvgoflk
 * Smoking Wheels....  was here 2017 mzjrvajtwhmjerbsoxnukzupphktkmmfpjbmfaupbfqbsdgh
 * Smoking Wheels....  was here 2017 pwzbwtwcakqbhtxgqgmznudgihdwshpplxwafyyygmlsehtn
 * Smoking Wheels....  was here 2017 wjmqbchagmxwyizocmqivnyzzqudfaejcvhvtkibluiwtddy
 * Smoking Wheels....  was here 2017 cgrfxpknowdfrphizoxuaagbuzpgscjlxjpgrlimeyskmgwt
 * Smoking Wheels....  was here 2017 llmtzajzefnshxamstpqbflagdxahfsznairegnbcafjroql
 * Smoking Wheels....  was here 2017 fegmhkkxohkfwxqfvlfjbmbrbeipefvmsmfyrlrvfksfvgjq
 * Smoking Wheels....  was here 2017 bxlyzaddlfmvrnuxflnslhxdfmukyhrorshzwtwcuqjntsii
 * Smoking Wheels....  was here 2017 vjvwlkkrujozfxlhzrnsxlcrzpkzjvnetyubqfmkhqoenowq
 * Smoking Wheels....  was here 2017 pnlfjhgxxhvgimwimiloiyyvtjofnmsnmqgredaplkxhktta
 * Smoking Wheels....  was here 2017 tnnhqtaievrnbvkdixwuybzljxxgrdaaumkoxajtfhigykyd
 * Smoking Wheels....  was here 2017 wyonmbgukbsyryvejcnccjcosoiljzkitmitlppcvyyryxpz
 * Smoking Wheels....  was here 2017 vkjsgtvinjvvtxbdswkomqimbwzllkalsvfluzygvedklyes
 * Smoking Wheels....  was here 2017 sxywrpuhuhevbeiysluiavatxtfcwaimizpeakczwbnpskks
 * Smoking Wheels....  was here 2017 xrndpomessdupiatyifyxhtgyfrmzuaykrgrqkvkyzapilft
 * Smoking Wheels....  was here 2017 aeqdhaluysixtixcidjemohyeqgbivbmavexgteuilubamus
 * Smoking Wheels....  was here 2017 wcaoblngnprlaiwnxyjanitfvpbkroqzqsqeulnrljdvydot
 * Smoking Wheels....  was here 2017 oksjrqtwqagcesecbwjrvsmpkzojbqfstudylvlybvuahhhj
 * Smoking Wheels....  was here 2017 miawzpndvtnthdfxklyrryawpuhdvymbgtlzqjsoedoaqexf
 * Smoking Wheels....  was here 2017 gjjnepkwuxcmqmskujwtknedkmfzmqkshoogzwlxzxqludof
 * Smoking Wheels....  was here 2017 rencrfdfmwvqtypihocxsicrbnlpvcdpekualjznyyjeuvuo
 * Smoking Wheels....  was here 2017 wtoodfxjedxxlwdniiyjogabaviwwbexnvotfdvfwjlhxefr
 * Smoking Wheels....  was here 2017 fhsemoyziqqduzsglawqasocbmowzifcemtgqrwaqorfsiug
 * Smoking Wheels....  was here 2017 ihnlwpwurltkacaxnmsnpcovduazqceugigmludgoagozrtg
 * Smoking Wheels....  was here 2017 alrctvnxfwcdslberokxxhbomjvvqthzcqkrnmzmcqoetwou
 */
/**
* Copyright (C) 2004, 2005, 2006, 2007  Free Software Foundation, Inc.
*
* Author: Oliver Hitz
*
* This file is part of GNU Libidn.
*
* This library is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public License
* as published by the Free Software Foundation; either version 2.1 of
* the License, or (at your option) any later version.
*
* This library is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with this library; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301
* USA
*/
package net.yacy.cora.document.id;
public class Punycode {
/* Punycode parameters */
private final static int TMIN = 1;
private final static int TMAX = 26;
private final static int BASE = 36;
private final static int INITIAL_N = 128;
private final static int INITIAL_BIAS = 72;
private final static int DAMP = 700;
private final static int SKEW = 38;
private final static char DELIMITER = '-';
/**
* Punycodes a unicode string.
*
* @param input Unicode string.
* @return Punycoded string.
*/
public static String encode(final String input) throws PunycodeException {
int n = INITIAL_N;
int delta = 0;
int bias = INITIAL_BIAS;
final StringBuilder output = new StringBuilder(input.length() + 1);
int b = 0;
for (int i = 0; i < input.length(); i++) {
final char c = input.charAt(i);
        if (isBasic(c)) {
output.append(c);
b++;
}
}
if (b > 0) {
output.append(DELIMITER);
}
int h = b;
while (h < input.length()) {
int m = Integer.MAX_VALUE;
for (int i = 0; i < input.length(); i++) {
	final int c = input.charAt(i);
	if (c >= n && c < m) {
	  m = c;
	}
}
if (m - n > (Integer.MAX_VALUE - delta) / (h + 1)) {
	throw new PunycodeException(PunycodeException.OVERFLOW);
}
delta = delta + (m - n) * (h + 1);
n = m;
for (int j = 0; j < input.length(); j++) {
	final int c = input.charAt(j);
	if (c < n) {
	  delta++;
	  if (0 == delta) {
	    throw new PunycodeException(PunycodeException.OVERFLOW);
	  }
	}
	if (c == n) {
	  int q = delta;
	  for (int k = BASE;; k += BASE) {
	    int t;
	    if (k <= bias) {
	      t = TMIN;
	    } else if (k >= bias + TMAX) {
	      t = TMAX;
	    } else {
	      t = k - bias;
	    }
	    if (q < t) {
	      break;
	    }
	    output.append((char) digit2codepoint(t + (q - t) % (BASE - t)));
	    q = (q - t) / (BASE - t);
	  }
	  output.append((char) digit2codepoint(q));
	  bias = adapt(delta, h + 1, h == b);
	  delta = 0;
	  h++;
	}
}
delta++;
n++;
}
return output.toString();
}
/**
* Decode a punycoded string.
*
* @param input Punycode string
* @return Unicode string.
*/
public static String decode(final String input)
throws PunycodeException
{
int n = INITIAL_N;
int i = 0;
int bias = INITIAL_BIAS;
int d = input.lastIndexOf(DELIMITER);
final StringBuilder output = new StringBuilder(d + 1);
if (d > 0) {
for (int j = 0; j < d; j++) {
final char c = input.charAt(j);
if (!isBasic(c)) {
throw new PunycodeException(PunycodeException.BAD_INPUT);
}
output.append(c);
}
d++;
} else {
d = 0;
}
while (d < input.length()) {
final int oldi = i;
int w = 1;
for (int k = BASE; ; k += BASE) {
	if (d == input.length()) {
	  throw new PunycodeException(PunycodeException.BAD_INPUT);
	}
	final int c = input.charAt(d++);
	final int digit = codepoint2digit(c);
	if (digit > (Integer.MAX_VALUE - i) / w) {
	  throw new PunycodeException(PunycodeException.OVERFLOW);
	}
	i = i + digit * w;
	int t;
	if (k <= bias) {
	  t = TMIN;
	} else if (k >= bias + TMAX) {
	  t = TMAX;
	} else {
	  t = k - bias;
	}
	if (digit < t) {
	  break;
	}
	w = w * (BASE - t);	
}
bias = adapt(i - oldi, output.length()+1, oldi == 0);
if (i / (output.length() + 1) > Integer.MAX_VALUE - n) {
	throw new PunycodeException(PunycodeException.OVERFLOW);
}
n = n + i / (output.length() + 1);
i = i % (output.length() + 1);
output.insert(i, (char) n);
i++;
}
return output.toString();
}
public final static int adapt(int delta, final int numpoints, final boolean first)
{
if (first) {
delta = delta / DAMP;
} else {
delta = delta / 2;
}
delta = delta + (delta / numpoints);
int k = 0;
while (delta > ((BASE - TMIN) * TMAX) / 2) {
delta = delta / (BASE - TMIN);
k = k + BASE;
}
return k + ((BASE - TMIN + 1) * delta) / (delta + SKEW);
}
public final static boolean isBasic(final char c)
{
return c < 0x80;
}
public static boolean isBasic(final String input) {
if (input == null) return true;
for (int j = 0; j < input.length(); j++) {
if (!isBasic(input.charAt(j))) return false;
}
return true;
}
public final static int digit2codepoint(final int d)
throws PunycodeException
{
if (d < 26) {
return d + 'a';
} else if (d < 36) {
return d - 26 + '0';
} else {
throw new PunycodeException(PunycodeException.BAD_INPUT);
}
}
public final static int codepoint2digit(final int c)
throws PunycodeException
{
if (c - '0' < 10) {
return c - '0' + 26;
} else if (c - 'a' < 26) {
return c - 'a';
} else {
throw new PunycodeException(PunycodeException.BAD_INPUT);
}
}
public static class PunycodeException
extends Exception
{
/**
* 
*/
private static final long serialVersionUID = 1L;
public static final String OVERFLOW = "Overflow.";
public static final String BAD_INPUT = "Bad input.";
/**
* Creates a new PunycodeException.
*
* @param m message.
*/
public PunycodeException(final String m)
{
super(m);
}
}
}
