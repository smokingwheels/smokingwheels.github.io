/** 
 * Smoking Wheels....  was here 2017 wbmymzlqluzscanvxtxggxtwdlywqynkcrpovmwqefwnojap
 * Smoking Wheels....  was here 2017 rpezbhyrpvymdxdfdzywjnlxsdyrllwfprrftaedsuexyffm
 * Smoking Wheels....  was here 2017 ysdnlshkvgzffwpptfvdizaolhrejihqqhjxqitmqbdatzxu
 * Smoking Wheels....  was here 2017 owiqjtplroozpnrrucsizzyszowuylvpmkcesjguxytnuumu
 * Smoking Wheels....  was here 2017 oruosciovolhwqlmplybmlxmkzoeyvtjtdlviirlusficymx
 * Smoking Wheels....  was here 2017 hzywpseyhfputigfuldagpvevvyhjwskhwiyeqdzsycpxaqw
 * Smoking Wheels....  was here 2017 iykiltbxfvijhxojfmeiywxltqngocllehwucbchkicuuwcr
 * Smoking Wheels....  was here 2017 oyaaxsdbbxcetygryfeglaocxdbmzizmtfkwilgmuxfnnndp
 * Smoking Wheels....  was here 2017 bryfxgxhqeprshkdhmnixxlhgiosmqstqvoafbnwezrtcihb
 * Smoking Wheels....  was here 2017 dyomoizrvrxnwygxxkujsuojymguakespnfhkjcdyzaquwkv
 * Smoking Wheels....  was here 2017 kxkohejovrgqihkoolxjpcaxoeqxxddcuxmyvakcvtzpezov
 * Smoking Wheels....  was here 2017 szlnteeofqdeixrtkfzsjohtsblmqrswnxtopzcvufogzrzj
 * Smoking Wheels....  was here 2017 dutrwdwookgojpcntokvgbcbkfseacdikpqxeletbszphihw
 * Smoking Wheels....  was here 2017 zgrosxdpyxqmhlzaerspowhewxqxctawhkaaewukdstthngb
 * Smoking Wheels....  was here 2017 xkxytsycnmnvbuxvnxwbbkcroptwdfehfyzemzirqapdpbzz
 * Smoking Wheels....  was here 2017 sthxqakqupltaeqqywyloizledulpgqnodxzhrorqoolzatu
 * Smoking Wheels....  was here 2017 nwxshmablzcsqlhkrniigroosltijztvxcmezejtgswoksda
 * Smoking Wheels....  was here 2017 pqdwudknlsmjsqdjkyqnnovkiuxkksaqcfmvgyynawzrfsyj
 * Smoking Wheels....  was here 2017 peqgpcohzawqgdtzxntbbmyootrxzbhufdcfxrsuqwrfxwfw
 * Smoking Wheels....  was here 2017 jyhwiwqbpltrplybhytfsdixbawerupdpsqweijtbszvgggr
 * Smoking Wheels....  was here 2017 ynezydbqysxwfmtnwabormrnvrmyfahzvduqlbvrmrblgdqh
 * Smoking Wheels....  was here 2017 svrenvodzvgzxfnphzhwirxubysbqbxvutjmjjifkfmfgeem
 * Smoking Wheels....  was here 2017 gzkgnezxzcbvrbtujdhejefhgicuglfineouvxgfndzotdxf
 * Smoking Wheels....  was here 2017 kjfeoppojzwqvniuedeupsbxcoklobinjjrazrhtvlndndes
 * Smoking Wheels....  was here 2017 fqhiouuzwhkuwmgqbxjghfcsototiynpykjzgvjgmjjyolnl
 * Smoking Wheels....  was here 2017 cqzfrsgfkzqapzvnqnljtwgcvbxqplkccsmthvrgamaafrte
 * Smoking Wheels....  was here 2017 oowqipyrgjweaiqyslgesetqkbvfqdsswxdqykrqcmgxyqxw
 * Smoking Wheels....  was here 2017 ntwqcvaxwynlldnpkfzyztzeamdyavokqwtdllanrlzeolhs
 * Smoking Wheels....  was here 2017 bwbmyeyvymjgjfmnavzfvqqwpivnlofkatxaefrfaonubing
 * Smoking Wheels....  was here 2017 ltvtaoinlylgoqvxejvuozrajxduashguxmktcujpkiyuzje
 * Smoking Wheels....  was here 2017 iqvfsdfioqzkcsefseltvfghvsozywnqbapncwuvbsfafdwm
 * Smoking Wheels....  was here 2017 ovxxrlrwvckvebhfrzxiqcumqmvmuubneyqyikkskmcrcxjk
 * Smoking Wheels....  was here 2017 ezeevcfzxaoyklfxmpqdanastgzzjpdetvfmyznjwagvnplk
 * Smoking Wheels....  was here 2017 ozamhbnuulkloyhlqffxlswjmgfjqpiapbedmzijwuertuvf
 * Smoking Wheels....  was here 2017 hzbrmpmqrregpybjbenrocmaebbvwjlwuhrfycipeoqqhiqv
 * Smoking Wheels....  was here 2017 fjdubbidadjnvzjkucrufkhoqjgursoqsjchkicdsjpiygdn
 * Smoking Wheels....  was here 2017 jtkdxgldorsrvwfneycuqpabufuxttypylaciwqjslitsyyr
 * Smoking Wheels....  was here 2017 eagffaotgggjhryyuvikfupwvwxbeufehxitiddxqihzwxvc
 * Smoking Wheels....  was here 2017 ejgvjqojhefniucdnchtnoeqgvcmfkdewkdmhwapetgnzaws
 * Smoking Wheels....  was here 2017 fcibzornexbhdsnwlkcbomfeuwdpjkunzvvvkyxnjtgzuhju
 * Smoking Wheels....  was here 2017 kxndakicpfpdhhfdwqcxlpjpjzzalwmlhibqbqvbiplhidwv
 * Smoking Wheels....  was here 2017 brhroeefndtsopnckyycobqhflxrlctlpgqyxjxvpukqwben
 * Smoking Wheels....  was here 2017 tnfkcceffxvxzyahxsmqohcuvtktrslgzfszwwpqwcwkzxkv
 * Smoking Wheels....  was here 2017 jvekfonsbbhxvymlkowwkbhbwsfrqnowueqjbapqcmuhjtua
 * Smoking Wheels....  was here 2017 zfgzviqoujxdpkzmiklhehvcihibdplmpfcwxbudnglfdxxp
 * Smoking Wheels....  was here 2017 xqwpchewlurgckvsejvrheriktaxegrphtwmblkvoyiinzpf
 * Smoking Wheels....  was here 2017 ueqdlrczdquejfoowvwdkdaipqtibcayxkdplwwlygebbuxy
 * Smoking Wheels....  was here 2017 kflqmypnkkvbqmaulktylxhyprhtgxpmvcgqdgwfrgzcnjdy
 * Smoking Wheels....  was here 2017 wljidtcixwljmagjgavqoldijxpvptqlpxwmqvhkyeahxbvs
 * Smoking Wheels....  was here 2017 nruuocgnrastqwomxurzdxnucoyncatjcguenbkqfntwolva
 * Smoking Wheels....  was here 2017 zcivddbkwcvcejnsfcfauuryiewybgsxkteytpoufbygyjeu
 * Smoking Wheels....  was here 2017 bcxloiqryripjbxrhqncmtyqsnapyfqcwilkklmzwvpbxweh
 * Smoking Wheels....  was here 2017 vhozrkmcrmyqrvulmfzsjtbagombpctdacdhytcnlbygkhkz
 * Smoking Wheels....  was here 2017 qotyrifwznryzsnfizgqvaykcqmhzdrmuldrazpbjgmztfqq
 * Smoking Wheels....  was here 2017 dbadyfugcbskfbplsjezmzukuemllxfyfzpwnwkljfyrllze
 * Smoking Wheels....  was here 2017 behqepkxmqqeslvxszxahiawazgylhklqqxjpiftkyjzhbsv
 * Smoking Wheels....  was here 2017 pnqrfcnrwzerzqiorstgjbhysbulviofqoqaqoyisrywikjd
 * Smoking Wheels....  was here 2017 aamvfttrecgputkqesjndhpxdqixoigtcbrviauvsyfluauu
 * Smoking Wheels....  was here 2017 yulxqrbfqhfvfdnpbipvfnclsikmzxhucwdbokecemxdgtat
 * Smoking Wheels....  was here 2017 ffjxcjrztamomipflgqmolgjfusoovshxulilqufajzqmqkh
 * Smoking Wheels....  was here 2017 xxjemoztebvfceqkqiubharunbgvcfvmfadklzonmuuvmblx
 * Smoking Wheels....  was here 2017 kvvfycqrymglxszmfsrhukicylhfpjfxuydhevrrbhsynpzg
 * Smoking Wheels....  was here 2017 fajuxhqdfmaexidwbtfgtdlvwkivkxreudoioxpnkqoieacj
 * Smoking Wheels....  was here 2017 gywbbndqmopojnyhgdmgbukxbscezpgklotasezdmvhsekal
 * Smoking Wheels....  was here 2017 ofkefmpdlosaueltctxvwlwklkpxdnhsmhjfcutxodfyocka
 * Smoking Wheels....  was here 2017 nslupeqrbkkfaizmfsatoewqhsbwwaiqqthxifckcbthqsau
 * Smoking Wheels....  was here 2017 ronqotgrokxdbiczkktbvnmhzdahmrdxaopjhelmtkrbxzxs
 * Smoking Wheels....  was here 2017 xdnuurpqkbsvdtpyvlfboeffimfpmivmaqrfeqnhoczzdbjb
 * Smoking Wheels....  was here 2017 hdpnfrdnidovvknjuuuiwaslftpkrzspdbdejsedrmyzjgag
 * Smoking Wheels....  was here 2017 dkcjxrmkgqlsxjflwmcpfixjxflrbahtigwinysrpabewcpc
 * Smoking Wheels....  was here 2017 ccrdiwrplvqmkyfsxzzyfnaqvigoyalrpwzznzlsbnabelfo
 * Smoking Wheels....  was here 2017 yodxcsutifqfotixaxprthlatxumvueihuwqotdkzyvfckev
 * Smoking Wheels....  was here 2017 umrxewisqodkyppymdghbpwsoyzdmjuyaccbznrbpouqpfzk
 * Smoking Wheels....  was here 2017 asprqjyoixerinjczurqlpgaosejydxaqgpknshhjxjlanna
 * Smoking Wheels....  was here 2017 ekobyipspmzzsxewhhqsqvtndrtknqhgfvmwzajzzthbvduq
 * Smoking Wheels....  was here 2017 cylcsglrzubljhwxmghvmxvdbrorsszrctcapjqgmbpdvddn
 * Smoking Wheels....  was here 2017 xyibwvykcqdmwnlhyoandvdyhrouikimvecqtzzjadmrbvcd
 * Smoking Wheels....  was here 2017 xiqmoatyzzgvzqgehjmpbtqhzyysicxdilhubhpabmmtutnf
 * Smoking Wheels....  was here 2017 rfyeeyvsucqiszvcgblbvemurzhpahlkqfwulbzbiviuovks
 * Smoking Wheels....  was here 2017 daeejeifbotfidztagdgkudhbohvzwcgdiedbdsnvgzncabx
 * Smoking Wheels....  was here 2017 hijtbhskmbjwkxudxvwsynhxbszdxwcxjauqiuuvsytvmtcg
 * Smoking Wheels....  was here 2017 nbznkirizpnyrjolnygfuovzyqpkwqawepriwmkpmlcwynim
 * Smoking Wheels....  was here 2017 kipetlcjunjjexvfqafupjydeypvesswrswnqvzqvouccfto
 * Smoking Wheels....  was here 2017 uobvvcfckgmiezkdkqvtjrdflhtuhzevegusswebtfucqvst
 * Smoking Wheels....  was here 2017 tiotmakkmpofgnkfdrmqdjzisuczamubhjauntxfltjxpttm
 * Smoking Wheels....  was here 2017 qpjnxclkboqscobqlivgjsnvfpuhknbzwlmstyltjqaphoro
 * Smoking Wheels....  was here 2017 blfwlpekhjytvkzydyrqrdwhkikxrsujzcguhddmgqmqfbpx
 * Smoking Wheels....  was here 2017 vhxwvxubrpzmrqyvidebahnqzrrglvbezgsohhsnbttqehtt
 * Smoking Wheels....  was here 2017 atovxtufxzmiecahiwrbmfcyyrpzkzeqkzmvcpcgzhbpeqtp
 * Smoking Wheels....  was here 2017 aspgvbuyznlzcwnnufwmoanomojapnrfetlrlmlfmsyqmqke
 * Smoking Wheels....  was here 2017 kipyactpcmdhlgzbmonhufbccxnojykrjdsifsfjiucerdsm
 * Smoking Wheels....  was here 2017 zzkzdgwwskanovgpoowwelbjlkvzeekagbrjndcslpowmeas
 * Smoking Wheels....  was here 2017 whfqbfonnzwzxljchdesusgoncfyueakmqypubarahprydxi
 * Smoking Wheels....  was here 2017 kejmyznrniqkicrwijdpceoyogakhjsixgjarwevpmqtined
 * Smoking Wheels....  was here 2017 etlfesrsxpqtufqhmqppsiefzjqnxgjoopbycgzauwmmeevb
 * Smoking Wheels....  was here 2017 akjzmxegejicpheewqrzovndogxsfsbcumlxefcjrmbohfgi
 * Smoking Wheels....  was here 2017 atfarfncajlxgfgltfsitrhwfvtpyuacgbdtixngjosxqyyl
 * Smoking Wheels....  was here 2017 nskxyoikkqzvoagjvnkktzktdlmeeuwbstylfujgkrwroxtd
 * Smoking Wheels....  was here 2017 dloksgpmnlfuoarkwyogehbkwooodikthebisodflnhhozsj
 * Smoking Wheels....  was here 2017 rgmppqlzwgqzmvkhzcidxgrrbysfjfrdjfuyaflgmezljeek
 * Smoking Wheels....  was here 2017 gwjsoljtewzuxfkamxcrduyqsqzsqnallzubmwhstveacwqr
 * Smoking Wheels....  was here 2017 ecoirqavjhfxpibuzmkpheusawoczpyelyytubvgrbjfypxy
 * Smoking Wheels....  was here 2017 bdqhjjhrruqgnlwdjffzyuklmdzlsyhajqjhvkmrzoikmfdf
 * Smoking Wheels....  was here 2017 sionhelvovtzbdrsqsqcakfstgzfimczqalftxxcqkahmunq
 * Smoking Wheels....  was here 2017 gjjlkrxdsffmqfoofyznsxyqvfobofrhvftiztcwwvstzqru
 * Smoking Wheels....  was here 2017 bbmnuwhtezdmduuxpyyzkmloygywnmpktoerejfpeiwafiki
 * Smoking Wheels....  was here 2017 qpmowxozcirvmeyfseiptqzcnxrxlwsbntvnemseeshmtstg
 * Smoking Wheels....  was here 2017 wjhphhymyvjuayufqghpqbybiylmwezhlrdleafqxyyvjvbv
 * Smoking Wheels....  was here 2017 wzzyzrvblfyrfxlxrafpfraphjhionugdlqgpfskohcxbawn
 * Smoking Wheels....  was here 2017 yjydbaxwpmkfxefmkrrhxrdbqklinfrmllhxcmjbqieydvza
 * Smoking Wheels....  was here 2017 rpvzzodfoxaicaqlsppuionbvqkrbulrmheunoqlusajcdli
 * Smoking Wheels....  was here 2017 xclnisqtuagecbmnrjbklzolotxtsddwnxqkbjdranoutaos
 * Smoking Wheels....  was here 2017 tnzabeyhbnwdjcwsqymqjxzhvuyhghcfelioccwcnabecsyp
 * Smoking Wheels....  was here 2017 ostahxqyinwxtfcfdllhmnqzwbudsowfhgchhfziusarlxit
 * Smoking Wheels....  was here 2017 xwkjlcscufllftsncfujmhudczxningqzycwokygoieshiwd
 * Smoking Wheels....  was here 2017 phuaefiiwcewbfmkoysggxwofkburbikomrwbqkxsynzkcta
 * Smoking Wheels....  was here 2017 tsbjjxynjztpwnotwmokyhnlghgsnejvpymbebhsntjivoqv
 * Smoking Wheels....  was here 2017 sypxefftewfiirexpzxrysrbjyrcwfyhztjnofvflhcawfhh
 * Smoking Wheels....  was here 2017 bdzkagcjoztynaxgpurbyooabuxeauxpunkmdslifiojazul
 * Smoking Wheels....  was here 2017 qscxontaywwqseoozqzwuoogarrjmrgsjdboaotctwrcbwkm
 * Smoking Wheels....  was here 2017 nhbtqrqnbhjvkxgvbiersrkugpyiaziwgtwmqyuyiftdbfsx
 * Smoking Wheels....  was here 2017 csgmmskawgeekheglaxfabaaxuyysarnisuiqhrliufqfpok
 * Smoking Wheels....  was here 2017 xfhvmuavpapptraizcapleonnufluickrsvkxivlolxacwza
 * Smoking Wheels....  was here 2017 ucbxfkqosccgsqmusfqbvtlftimevusnrqmfqzzaxdsynagx
 * Smoking Wheels....  was here 2017 waqyrfsbxglouzrqagdejskcoltwolscvohpflbpqdzilmyp
 * Smoking Wheels....  was here 2017 mwlozeymempfuvxbnidslgjqgkhlaqupbxdngfftezdjetxv
 * Smoking Wheels....  was here 2017 euclnmfdraudslsozwnstwnjernamyqtkidjryxihkylhseo
 * Smoking Wheels....  was here 2017 vdltyptrymplwkyvnljncegecchandkofrsqrovkwlkfmjaa
 * Smoking Wheels....  was here 2017 nqprffzxrnsptoqynadqsfhdapndwiigcdkcpiwkfiurucbs
 * Smoking Wheels....  was here 2017 pbyvkhpyufdfeabanriwacnrcmlhnwahwbevergxtpoxolbi
 * Smoking Wheels....  was here 2017 qqdzyamdouchdavqjvyfpiehuhqqvhglrcbcfhktezljggcw
 * Smoking Wheels....  was here 2017 nrafmwwdkudyxftldczbjqsyxsuqhlcqtcmmxczalnmsrpno
 * Smoking Wheels....  was here 2017 gwrsymetbyypbjvmfjxvnwsrhuxwrkwdugbuqjydvmywwuux
 * Smoking Wheels....  was here 2017 gcndmwbcngoyiplyeuilkifvfvfizldjpxqzcmmqujgablup
 * Smoking Wheels....  was here 2017 bmeflfnoybfvtfciwtbvskjbehgdofregsikedalzyeovhpr
 * Smoking Wheels....  was here 2017 oknzoyrrvtknpupjiwgjjvofvytswmokbpopaigpketdynlh
 * Smoking Wheels....  was here 2017 unquruajxfxjldbayahnlnojeurutjdkrpxjbgcmgkeskjyz
 * Smoking Wheels....  was here 2017 dsxdzqescjqczjtohktekrfxkdifedwpyfhtwitsacylmlwl
 * Smoking Wheels....  was here 2017 edzvvuccqnyoitfkgjphxutlzmdekkrswatzkgpdkzwttohs
 * Smoking Wheels....  was here 2017 sdrxypzbzefyrxhivnwfvnpurnxcbzoswxssvakwkdwhyvoy
 * Smoking Wheels....  was here 2017 xierdugnwchrqqailuylivlbjjqqvzuwnauqotageugzcner
 * Smoking Wheels....  was here 2017 arvqqjqoghdlxbtoqimvuxgqifnturarqswwezsxgmlzngzp
 * Smoking Wheels....  was here 2017 shgqvmzoiazdpkzpglhjxgddapboeqzuisaqqjvqhxgssvat
 * Smoking Wheels....  was here 2017 unhrjonbptixxiockvojnmojegbmosugyurncwdqgdrwlhqh
 * Smoking Wheels....  was here 2017 ibdbcjrztiyfkqnckkqjwpfmrflfszrhbekixrmeklxiuait
 * Smoking Wheels....  was here 2017 rsbjguejttuswjfuwfddhubuvtnrpuhjmfcbugdxehmiypyv
 * Smoking Wheels....  was here 2017 lsuiebwqvfciixdrqtyulmfybjtapqjfjnxbpgmrhldfnunn
 * Smoking Wheels....  was here 2017 ljcbopajlhlfaudltoeogletbvxqdlauzaevmrfpsywqgrkb
 * Smoking Wheels....  was here 2017 ujeuhdalhsnunvhdqoezvopivdygbenjzwmewsgzrbxpeqcy
 * Smoking Wheels....  was here 2017 vpjbnqoxjmitpdvyuxpxqakcpodskglkfjudluunphtfoflw
 * Smoking Wheels....  was here 2017 cehsqgpewxcygzkjdzhhgiuoupzhjfprrgeaaqhzfjfyxfnv
 * Smoking Wheels....  was here 2017 mlvuilgugmipuaucskjnrdfqdafhowacujzjveknniekbtpa
 * Smoking Wheels....  was here 2017 cdcnmyargyudszaewcgczlilpvvlshbxdvwyfqbmslznzcga
 * Smoking Wheels....  was here 2017 fblnfroxvimevaluednuokbhkicrwvfpoarvwkllfecmawhl
 * Smoking Wheels....  was here 2017 ljonzvvvewqrdlpknybrdmpuzzmdiajycqnhrgaivjfrqwuj
 * Smoking Wheels....  was here 2017 rmfqkwzbuctvyugvyezbpjkvcotfotnwdmvwvclelzkvqfay
 * Smoking Wheels....  was here 2017 yaqbjmlljuoztwoyvrqlaadmrcwqjbapfuekreqjhhxuados
 * Smoking Wheels....  was here 2017 pvclcqycwycvivsbtqrqxqtdzvdgvgkrgwlwwwvmvueudifj
 * Smoking Wheels....  was here 2017 gchnxojknuoisyjpnjzrvrjjkhzhdxmuhkupjxklugzflnbw
 * Smoking Wheels....  was here 2017 sfbinpxxuxlpfvhigorwsvnasgfewwhxrgndggbhesissvjn
 * Smoking Wheels....  was here 2017 cuneuoamjzncigoficbttbvgwrumuffganhgzctkdjkgaost
 * Smoking Wheels....  was here 2017 tsbpwikhgcvlvilngdwdinfjcwzgygsjcryaewrjdvuyqhyh
 * Smoking Wheels....  was here 2017 gdhkfdypqmnpuiorxzwabsxavhhopoqxbhqsthfbytegbwbe
 * Smoking Wheels....  was here 2017 kkcpkkvczqeskxrkkjftwihatukwhzcxghtwvibpnfpubiko
 * Smoking Wheels....  was here 2017 ifookwnoaimfgvvtbdivxhcmxhkvtoipfuwhwdeiamgosboy
 * Smoking Wheels....  was here 2017 kkcsilsesoltdfkxlktbpufumcljbqxkvewanftvyarqhogb
 * Smoking Wheels....  was here 2017 eehypjhghqigaiwilokmoiwnxscqluqdecwjqfezappngspy
 * Smoking Wheels....  was here 2017 lvahwamjeaqxfucvchkktomnyxbbnuqrolgvjcexehavlnxt
 * Smoking Wheels....  was here 2017 kalzaerlcmccgkdhuldjglsyosjiyudjpirgebqxrhfnwktz
 * Smoking Wheels....  was here 2017 hsxpftqnbctmxghzbeedmencxigjwcspeeyqqpuqydpruwwk
 * Smoking Wheels....  was here 2017 tyaywyfafatbfrbkvwkudgcpniehlgfdhofhsjbyspzvutky
 * Smoking Wheels....  was here 2017 qeraqfpmcvrxlfjgcdzpchviblyoicryjlwtohcxzqjopdpw
 * Smoking Wheels....  was here 2017 zayejghvihfmcseogxfdmhljnrnuesjhyxmwoqxxwpzvfjbr
 * Smoking Wheels....  was here 2017 fihyhaxczkklzfvmxgudtlwbdidzckyqxizpiupoyyhvzyoa
 * Smoking Wheels....  was here 2017 vhgctrkrfkmsdcxovqosnfhaiwhgjucshklhvnprwlcxkufz
 * Smoking Wheels....  was here 2017 rgsrltyflwymuxeneqqcrhcdvbualqzmlzglesrkpbitgxgs
 * Smoking Wheels....  was here 2017 xwvyfvammmodnltigdkwlpbmpynzeavezfaxuorbjdiinqhs
 * Smoking Wheels....  was here 2017 vaynhzgqghgjbvweqilvdjakwuvaoigitmrripvhqentopcs
 * Smoking Wheels....  was here 2017 bwsdzhqayoibmjdqforzlafocbehxbbpukgbrkoydwqmvntt
 * Smoking Wheels....  was here 2017 juywahhgbugkbqiibmeqghbtzoihrchznxfpzbocuhsdeppy
 * Smoking Wheels....  was here 2017 xjvahrrehtvvgloimzjjucfcnhfprngtlbccqqtcwsarobdw
 * Smoking Wheels....  was here 2017 zoscyjmwplzyxwcvcevyjqrywmdezpmjliupjriquozhgmeg
 * Smoking Wheels....  was here 2017 fmewioqtgeztbgmhsmljqkpxorpevxvnqhmjzvsliskiwtvz
 * Smoking Wheels....  was here 2017 lndmesikqjjjydommnizpakwhribsijgiwlzrcptjbgmcxjk
 * Smoking Wheels....  was here 2017 shscjnzqmxvgckjisewihnuxakhkmxitcejfwpwvezurahjx
 * Smoking Wheels....  was here 2017 krgjayhpvrjahbgdzoseebqjyeufcyinvqcdevuhfxncwlph
 * Smoking Wheels....  was here 2017 cwjaoefquagpomsidcqpxcfwnmhqwbehovuznntaeqdeffen
 * Smoking Wheels....  was here 2017 pfzdqrwjxkzeffpqglwwjhxgndnbiayaqrtjbolcadrnuriu
 * Smoking Wheels....  was here 2017 bieadctqwqgetczcslsntqkrwbnegywysirafeuxztkcrdsp
 * Smoking Wheels....  was here 2017 udidglmnqsdgxecwbfvjjjrlupnxrepondjaovzboxuacecr
 * Smoking Wheels....  was here 2017 ktbjjxblkwviuupmdfalzvvesgakvfwpgtzqbfljkkpuqqma
 * Smoking Wheels....  was here 2017 rpgsdyqyrqwoqofqbznbkvisksschyuafcwlwgxynhuaaogv
 * Smoking Wheels....  was here 2017 thalkfqxdtykzgbjenpswfxevbrrvkqbzgrfjdgectpphiyq
 * Smoking Wheels....  was here 2017 yrtdlrtlthbmoykvbwxfrhlxdnczlzzfkphagjrrqjputljc
 * Smoking Wheels....  was here 2017 wyapooywulnsmzvnnmjqpkdowqmglepfovuciqpfvvmxxupg
 * Smoking Wheels....  was here 2017 jlswkhjwqtthyydfsyaglilxsepxivqauvoawwsapfgrnkxi
 * Smoking Wheels....  was here 2017 mwzeyolfbaoqnqkwxehqkzadpcloxahwsrfpegzigteaqpvu
 * Smoking Wheels....  was here 2017 pbfdhixbaexjzcxrtiumwouourgfedfgcuqwzgoweyrcnagj
 * Smoking Wheels....  was here 2017 hdynvvqtrnamjtfebtjymoyttmmylqexdvyccowjdpphskea
 * Smoking Wheels....  was here 2017 kndjglvwpplbxcebxbdhepyqefyfflftcqnwtdqabswiawya
 * Smoking Wheels....  was here 2017 bwvylxyhkcxpeztjrfnacrlhzxqsgorcpjzxifteemucktcv
 * Smoking Wheels....  was here 2017 nzlwoeqdccjsxljgxhdyqakcmvthpjckmleimeljynutfpld
 * Smoking Wheels....  was here 2017 kcqvzlwtxvdjewmflrudlazpcmufokijulgkctcocmrsxgba
 * Smoking Wheels....  was here 2017 poezkeusgvrrguzzkbqvljqrnqnuqniayhoqixktpmkrhufq
 * Smoking Wheels....  was here 2017 ezhnravxxvscqbxpdhcqtcalshyupunnlctwpvijqsgnkmnm
 * Smoking Wheels....  was here 2017 khhbzzsluvghdsnffnshuicgytibmmklfhqdoyaarsrlnzsg
 * Smoking Wheels....  was here 2017 zpuitfjqcdpdsckjmckxfnatqlcupfulhlkscyynmgmwdbya
 * Smoking Wheels....  was here 2017 rhslofydjgdwtuktzsgrxkfsnebjkvsnankeivuzziplbvlx
 * Smoking Wheels....  was here 2017 pacqkqxuhxswrpnidfrgbxkhozeotjoxzpghtultjehcioum
 * Smoking Wheels....  was here 2017 cqkmjmxsudhuipckmthiagnwycsepeucbbubxgcmdjcafxvl
 * Smoking Wheels....  was here 2017 siftwwxfdecoserjwsyanwtzebelgvhuhpewuxgzapsofpot
 * Smoking Wheels....  was here 2017 jmjnoicxtprjducakttojlmoyphtgdczbbuensmkyyelduir
 * Smoking Wheels....  was here 2017 crbbjnwsicsqbjkijscouylqfsbtjdnyypgvmxvadqroztsq
 * Smoking Wheels....  was here 2017 gwpxkkyrxsfziywmluqudpnpgsslqgccupjwiwknbeudbcmk
 * Smoking Wheels....  was here 2017 kdpwcegersmjxvcakhegcuyblcuxiyqfqrinzjrtlienwqsz
 * Smoking Wheels....  was here 2017 lwzycgzubpyzdpxqiywgogdxnpzpydggxsmkphiugdxjfkro
 * Smoking Wheels....  was here 2017 ktwnhknkvdjendhiqobjryuemhiehvekdwmhpxhzrvercuaq
 * Smoking Wheels....  was here 2017 qqobwnpdwjuqvkqhvilkwavgoibpjjagdodgopsyfymouily
 * Smoking Wheels....  was here 2017 urtjevdhmmkibvkaupvitaktdirynjolbjpmlcbnoeplwwcm
 * Smoking Wheels....  was here 2017 qfhmxtimcbtjoynhpaimgoznazxsfpxzffgqjiawrqnablgl
 * Smoking Wheels....  was here 2017 gzhtzapqlvnfupybpmjlnpgrcjtofehcfeslunnhunmekllh
 * Smoking Wheels....  was here 2017 btdrmppuluunpvbnkdmyyjdoqrmjpjigwsvzicskijzcejnv
 */
package pt.tumba.parser.swf;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
/**
*  A Movie or Movie Clip frame
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class Frame {
	protected int frameNumber;
	protected String label;
	protected List<Placement> placements = new ArrayList();
	protected boolean stop;
	protected TimeLine timeline;
	protected Actions actions;
	/**
	 *  Constructor for the Frame object
	 *
	 *@param  number    Description of the Parameter
	 *@param  timeline  Description of the Parameter
	 */
	protected Frame(int number, TimeLine timeline) {
		frameNumber = number;
		this.timeline = timeline;
	}
	/**
	 *  Get the frame actions
	 *
	 *@return    The actions value
	 */
	public Actions getActions() {
		return actions;
	}
	/**
	 *  Set the frame actions (or null them out)
	 *
	 *@param  actions  The new actions value
	 */
	public void setActions(Actions actions) {
		this.actions = actions;
	}
	/**
	 *  Reset the frame actions (if any) and return the new empty Actions object
	 *
	 *@param  flashVersion  Description of the Parameter
	 *@return               Description of the Return Value
	 */
	public Actions actions(int flashVersion) {
		actions = new Actions(0, flashVersion);
		return actions;
	}
	/**
	 *  Get the frame number
	 *
	 *@return    The frameNumber value
	 */
	public int getFrameNumber() {
		return frameNumber;
	}
	/**
	 *  Get the placements in this frame
	 *
	 *@return    The placements value
	 */
	public Placement[] getPlacements() {
		Placement[] p = new Placement[placements.size()];
		placements.toArray(p);
		return p;
	}
	/**
	 *  Get the frame label
	 *
	 *@return    null if the frame has no label
	 */
	public String getLabel() {
		return label;
	}
	/**
	 *  Set the frame label - set to null to clear any label
	 *
	 *@param  label  The new label value
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 *  Set the stop flag - if true then the movie will stop at this frame. This
	 *  can be set on the last frame to prevent the movie looping.
	 */
	public void stop() {
		this.stop = true;
	}
	/**
	 *  Place a symbol at the given coordinates at the next available depth.
	 *
	 *@param  symbol  Description of the Parameter
	 *@param  x       Description of the Parameter
	 *@param  y       Description of the Parameter
	 *@return         Description of the Return Value
	 */
	public Instance placeSymbol(Symbol symbol, int x, int y) {
		return placeSymbol(symbol, new Transform(x, y), null, -1, -1);
	}
	/**
	 *  Place a symbol at the next available depth with the given matrix
	 *  transform and color transform.
	 *
	 *@param  matrix  may be null to place the symbol at (0,0)
	 *@param  cxform  may be null if no color transform is required
	 *@param  symbol  Description of the Parameter
	 *@return         Description of the Return Value
	 */
	public Instance placeSymbol(
		Symbol symbol,
		Transform matrix,
		AlphaTransform cxform) {
		return placeSymbol(symbol, matrix, cxform, -1, -1);
	}
	/**
	 *  Place a symbol at the next available depth with the given properties.
	 *
	 *@param  matrix     may be null to place the symbol at (0,0)
	 *@param  cxform     may be null if no color transform is required
	 *@param  ratio      only for a MorphShape - the morph ratio from 0 to
	 *      65535, should be -1 for a non-MorphShape
	 *@param  clipDepth  the top depth that will be clipped by the symbol,
	 *      should be -1 if this is not a clipping symbol
	 *@param  symbol     Description of the Parameter
	 *@return            Description of the Return Value
	 */
	public Instance placeSymbol(
		Symbol symbol,
		Transform matrix2,
		AlphaTransform cxform,
		int ratio,
		int clipDepth) {
		Transform matrix = matrix2;
		int depth = timeline.getAvailableDepth();
		Instance inst = new Instance(symbol, depth);
		timeline.setAvailableDepth(depth + 1);
		if (matrix == null) {
			matrix = new Transform();
		}
		Placement placement =
			new Placement(
				inst,
				matrix,
				cxform,
				null,
				ratio,
				clipDepth,
				frameNumber,
				false,
				false,
				null);
		placements.add(placement);
		return inst;
	}
	/**
	 *  Replace the symbol at the given depth with the new symbol
	 *
	 *@param  matrix     may be null to place the symbol at (0,0)
	 *@param  cxform     may be null if no color transform is required
	 *@param  ratio      only for a MorphShape - the morph ratio from 0 to
	 *      65535, should be -1 for a non-MorphShape
	 *@param  clipDepth  the top depth that will be clipped by the symbol,
	 *      should be -1 if this is not a clipping symbol
	 *@param  symbol     Description of the Parameter
	 *@param  depth      Description of the Parameter
	 *@return            Description of the Return Value
	 */
	public Instance replaceSymbol(
		Symbol symbol,
		int depth,
		Transform matrix2,
		AlphaTransform cxform,
		int ratio,
		int clipDepth) {
		Transform matrix = matrix2;
		Instance inst = new Instance(symbol, depth);
		if (matrix == null) {
			matrix = new Transform();
		}
		Placement placement =
			new Placement(
				inst,
				matrix,
				cxform,
				null,
				ratio,
				clipDepth,
				frameNumber,
				false,
				true,
				null);
		placements.add(placement);
		return inst;
	}
	/**
	 *  Place a Movie Clip at the next available depth with the given
	 *  properties.
	 *
	 *@param  matrix       may be null to place the symbol at (0,0)
	 *@param  cxform       may be null if no color transform is required
	 *@param  name         the instance name of a MovieClip - should be null if
	 *      this is not a MovieClip
	 *@param  symbol       Description of the Parameter
	 *@param  clipActions  Description of the Parameter
	 *@return              Description of the Return Value
	 */
	public Instance placeMovieClip(
		Symbol symbol,
		Transform matrix2,
		AlphaTransform cxform,
		String name,
		Actions[] clipActions) {
		Transform matrix = matrix2;
		int depth = timeline.getAvailableDepth();
		Instance inst = new Instance(symbol, depth);
		timeline.setAvailableDepth(depth + 1);
		if (matrix == null) {
			matrix = new Transform();
		}
		Placement placement =
			new Placement(
				inst,
				matrix,
				cxform,
				name,
				-1,
				-1,
				frameNumber,
				false,
				false,
				clipActions);
		placements.add(placement);
		return inst;
	}
	/**
	 *  Replace the Symbol at the given depth with the new MovieClip
	 *
	 *@param  matrix       may be null to place the symbol at (0,0)
	 *@param  cxform       may be null if no color transform is required
	 *@param  name         the instance name of a MovieClip - should be null if
	 *      this is not a MovieClip
	 *@param  symbol       Description of the Parameter
	 *@param  depth        Description of the Parameter
	 *@param  clipActions  Description of the Parameter
	 *@return              Description of the Return Value
	 */
	public Instance replaceMovieClip(
		Symbol symbol,
		int depth,
		Transform matrix2,
		AlphaTransform cxform,
		String name,
		Actions[] clipActions) {
		Transform matrix = matrix2;
		Instance inst = new Instance(symbol, depth);
		if (matrix == null) {
			matrix = new Transform();
		}
		Placement placement =
			new Placement(
				inst,
				matrix,
				cxform,
				name,
				-1,
				-1,
				frameNumber,
				false,
				true,
				clipActions);
		placements.add(placement);
		return inst;
	}
	/**
	 *  Remove the symbol instance from the stage
	 *
	 *@param  instance  Description of the Parameter
	 */
	public void remove(Instance instance) {
		placements.add(new Placement(instance, frameNumber));
	}
	/**
	 *  Alter the symbol instance by moving it to the new coordinates. Only one
	 *  alteration may be made to an Instance in any given frame.
	 *
	 *@param  instance  Description of the Parameter
	 *@param  x         Description of the Parameter
	 *@param  y         Description of the Parameter
	 */
	public void alter(Instance instance, int x, int y) {
		alter(instance, new Transform(x, y), null, -1);
	}
	/**
	 *  Alter the symbol instance by applying the given transform and/or color
	 *  transform. Only one alteration may be made to an Instance in any given
	 *  frame.
	 *
	 *@param  matrix    may be null if no positional change is to be made.
	 *@param  cxform    may be null if no color change is required.
	 *@param  instance  Description of the Parameter
	 */
	public void alter(
		Instance instance,
		Transform matrix,
		AlphaTransform cxform) {
		alter(instance, matrix, cxform, -1);
	}
	/**
	 *  Alter the symbol instance by applying the given properties. Only one
	 *  alteration may be made to an Instance in any given frame.
	 *
	 *@param  matrix    may be null if no positional change is to be made.
	 *@param  cxform    may be null if no color change is required.
	 *@param  ratio     only for a MorphShape - the morph ratio from 0 to 65535,
	 *      should be -1 for a non-MorphShape
	 *@param  instance  Description of the Parameter
	 */
	public void alter(
		Instance instance,
		Transform matrix,
		AlphaTransform cxform,
		int ratio) {
		Placement placement =
			new Placement(
				instance,
				matrix,
				cxform,
				null,
				ratio,
				-1,
				frameNumber,
				true,
				false,
				null);
		placements.add(placement);
	}
	/**
	 *  Description of the Method
	 *
	 *@param  movie             Description of the Parameter
	 *@param  timelineWriter    Description of the Parameter
	 *@param  definitionWriter  Description of the Parameter
	 *@exception  IOException   Description of the Exception
	 */
protected void flushDefinitions(
Movie movie,
SWFTagTypes timelineWriter,
SWFTagTypes definitionWriter)
throws IOException {
for (Placement placement : placements) {
placement.flushDefinitions(movie, timelineWriter, definitionWriter);
}
}
	/**
	 *  Write the frame
	 *
	 *@param  movie              Description of the Parameter
	 *@param  movieTagWriter     Description of the Parameter
	 *@param  timelineTagWriter  Description of the Parameter
	 *@exception  IOException    Description of the Exception
	 */
protected void write(
Movie movie,
SWFTagTypes movieTagWriter,
SWFTagTypes timelineTagWriter)
throws IOException {
if (actions != null) {
SWFActions acts = timelineTagWriter.tagDoAction();
acts.start(0);
acts.blob(actions.bytes);
acts.done();
}
if (stop) {
SWFActions actions = timelineTagWriter.tagDoAction();
actions.start(0);
actions.stop();
actions.end();
actions.done();
}
for (Placement placement : placements) {
placement.write(movie, movieTagWriter, timelineTagWriter);
}
if (label != null) {
timelineTagWriter.tagFrameLabel(label);
}
timelineTagWriter.tagShowFrame();
}
}
