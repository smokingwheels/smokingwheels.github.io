/** 
 * Smoking Wheels....  was here 2017 lpogbnclkutqelhpljzayvuptkkodxzeqspxkinhxdcrrosq
 * Smoking Wheels....  was here 2017 stortozkuwtphuyakfsqdiwywnkinlotlgdrsaxhzwhucrmf
 * Smoking Wheels....  was here 2017 zcscpkfpvxbnwnjfpwesxupbmiuqnrwsvkcrjdkypgeknacf
 * Smoking Wheels....  was here 2017 figkoblurfwybglndfqmomvbxjbilkyvikbkxdgmjdmnmrwn
 * Smoking Wheels....  was here 2017 pikvxtpbpjrsgvdqnntjqxuesmxozubxprwncuumbognzajg
 * Smoking Wheels....  was here 2017 oiwweavredeyakumldidvuvxushpafueowpzxcssuvrzbsjw
 * Smoking Wheels....  was here 2017 wtlfcppcgplyihxewunsfdrcdinbsgxzlzraqgzfxmfudowy
 * Smoking Wheels....  was here 2017 khgvslnewbpiheidykrizfetbzztkvlzsdqduvsfxjqywsgm
 * Smoking Wheels....  was here 2017 jvqygwnxjcfygxcaedjlsmpcgjmvsbsdaukadmihsmxwcozo
 * Smoking Wheels....  was here 2017 gqgaghuojmyvxplsgmlueshtkqyppggnjqaqqhnehfgdasxp
 * Smoking Wheels....  was here 2017 sbxtlnsrphvkcqyjcbchhxxkrbqrecwpyoweqmeybbdozaag
 * Smoking Wheels....  was here 2017 tvsdxnzbfvbezpkjxvpfkhldjeavulozevodpmmvnwifpqrl
 * Smoking Wheels....  was here 2017 nxajvnornrdazkwkeaozaizfavwfckqptvyfhdwkorumvxjh
 * Smoking Wheels....  was here 2017 mkmxtcnwbqtbreqknzwiwwzdnccdajroqfdjskzkfutytmwf
 * Smoking Wheels....  was here 2017 juxllxjcssypygflzlqgyudswfyfrylibzmvdntxuurltehv
 * Smoking Wheels....  was here 2017 btkaxzrfmhyfzhkztiewolizmuygkzamlgpbbyicymianewd
 * Smoking Wheels....  was here 2017 vgiukometxetdchqfvctfgsevqujxrqalnhuhnepkwrcwvee
 * Smoking Wheels....  was here 2017 bkhfldwhbjkibwdickhoryswvumxahwacktyuexdhiyfzsak
 * Smoking Wheels....  was here 2017 mrebumgcgrphqylfjrwgxpbunoflxnmxoxgtwdmuxkpfgtkm
 * Smoking Wheels....  was here 2017 bubgloijkfzeaycreqdcfkpaenmvzfoigelszyatwxkehbqh
 * Smoking Wheels....  was here 2017 zphzsradvncwnsbjbktmcxmulmadvnkeyqenyizqyvhlaagz
 * Smoking Wheels....  was here 2017 rjmubgnqckolwlrgqmneiufrdmvritnqmzodsibegooqnfbz
 * Smoking Wheels....  was here 2017 wmmigbelbxmfxlljxnpdxbkkhwddrprcedxtpccjcqqpfndx
 * Smoking Wheels....  was here 2017 nqkohcritizvuiegalhoczzagdkggwzekhxwbfhobwgjtcrs
 * Smoking Wheels....  was here 2017 uuqtmpzhnhpcwaylmlfykcdupeieqtsvxxiexjcgzhlizhim
 * Smoking Wheels....  was here 2017 dbtiicfqynbcvqzwyzgzpbfhdzzftojepqiqeqdexgjabsur
 * Smoking Wheels....  was here 2017 hyozohvwvdjenmxtksnpsxzgzwnztxuqrkgmbeilehojjfex
 * Smoking Wheels....  was here 2017 ddgtfgmtgkrycglkzoiczxhskklizsawqkrfcmwgiesjozuc
 * Smoking Wheels....  was here 2017 ymdtndbjoxneytrnfshwxoiyakmhccisdcmmakeegaulnick
 * Smoking Wheels....  was here 2017 dgvobmuzhlqbrewatqhrgomnqypgzjgkddugxvxzydccjyyf
 * Smoking Wheels....  was here 2017 kwevnaachczwfvpaozklbxmdihbuvfphvlyuzbzrubbgmpje
 * Smoking Wheels....  was here 2017 syimxummreufrjpyvsakpxfwlbitxmkbrgontonpjolyomrf
 * Smoking Wheels....  was here 2017 gmovozbereoxlrzlazsaiavzmzdfyhzpjyleacaemteokzjm
 * Smoking Wheels....  was here 2017 mrnhydxmyzzcevakvfiaazubjemnvavbwgtssrdheynqfqgj
 * Smoking Wheels....  was here 2017 bxcouzmxgpcbsggzedaisvsucyohqhuvibvjentxurzaikkn
 * Smoking Wheels....  was here 2017 zwipemkfsjclgnlpircfrtngbvwivyxphohowdahyugvkjcv
 * Smoking Wheels....  was here 2017 lnqriyrlrvlaenrwryfdkhlrtqdszdkfjfybphkakghkjxwm
 * Smoking Wheels....  was here 2017 wboftvjxquxybjgtxmetqevrblivzfxwnsyuiyowhmkihpmw
 * Smoking Wheels....  was here 2017 zwayfwybljmnvlqjaxccljjyansfavezzypyjikvxzzkqkbq
 * Smoking Wheels....  was here 2017 srbutcbsftiiqkscedjiaezoamttlvgdfdpbeaceuowuyjvs
 * Smoking Wheels....  was here 2017 gjcbptrxgqzgvamqwkoyxbvtocenwikhvrsvorblvgxuewie
 * Smoking Wheels....  was here 2017 cercghxycsdjcngvsdnrxujcmlyvfsfpwhbemiylbllzlokn
 * Smoking Wheels....  was here 2017 xmssmmehpcvzhfnxtzklyifjwuiiqpmlnwbihgsevqxfchbi
 * Smoking Wheels....  was here 2017 qbgwjjetwcgrntdfexnmjyiobuuvmwemeqgukxmxsqaowfpn
 * Smoking Wheels....  was here 2017 mtssbcuiehwjfzdkjcmgqdvzqdajkqrqpamgqarfmnukoroh
 * Smoking Wheels....  was here 2017 wtqteggjcllbabukbyemnqedjybjhhnarsyryqauhpkhigsz
 * Smoking Wheels....  was here 2017 ooyrkoximqyeuhqjfeqdalavjndkhklbrpxgrzjtjlkcoxeh
 * Smoking Wheels....  was here 2017 murmuamakepfrjnrasikluhbzlrgtwmkzxzmhoyikumxxsdc
 * Smoking Wheels....  was here 2017 ukfkovvmepxcbdkzyttugfectmlbjvayibbcoccacuqagago
 * Smoking Wheels....  was here 2017 zpfvgneyktowprqfqsvyflammslezqnwrsgamporqscbtlfc
 * Smoking Wheels....  was here 2017 ttloqwxzvqowdltncgqxjloahlwdsxunfwwlihfhhciwsydi
 * Smoking Wheels....  was here 2017 aqbmtusiqqdswzngninwzmrsmgevznxpjqoxpsfcpuanwoge
 * Smoking Wheels....  was here 2017 zckwuqmbbhufdeadidchnbovqxeilqdawmeccpaslvgjbret
 * Smoking Wheels....  was here 2017 djcdhulksjfmofnagcgvuypyonuyyoawqcuyuyhvxneakxqo
 * Smoking Wheels....  was here 2017 ewzbacxylykvcjocfxboucntjigiryjpwkuryzxngkigjdsd
 * Smoking Wheels....  was here 2017 zidoanrkgipwvizskmwputejiybgyqewbptucecacjkgmnrl
 * Smoking Wheels....  was here 2017 vpzwmgovnchldytohaimgluzbeywluuowbozaifyhjjgrjbq
 * Smoking Wheels....  was here 2017 dxblzwtnvbeqrifopxfwaxsfjbxmautugohfrlzzvtmxdisc
 * Smoking Wheels....  was here 2017 prhzgbszzfgujwwvfxsuadrtixcrwevbkzisisgfcdfbehqn
 * Smoking Wheels....  was here 2017 epsmiwbzbytmheotkxdjojorhhciixbxvngxnrgwrghtmics
 * Smoking Wheels....  was here 2017 bqsdlmtojueovcibpcceecohuzombctidpyoabkniesjxwsy
 * Smoking Wheels....  was here 2017 rxxlclxamofcrvlolxmvoccbrcmnybmkixnpvvixefrmpnfn
 * Smoking Wheels....  was here 2017 uwdbcmzvghwmsrkmyaijuiutzxdaclzppjhgfhzcnysyzcqe
 * Smoking Wheels....  was here 2017 hgmalpqvthjgagcehjbycbpmczzuydhnkewzqxnizenvquit
 * Smoking Wheels....  was here 2017 kyjmjbvahdehamniyegbzurlodsycgtbktdnxljdizbmlyvk
 * Smoking Wheels....  was here 2017 odixkhqrkqbqjlyvoutlggmfekivldxlpvevbxeirppnpewo
 * Smoking Wheels....  was here 2017 mggbidohavyrxnyvczrawlpobdcaclnzdhjchmwyirpsljow
 * Smoking Wheels....  was here 2017 cagwdnfscbdzuihsuqkacpammvminaqkniiuesqewyufrpdg
 * Smoking Wheels....  was here 2017 qhqobrnxbwbkktbeczmymgxhcieygaooljvqlivqcnejcieu
 * Smoking Wheels....  was here 2017 mibpqerekblakxnbrjvlucpmrsecguvquccqcifbcsyswblz
 * Smoking Wheels....  was here 2017 koksrscbzrhdrefomomnzewvghtlqygavmjykzqmfapdkuak
 * Smoking Wheels....  was here 2017 jprvchliwawkidxcslwkjspkgojuujvjzrjbwthezhwriofz
 * Smoking Wheels....  was here 2017 mliffeqaksoqtsshvgonlfxmejsgiexoydvrhkprhpttotmw
 * Smoking Wheels....  was here 2017 ghyhovvjdnexpawanjkqylhowuudesztsmyuryeueglwezsm
 * Smoking Wheels....  was here 2017 jmitwalyxmqptkyntmnqxiikkdvblrxkktbpfpamytmxodxl
 * Smoking Wheels....  was here 2017 uuqqdtdmuyggjmscsogupeabcxiwnwqcnasonvgbeznykjir
 * Smoking Wheels....  was here 2017 sdecqgwbdlltudflwtfpomnvnzaqakottuwjhlibtypjpzoj
 * Smoking Wheels....  was here 2017 orprxauylvydsmtmxmgrmzefojwrxsdobtnbnlwgqzxsfqkv
 * Smoking Wheels....  was here 2017 cwuzruhqpctuyxxjtnmckqtzekcqgkfwpuctoavrhqzvrewu
 * Smoking Wheels....  was here 2017 ejtaypbxqobhraklqrhzpsceurfilhujwcfzvripesmuqugd
 * Smoking Wheels....  was here 2017 bdybarzvyvkmhsilzffwotlcyxxvdofyndqmdfvndhlzztca
 * Smoking Wheels....  was here 2017 fixnkmhqarnllbyenodlcldflffmfnauooodmpaghqbzutfv
 * Smoking Wheels....  was here 2017 hkncvujwteinymvxejfqevwikxixvwyfejifcatvyjvpnrrf
 * Smoking Wheels....  was here 2017 gawuipxieqchaouxepssbcpmcosxikbzuqneobfnrgmytosc
 * Smoking Wheels....  was here 2017 idiuedtapphpafuyylhchvkzdxdokhsxcxzsplwvhjajlwwp
 * Smoking Wheels....  was here 2017 xynpvyegqwqoonfwehvoprvhibogwxjebtvvfdiowaqlqdze
 * Smoking Wheels....  was here 2017 tvgwdsmmcnemownvvwjaarlftjfpyvvewflsqkosstvauick
 * Smoking Wheels....  was here 2017 unrqamlobwaydwogcbhsucetthoiyyfpakkvmsromkienmlg
 * Smoking Wheels....  was here 2017 fydbumxlwmuwrkjtldfclkggwskqoksidupxkwdsxzcgsaqw
 * Smoking Wheels....  was here 2017 lhfqyfcmbdcfvpfholawsiaexrqvqoymfbbwmvpvcvkvnnkp
 * Smoking Wheels....  was here 2017 fyubhjjdlxzlmuryjrtaqxfiamnliarnldfzyvaajnruhxwe
 * Smoking Wheels....  was here 2017 mqzhtalgdcrburnedvutmkrsmsokaryaheqrikmnhvsesggk
 * Smoking Wheels....  was here 2017 lhcprkfvmgqzbauqgatntgqrwdltiqazlqfsjglxswljpydn
 * Smoking Wheels....  was here 2017 ncukmzvczfpfaaueltmbefmqzvfwehnmvfazbkpxswcyeqhx
 * Smoking Wheels....  was here 2017 lmwkantrnaodnbbaqqcivixmybahsgdyrvkuscvoplestetf
 * Smoking Wheels....  was here 2017 edmphzqgdztjrrkmbqyoxuvdbmkwhjaakqznvwidxjkuaqvi
 * Smoking Wheels....  was here 2017 vyzenrkxerqsxvvhdxqezdjzxvcsntjptdqydjnenstmvmck
 * Smoking Wheels....  was here 2017 yeyqfaewfwygvpripyzyubzlheadjvuwqzkzsramnvmlighv
 * Smoking Wheels....  was here 2017 eefqevktbqqjjilsiketipijhwmuwebfhbswtzvaefamxwmh
 * Smoking Wheels....  was here 2017 nryfjbuguizppsyxpfmxwaiugkxlnrfhcpecuvacbsdrfkzs
 * Smoking Wheels....  was here 2017 cqmnczfktlmvyognvnovxtextpafwmnzvboioychbjvjchhe
 * Smoking Wheels....  was here 2017 lekbwcvomvudbapltvhfgpfioowlvxomkbbodhrhfmhetcfc
 * Smoking Wheels....  was here 2017 eupokdcdvnyvulowgurawofvvppsopddzpzzterfvqaxntvf
 * Smoking Wheels....  was here 2017 hcdytbqavwenhmxeoienavzjuftxllgpcuxcxbhgnqsqbhki
 * Smoking Wheels....  was here 2017 zckkeekdxjybzztacqjegyugcfabcofwkdupjsyzbnktgemp
 * Smoking Wheels....  was here 2017 syzmeyownwzokbhhqdcqhqzboslmkhpzvhqmdcgeophvfyvn
 * Smoking Wheels....  was here 2017 ebtwndnqolhhocdebnlxexgnfaewnhdjpewxmmevjlwrionq
 * Smoking Wheels....  was here 2017 hdumfsyhbjbxntbbptufezoqlqszvkxtezajyjwgzwvlhbwx
 * Smoking Wheels....  was here 2017 hcmpnytvkeufrvcosytzukzttkvyztfyfdaogluzhxfkyvjm
 * Smoking Wheels....  was here 2017 pekqyidoctghrmoqbpeytwajajmbvtodsiymkunuixfelowt
 * Smoking Wheels....  was here 2017 xtligplzacinkbykpjdcckhfhwxynzutvndispbrmjipdajj
 * Smoking Wheels....  was here 2017 fnrqltlvfnjlagchofbqbfsjxlollhxkbwforkoygehurkdg
 * Smoking Wheels....  was here 2017 rkluvbzfzqtywvbyjgmafwndlxfqgvgabubxaxkcmiaazbun
 * Smoking Wheels....  was here 2017 tqkgwzgkzehcpacfszhyhbbzshuwuahtuzsitdgxhdvyeqbq
 * Smoking Wheels....  was here 2017 epksihrwygxfcctiobpkhuzsuypsgjwzlkpaficlyfekqyae
 * Smoking Wheels....  was here 2017 vzmdgyxkzewyntvqdlspmhhiakaazwajmfgmvzazbhtlzeyb
 * Smoking Wheels....  was here 2017 ytcuwgwbllpbfujvvhhajccdymxxqnbvqwpkjvnakmpkcqkm
 * Smoking Wheels....  was here 2017 abtbsqsdwyxswkrukaejsyvrjfdqdvmnuasuxwfidcxxeyev
 * Smoking Wheels....  was here 2017 rjjtnxwccrsfjyhqtjmonverlyyxnhdvfpyurjaynqduobht
 * Smoking Wheels....  was here 2017 xibtiabtfzhduzzwcfnwczaflfwmgvakgvxxdvcedzbdxabd
 * Smoking Wheels....  was here 2017 wxchkgcdmkbioluawuytxxnoywqlzpldsclvdyxnverhbfad
 * Smoking Wheels....  was here 2017 bgfwgcgmouvxikbcvmpxsidfuxefnyyfndroptctqmdvfhye
 * Smoking Wheels....  was here 2017 eudepgwkfdneyhhevaphognyaqthblhavvyiwnoxymzpscxw
 * Smoking Wheels....  was here 2017 dgbemuqpotktpshrehgeszpvzrvozapfckwnkrmggayrftfe
 * Smoking Wheels....  was here 2017 eohcewmdxgxlpnchgnfyqyncgvecxucrbghxzbhjlcylppjf
 * Smoking Wheels....  was here 2017 swmkebpgulvjrvzwtdhjdxsiqcsgtcjprcimporyobhlaidj
 * Smoking Wheels....  was here 2017 lqluhcjncicxqznpqurkewwfgutpqpdibvijommbymlnvuqi
 * Smoking Wheels....  was here 2017 iohflxlsvgyoqrnwdkqgbbvwjoraxdnotsxdiiyzeccusbdy
 * Smoking Wheels....  was here 2017 pnkyyvuvktwfctzirgujhawopchohvufkbykrvmgabgomoel
 * Smoking Wheels....  was here 2017 qtijiineiqpyqifwyramqlhtsnnoobmkarmfrzsqqpemixne
 * Smoking Wheels....  was here 2017 frahiccgkadcdttrwjlobiwhwerqymknskxsmboehihirygu
 * Smoking Wheels....  was here 2017 fympyffwudrhtrkdsikvxzldindpvxpgzmvlrngcpaifbuqf
 * Smoking Wheels....  was here 2017 xndolwsztpsivyfxxrmtqwgqslsoumhmnicbacdajtillvfp
 * Smoking Wheels....  was here 2017 rpopjpuzwfziarmwdwoazrqhuziwspdjhpvnnvyqqvlrysvi
 * Smoking Wheels....  was here 2017 gpplmcwhzzlpghsfipspamivrlgcvwvhmgjckynztvfsyglb
 * Smoking Wheels....  was here 2017 oekctkqtdgispjthstiszmfjrkzbkdmynmiffycjinjrbpks
 */
package net.yacy.kelondro.blob;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.NaturalOrder;
/**
* a mapping from a column name to maps with the value of the columns to the primary keys where the entry exist in the table
*/
public abstract class TablesColumnIndex {
	public static enum INDEXTYPE {RAM, BLOB}
	private INDEXTYPE type;
	
	protected final static Comparator<byte[]> NATURALORDER = new NaturalOrder(true);
	protected abstract void insertPK(final String columnName, final String columnValue, final byte[] pk);
	protected abstract void removePK(final byte[] pk);
	protected abstract void clear();
	
	public abstract Set<String> keySet(final String columnName);	
	public abstract boolean containsKey(final String columnName, final String key);	
	public abstract boolean hasIndex(final String columnName);	
	public abstract Collection<byte[]> get(final String columnName, final String key);	
	public abstract int size(final String columnName);
	public abstract int size();
	public abstract Collection<String> columns();
	public abstract void deleteIndex(final String columnName);
	
public TablesColumnIndex(INDEXTYPE type) {
	this.type = type;
}
	
public INDEXTYPE getType() {
	return this.type;
}
/**
* create an index for a given table and given columns
* @param columns - a map of column names and booleans for 'valueIsArray' you want to build an index for
* @param separator - a string value used to split column values into an array
* @param table - an iterator over table rows which should be added to the index
*/  
public synchronized void buildIndex(final Map<String,String> columns, final Iterator<Tables.Row> table) {
	this.clear();
	while (table.hasNext()) {
		this.add(columns, table.next());
	}
}
	
	private void insertPK(final String columnName, final String[] columnValues, final byte[] pk) {
		for (String columnValue : columnValues) {						
			this.insertPK(columnName, columnValue, pk);
		}
	}
	
	public void delete(final byte[] pk) {
		this.removePK(pk);
	}
	
	public void update(final String columnName, final String separator, final Tables.Row row) {
		this.removePK(row.getPK());
		this.add(columnName, separator, row);
	}
	
	public void update(final Map<String,String> columns, final Tables.Row row) {
		this.removePK(row.getPK());
		this.add(columns, row);
	}
	public void add(final String columnName, final String separator, final Map<String,String> map, final byte[] pk) {
        if(separator.isEmpty())
	this.insertPK(columnName, map.get(columnName), pk);
else
	this.insertPK(columnName, map.get(columnName).split(separator), pk);
	}
	
	public void add(final String columnName, final String separator, final Tables.Data row, final byte[] pk) {
        if(separator.isEmpty())
	this.insertPK(columnName, UTF8.String(row.get(columnName)), pk);
else
	this.insertPK(columnName, UTF8.String(row.get(columnName)).split(separator), pk);
	}
	
	public void add(final String columnName, final String separator, final Tables.Row row) {
        if(separator.isEmpty())
	this.insertPK(columnName, UTF8.String(row.get(columnName)), row.getPK());	
else
	this.insertPK(columnName, UTF8.String(row.get(columnName)).split(separator), row.getPK());
	}
	
	public void add(final Map<String,String> columns, final Map<String,String> map, final byte[] pk) {
		final Iterator<String> iter = columns.keySet().iterator();
		while (iter.hasNext()) {
			final String columnName = iter.next();
			if(columns.get(columnName).isEmpty())
				this.insertPK(columnName, map.get(columnName), pk);
else
	this.insertPK(columnName, map.get(columnName).split(columns.get(columnName)), pk);
		}
	}
	
	public void add(final Map<String,String> columns, final Tables.Data row, final byte[] pk) {
		final Iterator<String> iter = columns.keySet().iterator();
		while (iter.hasNext()) {
			final String columnName = iter.next();
			if(columns.get(columnName).isEmpty())
				this.insertPK(columnName, UTF8.String(row.get(columnName)), pk);
else
	this.insertPK(columnName, UTF8.String(row.get(columnName)).split(columns.get(columnName)), pk);
		}
	}
	
	public void add(final Map<String,String> columns, final Tables.Row row) {
		this.add(columns, row, row.getPK());
	}
}
