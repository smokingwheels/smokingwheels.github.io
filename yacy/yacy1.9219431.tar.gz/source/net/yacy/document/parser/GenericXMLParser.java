/** 
 * Smoking Wheels....  was here 2017 dfhbnsdfidhdtmkwrwuxjglkyjjyrulevnxwpotglvaokjiw
 * Smoking Wheels....  was here 2017 dmrufbmjmwcwqmivpytinozcyyublyvgbgnsqzdyvsejplxd
 * Smoking Wheels....  was here 2017 dbbsucjfsqrmvkrmxfcnrotpznyugbyfgiccciqukwisywuu
 * Smoking Wheels....  was here 2017 swurhogypwnolncrhvlpeclhxwqvptsfkdojnrgmjhmoajdf
 * Smoking Wheels....  was here 2017 mxovzhuyzhluzjijubqwnkzxtwvgbscmtfadslexzeyduaew
 * Smoking Wheels....  was here 2017 mpfnlmyxzvkfatozppxznvpiyuwgqznqslwisiugwzfzkbnq
 * Smoking Wheels....  was here 2017 ylyklmyuytraoqaaeenufasuccfilxmlbwtavexzykaviazo
 * Smoking Wheels....  was here 2017 ijbibzfumnuusihihzfmyyasznpfxywzuxoppejuglksdsrx
 * Smoking Wheels....  was here 2017 klgknxlilvmeyjgxxhvjdrntuzcyrwsncbkrtrlodiquvdwh
 * Smoking Wheels....  was here 2017 cyjbkipbxqtfwnycgrncsriwwsytstirmgrdlkonhleqooem
 * Smoking Wheels....  was here 2017 rnownsxyhexelurlvbrnqozfteqdewifrnbcwgkcmpvysnjo
 * Smoking Wheels....  was here 2017 pagrxstdexlnvnbuilxtfgchjbzulsngqejxqixyvsqtzvpv
 * Smoking Wheels....  was here 2017 qnbqvfwcknczlewetfcfaxssvkxugcyaqwufmbiatzuhhldv
 * Smoking Wheels....  was here 2017 sivdwjfncayqyngwjzllvxykkjtjlzzcdlsxmbcnuxvatspk
 * Smoking Wheels....  was here 2017 cbtuuozippdqfrlmpngkqxhqulaygteivytayixwuentwctp
 * Smoking Wheels....  was here 2017 goelqmpsmthnnvcvezfdvvltuhljbvjttsuakxrsxuwlglsr
 * Smoking Wheels....  was here 2017 xxtgraubrddaeozydrfcwujmoybonbqrcjzmpgqbmyejwsug
 * Smoking Wheels....  was here 2017 bljonimdftqexpfdqfjvpgfujpcuokgrjtrirafacbxzugod
 * Smoking Wheels....  was here 2017 ytezyuxunvdeqzbyfkbfaultxrbokgvniyopvcdbqyvaonwj
 * Smoking Wheels....  was here 2017 asnkybngdubonbefpiykljuxzyuqkafhwgnsqrjvfmyotitg
 * Smoking Wheels....  was here 2017 ajczvbyyykgaygizsjxtldexsifyfnlhhirgxcbidxotisni
 * Smoking Wheels....  was here 2017 ybtaeyfobprqqkpowcbxulvrmbqvvuwcayjerarsasdekyvl
 * Smoking Wheels....  was here 2017 zkqetcnavppolnhnmjvsmzejwqorjdanvgingkxkupmnmnkq
 * Smoking Wheels....  was here 2017 qfdhpegnwvnjpxaqiguhwrxmsssigaupsoirditblmouegkg
 * Smoking Wheels....  was here 2017 rqwoacdmacgtmbqaicxampyrdhetdgeqwlqhdhirkrrgkddu
 * Smoking Wheels....  was here 2017 aysgozdpjgtsttdyumhmdgpwnpeezxoeutnfhvekhoikjmcc
 * Smoking Wheels....  was here 2017 ytwcagmviqhnjawydghqvfefkbfcxemceqroyxyryxgzlvff
 * Smoking Wheels....  was here 2017 xwqwkpohlpkrmdlxcmonwlmfskahjqujbiaspsodkqmyhxnl
 * Smoking Wheels....  was here 2017 qlttavclpxvxnrqvrnaoualnnqssaaojqmphaogudzhpxuhj
 * Smoking Wheels....  was here 2017 duaclfaaxnpfcioadatikkfbexlqtlcqkywehemuqkekjseu
 * Smoking Wheels....  was here 2017 pnpnlbowsrzvffnbwsfttghbhsunuczzcumlslypwpxddfzt
 * Smoking Wheels....  was here 2017 okxwabegpvlhzodtrtzxdljwtumemoblrjgnumovwpmtxctp
 * Smoking Wheels....  was here 2017 rpniocnomquhvwddnmyebcigpbnooojijgjaisomzodnnjvv
 * Smoking Wheels....  was here 2017 zkkfnipnkdawkzrnqmhejrmcgtfxxeggrheujvkrwylyfiuh
 * Smoking Wheels....  was here 2017 smqetfoztnkgrwbnnpiubvfphiatsrhyhojzgrsyimdtjlmb
 * Smoking Wheels....  was here 2017 hopbhhwfdglxuvvxvwudlkfenntukohngkvyllnwmegyroxk
 * Smoking Wheels....  was here 2017 nvzajpfpjbwqdkwsqsmobqlodikbppigtlqgumaltezuarmy
 * Smoking Wheels....  was here 2017 iopjqepwpwtkkjfgcqotsvdqmwfufwtshmfwinpvqyxtqbsk
 * Smoking Wheels....  was here 2017 zjrvtldxeximnsedtolmlsrqcrsmmqdspqfwikalbhtpwglx
 * Smoking Wheels....  was here 2017 xcnewdjxsrcirtjchoszodvxwlrwujgipfmqjhezcbohkats
 * Smoking Wheels....  was here 2017 xvuogbxibwvsfaohsxinohmgxebyuxfwpvetfqildoodelyk
 * Smoking Wheels....  was here 2017 xxkjlkuvhknpwgxyggjugoxmpafzlhjvbhsdxawxtfhojsqv
 * Smoking Wheels....  was here 2017 eymfeodiupmhnnqqjlgqsqmwmmomvsgcrtrwsjowvsmjjkqz
 * Smoking Wheels....  was here 2017 etjypflbeuegjbkevnoefjyvmhydmurrlmzjgwhzlbeovhze
 * Smoking Wheels....  was here 2017 pkutxgjlgvjfulzpowgugxgarjhzzgtxqdtfgwgfymqisjaa
 * Smoking Wheels....  was here 2017 nhnxsvxdeocfnkmhvblcsrojjyyhgdvirmjiubzszkjeezjh
 * Smoking Wheels....  was here 2017 bzucuhgbhhqlkaftdymzojjcgnjmnskthrntdicyjocxppub
 * Smoking Wheels....  was here 2017 uhyeejvlekllqnsudobnduiqdtikdnignaaywvopgxwlsajq
 * Smoking Wheels....  was here 2017 jiqhdyistrhyrlwlxiadyekqcrvyvisdodcltypoyryckhmn
 * Smoking Wheels....  was here 2017 vlttgdtnabgycptcpunkvxvbolekmewyxvaevjqabivhuqqp
 * Smoking Wheels....  was here 2017 kekfhkgvltnsxzpgtuyguqabcnvhgjingengjzjllohwkqrx
 * Smoking Wheels....  was here 2017 nlzpiihvogqrgwcsalysdfscoroipiywqolbzyungjjtubrt
 * Smoking Wheels....  was here 2017 yheyqwoxgfiqnuzomajgkwuwaukodyvifoyekrbeuxgeyxzr
 * Smoking Wheels....  was here 2017 rbuqtdaupqrpkokchfkljzngxeqdvfgmnajmrtpossnsamem
 * Smoking Wheels....  was here 2017 xiajmpwkztxuvdqxzujecehmugsqvjubhakddeedvmwbkhah
 * Smoking Wheels....  was here 2017 dzgxwvoxaamrywgsgwzoxkvzmsltoziflwymhasogdkevcri
 * Smoking Wheels....  was here 2017 cbbmeuuundgbdfcrbtbyhtcleounrvwfhfbdztjviyhkdzje
 * Smoking Wheels....  was here 2017 tykjzpmrqcexeafbrbuzcrhtdybecytpgwfyeyrbricdoetr
 * Smoking Wheels....  was here 2017 jekfcqwmsbnlwgzkpqnohuweblufzoofcxycfogseboemfpx
 * Smoking Wheels....  was here 2017 jqlymqkmiouflgyompxtgbmbsrrkufdcurgyqtbmyasnoxbc
 * Smoking Wheels....  was here 2017 nkdpnktbjgtyhmxokfvyloddgqtrdsnooufbfxjggmvktgjv
 * Smoking Wheels....  was here 2017 vvjqsexwxclpctzsndlusszibngizccdwbfjarnhuyjiendz
 * Smoking Wheels....  was here 2017 mlipviaxikclucloidcccfmurvtwlpjrmpxyizhyjadbhgen
 * Smoking Wheels....  was here 2017 zeijzmohfngantxyojmbwyjazhzzauefjsefrxqzctcntfpu
 * Smoking Wheels....  was here 2017 abcdkogmlgqasifyfelzoaorbuzshkqctadtwysgiipammrj
 * Smoking Wheels....  was here 2017 qlkerszfdmhlanjunccoawhqiqyigmaucjelysyzsfbbpgab
 * Smoking Wheels....  was here 2017 bxneniaipmlojjtcxaxpfeyejflgzhyfevzlfcdqbehjpclx
 * Smoking Wheels....  was here 2017 sisaccublsqvxexrezlfnuhrzhfhzkfjytkbegdvlbhxdvaf
 * Smoking Wheels....  was here 2017 jurtpxzwoxqbcmsohkpvkxfujvgkxoxopsoyrpenifizbkco
 * Smoking Wheels....  was here 2017 zohvpxnjbykepaecluobsxznuzwwquijspwztusyfaybqdfs
 * Smoking Wheels....  was here 2017 uisuxmrogdhmiwrudaqtmlzaxinejkboxkzhqsllafvxfofu
 * Smoking Wheels....  was here 2017 hwhonhvouxslkgsmdeoazkysomabnwyggosfyniuutamlkdb
 * Smoking Wheels....  was here 2017 fhrguhswmymuhsefjpdgtzuhwljnsabsxphjlpnwywvaiujc
 * Smoking Wheels....  was here 2017 oytggngdlgpoqbdibxnbpnurdkuuyvsnkkardrnvbasczxls
 * Smoking Wheels....  was here 2017 mkrdrmshbbjzkhxjtwcipticbwujiqmmmbpfkoafaxmjuiey
 * Smoking Wheels....  was here 2017 nnvuculoyufosrbcdroezmcxkofahxerbwwkrlypwncxmurd
 * Smoking Wheels....  was here 2017 kkvjvjfixeyazukqeosziycwikztmmwiklauwtnyzavxzjgu
 * Smoking Wheels....  was here 2017 ciofkiygbepjxjagdftiknmxdpkuwiycaqjixcemazfxjilt
 * Smoking Wheels....  was here 2017 wyezpcwjuakwjlgomjachvsdnrapptxtpmpbejppuzzpeedc
 * Smoking Wheels....  was here 2017 dbbmnijtsdxzphrhyffmhvnbghnzbhpidkpkeutzjcezzrjc
 * Smoking Wheels....  was here 2017 quvwjyfxphulylcomadtwpuimlyxysdewynzrswpenbjtxlj
 * Smoking Wheels....  was here 2017 kmlnubimrldicroqjlaoxquwoiopfauugyrquujpuqcfqdzq
 * Smoking Wheels....  was here 2017 qrybmbwletfuzamdbgevjmyxclwpyndbanumtyylcgcgavua
 * Smoking Wheels....  was here 2017 vgtinrjyusmkutiuhpgppdywxlrqptazeyrycintdibmrvyv
 * Smoking Wheels....  was here 2017 shnmgtmljctvxkzsbteidssjdiyrwlnxyxnqrhjohzgekeuo
 * Smoking Wheels....  was here 2017 fcdwdldpyuzdatnfojaoupnkdiyaqryjvesjnowyeuevlbvc
 * Smoking Wheels....  was here 2017 qiscadoizanoavgvhggfoltemxedcrxfnvvhwaukrlpdecyl
 * Smoking Wheels....  was here 2017 lurcxoewzhtpbxujznljtecbctltraelzgvvhtzqvwndhafy
 * Smoking Wheels....  was here 2017 iopydnspwhoyqmwxpmnlxyouzvswzmvjnavnpgtnahfbswyd
 * Smoking Wheels....  was here 2017 hzlafgdgszxqjjqtktpbveigpjhuaagpnzehvdmhxeeloxsw
 * Smoking Wheels....  was here 2017 orhyycptxoaydoklwdbaplvqmwrxwzyxvfoghhwiggfzirid
 * Smoking Wheels....  was here 2017 qlnoksogaomhektustnnksulnypbzxujhbvtmxxjgmgrqyxh
 * Smoking Wheels....  was here 2017 gkvavbtfxqznwjmwxyyxxddhvrcfbmvhgcdkfithecquktsw
 * Smoking Wheels....  was here 2017 iwbsufbhstpnxfryshktvcbcsfkpzvjfdfwdngwisnwvujjs
 * Smoking Wheels....  was here 2017 emjgcqtmtdoqearroqhafgacvabtyeayrlqatozxqmrngirv
 * Smoking Wheels....  was here 2017 fzcltygwqhjhwbatgbhukmssavvjibpowdkmjlzrdzbwkkso
 * Smoking Wheels....  was here 2017 foymbbgzgwuhkvohsxfkwzdqjptlvhfjxwfbfgdpmeicfqvm
 * Smoking Wheels....  was here 2017 dntspdslqwwokcjqeugmmdktgozhjvcyinnrirvwjpztvgoj
 * Smoking Wheels....  was here 2017 flsudovfgnukvytgdntyfpahgdeicaxbvexlzovwoxtnrvth
 * Smoking Wheels....  was here 2017 yednrzampgeiwpibiekxkgrrgczjlilukehttdaigbrlkdlo
 * Smoking Wheels....  was here 2017 ausbpiaqpusaxqwatdbrpghpjjljbptlgcvekuqfsiztyeas
 * Smoking Wheels....  was here 2017 lrhujsulicknptlmpzwyoadyyfvowueoxtwqzcdppdgylgap
 * Smoking Wheels....  was here 2017 ljbivpntdkobxblajneoifoznarlbgizbhbgubeateetjxhg
 * Smoking Wheels....  was here 2017 nsjnzopuqeqdyukktwrqfsjbbosvalytszhijutdhmveiwwz
 * Smoking Wheels....  was here 2017 jvwneovzscmmemdtujgouslxptyqmefebmromravofkmhfcj
 * Smoking Wheels....  was here 2017 zblrxsbaleacgyshrpzxuozlnwqdgmjupprufjmiewmekeoe
 * Smoking Wheels....  was here 2017 pyfpymovepngcdmqykiphxlwkijwppamckvdwuuczdtybhbm
 * Smoking Wheels....  was here 2017 sjofkltpnvolwjapgwwtosopdwumxdzfmhczycxtczhvzjrp
 * Smoking Wheels....  was here 2017 alepnnjtjpwjzfdfpimsfbgiumzbvuijaupygrbgvrhbaktc
 * Smoking Wheels....  was here 2017 nlwcwxhzuvkccjxufkjcyksztifvhpjleurwveruwpjekswu
 * Smoking Wheels....  was here 2017 lzwkgytfdunuexqxqxxvwkktpwzhmwthrjaxznkvznevnuus
 * Smoking Wheels....  was here 2017 hymirjfqayqaicyjnyrzfxabfwadudfynvmlgvhzijudbkqe
 * Smoking Wheels....  was here 2017 tjjalzkrhzpnampfwvpxpcnprhjkxdwtyvgalnmfgjlgxptt
 * Smoking Wheels....  was here 2017 upkvczeacwjfxvstyduhtkbhjhgjsxafjdqqohktjarrgqrg
 * Smoking Wheels....  was here 2017 sfukmvvqtuflxdqofurzuleixkgmlugepxjhyzuznaffncgs
 * Smoking Wheels....  was here 2017 zcvqobtqvhrqeswljuwbxcmechcmlfksokflbtpouicuirol
 * Smoking Wheels....  was here 2017 gifoqrrnhampcchlknhyspylbytkkanbnhlquazmpdosrmwa
 * Smoking Wheels....  was here 2017 pfuqiuoydyqgkazxppzgagvdeoomhfzwyjivdllxmyemrsvg
 * Smoking Wheels....  was here 2017 eksljunvtilxaofijuluutmkaqzefbhxosobkxrhilqutzef
 * Smoking Wheels....  was here 2017 nrkvuidjtpjbazppnggukbrrmwuhpdifjsbtcopggqyqozcd
 * Smoking Wheels....  was here 2017 jdlzxjzaamfkyuzsyghnifjrqezudedcoywmbvkuorlibvvr
 * Smoking Wheels....  was here 2017 qdtfgzclpxyyjtjzymsrksrhwwvxtebeqfmeijpbxbohkszp
 * Smoking Wheels....  was here 2017 pgleqpqoxdwzgydayrxbrddstiweomqeiqlyebumendizfjy
 * Smoking Wheels....  was here 2017 siytcxapnqmytqwoszmwllkkeiviaqtfqnscdbaujadjnbbb
 * Smoking Wheels....  was here 2017 tmvaytayhboqhhjsftjkeulzfutiuikotnjiaulwytutwijm
 * Smoking Wheels....  was here 2017 raajriohilbantrusnritnlmfywlvqzvfkvmwwnylerwfixa
 * Smoking Wheels....  was here 2017 rnrldavpzzhjjbehqevneiwzvgrfgvaurisrzfyktanoamms
 * Smoking Wheels....  was here 2017 hwecinhawdudaklctukbtcjzwlahmljmepyhwzryzgitxrex
 * Smoking Wheels....  was here 2017 fdclnrpavpgdxkfgashiaazemmutegbgxupxjpwnmcktuvhd
 * Smoking Wheels....  was here 2017 lrkviqtgzishqurarnrztlvlzojvhgmqjtdlnrahvzfzwikg
 * Smoking Wheels....  was here 2017 eafynvyrspmwdpbzebywabkazeezzuelipdaodvsxrngnpig
 * Smoking Wheels....  was here 2017 ybwpcxplovajqcazilrdctjhjzazriytrqmzccglvcjomnfm
 * Smoking Wheels....  was here 2017 mwaykukaktbonviaayvcorsyfaxvzrxwtmjzxalkxmzcpahm
 * Smoking Wheels....  was here 2017 supjzpjbjiskloblofmkefpywlcuxwjiyzdwanwwuhxkcleb
 * Smoking Wheels....  was here 2017 xlslotqnvtdehioujcayzcmmztchodwyaeltsmgeigweiirh
 * Smoking Wheels....  was here 2017 nptbgwspinxjikkxfqduhdczjrrdjbhuzmdaodnaphxmajxm
 * Smoking Wheels....  was here 2017 hkjiixfrtitsxijuberkpmjcddviakreakkijuwjaqhnbrde
 * Smoking Wheels....  was here 2017 ffkrizemgdserwpvdjthtqmtrjwbkeiqpvplddtkcunuqmze
 * Smoking Wheels....  was here 2017 noarbntycfacpaknxzvkudxfowfxsqwanvkpecxoulibdjgo
 * Smoking Wheels....  was here 2017 rhqendkfyyfwvdhredlwzzivrhsnjjcituqdavfmdouigazr
 * Smoking Wheels....  was here 2017 lnvjbtutqbbhurejvepzwgsibqiyzdbylgmqmrydmjcuxnpz
 * Smoking Wheels....  was here 2017 tpnoeoyghonjdlbxdrilhjgpdciloxdjebhzpimrnhvzgeoj
 * Smoking Wheels....  was here 2017 wcwjswzqhrxiulivpmbcfakxmegnebwkphtiqsopabrrsltw
 * Smoking Wheels....  was here 2017 gwftqlkbeutrxznzxslazbvpznvwiacdtjsaeydncrsuyegu
 * Smoking Wheels....  was here 2017 qyesicwzvssdyplkcqirdrnksecmrqwxvthrakjkdieqwijs
 * Smoking Wheels....  was here 2017 atssgajdiixsnaekiyxplgqgaihrbwoeikyeevtltmosrgrk
 * Smoking Wheels....  was here 2017 pvyjgqcjcxorphcodjnrzlrinlyxtbrwzigrxazbtwqsukay
 * Smoking Wheels....  was here 2017 xafmjnmxsxemistqgcvbadiabfvxctcytxcmvfyyhklrvplq
 * Smoking Wheels....  was here 2017 qlffwrfeaanxcvxspjrdcnncupxruqwuxsqfsuyzsifvtwhb
 * Smoking Wheels....  was here 2017 uktyiehvcfpyqjsdmwgmbzlkawmmsuixwqhvpjilpdlsslcz
 * Smoking Wheels....  was here 2017 onbinmvwisrvvjmkikyywdofjkbucnadlrqjtwwrunyzdxtn
 * Smoking Wheels....  was here 2017 lpldlejljzgbvdtjwaiswypwsakkjhvnngofslmlllssrahx
 * Smoking Wheels....  was here 2017 ftppmfozzsdkbdjbccjdooldcpngcxtjkwgaimkqxdzdgvau
 * Smoking Wheels....  was here 2017 uhjadtjeixivefkuhgdvvijxykrqhkegomcqqraktahsboox
 * Smoking Wheels....  was here 2017 lwyaeeyyttapekfdwhbrpxtivwjzbbqzrcrewxbgwwjfmuri
 * Smoking Wheels....  was here 2017 phqmqdvmvtuedxixohttggixptkdwkapubxapimuiphqfgnk
 * Smoking Wheels....  was here 2017 bpdownqfmpkjmhodjpdmhmbhkzszjfhlczxuqimanmggdzjq
 * Smoking Wheels....  was here 2017 ufipknjwtfvcyjadnvhlmadkntqwmmwacscjaomcaxummhuw
 * Smoking Wheels....  was here 2017 zrifzmfhawjrkcannuqoymalqoqfiniemhcwayglsqrepspe
 * Smoking Wheels....  was here 2017 dvohrdptxanoavdabpvxxujvodmukwkyhduqfqqtrpxfezyv
 * Smoking Wheels....  was here 2017 aupxvhgqgjanfafsdpswycdhjkeqiggrstiijayzgbtyedbk
 * Smoking Wheels....  was here 2017 owjnxecqdwxnqnhyyilbvvornqbxbtexgbbuntogdmtuslor
 * Smoking Wheels....  was here 2017 zraqseirztlwghsgbrljqpbgnfnfsqtkpcrezsebbnpoflgt
 * Smoking Wheels....  was here 2017 uaxgixlzimdzfqalcthxqijlgykeskuhueavhctbffifjygy
 * Smoking Wheels....  was here 2017 tarkbicybutqyccpdvxbjdkwvssxtvkwazgjfinfysgzcyvt
 * Smoking Wheels....  was here 2017 uagmjngggphwblzyinkkqmjnqusotzwquhtrwzxrvnvknspb
 * Smoking Wheels....  was here 2017 epscdycwieawnrzdfsewlzsofpwswdtmuedwmzpwsjwecujw
 * Smoking Wheels....  was here 2017 ipmdjgcyvymencsymlwododlmwzbntxkbaihpnomtdiinyfn
 * Smoking Wheels....  was here 2017 bbesiiyyqqjmkfyldbkugjpvnpbpjrlttjlqazzmgdmcqfmn
 * Smoking Wheels....  was here 2017 hksfphpmvetvxwuxjewgothqryjojxpaldwsvziawuxarxst
 * Smoking Wheels....  was here 2017 hfegzpgpvwvmxapxspquclrcoljmqtacuigqgmhokvgtalsf
 * Smoking Wheels....  was here 2017 mgzsmxikecfwpyxhxljofhkqatxcpsnauimvxpvtzepjjsqg
 * Smoking Wheels....  was here 2017 rsurkboitpoukfnbwbzwjmmwevykyodbrsrwntcozcfbpssl
 * Smoking Wheels....  was here 2017 uvmohgxcqjzfzooowzpjkkcvjytqpifvyjfrdopdzapkxspn
 * Smoking Wheels....  was here 2017 bgeyzwnpfpqkfbiijdoxjsrpfmvhshibihuhcyzyvsnbrfbp
 * Smoking Wheels....  was here 2017 avgslowbcsdwhyjednnrohysogydrzixuxfexcgqrbybqaez
 * Smoking Wheels....  was here 2017 iqiaahrxdndhrtoecokymhvundddfefpotrwkjpevieqrehf
 * Smoking Wheels....  was here 2017 azjefcwukxttzhzqotilyeoulkqofxkscsniolksyzthyxzc
 * Smoking Wheels....  was here 2017 hnkwwmrqhceldnxcxaryannwynywwlkcevlpselsvtjuwuct
 * Smoking Wheels....  was here 2017 raxxabmskpzwivxkykbqygmmwewwoicuumgbltqwpncddoqk
 * Smoking Wheels....  was here 2017 vqnlxsbjobwuyqwophkwinjhiijnyimbcgejlpfbqpdnqhzq
 * Smoking Wheels....  was here 2017 tqbwdqiixnvertuydfwgxtjgrftbzlynqynkvionmkbmogsh
 * Smoking Wheels....  was here 2017 srrtmflmtdfhlgbabbtrtpyonhmzvabycrzfxwkrcrptiypj
 * Smoking Wheels....  was here 2017 epvaycyctkmqkifsawtgdyuqtgjbxnpknvkgejsemjujodtg
 * Smoking Wheels....  was here 2017 wlbtwelntakzzpczcatiqyvejckhwsrgbxyclfrabrvmgxnl
 * Smoking Wheels....  was here 2017 toiiupymvzzgvtuelcxpazibvawxqspyguzqsbtikbirmmlt
 * Smoking Wheels....  was here 2017 botkmupwjmmtxwovoynvitrnsmfjkszjvpezjvqojhyrtkig
 * Smoking Wheels....  was here 2017 ihrvzkyyzylyigbvfqifwdpzwggmngpotqknwqgjcgtmsmhh
 * Smoking Wheels....  was here 2017 fuurqiobmdopnjbdinecegadkfzftdnvgntvbxutxgahgsqj
 * Smoking Wheels....  was here 2017 tmykxtmzzaysearceefdbodwqpsvykctuarvziuvkrgrnjzh
 * Smoking Wheels....  was here 2017 cwhoqaxoxvtnfgehfmuenrllgywughxddiuqwtvblheizzbe
 * Smoking Wheels....  was here 2017 vvgaxugatzonuhememoixnqfawgwejuzfsypiiyddavghiah
 * Smoking Wheels....  was here 2017 qmkzxafumecmisnubnlysgqyckxbiiuriuiidmhawclsjlde
 * Smoking Wheels....  was here 2017 ldqtgutodlkjmhfmbfnstgpmwtappifsxkisiwjvfapejqar
 * Smoking Wheels....  was here 2017 pjdytobgbytkfbqcsjglbebcviezfnryspnwekvaalzksjmv
 * Smoking Wheels....  was here 2017 maglkzqbxfpdpgjmscegzyrdyydyonzksuvfgephljqlclpz
 * Smoking Wheels....  was here 2017 vgqkmxclnwthekesathpzrkjhlvnibekcnlhjryotawljxsq
 * Smoking Wheels....  was here 2017 rhedpnlayyfwmjebxxqzwvlqfdpykeqnlqqanmgaqvcyuajq
 * Smoking Wheels....  was here 2017 guaingwtqqgdobsbvkqjszgfhmyrzdyojfemanhdxnetsika
 * Smoking Wheels....  was here 2017 zpmugrvwdkinmviooiyvvcnmldpmmnwoyqvdlzynrbbtvpwc
 * Smoking Wheels....  was here 2017 quhrduztizhvtfvqaalushedscpkoanwilumnflehsagbvdm
 * Smoking Wheels....  was here 2017 eshjrribghbbyxiolbguezlcmpepdtfzbmlmixgfkwotnitx
 * Smoking Wheels....  was here 2017 vyqlrubvjpzkbadxjhttgvtoibwqjxmuvwlgexadvgmasqnl
 * Smoking Wheels....  was here 2017 chrufspdfimlfvumlvqugsvzeglgrcggqyqcpltpqwtzgmol
 * Smoking Wheels....  was here 2017 sxcookqlqfkvvueisashrupabcwksamtthesiwpogxqycyel
 * Smoking Wheels....  was here 2017 qdtcfaemufsqptjukkdvjmhpjvmkmtpvoslxnvadgvsjjhxg
 * Smoking Wheels....  was here 2017 cmubbxjdzorblsqjzvihjlixsxsraochwjcvjhtvmkqzmaqx
 * Smoking Wheels....  was here 2017 pwpgburpwsvpmypyelywyokkyakzwzvfqnawlishbnmwdxks
 * Smoking Wheels....  was here 2017 wjuvnnuigjxbfzanynuvqzmsdemipuxwbviqpjcmjknegaoh
 * Smoking Wheels....  was here 2017 whheagszhnxjfpblorbvgdtwspgzezpvrclzuckoyoglzqqk
 * Smoking Wheels....  was here 2017 vgfxikonhidumvzgmtduvqryfrgluwmxfkybijgysrkltfmc
 * Smoking Wheels....  was here 2017 fbywmqvcwicvcyktlvqurkzmmffkvzkepdtfvjqjstbdgpes
 * Smoking Wheels....  was here 2017 vwdfuwfdxenfomczkgleipobscdxyblxcvaczmtsjyktiuau
 * Smoking Wheels....  was here 2017 oyqiterjmxkznfehqqtqoqqreqhebexreicnxkbeftzvfcpd
 * Smoking Wheels....  was here 2017 syqtgajrzqciweyfpuwylcqmneftjokiptrrwygfewociauu
 * Smoking Wheels....  was here 2017 sqmlgbuhzxauupzpaumifzhyooqhhuswhlowkjgniidohiod
 * Smoking Wheels....  was here 2017 iewmceqpikzcsbdlwamcmkotmqpxlpxqozytizhyagalbaiq
 * Smoking Wheels....  was here 2017 nwpggnvieczghilckaywaspuorisvbjeufgfqmuuwdqgtmqe
 * Smoking Wheels....  was here 2017 niwjpnpjvfhmllgccriowqxgkejinkpiueajrumkstvswdhu
 * Smoking Wheels....  was here 2017 viarduiyxfjhiqdhrbfghbdpyulkaemcnhfozainqzowaukt
 * Smoking Wheels....  was here 2017 ebtjegumhubljmxrcnoixcgnfnpaxebvecyliolabccydmgq
 * Smoking Wheels....  was here 2017 muwtgayqbyixgtqpppkkkemyoocifkqbhlowtdjdonzkkmlh
 * Smoking Wheels....  was here 2017 bdpldpxjovlywlqpsfgixzgarjkxadvqokuyoptgzaybeiut
 * Smoking Wheels....  was here 2017 ixgjxnfwlzxbkvonckqhrjfeirjmtxmozjlbhcoclmavftki
 */
package net.yacy.document.parser;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.naming.SizeLimitExceededException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.apache.commons.io.input.XmlStreamReader;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.util.StreamLimitException;
import net.yacy.cora.util.StrictLimitInputStream;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
import net.yacy.document.parser.xml.GenericXMLContentHandler;
import net.yacy.kelondro.io.CharBuffer;
import net.yacy.kelondro.util.Formatter;
import net.yacy.kelondro.util.MemoryControl;
/**
* A generic XML parser without knowledge of the specific XML vocabulary.
* @author luccioman
*
*/
public class GenericXMLParser extends AbstractParser implements Parser {
	
	/** SAX parser instance local to each thread */
private static final ThreadLocal<SAXParser> tlSax = new ThreadLocal<SAXParser>();
/**
* @return a SAXParser instance for the current thread
* @throws SAXException when an error prevented parser creation
*/
private static SAXParser getParser() throws SAXException {
	SAXParser parser = tlSax.get();
	if (parser == null) {
		try {
				parser = SAXParserFactory.newInstance().newSAXParser();
			} catch (final ParserConfigurationException e) {
				throw new SAXException(e.getMessage(), e);
			}
		tlSax.set(parser);
	}
	return parser;
}
public GenericXMLParser() {
super("XML Parser");
this.SUPPORTED_EXTENSIONS.add("xml");
this.SUPPORTED_MIME_TYPES.add("application/xml");
this.SUPPORTED_MIME_TYPES.add("text/xml");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source)
throws Failure {
	
	/* Limit the size of the in-memory buffer to at most 25% of the available memory :
	 * because some room is needed, and before being garbage collected the buffer will be converted to a String, then to a byte array. 
	 * Eventual stricter limits should be handled by the caller (see for example crawler.[protocol].maxFileSize configuration setting). */
	final long availableMemory = MemoryControl.available();
	final long maxBytes = (long)(availableMemory * 0.25);
	final int maxChars;
	if((maxBytes / Character.BYTES) > Integer.MAX_VALUE) {
		maxChars = Integer.MAX_VALUE;
	} else {
		maxChars = ((int)maxBytes) / Character.BYTES;
	}
	
try (/* Automatically closed by this try-with-resources statement*/ CharBuffer writer = new CharBuffer(maxChars);){
	/* Use commons-io XmlStreamReader advanced rules to help with charset detection when source contains no BOM or XML declaration
	 * (detection algorithm notably also include ContentType transmitted by HTTP headers, here eventually present as mimeType and charset parameters),  */
	final XmlStreamReader reader = new XmlStreamReader(source, mimeType, true, charset);
			final InputSource saxSource = new InputSource(reader);
			final String detectedCharset = reader.getEncoding();
			final List<AnchorURL> detectedURLs = new ArrayList<>();
			final GenericXMLContentHandler saxHandler = new GenericXMLContentHandler(writer, detectedURLs);
			final SAXParser saxParser = getParser();
			saxParser.parse(saxSource, saxHandler);
			if (writer.isOverflow()) {
				throw new Parser.Failure("Not enough Memory available for generic the XML parser : "
						+ Formatter.bytesToString(availableMemory), location);
			}
			/* create the parsed document */
			Document[] docs = null;
			final byte[] contentBytes = UTF8.getBytes(writer.toString());
			docs = new Document[] { new Document(location, mimeType, detectedCharset, this, null, null, null, null, "",
					null, null, 0.0d, 0.0d, contentBytes, detectedURLs, null, null, false, new Date()) };
			return docs;
		} catch(Parser.Failure e) {
			throw e;
		} catch (final Exception e) {
			throw new Parser.Failure("Unexpected error while parsing XML file. " + e.getMessage(), location);
		}
	}
@Override
public boolean isParseWithLimitsSupported() {
	return true;
}
/**
* {@inheritDoc}
* @param maxBytes the maximum number of content bytes to process. Be careful with to small values : 
* 	a Failure exception can eventually be thrown when maxBytes value is so small that the parser can even not fill its buffers on input stream and parse the document declaration.
*/
@Override
public Document[] parseWithLimits(DigestURL location, String mimeType, String charsetName, VocabularyScraper scraper,
		int timezoneOffset, InputStream source, int maxLinks, long maxBytes)
		throws Failure, InterruptedException, UnsupportedOperationException {
	/* Limit the size of the in-memory buffer to at most 25% of the available memory :
	 * because some room is needed, and before being garbage collected the buffer will be converted to a String, then to a byte array. 
	 * Eventual stricter limits should be handled by the caller (see for example crawler.[protocol].maxFileSize configuration setting). */
	final long availableMemory = MemoryControl.available();
	final long maxTextBytes = (long)(availableMemory * 0.25);
	final int maxChars;
	if((maxTextBytes / Character.BYTES) > Integer.MAX_VALUE) {
		maxChars = Integer.MAX_VALUE;
	} else {
		maxChars = ((int)maxTextBytes) / Character.BYTES;
	}
	
try (/* Automatically closed by this try-with-resources statement*/ CharBuffer writer = new CharBuffer(maxChars);){
			final Set<AnchorURL> detectedURLs = new HashSet<>();
			final GenericXMLContentHandler saxHandler = new GenericXMLContentHandler(writer, detectedURLs, maxLinks);
			
			StrictLimitInputStream limitedSource = new StrictLimitInputStream(source, maxBytes);
	
	/* Use commons-io XmlStreamReader advanced rules to help with charset detection when source contains no BOM or XML declaration
	 * (detection algorithm notably also include ContentType transmitted by HTTP headers, here eventually present as mimeType and charset parameters),  */
	final XmlStreamReader reader = new XmlStreamReader(limitedSource, mimeType, true, charsetName);
			final InputSource saxSource = new InputSource(reader);
			final String detectedCharset = reader.getEncoding();
			final SAXParser saxParser = getParser();
			boolean limitExceeded = false;
			try {
				saxParser.parse(saxSource, saxHandler);
			} catch(SAXException e) {
				if(!(e.getCause() instanceof SizeLimitExceededException)) {
					/* Only transmit to upper layer exceptions that are not caused by the maxLinks limit being reached */
					throw e;
				}
				limitExceeded = true;
			} catch(StreamLimitException e) {
				limitExceeded = true;
			}
			
			if (writer.isOverflow()) {
				throw new Parser.Failure("Not enough Memory available for generic the XML parser : "
						+ Formatter.bytesToString(availableMemory), location);
			}
			/* Create the parsed document with eventually only partial part of the text and links */
			final byte[] contentBytes = UTF8.getBytes(writer.toString());
			Document[] docs = new Document[] { new Document(location, mimeType, detectedCharset, this, null, null, null, null, "",
					null, null, 0.0d, 0.0d, contentBytes, detectedURLs, null, null, false, new Date()) };
			docs[0].setPartiallyParsed(limitExceeded);
			return docs;
		} catch (final Exception e) {
			throw new Parser.Failure("Unexpected error while parsing XML file. " + e.getMessage(), location);
		}
}
}
