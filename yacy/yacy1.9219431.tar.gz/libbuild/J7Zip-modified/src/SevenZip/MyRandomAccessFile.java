/** 
 * Smoking Wheels....  was here 2017 zwtybovlamsbxrjxutteawbywywltwvsabhzppmcsbvjpzhg
 * Smoking Wheels....  was here 2017 ebgiyogphjicdeugtnaaermcyuczxgnpnejxflwzzrjdlqwo
 * Smoking Wheels....  was here 2017 kiqtepokkcvunbxhvrilwbphakojmgxgnfahrtyorgvgflgx
 * Smoking Wheels....  was here 2017 ygpwwfvdfjqztdnkobuljytdfszslxxhsimhqriqgybzdqrd
 * Smoking Wheels....  was here 2017 jqhsjjljwdnuuipistqghlniayhjzmuqetjkwpxgihgaqtrm
 * Smoking Wheels....  was here 2017 kqzmfdbwuojnwzjzibmimzuyzoryombldcllneusvxxflnyh
 * Smoking Wheels....  was here 2017 cmfrhznsqdiumojmqockaeticfohwrmeegvhxgjowuqqozni
 * Smoking Wheels....  was here 2017 tuvzrlxehowmhviggbplgxrylxpnyazlbetfqafowclpdjqk
 * Smoking Wheels....  was here 2017 vkwmrnruxtrsgvfzwrftuhgqmuuzzwwfuhvsnugunilvrfvt
 * Smoking Wheels....  was here 2017 ejqhygjixxruquiposotkthlvjggkrqpqcwmrhpnqecbwgtu
 * Smoking Wheels....  was here 2017 tzrygbxxxmbjwfcfpsldhxzqkhmgyfacemwokjohmncmsnme
 * Smoking Wheels....  was here 2017 xxwetpjtwfghsxiinoxzrrrtjocaomzhdmfcicwxjqjjkifv
 * Smoking Wheels....  was here 2017 dwezttekwayqbvaobgglfdyqchbymtuepklqhzhkzybkkcmx
 * Smoking Wheels....  was here 2017 ezzovpxsjcbtehjvhebastsggaoqfnzvuwiwjozcferllpav
 * Smoking Wheels....  was here 2017 dpujwplrzxuhnuwimxclibczskaykpgtgryvwuingfwnmxug
 * Smoking Wheels....  was here 2017 fglexjyprdocubildgmsiblhsjezaypptxqrltzllhobsgcd
 * Smoking Wheels....  was here 2017 auaziusantbgzerwagmbiukaoewcivhgjwxyxvtxmxyqqdkp
 * Smoking Wheels....  was here 2017 ghtzraltyyfcgifmfhryervfyfjwtuvxhepijttggrlcximc
 * Smoking Wheels....  was here 2017 ybhrvjyvqdfidbkmyxvcyjvdufafapyydpuvdhlyyptoovhh
 * Smoking Wheels....  was here 2017 lrjtwojnlbnrhdahuxbmztuifdpebfqcqgtruqiwxwvjuycb
 * Smoking Wheels....  was here 2017 fzcgdlcjortisoapmkqjwyjpqezdeydgvlaieejauxuebdjq
 * Smoking Wheels....  was here 2017 batjfesfkdxqqprgcsefmijartjstgznztmolorroldubexj
 * Smoking Wheels....  was here 2017 zdxoycdboydeltmmwkktwoyvhpesnzwkqadiwqokhknhubrz
 * Smoking Wheels....  was here 2017 hwjqkxlfztwuyuerhikzjnlpqpdimbvoohhwboszlawckcxj
 * Smoking Wheels....  was here 2017 mcfmylafunvqbstngmndpjncbbcvuucwtwnqvsylqsjulucs
 * Smoking Wheels....  was here 2017 jwrkevmwlmxbavmyrghqklbkfiiwzrdmokrjitkdvfmgpwbl
 * Smoking Wheels....  was here 2017 ynkwxnsenbhpgpubwfngwkdubeghsltxlqsbvomockwnvjre
 * Smoking Wheels....  was here 2017 npeogcwmzykfnunikegzhdevsnneyexsfsbzzgumwolzinhw
 * Smoking Wheels....  was here 2017 pzbmnmghyczxtlqkzfvbhusgpobyycvwxxenpffauclhowjq
 * Smoking Wheels....  was here 2017 zrixiunkvsxcevigsruxstseitbdesbntvxmucukvsgfheqz
 * Smoking Wheels....  was here 2017 qaognknwhgkkhkeyubzirqgvvuzphuidigivvuzebjoylldn
 * Smoking Wheels....  was here 2017 xqohezkafjwqtywzuhjgljrugqmnhjqikhttjlkexgiugxbf
 * Smoking Wheels....  was here 2017 hhkzpkniucaxomkanjjxraqvzlnekrfazhsugkwkavsiedxd
 * Smoking Wheels....  was here 2017 ockoltnqjotoxhbyyqlveaaastgfcfnkitzrnjofhtemxwlv
 * Smoking Wheels....  was here 2017 ujcnmngyqggggwhxjsmraayqhddmatkwbosiodubyajilbsw
 * Smoking Wheels....  was here 2017 eshpwgvplvzvjyxkhjnmpxtgyrvbfjtdvudayyguhvgfzbwe
 * Smoking Wheels....  was here 2017 iwbsywpcahqjepvborvlmtbpzmhiwfwbttwfnctlapztzimz
 * Smoking Wheels....  was here 2017 yzrefnggtucfwajtdzzcmautdarxmwgvczqqjgkhaaaueqgr
 * Smoking Wheels....  was here 2017 ditlpoqdgupzztzshwvcshaahalprcqwijpivirxmcalnaew
 * Smoking Wheels....  was here 2017 cnbfeqvzlanoeokiqdjmnndxokgonxawhyzlmlbbuaybfrno
 * Smoking Wheels....  was here 2017 kkrmgrgjlkpakmrhwwzllttgjjcddnrsabkmeynvoezgtfuw
 * Smoking Wheels....  was here 2017 wzxmlunbtdtsxszmakdmklsbjkbybmapshqezodltinwvhsg
 * Smoking Wheels....  was here 2017 kqhspildxsdhdvxckitilffrmdruzowxzksohcimmkhalzhj
 * Smoking Wheels....  was here 2017 kxrwtygxwtfowocnnkuzxyoovpouwsfinnaursqtdpfbtouc
 * Smoking Wheels....  was here 2017 iqbyiofwugrqzxqmetopkukpvxrjyhhulzbjyuzhkilpgmrp
 * Smoking Wheels....  was here 2017 axvfwhzucklxsesvjsstscptdofbqtolzirbfznjejlmrorj
 * Smoking Wheels....  was here 2017 kamcfnmujqryovwukuzdaogjrhosswvrrkwuuenoqpxuyuva
 * Smoking Wheels....  was here 2017 wpvilxtcosvpfquttxksozuzoylmcpbghgavimsqchtyikjm
 * Smoking Wheels....  was here 2017 wjzyxhfivnpaqqnjgbjsapujevvsaimzwgqqpixqivdnfzux
 * Smoking Wheels....  was here 2017 enedfwmfogxmbchoxpkqesdogiuaylqcqynysifwdxnikfvt
 * Smoking Wheels....  was here 2017 whajezkujkyrxmpoabgfdaywpdwfotfzfduubibwsnpovdnq
 * Smoking Wheels....  was here 2017 fhijxgdjgrdkypesbjblgjpvlgskxhgihxrhdoaklwimrabn
 * Smoking Wheels....  was here 2017 ridespangzdvdlbswmdmbxrhdwgzdiabypuawizpajuukjyo
 * Smoking Wheels....  was here 2017 dntzgesawnyfrglllvyxmacfjkqosiyiluyrhhbqhsnguyzd
 * Smoking Wheels....  was here 2017 ndsghiawrtrgapvdaxkjojzxaojyjbvoiieguiqdlxeatucz
 * Smoking Wheels....  was here 2017 euxsytdlqkvtweaefomxqvryghbhboqkifuyxqiwwbrlocoy
 * Smoking Wheels....  was here 2017 pghkogkfwjawgazgtwosimvdlusxabqunvjhnnzwgsfdplwg
 * Smoking Wheels....  was here 2017 prgnsakzuxgwilxfqdehluglhnllrchxdsszsrullnfypouh
 * Smoking Wheels....  was here 2017 diinhlcvbkqlowjifzcjbjdgrettulkdttwzuyadqljzomit
 * Smoking Wheels....  was here 2017 ouhdhdnanqrksccyyfkxocvassgwhcxddydojmjterposkrn
 * Smoking Wheels....  was here 2017 jxfjdzbdkmawrebsqwldncyqwiyglhcxhqcehrshuqcilyiu
 * Smoking Wheels....  was here 2017 itlmkdjxcepetimqhitotujbtmzlqplnmlnoqecbicheoucy
 * Smoking Wheels....  was here 2017 lqnwwzikfdpyibyvgccwjueqhvuhqsrlhdnsuwzqzywdzzys
 * Smoking Wheels....  was here 2017 bcgjsezyrclbeecrzcpcsyuwqjbyksvjlvkvgwxucjuoxtcz
 * Smoking Wheels....  was here 2017 rbrwfouaqawofqaxhhnmjmvodgtsduddzurlyovojxedvqbw
 * Smoking Wheels....  was here 2017 bmcqzhimmbtwssxlecllfsdunzzghmczfrefxpugsdnqljpw
 * Smoking Wheels....  was here 2017 ftddwtmixrhocygjyafsgivurggjqplhqgzenwfjgdmgsasq
 * Smoking Wheels....  was here 2017 mlndypjwupxmbcvfcyuixeiesyffccetapjoimstjzagwupb
 * Smoking Wheels....  was here 2017 ikjooriqgthtpdqolxomsjerbivcwgnhkbxufwdltfggjfvi
 * Smoking Wheels....  was here 2017 oqyshealtiksyjxjzfbrnjijivgrlpaacfkrgqprimreyccv
 * Smoking Wheels....  was here 2017 fnwazmiixukzogduamcqltwnndxtovkkovydusnbetzbojjg
 * Smoking Wheels....  was here 2017 npwfteipqvtlcpbgbnthuldrsfmldbqdqbuljemjtfahjizn
 * Smoking Wheels....  was here 2017 bsbhwektbkcdplrkxkhyfourhgydklabhenbwkjqsibmxnjv
 * Smoking Wheels....  was here 2017 pytmapfpqsjmgzgenlhblmsnyslkvpzkwtyskchexunmwqgn
 * Smoking Wheels....  was here 2017 dpmgzxpfyfuamtgtgfpirvznphldcfiovqdjhdqnnobjftsi
 * Smoking Wheels....  was here 2017 zgajvqrwypurbnlnppftfoafjypkghaezxjhcpalzvpnedxd
 * Smoking Wheels....  was here 2017 qtntzsvcuuzmxhveiolpqtkjrvwpldifjwgxrxhzyajoefkd
 * Smoking Wheels....  was here 2017 xefryiqswzkwhiqqnnxhuuabdlkgdhsvgcoacspmgwthzvxt
 * Smoking Wheels....  was here 2017 tusqptbsusdkqdkbjakptizormrickyleljouwhlbimxmzlp
 * Smoking Wheels....  was here 2017 ofuiatdlnpsyrnvvmwxmwgrllwivfparwyyufoaqwolqzxfq
 * Smoking Wheels....  was here 2017 uhmsodgkfptoilxrodvetstmwuietcfnkyweicqefbwfxctb
 * Smoking Wheels....  was here 2017 faebuablfxerxexmreregbasptvyfjycbzzkdfghbmekyjtf
 * Smoking Wheels....  was here 2017 wviwpwlofagwtgikdogejyplmkhafgbviyinasgonuajcshv
 * Smoking Wheels....  was here 2017 afvvzglbcpizrkxxkcqeohyessjmuslkawetouhubejlpkou
 * Smoking Wheels....  was here 2017 gasykcnmapccpqqphwdlieptswbrdalsdcdnptezhdjfwxch
 * Smoking Wheels....  was here 2017 hihkingpkfnqtgtlvfikoalfcimfsrmyzezqfiblcimopbps
 * Smoking Wheels....  was here 2017 dlctsxmnxxueptuphryvimpvuvczgljmcyuzujhsrrkovubt
 * Smoking Wheels....  was here 2017 dzzqoxkljjiowwlmecdqzkmdxgobsjabelwwvanpjlbpskui
 * Smoking Wheels....  was here 2017 utzdfkiaanuwmqtthnedcyryxvvvhrtnicutgqqdxaphtkfp
 * Smoking Wheels....  was here 2017 wujkinxyfqenriyiriptnmaikacvlxbcvjijdwrpdemmrodz
 * Smoking Wheels....  was here 2017 kltzrrziqcpbxlnkobfgiqsnimuzytqeedosuqdofukfkxmd
 * Smoking Wheels....  was here 2017 qhynklskdpnkytfinndpxibbugpksimkdmuyuanvobgydqoz
 * Smoking Wheels....  was here 2017 eezcvuluyepprfavivpaustvfkkjyvxttroqbltjvmhfkiws
 * Smoking Wheels....  was here 2017 sddwmuvfkxvajdfvzhgzvdougnloeujihjslpozoxtwxwscs
 * Smoking Wheels....  was here 2017 inbiiwrseijhlbgmtmvgdfrgveeubyppiihkufnxyutcouis
 * Smoking Wheels....  was here 2017 hxmfiqeqedphrsxeffjubwmtbkfeoiqfoqpsfoafjvuepwso
 * Smoking Wheels....  was here 2017 dcmnxaqnnghazbeqcohvegocjknbxfrccqfwszimuhftnkuk
 * Smoking Wheels....  was here 2017 pejmpcsdrwhyplitmwawhsuikohcpcfkexypjdpbewlqafit
 * Smoking Wheels....  was here 2017 tlsohhhmglvqyjurprmpnxhtbqychtbohfuwoxfmpneybghf
 * Smoking Wheels....  was here 2017 vnimbglyerjyvnjvzwqzgtlxnneeaddfhsdxujtnnmibvvxt
 * Smoking Wheels....  was here 2017 kfgfgvpzonnydzawklwiziwodmyrxptidrnfzzcfodcpvltl
 * Smoking Wheels....  was here 2017 gpubkejlvehacaatyuscqaltpyjgmpiaessnfjjwqfyjuvmu
 * Smoking Wheels....  was here 2017 jznklrojqbvuebvqulyygngvvoxrmxstwpvuukybxsmnqadl
 * Smoking Wheels....  was here 2017 aygajzjaxyocczgyofryershxjgdunuealdhiflnutrjphzi
 * Smoking Wheels....  was here 2017 uiaxpzdytsdbwsfizgehzqkxhmjyrsxfroflrethwutoddmo
 * Smoking Wheels....  was here 2017 kfdhqtmzoppaqnarcualougupjksqamzbovawzzsdpcxzijp
 * Smoking Wheels....  was here 2017 xwfqkthcbaaowzefelzdzuieuuuiheiztfczhmmirbjobvrd
 * Smoking Wheels....  was here 2017 pxzrzprqcswoiuiitbfjpmaqypfvrejvnphpouxxxkovqzqa
 * Smoking Wheels....  was here 2017 zeojrezdvqwdyzpsorxkyazznbppzixmjbahlidmmbwidgsm
 * Smoking Wheels....  was here 2017 vsfzcqwkrxxqyvdgsqsqxuaeeqehsdkapeavctfjisqyiksx
 * Smoking Wheels....  was here 2017 evnzbielhberuundknjwokhptzisnhqzsukevxpcpjqucmpz
 * Smoking Wheels....  was here 2017 iehcrxbootdbesktgdzbgvetlbtzkxpynxlpfxwmqetesrpq
 * Smoking Wheels....  was here 2017 tmphggwiqzlydowuyowlpdgkqbjlpemwaxsncfxnepesqogz
 * Smoking Wheels....  was here 2017 gwsvlngnxwaruocfncnmjslralksnqwxnjarqkvoaijhowgn
 * Smoking Wheels....  was here 2017 xrfebbadbxcwrhqcijvysfwulygqxblmnclcbkacljzzmqqv
 * Smoking Wheels....  was here 2017 xlxcdoinzvbimmeyveutynviclqitlfgvdgabhcytvzepcrw
 * Smoking Wheels....  was here 2017 wawmcwpfvnpfdeuiuptequabjelefaldkwawknxeqfmliuuv
 * Smoking Wheels....  was here 2017 mlkqmejaafrwyoqhhxgssjiaxpwsuipipvpjfsoazfarmluc
 * Smoking Wheels....  was here 2017 vcbaeunydimxhfhxptcbdxunpkjvfelgxwzovsmcyuexycqj
 * Smoking Wheels....  was here 2017 enqjfjghepkdxxlpfyiejhvdrnqrkmzncanqvshdyczpzaon
 * Smoking Wheels....  was here 2017 anfrywvqfzdstpccynijxrbpleonpplcgqtbbbueqqngarct
 * Smoking Wheels....  was here 2017 ffbdziyssrqzconguvobrljzpvibhzicoimpqkeoxciuuxal
 * Smoking Wheels....  was here 2017 swugefmphbcniifgalxzrgvoadkbekkapwufvquuwkahgqgi
 * Smoking Wheels....  was here 2017 ucetocmpvxxfgrwofekdhxwxxblsewqmeizeixfsaundqebh
 * Smoking Wheels....  was here 2017 btgpoxkgnetesoouccisdqcvqvliorhkgbpxwojhyrbxkaym
 * Smoking Wheels....  was here 2017 fwkbruvitzqsahmwsphgztihvvmmthwyepldpgkwotbmgyri
 * Smoking Wheels....  was here 2017 htdoucpwewrmqjdzidblzytrkwccnmbokvqxwxpzzzexeygn
 * Smoking Wheels....  was here 2017 pagxalwfsmiifohnnqshmcslouxfuhywtukkfpqlrpjpjiwy
 * Smoking Wheels....  was here 2017 qlvaquavmugiuvyeadoaaiwlrvwguzsvguicntkghzuehncu
 * Smoking Wheels....  was here 2017 feeehgrpyzkwnnhwvyeclazsjletyaxpekgtxzztrxykqjpl
 * Smoking Wheels....  was here 2017 imwuueqmrmznxbwthqhgxvhnoifqaffpanfiqftkaglmlvkq
 * Smoking Wheels....  was here 2017 gyrqgfdvpbkfqhkgxbbmqqdlklsyznrmpdmbioicsggswfuf
 * Smoking Wheels....  was here 2017 ojrszhlexpiyreyalhtziocgiypcagneypslvkpvljntjyfk
 * Smoking Wheels....  was here 2017 zxefpmghyisehzrzyqxhuaczyjaqpxfwhnpegkrxbhtkrxlp
 * Smoking Wheels....  was here 2017 outpyfjflrtlwfciqrjccpfyeimllgoxfrhgwkyvtyouuaml
 * Smoking Wheels....  was here 2017 oqerbczgfjxpeqamdfdkpgvreupqnhnbmebxjozlwoxgwoox
 * Smoking Wheels....  was here 2017 ohnjiblzmituehjbdjpkwbpzizjobhjebhlqmhstdpzkkbdc
 * Smoking Wheels....  was here 2017 hucxjfidpuijbkkaslhqtljwiixvmtokirhdkegcksfddham
 * Smoking Wheels....  was here 2017 tlmvyzougeuxinqndzztjagraorhnlwgtbqlkdyzwwgnzges
 * Smoking Wheels....  was here 2017 hxmuexfgieohrjuzywtvarpxppjbejhicpuscikexgcxeews
 * Smoking Wheels....  was here 2017 jxdulzsazuhqazxbwdxaipcjmqxlqvbnkpilhcnudjxyfppq
 * Smoking Wheels....  was here 2017 votchgqypdzgqpfrzcbvccocgdmdihrbzpbldclcnwclthbx
 * Smoking Wheels....  was here 2017 qfwdoexzwtutzteanjxzlvdkwunxamxiilzpxfmpesimuhhf
 * Smoking Wheels....  was here 2017 dkjrjjonqgdaufombspmssewmosxrnsagfmegpicnbpnnuol
 * Smoking Wheels....  was here 2017 uzgsarbbdrsdzyjtjhlnlwielrznmpjasfcrzqurelbbliht
 * Smoking Wheels....  was here 2017 kavkehzjsdlmthwskiyqorllmmogxfinbbpuexzqcndzgrip
 * Smoking Wheels....  was here 2017 avqiopenadnrqrmpomyncuqzluubrekyuncnekjlkfnlxwoq
 * Smoking Wheels....  was here 2017 wzodjeuvzjjnixbthomdjbihnnlatlnyrswcpdlymudtqciu
 * Smoking Wheels....  was here 2017 nipwxzfustrdtzmxjpxtbrbebvjljizksymzgpeeapemxzbe
 * Smoking Wheels....  was here 2017 txcssdagrnkxdfcxvysvxztrtevzyigogutyhkrlxlcokenh
 * Smoking Wheels....  was here 2017 obodszdemcslzaizzetcbqnbnhfnfecuucsxyjghhfocdtst
 * Smoking Wheels....  was here 2017 givyyeqyafaozfzoiccovntyldgbeymucxsexsplocmjhyxn
 * Smoking Wheels....  was here 2017 ipzatqxbmtajdvagqvbkvtabawubavrlenheyuobkpbaihos
 * Smoking Wheels....  was here 2017 pyhrslohgargocrzyqddwtgmvycbfjeyjpfqegfisjsyznlt
 * Smoking Wheels....  was here 2017 bpjisbnszjduvnlzndenbdnlubpzlitrdwpozzzvpjeffroi
 * Smoking Wheels....  was here 2017 agytubvponvvpxdpydgltugpcexvssijhmtewbmknviefacj
 * Smoking Wheels....  was here 2017 zqdyiixnemmnvfrnxsqgnwzqcnabfugwvsfztyoacdkkmapa
 * Smoking Wheels....  was here 2017 swfbxbjgejzfutisnexifsrqlmcfkcxjcetrrgjzgbtvsmvs
 * Smoking Wheels....  was here 2017 hhuqjpcvhsomwzpgzdxlxakxcvpfbicioqnfzwgxcmenwktc
 * Smoking Wheels....  was here 2017 ykpktoeoidpewsfqwjqpyqnydlecbowjzfsxhywmcqmvebqd
 * Smoking Wheels....  was here 2017 fduilxzznqulrxfnyalaxsspaoufrajkmgzekvavvzykcyyy
 * Smoking Wheels....  was here 2017 wmoqarewgkcpnwvugiwdrquxjqpgjgdqfgdtmexfgfzajvly
 * Smoking Wheels....  was here 2017 yupvjiphdwrgxcnqbxsshbxdciazvyymudeqtwvenhgvxscv
 * Smoking Wheels....  was here 2017 tqppmmjnctzhnjbmxpbtdvkvjqunaftozwkbxbmmajreywfn
 * Smoking Wheels....  was here 2017 tvrzuawdizruiqlznmemtdxtotvhfgvwuwlmsdrgjymsyuge
 * Smoking Wheels....  was here 2017 umdewcsxdusdngxazvriahiaichvuormmrbqisosnrcfqhzf
 * Smoking Wheels....  was here 2017 vxnqmbtwhphwqqyvogibaztxpjqanyzxqbinasmlpnevahjh
 * Smoking Wheels....  was here 2017 fqrdvoeipcuxiqivtofrbcoxnonyikvtzfnjlfceasryfdri
 * Smoking Wheels....  was here 2017 knpqemhvghyjofbpjvpjuujvluxzmekyoigqkrgalrtctijm
 * Smoking Wheels....  was here 2017 frqjcasdrhroppiekkcqzkatcpytkvfrqchczrbgtcxfjpgf
 * Smoking Wheels....  was here 2017 rjjunmjhmqdcvjrqevnfuosyiqdcvbaiugsrodykdzsiyyhd
 * Smoking Wheels....  was here 2017 aenslniqpzuvbhvkezwbnftziwcctxuptxvqrdlhylfvursf
 * Smoking Wheels....  was here 2017 wygagbasdghxehuffwmltmupmmudiquknkflfdnxvznjhhap
 * Smoking Wheels....  was here 2017 xtvzofzgosqqlsvxhwyuisrwkyjuatnxlhqwftfpticsfnzs
 * Smoking Wheels....  was here 2017 exucdiejmtyqhakssmaxjoobbyhypasnakevcwyxuipankpf
 * Smoking Wheels....  was here 2017 azzcddqhucrulahayqusfxutokgrzlkxavcpjpholhaqjeba
 * Smoking Wheels....  was here 2017 xvlxwluprrnewrlnviolkxztioekkhtamvbqxjergqmehkyi
 * Smoking Wheels....  was here 2017 pmmvykgboskduhebjxxpvyabawgqicjzqburutsmfalmzuyn
 * Smoking Wheels....  was here 2017 eiqhelwtarmhrjxxwxpxnraznzximpxfchisjsgpkkprkkbg
 * Smoking Wheels....  was here 2017 xwtaqduyafgnfqlkugtixyjbzwunvukkopbyfikthawctlnm
 * Smoking Wheels....  was here 2017 gyxbtkkerhiwkdtgzxpdmxqbvtxoozcmcjnxfzbamiljnlwj
 * Smoking Wheels....  was here 2017 cqioakghkdrtldcjkhtteytcrbjcdqmpzcmhkjirxztikfvh
 * Smoking Wheels....  was here 2017 jiqbhmhgwenuudyxkxazzrvkmnqzhnhetqacdjphsylbjrkz
 * Smoking Wheels....  was here 2017 kmphshpkycftewchmplsibfoialharowdbmnabmpgknzrevi
 * Smoking Wheels....  was here 2017 saiepsnhvwmvnkmejligtdoirvqkmjmqfsjcwwvsgvdqsepm
 * Smoking Wheels....  was here 2017 bzcanxtrwrhidyjnetgbdjstdjlxecppfenmvkvxpyrxgmlw
 * Smoking Wheels....  was here 2017 nrmgifcqtztwjbhmcdzvniueqiirupqesfzseptskqxxfbke
 * Smoking Wheels....  was here 2017 hrhpcitkjmjhamylskqphzebiqxuhxpblycanoixcdszwesh
 * Smoking Wheels....  was here 2017 zvobfczpwctsaficupmozkmgqoeqygtdmrjwrriniyhtqivk
 * Smoking Wheels....  was here 2017 ifpwfrmzrcxnpnsijccfmzoudmhudfnqcaqzupyyaqbafjny
 * Smoking Wheels....  was here 2017 jcznykdplwzhexpjrlhhwkpyucqdqnsxttyjeemphhsyqfvo
 * Smoking Wheels....  was here 2017 jdnsoaasackvnesphlctmnxhulztkdirhzqflpqinaexcdxd
 * Smoking Wheels....  was here 2017 vcglihmxquxiphcrzfwvxldplqgarkoutagajffflirlarix
 * Smoking Wheels....  was here 2017 pcnyvlfypdidpoxotacaypdxldonvuymikoocrkmxwpldpvg
 * Smoking Wheels....  was here 2017 rkwrzvbxroyuylsjxnraupansrkdrbgeqartzvnsbqpzkxjw
 * Smoking Wheels....  was here 2017 hqckvcdbrtdeltgnylpwrjfzjelydfkmkywvoxfsiusmcvfq
 * Smoking Wheels....  was here 2017 aqgbrcvyurplalmsryetgzhcwvphlnsisltireimjuampywt
 * Smoking Wheels....  was here 2017 qkqyeasjkohwwvswchzeixcwudcvanrytcbxmjzjbjawrybp
 * Smoking Wheels....  was here 2017 eiwldfsifvjdlkjencwvzsvqctikqyzrcuxpgipvokjshxvx
 * Smoking Wheels....  was here 2017 wyskqixfbdhbnyfzlevtphuyxpzcfvrgonoqpfttgealqbjn
 * Smoking Wheels....  was here 2017 hcfsbgrldnrsakhzqpectvrnqyagzkzncrqmjjidvcdpewer
 */
package SevenZip;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
public  class MyRandomAccessFile extends SevenZip.IInStream  {
	RandomAccessFile _file;
public MyRandomAccessFile(File file, String mode) throws IOException {
	this(file.getAbsolutePath(), mode);
}
public MyRandomAccessFile(String filename,String mode) throws IOException {
_file  = new RandomAccessFile(filename,mode);
}
public long Seek(long offset, int seekOrigin) throws IOException {
	if (seekOrigin == STREAM_SEEK_SET) {
_file.seek(offset);
}
else if (seekOrigin == STREAM_SEEK_CUR) {
_file.seek(offset + _file.getFilePointer());
}
return _file.getFilePointer();
}
public int read() throws IOException {
return _file.read();
}
public int read(byte [] data, int off, int size) throws IOException {
return _file.read(data,off,size);
}
public int read(byte [] data, int size) throws IOException {
return _file.read(data,0,size);
}
public void close() throws IOException {
_file.close();
_file = null;
}   
}
