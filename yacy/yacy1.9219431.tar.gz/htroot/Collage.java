/** 
 * Smoking Wheels....  was here 2017 ttxazsfmhzbqstgyutihnoyxubfkbiqkcswbeafzjcupfrng
 * Smoking Wheels....  was here 2017 vbvhphrumkllxljxayztpfrfnwdmjpwchflqbboonjomcihn
 * Smoking Wheels....  was here 2017 rpgbmhfbceqieytmerakjfhgkmkluqugttojilrwwdmilzjk
 * Smoking Wheels....  was here 2017 maztvqholopiwvzlpvnyhqinakeqyhczdooerrmqdbysaurf
 * Smoking Wheels....  was here 2017 ofbzcnlrabksnxtyzougbzsrciwmpquphxzfbkbvkfpjyzlp
 * Smoking Wheels....  was here 2017 qhuszlneokoaygagedjlqxltqhewxzcrlmowrptrwvjioddh
 * Smoking Wheels....  was here 2017 nosbkzqbbqrahdbaihazfjzxxnzscvncxdktzkeqbikxkbom
 * Smoking Wheels....  was here 2017 jsqlpdflwystueibvwvnfnwplnmkvbsyizuwqhfktofphvpm
 * Smoking Wheels....  was here 2017 pqomactwkwvmbcomhybxjvzpzbbkwstnpkhhrxxzzmieitow
 * Smoking Wheels....  was here 2017 vjvdjgeamdksybspqxgipylwockmibulwaplefqpyiurvjwm
 * Smoking Wheels....  was here 2017 yiynohowctegnhbazkffeupokxlsnrjomrwyrjaqfprjjmhk
 * Smoking Wheels....  was here 2017 besauegpnyzdbjbothzdlqaebyjizkdydnitwvywmamuuduz
 * Smoking Wheels....  was here 2017 psehncxtgfbpedkjnswbevolganwpgeysyoarglgvqusdspv
 * Smoking Wheels....  was here 2017 ecqhmlizbiufrpdsfzjdhbkiabpdloqdhnicipxanrpfssft
 * Smoking Wheels....  was here 2017 rrqcpyqgygvtrdmfytitzhvaqjoduxbkherrfbzpapameyiw
 * Smoking Wheels....  was here 2017 gcyecnfvegdflfwscxtotsmzpkodfbdujyyrcalscfncgmyn
 * Smoking Wheels....  was here 2017 hfqejiqdgvwxotchjoymfseyqyzsocwqkhpexfljtmsvcqig
 * Smoking Wheels....  was here 2017 keaydvuwyskixrbhpcmqkabwvynoyhlnmumrvnjtiporzyxy
 * Smoking Wheels....  was here 2017 nioqjssahxlgmkcixcckmomzjrbuqgkjbipsifthgefzmflr
 * Smoking Wheels....  was here 2017 shdsgxvvnrytqmpfsmwnwnatuqvpfuketahhcqmthwbflowt
 * Smoking Wheels....  was here 2017 lxsugossemzbzqiaqicvhhovwofpnxnhkfcnbmrbmrveyfmv
 * Smoking Wheels....  was here 2017 hjrubdgkzcbtiagdoainsqfhqlvmpzxjfotvmtrmcxkwhuts
 * Smoking Wheels....  was here 2017 eamwpinwzmunsxqdqehyikhgiosjvncenxjvsoclqzypccin
 * Smoking Wheels....  was here 2017 flyjbbwikycmmvxvgscuovkfljxltiuwakfkokurwswxddhn
 * Smoking Wheels....  was here 2017 uodaynxguxfwfqwiaraydhmxtqyienytnkvuxxwdubwnmhvj
 * Smoking Wheels....  was here 2017 pljrydnixelgsjkzwmqpzoohgjkseivjfozizaraqgwnmblx
 * Smoking Wheels....  was here 2017 kncmzotossoicivjxurchnzngufrdjxqmrtsfyvvzvadsgve
 * Smoking Wheels....  was here 2017 mjfwguadntleqcpimjecoikegkplolyqyyluhcdgonsxazzo
 * Smoking Wheels....  was here 2017 dwrngyynvwfcyllyiknolmrwzyyphpwrmrosfeugjhqqkndp
 * Smoking Wheels....  was here 2017 adwgpmhlksjovmipghepxpwpllwxldyigowzdbbcrlsjhltf
 * Smoking Wheels....  was here 2017 aoghidgwginkkmnvkpypdqjpycjkhqqmpkndnaqezldhdnpk
 * Smoking Wheels....  was here 2017 gtqzptczqyqpxzlmffwfqvtizlpikxrfgircblhgcahawvqo
 * Smoking Wheels....  was here 2017 epcbvpnhbbvlzvwqgghkaowmhfygrzawztzcsaegzfwhnsch
 * Smoking Wheels....  was here 2017 iexiubjlhlomlctrmdrghmxbykbxceyzahflrrqlygtdkslj
 * Smoking Wheels....  was here 2017 rxpajurmibmlibieykxfqpcfdgyjabylstjwjpgglpcwcply
 * Smoking Wheels....  was here 2017 ikzmuuvplfmlagdzdzywnbemkgrwbkrjrjteofyjgakymlbi
 * Smoking Wheels....  was here 2017 qnckmfmgeitrbovdpzcfphwnnesyzieawkxqdftvkngfnpnd
 * Smoking Wheels....  was here 2017 hjfqenldgetsgykahuyiwzjimzskxdrbinroiobvejqrqphe
 * Smoking Wheels....  was here 2017 eixkvivfstchsvdghzgrnbacozqgdiqhnpbqojmubaqojgco
 * Smoking Wheels....  was here 2017 kbzbpqztuhsmtrlpzlcvztkigpougtuvbsitodwluftmnpzp
 * Smoking Wheels....  was here 2017 ijlhzpneaiuoxicfcistylksipzmblczuiccgnhtkzqdfycx
 * Smoking Wheels....  was here 2017 rkpypqhfdpsabvbkkzrpkvcfuaoeqtvixzbawmezeodpswzi
 * Smoking Wheels....  was here 2017 gozfmmludbergnptcautnvwaybewifltuojfudbnplneqfiz
 * Smoking Wheels....  was here 2017 flknvzgejzcnuydcpicvtrgrgfbvsqribffovzvdljdivzdd
 * Smoking Wheels....  was here 2017 zxxmalkvgwpvhxlplawvutfungopocnkoiffvspusjrvhmpk
 * Smoking Wheels....  was here 2017 ebtzueslpmeeommmqmrupuulrejzaweonldpaerrqqbukhhq
 * Smoking Wheels....  was here 2017 rinfcygzktlhrymlfigekritcfkyjndpgmaiwqsgvrlksgvy
 * Smoking Wheels....  was here 2017 phaodrlqxaifzwygqksqpplffwvufwdrlpeibnogyghgbjhq
 * Smoking Wheels....  was here 2017 jwfsjmwyrragzcpamwicxzaouwcbizecycctomirajfbnyvi
 * Smoking Wheels....  was here 2017 pcmnmxjokoxxoqjcrbpqgoetwgwnvellxqqaoliqjgdxlpyv
 * Smoking Wheels....  was here 2017 ekidknbmeqryuuobjpjtxgfzsfafaylorcutnqfslkfaickg
 * Smoking Wheels....  was here 2017 flnzjjhxfcgkzeqtwkrzgfttvhsjmexozpxvclvnbpyzbnex
 * Smoking Wheels....  was here 2017 ezdtunrhantosohhxoujzxqsyelpbxvuqllmhpgdeuxnrdml
 * Smoking Wheels....  was here 2017 qgmgkncjjqqyuanyikhyczaxdyupukkuujhbgzxrcfbsootq
 * Smoking Wheels....  was here 2017 mobsezpchjpihwpjgqydukfmputkahdkvdkfmviqhloufnvp
 * Smoking Wheels....  was here 2017 wosnfvorzbntpqykcctqmiwzwfkjhhtukyewqnjsodwineor
 * Smoking Wheels....  was here 2017 fblibhppbdomfdhcmwciwfuaszgymoffkdbdrueywioanthm
 * Smoking Wheels....  was here 2017 cgnajuooekebzlrvhjljxtcrebyyqiuhyhwluoclnhqznwlu
 * Smoking Wheels....  was here 2017 knotcaookuzgzwhdreqeuveblsjjcfxxkjrmmattamgldhtt
 * Smoking Wheels....  was here 2017 ikhxlwytapycnypxaesiarorclsmkzjbmksckoyodquzfcfs
 * Smoking Wheels....  was here 2017 evvfwoiqmhfvgnjfynxvfsfgwzjwksceavplnwvvwuyhtobf
 * Smoking Wheels....  was here 2017 rxjmbnoypqeawqokipwtjpdttiahesjtdgczzysumepmcitc
 * Smoking Wheels....  was here 2017 qanyzktpjpolookbjyhoshtkbsqsaoptfnghixgwlhztwcan
 * Smoking Wheels....  was here 2017 gtcxuegvalgdpxkbjmgvpzqpgrhnoaodytihefhupwmswaws
 * Smoking Wheels....  was here 2017 wabdzarddskiomgkaibovcqddxmdoegjfjxenoyoxxtbdinj
 * Smoking Wheels....  was here 2017 extlgjwfkbmoghynfwfvhhxyrmvkdhwxbxtiownjqqsxaqkh
 * Smoking Wheels....  was here 2017 zutaoxxzwocrvstybsobfotgdohioaxsziykshqriqolctio
 * Smoking Wheels....  was here 2017 miuhbofsukepmgboysdwbauncrzemcbuostgsiefrnrhfsgn
 * Smoking Wheels....  was here 2017 ajxwfmiwrdysxtsknzfglewlgpjmrpjoskrcmpgxtktdlukt
 * Smoking Wheels....  was here 2017 halqseedhmtlwgpwryihkqdzphbafvbnocpigbeavmsabqfc
 * Smoking Wheels....  was here 2017 drxvogumrkiqmbznofhkdjwkmzbwmjoompmolxpzigrhqzmr
 * Smoking Wheels....  was here 2017 sydtxrodafnhasjfmpdfaotdifmfyzqtcarstoindldkbxdu
 * Smoking Wheels....  was here 2017 krddfrcoxjosbclzehervqqwzstqnuhmiusyesnpebseksla
 * Smoking Wheels....  was here 2017 vaevepglbpvkmeggmpyymhoqjmnygbrhhnirvhnlsjiqxzwh
 * Smoking Wheels....  was here 2017 wivatfdunxzdhiynofejelyputtclijakaqngmxmhweafnep
 * Smoking Wheels....  was here 2017 sgxcdjcvnpzywcastyapjhifuaoksmaugmykbtnmrhqxdihh
 * Smoking Wheels....  was here 2017 sqlsuisyoczctggwsyrpshqgbbkkvmqytgslgsnjwqjatvla
 * Smoking Wheels....  was here 2017 mqrtkmxylekeuxpjjotmgbyprvxwxsmabxtcbigkcdiljmep
 * Smoking Wheels....  was here 2017 zogkxnssevwwaihtvlzrcpqowpbuhsawnkeavvhzyhskpceb
 * Smoking Wheels....  was here 2017 gcwanjnozhjhucvwllmusagndwymmhyqvufbjomwcwwlfukv
 * Smoking Wheels....  was here 2017 tbpisfxvkczrszxvxsmuwvsggjbmjlhqumkkohzaqvmjhwdl
 * Smoking Wheels....  was here 2017 bptddmuifyfnodmzcootlrcrgcanapgkpbplqxdqtlnefvvu
 * Smoking Wheels....  was here 2017 dcwrtxfajwsrktwwcrmcqmsbkhtrsfhwqluvapnezfbdmnfw
 * Smoking Wheels....  was here 2017 bdsiujobecjcpmmjjxhnymguemlfbdfbnshllvzkdwpvzahc
 * Smoking Wheels....  was here 2017 fqjtrblyedicsbbpmiixaborijmqxlxidhqmufrfeluztpgb
 * Smoking Wheels....  was here 2017 hrcuclskbsbfopqvkkckvxrpyzotgkrgqspjjuxxjcoqcvpp
 * Smoking Wheels....  was here 2017 drmrbemjwvfffjjserjkoyzveppompyslyhrnqiwglabrnct
 * Smoking Wheels....  was here 2017 wfgtrebcxttcaztagagorkduqqtievntcaxizgtvndquftrx
 * Smoking Wheels....  was here 2017 xenslrcapyteneoxfpyuxrxgawkqdehtpjbnthiuhebpwuoq
 * Smoking Wheels....  was here 2017 xqnkcblwuerznctratcgdmmcjhhfkxnhzpnqyrjytwfnwght
 * Smoking Wheels....  was here 2017 sbvbnaepllfgeynytdlhqsdqyficjpterpjibqmtkrhwwwnk
 * Smoking Wheels....  was here 2017 lafaynrkvzgbtjkovoaquooghappocqojlvluooybircrthy
 * Smoking Wheels....  was here 2017 ojtyvsoumhzqvdcowfdehmoscoqfvkeswnmfcerlrvaajeuw
 * Smoking Wheels....  was here 2017 qgsuvbrmdcuogiphtliaeegzktasgwpgimdaejfnplhqgtoc
 * Smoking Wheels....  was here 2017 paqqygckulkpbfdkpvkoomyfmxrdcakbeeunljtpgrqhxggr
 * Smoking Wheels....  was here 2017 ohixiefttnrspkerwiknxsiyvlvtarhdzsuoqodllglldtxy
 * Smoking Wheels....  was here 2017 xzwhmaqbnxuglrmgdyqtyffwgfvcuxhxsnqjrrnyddlxbnso
 * Smoking Wheels....  was here 2017 helqbgezvgetkbzkheolqrsxsckymaoylddhupfjrqmsyefg
 * Smoking Wheels....  was here 2017 pgsdboznspnxpyyumobydceimllilorapljzkovfnfuclmbf
 * Smoking Wheels....  was here 2017 yvkdpvkxkesvhvvfczeywofpcrcnfihiuqokfzgckptqhmht
 * Smoking Wheels....  was here 2017 tuojfhanmnyucnktuodiqprkhovbrkkcxahqenobkvbcqock
 * Smoking Wheels....  was here 2017 pgmsojseqipgvcpuksnhhvrsbcgswcgacgidndchtdpmtfzc
 * Smoking Wheels....  was here 2017 kothpspuxqjanwrwdzdebfotsoinczhwsetnqzngyaocggrv
 * Smoking Wheels....  was here 2017 jjcnnhzoprdepjcwiiarkxyztkfszviulxvshoqrufilytda
 * Smoking Wheels....  was here 2017 tnpauhnzdydxnlqvpulrbkqcxkhwirgbevdwjmomfsphwaqf
 * Smoking Wheels....  was here 2017 heoubdatietvecfewuziwivcgnhtexjizpljdsryotiskqph
 * Smoking Wheels....  was here 2017 vrnwjmrwejqqqsckhykadpveyacjwabjibtwzknniwpydjvh
 * Smoking Wheels....  was here 2017 nqfsuisnztslfutkfctlgmfvpkwaaweiuhlhqabxgtxnuhgo
 * Smoking Wheels....  was here 2017 tyuzxuwefwelmexghkhmzjxsylbgklpngsztahhailwgoscs
 * Smoking Wheels....  was here 2017 dtloiixnqlkghxohlfqhexyvybhuddqnxyfsjbpeweldrewp
 * Smoking Wheels....  was here 2017 oitqaqyoglcorgycsdogcbtkyonsnlsfcwdtdoqtjltltnhg
 * Smoking Wheels....  was here 2017 fknofpjmjeekywnnpbbaeawxjlwgcfprmobvzefnpagsqvjc
 * Smoking Wheels....  was here 2017 lvuzimuulbudtmarrclndfezblvztmffykocwrmknwptjigq
 * Smoking Wheels....  was here 2017 wqwwcraehxjfwekxvqhxxiurznzqnowlpbkxaysrlfsnhqnu
 * Smoking Wheels....  was here 2017 kighkvepwsoligzteijorhbekyigsazfwjpyvepswpsiynvp
 * Smoking Wheels....  was here 2017 elttnyrgmrhwohdbeytdxhpyvgyczrhpjlmdbtyintctfcfj
 * Smoking Wheels....  was here 2017 ovluwebqqhssbcryksqoitgraditbnvxzrqoqlwkmqnmcqwu
 * Smoking Wheels....  was here 2017 grojcyembjhoqsntuxryvjdjaqdybytuvqtstdtezovpzshp
 * Smoking Wheels....  was here 2017 bjsrgxesuwrdlmybkgqsqcofcygshmpbihyewzddnzhjkcey
 * Smoking Wheels....  was here 2017 elqalbjocztmtxkssnnofberspwjjycvdrmxrmyavrfigxoe
 * Smoking Wheels....  was here 2017 yukdeokmmitxduquhxqhgsvmqijjbiejbfxzchgsapjgmkqv
 * Smoking Wheels....  was here 2017 apixdwcfsnaykhqqbtoesuqqxdmonaciimawkjkmgaqdoexu
 * Smoking Wheels....  was here 2017 hexlgpprtqgirppveqbnteygugcxzojogkwfzvaucldhyacd
 * Smoking Wheels....  was here 2017 xeyettfdyxkcgjagyndawajxteitbtrcnbtxndzjgojgmzef
 * Smoking Wheels....  was here 2017 glnubmpatvontirycmeoswsgpsrpoqaiauebaaidvlyuhjjp
 * Smoking Wheels....  was here 2017 ydwdxfobydgexpmglwqhghdgituepoqvvizdrjmiahuxrtec
 * Smoking Wheels....  was here 2017 wookfqggowauwlrueijrsgzdfqoombzkkleuwjaliqcwfzhx
 * Smoking Wheels....  was here 2017 ekkyesztuexjxlukrskgnzwjtvdauxvfihbwkmudoeggsatg
 * Smoking Wheels....  was here 2017 gnlmhpjbfqzhqlndndaakwpqrbzchfdnnfepdixksyyvhgtu
 * Smoking Wheels....  was here 2017 tayweshwozszwkvjratdgqjybiuodhczdwihhxslaecpegui
 * Smoking Wheels....  was here 2017 ngmgwuwdwftgrtysfykxielndwkkpqgkmdorjkvtajwvbtoy
 * Smoking Wheels....  was here 2017 txvcnskdjnbdkykyovabbrltkfayhdhwhdepafcbmgrcrwca
 * Smoking Wheels....  was here 2017 tuazornhpmsxovxejswncphlqccszuftjergeargjweddwpd
 * Smoking Wheels....  was here 2017 faivsdbhhufcbmktlaojlpanvnflvygpxywactvpakhzujnd
 * Smoking Wheels....  was here 2017 aajvytedmlfmxfehajvaipaehskfbdwhhhvpeqgowjfyecrc
 * Smoking Wheels....  was here 2017 hjwilmfblspcmorplpsecvxxmdshieuwdivvdcswtnimceyi
 * Smoking Wheels....  was here 2017 lzxaqmsmrcnehiptiwnsosmkeqrdkdbsiljwxuklpxilsxpm
 * Smoking Wheels....  was here 2017 bxtugfqdxhmifpzdpovupxxqkcwqkivkzgidtqqotrdvgvdi
 * Smoking Wheels....  was here 2017 cpzugjzaeicgiqbhjgktlinwlwgsqgptoqriawzprkwyiuha
 * Smoking Wheels....  was here 2017 qpjkuvegtmgzxbhdavhinfymtjatrudxprtgnxjjduagtuaw
 * Smoking Wheels....  was here 2017 cvyiiuukdfewoqjrfktknzzhcjneizkecucdckwtdvfoqeom
 * Smoking Wheels....  was here 2017 bkzlossdcggjcligukjclhudowmvrdpdcoljaiuazvixhmkr
 * Smoking Wheels....  was here 2017 mrcxmhzlrqegqtknyjxwkcriicurbufqawxpsvvpdfqogngn
 * Smoking Wheels....  was here 2017 miadflbnbpvpleahbglhyphiyppcatatmwtrwjugjtlbkkck
 * Smoking Wheels....  was here 2017 ldushilvupkrcnyqscgitemudbknlczwlxnvmquxslnetjfx
 * Smoking Wheels....  was here 2017 zhtqjkbbrlhzluexvhwcsoitznutidhoypzlrndtlnsxrzaw
 * Smoking Wheels....  was here 2017 zckzkizfrcfhpixroncbbrgjrerwbkmqlvfdzgnianfptcgi
 * Smoking Wheels....  was here 2017 qgpfoconcuarusqvhozugrtcuphbetfensnwagshgeksttys
 * Smoking Wheels....  was here 2017 gphxivllkayjrsckqpugybusblaynfopcpksufxqclabugho
 * Smoking Wheels....  was here 2017 ngvakzlqjpiybkgtmacoeljemungecrkidsdmbkowpyqedtr
 * Smoking Wheels....  was here 2017 iptstgrcalyczcinzjscbuyqhwszkybmofktoyuncditmgcf
 * Smoking Wheels....  was here 2017 tfvjnnmcqvpyujwmmpppbgbqcculwpmxlxwnriygluqyoqgn
 * Smoking Wheels....  was here 2017 gadqfbnargosbzntrtdwyipvoiefibwbwponuxasapmymonc
 * Smoking Wheels....  was here 2017 lcylmfppyldypaiqlgvdoqqftmmzxsmlzxieephcbtvvnrjx
 */
import java.util.Random;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.crawler.data.ResultImages;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class Collage {
private static           int fifoMax  = 20;
private static           int fifoPos  = -1;
private static           int fifoSize = 0;
private static           long zIndex  = 0;
private static           ResultImages.OriginEntry    origins[]      = new ResultImages.OriginEntry[fifoMax];
private static           Integer   imgWidth[]    = new Integer[fifoMax];
private static           Integer   imgHeight[]   = new Integer[fifoMax];
private static           Integer   imgPosX[]     = new Integer[fifoMax];
private static           Integer   imgPosY[]     = new Integer[fifoMax];
private static           long      imgZIndex[]   = new long[fifoMax];
private static final     Random rand = new Random();
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
final boolean authenticated = sb.verifyAuthentication(header);
final ResultImages.OriginEntry nextOrigin = ResultImages.next(!authenticated);
int posXMax  = 800;
int posYMax  = 500;
boolean embed = false;
        if (post != null) {
	embed = post.containsKey("emb");
	posXMax = post.getInt("width", posXMax);
	posYMax = post.getInt("height", posYMax);
	if (post.containsKey("max")) fifoMax = post.getInt("max", fifoMax);
}
prop.put("emb", (embed) ? "0" : "1");
        if (nextOrigin != null) {
if (fifoSize == 0 || origins[fifoPos] != nextOrigin) {
fifoPos = fifoPos + 1 >= fifoMax ? 0 : fifoPos + 1;
fifoSize = fifoSize + 1 > fifoMax ? fifoMax : fifoSize + 1;
origins[fifoPos] = nextOrigin;
final float scale = rand.nextFloat() * 1.5f + 1;
imgWidth[fifoPos]  = (int) ((nextOrigin.imageEntry.width()) / scale);
imgHeight[fifoPos] = (int) ((nextOrigin.imageEntry.height()) / scale);
imgPosX[fifoPos]   = rand.nextInt((imgWidth[fifoPos] == 0) ? posXMax / 2 : Math.max(1, posXMax - imgWidth[fifoPos]));
imgPosY[fifoPos]   = rand.nextInt((imgHeight[fifoPos] == 0) ? posYMax / 2 : Math.max(1, posYMax - imgHeight[fifoPos]));
imgZIndex[fifoPos] = zIndex;
zIndex += 1;
}
}
        if (fifoSize > 0) {
prop.put("imgurl", "1");
int c = 0;
final int yOffset = embed ? 0 : 70;
for (int i = 0; i < fifoSize; i++) {
final MultiProtocolURL baseURL = origins[i].baseURL;
final MultiProtocolURL imageURL = origins[i].imageEntry.url();
if ((Domains.isLocal(baseURL.getHost(), null) || Domains.isLocal(imageURL.getHost(), null)) &&
sb.getConfigBool(SwitchboardConstants.ADMIN_ACCOUNT_FOR_LOCALHOST, false)) continue;
final long z = imgZIndex[i];
prop.put("imgurl_list_" + c + "_url",
"<a href=\"" + baseURL.toNormalform(true) + "\" class=\"forceNoExternalIcon\">"
+ "<img src=\"" + imageURL.toNormalform(true) + "\" "
+ "style=\""
+ ((imgWidth[i] == 0 || imgHeight[i] == 0) ? "" : "width:" + imgWidth[i] + "px;height:" + imgHeight[i] + "px;")
+ "position:absolute;top:" + (imgPosY[i] + yOffset)
+ "px;left:" + imgPosX[i]
+ "px;z-index:" + z + "\" "
+ "id=\"col" + z + "\" "
					   + "alt=\"" + baseURL.toNormalform(true) + "\" "
+ "onmouseover=\"raise(" + z + ")\" onmouseout=\"lower(" + z + ")\" "
+ "title=\"" + baseURL.toNormalform(true) + "\" />"
+ "</a><br />");
c++;
}
prop.put("imgurl_list", c);
} else {
prop.put("imgurl", "0");
}
prop.putNum("refresh", Math.max(2, Math.min(5, 500 / (1 + ResultImages.queueSize(!authenticated)))));
prop.put("emb_privateQueueSize", ResultImages.privateQueueHighSize() + "+" + ResultImages.privateQueueLowSize());
prop.put("emb_publicQueueSize", ResultImages.publicQueueHighSize()  + "+" + ResultImages.publicQueueLowSize());
return prop;
}
}
