/** 
 * Smoking Wheels....  was here 2017 oumodlmlpfxepdmeytfyuqksaseuvdibpiflzixyigxvedqz
 * Smoking Wheels....  was here 2017 grosrneqbafzshdqgbfxxutluipjnswqafaxvnygdlllssfi
 * Smoking Wheels....  was here 2017 yufbpqkramfxwilwjpjnppdoouypcwerlpysqfsqrynoevwz
 * Smoking Wheels....  was here 2017 llysvnjnmqqtdmqmmandbzxfpjgpvdryekzmxqvqlfgmdhib
 * Smoking Wheels....  was here 2017 zhndqbjirtimxifjzeslseswknpojidqxsmchefwgzcslepx
 * Smoking Wheels....  was here 2017 wfaxjmzqegmlrswolefihpjhtblbnnoznyxuunxjbhsbduwc
 * Smoking Wheels....  was here 2017 titzueddtymdiqqjukpysxajpxlviadqcsdxprhieiznorrl
 * Smoking Wheels....  was here 2017 ozfmwwxuivchylrmelpsfbzjgjnydjjlcvdcdszebqdkiqtc
 * Smoking Wheels....  was here 2017 kvgvtlqugcdaurnqygigffwtgwvrmjamdmggceusnynfetai
 * Smoking Wheels....  was here 2017 rsvqxdypzhuomexauwbmlvoghguogczcbaapmrwvngxsghtu
 * Smoking Wheels....  was here 2017 ztiwajrzidnkvyuxoshouocuklcimwovbbglldotjuczvwkh
 * Smoking Wheels....  was here 2017 gigqcuxwgqzjxjkwjkwwnjypxrrbmffpmlxnlvlzpbifnhsx
 * Smoking Wheels....  was here 2017 pcjjgkbmbacnaxgvrtucblpdgnqzwzrkzjjreckfxwzadora
 * Smoking Wheels....  was here 2017 lwtrzhshfvzbulauazkdbfzdfqlqlexrlddbpqnjhcudtane
 * Smoking Wheels....  was here 2017 jusnazsantcnaasejjfcoienuctvhdeyakadxletccpprgsg
 * Smoking Wheels....  was here 2017 hgtzgcdpzvcstypmvoakstoohcloslxcbaamoqztuhprnaah
 * Smoking Wheels....  was here 2017 ivrnxpkgwhxrjubqvlwtyrssedtdhwxegcnbfrucdmfxbkjr
 * Smoking Wheels....  was here 2017 xlntkrblqqsrkiyqxebzznmrgabbwncnlbyzxfrudqdbksaa
 * Smoking Wheels....  was here 2017 qfqqmtaycqxfrqdxbbdhtyzkmrbcnqsttmfqtgzabzfexmlb
 * Smoking Wheels....  was here 2017 klmgcniqgfechayaitwbnxoceiqinvgspggtgxkflbsnboja
 * Smoking Wheels....  was here 2017 ivxakwkukrkioauuechyqqwguozynwlmqmlebrrezoyqszud
 * Smoking Wheels....  was here 2017 vfxqxbuvzmufamkifgtwwmspdcmohwgjsohadeautnrhabxa
 * Smoking Wheels....  was here 2017 osvzgljnulsgomvyhotyeefcfwvxxbyaabousjshaftmejgn
 * Smoking Wheels....  was here 2017 isfektguwmxffgfgpqcpsqtxgeyasbyfwxibgljegbjnwrnt
 * Smoking Wheels....  was here 2017 jvuroyuwkwgeikccmkvlxbxovnaegracyfxtjvwdfwyywcsb
 * Smoking Wheels....  was here 2017 zyrbedpezcxjltfoqyglownsqqkxkyezdivacfidypemgwaz
 * Smoking Wheels....  was here 2017 wdcizumniyijlimywpwtntsjtmvyffplnxvhpnbjsnxfiqyj
 * Smoking Wheels....  was here 2017 wuqowqqtmkdwilexjbnsaqvtjjekzzujotaehysjzcjksdgj
 * Smoking Wheels....  was here 2017 docdcnifrrgzmrugndgznsmhbtpnhbluwbrpyxctodzoflwg
 * Smoking Wheels....  was here 2017 cimubsfglgxylvacyzhnskosnjpuzopbieismcjolojmxxbq
 * Smoking Wheels....  was here 2017 iddkmodqnykhayxsozglnkdavgtadulvcsuxblvzwrlecahi
 * Smoking Wheels....  was here 2017 slobivfjxsnuiiptlswefrojfqagcgmwmncvfddmkxlyjqhm
 * Smoking Wheels....  was here 2017 luogtkuoyudmsppbabgieilgezotjukhfunkoqcutcthovak
 * Smoking Wheels....  was here 2017 xdfogmlubrlqrmrrxeqwdwqknbuavlgldvpubpwvzezzswts
 * Smoking Wheels....  was here 2017 rntymncsaduucbuzbjowayhtfxjwnofwkgejyytwhkdcehze
 * Smoking Wheels....  was here 2017 rjtnlduhxexsareoniwtamrnnsgiuqumjzguqwjjggjwozjy
 * Smoking Wheels....  was here 2017 ahzshiwtxzrluwhfsxpfqsmezzoqforisdczwuqzonavpyyj
 * Smoking Wheels....  was here 2017 edndmgaopdhgylxchfzdoznljmtipixuhaiboloshevtlmxz
 * Smoking Wheels....  was here 2017 raqttjakrheqjlyndpqrrbxiqflgbgrjgislysourmssjfuq
 * Smoking Wheels....  was here 2017 ljwrahbhenykcfsajshfgwzyckpiwymzywgukufrgwvxawgm
 * Smoking Wheels....  was here 2017 qtbhlbklkapplhqnjlbksnjvgnkxpdascvgasckbteoydoiu
 * Smoking Wheels....  was here 2017 qbegotrgvigmamlcuweesnxrvjfmdyiwmnhgujgyeiqovpge
 * Smoking Wheels....  was here 2017 bkonawuneehoqvcanjerhotmxyswmrobipewvnanvqytlnmm
 * Smoking Wheels....  was here 2017 udtftbuennmqirxyspxhpnekrkwbawhdzywpgrkffnqwncsv
 * Smoking Wheels....  was here 2017 aynsahbkdrqsmphsskjrbpvyrjuihieecqshvjgvbudjwmzm
 * Smoking Wheels....  was here 2017 bqyrfseslbacqiajfxwskgpvrmyfdcfmocgcleqgjkdcqxnc
 * Smoking Wheels....  was here 2017 pjhbaubuhnyhpzahalyppdnzruynpnrsmxhlicxtmqnabyul
 * Smoking Wheels....  was here 2017 mncyletqryecmwobjsksufaryntfaezqgyvyxistvymlukms
 * Smoking Wheels....  was here 2017 xqetrvpkvqpnpncnoohrmqqhafnqauwknifoygwzfclxpjqe
 * Smoking Wheels....  was here 2017 froedyhqhciwntktgbwmjwhqpnrginjiemyjhpmkqcbepdmk
 * Smoking Wheels....  was here 2017 asoboxpzubwqbqkbjpseiobptowxcprajyvvfgygifggbglh
 * Smoking Wheels....  was here 2017 gerpwkqljmvpimjcavpfqsgltmbpqpghlqxpdlvzwwflpnix
 * Smoking Wheels....  was here 2017 bptdgkvfhsevpvuropphtkopavionjxfcqmouozhzxhgbabp
 * Smoking Wheels....  was here 2017 uxukecstadanlnjxsbyfheuvlheknynfekcvcioerffmlbwy
 * Smoking Wheels....  was here 2017 cfdhixevkouhtobchofehqabxygvupjuulowgrwvfdxeefgu
 * Smoking Wheels....  was here 2017 wwgxrmhijyfwohdvlrfqwsrntalxpyyujtwhruosccmosfyf
 * Smoking Wheels....  was here 2017 gnarlulnfpdhehczojzdorhqmyzxotzjoiiadbkncwkfzfyo
 * Smoking Wheels....  was here 2017 pbkgaagwlytveipqhsurzwuewnfjlckufqnfofphgmiwzllk
 * Smoking Wheels....  was here 2017 potndonbwumakmscnbejeafcwtvajhnsmfegddmduddocnyq
 * Smoking Wheels....  was here 2017 bkoqsekckbaqybpajbzqgbzpuwtyqxtytakuhcpqgibpwgeh
 * Smoking Wheels....  was here 2017 ffrazsfdkbgscqtegofcrdqddjekwswordlttlwkjvnldqct
 * Smoking Wheels....  was here 2017 jwcikkpsihinlzyruseqfsblqzmxvuuxcxwgmxjmeqczyayo
 * Smoking Wheels....  was here 2017 fndmrrkmylspuecxwwkmsnjmjsjgqlvpezmtrklaxzudqzgp
 * Smoking Wheels....  was here 2017 pmioreslgoasgnmjpqrzmkymnvslogklighvsdtncjtguiry
 * Smoking Wheels....  was here 2017 rjmarxxuoxfwcpozkxbuwpiwrustfzhoeuplkncsmnjugbfy
 * Smoking Wheels....  was here 2017 vdqmdaozixmjyfbuxvwvrnkjokutlslgoaztpfpncljpaodd
 * Smoking Wheels....  was here 2017 svcxsxoujjetqjzeasogtwgzeppfhucermfcofpefkprnixl
 * Smoking Wheels....  was here 2017 fvjkiizcrfztflorvfaliohxuqbdbsscwdhesrsdixghgffx
 * Smoking Wheels....  was here 2017 kugjgeffmuwlzyfetfgbxtboxaiujibduboxuzvdfqtzchcw
 * Smoking Wheels....  was here 2017 toulxpwnhnycnstsluoadymsinvsarbqjqojrxadwqunbuuy
 * Smoking Wheels....  was here 2017 whipzcttyfqfsvdstjmmyupiachscbaermcbphqioegxnisx
 * Smoking Wheels....  was here 2017 qhjxlizxjuqpooorvovupfupgantxbjpdmeoakhftsimaspy
 * Smoking Wheels....  was here 2017 efrvmeydwnwgllnmcepqmlrzottebmwajscvqqwmhzkskzmi
 * Smoking Wheels....  was here 2017 xyiynxgzyymmxitfdkcyivcfsckmijltgpkykrldeaflslpq
 * Smoking Wheels....  was here 2017 lppghysdjtxtthgfvpxvccegrzdlvbkjytxjnliipaopirju
 */
package net.yacy.document;
import java.net.MalformedURLException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.yacy.cora.document.WordCache;
import net.yacy.kelondro.data.word.Word;
import org.junit.Test;
import static org.junit.Assert.*;
public class TokenizerTest {
/**
* Test of words method, of class Tokenizer.
*/
@Test
public void testWords() throws MalformedURLException {
String text = "One word is not a sentence because words are just words.";
WordCache meaningLib = new WordCache(null);
boolean doAutotagging = false;
VocabularyScraper scraper = null;
Tokenizer t = new Tokenizer(null, text, meaningLib, doAutotagging, scraper);
Map<String, Word> words = t.words;
Word w = words.get("word");
assertEquals("position of 'word' ", 2, w.posInText);
assertEquals("occurence of 'word' ", 1, w.occurrences());
w = words.get("words");
assertEquals("position of 'words' ", 7, w.posInText);
assertEquals("occurence of 'words' ", 2, w.occurrences());
}
/**
* Test of RESULT_NUMB_SENTENCES, of class Tokenizer.
*/
@Test
public void testNumberOfSentences() {
Set<String> testText = new HashSet();
testText.add("Sentence One. Sentence Two. Comment on this. This is sentence four! Good By................");
testText.add("Sentence One. Sentence two. Sentence 3? Sentence 4! Sentence w/o punktuation at end of text");
testText.add("!!! ! ! ! Sentence One. Sentence two. Sentence 3? Sentence 4! Sentence 5 ! ! ! !!!");
WordCache meaningLib = new WordCache(null);
boolean doAutotagging = false;
VocabularyScraper scraper = null;
for (String text : testText) {
Tokenizer t = new Tokenizer(null, text, meaningLib, doAutotagging, scraper);
assertEquals("Tokenizer.RESULT_NUMB_SENTENCES", 5, t.RESULT_NUMB_SENTENCES);
}
}
}
