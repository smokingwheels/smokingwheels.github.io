/** 
 * Smoking Wheels....  was here 2017 tcmlexlafzlqflxmzdwezsxwgzunlevugyfoobtdwwrvpsah
 * Smoking Wheels....  was here 2017 gfrtjvjchygafhobwdonlgkgvczhgldjbzzssjsgdlmxgtmh
 * Smoking Wheels....  was here 2017 tysftqrurjxelieclwrdjozsoluptlekocbnvrtbrfxofgvd
 * Smoking Wheels....  was here 2017 nndzwdtjhrqlfmuxhuckothsqqqajhioozppbesjyarmhqop
 * Smoking Wheels....  was here 2017 dlulpkheilxhyxqbfpwaeagynmigylaqdpxxsmtcoztukqku
 * Smoking Wheels....  was here 2017 kjufbqeagnlmkzhkgikvpazivctijpdrnfonljiknkjrwdma
 * Smoking Wheels....  was here 2017 jjmfrmouradbqmnzsdgyklycowenzppajhkvdwatzyyrdhaw
 * Smoking Wheels....  was here 2017 jqkozrvrpihhufidfpfunktrwjaifstgkoomxhuwjlgnznoe
 * Smoking Wheels....  was here 2017 xqlqygreezjplkalmjlaadhuemaowgbetaiiddssjafgjmwz
 * Smoking Wheels....  was here 2017 wcscpnzywxawilcrqmglhgtieidexykxrwipkghlyaaeodyp
 * Smoking Wheels....  was here 2017 gamujbwyidfalbjaycghzmnpveplorsstpjpqrcngafscqdr
 * Smoking Wheels....  was here 2017 kqkxwpukmcgizcvrzufwxxgyhtvwirhfvypyxrbqsxlrqkxy
 * Smoking Wheels....  was here 2017 vlguyfjsnjnjntuipfiwfuvczupgahsfwxgqqujtbusbgbbo
 * Smoking Wheels....  was here 2017 kdectfnqxutvsktstjwehslbqmwoofruhsarkvjceafddopu
 * Smoking Wheels....  was here 2017 drnsqcjbhmxtqvmywnlxtllydeubfkggousobvsbgelkucwg
 * Smoking Wheels....  was here 2017 jjvtgrjfqufknvbjkcwkmaohrlximztfoxkwucjktdbraais
 * Smoking Wheels....  was here 2017 qpyqkacocidhvqsmgwgkotpssdwadjqlhblmyekaiacxtbth
 * Smoking Wheels....  was here 2017 tfzzhknuczjdirzfkuzsjeufyjrgcfscbmlocvhdxesjgdfi
 * Smoking Wheels....  was here 2017 uchsgjuwjuxazoqofconobnzfonfsmakmpemecqfsejobjzi
 * Smoking Wheels....  was here 2017 bmkxwsgyvdyecfswfhwezmklvfxlkivzievxhijxexvhveof
 * Smoking Wheels....  was here 2017 bxgzblqnqqzdewnsgbaittjidgnryerrrfqruaqfymbnqhty
 * Smoking Wheels....  was here 2017 rcvoyxuggerpwxnxiliwgjoovtizirhovxhyhzviygfosooy
 * Smoking Wheels....  was here 2017 yzonwqwciuaqgzooupjxcckjwboouttxhundsfprkuuxoegt
 * Smoking Wheels....  was here 2017 evybmkhhvxgmoapzecawdboelvqzvoiiznnvdcwytznhxpkd
 * Smoking Wheels....  was here 2017 xcxmqgsgxbuqheyshpikonwrywiyfnnqvcpyycudrxjsslth
 * Smoking Wheels....  was here 2017 yonmlmaradjxdxepgcriranwcipnyidxguhptbsjbynnhqik
 * Smoking Wheels....  was here 2017 jdbyiqkowhzhewzthvqvciywunpyfwemtbnflzjecsldcjke
 * Smoking Wheels....  was here 2017 mcfzvmeaiuuapyllzgahtntfgbwsoiyyeqhkcepfhbwjxaoi
 * Smoking Wheels....  was here 2017 wxszxdcoqhipxiugedzjswwoxubpscybnnabdeplfbtfrhnz
 * Smoking Wheels....  was here 2017 ghtppvaxfrfvwlqaxmuwkxkvlweqrxzydwgheutbxbiyrchm
 * Smoking Wheels....  was here 2017 ugpsicbxtznsmyrvmlbajlvhuplasqbypgwnbbrnntabkpfj
 * Smoking Wheels....  was here 2017 tawlrtrwepknztyzloreooticphjhkmorjxjyginlxpipfum
 * Smoking Wheels....  was here 2017 rbkeownfqdisvaubqnryambrvtljesssldstezvzkqzuhpux
 * Smoking Wheels....  was here 2017 kdhpcsmpplzdvfrxcjkgeuygrcwajfpkfxxtjypdiilqrsgx
 * Smoking Wheels....  was here 2017 zewnqurztqksyyjodglgqgvhncuqbudzobiukghlkpjkgrkd
 * Smoking Wheels....  was here 2017 sksduyopabttkeykhsrghyhgqgrrvpqzgjbmkeuoahnxuxwj
 * Smoking Wheels....  was here 2017 ejsvlftxpinutbqykmeyedhujlgzicoijukttgglylvdhdir
 * Smoking Wheels....  was here 2017 dtxfsweowgknsaaannggukywmvkmrytzgpasahcianohzfwl
 * Smoking Wheels....  was here 2017 roqezmynpakahrvszanfqmrsvsllzbejkfrtehyqnbeyjite
 * Smoking Wheels....  was here 2017 dznwwvnzrxrnsadkgnvhrldtqsulwpezrknnfqscuyiwexns
 * Smoking Wheels....  was here 2017 ankrgynkgpsnmeeogtgczpfrjsefzzgrcewwqtppogaalpxd
 * Smoking Wheels....  was here 2017 eyigfcwnvwguiomczqcnymblquosjxdnzshzynykujmsjizu
 * Smoking Wheels....  was here 2017 qerlexrfbwgjhwvbtlasdwdgkgdhggyvwnqeczkypwekmhzg
 * Smoking Wheels....  was here 2017 smakscjswywmpzhtdrvbnvaoxukjeewfqhaeejxxlquxowmh
 * Smoking Wheels....  was here 2017 aifnstpnkrqrscbtxbqddqqbmgauvdmmhbuuogpfbthfmtfa
 * Smoking Wheels....  was here 2017 hlikidhfezgrkqtxensxjudrxranfuordamfwlwdipypqvgu
 * Smoking Wheels....  was here 2017 pvsawunwwxrnsgchgismxeyrbmpvpbdetrzvzzkbkteokiwc
 * Smoking Wheels....  was here 2017 hrykaoupiwcmuwdfqzmgnusldffgmclnytjfzdbsucrvppnv
 * Smoking Wheels....  was here 2017 wmxaqksxujaafqdfeebvkxhrouomqhbntezihmaadslmfjbb
 * Smoking Wheels....  was here 2017 fzqmurelsjdyszpexxvdxcxjahpqzkthmgkgnusfjzrslmnc
 * Smoking Wheels....  was here 2017 iemrxyiftylfgojeekjhqewsmbpwugnctlmkncsssmwcwfcm
 * Smoking Wheels....  was here 2017 nhbspxpjvkcecilmndmrmcydctzupbrphmhlkszgobsjdwkc
 * Smoking Wheels....  was here 2017 jtfasrqjelqhtlbsswixngyihdmbdfsnfieepeqtpwdnieea
 * Smoking Wheels....  was here 2017 sjzfjoiyevshziuswnfyfdbgtjaujllavftvrhdktglwqbln
 * Smoking Wheels....  was here 2017 obtezavznrhgspkmhkrvcordlvweppwjqpvsmcbsfuavoqne
 * Smoking Wheels....  was here 2017 fccadyntdkqjgfyknxqacomkncmtgwhemhnnfvjiljqgwjww
 * Smoking Wheels....  was here 2017 gywfsicrgoefbjqajvddhkiskzogcrfgleddfdeedafdoyip
 * Smoking Wheels....  was here 2017 nheivllkharnylbewdobbrkcvraterkrvohqbsxndfzswfwt
 * Smoking Wheels....  was here 2017 aehgwwszwxahvczyjblybdcrrmelsvytdxumrrftsllnhkux
 * Smoking Wheels....  was here 2017 cvwdlkhnznlvzgkqkbrddvbzealwegbcgxuhdgzqhqghpxrv
 * Smoking Wheels....  was here 2017 hssjkbwnvnmoxcpvuxhhkceqsdnvhjhmfopxwbjbnxjbskfq
 * Smoking Wheels....  was here 2017 knxoydhqutujjbdjpnrhgkqpaykgdwkahdtmlvugiobbzumq
 * Smoking Wheels....  was here 2017 nhvqifuxpiidituidekhhpvdzuhlxrlzbbeltpxqyfuwugtk
 * Smoking Wheels....  was here 2017 ygatgarkdoigbeozyihqjskquhqycysaibxkxspyusgezfnt
 * Smoking Wheels....  was here 2017 fwjforrrqcgdaksyvtmbrbhuyiemlcrxfehgiszdnfjaniqu
 * Smoking Wheels....  was here 2017 dvysjkqkmtuozyvbwkhimdppaywbzuetypxcoiojcblrqmbv
 */
import java.net.MalformedURLException;
import java.util.Date;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.crawler.data.CrawlProfile;
import net.yacy.crawler.retrieval.Request;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.search.index.Segment;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class QuickCrawlLink_p {
/**
* Example Javascript to call this servlet:
* <code>javascript:w = window.open('http://user:pwd@localhost:8090/QuickCrawlLink_p.html?indexText=on&indexMedia=on&crawlingQ=on&xdstopw=on&title=' + escape(document.title) + '&url=' + location.href,'_blank','height=150,width=500,resizable=yes,scrollbar=no,directory=no,menubar=no,location=no'); w.focus();</code>
* @param header the complete HTTP header of the request
* @param post any arguments for this servlet, the request carried with (GET as well as POST)
* @param env the serverSwitch object holding all runtime-data
* @return the rewrite-properties for the template
*/
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
int port;
        if (header.containsKey(HeaderFramework.HOST)) {
port = header.getServerPort();
} else {
port = sb.getConfigInt(SwitchboardConstants.SERVER_PORT, 8090);
}
prop.put("mode_host", Domains.LOCALHOST);
prop.put("mode_port", port);
        if (post == null) {
prop.put("mode", "0");
return prop;
}
String crawlingStart = post.get("url",null);
        if (crawlingStart != null) {
prop.put("mode", "1");
crawlingStart = UTF8.decodeURL(crawlingStart);
Segment indexSegment = sb.index;
String title = post.get("title", null);
if(title != null) {
	/* Decode eventual special(non ASCII) characters in title */
	title = UTF8.decodeURL(title);
}
final String crawlingMustMatch = post.get("mustmatch", CrawlProfile.MATCH_ALL_STRING);
final String crawlingMustNotMatch = post.get("mustnotmatch", CrawlProfile.MATCH_NEVER_STRING);
final int CrawlingDepth = post.getInt("crawlingDepth", 0);
final boolean crawlingQ = post.get("crawlingQ", "").equals("on");
final boolean followFrames = post.get("followFrames", "").equals("on");
final boolean obeyHtmlRobotsNoindex = post.get("obeyHtmlRobotsNoindex", "").equals("on");
final boolean obeyHtmlRobotsNofollow = post.get("obeyHtmlRobotsNofollow", "").equals("on");
final boolean indexText = post.get("indexText", "off").equals("on");
final boolean indexMedia = post.get("indexMedia", "off").equals("on");
final boolean storeHTCache = post.get("storeHTCache", "").equals("on");
final boolean remoteIndexing = post.get("crawlOrder", "").equals("on");
final String collection = post.get("collection", "user");
prop.put("mode_url", (crawlingStart == null) ? "unknown" : crawlingStart);
prop.putHTML("mode_title", (title == null) ? "unknown" : title);
crawlingStart = crawlingStart.trim();
try {crawlingStart = new DigestURL(crawlingStart).toNormalform(true);} catch (final MalformedURLException e1) {}
DigestURL crawlingStartURL = null;
try {
crawlingStartURL = new DigestURL(crawlingStart);
} catch (final MalformedURLException e) {
prop.put("mode_status", "1");
prop.put("mode_code", "1");
return prop;
}
final byte[] urlhash = crawlingStartURL.hash();
indexSegment.fulltext().remove(urlhash);
sb.crawlQueues.noticeURL.removeByURLHash(urlhash);
int timezoneOffset = post.getInt("timezoneOffset", 0);
CrawlProfile pe = null;
try {
pe = new CrawlProfile(
(crawlingStartURL.getHost() == null) ? crawlingStartURL.toNormalform(true) : crawlingStartURL.getHost(),
crawlingMustMatch,             
crawlingMustNotMatch,          
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlingDepth,
true,
CrawlProfile.getRecrawlDate(60 * 24 * 30),
-1,
crawlingQ, followFrames,
obeyHtmlRobotsNoindex, obeyHtmlRobotsNofollow,
indexText, indexMedia,
storeHTCache, remoteIndexing,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFFRESH,
collection,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
timezoneOffset);
sb.crawler.putActive(pe.handle().getBytes(), pe);
} catch (final Exception e) {
prop.put("mode_status", "2");//Error with url
prop.put("mode_code", "2");
prop.putHTML("mode_status_error", e.getMessage());
return prop;
}
String reasonString = null;
reasonString = sb.crawlStacker.stackCrawl(new Request(
sb.peers.mySeed().hash.getBytes(),
crawlingStartURL,
null,
(title==null)?"CRAWLING-ROOT":title,
new Date(),
pe.handle(),
0,
pe.timezoneOffset()
));
if (reasonString == null) {
prop.put("mode_status", "0");//start msg
prop.put("mode_code", "0");
} else {
prop.put("mode_status", "3");//start msg
prop.put("mode_code","3");
prop.putHTML("mode_status_error", reasonString);
}
}
return prop;
}
}
