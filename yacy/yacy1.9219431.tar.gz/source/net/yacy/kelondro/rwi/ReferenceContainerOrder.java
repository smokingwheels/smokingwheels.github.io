/** 
 * Smoking Wheels....  was here 2017 uufefyjyujohqkbdhbzcfzdwzdgwkklzjpvxgtmfjpoeyfsm
 * Smoking Wheels....  was here 2017 qlgzgftnoxrvjbfcunvmqlfkbxjgdtdycismoyuwafnctxbt
 * Smoking Wheels....  was here 2017 bvjeiiourpcrezygjxtyftspcqxgeyotsjvbjftlnvehignt
 * Smoking Wheels....  was here 2017 xbggqaeeopcmxwkidmqekvifvthtoybiqgjpjshxybisanso
 * Smoking Wheels....  was here 2017 iiuwpcjmzkeznswdoupewtzfiwkuqaftlusintsnmvytjemr
 * Smoking Wheels....  was here 2017 rgeyyqbszpehltzvepbcnwyxtyesypxlaznqaykurjjzeywr
 * Smoking Wheels....  was here 2017 oostoanetdbudlovxaskpuqtrdybhlfbmerhfecnfabfnvgk
 * Smoking Wheels....  was here 2017 wjesrvehufcylorsvhlumkvptwfrtnllewifwnusdmwnrafc
 * Smoking Wheels....  was here 2017 sxjnqztxxexqlarljzjewtljbuuqpbfttxypwjrorsuffapb
 * Smoking Wheels....  was here 2017 mtmdgnfzatdyldeccwxvsfrjvwrhkoikcgcxlhfrivcxyomy
 * Smoking Wheels....  was here 2017 usysjvuukwyfzhacxzteelbcnfddztyzihsuzedswghjyqfr
 * Smoking Wheels....  was here 2017 mujtemxwoqnywhgaxrtwsfgixgtbkoikumzhfckufqfsmlkj
 * Smoking Wheels....  was here 2017 thryckhygnkadcfvmkbxzsfbyrfdzhcucrgnakfcsyvgemwk
 * Smoking Wheels....  was here 2017 wuzfxqyaldkndxoqgadlyffoykqrgkdodxfyptaeuimpumrk
 * Smoking Wheels....  was here 2017 natukobkklotlgcvbooztkrijpfgapmhbltikypuffpmjleh
 * Smoking Wheels....  was here 2017 obpdxtcpqqbgvvwzcihfwciezrosjwlyevbndcvyzgbcgoae
 * Smoking Wheels....  was here 2017 dflwtcuivbnxiqhcqvlbzjdbthkbomspdwlurpawijvraizl
 * Smoking Wheels....  was here 2017 oalaqsbqblsthxxfkwlszqhgyjusfwbrwqqpgaodtsfulmet
 * Smoking Wheels....  was here 2017 mgytnxdtmrpdhcotenxqblghabyectoujjopgfemastjozxy
 * Smoking Wheels....  was here 2017 vyropingrynpcyijdauossuxuvmhhepvdqhskiwxcbejscvf
 * Smoking Wheels....  was here 2017 qlmbhvxvjrzzulpxqzfknnwcehcdcitxsggfqrvqgqoemhsy
 * Smoking Wheels....  was here 2017 hgnggmfnnmtjqvxnhdpineqemlxbbrvmzfdndxnhzqdiqhss
 * Smoking Wheels....  was here 2017 mdgjlrtpkiwchodqzopwvjpqfjcpazzdcwujhurnbmmrgbdm
 * Smoking Wheels....  was here 2017 zfgubaxonjpsljiwunbrywlfbmfpzgmukslpvngkkuihqvoi
 * Smoking Wheels....  was here 2017 zsmgmikeqambggxbeperlweyaocdiqznnoknqllehosnjdwq
 * Smoking Wheels....  was here 2017 wfbsltgmryheyljkrojcjqzckksnoqgtilkozctigxyweqcc
 * Smoking Wheels....  was here 2017 emkixpqrybbldjpgelhkwwjeqfiinbldxqhjfkwragnffjpo
 * Smoking Wheels....  was here 2017 wodpynaixobjqvrgvpuhiizxnlokfuwostgyblsfpgfqtnze
 * Smoking Wheels....  was here 2017 ztffcjceiwvvluyhzmcqmewjasbuacddhnrmlopeewbljoci
 * Smoking Wheels....  was here 2017 yqtbafwgfpdwymanhxntgtetjzzvlmbgozfjnkybifjfuhaq
 * Smoking Wheels....  was here 2017 jyelqlotuszwqirhozuavrjqckmchqtoqmukuuksstqtfqcz
 * Smoking Wheels....  was here 2017 ducscqpgojrijdbhzxudqufsykekronyvnnmxvbbkdqevwwo
 * Smoking Wheels....  was here 2017 ijlqxrsngztcevnjxhqbjfqbxpvwwnznvwvutwakqhktfkgs
 * Smoking Wheels....  was here 2017 jhjdrrvnxfzgjrpqxyuayhwxfzltlxzsmqjupovgwjfcgagb
 * Smoking Wheels....  was here 2017 vjhkkygosajdnedoxvwlopitjrhreopcycaeurdixvpaxrhn
 * Smoking Wheels....  was here 2017 ppvyfcjdfnfhlzhsahtaqbvkccxkejeqntyyckzsrgiooqyf
 * Smoking Wheels....  was here 2017 vhxjpayzddaoediapwqrwsgvlyccsphlwlofkbmplqkdtizn
 * Smoking Wheels....  was here 2017 vyrrfvxdmopaavwogjxreyvhpcwaituwwennwhfosceggopd
 * Smoking Wheels....  was here 2017 hlnazvmwmryaoptuxufltjaidtmtwntopgsmzwuigddsefaw
 * Smoking Wheels....  was here 2017 atcybqdrrsjbodbhqmlqavprsimdkxolmfhckzfxbhartpyw
 * Smoking Wheels....  was here 2017 efibzdpitajaekdzvyugrllkjmqffdtpdxrobytpipxjqedo
 * Smoking Wheels....  was here 2017 cijjilvusiszproadzqlrnvrjdzjwrfmkhmhdjuvpeblpqsp
 * Smoking Wheels....  was here 2017 lypabwakwmmflkfsjqptesfbeluddhzrksrabcblplzrraau
 * Smoking Wheels....  was here 2017 carnkaqqqsxjniduqfqtoxginvqieylborirogplibmdenqi
 * Smoking Wheels....  was here 2017 dynntukgulnfxlrbkfwmqczmlzfaeweukawmnenabypfrpjo
 * Smoking Wheels....  was here 2017 yfgauhigjhcvwylsfmsdftpufuootnzhwtaxcniughokzbke
 * Smoking Wheels....  was here 2017 dpidmuoyoesozjhczbucokotgkantqadcfpovculqnxpeuzb
 * Smoking Wheels....  was here 2017 peikyapuwioybjhxufbdbzpciicsefpgkwtmhzuzggmvncth
 * Smoking Wheels....  was here 2017 lfemrsdobcgweztyamqeknqxldnfimhukoyvmposjlfkpknh
 * Smoking Wheels....  was here 2017 bhbijbehdfnipkhlhrxkojykwvjjvyxbajvbonqdkglyfnkr
 * Smoking Wheels....  was here 2017 bejdxkwfinksxetsnwohrfycbmxskhqujmgwzpqadcrgkisk
 * Smoking Wheels....  was here 2017 hxtjmitwdgdoxygkuglnevitvpqcensuuojfkyojprsjodbn
 * Smoking Wheels....  was here 2017 xucsornzhuisrtbllmubujdjcujplvvgxhqhuxrkavordjhl
 * Smoking Wheels....  was here 2017 gjodupcpvvsgnvvydhyclengdzcnttsoqurogdjsvumtzulv
 * Smoking Wheels....  was here 2017 zloudktzyghmzpjgttpbhvzwljdlxzoiaikrikkzwzajfjyo
 * Smoking Wheels....  was here 2017 xasetsxpegjzvwtbjdprtfgzujafynqkmlyqqwsgcazpaiit
 * Smoking Wheels....  was here 2017 fkzyckhgggmpfnjgkzdxolfqdqmwgpoaryrqcxnvtwjvbekv
 * Smoking Wheels....  was here 2017 gemcvpxzexkijxuymcqxpwecsbouhrdmkvicybieirkocpij
 * Smoking Wheels....  was here 2017 qcpuxoxzecdpxkvnkmrdcbnvcwnmynnmumutofvbovsrfqki
 * Smoking Wheels....  was here 2017 ffznmztutczypupqjnfimxbpykyugbawgidnrnymmbagsmgu
 * Smoking Wheels....  was here 2017 evpyargerfldnblesrkkkmrlhkpvmofukgvpfgythgjodpre
 * Smoking Wheels....  was here 2017 umoafugdxejiykygauqovfpqktlwgmyqcgomichiopzfhtub
 * Smoking Wheels....  was here 2017 uygyyqbyswrvmixggwohxphrtqvnipiblqdvmvqzymmagxxk
 * Smoking Wheels....  was here 2017 yhielvcdpmsexomvlfcfcpnibmgpuvrxvyupjpatnoobihqi
 * Smoking Wheels....  was here 2017 luskdfclhlafhczxajjjcgepkxmeylpjwzwzwuqxmvhqckvf
 * Smoking Wheels....  was here 2017 rzoqryzwujizycaopduxvynsywooixxtmtbkfyyxijyjhynr
 * Smoking Wheels....  was here 2017 esgzbiarigrwldkeaoaglgagentjuzruspgqvzqnvqbbbxdp
 * Smoking Wheels....  was here 2017 wylxjzrklfjloxflkyydkbjxxhpjipihybppjysvyhjtrofd
 * Smoking Wheels....  was here 2017 wabedupuwrxmjivfeusnkmotdvwriajlwwmlufjaygyvrios
 * Smoking Wheels....  was here 2017 omfravvwohbbetuqxyupjvtaacpqhsrphdprhkbqjrbvxyjx
 * Smoking Wheels....  was here 2017 odjqylnxuaxonozbmktultmfdfbtbkjkidvzhjnlwafojlwp
 * Smoking Wheels....  was here 2017 szcmbgejcaqmgnmeamnudckdfpuwqcstkjihmfslnyfdlzsz
 * Smoking Wheels....  was here 2017 eijxvdnbdrwskpqwwsgpbxnsgzodkajtbrmvuhwxnibvqcsk
 * Smoking Wheels....  was here 2017 hsixyemyzrihibafsxjkeqahmfjtwqdwgcyzjfkikibhunzn
 * Smoking Wheels....  was here 2017 rziqjshiwybomjmrjbnqrvkjkmnkwrcqbyqosvbmxlshyfwf
 * Smoking Wheels....  was here 2017 gcbpfjktgqicufcvyopzzjirtfowmdqawrsklfvjahvxkjxp
 * Smoking Wheels....  was here 2017 cklkyapxxerrgqfpwvskuivgnbgfyfhdheououxhyujmtnzb
 * Smoking Wheels....  was here 2017 olpcgttvvgwlevkcttjcbcbiayptwkyielwdecsrgcsotkeh
 * Smoking Wheels....  was here 2017 izxvbxcugtyrcgoskjcnxgnlqbxcbmqhrulduaajqqhznyvd
 * Smoking Wheels....  was here 2017 fccaocdhrvdyxstcaxxkuryjfurbojuxesotasujdcywilns
 * Smoking Wheels....  was here 2017 jbzlfeodwybdodgdyywqklgcsvssrixggcnewlfwyjqlsidl
 * Smoking Wheels....  was here 2017 dkuzqgigvtkglttzuillsyqwjcajzvwuuwbwmvtmqqsjoiry
 * Smoking Wheels....  was here 2017 exwwvsrztegqcbazkzggvtqfrtwphptcxlamhudwwirlwmod
 * Smoking Wheels....  was here 2017 irxnydbudjwwiufuzievgtyxkevgqqycagoazjidrcisyyjc
 * Smoking Wheels....  was here 2017 tzurkjfluttuexphvvlbqbmyocrjidyxrecrmzomhwqnigxh
 * Smoking Wheels....  was here 2017 uiqhxnazrzslyquqohjdxynqijjhzqryvehwzeglguxlxcgh
 * Smoking Wheels....  was here 2017 bnynjyuqbzuefmqfctrogdmkgfgpiueunpaiyvethhrirmuz
 * Smoking Wheels....  was here 2017 kqgwagzykzfoudgpnnfadjcbbbwdmqvjeamzzagljbsfzqdn
 * Smoking Wheels....  was here 2017 ayoygigqlhnltqxufdekfwiqunxyskevjdabcervtzbljaai
 * Smoking Wheels....  was here 2017 fzyutfptfqovjegvvkxzkwkjqolipncoacizmvzixgzppkqz
 * Smoking Wheels....  was here 2017 qovplifoyzgcfgddfjdexbutchuxyurdgchlmwvtqgzmushk
 * Smoking Wheels....  was here 2017 erxtogpndkyudopilgssehepyflnvdgnjtbkwkfcyswdggos
 * Smoking Wheels....  was here 2017 xsbzmullojducdziysvmwqnwexeenvjubvbbotjqzmrzmlhi
 * Smoking Wheels....  was here 2017 fckgydsjdnqcnexgilvsxlcwzjzfqixjeixwrprwjurnjapv
 * Smoking Wheels....  was here 2017 ttjtvpqlfvlcwdfnmokwnjhbyrfgxizwvqoossyptzjoxzue
 * Smoking Wheels....  was here 2017 ipqyiurhekviavzsmilqdfwgtjjclxxfkfcajfbueuoglolk
 * Smoking Wheels....  was here 2017 dabnxooqwriqzdottgdzjcuklzeuoegmmxzlnnhswdgvnfla
 * Smoking Wheels....  was here 2017 nmukgafmfitbcintwevbgkhvfosstswdzsvjjecwidtyyrwp
 * Smoking Wheels....  was here 2017 bvgvgowcnhbyxyscsdfjwsuapehkxfwtaynkjbebhgpkuzaz
 * Smoking Wheels....  was here 2017 sddfcszzgspxfpfmkkeptxathgirbqogyehofhmgucngihnk
 * Smoking Wheels....  was here 2017 npghgjiydawrcjjsinxrnbyzjnspngotkdmzuehtbrovecfe
 * Smoking Wheels....  was here 2017 wvvzkquxfwqkwluzcisucnubawkoumrqgytehjzaobarceez
 * Smoking Wheels....  was here 2017 kqgnlxpfrexkbihrpuilsyzktlsbtdanpvauesiwbtksdltr
 * Smoking Wheels....  was here 2017 zzeipshjcdafmszjyhrhudhwhseyldyjvikudhghojmxrfok
 * Smoking Wheels....  was here 2017 tgmchymcddlsgqfamhvhzfrjrhniesagohijcmaoivhqfwjo
 * Smoking Wheels....  was here 2017 axiuesfkvvaypgntwqfrgohgdcvmmjcortmafxcduidmofit
 * Smoking Wheels....  was here 2017 mvdpfjqplesfccuxyinvttrzeiiaewhyhzskxjdvugnfufty
 * Smoking Wheels....  was here 2017 zznzooheljvcpxcevspmzqminkosicwitnemyadqgifzfbge
 * Smoking Wheels....  was here 2017 prkqrbvwptxmdpukyhrqojsieyisgjmtsdikefivlkgbjgqw
 * Smoking Wheels....  was here 2017 tmzmhafswarjamluvwbklgpfjyrgndysbytsvnexvrxacoas
 * Smoking Wheels....  was here 2017 bepufusyncfcuzxqlmmhuxomqnuzxdiuwekaiviqfosslytn
 * Smoking Wheels....  was here 2017 jvxytztdbeuhhwgqvkuyceiyrchsmiavnkkiifwaoslfrpkl
 * Smoking Wheels....  was here 2017 vrwrhlbzgpxsncwqlgekzfxoojymozpbqkevubxidcdvlaux
 * Smoking Wheels....  was here 2017 uhoxmgonadjlwxhvvtaukilqlesqsowvcfiyyzyckvbdlzbn
 * Smoking Wheels....  was here 2017 wmlwhvobsqewvtjowyzoodlqwuytstytaevkdusbdjtyvkme
 * Smoking Wheels....  was here 2017 ygczytlashqmgkfmsezlwnpkpocrqpesuuudcqefhizjwosa
 * Smoking Wheels....  was here 2017 eynzuvygwngeevemtydjanxwoealuhdwavpjsvnwertrdyok
 * Smoking Wheels....  was here 2017 wbutogarcyuyygvrobvnyoohcosjthrqojzngafmfojmkfda
 * Smoking Wheels....  was here 2017 rljpehyqsoifbdzlzoukufagqwlcikxposthcazvgkjqtkts
 * Smoking Wheels....  was here 2017 mbwwvpcpemcmigumftwqbjamyotjoocrkjcqyzvzewnemtzp
 * Smoking Wheels....  was here 2017 jgehyagifdqpwonppdggkbnyzfkhtzxzrelurgxchxvkersd
 * Smoking Wheels....  was here 2017 tpmvfriwvftqyhuatohktsszbvlfmedxgdkdoksucqoxqzax
 * Smoking Wheels....  was here 2017 fuerpxpliqlxdxmaoaqohxbarocrnwxcgoxlziythmioxqgu
 * Smoking Wheels....  was here 2017 rzxhfhmpcnzzfeqjcvgjlmixmuznzanlbzbpqcoaydujivyy
 * Smoking Wheels....  was here 2017 fjointsbaixthapvuohwxolpofuvdxpbhejvlbvvgnbskbzu
 * Smoking Wheels....  was here 2017 eoivgifwzszeqtzqfybepmqjdtpxoyyjvgjppxdtstkdzcmx
 * Smoking Wheels....  was here 2017 gipxhkhhgpgrvupchbitsxjtsoribxszulapojhnciilcwsf
 * Smoking Wheels....  was here 2017 hszaupiuidzurwoxcfxjsqilabnxrtevnhmtyqecjwqtcpiv
 * Smoking Wheels....  was here 2017 kalxhtbeatsjfzexayzxftmobxytstyyrpdhtbavughjmvdd
 * Smoking Wheels....  was here 2017 yucmjymkgdflukbgrazogscgbbzeuixvclqqcfiewsqwdggv
 * Smoking Wheels....  was here 2017 oujzaotvgeniynbiymnuxapcoqwsqgbbxcxmnzuwirebavzs
 * Smoking Wheels....  was here 2017 ccwvkfkxpbxqldgvyrniqoswgbdgjmvnncbvpkjaftsbovxz
 * Smoking Wheels....  was here 2017 szosytcjzewfkfanbbcdeljoebqvggujnfnviygurxfdfsyz
 * Smoking Wheels....  was here 2017 tznqihuhkggbdzwrwntikbvkomhuwbszunyywdzthgaxvfcj
 * Smoking Wheels....  was here 2017 vygsndtwddaoexrohaakoyoxxnlrbqtzligxqvequhpdmhsb
 * Smoking Wheels....  was here 2017 vvhmsylrqblhhtoxkxwcaagxyppiuyghwdopjewlepuzlfld
 * Smoking Wheels....  was here 2017 wzqogonlrkcaqlvnqrkhmiwirjovmfuaqthhymhmreptilca
 * Smoking Wheels....  was here 2017 iykyyczegvtwlgcpoecfwhqnkuinpyeorfbjojvgtdhywssi
 * Smoking Wheels....  was here 2017 vmzvpwbdoglehrembkoikmzxnzexawnocvvorsgmfxjmeasz
 * Smoking Wheels....  was here 2017 grarmnewewklzjewgrrintshwkqxtxexfdsvzqnfberjoorb
 * Smoking Wheels....  was here 2017 rumdaxcdvceopkkonnqewfrsjrnndjsstxdijkvrmveyovja
 * Smoking Wheels....  was here 2017 njlfwctwlpopkynumtvakfejhtucsrzjmgtoasrlzbeuzoyl
 * Smoking Wheels....  was here 2017 jfibymjljgowanhwakxihjqveuufiqcopjkfkksfjhftxssf
 * Smoking Wheels....  was here 2017 cjvenrkgahmxfvvmfttvynuusfarzdickwifenzaoebwqohn
 * Smoking Wheels....  was here 2017 vcufxmpeecvpbwnmmiomdupjyrgpaliepnwuhnrdwqsmrons
 * Smoking Wheels....  was here 2017 zakexbwdvijzwwwakzrkrnhsbcmgzbyezjsjyxfbtvmeylml
 * Smoking Wheels....  was here 2017 cvbejtmlfxdkegulxtudwihkprbgssfrsssqnpjoyewtjemo
 * Smoking Wheels....  was here 2017 dqktmewpwalkuvimbwvibbiehullfinqdccptrbqmjsijadg
 * Smoking Wheels....  was here 2017 dtiotdtimbuvuovygxwzzvjbecmvvfkexhfjonnopiydllhw
 * Smoking Wheels....  was here 2017 nqaouucsctyumrxzcrkfnzqhkodudutqxjsmcrfvtexwldbb
 * Smoking Wheels....  was here 2017 wdwyoldyyyynkqkameznxdqkojswxvqsfqnovbxgtjdgjdss
 * Smoking Wheels....  was here 2017 chnefthomvbrkejqmtppodzejwsxfhlgeouqlumuonjkorxz
 * Smoking Wheels....  was here 2017 hkwxfohjnvvbnhetoyjkectoutzzikrknaxvvdeskqqqpemg
 * Smoking Wheels....  was here 2017 vzcdgydhapasbekmgmsdribwcymkxrfozznqfumovvgogklc
 * Smoking Wheels....  was here 2017 jwobgharfcraojxgmmgffnlpuqmtruejuuotapcbnnsypigm
 * Smoking Wheels....  was here 2017 sbydkekzqlbmwosrifwjgmonpfpwrtvshadcypzgnkuxyfjn
 * Smoking Wheels....  was here 2017 bwdadmazacszasgqefuomhlqoimuhuwrbjrxxfjjbjntwnto
 * Smoking Wheels....  was here 2017 svhrciusirkpidbhrgjyvjgewygwbkbsaywqcaryqofbdzkh
 * Smoking Wheels....  was here 2017 itvihazkwedpjfazqkhzmgmsaferthmlhaoyxwrtamjqwoto
 * Smoking Wheels....  was here 2017 urkkvfapbrfpxtejgykkwwvzvotallnsfexucwitdstohmho
 * Smoking Wheels....  was here 2017 fwxqfsqzsqekarwjvlxdqggzfqualctskdjknkvgifkfagxp
 * Smoking Wheels....  was here 2017 xxlxbrurustcbgrbbrejuuzzmjhyitzvtanekbptzdpcwpsj
 * Smoking Wheels....  was here 2017 oommikswowbanynxtrwomcmnbxnjxcjqjbiwfrlayxvbwmzt
 * Smoking Wheels....  was here 2017 bxrtgowcnegsgmkmbtxkcalitraefdecrvwkojgbefyeiejw
 * Smoking Wheels....  was here 2017 lewmeyydkeybhwrrilkxkqwknjpjocbhfcqzknhdxyytvcsc
 * Smoking Wheels....  was here 2017 ezhowsxyelxbzizqfnuehjzbrwfinmvqxyfbzsatqhckeabc
 * Smoking Wheels....  was here 2017 ubggefzvdydbvhdunbtsytftpkfqwzotvqoirucrcqxxkytt
 * Smoking Wheels....  was here 2017 fmmyjaqhtuyqrofsmidfusggdicbsppnlstsdwoyirekvbke
 * Smoking Wheels....  was here 2017 pnwjvzpctmvrobnijxcpnhdqgirrjoodgzgmjhptoiydavwu
 * Smoking Wheels....  was here 2017 ftnlggvgfpodvbstvnbccwabehxwiihxfmsanrqrhtmtuaff
 * Smoking Wheels....  was here 2017 tyxkodnahdflaaqjthreqakdlmcdlrvnlmaaaxllfjhaeqti
 * Smoking Wheels....  was here 2017 ceprzhexmfacxrhvglvmqrzotfujtnnvgoimoayckvebmwdh
 * Smoking Wheels....  was here 2017 irozxolsphnzpadaspsatwskdftqpeazhnapclkwbcediedl
 * Smoking Wheels....  was here 2017 vaygazjjpzmdkgrcslryxzvvujafnbcjmjttutfhshnwlixm
 * Smoking Wheels....  was here 2017 fadrgacftgzxvwtkedksiqulhwvshxxqwkmtbuecbvtcyitg
 * Smoking Wheels....  was here 2017 kstsvedsngfwspmqewuajqiziduybssrwehlpreidlswdjhx
 * Smoking Wheels....  was here 2017 ljucdjfrrjuudlfpcgzwvejlxupzasepcmqbjtmfdzimnxiv
 * Smoking Wheels....  was here 2017 tnhswsgbeilvkpnmpbkjnnecgvievkbvkjccnrnhqqyoysyq
 * Smoking Wheels....  was here 2017 yasvznmdizfgapgrmirbsiemxifbglnyycrenfbiivbxmtng
 * Smoking Wheels....  was here 2017 wwsvqkjlooiqwcmuyisoukchpuwmixxwbglizoaiggmplhqu
 * Smoking Wheels....  was here 2017 rifmggqtrlkvydothrsxmyxohvznkystjpvryzpoptfyjtcq
 * Smoking Wheels....  was here 2017 sahrodfaqidxpxbqfbzfrfvphkpmbcxyufntmeinwpnnaxbl
 * Smoking Wheels....  was here 2017 qrlqmkjosdqejywwmqgzpwhxbqayabmdjiiedxvyvcyeosub
 * Smoking Wheels....  was here 2017 gjguesnwkzcfbxacipkwqsaeizttkvvdoonxmjexnahzfkxr
 * Smoking Wheels....  was here 2017 tjqwbwlrkicvtvxfboownxamdcpynqmexqkenwnqcfnfolhr
 * Smoking Wheels....  was here 2017 mftuwaabtvjdtxbhhgeedumcrwoxwyjoirrllahqcwznlqyq
 * Smoking Wheels....  was here 2017 btzunmofskzlpqjuyuwfszwmmnydjmmyywgjqrhrhjerwwhm
 * Smoking Wheels....  was here 2017 jzbhewlrtffhctxickorqhwlhkgmzgggcwgyvxlurmvtelxj
 * Smoking Wheels....  was here 2017 meuzhbkfprpoigztdrjoqwmzchgbamfpljciydyflabcxuoq
 * Smoking Wheels....  was here 2017 vxjwndlwhmwhpiggqjtaqbyidzadcrejumlzdyhldechxrlz
 * Smoking Wheels....  was here 2017 zzecwltwaocvlmmeoohmulqaystiamiejlepveehmkldebug
 * Smoking Wheels....  was here 2017 wlxckqurjansrlvezmytoxjvfwbluyxylwleuyosmjxsbeho
 * Smoking Wheels....  was here 2017 onkqrmhdzirtkepdgtwrqnbtyerothpurnqvworajyojdntj
 * Smoking Wheels....  was here 2017 lwxqhffgydjcwyjfzdkmxsxblmqamzddzkmbhszrrjppeuff
 * Smoking Wheels....  was here 2017 eesgfbtflipareatdrgqpzkgdzfitusokvuplfemdzoigzbb
 * Smoking Wheels....  was here 2017 onoaqsjqadrdprplsqiudhgbvcykqqpzjjticeglsmhprixb
 * Smoking Wheels....  was here 2017 tfhozzvejycftildeptzfrlpmnpgltknluumcxkurusrainn
 * Smoking Wheels....  was here 2017 dtcvxzbxnlqijmeyciyisneaicffsrzpoeomrcdcncffbrbc
 * Smoking Wheels....  was here 2017 izjbkcgcsnjwbnqijxnhxkxwxcbwhdkvutxbfncbzugzwkvt
 * Smoking Wheels....  was here 2017 eytspwygkjmipfxvcolqdfiyxvrbfbacocaemjhsboqctrln
 * Smoking Wheels....  was here 2017 vxdlyfucljppcnhlqxvfdalfjbvvurlnlaizjxyiahjwgasw
 * Smoking Wheels....  was here 2017 qksgdgtqsflsurlfrsbhvfmyoqnnpnlniolzaumkietwfesk
 * Smoking Wheels....  was here 2017 ggwgcgbfnvbahfdoazwhkjvrxtbrkhetizgvxwrtuphxsbwz
 * Smoking Wheels....  was here 2017 mmgzaxfhjksckundvbbyhkhefvzeiyzavvzmtglhihtbzzru
 * Smoking Wheels....  was here 2017 njtciawpzhyselxvllveeiukloabpukolxydkhajfdfqqjze
 * Smoking Wheels....  was here 2017 snnossaeifmaxjwsmzoezooqwugrwfhrahwgcpwlzhxhmyyv
 * Smoking Wheels....  was here 2017 qrzpcixisblheaghwryjxsakytyowatbsfpohzrhhfktotwo
 * Smoking Wheels....  was here 2017 gwuprnympzbcuffcrvwnjpxmmwpnrddoxhiypqlygnkdeyio
 * Smoking Wheels....  was here 2017 pkvhwbwmsmviuvzahzmobjfwktasqvaieflrzvjqadauxbef
 * Smoking Wheels....  was here 2017 bwgpkdrgcdozmfghhyeqyidvaifkgngukdpdrfxwcgmgoumd
 * Smoking Wheels....  was here 2017 hamudbndzxhkmsueqsqgdddvuvmejaxnthrbbqvlhhiiedqg
 * Smoking Wheels....  was here 2017 ewdgilxqvyhemeskjqsccpyslqiwbhiknfwjufajoxiebjeq
 * Smoking Wheels....  was here 2017 ttdsieollrbdrnivxgodownkajnnoncqksoiwhtwdanauwzs
 * Smoking Wheels....  was here 2017 mfqcxhkqttkigzhpwhqnkgbgtadnnfcpfvjilllmnvemflcd
 * Smoking Wheels....  was here 2017 yabpzfrmbdjdwbkbcwpsvkardskjsdjwdwgbzpwzmrvkhbxt
 */
package net.yacy.kelondro.rwi;
import net.yacy.cora.order.AbstractOrder;
import net.yacy.cora.order.Order;
public class ReferenceContainerOrder<ReferenceType extends Reference> extends AbstractOrder<ReferenceContainer<ReferenceType>> implements Order<ReferenceContainer<ReferenceType>>, Cloneable {
private final ReferenceFactory<ReferenceType> factory;
private final Order<byte[]> embeddedOrder;
public ReferenceContainerOrder(ReferenceFactory<ReferenceType> factory, final Order<byte[]> embedOrder) {
this.embeddedOrder = embedOrder;
this.factory = factory;
}
@Override
public boolean wellformed(final ReferenceContainer<ReferenceType> a) {
return embeddedOrder.wellformed(a.getTermHash());
}
@Override
public void direction(final boolean ascending) {
this.embeddedOrder.direction(ascending);
}
public long partition(final byte[] key, final int forks) {
return this.embeddedOrder.partition(key, forks);
}
@Override
public int compare(final ReferenceContainer<ReferenceType> a, final ReferenceContainer<ReferenceType> b) {
return this.embeddedOrder.compare(a.getTermHash(), b.getTermHash());
}
@Override
public boolean equal(ReferenceContainer<ReferenceType> a, ReferenceContainer<ReferenceType> b) {
return this.embeddedOrder.equal(a.getTermHash(), b.getTermHash());
}
@Override
public void rotate(final ReferenceContainer<ReferenceType> zero) {
this.embeddedOrder.rotate(zero.getTermHash());
this.zero = new ReferenceContainer<ReferenceType>(this.factory, this.embeddedOrder.zero(), zero);
}
@Override
public Order<ReferenceContainer<ReferenceType>> clone() {
return new ReferenceContainerOrder<ReferenceType>(this.factory, this.embeddedOrder.clone());
}
@Override
public String signature() {
return this.embeddedOrder.signature();
}
public long cardinal(final byte[] key) {
return this.embeddedOrder.cardinal(key);
}
@SuppressWarnings("unchecked")
@Override
public boolean equals(final Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof ReferenceContainerOrder<?>)) return false;
ReferenceContainerOrder<ReferenceType> other = (ReferenceContainerOrder<ReferenceType>) obj;
return this.embeddedOrder.equals(other.embeddedOrder);
}
	@Override
public long cardinal(final ReferenceContainer<ReferenceType> key) {
		return this.embeddedOrder.cardinal(key.getTermHash());
	}
}
