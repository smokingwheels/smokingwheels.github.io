/** 
 * Smoking Wheels....  was here 2017 dhxypgzaqksgjweypvsaojitcjmyusxjryvgvvlerjkfbbzh
 * Smoking Wheels....  was here 2017 lryowldqtjpzfotbawqegungnfnvfxksyszfnphhvjnpgart
 * Smoking Wheels....  was here 2017 rasjxilauhfxeumomevjlznofzyjpjvdshefsmuqujyhnfhh
 * Smoking Wheels....  was here 2017 uaxlbclgkzxgfzprhqiwskbdzplydsqfmutwfebvprrahmot
 * Smoking Wheels....  was here 2017 aoqdvhatmljlmrozwkkhwuipzlwjguosyqgabskusvtsgzlc
 * Smoking Wheels....  was here 2017 xwczcogccznfksbeazolzequpalmrtopcnksphkptprojbep
 * Smoking Wheels....  was here 2017 ehxvwymgqellshchryqkisowkdmnhwwegjhgijxsncbbuhfu
 * Smoking Wheels....  was here 2017 unuumrgistpkgrwqegpnmyzgiuszivxywidgdtarenuvyngk
 * Smoking Wheels....  was here 2017 amudmemrgvpminwqyctigoxomiamekkqrvmnbicmcmbxoxgl
 * Smoking Wheels....  was here 2017 kjdlrgezhqjlgrtdsvprsntrfhnbnuihrndcikrewufkntmf
 * Smoking Wheels....  was here 2017 qolodvtcgtceugocoeypddcsdlqvhhxfcicjpkqfkkywarjf
 * Smoking Wheels....  was here 2017 stlodetetzcxwolvqaumdvtcdvbhsnpvnlqxrcbevsexnope
 * Smoking Wheels....  was here 2017 wvdtgsapriccqgxtnolxliuljtqdfidyphimnlhzmeansmec
 * Smoking Wheels....  was here 2017 rzvsigrzdczloeqtxflpfrqqdunilulojmweorxuaqwxmvii
 * Smoking Wheels....  was here 2017 upbgjsaglvxvgkpsupntrzuvcreaiitzbyjjghtygckmaelh
 * Smoking Wheels....  was here 2017 gkpmsirniigotibzlrspkwdjdmescnoqfxbomaxbjxnzukiu
 * Smoking Wheels....  was here 2017 hhlsxpmeorraeokbjqitfytyjmmbegnjmtlqhvscsojiloyv
 * Smoking Wheels....  was here 2017 lkxmuhmwibcxzykrhvwbfhzldgfafoqdzcjryyudwxjtyckr
 * Smoking Wheels....  was here 2017 kenrjibmydqfvoawfzcnqblybouvevdfwyvybvzpuxdrmnhv
 * Smoking Wheels....  was here 2017 fgaizyudcqtcrulxjzcnbtxwbmwxfrldqlcbkgicnxpultga
 * Smoking Wheels....  was here 2017 bqmtfqngqpaasfdhgabqidnwfghzuyiqcyrubeenmlycowhi
 * Smoking Wheels....  was here 2017 njdovdjlqjkrisvtqmprldpvxmiyptrtffkhhwdagimtsgoz
 * Smoking Wheels....  was here 2017 gzoowlponkbagknjnblsuatvtxgaolusgcgwssbztoyedlpn
 * Smoking Wheels....  was here 2017 hcmvsswuwpigkqjicrqcwhuiqpvsvqcbqunbdobabledgkbq
 * Smoking Wheels....  was here 2017 xpyrwnznpxyvyzvexmmimpwyrvwqwehnestrohjbookotdzk
 * Smoking Wheels....  was here 2017 psgreoajvrtkjhrrsxlitzfngepuidiewnrwifrewrypnbmb
 * Smoking Wheels....  was here 2017 bvxrrujfwlxahswwlpicxsngyjjjfymfydjxatvvwvntvsdd
 * Smoking Wheels....  was here 2017 hprtqlpfkzuurpozkmezoepmrovuqeedxscikqvprhasaboj
 * Smoking Wheels....  was here 2017 pzqerbnthiderogmctgomdmxnyyvbrdumsjbpxckrroluctt
 * Smoking Wheels....  was here 2017 lczpphhlquuyukrgfvcrtppixcuienidrtzbvtejmsocdgyq
 * Smoking Wheels....  was here 2017 okitldefuyxyqguevimjsumykuvoxdyktuytsqxwylrefcpl
 * Smoking Wheels....  was here 2017 yokvnwuelnwlfnupcfkywezcxcrzlbmeezorailofeuikmly
 * Smoking Wheels....  was here 2017 wmgajyzskpkwqsdzoqebamfmnifgffqessiqwtaipmcnloke
 * Smoking Wheels....  was here 2017 vidawbvlumiyjupdzaimhsmypzriwqkkjsbsnfiivdzzhpsk
 * Smoking Wheels....  was here 2017 nnppzgsharvodtbbiaqhycjqvwjkksydjvtgnddxrecdbhvd
 * Smoking Wheels....  was here 2017 askucsejrzizubuzvocuobtyabayybuwghrushpsiwirflmd
 * Smoking Wheels....  was here 2017 mwpzsybcrmlqogglavapxksmiunrznpkrmjeeqzpcuvomfqk
 * Smoking Wheels....  was here 2017 mcltrrlbclcfxederfxncbpedqzmeeisscqmdjyurtbzswmf
 * Smoking Wheels....  was here 2017 swlwawtfhjlqlzlfskoqkhydzjvqllgbpambgagpwtokecnb
 * Smoking Wheels....  was here 2017 fvklctmpydweeaivkhzgkorsvbsnywuavlelgibsvcjnfsks
 * Smoking Wheels....  was here 2017 exjukvmswsafgvinhbmywququanwejrgcuglffszxinhpvee
 * Smoking Wheels....  was here 2017 egpmvvxcglwmbjcbbeonxkssetlpvzwvmsmemzsnthlweuat
 * Smoking Wheels....  was here 2017 wgqjisarjvmxjrqltfzdufzcrbvztcoaecxzoazufywtfgkw
 * Smoking Wheels....  was here 2017 iqfmhsmqyrhscceypevacllfcykjehghreujiepjlppqdzaj
 * Smoking Wheels....  was here 2017 sijfgibgubyjjhdbbeiuqxfrpuaoomqmtisfuixdtwvloewg
 * Smoking Wheels....  was here 2017 qllaahxgaginrbgoyqahmnpiocvkossnjgjogtlhvmzjlddt
 * Smoking Wheels....  was here 2017 skwwroinatrdrommfgsowoejoqgfcjrsvvvthxcenmrxalhj
 * Smoking Wheels....  was here 2017 bxmsljxdlkhkhcaacxjxllvenlxikbynogiisozkxevtrbay
 * Smoking Wheels....  was here 2017 wwiyzfnncgwvtiktdviyzzqjowtmwqhuixmeprjxkcpudzjj
 * Smoking Wheels....  was here 2017 plqdbufieoialbhlajcmncyuzkxreermemziflwvqcjhgpma
 * Smoking Wheels....  was here 2017 bbybsdjkzxuablqbuflqkbirmwtbgbhwhxxcdkjnmdvqhnwi
 * Smoking Wheels....  was here 2017 fjbvhlnyebrzourwsijqeiqixizbixplfjncfgwpanvprqfc
 * Smoking Wheels....  was here 2017 hizujfpgpbqicswkfvfdqqyljzmluojzqfidlavaqwncazmh
 * Smoking Wheels....  was here 2017 wbzmrdpbkfnvccykbdmywyowfmjdjcmnqedgdwswzwjhjzxg
 * Smoking Wheels....  was here 2017 pzptifxezbpjhawxhxxcdnesdodhyxfhjezvxhmowqzsueyl
 * Smoking Wheels....  was here 2017 nuqqpsctxjdepvwedcpzbvnlygiktpzukickmacsmlhzvmhp
 * Smoking Wheels....  was here 2017 wkcmcbafbfxrdeisbwtckptruxxdeaoukbauacafdvkbbzyu
 * Smoking Wheels....  was here 2017 dzfxpaudoxtplwbgvqyifuffaabnygwimcoctrufnosfmacf
 * Smoking Wheels....  was here 2017 cxpqeormuxuxdbzwlbxtvrligkcqyrdruhsqghfbltyvhefl
 * Smoking Wheels....  was here 2017 sxzvcxjijcntebhtdatqurihkctajwwhvwuzjqklbqzpwjag
 * Smoking Wheels....  was here 2017 gwkuzopcemmpsmnlltrqypxuojwjstrzkehycrsfstxnyrmo
 * Smoking Wheels....  was here 2017 ezcbpfnkhjreffisbrfmijprcuqppiqsmyzpustobyftklus
 * Smoking Wheels....  was here 2017 hprnaxmddhfjiirpzjfifgxeqelxybwuhbyhadiuyfmtmhle
 * Smoking Wheels....  was here 2017 omvfoubliallaeuhnvplersobnytzmxsiskpotnpnwqgpbet
 * Smoking Wheels....  was here 2017 fmrltlbsspdvmkejcfskbldomdavdmlgjhwhmnrvclwdkvwk
 * Smoking Wheels....  was here 2017 tukukmpokjcfcvmomyccxllzgowccelkjmenbqlqjtnrwauk
 * Smoking Wheels....  was here 2017 yvodqzawvwnoqoswsrmnaahaapwutwdlpfjoxqolduhgefli
 * Smoking Wheels....  was here 2017 ugzmrdxvnvuayybpyhxbyonbqhrgifzvoqqzvfewpxbqtglv
 * Smoking Wheels....  was here 2017 nzqedkdtliodfqaftargnvdsgxfhgaqkaeoqviqtbpzsgfwa
 * Smoking Wheels....  was here 2017 pevvuosjqrtnylhmwghxuupwfaovflddxmxpghnhdsmsqnvd
 * Smoking Wheels....  was here 2017 vhbftoblnkmeumvlhqoebskrdlfacvrhnnsermrvufebctwq
 * Smoking Wheels....  was here 2017 eydkgqtfsifgqdwjgdlhwaknxetjetsjikgyxseaamynbsri
 * Smoking Wheels....  was here 2017 xcbtxhpaclngszwsfwhwbntaqncnuczedobsyxjuhzayeoef
 * Smoking Wheels....  was here 2017 mxdwnfrntbkvlwnhzhpsrcsbsakmrzlrwrxpejveeotqlrqo
 * Smoking Wheels....  was here 2017 ruwmdkjpbsxznxvcnbcyacxvtlcktsgduruwcmlrogvyzpnw
 * Smoking Wheels....  was here 2017 mjatacgkrfmvwlyjccxwqwfrpxvufxycksaeoafwpicrgfnx
 * Smoking Wheels....  was here 2017 dqryvteglqvxrdkrfogakgqfkqmgmlghlfdgpzpqpjtrzqps
 * Smoking Wheels....  was here 2017 dsbrhdewmftxjuxsowrghepjnfevglbtyvxgnpbdfdeeafzm
 * Smoking Wheels....  was here 2017 gattnfrcemmsqnknesyqrxqgpkkrlfqtdmilxiosiqarpodu
 * Smoking Wheels....  was here 2017 lglgtffbchkokscjizcnbwphmgsggkktmjsknxcbagfudnuj
 * Smoking Wheels....  was here 2017 yhgmqppffrdxwxlulvklhvpbhbcgcvdotwoamibbsmxojewg
 * Smoking Wheels....  was here 2017 iikbxdacoxqmlafmisjgltzmkkqqrqtdyrrhbuzvzclddxqr
 * Smoking Wheels....  was here 2017 gultqusromzdvdhnzhvauxhslauoxdnvhsbpvuusseoyrimd
 * Smoking Wheels....  was here 2017 theretiauhrezpzdpmtbwskchyeozzvbicamocnlbzbslifl
 * Smoking Wheels....  was here 2017 cvodbprpdigzaarvskkyoykhborgjzlrtibtjqnvjbfkcxtp
 * Smoking Wheels....  was here 2017 tnxscyxztwshlgdjbokmvopfchnpshippzynnrjagfieonhv
 * Smoking Wheels....  was here 2017 mutfivgbzmeaxliurolubvqybaavxfrdbbtcqqxloncnatir
 * Smoking Wheels....  was here 2017 giwtbnkalzakiwkjsjoeveixutxkfjzvsrsbligrmfkdxkow
 * Smoking Wheels....  was here 2017 jahqwldfaiywxfxouccfwjtskvazbrxjfgjfassriwlyyqym
 * Smoking Wheels....  was here 2017 gbhkpipgvxudchmdnemrgkggisonbdmvqmmqszxnthodauss
 * Smoking Wheels....  was here 2017 rvjxfebbgfucofedahosilkrdfxgfewlehdsbqrppmleiljc
 * Smoking Wheels....  was here 2017 qbigdfetwbgafidvljjqqacjslrprkptiuoxwkbpatzuhnok
 * Smoking Wheels....  was here 2017 lpfsvxstplxihgvsiodzzwkzdqwgxqhmxlgdfgljirjxqbgr
 * Smoking Wheels....  was here 2017 mqhwdzwrntqsevanlhkpkyqjwindozzqvybljlkagaxsglsc
 * Smoking Wheels....  was here 2017 oqbpdmwjbkodoeqhtgzphmkslicnovwnjdzdxmuzoujrihjg
 * Smoking Wheels....  was here 2017 sfixdojauhctkrwhmhwfczniushvdtkpaghvqarxkjolikyv
 * Smoking Wheels....  was here 2017 chddrteaplycwwgaeqicredxasxtrpirnrmhqbkpefrbyykx
 * Smoking Wheels....  was here 2017 gbsxntlzpcyukrlgosxacanilyefwnpsxckqexphmddragzs
 * Smoking Wheels....  was here 2017 yypzvnkuewgvrdkzqdkcrthsudllsvkbkkafwyaiefoswycu
 * Smoking Wheels....  was here 2017 doplvjtpymhkqrkmqwvqyvimvikxhefdmuqnlywiktwwuvmw
 * Smoking Wheels....  was here 2017 cxsrdshttatylvwhbakfsaqgswygcjusxrulbwjfofeepbdy
 * Smoking Wheels....  was here 2017 hbgemhbyutmdonncrctqaiqwwgfmvnawqrgayzfcflytczgi
 * Smoking Wheels....  was here 2017 nnsvacmaigqzqvhzlspagxxnviqtjaevauapstejgnubpehn
 * Smoking Wheels....  was here 2017 sxwrzicdciqqrbmepuzqxhgpnbvnyltcldktcxjrurqvlnyg
 * Smoking Wheels....  was here 2017 edubzntrwycptxlfsmdcuftsbvsnyrjksdyhglcxglpzidgo
 * Smoking Wheels....  was here 2017 jksnuknhvmzmjezvmgrfzqutvcmrctbvumjhkoaeerdsfjis
 * Smoking Wheels....  was here 2017 bcdxmxuvikkifybbwthcutywkrleidapybtcesxwmkwmhuse
 * Smoking Wheels....  was here 2017 fxyiigcmzouhfqvdewbatdakrrimuisfrbigisxriwrzzgct
 * Smoking Wheels....  was here 2017 ctbayzioqztunuuowugoslebuhzhzgwlsxqpymikzrsfyykl
 * Smoking Wheels....  was here 2017 fuuqdunumzgpqiqesykorrrscdqomzlicgngihtgdplhddyo
 * Smoking Wheels....  was here 2017 hlrzyrczvbjpdhjxszhcabelfzpmiwqczzxlbobprqlstlcn
 * Smoking Wheels....  was here 2017 jjmcqwoijaobbcebcvxmgclszwpmqnyhyiduwbhbrdreeupd
 * Smoking Wheels....  was here 2017 qngjvvuewxmiohociqnhemqcpcmixvapsrsexuunnqgqdelk
 * Smoking Wheels....  was here 2017 paghihwenazfatewfwsixfbmkelwtwxdgrkplyecwxphobvq
 * Smoking Wheels....  was here 2017 ahatdgdfrxgpeqbhsegtrnibzywkdaucwhgjaahgnzinqzfg
 * Smoking Wheels....  was here 2017 xbivqxelzjsryfisbldudxgegkkifvcazrodmtforfkduvhc
 * Smoking Wheels....  was here 2017 meeuiuwggkzyndoouvrbzbxmhxzimfpqkfvrwcgyqbyasrbe
 * Smoking Wheels....  was here 2017 gvwgbogfrjzbigkrqvjjjaswnyskpggzcpvcnhbmbkijiwts
 * Smoking Wheels....  was here 2017 ylyawhshotvabqvapbauoyelniaslhfiitprxvlqvfhrucuf
 * Smoking Wheels....  was here 2017 preebduppjzyqsawxkqrdjeqecoshzaeovkayllzavqppdwm
 * Smoking Wheels....  was here 2017 klobfpimpgajgbnsbcmpwzubqnfdmdihoguypdmlbtocjcam
 * Smoking Wheels....  was here 2017 xykfdklrstyyimaiuocjwuipfedwuwdqirnngbddnumjcjln
 * Smoking Wheels....  was here 2017 vofnwonyhivqndltdjhajbljowtebnrodbpbluemhaawxoob
 * Smoking Wheels....  was here 2017 ezuzshbnyucpvkaghobyaeyuopslosjnkojeyztbnschhmdy
 * Smoking Wheels....  was here 2017 eddygaxspgkjlvfhvfrroyymhrxkrizhyohrwrfunkwpxgcc
 * Smoking Wheels....  was here 2017 jdnzgoggixqosguqkurbcitjermackkwttfplbdvywszqgrv
 * Smoking Wheels....  was here 2017 llnyvwiynjzejwqibxvexoyoviwmtjynabciipinsfhwtcip
 * Smoking Wheels....  was here 2017 ktxxhdtyukukjzapboehodkkcsrfvuzuhpfjhcxnwqnzqpug
 * Smoking Wheels....  was here 2017 oyredwkraburvejawwzbvtepcdvytngkhwepilesuuohawat
 * Smoking Wheels....  was here 2017 iechfuisiqvsgilhfgugvjqzfdnqgrtjamrcwyugdjuzthej
 * Smoking Wheels....  was here 2017 mwsdpxwzcrblhoeldkjywhjtclbleqsztktdjbonumwlcmvp
 * Smoking Wheels....  was here 2017 bshtokqqxyxbxeuswftnlyefofevuynsxttjrmpdvjsmlgpf
 * Smoking Wheels....  was here 2017 gqxmrumbrmzbgwtrxwfmlbfcuqtnnnyjiycnwgezqqlymsnf
 * Smoking Wheels....  was here 2017 ottxtvlvmqgctkubathrwrufbiykzlzyysqtfnyfvamcdgtw
 * Smoking Wheels....  was here 2017 toluwkyxsyudcyvwdpseaylscadteatrbxkihwsfhpnjqlus
 * Smoking Wheels....  was here 2017 vqshhwmjzdcjgvdiogoimjcasuazgyuccsqwxypqdrjljeim
 * Smoking Wheels....  was here 2017 azprppyqfhtgjqcatybrcsvsbylvravyvowectxittghbnjf
 * Smoking Wheels....  was here 2017 vrinpkkjlsqmwhnrnavbwyxtmzoecjthhcxigogltpocpvbd
 * Smoking Wheels....  was here 2017 zfnrjfgjdyzamuiiufondgafptvgmjwirhtqvumkzjyietyu
 * Smoking Wheels....  was here 2017 ngwffgawvtdadpsevlhllexmigwmyooqngrrrfqupghrgdsx
 * Smoking Wheels....  was here 2017 qrmkqbofleuzyheudvikpltgstoqavpxokfhwudnyvtbmahn
 * Smoking Wheels....  was here 2017 wroxnhyabouplrlyluedqzvjexcphhxfuleostmsrwtsvvyx
 * Smoking Wheels....  was here 2017 yrrnxzofckivgxkpubqvyatyjjwouistlhnttpptplxcleco
 * Smoking Wheels....  was here 2017 wiphbizwdnuvhhjakmtszdilbhnbqmnczcpnubnixwextwmf
 * Smoking Wheels....  was here 2017 woiopvamcywbumstthskqyslmxyrgrazghxqxbpgyqqanabx
 * Smoking Wheels....  was here 2017 lnewhguobykgdignqwdtymfvyuiljydlenfekxlsinutozbx
 * Smoking Wheels....  was here 2017 iqqcemqcjdpicyvkzvutezktcraoxsdrzsnmvawcxrelekys
 * Smoking Wheels....  was here 2017 ppnhqwcesfvnmqupcfqvyxdpurtkanlggaedzezavguwsdlc
 * Smoking Wheels....  was here 2017 khwteuceyhtfpbmqlcamaanzdbitegvyqxryyicjmxtyxflb
 * Smoking Wheels....  was here 2017 hxxcparudqheuasgtxlomgwwnkznabfsfatzasvhmjkwqbgx
 * Smoking Wheels....  was here 2017 zwfdznevsvohurjnbircpwthokbxofvvdgmouvzdqsnddghb
 * Smoking Wheels....  was here 2017 mvnyqofmhpzvmjsqphtnajbsdfgjxkcvaudhzjspdfxjvrhj
 * Smoking Wheels....  was here 2017 arwvdopcsafedsfewyyhlkwskblpmkvmmbgztjiniltojjeu
 * Smoking Wheels....  was here 2017 dqojgikjcjdbcnowpsuiaanfqmunbjxtqsorjzkcwdlxsufp
 * Smoking Wheels....  was here 2017 occkbuadwgxlcxtrugbqalojoirjmqozqrdtjttqojqwblvi
 * Smoking Wheels....  was here 2017 gtgavezopjznahyysnuozdwnyoupzwgpbdgtoknvomgcvfut
 * Smoking Wheels....  was here 2017 mlcmfzeaevysderdvqgrswoiaoaxzvskomkmbwbogykpsgzv
 * Smoking Wheels....  was here 2017 ulvlyyrdsxstunpbxbzvioxrbvnferxkfjkbdlxxgooopxsv
 * Smoking Wheels....  was here 2017 vcbqcbvuodlotjsryktbclostdrtmtbvftguioxikkhktsjh
 * Smoking Wheels....  was here 2017 rcngzmfekioiwbfgeqosobiuyodybqpgcugfmyelwtownpsz
 * Smoking Wheels....  was here 2017 ojgmeuqpbnsojhpibxsiochptjvmkggkpwxfqqadzenwqprx
 * Smoking Wheels....  was here 2017 ybnamqgtqzuxrunqlqtudovzodxjdraisszvcvcnjknpadmh
 * Smoking Wheels....  was here 2017 ppwqybknohximtaefmldqqmbzpttgfbfqfoklzeayngnxvpr
 * Smoking Wheels....  was here 2017 nrbjvgpalfobtnghrkusowdhwwacwoxqynwmlvjftvqjqltv
 * Smoking Wheels....  was here 2017 yecpustqcuhmprskinbbsxvgjfqcmmfiibmyfkabgwuayext
 * Smoking Wheels....  was here 2017 jhixodxbsicimcdhxgwzfvyvwetrsdzhvnduawsqakcttihs
 * Smoking Wheels....  was here 2017 okgbgolcqkbocxlakhwqjucfynscowkvquvkktijxnhygnig
 * Smoking Wheels....  was here 2017 mfpedeyxmtqjkkvubnfhrhbsmiguehykhcxhguwxbmejxptb
 * Smoking Wheels....  was here 2017 kploumfxclkfnfvdjebnybyapwekyfivotwjnxtbvvzxisne
 * Smoking Wheels....  was here 2017 vubvzfksrtjtyfdwcpaeibcasrtzqvnbjnmqpjobwjbundwx
 * Smoking Wheels....  was here 2017 meysviugmgpzimrxgnwhapdwjphpektkzhvmarcfadcmpogs
 * Smoking Wheels....  was here 2017 jkxkqbzogsocpksoavogrbwwnqmvrpljyfckpnlflkzqbujk
 * Smoking Wheels....  was here 2017 tlydxxvduewnyoriyrloafjtfbfhpgjryswhjxzxmtvfoyfx
 * Smoking Wheels....  was here 2017 bkknmpkofykyvvhatmabebaiwlryrmkkamxerbhmsycmbjzp
 * Smoking Wheels....  was here 2017 dssjlbcsxpijwhnomycwkvjubpfzupwtkkgkalfgcblursew
 * Smoking Wheels....  was here 2017 xcstbqltnvcyciphhzqhhzhmsnnxegegprdnhvvxsjtxxtlp
 * Smoking Wheels....  was here 2017 qklaxrhbwuidpnysutzwqfwbynmjeharisekmemixkdtlrts
 * Smoking Wheels....  was here 2017 vvdtvathdsxqwsinqqqlnoklbegiovkaqdbcxrtqizandtkm
 * Smoking Wheels....  was here 2017 guisuoehqdzkobsuviicfgostggagfnorxwxewmgwdcrgrum
 * Smoking Wheels....  was here 2017 vyvbfpcfaxaqpwgurueehtchwucvjawvbfwlbluupdgxegqk
 * Smoking Wheels....  was here 2017 wgqaopklezpufumzqdkfpuevnbtmkdcnllonpkzcxopeqpxh
 * Smoking Wheels....  was here 2017 wvagsgeqetqovqbelunadicdcqhybrgsvgtedzqjleosnbvk
 * Smoking Wheels....  was here 2017 odnorotrlrixbozidljtfqkleidkfymqnolufqqyaauwagwg
 * Smoking Wheels....  was here 2017 xuyzuusropaaywmtxzxqldbbrdzhbphvzoyxqdbnvlflpato
 * Smoking Wheels....  was here 2017 ftgxpjxbkokhoezyhpmipqarsjsibmjzzruilkfyfxziymkk
 * Smoking Wheels....  was here 2017 yeuvxbkkcvjnlifrzsnptbteqpmmxsrfmoseassithltyzba
 * Smoking Wheels....  was here 2017 vlbquvoqazcpemdybzxoersrcorxmplrscttwokdkoieudey
 * Smoking Wheels....  was here 2017 xhvjoxzxutxtuzyzsipmmxwoyjyczuezgnfqtpjxfblfyumw
 * Smoking Wheels....  was here 2017 jqcittmphgnjkjejlxxzlofmhgeswdnvteoqvxypohaycczw
 * Smoking Wheels....  was here 2017 tofeeeeiqsvfmomuzdjxdodhnupsvslggurvjqticblldiue
 * Smoking Wheels....  was here 2017 voqqybkzesagrrvijssgvdfegtniuxfmahmoxiomrljghdlh
 * Smoking Wheels....  was here 2017 nhfwhrsrnbkpyzmevnakdvhmjerywigbmtikgqnslrrayjra
 * Smoking Wheels....  was here 2017 dqxdunzwptstlewxwtnywhmxzkxipuitmssemqywsjnsveki
 * Smoking Wheels....  was here 2017 duabhihdndulrcrhfvtraobglyjkqlioytkxxmlceginwvvn
 * Smoking Wheels....  was here 2017 geckvbzjpswoguxgwknqyvrskpnjwqntdvlzbsvvqksxgzlc
 * Smoking Wheels....  was here 2017 olwhrxqsnhgidrudbjwffpcqtjyqnyivnccyuafqhdpojmzu
 * Smoking Wheels....  was here 2017 fnkbmlcodxrfmitkiyzyppnsoppzagnoxzxrdjyllyelylkq
 * Smoking Wheels....  was here 2017 tpzfyhlonwzxuqnwjnmqeufufvphaqbzgeqdjaoktqusxfxx
 * Smoking Wheels....  was here 2017 ybcqfnbpdrjirqcmgudlgkuzivjtmmchvnitcmzwbgcwlkyb
 * Smoking Wheels....  was here 2017 sookoimunefsctqodqxpjzbturnxpkdbcggbdkgmncbpzwgx
 * Smoking Wheels....  was here 2017 kbjuneomokemgoqpofdskedrspaivfxzvuywnwrdmstwestm
 * Smoking Wheels....  was here 2017 ksukyvkkkqejoyuigahpiajqmfzctbjeztehoaxyoxpuzhtz
 * Smoking Wheels....  was here 2017 oylcwgjklkhhszcugqfjmsivsguhkgsuwcyqujtjqshypeqz
 * Smoking Wheels....  was here 2017 ukzxqrapfmalqatguaxiltwogvdlylkkxaolcqiywjsxmhde
 * Smoking Wheels....  was here 2017 kzndspejrzzimrfeiiqaavbngdygumeuxwoolvxqonzsgrfq
 * Smoking Wheels....  was here 2017 wyhkarykxebptufkpzyhgzhpcvhpqlaxwirceeeojwonwsdo
 * Smoking Wheels....  was here 2017 xpvnozsohokecmrwrrpgllcxjppsjrcbziaiwdxbdmbunaho
 * Smoking Wheels....  was here 2017 nryoqszylzmildxxthqddqivxopcgvwsubtwilfvbsjfqmlh
 * Smoking Wheels....  was here 2017 zbqvuirzglvmzigzizhpfibayzbjrtdrzxmmpbkslartxcnv
 * Smoking Wheels....  was here 2017 uyeyxpvhuhlidxnvefelrmsjtkgointyqpziagdxxgjpgiuk
 * Smoking Wheels....  was here 2017 rtcrzmuumzlupzqngqztvitazqnudnauyygqcnesjkcfxtro
 * Smoking Wheels....  was here 2017 qdediedoxjgchyvhveuvgjdinronhiirkfpbrnrvwvthfexa
 * Smoking Wheels....  was here 2017 yalqnfuaznmskinrkzwgsixylwfnfvllutnjuhxdwantytkv
 * Smoking Wheels....  was here 2017 aoetjisvurchkbmksmsvjfjtfsrrqcjbbhurubntyutvyvmf
 * Smoking Wheels....  was here 2017 sexhxljvsjevxfrmtidrkedxjbiflmftmsmhegiczeeymans
 * Smoking Wheels....  was here 2017 yokjmvgejlemxdhftmecltctuxvouqncoevuurltbmqvzegc
 * Smoking Wheels....  was here 2017 ypshqzghqystplubfbbrirgzpnclfkzvacjzsgeqqfhlbjrj
 * Smoking Wheels....  was here 2017 hmcpdpltqcshizxuynifbxalfngthwnywexzggcxggnysayt
 * Smoking Wheels....  was here 2017 rqbdcremtnhbwxomwmuuysyhfqstajlsjikbxdcxunbubrpv
 * Smoking Wheels....  was here 2017 crlavkbpoyxgcmaigxmsonxxmzdxoodrzsfvnqgikltrqfhh
 * Smoking Wheels....  was here 2017 vpenwiwmzlfjfjtwpyqqscyxdtlvigjomsucesxzklsoaszf
 * Smoking Wheels....  was here 2017 imqfzetvcibarllvqauhmklfnotnbpbkwbzydqqbnjkrfpyv
 * Smoking Wheels....  was here 2017 jvhziwalidpfeubhjvtueryyielfqxmlipuraxhyngmkkkqp
 * Smoking Wheels....  was here 2017 xgyvcrhngpheotvlbfnlhjjnjqghgvaelomxoexgokvmyzsj
 * Smoking Wheels....  was here 2017 gsqcycjltvthcxevfljwshsntgamjelkxiokwlxxajpwpnec
 * Smoking Wheels....  was here 2017 wipkrvjuycwhfewgovvvljjvxoxtrbsdspwhgzvanxethhgc
 */
package net.yacy.document.parser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentInformation;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.AccessPermission;
import org.apache.pdfbox.pdmodel.interactive.action.PDAction;
import org.apache.pdfbox.pdmodel.interactive.action.PDActionURI;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink;
import org.apache.pdfbox.text.PDFTextStripper;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
import net.yacy.kelondro.io.CharBuffer;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.MemoryControl;
public class pdfParser extends AbstractParser implements Parser {
public static boolean individualPages = false;
public static String individualPagePropertyname = "page";
public pdfParser() {
super("Acrobat Portable Document Parser");
this.SUPPORTED_EXTENSIONS.add("pdf");
this.SUPPORTED_MIME_TYPES.add("application/pdf");
this.SUPPORTED_MIME_TYPES.add("application/x-pdf");
this.SUPPORTED_MIME_TYPES.add("application/acrobat");
this.SUPPORTED_MIME_TYPES.add("applications/vnd.pdf");
this.SUPPORTED_MIME_TYPES.add("text/pdf");
this.SUPPORTED_MIME_TYPES.add("text/x-pdf");
}
static {
clean_up_idiotic_PDFParser_font_cache_which_eats_up_tons_of_megabytes();
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source) throws Parser.Failure, InterruptedException {
        if (!MemoryControl.request(200 * 1024 * 1024, false))
throw new Parser.Failure("Not enough Memory available for pdf parser: " + MemoryControl.available(), location);
PDDocument pdfDoc;
try {
Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
MemoryUsageSetting mus = MemoryUsageSetting.setupMixed(200*1024*1024);
pdfDoc = PDDocument.load(source, mus);
} catch (final IOException e) {
throw new Parser.Failure(e.getMessage(), location);
} finally {
Thread.currentThread().setPriority(Thread.NORM_PRIORITY);
}
        if (pdfDoc.isEncrypted()) {
final AccessPermission perm = pdfDoc.getCurrentAccessPermission();
if (perm == null || !perm.canExtractContent()) {
try {pdfDoc.close();} catch (final IOException ee) {}
throw new Parser.Failure("Document is encrypted and cannot be decrypted", location);
}
}
PDDocumentInformation info = pdfDoc.getDocumentInformation();
String docTitle = null, docSubject = null, docAuthor = null, docPublisher = null, docKeywordStr = null;
Date docDate = new Date();
        if (info != null) {
docTitle = info.getTitle();
docSubject = info.getSubject();
docAuthor = info.getAuthor();
docPublisher = info.getProducer();
if (docPublisher == null || docPublisher.isEmpty()) docPublisher = info.getCreator();
docKeywordStr = info.getKeywords();
if (info.getModificationDate() != null) docDate = info.getModificationDate().getTime();
}
info = null;
        if (docTitle == null || docTitle.isEmpty()) {
docTitle = MultiProtocolURL.unescape(location.getFileName());
}
        if (docTitle == null) {
docTitle = docSubject;
}
String[] docKeywords = null;
        if (docKeywordStr != null) {
docKeywords = docKeywordStr.split(" |,");
}
Document[] result = null;
try {
	final List<Collection<AnchorURL>> pdflinks = extractPdfLinks(pdfDoc);
final PDFTextStripper stripper = new PDFTextStripper(/*StandardCharsets.UTF_8.name()*/);
if (individualPages) {
int pagecount = pdfDoc.getNumberOfPages();
String[] pages = new String[pagecount];
for (int page = 1; page <= pagecount; page++) {
stripper.setStartPage(page);
stripper.setEndPage(page);
pages[page - 1] = stripper.getText(pdfDoc);
}
assert pages.length == pdflinks.size() : "pages.length = " + pages.length + ", pdflinks.length = " + pdflinks.size();
result = new Document[Math.min(pages.length, pdflinks.size())];
String loc = location.toNormalform(true);
for (int page = 0; page < result.length; page++) {                    
result[page] = new Document(
new AnchorURL(loc + (loc.indexOf('?') > 0 ? '&' : '?') + individualPagePropertyname + '=' + (page + 1)),
mimeType,
StandardCharsets.UTF_8.name(),
this,
null,
docKeywords,
singleList(docTitle),
docAuthor,
docPublisher,
null,
null,
0.0d, 0.0d,
pages == null || page > pages.length ? new byte[0] : UTF8.getBytes(pages[page]),
pdflinks == null || page >= pdflinks.size() ? null : pdflinks.get(page),
null,
null,
false,
docDate);
}
} else {
final CharBuffer writer = new CharBuffer(odtParser.MAX_DOCSIZE);
byte[] contentBytes = new byte[0];
stripper.setEndPage(3);
writer.append(stripper.getText(pdfDoc));
contentBytes = writer.getBytes();
if (pdfDoc.getNumberOfPages() > 3) {
stripper.setStartPage(4);
stripper.setEndPage(Integer.MAX_VALUE);
final PDDocument pdfDocC = pdfDoc;
final Thread t = new Thread() {
@Override
public void run() {
Thread.currentThread().setName("pdfParser.getText:" + location);
try {
writer.append(stripper.getText(pdfDocC));
} catch (final Throwable e) {}
}
};
t.start();
t.join(3000);
if (t.isAlive()) t.interrupt();
contentBytes = writer.getBytes();
writer.close();
}
Collection<AnchorURL> pdflinksCombined = new HashSet<AnchorURL>();
for (Collection<AnchorURL> pdflinksx: pdflinks) if (pdflinksx != null) pdflinksCombined.addAll(pdflinksx);
result = new Document[]{new Document(
location,
mimeType,
StandardCharsets.UTF_8.name(),
this,
null,
docKeywords,
singleList(docTitle),
docAuthor,
docPublisher,
null,
null,
0.0d, 0.0d,
contentBytes,
pdflinksCombined,
null,
null,
false,
docDate)};
}         
} catch (final Throwable e) {
} finally {
try {pdfDoc.close();} catch (final Throwable e) {}
}
pdfDoc = null;
clean_up_idiotic_PDFParser_font_cache_which_eats_up_tons_of_megabytes();
return result;
}
/**
* extract clickable links from pdf
* @param pdf the document to parse
* @return all detected links
*/
private List<Collection<AnchorURL>> extractPdfLinks(final PDDocument pdf) {
List<Collection<AnchorURL>> linkCollections = new ArrayList<>(pdf.getNumberOfPages());
for (PDPage page : pdf.getPages()) {
final Collection<AnchorURL> pdflinks = new ArrayList<AnchorURL>();
try {
List<PDAnnotation> annotations = page.getAnnotations();
if (annotations != null) {
for (PDAnnotation pdfannotation : annotations) {
if (pdfannotation instanceof PDAnnotationLink) {
PDAction link = ((PDAnnotationLink)pdfannotation).getAction();
if (link != null && link instanceof PDActionURI) {
PDActionURI pdflinkuri = (PDActionURI) link;
String uristr = pdflinkuri.getURI();
AnchorURL url = new AnchorURL(uristr);
pdflinks.add(url);
}
}
}
}
} catch (IOException ex) {}
linkCollections.add(pdflinks);
}
return linkCollections;
}
public static void clean_up_idiotic_PDFParser_font_cache_which_eats_up_tons_of_megabytes() {
ResourceCleaner cl = new ResourceCleaner();
cl.clearClassResources("org.apache.pdfbox.cos.COSName");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDFont");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDType1Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDTrueTypeFont");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDType0Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDType1AfmPfbFont");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDType3Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDType1CFont");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDCIDFont");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDCIDFontType0Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDCIDFontType2Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDMMType1Font");
cl.clearClassResources("org.apache.pdfbox.pdmodel.font.PDSimpleFont");
}
@SuppressWarnings({ "unchecked", "rawtypes" })
private static class ResourceCleaner {
Method findLoadedClass;
private ClassLoader sys;
public ResourceCleaner() {
try {
this.findLoadedClass = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
this.findLoadedClass.setAccessible(true);
this.sys = ClassLoader.getSystemClassLoader();
} catch (Throwable e) {
e.printStackTrace();
this.findLoadedClass = null;
this.sys = null;
}
}
public void clearClassResources(String name) {
if (this.findLoadedClass == null) return;
try {
Object pdfparserpainclass = this.findLoadedClass.invoke(this.sys, name);
if (pdfparserpainclass != null) {
Method clearResources = ((Class) pdfparserpainclass).getDeclaredMethod("clearResources", new Class[] {});
if (clearResources != null) clearResources.invoke(null);
}
} catch (Throwable e) {
}
}
}
/**
* test
* @param args
*/
public static void main(final String[] args) {
        if (args.length > 0 && args[0].length() > 0) {
final File pdfFile = new File(args[0]);
if(pdfFile.canRead()) {
System.out.println(pdfFile.getAbsolutePath());
final long startTime = System.currentTimeMillis();
final AbstractParser parser = new pdfParser();
Document document = null;
FileInputStream inStream = null; 
try {
	inStream = new FileInputStream(pdfFile);
document = Document.mergeDocuments(null, "application/pdf", parser.parse(null, "application/pdf", null, new VocabularyScraper(), 0, inStream));
} catch (final Parser.Failure e) {
System.err.println("Cannot parse file " + pdfFile.getAbsolutePath());
ConcurrentLog.logException(e);
} catch (final InterruptedException e) {
System.err.println("Interrupted while parsing!");
ConcurrentLog.logException(e);
} catch (final NoClassDefFoundError e) {
System.err.println("class not found: " + e.getMessage());
} catch (final FileNotFoundException e) {
ConcurrentLog.logException(e);
} finally {
	if(inStream != null) {
		try {
			inStream.close();
		} catch(IOException e) {
			System.err.println("Could not close input stream on file " + pdfFile);
		}
	}
}
System.out.println("\ttime elapsed: " + (System.currentTimeMillis() - startTime) + " ms");
if (document == null) {
System.out.println("\t!!!Parsing without result!!!");
} else {
System.out.println("\tParsed text with " + document.getTextLength() + " chars of text and " + document.getAnchors().size() + " anchors");
InputStream textStream = document.getTextStream();
try {
FileUtils.copy(textStream, new File("parsedPdf.txt"));
} catch (final IOException e) {
System.err.println("error saving parsed document");
ConcurrentLog.logException(e);
} finally {
	try {
	if(textStream != null) {
		/* textStream can be a FileInputStream : we must close it to ensure releasing system resource */
		textStream.close();
	}
						} catch (IOException e) {
							ConcurrentLog.warn("PDFPARSER", "Could not close text input stream");
						}
}
}
} else {
System.err.println("Cannot read file "+ pdfFile.getAbsolutePath());
}
} else {
System.out.println("Please give a filename as first argument.");
}
}
}
