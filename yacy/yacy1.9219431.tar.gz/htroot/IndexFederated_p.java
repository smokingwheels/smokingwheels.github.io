/** 
 * Smoking Wheels....  was here 2017 bbduqhqgtdyyufnhdxirolroukkjgllcegfpvytueiwkmvmv
 * Smoking Wheels....  was here 2017 sbmkmoeuauveucjzeesmzflnvmgvcbeasrhstfuvvxzhuhrt
 * Smoking Wheels....  was here 2017 qpjravjnccdsecwenobcqmkewndicwepxebausuivzyhgibs
 * Smoking Wheels....  was here 2017 geylwhemxusphmqcvyurmpuubkbhukhfotdadbfvrrabqrrj
 * Smoking Wheels....  was here 2017 doozzgwxtsodsslczhnstfaxyjifajpowtljebtadluiagxp
 * Smoking Wheels....  was here 2017 ewxsoiwjdcyzgmkubyfwuevhhtlzvtmmdrdarxjyfyagsjin
 * Smoking Wheels....  was here 2017 mjwjbkwouhjwyvxclkybioexbhgqotndaipfnxhxedrdhlto
 * Smoking Wheels....  was here 2017 loqvcownrbrxcxldumeohthanwsmsxnxkumiwqyjlccnnfii
 * Smoking Wheels....  was here 2017 rhoiqccncfwlghzizgouxipeeqccdwpkkhsdfzdcviugnsis
 * Smoking Wheels....  was here 2017 bojjwsacnzeahrmgbzylnewdsbzjwrcojkkoebtchlokockv
 * Smoking Wheels....  was here 2017 srwogghyrtemfakwlfnmwjaxetdhfoolyyzttfarckkhfxid
 * Smoking Wheels....  was here 2017 zfgxktydpgrxioggusscxhhsvsogtzxnyxdgcblitjongwge
 * Smoking Wheels....  was here 2017 mxyoiqdxnippeuwuxpdstodddaouhrdkoqrrqkruzsqwuxnx
 * Smoking Wheels....  was here 2017 dvpbeljtxfidqkkdycrbxyhwvcpswqrydqwabltctdjlchql
 * Smoking Wheels....  was here 2017 ahcajcjmogiisldegtncarszyrodvbbhisalhlvmkouotnod
 * Smoking Wheels....  was here 2017 ovokprbbkekhtcscmjczazprsrjjrmdwyxulnbjmieeuohhr
 * Smoking Wheels....  was here 2017 hellvorttvoigwxenazfdpknqejzhoagcnesfddvijbyopey
 * Smoking Wheels....  was here 2017 dmkoehsccmcabmwdlzdlsgwflrbvriakgbfeatbpkufdcrwa
 * Smoking Wheels....  was here 2017 fyhldtvwdmoegxxwqtsqndzvdvfxdztkyjjawijztjrrszdj
 * Smoking Wheels....  was here 2017 xehckcbawnrwcjqlsfbampxpynxpgbarbmhtzknoxircehco
 * Smoking Wheels....  was here 2017 vxvrvpnwpmmlfivhoixasfdbkyimwgyutrwaswgaqavhpnco
 * Smoking Wheels....  was here 2017 vfmqrytxuphliprbhkciswkygncjynwskmgtvvmkxdvghztk
 * Smoking Wheels....  was here 2017 bkgrjymwegpsobkphauxdppglxxixcjnosvfgpmayptjtcvo
 * Smoking Wheels....  was here 2017 wzftnsputbfieasceykyywahgawrfngrelivdwrhhovfwpmq
 * Smoking Wheels....  was here 2017 wuubdpkyuacquyjwufpxhecnfaeasmrshxohxkubrlqoqmam
 * Smoking Wheels....  was here 2017 yvqakfhvthpddnnqhdhlplotajldnyypiqsogiuhbxynkzbh
 * Smoking Wheels....  was here 2017 gkrkskafkggtjtlfagoppuizrrjeverlymeudbwgtxtlsokl
 * Smoking Wheels....  was here 2017 cbabthndtptmsxttpiwmenrlkxajhqqqxmqntdnmfpjvkyeo
 * Smoking Wheels....  was here 2017 dochnfbubfertkhrymwoogaruerirazulxzjmllsejholdsn
 * Smoking Wheels....  was here 2017 gaomcubsthvxhaeodxlpewclmywxbjbvwhihbbqyqxisgkom
 * Smoking Wheels....  was here 2017 orijzwfsqhfzkrrjnftlqlxtnxjdtxkwuldnjkhmwdmpidqu
 * Smoking Wheels....  was here 2017 kcnwwootrubakrmeueekzipwexekgcxhckampavvjfbtmdyd
 * Smoking Wheels....  was here 2017 kaoeqggcdumhvmiktvkvidrgweoemqptylwxgtbswonbuixj
 * Smoking Wheels....  was here 2017 mpbtnmthnkrlnujrpmimduvtkbdkjoxdrdwsxuwejwsonzar
 * Smoking Wheels....  was here 2017 saziydvbobgfmqywprchbhbiuipbibioxhlcpkmmczrphpfj
 * Smoking Wheels....  was here 2017 mwlvoikkglxsbeqdmedlbaoggvznwrtkmxenlfkcoepswwnd
 * Smoking Wheels....  was here 2017 kxvliksqvmshvygvabakiquagspivbhjohasxdhwnucujtiv
 * Smoking Wheels....  was here 2017 kgvplzfgviymoqxrkpswgzmlolzifgggnzcoqfeszmxvaoep
 * Smoking Wheels....  was here 2017 ndjbhypayjcdihzlaikupcolfswpjlfhzvwiqufydgbfkrxw
 * Smoking Wheels....  was here 2017 dcnspiwxfizilczikckjfkhjkjhmwdatuuxkanxbnevmjxrg
 * Smoking Wheels....  was here 2017 yztvhnffwbqjlnutmwlbhmdsqpnnmaujbednfgywxttlyetp
 * Smoking Wheels....  was here 2017 suruodckkuiweinhjzjniftfrwdnhevzfptqzbihfppglttc
 * Smoking Wheels....  was here 2017 rufhvzhioyoormmwlzityqewnuwppsttvtdxejfruqkdkdnc
 * Smoking Wheels....  was here 2017 cpnitgryidcqfegpiruyceoakhtbzfkbttxvbrdlaaktrzdg
 * Smoking Wheels....  was here 2017 ryacigmmzhailzswwbjnzkkbvocmfivnewaczxtltffwhjyl
 * Smoking Wheels....  was here 2017 gxiarognzppgcoyiflzebflwnakrkclblqpqrebrxwnpolnv
 * Smoking Wheels....  was here 2017 ytiugcptcnifgwgwsjsxxqpjmhksurttdwaqbugjtxlfassu
 * Smoking Wheels....  was here 2017 dbfjtxogiqzhffgpzrbwocdwzjfzzqrbepzpikvauleinxqy
 * Smoking Wheels....  was here 2017 kpkzdkigxxqwobtyxiqneelwnibzurforcjexwmluzgtdapd
 * Smoking Wheels....  was here 2017 skmbndihjnnkccxnqripeshcurmogtuezyiilgdpsdnochfp
 * Smoking Wheels....  was here 2017 cukhjzibjvevwhaemghzgwqqvafurcyasxggyxcuvvycadir
 * Smoking Wheels....  was here 2017 ygiqjbhqzpkeeyrddvyyiyssxijzqfnnuavkomtnpfuysjzz
 * Smoking Wheels....  was here 2017 xqqgmrkhlretpmrskmxwpnyvmsdtxvqghqynsvvnutqwgyol
 * Smoking Wheels....  was here 2017 vzzrvndlgfvdxrfolmdnmobthpdxpxqdoftmcaivkbgzwbpd
 * Smoking Wheels....  was here 2017 wognwjgzdswefmnppjturbamjsbmzsbihpqmqllsscqpefan
 * Smoking Wheels....  was here 2017 iyquijqvbtbxvcgynyewckbhxxzwqruehvgbnrqreabizewe
 * Smoking Wheels....  was here 2017 wwmrcwohihlsgbgybfahzgqsmjdojoxitenvfoqmngcyjwmb
 * Smoking Wheels....  was here 2017 klmpjmlvknhdibohjofrrjmmtoclfitszfpuigjdulmoonlf
 * Smoking Wheels....  was here 2017 zxohobbgbvdzcdowulxzyynpucqpnfwkpsvcwccwfohlfrqc
 * Smoking Wheels....  was here 2017 awvrkrhohwsixlutxrmlrhzjtxuiusevnsygzrgggrtgbzbh
 * Smoking Wheels....  was here 2017 caryutlahpdohnekriqnbaihgduexospvovycvoashktfnet
 * Smoking Wheels....  was here 2017 dnvpwvydpdqeaaskergvozhcygeawsvpxspbyszfobaazlmn
 * Smoking Wheels....  was here 2017 fochetmqzysagavrtgmkvivuvxtwzldzkarwkrtaawqkwfvc
 * Smoking Wheels....  was here 2017 ttszhscpjreeesajbwskuiesfandvelddmsurhiaqxoltqja
 * Smoking Wheels....  was here 2017 iwawgzxgcgbzlofuyophrrthnsuigrvshlpnekkzcpgaprjg
 * Smoking Wheels....  was here 2017 vxrkdfkcovpzvilropbuwdhhombhgxroelnaqdzvlpoevnlx
 * Smoking Wheels....  was here 2017 jgqilgjxpvjajycwhofubxtuhydbdcovlfwmyxfyyvlfxrli
 * Smoking Wheels....  was here 2017 hjamvfsrdydekrsmrfnnfhjazazansiyzwgjifqtalgsswle
 * Smoking Wheels....  was here 2017 hceegkqsmbxtmzdxrpokmwplcwyteoamwqqjezxalxlngbuj
 * Smoking Wheels....  was here 2017 elwuwmqmbizilqmvjbifioexkyoadnbjmddlehaugvwswnca
 * Smoking Wheels....  was here 2017 csxcchkurgwthpccccwvklaixxnytxysmcethnfirempcsdm
 * Smoking Wheels....  was here 2017 kmmysxxphkjcibowomrmqwjbvrxuoepyspjusgxcecpttjcm
 * Smoking Wheels....  was here 2017 smzpnsjeetmqeosmohjphlsorjafkaaqhxqfvivxnztzxmfu
 * Smoking Wheels....  was here 2017 yvbnuihbvlnzpupqgvvxraspflizhlqtpoeaixyusnrkwgeq
 * Smoking Wheels....  was here 2017 etqjyoiazxyzrtqezpfipsjekpreorajgkikfhmyarlieetk
 * Smoking Wheels....  was here 2017 uvwcromapuqqsqjgkkybxwxpnraetfzxdkttodxxwniiqybq
 * Smoking Wheels....  was here 2017 lvdxwryjzbnjgzqgjirpuctibyslsupzjykvxfxlboveiqki
 * Smoking Wheels....  was here 2017 xuchtmeoqwxrcmnvapipsgrdtsfxligmhmjovslopltaojlo
 * Smoking Wheels....  was here 2017 kbqwsxxjgpjkjdkvrvzajlpbosjpidnnowcejzuorbdewsyt
 * Smoking Wheels....  was here 2017 gdyrmydtvxqqhevlatcbrasjuwcwvqfoacfbqpjwvofebibm
 * Smoking Wheels....  was here 2017 cvkwzbzbqutrlarzxlieuponyiugvpmeunqydkwivknwggcr
 * Smoking Wheels....  was here 2017 vdqwkuateizdrmaekfobeauismypjzpggqnulnhxphwirsqm
 * Smoking Wheels....  was here 2017 nkpkdzxofawuanevyoxqnkjtdbhytafzbgfupiwxlbgwydoh
 * Smoking Wheels....  was here 2017 nellxupormetujtddhwetbodlxxroedrbklkskauvxzbvhxs
 * Smoking Wheels....  was here 2017 ofneqojzwqyjolplvlzbaruxcgaioglaijcigpminhntkebq
 * Smoking Wheels....  was here 2017 kpnanxpihrkdcovkeigzubuwxnfsvdmxhthmxagomvtaayof
 * Smoking Wheels....  was here 2017 foiszqbkqzeymrsxmnuzthnavigyrcvlohmcpbmtalpdeehu
 * Smoking Wheels....  was here 2017 jsceswseygyvazwcmszdvufqdpdiqpjaaagpnhrjpijtroib
 * Smoking Wheels....  was here 2017 mugppztxljvdgaeiybmzfchfhoelolehthorconfyxqqpbzx
 * Smoking Wheels....  was here 2017 kxkmxpqdqoakblrhaufficmnbovcnnpddpnizzagbvdwhxxk
 * Smoking Wheels....  was here 2017 hgnmzndphebnkhsvclhswytolhzjtcervtoteyjvfzwugpwa
 * Smoking Wheels....  was here 2017 mmrppxdiiyunruxcuvettxjqrsoowquiruiiuabjwpeziwai
 * Smoking Wheels....  was here 2017 qhiypbxoctdtjkclzamtdqsegxxirynruatvhbtrvboforrg
 * Smoking Wheels....  was here 2017 pudafqxvaumtixiotgdknyoayjokfxrroyxdkektaauqghlx
 * Smoking Wheels....  was here 2017 mgyoxmvxwkhjpeaincgroavestfxuuxkpkhnztiwskwnzdcs
 * Smoking Wheels....  was here 2017 rfyliqrtqjjqnorvwjgteeuwuxzezbbhtkmkhiwolkdmozug
 * Smoking Wheels....  was here 2017 umoxjoqspnsyplensbvcozwptcbtpmdzegklsvvnxlbhavwl
 * Smoking Wheels....  was here 2017 sbjkhudfebpwrqpzdnukdiuegrbmraohgngqxidvdelbrvxl
 * Smoking Wheels....  was here 2017 ohjpmezbfkpdvbhdmgkppinojjsknxwloyjewfasimiccosp
 * Smoking Wheels....  was here 2017 rrqmqwbhpflyizvdlbyxxigbhabwspytaqkntayraoyacrko
 * Smoking Wheels....  was here 2017 sbpgsepcrlfnswchwzetexnenwjmbwvxsviiaqpmywwosfif
 * Smoking Wheels....  was here 2017 nlyivtcawecmwldiwiywxzyruheaqrxuabgphfzedawxhibs
 * Smoking Wheels....  was here 2017 fdnkmlgwzxsrusibuqletponeygosftmoeomobgzuyzhjpll
 * Smoking Wheels....  was here 2017 fqmmihaozhvdvwfrhraxrdnavuplwaflffxmzuzlkulisroa
 * Smoking Wheels....  was here 2017 cvhsisqlcfkemkqnfnjmufjshyofxuigckfgzgthsauvloti
 * Smoking Wheels....  was here 2017 trnopinavwtlqbthrljpprthhwptwnnvojqtgoqpuhvxwnqn
 * Smoking Wheels....  was here 2017 hmdsrylazrlrhvvuczefupruwfncclihhvpetbununovmzaz
 * Smoking Wheels....  was here 2017 bvgddsilmhfztxngczenfjimfxjodbpbcwrzqjsrhwheesaj
 * Smoking Wheels....  was here 2017 tmibzxkopqbsqupzmkbadpewwckttakscuwwjjctysnvysyn
 * Smoking Wheels....  was here 2017 enywjgeyvxikrgeqkpsizdytnfdmckdfsdgvpcxuvubucdlp
 * Smoking Wheels....  was here 2017 leahtmhgxmmxafqdgchlkbqcfyivkjiqnqgzgzjbezwlgngz
 * Smoking Wheels....  was here 2017 zashuutpwaigxxmoqrfoitjefecbglwjkknvooyblmhiepoj
 * Smoking Wheels....  was here 2017 jvlaknteymxvxvqjkkcczvsmycpvmiucmszaxtiokrvhyirn
 * Smoking Wheels....  was here 2017 mswzvgunpzmdvsedtovvtcivfcmycanrdctpapnobghjvyds
 * Smoking Wheels....  was here 2017 mwwwmvnkpapctokuyrqpjsefzwklltogzjgrunsipcqykywf
 * Smoking Wheels....  was here 2017 rxppajzuyearzoylrovssamwnimrbztewodslcjjqlfnnaxt
 * Smoking Wheels....  was here 2017 tpljkgjawkthbgpmugdnaqshhqzftlgdzyiljefluqmzeepd
 * Smoking Wheels....  was here 2017 nzcruccnwxbluhmolalurjphcgkwpdjzpcyuhvfpdkhjsroo
 * Smoking Wheels....  was here 2017 djleqrydsbozgrynymwmkjbwwtnsxhrwlujzdmobxpparypk
 * Smoking Wheels....  was here 2017 yhqwqevvjoyatroozivsdzjgxdjcfjaehbilbstjpltmxtvg
 * Smoking Wheels....  was here 2017 pnbwrxavdggvvtebjszaauyarogpidnnifqwnjngxjfqlbob
 * Smoking Wheels....  was here 2017 zdksznxtlkuaiqwpgvgbnrnwyjqajnmwxunfeotsxzunocky
 * Smoking Wheels....  was here 2017 elnazvggbjbkhhzcaguuisbvrijkoungqpjrzpsbugnlwifh
 * Smoking Wheels....  was here 2017 nxquiyajzwwazzcsguyjjhuedildnkldkrusdexubirzdobs
 * Smoking Wheels....  was here 2017 skbgzflkmtfgadcvwnkiuadkvnduacjchhsabcyqmptalrgc
 * Smoking Wheels....  was here 2017 pxmudhywafkqeoaayqchbswhnhzddwpbtzioklxqbupocylp
 * Smoking Wheels....  was here 2017 htvcfzgljsyaoeggwucgwnxvdjtheyueipymeqxbzueyrwlq
 * Smoking Wheels....  was here 2017 engfwkigmwplkfjqhrxkcumizqmorusuxdiimgmjvttuydiu
 * Smoking Wheels....  was here 2017 vxdgcykmrqkgieeoakcfacbfnhknmdmoqxhsucikhcxwzuly
 * Smoking Wheels....  was here 2017 eadradyqjdraduuqggqizijinsdzqzmjxkaptijcjnkhczkh
 * Smoking Wheels....  was here 2017 hddfcxqojuwpvanthuqssoirzpjbmnfjgnxfjixthygiwgbe
 * Smoking Wheels....  was here 2017 pviubjleqivaucacutmpeefldwfamhpxqfqztqhxpmspbhlg
 * Smoking Wheels....  was here 2017 rwcptuqulqnpnoczqewkmulfmqwnozsrcubqkdigaqjytdxk
 * Smoking Wheels....  was here 2017 kgbdkwqwgvhzwbvcxlrvcfuttkwhrpvmcvkbyyzwozykhyct
 * Smoking Wheels....  was here 2017 yieblkegvkqxwqoiaabvsodazuamfiqoeczojkkzlmnhegur
 * Smoking Wheels....  was here 2017 pqoionewezimvlxuoskqggtijsjjsrxfgqmmuccceiifgucw
 * Smoking Wheels....  was here 2017 ayqcroxbonjbjbrxkokqxubdlieoyksdltworytamxxzomje
 * Smoking Wheels....  was here 2017 cibxzdvhkdceedygsxypccvhzcyvzllfcyettzkrkwbrkpes
 * Smoking Wheels....  was here 2017 ybskxdphnhzrksctufeknhzswrmiebsnwcxgwqeldetqjqkx
 * Smoking Wheels....  was here 2017 xrsneqgewpvqjzsnhilhdrurmytiarhnpernhlpsgzijgibj
 * Smoking Wheels....  was here 2017 pzonqzzctbrjolqzdhnsbxqtfcdjkchukmjgkhjjkrhucpoa
 * Smoking Wheels....  was here 2017 yavtoufppttlvvxtjkfjuuhrwocjhhcgroejxhkiqzkxgsmy
 * Smoking Wheels....  was here 2017 bblaixsmeeqsfbxtjerezmsklzkiblfaaglcstzwftsbfdqo
 * Smoking Wheels....  was here 2017 gsofqmlsmycfblfaukjjohchdicpgboniowxajonpfmvvqcn
 * Smoking Wheels....  was here 2017 erpnkuopuzegxlrbndxjswyumrmtrxfistjlgxvbotfaeehr
 * Smoking Wheels....  was here 2017 tbelwnppolcmouklqsexwayrgnbpjwljolbrdnumbattnzsf
 * Smoking Wheels....  was here 2017 adeqkmfnnukrbkrbnpjwtwayjnpgqhyuliivoopbjzcilngl
 * Smoking Wheels....  was here 2017 klvbsuljsrxxspebuqwogumwdoezcomzgoxisptgztmhtozc
 * Smoking Wheels....  was here 2017 numxsuljkapndvqviviiokszbwzknmendipwbozxqunmmagy
 * Smoking Wheels....  was here 2017 ffurqcrbazubcufagnrxdmlavuqiyzijmgplgmgzjtxazfqg
 * Smoking Wheels....  was here 2017 qzrzwoxejzzjqngmygahqgramavvrhppvcieftssioreunzh
 * Smoking Wheels....  was here 2017 drgwdhbujrzobehjautpzypfgmrfiytqdxlpeyyrdkeostku
 * Smoking Wheels....  was here 2017 iczliricjztwzifbidpjkgsdqijcrqyclyvinzoplqwyvweo
 * Smoking Wheels....  was here 2017 cflfqggqubqyeqcfarjfhaqnjangtilxfvpjyxomhzolkczu
 * Smoking Wheels....  was here 2017 pkqwnxmfjjdoschslxhdjilkmevuxgxdzgfxkcdqxigkaxpw
 * Smoking Wheels....  was here 2017 ddpiquzteobvwyjrgpthnnhaetjbsyegrjhkbdvnvvginadj
 */
/**
*  IndexFederated_p
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 25.05.2011 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.apache.solr.common.SolrException;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.federate.solr.connector.RemoteSolrConnector;
import net.yacy.cora.federate.solr.connector.ShardSelection;
import net.yacy.cora.federate.solr.connector.SolrConnector;
import net.yacy.cora.federate.solr.instance.RemoteInstance;
import net.yacy.cora.federate.solr.instance.ShardInstance;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.TransactionManager;
import net.yacy.kelondro.util.OS;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class IndexFederated_p {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
        if (post != null && post.containsKey("setrwi")) {
	/* Check the transaction is valid */
	TransactionManager.checkPostTransaction(header, post);
	
boolean post_core_rwi = post.getBoolean("core.service.rwi");
final boolean previous_core_rwi = sb.index.connectedRWI() && env.getConfigBool(SwitchboardConstants.CORE_SERVICE_RWI, false);
env.setConfig(SwitchboardConstants.CORE_SERVICE_RWI, post_core_rwi);
if (previous_core_rwi && !post_core_rwi) sb.index.disconnectRWI();
if (!previous_core_rwi && post_core_rwi) try {
final int wordCacheMaxCount = (int) sb.getConfigLong(SwitchboardConstants.WORDCACHE_MAX_COUNT, 20000);
final long fileSizeMax = (OS.isWindows) ? sb.getConfigLong("filesize.max.win", Integer.MAX_VALUE) : sb.getConfigLong( "filesize.max.other", Integer.MAX_VALUE);
sb.index.connectRWI(wordCacheMaxCount, fileSizeMax);
} catch (final IOException e) { ConcurrentLog.logException(e); } // switch on
}
        if (post != null && post.containsKey("setcitation")) {
	/* Check the transaction is valid */
	TransactionManager.checkPostTransaction(header, post);
	
boolean post_core_citation = post.getBoolean(SwitchboardConstants.CORE_SERVICE_CITATION);
final boolean previous_core_citation = sb.index.connectedCitation() && env.getConfigBool(SwitchboardConstants.CORE_SERVICE_CITATION, false);
env.setConfig(SwitchboardConstants.CORE_SERVICE_CITATION, post_core_citation);
if (previous_core_citation && !post_core_citation) sb.index.disconnectCitation();
if (!previous_core_citation && post_core_citation) try {
final int wordCacheMaxCount = (int) sb.getConfigLong(SwitchboardConstants.WORDCACHE_MAX_COUNT, 20000);
final long fileSizeMax = (OS.isWindows) ? sb.getConfigLong("filesize.max.win", Integer.MAX_VALUE) : sb.getConfigLong( "filesize.max.other", Integer.MAX_VALUE);
sb.index.connectCitation(wordCacheMaxCount, fileSizeMax);
} catch (final IOException e) { ConcurrentLog.logException(e); } // switch on
boolean webgraph = post.getBoolean(SwitchboardConstants.CORE_SERVICE_WEBGRAPH);
sb.index.fulltext().setUseWebgraph(webgraph);
env.setConfig(SwitchboardConstants.CORE_SERVICE_WEBGRAPH, webgraph);
}
        if (post != null && post.containsKey("setsolr")) {
	/* Check the transaction is valid */
	TransactionManager.checkPostTransaction(header, post);
	
boolean post_core_fulltext = post.getBoolean(SwitchboardConstants.CORE_SERVICE_FULLTEXT);
final boolean previous_core_fulltext = sb.index.fulltext().connectedLocalSolr() && env.getConfigBool(SwitchboardConstants.CORE_SERVICE_FULLTEXT, false);
env.setConfig(SwitchboardConstants.CORE_SERVICE_FULLTEXT, post_core_fulltext);
if (previous_core_fulltext && !post_core_fulltext) {
sb.index.fulltext().disconnectLocalSolr();
}
if (!previous_core_fulltext && post_core_fulltext) {
try { sb.index.fulltext().connectLocalSolr(); } catch (final IOException e) { ConcurrentLog.logException(e); }
}
final boolean solrRemoteWasOn = sb.index.fulltext().connectedRemoteSolr() && env.getConfigBool(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_ENABLED, true);
String solrurls = post.get("solr.indexing.url", env.getConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_URL, "http://127.0.0.1:8983/solr"));
final boolean solrRemoteIsOnAfterwards = post.getBoolean("solr.indexing.solrremote") & solrurls.length() > 0;
env.setConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_ENABLED, solrRemoteIsOnAfterwards);
final BufferedReader r = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(UTF8.getBytes(solrurls))));
final StringBuilder s = new StringBuilder();
String s0;
try {
while ((s0 = r.readLine()) != null) {
s0 = s0.trim();
if (s0.length() > 0) {
s.append(s0).append(',');
}
}
} catch (final IOException e1) {
}
if (s.length() > 0) {
s.setLength(s.length() - 1);
}
solrurls = s.toString().trim();
env.setConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_URL, solrurls);
String shardMethodName = post.get("solr.indexing.sharding", env.getConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_SHARDING, ShardSelection.Method.MODULO_HOST_MD5.name()));
ShardSelection.Method shardMethod = ShardSelection.Method.valueOf(shardMethodName);
env.setConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_SHARDING, shardMethod.name());
if (solrRemoteWasOn && !solrRemoteIsOnAfterwards) {
try {
sb.index.fulltext().disconnectRemoteSolr();
} catch (final Throwable e) {
ConcurrentLog.logException(e);
}
}
final boolean writeEnabled = post.getBoolean("solr.indexing.solrremote.writeenabled");
sb.setConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_WRITEENABLED, writeEnabled);
if (solrRemoteIsOnAfterwards) try {
if (solrRemoteWasOn) sb.index.fulltext().disconnectRemoteSolr();
final boolean usesolr = sb.getConfigBool(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_ENABLED, false) & solrurls.length() > 0;
final int solrtimeout = sb.getConfigInt(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_TIMEOUT, 10000);
try {
if (usesolr) {
ArrayList<RemoteInstance> instances = RemoteInstance.getShardInstances(solrurls, null, null, solrtimeout);
sb.index.fulltext().connectRemoteSolr(instances, shardMethod, writeEnabled);
} else {
sb.index.fulltext().disconnectRemoteSolr();
}
} catch (final Throwable e) {
ConcurrentLog.logException(e);
try {
sb.index.fulltext().disconnectRemoteSolr();
} catch (final Throwable ee) {
ConcurrentLog.logException(ee);
}
}
} catch (final SolrException e) {
ConcurrentLog.severe("IndexFederated_p", "change of solr connection failed", e);
}
boolean lazy = post.getBoolean("solr.indexing.lazy");
env.setConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_LAZY, lazy);
}
/* Acquire a transaction token for the next POST form submission */
prop.put(TransactionManager.TRANSACTION_TOKEN_PARAM, TransactionManager.getTransactionToken(header));
        if (!sb.index.fulltext().connectedRemoteSolr()) {
prop.put("table", 0);
} else {
prop.put("table", 1);
final SolrConnector solr = sb.index.fulltext().getDefaultRemoteSolrConnector();
final long[] size = new long[]{((RemoteSolrConnector) solr).getSize()};
final ArrayList<String> urls = ((ShardInstance) ((RemoteSolrConnector) solr).getInstance()).getAdminInterfaces();
boolean dark = false;
for (int i = 0; i < size.length; i++) {
prop.put("table_list_" + i + "_dark", dark ? 1 : 0); dark = !dark;
prop.put("table_list_" + i + "_url", urls.get(i));
prop.put("table_list_" + i + "_size", size[i]);
}
prop.put("table_list", size.length);
}
prop.put(SwitchboardConstants.CORE_SERVICE_FULLTEXT + ".checked", env.getConfigBool(SwitchboardConstants.CORE_SERVICE_FULLTEXT, false) ? 1 : 0);
prop.put("core.service.rwi.checked", env.getConfigBool(SwitchboardConstants.CORE_SERVICE_RWI, false) ? 1 : 0);
prop.put(SwitchboardConstants.CORE_SERVICE_CITATION + ".checked", env.getConfigBool(SwitchboardConstants.CORE_SERVICE_CITATION, false) ? 1 : 0);
prop.put(SwitchboardConstants.CORE_SERVICE_WEBGRAPH + ".checked", env.getConfigBool(SwitchboardConstants.CORE_SERVICE_WEBGRAPH, false) ? 1 : 0);
prop.put("solr.indexing.solrremote.checked", env.getConfigBool(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_ENABLED, false) ? 1 : 0);
prop.put("solr.indexing.url", env.getConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_URL, "http://127.0.0.1:8983/solr").replace(",", "\n"));        
String thisShardingMethodName = env.getConfig(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_SHARDING, ShardSelection.Method.MODULO_HOST_MD5.name());
int mc = 0;
for (ShardSelection.Method method: ShardSelection.Method.values()) {
prop.put("solr.indexing.sharding.methods_" + mc + "_method", method.name());
prop.put("solr.indexing.sharding.methods_" + mc + "_description", method.description);
prop.put("solr.indexing.sharding.methods_" + mc + "_selected", method.name().equals(thisShardingMethodName) ? 1 : 0);
mc++;
}
prop.put("solr.indexing.sharding.methods", mc);
prop.put("solr.indexing.solrremote.writeenabled.checked", env.getConfigBool(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_WRITEENABLED, true));
prop.put("solr.indexing.lazy.checked", env.getConfigBool(SwitchboardConstants.FEDERATED_SERVICE_SOLR_INDEXING_LAZY, true) ? 1 : 0);
return prop;
}
}
