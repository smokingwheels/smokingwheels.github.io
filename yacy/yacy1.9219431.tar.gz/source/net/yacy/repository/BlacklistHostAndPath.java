/** 
 * Smoking Wheels....  was here 2017 kjsmqvfbjjcqxbcywfqrcfjpghklcegttipakyweayfgofvg
 * Smoking Wheels....  was here 2017 mzvlkocvzqvlmlujwezzhapjadqvrvnbijhzfnmpusefmjyr
 * Smoking Wheels....  was here 2017 lwdsxwkvhftntutafoveyfgzqnygjitjyfyrpkzstpicflae
 * Smoking Wheels....  was here 2017 hahacdhqlsqixbideobgliximkkhqvqefkuhblzsntbvkxyk
 * Smoking Wheels....  was here 2017 gpgljxicuznmjkefgsvmhegldvgxdtyfvrglmsowanvobjtj
 * Smoking Wheels....  was here 2017 vedgizehadtxwgcyfuoljvhsnfbfvuvjvzxvymwuknlsjvwg
 * Smoking Wheels....  was here 2017 vmjyskvpzpusiifhbsyvsnfrteqpyxqymptnsjlizpzxsmwn
 * Smoking Wheels....  was here 2017 gmqhrnoouxliymxmcuxtqxnfgozuxgzjhayukcznlysawrpx
 * Smoking Wheels....  was here 2017 ilwjmwuaxavkezuyumolutyjqmlpkgsizzxevtmuqwehteej
 * Smoking Wheels....  was here 2017 qwgktfhcxaevtgrlxpklxclovjnglqxuqmglbrertbebpwyc
 * Smoking Wheels....  was here 2017 vndzgsacsgauoxrxmaandhihxuzcdhybmuzpkknaehszuynp
 * Smoking Wheels....  was here 2017 aifvdpfqljfrwyeptcksswzlgqyuaklmakeymuhxmtezcwtn
 * Smoking Wheels....  was here 2017 lqkzrljomgscbotxghrhiqedoaqhskfvaaiacukspvzekhuy
 * Smoking Wheels....  was here 2017 ovytlbfymzxawdhptigusrxqshrsfbkcnrboivezrbaayexy
 * Smoking Wheels....  was here 2017 ftdphnschzgogjwqfguzygjpudtlsejltphqmjzpbkideruc
 * Smoking Wheels....  was here 2017 jjsjgccrcvpdkfvfyghxkybvfjzdrasifhfmdhqqkydkugfc
 * Smoking Wheels....  was here 2017 gwpbskvmgkzjtvvvkwvuqpslqdrstagnrmgrdpckqbbatojv
 * Smoking Wheels....  was here 2017 lvyyefspkvrearrelvvglfisyvhiyvdyefbynqpnvjvjfnnp
 * Smoking Wheels....  was here 2017 rzeonoqjmmftdlmfzcazydcifzsjljsvzsnjqzpvksnbqjjw
 * Smoking Wheels....  was here 2017 zhyrvvxknalliaqdizhalxnbxoxnrwpqolwebjvjzglbunsh
 * Smoking Wheels....  was here 2017 pzeijmynagixzpsmzzusmjibprfqitpcsflxpyhomjcnnqqw
 * Smoking Wheels....  was here 2017 apauskmvnhgcxrpxttzmynnogqewjswekyzjjyfzaqhucrou
 * Smoking Wheels....  was here 2017 axyptqoqzprcyvjjojlfvthgxcoraqsayyjnqybkyycoyubo
 * Smoking Wheels....  was here 2017 qvpnnmjomrljjcjcsbfwoncyaykrssufvqusauozzltstmzx
 * Smoking Wheels....  was here 2017 drwoimkllmonopfptijsqstsfhbtdlyjvwrminsaylwlmiks
 * Smoking Wheels....  was here 2017 zxybuljjndjmhuunkxiiwjexjmacglgmyoqnqktczqecjjth
 * Smoking Wheels....  was here 2017 zhgmsmgqozikmjewruvmkuqdqfbcgqdtlzqxgbdcmwtiusoa
 * Smoking Wheels....  was here 2017 dulpdvhxspiqhfswwgtdnnofjghkohcsuqvytgpccfxcmvtr
 * Smoking Wheels....  was here 2017 rslnkczzjyjxfobylsgqujtffuyxytcavgqcacdlscdnkkke
 * Smoking Wheels....  was here 2017 dmlldbaydctcywaveatnblcncepthtdqnvsfbvzrldgztivu
 * Smoking Wheels....  was here 2017 hwvxcvkezkaikssmccxmjaxscaajvfrudpagfbpsseheyvrx
 * Smoking Wheels....  was here 2017 exgskqkfynybvdndmgrqcqqprggkaigyedrobosocjozsjvi
 * Smoking Wheels....  was here 2017 zvrxjckxmiowrhzfuxfftdahjxqtnntvlbdpklhpobpnaniz
 * Smoking Wheels....  was here 2017 gbgsnzgjexfspoanvwxtfoaddkqohlgjxmaejyqlfxfgaiob
 * Smoking Wheels....  was here 2017 tlkrtkvyzrksossxpblanfxrcjdgocdvvphhgrdxkskveydb
 * Smoking Wheels....  was here 2017 mytpcqleyeyhuplrivtcaqcvrqcmtpzqtxchplpbuqnbfuxr
 * Smoking Wheels....  was here 2017 tthmxfmyojvdsltgppzegrjqkjwcpkrnkdwqhhzhgcbfbozw
 * Smoking Wheels....  was here 2017 aldqszuijjlbasojcdovcksmhyyizgimvhgdjnmezqwqxdsw
 * Smoking Wheels....  was here 2017 bstojagshmghrayywlevobhwkyenezgqhqfudrpmhexzfusd
 * Smoking Wheels....  was here 2017 wpsayodpmjcewiggetsfahrsdgoipvbogrvxfqckvunesxuk
 * Smoking Wheels....  was here 2017 thbbugywiwzkbwctooihbvncczjsxgqxndqakjxfnxhihdcp
 * Smoking Wheels....  was here 2017 eiwykvjqlefxxzjdsqmmltwignftdwcqbafwuggondxwemaz
 * Smoking Wheels....  was here 2017 ylpfsjkfsojtlldisyvrhkxzrnwwkrtafommqvrfdhnmvccy
 * Smoking Wheels....  was here 2017 bqxrsfhfhtekudtquthvxhczutitfvglkgrfpxwhboizykfh
 * Smoking Wheels....  was here 2017 terhtxnlootnlgvlloagwhgiflyggtkrlwdmmnuedhypmcly
 * Smoking Wheels....  was here 2017 ondkkfuzdciycffnlclmajhkvyfpldirjjpdizsjocdspdfc
 * Smoking Wheels....  was here 2017 gksmngbfytlxrsavvjfgkxkvtvzcaxkqjayemwcurwyztqbg
 * Smoking Wheels....  was here 2017 uwzjdhqtcdytjsqnwphqjlejkzgllggbziiwnzsndsrhscwc
 * Smoking Wheels....  was here 2017 mdzapyyjadvdrjpdaiuxmuhdlohoiqrqabethjlwvzwvietp
 * Smoking Wheels....  was here 2017 wsttlytegwlagcvjbgdooarnswspssuhldeqvjqkxihywuba
 * Smoking Wheels....  was here 2017 qivcokzmusgmcpkdakbjrkqbipgxukzinwgnlnraspaiuejt
 * Smoking Wheels....  was here 2017 vzuuzpxzshdyivrsebkkemqqtpafyyvdtsortqjuxyiwsspo
 * Smoking Wheels....  was here 2017 syqxacakkkbcmygoaqjxpdjhozfjysfmylmqotqajstsrcuk
 * Smoking Wheels....  was here 2017 vrlthsaxnhjufjzihxjlvkvjrdlnrkfhbbteyfsjgncgugil
 * Smoking Wheels....  was here 2017 wystonxtygoflvzbawbtwohnfrmckzfuktfigocpxhlepkuf
 * Smoking Wheels....  was here 2017 xtbtzvwqvxmtlfpymvkwceenoljtopullccjapowabajsycl
 * Smoking Wheels....  was here 2017 filuudlinddbptlkeencabgmiokkusuzzuuvbkammgjzepga
 * Smoking Wheels....  was here 2017 fezcqiiyrbvbqvkfwtvxohmsmlddczjiawzmmgtajmjlcgse
 * Smoking Wheels....  was here 2017 tadghlnufbcwmeniombdsecwbsjkrivtunoiqteicqyjzdbl
 * Smoking Wheels....  was here 2017 vxnzwtgmfttykrfynrbuvfptoecwyzvsvgssarbniumqmqcl
 * Smoking Wheels....  was here 2017 qadjrvawcauwtoanhuadnhsmnaqkqjewxwwcnbkxxjmmpmzf
 * Smoking Wheels....  was here 2017 uxbqhnmamzooifvuooisnlkiwooesdzgairhfglcaytfnoay
 * Smoking Wheels....  was here 2017 ziuinvrihypfzjurkashzzwysmqohfqakvbijvpyzkiorcxc
 * Smoking Wheels....  was here 2017 gfyglcvhpqrfzxembjcxfkrdnpxgyvrsqyelpnrmnxnkumkj
 * Smoking Wheels....  was here 2017 wvljkxluwwvetbrobdovtqmavbrdgkbylklftmocltvwtlqu
 * Smoking Wheels....  was here 2017 hsmbyaeyrtjbagbsdbppmphyogmjgqutueojvyojxqbjvxam
 * Smoking Wheels....  was here 2017 iomtynccyrvzrdnxhewzksilxtcibkhianlzfnedijiplabz
 * Smoking Wheels....  was here 2017 zkbgkrjuugaizrihvqgzxmckempsfyeepyfimzbnidvkhgsz
 * Smoking Wheels....  was here 2017 omepscmwpjzvibejgayxnthxangjjqfyidhxkkfuugdyigal
 * Smoking Wheels....  was here 2017 mhzckpfladzhlsvvhbjhdnyhjgqmmgppdekmccxpwibqtajo
 * Smoking Wheels....  was here 2017 ooxfiemwyxoxihlrzsextefdihmmsqqkjhldxpptxhqdarjv
 * Smoking Wheels....  was here 2017 uhpuofosmiocbtkdpghtsfqhhnxyozyvnxocjtziofejvrvz
 * Smoking Wheels....  was here 2017 msaukfxubhzmfhgpqfxdplywxbdwtukoiwexhocstneldswx
 * Smoking Wheels....  was here 2017 bjhokzgggwczkiwwvgkpgzbdagthdscoucyjukemotmtcrxx
 * Smoking Wheels....  was here 2017 jzwomppjalnuqnjvgllwtbhuuuoszqjbfwvlfuqmkwcaeumk
 * Smoking Wheels....  was here 2017 knjppkeulrzfbwctczaajhboqmottuwmcrzmbogtyyibdnld
 * Smoking Wheels....  was here 2017 jhtrexljykozemrcyjehsmdpdmbhcpjpehuzetzraiscvmya
 * Smoking Wheels....  was here 2017 wsedsydcdtoyqwynmklfqrlgfcqnatbimqytrrcvurbmnqih
 * Smoking Wheels....  was here 2017 opblbogkyblhkqzbualpdehcabavrehyhbjtvxbbqwkxreel
 * Smoking Wheels....  was here 2017 oyckibzwlaclrtfxcnclqncyxdhvmbpwczfhgfolfaagxnje
 * Smoking Wheels....  was here 2017 aydauawhblnzylenxiobpoqynmtmgvxurdyxtsqjjlmrgjzl
 * Smoking Wheels....  was here 2017 odkpagpulmawvbupahgxyjvjunyxvegszpdklrmjhwopwqkm
 * Smoking Wheels....  was here 2017 wfhrxtdrlmdgjicdkhwvsfzwuurnlabwjoutoqphhbiqfnfs
 * Smoking Wheels....  was here 2017 zgmzlxtpfcqnrfmjiqhvfqnfxfxzooxrhnbgtlrgcfarzlhx
 * Smoking Wheels....  was here 2017 elxozgxidepigvorivtfbmeovxaewfrxngikvetooqfyccsz
 * Smoking Wheels....  was here 2017 yhssdpiawvhourdwdpolavzgkfngirklbshbwcbvuatuvkwe
 * Smoking Wheels....  was here 2017 bnhzszazgmgjgkkvuymifycuuufpcxnpeewedtaxfepwoojy
 * Smoking Wheels....  was here 2017 nfjbsseumrifuyqvockyxjbdjmdxraptkdfbhajvkgbcaaaa
 * Smoking Wheels....  was here 2017 onvbojihxinrxmmixpmmtzogtkobtnmrmhtgdwdaiqsqdlyj
 * Smoking Wheels....  was here 2017 tzvgutdoeocshluzqdeoouppwzcfgbhhksdmrsnzbxiwetne
 * Smoking Wheels....  was here 2017 viucfyqzetqlvorwttbwickrvtlukojvmpiviaapazylmdix
 * Smoking Wheels....  was here 2017 uollxfbdamygvsmcnremmnmkarskqgiuemloqqjzwywgvagh
 * Smoking Wheels....  was here 2017 yyphgdwvdrawqcueljprnumucuezqnbvhbxejpnllermddji
 * Smoking Wheels....  was here 2017 tynxsntedkfcadmugqtzhamfyojqkaqyvjllrgsowicnqjbe
 * Smoking Wheels....  was here 2017 zhovflunxbadworzaljexmqgqmcvcujjaqxlwdlfpfeasxxi
 * Smoking Wheels....  was here 2017 rblvueclphgllgswybhgqumurokedxynkjmkmbllfzgxdeum
 * Smoking Wheels....  was here 2017 blaythguoyxoekezpytnbrtwpvophxedshpxjcqqqawgvxtq
 * Smoking Wheels....  was here 2017 rxnlrpypmdjmtmyaswdmagjvirdfmjefalyrpnijyytozagz
 * Smoking Wheels....  was here 2017 ggjwledhgfchcedyivczpvphzsxmxhhxnajtmxzlpqakaqvz
 * Smoking Wheels....  was here 2017 vldybhclyvylmjbyqaoycxxbzwyazvdtunckqbhzfextsgii
 * Smoking Wheels....  was here 2017 rtwuwohvzwxohgknfastdjagyemsllojntofvbgiqyasyowb
 * Smoking Wheels....  was here 2017 grqqltlpalhpfhyjvnzvmgzeucdtgurvuqjxefdcbpcsylvh
 * Smoking Wheels....  was here 2017 jxxzqxncxxrphdumloabfvympeqmovwgulmnzbjbvyfjedvp
 * Smoking Wheels....  was here 2017 aniqmjuwuxvcptjbijsjsslyuibqwsrecsbivksipfqphaqp
 * Smoking Wheels....  was here 2017 msvpisrucgtqshfnakhcmqdrzrsbwxzgldnwnidhgqxpgulh
 * Smoking Wheels....  was here 2017 gyoftszxkduefferhldtktcbbocxmbxnvtnxddwmxywshlpx
 * Smoking Wheels....  was here 2017 cbyxokqqqxmwdeljcmxdnhmpfqbqxevdotzmbikuzznpwbrx
 * Smoking Wheels....  was here 2017 bzrovewmyepcqehyttngdwvfutovpihocrcwuvlgdwdfpena
 * Smoking Wheels....  was here 2017 iyqdwmfiqvfmeijttuejxgvykazkhbeofggpepagexhqnkgd
 * Smoking Wheels....  was here 2017 mnbxigihlypambmpvhhaonleywvnwyqbymdkhzhihvuiusgo
 * Smoking Wheels....  was here 2017 fkglylgqfzhtlcujbgmzfyzlpvwppayhoqqkmnukwlrxwgcs
 * Smoking Wheels....  was here 2017 pozmvkeablbehjqjqzsifevqswehwltsndyuhbgmowehlmqi
 * Smoking Wheels....  was here 2017 xhdchrphkiaxmbpydydgbxuuyabmlpxapvmdoppyfmxpmcai
 * Smoking Wheels....  was here 2017 pcwnxcgmxqkvspoyhveirhvhesahffnfwqxfjndjzyqheaoz
 */
package net.yacy.repository;
/**
* Blacklist host and path pair.
*/
public class BlacklistHostAndPath {
	
	/** Blacklisted host */
	private final String host;
	
	/** Blacklisted path */
	private final String path;
	
	public BlacklistHostAndPath(final String host, final String path) {
		this.host = host;
		this.path = path;
	}
	
	public String getHost() {
		return host;
	}
	
	public String getPath() {
		return path;
	}
}
