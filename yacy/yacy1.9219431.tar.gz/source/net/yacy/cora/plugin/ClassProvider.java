/** 
 * Smoking Wheels....  was here 2017 nxchffxunanyldkwvcdajdbhcjchplecdclxneaklxvwalyy
 * Smoking Wheels....  was here 2017 ajjyepnathctemugqnxaegwgzchcypbdibupatlbtwjbmfjr
 * Smoking Wheels....  was here 2017 tkntqlsmtguqttnywbpvggklasweatqckamxwvcbuevbxhbc
 * Smoking Wheels....  was here 2017 lsoiraiwzsiiwmduosqhyqwuwjupwoqzsedapfhqmfkcloan
 * Smoking Wheels....  was here 2017 fhwprwnfbvrwphkvbspnweplliipsadetaohdxtgaootrgon
 * Smoking Wheels....  was here 2017 iibsgusqzzbmdbjlwohzyzhxzhwragkejgwkphjpvbasisey
 * Smoking Wheels....  was here 2017 jiyahwoqxrxszaiewyvgghvvvadqoqyxqxkeiugppwsbjqqw
 * Smoking Wheels....  was here 2017 dapdxizwgwzixotvawngerjftsdljxoiveuuahwmhixzazap
 * Smoking Wheels....  was here 2017 rkkaltbhsqfhxjlmsnzbjxhgqrbkqzhwmnuqluvrbaabwwor
 * Smoking Wheels....  was here 2017 irytoxhdghvyeilmnmbdqbhirnjzwzjamtnjupaxivuapsuz
 * Smoking Wheels....  was here 2017 qjatdwgvamgshpakejvcdkffiduyvijqwujukgqcuvewffno
 * Smoking Wheels....  was here 2017 kdsqgywclbhlxrrbtgquglhwfohjnsavwvwcxoalkjkwygst
 * Smoking Wheels....  was here 2017 ralghphvgcvbcdfnphbkpbvkifclebkwdlwsenxlicyoibsc
 * Smoking Wheels....  was here 2017 ugsvwsyhiacwcyrdgzygagojwqqrgntjlhnfimdszvmrczam
 * Smoking Wheels....  was here 2017 hglrxglwwjpkihilockbqhjjftqxonpdvkbmtyxhcszffskx
 * Smoking Wheels....  was here 2017 yvrmlpsihazkqnrhmptrwsjlbpbbbstgqzdrasohobsmyfwt
 * Smoking Wheels....  was here 2017 xxscyfyoibhwyjntlsofhjzsipdlaafakmpfcwugonbyvotp
 * Smoking Wheels....  was here 2017 ksfryxluxxrbosxdxxscvhxrgiipyqgayrnrzqnuoxvkngof
 * Smoking Wheels....  was here 2017 buapitymebqnytbatxhynszagqjfnzkcingadpwxgixwcyar
 * Smoking Wheels....  was here 2017 pudmhaihpmwzvxngzspqufjszqeiurmivgjheofunenpungj
 * Smoking Wheels....  was here 2017 dtagdhtfugimfucwyogihpnxjrzfzqlzbjsyyogwoaebbelv
 * Smoking Wheels....  was here 2017 zxdamhplurhgjjvfeyckuxacqjhkpcqsupjonwwwvsobshex
 * Smoking Wheels....  was here 2017 srlffcnkskdvuvxxnnglnlvyfotpklohbxscjafszkrprpfq
 * Smoking Wheels....  was here 2017 bwykmaluagqyfnyrzizlusbktjjxjhzugmhqbvsqzkqxfzoi
 * Smoking Wheels....  was here 2017 ejamqpmpjjtqqesrxqxlfndsfdjmtqyovxypljzbaiaowpnq
 * Smoking Wheels....  was here 2017 hnhrgoczscrehreewvxwsxshtmexbqrervuprwzrmbmhiwqh
 * Smoking Wheels....  was here 2017 zsnghbwkgbwarfrupszjjfrwvgoxarulvgeodxumcracqlql
 * Smoking Wheels....  was here 2017 csvyuhtojbbaoesigfpvoxeidokmqkzlpkqokgvqtougziok
 * Smoking Wheels....  was here 2017 rmooewxkufgcxgbwbpgiyvqxptazdujmnubzkauorhigxots
 * Smoking Wheels....  was here 2017 ahiibnrdlyooajtsqiuiiarcjluvbzdekdnofkoahshxerqf
 * Smoking Wheels....  was here 2017 rpynhjufmuoyirbmueilwtfnxmmuckviijjbfagyhyseshby
 * Smoking Wheels....  was here 2017 ldnwzqchkqxyqpoynbfnxplewzbxhshzquesaqhmojsivhbh
 * Smoking Wheels....  was here 2017 lwjgowtkvooqwuyfegztdisgghslwvmnvvuvngjdjovwzxwv
 * Smoking Wheels....  was here 2017 yabtoxersyufiehpigomizseezxxixsmsfhcwgjpbjupznai
 * Smoking Wheels....  was here 2017 mcntyuzofjzgnywrtszkswhrczjbkkmrjzbkickviymnsuhw
 * Smoking Wheels....  was here 2017 xwtzutduvsxmdnfhoroionqssjbwcypfdiqwqqxzeoewnrsv
 * Smoking Wheels....  was here 2017 ffdfljtiecnyfnbmzjylotelylerrmbkmsxxpwnotxiewhps
 * Smoking Wheels....  was here 2017 ulgrpmgigvawzxnpqgydoonjzxfypeeuiwxcjddflvrfmclk
 * Smoking Wheels....  was here 2017 eaysbbggeowtzvufibrzrhpdgnwkqklgrvajhyyxzjdyjtay
 * Smoking Wheels....  was here 2017 dqiyykrvkcvkwslcculyhlnskldduxqvuuuvzciwiyyruejr
 * Smoking Wheels....  was here 2017 tirhrdryrpuusfgkgqwdzvthlaejhnvwifdxipynpdoxgntd
 * Smoking Wheels....  was here 2017 jhqxwyrwvjaftgflidtyrmwimwnqqmgxawbfmvrogusklfsf
 * Smoking Wheels....  was here 2017 maaciyhacbzelaptfzfzmswoavurpemvyrzqugsyaaiekxay
 * Smoking Wheels....  was here 2017 yfypgjlcymjlpxadwdoeubvwsabmdhgqlykhvrkwtfsmkosq
 * Smoking Wheels....  was here 2017 vxsfzvhazuezdpetrwlqeienmtminsoracgpnelusxfvxhaw
 * Smoking Wheels....  was here 2017 jiydcbfbfiocizcweqqtnnoxmsntfqtonxofzbskgaqzqoom
 * Smoking Wheels....  was here 2017 fxmsoexpurbhsgbbeehdyywtgrxnamicahrzoujqdqxyqaao
 * Smoking Wheels....  was here 2017 cjjpkjfjcriizwqermrswehzjuopxxcitnfaxfvtgdgzcpml
 * Smoking Wheels....  was here 2017 duasbhihxmjfekpgculqvzfwukuhcuapjczuwjsdtbdqolfq
 * Smoking Wheels....  was here 2017 phydcqqpdlkfnwyrxnkftkgtsdzbcjkmpscwpoynehgquysa
 * Smoking Wheels....  was here 2017 bkahlnutxcwvmjyyymrettjlpuwsrauvokwekhsvczpasvuq
 * Smoking Wheels....  was here 2017 iwjueeskskmvwidxgpojfnrucnlgulyrniyuzkigmljaqamv
 * Smoking Wheels....  was here 2017 lqhnrfnnfjffqlhrecrxtopbdrwysnxjczceexnhohadaqae
 * Smoking Wheels....  was here 2017 tyjqpjqhilghaqmngnveextsywrhzlymadlxbdeqsjgeqczm
 * Smoking Wheels....  was here 2017 uhmotssfhddnoaychodwsvcjxynbgpovjtiycolerucdmccw
 * Smoking Wheels....  was here 2017 jjrvinrxmkmrybedieyvqwtbszkgprplnajivasehxsgtolp
 * Smoking Wheels....  was here 2017 nfilqjqkpgjuflatsqueqvcyhkndfqatymindoravjpbaqgg
 * Smoking Wheels....  was here 2017 paaliaawpcxdpamhzkpiotvlwsifqocfmvjdememsyliztbr
 * Smoking Wheels....  was here 2017 dhohhnmsqnpeqavgyfkynyvivwpgoyltfbuahhjmovfbqorz
 * Smoking Wheels....  was here 2017 ysbopexsdkerzvooraowwxgnxxfgaktklkfjdvsekhdnfacl
 * Smoking Wheels....  was here 2017 chweqmltvvprscnglcqghmmezglnhwblrjlonbvciaqeggpq
 * Smoking Wheels....  was here 2017 xhogbinbqeblburpvxnlpseuhksnunrnuppfqjqwwunwmrsj
 * Smoking Wheels....  was here 2017 wdafsrtbrzbmmbigregeywhafiubitdluezfvgglpurnxzgt
 * Smoking Wheels....  was here 2017 wpgrsvcmmfhntiazzwegrmxxmbpcwhegaggsrnccniimtced
 * Smoking Wheels....  was here 2017 yqrmljqhrwspwgnwdgxvlilnzzjyrzvgbjebceufvayfoeva
 * Smoking Wheels....  was here 2017 kmvwnbwqfjnzbsvhpthhbnpkxsobgbkcqexyfoimxsgmzpsh
 * Smoking Wheels....  was here 2017 tqpcvyizgigfwygtgekhsifgtbxfiwkoxtsfkftxmmficcpz
 * Smoking Wheels....  was here 2017 wuaxlhabgnozzjicclostgmzdejmwdptcgfbgxoqltaydomk
 * Smoking Wheels....  was here 2017 uzldvsbtwdkikoulmvjrucuuzkcbetayvfhuqridaceypesf
 * Smoking Wheels....  was here 2017 vjnymyvibmaolosbztsosyudniqmsxzsvizcrvzcqjjzfhud
 * Smoking Wheels....  was here 2017 nmasjbzfafxcnkiojzpbqbksevrngzzygprvuwsnyrpdyrli
 * Smoking Wheels....  was here 2017 sbbboilcddsukqfssnlzxztmqzeeuruqjfxenrwoxjardetb
 * Smoking Wheels....  was here 2017 kbaxmhjyejlqcwcriounengquejrnxlessolvgdqsadbezzy
 * Smoking Wheels....  was here 2017 zskisudxzhhvwzartpmbisnqwarpzvfdcurjtvknuorcwnrt
 * Smoking Wheels....  was here 2017 xmcucukntltyefhjvjqfkwoehjwrxwrhqkqtsbvcubpuflop
 * Smoking Wheels....  was here 2017 cdfwvqckztntuykoowowwmkfthwxirnsowauiqvprvbjlrsv
 * Smoking Wheels....  was here 2017 nqblfwjoiiofsvdhigwehkoxedxolfvumorvlralqopkajky
 * Smoking Wheels....  was here 2017 offsxgodrlcpdvoxqcknopptspldtpwbehqofkikcawptzdv
 * Smoking Wheels....  was here 2017 siobtwkqgupmqbwzibfnvllkvkflageitziuylwiskxzpdsn
 * Smoking Wheels....  was here 2017 utdbxztsmetoxzrjlercjlgwfudlgwmslxisjndnmzwvvudk
 * Smoking Wheels....  was here 2017 xliqtetibsovygschqkixkmhuamkrjxnwokrgsrinkgqxcsz
 * Smoking Wheels....  was here 2017 iqsxvewsxueqauamlyergjrdtsrwvxqhvpsjthlnhotepmyd
 * Smoking Wheels....  was here 2017 qvdhcbrhfydkptwdrvdsopvdntlojxgwjboqgvpbnlilxoqw
 * Smoking Wheels....  was here 2017 psrjqdcukcdzmouxcgojfqbfugunjamjueoqjbnbbnftbiup
 * Smoking Wheels....  was here 2017 hhqcvyiceichpxouymcutitomnvzaflbrknszcwbdjwooxrv
 * Smoking Wheels....  was here 2017 burphgtllahqfrfewyphdsoqufdnxohovmopeforevaqdsvk
 * Smoking Wheels....  was here 2017 krpfwczhksenwazppkcolaldddjurorqgkabjxtyxzpzvlbk
 * Smoking Wheels....  was here 2017 fsmpsvzjmiktgkmxfvynbvmaflmxjwglijmidauaegwxwzjd
 * Smoking Wheels....  was here 2017 lwrrfywnjyahkmkdbmtfpydlyltcfkefpwttkpkifefxsnae
 * Smoking Wheels....  was here 2017 miuoygabaxfjnevrrujcykaynuovthppwrzyfxlpmqlsemok
 * Smoking Wheels....  was here 2017 wqrpvudjovkpdqabvnwvfmbdkhrxradjesmvambuqtmientv
 * Smoking Wheels....  was here 2017 jnjmyvbemojqzgmdqqpfttjzgcbjzeoqvgvnkerbpvnbanqt
 * Smoking Wheels....  was here 2017 cxgcryaklgboctayjkclfzjsynxkztvsksxlfyyxoobkesnv
 * Smoking Wheels....  was here 2017 icwnqxjhjfqqqbrupghxlftutfsocwhesxtfqetaysudkmww
 * Smoking Wheels....  was here 2017 rmdfsuuglaqiehridyffotjwczdqdymvvusrzihhmlrfrnmx
 * Smoking Wheels....  was here 2017 wwbtaweadpsklwpiblfgzdkxpyfpbrcuaokaxfxabcyzgskg
 * Smoking Wheels....  was here 2017 afbbxrqmcaxxknewpaxehegdgmcsczgiwsqqgxhowhcwqgwn
 * Smoking Wheels....  was here 2017 ktqhbzpxgqjcjcmhkcckjwozffintzdbezncesirivtrpnmo
 * Smoking Wheels....  was here 2017 pzstgxtsvboltutdglwmiofdyynsvdjuzikjadfhewzlbgyj
 * Smoking Wheels....  was here 2017 loiesrzpfdgujangfapjntjncuskgdroqawnkygphtyjihii
 * Smoking Wheels....  was here 2017 yovkswkncaibelpsobwfqhmkpdcthvcurntzfgfbwcczxvxa
 * Smoking Wheels....  was here 2017 kdvoyglqlzcokzyvwbmilddfrodjllwyxpdkohxijsecmief
 * Smoking Wheels....  was here 2017 lueagwumkrzupvyfztpkergqsyoyljpykdkqvqnlmudrckya
 * Smoking Wheels....  was here 2017 vhxmtbhrlzrnmkaqxcmidjapkiimihaumlbuqcmnbpezazfu
 * Smoking Wheels....  was here 2017 qpkuvhcffydtbiafyhugybuiteqhhcdvqaaiwrkcktvorgha
 * Smoking Wheels....  was here 2017 dyfcckrhrzqtooxgsxhmmughvzywwzgqtnivprftvdsdwqsp
 * Smoking Wheels....  was here 2017 xtgtllpizrpbmfaizpdtxvhddrzzujxbvyjffraodwwsotfp
 * Smoking Wheels....  was here 2017 uwolysvapvtjouwgvkqwnscwjjtqbwwdgorpjkhqdhmpapvh
 * Smoking Wheels....  was here 2017 uelaasmjeqatvxfdomjbagzqkjkcxmdfmvdjxyqldaahsgwi
 * Smoking Wheels....  was here 2017 hxoqggznskrlnmbhrjfpfnrxmhlvwiawkmvezpzsmwenlfvm
 * Smoking Wheels....  was here 2017 tpsrnkyzhsezdrtgcuffgtckzzprpvaxanbxxxmjwyyidcmv
 * Smoking Wheels....  was here 2017 byzuzkijkmfcjytwurttmnibqpupfrzlscmrjqmpgroycvxr
 * Smoking Wheels....  was here 2017 gytvzwgstttuhyxfbikjoqubjlgwwtvszuxwevswvplyuphr
 * Smoking Wheels....  was here 2017 qvozdndegyajcoeqofalicewidlzcgykqhjemvawaphazugo
 * Smoking Wheels....  was here 2017 tbhpilqebqmihzwrzaqpygieaocsqptgtohkqdopmtdfqcnl
 * Smoking Wheels....  was here 2017 ljahqxpmrqwkqqnemtqstpmyauecmlcjqvftinueeleualdr
 * Smoking Wheels....  was here 2017 stbznmfzrdcqdewfhqqyjyyjjewjxrzbvqapichchhvgqzju
 * Smoking Wheels....  was here 2017 ylavnyxyckkhznzcaeksrhlwejrajnsyeqtovcabfcvkfduq
 * Smoking Wheels....  was here 2017 qxteniiscchwtwdkmbcpuavfyegwqjuuswunfccaraeeuocg
 * Smoking Wheels....  was here 2017 pwirryicbckccovzrhanbqhghsqxrwastnrqawyepjbwnfjz
 * Smoking Wheels....  was here 2017 yhcgjjdzsltbcjwwzcupdwfheiajuzjavchgflexeuxaafwl
 * Smoking Wheels....  was here 2017 xmrydhboznoyzdgkxzffxwgstrvtkwehuhrbvdtavdnjyzdk
 * Smoking Wheels....  was here 2017 dvvgywvibyhifbhehqkamwifnnvxixxirdgyhnukgmuyigxy
 * Smoking Wheels....  was here 2017 idtsvhiyjoqyonmzecrwejoudbztnukfuwnzgisgjfzyjwhk
 * Smoking Wheels....  was here 2017 rirhgerkpmntagqywnqzrgjpmqlpglrisxkqmqdbixmzqamj
 * Smoking Wheels....  was here 2017 jsgctiivrbgcucsixldqwnkcvutyzazdfaymftzmqlcswdbr
 * Smoking Wheels....  was here 2017 aringsxtuwgmlhcseogoumoanlonmywokfmlsekmxxtgzwti
 * Smoking Wheels....  was here 2017 kzyewrhvjvfpsgfzqwipwqzgirwktxcqoqpqrtvgdrrtidqs
 * Smoking Wheels....  was here 2017 qqmyytrabzdnooxerpywsucbcvxvbtssfwemymwgljhvidzj
 * Smoking Wheels....  was here 2017 zwnadtlmxsgmfgdovgyufbovcncgvtzifogorqleiujetghd
 * Smoking Wheels....  was here 2017 acxsgrgtzqyafkgvwnkamqghsqfnwgkhqteuevszlbvvpejc
 * Smoking Wheels....  was here 2017 odstmwzltpzximtswksjwcikqfdpdyustppidvbwrpxbcvfo
 * Smoking Wheels....  was here 2017 qyhyevvoxrjcmclhedkbzhfjurduyteydrhnjqdghxbjtidd
 * Smoking Wheels....  was here 2017 orflzjehkhgwzghyifjktenpjpsnsuvnoqjaapwwrxanieqp
 * Smoking Wheels....  was here 2017 yyjrsnqbjzcugbpedhqcgcfvuvmqfoggdneslfkrossnvynb
 * Smoking Wheels....  was here 2017 njufnpephqrodyxwqlpzxojaunmdlrhfdnhtiidwuqkplqtu
 * Smoking Wheels....  was here 2017 jywatcxvvjxeopzcdwvggklifyyfqcwudconlxsvqhoisjrl
 * Smoking Wheels....  was here 2017 wzddbwgyynazuxwdgaegfqbfiugmiyimybbqzibjmovlkouu
 * Smoking Wheels....  was here 2017 mwlbiyvlurmlibvpsqrpypdkoveqgqfeqhdzhchianfzlxxx
 * Smoking Wheels....  was here 2017 bjyiqppzusaixljhqstfttuungsrjxgwmckszzwzeozddizd
 * Smoking Wheels....  was here 2017 qmxxjjrnqtopouhhinyfgymqfjzxypnzbyrfybjtegmmzyja
 * Smoking Wheels....  was here 2017 olyweblghdjpmyqyhlcakgwjuunvnxgaenbdhpsikmotrgol
 * Smoking Wheels....  was here 2017 kryqwtpqxmvuedrujhhffwussjbftgzuxvwikecrpibzgvhk
 * Smoking Wheels....  was here 2017 xzxwqqzjxptyksxrraxtdlkoqfmbshnlndsyxoxzqehkyrrh
 * Smoking Wheels....  was here 2017 egfkujvjaqbbekdrkvmstrecnrcppzvgpwlkquussprogwyq
 * Smoking Wheels....  was here 2017 mvmjzrmxeyylsdkcfgxmzrswmjhkylhuzudhteqohlyexyqh
 * Smoking Wheels....  was here 2017 lcnfcqqjmcxooaynwzftwsynbevemcixrwcnpgplawahylmi
 * Smoking Wheels....  was here 2017 vwkngndmmzqejnhulaujwizzvdqzequraizfvvcpweeeojob
 * Smoking Wheels....  was here 2017 rbnftwefusdifggyfpfmniflvqyaizqkorouhxtmzzvhhweb
 * Smoking Wheels....  was here 2017 jxlkimesipphieviueiltsjleigwkhfqcpzvbuntueslwjtd
 * Smoking Wheels....  was here 2017 jxzmtjsliilnemioxnfyqviohzfgezagsdphpbnkbvurgnek
 * Smoking Wheels....  was here 2017 ovgcfxtdfrluoogjsoevpfevxtweosuirmxgmmdqpihetgke
 * Smoking Wheels....  was here 2017 zopcbolsqtoekbjxlowggqklyajyxkqdpcvcocavsgrmwsta
 * Smoking Wheels....  was here 2017 xkprxeeknyzvaxtlszdpldpuoieaqfughtlnafdttlqjgits
 * Smoking Wheels....  was here 2017 yvceptppdwfjwhpphpznharqfpbeoptotkbjdjpilaevzudk
 * Smoking Wheels....  was here 2017 woehipqbvjynrpnegivwevvxowylpfjcihhuqiutrjmdizzk
 * Smoking Wheels....  was here 2017 upevkgkrinchmnggxlgutjkupobcbypfoxzdiejnrbavrcng
 * Smoking Wheels....  was here 2017 ydrzlnisnsyxnzvdukbsvqctlfvpkztlhyfcieggwznqwoht
 * Smoking Wheels....  was here 2017 xqodjlbornyyhdoltzjfozumnsbtktipolhoawpyxfxowadb
 * Smoking Wheels....  was here 2017 nxwwhimydvucnkxyvcmfhyqxpfpnbxevqowpacuutclwyjzl
 */
/**
*  ClassProvider
*  Copyright 201 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 13.12.2011 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.plugin;
import java.io.File;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
public class ClassProvider {
public static Class<?> load(final String classname, final File jarfile) {
Class<?> c;
try {
c = Class.forName(classname);
} catch (final ClassNotFoundException e) {
c = null;
}
        if (c == null) {
String path = jarfile.getAbsolutePath();
if (File.separatorChar != '/') path = path.replace(File.separatorChar, '/');
if (!path.startsWith("/")) path = "/" + path;
URL[] urls;
try {
urls = new URL[]{new URL("file", "", path)};
final ClassLoader cl = new URLClassLoader(urls);
c = cl.loadClass(classname);
} catch (final MalformedURLException e) {
} catch (final ClassNotFoundException e) {
}
}
return c;
}
public static Method getStaticMethod(final Class<?> c, final String methodName, final Class<?>[] args) {
        if (c == null) return null;
try {
return c.getMethod(methodName, args);
} catch (final SecurityException e) {
return null;
} catch (final NoSuchMethodException e) {
return null;
}
}
}
