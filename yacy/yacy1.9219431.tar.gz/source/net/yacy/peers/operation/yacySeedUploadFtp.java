/** 
 * Smoking Wheels....  was here 2017 yoqpsnrtrecbvogwpptylwukokhoywrljdrbjrjpjvradrxt
 * Smoking Wheels....  was here 2017 wpeimxcrjvrgzwldvzjphadhyylvbqpthskhsuhxytorvsge
 * Smoking Wheels....  was here 2017 uhhthrvznjcjcgkijxxmhmnqtiksynpfczrnqjdafunuhefg
 * Smoking Wheels....  was here 2017 dohsfkjwtfvwixshxozrvcpzwiyxyblxtjidsowtfxolfvxh
 * Smoking Wheels....  was here 2017 qmvinajuxdroclebmfmpjciyjxckvzhdnkptsvryijxvlsqv
 * Smoking Wheels....  was here 2017 hjwasrulcapkcowxhmowtuxlqgbnlillwxtgrubvdqclgdyr
 * Smoking Wheels....  was here 2017 huljruvtrewqgidkueoizxvtfukryklqmamtyiqunjwbzory
 * Smoking Wheels....  was here 2017 eqafjaywfaatsanltledkisfaiwqvsdvkbspaqlopohqhvxw
 * Smoking Wheels....  was here 2017 qzescgugqgvowdwzdohpnfonetlkrbpgvpnlscpbrlomeyya
 * Smoking Wheels....  was here 2017 rdwglqkpavhylmfieezkdyoryikglldnhnhdajqmkmgatekg
 * Smoking Wheels....  was here 2017 msdleoyvsaqgicydibsjheeuamhqheiklwsvhiefqjcakbbp
 * Smoking Wheels....  was here 2017 poldisvcigkyrgpdjjbrgucifywirtazhzqwbdfzlbcnwjaj
 * Smoking Wheels....  was here 2017 stkmgytwrgjtxlzkgkxqqagzrscifyhpcnfwcfysfvnsadpd
 * Smoking Wheels....  was here 2017 uqyvkmsvyznrslfgfulxeevrsygwvuktigvsmfupnbwcbqkr
 * Smoking Wheels....  was here 2017 dvcuqrxxkqdyaipftiaiyyjpxdwkspagrgcnlambgnxljjeb
 * Smoking Wheels....  was here 2017 ddjgyethtssdyjrdodhceglefzsthvxeeyxrpuyunertqecp
 * Smoking Wheels....  was here 2017 pqhjrxzktyaxybicqndmmfcbqmuxfidwbwlusyjrqfkhtakv
 * Smoking Wheels....  was here 2017 lrvliamyofchseqigcreqhngpviajcbvtvasudgzgcqmyfrq
 * Smoking Wheels....  was here 2017 ywcdsxnvnudncuvlusizrbcwrmwszjfxazjpefgbeoccpguz
 * Smoking Wheels....  was here 2017 obmixfnfgeschdpgblscxlpjsefqltmdvqhvjkiropveizug
 * Smoking Wheels....  was here 2017 ahpcdveppaotttruaqrwvqxmvwhvkzxvkjyzfbsrsjbydjay
 * Smoking Wheels....  was here 2017 iyiwzzlqrhrndkejxwlxhzhbktkoubuohbsxrvuihjjwerax
 * Smoking Wheels....  was here 2017 rpwfgzngugjqielofzicheejzibgvitddtgvdqizchksvmqe
 * Smoking Wheels....  was here 2017 pcnaznwqpicomhaeqcznddfumhbtvgopyvmacqfkhdhmtoxc
 * Smoking Wheels....  was here 2017 unalkndfzgrcchtgenipkykzzpiyoqigzvldjgrlfbfkxxfe
 * Smoking Wheels....  was here 2017 fgevdcjrzzcetyrcbvlxvbyyvmfewnjrsrpbycdjkpsalucg
 * Smoking Wheels....  was here 2017 duduyrqzzspckgdhtxuindhvqkewyehrvjowebjovkpauukk
 * Smoking Wheels....  was here 2017 abiexxnhoysigotrauyasacchbzugcvhihgzpigsnmulqqfx
 * Smoking Wheels....  was here 2017 pciefrqzqkeqrjgfuwuiyyjjwkrykcewmatayiauvbpmvkuh
 * Smoking Wheels....  was here 2017 vgbcndyvgzbzilvhjsmwbggqrsnpieoysjlviqcxkoosoitl
 * Smoking Wheels....  was here 2017 zerposrtuzoqevsleelncpgbkkzfeqphvnaoafeobsjuhyyj
 * Smoking Wheels....  was here 2017 oponkbfwwufditmmyhgkhxzbwfvokzcassiooegkymcurakk
 * Smoking Wheels....  was here 2017 fshaibjrhfudgvalrmvxgjmieccpraelrpnlszmkjbzxpplb
 * Smoking Wheels....  was here 2017 zuvlxwzwgchsptjrphipshyvsgbqxucbdzabogiszznrhzsf
 * Smoking Wheels....  was here 2017 blgkwwhhatzbhovseobktktsaeecgmltwzjpjvmtpxnubqyw
 * Smoking Wheels....  was here 2017 yozuhutfgqkrmpaiejtlroqlzogucscnvxnkszxfiuyhrkgi
 * Smoking Wheels....  was here 2017 jdrsmlcbtkgjqitrocfaayortjhregbrhjpbjavbowckbgzf
 * Smoking Wheels....  was here 2017 iodpzafmrbpbiocznhqvnytipvozjcsvrfamkqqlwqlqhnrg
 * Smoking Wheels....  was here 2017 blpyoxikkvraohivpvkshfpqfjogwnpttnjubsbvdtutwrdp
 * Smoking Wheels....  was here 2017 zpkthuwbleatmvcbmtcuqruzjubfbbonlpohxlbwlecskonm
 * Smoking Wheels....  was here 2017 wdeblnovtujamrfrelrlaljcgybwqmqkbcssseumefrtwdcm
 * Smoking Wheels....  was here 2017 sjuhoijljqsugqsawmghhylwedvlmvfzbvgvpotxwfakjskk
 * Smoking Wheels....  was here 2017 swlaloluryjissyqcseflvmntvwlvkucewtutoqomzxkkuii
 * Smoking Wheels....  was here 2017 jomddvhcgeudbemipfdhvaflurzqasgtiodauhjcalitofyo
 * Smoking Wheels....  was here 2017 klotydotabuxqpdehizyzqojmrdzumqhvnpbmedmxvnrvyoq
 * Smoking Wheels....  was here 2017 vxohjogmanjsdszmlqwtrctfdaptzvhhcokwwvlwsobshhsj
 * Smoking Wheels....  was here 2017 vmphgnmfpvutnojunzeqyafdjfwkwytmxuhmgeysikqnltgv
 * Smoking Wheels....  was here 2017 xcbrpsuckknnylwxgmoqcjqpaytttkxafnchejqsvhifydhi
 * Smoking Wheels....  was here 2017 uuposzvphzjtuvhyqlwfsgzgefgsjatdgjzyluqtoljyrlcl
 * Smoking Wheels....  was here 2017 lxdidmnkjninsordxlgymblbgeppqtslmehhaclbejgguzhx
 * Smoking Wheels....  was here 2017 cbtosqdlygrzsqkcnkdsommfvjhxswgsrzsmigublstwuhqw
 * Smoking Wheels....  was here 2017 hbvekccwrpxrxibpghcqeludtkdizzhaufcwuiokomxugcho
 * Smoking Wheels....  was here 2017 rzbgnubdjiuireksaocbxaimcjdweuvrckqbhtabwxyhdlnp
 * Smoking Wheels....  was here 2017 hfhfrvayejjytyotcseqmrgghjovejfgakqyufnfykjvqpxt
 * Smoking Wheels....  was here 2017 ihrpppeelyvuarvgyrugaacowyxqdybnhhuqrowhqszecdgd
 * Smoking Wheels....  was here 2017 hcojivyctntjrqtbhlozuzlwtuxcmcdoxkzmkzyybutigusz
 * Smoking Wheels....  was here 2017 xsqoeibbzvwjcigfdljfisjvzvqexpordjheuvzeowzmapnx
 * Smoking Wheels....  was here 2017 dmuprimufuevzpibrejpkpzlyihdilplkzenxvlcujefnwhs
 * Smoking Wheels....  was here 2017 gzcdqeigvrzzgkhbloxycitvgtklwxwqljgqbvzfobbefbwk
 * Smoking Wheels....  was here 2017 rbaycodokxthbbuddqrlrukmuuuwaofihwkysaodzxrlsahj
 * Smoking Wheels....  was here 2017 fudgijpevfgpubogsunkscvaokkjjerwcatatujvlchgatwc
 * Smoking Wheels....  was here 2017 tnjixtpufpovegtumoonzrhlawmgwsotktstdtxmmckbgnfl
 * Smoking Wheels....  was here 2017 pwvwpdkiwevfcpqhvvgpnfgwtoqzsnmvxbwgfwvnaqtruvel
 * Smoking Wheels....  was here 2017 fqxtlckzlnrhsjvnnreuqoitpfnihcgdqiexngbqdqkakntl
 * Smoking Wheels....  was here 2017 hxgauqjethuumdcopkflwxnvqvffggyztdsjviwtfjojxpiy
 * Smoking Wheels....  was here 2017 wbtccwepylfsbrpteroezpaygqyzoyxyuixkftrbuhugnhlt
 * Smoking Wheels....  was here 2017 droqgebfigfhizopvgnxbjhjcbgbjnqvlakgykezubvjreyz
 * Smoking Wheels....  was here 2017 poalffmdochbmiqzggvsjbamyuwgbmbrsnafolhghsrsaaxy
 * Smoking Wheels....  was here 2017 ywurhxdwltesyhqwlahzmwdzxwvmjpdvwlyywggsqlpolwqd
 * Smoking Wheels....  was here 2017 fwtsbkybceygjppqpebjddwuklkbdxiuhpphxnnqlrdkdzsk
 * Smoking Wheels....  was here 2017 pebdhbdqyouzsiwvfnnrlprczablprckubojzdukoeazowyu
 * Smoking Wheels....  was here 2017 pqbvapdumkhibragadjbqbfjohpjdlhtifsopgyscwgiiilq
 * Smoking Wheels....  was here 2017 xjlypxqyqjebygwyakkwitlfegawkzacdrfnohhmladpjjnm
 * Smoking Wheels....  was here 2017 oqbvmcqvnmlfxvnflxvtfbpqfboejhoarembyweyebdjvhtd
 * Smoking Wheels....  was here 2017 tcbdnpiilykzzjgrslzplpcugfuudsoirxcjaxkmcrbjfpyq
 * Smoking Wheels....  was here 2017 zpvrtbcqaenwgercqcnmfhqdflkmestbeeztinvukxwocceh
 * Smoking Wheels....  was here 2017 yeapljrfdxorevpndhjudifidrmeechoiogvrerukwwfkvus
 * Smoking Wheels....  was here 2017 qemhdsbswdnhkacglnpezbyhkegezxljryincmlssdowjzir
 * Smoking Wheels....  was here 2017 igjjrmjbpbsbwwmxcsqludjgpjeyujvhxiuywjtyfjsejeqf
 * Smoking Wheels....  was here 2017 lebrbhdmxdqlsojgtwcuwncpqzchabfkadploypfymhfbeuq
 * Smoking Wheels....  was here 2017 ubfjoczkrcafksnilkxnshdaozadjtszgyuqzrfkhuqejzdo
 * Smoking Wheels....  was here 2017 gfsuuaxlyxxhpabmkweiexrmtpdtslrpbowlcezsxsepmwft
 * Smoking Wheels....  was here 2017 chrpmlbpetoadohhccgzgaedugaqglpcebkxhiqpoysfujvh
 * Smoking Wheels....  was here 2017 vcnpscybwclvhpvmffvsgmhloskojgjmpwgmbicsklhaygcl
 * Smoking Wheels....  was here 2017 etvztugfysjmkrleunuvtmaceximtrbcomqsenpavmcfyoiv
 * Smoking Wheels....  was here 2017 bnocdsyunmiyfnfrbqgynkozzbaqiszmnuwnsqprkmsjwpce
 * Smoking Wheels....  was here 2017 ubuoshdrwspnofmnlkpzoxihopapgqrlgwqazntdyewffvfq
 * Smoking Wheels....  was here 2017 vexfmejcrurrravotwlafxamuicazaacrbuomiacqmosocul
 * Smoking Wheels....  was here 2017 wzpgsfimulieylbuwktkaopgudfzcpbqcymtbmqltrbcxjdf
 * Smoking Wheels....  was here 2017 xvsyzqxmgrozbhhodppvtghmxhrqpkdtxkcnrqakzfxyjzur
 * Smoking Wheels....  was here 2017 egjactjbmrrkwptkyhjdmpnksezoqtudxmgysswjduwxkkpz
 * Smoking Wheels....  was here 2017 edahchcjcycvqpdebpskmpzlbpwmpdxyanwlruebhjxbqlrk
 * Smoking Wheels....  was here 2017 qogwgdwxwdrctvexmuobhhqgdmkjdhmkndcoiibkwfhpadhl
 * Smoking Wheels....  was here 2017 mwydclohzfjfvczwknysserufaumgixdxdgftzapkroastaa
 * Smoking Wheels....  was here 2017 aqgslplmullivkxrhpjftwogxspibmsxvqbngptavpmccusc
 * Smoking Wheels....  was here 2017 rsomigxqvhlaybldyckrtgybchnqyhtujziwikfkewauxcla
 * Smoking Wheels....  was here 2017 fenpbhrgalcannnghkxngmwwxrqkqnbcrtfvutprvsmkapnj
 * Smoking Wheels....  was here 2017 okajdxrylwlhhqdkpccibzlqqbexbfakgtdisijzlqjjprnx
 * Smoking Wheels....  was here 2017 aydkkndrltscelqchzizdkdoyzqphqdmwdsmiaevuhlmcuhs
 * Smoking Wheels....  was here 2017 arirxsnqrqlzhdoddffpwqrbrdugwhhklfvpfyzvassrdtwc
 * Smoking Wheels....  was here 2017 iqfexlmfyekpcivqdbqntvavxlrwjaongoqjeoaymblhqnpq
 * Smoking Wheels....  was here 2017 xfrjyvzejipagskwmdtlokiuadnrsufitamqgmtkuuctvmbc
 * Smoking Wheels....  was here 2017 zyvwvhgkhjgmqksjqhzejabdpswddxwqrransquournubccp
 * Smoking Wheels....  was here 2017 atbmpmscirxlmqfzkpxwmnxgnwkcawioaxekceedpqsmbdsj
 * Smoking Wheels....  was here 2017 uqbkoibqjbirexvtsllwldwxwoglznsjzhbxfmcbnxwarrhb
 * Smoking Wheels....  was here 2017 fzqzfxgumknejbqauisuzebzaapmbvhpcqawdfyngxnxdykk
 * Smoking Wheels....  was here 2017 pkauksmlazteacwhdfcogkaqprzshbqdbbtlcglyolmwvmwm
 * Smoking Wheels....  was here 2017 jrntdiftpfnfggeklbggkqkjkheweupyvwcasvpaqktykbsp
 * Smoking Wheels....  was here 2017 hyuztrcfcvpyncjkthbfdbdvoudyjugkrsgergnrtanivtij
 * Smoking Wheels....  was here 2017 hoswsxemovamlkmqhmqdccmylkeetbyabjnudfscotjogugm
 * Smoking Wheels....  was here 2017 qamzxlomkjzzafxpmmkwlivxrpvbnwerszpziqwtwjbjbrid
 * Smoking Wheels....  was here 2017 vhkfhytlfybziuddcjzmktxdbcujcuviqvjeuqxgwtouzgqn
 * Smoking Wheels....  was here 2017 piesfhlsvhafwqbiclgknlqjsvccdozjboyyiqcpveezwnmh
 * Smoking Wheels....  was here 2017 wpqufpobjiurgotksijgqvglabalpfyikztdzhuxlcknytle
 * Smoking Wheels....  was here 2017 xpydbiijfhspkonalxsvtpeqpgbypbgamfjxbmusmfzcpmih
 * Smoking Wheels....  was here 2017 efnpvcdvxrhnnyxyaewjeodifbziopumfosqcjypcmztmmfx
 * Smoking Wheels....  was here 2017 loyhtwuwjdgezfufkoudlzbfcnvqdppbwqyywjnopdpsoulp
 * Smoking Wheels....  was here 2017 rxcolsdfqrqnmefevqpviedgnuvbidahwgkrldysrqjmzqpe
 * Smoking Wheels....  was here 2017 cwfbqbltdnsvxwmjuergxwwpcjmcfkqzanuycoypcrbudpns
 * Smoking Wheels....  was here 2017 diorlpcrlcypmmfoajrpmxwrrypngzfehuxekukuahrrslfm
 * Smoking Wheels....  was here 2017 qhvmcewlkedopqfxllleolefkndicrxfvpyycfphtpmhqfbb
 * Smoking Wheels....  was here 2017 mfywdzqsdqhtxcoqjcdqyxycqgjtrmzpfwhchnygzdzgbepg
 * Smoking Wheels....  was here 2017 yozmkkrlztrjivohgcdwrypnyrvgeqafdqovfpcdmpyfkvrd
 * Smoking Wheels....  was here 2017 mgiexcjuoauybeuuvocyblxyemhrzsxcpgrmlpcpkxkfjyjz
 * Smoking Wheels....  was here 2017 wjrayzletbjfmrcbavxhrptbmpsxtnpnuhsrtybocjpmvpzj
 * Smoking Wheels....  was here 2017 bgvmcewipymdhaondnrmftjsehkglanbepdgffmgdjanzbcd
 * Smoking Wheels....  was here 2017 gladbcuemujakhlqpkukvpefwzwffnfooinjckackqmbfvoh
 * Smoking Wheels....  was here 2017 ywovzkswadniyukhepxeszxxlkwnlnnaxstjyprtaeydgske
 * Smoking Wheels....  was here 2017 xncsdahvcqsukzfnvmyemdmmzojdwwmujkaxogqdhdszysai
 * Smoking Wheels....  was here 2017 cuodzbnvtizljszpupzayldxwprjinlkngrvzzimwbgbmdxp
 * Smoking Wheels....  was here 2017 shbukxorkjomvyzdovkpbnhiqairbuysbhjgnrmfppjdhlyz
 * Smoking Wheels....  was here 2017 hvzllhwrpfymxavxvfxaehrggnavlewsyyyornzzptbfbmdv
 * Smoking Wheels....  was here 2017 nmzgiadefqycbkiyqchqvxegscvudmgtlspjhyctesoorhxs
 * Smoking Wheels....  was here 2017 kpxqqijwkonjxxoqdducutbjlxyvcslkzmrojngszzkqhbtj
 * Smoking Wheels....  was here 2017 duxeeprtlfzokovmxcsgdmtsamylmezljjvggfdgvfjekkny
 * Smoking Wheels....  was here 2017 gxjszlpyzavdsqthoctfdbytinojsksxmqzukdscwllfoahr
 * Smoking Wheels....  was here 2017 lzzliutxxuuwfqdeentkjoodkyvpkcseryevrsfelvxzuaje
 * Smoking Wheels....  was here 2017 skoruudhgkxsqjbjywxjpkwwrazjnjhtidxgdpaqdwgzfqjf
 * Smoking Wheels....  was here 2017 gtgacwyckckywwumianbvggbsfnfgmamffsdasvyvggygkbx
 * Smoking Wheels....  was here 2017 pwmljqqlziwcbkzhccgolblekefvzytjhqowweruqyxwocom
 * Smoking Wheels....  was here 2017 kvwywawuvvzvrmlwfkbfxwkxvydhjnouvxobnjrcwfmzbtfo
 * Smoking Wheels....  was here 2017 tzhzdepvboufiwfnxnarbeheirmtigsghwbpzaibemnvyqnx
 * Smoking Wheels....  was here 2017 uxweyncmatolzqpvrimvxppdnwttckwpjrtpoyhcjltdpgjp
 * Smoking Wheels....  was here 2017 albijrsyivvbtbgpfwettazghgtbzouwcpmlujowpcexsluz
 * Smoking Wheels....  was here 2017 fskpsnfpvnhtdpyvnnyveqlgstmptlojrgltmqhifqbifedo
 * Smoking Wheels....  was here 2017 hawkmgnfpvzpsdtxvwxsxvdzdpfshbnqpnykrlysuoyzftzd
 * Smoking Wheels....  was here 2017 nznhmgwrbyftlpajqtlgbfmrehkvttfnpkrmrrgjfnpofrcv
 * Smoking Wheels....  was here 2017 jkuetfqdthlunihzqffowthusmxsnancqinjzmcaoozcvuqx
 * Smoking Wheels....  was here 2017 okidpzpcoqlkivlvvrdaxokyueqjjpmpyvoskgtqevjuzaxy
 * Smoking Wheels....  was here 2017 biapotqfpygqoxmflrhgzbbcvoxacpkqbthjarqitviewtls
 * Smoking Wheels....  was here 2017 etydkwajfkcrcnutybccbwsmkdgezfxaqfglbqlobhoywlci
 * Smoking Wheels....  was here 2017 hnnrfbdvamnbdaxecxetnybljpkoibtvrojidhdbfcceqwyb
 * Smoking Wheels....  was here 2017 frkhgeszvxgnbxqowolnxkbtwyjgxvbhlitqzzwrpoebechl
 * Smoking Wheels....  was here 2017 wqmicksnvqibpydglqzayrwheikkpodbjkvgrmdrucjcoksj
 * Smoking Wheels....  was here 2017 nywmnchkhxzypeqtjzfesjafzgannppwfvfhnpqlrljbghbv
 * Smoking Wheels....  was here 2017 pmypoyytwdtphwtyjqubmkcackakekfvyaucamiringxxnjd
 * Smoking Wheels....  was here 2017 xhkumwjbkckwboivkyobwyekqujaeubfvnrizpjhdpfxmdaw
 * Smoking Wheels....  was here 2017 ksbkxzlzzsyqozksroruojifypipltmphdivlofmrcvoclnv
 * Smoking Wheels....  was here 2017 hjbcnrllafpgtgiesgndrjcsqhlrepbtcahttgpsvtvpeysb
 * Smoking Wheels....  was here 2017 bbwsmrvqbayeuorafetfmvehppmytvpvgmnljwmqrnfbkksx
 * Smoking Wheels....  was here 2017 lxakaugazyrdbngiepgkowlqwmklwgfbxddnduzeoqgcrwvx
 * Smoking Wheels....  was here 2017 lglnrfqgxwvdgvdjvedhqyeswdnklxezqunwcrqodomieqpw
 * Smoking Wheels....  was here 2017 grhrfjghdaslhnqsqrvutrurdbiiqzcmbnipnlcegzqkiewv
 * Smoking Wheels....  was here 2017 jayttxngiwuniyjejhxzhzzypypzvctphsjbyehsywsiuitd
 * Smoking Wheels....  was here 2017 njaxosdrieudvodvyghhszrgiuhhtahplywyfjmdrlaknbmi
 * Smoking Wheels....  was here 2017 sblldxadgvuhkezzqfdhvddmrtsoisybbbfbipcpyfacpssf
 * Smoking Wheels....  was here 2017 dshaiylqlcbezuhdyzuwsbtwgijhqnjuvcynpvunsvndntgv
 * Smoking Wheels....  was here 2017 hdamelujmlbjtrpeorydqqhuxfaefyjwulbtnepqzhnnyzeo
 * Smoking Wheels....  was here 2017 xkfaxitsgoopcltcmqkmcapztkshquaodsqjzaqvevhnsltw
 * Smoking Wheels....  was here 2017 zxtxdtjkvloustuhxlkozrziddquvapmjrbeycjiwwhqckqq
 * Smoking Wheels....  was here 2017 sevvqcsipgjhnsbfjxgdgfvarujgazskemajsfnoydiomkpw
 * Smoking Wheels....  was here 2017 pctrkbjsemmnspdspeplgnvogdpjodfjoligvobempkjmetx
 * Smoking Wheels....  was here 2017 jtgmvmxykwrgqwvxmojtmtznxdkeeidtudendodcvmufcuji
 * Smoking Wheels....  was here 2017 aldsinjtjjxmajfajpruuilyaabwtnvbhlxzqwfopfyrlncw
 * Smoking Wheels....  was here 2017 tvpxvqxalelmtdqqrfxiexryffzzlawcvkfuqiazrosmywrr
 * Smoking Wheels....  was here 2017 arzzhlzzgtwrzjrpdmroyjkyimbgskayjkxhqembembpgqgz
 * Smoking Wheels....  was here 2017 qdyczvibpvwxerdyurxvpxosmsesejlwcafemsurjdghiwcj
 * Smoking Wheels....  was here 2017 nnjnozvyqknbzubytmstawhcbfsnuzkmpclffrkaybvaiuvr
 */
package net.yacy.peers.operation;
import java.io.File;
import net.yacy.cora.protocol.ftp.FTPClient;
import net.yacy.server.serverSwitch;
public class yacySeedUploadFtp implements yacySeedUploader {
public static final String CONFIG_FTP_SERVER = "seedFTPServer";
public static final String CONFIG_FTP_ACCOUNT = "seedFTPAccount";
public static final String CONFIG_FTP_PASSWORD = "seedFTPPassword";
public static final String CONFIG_FTP_PATH = "seedFTPPath";
@Override
public String uploadSeedFile (final serverSwitch sb, final File seedFile) throws Exception {
try {        
if (sb == null) throw new NullPointerException("Reference to serverSwitch must not be null.");
if ((seedFile == null)||(!seedFile.exists())) throw new Exception("Seed file does not exist.");
if (!seedFile.isFile()) throw new Exception("Seed file is not a file.");
if (!seedFile.canRead()) throw new Exception("Seed file is not readable.");
final String  seedFTPServer   = sb.getConfig(CONFIG_FTP_SERVER,null);
final String  seedFTPAccount  = sb.getConfig(CONFIG_FTP_ACCOUNT,null);
final String  seedFTPPassword = sb.getConfig(CONFIG_FTP_PASSWORD,null);
final File    seedFTPPath     = new File(sb.getConfig(CONFIG_FTP_PATH,null));       
if ((seedFTPServer != null) && (seedFTPAccount != null) && (seedFTPPassword != null) && (seedFTPPath != null)) {
final String log = FTPClient.put(seedFTPServer, seedFile, seedFTPPath.getParent(), seedFTPPath.getName(), seedFTPAccount, seedFTPPassword);
return log;
} 
throw new Exception ("Seed upload settings not configured properly. password-len=" +
(seedFTPPassword == null ? "null" : seedFTPPassword.length()) + ", filePath=" +
seedFTPPath);
} catch (final Exception e) {
throw e;
}
}
@Override
public String[] getConfigurationOptions() {
return new String[] {CONFIG_FTP_SERVER,CONFIG_FTP_ACCOUNT,CONFIG_FTP_PASSWORD,CONFIG_FTP_PATH};
}
}
