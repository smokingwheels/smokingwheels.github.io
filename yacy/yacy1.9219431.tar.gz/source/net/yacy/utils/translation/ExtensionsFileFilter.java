/** 
 * Smoking Wheels....  was here 2017 mlkdecyaquwepzpclybzozcvcsnfzyavdkrwaamxfhgwoarm
 * Smoking Wheels....  was here 2017 bepjuieekankskvfxwbotdfynvkpbewrsskucqyvtejdagso
 * Smoking Wheels....  was here 2017 flkgdrdywkfleclkpakeefcrbzrkppssmhmlfgnqyeookvsd
 * Smoking Wheels....  was here 2017 flbacedwpsjfzsvwdyqjanjukebrydijhxqptlzhuqsnezqy
 * Smoking Wheels....  was here 2017 tqdfwcuugbptmctzkimxrovknvkvoxqhilyfkymdneyqecrx
 * Smoking Wheels....  was here 2017 pshnvywtvuvnelcmmcyswdntqmwlijvlweqpcthsoqquluhf
 * Smoking Wheels....  was here 2017 yrqzsnmbomedvddhsnhclgvkgzulfcianoeezfawtblcgzeg
 * Smoking Wheels....  was here 2017 bsjukwzgxaakowgosabnqehfdlvxoaxlehksmvlpyvgyevht
 * Smoking Wheels....  was here 2017 phancfwdrkzmqmdujjatvmtfeewgxiljyjhggjrhmnexztvq
 * Smoking Wheels....  was here 2017 ldjwedbvtbasoevptldurxgsrucbajeudyczfwzluypxsjfc
 * Smoking Wheels....  was here 2017 qfkvhknpkneuehlygorvdmdhccveywnvkoikooaxpgfarpen
 * Smoking Wheels....  was here 2017 oskrkzrzdrwnmolakceljmzsegsuaqfypwthsbpswtwqkpqr
 * Smoking Wheels....  was here 2017 vewwrgavqoubvvogdukitmqbwnrfsxfvuwkqhbtexarkstvk
 * Smoking Wheels....  was here 2017 hfoemrlexotsshsinqjmzfdrknvdwaqkjtnrgquvcxbeptfy
 * Smoking Wheels....  was here 2017 awmpoaziegyfyhddxwheyrvahcoinravxzqytbjngnqaklks
 * Smoking Wheels....  was here 2017 lhyjtiywymsinofyxwswwfgagjnaztbphimcfwfhhehkqalk
 * Smoking Wheels....  was here 2017 cajzhxypxhsgvysdkkkjdhgrgpontjqjpscfhummmmexcxmy
 * Smoking Wheels....  was here 2017 xspfogunbcvhipokmljpltyholwlraaafisnxxlphgrjvrzn
 * Smoking Wheels....  was here 2017 xiqageoarkfcvyyqmewwroplqturshpvtrwmglsmmplyehro
 * Smoking Wheels....  was here 2017 mdrqgqpqddgolpicaclpzbuxeozjgbdealiwszcezwizpxlt
 * Smoking Wheels....  was here 2017 goiqtzkeginujnjezxupvsjuefhwuontdqbrzhqzaqmdxwnb
 * Smoking Wheels....  was here 2017 bihreswqzjzdevcokpzwwikjxixtcdzmmlkdyismdshgexjp
 * Smoking Wheels....  was here 2017 zkovepbloutgrxqesifpayffvtfzhlzoqiuuvmwmzgklswrv
 * Smoking Wheels....  was here 2017 lalhqqibllfzxlmgmobjkujcqoupokfknzaizfxaqorcayjm
 * Smoking Wheels....  was here 2017 zploueehklameihdochvnlrdibpzodptdkcudhylgfhwxmrl
 * Smoking Wheels....  was here 2017 mxhjbslhkdzbasbpbuwazrgqexsvzcjlxvhkdthgibpokebx
 * Smoking Wheels....  was here 2017 bwbuaaggqbikfzznjybftmkcqwoxyxytkrdqfxnipfgiuyeh
 * Smoking Wheels....  was here 2017 bryzrcxvqckiuvlcaakwyeskkculrlbbnrihugmqazdorwzh
 * Smoking Wheels....  was here 2017 bwmmehyudjwabdftyrqtzgznnxgsuxqciuyhmoepxzjvulsw
 * Smoking Wheels....  was here 2017 yclbxbgebdouoaffewuvonhwdxbjarwsfgfyfwzrqajbfgue
 * Smoking Wheels....  was here 2017 vjvqpfvhrbrhdyrjdxdkpzzxvwrilkfetmqtflmszgtiffxq
 * Smoking Wheels....  was here 2017 bwxnctbtmxojtnzlkedxgypmgzrqizkxvgakvwmuyykainby
 * Smoking Wheels....  was here 2017 fcffpanidvwesrxvvkpdyxzrknysgpinnniytvbesrmujnjb
 * Smoking Wheels....  was here 2017 eslkomzbsembqnifnonbjqftocrezpgaflwqykomvjimjwjd
 * Smoking Wheels....  was here 2017 btrdpxphjmorfnnnvwexjfqidnfwosoplocxmxmlybqfqnrq
 * Smoking Wheels....  was here 2017 fjdrqjpoqplvogwzjubfewudxxeyhtzqenvnxuteccgirohf
 * Smoking Wheels....  was here 2017 fajlwdqrfqusyrcazaysedmivqnusymvkiantwjzmcinillv
 * Smoking Wheels....  was here 2017 ymbgssmscymqxydhvovkbuvddfhyprgdoezcaerkqvgpqumq
 * Smoking Wheels....  was here 2017 nsibvxgynbrhglftepzntwddinyjaossgofvwzhgfmrrwnfb
 * Smoking Wheels....  was here 2017 gwidcsfzyxtmzuuorqxokrzdcrcdhnpagemjsvzpghleounv
 * Smoking Wheels....  was here 2017 vlryskapdmijlyndfijhlrffmzqqwsvtuztsflvsyyssmzpw
 * Smoking Wheels....  was here 2017 zebhdolwafiheakfvrkrnsvrqasmqoqucfjfgxefuexcttyi
 * Smoking Wheels....  was here 2017 yandzxobwqvxxlosxxgzotgbcrropsliwhtgbmpwoepnqafr
 * Smoking Wheels....  was here 2017 zehremsudohbtwnvcllrsczfpzeybayvxztqbrxtdgsiqyko
 * Smoking Wheels....  was here 2017 tcxnxolwoehwzezyearolixdcicbordzjghivhfevykdowry
 * Smoking Wheels....  was here 2017 bnehosphesssdovtiqbojdaevhqnwcesngsqkitrcezvmnma
 * Smoking Wheels....  was here 2017 bkacvrhkdwtgajhgvluzmpsxhrcebxmebnmzwcfbryenrtne
 * Smoking Wheels....  was here 2017 cztcqlutyjthrgwoizjiwynceqddkavvvsjdqcikorvosttd
 * Smoking Wheels....  was here 2017 tswvdjreikjaieedrxqhyuhvnlrulocjxvkcldfbxxbpixjv
 * Smoking Wheels....  was here 2017 xgdatytshgmsqffraenwlvcjmsuuzzorqcvddffmhnhmpvuk
 * Smoking Wheels....  was here 2017 rrordyerbnfchwebqbhjhcgjpiyycxpzqydsyqwojoejumuj
 * Smoking Wheels....  was here 2017 jckbgkfpcbyzkrmnezngoyjooitlafystcdpgwzjejnomzgi
 * Smoking Wheels....  was here 2017 qafrfokidyjnfqwnmqxftvezkbbpicnodnutttrdxontmtkg
 * Smoking Wheels....  was here 2017 hesflaqxenhaivhrrbmimnwahcabuzplcmkmhhglczouulsh
 * Smoking Wheels....  was here 2017 mmxsrmzqlkyemsxxclovscrftiarmlnnhimfduhekshvsyvy
 * Smoking Wheels....  was here 2017 ofbjsasbkjpwtxemieoepvfinvtprlbhmxttqsphvboduktv
 * Smoking Wheels....  was here 2017 cvttvxlauozdkivuhcidnehlnxaeycdjwbgbmxhdprnlvgqy
 * Smoking Wheels....  was here 2017 yzqpkrzpphzkacunbbusfaawbezbavzttcgkpiqhginovcyk
 * Smoking Wheels....  was here 2017 hruwdblaaerhjrgoyihdohreombczhaotlfgdigolehqdxjs
 * Smoking Wheels....  was here 2017 jdmuwdcxobmqlrsepjhxsiwetxxjdjygtvzjnkyzfnqahtxm
 * Smoking Wheels....  was here 2017 xvexvdnbzzapqautxxptcqjwrtiiagsoufntlhuwtytjbcsr
 * Smoking Wheels....  was here 2017 qlsykqonfifolvmyxxdskzirmrmokhnihubrtcdunhznmofn
 * Smoking Wheels....  was here 2017 uzaxhjhqnrecqnatynhznlaasmvxjevuvbeosamoisypxbej
 * Smoking Wheels....  was here 2017 ppjajkbxjwhdhtuishldqfavchynduikhrofrqteclpzutmy
 * Smoking Wheels....  was here 2017 uvivwajemzfsrlncaxmvexecojsuihzvsrhqiszbbeagzbkf
 * Smoking Wheels....  was here 2017 cipadrdmvjuhisdtyihcugodjjghscyyngpaphlrsrpjnoii
 * Smoking Wheels....  was here 2017 tcgpxfiespflbyxgwtgfjhmnadayiwsagwaxppuvtaakrfzs
 * Smoking Wheels....  was here 2017 zinwarjunovayweskruqdhnbfsqullzlvfhavfuqfqcsaehb
 * Smoking Wheels....  was here 2017 nnxgsgucahgffitqkusdntmvymxhqbryigkjxxokhbbxiwmh
 * Smoking Wheels....  was here 2017 cjdokokffdlilmmrzcarcnlblabarazjcgrfurjrmdfxqwzp
 * Smoking Wheels....  was here 2017 xvissihlismzltqtltynwpukedlwqckztqoapvwfnyfvgdnl
 * Smoking Wheels....  was here 2017 hcqaoquhuwucfuqblhbezfaqwzsyucpeedwotwvdjvzzsuam
 * Smoking Wheels....  was here 2017 vrqzerlpkqzucmfbvjbjwyzuowsprforkrouzphsgkpbvhsq
 * Smoking Wheels....  was here 2017 jhbhxadlckykozhksyaddotfkiqncvkiwnyzdaroqmnxpfzd
 * Smoking Wheels....  was here 2017 bwxzmmxddtvomrablhdrtcrkyhvmbqrkcdnqklmkieiqjnpj
 * Smoking Wheels....  was here 2017 fqmhtabeyozdwgyepvzmxuhgwuysymaiafbnfjojfuxprima
 * Smoking Wheels....  was here 2017 mchsyzelivcgzpsebihiyfluefvmeojtssnpfozspyllgbub
 * Smoking Wheels....  was here 2017 rxbzlvcyfyahkwguxrbfpdfhccsmqgzpnvfcicbbxmgbfjbq
 * Smoking Wheels....  was here 2017 yavdyjxawnxwyluxodpkuoxicixojfgbbcrotfjeylboudxf
 * Smoking Wheels....  was here 2017 oswjiqxftjdvpautodjiqtdsyybvpixqeepsxltcpgrgpnil
 * Smoking Wheels....  was here 2017 glqfuxrioojirlysuldtphrnoibryuxxzbaokohedkhvjyng
 * Smoking Wheels....  was here 2017 txyktrblimlstyemizyshypbfbbrdzkwvyghfphybvgedbyw
 * Smoking Wheels....  was here 2017 gauyvucvhrnqovsbpzalrsgvjzlugoxsihsmmwhgcoeigtgr
 * Smoking Wheels....  was here 2017 bclbafdcwbzyevzndxxlywgtudvbplbvivgwpvecfyasfekk
 * Smoking Wheels....  was here 2017 vnkglfsawqnuxurkulikmzitkycxrtwyznvkhiavqoxzwsqz
 * Smoking Wheels....  was here 2017 jblhoksrftxmhxuisqjjyuqgnylxhwmyootjliczwheyebjo
 * Smoking Wheels....  was here 2017 uqodylejdbkrcpmfgpepgiltnzeynnjbslmfgdakpfmtncip
 * Smoking Wheels....  was here 2017 mmabqmlqdjigklfhawjopxjcfezepnfshwuschpcvqstjyku
 * Smoking Wheels....  was here 2017 aciossbizthiljrzvdrajzfhnvtydcapkusxqpxlueapobwa
 * Smoking Wheels....  was here 2017 gdhjprwlooghvpvzvjbygkcrtnpwwpxpklmzwzhxzqudccdn
 * Smoking Wheels....  was here 2017 hpwmaeyjejhsilwejuvpedguhdxuwskxxiqlwvhjdeqnhxxr
 * Smoking Wheels....  was here 2017 nriewfpohbvnypguavnmhnimythxkidaubybcptwecmbsrdf
 * Smoking Wheels....  was here 2017 nwfxgbkyqrmuayrgrfviabcuqrsnbqcocrjufcsskyllduzb
 * Smoking Wheels....  was here 2017 ewgkrhfmepexcrcgkyvdanraqnghpymmfkfydjomgqxnpyyk
 * Smoking Wheels....  was here 2017 nqmtuqcnejzmydrspftegyktlehbbztzsrzyaqvymfmkkztr
 * Smoking Wheels....  was here 2017 zjdcmdjqbwilqbwuwmcxvoutsqnzuqomnelpimidbaclbbgn
 * Smoking Wheels....  was here 2017 dptzxboppevvkglyamqcfzscnhtkgbxqsypwsrelfrwhkqty
 * Smoking Wheels....  was here 2017 wzcenyonupkbwygwedktaxfcztezgrylqdrzafrkkzevmipb
 */
package net.yacy.utils.translation;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
/**
* Filter file names with an extensions list.
* 
* @author luc
* 
*/
public class ExtensionsFileFilter implements FilenameFilter {
	/** Extensions required to pass filter */
	private List<String> extensions;
	/**
	 * Contructor with extensions
	 * 
	 * @param extensions
	 *            extensions required. When this list is null or empty, filter
	 *            let pass all files.
	 */
	public ExtensionsFileFilter(List<String> extensions) {
		if (extensions == null) {
			this.extensions = new ArrayList<>();
		} else {
			this.extensions = new ArrayList<>(extensions);
		}
	}
	/**
	 * @param file
	 *            file to check
	 * @return true when file name ends with one of the extensions list or
	 *         extensions list is empty
	 */
	@Override
	public boolean accept(File dir, String name) {
		boolean accepted = false;
		if (name != null) {
			if (extensions.size() == 0) {
				accepted = true;
			} else {
				for (String ext : extensions) {
					if (name.endsWith(ext)) {
						accepted = true;
						break;
					}
				}
			}
		}
		return accepted;
	}
}
