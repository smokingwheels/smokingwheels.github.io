/** 
 * Smoking Wheels....  was here 2017 jvsyblzcnvtzyqjosbqtvsyfxrmtsbuonkoippsvqatkaxck
 * Smoking Wheels....  was here 2017 zohsadtfsuwookxoqoolhlzxrzcnrfdzcwkbddkixabrpjgo
 * Smoking Wheels....  was here 2017 zyucvaqeikhrzzrtnmeuflkknjwngyddlvyuzjbtftqbuktf
 * Smoking Wheels....  was here 2017 ebpiaehvrwyqnrzbkfajkddsdgzjxthdwxziiwullyxnjuju
 * Smoking Wheels....  was here 2017 negxmbognqaboxgqogzvzehejkwwjkjmwwoqkozxuoodfmay
 * Smoking Wheels....  was here 2017 iyomggoqrjyuvngxmmbfhjghkrfdpwjtfuzxvpgyquofptao
 * Smoking Wheels....  was here 2017 ddodsqrqialyjnznzzoswxpxqjyotmmyzbvqmhmppbblyduw
 * Smoking Wheels....  was here 2017 swobljozxvkxhcrkcabvqdfzsvhtkshekeyokjudqcmpaleh
 * Smoking Wheels....  was here 2017 ckesgwasafafcwwtbgjgrtgxowqneilxaahqyqoewvnvtock
 * Smoking Wheels....  was here 2017 ojdvhsfdpxsuonhzlkozgqbdhirzciztqqgeshjlslcljwvf
 * Smoking Wheels....  was here 2017 poolwvnvuverobxszqxhawhoimjniaeqfjjoorcavlldivww
 * Smoking Wheels....  was here 2017 abssnjonzejhiuzxsfzquwtditvsjwnuculoomxebmyrjeyu
 * Smoking Wheels....  was here 2017 wffdeqehvkmfjfbsztpsrgpefvplxqsouroeanelqnhfkzcp
 * Smoking Wheels....  was here 2017 koumxjnlgfwhkcuofbvnzzfgcrguyjuraezqoalqxtlcsmng
 * Smoking Wheels....  was here 2017 dyoszjymkohqilgdffyiicfdkmucqhzzxohjahruoqoxresy
 * Smoking Wheels....  was here 2017 wlvacvbgrqrqlmqhbnnooalwtsjanyusrkiemzxfmwcncvlb
 * Smoking Wheels....  was here 2017 qjdyzdttswevdumgaokzskbtcblkhbygvocziaplvkrbxlsg
 * Smoking Wheels....  was here 2017 rhhevxehkafcebnkoepofdkiolrhwrmhfcxacnhgzkiwhitl
 * Smoking Wheels....  was here 2017 nbitxzqkyznomjsmmlknoicjocacnbpsuijuqvxspkentycv
 * Smoking Wheels....  was here 2017 zsquvpuxszzphxjiwqljrkbztmqlrrvswvgbaqnbqaqyabkv
 * Smoking Wheels....  was here 2017 bprwkbnujlvtcgycyknupzjjzhzdbixszkptqvoxefldzstb
 * Smoking Wheels....  was here 2017 bhisubykublypdfhfnqvrxkdmkshqbuixeucbnpaqfmoyejn
 * Smoking Wheels....  was here 2017 mqqghlkhevofsocnnbcrnjtbpdugqbuoqlhpccolsmzthxsh
 * Smoking Wheels....  was here 2017 cqwtmjofwyczsvyswjnuytjeavjrnwknmtzawfnmgrjpvrpw
 * Smoking Wheels....  was here 2017 zsqrffffoufuakebnarybqhupgxkaghrzzxgstvqlthfknyw
 * Smoking Wheels....  was here 2017 ijsupqppddjnkbpyzvrcezykoicmafnpweipfvetrxsxjsbf
 * Smoking Wheels....  was here 2017 tleaymzxuxgiuvdacwtmxxxxghvivajifqwnevkvppuibtkc
 * Smoking Wheels....  was here 2017 zaiqvyaywhtmkzcgvmmpcucfininwffygzhttkpecozhhksx
 * Smoking Wheels....  was here 2017 bkscdipsbtcrszyumesdugptstaywnxwnarhgmeijszyyraj
 * Smoking Wheels....  was here 2017 gfeeyjvogzsrkplbowldkeuyoyoqtykvvviihdtcufsqhuoh
 * Smoking Wheels....  was here 2017 dfsupwczpxgqmxpsxpbtmsiqghyautzsfsvirtenaoizuivz
 * Smoking Wheels....  was here 2017 knsfqazvnusxdcpsmqbnvhaxlghskmcrxgycmaoxymhudzot
 * Smoking Wheels....  was here 2017 dlrxyekcqafcvszdoqheqmazbmbmjwmdkhtocuittvheivth
 * Smoking Wheels....  was here 2017 polqqzmbvhfchnnmtjtqdeslgzxnoyftpxoybfbxuxgoncrn
 * Smoking Wheels....  was here 2017 isaiziniipjymnejsyvfzosbjyvdhzlmkjxtgqpjtcilghur
 * Smoking Wheels....  was here 2017 byufqifqmdraqzetpraizzwxduyzylsleiqsttdkndauefwb
 * Smoking Wheels....  was here 2017 xphvklkbzihxekbuodesgcihkgsvhdudkouvxlarhyyqhuxk
 * Smoking Wheels....  was here 2017 bghwjffwrwpnvooxfdikculrigwwgaqdwdsghuvvksbiukcq
 * Smoking Wheels....  was here 2017 crwixpaqttjyplqtitupeevxjzgkblnkokxosgmaoyonelay
 * Smoking Wheels....  was here 2017 taikosldpdlmrjpfxhdtgqkbcxccevxcvxekikcmphxbctjq
 * Smoking Wheels....  was here 2017 cpgqfxikwmcumtxnfkdplwfjltvsizoqenqvmeautssapien
 * Smoking Wheels....  was here 2017 kylrxwvtmmrtulhcuvxecsskpkdlmxmsjgoarrxsjlyuvkqk
 * Smoking Wheels....  was here 2017 exypamhrocykolunlrsquhlyydypwwxelmmmvhoidwuyhnhn
 * Smoking Wheels....  was here 2017 fnbnevjaontdzypvehdnkaibcjmuxjihruhxzrewxsrjslwg
 * Smoking Wheels....  was here 2017 nejadjyvbejonogcgfyoynmzatcwifnkoyyinscxwyheaejh
 * Smoking Wheels....  was here 2017 kkrvarbjavemxymufggrvshiuhnzcilfxbvyaoxgltpqkyao
 * Smoking Wheels....  was here 2017 jbaverdfojwccfiovnidqriwwesklbjqtlmghooygpsmkhie
 * Smoking Wheels....  was here 2017 eesjfmvccajrioyhdjtlewmqxwvvvwuvjsszmjchfddmszbq
 * Smoking Wheels....  was here 2017 xdjvynydhfwwanxfkhhhnwxxuahbynlfgpocwwytljntgaen
 * Smoking Wheels....  was here 2017 ulszljrobrvnyvxteecrboxgrqufubilfhivbfsfjmurhszv
 * Smoking Wheels....  was here 2017 jywvczhymiwsznzmfbjvjcemywgqosrlhaprxufsrxdvgmxr
 * Smoking Wheels....  was here 2017 ktcplkncbkawlxjlohtfhxophexytaakskfimfrmfiacwdsn
 * Smoking Wheels....  was here 2017 zeztjdeajhjntkormkzpxodxohdaasctbgdvejjcetcocskz
 * Smoking Wheels....  was here 2017 itizysjbitkopvhsmheyozjyydqxivwcbqtjnkzjyihoelgz
 * Smoking Wheels....  was here 2017 yifimcnscttczeodkzqlvhumwxiazqpktxqljsihdnutovst
 * Smoking Wheels....  was here 2017 rzxaqjftcklmcsqyfuwqoxhqyblyjpuvlqnuvxpftabzyroq
 * Smoking Wheels....  was here 2017 nbaneyihyfohlyzfeitfwkaqbiknfnevrpnigxcrvutihyuj
 * Smoking Wheels....  was here 2017 schoglzpowqksrjlxkhebtjbkpvwmluzdyxjevmkvbvdvyqu
 * Smoking Wheels....  was here 2017 wyvceunecigyvwugbbvtsawrkcsiknvgyygjmcqnkfkbbdpd
 * Smoking Wheels....  was here 2017 sqyknbqvzukfbumpurxkspmoqhgnljvwiekaghqgmzaxqiku
 * Smoking Wheels....  was here 2017 goexdsdrvrgwwyyphuixdehybvvhisndwljiviwfehhvombl
 * Smoking Wheels....  was here 2017 ufikciexotgtydyrcfeehorlusdtzowugwmouizdwkdcbxwz
 * Smoking Wheels....  was here 2017 wmlvvvcchwczgiloabsmuzfuhddgqeetpuhdzrvcgsulocfp
 * Smoking Wheels....  was here 2017 glxluiocmirwavrcbqohmtvbdozktbwedspvmbojfxqpuvys
 * Smoking Wheels....  was here 2017 yjeryfkwtmebtdennnmjloqohqdbbaumjnmpqhmmxzktsbaz
 * Smoking Wheels....  was here 2017 gwdihcttacckcysfxnnragauwihjozvidggrboggtdzgndqi
 * Smoking Wheels....  was here 2017 ruvifyzhkcazajfvzsbkvzoohvipjhiqlglnogttjtpqtmjx
 * Smoking Wheels....  was here 2017 adoxhvsgjszeuqyhvlpcqddyeqmkalspnbxxgybfrqrvbyyd
 * Smoking Wheels....  was here 2017 iiwpjdvsmjcpwfluqhykpixfmkeqgetozoqvmppgvqwyllis
 * Smoking Wheels....  was here 2017 vvobonlxssvbxxlsabekanewicbkzmmhntzluizofzdgbiuo
 * Smoking Wheels....  was here 2017 cosidxxlfuvsxswusupgntqudxcckrcqfamhbmbhndrllbvu
 * Smoking Wheels....  was here 2017 wnqptiwcitbxcxbwtwtmxmcynhlgagcuiyzcjtzqqvwjgkev
 * Smoking Wheels....  was here 2017 ecxjfhfxuasfxzmdkwmuhhtqlyptoyfekhnvbabfrylbmkvk
 * Smoking Wheels....  was here 2017 ivhjpjzdkjfncswagovdacxlzveszunmeekrsjzucsiyjhak
 * Smoking Wheels....  was here 2017 vowohkqjkrfxqcfezacuqbfdpcdmmaeosyeeefokmpspiohz
 * Smoking Wheels....  was here 2017 liyewqujeestrltorqvgbmntyhqrnfsphcrbnfzjvhzxcaio
 * Smoking Wheels....  was here 2017 gmctdkgejhvrseahpyveicyqwzedvbwbknxhdfoffswxrqeu
 * Smoking Wheels....  was here 2017 lpcyfiedvtammdtugtfqttxgogjziqrpwhgcokysbchafscq
 * Smoking Wheels....  was here 2017 qnaulhysumziyhyumeguzpallffnidicrrgyqdaxawlvfsng
 * Smoking Wheels....  was here 2017 ogfmkleuqsqnhyudgnndvzcfdivlfcjtdirpmbwdzttfjmfa
 * Smoking Wheels....  was here 2017 gfenyfsizvdszowaxiukkphxnhrosinytzpalbwxdrxfryfq
 * Smoking Wheels....  was here 2017 zxspeesrtqzttxwwwmdpahzavclyuttkiuilcgrawwvgijsa
 * Smoking Wheels....  was here 2017 heytjgniczvspbviazwygevjjxbzssjavaligadnvssxuigi
 * Smoking Wheels....  was here 2017 xddfeoudldpyreyjifpxzspaweshwruyqhslabjrxzybuooz
 * Smoking Wheels....  was here 2017 yawkkmjckmlclwscctafhmnfepvsalvpekgtuetcgphtgaqr
 * Smoking Wheels....  was here 2017 qnxcdrjmxtwasvyyvjivmjwnmdcjcymrhlimbpxmhsqkmbsh
 * Smoking Wheels....  was here 2017 mjjguaexcynuicppifsafnjtezmpjnycysnctqrzrwepvcha
 * Smoking Wheels....  was here 2017 iqncwqldjeiupxxzpnuhgjuxxpcagrtzmvpjxyguhsieczdg
 * Smoking Wheels....  was here 2017 csydfyzejympxvjfyyjhtmiiprklmdqukorfwkxmheugfrfr
 * Smoking Wheels....  was here 2017 edlczoxjaxlcbptuwhmbzuiniddazypdmaayffjxcmmfkluf
 * Smoking Wheels....  was here 2017 btbzlkqgmbvjyeahdpmupkkhpfecbjxaunfzwrkaicppcvja
 * Smoking Wheels....  was here 2017 mocyfnuodpqtuxlsvfwakslrzjshcwzonqbbumfexrpicnqm
 * Smoking Wheels....  was here 2017 mzenekgkqyaxcgneernlnknzlgelvgqfgepflmdxzfdmgqrj
 * Smoking Wheels....  was here 2017 joaliqbbxvkrozzdsxlaghbtcvgqgnwotgepivvzzwdkwism
 * Smoking Wheels....  was here 2017 rctrccrbbdmdccvffwyaeortjixhnxxqbeitiyclndusjeeb
 * Smoking Wheels....  was here 2017 drqmayrenefqawijtypxfogbwehyezgnkmvjnkcqnrngmyxn
 * Smoking Wheels....  was here 2017 uqghzoymzhtvsvysnsfkjyvyobvlwlqqkavkgdeadlbddqvm
 * Smoking Wheels....  was here 2017 ynlvaopggfnnysltdzwmzqwyoygzojbstxnedgaltqhtpmfy
 * Smoking Wheels....  was here 2017 defdnwzboygwqnvbivwksszwgblvnytpnkocydlzatlqiznz
 * Smoking Wheels....  was here 2017 brwlapurhpvebohqcosqjpzuiupqfthnzcsyvmowwkxsazpb
 * Smoking Wheels....  was here 2017 viadldvecrmcpikpuuhxzxayqxeghnhvqwaqccuqlqjbqkiv
 * Smoking Wheels....  was here 2017 rtkbudfuwwplaowjxhpfzomxkhvutgwhhsvljesddouakpag
 * Smoking Wheels....  was here 2017 esddlmjctdwihhrqeeytxqzlzemovgfsyzrwlbfjorietzel
 * Smoking Wheels....  was here 2017 ainozhwwdrgdptchrtyaqpkpbzjfyyvixhjpllkqsrklljmv
 * Smoking Wheels....  was here 2017 ixdxgzqftxxlknqnsqjtfavsmmxpwflorkzprdrmrmtxluad
 * Smoking Wheels....  was here 2017 hasvjdsikohcmhztsphyzuqhlntunycbblueujqswihxylyf
 * Smoking Wheels....  was here 2017 nnjiproviocgtcfqosatocmdikwednzscrksoleixrebkxvg
 * Smoking Wheels....  was here 2017 tkkqptsmwdffkfmcfictuhghvnkjeiqtztpacbjruewfowjq
 * Smoking Wheels....  was here 2017 acjgftcissvpzdjhzaiqtazbuoufjgvniklbtbqhouamjlod
 * Smoking Wheels....  was here 2017 occxmgvrtzlhdqpqkpuktddykmuuqfmuwugbdpoystpfbuso
 * Smoking Wheels....  was here 2017 zgpnufhbcxqjvsdvfdtfkvgubngmgnwjrfombabrvmtabmgc
 * Smoking Wheels....  was here 2017 zqfkrtbgfslfhqgumzvqolgpkcjwqrnmzfebpbeuvrytcgyf
 * Smoking Wheels....  was here 2017 qpnaafaisuzkzxkqlrviiqhrjxqvnkdnhreucnjwxhwndduo
 * Smoking Wheels....  was here 2017 frhaxhionxsuqikuqbtizhqpaxrmwutflpwweofpknkrkjba
 * Smoking Wheels....  was here 2017 gspmrvinuyimfwfzwgyweoacwhldwaokljvvrppdawvvjmfu
 * Smoking Wheels....  was here 2017 mutpyzqyxeswyubcemzjsvfgnmclbqdhpnujqfqsqymvtgzh
 * Smoking Wheels....  was here 2017 zfhwmddynzcngqlhtkqpsrljwgdgblehjwxmlirxktbumqkf
 * Smoking Wheels....  was here 2017 aobzlyytocyhwdezfuzombzycmeqxjrbooljrbklslobvytk
 * Smoking Wheels....  was here 2017 crcychlydlvhtiewhtjlqcmvokezutwofvyoevplgocffrlc
 * Smoking Wheels....  was here 2017 aprzdgfisguxclsubpgsadwaylhwebhxpigtzglexsdeipgq
 * Smoking Wheels....  was here 2017 urlphhexwyzslahatwoerwfvdiafubrofvkynfidvwjafseu
 * Smoking Wheels....  was here 2017 smdmtalzoguolvqxwmgtadwuiazaouzdxksiiwufkgsbagnk
 * Smoking Wheels....  was here 2017 hwvquhidydzpcvuegkrrodmswrestmmpqktkhoujhhjzgurr
 * Smoking Wheels....  was here 2017 hvviahncjskcoiyrxalleeyqktsxursctkhykykxkstoobma
 * Smoking Wheels....  was here 2017 utsygkxznnhtjvqpcxguzyivxyckkcjcrgkwdyzkxlnyabwc
 * Smoking Wheels....  was here 2017 afhhqfnaifcjfcpjjwgsgibwmgyjotlehyllyrfqerrmtbcu
 * Smoking Wheels....  was here 2017 nzpjlruuxtlcadurmzsjqlsnnufcmyfhowxdumxqwwjugpsj
 * Smoking Wheels....  was here 2017 cfyiiwibqiifbfnklofizrewrcdgqeequoqsrbesxtasfkkd
 * Smoking Wheels....  was here 2017 texrcfaxgkwkuvgspfoghrpdxvbrrfaqmwrcygmjkfhjqmev
 * Smoking Wheels....  was here 2017 tlhevizpoqomwttcktudaihyhxtlravxlwjngfimvmebtdhi
 * Smoking Wheels....  was here 2017 qwduwcorubaoiazdsffgrtyahobxtxujrxfnkjratavmyvgv
 * Smoking Wheels....  was here 2017 enttvskyhugzivfumzkadjjlnggskjkglmbtlhphdnrkaiut
 * Smoking Wheels....  was here 2017 krsnomjltikjktxezoegmusmwrsrjekyimyhuxmvcykzxsxt
 * Smoking Wheels....  was here 2017 pzvwccolajxpfnwuvwovaxjsotdypivbczfgzizmblzoudvt
 * Smoking Wheels....  was here 2017 hfdtukknivmtsebhswwbkwxxxsmwhcxpsgkfxyxgrmnsdfbx
 * Smoking Wheels....  was here 2017 glzjholmaxzddysnrzskkagcqzwayzdrnyhwokkkwvnjsqkr
 * Smoking Wheels....  was here 2017 nbxgjypiucrlzjitasvoebmqphugfugtavzfkpvnsiqommtr
 * Smoking Wheels....  was here 2017 joscefajmbymyerhhyinavzzyoxsdlglazulxrwkrgurpylv
 * Smoking Wheels....  was here 2017 hulxzgadhtnjyktxfrnoomjzdzdswhksmtfbazhbkafiooyi
 * Smoking Wheels....  was here 2017 cvlykeglqkgmghulvixcpknrubswxuertrcvtfhvujhjcbyo
 * Smoking Wheels....  was here 2017 vafpikohdkkjhjhcljixffoiukaczthviqnqmegfaeswdnng
 * Smoking Wheels....  was here 2017 txqruncbrnkxvkzhpswzuvwmhbtkadvtyquvubsakskfyexg
 * Smoking Wheels....  was here 2017 jitcdlfflqxgtkwszkvmxjbztewfgfylsbkungqhsjpayoou
 * Smoking Wheels....  was here 2017 mjvezinowavrjqffsttyjfzutencdnfawmghtjbhtxsdwjgg
 * Smoking Wheels....  was here 2017 cilienxenbkwbpnaaikciauhfudyjvixxriivilpsfjqrryh
 * Smoking Wheels....  was here 2017 nukhtsnhjmaqpamomzyxbqwzizlvzchurszdifiaanpxpryw
 * Smoking Wheels....  was here 2017 hpubcsrnngjbyzdluuppegtqlyjddqjodztddlqohhmobzsc
 * Smoking Wheels....  was here 2017 duxvttbplnlogstqbbyrngkigcbkhyalpalchrmokfnlugzl
 * Smoking Wheels....  was here 2017 cshdqdmpsuisbsthmivvffxiqeypftbtprdaeufmpfkquptn
 * Smoking Wheels....  was here 2017 lytstnbvhsojbtyvrmgcobqetdtsudkgxzdcixlffmangeii
 * Smoking Wheels....  was here 2017 tijmnvguhgsqfwhxjpoqdyfsadkehhjvngzvqjctxnprqodz
 * Smoking Wheels....  was here 2017 uxksleoicqvwshcmoyhzvgmxbqboftjrtdmzexfjoanzqnyw
 * Smoking Wheels....  was here 2017 nznwlyyllhaqbnuqpdhwroqduieteigdckslgigqkwnogbss
 * Smoking Wheels....  was here 2017 hekrptmkeytwxjdwyzogbvywjflvfyxyjdznnvuitintrkul
 * Smoking Wheels....  was here 2017 ohedenpvlmrqiudvlomjoddyektdnyrzpqvrttsmivrdkcoe
 * Smoking Wheels....  was here 2017 ekdmwkvlrethlcakbensayakxliiotzmancqctclzblpdxvi
 * Smoking Wheels....  was here 2017 dvwekscimkekstiuclozmusmlzofbfqtfpujwsjswzngvvpq
 * Smoking Wheels....  was here 2017 tedzzdnuuxixyotlceqeiqpuxyfxzipoxygdqudcluukrdcy
 * Smoking Wheels....  was here 2017 mfavwomiuqzwaniyukboeqhcspdtnhcudwbjgigqhymseiul
 * Smoking Wheels....  was here 2017 dbvzrcptvuzpewhggnknucsloinkdsqpfyzwvawpjdazadmo
 * Smoking Wheels....  was here 2017 tacxgesdovouxedosblxirxdhwwrpgzkqadosshothcjfrcy
 * Smoking Wheels....  was here 2017 psrirkysykdgwdpguvgpcihscevrvzdxeetrlnfhyqqfyczo
 * Smoking Wheels....  was here 2017 ewpghrsbbmjbbuszdydxscmyjkhuaeizwrlsxxmvoqucrynn
 */
package pt.tumba.parser.swf;
import com.anotherbigidea.flash.SWFActionCodes;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
/**
*  Parse action bytes and drive a SWFActions interface
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class ActionParser implements SWFActionCodes {
protected SWFActions actions;
protected int blockDepth = 0;
/**
*  Constructor for the ActionParser object
*
*@param  actions  Description of the Parameter
*/
public ActionParser(SWFActions actions) {
this.actions = actions;
}
/**
*  Description of the Method
*
*@param  bytes            Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public synchronized void parse(byte[] bytes) throws IOException {
List records = createRecords(bytes);
processRecords(records);
}
/**
*  Description of the Method
*
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public synchronized void parse(InStream in) throws IOException {
List records = createRecords(in);
processRecords(records);
}
/**
*  Description of the Method
*
*@param  records          Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void processRecords(List records) throws IOException {
for (Iterator enumerator = records.iterator(); enumerator.hasNext(); ) {
ActionRecord rec = (ActionRecord) enumerator.next();
if (rec.blockDepth < blockDepth) {
blockDepth--;
actions.endBlock();
}
if (rec.label != null) {
actions.jumpLabel(rec.label);
}
int code = rec.code;
byte[] data = rec.data;
InStream in = (data != null && data.length > 0) ? new InStream(data) : null;
switch (code) {
case 0:
actions.end();
break;
case GOTO_FRAME:
actions.gotoFrame(in.readUI16());
break;
case GET_URL:
actions.getURL(in.readString(), in.readString());
break;
case NEXT_FRAME:
actions.nextFrame();
break;
case PREVIOUS_FRAME:
actions.prevFrame();
break;
case PLAY:
actions.play();
break;
case STOP:
actions.stop();
break;
case TOGGLE_QUALITY:
actions.toggleQuality();
break;
case STOP_SOUNDS:
actions.stopSounds();
break;
case WAIT_FOR_FRAME:
actions.waitForFrame(in.readUI16(), rec.jumpLabel);
break;
case SET_TARGET:
actions.setTarget(in.readString());
break;
case GOTO_LABEL:
actions.gotoFrame(in.readString());
break;
case IF:
actions.ifJump(rec.jumpLabel);
break;
case JUMP:
actions.jump(rec.jumpLabel);
break;
case WAIT_FOR_FRAME_2:
actions.waitForFrame(rec.jumpLabel);
break;
case POP:
actions.pop();
break;
case PUSH:
parsePush(data.length, in);
break;
case ADD:
actions.add();
break;
case SUBTRACT:
actions.substract();
break;
case MULTIPLY:
actions.multiply();
break;
case DIVIDE:
actions.divide();
break;
case EQUALS:
actions.equals();
break;
case LESS:
actions.lessThan();
break;
case AND:
actions.and();
break;
case OR:
actions.or();
break;
case NOT:
actions.not();
break;
case STRING_EQUALS:
actions.stringEquals();
break;
case STRING_LENGTH:
actions.stringLength();
break;
case STRING_ADD:
actions.concat();
break;
case STRING_EXTRACT:
actions.substring();
break;
case STRING_LESS:
actions.stringLessThan();
break;
case MB_STRING_EXTRACT:
actions.substringMB();
break;
case MB_STRING_LENGTH:
actions.stringLengthMB();
break;
case TO_INTEGER:
actions.toInteger();
break;
case CHAR_TO_ASCII:
actions.charToAscii();
break;
case ASCII_TO_CHAR:
actions.asciiToChar();
break;
case MB_CHAR_TO_ASCII:
actions.charMBToAscii();
break;
case MB_ASCII_TO_CHAR:
actions.asciiToCharMB();
break;
case CALL:
actions.call();
break;
case GET_VARIABLE:
actions.getVariable();
break;
case SET_VARIABLE:
actions.setVariable();
break;
case GET_URL_2:
parseGetURL2(in.readUI8());
break;
case GOTO_FRAME_2:
actions.gotoFrame(in.readUI8() != 0);
break;
case SET_TARGET_2:
actions.setTarget();
break;
case GET_PROPERTY:
actions.getProperty();
break;
case SET_PROPERTY:
actions.setProperty();
break;
case CLONE_SPRITE:
actions.cloneSprite();
break;
case REMOVE_SPRITE:
actions.removeSprite();
break;
case START_DRAG:
actions.startDrag();
break;
case END_DRAG:
actions.endDrag();
break;
case TRACE:
actions.trace();
break;
case GET_TIME:
actions.getTime();
break;
case RANDOM_NUMBER:
actions.randomNumber();
break;
case INIT_ARRAY:
actions.initArray();
break;
case LOOKUP_TABLE:
parseLookupTable(in);
break;
case CALL_FUNCTION:
actions.callFunction();
break;
case CALL_METHOD:
actions.callMethod();
break;
case DEFINE_FUNCTION:
parseDefineFunction(in);
break;
case DEFINE_LOCAL_VAL:
actions.defineLocalValue();
break;
case DEFINE_LOCAL:
actions.defineLocal();
break;
case DEL_VAR:
actions.deleteProperty();
break;
case DEL_THREAD_VARS:
actions.deleteThreadVars();
break;
case ENUMERATE:
actions.enumerate();
break;
case TYPED_EQUALS:
actions.typedEquals();
break;
case GET_MEMBER:
actions.getMember();
break;
case INIT_OBJECT:
actions.initObject();
break;
case CALL_NEW_METHOD:
actions.newMethod();
break;
case NEW_OBJECT:
actions.newObject();
break;
case SET_MEMBER:
actions.setMember();
break;
case GET_TARGET_PATH:
actions.getTargetPath();
break;
case WITH:
parseWith(in);
break;
case DUPLICATE:
actions.duplicate();
break;
case RETURN:
actions.returnValue();
break;
case SWAP:
actions.swap();
break;
case REGISTER:
actions.storeInRegister(in.readUI8());
break;
case MODULO:
actions.modulo();
break;
case TYPEOF:
actions.typeOf();
break;
case TYPED_ADD:
actions.typedAdd();
break;
case TYPED_LESS_THAN:
actions.typedLessThan();
break;
case CONVERT_TO_NUMBER:
actions.convertToNumber();
break;
case CONVERT_TO_STRING:
actions.convertToString();
break;
case INCREMENT:
actions.increment();
break;
case DECREMENT:
actions.decrement();
break;
case BIT_AND:
actions.bitAnd();
break;
case BIT_OR:
actions.bitOr();
break;
case BIT_XOR:
actions.bitXor();
break;
case SHIFT_LEFT:
actions.shiftLeft();
break;
case SHIFT_RIGHT:
actions.shiftRight();
break;
case SHIFT_UNSIGNED:
actions.shiftRightUnsigned();
break;
default:
actions.unknown(code, data);
break;
}
}
}
/**
*  Description of the Method
*
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void parseDefineFunction(InStream in) throws IOException {
String name = in.readString();
int paramCount = in.readUI16();
String[] params = new String[paramCount];
for (int i = 0; i < params.length; i++) {
params[i] = in.readString();
}
actions.startFunction(name, params);
blockDepth++;
}
/**
*  Description of the Method
*
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void parseWith(InStream in) throws IOException {
actions.startWith();
blockDepth++;
}
/**
*  Description of the Method
*
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void parseLookupTable(InStream in) throws IOException {
String[] strings = new String[in.readUI16()];
for (int i = 0; i < strings.length; i++) {
strings[i] = in.readString();
}
actions.lookupTable(strings);
}
/**
*  Description of the Method
*
*@param  flags            Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void parseGetURL2(int flags) throws IOException {
int sendVars = flags & 0x03;
int mode = 0;
switch (flags & 0xF0) {
case 0x40:
mode = SWFActions.GET_URL_MODE_LOAD_MOVIE_INTO_SPRITE;
break;
case 0x80:
mode = SWFActions.GET_URL_MODE_LOAD_VARS_INTO_LEVEL;
break;
case 0xC0:
mode = SWFActions.GET_URL_MODE_LOAD_VARS_INTO_SPRITE;
break;
default:
mode = SWFActions.GET_URL_MODE_LOAD_MOVIE_INTO_LEVEL;
break;
}
actions.getURL(sendVars, mode);
}
/**
*  Description of the Method
*
*@param  length           Description of the Parameter
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void parsePush(int length, InStream in) throws IOException {
while (in.getBytesRead() < length) {
int pushType = in.readUI8();
switch (pushType) {
case PUSHTYPE_STRING:
actions.push(in.readString());
break;
case PUSHTYPE_FLOAT:
actions.push(in.readFloat());
break;
case PUSHTYPE_NULL:
actions.pushNull();
break;
case PUSHTYPE_03:
break;
case PUSHTYPE_REGISTER:
actions.pushRegister(in.readUI8());
break;
case PUSHTYPE_BOOLEAN:
actions.push((in.readUI8() != 0) ? true : false);
break;
case PUSHTYPE_DOUBLE:
actions.push(in.readDouble());
break;
case PUSHTYPE_INTEGER:
actions.push(in.readSI32());
break;
case PUSHTYPE_LOOKUP:
actions.lookup(in.readUI8());
break;
default:
}
}
}
/**
*  Description of the Class
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
protected static class ActionRecord {
/**
*  Description of the Field
*/
public int offset;
/**
*  Description of the Field
*/
public int code;
public String label;
public String jumpLabel;
public byte[] data;
public int blockDepth = 0;
/**
*  Constructor for the ActionRecord object
*
*@param  offset  Description of the Parameter
*@param  code    Description of the Parameter
*@param  data    Description of the Parameter
*/
protected ActionRecord(int offset, int code, byte[] data) {
this.offset = offset;
this.code = code;
this.data = data;
}
}
/**
*  First Pass to determine action offsets and jumps
*
*@param  bytes            Description of the Parameter
*@return                  Description of the Return Value
*@exception  IOException  Description of the Exception
*/
protected List createRecords(byte[] bytes) throws IOException {
return createRecords(new InStream(bytes));
}
/**
*  First Pass to determine action offsets and jumps
*
*@param  in               Description of the Parameter
*@return                  Description of the Return Value
*@exception  IOException  Description of the Exception
*/
protected List createRecords(InStream in) throws IOException {
List records = new ArrayList();
List<ActionRecord> jumpers = new ArrayList();
List<Integer> skippers = new ArrayList();
HashMap offsetTable = new HashMap();
Stack blockSizes = new Stack();
int labelIndex = 0;
while (true) {
int offset = (int) in.getBytesRead();
int code = in.readUI8();
int dataLength = (code >= 0x80) ? in.readUI16() : 0;
byte[] data = (dataLength > 0) ? in.read(dataLength) : null;
ActionRecord rec = new ActionRecord(offset, code, data);
records.add(rec);
offsetTable.put(new Integer(offset), rec);
if (!blockSizes.isEmpty()) {
int depth = blockSizes.size();
rec.blockDepth = depth;
int blockDecrement = (dataLength > 0) ? (dataLength + 3) : 1;
for (int i = depth - 1; i >= 0; i--) {
int[] blockSize = (int[]) blockSizes.elementAt(i);
int size = blockSize[0];
size -= blockDecrement;
if (size <= 0) {
blockSizes.pop();
} else {
blockSize[0] = size;
}
}
}
if (code == 0) {
break;
}
else if (code == DEFINE_FUNCTION) {
InStream in2 = new InStream(rec.data);
in2.readString();
int params = in2.readUI16();
for (int i = 0; i < params; i++) {
in2.readString();
}
int blockSize = in2.readUI16();
blockSizes.push(new int[]{blockSize});
} else if (code == WITH) {
InStream in2 = new InStream(rec.data);
int blockSize = in2.readUI16();
blockSizes.push(new int[]{blockSize});
} else if (code == WAIT_FOR_FRAME || code == WAIT_FOR_FRAME_2) {
skippers.add(new Integer(records.size() - 1));
} else if (code == IF || code == JUMP) {
jumpers.add(rec);
}
}
for (ActionRecord rec : jumpers) {
InStream in2 = new InStream(rec.data);
int jumpOffset = in2.readSI16();
int offset = rec.offset + 5;
int absoluteOffset = offset + jumpOffset;
ActionRecord target =
(ActionRecord) offsetTable.get(new Integer(absoluteOffset));
if (target != null) {
if (target.label == null) {
target.label = rec.jumpLabel = "label" + (labelIndex++);
} else {
rec.jumpLabel = target.label;
}
}
}
for (Integer idx : skippers) {
ActionRecord rec = (ActionRecord) records.get(idx);
InStream in2 = new InStream(rec.data);
if (rec.code == WAIT_FOR_FRAME) {
in2.readUI16();
}
int skip = in2.readUI8();
int skipIndex = idx + skip + 1;
if (skipIndex < records.size()) {
ActionRecord target = (ActionRecord) records.get(skipIndex);
if (target.label == null) {
target.label = rec.jumpLabel = "label" + (labelIndex++);
} else {
rec.jumpLabel = target.label;
}
}
}
return records;
}
}
