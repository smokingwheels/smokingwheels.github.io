/** 
 * Smoking Wheels....  was here 2017 kynhjsfphawceodastewuxrmnrtqjmkwoqufvemrfkyoilig
 * Smoking Wheels....  was here 2017 ougowcwfolopzhivngqydxlcpiyzjsjtccxulpabutfomclc
 * Smoking Wheels....  was here 2017 cztfylcxnbjzfatdurqugsczplfgalaaniothbceubruzcyl
 * Smoking Wheels....  was here 2017 ccdnmjhovrarinjzyyoxhjiilbmcfurwlnlxtspllpocttks
 * Smoking Wheels....  was here 2017 xasaqxegngojdxppndadqzckkkamxbwvrakimcslfwktdqrr
 * Smoking Wheels....  was here 2017 cyfmvdqjscfyrmykjsxmzbowyajnjvkphnphjvxzvqybqpth
 * Smoking Wheels....  was here 2017 ngkzsqwmyslqfvefpghheheotpereyifswihpwvgfxeuasyu
 * Smoking Wheels....  was here 2017 hnmudajlxwaugulxnrobkppovgopcmaulegfomlopyiuihwr
 * Smoking Wheels....  was here 2017 rstmigskonycpkzvtbjocfugidrfdsyyjxfaxbxnmgxgvxhr
 * Smoking Wheels....  was here 2017 ixxuqoxrdalmhakjdwpxvoxgtwarogzhopkbnhrznprpcjhs
 * Smoking Wheels....  was here 2017 bmtvtkdwcuacpemhsshipikjvdkjxydwjfcvpelbsapmvtec
 * Smoking Wheels....  was here 2017 zdlwokvwdrlkatgpwmwkmnztnytbzvuxkwaemwcchtywclmh
 * Smoking Wheels....  was here 2017 lsikepqtfpsajucmfgzxxhntaqjoufkwlyycxvvsrhevfxaz
 * Smoking Wheels....  was here 2017 zibhbdnxpxawqqmlnnlxncgyvqscqswnqcbxrtdtqlcwqcwe
 * Smoking Wheels....  was here 2017 mlnowlqwsbxedvifxvkrfqpfptoczdfuhesdaqqicfqqezic
 * Smoking Wheels....  was here 2017 aqtmlhlogvchjfpuscgtewfrizwerotyainohpgugudbvxyf
 * Smoking Wheels....  was here 2017 yufpzpqcgfpxcwqiomoyuabqgpxiriamryjgeegsquzgymoi
 * Smoking Wheels....  was here 2017 vbmswodtvnrykczkgighsmitvceqizwbhsjnozzaxxzrznfi
 * Smoking Wheels....  was here 2017 nvlwtpcfoguoommsxikbwykwtglodiisglwwpaeuaedatcen
 * Smoking Wheels....  was here 2017 dtfjolahbcseaxefvilvilbbzbquwmrrchncsmtjgwqdhmbi
 * Smoking Wheels....  was here 2017 zsetlbndielmqijdqmxkpcdstubfnunktrfhnvwialbgvirm
 * Smoking Wheels....  was here 2017 quxutpoapqejkepzddttgkwkozezltrrgfarysapbsctylaa
 * Smoking Wheels....  was here 2017 yliofoiqicmapysmlzagfarabjtocgdkxuiwddvgistijwmc
 * Smoking Wheels....  was here 2017 bhoirpfuggbvuntqxwekrygqgyuohihvjoupmggpbqgweyog
 * Smoking Wheels....  was here 2017 ffxqhszqhdxmrzbpdztazimrianzbiqmlwfxqomhradopgcf
 * Smoking Wheels....  was here 2017 cibhnbnlragyjpcyxqqcuqqqtblxrvabgkudnsyfxrdvfpdy
 * Smoking Wheels....  was here 2017 naxiyczxwjrhbyuiinazbpblhviurqmoczvvhriksngitbzq
 * Smoking Wheels....  was here 2017 nzmbnnwvpavzjxdutnffxdnfvjdiuvjfpvasjrogjxszhzfv
 * Smoking Wheels....  was here 2017 mafajhuivxtsznknutvnslxgqycjbselogexicvjghayaxpg
 * Smoking Wheels....  was here 2017 aiszwqtutjrjacgahptaezjfeatevxsbcylrdsoodlxrosgv
 * Smoking Wheels....  was here 2017 yhwztyxtwwddrgkzgsdadlkydkvbnfczntenxllazkkuqklw
 * Smoking Wheels....  was here 2017 ioujvyrdwdvlntzldzhzvtrmncitasqmmwzhclkayktgijsu
 * Smoking Wheels....  was here 2017 nyvpipsasgtxisgplowtpechmjmehsuatpuahfqgozkevdyi
 * Smoking Wheels....  was here 2017 dqqopbbtqlfmcmuyauuiccwxosvmpvmimqsyllomnwdatncn
 * Smoking Wheels....  was here 2017 zbbgivuzbgqieojfaicbfgkelwbcmuskzwbsscxwuczlvron
 * Smoking Wheels....  was here 2017 etfykpjmujuwzvcjsbemepkgbxertuvlvkmaljntpxcjbvww
 * Smoking Wheels....  was here 2017 armfzhnlrxrukigqtcrjhhvlqamdlbiywrwyirrsjwbzuqvg
 * Smoking Wheels....  was here 2017 eznvldddaaoykllnxxmthvukrukqtgbregiugstrvqpqnvmr
 * Smoking Wheels....  was here 2017 kzdvmokgghxphrktibryawuywytqhccodbfckmlrzirbzpdj
 * Smoking Wheels....  was here 2017 vjnoyhtpcmlcowghilqmrjnfemltutsvigfrddscaeodheku
 * Smoking Wheels....  was here 2017 uaznbfxhnpgcadgjmfzdqovnvruyhnmaoecndesnjqtcqeas
 * Smoking Wheels....  was here 2017 xbdmdptrsvmprtzlrtqzovzmgbhjbygvymbyhfwwuoagpjcb
 * Smoking Wheels....  was here 2017 yxyoxwmkeurrvigiyrqiiyjafjqkqxzfvcmnuhwegwhjyxyd
 * Smoking Wheels....  was here 2017 bdkzgsogpfpuyqdyrxkrcvsdqqwuvkblucxzzorvyxwiscbj
 * Smoking Wheels....  was here 2017 orzihcqjybfqxvxmloowirxgtcfkpvbyrxhlnmllidghdmim
 * Smoking Wheels....  was here 2017 brhimeqdlqtcqednbaywpydybgekgssnodsditqwehdquxtm
 * Smoking Wheels....  was here 2017 jnddkmucnmtimgrsqysavhwcfxmfjxdcusnqphxejmodkkrp
 * Smoking Wheels....  was here 2017 pusyaqnezhyuywncnffxfttufbenqlqyysjsqjetewtqbjqh
 * Smoking Wheels....  was here 2017 cliilqllscicueavhycfdltjgzlgdssnwpdlejrfbafhaili
 * Smoking Wheels....  was here 2017 koqcdrpfyfcfbkslvnecfvamvdvncggosyyccaujrrsouddq
 * Smoking Wheels....  was here 2017 lonhrecedbviafkrdpqujrayqibudwhasqdgoggjcwfcdvcm
 * Smoking Wheels....  was here 2017 fccfavjdamgugjemqcvvtvkwqodtyrcdnwiqyhzolvzvdtui
 * Smoking Wheels....  was here 2017 casjhqdeolihlyicwcjauodqachgpyhlzzlixodofcmwamcy
 * Smoking Wheels....  was here 2017 smaoxtisyghtrhkaszckcijvilamiiqqepnqjudedknsjvbh
 * Smoking Wheels....  was here 2017 wwwvnqcirisjfyfyflfiptoieicxsofrkrablxsoduaaxxzo
 * Smoking Wheels....  was here 2017 qujmaaxwmognpuvwthaglwkfqwmdnuhuhhnlpcuamnhqrzjh
 * Smoking Wheels....  was here 2017 kexcovlkgvzxqwobwtdzbvvvvflcthmmsvxvkvofpcuuyrcd
 * Smoking Wheels....  was here 2017 sddkogpjhnclgmzymdmpbczvhxmasronryglvvkzfggxgtfe
 * Smoking Wheels....  was here 2017 kcwmqspizbcgvgwgpddkijizrtigxtqupnzxazblhbspkjao
 * Smoking Wheels....  was here 2017 qqgptzwccftuvygappmwcpnmzsamdoyqassyjnlxbslwjucv
 * Smoking Wheels....  was here 2017 rrrizycwobatbsnlbrewrznrkbsqkmbluwhqmxsaytvumqer
 * Smoking Wheels....  was here 2017 diskuveypufzouezwuakuznclhzwzbvyarvhivipsztvgrkb
 * Smoking Wheels....  was here 2017 vahzvcixsytsovbkamethgyrugopldhfaztlagzuhicrlabg
 * Smoking Wheels....  was here 2017 xjmfylzqpgliqpfrytanjumnkvknmttjkxqwzjpxxdefbzrt
 * Smoking Wheels....  was here 2017 rgstjuvhfugnnexafqekltbxnkvnfguzaxjpvoiqawlpldcg
 * Smoking Wheels....  was here 2017 tuojkiudtukehyuxqpmocqvnpkguxgesxnbynqrsjhrhbhis
 * Smoking Wheels....  was here 2017 xlxbuoavsslnekochgcegdgeipmsamzpmtcmemgjwlwysotk
 * Smoking Wheels....  was here 2017 htwekdafukcwtljooljwcdbzsbmakcnvgqbyfhbwuofllgxu
 * Smoking Wheels....  was here 2017 frvfkakkyvjztcnnajykaxchyzmoakjxdpwkgofvodhanxop
 * Smoking Wheels....  was here 2017 hhkzdletkglufsmlnkqurxptmxanfyindhqdfyedxzualkuv
 * Smoking Wheels....  was here 2017 iblnivmvqfxjlveccdqkytzeapwjlplsrpstgkqwvctdbuxs
 * Smoking Wheels....  was here 2017 lncdvwsojlmeyhplengsalyrpbxsnjashqsyudnlmsjihjms
 * Smoking Wheels....  was here 2017 zrtjvmqznycymebshqengflpjnnmnqpyvuovlpbjijesntio
 * Smoking Wheels....  was here 2017 nozasycnizcmcucjhxfxilpouocwqybeksiqdmpoduxtesmf
 * Smoking Wheels....  was here 2017 xprcdqjshdxbctpegynddwxlqylglekjjhkzatwdvbobdkgz
 * Smoking Wheels....  was here 2017 flzxaivlcbhayvobnqmuvlzivpnjshytgqkpmpvkrjjpibgg
 * Smoking Wheels....  was here 2017 tzfamxeusvgbmdhisdrpvjvoovpblsfvyeeoflpabgwndieu
 * Smoking Wheels....  was here 2017 fibfxoieisbcszjkrwzqtcotjeenzzcinnxebarutmsgzafp
 * Smoking Wheels....  was here 2017 iwinaundlfehxzpaljofnhrtxjzeuypghoxyfhsvsbakseox
 * Smoking Wheels....  was here 2017 ghffrhcptbicowafkpsvixwrdlasqqbtxlusbkqodgyzidwe
 * Smoking Wheels....  was here 2017 hkzxazvpfhodnuydcsdimezxiqozpkzjenmlgwrmnoaddmwc
 * Smoking Wheels....  was here 2017 bjjimbpmbecitbzhlarstnhaxmbgyvfvembnsienotagqbrt
 * Smoking Wheels....  was here 2017 kqenraqyuflxpfxllflhyrevosgwesvcgeykouxuewwzpwoh
 * Smoking Wheels....  was here 2017 jtnvonhtbeifndtoneupfoinijemcdclatrygktprcwhbhce
 * Smoking Wheels....  was here 2017 iqvtgnibvbuxhvvweajmbjskirccslphhofejpyolbmihxdf
 * Smoking Wheels....  was here 2017 wlrcdfrfjdzzastvidbxanlcdeluieekdiqjwdwogkmnvnqj
 * Smoking Wheels....  was here 2017 voyxxblvcxnoxghfaeyebvblkqzbkfvtywhcwyfrafwmlfav
 * Smoking Wheels....  was here 2017 hptmltestdbbnjmyqbkwiddobbtmvowohivdtgxhzswffitc
 * Smoking Wheels....  was here 2017 pmmjwglahwqdpbrhsvcufqsvksybnowizcdngkezplzvikrx
 * Smoking Wheels....  was here 2017 jhsirsgcyimtfrktczwyiwwuwbcyvvrtevhofflppeyujgxg
 * Smoking Wheels....  was here 2017 klkkkruodacbqvmaxbvprmcidyymgehwdjstupihxwusczqi
 * Smoking Wheels....  was here 2017 uppybtlfqtgljhzbmaijikcpeilloqbwnxzzkswjuvsooynq
 * Smoking Wheels....  was here 2017 xqrlsxxfjmwoeeeekybasvtwgmxruonfcuzfsbemsoglaqix
 * Smoking Wheels....  was here 2017 hqhrujdwnmhkdurtmgvomggvuxujfnnrasvtohrliudvzydc
 * Smoking Wheels....  was here 2017 vbgtzpiwqiycmsgpwpvinjbgnjvyjibfpmxeekcjrpijhyfm
 * Smoking Wheels....  was here 2017 pnuxdgwzkrqbuszrwuiwacwijwbcbcmckhvgxoiqxedzwxen
 * Smoking Wheels....  was here 2017 xweslhmitqhyuzdfbbaxirojqsrrgditimmalgpvnbawcluy
 * Smoking Wheels....  was here 2017 khbzhxbixkesnsirhttodmjyrkgxgzkxltztrdiugatjljds
 * Smoking Wheels....  was here 2017 xdisiownjnvmgpiuqmrcjhszhqlepmvpbxrbseerachgstnc
 * Smoking Wheels....  was here 2017 lbcfmzftvtzsnjfomecbcagnlmhebtvatefraodubmxixymo
 * Smoking Wheels....  was here 2017 lysawbxfgcpadehejzsgvwyzhfbvrbzqlwlrgthtvtcwinvu
 * Smoking Wheels....  was here 2017 myvyxbudvvykchdeefjrdgyxihfgszdfdrniglekbqpfmgqv
 * Smoking Wheels....  was here 2017 ikiagjcgblmyqhngzodryytfgnnxrjisgltefpkxsekbdggx
 * Smoking Wheels....  was here 2017 dzhnutgirradjankcxltkwzybxymjhwjhivankypzotijwdl
 * Smoking Wheels....  was here 2017 gpcarbxnpqooankwdjxtxepmzsuvuchqespxviyajjeekqef
 * Smoking Wheels....  was here 2017 fjjijpbdamgfpevbyjkqdjulkkmeghliygddbbxcojjavjlf
 * Smoking Wheels....  was here 2017 xqzlltvvmtrglmmupnzuzdysduuyhtjiyuxginlxmnkojeeq
 * Smoking Wheels....  was here 2017 kccqvgrlrgobajnalscrpkvibwtsrnjxumlbcxnuldlrbjyy
 * Smoking Wheels....  was here 2017 apansahbnyxhdufycbjdjkhrlxonjyzohtqnysijwraoenqy
 * Smoking Wheels....  was here 2017 khjwlgpahcxyvddcizpfynojsltltpbzofqawqhnkyxqglfo
 * Smoking Wheels....  was here 2017 iocsrluajgdcjabdidyehocgqebygiqexsvcxpcidybncgaa
 * Smoking Wheels....  was here 2017 ybgijghvodhfgebdiivpmjnkddlrsdajylumnurdexsfrfqv
 * Smoking Wheels....  was here 2017 orfgqqtouukzhsmgzuufyfuglqfoekubntkgkrfpbkkuiyws
 * Smoking Wheels....  was here 2017 tnqiwuephmrhnzvzdvtdinciadvtvstysiusjzdmldwtnhtr
 * Smoking Wheels....  was here 2017 kzjptfsnmrqheoybvcuqozwookashwyawzikqqczjecscgpw
 * Smoking Wheels....  was here 2017 osohdnufdezkvfwmloiftovzbmubiyrnoxqcpuckzsipaezw
 * Smoking Wheels....  was here 2017 ppnzgsctezujfbxlogysjlvzspltxgnyqmovwzhjthbpprri
 * Smoking Wheels....  was here 2017 ctxmkzonvigaklrmapoezbceagkxijgzeihykvctksbcjoug
 * Smoking Wheels....  was here 2017 wppviujdouwoqwxhxggwoeckqglaedzqoicyiifpyyhucwpx
 * Smoking Wheels....  was here 2017 asshxuzkcbkjmfrvockigrltpporeqzdirsqarpingaquzrt
 * Smoking Wheels....  was here 2017 xbplgzalkfveroijpgqkkudqbnzvievyjrxaeijnqdtsulvm
 * Smoking Wheels....  was here 2017 ctxavomqrllwgfjjucubsyipmogqziivszxlqyaaakfmobcc
 * Smoking Wheels....  was here 2017 kdmegxnojirqntrohhbqbwlnqmboqxostnzlqmfypakqwyvw
 * Smoking Wheels....  was here 2017 axmckvocfohwyzgylstrqmfmlglfaztxbkuvnfwrpgobukng
 * Smoking Wheels....  was here 2017 exgjmeijffhfjzksunnzuanxdfqogyovmbfozmetnqfxpzby
 * Smoking Wheels....  was here 2017 nhktvfrqnnyqucsjfbgofxoieudsnhtfcbjaxbobaybquoly
 * Smoking Wheels....  was here 2017 wkujejwpqashnxaqtzzsuvtrhurdkwjbfhqskwttcddxeezn
 * Smoking Wheels....  was here 2017 izpkjjicgljpaehnveeastuykggmrttpmyplycrdznrptdgc
 * Smoking Wheels....  was here 2017 fuenpcsfjuxfcbyfyulfhwrpujdqihkiskefcflvcoexvbcm
 * Smoking Wheels....  was here 2017 dbdkfuyiejnbuvlgzfpkhqmewsuvrafyzgmjwxorfcjhwtmo
 * Smoking Wheels....  was here 2017 ydiexxfzdquhkbrhbbuvntspizzlgvfkrkvlidrufbhjthvp
 * Smoking Wheels....  was here 2017 srwbpdzdykkikqqjlflbeeawfgsevsraiaxfxdtnjtdbkzqc
 * Smoking Wheels....  was here 2017 toeqjlyuqrkwporruwcxrcilrufxkaefvlpshgymerlnelru
 * Smoking Wheels....  was here 2017 swwsszzjirzvaeitxiqjqzxwgazuginsfiyhihsnhpxfolcq
 * Smoking Wheels....  was here 2017 kctifghmoyqjxbkgwhftzmbaouthymunwpjkedstrnptibdw
 * Smoking Wheels....  was here 2017 xuatuyixbgewwazfbpfqvooaqcobgogvjimxhawootrdnrjz
 * Smoking Wheels....  was here 2017 owznpzuvspnapejvblftqmifqepadvneoyevgjlmlsslkvpr
 * Smoking Wheels....  was here 2017 zmilboopugztevbpreceapnecokizxjhnbnmaxtkagkdniyz
 * Smoking Wheels....  was here 2017 zzwpuevutsagvozgakafxrpurztkfqwcppyjsoplfiuwrhqc
 * Smoking Wheels....  was here 2017 qatfsmcghskwdeculbhklqfdjmoxrbiwjrahtovzhfbpvzgm
 * Smoking Wheels....  was here 2017 injwzlzckicjwtsknhpnzsjpjhcujmhbrrriuiqosltlhapx
 * Smoking Wheels....  was here 2017 rohjagkshuioaqlpcltpgiduezxeonokqfzssomcdtqvpfui
 * Smoking Wheels....  was here 2017 kpkslkqrkprsxjccgeyzcdbnlgrnuzgxofiarfbqpdqlnqbz
 * Smoking Wheels....  was here 2017 sewfdnavmoveaurwijldretyfellwypubuiccmhohxafcqai
 * Smoking Wheels....  was here 2017 xgalipgilquqezoexezylpekqylyuteoyiwxpvimroigotld
 * Smoking Wheels....  was here 2017 nymeiwimocuajgflwyjjzvmmfcdcuyvwhmbtcyqhlwhbmvkk
 * Smoking Wheels....  was here 2017 mqdlwrjxgljmweomgistgqebqkikmiptndgfutxapuwfqxfh
 * Smoking Wheels....  was here 2017 vzcnuvvmhmfmfpoflgkqjxwgwxzlpbuldkcbanabiqisbjki
 * Smoking Wheels....  was here 2017 yvtahfkhofjpfpowaucutvnjeujfdjykbsmilqgacwfrztvf
 * Smoking Wheels....  was here 2017 jjrrtbarjwbwwmdyukqgayibzqywlwxjhrmiavytqienzwnz
 * Smoking Wheels....  was here 2017 yxunvuwgczujlubewqcjdvrdzeluzksifdmpvavjxzgyuvuu
 * Smoking Wheels....  was here 2017 uefxldixnhinnklnplypfoitelyroarnlidxilvfdbtvmyee
 * Smoking Wheels....  was here 2017 gzhisaerovpbukngnysurfdftqpkfbjjuohjdndwtdbjhunw
 * Smoking Wheels....  was here 2017 wnqobrgzlwyvibxuooiadijefjzefcorimbedzegnxazuexu
 * Smoking Wheels....  was here 2017 nddsdmvlrxublykxtvwmnojmfhulbyjklauzospliloiseog
 * Smoking Wheels....  was here 2017 hmybvfgvxsxcpybplttuzxxfunauoratrgemszktmzzjcdcr
 * Smoking Wheels....  was here 2017 nmjchuhidhgrqcebgkotymvtcgyftqegxpatiftvkbsegqiu
 * Smoking Wheels....  was here 2017 vfbqykufowdrnsiuzeejavkrqabwwjoofsmcgdbnujogrlhq
 * Smoking Wheels....  was here 2017 zcxtlmaeraahokimsrtxdozwdoccmsgsxlxbrqzypznfdshj
 * Smoking Wheels....  was here 2017 dsatruibemryhyfevwqzlriknxaritoypyylzynlceuarrxn
 * Smoking Wheels....  was here 2017 pbtcufmxbgbgmlhbxvkjikhrzidlmucseplgvnvqtkxupzxu
 * Smoking Wheels....  was here 2017 yetqfzjdmqleegdqtzzbmcdgbixpekptqbnvdaiiflpzjlle
 * Smoking Wheels....  was here 2017 bmwlooehychxpwopnynktogalrcnzldbjfoqaltsmiwhvdsy
 * Smoking Wheels....  was here 2017 apfsupihdkkuiepzmphxiribbjryqybvzeeowzybuiyoziim
 * Smoking Wheels....  was here 2017 dlfczcnfbotocgpzgbzjpriteqxtehxohihpkceaoxizbqcp
 * Smoking Wheels....  was here 2017 adkipfskxwoczjccrtmwfzjrfbhdwzlzjiybmlvlnwvarxcg
 * Smoking Wheels....  was here 2017 nbtlglbmdujogdwbwiwrchyrxjomhxucpbnmgzpkrfihofor
 * Smoking Wheels....  was here 2017 swhtwlzimdwkkjaucqnhjpsxfpslecgdnqsqdykiffetsvdi
 * Smoking Wheels....  was here 2017 yllvpefzxxchgevpavcolbqsjyazoxinamhottltpjvnlipz
 * Smoking Wheels....  was here 2017 uxvkvvpwpihcuvxymgknzdvrvzygswxbeflpbceonlabhpzo
 * Smoking Wheels....  was here 2017 cqhofxlnbyybiyznnppmxouqhmfrevzrhsogdyhvzktaarqj
 * Smoking Wheels....  was here 2017 zhzprabwznunihejmtbxifftskxxtxwqadejmnqzfpgiqxcu
 * Smoking Wheels....  was here 2017 stgajefzjbvfrauravkrrjyijaewkiejdwgxqfmopmbdmveq
 * Smoking Wheels....  was here 2017 zetqqpufjuiahkjxwfnuokhaqwpsltqrunwfpuglyvxwzhxw
 * Smoking Wheels....  was here 2017 oxhnfraemhucnasvfomoyboqirwxkzkmhzjumdotdrueaiqs
 * Smoking Wheels....  was here 2017 opbyzchskgxxvswkjsrnzhnhimzbbcsbfllmrmlulfxaoiyq
 * Smoking Wheels....  was here 2017 hejlbxiydtsccnexxwtmzgcjwofdlkdvkfxiwgzfibvowvok
 * Smoking Wheels....  was here 2017 jsxvwfafxamogvftrjnlslllljbgvlmpzzwpxfswmwhenrpy
 * Smoking Wheels....  was here 2017 qqmcbmpdcnqnpdsstwesaozkttfwsdvhgptvzgfwwsfohxjn
 * Smoking Wheels....  was here 2017 eogpnllomcziriusngbwanmitqtrylmevfeunonntvyqdwkp
 * Smoking Wheels....  was here 2017 ikowkbhpbtnrglubnrureotorivnluzrngypcqsmnuxoldny
 * Smoking Wheels....  was here 2017 sgarembpyslnkvefpmgedcctziapprdplhgnrdioygwtqnum
 * Smoking Wheels....  was here 2017 coobkdxesmhzibvwwinruvvsjkajwzavzhlbkazxzivwodnn
 * Smoking Wheels....  was here 2017 qxhiavhezvumpxtaqdargstoupwlbtysqhdarnqwvfawfggl
 * Smoking Wheels....  was here 2017 qfnafkwtuuysznhyozjazzsqncuuehlqhtfmdblbylywwmub
 * Smoking Wheels....  was here 2017 spyxicpehqapmfabkhjtqbypzmgomfjjahtssiwhbtkicpgh
 * Smoking Wheels....  was here 2017 rljcbjrcavmglmschsgdbpwhwlbdohsxeufhnhpsefhwptwk
 * Smoking Wheels....  was here 2017 qkyvhxnjqebeiglcnchtkqdteceferwljjcyzcnrkbymmffx
 * Smoking Wheels....  was here 2017 yjbqeruccquyynnftpdiehskdpvsiqimkmjtthwtitugypem
 * Smoking Wheels....  was here 2017 elhjdwlqroxoirnzvpsyxbuvennuhtxskrdzsnbupdqrprsc
 * Smoking Wheels....  was here 2017 dbozuxroujxdsffdtsbyoquwapbxqwrfrwtgbsuzeeljeoea
 * Smoking Wheels....  was here 2017 zvzwbnxuewncqarqywpugyjrrxjrbazcugvgdczphdlgrocs
 * Smoking Wheels....  was here 2017 zpxmbrvkubudyefsyfyhlfnohpsarohxrdgcqcuglnemlgiy
 */
import java.io.IOException;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.data.NoticedURL;
import net.yacy.crawler.retrieval.Request;
import net.yacy.kelondro.data.meta.URIMetadataNode;
import net.yacy.peers.Protocol;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class urls {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
prop.put("iam", sb.peers.mySeed().hash);
prop.put("response", "rejected - insufficient call parameters");
prop.put("channel_title", "");
prop.put("channel_description", "");
prop.put("channel_pubDate", "");
prop.put("item", "0");
        if ((post == null) || (env == null)) return prop;
        if (!Protocol.authentifyRequest(post, env)) return prop;
        if (post.get("call", "").equals("remotecrawl")) {
final NoticedURL.StackType stackType = NoticedURL.StackType.GLOBAL;
int maxCount = Math.min(100, post.getInt("count", 10));
final long maxTime = Math.min(20000, Math.max(1000, post.getInt("time", 10000)));
final long timeout = System.currentTimeMillis() + maxTime;
int c = 0;
Request entry;
DigestURL referrer;
while ((maxCount > 0) &&
(System.currentTimeMillis() < timeout) &&
(!sb.crawlQueues.noticeURL.isEmpty(stackType))) {
try {
entry = sb.crawlQueues.noticeURL.pop(stackType, false, sb.crawler, sb.robots);
} catch (final IOException e) {
break;
}
if (entry == null) break;
try {
referrer = sb.getURL(entry.referrerhash());
} catch (IOException e) {
referrer = null;
ConcurrentLog.logException(e);
}
if (sb.crawlQueues.delegatedURL != null) sb.crawlQueues.delegatedURL.put(ASCII.String(entry.url().hash()), entry.url());
prop.put("item_" + c + "_title", "");
prop.putXML("item_" + c + "_link", entry.url().toNormalform(true));
prop.putXML("item_" + c + "_referrer", (referrer == null) ? "" : referrer.toNormalform(true));
prop.putXML("item_" + c + "_description", entry.name());
prop.put("item_" + c + "_author", "");
prop.put("item_" + c + "_pubDate", GenericFormatter.SHORT_SECOND_FORMATTER.format(entry.appdate()));
prop.put("item_" + c + "_guid", entry.url().hash());
c++;
maxCount--;
}
prop.put("item", c);
prop.putXML("response", "ok");
}
        if (post.get("call", "").equals("urlhashlist")) {
final String urlhashes = post.get("hashes", "");
if (urlhashes.length() % 12 != 0) return prop;
final int count = urlhashes.length() / 12;
	int c = 0;
	URIMetadataNode entry;
DigestURL referrer;
for (int i = 0; i < count; i++) {
entry = sb.index.fulltext().getMetadata(ASCII.getBytes(urlhashes.substring(12 * i, 12 * (i + 1))));
if (entry == null) continue;
try {
referrer = sb.getURL(entry.referrerHash());
prop.put("item_" + c + "_title", entry.dc_title());
prop.putXML("item_" + c + "_link", entry.url().toNormalform(true));
prop.putXML("item_" + c + "_referrer", (referrer == null) ? "" : referrer.toNormalform(true));
prop.putXML("item_" + c + "_description", entry.dc_title());
prop.put("item_" + c + "_author", entry.dc_creator());
prop.put("item_" + c + "_pubDate", GenericFormatter.SHORT_SECOND_FORMATTER.format(entry.moddate()));
prop.put("item_" + c + "_guid", ASCII.String(entry.hash()));
c++;
} catch (IOException e) {
ConcurrentLog.logException(e);
}
}
prop.put("item", c);
prop.putXML("response", "ok");
}
return prop;
}
}
