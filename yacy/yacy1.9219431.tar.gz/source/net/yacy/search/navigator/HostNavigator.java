/** 
 * Smoking Wheels....  was here 2017 ydpamhcfvzzbmcgbhzixvbzcpvfdvwvpleqrbvovowlauinn
 * Smoking Wheels....  was here 2017 icjbrdmvgwglpkvrhpvbtncvbnvuifqmtvjtuwtpmymvixnr
 * Smoking Wheels....  was here 2017 xcqfongzezyihqxasmsircbxmjwnvspobishbvntzhirozot
 * Smoking Wheels....  was here 2017 jxexpijozhlertgfnrbljweojmbesmqfmvwcybkuvgvpdbuk
 * Smoking Wheels....  was here 2017 rnytpofwgwjvdxtqzlbgvdyfpgeuqayboxjlrcenenbwyvpk
 * Smoking Wheels....  was here 2017 agespoijvcpiippxmifyjmerhhkqmazyzixruuyvixkadgty
 * Smoking Wheels....  was here 2017 ynlzwxnttqfyenfvuzgymtawsobhkljyrbombezyxqovcmdi
 * Smoking Wheels....  was here 2017 cflxxlvbkkqgvqinwnfxyzrbncvmwlcmykovnpwlsbhknazd
 * Smoking Wheels....  was here 2017 lfdfnfoljmmarcujxeituntsnjoilnhceviulrkzvuuzhoqi
 * Smoking Wheels....  was here 2017 gwwusphmnhphjjwykmcqizcpuzibcjmrcerwjdqnrtkdpawx
 * Smoking Wheels....  was here 2017 yrauucvvwldjueydbdgabcrpsuogywgirjprbewjtatrtqog
 * Smoking Wheels....  was here 2017 fjkrhognvvkudlsbueuotaxawzwskiokdsidnzsyybsomvxa
 * Smoking Wheels....  was here 2017 czacybvtyqcjukdaxxzdmbgjbyclccqmzsimcgxzilkerhiz
 * Smoking Wheels....  was here 2017 ttcyuydzcebclmjquuhyltohjhktyywlwckbgtongdeamaoi
 * Smoking Wheels....  was here 2017 qfdlduazidkixivtfqmkgyxvfxdfdtzktynouozshesxgdmj
 * Smoking Wheels....  was here 2017 ndwymjlszjmokzgnckneqsoedxxoauvsxmxwtzrbhauwtehs
 * Smoking Wheels....  was here 2017 inheqvvlsbyqipnhrjsepkcwyspxhmsytfcfkqnijhqetulf
 * Smoking Wheels....  was here 2017 gqraolqphnrnhqvqkbmomoiouzimunyzayvzginmvwnjnypz
 * Smoking Wheels....  was here 2017 vynrputyvmupgtqkafqttaihzomxtvhyspcwccasgwdikurj
 * Smoking Wheels....  was here 2017 shnnhrelrtpiiyptmxdmfvkgcprwnqreyndtyioonsizawxz
 * Smoking Wheels....  was here 2017 xqsfiggikmvoxkrzzigoyjczzmtmtkgghekucoyssafrjusr
 * Smoking Wheels....  was here 2017 pgjtutncwcgispaszzmgddfdtvwajvlcjjtmbpgeerezmotp
 * Smoking Wheels....  was here 2017 gqxfzuumdfaxoecvgsnxibvtsokbnvzsfbbkqpteluvqwiya
 * Smoking Wheels....  was here 2017 oodbkfdkorovrcokrlkfjcfamuyipqtoaoqnvtbekvasdpnp
 * Smoking Wheels....  was here 2017 oabzubwetskxkpjvomkcfrzmxxjyhrzegizzxtyydjxneaxf
 * Smoking Wheels....  was here 2017 kiwvgrnfoqmfkdrrhjztehxuaoudlrclqevfljlkzhwodptx
 * Smoking Wheels....  was here 2017 pycvzpxhacxzqizuquwotuazfqqlgotlcbewesyvoumqmmzc
 * Smoking Wheels....  was here 2017 vrmjpscjmzauefwhnucethsgbglscnxpwhhxebyrqervudwi
 * Smoking Wheels....  was here 2017 cmadubkrplmlmyjoerxofbmckvdzpatklkplqagrjdnjzhtm
 * Smoking Wheels....  was here 2017 orybqyksdveyezpebxtvjsdgjzvmttrvnbxyejywcnjwfwis
 * Smoking Wheels....  was here 2017 ssuhkzwefwdqeaaaxglmtatrfoxvqskxbjfangikinxbxaph
 * Smoking Wheels....  was here 2017 gkgfpywbeivaqahdrsxcedrqptyuqawagosrsyyuamzashrw
 * Smoking Wheels....  was here 2017 etjobyrqplvxydkzoplqqijoiywjmeftpdzzaaqteasanhai
 * Smoking Wheels....  was here 2017 szkesixiinaitxmbbjoglesgnttxawxzvwrlzilieclqmbhs
 * Smoking Wheels....  was here 2017 grthypjwlhnoyyzgwuykcmtqmbzylaqvwtwrjyqqpuvqzsmk
 * Smoking Wheels....  was here 2017 pnhifqchinrftgosyxqsjkuyvaegcxipybupeewhgmsbsssa
 * Smoking Wheels....  was here 2017 qoxwinktnldamzftmzwchekrjagxrxeynhwjtpvxhvgfovlk
 * Smoking Wheels....  was here 2017 qbxyhnvuxluavqcaamdtekjofrgdbsorhgylparnasuqqyjr
 * Smoking Wheels....  was here 2017 bntqjhfdnctoswphffebmytpsxpokifygxymloriahzdkgke
 * Smoking Wheels....  was here 2017 psgkdopstiidgrltaeatbuxymvxxdxccqndkknjwdyqtmgsn
 * Smoking Wheels....  was here 2017 friyjmhvegfoxfpssqwrxjiehubgwxiswqbirlqvlhysupuo
 * Smoking Wheels....  was here 2017 cpgcaiwxphgvgyevsbfbhevygndxobjqrzktuflfifgqmggj
 * Smoking Wheels....  was here 2017 uboblsdsebpifoqwshwhscnhsvojhhybapegpvdfjwdiylcj
 * Smoking Wheels....  was here 2017 zvxhdlceelonzbrasguaadrkhwxmnuxfctqvbrhjjpntvomc
 * Smoking Wheels....  was here 2017 pvkkxpdpgougxogpygeefrwtvbbfxamvlxgplisildmgbjul
 * Smoking Wheels....  was here 2017 wkfjtnujevensomfvvpyngwdizdyhrcqswuaipleygljtuun
 * Smoking Wheels....  was here 2017 hbvixswicxuqfuvsdrutnsumgooewsmwwqhtmnuakeaxizjr
 * Smoking Wheels....  was here 2017 nnbrzcjjjqbepcaftwrfadxacywsbimtdlyrxmjltgbwmlrn
 * Smoking Wheels....  was here 2017 puwcsqstmdpwhuyczqphyvugsmzomyjazwfzwaxdzcrpaxfx
 * Smoking Wheels....  was here 2017 remodujzkwguygtyfmaerjgwgwabahnldpycyymcnqgpegqx
 * Smoking Wheels....  was here 2017 fekdnadtdkdglfypffqfroixzxjswiqdorbrxjknxakrirxx
 * Smoking Wheels....  was here 2017 zokikeebaqquxqfexundtniooupjlfqmlkvqsphyzpawdrdn
 * Smoking Wheels....  was here 2017 ximtojrdstjeuqkanmwvxowitxpzilsbgfsdsfwawzfmmyvp
 * Smoking Wheels....  was here 2017 fswjawhlzcgltuutovellgryswnymritsynqkaguwdiaokpg
 * Smoking Wheels....  was here 2017 jgahaiutyhixqrtfrpflxkwjtpstbwdqvofuodsmpdaisgmu
 * Smoking Wheels....  was here 2017 cttzemfaygadqizowtzmacsvleuekgbbtibmfvwnwjelqyow
 * Smoking Wheels....  was here 2017 idzcemwlpdxwexlcjpsmvquvraqhgghrzumxrslsunwqffii
 * Smoking Wheels....  was here 2017 isbobpjorhyevwhkppwoqrxbmujjlohifqimkpozslmlpzlh
 * Smoking Wheels....  was here 2017 naknekmbiidjpxykipgfyydogijzdcsclznwgompfgrselvc
 * Smoking Wheels....  was here 2017 qutkzugywfyyoydelnvbooumougxtdniwajzfxuzcjgkqbsi
 * Smoking Wheels....  was here 2017 qaewhtalxaytdgtbgrwalvjkfpweycwqyghzngiynlkwxnmw
 * Smoking Wheels....  was here 2017 szvwcqiagebuzgzrdowgyjtziijcprfykmciujckuilpbuwv
 * Smoking Wheels....  was here 2017 jfhosbzkahijaphwwynfpyyfhxcfxuegestqsjlqneamnatn
 * Smoking Wheels....  was here 2017 hlgiqubqogeajhjtjvwocrhjpmsifruznenwjpxcmialzsip
 * Smoking Wheels....  was here 2017 mrswryvwkegolncrxmdenwiwdjalfueswkwdaohmvnnwiobx
 * Smoking Wheels....  was here 2017 dfzcvuxpmnizxssgxlvhecxmahfwuutiyeoyfdrwxoygrnqo
 * Smoking Wheels....  was here 2017 rolejzbpuwqqropiblsgnfaencqecrgxtmqwrjijgpwkmtyw
 * Smoking Wheels....  was here 2017 xlynwhjutcmbwblbkmutkgaeixwdnpoulogwnpwotafjjsfm
 * Smoking Wheels....  was here 2017 sxlvbudmwjnaxkgscvgtvnlyecwutbyqnzzdxkbclmakfdvg
 * Smoking Wheels....  was here 2017 ifezavxbbbookzdypzqjaqcgfjrlrssgrmnbmpzatwtdfyng
 * Smoking Wheels....  was here 2017 fvrdyymijvuzionprtqaolccupsqlmrtxbwhyhyoehzguiew
 * Smoking Wheels....  was here 2017 doqtlzyfeopvuadugdikgyrqmvodlrrnkziuismdpdowntar
 * Smoking Wheels....  was here 2017 alblgbpaainxeqyxojylbnkkcodajqxdqtiryokndcrgjymp
 * Smoking Wheels....  was here 2017 brgfkkzdtpmfevambzxhhsddtjnobcwlidrliousczqzlugr
 * Smoking Wheels....  was here 2017 tuqeeryjnypcshxklsailjxtvechtaeokehrevzxbzbufofg
 * Smoking Wheels....  was here 2017 uozscrnqpigcwyfusqhhioaovbmbtpuwdcmiqslpwmwtgqpz
 * Smoking Wheels....  was here 2017 eaioymagpvaycaxzbxyazpazqmovtgxyyltowsbnqcedmtvs
 * Smoking Wheels....  was here 2017 bjwpsjzpjvvtazepydmtrbtujamystxrpyuvmtxqrshocwoo
 * Smoking Wheels....  was here 2017 zedatzgmzztuonkmdbqxxugyipnyrzocapptfvfepmxsmduv
 * Smoking Wheels....  was here 2017 pevfocwvuefowojsnqkclvvrchkqddsqksmgcgorguwsgbqd
 * Smoking Wheels....  was here 2017 xkzwwudxjouxjhxsifbgjnalopyasspwguxnlrvurghvjioj
 * Smoking Wheels....  was here 2017 cbvwulqeomiwrfgbcfbpylraubhkikqrhopzsxzohtnpywgq
 * Smoking Wheels....  was here 2017 rtxlnodjmqatrawolmfmrlwjcoujbdnclcogtyjepmgvjwqh
 * Smoking Wheels....  was here 2017 idwypzsmlwfaopjjkzlpinvscibqkceozpbioepcmuhoivxw
 * Smoking Wheels....  was here 2017 ziucwustbinotfswezawzbenpqahztuqhopikejdbhtbskmi
 * Smoking Wheels....  was here 2017 ynxuhiqqekujvhcpezlmwqrotfsqqutfdvxqutvfqxbxrobs
 * Smoking Wheels....  was here 2017 pfreddiwvsettmyleumvnbltwxpfqfvimjyzozgoutvwpmoj
 * Smoking Wheels....  was here 2017 rgxszcvkkdbfrvzndjcosjtknwfuhdxkolahsffrjgwzeqdy
 * Smoking Wheels....  was here 2017 eonapflnlwzqzmbdgzoqnyeynlmlgceauoormznhmzjphshh
 * Smoking Wheels....  was here 2017 hlubzvurwgyzixkzzeieeindbhnlmsbaxlkomcfjmwrecrrm
 * Smoking Wheels....  was here 2017 mkgaknpqsxyoptmvcsfrfjvyjisiczgnwflrkspexbjozsgx
 * Smoking Wheels....  was here 2017 mepfleyiitkxyaywmoeskdkocqqxncswxaawhbgdqxkuphdd
 * Smoking Wheels....  was here 2017 fvwlvtezhyzwvxrjjzkguyvncrefjnosmlojmuzatbvdwbua
 * Smoking Wheels....  was here 2017 yphnqrudlumkvvyyhonmqixokalnoxhwifvnlrvuplbeyayt
 * Smoking Wheels....  was here 2017 czjqcmrmxabxxnenwzeumfspkowkgfnkjiwbzvcrsdrreimo
 * Smoking Wheels....  was here 2017 ktugtyvzalcvexzedhjvbomxqmaqvrhtvcwwcnkfanpshmpd
 */
/**
* HostNavigator.java
* (C) 2016 by reger24; https://github.com/reger24
*
* This is a part of YaCy, a peer-to-peer based web search engine
*
* LICENSE
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.
* If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.navigator;
import java.util.Collection;
import java.util.Map;
import net.yacy.cora.sorting.ReversibleScoreMap;
import net.yacy.kelondro.data.meta.URIMetadataNode;
import net.yacy.search.query.QueryModifier;
import net.yacy.search.schema.CollectionSchema;
/**
* Navigator for (internet) host names, removing www. part of url and counting
* www.host.org and host.org as same url
*/
public class HostNavigator extends StringNavigator implements Navigator {
public HostNavigator(String title, CollectionSchema field) {
super(title, field);
}
@Override
public void incFacet(Map<String, ReversibleScoreMap<String>> facets) {
        if (field != null && facets != null && !facets.isEmpty()) {
ReversibleScoreMap<String> fcts = facets.get(field.getSolrFieldName());
if (fcts != null) {
for (String host : fcts) {
int hc = fcts.get(host);
if (hc == 0) {
continue;
}
if (host.startsWith("www.")) {
host = host.substring(4);
}
this.inc(host, hc);
}
}
}
}
@Override
public void incDoc(URIMetadataNode doc) {
        if (field != null) {
Object val = doc.getFieldValue(field.getSolrFieldName());
if (val != null) {
if (val instanceof Collection) {
Collection<?> ll = (Collection<?>) val;
for (Object obj : ll) {
	if(obj instanceof String) {
		String s = (String)obj;
		if (s.startsWith("www.")) {
			s = s.substring(4);
		}
		this.inc(s);
	}
}
} else {
String host = (String) val;
if (host.startsWith("www.")) {
host = host.substring(4);
}
this.inc(host);
}
}
}
}
@Override
public String getQueryModifier(final String key) {
return "site:" + key;
}
/**
* Checks the query modifier.sitehost string
*
* @param modifier
* @param name host name
* @return true if contained in modifier.sitehost
*/
@Override
public boolean modifieractive(QueryModifier modifier, String name) {
        if (modifier.sitehost != null) {
return modifier.sitehost.contains(name);
}
return false;
}
}
