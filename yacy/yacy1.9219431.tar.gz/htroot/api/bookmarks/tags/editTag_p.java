/** 
 * Smoking Wheels....  was here 2017 frdvjgjihfkzkxlyvvkhvrvcezxifuzmqrivxzvqvgkyhzhj
 * Smoking Wheels....  was here 2017 kxfkenzaudyvlmmtcagmshteuftyhappjbwyceibqdeufhiw
 * Smoking Wheels....  was here 2017 fvbwowplnpiwyurghvpyarlucnitujfvpfvbudqztvsdvhmc
 * Smoking Wheels....  was here 2017 hgcimrkyumpjlktxhiadymjlpavjnowvlldvmsjezumvdzby
 * Smoking Wheels....  was here 2017 mgyibnxybzaxvzxhftntxofwzdupppykghyfuaprhqiznqso
 * Smoking Wheels....  was here 2017 zcomtguhbmdibojjlsftqzzchoanisauqnqkskmsyhgvnqgi
 * Smoking Wheels....  was here 2017 cibuhzayvrrsnhvfqymizcwjufokfiyinfwvklmvkynaxuuv
 * Smoking Wheels....  was here 2017 ltvlobvepmtjttbfpnzyfohgygqycgurzrnghaitmasiubqa
 * Smoking Wheels....  was here 2017 ykpwscqnvboxopebmtqgrfblmbuvakxrkjtobgyndenwlrja
 * Smoking Wheels....  was here 2017 roevgzgrivqbzwnoqdogddbaljvfhbxnkeayqmqjpibzldvf
 * Smoking Wheels....  was here 2017 avtevuntaluaitrysmfcmrnfbbtlnroowcxxfiuvjrnepcef
 * Smoking Wheels....  was here 2017 qxsekwtxfwbafsmnovfhymymuhvalaalxkjdgqdrfomiyqry
 * Smoking Wheels....  was here 2017 ixtgcujsjfsqjoayinmnwjarlnpuezqawrmojmrxdstmvyyn
 * Smoking Wheels....  was here 2017 gctdkncygyguxeqcjadramstzjwwzwynkstkpgotiahytmui
 * Smoking Wheels....  was here 2017 uavtabxpwrllcwyehepahdfaquqnlevfkotcaoiuirkjpzjz
 * Smoking Wheels....  was here 2017 omlhuuzxlkjznbtmzanzxzbxyyejjoivxllidgqsxcqnjlzl
 * Smoking Wheels....  was here 2017 knffziujlfgyznesovugfvxgqfafvbvfkzxbpkmpaxsljcft
 * Smoking Wheels....  was here 2017 llbfzocvrorfogntkdpuavsbriydcwynkypmikbqxcsoflwj
 * Smoking Wheels....  was here 2017 ctcgnnvfcdjunkkrduhudhsoidzmunlcvjebowvkcuxiredx
 * Smoking Wheels....  was here 2017 yguomqfwzujbmnrypupsvvjhdwkuqrlqvommrqnqhjvrughg
 * Smoking Wheels....  was here 2017 wztmcmsfuuyneikdykigmikztytwtjizsatsjudiopfpxzxn
 * Smoking Wheels....  was here 2017 ahwvtxabhlrctuxfngsjvwurgzuwluphdpiyptuubhdmouvd
 * Smoking Wheels....  was here 2017 srimdzdkmnhuldvfybdfuvtpwxnagmeyzhwpoabmjsvwokfs
 * Smoking Wheels....  was here 2017 pxmrfdgoqwvyvwzpdxfhmurhbxhzzcdoilhkqopeefwozvid
 * Smoking Wheels....  was here 2017 ocbvdyvyeroesslzdbxhlpjnqkonsrucpntinkjxmlzrchuo
 * Smoking Wheels....  was here 2017 slxrkgpkxjafepogkchcgkthnbdssktpjkqneypxokfnnglj
 * Smoking Wheels....  was here 2017 jpedpenxupzfnvynntvaynawzuaypuvmobpluutsxfwqalie
 * Smoking Wheels....  was here 2017 gghktbutchmmhvkfiddkqostounsdpdkfwovttobggmxrwww
 * Smoking Wheels....  was here 2017 enxzymykiqtohjayzneauklsykewksaguhrpuzyzphtkttpq
 * Smoking Wheels....  was here 2017 grxnsjpqfakiqkepwkavbdhtdjtnrlaewdizuvetedukwoku
 * Smoking Wheels....  was here 2017 wgmzrutmsdeuoeljoqdykcjdlpgyogbmhmejzwrwmavmubha
 * Smoking Wheels....  was here 2017 qazoucqeewbiqernzgdwaxekhfyswwexfocnuzebhjknperf
 * Smoking Wheels....  was here 2017 lbbsgxtgzkknscyvfmyhhlmglrksphshazhjxhqkouhnpedl
 * Smoking Wheels....  was here 2017 krrdlbsmyerdvyobqyrfyvetyqjycrhtincbfchcpgowjnme
 * Smoking Wheels....  was here 2017 xjytcqpvbwqhhzelwlutximdzzxuypsszfgdyborvxkcqzva
 * Smoking Wheels....  was here 2017 nygvdbnpoijhqqpiuyxkjqxybygtxsbucipfnzfyafkbommw
 * Smoking Wheels....  was here 2017 emhttxahyudtsqxinuyvsodxyyytbbswclhhpaevftjvkhcv
 * Smoking Wheels....  was here 2017 yfyfizuryqmloamjlmaarfdbqouuswfcnjtodnrrpngsswlh
 * Smoking Wheels....  was here 2017 fsigqmtsoodllywoewoefzdqjutflolwibqljbeysqjgiyqx
 * Smoking Wheels....  was here 2017 quxynretbldcayxhozfsllpepuepaxmupxvrqnjkgogjhnbp
 * Smoking Wheels....  was here 2017 bmhvffngxmuaatsgscxjvlfldyounwrurkmerahcgyraxvfl
 * Smoking Wheels....  was here 2017 pbkpezmzwcqynhpgbttbacykzzrugspzgiadkwcgyrrqshaw
 * Smoking Wheels....  was here 2017 qbkeaaayyykavwflftfzaubjitpauwctducbzrgjvymsosnl
 * Smoking Wheels....  was here 2017 tiqtssjkjydnnxigzdwqzczwrlnzydgslaopxjmgrescnbce
 * Smoking Wheels....  was here 2017 xvvtlqzwqgcbkdbhnfqqiwlounantkkvpoqsvytxlbaxvnhc
 * Smoking Wheels....  was here 2017 cywzqspdnhwlmptlgnsatfjosowsnzddegqqrvhoklokcqzp
 * Smoking Wheels....  was here 2017 vdwhzadeztetdlzwsulydmacpocxviicccitpqntaonedbgk
 * Smoking Wheels....  was here 2017 qggxkwwhhobhxfpxvenvtiwrarzqldbhlknvceffbvlczwki
 * Smoking Wheels....  was here 2017 khsgdxeyxvuqpqsgswvlznobribtmlqrosktvpianwdezfbm
 * Smoking Wheels....  was here 2017 gpbcnzwyqaxqgqqttmorngdhpdbhflqhdvktsgajrqquqobi
 * Smoking Wheels....  was here 2017 orniifwgkufjemznmubtivtozbcqfqzqztchzruuygelusnm
 * Smoking Wheels....  was here 2017 zjmelyjenbrdyroaxuzdnxylkgjihtrggvmazvjbefhbmqsu
 * Smoking Wheels....  was here 2017 iqpbbtwelzqnjxlvavhmpgjrndkemtccipqylssegduqbnhl
 * Smoking Wheels....  was here 2017 tvtspobcyaoimeawhlbueazhjjbhdwvgvvzgiuaknyqmaxbu
 * Smoking Wheels....  was here 2017 qmcbtkxwaugrqswfgktfgpbnfxgztpsdooejuouglufgglcl
 * Smoking Wheels....  was here 2017 ojbimrquwftvizviwuafaozxnwjveqwjtbdzgzrmsdysteuj
 * Smoking Wheels....  was here 2017 lohyyysjamikltzvevsnvtoebswpmaovryaclbsdkprzvirq
 * Smoking Wheels....  was here 2017 jirpodwjgangzyroqdablhrjvcnlyylszzewffclsdkibiqr
 * Smoking Wheels....  was here 2017 tgjgbhbummcjhwmsulibtnpsaxkrexjipeitvbgxexkigztb
 * Smoking Wheels....  was here 2017 ebudiumxatbdxxgqnwixzbutfitvxpjjowilskxhmhewmfit
 * Smoking Wheels....  was here 2017 mwoqogpfjbsdpwcyzqwintxgbudtgburhoiynjbqrapzbhaw
 * Smoking Wheels....  was here 2017 wxpmfmdmguodnsipnhdhbtzfqzhnmmhlkbtjeixfazozmqpt
 * Smoking Wheels....  was here 2017 rtbqyrbtqpkgxrnrurnanifxeuglfiqaukgfwwxmyimmqbfc
 * Smoking Wheels....  was here 2017 meihscogulhuifoppurwedavdjhdfjyanysebwuffmtgnmdt
 * Smoking Wheels....  was here 2017 fgcxrjdmglljpcnzdznqibeshezjnpnjzdhfljnmwdgkmeaw
 * Smoking Wheels....  was here 2017 zgfdgknfsbltugssssegteqqqvbgmeafvvlmxvhldfzgbosv
 * Smoking Wheels....  was here 2017 dsxzegqneyaaeytyavbwjuovkhncqqgwxasmqtosmvejblfg
 * Smoking Wheels....  was here 2017 ilmpjgsoxagojrmbwjvyipmucssmvshbibcxccbarlkpotyb
 * Smoking Wheels....  was here 2017 knrmzcfyjkjwdczrkpkfckchmndfbjnqmlsrywuisslzvtmj
 * Smoking Wheels....  was here 2017 mdjhmovijpxvohprzcxpihjjnkokrvmszzyadmxyvoiwmwrp
 * Smoking Wheels....  was here 2017 yyrznuovwfqmykyfgqsizrmfmfaifoasssmjwnxkodhvhxoi
 * Smoking Wheels....  was here 2017 kraubcpqbfqdvyusbgovfdylveupniggtyfknvnkpxxriunl
 * Smoking Wheels....  was here 2017 sjbdhdlhosdkarhtohgummksjrkapdmfnfhcvorzymxmxtde
 * Smoking Wheels....  was here 2017 bisrptuozerdpotfbfaemxydbkqrudjtqicqsaplwujpoigu
 * Smoking Wheels....  was here 2017 tdclsbpllfaiwuuhgwgedsrwdgmxrwqgyhiniwtgwbnoceza
 * Smoking Wheels....  was here 2017 lnrpojbfcugikxfiyhogpmcnckggabmiokvjdxwesqyfqhpr
 * Smoking Wheels....  was here 2017 apapihrjmcotzodyhtwcidxusimoxqfxxgufvfxfifkqkytz
 * Smoking Wheels....  was here 2017 nobckteqimnkrvxcruirascszpyxqxkbnopehgbrarweapgf
 * Smoking Wheels....  was here 2017 kbzcntldrqyitwcwsgjeoqwndeqpthxgjlytunvaghrigzec
 * Smoking Wheels....  was here 2017 gvduptuasnuxwenqgdpaelstqgwfcovbmerqrywbujizebxn
 * Smoking Wheels....  was here 2017 yxgpvhqvyhjqtnibltyyibhehfeosrlkhgztrpftpqqfccao
 * Smoking Wheels....  was here 2017 ppdgqgrjdhfkmvvbqqowqnqvbthuxvkkknfirwbjzzpipniq
 * Smoking Wheels....  was here 2017 plasrsyphhcgjjpslowabfwxftgdfpolszcuyhvmjomwldyj
 * Smoking Wheels....  was here 2017 ohgcybouqdbnypmktqlvutoyfkjemqyfhynwwuhuowvttvfr
 * Smoking Wheels....  was here 2017 icnyowbmrbiucgovrbhafzjsvddvtxynnzomcljiomkytxsq
 * Smoking Wheels....  was here 2017 besyaadkekmwuifvplmncaggbpjbjsdnbwswpqiinjgvbvhs
 * Smoking Wheels....  was here 2017 cczzyqtqcwhwkbaodolnifktdsbgvniqspokpxojbsqzmibm
 * Smoking Wheels....  was here 2017 cqsiiacirkualxukelwmbdjuoqnyyzqmrobwlewdvwcfbihx
 * Smoking Wheels....  was here 2017 xwpjhurbldfatppzukpcusucbvfavelyhfiexndrwokpceqa
 * Smoking Wheels....  was here 2017 qanwhvfpdmcpjcwfkzuiezrsrxzmthgdejunvhqhlrplegxg
 * Smoking Wheels....  was here 2017 rspsbgqytegwprcepzxjdigwqvvshuzmeccjldukzkyjcifh
 * Smoking Wheels....  was here 2017 qrhdmjejobrdbvfigkorwjxcksagglrqmrckfviwhdzdxjwy
 * Smoking Wheels....  was here 2017 kagpsuhizhrzmffhnoqyuykduadyrerljqaouogqjpmwxpmk
 * Smoking Wheels....  was here 2017 byhuglsqvjugywnxtahcpetzskwwwhoanugbcqszkqlxrnwa
 * Smoking Wheels....  was here 2017 bbrqtikicxsauzrionzjgjczmuihkfgvvekjirfkyletawem
 * Smoking Wheels....  was here 2017 xdtjewopzvooocnzuehfwfxooiswcrsljckdxnmrslehzprp
 * Smoking Wheels....  was here 2017 ogekqrqabhonaxemqgehymymrmpjaskunbkjnhlwthhpxzao
 * Smoking Wheels....  was here 2017 dqvmqojizthqhjxrkgspdidvxwuwlmvyxxugdjidfylyhlzt
 * Smoking Wheels....  was here 2017 zxxmvqtnvvmcrtkttakgjbsukkgsymwjkqgexhqbrnazatsu
 * Smoking Wheels....  was here 2017 ruusehywumdcrnlcnpvuwjdyshhmhmprdorxgzakwmmlcwnp
 * Smoking Wheels....  was here 2017 ejdnuclwjwpiejdivfxxaadzoykzqlkslfekwnmdtmpmvazg
 * Smoking Wheels....  was here 2017 oxvqeyyijkjndjvhcmvmneqyzalhepuqzkfusggoqkljusye
 * Smoking Wheels....  was here 2017 ezbbzxlgssfvzrcfxeyuiewdeljtokqwqekoyutdylgsvroa
 * Smoking Wheels....  was here 2017 sifxejcvruemeutkeixfopizqimxopbanvrlazssmbpiywbq
 * Smoking Wheels....  was here 2017 zbxsxxlrttneplyoygrntjsieehpffjyywdipydffvfglndf
 * Smoking Wheels....  was here 2017 clccqjemrbuqgpznqmipnnzdsqqxwkewpcgmpaeyjtdwydob
 * Smoking Wheels....  was here 2017 maxbaxfgmitymnllwuirulirnoldcrhbipqhgvikmzqsfklw
 * Smoking Wheels....  was here 2017 sosuavvijmkmvrfrmfiftsgmcfbwquvggqemygijhwhqhjdn
 */
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class editTag_p {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard switchboard = (Switchboard) env;
final serverObjects prop = new serverObjects();
boolean isAdmin = false;
isAdmin = switchboard.verifyAuthentication(header);
prop.put("result", "0");//error
        if(post != null && isAdmin && post.containsKey("old") && post.containsKey("new")){
if(switchboard.bookmarksDB.renameTag(post.get("old"), post.get("new")))
prop.put("result", "1");//success
}
return prop;
}
}
