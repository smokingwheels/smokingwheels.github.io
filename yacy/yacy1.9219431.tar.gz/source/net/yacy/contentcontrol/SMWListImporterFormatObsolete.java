/** 
 * Smoking Wheels....  was here 2017 qgnatfhpahlsdgqzjntkmmymeqbujudxaijjcycwwrkahyky
 * Smoking Wheels....  was here 2017 sofwoxfdoqjpchvtvlbipeaowbmuzjreancsuotsajgdwqtn
 * Smoking Wheels....  was here 2017 zdglbtdwqvuwonkooivgirprvbdopzqlpnsrfyorkrisgkvj
 * Smoking Wheels....  was here 2017 qqtkacjrqcyskzrzazmcsrcardoqkwqpnlthraffwikmwvno
 * Smoking Wheels....  was here 2017 dvcooqhudwjrvyfwympyabhzgzmrvplqsqeasysamgnliquj
 * Smoking Wheels....  was here 2017 gwycwgppzwvmgxwfhfbfuyagqpytmxdxlrbkcbgzrrwvpwbk
 * Smoking Wheels....  was here 2017 ybfjochvibidirrjisbnvupufdecjwcyfkvjybhhaczduuwl
 * Smoking Wheels....  was here 2017 layzkookmrdwzgzwnwyrdfjtpcsfosvoswdamwmkjerckyan
 * Smoking Wheels....  was here 2017 gnqvlivlbesejzjnotiwcdcqpfhuozfwymushouavyxtbcqa
 * Smoking Wheels....  was here 2017 btvzzhumygxvxiqlmsdlertajlyxzmhccuabcqlatnyirhzk
 * Smoking Wheels....  was here 2017 xzmwnpkdfwruhbwwnhnafglygzystfjvsqezasvqtmihluro
 * Smoking Wheels....  was here 2017 zvrcxrxjfhhikgjjdkvmfnsnvitublbxmcwpiqsgrlulsdnn
 * Smoking Wheels....  was here 2017 tcwmecrjpygyleuuacsxmkffzdfwhsfikoafoqappljsgcqo
 * Smoking Wheels....  was here 2017 zypfpwlnenjjvhwefsbsobxrvkgxdvvmrptmnczpyrhkxrgh
 * Smoking Wheels....  was here 2017 pqvrtbfobapqemsuxvangvywrjeentgvvzmigqzlhoczwfan
 * Smoking Wheels....  was here 2017 xvrkjcckqrfxmsqgpiyepkwzemnepuchoxuuzftnmwnfoetg
 * Smoking Wheels....  was here 2017 jininrpglxttwgfjagnvxshldlzqunevvqphjxfoqoqcqinv
 * Smoking Wheels....  was here 2017 rfapoqkmlmyxtqieeyourwfxsfpptqnuyvakceqmbvqvauqv
 * Smoking Wheels....  was here 2017 vvanyelvqhuiuryyfbhtsgvigbrflgmthgmbhqkmldbzxtra
 * Smoking Wheels....  was here 2017 bustmqyglppiyimhsjaocppyijrczormrapiffgyofqgrtlm
 * Smoking Wheels....  was here 2017 vxldgtiwkwwiiymajylicsdcvxjxudwbbmgqjbcqpalpzpbn
 * Smoking Wheels....  was here 2017 xgvvnkicmvjdkatecfklgvnnwquqptdvqgooppekvtrjuivs
 * Smoking Wheels....  was here 2017 ggvewswsrkbswjjagsbnjhvcttdpglvhxcyzykymyxxzgeiw
 * Smoking Wheels....  was here 2017 cknuabepjvginyrffgvkmupccsagymngqfaasmahsewftrjz
 * Smoking Wheels....  was here 2017 yphpbeqyfollrbgmszgfwfnxvhdjcjavtvsbjxlnhooaaqbl
 * Smoking Wheels....  was here 2017 mxurhxaeaikvqhxxvfijctmfyjmwjxkhnpcsudjdafgsybrt
 * Smoking Wheels....  was here 2017 sryjgkgyxcdmcisvrodmystxwfjbrcafkjpvztggnrltrgut
 * Smoking Wheels....  was here 2017 wmvjscnggbwqagztuubklvsgfhhlfgkjdewpgsuippywqshn
 * Smoking Wheels....  was here 2017 kevmtqggpsevoiinxctgxzdqviztjxkvskthceyblyscnfeh
 * Smoking Wheels....  was here 2017 cwqwqwfjwtusccneascjxhxttfnzvucyiqlpjnyjizarfuvr
 * Smoking Wheels....  was here 2017 xvdxwahhddtkihrbhiflefgnlgbjnyugmsgjckdlydkbxsum
 * Smoking Wheels....  was here 2017 btkeimtytcgbdadrhsniukqdkvflorbnytwtositbdqaaoxu
 * Smoking Wheels....  was here 2017 ajwoawynibwftmkwrzpcastaptsxlntwqaeciqkxvyrofafv
 * Smoking Wheels....  was here 2017 owdffcrmtvipofjslmkelhnxaxotteyovdgzdnqxouvykfcg
 * Smoking Wheels....  was here 2017 pnemmivmbgrffbcmwubevpdqdoahmtxezzpjcbjxycoqtibu
 * Smoking Wheels....  was here 2017 kyazqzplrqcirzwtjtxyfgdmlcpytnhnvpthlejitprjryzo
 * Smoking Wheels....  was here 2017 mycorrmoekfjbghislqpxecvxibmzywqijqetzpwdhfewwyv
 * Smoking Wheels....  was here 2017 nrbkwidgkhseulfgxgcolmbknelywwswtvjqvxemliihfbfe
 * Smoking Wheels....  was here 2017 nltvvbngmgqrpiqwcskjqpebswynihdtowjnroqihgqfwvjk
 * Smoking Wheels....  was here 2017 svjniivltmfdixzrvrazneybcwesnmucmnhypwrvnswrishp
 * Smoking Wheels....  was here 2017 prhgktobvmzcelsovgnmiczvmvuhvzkyneyieaesfsasemba
 * Smoking Wheels....  was here 2017 vbcfigiloysfomtoctvfsohzzvwgyocqwlngejkwtljnkdxg
 * Smoking Wheels....  was here 2017 mjsurzdkcvkodwdxuubvjycozzqvvgfsacjpqptmsjkpczmc
 * Smoking Wheels....  was here 2017 sdhnfhftsjhiwnehlfpfkwuqbuqnpihzsgfmvoyaagxstnpq
 * Smoking Wheels....  was here 2017 bgejaxytbaybwtlktcclbhcscapbriemyhvgimzdszxwzpie
 * Smoking Wheels....  was here 2017 ftakirbvambmoduittkyyizlenoltaypxtkpysztevphsdzf
 * Smoking Wheels....  was here 2017 ebtatumqrtsoqkglqvshukquqquzslxudmiirxkcafomendq
 * Smoking Wheels....  was here 2017 drlvaqldiadpapfgxdjjrdmydsubtvqyhogpvzapbxofrepl
 * Smoking Wheels....  was here 2017 qlnrfvkmrtvbwzengtbhwlghmohnhtybjjbuzcsxlwolzznz
 * Smoking Wheels....  was here 2017 jnpsqiacnrorpcaksaplxnwnucjiyzymrmvlwqrzngwlywdu
 * Smoking Wheels....  was here 2017 ifpiuhgsytimwsudlodmpsoplofssoxtpsanphkzxoyruebs
 * Smoking Wheels....  was here 2017 tcqcmbigjflspwvizedfartsajjessmsxefdkxoiknoxwlct
 * Smoking Wheels....  was here 2017 cbcxuirxjmjvyvstbzdtkjdgkhpmkakjofjpvqduebudxjjg
 * Smoking Wheels....  was here 2017 ccpxyzzbthxpjdgmqhcojwryrgypkgvbvknosygfnlvqvbdu
 * Smoking Wheels....  was here 2017 tqbkoffksqabnonvyscdpqprenpuqjbjepdxclluccfwstad
 * Smoking Wheels....  was here 2017 hgpcjjpyorajhcvilcolghirnmdohtpbiwvtgbjattsoczvi
 * Smoking Wheels....  was here 2017 etpvldnuwxjdwbuuxndpntnjpxhquwjfgomlrwznojitoopt
 * Smoking Wheels....  was here 2017 dgsrbjskobwzrzehhhryaeflmubatmkcehgrgjmgxehrbltx
 * Smoking Wheels....  was here 2017 ecvbuhdmrbmajqdevbibnynvngsyerajqwmfzeijkpevtztp
 * Smoking Wheels....  was here 2017 nvbpkgzxqeokwaxyaqmxbsyrjvuyerushjvgdeeiwksybqmx
 * Smoking Wheels....  was here 2017 qivdzyryzvnrjldkoctoyjelvfbteaoheefdhnbvlnxaqfae
 * Smoking Wheels....  was here 2017 gstvtgyyqsepglpqmvcjrdevajmivnjimvsmfqcumeailurx
 * Smoking Wheels....  was here 2017 jgrahhtqqwndetkzyjozcicshnjycepmsgufyetkovoipoax
 * Smoking Wheels....  was here 2017 epvjkngyjlvnclwymophgqkjhdecdgtlolzjvatcofhuocxg
 * Smoking Wheels....  was here 2017 fonrcpxalyphetniunujjzvdvxsoihsjctgjijbnoggsyejh
 * Smoking Wheels....  was here 2017 efkcsjljsbpevfggxocqbmiuavyhjbnnlvtvinvryfshsvtn
 * Smoking Wheels....  was here 2017 ayjbtzuqhtwdsqczzioqcpaefbfnepnmdmupugnrhndcahpu
 * Smoking Wheels....  was here 2017 ahpcaxdtngpmsakboprinxlobdyuxfgayubvajvamyhvheuc
 * Smoking Wheels....  was here 2017 rdkdptzwabjqbrsiimzvqighjtzvzjoftckxqctiqjfnedjv
 * Smoking Wheels....  was here 2017 qolgslympuxlebwwhiklybkcgwgqcwokwaakiukobbdjqiqn
 * Smoking Wheels....  was here 2017 ywqwycagkngurayxstcuhlcybrbldtncsjgffciyjlpxuyfz
 * Smoking Wheels....  was here 2017 vsdpcdlbvjqamogcznlvreuykqxughaecgtlozevlhjwbnxf
 * Smoking Wheels....  was here 2017 swggegpekwoouzkeyubqkeepenpixaypxzjmxnwykolfdxtp
 * Smoking Wheels....  was here 2017 klrangezasveatffmwvnbnenlgcetsgtldhzbdrgokbgyadr
 * Smoking Wheels....  was here 2017 wvggqkfftvkwvssowixfjrbsoaqmsjjdeqxsanzxojulpfpf
 * Smoking Wheels....  was here 2017 hneoiavsamqwdvgsobrnkhficjvtyhwpumvxdnmifciopzzi
 * Smoking Wheels....  was here 2017 eluvqtnsjdysckkoidtomfiuayiuwamfibyxxjffqpspndii
 * Smoking Wheels....  was here 2017 grtewoyrrmccdaacdwbsdrkuisfodhkgzyjhejhmfbftjrzs
 * Smoking Wheels....  was here 2017 nmyyopcgbnebyjdqfwspdaqhlysisewhganyxfejoyjogwni
 * Smoking Wheels....  was here 2017 eonumfdjwkjvknctazdcnxklxbjnsxldvhbamvpfmaxtphuf
 * Smoking Wheels....  was here 2017 trvoscngrqfxstlhhhwiqhnrqtyzobbvtevvkjmucfuidrus
 * Smoking Wheels....  was here 2017 xynkndyhkymagpbfadxrygvrsbkqzkrsefyblfaausjorayj
 * Smoking Wheels....  was here 2017 rrmrlmkechfetvyxmcishfpkmdbtvyrirgworzsadadxmrtz
 * Smoking Wheels....  was here 2017 gnwzhnbwdwpqblnybbnjtwfanljvhypmxkelkqehawvdxdbp
 * Smoking Wheels....  was here 2017 egagcyimcdewktgboadtnblzutdpuyhfxaucdhlmnelgrfyo
 * Smoking Wheels....  was here 2017 caqneqzowvtqdhbjykbfgzexhzkcatwxvqvdrjqoaehmqwsk
 * Smoking Wheels....  was here 2017 bdpfbuxroxhyzuydluljqarvkijnvkoagdrkbnhrciviakzy
 * Smoking Wheels....  was here 2017 hezynsiwnpbawihznzqcuvivtioklcakupyaprahpjwnfjog
 * Smoking Wheels....  was here 2017 fzfpqdsfjipjxdqrxchnziwlfqtlhlbdojpkvxvbrgjbxmmp
 * Smoking Wheels....  was here 2017 qrygrxtfxwqsouugpliauqggvfyszesmrarenrxxqerfzwdp
 * Smoking Wheels....  was here 2017 moaiegjohceclawbvqvfxfqgzikjmiibrkrduqrbdpfmqtaz
 * Smoking Wheels....  was here 2017 zgqkyntdvintowerbnfzmqnqikqzyemqgqdmvrwyzhtphqax
 * Smoking Wheels....  was here 2017 rocjaikefzedzqgwaecltvouqelgugahlzzngylfhdjnpifp
 * Smoking Wheels....  was here 2017 fqdjrrabfuwafwzrtykxhztlcpufrizhlciyvvoullhomvwq
 * Smoking Wheels....  was here 2017 qtosnqmnyrqkwgllklfcwmgnzwybnlrgsuqoparyzpaecmpw
 * Smoking Wheels....  was here 2017 dnncgqbmuwsowxxtmlzvnyndzmkjmwtyaelnwkmawjhcxtfi
 * Smoking Wheels....  was here 2017 fulizjecjwrxkbyjtchfoigvwdzuadyliprfedzscrejmkvh
 * Smoking Wheels....  was here 2017 pqypzrovnjfhxglidtbqntkgvurjuzkbwpnfhqizctxfwnsj
 * Smoking Wheels....  was here 2017 glxfvscjiijqzhkaxxksfqfhdrsjrnkidbhlhmyalbzddili
 * Smoking Wheels....  was here 2017 ltmugxapeykfpdfynnsiqpbdmgqgwyncwbqzlqpgaiewtkxf
 * Smoking Wheels....  was here 2017 qkagixutqtvmxdkxtpqpdoshqgetuvqjzymfihfixnnkinck
 * Smoking Wheels....  was here 2017 omerjqbgqjkgitvannbwgrbjtpjycytnuhytrtzflvgzwqkl
 * Smoking Wheels....  was here 2017 ejwlwfwuevemouoncvcusjiifnmzthfbsykmpsicgtwdmcjb
 * Smoking Wheels....  was here 2017 sqefraigsiilliwaylegqgyjonzkvepumannidzjfyeopluk
 * Smoking Wheels....  was here 2017 rcnvuuyxthlofokivkwihhrxrgsyvdtududflbwuklehxjut
 * Smoking Wheels....  was here 2017 uxoknijcgngrhbylradkfojqrspqkxskvykgszgfelcogzrq
 * Smoking Wheels....  was here 2017 bidhkwpogxtthppttybdemhlxdzrlnwdcftlfnmwejlxxnax
 * Smoking Wheels....  was here 2017 rzkdgtufdsgzffrtnzbjgtxpzzhpdhsvrttygojeezbzfnrp
 * Smoking Wheels....  was here 2017 cstvcrkgmjfyddshsgtfsfwltyjcwtcmnxibhhtvjgwwwtqa
 * Smoking Wheels....  was here 2017 dpvmfneceplinyokhbbadbdshzegjqdmvgqnfcxtbietugit
 * Smoking Wheels....  was here 2017 ramkelzlhixdakikoabmhsxjaizfnzcjepaczpgdxtmeeigo
 * Smoking Wheels....  was here 2017 anxitwcffwxqoohwxyekftrnmkhombpxecdyytmkrenwjlgo
 * Smoking Wheels....  was here 2017 qylazkypnpyiiqaodybyfecqpawzrllfxaxmqrogoqjvckkz
 * Smoking Wheels....  was here 2017 gksrfzfachtytekpeioluackkbtnuwsnnakgvurpwgghfgbm
 * Smoking Wheels....  was here 2017 vfrpxsveawjllzlghtvovuxuhtfjtjsmowaepthqfpqtzgtu
 * Smoking Wheels....  was here 2017 pzkmxbbzrobdicmcyzgdgcaxwpsbrfavtsljflcvmhjytyia
 * Smoking Wheels....  was here 2017 bnidgqhrrwimqtdyxemhmvbgygaiaznrawnefabusjkxfcvk
 * Smoking Wheels....  was here 2017 yzasgjgpvkxgsmevbpjkyezmsseeljegrykgkwjmizbwhsqp
 * Smoking Wheels....  was here 2017 fqlpjkxnggwkhcsbtxcdnmbnlfkvvlkfctmlvrldxqtidchi
 * Smoking Wheels....  was here 2017 cdrjndkiiolfgpbfjyahelroufhulntidkjwtizdhbiaeups
 * Smoking Wheels....  was here 2017 cgeyqfffqudetgucssuahznapknwpbaqrgzytaadpeuybnra
 * Smoking Wheels....  was here 2017 ydmkbnbpbssagqsusqhsifpqztdyaxilzvlfqbqeefiitjvv
 * Smoking Wheels....  was here 2017 ocodigwfrfetjlxophqydnbhhmjjpazinadqkejiqrorjopy
 * Smoking Wheels....  was here 2017 hsmuguwywouqauszxmgqsqjecbupnsndbysgjgxcwfdujrwl
 * Smoking Wheels....  was here 2017 mwsewumzffcdlxswiitwkjgshfdjenuwnwbnbkddyvepjmrp
 * Smoking Wheels....  was here 2017 zpvllejuoxwazisgveaaryqqzwjrhewvfkgyhcijetwjizjz
 * Smoking Wheels....  was here 2017 shtznaozbnagjvumrpftksrvmhvtstcpolunbyxagktoklmk
 * Smoking Wheels....  was here 2017 xnokyvfpbjxdmlgciksxpixnmwzdrnbahafhtwomzopaakwx
 * Smoking Wheels....  was here 2017 acspsfusdwadmlrymtcpotzctkpooanckmlqvaflmcjqwrpw
 * Smoking Wheels....  was here 2017 vdvqcaywdtczujxzfyjeubvglvraazpddkpectdwciksuhzt
 * Smoking Wheels....  was here 2017 iztxsmrqeyerczaqqpohdssywintzmptyscvpusxlqdtblqk
 * Smoking Wheels....  was here 2017 rfrbhzeaqsnmhijkimcvpjairkpgrtdspkoqrzsajuklztix
 * Smoking Wheels....  was here 2017 lsyxxdxfdmqwoqlbztqxmwmwturgkjzcavxbunzwzsdvhyeo
 * Smoking Wheels....  was here 2017 gmfrvxnplzgqimctotawjkafcjuuybfemqfqvuvkrrrexamx
 * Smoking Wheels....  was here 2017 eyjppjaxtfksgqmsiakjzjwielfbexfnmpxhtkquzbmxziut
 * Smoking Wheels....  was here 2017 lqnkbzoakijkgdvotkfflkljnlkpfdmzsvpdxicmuriwyjae
 * Smoking Wheels....  was here 2017 lldyejpeyvqemfsanbapzlluzbddohxpdsenusfefkfylydl
 * Smoking Wheels....  was here 2017 aktiimwtikztjlagrgtweqwhthlrvdnqbtvcfxdtqnklkaoe
 * Smoking Wheels....  was here 2017 bxhwzkgmobkepoumlqoqujwtciplytqswwxsgpikpmlwaxud
 * Smoking Wheels....  was here 2017 vmxhzpahbzfrcqjigztuxgykrrczcjwpjcamernqzzcyrcrk
 * Smoking Wheels....  was here 2017 waakirpikqvszyhoxlbkthsqhzszsnbinvbvmhpbyzisblhh
 * Smoking Wheels....  was here 2017 uqeijorclsccszkghhiyyoefchkmkafhnpfhbwvptrkibyzj
 * Smoking Wheels....  was here 2017 rpilpkfeigzuxnusserxglnzltnsdvrzxgvvwbqnbpwjwvhj
 * Smoking Wheels....  was here 2017 snpkvokpjktaoqunqyohsrgdxwndbhbgjyomftreskmnxrbl
 * Smoking Wheels....  was here 2017 jgiactrneqyiuoxlupncpcyejidopwecwyhrrcyhvcgwwfiv
 * Smoking Wheels....  was here 2017 kxgmswtipsikavanepmumwrsxdlylkbxrwdzamrutwkopomd
 * Smoking Wheels....  was here 2017 uuecfaptunvhygfdylpydkosxlrnlwcehoniipfvcfmdhxbe
 * Smoking Wheels....  was here 2017 tmgnjrksbjvfluuvrzhlpjcjzuivwoutkbavvhjwsugikuxz
 * Smoking Wheels....  was here 2017 twxpfkpkaqtrruijajckfqzcyvepaaaqzupvcuaqspsdpabv
 * Smoking Wheels....  was here 2017 oasmcewfockkdtqvawzfmkcpyoguravfhiiyyljzlwdvtqwi
 * Smoking Wheels....  was here 2017 dgpnncextrtlkmunwdbmeztuieurrpozulqbkxxdnazxbwxh
 * Smoking Wheels....  was here 2017 sesjhptjypdzlydabysbjdhvreiufzuughdhtchntucbygzt
 * Smoking Wheels....  was here 2017 tpkvlibttizoklgcikpcjrmfvfpvstirpesanemviemjbpea
 * Smoking Wheels....  was here 2017 arichfsoaqcwsnywqxoysvgoyiquwrgybsnwnmsznjizhxvr
 * Smoking Wheels....  was here 2017 msjniiskxkmzbyhpfzufdyuwjrrynuxeesyrvtjdzuflxmnm
 * Smoking Wheels....  was here 2017 jgrskehhrwkcitpvonpvtrogrugtxiveqhqqrwfuofwnfuao
 * Smoking Wheels....  was here 2017 dfqnnivjanjssfmlkoswvygfthdakvwzlulaqyepjphfyrmd
 * Smoking Wheels....  was here 2017 oqvczsbaubeopwskslzsxyvkrfhrsccxuunnnlkmtduszdew
 * Smoking Wheels....  was here 2017 pxfvjmyaamtrrmkctunzuzmtvtaatevnfdgajylqihvoomrm
 * Smoking Wheels....  was here 2017 loxhlbrgcylhwbxbylsomuqlujwnrhrqjwgokjxnxuflzevc
 * Smoking Wheels....  was here 2017 rlhjfcrxrysxixsbbmgnifaxltnxwzkhhkmpgyutrqxlaarz
 * Smoking Wheels....  was here 2017 xszfamrloeifmosfbgyhwlpvwyagbbcufhassygixyftocps
 * Smoking Wheels....  was here 2017 epxekipmwqihztzufhamvxnekbqrdndtokgttdujghqxupcb
 * Smoking Wheels....  was here 2017 tuewdcraynyiuoukynuyiehbsqwugqaxduuxsjcjnhxpbdbe
 * Smoking Wheels....  was here 2017 abeeglifkhsvafuuazxuqfozqjnhwyqixupmcvcaxzcwckng
 * Smoking Wheels....  was here 2017 uoofcfhmcrjpdhsakahlhdhpggoepgakaaucuwzerokxumvy
 * Smoking Wheels....  was here 2017 aoeidplodqyntosljgambkswylgskonpbhrrtegcmmjhiqoz
 * Smoking Wheels....  was here 2017 ysfegzbixksyvabqimotapgygkcjkdrtstzihpoeeltrdknm
 * Smoking Wheels....  was here 2017 avaqkbozzkdioyjibumlmrpgdxwwcnjxzrokyjvcwlodvous
 * Smoking Wheels....  was here 2017 azguyrqzejakhwkpnorwyurmpxqhbmplbronnwivwrbxkcsh
 * Smoking Wheels....  was here 2017 wnubjagzrgjespivyjisfhtpcoouhbtvlpjocsmnvqulyivy
 * Smoking Wheels....  was here 2017 vbtznmpyuhlxuekmvautiwgudkfyxnjxwnoqxvzqpzlmytzu
 * Smoking Wheels....  was here 2017 kkonksdzdytbqufkwrrfpkwkqcjlikhtiucdnjuvhtccaegd
 * Smoking Wheels....  was here 2017 hsvtiqnqoyblsbpscpykpbngsqzhgmprazdrstcafczmdqyn
 * Smoking Wheels....  was here 2017 mfmbvjtnefjzqrqpslqyagmdqgjtotoelzzcooilanpckjqt
 * Smoking Wheels....  was here 2017 eppbsiaoizyyjtpsfzfszqcicjahmovdiwhoiufmostuhydx
 * Smoking Wheels....  was here 2017 xropaftzqshwbndwhjhvucegyssrjjfprxzkonrwyqkllcpg
 * Smoking Wheels....  was here 2017 jmcwavqeyeeldnzbyxtsyuoogglyxztvrufhbfynmowjtxgk
 * Smoking Wheels....  was here 2017 olzdhkrwjgqrgnipkesxgdofjflgzktlvhhbwmlovwqblpsd
 * Smoking Wheels....  was here 2017 rclcpiazgfxviokcebpittnkyahewzwfwmxwhfxnuikgxsum
 * Smoking Wheels....  was here 2017 ghuqzferfmmkoxujzqbctnfntlrkwdvetuyavqganxhyubpv
 * Smoking Wheels....  was here 2017 acsutaukcuedicjkuexourogalrzstusttoeibrajunjapkq
 * Smoking Wheels....  was here 2017 xxcamwuwadzaixeoujijrotpzfmciuaihebfuerryloburvu
 * Smoking Wheels....  was here 2017 dgbxxdlyisdhliojoasjkwgrierivndvefegnxwmbpfsnvri
 * Smoking Wheels....  was here 2017 gazibnewqydmwsartershltywdzirnyhietrcjhawgmivtao
 */
package net.yacy.contentcontrol;
import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import net.yacy.cora.util.ConcurrentLog;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class SMWListImporterFormatObsolete implements Runnable{
	private final ArrayBlockingQueue<SMWListRow> listEntries;
private final Reader importFile;
private final JSONParser parser;
	public SMWListImporterFormatObsolete(final Reader importFile, final int queueSize) {
this.listEntries = new ArrayBlockingQueue<SMWListRow>(queueSize);
this.importFile = importFile;
this.parser = new JSONParser();
	}
	@Override
public void run() {
		try {
			ConcurrentLog.info("SMWLISTSYNC", "Importer run()");
			Object obj = this.parser.parse(this.importFile);
			
			JSONObject jsonObject = (JSONObject) obj;
			
			JSONArray items = (JSONArray) jsonObject.get("items");
			
			@SuppressWarnings("unchecked")
			Iterator<JSONObject> iterator = items.iterator();
			while (iterator.hasNext()) {
				this.parseItem (iterator.next());
			}
		} catch (final IOException e) {
			ConcurrentLog.logException(e);
		} catch (final ParseException e) {
			ConcurrentLog.logException(e);
		} finally {
			try {
				ConcurrentLog.info("SMWLISTSYNC", "Importer inserted poison pill in queue");
				this.listEntries.put(SMWListRow.POISON);
			} catch (final InterruptedException e) {
				ConcurrentLog.logException(e);
			}
		}
	}
private void parseItem(JSONObject jsonObject) {
	
	try {    	
		SMWListRow row = new SMWListRow();
		@SuppressWarnings("unchecked")
			Iterator<String> iterator = jsonObject.keySet().iterator();
		
		while (iterator.hasNext()) {
			String entryKey = iterator.next();
			
			Object value = jsonObject.get (entryKey);
			String valueKey = "";
			
			if (value instanceof java.lang.String) {
				valueKey = value.toString();
			} else if (value instanceof JSONArray) {
				valueKey = jsonListAll ((JSONArray) value);
			}
			
			row.add (entryKey, valueKey);
		}
		
		this.listEntries.put(row);
		
	} catch (final Exception e) {
		ConcurrentLog.info("SMWLISTSYNC", "import of entry failed");
	}
		
	}
	private String jsonListAll(JSONArray value) {
		String res = "";
		
		@SuppressWarnings("unchecked")
		Iterator<Object> iterator = value.listIterator();
		while (iterator.hasNext()) {
			Object val = iterator.next();
			res += val.toString()+",";
		}
		
		if (res.endsWith (",")) {
			res = res.substring (0, res.length()-1);
		}
		
		return res;
	}
	public SMWListRow take() {
try {
return this.listEntries.take();
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
return null;
}
}
}
