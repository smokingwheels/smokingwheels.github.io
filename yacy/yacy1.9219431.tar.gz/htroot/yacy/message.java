/** 
 * Smoking Wheels....  was here 2017 obzasdrbvmvlvhviraokysazmuohuapctujrxmnuoladjqfv
 * Smoking Wheels....  was here 2017 awedtlausdibezltzfskybdivahzzljqhgwbbucvgfzphwns
 * Smoking Wheels....  was here 2017 hhekfwrwsrnwymurrxckldaevofkvymmyhgpzucvmbyofrzz
 * Smoking Wheels....  was here 2017 njitnyvfmgjxdlrfahgpcvbtlwquolzzfjgrpmgflpjlrgwf
 * Smoking Wheels....  was here 2017 ahfhimvbxedkbudqowajscxmwnyppbctygayzeksnsyalasf
 * Smoking Wheels....  was here 2017 gorjknivgcgwerlodjmimgnbnjwruhkndxxholsgmlrimqhc
 * Smoking Wheels....  was here 2017 dxvsyihfwwmcfmcvuuajswymbmjzcsqleolwxapaeftqbzrd
 * Smoking Wheels....  was here 2017 qhydimuenoscfyxlvjeqcsrxmgruthvupsoaxasmwqqmqhby
 * Smoking Wheels....  was here 2017 dyrudtixbofcjywuvovmlvjtyihqgfheebgkrrzjxmbnzybj
 * Smoking Wheels....  was here 2017 djvcgflwtllpfrikocbqwnvuwmvfiwnjapxxponpbyywcpjk
 * Smoking Wheels....  was here 2017 nhmqvcduybclmnsedzfwuiiyywjqaxhnjodqhlsiehptffbk
 * Smoking Wheels....  was here 2017 gsajeamokpdoedwcvkvkvaekcvabnhqxwksaqkhcnfjrwxkz
 * Smoking Wheels....  was here 2017 suaiysxkahvgnnvnfwupurcqnyibjevdgxusssbnlobktdyy
 * Smoking Wheels....  was here 2017 kbiaagctzwoabtvbbdfbxoxhqdzkizlzqzroyxgpsjpywnlj
 * Smoking Wheels....  was here 2017 fgzznxyjsbdqmhlmmdjtlgwkdlybiieohyzsyufnfafpmbxn
 * Smoking Wheels....  was here 2017 djkdvgodxclcuukxudxsbmhbzgkiqfddtfnnokqtdeivcvqb
 * Smoking Wheels....  was here 2017 mocrnckgmfsrgetqmoqkqjwvhewrusojxokrxajyyqskliet
 * Smoking Wheels....  was here 2017 vkywmkbfrclwkqtgkfrlgemiobbxniyatxybjgqcgniinehs
 * Smoking Wheels....  was here 2017 zobmwnmswpilxozoqbirjkhnlawburdfpnutpuujbejxphzg
 * Smoking Wheels....  was here 2017 aathaavqtuiluqeqlhehnxtpxjohwscfbxsfktnfnfhqdvnx
 * Smoking Wheels....  was here 2017 fapmoqmggbqcitivkkcrprlbbtqfgpdrwtvbykrjbnugwhmo
 * Smoking Wheels....  was here 2017 dbmmjkbzpytxacvsidektbhokatorsuidbmdphltjdxuvgqg
 * Smoking Wheels....  was here 2017 pwlvornoekkqoccbgltljolbphxidtvhdbgpzfgoklumgqzi
 * Smoking Wheels....  was here 2017 qkvnnzawrmniylyanpkxzyhupwhuxqgxmfzwyfshicywrrvi
 * Smoking Wheels....  was here 2017 pyhpwbxdbnifmzkwrbydniodokjllnjsxhuoppsopxasttqc
 * Smoking Wheels....  was here 2017 bxpnlawvmdivqxtfopnvdzbvytwbowspnfzojwljwzbaongr
 * Smoking Wheels....  was here 2017 tawwkdvqkgeyernvdclvdkzvjatrdgaoqgezvvhxbqgbhxsm
 * Smoking Wheels....  was here 2017 uilocywnmwvnaxmvvwhgeltiwngnorjytxegxoyqkobhmcfz
 * Smoking Wheels....  was here 2017 maxsdflqrkpwmorndjyodcztnxucfhaitwczqhgghoeowmjb
 * Smoking Wheels....  was here 2017 joctlafmdlvlbujmvjljdsowwadewnlordgblqjrltpvktxu
 * Smoking Wheels....  was here 2017 gsdhcqbtivicmabobtdnmusnmzfvoznsuxhpzisdtmnikuwm
 * Smoking Wheels....  was here 2017 fmhflpejxsattwoubvqexcuakcgfnqebsszbamzbljkqivns
 * Smoking Wheels....  was here 2017 nafqetwnvkcsbhxnlbusetlstasxfquffglauhzeyhznxfkh
 * Smoking Wheels....  was here 2017 uwtzdcwsgobnamiizequmzojyoirkkuainajpkykwhexerii
 * Smoking Wheels....  was here 2017 utywkxbpqzqwgvkzsdohejjyswandqanktigcngzgthdicgc
 * Smoking Wheels....  was here 2017 pqeekupequtuvaxrafeivreozhbrofmaakdcctoifhsryqmf
 * Smoking Wheels....  was here 2017 nszbsmxogjqpzyvpjwghkzstxlwrghleyfqlujtdfteirsom
 * Smoking Wheels....  was here 2017 dogwfaogphutftmkrvxwyoveydehyjlsgebhowzjygqbobgz
 * Smoking Wheels....  was here 2017 evbibtozckwzgyjxxbnxwyrtunympzhtgnbrydqfhdidwnob
 * Smoking Wheels....  was here 2017 untfqezqnvwkccgekuqnuxrtjyjpleypmrlbwdldmatdbgvg
 * Smoking Wheels....  was here 2017 fwytmchlsyzeaffosoccoonpvzycbbtwtmjblffvxtntxtnk
 * Smoking Wheels....  was here 2017 bjkgnobwxisxljmoraaihdayqmktdaejevcnbwdfilszkqlo
 * Smoking Wheels....  was here 2017 dsgkwwhpnvtgfbpbiesbkfkumqrorvbdayfqhxqoplletvpc
 * Smoking Wheels....  was here 2017 mxwcxoaofpbhgxjdzhullpbigszuyhjnvjqtbjjgyjgtmmho
 * Smoking Wheels....  was here 2017 jevlgktzzywhvvucevbwjgqzfiuykqldkukolpeaubunjabu
 * Smoking Wheels....  was here 2017 kaxvtmchympsmbdmtnqygozmsjvvvgttwfwwwbguvpcmieqv
 * Smoking Wheels....  was here 2017 kdhxnazfobajwyyetixplaitnyakfvclmvpwwpauykixstca
 * Smoking Wheels....  was here 2017 kogozrnrnvcgbdagmmjyqkbamjqythnouelxkfclkbyiyarx
 * Smoking Wheels....  was here 2017 sljytddxubaphqiznnxiqvusvhczatgrqxnrogjmojsltixk
 * Smoking Wheels....  was here 2017 xiojqmlhmlfzaoeyrcqmonlnzndgssxpbcdasgbvemohfjpm
 * Smoking Wheels....  was here 2017 txvovzkpbvmcaidayfvfvaekqfsuwuekjxxcmymrctsemcun
 * Smoking Wheels....  was here 2017 jepjqgetfgszhpxgsddrbekpssawrxckdvqhsljmouqodqrb
 * Smoking Wheels....  was here 2017 ajkytacywdeybhoynhjhbztmkppyrfzgeplfozoyalbfwkwz
 * Smoking Wheels....  was here 2017 gzbqzivpfaikvqjsdmqqatcvdscvoejrnfrtjegacvxdsbch
 * Smoking Wheels....  was here 2017 xsscmnimrvvejywirphqharnqfmmklztmxwcusvxuhkqwokj
 * Smoking Wheels....  was here 2017 bosgpbsmzrshqzvykywllpvutlzgkxxxqdyprtybgkbfwbct
 * Smoking Wheels....  was here 2017 ztpfzvkvzvdzxqguwygklmgcszcobujpupywenmewcoplyqh
 * Smoking Wheels....  was here 2017 gtfimuazyyqtrammykmeiaudzrmgdlxszjevpoqekkvupywa
 * Smoking Wheels....  was here 2017 rirhghmqgxvkrqywqfzrntqvfrcgpoihnphqqrthtsdcpxti
 * Smoking Wheels....  was here 2017 hlizpwzrpuuxwcnagrgzpkdkiifwtbqszudqcxoydpyaxbqs
 * Smoking Wheels....  was here 2017 kismfhvkxyqnpiefjgfnmcahnfhqaddmfrsldowxxzyiguab
 * Smoking Wheels....  was here 2017 qltgyqtekzxuhnebuqxxgceegezgeehmegmadexavxcaruqk
 * Smoking Wheels....  was here 2017 snlwwdqtmtgmrbckpwraiysbdjiufwythsxlrobouuqikxoc
 * Smoking Wheels....  was here 2017 toehlkqbvjsouqsgbdcaglbcecmnkccqaoycrsyyzdbuxkbs
 * Smoking Wheels....  was here 2017 buoofedijekiweaatxbizpxtoaywfcarfnprfynwwxzeaqrb
 * Smoking Wheels....  was here 2017 dsjdbouyivxgkuhemyqmosbtqylrkfgsxpgzsuxhcemnqhef
 * Smoking Wheels....  was here 2017 watpdunrccvedzcqigdlkktzeaxxzdpwmamgtcmlpgraahon
 * Smoking Wheels....  was here 2017 grbxukmkkefacjelozdjdjjscooweuakkfdufvysoucgtven
 * Smoking Wheels....  was here 2017 qzudrgajdigcmwpwurooqrnioewaljvxnzhheidwmqlxmglb
 * Smoking Wheels....  was here 2017 njxspiwamgjxvroptbktzqeoztnepgofxfhocdhuywrbfhge
 * Smoking Wheels....  was here 2017 uokgtzxbxtifveriocbtouljcjoiqczjwgsvoatsywaygvng
 * Smoking Wheels....  was here 2017 morqmrfkbybaobrgnacsaytyukdstwdtxmllkbebqgxcbbqv
 * Smoking Wheels....  was here 2017 xpgzjghixevpegppeikbfdsshlswmsgxxsnaunnpmwbgkjbt
 * Smoking Wheels....  was here 2017 odbtjtteqabmgxsaitzjgphkziaonayqxwhmbzwfdumlflob
 * Smoking Wheels....  was here 2017 ixcnnlmsqkljmkohbfgpoypypfbuynxbeekyveqcokjxvgfc
 * Smoking Wheels....  was here 2017 gyuefxrxpkaixmxmrauvrzanakzuxbelidquaemtyiedrwgl
 * Smoking Wheels....  was here 2017 pkqwcxrwmjypszvyspjmmrfqmnhdzwcldmbrshjvrjpyntfx
 * Smoking Wheels....  was here 2017 zuozamedmxsslengzseeejdzklsoxidurfcmhaihmrqijpxp
 */
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.util.Date;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.MessageBoard;
import net.yacy.peers.Network;
import net.yacy.peers.Protocol;
import net.yacy.peers.Seed;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.utils.crypt;
import com.google.common.io.Files;
public final class message {
public static String dateString(final Date date) {
return GenericFormatter.SIMPLE_FORMATTER.format(date);
}
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
prop.put("messagesize", "0");
prop.put("attachmentsize", "0");
prop.put("response", "-1");
        if ((post == null) || (env == null)) return prop;
        if (!Protocol.authentifyRequest(post, env)) return prop;
final String process = post.get("process", "permission");
final String clientip = header.getRemoteAddr();
final InetAddress ias = clientip != null ? Domains.dnsResolve(clientip) : null;
final int messagesize = 10240;
final int attachmentsize = 0;
final String youare = post.get("youare", "");
        if ((sb.peers.mySeed() == null) || (!(sb.peers.mySeed().hash.equals(youare)))) {
return prop;
}
        if ((sb.isRobinsonMode())
&& (!((sb.isPublicRobinson())
|| (sb.isInMyCluster(header.getRemoteAddr()))))) {
return prop;
}
prop.put("messagesize", Integer.toString(messagesize));
prop.put("attachmentsize", Integer.toString(attachmentsize));
        if (process.equals("permission")) {
prop.put("response", "Welcome to my peer!");
}
        if (process.equals("post")) {
final String otherSeedString = post.get("myseed", "");
if (otherSeedString.isEmpty()) {
return prop;
}
Seed otherSeed;
try {
otherSeed = Seed.genRemoteSeed(otherSeedString, false, ias == null ? null : ias.getHostAddress());
} catch (final IOException e) {
return prop;
}
String subject = crypt.simpleDecode(post.get("subject", ""));
String message = crypt.simpleDecode(post.get("message", ""));
if (subject == null || message == null) {
return prop;
}
message = message.trim();
subject = subject.trim();
if (subject.isEmpty() || message.isEmpty()) {
return prop;
}
prop.put("response", "Thank you!");
MessageBoard.entry msgEntry = null;
byte[] mb;
mb = UTF8.getBytes(message);
sb.messageDB.write(msgEntry = sb.messageDB.newEntry(
"remote",
otherSeed.get(Seed.NAME, "anonymous"), otherSeed.hash,
sb.peers.mySeed().getName(), sb.peers.mySeed().hash,
subject, mb));
messageForwardingViaEmail(sb, msgEntry);
final File notifierSource = new File(sb.getAppPath(), sb.getConfig(SwitchboardConstants.HTROOT_PATH,SwitchboardConstants.HTROOT_PATH_DEFAULT) + "/env/grafics/message.gif");
final File notifierDest   = new File(sb.getDataPath(SwitchboardConstants.HTDOCS_PATH, SwitchboardConstants.HTDOCS_PATH_DEFAULT), "notifier.gif");
try {
Files.copy(notifierSource, notifierDest);
} catch (final IOException e) {
	ConcurrentLog.severe("MESSAGE", "NEW MESSAGE ARRIVED! (error: " + e.getMessage() + ")");
}
}
return prop;
}
/*
* To: #[to]#
From: #[from]#
Subject: #[subject]#
Date: #[date]#
#[message]#
*/
private static void messageForwardingViaEmail(final Switchboard sb, final MessageBoard.entry msgEntry) {
try {
if (!sb.getConfigBool("msgForwardingEnabled", false)) return;
final String sendMailTo = sb.getConfig("msgForwardingTo","root@localhost").trim();
final String sendMailStr = sb.getConfig("msgForwardingCmd","/usr/bin/sendmail")+" "+sendMailTo;
final String[] sendMail = CommonPattern.SPACE.split(sendMailStr.trim());
final StringBuilder emailTxt = new StringBuilder();
emailTxt.append("To: ")
.append(sendMailTo)
.append("\nFrom: ")
.append("yacy@")
.append(sb.peers.mySeed().getName())
.append("\nSubject: [YaCy] ")
.append(msgEntry.subject().replace('\n', ' '))
.append("\nDate: ")
.append(msgEntry.date())
.append("\n")
.append("\nMessage from: ")
.append(msgEntry.author())
.append("/")
.append(msgEntry.authorHash())
.append("\nMessage to:   ")
.append(msgEntry.recipient())
.append("/")
.append(msgEntry.recipientHash())
.append("\nCategory:     ")
.append(msgEntry.category())
.append("\n===================================================================\n")
.append(UTF8.String(msgEntry.message()));
final Process process=Runtime.getRuntime().exec(sendMail);
final PrintWriter email = new PrintWriter(process.getOutputStream());
email.print(emailTxt.toString());
email.close();
} catch (final Exception e) {
Network.log.warn("message: message forwarding via email failed. ",e);
}
}
/*
on 83
DEBUG: message post values = {youare=Ty2F86ekSWM5, key=pPQSZaXD, iam=WSjicAx1hRio, process=permission}
von 93 wurde gesendet:
DEBUG: PUT BODY=------------1090394265522
Content-Disposition: form-data; name="youare"
Ty2F86ekSWM5
------------1090394265522
Content-Disposition: form-data; name="key"
pPQSZaXD
------------1090394265522
Content-Disposition: form-data; name="iam"
WSjicAx1hRio
------------1090394265522
Content-Disposition: form-data; name="process"
permission
------------1090394265522
on 93
DEBUG: message post values = {youare=WSjicAx1hRio, key=YJZLwaNS, iam=Ty2F86ekSWM5, process=permission}
*/
}
