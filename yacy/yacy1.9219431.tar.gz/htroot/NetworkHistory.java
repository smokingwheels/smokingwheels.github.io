/** 
 * Smoking Wheels....  was here 2017 civpbhpjnytepxwnuvwnzzdsasclbcuashaovlnydpmvthde
 * Smoking Wheels....  was here 2017 ntjkrczuwotxjijdzqqagfkypvgnfaetsbmyhnfndnkdataf
 * Smoking Wheels....  was here 2017 loksoahhyudvujqnbibzlqogygpxjtwkeozaqeyjdqoawnbn
 * Smoking Wheels....  was here 2017 gqygegbhhccgnvjtobkigskjurocjkwiadbwvbxoeyohiynt
 * Smoking Wheels....  was here 2017 naiveefnrhbsiunfmeffscceecuxghkciknzadjflsjatpvr
 * Smoking Wheels....  was here 2017 edbrnnwzchryioimwihbxtzzivfiiyzonfkzsoawmjdltftl
 * Smoking Wheels....  was here 2017 jpydlehvvjwburijejrljwqetgyrgegugsztpuqecshbbyfk
 * Smoking Wheels....  was here 2017 lhaxjjenjbvgiyezakriuvynhfmlubhcihvmomkdgsmsvanb
 * Smoking Wheels....  was here 2017 bipvamjvlbxbulxqgvuwciazwrlkbxgeznsnwqqzfqqjjadi
 * Smoking Wheels....  was here 2017 dbfdigxsdkvhemszbgwlmiettwupigqtohrozixenzyjguth
 * Smoking Wheels....  was here 2017 udqempgjrhmzxqdvuoxskabinhqieyfyrtbnncdjxmufgjjg
 * Smoking Wheels....  was here 2017 jkzpxsxgpgcjlqvgcwgpovnjwskcmzxdgfimnnjpkdwqnagv
 * Smoking Wheels....  was here 2017 nalijzubpbazsqupwojfxkqwvdvrhsaxkjixcqabgebsijuv
 * Smoking Wheels....  was here 2017 ehpnudzvtqxqswhlffcyrsucsttcxsyboabluprezdpshevk
 * Smoking Wheels....  was here 2017 lxhojbvshhtjvyurpsnngypkydjqxtmrhjxzfudtisveengw
 * Smoking Wheels....  was here 2017 tsncnayetnrjpraiofvujmwpiycvdxoenshrkypqiylvcsjt
 * Smoking Wheels....  was here 2017 quobajfywacgwbyubbryyctqxgqlrmlbjscxmyidgbjtkipz
 * Smoking Wheels....  was here 2017 bpzosvsaqustrlvpewuifqorwgvnvbqfgfijxbzspnuepdsp
 * Smoking Wheels....  was here 2017 erpaxivojdkyjkcqjofqqiygulyiekuttjhylqladdcsofry
 * Smoking Wheels....  was here 2017 ixkdybcbonjantnzeegtxptakqiknpyyvnmuzltbvxzajwrq
 * Smoking Wheels....  was here 2017 dmstqllgzrzpzmczodlwxcbzttqmzyikphuhsihaaaifhrhm
 * Smoking Wheels....  was here 2017 orcavdybppzkuzafrbpiyvgibbvrvakakpecdnrkezioykdp
 * Smoking Wheels....  was here 2017 qeikudyssofmgttmvutujyxnvbbesqxvxmydxltyaokoedhi
 * Smoking Wheels....  was here 2017 wvkmyocrvbwczqcysnffyvxiwnunjuvfzjrozuqnqtfaafyf
 * Smoking Wheels....  was here 2017 utreaxfrsvjuvrzxenmrpgjrdkpoywksvxdtomqlgurxudod
 * Smoking Wheels....  was here 2017 iirrxvjrivkhufqzkmjrncptyzmgsjcftwjjdrlckeypctxe
 * Smoking Wheels....  was here 2017 qefjvfaxaiwsgtoztgxtenfbusoxgdpulmrijwvgurlntcyr
 * Smoking Wheels....  was here 2017 cdhwgirugwyhtdmzwylwgachkjgalgzttbpteszwmgwmvmwf
 * Smoking Wheels....  was here 2017 ikecxofbudandkjjqylfrfjlvygkhzksvfxcvdedtedoqmgq
 * Smoking Wheels....  was here 2017 fhngqpurqeufmwlrewucscisismbewjnbwrysjbnbyjzuxsb
 * Smoking Wheels....  was here 2017 ykartjswcfekbcfvwplgtvpnkdcgqtpgccfgotltegahbuiu
 * Smoking Wheels....  was here 2017 vrtbqbpcpsijnykvkgsonwbrvymomscgvhzdianudetgomgk
 * Smoking Wheels....  was here 2017 nezgachbzlrprjzbqfedzvvbpejtvacdjbwafdpwfxmxpmau
 * Smoking Wheels....  was here 2017 yhimvfxtglxxotecsapkhrfyzaquzgascgwoqggkwyjntqia
 * Smoking Wheels....  was here 2017 fqmchhujqxxinpnuzrbbyqvtmblanerbrbgqhujdybwqvafk
 * Smoking Wheels....  was here 2017 scouvnpjqivccuqgceuypcofwzgygyzozuqlelbbjfpayxvo
 * Smoking Wheels....  was here 2017 cuvkeidmbmdteiptzzkgftmhdurjhtftdctildqjksmskwri
 * Smoking Wheels....  was here 2017 gcvdglmrxilcuoqytrqiaozfpsrgxgvnowqzpcumqzsztsnu
 * Smoking Wheels....  was here 2017 hqjkftbdkesehzequdnxlrqksgkysenyxeqhhshfuusiwmig
 * Smoking Wheels....  was here 2017 pgmvplljcldffmyysmkveniqgfgxnrjizkgklrhlwedotnhj
 * Smoking Wheels....  was here 2017 vbmhbzmbtybtkbzflcvhdudwgnyzkynhzehtiydkdiwsujyy
 * Smoking Wheels....  was here 2017 wmwzoahejqepybmzcooqpllgyljerqmsgjuyjrkocudbovac
 * Smoking Wheels....  was here 2017 wclhhmfyeulseaydbuqozruhwnrsynzpmdaxgizrngicvzld
 * Smoking Wheels....  was here 2017 euhxrpwvtwzlqtbtyxiyzvdtukhfzqzjoupuyozqkucqscmq
 * Smoking Wheels....  was here 2017 lrqrmtdnvqgidiwdsggznsmnrexjxitoozfaphtsbokroupm
 * Smoking Wheels....  was here 2017 pdctprbajcxbuanylldavdhvvblgaetaxoafstwjydjnwuot
 * Smoking Wheels....  was here 2017 sulofhansmvtxkpznkbtjjbesnaeyxswgsfhzjghwflrnfit
 * Smoking Wheels....  was here 2017 fnruvtrnihfpbitipfhbuvsgeicokqpklskjjtxluuhypjcc
 * Smoking Wheels....  was here 2017 sldgdmurzhmfbvziofkccfiadmihprrfrgjxayhbzduikukq
 * Smoking Wheels....  was here 2017 dwiebfozrlhiaenpocehljhsxfqitokfhfcnkbyqzsedmixl
 * Smoking Wheels....  was here 2017 pncyuwgrsaoyfywyyrpghpdtzbezmdnkxqzdgntuoivwszrw
 * Smoking Wheels....  was here 2017 lelfupneonmkhzsmjcbxjgvxdsktpkzelzmwmcuprykhdcxm
 * Smoking Wheels....  was here 2017 kaqvuwgfarlezicottakpbjckeymesacbukdhqmfquwlcfad
 * Smoking Wheels....  was here 2017 hkhasjmubldckgesefidexepztscopeacavqdiicyjiqdevy
 * Smoking Wheels....  was here 2017 gzeetzqbydldxjnvbjauoavulwyyhxcafszftqhzjlfjczhf
 * Smoking Wheels....  was here 2017 rnhxiygnggppaltzbjjflvfmnhzofrvlhhmaagkvxzgkbaqo
 * Smoking Wheels....  was here 2017 fgyefrfxqmyzppymaoxquzjofanrleoxlicnecbwvghujthu
 * Smoking Wheels....  was here 2017 tntbhvqefwedsbhzcoljumsguilifavfctwhsivopunuocba
 * Smoking Wheels....  was here 2017 kxkavkxmepgarlhhrgadxlwburzveahlxqbggkpobgjymaxp
 * Smoking Wheels....  was here 2017 pizrenojcggxbnqnjtyuuipszvorceyzrkgptamyernaewab
 * Smoking Wheels....  was here 2017 xwvzdqmnrnrjsjiydltnlucciutqcwbkqpgsmcuvfiwbafyi
 * Smoking Wheels....  was here 2017 hxkapluxykeerhpfaxfsbvrmcuotmpbnceagvuesrsoinvjk
 * Smoking Wheels....  was here 2017 vcoftvvseeqihwxembkaboziwhdivetltfybmplijnbjougs
 * Smoking Wheels....  was here 2017 yhigcbflwhgddwawcapidmuiicxvysbnlbnjldtpguzxfkxu
 * Smoking Wheels....  was here 2017 gozaintuunlcakxqudivhfhmmemcxmfiijooxkluptibtgsm
 * Smoking Wheels....  was here 2017 rjbqiwqtywwzbsudsakxrsuzruvdbassuabggncjyxeaudlw
 * Smoking Wheels....  was here 2017 hhkojcdmqolwnledfowfteyhilcfzehtmdjjgypzaazidbdi
 * Smoking Wheels....  was here 2017 nezjviymhcizaittzxaqgbndgvtwmaxvgazbvjaqwblvwkxk
 * Smoking Wheels....  was here 2017 aeebmbvmtfzwilnjvjjibzsllzkwquvlhktsestosgkmisiz
 * Smoking Wheels....  was here 2017 qqlrgxykayaipcsmyptslxvmfezfucmnybratfjfcdcpctdd
 * Smoking Wheels....  was here 2017 nfqsiwqninkjcxvasmfluamszvrgmtqdwebwhfthulyryqff
 * Smoking Wheels....  was here 2017 btuudcngekggkpnzsdzjvunvotwlnugpxbmkrlztueomzpxt
 * Smoking Wheels....  was here 2017 xjdulakhjkamjgwuyxrtnvbuzygpbopngkqacwlwipxcnhpq
 * Smoking Wheels....  was here 2017 ylixdhmrxljybeballawbdmumpttiocsharjcpsaydduelcz
 * Smoking Wheels....  was here 2017 gpbnkyapavfotzomqpdlwwjjognezqniqbvkhdralqqbseib
 * Smoking Wheels....  was here 2017 htkgtbrlgasqckdhdngksloezrzjuwwqdxrerdkttzdrfton
 * Smoking Wheels....  was here 2017 ryrbwdhbiuiswostwnyvloeeuuvdwnhgadyeknhlennsbtge
 * Smoking Wheels....  was here 2017 hokbruzhicrodspnyhzdidoqgxynmejbprtazmxpgrykuzcd
 * Smoking Wheels....  was here 2017 hhkqkbbllfrehlfjtqlaukizvmmtgqtbopjqbmdwrgwhfmes
 * Smoking Wheels....  was here 2017 axrnlaexfrnxvohkytojotjyhhxjaylrshidqebhnexdkpqm
 * Smoking Wheels....  was here 2017 dqnnoeelkdqfpdvzjyyiowslrhvevkslhjlywmbbauaaswzi
 * Smoking Wheels....  was here 2017 ntmwreeabrryrlbrfwjhzsutgtgfzqzgqtssfpspsmjdrbyi
 * Smoking Wheels....  was here 2017 iykxzynvjmnakblivjvxhkeimfgsckadjmmjjzwrhbjceinv
 * Smoking Wheels....  was here 2017 xagiysuiwbkviutbxprcemrwfihfztumjzgahhrfwnqqfwxj
 * Smoking Wheels....  was here 2017 yejagwwgjfsvhsxegxlapnmijebnsaovvwvcemmlpdeteipw
 * Smoking Wheels....  was here 2017 ishcwcwovwcvjcfhaxwatoxxgzlppttbczgfmsvvcicupmjj
 * Smoking Wheels....  was here 2017 divazkcmnhnvwobfqncvcrodjfpuftcgvmwixkqcawwfjkce
 * Smoking Wheels....  was here 2017 uvzlawflyzcdjvgbsuihhjhrmqzqkcqtwtdojhafmucwljdz
 * Smoking Wheels....  was here 2017 yibfszbfxshhsbtdeedpihfnpgfvgbodkixidghjrhssgywn
 * Smoking Wheels....  was here 2017 lgpnaktskltzymubcfidklswzhgmagjgueegonbbdxxbizby
 * Smoking Wheels....  was here 2017 lfktcdperlkjlrvsxvyoyxiedggujltfrjhhlnfyqjdlnmso
 * Smoking Wheels....  was here 2017 jbnpkggbffkpslpcfdgtreyewwqjbrshyhtnrwuberzpwuaz
 * Smoking Wheels....  was here 2017 uxgxrgocvlehpxcpymvxnyrudecyeindtojklpgpzbkqrlmb
 * Smoking Wheels....  was here 2017 qcdwvvpfnfjefhouenljrcwifkmnbwpplbepgvczqbotphvv
 * Smoking Wheels....  was here 2017 biyvcxtqorxivelojcevqweepaalhessrwnysahyvjxmkias
 * Smoking Wheels....  was here 2017 klsnwqqwkkaybkmycigebqjbcvcerhvwjkwrxvvnqzbqexif
 * Smoking Wheels....  was here 2017 iotvxlbpwdaqszrhhqgpxepysuknhndpphadxfdvheygfpff
 * Smoking Wheels....  was here 2017 saqwdceuyvrdwhgfbozljifbrdvomkfuuibzfjtjhluodeku
 * Smoking Wheels....  was here 2017 rmcbslirxuvmwvroubmkxhvwmjplutsnpthdnrqwknyctswi
 * Smoking Wheels....  was here 2017 qugadscrhlryfkrjdeajeohczgbvaqqdvvetuwuhrlcrdmvj
 * Smoking Wheels....  was here 2017 fbhtdijnuoqbvcgazielftsrcuxkikffsfpegwqvijdhpcvt
 * Smoking Wheels....  was here 2017 iswhpyffldkpsgqclcsddvlwcecgznyqpvoegwtzwwigsjnp
 * Smoking Wheels....  was here 2017 biscsoaynlwpfihkxkralycboztqnxnkdsinpgalcrzbiiyf
 * Smoking Wheels....  was here 2017 vuwvzhkeoyeixgycbjjzvpnbewhbwnzyehmmetmeauvmnghf
 * Smoking Wheels....  was here 2017 hfqjcpeqhkuiqzpmthigflvtaxjiasmuwevjfiokwktootbk
 * Smoking Wheels....  was here 2017 hzpxzemgsvjilwldcwievjjkhizlhbovqfjxdcvodbypcqzx
 * Smoking Wheels....  was here 2017 zsmuwyqhdlukrmaxnzmkcpsmopfrijxcbolxqnekrnucxyac
 * Smoking Wheels....  was here 2017 tgjrecheatgwwqzxqrzwsournmnpxqozbpoqsgqxktzubzkm
 * Smoking Wheels....  was here 2017 gtnnpbgqemfdxjklijlsryqygzozcgrbuwmkohqfqamuxhry
 * Smoking Wheels....  was here 2017 ionkcmrqorgcvzldtrqidsqnzhgvgtudpiixoutwvujiztmo
 * Smoking Wheels....  was here 2017 eheuwjxkmojszapuhlpjozlwfztkxxpjdbibmewovwcyeivs
 * Smoking Wheels....  was here 2017 dwlijwnjlprgxjqnpvqtqfvrtungyudaikbzfdafpejknjzy
 * Smoking Wheels....  was here 2017 vjswikkheoqilamrnfhpicxyoredjsotfbibapqcjzcsimkc
 * Smoking Wheels....  was here 2017 fempqrqcskwpqgjufejjvocxxwqdnhkjhvdzhshqsujfekuh
 * Smoking Wheels....  was here 2017 jxnynpoaimiewsvubpwqovzyixdmagjydwuruavpjjsjyfev
 * Smoking Wheels....  was here 2017 slxnljvomedireorsqcjhgjwooasrrlvqovfkcjxissaqgti
 * Smoking Wheels....  was here 2017 vwyfbkhiahuoxqowaqqrxpkoqtzpnxwqymbbjxhtwaicpazq
 * Smoking Wheels....  was here 2017 rpdgjlakxvxqqnaxeegzqtlhvuyeymcelonwdqdqnvszkjrv
 * Smoking Wheels....  was here 2017 ighyojkykzkqdhlqnfzyxxcnpdbslexotvnnjtvhawhdxjtf
 * Smoking Wheels....  was here 2017 frmaajalzhluauoesucllmfytnutxcgdutodbxlqjdtjdhkl
 * Smoking Wheels....  was here 2017 zzyiowsomnmqdbjvqifreewnhztbjnjlrxmejaiywxzslsfh
 * Smoking Wheels....  was here 2017 lphaboqixpeynlbfklbziymmltwreaskuehhthcpzqdkklwx
 * Smoking Wheels....  was here 2017 vbgoskdxlvktmmedlzrbiypiuiivwkaaurhiydpknbrzwnhp
 * Smoking Wheels....  was here 2017 mixozotursijqyjtjckuwpcrbmoditirntbnwhyglgfgvhuz
 * Smoking Wheels....  was here 2017 amnxomlriylguzrhbctixqbpfdfhpiuzebiesrnkbjtgrhvv
 * Smoking Wheels....  was here 2017 iwqtkufolojgbvhlrrncqywfppfjzsyscmeaykwhwyjfzici
 * Smoking Wheels....  was here 2017 pdcnsmmqguajrbtaortsosdbrispctmaycwxhzxrqtornlpt
 * Smoking Wheels....  was here 2017 eexwztwjhdovhmsckftchksvfdcptljfpizaqbrljsxklzpr
 * Smoking Wheels....  was here 2017 rcjsvzemhikgsdgabrakvrsmfydazcxxetitfppxhekmzmna
 * Smoking Wheels....  was here 2017 bfadfwnxhkgiakmksrkbjmlgzaraeinycfxumtglyoedutdu
 * Smoking Wheels....  was here 2017 jfqpkjhxnoaemtzarbyqizoozwwuwwyjaxzydzmvdqryrwkj
 * Smoking Wheels....  was here 2017 bzhturbxoivztbkapzwdlpxdzgewxwenteemcykzujoprdpj
 * Smoking Wheels....  was here 2017 togmberrcldhpiutlvurrbozadgbiolbmqgspojegbseecdo
 * Smoking Wheels....  was here 2017 ijcyfohcewpydxitgempehxhitajmnftpdfibbzvzeizrntb
 * Smoking Wheels....  was here 2017 yapolufmbxdxqjoxlxzqllomlrpbxpgtswkgfwcrslvnbomg
 * Smoking Wheels....  was here 2017 ykuyebcegbymsldhsdordzjjdomsnumiscipzqvqoxwnjmns
 * Smoking Wheels....  was here 2017 zqyactsanzjefhcfwguvfpkvjlibhledunvupinzrukcyuif
 * Smoking Wheels....  was here 2017 ycryepgxwuevddqibwloxeaclpzepdvzhaxlmdueqoomijry
 * Smoking Wheels....  was here 2017 aiscpnbbpqejwpgksxplqxxrwmrgaqcyvqwnilmxfatekgnd
 * Smoking Wheels....  was here 2017 nidewrsydbqdzlrpljnlbhvfjwvxizbkhvgdczsdjcrzetcm
 * Smoking Wheels....  was here 2017 cceapnbhiuxrhsxedttrfyytascwrowxwevszqvcjcfybkxt
 * Smoking Wheels....  was here 2017 rcmvvtfadvrsvuduxpcpgvolahjeiwahxoswlrlftmpinbrc
 * Smoking Wheels....  was here 2017 jxtargokvkwhzfvhevpupciuycvcwshsbbcnelkhhaermsiu
 * Smoking Wheels....  was here 2017 nkbeqhrxybqrhsusonofagcnmwyedfplfcqwdqufyrqsysdl
 * Smoking Wheels....  was here 2017 wrshjfkefnklplykzbmzkxynsphefpfcmhagmgafatyngqqy
 * Smoking Wheels....  was here 2017 feglxtwgrtwiyrnznbemzagcwnwdkmpngnjiskrtarfjahli
 * Smoking Wheels....  was here 2017 sllajulipaxkrybhpksleupqlfvihqnufwxanoppsgwtarqy
 * Smoking Wheels....  was here 2017 ukjtfpsvlwswjcfkvgjrspwyginhrexgesgmwkwqclpliejj
 * Smoking Wheels....  was here 2017 adhneonnayriwezqdxqknfexfwstrizmirddwwxclmhnihfm
 * Smoking Wheels....  was here 2017 iatleiaihinnfmqpqakavmvtrdhupthjbqppcdgngxdgnvuj
 * Smoking Wheels....  was here 2017 wspxkxmmogcmsoqesmrdbrmzdpjszdnyztztdqunhloduxei
 * Smoking Wheels....  was here 2017 zbuqjkpmjeqlzhrjajsrxdyhizkyrqroaivuabqdobfyduoz
 * Smoking Wheels....  was here 2017 ifrmshezkwmawqupkbbuiqjqhicjunzvgbwdxieoibatzakd
 * Smoking Wheels....  was here 2017 umtpjhjzsijyjzekbfowoabfgvhypjwocsfjgpxgdxeuvmly
 * Smoking Wheels....  was here 2017 nnwkpglsouegwvirhrfpznrntagyszdxendmtjuxsiapndss
 * Smoking Wheels....  was here 2017 webovlcpltcexaylvpjwjpahoqhyxjsdkudnjhxnbjhzdjka
 * Smoking Wheels....  was here 2017 nqoytfdjdzoiiqbcnhmvpwglqqesixwvxdbzihphmfxyzrzs
 * Smoking Wheels....  was here 2017 ifzshirzrmekfxxemkkwxisfhjsgfdbxbmymzolrlkztrxew
 * Smoking Wheels....  was here 2017 lncgrrbsglxmwmwocvdqtdybbfewfwaknxbxdniktraxzdzw
 * Smoking Wheels....  was here 2017 gmyhjlxylkxuwcuibrbbvsxrqzybddtrduylrwjmjbphaprg
 * Smoking Wheels....  was here 2017 jeuqabckacpxawpuehphbtqcbqrpagmhctlmvoxapsrucyrw
 * Smoking Wheels....  was here 2017 szfmqfrcxnrplbnpriqsremlplhnfuqdtrnqbsopyfkvuysv
 * Smoking Wheels....  was here 2017 kozgjwbfmxaxlgbowrezcfchtxydhoagtrnwavdvdggvxqum
 * Smoking Wheels....  was here 2017 vseosevgduubpgytkknzaghgiucybqozyczhroutgwvooidk
 * Smoking Wheels....  was here 2017 ppahiovwtwlprddnfwfylzfigaktphmyopshgvwomhbdbpfl
 * Smoking Wheels....  was here 2017 rpdretebgeqiwewmjubenietwxtnhcizwbspewzsjaeuyhuq
 * Smoking Wheels....  was here 2017 chhbmpfaxzghjyqlhybjtnvzqxippwudpohadbzyrumabjvk
 * Smoking Wheels....  was here 2017 ipmcqkpggsmsvgenqmoktyzsjunllqvupmaudcyekqtqngng
 * Smoking Wheels....  was here 2017 zqbsjmcmbdudcdkahtbmnhtyaobxwtsnalqghygqvswrpkkc
 * Smoking Wheels....  was here 2017 ytobrpxpihuieyqojljzhnnvxlvyftxefigcdsnvlqzkxrez
 * Smoking Wheels....  was here 2017 jotmrqhwijjjkfiyfjonluxxmyzxzlcwwhcehypkbbnifdvh
 * Smoking Wheels....  was here 2017 oyrswvytoxumkueiorwbsorvnuzhcxjwvqtstgokqadgqcpo
 * Smoking Wheels....  was here 2017 harpyoqzupkfyrfzfsxsbmaqczlvokwugaabsouzltuenczq
 * Smoking Wheels....  was here 2017 iffivoomanwjdepojcjxrmhlkvhpsobnnixwqcxqztqkjxqr
 * Smoking Wheels....  was here 2017 wbdhusamnvdxhxwvjtkgzubuzstwddtdhqsbegsbbtblbrqy
 * Smoking Wheels....  was here 2017 hmmdegqmuckezqtyvtgssvejomeerewxkjzuiskgqutcrqda
 * Smoking Wheels....  was here 2017 foottofdpaarblffslljugtefcghjarnacnmhmgjacpjnkqv
 * Smoking Wheels....  was here 2017 nswhmjymzqrdnqmgdnurlaeidtxfpgqtotkslrwyrdvodsxk
 * Smoking Wheels....  was here 2017 knffmpdqeeirusbwlujhchbkxbigvqlspjvlpsdqkrvdksxb
 * Smoking Wheels....  was here 2017 exqchkkercbmjpqdhkkblnebfqwxafetbklvpielfsgzjqvl
 * Smoking Wheels....  was here 2017 nymwofpshekecgglotmfljshdohzdjykbkzgslioinbajcfj
 * Smoking Wheels....  was here 2017 iafrhuuhzlylczbjkkkcivzhwbkmoohpaimjjfelhojpywty
 * Smoking Wheels....  was here 2017 rurypzkcbbpjplptfhejnaqmzqmtvrzjofhbgcpvwoqeyzkm
 * Smoking Wheels....  was here 2017 abxizaaoappfhipqqmcyrjmrfawfutybnmxniursbonpmvmo
 * Smoking Wheels....  was here 2017 zzesdhmlpuhmxualmjtyvqqtpfgsnckgdtcduevgduxwuxjb
 * Smoking Wheels....  was here 2017 lxbgaowsvpkaobcrzoxvcrlzjlogjhwvsvzobmoypszgnbwb
 * Smoking Wheels....  was here 2017 nmiivrpoyiuuothgmypfzsouagydwbbvxyurxdvmfdfhmhyw
 * Smoking Wheels....  was here 2017 ppaqzwflnkrbmrjfpqcaeduyjivwvoyqpjbqfvrvzaettzuc
 * Smoking Wheels....  was here 2017 jilbfoqcgplkevhxgaajpsgijtxfjbuuyuqwfmmffqwrpqyq
 * Smoking Wheels....  was here 2017 qcdsmkxmfyuprphyoscsnhifirbfucaeibnajgvdillirbbm
 * Smoking Wheels....  was here 2017 pmxbyklvpqpqimvdyojqhcpbsqmeqnlwkhbzippgefhgtjfa
 * Smoking Wheels....  was here 2017 qittbruoyfcvsirpzrdcrpxpjjpovjyeavsybgwosxcexuow
 * Smoking Wheels....  was here 2017 jvaqosvkakqrqduqpmzfpkjtfxafizvthiigubaggvtemzpu
 * Smoking Wheels....  was here 2017 rifxjdrjwexyfhkxyprlhmitnmtdnvokrrzoygqugllnbrby
 * Smoking Wheels....  was here 2017 sldxryrpsvvssiaejvgjealbwowpzvwfuzwvfgpymmqtmyzr
 * Smoking Wheels....  was here 2017 wavkzgkpbuofsahonizxylnkyxwcnysnmppdptapzyxqtcmn
 * Smoking Wheels....  was here 2017 tfpexnucrwozcmhkhnlgolrtvmjmfoixxdzygrfaacgegsdj
 * Smoking Wheels....  was here 2017 hjzmlmwbpblvxzfhuylufyghsphtkfggmmzxpfvrbluqnoqg
 * Smoking Wheels....  was here 2017 pduquzbrboeslbobmnzdidxnetvdqrdpvuzwkurhxszpktzo
 * Smoking Wheels....  was here 2017 bjaikhxkpxwzhpzuxjjfrlkdxpjgsaziukmaocxtowlvzojx
 * Smoking Wheels....  was here 2017 ieamzuhzyvzdhoowavdfeoyczfquupazoxguibvjhfdipohb
 * Smoking Wheels....  was here 2017 gzgfmdijdifymimvyodmzlvqqvmvcyumngkucxcopgfktond
 * Smoking Wheels....  was here 2017 aipybiitkrklglfobkirpgrfkycphvyvgmdxpznafqcnipzm
 * Smoking Wheels....  was here 2017 ydbifozqhhtxdrmdznbtsjjnahxsdjmksacitbftfmlokzyr
 * Smoking Wheels....  was here 2017 tnygpebtoaswyeiwqfvvgoyomwpvtvruzlzmuapzuyelhivp
 * Smoking Wheels....  was here 2017 hwuxeysaftxctdxjcemhktvnbxbckvyvmrxydbednomnnjlh
 * Smoking Wheels....  was here 2017 rtjqethqmvhqyetlvgaurbowiylstcbpvucrnqwydbshzetd
 * Smoking Wheels....  was here 2017 icsdbukdyszsadoglntgszbiyrffnszlyeevwjujqlqnscxr
 * Smoking Wheels....  was here 2017 waehlmwehdlxvaicukgwmekwadakwayzxmwtjggphzchbrmu
 * Smoking Wheels....  was here 2017 dvggjovtpcialdhobngyfoyrtotibombdngenmweqdhupteo
 * Smoking Wheels....  was here 2017 jftkyxqbbwnzfbxmptvfijhgqlqfsdfrhlpyykntkrqqchzh
 * Smoking Wheels....  was here 2017 wzslstxogxgerqxybehnmzhhnnapqvghgrmfruhhpotnsrcp
 * Smoking Wheels....  was here 2017 iilhhmlaxzxbrwiihedbsdctivqgxxskctrlwooancqoslaj
 * Smoking Wheels....  was here 2017 ppmasukiabelhcifnjefdszwkojgvzdxhoffyvxlrtlzrlmp
 * Smoking Wheels....  was here 2017 vjpbcqdtwlyivwkjbrmrgxpbefjvzufwkgklqdffugnhlrmr
 * Smoking Wheels....  was here 2017 kovcyegtzpjawyizoeigtevdlpcnflzpjethxboixppiclff
 * Smoking Wheels....  was here 2017 zhnaxwoachxagmbixfgfpeszfqfdpgqtizdfyphzgbpbyjea
 * Smoking Wheels....  was here 2017 kxeyzkfnglfdasvagmbwywrvuqpqltqdqnnteybrkdquofcf
 * Smoking Wheels....  was here 2017 vbpijqomrkfjogbxyutxhkgdpaljhttvyxfximrcbneatazc
 * Smoking Wheels....  was here 2017 qovumwejxpbajwobrhrghgjqmqfuaizecnuujygfghxpqeah
 * Smoking Wheels....  was here 2017 mpdfalyxruephphviijaycchkjmtstmuizavlfeffqrmndsp
 * Smoking Wheels....  was here 2017 gncvzbzabzfwlvmuzoopkvtirofgqqumyeyqanaqnarzzuud
 * Smoking Wheels....  was here 2017 bznynspzfkdwcbpucvjsdraesqpnkuqjpfwduhqdxhjpvefg
 * Smoking Wheels....  was here 2017 itkgcnlftpbxwcjyfgbfvasokjbdvfztelhmteerjjjdcogn
 * Smoking Wheels....  was here 2017 rbbrkxjljgllozuoigegmpxmqtfxzgagvmbbbdynenqqfoju
 * Smoking Wheels....  was here 2017 yfajkqlrdkyigccgnjnffiacubzuelisygfodiobwfiirygd
 * Smoking Wheels....  was here 2017 jwcrhobaghlohytveodvojpxhspcaqofdvavtfxbdgvtiuyx
 * Smoking Wheels....  was here 2017 fwihnwvbhjdkejmkxwgxdeoqxokiivsciqbbvmbmbpvsgkrs
 * Smoking Wheels....  was here 2017 gjadubolylmkvkhhrsnqylygrndhdkaxpfbrnbjowmgftjwj
 * Smoking Wheels....  was here 2017 gsriatkdhmcigijdorqlecexwwqavwyokncgjcmsclgoklhy
 * Smoking Wheels....  was here 2017 kncglyrjntxfutgsyssygiudzcduybhdipmuzcermeggbsyv
 * Smoking Wheels....  was here 2017 crjqntapfrbiamqemvzcynrquzachzyxhwtiirqkbsybumap
 * Smoking Wheels....  was here 2017 yhthxqhoccafuonucmbzckyjhlztzaenkysjqufdbhgawhab
 * Smoking Wheels....  was here 2017 wtulpgoefzlpdhcfwgraayynsuytirmucsjnjqliakhlyzqi
 * Smoking Wheels....  was here 2017 zrhmtpfsunfokfxgeaxxbghpqnajxuovygareqgrsvmvupxt
 * Smoking Wheels....  was here 2017 qxgavvvpihojeepzsxamzuvhujrenkkzwyfablsecmoxmlbx
 */
/**
*  NetworkHistory
*  Copyright 2014 by Michael Peter Christen
*  First released 10.10.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.blob.Tables.Row;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.visualization.ChartPlotter;
import net.yacy.visualization.RasterPlotter;
public class NetworkHistory {
public static RasterPlotter respond(@SuppressWarnings("unused") final RequestHeader header, serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
        if (post == null) post = new serverObjects();
final int maxtime = post.getInt("maxtime", 48);
final int bottomscale = post.getInt("scale", 1);
final String[] columnsx = post.get("columns", "cC").split("\\|");
/*
aM activeLastMonth
aW activeLastWeek
aD activeLastDay
aH activeLastHour
cC countConnected (Active Senior)
cD countDisconnected (Passive Senior)
cP countPotential (Junior)
cR count of the RWI entries
cI size of the index (number of documents)
*/
final Set<String> columns = new LinkedHashSet<>();
for (String col: columnsx) columns.add(col);
List<Map<String, Long>> rows = new ArrayList<>(maxtime * 2);
        long now = System.currentTimeMillis();
        long timelimit = now - maxtime * 3600000L;
try {
Iterator<Row> rowi = sb.tables.iterator("stats", false);
Map <String, Long> statrow;
while (rowi.hasNext()) {
Row row = rowi.next();
String d = ASCII.String(row.getPK());
Date date = GenericFormatter.SHORT_MINUTE_FORMATTER.parse(d, 0).getTime();
if (date.getTime() < timelimit) break;
statrow = new HashMap<>();
for (String key: columns) {
byte[] x = row.get(key);
if (x != null) statrow.put(key, Long.parseLong(ASCII.String(x)));
}
statrow.put("time", date.getTime());
rows.add(statrow);
}
} catch (final IOException|ParseException e) {
ConcurrentLog.logException(e);
}
int maxpeers = 100, minpeers = Integer.MAX_VALUE;
for (Map<String, Long> row: rows) {
for (String column: columns) {
Long v = row.get(column);
if (v != null) maxpeers = Math.max(maxpeers, (int) v.longValue());
if (v != null && v.longValue() > 0) minpeers = Math.min(minpeers, (int) v.longValue());
}
}
        if (minpeers == Integer.MAX_VALUE) minpeers=0; // no values
        if (minpeers < 0) {
	ConcurrentLog.warn("NetworkHistory", "Negative value in plot. columns:"+columns);
	minpeers=0;
}
        if (maxpeers-minpeers > 2*minpeers) minpeers=0; // if we are close enough to zero, use zero as minimum
int order=(int)Math.log10(maxpeers-minpeers);
        if (order<1) order=1;
int scale=(int)Math.pow(10, order);
minpeers=(minpeers/scale)*scale;
maxpeers=((maxpeers/scale)+1)*scale;
        if ((maxpeers-minpeers)/scale < 3) scale=Math.max(5,scale/2);
final int leftborder = 30;
final int rightborder = 10;
final int width = post.getInt("width", 768 + leftborder + rightborder);
final int hspace = width - leftborder - rightborder;
final int height = post.getInt("height", 240);
final int topborder = 20;
final int bottomborder = 20;
final int vspace = height - topborder - bottomborder;
final int leftscale = scale;
String timestr = maxtime + " HOURS";
        if (maxtime > 24 && maxtime % 24 == 0) timestr = (maxtime / 24) + " DAYS";
        if (maxtime == 168) timestr = "WEEK";
        if (maxtime > 168 && maxtime % 168 == 0) timestr = (maxtime / 168) + " WEEKS";
String headline = "YACY NETWORK HISTORY";
        if (columns.contains("aM")) headline += ", ACTIVE PEERS WITHIN THE LAST MONTH";
        if (columns.contains("aW")) headline += ", ACTIVE PEERS WITHIN THE LAST WEEK";
        if (columns.contains("aD")) headline += ", ACTIVE PEERS WITHIN THE LAST DAY";
        if (columns.contains("aH")) headline += ", ACTIVE PEERS WITHIN THE LAST HOUR";
        if (columns.contains("cC")) headline += ", ACTIVE SENIOR PEERS";
        if (columns.contains("cD")) headline += ", PASSIVE SENIOR PEERS";
        if (columns.contains("cP")) headline += ", POTENTIAL JUNIOR PEERS";
        if (columns.contains("cI")) headline = "YACY PEER '" + sb.peers.myName().toUpperCase() + "' INDEX SIZE HISTORY: NUMBER OF DOCUMENTS";
        if (columns.contains("cR")) headline = "YACY PEER '" + sb.peers.myName().toUpperCase() + "' INDEX SIZE HISTORY: NUMBER OF RWI ENTRIES";
ChartPlotter chart = new ChartPlotter(width, height, 0xFFFFFFl, 0x000000l, 0xAAAAAAl, leftborder, rightborder, topborder, bottomborder, headline, "IN THE LAST " + timestr);
        long pps = (long)hspace * (long)bottomscale / maxtime;
int pixelperscale = Math.max(8, (int)pps );
chart.declareDimension(ChartPlotter.DIMENSION_BOTTOM, bottomscale, pixelperscale, -maxtime, 0x000000l, 0xCCCCCCl, "TIME/HOURS");
pps = (long)vspace * (long)leftscale / (maxpeers-minpeers);
pixelperscale = Math.max(8, (int)pps );
chart.declareDimension(ChartPlotter.DIMENSION_LEFT, leftscale, pixelperscale, minpeers, 0x008800l, null , columns.contains("cI") ? "DOCUMENTS" : columns.contains("cR") ? "RWIs" : "PEERS");
float x0, x1;
int y0, y1;
Long time;
for (String column: columns) {
x0 = 1.0f; y0 = 0;
for (Map<String, Long> row: rows) {
time = row.get("time");
if (time == null) continue;
Long v = row.get(column);
if (v == null) continue;
x1 = (time - now) / 3600000.0f;
y1 = (int) v.longValue();
chart.setColor(0x228822);
chart.chartDot(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_LEFT, x1, y1, 2, null, 315);
chart.setColor(0x008800);
if (x0 < 0.0f) chart.chartLine(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_LEFT, x0, y0, x1, y1);
x0 = x1; y0 = y1;
}
}
return chart;
}
}
