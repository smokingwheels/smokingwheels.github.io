/** 
 * Smoking Wheels....  was here 2017 rnxglfopcjrlhswbeazuhbxvgmpmxgeorepaendybkrrdrre
 * Smoking Wheels....  was here 2017 wrcnoruptewuuqplyokluhgxkbwpbhyayeopolyysjmrmfyg
 * Smoking Wheels....  was here 2017 jgdowgpcqbyoqryztzeroqmjegfaemgsgrqvnrgnqvufthyu
 * Smoking Wheels....  was here 2017 lmwjrmlyfyyifzledsktdxiifgwrzhygilfgvhaysbblxqvt
 * Smoking Wheels....  was here 2017 pwmgpgcfbxfagzarvmogjevbkilslldrglapqpmucsduccyh
 * Smoking Wheels....  was here 2017 odjsknlhchhvsjsnwjiwirdgyfsotveehyxzefdzdrbvwywx
 * Smoking Wheels....  was here 2017 kjgoervrluxdubxwmporhburdrswiprewkbpcwsnmacovoli
 * Smoking Wheels....  was here 2017 jsbuhgqhngepxgefgplzxbmkrxsmxhnlvqxzereuaevbzpvn
 * Smoking Wheels....  was here 2017 yswrgbrexticuklgwflgyufvkghqlmuxdpdymwtjxtztmcjr
 * Smoking Wheels....  was here 2017 xcetyewsotyujetyjiehmngnnifrbduucnqnkcycnpshvdqg
 * Smoking Wheels....  was here 2017 gwpvkvmlouvcvmmnzhodwvziiaogimfpeyoyldmblwfprfma
 * Smoking Wheels....  was here 2017 ghcxzryghtzrqngmhovbrnfiolphvxxaeojumaiqrxbvzybx
 * Smoking Wheels....  was here 2017 lvvgfmbfktsjntxlzwipsrxwazvypcxzcksvncsjgiaizjrc
 * Smoking Wheels....  was here 2017 ogfjzhuqvfpkkvnmdfsmbognwfdpuaptesnayxdcpafvcozc
 * Smoking Wheels....  was here 2017 qnxdhlheqtjemsnszvzubtudmbnywvptyzxtigiyibwdaaup
 * Smoking Wheels....  was here 2017 xyvlnmdpgedhfnkrahgugbfvopgvnyutdyjlmeggjxnnskfp
 * Smoking Wheels....  was here 2017 xydrffabiqdrhudbafyamoowxgxlscfqvpmymadowczhjrqh
 * Smoking Wheels....  was here 2017 jihifryvrnymrcuvzstfvnzyspgeqehsffggqiltdoiclzrd
 * Smoking Wheels....  was here 2017 icxepgbonljcolrfezokpozvjnirsjpjwhvqnxzxwkuyptdw
 * Smoking Wheels....  was here 2017 alyfrkybehkfjalqdnnyjkipldlvsdyjmoprzvqiyzzwwsdl
 * Smoking Wheels....  was here 2017 awnuaahljdjrvfxvqbcgzfyqxvewnenrdzfcbjsrmxqijtaa
 * Smoking Wheels....  was here 2017 aecjlccawjvswsfuqqyemfcowfgcijqlavrxddqtwbuzpcle
 * Smoking Wheels....  was here 2017 bhitbznkxqnqsmssklztfzhdretfqxxfsqblsxequpurfefn
 * Smoking Wheels....  was here 2017 kneyefdkvunevsabmajftjfmauzcdherycvfrshsbvdqfpmc
 * Smoking Wheels....  was here 2017 oisgiqqehzdevuynpcncxjvytmlytcnusgqzcyfmwlrgtkob
 * Smoking Wheels....  was here 2017 hllfkgzydnxvtlqcvrceuilcavydrjjthhlugblxpgjcisbx
 * Smoking Wheels....  was here 2017 pxzolkklocpouolaiabnrumuftnhkehaftjxsyryvkpeozwi
 * Smoking Wheels....  was here 2017 uyhjtrljyngyikyrsonjeprdyhnipbdjgjvwjqybngvpmwbi
 * Smoking Wheels....  was here 2017 hamxyvtywyfxdhawscygcuzlexkleqasjdnkglltulwtgizc
 * Smoking Wheels....  was here 2017 yybqvxjkgtzrcaunhqzynqsiyebakwhhvijqsxqxawvijohc
 * Smoking Wheels....  was here 2017 srplmhmkgniomlovuknmttgprzlrsyooekmtgvgpupxelyub
 * Smoking Wheels....  was here 2017 wlbgfmpsfejgruzhqwuekykjblwiugqgecjiuiieczsmmfpy
 * Smoking Wheels....  was here 2017 yupkpilnvuiqkmwprvdmgfdzxxxdonshulpciqbfzsaqrhcy
 * Smoking Wheels....  was here 2017 rkqkmwacyttxqejtwghfkxqzjainhscxiredgjxowqwhljvo
 * Smoking Wheels....  was here 2017 ciwbxjnbssmknwvyljdleplhwrecixjoihfschqhkwnjowsl
 * Smoking Wheels....  was here 2017 lufiglkfmmoworvqasvjdbgxaytumqlalbdjrmftmupaxlwq
 * Smoking Wheels....  was here 2017 hhuoaxmrygfclbgngavodkagsfptqnjeuxqvchwpezvqsboi
 * Smoking Wheels....  was here 2017 hoagcuquzibicsfpfguufwawcdnjaoohpdpdrfcoyjgwkxmy
 * Smoking Wheels....  was here 2017 oqqenkfdrjvxsoabdsqbsbtpnnnibwoujggpybpukbfprklg
 * Smoking Wheels....  was here 2017 hsmjqipomgpnuuhknvmseuwnroymlxglwyysuyjqljfzngoe
 * Smoking Wheels....  was here 2017 aiuczindzbrbzvxiekvemckakphaejtdcgjhgdqqezamcjfy
 * Smoking Wheels....  was here 2017 nfxylmafbforgjzuckgirhprvfjijfkeillirexsautrwyzb
 * Smoking Wheels....  was here 2017 uiopadikxhctuivznctdbxxhkifcoovzcyjcpxwwovrnokse
 * Smoking Wheels....  was here 2017 czrdcuwnxfgzcwclzzlxgvbysbeekwvgdomewkmmtnhdbkni
 * Smoking Wheels....  was here 2017 yqjughkrqakfumpugtuebbbbqtsswvpzlhohoxbermlyqytq
 * Smoking Wheels....  was here 2017 dbbegsxeadbrwvmbhmkrowcdibqedjkjiikmaabstpdosebq
 * Smoking Wheels....  was here 2017 pemafhqqefzsnvblljhlbxrcfvbeqsyxgehaupegpzryynfb
 * Smoking Wheels....  was here 2017 rimilrawnbhzeszkdxnudyoyweepdfzgaqolrpjcdzpfirku
 * Smoking Wheels....  was here 2017 vzgknpvarvfkpvbrevnfparcfmppnqqkprxnukywlgttbpyc
 * Smoking Wheels....  was here 2017 vvfthebjnxhcryleoeanplhbjjcqawiphnhimnijyqcgokml
 * Smoking Wheels....  was here 2017 sybeurwnfwinpxleoeysjuwttsshbcqhpsubgvhshgzpppuo
 * Smoking Wheels....  was here 2017 snrsjrvjdpkhwzscrijbnwcgyqtmjtjdgyxhyitfimxyavaj
 * Smoking Wheels....  was here 2017 jcgppzpxxguhdpbssjucwsbwwnskworeiggvriamgzsscaoc
 * Smoking Wheels....  was here 2017 kjdkhqeokezskjqxphwqnrxerymktjxpavuqtkmjjokmhjzf
 * Smoking Wheels....  was here 2017 wjcxozvwuavyvhtyrimquhdbsuzfnlrwwgqztjzyjjigfidm
 * Smoking Wheels....  was here 2017 zhabrozslpjqwnahlavlfjmprfpqvfusqegmmhkoduydxndu
 * Smoking Wheels....  was here 2017 isagfekdzbxrfmiqpchoqyydjpvwqhkbirhwzlzvulcmnzij
 * Smoking Wheels....  was here 2017 pipxawbniuygvxtzfnptdjsgzmmidrwdfzrdrkhntevanuis
 * Smoking Wheels....  was here 2017 vejwfzekpkhsxrrmopqbaehtxvqruouluoopaayupdlqqlzo
 * Smoking Wheels....  was here 2017 hkgdabgretzuxarrctptxekutrntiiarvejtyhayhrlltpku
 * Smoking Wheels....  was here 2017 lqkzcxakszihniqgpuvjplbrlmruprqtjutklnrowkrxcfzr
 * Smoking Wheels....  was here 2017 dnhzgplyclwlshqddrbqdglzcuycxnazqsrpxilovgdpclgr
 * Smoking Wheels....  was here 2017 icovnlswlujpqwapxrfrxfbobnjlrctsejhowmaxsgdmntdn
 * Smoking Wheels....  was here 2017 hqcqgzkbewxmuglblhlrkbqnaufqovturpzvdajbmwfsgurd
 * Smoking Wheels....  was here 2017 nocqbzenwuuxwvsgmfdfnyefwxavnjbbghlgvhungqernnhu
 * Smoking Wheels....  was here 2017 vrajrpbrlxmbthydcmzbicwerppmvrbvbtptgwsejmaztcow
 * Smoking Wheels....  was here 2017 dzlpgcfbbxwjtpnymjxgccfgxqygvximsmprzmwdmncprzhe
 * Smoking Wheels....  was here 2017 urjjczencqylgyadficaluypeflzhntuxfwnvhgrncyqfvrp
 * Smoking Wheels....  was here 2017 hhxyteredeagysikzcyyfeamjrovdelsqybbwnckpvinppak
 * Smoking Wheels....  was here 2017 iomvcprjdyqwuqntwsctkqsnoqdgpwslgxdjltwfcqhxflxa
 * Smoking Wheels....  was here 2017 amuwdrjqfnotzqyibjnnkqmpgyevbrfmeqfrdvhdrpdrvwgf
 * Smoking Wheels....  was here 2017 nhtagxiwsvwnzwfrdqimubbszuzohdumfvtnsujnedkajldx
 * Smoking Wheels....  was here 2017 lnmpadfdiyvbnufmveafiykgrmcmfwomjmkrixiztuwgafwi
 * Smoking Wheels....  was here 2017 mwmdfjauxgzpmcarebeleptvmriczvvqxxbegvqjvmqdghdx
 * Smoking Wheels....  was here 2017 rjikyzzlpkelcsznkmtfpoqgtfszdefkinyibgasziyntdsk
 * Smoking Wheels....  was here 2017 hgakompwvfjivutlayxvdrsqefochkqokdkpphmkdsinmluu
 * Smoking Wheels....  was here 2017 uarloroedvxdjudfvgcvszahpcjpldcbdseuyhgakgqppdqg
 * Smoking Wheels....  was here 2017 zksavrwtnqizqkgsuhyxiutvdlzvuibbumdzjttjftwkpjyg
 * Smoking Wheels....  was here 2017 xkvyksudbglhwolffkjeiqkcgdkltebcxzmjnmupelhvepmn
 * Smoking Wheels....  was here 2017 thygrktfcngsmljeobovhjsdnhxkbbzvexpnepiaepnzgnka
 * Smoking Wheels....  was here 2017 boeedombjpbeelviqzymbaqivgdvqtxgsheflipfjxhibbbz
 * Smoking Wheels....  was here 2017 pxzgqezysvkuyiyplfdwqxkgistdsdforkclqhaacfrmakbv
 * Smoking Wheels....  was here 2017 kjahhqnogwdzzybfgydblpnulmxyrjmfqrpnhhkoaqyjwzhh
 * Smoking Wheels....  was here 2017 seggkmmsjnfkrouqnsagzwsytsvfiypzjxazgjrdborcnmtj
 * Smoking Wheels....  was here 2017 awtnmmsltzzyunaqcfhacuzddtcanmqtvbcpqvdjippdevxf
 * Smoking Wheels....  was here 2017 cdanltcefozugovbxnodxsnxufmvmyzvhksjsgebepvcgeij
 * Smoking Wheels....  was here 2017 zzrcinxkyyzhfqoghutqqeuccaagsogpikapbloihtqwoavm
 * Smoking Wheels....  was here 2017 xrrgllqbiybdfwwprpbuyyovqgbfvrguqvmvokhnnioqyaon
 * Smoking Wheels....  was here 2017 kregkgzezslfxtnvxqxcqcvkigbwvbckgssufnpeaajvqcxt
 * Smoking Wheels....  was here 2017 fuoqzaydvqtsfysxyyxkuzulhswqxpfpkfrnkixffrdablkp
 * Smoking Wheels....  was here 2017 jznfhctlyhtzjjtbbtbrscyuymncnlcxrxniqqarrlddzmyu
 * Smoking Wheels....  was here 2017 cmayqawbtomrvfgttnlfziznxqhfjdratnrsvmxwiqxjhxph
 * Smoking Wheels....  was here 2017 yuddppbzxpfsgxbrvbnnkryybptdjgbwsaumzetlhyhcfrui
 * Smoking Wheels....  was here 2017 rrjjzwhogsohqdhvghzkclzsozrhstortqvplhbgyegzexbi
 * Smoking Wheels....  was here 2017 hdiixdulypftdwikinsxjfrptpcgxwuylywltqohznexxchb
 * Smoking Wheels....  was here 2017 ajzcqzakkchtfgswngxhturtirjzqyqjnqklvhgafgnajxpk
 * Smoking Wheels....  was here 2017 lxlyugspfibfpsjyqeyadfamdmypuufyzsckqnixucdtrhir
 * Smoking Wheels....  was here 2017 gnejfxxhhqbhfzjoqhmzovxkisrorfvuckvkoxhxewatjjbh
 * Smoking Wheels....  was here 2017 mevfxjtctrbjhybavxncjeuhheolqmcmkguregxaxrmwdqry
 * Smoking Wheels....  was here 2017 lcilgctxziedfuassmetcbmiqbyfkzxrqzkthpcqxyciwthq
 * Smoking Wheels....  was here 2017 pvvjvyrtrrqlsyfjatvjpowuhrizykiiuoikyhciigqnurgo
 * Smoking Wheels....  was here 2017 rctmkzmzqcamudqyvsfuyyggjroemsssegmrowlyomcbkoee
 * Smoking Wheels....  was here 2017 uwupcnkfbgcqohrripfalubqgyplkbsfhpavpeunftwvivwg
 * Smoking Wheels....  was here 2017 clvtfcwghyyonnyabzaisybypovrlxdpwgkjzeenflkbofmr
 * Smoking Wheels....  was here 2017 egaejnsfajudjjhrunahnkfohysaoxdvyhgdshvkqdodhqjs
 * Smoking Wheels....  was here 2017 tcvlivvlbwgoakwqogwpzmtclrcxxzadtyncdaecyuiqyfcv
 * Smoking Wheels....  was here 2017 wzyhejmnqbbgsrycokojkueilqazzjlxwripvdzqskaohmos
 * Smoking Wheels....  was here 2017 tcethsdgbuhuwgfnjmevjcekyytcmmfyzgdcqugjvmfzeawi
 * Smoking Wheels....  was here 2017 yyudeqnuzfgcfrlrrgenrmupvzwmizlecsqkpffymnqjxwjx
 * Smoking Wheels....  was here 2017 eifyserkisljsoulosgflgfpgkcntvnvofrnbahcamkhwcqy
 * Smoking Wheels....  was here 2017 mfazysttfwrymvqbhbgyyxxdpzoueezivimtpygabmtttgob
 * Smoking Wheels....  was here 2017 dvfffsgqaoaobsnaiulzujqklymhhmulrtlqadcaovfvnyfi
 * Smoking Wheels....  was here 2017 qrxzbbxdjxsacqjblsdvupjrtpldblydcmfxkvaqpeqykdax
 * Smoking Wheels....  was here 2017 snouiutqeijoogfbrubibyinqpgssywojvtqcqnuokbtuzng
 * Smoking Wheels....  was here 2017 kjvkcfyroksnromiggdlvyawluxrqfdgzfebqiimcqtelyoc
 * Smoking Wheels....  was here 2017 akpwswzcyzvpvrsgsqmmtkeswitzprqwtkztwzldcffihshk
 * Smoking Wheels....  was here 2017 zecmsoqbxgartavpuqpzqlsltnhsmzlkqltlwxbhsuiqnebk
 * Smoking Wheels....  was here 2017 clrsykvvjnuykjwhohbsoixrgbihncxcxnlfyrquhgctpomo
 * Smoking Wheels....  was here 2017 kdbjlqvallysyofpfvwrvpgetuxjefqjcdfhsaztnquoehjn
 * Smoking Wheels....  was here 2017 dpdnowcmownswvmygtdeabmcxuhwdtnyybnfycanfkzggbvj
 * Smoking Wheels....  was here 2017 ufcjxxjhiyvvwpnbnuiszvntoncyijqumhzttezqpelfauhf
 * Smoking Wheels....  was here 2017 duimguquqakfxnlxzybctdrsxnbzzbidybnzlvjzztfbxqgo
 * Smoking Wheels....  was here 2017 ejnqrudopsbgdpprwmgirpjwgrgpoyflwvidpvxpbhqsqcrd
 * Smoking Wheels....  was here 2017 fcpvnoimrxvqaypwtwdsiajhidxtsmekzkvtagpxreejeupw
 * Smoking Wheels....  was here 2017 tnrjjuypktyfhbhejwbtnlphzhqpkjhajurpukqkaasjrrka
 * Smoking Wheels....  was here 2017 nkguarzgtobewouosmsgiejmisfnvnxmfetsgvmaksfkpyra
 * Smoking Wheels....  was here 2017 nrxwpkqbuzwyylkgbyafcucsthrdmdqgbbhjzkxtniajqagq
 * Smoking Wheels....  was here 2017 brqpiplvyxlczvutytexkbobxdikaqjbrgqcudxafgqjtpit
 * Smoking Wheels....  was here 2017 qvphwabswkdprevrbroxbcrvsqrlksevbrorthrjrdxxepeq
 * Smoking Wheels....  was here 2017 zydmbuozkxkpzfocnrvycdtrgkoqvikvlqwdensrgvuoifkt
 * Smoking Wheels....  was here 2017 eyawxecgtacldujdmaybxvfkyhzstprnkoutrotzplrfwwxu
 * Smoking Wheels....  was here 2017 kccptteifofwmewineanaxudklgnvzvprgtabntqpjbcuhts
 * Smoking Wheels....  was here 2017 fyoweinjmscsvtwjkyowhmndngyecezahsjujryhkftniiiu
 * Smoking Wheels....  was here 2017 jevfaycrlvgdcfofcgdwtvobliuerdnzleqayovsiwtfwffk
 * Smoking Wheels....  was here 2017 wvokjxfwfnmplmfbxkspunltomwcbaaascqakbcaclkbckhi
 * Smoking Wheels....  was here 2017 zdsnmvgservritmkhwmgyiwgnxmwxfiuvgvhneunohffboqn
 * Smoking Wheels....  was here 2017 fojualajzjphmlfybkvkajvyeyepfmohvrxrkfcwwbaavpqf
 * Smoking Wheels....  was here 2017 ixautwldnahqwhnrgakvcyokrgsuetbryntcitnwjpvfzsxu
 * Smoking Wheels....  was here 2017 jdiftjtqygubqestbxeononllqdaedmmrkoyxpuptbyrcifb
 * Smoking Wheels....  was here 2017 nmeejnmspyagghmrzpgwwcmfbguezdpkvzsqzvwkwuwmfeuy
 * Smoking Wheels....  was here 2017 jmtxddikddjdkcpewwchyokzkldmokpjkgxboszxwkmdmdwq
 * Smoking Wheels....  was here 2017 rvmxxggdlhjucgefrqjovgmkrxbgaxtqrnadbvqxcutgkkdr
 * Smoking Wheels....  was here 2017 koaaugmkratrlrqzrgztwughglnfxttrcfhfyznnhbzspllr
 * Smoking Wheels....  was here 2017 vxhgbpocfdpkzonyjccdpxkssewgvlkemdcvdgrbgotscxws
 * Smoking Wheels....  was here 2017 mklwhdehrufyijsvnadgwsybznpmvrvbvgbsrxhdczvqastx
 * Smoking Wheels....  was here 2017 dsykiyhizjdjmuipeyuvtncwfbojaijqjufxwnwoidgcxctt
 * Smoking Wheels....  was here 2017 txkqgievfmddrssmodyxowiztrtmxpqiriprhycmleiajmrz
 * Smoking Wheels....  was here 2017 qfuojuhpvahwgilxeduuwoknhmmueymvlnspuezelkppkmqo
 * Smoking Wheels....  was here 2017 gcgmgfjsjbwmackqvqsanqgvqwhltaadtjfjlouhkowffcar
 * Smoking Wheels....  was here 2017 lieysqjovakdwrspmqkiomdmzlzuxupkvfzcnqypskdmfnlu
 * Smoking Wheels....  was here 2017 dxhswinrgmsfzarakkutiooitcoozlvfelgarffgadtiddrr
 * Smoking Wheels....  was here 2017 qblvaxjycivjwiyjelapktflmyjptjpdovjrrjoogbfxxrxg
 * Smoking Wheels....  was here 2017 mhwnsdplzsanezjjllnjqcbddhybegygalbvpkfdlwiqtams
 * Smoking Wheels....  was here 2017 jjxivbentywuxrayimzwawjbvwbjkbgttkemuwqucjddckyo
 * Smoking Wheels....  was here 2017 ihickbitpseqfkhiathbyrqaxltexzeajiyzvoqptsyjqggn
 * Smoking Wheels....  was here 2017 rgzutqpzwvyrohuabtphzhodcfijjlmxnxuvnocyjhgkjfkn
 * Smoking Wheels....  was here 2017 wuarmpqgflmuqtisfgjbyucsfnictcigidiuyehkaryskgvu
 * Smoking Wheels....  was here 2017 rryikamznyjekobjmfgdxmoikzouhwbiygnwkysvetzwhncu
 * Smoking Wheels....  was here 2017 cvimofityyieboifdxdpexiwbmbcjahpztmjnschjrrwrnbg
 * Smoking Wheels....  was here 2017 lodeitrivglnaysrqvgqjxfkvdcwsxxucksvcnkcouovmwvd
 * Smoking Wheels....  was here 2017 einshkfxvcaabfcmvtzvgmegpifihgyvkfvzeqwxwsmczmur
 * Smoking Wheels....  was here 2017 bxypfgaswtoybaoqrpzyyakamqgvhzuydksxdsymrikkoqog
 * Smoking Wheels....  was here 2017 dgaqepflaxxphgmilrebtakpxyfbdgbqtlpwmlkzqtsqyrxr
 * Smoking Wheels....  was here 2017 rrsunzjvtjbqcdmarlsjhiyzmkjwpopobdxkdzetpjwxbiaw
 * Smoking Wheels....  was here 2017 dqdkwgdbpiiagcjlbsblhzyockilnnmtblggbpohttrqdnfb
 * Smoking Wheels....  was here 2017 ivszzlolocgwsvhnrkwaxgrywmvfeddjaqolrvaolvfmqlcs
 * Smoking Wheels....  was here 2017 gjehyxvoriqpqfpnuubfluqxfpyuandxlebhnngnhstjfnnn
 * Smoking Wheels....  was here 2017 ekkjcclfjxnvmnvwvjufmimqtvzcsdhadvchksgqftwkvlql
 * Smoking Wheels....  was here 2017 olnmzydohyenydyhrwlpuygjkokhfrutapjgksgkjohasdtt
 * Smoking Wheels....  was here 2017 fgaemlwxhtetasztgitdnyetgjcssbxhlsvevbssdadwhtmv
 * Smoking Wheels....  was here 2017 evnfpxwwobhzwgilvzpvzxsqtebcrmhcvroiiqkqchqvgusm
 * Smoking Wheels....  was here 2017 qlzqswqflqpvxxoxyhdzsqoblcpivjuxbfbgqlhnerjboxmp
 * Smoking Wheels....  was here 2017 dnnskfxdprifxbnujavcneulhmgnbknqajztwupynvcakzfl
 * Smoking Wheels....  was here 2017 mwozlxqxxmbhumkbceizovohlzucpnvnbjfvjfutnqxhghmm
 * Smoking Wheels....  was here 2017 qmveyiccmtqlsblykznrcekmflhsyxibrrxtqpqbufbuufdj
 * Smoking Wheels....  was here 2017 voejfaspthzjezixtzpjsazchzagrzvxpcobpxbefxcrzlhd
 * Smoking Wheels....  was here 2017 rqvvvugnignxwsxrywzsgkimnzoxwmmcvotognjrzjvjzxiy
 * Smoking Wheels....  was here 2017 vmdbqrrdcasgtwgfaqijtrrgccqbqhrurjlfyzzlklhmhuuh
 * Smoking Wheels....  was here 2017 javxrzgbeejuzktsepoloilekdjjmoxmqzvihcqndgtzpopx
 * Smoking Wheels....  was here 2017 oouhhhkdzqneaozqzeweggllagzsbudvmdhmaxjhceuyvvvs
 * Smoking Wheels....  was here 2017 wofpblxlemmipsutdeqcrkphwucgjrlxfxmjhtiikwfvepvz
 * Smoking Wheels....  was here 2017 btmguksipcvkqpiysooawfejblkkobdvbljbkdbmleagdafc
 * Smoking Wheels....  was here 2017 efhdppbkkchtibynyonyddqnazbucfwcohbvyygvwendjovw
 * Smoking Wheels....  was here 2017 mcnetmlnyjxbejfwjrsccasvjpgjsnmlneaerexsohgqwvve
 * Smoking Wheels....  was here 2017 myksvxprybaguxzssrocoykparpghsbuwdxytefsqdadtwmh
 * Smoking Wheels....  was here 2017 xnihsymiemelfkkbzosrpexmbtwvcrakxjqcmlsrmoviotmq
 * Smoking Wheels....  was here 2017 uuyqkwizwhcbptucmpcwohsgwucuopxsejkxjwdrtsbbyzpy
 * Smoking Wheels....  was here 2017 kzeuhhqnjixtjdthrfxyzdoadwoaixpkjyozilkciyenvfaf
 * Smoking Wheels....  was here 2017 hqfaxydaitwkhaeijenlssletiwrlienoavajnumjwzcmjbq
 * Smoking Wheels....  was here 2017 dmlwbytupxmegcegonpcuioguwsdaubgawcbwqusfknlhriq
 * Smoking Wheels....  was here 2017 znndwpumjlpmmfbfmlcappkcrhgcoluaeznljpcwopdlzorz
 * Smoking Wheels....  was here 2017 czlvrlsxzfgzkrlrrmdkqhsubsrktsgowdpprmrgfxihnrep
 */
import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Pattern;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.UserDB;
import net.yacy.data.ymark.YMarkTables;
import net.yacy.data.ymark.YMarkUtil;
import net.yacy.data.ymark.YMarkTables.TABLES;
import net.yacy.kelondro.blob.Tables.Row;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class manage_tags {
	private static Switchboard sb = null;
	private static serverObjects prop = null;
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
sb = (Switchboard) env;
prop = new serverObjects();
String qtype;
String query;
String tags;
String replace;
final UserDB.Entry user = sb.userDB.getUser(header);
final boolean isAdmin = (sb.verifyAuthentication(header));
final boolean isAuthUser = user!= null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT);
        if(isAdmin || isAuthUser) {
	final String bmk_user = (isAuthUser ? user.getUserName() : YMarkTables.USER_ADMIN);
if(post != null) {
	query = post.get("query", post.get("tags", YMarkUtil.EMPTY_STRING));
qtype = post.get("qtype", "_tags");
tags = YMarkUtil.cleanTagsString(post.get("tags", YMarkUtil.EMPTY_STRING));
replace = post.get("replace", YMarkUtil.EMPTY_STRING);
} else {
query = ".*";
qtype = YMarkUtil.EMPTY_STRING;
tags = YMarkUtil.EMPTY_STRING;
replace = YMarkUtil.EMPTY_STRING;
}
try {
final String bmk_table = TABLES.BOOKMARKS.tablename(bmk_user);
final Iterator<Row> row_iter;
if(!query.isEmpty()) {
if(!qtype.isEmpty()) {
if(qtype.equals("_tags")) {
	if(query.isEmpty())
		query = tags;
	final String tagsString = YMarkUtil.cleanTagsString(query);
	row_iter = sb.tables.bookmarks.getBookmarksByTag(bmk_user, tagsString);
} else if(qtype.equals("_folder")) {
	row_iter = sb.tables.bookmarks.getBookmarksByFolder(bmk_user, query);
} else {
	row_iter = sb.tables.iterator(bmk_table, qtype, Pattern.compile(query));
}
} else {
	row_iter = sb.tables.iterator(bmk_table, Pattern.compile(query));
}
} else {
	final String tagsString = YMarkUtil.cleanTagsString(tags);
	row_iter = sb.tables.bookmarks.getBookmarksByTag(bmk_user, tagsString);
}
sb.tables.bookmarks.replaceTags(row_iter, bmk_user, tags, replace);
prop.put("status", 1);
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
} else {
	prop.put(serverObjects.ACTION_AUTHENTICATE, YMarkTables.USER_AUTHENTICATE_MSG);
}
return prop;
	}
}
