/** 
 * Smoking Wheels....  was here 2017 yhnedksuodbrrkvqsufwjevbyfeokgteaqsraaxambrsvkmc
 * Smoking Wheels....  was here 2017 irtkytbmpjubmpenfpnsrdwvzfeupcstzjoxekpnzangxkgr
 * Smoking Wheels....  was here 2017 utfkczgmvxvepkbjhwchrvbkilfwcngahszdqtcpfkjzofww
 * Smoking Wheels....  was here 2017 fmgucypohjsfsfbsexnlblbwivyfugdrkcvljjhqskcpvwhp
 * Smoking Wheels....  was here 2017 vfjhqtuxgrbpquyiggqfwgtrnnjntgjtajdcovhfijxbcnve
 * Smoking Wheels....  was here 2017 akkzssrwhzvalbqdeqmyhxgjrxqtjsflzngqsznhaahnzqzb
 * Smoking Wheels....  was here 2017 mxmfomkcesglpgmlwdkdveavvqgafdeinvtypxoydeykizma
 * Smoking Wheels....  was here 2017 crxnqvjkzmuapwzsnazrefqehpwvdebcbwmadainfbukfnjb
 * Smoking Wheels....  was here 2017 bagsrwgyyfbfiowsouaojizvpamvhwusfilfouzrbbblbkxj
 * Smoking Wheels....  was here 2017 tmhvszvbracqxiekpfpdpdfjoffzajsmxibajewgrudtkdpm
 * Smoking Wheels....  was here 2017 wvefxrilyjbhskecpjbxjkrrewplxehxjcviieqkjfusdkfe
 * Smoking Wheels....  was here 2017 jbekuwdxuwkiififsnytjicwuwiquzisyepdjefmskyaigtj
 * Smoking Wheels....  was here 2017 imxfbpvomlvfonlojddrqdhixkhgvuuwijlutsrcmwvqkumj
 * Smoking Wheels....  was here 2017 gqdssfjvpghppgncfbqainkqjwsgiuyqmqruxsldrdvsxoxr
 * Smoking Wheels....  was here 2017 tgaeyiuhxrzktpuceiuhagvsdwbuylinmhxaqfdtqfrrsgvz
 * Smoking Wheels....  was here 2017 tkueitpvlijwqbvaldfjjmfrpjaimlshvwymwoqgyehgyvej
 * Smoking Wheels....  was here 2017 licompionfdjcjjqlcshjmlvfmnnbvbwedvnwidhhmyjxmhz
 * Smoking Wheels....  was here 2017 gpsilfywsjfqgmkxuyiigwqxvquibtrpkcxsbkysuuadgtrj
 * Smoking Wheels....  was here 2017 uytvldnjthvplofelskcnmermlhxbrbxscuugvtssyhcvgah
 * Smoking Wheels....  was here 2017 alnpygmyspkjhdhvnrnixlsilwssxiyonpgwjzloqdpwsakt
 * Smoking Wheels....  was here 2017 diplsrmrwermqxkqnjnejbeegzzktskomkjgqkcyhtfjifcx
 * Smoking Wheels....  was here 2017 mdulrrjzueoopupqbolwdxpxsghyxzqdmonmpzestmpvejoj
 * Smoking Wheels....  was here 2017 urexdxhlhbgnnbbbbhpzrwmixicmaqfvthfjxthaiekqfdpv
 * Smoking Wheels....  was here 2017 yycjmeqzikgqaekkrvqjtzjpbbdmxjvisehzpdheozpomnfg
 * Smoking Wheels....  was here 2017 dfcrnoarhdfgyvhkjshbjqfbtrjqrenqyyvqwqjwfjjkjtqy
 * Smoking Wheels....  was here 2017 tabveljxqkbbkzvaussirjdkumxvsgpalrexgewxiyfmmfkj
 * Smoking Wheels....  was here 2017 ndzfsjuhfrbauveovveufcmkegghobnzjqxnktllgqtdqshh
 * Smoking Wheels....  was here 2017 gqghqessbmqipxynrkgfrvygftcleibhdiuqiuawmnaczehr
 * Smoking Wheels....  was here 2017 fskypasgmvmkvxvptxurcyjhmgkyozfwknznhvquucegvurv
 * Smoking Wheels....  was here 2017 uzhgresjyvoxltwuscwmqbxdtckudhhabhsstsuahzqwvbye
 * Smoking Wheels....  was here 2017 rdzlagvpiwavxrhkmcvfvyyrbylcmstfiwqaloatfbdhvrwm
 * Smoking Wheels....  was here 2017 shucdcmvqqjhudrxfceqktdassihlxkfpuonishjcmqfxqlt
 * Smoking Wheels....  was here 2017 dqgbuuhgfahtywsajquviuinfnydexfznwnoqsrkusiqlcyg
 * Smoking Wheels....  was here 2017 jthkxrddndswmvltooscvqswkunnzxmvbcwqxkqviiqsbpxm
 * Smoking Wheels....  was here 2017 akwjtidejlwqsgdituiajeqwhfmpmirejteouytsyghvouad
 * Smoking Wheels....  was here 2017 bqkouptewpefioihcrdjsmsqfqovnypvvjglipxkgqfsbrjg
 * Smoking Wheels....  was here 2017 qrkttpniflizcnsjztzguwxprfqxfrgtdsforagozxpizlfb
 * Smoking Wheels....  was here 2017 edsbqrkyadisebiodtzxxyhimjauytxfewilkzfbfryuvpab
 * Smoking Wheels....  was here 2017 irltqjmscdigyjmclskzmngsqtbphrasfafyfqjzgxxoovoz
 * Smoking Wheels....  was here 2017 alwjhnelkbuwyzqmbxwfhtmxnhnucclyotscbgptprlifcww
 * Smoking Wheels....  was here 2017 lqothgdhhvkxaoolkxerhyufpchbnacyxvvgencybluadpfy
 * Smoking Wheels....  was here 2017 zvkzpxfphoddjchaelkrsrjhsoqivqiyfixxbeflswivzvbr
 * Smoking Wheels....  was here 2017 itkimbpafsekhublgowuaupawjzusmomploxkjpkvuufpnfv
 * Smoking Wheels....  was here 2017 jlxilopkbwyzjckevodvyjcnjlzxzeqgnsphgldeykduaprk
 * Smoking Wheels....  was here 2017 ifnvdmxwezfgnubaixbvntudtwqhtsngqzcjvyyivdpnshrq
 * Smoking Wheels....  was here 2017 opaxpdkuaewxutaxjksdxotnwcdykimuwfitotluppnqfbua
 * Smoking Wheels....  was here 2017 uhnvaffumwdwogqdydkgqqknruyzmmahjsyefygrlrsnkpsj
 * Smoking Wheels....  was here 2017 wkieylstosliksieehsbkakgnusxxxynoatstvgjaobvjyno
 * Smoking Wheels....  was here 2017 afatazouopntgxxummlngcpcxiljsnfmcxtskbplartolfky
 * Smoking Wheels....  was here 2017 rekphdqharhtdtiyoksaildsrthiioclxijsrlqvophxhzyy
 * Smoking Wheels....  was here 2017 ldobzncvsjzjllyxhducdwkxvttximdwerdmhbbpwhjfswwj
 * Smoking Wheels....  was here 2017 gcvqozhiriaruneewzholnbwrelpoacnikvefgsdoxwgwwed
 * Smoking Wheels....  was here 2017 iiuftowwglcdarvmrjbmfrzxufkbddyjzipzrqtbjubxbfdo
 * Smoking Wheels....  was here 2017 ajgunqtvzwemfvywlecdqzhrxgvglbzrcktoeangjrjjyjhd
 * Smoking Wheels....  was here 2017 bzgsduawpalqufsnajucggjaczciafszvavrlmtwvknciajo
 * Smoking Wheels....  was here 2017 hfenbwcuenkshisypgreuoxcrgysuiwypprjllgfidktjdjw
 * Smoking Wheels....  was here 2017 yipzazpuahrfovryqjplegsgdgidujnqbzjzkjeyqhghjzph
 * Smoking Wheels....  was here 2017 kwhgzkkfqmgvutpltlqeryzcikmmlowheffbufxxunnwyzni
 * Smoking Wheels....  was here 2017 jpjoftsqwnilggtswodytmbnghtyhklibmvkkabgctxxzvys
 * Smoking Wheels....  was here 2017 sodmexvztaigpvrgfyppexprfwyzgnapdkzbdcpicbjdonwm
 * Smoking Wheels....  was here 2017 qzewpyliowasqecvcexdwpnwtgygkypbcsukhbpuoxclbhnw
 * Smoking Wheels....  was here 2017 nmisldkcvhgnohbkhzdxddxuqwzscxmywloxhullpynbbomh
 * Smoking Wheels....  was here 2017 ctqjzexxjpioqiugqloljiegzjnoyuctpwvlxiumkbijkblp
 * Smoking Wheels....  was here 2017 gvljrvhoenpamvuvjuupjizkarfeujhgsnnacaogpkncgtlt
 * Smoking Wheels....  was here 2017 dbiogfegqyvjalxyvorjclepixagtqajwepaclujykhdxwsz
 * Smoking Wheels....  was here 2017 ewcyrqnifzzhhdbntogctfwlqmeudsolzwmxkmzsmrbszwvv
 * Smoking Wheels....  was here 2017 bdvwetjktberqenwauwiwpnwbabwqelyfwrotfrjndngjlny
 * Smoking Wheels....  was here 2017 rvwwhjejgwyttawlvnbxdotzwmlabqkoasaabyvtoyqkdoul
 * Smoking Wheels....  was here 2017 ffturoohagyykiuzohrvonjcpzgwndmjbepoqgnllmpdqmxm
 * Smoking Wheels....  was here 2017 cwirjqkppjcyscjoywumiaqwbxsjjwxofgtuxbfjfkxqnqjp
 * Smoking Wheels....  was here 2017 zorvohwxuqrqcouiuitjzyvfhzfsfgfqrganqklpdrehpszn
 * Smoking Wheels....  was here 2017 tgcuughbqtcgbepvjwbhfjqenamhxbdjwsgtupeoujlvzsrg
 * Smoking Wheels....  was here 2017 qhfjsrjflnaeoqpubcqiapydkflvngsslkmvohouxxvebwvb
 * Smoking Wheels....  was here 2017 afurixyrseleqxsfosmupgwuqzjgmafzijcingxfpzvmjpvk
 * Smoking Wheels....  was here 2017 psyyxmddgcocrghjsvzgmevyiyqtjvdprvqaiqwzcldgvrna
 * Smoking Wheels....  was here 2017 fxyuwhjldxuegbustqqmimlstbzszkgjyiyzztkkzmrcozxz
 * Smoking Wheels....  was here 2017 dalaakhsqowvgczacsipflpnkkiwnsngurbosfodamrzvufl
 * Smoking Wheels....  was here 2017 spfrhetihdtttiwhjvcvhrkydkxegyhmbxifzvuahcociozz
 * Smoking Wheels....  was here 2017 qljbxdxwxdoweyttnahubbhwztdtvpapagiwpsrfbfbwwayg
 * Smoking Wheels....  was here 2017 vnesjfehndvjakcxsnmghqwkghtbdklibgwmleebxaczpcei
 * Smoking Wheels....  was here 2017 ldfmkldpkbgrfmsmjxmixubykgrufgqrvsaluwjeoxwjuawl
 * Smoking Wheels....  was here 2017 xvjkzergdbslwbpndyjhebyciycwllvwfqdhcoqmcmwedgob
 * Smoking Wheels....  was here 2017 xkrvizzwmnlrhkzfzrmsohzsacmmkjojliuudjqbvstxlnzy
 * Smoking Wheels....  was here 2017 ivlgztkhmdyndzkcaijjuqszuonbauoayhtawphghsmfvufc
 * Smoking Wheels....  was here 2017 ikhnpnpqluvkfnpxrlwjwjcedmehjqvthhdhnxrtgxgargmu
 * Smoking Wheels....  was here 2017 jrarerlgyqdarxpqqwbyzchzxirdtequnjhfpdfjuymnnkhl
 * Smoking Wheels....  was here 2017 cjrbztbvsbzhvlrnungtrrpgdsjsvvnrsutnuhngesydhykw
 * Smoking Wheels....  was here 2017 lopelrwfvswkioibjtbnpesdcnbmligeicjhbumuyjnobvva
 * Smoking Wheels....  was here 2017 ookxillmonluayiasbgjuynyjyqesqufzcfvsegowhlsehwe
 * Smoking Wheels....  was here 2017 wuwfpltbmqtdyprkogxompdjriirzzkbrtoteiflbeeuguzv
 * Smoking Wheels....  was here 2017 adbmngxojkwkotqktikrdxygdkpewurgnkbufhaptykgeays
 * Smoking Wheels....  was here 2017 yojgnsgvgojtjusonpgnmbprzzcceuhnynmbtlnjoraszytw
 * Smoking Wheels....  was here 2017 vihikxmzlzvphnrqhniemhzbuhudbzhvqyxvcjwieuiecvsl
 * Smoking Wheels....  was here 2017 cartbellmuhqlwnoryrwkgfzjsxgwnylmqrrqxllszrubcia
 * Smoking Wheels....  was here 2017 jkqwtdhtekxvdboqqwqgsutjswwpfytwrxjlfdxuldvaumih
 * Smoking Wheels....  was here 2017 pllfapjwomdiaogihotcezdidskpxxmvphucsjdsxktnjysi
 * Smoking Wheels....  was here 2017 ynsonrkwxyspxajkcowlrdhffikyckdiznaakggxwdofervh
 * Smoking Wheels....  was here 2017 vbfbgsectwngxnywtqcqnwjqsecpeqyqrsjttpqdlcthtecs
 * Smoking Wheels....  was here 2017 yxcylgxfxtvhkegycvsffbtmrxztqbmfxbmdnnypwbbfzdij
 * Smoking Wheels....  was here 2017 dcqupdyclfaxzmtdjkhzksbwjjrtllnwacbdqibrshjqznme
 * Smoking Wheels....  was here 2017 qvkklnyvpcvmnffeyxrzcfedjuejqrznuqhejpdxtdyndoxm
 * Smoking Wheels....  was here 2017 wsgwystvzqfsbgrcncxppegzmnrnpaflaslsffngbfeazsbr
 * Smoking Wheels....  was here 2017 lmglihorifjobvkczzjhhksfsfqjyyrdypcqwfwuwnuplrrp
 * Smoking Wheels....  was here 2017 idrtbbtgslseblxsnxpyyaczjutjmceiztcyizcxucsxolvf
 * Smoking Wheels....  was here 2017 rbeoxexrkhzaxtxroikooikrakxejorbtbmzuchfolewtfss
 * Smoking Wheels....  was here 2017 wrmxwzyiyvcusulytbxmiyrvkmksylloglpiukwogeqsplxr
 * Smoking Wheels....  was here 2017 quueczzwdnhjwtuvadkgtrjkqpqfugahogasbzmceetwxwev
 * Smoking Wheels....  was here 2017 wlivdcmbbazyybmunulsoqcnyshcvsebezohmeyfvpmzwllc
 * Smoking Wheels....  was here 2017 txrtskzdyewavmfprpxwsesmwziabtxuslihkommawbaukbv
 * Smoking Wheels....  was here 2017 rsszuflkkfxeoyafehvcmwjyguzzyqlucqphgzluvqxdgeml
 * Smoking Wheels....  was here 2017 hpmvpeyndlilpsfxxynwiomudtrbauimnvzduolhmvsuemmt
 * Smoking Wheels....  was here 2017 prhvpaxihpoylefebvpbzirduwcueyhsjohvypkhpnlrqidr
 * Smoking Wheels....  was here 2017 rdtuoyzzbogdadwtblwsknvisfftmbkkjpptyslmxeiszwpn
 * Smoking Wheels....  was here 2017 zorvlgavbmlskmdqoojdvscauefzijxvjafkisysmltbuplt
 * Smoking Wheels....  was here 2017 escennelbtgoyliclgmwuuvcamoqihhmoatpvsobpflezgld
 * Smoking Wheels....  was here 2017 epklepvucaexhnxoyttsyvsqrzxchphcjfzljaeyvpjsptpq
 * Smoking Wheels....  was here 2017 enckgoqymfxfgkrwlpauicoaiwgcjfzrlhaeehxzycsrbjdo
 * Smoking Wheels....  was here 2017 nacdqtlgslkbybpyqpjjdhpwtmvoxjpltjekuheaahxexnqi
 * Smoking Wheels....  was here 2017 zvjzpukjqdvmssycktbzwedcznzrmnrzkqaxxdpfhbrrbyus
 * Smoking Wheels....  was here 2017 kzilqmyehzqqfvgtxismgwvtjwmwykxxvrjtnfaxiqzwooqt
 * Smoking Wheels....  was here 2017 zunilyqtxuoxgchrpwewgsqgjrhumzjitgihwbrtyjzruqlr
 * Smoking Wheels....  was here 2017 custbnlncvnbynbxedmnchpfwjnkjkhlakfajmwodxdhjqsx
 * Smoking Wheels....  was here 2017 msbzqukaqktyqhvrlezzildmvotyfgftvjpuvrgmgeeddgfh
 * Smoking Wheels....  was here 2017 apwosoafofruzwblsgfapgxfofotxdwzpsgqexsyuiaxflyu
 * Smoking Wheels....  was here 2017 wsrizyveedzbuyozhybtxbturkzonbhdzfiwstlmotwmymfp
 * Smoking Wheels....  was here 2017 lqijmhthzjqjeoihwynknmwuwpdilgtmxxdavctaqcedxtmh
 * Smoking Wheels....  was here 2017 lcxxjeyevgvrmwrpkizqxipcgloehdsnoaezhziqggrgazno
 * Smoking Wheels....  was here 2017 tdtpemussnafiiakbjaetrpvcuxpwmzzicjscvatzlgmifil
 * Smoking Wheels....  was here 2017 pbkepfxzyzxipsemfpkccxsjyvcfignwxytpmdzzqzdvfofd
 * Smoking Wheels....  was here 2017 hirsquekcvkuiyeuotgtcpeipzjazprkfpqexupdfoulhore
 * Smoking Wheels....  was here 2017 ptronutpxmumyfgpaywqiogpbveelbwckhpgcxnkbcxtkxlh
 * Smoking Wheels....  was here 2017 kksgsaajlpkpabxktjvqmyrhrjfbphxswolvatpdrsllrnnm
 * Smoking Wheels....  was here 2017 wmkozpqyabboldyyeozsmahuyrllohvfifhiyzaywvomlsfa
 * Smoking Wheels....  was here 2017 kpmphvlpezqbgkifyjjgqkfrseagqgvwqgmfikdsrctzhvaj
 * Smoking Wheels....  was here 2017 slcqwipzrvjbvdilztiukywvyokpmqmebynixcpnkkrlcrsg
 * Smoking Wheels....  was here 2017 rcoheymzogqsvtmemzldmtxkarizxfmxxwgsrlhvpxinzfgs
 * Smoking Wheels....  was here 2017 mvkhyttsecglbyncwqnjxceslrsbaxxzxtusvzjeaawdhpzz
 * Smoking Wheels....  was here 2017 oensfcgozobyptngtmqswrvlzattfxzszpkwxpeltktnpjio
 * Smoking Wheels....  was here 2017 nxyydoecvahewiqwcmdvvfflshxhbtgogtszojjubyrbvdce
 * Smoking Wheels....  was here 2017 jazlfzwguelhldmlcaomowavylxblbkhfsncvqvomuqlazhv
 * Smoking Wheels....  was here 2017 evgbfmzdbweseyttcnutbzdzeqrtlwoxlgxoyysjvjtpnbfu
 * Smoking Wheels....  was here 2017 lvnwcjkchhkeermsuvvxmcrnffjiljwpykfxifkddhotavhn
 * Smoking Wheels....  was here 2017 uwyecfhtewkovnyrdybnkcahcwnyaayyvmzyulnxsmshhaju
 * Smoking Wheels....  was here 2017 dwtmrxzzveocraqageakmbukdmtbaomqnxatgbycccdympkp
 * Smoking Wheels....  was here 2017 sfprondxndpepvipoanqsiyhwfbhpymssompypvibnbpyurd
 * Smoking Wheels....  was here 2017 vigutjrxvzmntyaitfrnimoobnqrbjgjhlpckxomrlymgarz
 * Smoking Wheels....  was here 2017 gcvcmcrplajaknzntwvovjaavyxiahhcluaahcuqftmzibfw
 * Smoking Wheels....  was here 2017 vlqefmownytxgctqsfmqybzwjmprjmjspfnkqnjffopvevht
 * Smoking Wheels....  was here 2017 usgwsqyvhrhobjakbumupyikhgrlfwmekkeprrmumimxgndw
 * Smoking Wheels....  was here 2017 nlmexxtuiiysahwvlkyicofijrhovqwrukievnlgbrqlcrgt
 * Smoking Wheels....  was here 2017 riklbwcmkhygkbnfuaetwtzlqjxexhcuxoowwbztfmtvpzle
 * Smoking Wheels....  was here 2017 emjgqkirohtkxenzhysyrqhxkgfthoxgehsvurxpoysuwjsb
 * Smoking Wheels....  was here 2017 fdxjkodocdzphipxirlynnbcfmfzajhahmuhuzkmumugfcir
 * Smoking Wheels....  was here 2017 evxwhrkmobqmtmuaobjbobjpvlbtnymjdcewjtufarkjhoto
 * Smoking Wheels....  was here 2017 ujkaojgctlyaowhmzcwviaqiiuehjtctxkligcuznmgpyouk
 * Smoking Wheels....  was here 2017 xsrlslbfrxhkjyswrancnnnjzmizlnuzazjtljgbwaipgamg
 * Smoking Wheels....  was here 2017 sekykamyrjlbbltxckcwdxvbjplovfqadpcldeieuttjpdai
 * Smoking Wheels....  was here 2017 qiinslkthahqrhmoxasnltudforzwavdefwyuijdjgaaolyd
 * Smoking Wheels....  was here 2017 iwnouhyegebcpsbcawrowxtjqboielztgeicfyabxluaaoaj
 * Smoking Wheels....  was here 2017 txjndkndrpeqmfcaqgpudljxwysdqdusxzhxiifixncacngc
 * Smoking Wheels....  was here 2017 aqkimvssvcjrclicdrfihtmcmkcaidgyrlutjcapfwbacnyo
 * Smoking Wheels....  was here 2017 pqlyvzmhgwpwplsgezsknjgqgvzzpqrsooedwbwsvcedraof
 * Smoking Wheels....  was here 2017 crotkkxnshafiiovsciqhecigvsdbbonspaxmiktbecwrswv
 * Smoking Wheels....  was here 2017 mudgrykghbdvxrkfxjrvifpiukbypeqdncdcfgmeleuvepwj
 * Smoking Wheels....  was here 2017 xfrhjsppgbpfedzgehparwsyiqzchyzmrvqaikgnupnznxwd
 * Smoking Wheels....  was here 2017 unaxmakxekjzfrgwerdnnrmxtxqnmntxcvuggrcsdaqnkbio
 * Smoking Wheels....  was here 2017 umhkflxwvnqclnojunpwiojzaymkvlovykfoubrvtjwwoubl
 * Smoking Wheels....  was here 2017 wdtjcwnhgcxtkckegdpxvnaimpfecjdzqatbwyvhfufsfbau
 * Smoking Wheels....  was here 2017 dsaoujxitzukafmczaysbzgjraunmimlwmkasytshrvzqbnu
 * Smoking Wheels....  was here 2017 atwcjhxivjiritwdpyrnflgqjqkjhmvknvnzuwuxasewliay
 * Smoking Wheels....  was here 2017 fbkgzeryjpqosyumayeztvjbqbnxdhtjuisuxvobtuyunmib
 * Smoking Wheels....  was here 2017 qrzpdypahkgethurlhavkehttgvowmzcbnunzdamyablyomc
 * Smoking Wheels....  was here 2017 kvcyopiraquajlplhnzefvwbgihaqbnoadvkgkgwlwutctqh
 * Smoking Wheels....  was here 2017 abrigoshzmftqkguflehikgqyscgteqaphdcfmrahznxookd
 * Smoking Wheels....  was here 2017 cesbkjynbhuhwkaydaxshsviwarjuiwyyegjplwcufzjfqnj
 * Smoking Wheels....  was here 2017 nensnwjefuwvsxjlfptiuwggheswrgydlicfjpumksdueyzb
 * Smoking Wheels....  was here 2017 oitcjeqkvuguapczwqndvejvuigknwwowpratootbydcttaj
 * Smoking Wheels....  was here 2017 neehwpqpjnvxxlfpuyhlqhhpewjxpkylayhjgfnvrnlmomfv
 * Smoking Wheels....  was here 2017 dnxohsmirjuarrznwplwrznnlmppojqidqpzppiupjujmxhe
 * Smoking Wheels....  was here 2017 ijfmblpntyplatxfhumdsjoqxbqvhktxqgjytbxajpcmpxhk
 * Smoking Wheels....  was here 2017 gzrwzupgyezmsksmmbgjsukjctjjvohfdorpyeieuqprhukt
 * Smoking Wheels....  was here 2017 hxetzdjxsgvxxomhbgwvwwdivybdpymmqnvmrvbbxdrgdxfu
 * Smoking Wheels....  was here 2017 extmiabdynkpxmlxaipcsjdkchdgecwffnlkqbrvzzcnzcld
 * Smoking Wheels....  was here 2017 tasqmjbuqrdtjoculpaaylbrhrggktedizilwgcwojugzgdx
 * Smoking Wheels....  was here 2017 gnryefzycosvepfsvpzpokunwilskumgqtowoykumqyimonh
 * Smoking Wheels....  was here 2017 byknjxsbvkbninuquboduwloqpwqnnawcvmgebbmtnzzaodt
 * Smoking Wheels....  was here 2017 wbaqiakrrolshndwhbcgdqlsqcyejigjvnpknpraqwrpoysc
 * Smoking Wheels....  was here 2017 owvxnllsqrgppdswlvcsgvkafukuuzzphiukmycutvxxcqhh
 * Smoking Wheels....  was here 2017 jskcqfmharfqdzhjsylpfugyvvfdxkgmczdojrnlvuxubxdp
 * Smoking Wheels....  was here 2017 pbpgtrjtksgmacxktdfeebbajpoebwghfpykpqhuyldmaesn
 * Smoking Wheels....  was here 2017 aslszlgtnepcoquellrbqogeutwbxtooukutyybajsgjwevt
 * Smoking Wheels....  was here 2017 nshbxjocmsrqkdmfaemzjhlnlevgfwxzgymrjwsmqrfdrxnj
 * Smoking Wheels....  was here 2017 ghsbfnwznheokgthvwjciqokvalkdchogzdmcckupuhuvnzn
 * Smoking Wheels....  was here 2017 rantwfctfycnqzoipfmqsfrmtswmasapsoarqjmvfsvkwntu
 * Smoking Wheels....  was here 2017 kquncbkaiepnnnfpgidfbvgphxorneonvytervprwhonsppx
 * Smoking Wheels....  was here 2017 jfwvkydrypdqojfpxlwpaowwsmgjkerczrdyfvqtatmtmtnv
 * Smoking Wheels....  was here 2017 tahpowxuhclkseidzcnwrtlsnqvhvrkivnginyurnktbleuu
 * Smoking Wheels....  was here 2017 zoxumgrvzwklazncfceheabrpsojewamjmlwazjhjzvphiyj
 * Smoking Wheels....  was here 2017 sputkqohuhgsvydvlkembffsxjwtzhzzrxgjlbasxjkvwxrf
 * Smoking Wheels....  was here 2017 wfgavwxetzlkvopuwibgajkwtokydpcrfgnyvnriqsllfyck
 * Smoking Wheels....  was here 2017 pqxlmbjmdxryuntrxlqqawqoskeotuimqhiwjzlujkdjtpjd
 * Smoking Wheels....  was here 2017 iknbinvrnfxzvvooflbxjhzjohknebzrwdzrnfsxdcxtciby
 * Smoking Wheels....  was here 2017 shfeqwmirghmiqgrtlorlmwfjxlcaxptczbebjcwgrmcaxxn
 * Smoking Wheels....  was here 2017 sjgivyqiqsiqxmllqqttbnwfjdcqdzvlsjjmytnzgjvasfyx
 * Smoking Wheels....  was here 2017 mwhjruyutmswjausipmddtysdcfwqhuujcavkycxxmdmmoki
 * Smoking Wheels....  was here 2017 kicievicnsiwwgjklcvfyteimgctwbszbfiwxvgmgsuqyiwh
 * Smoking Wheels....  was here 2017 entnnoxwsvmnsjkvyebmzkzylfdjkscnwywhflowqzpzzhzo
 * Smoking Wheels....  was here 2017 snqnfwbyklncowlkabuuxszrhxagezsffvlgheykokkeqjwb
 * Smoking Wheels....  was here 2017 fnfczwlmxnfyglfyaivetdbxomsbfwozvreajpotvkmciusc
 * Smoking Wheels....  was here 2017 ackjuwxvtdmvwaskqtgztdjgbilsyoycpmieyotsmrgaqabe
 * Smoking Wheels....  was here 2017 wagpwlqprtnquxhbvijsjrhowcpkxmhcrommsdemvalhlvsa
 * Smoking Wheels....  was here 2017 qibislysuzunpmjkrjveitmafryozklrmjnbqqskjryrucpq
 * Smoking Wheels....  was here 2017 mhllbzogjuzzdmsdskjmptuxrhkwhhkvstleasncyzabcbaf
 * Smoking Wheels....  was here 2017 xlfxxkipygbqpxkinecxlgjxbgdgeijvhsqjiezkoqbpyfmi
 * Smoking Wheels....  was here 2017 mokckgjjiuemfyqdbtiajbpxkgrxgzyeioqnfcsmnnuuegts
 * Smoking Wheels....  was here 2017 dqjockblncwrsbydljqqaidyyfqgiauphthptwpskvehyewi
 * Smoking Wheels....  was here 2017 czsbsycxwatqvycbeowuljvmhgaaoiacvcqzdaurzxkandak
 * Smoking Wheels....  was here 2017 tdfsgehexuvctqdwwdcuwtwcguzbhdvxwrbfvkqggkxepqun
 * Smoking Wheels....  was here 2017 uvyvwtwwjsgxvggvkbpgtipqumaqdztnorbcodwpohkeyjyj
 * Smoking Wheels....  was here 2017 bdhxcmdvjmmiqizlbsaxufrhgfvdymnsisnrjogblqvttilx
 * Smoking Wheels....  was here 2017 vhturlteeahtbpdldncwbtyjddigvremwmngkgagrxkuisol
 * Smoking Wheels....  was here 2017 kweopzqiimnweyqvjizkslqmirsyctzbbbilfanbhtomizvm
 * Smoking Wheels....  was here 2017 oqrmarwwpflqiqvvrdzcggaoummikemxcsozmzkpqaagnwzs
 * Smoking Wheels....  was here 2017 dondmkxqbyleecezffrtkevsvlgypqjvkzazfnnfexrvbibe
 * Smoking Wheels....  was here 2017 iaiisgivanhaocmajcvldpxhzsbjudruqputpdbouvuciphc
 * Smoking Wheels....  was here 2017 olxdrnatzcxtnpsxwoolsckxbrbphwrarreuftjnljugwcgy
 * Smoking Wheels....  was here 2017 nrhvpvectcmjmteyoqfipnsldasutiwbtkuzrkcemmjtpoqn
 * Smoking Wheels....  was here 2017 bswzzzdqjemabciorpixoykalqsjafbqgilibmdykimgpymv
 * Smoking Wheels....  was here 2017 lwflodnpdfpebhzoqztgmsmaorabflesvgfdnnpjbhirfmba
 * Smoking Wheels....  was here 2017 zpbfgohgqktmpicxbnorrlzbgouuqhopkfkaojxklbigaqws
 * Smoking Wheels....  was here 2017 ltpqjwmiocexblzwwibrpyizpxosyfstflptydsdwlgjydqo
 * Smoking Wheels....  was here 2017 ribgjyopbzipabdxgqvdzhdywpygzxjxonqkqevywsztbxlp
 * Smoking Wheels....  was here 2017 wpcwyudfixwajxivqyrcvwihpwxdvinbfeogvbllgesisenc
 * Smoking Wheels....  was here 2017 kcmocvcozcuveynorbsvifbrpargxtmnbmsxbpymbnzgnkkm
 * Smoking Wheels....  was here 2017 bphpcqphuygzukbkhzgyzfqyxurvsossfrrdayygoqjyjjuo
 * Smoking Wheels....  was here 2017 qdwpjazfubtqvsjuqbvfnytgvbqhfnakehhzskiaisxdhyth
 * Smoking Wheels....  was here 2017 izujqbxmhjyherhnesisxthxwymhlpkoocovjnhmddttrknz
 */
package net.yacy;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import org.apache.http.Header;
import org.apache.http.HttpStatus;
import org.apache.http.entity.mime.content.ContentBody;
import com.google.common.io.Files;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.order.Digest;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.ConnectionInfo;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.TimeoutRequest;
import net.yacy.cora.protocol.http.HTTPClient;
import net.yacy.cora.sorting.Array;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.retrieval.Response;
import net.yacy.data.TransactionManager;
import net.yacy.data.Translator;
import net.yacy.document.Document;
import net.yacy.gui.YaCyApp;
import net.yacy.gui.framework.Browser;
import net.yacy.http.Jetty9HttpServerImpl;
import net.yacy.http.YaCyHttpServer;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.Formatter;
import net.yacy.kelondro.util.MemoryControl;
import net.yacy.kelondro.util.OS;
import net.yacy.peers.Seed;
import net.yacy.peers.operation.yacyBuildProperties;
import net.yacy.peers.operation.yacyRelease;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverSwitch;
import net.yacy.utils.translation.TranslatorXliff;
/**
* This is the main class of YaCy. Several threads are started from here:
* <ul>
* <li>one single instance of the plasmaSwitchboard is generated, which itself
* starts a thread with a plasmaHTMLCache object. This object simply counts
* files sizes in the cache and terminates them. It also generates a
* plasmaCrawlerLoader object, which may itself start some more httpc-calling
* threads to load web pages. They terminate automatically when a page has
* loaded.
* <li>one serverCore - thread is started, which implements a multi-threaded
* server. The process may start itself many more processes that handle
* connections.lo
* <li>finally, all idle-dependent processes are written in a queue in
* plasmaSwitchboard which are worked off inside an idle-sensitive loop of the
* main process. (here)
* </ul>
*
* On termination, the following must be done:
* <ul>
* <li>stop feeding of the crawling process because it otherwise fills the
* indexing queue.
* <li>say goodbye to connected peers and disable new connections. Don't wait for
* success.
* <li>first terminate the serverCore thread. This prevents that new cache
* objects are queued.
* <li>wait that the plasmaHTMLCache terminates (it should be normal that this
* process already has terminated).
* <li>then wait for termination of all loader process of the
* plasmaCrawlerLoader.
* <li>work off the indexing and cache storage queue. These values are inside a
* RAM cache and would be lost otherwise.
* <li>write all settings.
* <li>terminate.
* </ul>
*/
public final class yacy {
public static final String vString = yacyBuildProperties.getVersion();
public static final String vDATE   = yacyBuildProperties.getBuildDate();
public static final String copyright = "[ YaCy v" + vString + ", build " + vDATE + " by Michael Christen / www.yacy.net ]";
public static final String hline = "-------------------------------------------------------------------------------";
public static final Semaphore shutdownSemaphore = new Semaphore(0);
public static File htDocsPath = null;
public static File shareDefaultPath = null;
public static File shareDumpDefaultPath = null;
/**
* a reference to the {@link Switchboard} created by the
* {@link yacy#startup(String, long, long)} method.
*/
private static Switchboard sb = null;
/**
* Starts up the whole application. Sets up all datastructures and starts
* the main threads.
*
* @param homePath Root-path where all information is to be found.
* @param startupFree free memory at startup time, to be used later for statistics
*/
private static void startup(final File dataHome, final File appHome, final long startupMemFree, final long startupMemTotal, final boolean gui) {
String tmpdir=null;
try {
System.out.println(copyright);
System.out.println(hline);
mkdirsIfNeseccary(dataHome);
mkdirsIfNeseccary(appHome);
File f = new File(dataHome, "DATA/");
mkdirsIfNeseccary(f);
			if (!(f.exists())) {
				System.err.println("Error creating DATA-directory in " + dataHome.toString() + " . Please check your write-permission for this folder. YaCy will now terminate.");
				System.exit(-1);
			}
			f = new File(dataHome, "DATA/LOG/");
mkdirsIfNeseccary(f);
			f = new File(dataHome, "DATA/LOG/yacy.logging");
			final File f0 = new File(appHome, "defaults/yacy.logging");
			if (!f.exists() || f0.lastModified() > f.lastModified()) try {
			    Files.copy(f0, f);
} catch (final IOException e){
System.out.println("could not copy yacy.logging");
}
try{
ConcurrentLog.configureLogging(dataHome, appHome, new File(dataHome, "DATA/LOG/yacy.logging"));
} catch (final IOException e) {
System.out.println("could not find logging properties in homePath=" + dataHome);
ConcurrentLog.logException(e);
}
ConcurrentLog.config("STARTUP", "YaCy version: " + yacyBuildProperties.getVersion() + "/" + yacyBuildProperties.getSVNRevision());
ConcurrentLog.config("STARTUP", "Java version: " + System.getProperty("java.version", "no-java-version"));
ConcurrentLog.config("STARTUP", "Operation system: " + System.getProperty("os.name","unknown"));
ConcurrentLog.config("STARTUP", "Application root-path: " + appHome);
ConcurrentLog.config("STARTUP", "Data root-path: " + dataHome);
ConcurrentLog.config("STARTUP", "Time zone: UTC" + GenericFormatter.UTCDiffString() + "; UTC+0000 is " + System.currentTimeMillis());
ConcurrentLog.config("STARTUP", "Maximum file system path length: " + OS.maxPathLength);
f = new File(dataHome, "DATA/yacy.running");
final String conf = "DATA/SETTINGS/yacy.conf".replace("/", File.separator);
if (!f.createNewFile()) ConcurrentLog.severe("STARTUP", "WARNING: the file " + f + " can not be created!");
try { new FileOutputStream(f).write(Integer.toString(OS.getPID()).getBytes()); } catch (final Exception e) { } // write PID
f.deleteOnExit();
FileChannel channel = null;
FileLock lock = null;
try {
	channel = new RandomAccessFile(f,"rw").getChannel();
	lock = channel.tryLock();
} catch (final Exception e) { }
try { 
tmpdir = java.nio.file.Files.createTempDirectory("yacy-tmp-").toString();
System.setProperty("java.io.tmpdir", tmpdir);
} catch (IOException ex) { }
try {
sb = new Switchboard(dataHome, appHome, "defaults/yacy.init".replace("/", File.separator), conf);
} catch (final RuntimeException e) {
ConcurrentLog.severe("STARTUP", "YaCy cannot start: " + e.getMessage(), e);
System.exit(-1);
}
MemoryControl.setStandardStrategy(sb.getConfigBool("memory.standardStrategy", true));
sb.setConfig("memoryFreeAfterStartup", startupMemFree);
sb.setConfig("memoryTotalAfterStartup", startupMemTotal);
if (gui) YaCyApp.start("localhost", sb.getLocalPort());
sb.setConfig("htTemplatePath", "htroot/env/templates");
double oldVer;
	    try {
String tmpversion = sb.getConfig(Seed.VERSION, "");
if (tmpversion.isEmpty()) {
tmpversion = yacyBuildProperties.getVersion();
int oldRev = Integer.parseInt(sb.getConfig("svnRevision", "0"));
if (oldRev > 1) {                       
oldVer = Double.parseDouble(tmpversion) + oldRev / 100000000.0;
} else {
oldVer = Double.parseDouble(yacyBuildProperties.getLongVersion());
}
} else {
oldVer = Double.parseDouble(tmpversion);
}
} catch (final NumberFormatException e) {
oldVer = 0.0d;
	    }
final double newRev = Double.parseDouble(yacyBuildProperties.getLongVersion());
sb.setConfig(Seed.VERSION, yacyBuildProperties.getLongVersion());
sb.setConfig("applicationRoot", appHome.toString());
sb.setConfig("dataRoot", dataHome.toString());
final File htRootPath = new File(appHome, sb.getConfig(SwitchboardConstants.HTROOT_PATH, SwitchboardConstants.HTROOT_PATH_DEFAULT));
mkdirIfNeseccary(htRootPath);
htDocsPath = sb.getDataPath(SwitchboardConstants.HTDOCS_PATH, SwitchboardConstants.HTDOCS_PATH_DEFAULT);
mkdirIfNeseccary(htDocsPath);
importDonationIFrame(sb, htDocsPath);
File notifierFile = new File(htDocsPath, "notifier.gif");
if (!notifierFile.exists()) try {Files.copy(new File(htRootPath, "env/grafics/empty.gif"), notifierFile);} catch (final IOException e) {}
final File htdocsReadme = new File(htDocsPath, "readme.txt");
if (!(htdocsReadme.exists())) try {FileUtils.copy((
"This is your root directory for individual Web Content\r\n" +
"\r\n" +
"Please place your html files into the www subdirectory.\r\n" +
"The URL of that path is either\r\n" +
"http://www.<your-peer-name>.yacy    or\r\n" +
"http://<your-ip>:<your-port>/www\r\n" +
"\r\n" +
"Other subdirectories may be created; they map to corresponding sub-domains.\r\n" +
"This directory shares it's content with the applications htroot path, so you\r\n" +
"may access your yacy search page with\r\n" +
"http://<your-peer-name>.yacy/\r\n" +
"\r\n").getBytes(), htdocsReadme);} catch (final IOException e) {
System.out.println("Error creating htdocs readme: " + e.getMessage());
}
shareDefaultPath = new File(htDocsPath, "share");
mkdirIfNeseccary(shareDefaultPath);
shareDumpDefaultPath = new File(shareDefaultPath, "dump");
mkdirIfNeseccary(shareDumpDefaultPath);
migration.migrate(sb, oldVer, newRev);
final int deleteOldDownloadsAfterDays = (int) sb.getConfigLong("update.deleteOld", 30);
yacyRelease.deleteOldDownloads(sb.releasePath, deleteOldDownloadsAfterDays );
HTTPClient.setDefaultUserAgent(ClientIdentification.yacyInternetCrawlerAgent.userAgent);
final int port = sb.getLocalPort();
try {
	YaCyHttpServer httpServer;
httpServer = new Jetty9HttpServerImpl(port);
httpServer.startupServer();
sb.setHttpServer(httpServer);
ConnectionInfo.setServerMaxcount(sb.getConfigInt("connectionsMax", ConnectionInfo.getMaxcount()));
ConcurrentLog.info("STARTUP",httpServer.getVersion());
final boolean browserPopUpTrigger = sb.getConfig(SwitchboardConstants.BROWSER_POP_UP_TRIGGER, "true").equals("true");
if (browserPopUpTrigger) try {
final String  browserPopUpPage = sb.getConfig(SwitchboardConstants.BROWSER_POP_UP_PAGE, "ConfigBasic.html");
/* YaCy main startup process must not hang because browser opening is long or fails. 
* Let's open try opening the browser in a separate thread */
new Thread("Browser opening") {
	@Override
	public void run() {
Browser.openBrowser(("http://localhost:"+port) + "/" + browserPopUpPage);
	}
}.start();
} catch (final Throwable e) {
}
sb.tray.setReady();
final File locale_source = sb.getAppPath("locale.source", "locales");
final String lang = sb.getConfig("locale.language", "");
List<String> langlist;
if (lang.endsWith("browser"))
langlist = Translator.activeTranslations();
else {
langlist = new ArrayList<String>();
langlist.add(lang);
}
for (String tmplang : langlist) {
if (!tmplang.equals("") && !tmplang.equals("default") && !tmplang.equals("browser")) {
String currentRev = null;
BufferedReader br = null;
try {
br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(sb.getDataPath("locale.translated_html", "DATA/LOCALE/htroot"), tmplang + "/version"))));
currentRev = br.readLine();
} catch (final IOException e) {
} finally {
	try {
		br.close();
	} catch(IOException ioe) {
		ConcurrentLog.warn("STARTUP", "Could not close " + tmplang + " version file");
	}
}
if (currentRev == null || !currentRev.equals(sb.getConfig(Seed.VERSION, ""))) {
try {
final File sourceDir = new File(sb.getConfig(SwitchboardConstants.HTROOT_PATH, SwitchboardConstants.HTROOT_PATH_DEFAULT));
final File destDir = new File(sb.getDataPath("locale.translated_html", "DATA/LOCALE/htroot"), tmplang);
if (new TranslatorXliff().translateFilesRecursive(sourceDir, destDir, new File(locale_source, tmplang + ".lng"), "html,template,inc", "locale")) {
final BufferedWriter bw = new BufferedWriter(new PrintWriter(new FileWriter(new File(destDir, "version"))));
bw.write(sb.getConfig(Seed.VERSION, "Error getting Version"));
bw.close();
}
} catch (final IOException e) {
}
}
}
}
if (!lang.equals("browser")) // "default" is handled by .setLocale()
Formatter.setLocale(lang);
ConcurrentLog.config("STARTUP", "Registering Shutdown Hook");
final Runtime run = Runtime.getRuntime();
run.addShutdownHook(new shutdownHookThread(sb, shutdownSemaphore));
sb.setConfig("memoryFreeAfterInitBGC", MemoryControl.free());
sb.setConfig("memoryTotalAfterInitBGC", MemoryControl.total());
System.gc();
sb.setConfig("memoryFreeAfterInitAGC", MemoryControl.free());
sb.setConfig("memoryTotalAfterInitAGC", MemoryControl.total());
try {
sb.waitForShutdown();
} catch (final Exception e) {
ConcurrentLog.severe("MAIN CONTROL LOOP", "PANIC: " + e.getMessage(),e);
}
Array.terminate();
ConcurrentLog.config("SHUTDOWN", "caught termination signal");
httpServer.stop();
ConcurrentLog.config("SHUTDOWN", "server has terminated");
sb.close();
} catch (final Exception e) {
ConcurrentLog.severe("STARTUP", "Unexpected Error: " + e.getClass().getName(),e);
}
if(lock != null) lock.release();
if(channel != null) channel.close();
} catch (final Exception ee) {
ConcurrentLog.severe("STARTUP", "FATAL ERROR: " + ee.getMessage(),ee);
} finally {
}
        if (tmpdir != null) FileUtils.deletedelete(new File(tmpdir)); // clean up temp dir (set at startup as subdir of system.propery "java.io.tmpdir")
ConcurrentLog.config("SHUTDOWN", "goodbye. (this is the last line)");
ConcurrentLog.shutdown();
shutdownSemaphore.release(1000);
try {
System.exit(0);
} catch (final Exception e) {} // was once stopped by de.anomic.net.ftpc$sm.checkExit(ftpc.java:1790)
}
/**
* Concurrently import the donation iframe content to serve it directly from this peer.
* @param switchBoard the SwitchBoard instance. Must not be null.
* @param htDocsDirectory the custom htdocs directory. Must not be null.
*/
	private static void importDonationIFrame(final Switchboard switchBoard, final File htDocsDirectory) {
		final File wwwEnvPath = new File(htDocsDirectory, "env");
		mkdirIfNeseccary(wwwEnvPath);
		final String iframesource = switchBoard.getConfig("donation.iframesource", "");
		final String iframetarget = switchBoard.getConfig("donation.iframetarget", "");
		final File iframefile = new File(htDocsDirectory, iframetarget);
		if (!iframefile.exists()) new Thread("yacy.importDonationIFrame") {
		    @Override
		    public void run() {
		        final ClientIdentification.Agent agent = ClientIdentification.getAgent(ClientIdentification.yacyInternetCrawlerAgentName);
		        Response documentResponse;
		        try {
		        	/* Load the donation html frame content */
		        	documentResponse = switchBoard.loader == null ? null : switchBoard.loader.load(switchBoard.loader.request(new DigestURL(iframesource), false, true), CacheStrategy.NOCACHE, Integer.MAX_VALUE, null, agent);
		            if (documentResponse != null) {
		            	Document[] documents = documentResponse.parse();
		            	if(documents != null && documents.length > 0 && documents[0] != null) {
		            		Document donateDocument = documents[0];
		            		String donateDocContent = new String(documentResponse.getContent(), donateDocument.getCharset());
		            		/* Load image resources contained in the page */
		            		if(donateDocument.getImages() != null) {
		            			for(DigestURL imgURL : donateDocument.getImages().keySet()) {
		            				try {
		            					Response response = switchBoard.loader.load(switchBoard.loader.request(imgURL, false, true), CacheStrategy.NOCACHE, Integer.MAX_VALUE, null, agent);
		            					if (response != null) {
		            						String imgFileName = imgURL.getFileName();
		            						/* Store each image in the same directory as the iframe target file */
		            						FileUtils.copy(response.getContent(), new File(iframefile.getParentFile(), imgFileName));
		                        	
		            						/* Transform the original image URL to a relative one */
		            						donateDocContent = donateDocContent.replace(imgURL.getURL().toString(), imgFileName);
		            					}
		            				} catch(IOException e) {
		            					/* Failing to load one image should not stop the whole task */
		            					ConcurrentLog.warn("STARTUP", "Donation frame retrieval : could not get an image resource.", e);
		            				}
		            			}
		            		}
			            	FileUtils.copy(donateDocContent.getBytes(donateDocument.getCharset()), iframefile);
		            	}
		            }
		        } catch (Exception e) {
		        	ConcurrentLog.warn("STARTUP", "Could not retrieve donation frame content.", e);
		        }
		    }
		}.start();
	}
	/**
	 * @param f
	 */
	private static void delete(final File f) {
		if(!f.delete())
		    ConcurrentLog.severe("STARTUP", "WARNING: the file " + f + " can not be deleted!");
	}
	/**
	 * @see File#mkdir()
	 * @param path
	 */
	private static void mkdirIfNeseccary(final File path) {
		if (!(path.exists()))
			if(!path.mkdir())
				ConcurrentLog.warn("STARTUP", "could not create directory "+ path.toString());
	}
	/**
	 * @see File#mkdirs()
	 * @param path
	 */
	public static void mkdirsIfNeseccary(final File path) {
		if (!(path.exists()))
			if(!path.mkdirs())
				ConcurrentLog.warn("STARTUP", "could not create directories "+ path.toString());
	}
	/**
* Loads the configuration from the data-folder.
* FIXME: Why is this called over and over again from every method, instead
* of setting the configurationdata once for this class in main?
*
* @param mes Where are we called from, so that the errormessages can be
* more descriptive.
* @param homePath Root-path where all the information is to be found.
* @return Properties read from the configurationfile.
*/
private static Properties configuration(final String mes, final File homePath) {
ConcurrentLog.config(mes, "Application Root Path: " + homePath.toString());
final File dataFolder = new File(homePath, "DATA");
        if (!(dataFolder.exists())) {
ConcurrentLog.severe(mes, "Application was never started or root path wrong.");
System.exit(-1);
}
final Properties config = new Properties();
FileInputStream fis = null;
		try {
	fis  = new FileInputStream(new File(homePath, "DATA/SETTINGS/yacy.conf"));
config.load(fis);
} catch (final FileNotFoundException e) {
ConcurrentLog.severe(mes, "could not find configuration file.");
System.exit(-1);
} catch (final IOException e) {
ConcurrentLog.severe(mes, "could not read configuration file.");
System.exit(-1);
} finally {
	if(fis != null) {
		try {
					fis.close();
				} catch (final IOException e) {
				    ConcurrentLog.logException(e);
				}
	}
}
return config;
}
/**
* Call the shutdown-page of YaCy to tell it to shut down. This method is
* called if you start yacy with the argument -shutdown.
*
* @param homePath Root-path where all the information is to be found.
*/
public static void shutdown(final File homePath) {
System.out.println(copyright);
System.out.println(hline);
final LinkedHashMap<String,ContentBody> post = new LinkedHashMap<String,ContentBody>();
post.put("shutdown", UTF8.StringBody(""));
submitPostURL(homePath, "Steering.html", "Terminate YaCy", post);
}
public static void update(final File homePath) {
System.out.println(copyright);
System.out.println(hline);
submitURL(homePath, "ConfigUpdate_p.html?autoUpdate=", "Update YaCy to most recent version");
}
/**
* Submits post data to the local peer URL, authenticating as administrator
* @param homePath directory containing YaCy DATA folder
* @param path url relative path part
* @param processdescription description of the operation for logging purpose
* @param post data to post
*/
private static void submitPostURL(final File homePath, final String path, final String processdescription, final Map<String, ContentBody> post) {
final Properties config = configuration("COMMAND-STEERING", homePath);
final int port = Integer.parseInt(config.getProperty(SwitchboardConstants.SERVER_PORT, "8090"));
final String encodedPassword = config.getProperty(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "");
final String adminUser = config.getProperty(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, "admin");
final HTTPClient con = new HTTPClient(ClientIdentification.yacyInternetCrawlerAgent);
try {
	/* First get a valid transaction token using HTTP GET */
con.GETbytes("http://localhost:"+ port +"/" + path, adminUser, encodedPassword, false);
if (con.getStatusCode() != HttpStatus.SC_OK) {
throw new IOException("Error response from YACY socket: " + con.getHttpResponse().getStatusLine());
}
final Header transactionTokenHeader = con.getHttpResponse().getFirstHeader(HeaderFramework.X_YACY_TRANSACTION_TOKEN);
if(transactionTokenHeader == null) {
	throw new IOException("Could not retrieve a valid transaction token");
}
/* Then POST the request */
post.put(TransactionManager.TRANSACTION_TOKEN_PARAM, UTF8.StringBody(transactionTokenHeader.getValue()));
con.POSTbytes(new MultiProtocolURL("http://localhost:"+ port +"/" + path), null, post, adminUser, encodedPassword, false, false);
if (con.getStatusCode() >= HttpStatus.SC_OK && con.getStatusCode() < HttpStatus.SC_MULTIPLE_CHOICES) {
ConcurrentLog.config("COMMAND-STEERING", "YACY accepted steering command: " + processdescription);
} else {
	ConcurrentLog.severe("COMMAND-STEERING", "error response from YACY socket: " + con.getHttpResponse().getStatusLine());
	
try {
			HTTPClient.closeConnectionManager();
		} catch (final InterruptedException e1) {
			e1.printStackTrace();
		}
	
System.exit(-1);
}
} catch (final IOException e) {
ConcurrentLog.severe("COMMAND-STEERING", "could not establish connection to YACY socket: " + e.getMessage());
try {
			HTTPClient.closeConnectionManager();
		} catch (final InterruptedException e1) {
			e1.printStackTrace();
		}
System.exit(-1);
}
try {
			HTTPClient.closeConnectionManager();
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
ConcurrentLog.config("COMMAND-STEERING", "SUCCESSFULLY FINISHED COMMAND: " + processdescription);
}
private static void submitURL(final File homePath, final String path, final String processdescription) {
final Properties config = configuration("COMMAND-STEERING", homePath);
final int port = Integer.parseInt(config.getProperty(SwitchboardConstants.SERVER_PORT, "8090"));
String encodedPassword = (String) config.get(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5);
        if (encodedPassword == null) encodedPassword = ""; // not defined
final HTTPClient con = new HTTPClient(ClientIdentification.yacyInternetCrawlerAgent);
try {
con.GETbytes("http://localhost:"+ port +"/" + path, config.getProperty(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME,"admin"), encodedPassword, false);
if (con.getStatusCode() > 199 && con.getStatusCode() < 300) {
ConcurrentLog.config("COMMAND-STEERING", "YACY accepted steering command: " + processdescription);
} else {
	ConcurrentLog.severe("COMMAND-STEERING", "error response from YACY socket: " + con.getHttpResponse().getStatusLine());
System.exit(-1);
}
} catch (final IOException e) {
ConcurrentLog.severe("COMMAND-STEERING", "could not establish connection to YACY socket: " + e.getMessage());
System.exit(-1);
}
try {
			HTTPClient.closeConnectionManager();
		} catch (final InterruptedException e) {
			e.printStackTrace();
		}
ConcurrentLog.config("COMMAND-STEERING", "SUCCESSFULLY FINISHED COMMAND: " + processdescription);
}
/**
* read saved config file and perform action which need to be done before main task starts
* - like check on system alrady running etc.
* 
* @param dataHome data directory
*/
static private void preReadSavedConfigandInit(File dataHome) {
File lockFile = new File(dataHome, "DATA/yacy.running");
final String conf = "DATA/SETTINGS/yacy.conf";
File configFile = new File(dataHome, conf);
        if (configFile.exists()) {
Properties p = new Properties();
FileInputStream fis = null;
try {
fis = new FileInputStream(configFile);
p.load(fis);
String teststr = p.getProperty("serverClient", "*");
if (!teststr.equals("*")) {
System.setProperty("java.net.preferIPv6Addresses", "false");
System.setProperty("java.net.preferIPv4Stack", "true");
teststr = System.getProperty("java.net.preferIPv4Stack");
System.out.println("set system property java.net.preferIP4Stack=" + teststr);
}   
if (lockFile.exists()) {  // another instance running? VM crash? User will have to care about this
System.out.println("WARNING: the file " + lockFile + " exists, this usually means that a YaCy instance is still running. If you want to restart YaCy, try first ./stopYACY.sh, then ./startYACY.sh. If ./stopYACY.sh fails, try ./killYACY.sh");
int port = Integer.parseInt(p.getProperty(SwitchboardConstants.SERVER_PORT, "8090"));
if (TimeoutRequest.ping("127.0.0.1", port, 1000)) {
Browser.openBrowser("http://localhost:" + port + "/" + p.getProperty(SwitchboardConstants.BROWSER_POP_UP_PAGE, "index.html"));
System.out.println("WARNING: YaCy instance was still running; just opening the browser and exit.");
System.exit(0);
} else {
System.err.println("INFO: delete old yacy.running file; likely previous YaCy session was not orderly shutdown!");
delete(lockFile);
}                                
}
} catch (IOException ex) {
System.err.println("ERROR: config file seems to be corrupt");
System.err.println("ERROR: if problem persists, delete file");
System.err.println(configFile.getAbsolutePath());
ConcurrentLog.logException(ex);
ConcurrentLog.severe("Startup", "cannot read " + configFile.toString() + ", please delete the corrupted file if problem persits");
} finally {
	try {
					fis.close();
				} catch (IOException e) {
					ConcurrentLog.warn("Startup", "Could not close file " + configFile);
				}
}
}
}     
/**
* Main-method which is started by java. Checks for special arguments or
* starts up the application.
*
* @param args
*            Given arguments from the command line.
*/
public static void main(String args[]) {
	try {
	      
	      
	        boolean assertionenabled = false;
	        assert (assertionenabled = true) == true;
	        if (assertionenabled) System.out.println("Asserts are enabled");
	      
	        System.gc();
	        final long startupMemFree  = MemoryControl.free();
	        final long startupMemTotal = MemoryControl.total();
	      
	      
	      
	      
	      
	        boolean headless = true;
	        if (OS.isWindows) headless = false;
	        if (args.length >= 1 && args[0].toLowerCase(Locale.ROOT).equals("-gui")) headless = false;
	        System.setProperty("java.awt.headless", headless ? "true" : "false");
	        String s = ""; for (final String a: args) s += a + " ";
	        yacyRelease.startParameter = s.trim();
	        File applicationRoot = new File(System.getProperty("user.dir").replace('\\', '/'));
	        File dataRoot = applicationRoot;
	      
	      
	        if ((args.length >= 1) && (args[0].toLowerCase(Locale.ROOT).equals("-startup") || args[0].equals("-start"))) {
	          
	            if (args.length > 1) {
	            	dataRoot = new File(System.getProperty("user.home").replace('\\', '/'), args[1]);
	            }
preReadSavedConfigandInit(dataRoot);
	            startup(dataRoot, applicationRoot, startupMemFree, startupMemTotal, false);
	        } else if (args.length >= 1 && args[0].toLowerCase(Locale.ROOT).equals("-gui")) {
	          
	            if (args.length > 1) {
	            	dataRoot = new File(System.getProperty("user.home").replace('\\', '/'), args[1]);
	            }
preReadSavedConfigandInit(dataRoot);
	            startup(dataRoot, applicationRoot, startupMemFree, startupMemTotal, true);
	        } else if ((args.length >= 1) && ((args[0].toLowerCase(Locale.ROOT).equals("-shutdown")) || (args[0].equals("-stop")))) {
	          
	            if (args.length == 2) applicationRoot= new File(args[1]);
	            shutdown(applicationRoot);
	        } else if ((args.length >= 1) && (args[0].toLowerCase(Locale.ROOT).equals("-update"))) {
	          
	            if (args.length == 2) applicationRoot= new File(args[1]);
	            update(applicationRoot);
	        } else if ((args.length >= 1) && (args[0].toLowerCase(Locale.ROOT).equals("-version"))) {
	          
	            System.out.println(copyright);
} else if ((args.length > 1) && (args[0].toLowerCase(Locale.ROOT).equals("-config"))) {
File f = new File (dataRoot,"DATA/SETTINGS/");
if (!f.exists()) {
mkdirsIfNeseccary(f);
} else {
if (new File(dataRoot, "DATA/yacy.running").exists()) {
System.out.println("please restart YaCy");
}
}
serverSwitch ss = new serverSwitch(dataRoot,applicationRoot,"defaults/yacy.init","DATA/SETTINGS/yacy.conf");
for (int icnt=1; icnt < args.length ; icnt++) {
String cfg = args[icnt];
int pos = cfg.indexOf('=');
if (pos > 0) {
String cmd = cfg.substring(0, pos);
String val = cfg.substring(pos + 1);
if (!val.isEmpty()) {
if (cmd.equalsIgnoreCase(SwitchboardConstants.ADMIN_ACCOUNT)) {
int cpos = val.indexOf(':');  //format adminAccount=adminname:adminpwd
if (cpos >= 0) {
String username = val.substring(0, cpos);
String pwdtxt = val.substring(cpos + 1);
if (!username.isEmpty()) {
ss.setConfig(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, username);
System.out.println("Set property " + SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME + " = " + username);
} else {
username = ss.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, "admin");
}
ss.setConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "MD5:" + Digest.encodeMD5Hex(username + ":" + ss.getConfig(SwitchboardConstants.ADMIN_REALM, "YaCy") + ":" + pwdtxt));
System.out.println("Set property " + SwitchboardConstants.ADMIN_ACCOUNT_B64MD5 + " = " + ss.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, ""));
}
} else {
ss.setConfig(cmd, val);
System.out.println("Set property " + cmd + " = " + val);
}
}
} else {
System.out.println("skip parameter " + cfg + " (equal sign missing, put parameter in doublequotes)");
}
System.out.println();
}
} else {
	            if (args.length == 1) {
	            	applicationRoot= new File(args[0]);
	            }
preReadSavedConfigandInit(dataRoot);
	            startup(dataRoot, applicationRoot, startupMemFree, startupMemTotal, false);
	        }
	} finally {
		ConcurrentLog.shutdown();
	}
}
}
/**
* This class is a helper class whose instance is started, when the java virtual
* machine shuts down. Signals the plasmaSwitchboard to shut down.
*/
class shutdownHookThread extends Thread {
private final Switchboard sb;
private final Semaphore shutdownSemaphore;
public shutdownHookThread(final Switchboard sb, final Semaphore shutdownSemaphore) {
super("yacy.shutdownHookThread");
this.sb = sb;
this.shutdownSemaphore = shutdownSemaphore;
}
@Override
public void run() {
try {
if (!this.sb.isTerminated()) {
ConcurrentLog.config("SHUTDOWN","Shutdown via shutdown hook.");
/* Print also to the standard output, as the LogManager is likely to have
* been concurrently reset by its own shutdown hook thread */
System.out.println("SHUTDOWN Starting shutdown via shutdown hook.");
ConcurrentLog.fine("SHUTDOWN","Signaling shutdown to the switchboard.");
this.sb.terminate("shutdown hook");
ConcurrentLog.fine("SHUTDOWN","Waiting for main thread to finish.");
/* Main thread will release the shutdownSemaphore once completely terminated.
* We do not wait indefinitely as the application is supposed here to quickly terminate */
this.shutdownSemaphore.tryAcquire(30, TimeUnit.SECONDS);
}
} catch (final Exception e) {
ConcurrentLog.severe("SHUTDOWN","Unexpected error. " + e.getClass().getName(),e);
}
}
}
