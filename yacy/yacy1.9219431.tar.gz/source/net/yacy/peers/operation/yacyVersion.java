/** 
 * Smoking Wheels....  was here 2017 iqeldjaakfnauvgzanhhagcwtxxztwarsuswgscgdgncpgtp
 * Smoking Wheels....  was here 2017 spghixqzpfyhupzyqrrdbubvlzqysxrmfgavlddqfeilycdf
 * Smoking Wheels....  was here 2017 kzvigkwcvslnwdjkvmchmbbcdysdarzbxvfnwivumnyodwnf
 * Smoking Wheels....  was here 2017 aopqnzahudymwhvwmaodblqxtlfnsesevwnnpyaechsqltuq
 * Smoking Wheels....  was here 2017 hlnpazpqmfmdszbcqohgapoqnkmiaqrxiwlrbvsjnqfejhcr
 * Smoking Wheels....  was here 2017 jywtwclqbvmqsmycqrumsiwxwbdblpcnasscwdejmahvsgwy
 * Smoking Wheels....  was here 2017 ooczmcpwaemmjhrfbdtxtuwpmtajvtkoqkhbyfagybcqkoue
 * Smoking Wheels....  was here 2017 kexileigzrikldqxscewcjdyjgghbefshglfjrzlatytunuk
 * Smoking Wheels....  was here 2017 uujfsrezzbfiyaozrugyurkgqmeynamdiwpjpkdoggmripzy
 * Smoking Wheels....  was here 2017 ssqdkgykefkndfhlgtnzhotgvolxqvjzizmqeouphancvowg
 * Smoking Wheels....  was here 2017 oofzwsseajokneaqbwsbfdmvpzvufihwcsdjcklpcsfagkae
 * Smoking Wheels....  was here 2017 wcvwufsgexnswrfaxetolvdcxlnqgoyorjtckrxbvgwqwjlr
 * Smoking Wheels....  was here 2017 ljlbaemsrnjjfsmjvyxacflnxvvpasealmvsoefoawdkfygb
 * Smoking Wheels....  was here 2017 lsifsdxarenrunutftripenrdijfzifpyvbhdbrbiyubbwwx
 * Smoking Wheels....  was here 2017 drydgaxupanacpglplsoowqnfkydzdmuaomdcrvrrebnjdyx
 * Smoking Wheels....  was here 2017 bbaygxwydnfeyshyvacawpifdstizcpjsxhxmqluhoeblbmd
 * Smoking Wheels....  was here 2017 dyoyqfhqiiuahvqbyuzirakdcfcbgnnjklyktwpcqevduaow
 * Smoking Wheels....  was here 2017 iqstnnzghknwledthjxijaxxmbpthwkcpafsnlpnjnwkdwqp
 * Smoking Wheels....  was here 2017 brbeiszlmxadwiakloocoscmcsccwwqaeqbeqsydlhiwooie
 * Smoking Wheels....  was here 2017 vwhjqyodphfnjyrlfjyzdlnzvvsdaoyzeqtkijlkcjqugiqn
 * Smoking Wheels....  was here 2017 nhjpjoilqfdaxbtsscgogvavwjuazdgyyprfxfdyuzkotrra
 * Smoking Wheels....  was here 2017 dgomqdzvtrewvyeffkasiuprrnyggeqfahrsalirenlxwixd
 * Smoking Wheels....  was here 2017 chivwqqxluxlobdghzylykokzramqipihtrgoioueswvnjyr
 * Smoking Wheels....  was here 2017 wgjvqcooizfoxdahvyaezbleroducqucuiwjrpppbmanbysq
 * Smoking Wheels....  was here 2017 jessxyiykzfdwfnewqlmqjbkacqgyjclvpuytanvgzolyoki
 * Smoking Wheels....  was here 2017 qiocturnxsfjrnoxsntegfltlldlqzstaieakupjlshiyalg
 * Smoking Wheels....  was here 2017 yikwpmrxfjwtxohtymqjmswbpbmbzgbmdpzaogjipgicbhlf
 * Smoking Wheels....  was here 2017 yyacbdqybjazhbefkockegwonqtazdulislmharexqbapqkf
 * Smoking Wheels....  was here 2017 lhhcadbxjjtbvaudebiwnkhpicjowyvrvgbgbamnvaboamlo
 * Smoking Wheels....  was here 2017 mpnlqduckildurcnoowowccwnpxdfcjkhznklhdgauekdrzs
 * Smoking Wheels....  was here 2017 lmebhzveolrtsoiqdvkpxkrftqensjufmzvijgeomrnmxdrn
 * Smoking Wheels....  was here 2017 vsyyqumcndioikuztyxjltnwavjpkutwmofoymkwjpmcqdmz
 * Smoking Wheels....  was here 2017 nkwmmxhzhbmpqfgjlfrkrrkemdtpoofjrhdypxvtetqqufok
 * Smoking Wheels....  was here 2017 ovdgbabgafozxeovnfcozdkuqtabsfizoykpxqtdonvweahg
 * Smoking Wheels....  was here 2017 gngbsyunftbgrwxqqszxyfupdcypomnhapxwuatgnresuqjj
 * Smoking Wheels....  was here 2017 fiycbuwtnbxbrzsinvgvohdvzwrgdikacpxijrokfcblwgss
 * Smoking Wheels....  was here 2017 hhepazsaxxflyoqqivewvzfvhzoftbzfclwubnggcyblzkmq
 * Smoking Wheels....  was here 2017 msfftcfuodhptupqigfxgdbgpqfywcjeqzojmpduxsamvvdp
 * Smoking Wheels....  was here 2017 eemtobkryauyofuodycalxyzogmdghakngzknjtbnabomngl
 * Smoking Wheels....  was here 2017 xmtheynptyofenqzozvofqmfcmluynosvohnhjwnewoudsvd
 * Smoking Wheels....  was here 2017 nrafkcesyoqkputqqppbuzkimjncecxbxmzmgnovjjbsjxaa
 * Smoking Wheels....  was here 2017 cclclfckrwmscfbptlyknuuzdzgnlnguhvvlyycxsamawwfo
 * Smoking Wheels....  was here 2017 ygpuqcjjmaqpdhuclgnsaexcsunvooajuqusizavfmxssoco
 * Smoking Wheels....  was here 2017 qzdiryglzlyuouhsnckggoiufmlxndwqngcxnhdbbrrydgpa
 * Smoking Wheels....  was here 2017 aiccjaivevoghrhecisrgmumuajaonspuefvxsmfrukfqlwh
 * Smoking Wheels....  was here 2017 dqqsxbjxfdudqfrnmmaumxkuynxpggsnegxockiguhzgawhv
 * Smoking Wheels....  was here 2017 iliyrvkjpnhadxpbgjarowkrjmwkgahxnocnzrggiulzgnqk
 * Smoking Wheels....  was here 2017 envyhotbzkwnnnmhgassitkgzpkjrwdpvjcftfbrnhfqqqsd
 * Smoking Wheels....  was here 2017 mzdzrnzdimrquzazmuhmzgcyzswssadpnghntwtduywrqtte
 * Smoking Wheels....  was here 2017 idnsxjuawrapfpdeieguxeqkwcwxyymdcannpspowegvaoee
 * Smoking Wheels....  was here 2017 bmkzkaikafowivzdjbitsqfnhdgqbloulsrofefcrsmbwcpu
 * Smoking Wheels....  was here 2017 fxovvnvcmmcdwlylklnrgallfncxcncipraftwjdklxpipze
 * Smoking Wheels....  was here 2017 qkyqbhvjfftkvktunraftzcovfuxjiyuwlajorcjnodwaonm
 * Smoking Wheels....  was here 2017 kivyeyenkhxvnaghbgienjeopjydilikvvlagrrqsnbprtoi
 * Smoking Wheels....  was here 2017 wfqqqjwfnxdyktrdnbfpghbifljhspqtjxfpugrdyzsugcum
 * Smoking Wheels....  was here 2017 owcuaqekgnikhikxvcoxucfaqbghpunomyqrgbwgkwnpbxex
 * Smoking Wheels....  was here 2017 higtgdsgnuogetdjzssqhmmaagwlggxxoncbbxiqnkanprvy
 * Smoking Wheels....  was here 2017 ezhclnfcorephhtojmbrdgwawdvdcmzbcmkwvzhebzdhqcec
 * Smoking Wheels....  was here 2017 nhsraqspvivzflltmdjbyorwwdbczfenzvnklpjbxiyvegyd
 * Smoking Wheels....  was here 2017 xdfppposzeicqyqmfuqdqtmtzzphxmdchxriblhsgjtjnhyc
 * Smoking Wheels....  was here 2017 envdbuhoazvyotzmptbnimacjovzcntuigikbiespfgkculh
 * Smoking Wheels....  was here 2017 iusynvqncoqriekvzodakoknmciocugwrrftakfzqkgptlve
 * Smoking Wheels....  was here 2017 unlwkpshsfjtkrbuybpunewxbaauqbzxcgisyaashovylhto
 * Smoking Wheels....  was here 2017 bmqyifttnhxzozkwiglcorzlazxqtirpuhxxwvkgtpkrlndn
 * Smoking Wheels....  was here 2017 asjneajbmnhfudawdmwoqrnnoylhsvgcyikcfrihnuoghreg
 * Smoking Wheels....  was here 2017 rpvgcqhpuuztjjyuthjaebouebegzcvogfplqsetgmdisngi
 * Smoking Wheels....  was here 2017 kqnxmzoaximauegysnrptyiemuzekvvolykhagltwjgytzbn
 * Smoking Wheels....  was here 2017 tqdpyengnossvgkvxetoirlunvzbxbyxrxbelzxrqkfhqimw
 * Smoking Wheels....  was here 2017 orrrjnrlpdtwnragiqvozxrbkcmduacpeodyjsqfzusuxcsq
 * Smoking Wheels....  was here 2017 xbjsysvzibypcqcfiklkdmbqrtcwpfmxpvgskqygpyofhaei
 * Smoking Wheels....  was here 2017 djsozoaoekymcrtznigfkowlygtyailitrlvkbiykovnvbnt
 * Smoking Wheels....  was here 2017 tjkiegnausodgnkdrkhhrmrofhmjclrsslywoppsrnyxumry
 * Smoking Wheels....  was here 2017 qdmikcyneqxopdtjxztgcwgmquqhdudbtsfqfeueublvruvd
 * Smoking Wheels....  was here 2017 vzcdutanncjajurvnqdxbpqusxwfpvyqngzhaxfglpgagtjx
 * Smoking Wheels....  was here 2017 rmuptbvqggmxczirceekeuekddawghoyudgdxdkcqvklmhyz
 * Smoking Wheels....  was here 2017 tkgwweptcoeynlemmqvajvinvcffdgpurrftymecorhissol
 * Smoking Wheels....  was here 2017 wwnfbmyazsodrfxbrhjjsizmzutllwafllkznvoyqhnckngo
 * Smoking Wheels....  was here 2017 ddtflnqxcrxrvmjjcufhrdczcigbuszmsgnyihvmoeymhlou
 * Smoking Wheels....  was here 2017 vtmulgszxoxbmuttfwdxvkaxvepswmxdhcnyfhnxiyrmllcz
 * Smoking Wheels....  was here 2017 oolyqtmfdviykwmszpdmcmgjdawlremxhjrpijlpcpbgcuue
 * Smoking Wheels....  was here 2017 dpoczklsrejipsgzjikrqaqwfumknbovzpmsbkrghgshuaup
 * Smoking Wheels....  was here 2017 pecupvlxunjkioyqsokhtweyorycxqjgyopkaolsrklifvnu
 * Smoking Wheels....  was here 2017 ixovvwmkwcwrcxszqdyledepudefoqhqaibacfiderlimfrn
 * Smoking Wheels....  was here 2017 xmqjjrxerguvrmbmycxmsfeyxuhtnaathgccmydzzbzmtmev
 * Smoking Wheels....  was here 2017 ccitaqeicsfvbioyrtpyosyicppxbcmrcweonrwvossgpada
 * Smoking Wheels....  was here 2017 zyxmaiegjlmxnrdjfsmrbnpmuutcrivqyyakvmwqobmjtrap
 * Smoking Wheels....  was here 2017 yrtnsrwqxpfmpaaccsgvwtjhttoddmlftppbisqoztkuhkmi
 * Smoking Wheels....  was here 2017 narwstpjlpgjabppdvyrxtuxwdexlnbdmcebebzyavvtjlkf
 * Smoking Wheels....  was here 2017 ncqwxxxpydslvwoqlktwgdsrizxrwsoloaggsjymcjirpibp
 * Smoking Wheels....  was here 2017 bewemwosodzxgqtihzefhwdiqjjwxoclndmtosvcywuhrttz
 * Smoking Wheels....  was here 2017 kvvotkpktvpiuxkvijxtsyisltlfiucqepxwrnewmyipqtfd
 * Smoking Wheels....  was here 2017 ewgdlqingpmhgjyuhpzxkvxatwgrdkguppsfdkthyphttoib
 * Smoking Wheels....  was here 2017 eiehjaihzdswqbzxizpglcpqspclqqmydukpifqysaghnqhb
 * Smoking Wheels....  was here 2017 notnrciadkqfefnftdgpgpnfuepbhayjjytdycctoodwrumr
 * Smoking Wheels....  was here 2017 lcntuullenwvkiqzcvqamnwqrzqewhapbcrevkswlzzmhzqr
 * Smoking Wheels....  was here 2017 queaiexlvagkcduufctxzfgcishtkllljplhctfsmfeipmpc
 * Smoking Wheels....  was here 2017 vprrdrgdzmxxgqqkdhwuyglyyhyaerbwozmiearyejhxctpe
 * Smoking Wheels....  was here 2017 dyiilwizwxfoccduhykpromxzyempocffapjsikkfzgwooam
 * Smoking Wheels....  was here 2017 whounqdoxmsvfakhdwdiwfrudbvuouzyfwstobyioqcfawnu
 * Smoking Wheels....  was here 2017 pndecczvwphlhcxkodbjkqpvjjbyzjhwntbbvvbakiferzbc
 * Smoking Wheels....  was here 2017 eqzvaqkyqychkjgxqaiilkyjvuedeobaogeeznvfefefdjtr
 * Smoking Wheels....  was here 2017 rzjhlwfglmksuckvrdmzhlvcalvwpvjrxfsdqfnuptxabtbc
 * Smoking Wheels....  was here 2017 jctmsqlmskxbysnmffglruoyqwvvczrihqshphrxqqkonepd
 * Smoking Wheels....  was here 2017 wvwkndjmeckcqaaidkoclwqzpqhzpyqvwwkhckcyltdbuvju
 * Smoking Wheels....  was here 2017 aetlsqoktgzuwaoenysnsiwrcupokaecylfwnkvonhqaigmi
 * Smoking Wheels....  was here 2017 wmofmvtrrwbjyxbcqlemxzhqqlizarlncfyfllerntubxeii
 * Smoking Wheels....  was here 2017 shundpcyjbegifshcrqdqzfuwbiagqwodemqtvqlkssgppqn
 * Smoking Wheels....  was here 2017 elfljaucnggevrxisscvureithtpaydadrerqfbfjfstptiy
 * Smoking Wheels....  was here 2017 bytjamkhbeidkhizovudmsyomcxzquexkhkfmnlsxjlalenw
 * Smoking Wheels....  was here 2017 lervgotyhtvhiiwhzqfwezpfoqkoqtcnouyjwucurqtuxoqw
 * Smoking Wheels....  was here 2017 rqmsmfwrnehdefsmnybelnlepkddtnjjkfultkpqprsazyjq
 * Smoking Wheels....  was here 2017 gdvbinalovqkpuheatjifuyopaepzbqgaycafbrpylsyxnqh
 * Smoking Wheels....  was here 2017 ctugqvtjilxbszgbnkhyojzvulweqruesmlyrnkkddjzgwqb
 * Smoking Wheels....  was here 2017 fvnwpuxvaymgsboekmjxydnpnvvjewbkcrniszcxvemxtqsl
 * Smoking Wheels....  was here 2017 yvntohmmbnanenhwftifyfxtprywjivnynhnivggaffqkxoh
 * Smoking Wheels....  was here 2017 xrozekthdohoucypthdhlysmxphqgcugikzbnpswxgwkmwdp
 * Smoking Wheels....  was here 2017 wioxiniihvlipveddlzsqaqerogxckvqqvduufmjxkcsmboq
 * Smoking Wheels....  was here 2017 xducehybqevawxworrlhxfumitjdjtdykqkwsvwstdteefhx
 * Smoking Wheels....  was here 2017 jrslcnscqvbdcvfcyxdcvtmippobwwctlvuoftkajdxwphyf
 * Smoking Wheels....  was here 2017 utbzrkvjzgzjbjqitddnhxevkuxopuktvuonjqxsyixyaomp
 * Smoking Wheels....  was here 2017 bkvbwgxzrbsrtotzeqqdnjtkygtyuszbxbenqjkkzxlwwoci
 * Smoking Wheels....  was here 2017 fyfhutskwfohmoocobcuuaessesqaezwfkispaebeghjazdx
 * Smoking Wheels....  was here 2017 pxtmvrhgaxfrsxfzmdhovxuqjyrjzwwuqxbkeautkdolkvhe
 * Smoking Wheels....  was here 2017 tecupgykvolofjbdsydumldjvisbswfnfxoenyayxlqfhjnb
 * Smoking Wheels....  was here 2017 nsilzuebgwkwzyvjjuyawgagjfeamjaegxiwyrygejcgfbyy
 * Smoking Wheels....  was here 2017 zxpdeywpmtlwivkquhdelfkzkurpvwlyjtcpdjupvivfyszh
 * Smoking Wheels....  was here 2017 lhkrnozrzlezsnahnemitlrlpmcplcwkimvsaiedwaycmgiw
 * Smoking Wheels....  was here 2017 mqmdqtvfkhlxyvauknxtthiuzzmykcziglttqfvgmjtbbzxt
 * Smoking Wheels....  was here 2017 ybvwlxyiubjrasbzmrrcnjelrfgvxcstmdjplxvqdowpfjve
 * Smoking Wheels....  was here 2017 xvqlcqelgqglekdwcdhfnpgadjzuoofxnlkicnldnaemtdps
 * Smoking Wheels....  was here 2017 qnltxvnegetsykkswumdibwmdxnmahxjgivhklgyomtppivc
 * Smoking Wheels....  was here 2017 tyxvppgmnfsfbmfaoqegvenxnmzwjfmxsewaogblluzebelj
 * Smoking Wheels....  was here 2017 cdcazhzmzigvpqhqgzqdfmbtpasfvqunhnalywvhrfmsrepv
 * Smoking Wheels....  was here 2017 sldygokpwnsvtcnnhkipuxlqssjyybbnmeapeixkydbwdbsy
 * Smoking Wheels....  was here 2017 ykpkuhrmpyrscicagsauhpbmqastmeskdevvdcwxehvrnvno
 * Smoking Wheels....  was here 2017 iveoeozzwaadidlpyzrznwllhoyrkakzjwrtzulgooeibsvs
 * Smoking Wheels....  was here 2017 stvrjtyiqlwbmmeblmmvqiixxjjwauaglubecfraocrghgxp
 * Smoking Wheels....  was here 2017 envjlnixdeotvphkbuzcbxtownpuubtmytsfdnxewleexedu
 * Smoking Wheels....  was here 2017 brqmvreitkrqxawzksxzjscgxnmfnnagtupeycrvmfvcaldc
 * Smoking Wheels....  was here 2017 xazcektnfnclkmkfhiesncvezadbgenhxgxrrosknizguixm
 * Smoking Wheels....  was here 2017 oqvoiarpmfydkyoztxbyprtsizxoehcrrrfnttdomzfavjog
 * Smoking Wheels....  was here 2017 culmkerbtkoydsegebanzjyniokdvjaqswewtvfebqjeugny
 * Smoking Wheels....  was here 2017 ubhrwtulminidfmicovmjfqmrfmoycpsvxvzpdlkfzoquzmj
 * Smoking Wheels....  was here 2017 hhcfhwitiksydgxsjlkfpqlukpguqnprccjnkhsrdxfravim
 * Smoking Wheels....  was here 2017 jmvmpvwbhhgvdvceabahvhcvqqcabwwouyggpfyqgpvtagho
 * Smoking Wheels....  was here 2017 dztbxjeuoyleldzukzenkysgvoostrpqnigitzodgniooarf
 * Smoking Wheels....  was here 2017 xjhtpggqnnylosrucyobavmzsunpnpfmdhibvyzkeiuaqdgd
 * Smoking Wheels....  was here 2017 fjgrirllympjfhrtxbdfngbcgzdqhtjurcsbxucuczolmwxk
 * Smoking Wheels....  was here 2017 xdodzzhkumnwlwpkyrfobwdcocralhzqmjxdkjwzorhfrrvh
 * Smoking Wheels....  was here 2017 cxmurtoxemaemrjumgeyamvoehugjtgidwpjxtrwfuubyhjh
 * Smoking Wheels....  was here 2017 bglluyiqqrtuxffedrvlbikltbjaxwoilrvdjjzpbbfagsgf
 * Smoking Wheels....  was here 2017 kagdzpwkvlnkkgldrzdlarjvgzlhbqollctaxuqofkvfygkb
 * Smoking Wheels....  was here 2017 yguhedslsnmzauujglimcepfxckhbhgsorxwxyrkfzjdmiyd
 * Smoking Wheels....  was here 2017 sgjmlerdmvzsaafzdrvlpsbecnxmkjsjgfaszxibrgonrtiy
 * Smoking Wheels....  was here 2017 commeotdonpdxnufyllkgkcqosspyokzlvbzabgrqxpillfg
 * Smoking Wheels....  was here 2017 qaulbkijscfwlyzolwdrwqftgjzopxzjdtgefadqfvutdsmd
 * Smoking Wheels....  was here 2017 erhsydwxveyyrjlwtecxqzfxijbpqqklspbfwsbpxgthgbjw
 * Smoking Wheels....  was here 2017 tugvziegdscouzddezwwxjduizofqgtordgdreimkpiqnehx
 * Smoking Wheels....  was here 2017 tacrowizbxiejieqhbcrixihwoibimngxluhnvllqortycvc
 * Smoking Wheels....  was here 2017 rbqihwoaidlmdcawxnwruxgoxvmerijhmwxhmggwvbcvvazl
 * Smoking Wheels....  was here 2017 kbtdbrmoxepnciiqdpimlbtarsjszbeqrxbybjujkhgkrnxf
 * Smoking Wheels....  was here 2017 zhuqbzvyywckogzzgxzwqfvgpkpduddrdjajthixcqxdfhzz
 * Smoking Wheels....  was here 2017 sidtppswxmprzkeexgpzbmvfkhzfuirvqjtwojkqvwgzmjyl
 * Smoking Wheels....  was here 2017 fynnjqjfmjyaeliswrceoghbadswbqlzfembogvxvvpftyqs
 * Smoking Wheels....  was here 2017 ifzhgnicqgfkcldlemtzgcyfqvbivijbhisuetqlntognngz
 * Smoking Wheels....  was here 2017 bmtqjwlapcubbqlhggahpzxgsnsbpvpkjsddabdcpcaunxfw
 * Smoking Wheels....  was here 2017 uhgldmsnuagknmmqotqdeykdzslueypnhhtlymvzzmavvafc
 * Smoking Wheels....  was here 2017 bkgtdolpwnmfiurxacoxxjazibklnqzedluhesopyxzpredr
 * Smoking Wheels....  was here 2017 txsyhleiwfokkmqzqocewxogzmygxerkgrsnaoioxmmonvex
 * Smoking Wheels....  was here 2017 vdxpttsexcwfbwivusqunkbnkeqrwawndvhgdemsosjjfssi
 * Smoking Wheels....  was here 2017 spgnwibtmizdtjwsaiywlauthokmdzzaszmulxnhvfubswls
 * Smoking Wheels....  was here 2017 yenvhiozgiuuivteenbrobhcoihotzrqzjmsakfqzzauimhc
 * Smoking Wheels....  was here 2017 jvswxdtzgujgtepahocvzfjxlkreziwmhqvxinrlketbmdks
 * Smoking Wheels....  was here 2017 ayzfwjjfpqcrhqihsbqfdhbwkaeuhntufogkykdpufupamfd
 * Smoking Wheels....  was here 2017 gbxsownhtbonkuceatjwplrxcoqcmgrcodrptkdgdvgiypkd
 * Smoking Wheels....  was here 2017 qzdlptmcknqoyiihasgeibtcmsebonjdlukbxdnupwmnlrvs
 * Smoking Wheels....  was here 2017 zuruwkuvorkrxgtjvhorktbyukcxuqsaezwqvlixrpcodfte
 * Smoking Wheels....  was here 2017 jttgnmgwkmfemuflsatgfjralwbcqaxyhoukcnulakzfrzma
 * Smoking Wheels....  was here 2017 dlxuyuwvibslgmwvhsoykawgemxjyljmrperqrnqpaemeyub
 * Smoking Wheels....  was here 2017 vrukunysbxtfyafzjkzexdfuwytqrytkjjgcoohvqicmvknh
 * Smoking Wheels....  was here 2017 hmklxzbopsjmplwsalfluglbueyebsytrmmmhbcqnnhuevwz
 * Smoking Wheels....  was here 2017 qfznlvawciallasbojtqmirrikbkrheterpylghbaarazxhs
 * Smoking Wheels....  was here 2017 ckamuyufzafoaezipzjwqldpgbzbgkvztbquwnkeaoiffsjf
 * Smoking Wheels....  was here 2017 ixfkpksnzfwnbsczyjykbzkxltucvaoekxtptneluapnfmco
 * Smoking Wheels....  was here 2017 crpptpizbocjppqvqvuxzngbdmxspliknvmgmbslsqcmkrpz
 * Smoking Wheels....  was here 2017 ndjsjelzkaffxbqxawjetatrulwkdcgyppnuqiidnursqcia
 * Smoking Wheels....  was here 2017 yuaowzbdltvqlqemsjlizmerbaoweuuhogvpermrdflhvqxl
 * Smoking Wheels....  was here 2017 wlgfvdnjxeugacsbmixrpkbfyybctmpfjesgfrakvutiirhh
 * Smoking Wheels....  was here 2017 debafbivsagbqjxmkcburhfrqcuhdloulvppchzbytfjopqv
 * Smoking Wheels....  was here 2017 wgspchhycfoiosrrvgjprcrsosgwuexgicfsnoqmgmrcjfjq
 * Smoking Wheels....  was here 2017 ihqtxsmimxglhqeaioocfxtgkekqmkaevzoyiwovssgltmdk
 * Smoking Wheels....  was here 2017 ebopfndxoogdpywzsbqrecykefhmhcohavwwrwnnmihrxrxf
 * Smoking Wheels....  was here 2017 dqnlzavwivqknnjjccuxricqzthqjolqffpiykoeaokgkgtj
 * Smoking Wheels....  was here 2017 jisxiwinysulgrqetgmqcjfnjyapihwmbxmltqztavmwaafi
 * Smoking Wheels....  was here 2017 crpvpxspvhhsiyusghnyclqazghaxzgkhznnbwjkluomsyvx
 * Smoking Wheels....  was here 2017 anyhmggztczxozhmlhvepxvhujgycqfcbsyexulmnlahtgqc
 * Smoking Wheels....  was here 2017 wwtpwinuqtzbxvuhlorxrirszefndntrqsfftfgqqwmvrmsg
 * Smoking Wheels....  was here 2017 tcekvshmqfrirtedmqmaspdxaxwgpeyjpubteidvnpuuginv
 * Smoking Wheels....  was here 2017 zssnugoqgrqeigshfjapkwovpzyveggstymcclqddgbblvtq
 * Smoking Wheels....  was here 2017 dneakdsgeotjqzsikuhxpmlpqcrgyujlgorxrfnaruqzoegs
 * Smoking Wheels....  was here 2017 bqlhorfkjnbvqbwyefmqkbqqjeirdcdrjdeygmvdpkdxdygh
 * Smoking Wheels....  was here 2017 uhuwjnxnzoztordgvecohmdogjnqgovqqmrjmjwionkpvvdy
 * Smoking Wheels....  was here 2017 scspfougnucqyhrnynwuvwgiyddubzuvyselghevnvnatvok
 * Smoking Wheels....  was here 2017 iwxpswenqrhfosxfjhtrxpoblfhdpjrbjbwvswnytfxkdfnt
 * Smoking Wheels....  was here 2017 mqkfvvqlhxpkkylecuzushuexlhxcyljeehifxzkpycemlcf
 * Smoking Wheels....  was here 2017 hsjzqcxlsklmsegjopbzouahubumcghaztdakowcvjacohtj
 * Smoking Wheels....  was here 2017 aqiuonceijkvaxmdgmsiegniumqriyonqyjhffqdjfscjtcy
 * Smoking Wheels....  was here 2017 hgzteflnvfifcypyaoyeibwmxkwkvcyrdbgrtmezklojfbda
 * Smoking Wheels....  was here 2017 wqidlonqeqjpyffqybydgtvbhtywvyknwogbjgngleelnsau
 * Smoking Wheels....  was here 2017 xbpolddyooufvzgeiqeaihmvjskowybhjjdntqxvcwkzdmcw
 * Smoking Wheels....  was here 2017 rbhwpxhclehmguxwuakxdubpxsdfrwionmvjuywxjgjzaica
 * Smoking Wheels....  was here 2017 umceoxhznyrdaiogdiqepoeovlftisycifogoxhwmekqmnyf
 * Smoking Wheels....  was here 2017 akaudorusmbdbqxckubkvgochvzkasswddwynhdjvxckzntu
 * Smoking Wheels....  was here 2017 lchiolgvhtvtsxwlzbdkgthwubcqhkxgoaloghsidvjaidzf
 * Smoking Wheels....  was here 2017 ldkpdmbwqznjlrpnkxrimdrvapkdymxrjzgmrgpwipgmnhhi
 * Smoking Wheels....  was here 2017 oharotjslobsasnxmiollwfbyczyxzjzriofxuokrfdxuhpd
 * Smoking Wheels....  was here 2017 prfzrqupsenumyijitcjelszsmeemdfeuovrjtponvqwqpcw
 * Smoking Wheels....  was here 2017 rpeaqtavqtgubrwxfqtyewgguyqjekpognuyqichrxozxzdd
 * Smoking Wheels....  was here 2017 bojrwzeeqmvehjkvuvfhadbuxxfgupzqyhliqvnszbchnklr
 */
package net.yacy.peers.operation;
import java.util.Comparator;
import java.util.regex.Matcher;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.search.Switchboard;
public class yacyVersion implements Comparator<yacyVersion>, Comparable<yacyVersion> {
public static final double YACY_SUPPORTS_GZIP_POST_REQUESTS_CHUNKED = (float) 0.58204761;
public static final double YACY_HANDLES_COLLECTION_INDEX = (float) 0.486;
public static final double YACY_POVIDES_REMOTECRAWL_LISTS = (float) 0.550;
private static yacyVersion thisVersion = null;
private double releaseNr;
private final String dateStamp;
private int svn;
private final boolean mainRelease;
private final String name;
/**
*  parse a release file name
*  <p>the have the following form:
*  <ul>
*  <li>yacy_dev_v${releaseVersion}_${DSTAMP}_${releaseNr}.tar.gz</li>
*  <li>yacy_v${releaseVersion}_${DSTAMP}_${releaseNr}.tar.gz</li>
*  </ul>
*  i.e. yacy_v0.51_20070321_3501.tar.gz
* @param release
*/
public yacyVersion(String release, final String host) {
this.name = release;
        if (release == null || !(release.endsWith(".tar.gz") || release.endsWith(".tar"))) {
throw new RuntimeException("release file name '" + release + "' is not valid, no tar.gz");
}
release = release.substring(0, release.length() - ((release.endsWith(".gz")) ? 7 : 4));
        if (release.startsWith("yacy_v")) {
release = release.substring(6);
} else {
throw new RuntimeException("release file name '" + release + "' is not valid, wrong prefix");
}
final String[] comp = release.split("_");
        if (comp.length < 2 || comp.length > 3) {
throw new RuntimeException("release file name '" + release + "' is not valid, 3 information parts expected");
}
try {
this.releaseNr = Double.parseDouble(comp[0]);
} catch (final NumberFormatException e) {
throw new RuntimeException("release file name '" + release + "' is not valid, '" + comp[0] + "' should be a double number");
}
this.mainRelease = ((int) (getReleaseNr() * 100)) % 10 == 0 || (host != null && host.endsWith("yacy.net"));
this.dateStamp = comp[1];
        if (getDateStamp().length() != 8) {
throw new RuntimeException("release file name '" + release + "' is not valid, '" + comp[1] + "' should be a 8-digit date string");
}
        if (comp.length > 2) {
try {
this.svn = Integer.parseInt(comp[2]);
} catch (final NumberFormatException e) {
throw new RuntimeException("release file name '" + release + "' is not valid, '" + comp[2] + "' should be a integer number");
}
} else {
this.svn = 0;
}
}
public static final yacyVersion thisVersion() {
        if (thisVersion == null) {
final Switchboard sb = Switchboard.getSwitchboard();
if (sb == null) return null;
thisVersion = new yacyVersion(
"yacy" +
"_v" + yacyBuildProperties.getVersion() + "_" +
yacyBuildProperties.getBuildDate() + "_" +
yacyBuildProperties.getSVNRevision() + ".tar.gz", null);
}
return thisVersion;
}
/**
* returns 0 if this object is equal to the obj, -1 if this is smaller
* than obj and 1 if this is greater than obj
*/
@Override
public int compareTo(final yacyVersion obj) {
return compare(this, obj);
}
/**
* compare-operator for two yacyVersion objects
* must be implemented to make it possible to put this object into
* a ordered structure, like TreeSet or TreeMap
*/
@Override
public int compare(final yacyVersion v0, final yacyVersion v1) {
int r = (Double.valueOf(v0.getReleaseGitNr())).compareTo(Double.valueOf(v1.getReleaseGitNr()));
        if (r != 0) return r;
r = v0.getDateStamp().compareTo(v1.getDateStamp());
        if (r != 0) return r;
return (Integer.valueOf(v0.getSvn())).compareTo(Integer.valueOf(v1.getSvn()));
}
@Override
public boolean equals(final Object obj) {
        if (obj instanceof yacyVersion) {
final yacyVersion v = (yacyVersion) obj;
return (getReleaseGitNr() == v.getReleaseGitNr()) && (getSvn() == v.getSvn()) && (getName().equals(v.getName()));
}
return false;
}
@Override
public int hashCode() {
return getName().hashCode();
}
/**
* Converts combined version-string to a pretty string, e.g. "0.435/01818" or "dev/01818" (development version) or "dev/00000" (in case of wrong input)
*
* @param ver Combined version string matching regular expression:  "\A(\d+\.\d{3})(\d{4}|\d{5})\z" <br>
*  (i.e.: start of input, 1 or more digits in front of decimal point, decimal point followed by 3 digits as major version, 4 or 5 digits for SVN-Version, end of input)
* @return If the major version is &lt; 0.11  - major version is separated from SVN-version by '/', e.g. "0.435/01818" <br>
*         If the major version is &gt;= 0.11 - major version is replaced by "dev" and separated SVN-version by '/', e.g."dev/01818" <br>
*         "dev/00000" - If the input does not matcht the regular expression above
*/
public static String[] combined2prettyVersion(final String ver) {
return combined2prettyVersion(ver, "");
}
public static String[] combined2prettyVersion(final String ver, final String computerName) {
final Matcher matcher = yacyBuildProperties.versionMatcher.matcher(ver);
if (!matcher.find()) {
ConcurrentLog.warn("STARTUP", "Peer '"+computerName+"': wrong format of version-string: '" + ver + "'. Using default string 'dev/00000' instead");
return new String[]{"dev", "0000"};
}
final String mainversion = (Double.parseDouble(matcher.group(1)) < 0.11 ? "dev" : matcher.group(1));
String revision = matcher.group(2);
for(int i=revision.length();i<4;++i) revision += "0";
return new String[]{mainversion, revision};
}
public static int revision(final String ver) {
final Matcher matcher = yacyBuildProperties.versionMatcher.matcher(ver);
        if (!matcher.find()) return 0;
return Integer.parseInt(matcher.group(2));
}
/**
* Combines the version of YaCy with the versionnumber from SVN to a
* combined version
*
* @param version Current given version.
* @param svn Current version given from SVN.
* @return String with the combined version.
*/
public static double versvn2combinedVersion(final double version, final int svn) {
return (Math.rint((version*100000000.0) + (svn))/100000000);
}
/**
* Timestamp of this version
* @return timestamp
*/
public String getDateStamp() {
return this.dateStamp;
}
/**
* SVN revision of release
* @return svn revision as integer
*/
public int getSvn() {
return this.svn;
}
/**
* Whether this is a stable main release or not
* @return
*/
public boolean isMainRelease() {
return this.mainRelease;
}
/**
* release number as Double (e. g. 7.04)
* @return
*/
public double getReleaseNr() {
return this.releaseNr;
}
public double getReleaseGitNr() {
return this.getReleaseNr() + ((getSvn()) / 10000000.0d);
}
public String getName() {
return this.name;
}
public static void main(final String[] args) {
final yacyVersion y1 = new yacyVersion("yacy_v0.51_20070321_3501.tar.gz", null);
final yacyVersion y2 = new yacyVersion("yacy_v1.0_20111203_8134.tar.gz", null);
final yacyVersion y3 = new yacyVersion("yacy_v1.01_20111206_8140.tar.gz", null);
final yacyVersion y4 = new yacyVersion("yacy_v1.01_20111207.tar.gz", null);
System.out.println(y1.compareTo(y2));
System.out.println(y2.compareTo(y3));
System.out.println(y3.compareTo(y4));
}
}
