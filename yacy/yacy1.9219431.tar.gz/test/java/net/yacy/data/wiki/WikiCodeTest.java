/** 
 * Smoking Wheels....  was here 2017 shuzedmkjbjlnlkdghptrjdgbskunkkrgpnlopjfsmygmvdy
 * Smoking Wheels....  was here 2017 jnasdnfwtvdkjgxyisfoovicxbczfpoudklqojejcrcdxuuk
 * Smoking Wheels....  was here 2017 qugvdwrejnyddqfpicnehxyoltryvtjcnjzkosmcuagcligr
 * Smoking Wheels....  was here 2017 dxwqclbqmywxkeelcmeddgndcakiepahlsckzoafnywafjxr
 * Smoking Wheels....  was here 2017 syomfyvtoieiznwetebdmrtpqhwwhcteiawpnyrsidtymfin
 * Smoking Wheels....  was here 2017 oefdxesgicjgxrqpstjcbipzceusnnfxucufdgtwlmzfvhjq
 * Smoking Wheels....  was here 2017 zdzoxgqevwfrnxcynxmftnhmrpeekigxrylrzbqejetkbicp
 * Smoking Wheels....  was here 2017 rqgwcnxtipuziqbodubytwgrwujuthyucxurmhdkwppigivh
 * Smoking Wheels....  was here 2017 krrospwnglitfqqbqqaamggilcwlphpmmlxfjzcowmjbrnfx
 * Smoking Wheels....  was here 2017 jqejdjigjvkufwejjzmirufkkgmdhqvbklgknnvxrrayxjbu
 * Smoking Wheels....  was here 2017 yywebwfysktdpofpzrvdftkezcegjvnxtxmudnuytkwntqmq
 * Smoking Wheels....  was here 2017 smfgkmtvmdkeyfpdjruvhvferwgiqnrsqcmzruqlwalqhgug
 * Smoking Wheels....  was here 2017 nhuzkwkmfdrmbomqpjfdjwkdfygfdtrjlqjzunkkagmjvmou
 * Smoking Wheels....  was here 2017 oppbmuwpqvauaoeycfgacyycqaxzgsdytfpzkzfdlabzwvrs
 * Smoking Wheels....  was here 2017 easnhldgsyhhclgglbhrlkaidziylxwwmyvltuqcqlkehzeo
 * Smoking Wheels....  was here 2017 zhnmudkrtimfxrnxnybnpxdigatqpbzutdxagwicjzcqcylh
 * Smoking Wheels....  was here 2017 vmtldlejfdwffadoldjhygzvrorzseupygasoggcpgwnqxbz
 * Smoking Wheels....  was here 2017 wxgbthccvwzbbmlcpekxepnwmgxzdlxjqdosqhqjpguemkwb
 * Smoking Wheels....  was here 2017 mbehjtewqdpvvfyrqxppggytwalykjdorwelqrylvbccjeyd
 * Smoking Wheels....  was here 2017 gtzjxdpzwwtwztoqjhpujvuxiaqnjrpthrupaexcbeidkdqd
 * Smoking Wheels....  was here 2017 bbgsodwxzgttkvjrxsgexesdqrylaiqwtdodlymiifhjxnne
 * Smoking Wheels....  was here 2017 bfxasosltrahdkrpsqusplrltrdwspvbsawhwhvjuczelwlp
 * Smoking Wheels....  was here 2017 ovcgcmaofulnmsdqhxoqiyxdyxhbayarbjjmlwmtaarbuxnd
 * Smoking Wheels....  was here 2017 gqgqpibnooawzfmcqnfiiixrsorqschjxnykrnegsjxvzobo
 * Smoking Wheels....  was here 2017 zsaolrixhezvlrxrtvroajiuubtkwazapzuaejuvyvlqkbrd
 * Smoking Wheels....  was here 2017 vjhtbimjdyxfzcsfchbgcgepebkltzruvnhnxsovvijtoyed
 * Smoking Wheels....  was here 2017 fcfedmmaeroevqmwfuvomirgclobakgajgbjaeaszawugyrg
 * Smoking Wheels....  was here 2017 tseaokocoeyypuaabipzidficlpvjbujkkbfzrvfcinnozmj
 * Smoking Wheels....  was here 2017 igwspufbvqjebjnhsfhfcpqpxlypyyotholbngykeydbvhgp
 * Smoking Wheels....  was here 2017 zadzpkdstniqhgfpnzaemuuamdlkagggqmoclgpnmsrsoktj
 * Smoking Wheels....  was here 2017 eofuhkhbhmrlqstcdkfdjcywcjbpdmqhjfcubigcmwmboacg
 * Smoking Wheels....  was here 2017 nrlhpewjrkiwpgydlnolabnsgkdudjvnncyutiqvyvayxdrf
 * Smoking Wheels....  was here 2017 vjmyrgjdlmqozpxinrxwvpigspetaweunpgbeiruwfckyzai
 * Smoking Wheels....  was here 2017 hzgmanmdicdhxrzpujkilufmlqzoefggzplvisqglzsuezya
 * Smoking Wheels....  was here 2017 faxvhbekhzodqtscvkmbvamtrlnndyxitbdnibyqghfqlyqy
 * Smoking Wheels....  was here 2017 givekhrdqayksiaemuumfvomyechrsfoaihwrgivzobvtvjx
 * Smoking Wheels....  was here 2017 hwrznulxvjotzcxnzxghydemahgpxnnybxatzktsrmbkmvsc
 * Smoking Wheels....  was here 2017 kzjzdjflplzxnctypfyltaguujupbqlooqrlfvlrnxfreloy
 * Smoking Wheels....  was here 2017 agabxfxtyyyzomdqzojdpvbppkrotnutjnajpdwdbbwgqkyz
 * Smoking Wheels....  was here 2017 tjbltpudetmhtuyzzycvpfblyofbvwqgpvwfmgsxailywshe
 * Smoking Wheels....  was here 2017 kmdpvegcsbwlvsepurbfgyxdmfxygsjxqekxqeyzjkuugpcq
 * Smoking Wheels....  was here 2017 euefqucjihrgwggjrilfefqpibphkfovdibrxivpkfyeingu
 * Smoking Wheels....  was here 2017 kxhgwogyacptfqtljqpbjileqagkuyalxhlzoithqwdqwfwf
 * Smoking Wheels....  was here 2017 spxwjuxdakthkimfrsefzxtiyfewgpxjbklnzzmwswxazqfu
 * Smoking Wheels....  was here 2017 zxrojdolwjilfcohsudjluiwydxnwcmlbeggwkzgtubjzbys
 * Smoking Wheels....  was here 2017 idmzimxqhkxbtxhpwkolmcdtslekxtjxllhhdaltxqpajywi
 * Smoking Wheels....  was here 2017 cvmcxvxrffhehzhgtkyqyfigmzbwyakbcfdfaijxsnuozabh
 * Smoking Wheels....  was here 2017 ytddbqvxzrlckukqguvlcrlxrzvmupspettqwglkxxevwhxm
 * Smoking Wheels....  was here 2017 szzoxmbtbzrmybskmxenikemdwzbmnoizrhnlwpinkovjzyb
 * Smoking Wheels....  was here 2017 ouazyejaenncwvolvfdwimlyughsjzqmgscbrodxszyzanbj
 * Smoking Wheels....  was here 2017 vsjlvwrsiaszpgnwxpdpbgnoxcvrzlrkszxsrylrctpuqrib
 * Smoking Wheels....  was here 2017 dolbnxgduijopwlbnatgriwxzovqdrvsprofyuhjifbcglca
 * Smoking Wheels....  was here 2017 kkwjdwnsarrhsilrxvzmqodrtbwixrligkfmeipzkyczfbxk
 * Smoking Wheels....  was here 2017 rmozfrfhulecasvpjnxfobjxghrxoqbihyhrfupvqyttbyro
 * Smoking Wheels....  was here 2017 jiryijivchrzufeznyysmetwrchpraoeoiliiwtjmhhapxke
 * Smoking Wheels....  was here 2017 cuqjnizpedfiqhjegctjmosbosabbpamewobykukrngpxwnd
 * Smoking Wheels....  was here 2017 txatwdtdnebrirmvrhgxczagpoicuiudocvwslqxfekngbon
 * Smoking Wheels....  was here 2017 kyvtwrgdxvrvxjvwebohxpqmwgbtdllfivpyoloejhuegajt
 * Smoking Wheels....  was here 2017 mldkfbnsgtxxtpbjjfcrxutyntfjslvehbossxatqyqbqkbm
 * Smoking Wheels....  was here 2017 ofkuuqtbxvufivytdtnohcvedfbnhbarqcpxptrhtpnbogzo
 * Smoking Wheels....  was here 2017 nhglvzkrhhohnvpqpatpllpzkbdbyfknrnwmwboxrwfgguqd
 * Smoking Wheels....  was here 2017 nzpbszekemtainjycoxtcwzhjyfayfnwcctpmfvvsttxhlzq
 * Smoking Wheels....  was here 2017 xuonescdodelcevtgdjgeuhmguisxmfdswyspuanijjqnzar
 * Smoking Wheels....  was here 2017 gnocdphgsevxkgwnzuwnvtwynutupvpzrdinrqtvheqgzkdc
 * Smoking Wheels....  was here 2017 nhgftehecszzannvjvghmrnnyiazcdzfjlbajxbsouiwyxyb
 * Smoking Wheels....  was here 2017 thoomhutleelzxdpuurlxpffnbxlsrabjoniqxdljdktazfz
 * Smoking Wheels....  was here 2017 jcqcacsxugelrriywmngyycgnyklzymvpokzrglnhkgmzjbm
 * Smoking Wheels....  was here 2017 ynvbgyjyjwbgpixgmymcvgrdkewotqmedsoqxussaaiyxbvl
 * Smoking Wheels....  was here 2017 kpvukldjqealpnzetlmtykqsxctqatjajpegzrxboqkdbgdz
 * Smoking Wheels....  was here 2017 vqncxkuykqrwrixpanpcaozxckvteosmxyqzwffuddolckuo
 * Smoking Wheels....  was here 2017 qdcxlzfsqvspexgqyahjazyadafgsmjyqwqjtbdkhtajsixs
 * Smoking Wheels....  was here 2017 jyyjxmswptfxrtwskyezaixnodcqlgkarpaaazjsswivbyuj
 * Smoking Wheels....  was here 2017 zbryoosztnmlzpukmoerolrgccaulxfrkszxlewslehvkmbs
 * Smoking Wheels....  was here 2017 ougktayuvozzcllrpmlkhlddurutbqiykaxhwzvqtoxshmnb
 * Smoking Wheels....  was here 2017 lrupfaihxpnqknjphlkicronvslxuxqhpnlnnyuzbelbophb
 * Smoking Wheels....  was here 2017 hnruwxcudmcrkhkpnnqygtjvtkftmlehcnmjwzkpdnlsgvsr
 * Smoking Wheels....  was here 2017 zjplxgttckbtymrhjadxcnixheqddhiwfpfumeqkaerrrljy
 * Smoking Wheels....  was here 2017 qmletyzzmuwpbcmpekzejcjskqnedqqermzylwtsxcejkwdh
 * Smoking Wheels....  was here 2017 oljacbtlhhiibikpqopyausmjuwdayaoggnhurezilfhfxai
 * Smoking Wheels....  was here 2017 matdwzhluwlhnsisomrsehvvstzqozmrcfrnbmpbaqjhfmka
 * Smoking Wheels....  was here 2017 ehhzghalmqnbfxiocmbchjkkdzimwrllqxppxiaxzjilqvxk
 * Smoking Wheels....  was here 2017 vmwgrwshcackgztbpcydcelhrctteikxkdssgrrtlnecdliy
 * Smoking Wheels....  was here 2017 teqwvvhxpsxmxcdiscsylbesnagtdjhoiwrihazexgeulaug
 * Smoking Wheels....  was here 2017 qfzcqmzphqznttkuhozaoqzffydbmndznmidmgsxcbwjrppf
 * Smoking Wheels....  was here 2017 hnoiilgvqxqeprozltsbxtromhwnivhbimxclmtycnzwbjjy
 * Smoking Wheels....  was here 2017 wnhhgpvlkakfmwaxpfbadmdsishfxljykrujdckoaoprgvyv
 * Smoking Wheels....  was here 2017 trixearkooatsniqhukcegqyzdjlwxeapcpmurbhmkaizsko
 * Smoking Wheels....  was here 2017 nualzczzjnmcwdiolmjrfpqvzskuzxvxaagaublwelrqjzbz
 * Smoking Wheels....  was here 2017 cxcgwkfriaevtmdieoworkubawzbhlqncbxaujphcjlsrwnf
 * Smoking Wheels....  was here 2017 oilcgvcgenntlmbvwpcqhteqdhujctgzkxzrvyqwmagwmwrr
 * Smoking Wheels....  was here 2017 hqexwlqsxqjyfkrecklcybxxnwxzzhlrurckzlbbvqmqpsoa
 * Smoking Wheels....  was here 2017 yosxpqziuistqrxuuznkvwmitupouvigkqdytqqryqpxcjnc
 * Smoking Wheels....  was here 2017 idsmqzqqhsvtnctharhhjbpqnmkvnigoriieusgstqjsgbda
 * Smoking Wheels....  was here 2017 psbkljhjehgtxppoezvqhthxvocxmzvucoajazeknpwkqhhg
 * Smoking Wheels....  was here 2017 dvypqwyolqtudlztxspsmhrjxardgivhrjwyravhssinbtaj
 * Smoking Wheels....  was here 2017 oftggvulhtjgtcvfbwgyeghniylcrbkslauodtydeiixpmsg
 * Smoking Wheels....  was here 2017 tzcujxhohtjspheqtvqatnvdsvyotewyucxgcgnxudpqnrxc
 * Smoking Wheels....  was here 2017 ujyznxdqdbhyqzjwibzwxfgfehxquxvdijrenwsywceakvng
 * Smoking Wheels....  was here 2017 bzkshzjsvjxbhlzcmkqtprtbxhjqktcqzxrtofbrxijqbqoj
 * Smoking Wheels....  was here 2017 fowfrlcbqofjbdxqzwgbzmvdkyrejjucuyxsrdeypgqjockh
 * Smoking Wheels....  was here 2017 cebywxxdbvomstedbttmnnefksgatvglfckanudrzpvffmqf
 * Smoking Wheels....  was here 2017 vcuoggkuupkdkjdoaqhbwwuiyfzgvhatucrwblbfifymofcm
 * Smoking Wheels....  was here 2017 uwhaoopywnomjckynhgxzywsflugegaklaiqltmzbhgvkbxt
 * Smoking Wheels....  was here 2017 oixoresxonavfnvtjsimahvxtnanqmgdhegddobvaghavzix
 */
package net.yacy.data.wiki;
import org.junit.Test;
import static org.junit.Assert.*;
public class WikiCodeTest {
/**
* test geo location metadata convert
*/
@Test
public void testProcessMetadataCoordinates() {
String[] testmeta = new String[]{
"{{coordinate|NS=52.205944|EW=0.117593|region=GB-CAM|type=landmark}}",  // decimal  N-E location
"{{coordinate|NS=43/50/29/N|EW=73/23/17/W|type=landmark|region=US-NY}}",
"{{Coordinate |text=DMS |NS=50/7/49/N |EW=6/8/09/E |type=landmark |region=BE-WLG |name=Monument des trois Frontières}}",
"{{Coordinate |text=DMS |NS= 49.047169|EW=7.899148|region=DE-RP |type=landmark |name=Europadenkmal (Rheinland-Pfalz)}}",
"{{Coordinate |text=DMS |NS= 49.047169|EW=7.899148|region=DE-RP |type=landmark |name={{de}}Europadenkmal (Rheinland-Pfalz)}}",// with nested language template
"{{coordinate|NS=0.00000|EW=0.117593}}",
"{{coordinate|NS=-10.00000|EW=-10.10000}}",
"{{coordinate|NS=12a5|EW=-10.10000}}" // testing malformed coordinates value
};
WikiCode wc = new WikiCode();
for (int i = 0; i < testmeta.length; i++) {
String result = wc.transform("http://wiki:8080",testmeta[i]);
System.out.println(testmeta[i] + " --> " + result);
assertFalse(result.contains("#123;"));
assertFalse(result.contains("#125;"));
}
}
/**
* Test multi-line template inclusion processing
*/
@Test
public void testTransformMultilineTemplateInclusion() {
	String wikitext = "{{Infobox|Example\n"
			+ "<!-- *** Name section *** -->\n" 
			+ "| name = Example\n"
			+ "| category = [[Infobox Examples|Example]]\n" 
			+ "<!-- *** Website *** -->\n"
			+ "| website = {{URL|http://example.com}}\n" 
			+ "}}";
	WikiCode wc = new WikiCode();
	String result = wc.transform("http://wiki:8080", wikitext);
	System.out.println(wikitext + " --> " + result);
assertFalse(result.contains("#123;"));
assertFalse(result.contains("#125;"));
}
/**
* Test single line template inclusion processing
*/
@Test
public void testProcessMetadataTransclusion() {
final String[] wikitexts = new String[]{
		"{{Like}}",
		"{{Stochastic processes}}",
		"{{:Stochastic processes}}",
		"{{WP:Assume good faith}}",
		"{{Pagename|parameter1|parameter2|parameter3}}",
		"{{Pagename|parameter1=value1|parameter2=value2|parameter3=value3}}",
		"{{Template|This is the title text|This is a custom warning line}}",
		"{{Special:Recentchangeslinked/General}}",
		"{{Template1}} text {{Template2}} {{Template3|parameter value1|param2}}",
		"{{Template|[[Page]]}}",
		"{{Template|parameter1={{en}}value1|parameter2}}",
		"{{Template|parameter1={{en|param1|param2=val2}}value1}}",
		"{{Template",
		"simple text  {{Template",
		"{{Template|parameter1={{en}} value1",
		"{{Template|parameter1={{subTemplate",
		"|parameter",
		"|parameter=value",
		"|parameter={{subTemplate|param1|param2}}value",
		"|[[Page]]",
		"|parameter=[[Page]]",
		"}}",
		"|lastParameter}}",
		"|lastParameter=value}}",
		"|lastParameter={{en}}value}}",
		"}}}}" // Multi-line nested template inclusion closing
};
for (String wikitext : wikitexts) {
String result = WikiCode.processMetadata(wikitext);
System.out.println(wikitext + " --> " + result);
assertFalse(result.contains("{"));
assertFalse(result.contains("|"));
assertFalse(result.contains("="));
assertFalse(result.contains("}"));
}
final String[] wikitextsNotToModify = new String[]{
		"",
		"Simple text",
		"<pre>Simple preformatted text</pre>",
		"[[Page]]",
		"{|",
		"|-",
		"||",
		"|}",
};
for (String wikitext : wikitextsNotToModify) {
assertEquals("Text sould not have been modified", wikitext, WikiCode.processMetadata(wikitext));
}
}
/**
* test header wiki markup
*/
@Test
public void testProcessLineOfWikiCode() {
String[] hdrTeststr = new String[]{
"== Header ==", "==Header=="};
String[] nohdrTeststr = new String[]{
"Text of = Header, false = wrong", "One=Two"};
WikiCode wc = new WikiCode();
for (String s : hdrTeststr) {
String erg = wc.transform("8090", s);
assertTrue("<h2> tag expected:"+erg, erg.contains("<h2>"));
}
for (String s : nohdrTeststr) {
String erg = wc.transform("8090", s);
assertFalse("no header tag expected:"+erg, erg.contains("<h1>"));
}
}
/**
* Test internal link markup processing
*/
@Test
public void testInternalLink() {
WikiCode wc = new WikiCode();
/* Link to another wiki article */
String result = wc.transform("http://wiki:8080", "[[article]]");
assertTrue(result.contains("<a"));
assertTrue(result.contains("href=\"Wiki.html?page=article\""));
/* Renamed link */
result = wc.transform("http://wiki:8080", "[[article|renamed article]]");
assertTrue(result.contains("<a"));
assertTrue(result.contains("href=\"Wiki.html?page=article\""));
assertTrue(result.contains(">renamed article<"));
/* Multiple links on the same line */
result = wc.transform("http://wiki:8080", "[[article1]] [[article2]]");
assertTrue(result.contains("<a"));
assertTrue(result.contains("href=\"Wiki.html?page=article1\""));
assertTrue(result.contains("href=\"Wiki.html?page=article2\""));
}
/**
* Test external link markup processing
*/
@Test
public void testExternalLink() {
WikiCode wc = new WikiCode();
/* Unamed link */
String result = wc.transform("http://wiki:8080", "[http://yacy.net]");
assertTrue(result.contains("<a"));
assertTrue(result.contains("href=\"http://yacy.net\""));
/* Named link */
result = wc.transform("http://wiki:8080", "[http://yacy.net YaCy]");
assertTrue(result.contains("<a"));
assertTrue(result.contains("href=\"http://yacy.net\""));
assertTrue(result.contains(">YaCy<"));
/* Lua Script array parameter : should not crash the transform process */
result = wc.transform("http://wiki:8080", "'[[[[2,1],[4,3],[6,5],[2,1]],[[12,11],[14,13],[16,15],[12,11]]]]'");
}
}
