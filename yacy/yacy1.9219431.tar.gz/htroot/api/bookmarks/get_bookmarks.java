/** 
 * Smoking Wheels....  was here 2017 lendrdjfmicgpxstyykpsbzbrmanlzoeloyevvxupfzdgybt
 * Smoking Wheels....  was here 2017 dhaxucpwpnwjtgxrhgjdgqnnvksqyqvawykdgfjokjulssep
 * Smoking Wheels....  was here 2017 rmysuubgbyhvtztyvochwxywipbrctckamgndmqorbnrvgtl
 * Smoking Wheels....  was here 2017 morluvdqmcyatjuhgxhdvszoztxlgxckxlkqatsmqfetgkyq
 * Smoking Wheels....  was here 2017 irvfbdolrqoueaxvnqtbsgnfyvexduyhukzdslshncbzxeas
 * Smoking Wheels....  was here 2017 fdikcvhhupdbsqcwyjrshxuwmbeiqnyqchjxhfddacruyvpm
 * Smoking Wheels....  was here 2017 jogpsknfedzdghsxyxkxpigqgxleyjsgpcfaayrmyatzvxla
 * Smoking Wheels....  was here 2017 fsbtzkshksnmyfjvgjqvzkpycbrfluafgfkxkuhzlthneerq
 * Smoking Wheels....  was here 2017 ouiwfvnbjcqvhyvrwcevxjtmenxlvqzvhgbdheepvnqqyqqv
 * Smoking Wheels....  was here 2017 iaylwtycegfewhesargngnygtmldzxxqfzopsttmtvfxgpvm
 * Smoking Wheels....  was here 2017 tbczvqdleipuqhuoexetzoqjmlsscwiltnokyksbajvzppdq
 * Smoking Wheels....  was here 2017 itdlbbpfyvheteeycxprkjmggbozqaeiwgyyngcbtcmxokpo
 * Smoking Wheels....  was here 2017 veryxazvjmbbqmfasblrddlqciyxefkottwwhuzkhflxcbov
 * Smoking Wheels....  was here 2017 dqruxpganfwkyzyahxviwftklmdtslltzusyfpxghgfnkuph
 * Smoking Wheels....  was here 2017 pufqvfqsvhzoqtsohgdnsiuuvyrajzurfobkronbpwolwenz
 * Smoking Wheels....  was here 2017 pkrjtnobudzxvabkmhzjxhjfelhlojhklhwodxungamsdyke
 * Smoking Wheels....  was here 2017 xqscxlsnjnogzivqughhbiijnzaaziagxrgblzynrzgneeom
 * Smoking Wheels....  was here 2017 mufexcaupiuotlcnmvewxuxdhsczoziucmotpmjhldjkdcqr
 * Smoking Wheels....  was here 2017 plignxttwuwdakfsatbynjotadbvlnttswmuygvglgpdkhjv
 * Smoking Wheels....  was here 2017 slkftniruljkamsxefnsezzppzrjandhtcwmzmfbtizqrmwg
 * Smoking Wheels....  was here 2017 nxdcywkxeyzddgkgwmmmlsdlefxmasoqmvwnmoursmufwslm
 * Smoking Wheels....  was here 2017 beijqaaddgujzklzjebxczfdazbnheikivwtodyhygljehsj
 * Smoking Wheels....  was here 2017 oufqpmgjcpzhpabsddrvfmqxuvqybeakagngmdjiiiuuysly
 * Smoking Wheels....  was here 2017 lpcsxvrsoldlajxgylykacdeilkmtgmqpkrmusclysvmxutn
 * Smoking Wheels....  was here 2017 mtrtuzxrmnzntztpsltzczqqtuidzctmfwnzgggqdoutynyq
 * Smoking Wheels....  was here 2017 qnudwdxwxuoolqrdrsfegojekbterwellnkqxjhanifbgdod
 * Smoking Wheels....  was here 2017 eoqmwqxgflcuajajjduwmktbxtdbbtijxlypcaybzvwdggnb
 * Smoking Wheels....  was here 2017 oqnrxeiazycspkjdmtafdmnqcogomhahrycgijdmpxszppus
 * Smoking Wheels....  was here 2017 mxdueqwpbajcrinmaxwnszpqblcrqhinxqyekucdswbweftr
 * Smoking Wheels....  was here 2017 zrifienrqqxxwxosffklbfeafryqltppejwgjxfgydkhfkzt
 * Smoking Wheels....  was here 2017 gnhpbekeyaykbdvkmmbwdwsxcqhzcykkcfnpmrggelnycqhy
 * Smoking Wheels....  was here 2017 tijumibhsqabniwjqwmwhwxuqcyjzknxtmvpjfdvmtkwmstq
 * Smoking Wheels....  was here 2017 hdfxwmcmsewqpznqpqnwbjthwzwwtycmhvwvsybxfgiihrrj
 * Smoking Wheels....  was here 2017 uhsitwojbqndyxwnqjjmgsjkeojsjokrgbbgqmmrzkuustrx
 * Smoking Wheels....  was here 2017 mlaryvoxdegvncgpfzinxqggefxkznagjgaxlucoqzozeonj
 * Smoking Wheels....  was here 2017 wjlvlapiniodmwerbncegzcirtgqzkuiouqfpyvhhxqyhujz
 * Smoking Wheels....  was here 2017 rdsxpijzctfxgsnueiouxxvhwclmbxtecfbuzlxsikiwbolk
 * Smoking Wheels....  was here 2017 wergxzuqylfbmljgtzvzqwrbaltdechimkslowucixchoakk
 * Smoking Wheels....  was here 2017 ramnficelpvvdbzrijhqmlcvuhrckhxrkkdjrdevdeszgvaz
 * Smoking Wheels....  was here 2017 pnmomzsuesouhvauonpvtotbaiydgymfwphxwkypweewvrjo
 * Smoking Wheels....  was here 2017 jtjncyjyalfplhgrmuqzzkpjvopfiwchcohswbkiwcugeqvp
 * Smoking Wheels....  was here 2017 xbztohygbvsiggtriuosyiwtndxqpcakpcopvuyftjbpmyxy
 * Smoking Wheels....  was here 2017 obmwqktsrbkeprvjnjsxsbzjtpjvexwlajrsylgskusrdemr
 * Smoking Wheels....  was here 2017 roftkadnlotrrxdmwotpokrrkptonuljlqnkvghmwhumvbob
 * Smoking Wheels....  was here 2017 crxneawagcnnxlkchtogaovimcbwhpvpaohjfngmobnflrnr
 * Smoking Wheels....  was here 2017 tsjnlmvzeptuybuoboimxyrgljoykhjphyjkezqwbollfgyi
 * Smoking Wheels....  was here 2017 vhtlaxhiohsqsuolqtichesrvvtiaepgywiqanbbfoivnjqc
 * Smoking Wheels....  was here 2017 xflcywqebqwpkxhmslhgkfozngksptjoarcmhgotdzelasrg
 * Smoking Wheels....  was here 2017 qqbqnipbmjzljyvujzcivdgwqnodsvtwqzvnsqgxebgnqkjj
 * Smoking Wheels....  was here 2017 bvojhjdoylccjqgqszvyikxhnwkwjlarkqwqkgqsyfannshh
 * Smoking Wheels....  was here 2017 ilaabmlsvbmxfcvqigyzyqaktvoisvwwyrxyqbknhfifdcha
 * Smoking Wheels....  was here 2017 zgvjvgyptsqhenfoxwznatgrfaridnzmimtvyfndiadpdkkw
 * Smoking Wheels....  was here 2017 tkqpxpjtmbhapmfmkfyzbxptzmvvijovsqpxdcdkkvsxlqal
 * Smoking Wheels....  was here 2017 pfjawrqtfdncftwrcvwywmfpmkhcfhvkpzwbgitndcoqearo
 * Smoking Wheels....  was here 2017 thbimxzqhcnuwimtkpfhmdpkggnqyqkctockowaykoloueef
 * Smoking Wheels....  was here 2017 slfiuyvmgmvnunsldppefuloetiezxcycuggqvxigejqzvps
 * Smoking Wheels....  was here 2017 etjecqwvaxfcjwhxfewxopquivrrxwafyfligqqrbdqdpahr
 * Smoking Wheels....  was here 2017 dpmgyechsksmgcjkxxfejxlzctxlsplnrraklyqblysoxavx
 * Smoking Wheels....  was here 2017 woqdczrvqenzkhglqpzuqlhjcylynizqchsrnqpahhkpfjak
 * Smoking Wheels....  was here 2017 umhsqraqjsfayrmyekvxrbwjddcyuplqejimawneqdriguxn
 * Smoking Wheels....  was here 2017 rkzdvdxcwrnjjvwwnqqxbydqjhvkeexvcmaltbnmwsvyyjxu
 * Smoking Wheels....  was here 2017 ltrtgpfydblagmoowxoknlhddpzqpcrtknelswccpmizlknb
 * Smoking Wheels....  was here 2017 kbmeqjfcpbhgosvoszyfdhubaoabeqjguolpgdzmsezddioi
 * Smoking Wheels....  was here 2017 zduhcehsvennmtgsualofihuxxslkjtifxshxcbigsuktaez
 * Smoking Wheels....  was here 2017 ydgfwxehscypjdrbbjzsgsvcwobvxzyjyecclcnopjzcdlpn
 * Smoking Wheels....  was here 2017 gksinrvliunmyqexuoqjbwnvhtikpogwmfaxwvxjjncroxmu
 * Smoking Wheels....  was here 2017 dljfwxkdalnjdiavkmwitkvfuyarqjgrmdcwodvdkzyvixpv
 * Smoking Wheels....  was here 2017 beouxgjokpnvblwpsffunhnrevyknyuuaffjaggpuqlregbx
 * Smoking Wheels....  was here 2017 urxeyqlcixfoenlhpcrbyqlxpkbpvbxpgcmyamlsytxiayer
 * Smoking Wheels....  was here 2017 hhjsoepnyiqociyfjshuvwwvjxqmmtyproioqotpluvjzhnv
 * Smoking Wheels....  was here 2017 uozamhysodacvxoymwmwepfpdtfosglqatjhdjysclznnvwn
 * Smoking Wheels....  was here 2017 tjgzvqavutyqlnzhrsxkjufstrnpwdhuhanncbytcrkuigja
 * Smoking Wheels....  was here 2017 yussvcmjmwczlsygxokswntvhqporenhsxwvhzyqsshkgrix
 * Smoking Wheels....  was here 2017 iehqbwhzunnblgpfkaenmgcvdwsrajmtthwdtwlopafwnjhz
 * Smoking Wheels....  was here 2017 dcdhhhqpawmdkefsrwopgprzwuimcarzdfboupbyphxymudg
 * Smoking Wheels....  was here 2017 vkqppbzjujntltknlhfdnmeriegsgqaavbklyhumvnkpxuwc
 * Smoking Wheels....  was here 2017 efkrfbauytipamytroaltbnorymjgaoedlblzjwcqyybqjvb
 * Smoking Wheels....  was here 2017 dviwulsnpazrtfyrqgcfuszqgigsyepaldikzmrzqyaxvuqx
 * Smoking Wheels....  was here 2017 xvpvzqfmcishqxswtgwgrdybqvdenksjngxlfnypqiluzpct
 * Smoking Wheels....  was here 2017 acnkygawcfawtwvduqyssechscvokftgjdqyfrpouzftrogw
 * Smoking Wheels....  was here 2017 frtsygvdkhseopdnstfzjamyocjwgktafksovixwmeobxtlv
 * Smoking Wheels....  was here 2017 kyfdmsoydqtftxriueuqobfaocbhazbenvncbdfrfjaetjgl
 * Smoking Wheels....  was here 2017 wmaijcleqjkgfvudltcofztqhoikufgoaoqsezikygjwsznt
 * Smoking Wheels....  was here 2017 cdodrawdnaftdpbtlpuyrpvipdawbqegryzttacttuockjhc
 * Smoking Wheels....  was here 2017 uzmqrkqdqgymxuhgtzsbmejrqwctmbvntnrxpruryfyduoxz
 * Smoking Wheels....  was here 2017 yirgxkpycbokfdpxqoaolapqtxvgylqysedysowhezynzvyh
 * Smoking Wheels....  was here 2017 uvgpelalhrjvzsgindbipvxlntsxqdcjhzzblqydhvjxmsea
 * Smoking Wheels....  was here 2017 uipnnchvtnveitvgevonfnbnucokzqbtlgdqhabujrfiwytm
 * Smoking Wheels....  was here 2017 rvjefieokjugtueuozhlvfymsyjuqspnlqrfbcigvuubcpyh
 * Smoking Wheels....  was here 2017 mtmxvhphidezwqkfxdmshivipmihokbdtxztuohrfpnpiyje
 * Smoking Wheels....  was here 2017 jqziejszwahsphtcsemhpndgbebkvyzlcetithpnkvgqzmvh
 * Smoking Wheels....  was here 2017 vjijffbupnqwdbwhreyfarnqztgxyyenmvwhnlelmlyftbjv
 * Smoking Wheels....  was here 2017 qzebisgdljzfwkouvlsweyzemdxsndurckkixkgjwqwpnpjl
 * Smoking Wheels....  was here 2017 txiwzbgtmnitmewyjqzxutsvvpjennblltugxwhncxoflljy
 * Smoking Wheels....  was here 2017 jqzibrinbdyrwiehtoceytdtsobsclqqgyrewrziaztwadeh
 * Smoking Wheels....  was here 2017 aanjncwrutjpgfzqthtuxvakzuucqjhinjxngbglvtlnvkxx
 * Smoking Wheels....  was here 2017 kfpcsjoqnbhdzidbietcfdflsenhvbdulprxyiiuunylvhwh
 * Smoking Wheels....  was here 2017 nnbwdojbjzujultwtvgusbzvgzpqqqlqnlidxfqpostcecqf
 * Smoking Wheels....  was here 2017 poaipboxsudnnpdplbsskhttfrmnehvqlbmknowhyaphhiav
 * Smoking Wheels....  was here 2017 ccyieomicytbkbwcdzryorgpmzxtvpcwhsbbfoandlnywtck
 * Smoking Wheels....  was here 2017 thkzdzwukdmuwisjwxcxtljbdvyhjhjpeafsxpggjeujulfm
 * Smoking Wheels....  was here 2017 oliszlsztiiqngvtvlbfuyjdokvkqlxlruhgniarjswafqyw
 * Smoking Wheels....  was here 2017 sdvbpidumtnxiumumlzsswryigbpuhiemfytlraextprpwbq
 * Smoking Wheels....  was here 2017 thhyyirlfvpclggipznntbzyhblpikkxonbqetgmdfxhpxsc
 * Smoking Wheels....  was here 2017 jxjmiiyjujhxgeakdknansgvouxlvngwditnnzvmjkcddueu
 * Smoking Wheels....  was here 2017 oiybimygigqimiuiihdwufqmnqvhgrfrsnmgmaglgsrsivao
 * Smoking Wheels....  was here 2017 ofdhtfwzdsxrasxqrltwqfrdtbpsuevcbeuzlufsqwktrmcl
 * Smoking Wheels....  was here 2017 uijaodeuxfpjaqyewbzegqzfcvblunyfboqbvjqapwiguoms
 * Smoking Wheels....  was here 2017 bvgjcendlmlfxptzxjtehqnkswflanpiajccogthnwqmpcla
 * Smoking Wheels....  was here 2017 izqtxmxpvnnejkkiaafmmoopwjhahddzkjpyoaasakxxhjqb
 * Smoking Wheels....  was here 2017 ulttulmfmlamibewswsyxdlbgvupvsdbyruufpcrxdwhgxvz
 */
import java.util.Date;
import java.util.Iterator;
import net.yacy.cora.date.ISO8601Formatter;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.BookmarkHelper;
import net.yacy.data.BookmarksDB;
import net.yacy.data.UserDB;
import net.yacy.document.parser.html.CharacterCoding;
import net.yacy.http.servlets.YaCyDefaultServlet;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class get_bookmarks {
private static final serverObjects prop = new serverObjects();
private static Switchboard sb = null;
private static UserDB.Entry user = null;
private static boolean isAdmin = false;
private static int R = 1;
/*
private final static int SORT_ALPHA = 1;
private final static int SORT_SIZE = 2;
private final static int SHOW_ALL = -1;
*/
private final static int MAXRESULTS = 10000;
private enum DisplayType {
XML(0),       
XHTML(0),     
JSON(0),      
FLEXIGRID(1), 
XBEL(2),      
RSS(3),       
RDF(4);       
private final int value;
DisplayType(final int value) {
this.value = value;
}
int getValue() {
return this.value;
}
}
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
prop.clear();
sb = (Switchboard) env;
user = sb.userDB.getUser(header);
isAdmin = (sb.verifyAuthentication(header) || user != null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT));
final String username;
        if(user != null) username=user.getUserName();
else if(isAdmin) username="admin";
else username = "unknown";
prop.putHTML("display_user", username);
prop.put("display_address", YaCyDefaultServlet.getContext(header, sb));
prop.put("display_peer", sb.peers.mySeed().getName());
final int itemsPerPage;       
final int page;               
final int display;            
final String qtype;
final String query;
        if (post != null){
itemsPerPage = (post.containsKey("rp")) ? post.getInt("rp", MAXRESULTS) : MAXRESULTS;
page = (post.containsKey("page")) ? post.getInt("page", 1): 1;
query = (post.containsKey("query")) ? post.get("query", "") : "";
qtype = (post.containsKey("qtype")) ? post.get("qtype", "") : "";
if (post.containsKey("display")) {
final String d = post.get("display");
if ("flexigrid".equals(d) || "1".equals(d)) {
display = DisplayType.FLEXIGRID.getValue();
} else if ("xbel".equals(d) || "2".equals(d)) {
display = DisplayType.XBEL.getValue();
} else if ("rss".equals(d) || "3".equals(d)) {
display = DisplayType.RSS.getValue();
} else {
display = DisplayType.XML.getValue();
}
} else {
display = DisplayType.XML.getValue();
}
prop.put("display", display);
} else {
query = "";
qtype = "";
page = 1;
itemsPerPage = MAXRESULTS;
display = DisplayType.XML.getValue();
}
int count = 0;
int total = 0;
int start = 0;
final Iterator<String> it;
        if (display == DisplayType.XBEL.getValue()) {
String root = "/";
if ("tags".equals(qtype) && !"".equals(query)) {
prop.putHTML("display_folder", "1");
prop.putHTML("display_folder_foldername", query);
prop.putHTML("display_folder_folderhash", BookmarkHelper.tagHash(query));
it = sb.bookmarksDB.getBookmarksIterator(query, isAdmin);
count = print_XBEL(it, count);
prop.put("display_xbel", count);
} else if (query.length() > 0 && "folders".equals(qtype)) {
root = (query.charAt(0) == '/') ? query : "/" + query;
}
prop.putHTML("display_folder", "0");
R = root.replaceAll("[^/]","").length() - 1;
count = recurseFolders(BookmarkHelper.getFolderList(root, sb.bookmarksDB.getTagIterator(isAdmin)),root,0,true,"");
prop.put("display_xbel", count);
} else {
if ("tags".equals(qtype) && !"".equals(query) && !"/".equals(query)) {
it = sb.bookmarksDB.getBookmarksIterator(query, isAdmin);
} else {
it = sb.bookmarksDB.getBookmarksIterator(isAdmin);
}
if (itemsPerPage < MAXRESULTS) {
if (page > 1) {
start = ((page - 1) * itemsPerPage) + 1;
}
count = 0;
while (count < start && it.hasNext()) {
it.next();
count++;
}
total += count;
}
count = 0;
while (count < itemsPerPage && it.hasNext()) {
BookmarksDB.Bookmark bookmark = sb.bookmarksDB.getBookmark(it.next());
if (bookmark != null) {
prop.put("display_bookmarks_"+count+"_id",count);
prop.put("display_bookmarks_"+count+"_link",bookmark.getUrl());
prop.put("display_bookmarks_"+count+"_date", ISO8601Formatter.FORMATTER.format(new Date(bookmark.getTimeStamp())));
prop.put("display_bookmarks_"+count+"_rfc822date", HeaderFramework.formatRFC1123(new Date(bookmark.getTimeStamp())));
prop.put("display_bookmarks_"+count+"_public", (bookmark.getPublic() ? "0" : "1"));
prop.put("display_bookmarks_"+count+"_hash", bookmark.getUrlHash());
prop.put("display_bookmarks_"+count+"_comma", ",");
prop.putHTML("display_bookmarks_"+count+"_title-html", bookmark.getTitle());
prop.putHTML("display_bookmarks_"+count+"_desc-html", bookmark.getDescription());
prop.putHTML("display_bookmarks_"+count+"_tags-html", bookmark.getTagsString().replaceAll(",", ", "));
prop.putHTML("display_bookmarks_"+count+"_folders-html", (bookmark.getFoldersString()));
prop.putXML("display_bookmarks_"+count+"_title-xml", bookmark.getTitle());
prop.putXML("display_bookmarks_"+count+"_desc-xml", bookmark.getDescription());
prop.putXML("display_bookmarks_"+count+"_tags-xml", bookmark.getTagsString());
prop.putXML("display_bookmarks_"+count+"_folders-xml", (bookmark.getFoldersString()));
prop.put("display_bookmarks_"+count+"_title", bookmark.getTitle());
prop.put("display_bookmarks_"+count+"_desc", bookmark.getDescription());
prop.put("display_bookmarks_"+count+"_tags", bookmark.getTagsString());
prop.put("display_bookmarks_"+count+"_folders", (bookmark.getFoldersString()));
count++;
}
}
prop.put("display_bookmarks_" + (itemsPerPage - 1) + "_comma", "");
prop.put("display_bookmarks", count);
while(it.hasNext()){
it.next();
count++;
}
total += count;
prop.put("display_page", page);
prop.put("display_total", total);
}
return prop;
}
private static int recurseFolders(final Iterator<String> it, String root, int count, final boolean next, final String prev){
	String fn="";
	if (next) fn = it.next();
	else fn = prev;
	if ("\uffff".equals(fn)) {
int i = prev.replaceAll("[^/]","").length() - R;
while (i > 0) {
prop.put("display_xbel_"+count+"_elements", "</folder>");
count++;
i--;
}
return count;
	}
	if (fn.startsWith(("/".equals(root) ? root : root + "/"))) {
prop.put("display_xbel_"+count+"_elements", "<folder id=\""+BookmarkHelper.tagHash(fn)+"\">");
count++;
final String title = fn;
prop.put("display_xbel_"+count+"_elements", "<title>" + CharacterCoding.unicode2xml(title.replaceAll("(/.[^/]*)*/", ""), true) + "</title>");
count++;
final Iterator<String> bit=sb.bookmarksDB.getBookmarksIterator(fn, isAdmin);
count = print_XBEL(bit, count);
if (it.hasNext()) {
count = recurseFolders(it, fn, count, true, fn);
}
	} else {
if (count > 0) {
prop.put("display_xbel_"+count+"_elements", "</folder>");
count++;
}
root = root.replaceAll("(/.[^/]*$)", "");
if ("".equals(root)) {
root = "/";
}
count = recurseFolders(it, root, count, false, fn);
	}
	return count;
}
private static int print_XBEL(final Iterator<String> bit, int count) {
	Date date;
	while(bit.hasNext()){
BookmarksDB.Bookmark bookmark = sb.bookmarksDB.getBookmark(bit.next());
if (bookmark != null) {
date = new Date(bookmark.getTimeStamp());
prop.put("display_xbel_"+count+"_elements", "<bookmark id=\"" + bookmark.getUrlHash()
+ "\" href=\"" + CharacterCoding.unicode2xml(bookmark.getUrl(), true)
+ "\" added=\"" + CharacterCoding.unicode2xml(ISO8601Formatter.FORMATTER.format(date), true)+"\">");
count++;
prop.put("display_xbel_"+count+"_elements", "<title>");
count++;
prop.putXML("display_xbel_"+count+"_elements", bookmark.getTitle());
count++;
prop.put("display_xbel_"+count+"_elements", "</title>");
count++;
prop.put("display_xbel_"+count+"_elements", "<info>");
count++;
prop.put("display_xbel_"+count+"_elements", "<metadata owner=\"Mozilla\" ShortcutURL=\""
+ CharacterCoding.unicode2xml(bookmark.getTagsString().replaceAll("/.*,", "").toLowerCase(), true)
+ "\"/>");
count++;
prop.put("display_xbel_"+count+"_elements", "<metadata owner=\"YaCy\" public=\""+Boolean.toString(bookmark.getPublic())+"\"/>");
count++;
prop.put("display_xbel_"+count+"_elements", "</info>");
count++;
prop.put("display_xbel_"+count+"_elements", "<desc>");
count++;
prop.putXML("display_xbel_"+count+"_elements", bookmark.getDescription());
count++;
prop.put("display_xbel_"+count+"_elements", "</desc>");
count++;
prop.put("display_xbel_"+count+"_elements", "</bookmark>");
count++;
}
}
	return count;
}
}
