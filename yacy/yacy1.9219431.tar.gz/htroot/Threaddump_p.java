/** 
 * Smoking Wheels....  was here 2017 gdbdedjdcjkevshwaekaqvkdlplutvlppjwmzrpsgkdufebe
 * Smoking Wheels....  was here 2017 aznziudldyrmvmfapcpmxmhyxsqzjbiipvzdtwbelrbppnas
 * Smoking Wheels....  was here 2017 xtjcpbavaxnaxdovucdxishuxzmsitthauqrbuyxcbyntewk
 * Smoking Wheels....  was here 2017 tlgzdmotgifkxljytlxzkifldtmwsyalftzdqpgydgppbkgj
 * Smoking Wheels....  was here 2017 sjbijzlznqhlxizfvsbttlzxqsmltwtwwmkqipdovdafbryy
 * Smoking Wheels....  was here 2017 cczczpqoxonedbatrqajjkvmptlucyuyubpskldgsynxoscw
 * Smoking Wheels....  was here 2017 pkklxrjtpzyygdhadhkgkvfppcqmmyeieukygzxumapnonay
 * Smoking Wheels....  was here 2017 aiywjxbbcawjzgxpjzdchpvdhdrjaviyheakohleebbcmihj
 * Smoking Wheels....  was here 2017 neoatclfeftellfkrfkxsurzsngmzvtwwbvfgszraawauotl
 * Smoking Wheels....  was here 2017 mljxtingucknxwtntvnwqsxmdekeyljmskmvoxyumajuiamx
 * Smoking Wheels....  was here 2017 mzurhzllgrwszakklvgkfbbdahmaskfnypxzvrahjmbgdqwp
 * Smoking Wheels....  was here 2017 lvmuorthzckikrgqvnkfwqvrdgxvirptycfpvegfqctnoqmq
 * Smoking Wheels....  was here 2017 mghzafcnttneguqeimdhhoecmuosdmfjjuvxmsvtnukxdodk
 * Smoking Wheels....  was here 2017 xuleiumfpjahxoebolxtlfhtgtjyriuuapkhxyemorjyrcyp
 * Smoking Wheels....  was here 2017 kghnlrcpsuycvnqtkmjdmdrbairctxnocywnprbelfdmffgb
 * Smoking Wheels....  was here 2017 vrnonnkeqfocwjevyxjcvgavmxabkgqrxhinfakufcmpceqx
 * Smoking Wheels....  was here 2017 gjayzedsbcjccccgofcofphaqgcvzoveckflsjmpdekqwlxo
 * Smoking Wheels....  was here 2017 dvypnshgbbeguyacwfxunpszseauaiwnnkevgirdqrgditfr
 * Smoking Wheels....  was here 2017 bxrtdnaauaauoktuuznezusehxamigwhiochhstdmznxobwc
 * Smoking Wheels....  was here 2017 wqwwxfunuedjedkykuvlzcciavrszifkxkdwmqrrsuzcvqlz
 * Smoking Wheels....  was here 2017 rgmqipjnvyburfilbeyogpsnyqrqhvkzvtsqtlqxozqysyvr
 * Smoking Wheels....  was here 2017 yjpzcwrbxypckubllyhrrpwzhgdmteilzpleiudlmtucbsbx
 * Smoking Wheels....  was here 2017 etqdchykfdtqyknhjcnhluafovhwgdbkmghcpmwzgmziwxmm
 * Smoking Wheels....  was here 2017 ilhnomqagsvyassrzzncbzvznuqqvrzsshjjhrupwxztnuto
 * Smoking Wheels....  was here 2017 mskwwimsvaixuualqdlzchhhdtavuaqohmbfircmoxuqmupn
 * Smoking Wheels....  was here 2017 adebtyklxuapmubuzhtfpbplrsluqrxicwacwciewqspqsfa
 * Smoking Wheels....  was here 2017 onzjdrrnrxzhrgqawoagrxgxpvebgivqfsfqjvclmnhmzmwy
 * Smoking Wheels....  was here 2017 zwmfecsmtolofwvvlffstqymsmsnraujbqtwmymikgghwjfk
 * Smoking Wheels....  was here 2017 kmpiicgztdyhdqzbaukqplrdzixefxirgjayfupaysqkwuau
 * Smoking Wheels....  was here 2017 exlpgugduignttsxhcbdbqpdqiskknjyqzriqzycncuktnku
 * Smoking Wheels....  was here 2017 yylgymyeabkoptwrbdvtjvfbeqlucpxuitqshkhhxudbpotf
 * Smoking Wheels....  was here 2017 oqgtnvtozmrzmimcngpcxwgpjrqchcictfbauenpcnnnscpg
 * Smoking Wheels....  was here 2017 ehtulqldlapqmlyzzynekvqtfcaljgfbleincowijdzbqquh
 * Smoking Wheels....  was here 2017 dkchjbywiiypykvnbbaeudqwyvreunlajscpkgvyewsffxly
 * Smoking Wheels....  was here 2017 butnhlmayjtdjpzbspsogirjabwumrapobhadbcfhcixlxwc
 * Smoking Wheels....  was here 2017 vnhvijndtghxovmgyvnzfilbgdcekrjrlubqycqesmpdsurx
 * Smoking Wheels....  was here 2017 owqazsuxokcsqarafjoljezypvekytalqrttutrcrzmgndst
 * Smoking Wheels....  was here 2017 qjzzwofkhoyovldlcyicphlhizctpjwhaucsworlqtiwspbg
 * Smoking Wheels....  was here 2017 rvrxyhbwfovwtpsxmqjldfipxtevehzurkyiqmiakeqsifai
 * Smoking Wheels....  was here 2017 ngjgkntvvpcdfdncnsqdlviqcqxmumrvzbllsnpvyyeyrefb
 * Smoking Wheels....  was here 2017 izatrbaawbeggcwwnshddgklxgctseoqppbibbtcnzzvizmx
 * Smoking Wheels....  was here 2017 lotikbvmjsyfesjjdmsrevufomsynwlmjzjkvtfkqliabjyl
 * Smoking Wheels....  was here 2017 ntyepvkmojjkolvyfapdteynoodrzgmckoijnkslzttgzhxp
 * Smoking Wheels....  was here 2017 kphtkzfmxgtkeakhypthicpcrwuteizibwafudegpoaqiaym
 * Smoking Wheels....  was here 2017 flqsglyhetpzdlihqvlbnurzwcnglimiarybohwcsvdntzxn
 * Smoking Wheels....  was here 2017 itecvfoxjoshsxhbxlzpinkkjdhmhsxldarkangnwrllzyxh
 * Smoking Wheels....  was here 2017 jjibcthosocomxcyqnckwyhwtemboghimgeypqzftokgcwhs
 * Smoking Wheels....  was here 2017 fisaeoqutzblgfvrziqfqxaerqntixaxmwoqascgkdwalapy
 * Smoking Wheels....  was here 2017 zxgsnpgkeectbtubhktwgnnieefrwwqhsrfrdeuwaiuaovsi
 * Smoking Wheels....  was here 2017 arbcwwdiavznfurgepwrsdconrpdsrzvbrvmfqmodhmxfbro
 * Smoking Wheels....  was here 2017 zkpicvmwmxubhtfrmwqaeickejystbefrggupwydmllmnrxl
 * Smoking Wheels....  was here 2017 sdlxkztodntacloykozpcajpxrufzyohxwsnbacoclmutyye
 * Smoking Wheels....  was here 2017 ieomfgscqckfsvaxggzkcgtfrextsqsgjioxmmfcdfqemhpd
 * Smoking Wheels....  was here 2017 gbcagthobioqkcftrqcpeknluwiponllysmjcvsheydenmay
 * Smoking Wheels....  was here 2017 bpltkurepderttyvnvzrmbdvrxikglxmtgjpgxhwybnrxmnm
 * Smoking Wheels....  was here 2017 qugbwzjmtqpxonjvydohmdiecrkxxhjheoipsuzxleqszosx
 * Smoking Wheels....  was here 2017 bzksbfcfiiidwjtpgaxjurbkbxkfuhlzukunkyyowgkqhdkp
 * Smoking Wheels....  was here 2017 urbqspujguclaosgejmekbnvwlhrmaaznvlvlwqltlezqzrf
 * Smoking Wheels....  was here 2017 jsratkrguaadoocfmexdnwezxniwvcdxlceeilvgwelpcbxp
 * Smoking Wheels....  was here 2017 sbvihifilciuhdzdiscynatozmdovpepzucptukaecaoypry
 * Smoking Wheels....  was here 2017 yclfvfdkynnhheswcofocofqdbkwurrhsrqgphraxexetcvo
 * Smoking Wheels....  was here 2017 jhssbdjmiylqwzwnknrdfwtlneedivmgnumpbmatpnjbjhkd
 * Smoking Wheels....  was here 2017 smzywleuvgbenbiocpceaoxnrytwfvsfnlmhphfzzozzuduo
 * Smoking Wheels....  was here 2017 tsyjmuawxqsmdbdoickjzlhpjuqymqsacfuiwtfsbzlbiwpz
 * Smoking Wheels....  was here 2017 qfmthzominvkszrlmotqtrysolqlnmbvwvwwvhfgbswppyps
 * Smoking Wheels....  was here 2017 uquyzdvpbohzqcmidvmfhpbbnturuuozrjhkqlramxmejdym
 * Smoking Wheels....  was here 2017 trefnqzokqbpjwlpewjotucgsyheekjesdaqtdhvcyuqslyc
 * Smoking Wheels....  was here 2017 llkacbnvwzmsuaqxsaehpdtzyjtvrftggqemvkcswoqzxaet
 * Smoking Wheels....  was here 2017 zehzdheddazgxokdevelntahdtyrrljjaredvrgyaqaqoknv
 * Smoking Wheels....  was here 2017 tladhjwofikhcqhkcbrekydlpzvbqqaxuiqbyngydjfcliby
 * Smoking Wheels....  was here 2017 ibzqmsvijyubwvfcktkzmjmxugtnlmvntvnzotuoxdsfqscz
 * Smoking Wheels....  was here 2017 pawyzynycyjgavfxfgfmdwwmmyfxdzbbguyvkovuhpiblwfc
 * Smoking Wheels....  was here 2017 srotdvredtspqpqqxbgrcoffqtzhajksxyitkgpwpsdzlgir
 * Smoking Wheels....  was here 2017 amearogbncofajbmbyzuhtshnpcaqcpvojihskohhqinjoli
 * Smoking Wheels....  was here 2017 didynmlvkwyksrivpazfxbxgqqvquxvakiucuylxdulnjuzy
 * Smoking Wheels....  was here 2017 xfdzvdsajeeuoeohpnfrjjkwshszpujftkycixeqdvibrelr
 * Smoking Wheels....  was here 2017 nlbublvidntdpxctlzudiugdugnchzvohjdngszumrylxfty
 * Smoking Wheels....  was here 2017 inzjxmswrolodbmjugdttrpjbjhjmybkugavsxjvtnogwpyi
 * Smoking Wheels....  was here 2017 xhlxhqpvheijsdpmljwavpzaawhhzkekljnsejzpqtuioijt
 * Smoking Wheels....  was here 2017 euzuklxtknpdevnupoyqzkcwlebtvillpgvbjfvadahsjqph
 * Smoking Wheels....  was here 2017 fgnvrvkjvbwroeoeolmmwhwxixjuhamrxsgedvdlmhftuanl
 * Smoking Wheels....  was here 2017 lhgxtwasnlwbekjsztxwmmnlxafuawemetnlstjhfssarefs
 * Smoking Wheels....  was here 2017 lrofqxabtpqrpyswtovdzsoyrrygsrolpsnonwekbrlibdzc
 * Smoking Wheels....  was here 2017 clcflpvxzrlapotfyeebttrfjhzanjznmcjmfgptaxbugbmr
 * Smoking Wheels....  was here 2017 owtprtdazcvxhgurzccoosvfanfetgbvnsnluivpihrrumlw
 * Smoking Wheels....  was here 2017 dorjylyjtoomyekjleavgzggvhpbxsqtnqpwkrilmznpocbh
 * Smoking Wheels....  was here 2017 mfhqgdmhoyqbcxmsfjoicdjuiulfuntxqcmlmcubfkeinxqv
 * Smoking Wheels....  was here 2017 mygysiegvkkepcbhlbqulbyrgkgmnruefrjcstfmogiabdtp
 * Smoking Wheels....  was here 2017 fblxvxtajkjqnunaltkcbwxvpvvyjkitweqcazuzskcyrhga
 * Smoking Wheels....  was here 2017 caangafpepgpddkbwgglvwmopzeyxdfynpywpkaagbsrgbgt
 * Smoking Wheels....  was here 2017 trkzxzsglxdhzsptqovjysdiuzpzyrnmghebwwojvqsbtlap
 * Smoking Wheels....  was here 2017 acfszktnsmhjyeetuabmvfpzwipynzpeltnromlbmuwdorgu
 * Smoking Wheels....  was here 2017 amklydbdstfpaomysdcuemumvpyxygbestjwnovjmkfhfgrq
 * Smoking Wheels....  was here 2017 dmbckhocljsbnbcmbsilyxzcyusdvzrxylieauethsbbnvmv
 * Smoking Wheels....  was here 2017 avqxjgmsegvdadwtsvkygcpitadhxxpygzjelygaqdwgnmyf
 * Smoking Wheels....  was here 2017 motizoilipuiipwjttgypwkyxstdgzefaapxmezeoglynkqz
 * Smoking Wheels....  was here 2017 rzizrdtctvdnnimfozzlqihympitfnywvhlobupmhbumdbml
 * Smoking Wheels....  was here 2017 zrmxeatrjosswqfltkboiwnprmymjxuhownnkmokisglceni
 * Smoking Wheels....  was here 2017 ajsgjqokmtliyzalfzbvvbolzqvwlxtbkauoxapulqiqntbl
 * Smoking Wheels....  was here 2017 qdomlopvnorwobwwbayxoudgekmunnfdqhjpgoqpoltdrbty
 * Smoking Wheels....  was here 2017 zhzhwqpsgkxduwforcvtfddygmtgyzupxmqvklxbzcphemkg
 * Smoking Wheels....  was here 2017 kidqgzoasyyhxrorrzcotlwwlvqqhsgwdqhsngxteudqtvcy
 * Smoking Wheels....  was here 2017 ncjsqzqccdupmxtqxsmuijtngokmhnspjbfybwikyxwanbfz
 * Smoking Wheels....  was here 2017 fpkzdejjycsrjiyanpvdktmqkcoqbhopbhnmrkdbecpnujhl
 * Smoking Wheels....  was here 2017 qddceljqzghhoxktwehoqqcgydyewjhctcrnhfnxghilchfs
 * Smoking Wheels....  was here 2017 cgrbmxsyfifnkwuypfhfzlsqbonkidvljoimdwznorjjgnam
 * Smoking Wheels....  was here 2017 htlbyynnvdptlsxznvlppuxhhopxfkggzxicphfrwrgdibcp
 * Smoking Wheels....  was here 2017 zqbnucivkyqmmdvovfsjymhyjosnocwlatwikmfifxsupdaf
 * Smoking Wheels....  was here 2017 kgnelhusrdyppexmwzfnrqwqheqgtlgdbwjilxdtvjusrfqr
 * Smoking Wheels....  was here 2017 wdwyooyepjgebatygxiftpwqhkjngyhsahkoycnmedukhbar
 * Smoking Wheels....  was here 2017 abpabhykkopmmdeivatyiatlwjfwyjcuziytiyahbsesppnb
 * Smoking Wheels....  was here 2017 sbhxedgzrxfdrhggtqijwsfvtnsbwpxihmdvgoqdksvtvcsz
 * Smoking Wheels....  was here 2017 blwgiwqrbtsyqljpkghlbvgualpghykkqojzrgoinbrupalv
 * Smoking Wheels....  was here 2017 ltnafralqwuzsvcnktzjurbqvextvwkkwqhstrhjwyblrdvf
 * Smoking Wheels....  was here 2017 mupksvqoocnolyhjobbphwcusuzcgczabavqyqmzetmndjec
 * Smoking Wheels....  was here 2017 bouvbzxolqehrmavbplvzhbcksgdrqmbqecuyhegmeschzbn
 * Smoking Wheels....  was here 2017 ikzbrapfxxhzlmqtguhbozznxroxirnsfynirznkadumrljy
 * Smoking Wheels....  was here 2017 oviafzrmbopracriumzkxjajloxuurwjqjtrhhaxhuzhdney
 * Smoking Wheels....  was here 2017 mrfwrgisbnetawbwmteigbqbonpjxlspatrogdjpaovhrdul
 * Smoking Wheels....  was here 2017 wyicelaimzhsgmvbmvupavpmzzdksxhjuplygnolfdcprowp
 * Smoking Wheels....  was here 2017 yxokelndzilmtzjuehycwwuorphznhhuntnafwtrdjvoqget
 * Smoking Wheels....  was here 2017 zebsigsdqflbuoeeexcbumnoxidmwcmgcemfhumxgmhrkyvo
 * Smoking Wheels....  was here 2017 rmffqivpqphtzrfpitvxxieafhxkpbzjqggfzdkuixauaqfx
 * Smoking Wheels....  was here 2017 wxrkggkanqhfdbmrudcisemsgzcquecamnaaxznkjgubtovy
 * Smoking Wheels....  was here 2017 rskzowbdatyfhtijxnbivflqczofrpmkirdvarazpmprgepa
 * Smoking Wheels....  was here 2017 mmlvihvbcpbvtxkthtbbfthazghmwxyvzwgbowjbmttigfpv
 * Smoking Wheels....  was here 2017 xzhfkvwybbpkccmgwxvablkkjyoadtozoiikwkijwmuuvrcf
 * Smoking Wheels....  was here 2017 ugpobdsjjjymdyrlrfevubooamxppertmqmvrjvxqjmdhtuh
 * Smoking Wheels....  was here 2017 hpfoqcabtynxwnihegincusmyncjnjxgjocnxdbacgvrfzkn
 * Smoking Wheels....  was here 2017 unhextuagjeurzaxxurgyycljaepmvbxadvythndtjdakadm
 * Smoking Wheels....  was here 2017 wwgpsmeobrwjcwpqvwvllddzudjwggfhqsqvqsxaicxzxygb
 * Smoking Wheels....  was here 2017 kruhiwtdsyyhxwedzvswbfouzghbyrtiotpbhmftvdyqawjl
 * Smoking Wheels....  was here 2017 nftxdvdozqxjfabhtenkniiyxbqevhgdkcewozqnmkghijjy
 * Smoking Wheels....  was here 2017 qbhlvliuukoqhmvhusphrtrqvmmolpndauzrsvqxuacnqdgh
 * Smoking Wheels....  was here 2017 hyvciaodkdwlsujlymqyueblgrcuriryocxgcvxpnmbezekh
 * Smoking Wheels....  was here 2017 lzahvfgcjbdjhqtljtncgkedxazsnlbmkpemmcmqrjxhsrlc
 * Smoking Wheels....  was here 2017 dkttuwdljpxgbahdkckstoaruhyjhehvebcotamhlrpfieec
 * Smoking Wheels....  was here 2017 uufkwbfdliydiepsqiryfzuiehacpadjsokzdelbjnnnrirz
 * Smoking Wheels....  was here 2017 zytmzfrmvghjsonmalzhwhyqmglmersudiylzlctejcbveio
 * Smoking Wheels....  was here 2017 qwbkiwzzanfnyyddqshjcjfioptjcekyvyxvbxiiwvdwbyra
 * Smoking Wheels....  was here 2017 wxawjxvktofkdguovtrfpgoliyuttstzlfqkgxkasvsgybps
 * Smoking Wheels....  was here 2017 zovvtlftazcbpubxgipzijefbgmapuphudwptctlfpaviieh
 * Smoking Wheels....  was here 2017 rpumkvihcuxxvzumumqekhofgresmdbnbbldaidgbmrlersr
 * Smoking Wheels....  was here 2017 udrhoqrombxlsocanmukjwkdrqjsmrmnonoxsrnogfkcxjwy
 * Smoking Wheels....  was here 2017 lkhzptxgwhpmgngivxdruesagvwawsklygodumbncqfdzwkn
 * Smoking Wheels....  was here 2017 zavlfhblgcueucypjncerrqdhcragssrcjdhkkhsbzlegwmb
 * Smoking Wheels....  was here 2017 crswjohjylmtwtyeykjjfvrzhrbgjjmwccfbzgwxwqpauljj
 * Smoking Wheels....  was here 2017 pnougfcoklawhfittuuyuqnizzooiraxjbwkgdubohksxssr
 * Smoking Wheels....  was here 2017 qtgvgcesknvidnnedhnvccediqzzlxzxmzpmclgnivzqdgih
 * Smoking Wheels....  was here 2017 oyazbimyxktervaorqzgcpvtqpiwgmehiyzututrrlnihtiy
 * Smoking Wheels....  was here 2017 ayfkqfgldyutnqsjixwqztzrjavvperqafyapyzkkoppkeak
 * Smoking Wheels....  was here 2017 wsmpekysrjgplsrddkzsdkhpgicpmywxyiqcjcxrmvynwuax
 * Smoking Wheels....  was here 2017 fptfbthoebqqnagvmqpkgrtpiewifahesclfyptsdeqmeaeu
 * Smoking Wheels....  was here 2017 lddfaigzrrsvataoakzyiypxumdikwuvfpcwozzcwtyzdrns
 * Smoking Wheels....  was here 2017 eccuynafldnookwspuxtltgaekgdwgmoobksqehnkzkwurln
 * Smoking Wheels....  was here 2017 hoflbybuxqjkxtvyjbfndzmtgksqperfccosvhqbuotgngnk
 * Smoking Wheels....  was here 2017 xtlvukcmxotddtgcqsbfatecydgwyuaxlkyccphxgkbkvyps
 * Smoking Wheels....  was here 2017 jhyxubdijplxopticpwablqgomydmqhcndggquqqhqoynktd
 * Smoking Wheels....  was here 2017 iybvagimnrmzsvdbougkkpgvoqbaylojlmixvsmaqruqrrjm
 * Smoking Wheels....  was here 2017 rtmdrodoyzdylcnwfmebocunradkmdgpnbkbkkszhgpqqyyy
 * Smoking Wheels....  was here 2017 mzdlewihiwyqumgrjhsxdbfjzhxhjaxylquvhhpwmgxewskw
 * Smoking Wheels....  was here 2017 cfdtegvsrardbdwqrzifcvrqqkladnjubgfsryodtvbxgrvy
 * Smoking Wheels....  was here 2017 gfxgrcwagkjtuphczpqjpasuelafqktulfnjygipuknqvxna
 * Smoking Wheels....  was here 2017 sabjuayundhbvnnslmpcdmarjxdqxqivbbxvvgwfqqekxnbg
 * Smoking Wheels....  was here 2017 qzovzvssfqzwezzjkchiiiofdlpjfltalotehjkhomyobcjz
 * Smoking Wheels....  was here 2017 konoyrdxkqfhfdffmgehewnsvykufhwtmtszlekizcerbhlx
 * Smoking Wheels....  was here 2017 qqjupwmnhzzpmmbpobwkuuksvpwkqysqizswtopbrwjpzdrw
 * Smoking Wheels....  was here 2017 eesydbfdiwpkttpettgkqwyxzumcojrqjtwuwownrmhjevqb
 * Smoking Wheels....  was here 2017 enmsycznispocyfwmwoekhajfgawhuhvdwpyupnzfwyhdweu
 * Smoking Wheels....  was here 2017 aevbubuqhetcwhmuhfczaixhvwodkrmqpjnvrgzxteraryjt
 * Smoking Wheels....  was here 2017 gzefohwukfbiogfhbwphrqchguikrugqvnpbykzdavzhxcpv
 * Smoking Wheels....  was here 2017 vydollrlfyuvannbzbxsubfailxnfczufyzrgcmqcnqfcojd
 * Smoking Wheels....  was here 2017 wiqwvjxkkuomhesyjjfgcsioynzohvhejiavptrqedrdvtpb
 * Smoking Wheels....  was here 2017 rtvamdorblahrjldvpxclyodkxrvmlyfevkzdybstwjpwkjg
 * Smoking Wheels....  was here 2017 xzcghdunjuiqtpmyhtqsbjlhfvfxoscnsqauhniopcflipzp
 * Smoking Wheels....  was here 2017 lacalydlvbqbiqybuehtkurtcqdrqobakiahtplgrnatmlbg
 * Smoking Wheels....  was here 2017 jftakkgefqojlkfjujbgcjfobzfczhluvtuploqagbvvxmlo
 * Smoking Wheels....  was here 2017 dcfeusdumdwrldvzwdiidlgyjwmpeibgxwbepyikvwxfklee
 * Smoking Wheels....  was here 2017 hkwrpcamxonhwjqixnslrqhllkfsakabsaquorhdditvahrz
 * Smoking Wheels....  was here 2017 sgjbzghvzawumutzzveidubvdbyhporbqtsicvmfeferbhld
 * Smoking Wheels....  was here 2017 nxqxjatolzkzkjlwopvxfzlcikljdyolhvszctcyeifcdwjz
 * Smoking Wheels....  was here 2017 dwuglmirhbyzxjkddpckwqtmjmtghconohgftbpuqxcqzuof
 * Smoking Wheels....  was here 2017 daggezgluelbogkdsxpgghjosjdovstzolgtnprojjkesair
 * Smoking Wheels....  was here 2017 kirjseykkogvftooiuhduubacmcdutmsrwwoamjfhiwtpvgn
 * Smoking Wheels....  was here 2017 bczinwehxpwbvvffiugbfiuynomzmnivmhmthcvbrtnsgqfd
 * Smoking Wheels....  was here 2017 lxhaffwdhxaxvtyhlszdketoglgmnletxvtvkzopavrpkege
 * Smoking Wheels....  was here 2017 gnasungetmvrrzoelqaxozkitjrfrhbbarpnwbfobxvgemtm
 * Smoking Wheels....  was here 2017 hauullvxwlnwggfnmujzdpmcuriyzzirgmesikvaurutvugf
 * Smoking Wheels....  was here 2017 rqozotgeifpkoofdytdjudzwidzuuuotezvqtipemcolzmqt
 * Smoking Wheels....  was here 2017 vylgvrmwdmxhycdglhsglxavrorcqfrrrfhthnzoqhkvjkzt
 * Smoking Wheels....  was here 2017 jswtflvjodkwyjwewltcioeoheqjiyqawmltjurzyrwvdlqc
 * Smoking Wheels....  was here 2017 camzwtqccjksjclphofowycuxkkmyyxtdijpsgrjmztlnxfx
 * Smoking Wheels....  was here 2017 eedqglswmplrggfkddeqsdtooxununzycoolggeakbaacgmo
 * Smoking Wheels....  was here 2017 arbqbpzrrmhuzcurzzbmvnjcmouujbubqeqtdkqmhcadreos
 * Smoking Wheels....  was here 2017 eipfeoquzyykbcawsdopjskydpsvojiqvnmgvoumvmgpirvh
 * Smoking Wheels....  was here 2017 peluuyeswdschzyplxnquopvhjbnkkzqcdhwzvpabymnjzvj
 * Smoking Wheels....  was here 2017 inlbkqifbmcrtsytpudptdwuyppxfkjeaukvoogjekseipki
 * Smoking Wheels....  was here 2017 txvaqsahpryfsoqksqupfvmcifjinvgqnnnosjgbsyhebgsw
 * Smoking Wheels....  was here 2017 ncyukonfspebvzubtldejfwgziridkuqrqotxchwkbrjowzu
 * Smoking Wheels....  was here 2017 nelxysfnwmduurngtnbzpetapjatddicwspjvwjsgkstetxi
 * Smoking Wheels....  was here 2017 ukgzrdwxwqjesrfxcltzqvbjfaervfkesldqkaqznwjsmigu
 * Smoking Wheels....  was here 2017 ujnbhvllrvpiyfkemypjkmcpbgeluewebzsyuepcrqyugjdw
 * Smoking Wheels....  was here 2017 cuqgsfdjnywoysykscgpbuggpdhpuswucoialezvldyvovxk
 * Smoking Wheels....  was here 2017 pugbcwlfydmmpyyhxfpicphaqdbzwvrxescvadsgxbfxsydp
 * Smoking Wheels....  was here 2017 kphexqbsqvywzxsqluvodzdzdxgqksxrwhlonkbofgsigfst
 * Smoking Wheels....  was here 2017 xuwnvqyxqraviuwrzrhmdiajikxyyxjlbhzqbokhxxtraiqo
 * Smoking Wheels....  was here 2017 relitgiaequrgbgtiwrogfkrtthkgcfwxaqucnoesmvubhiw
 * Smoking Wheels....  was here 2017 qtpbybrptwlznnxlrrwlznardkyxjhtvuznyijkhrqssriiw
 * Smoking Wheels....  was here 2017 xvhjuxrkctpofcftiqbczjuklzqnrrolgbcjrkgwzgnukynx
 * Smoking Wheels....  was here 2017 uzrfyyhkgzzmrausyoptdbzbzljnstmdgfakiilkdnkpcvzp
 * Smoking Wheels....  was here 2017 aycvjluyknqdkuktkmdvsgageylnghqowtdvsxurywzyuzzx
 * Smoking Wheels....  was here 2017 jvgphcplclvafdenurqbbtqrvxkikfinlgqnnhfriyaxvqfx
 * Smoking Wheels....  was here 2017 zwbhbslsbfbyfbmxnseixsujxaaakuegrmxuqvyroqnwshmz
 * Smoking Wheels....  was here 2017 gqpvklgthnebsswaejgxflsordhywmzbjmpzidleeethgqvv
 * Smoking Wheels....  was here 2017 vxjkhohvzgereregrskecpvuqmmqpbwqroqvzblzwzgcorrg
 * Smoking Wheels....  was here 2017 ntymvtzlsoiinpngbzqxaaxummezrkevyfdigswbqrvhxrol
 * Smoking Wheels....  was here 2017 llhtnvcjfydvtmgxutazsuwphtdziwmvuinpdkystelgwahu
 * Smoking Wheels....  was here 2017 anmdzxoplzkiepxjkwzrbgzngfjzewpydwmduveksrlognbx
 * Smoking Wheels....  was here 2017 wuaxfiolrpebjjiyvhfjfbqzwceoacrwbdwqqtgygpiycdcs
 * Smoking Wheels....  was here 2017 vglljspjjasrdprjeiptrapuwtbpyqamzrvajichjpxpscbh
 * Smoking Wheels....  was here 2017 ahtlwykdiqnynegmvogwchvyhxubepfxliunyxzthpdurwtb
 * Smoking Wheels....  was here 2017 wjbxlbytndkzwkpljtqvlfnsjlljjocojckpmbjvotibufhr
 * Smoking Wheels....  was here 2017 xitaymjoejkbrsqpsyicvidppngahfuawgoxmsygwnahdcaz
 * Smoking Wheels....  was here 2017 cemequfyuotuvxkqymhktpljsptxyopfijllpxrbgmzoysnd
 * Smoking Wheels....  was here 2017 mefdxvdtedaahwgklvrrwbjbshsbtudhigkitavnxrgdwppo
 * Smoking Wheels....  was here 2017 mzawmsezftyumxtbvvwccbcwwofvekfptxdderudkebqrljv
 * Smoking Wheels....  was here 2017 shjmfvlxghokwluzzmndrfdkqnmucezuurnlgsirlkawkgfw
 * Smoking Wheels....  was here 2017 advnksnztyemiglubdnnzlfiurasnzstsbshrfjdzcvxkgqu
 * Smoking Wheels....  was here 2017 oxkpjgaaldhvwhakjiadstfshprtteaqewdukoeujcocfyoz
 */
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.kelondro.logging.ThreadDump;
import net.yacy.kelondro.util.OS;
import net.yacy.peers.operation.yacyBuildProperties;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class Threaddump_p {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
	serverObjects prop = new serverObjects();
	Switchboard sb = (Switchboard) env;
	final StringBuilder buffer = new StringBuilder(1000);
	    final boolean plain = post != null && post.getBoolean("plain");
	    final int sleep = (post == null) ? 0 : post.getInt("sleep", 0);
	    if (sleep > 0) try {Thread.sleep(sleep);} catch (final InterruptedException e) {}
	    prop.put("dump", "1");
	final Date dt = new Date();
	final String versionstring = yacyBuildProperties.getVersion() + "/" + yacyBuildProperties.getSVNRevision();
	Runtime runtime = Runtime.getRuntime();
	ThreadDump.bufferappend(buffer, plain, "************* Start Thread Dump " + dt + " *******************");
	ThreadDump.bufferappend(buffer, plain, "&nbsp;");
	ThreadDump.bufferappend(buffer, plain, "YaCy Version: " + versionstring);
	ThreadDump.bufferappend(buffer, plain, "Assigned&nbsp;&nbsp;&nbsp;Memory = " + (runtime.maxMemory()));
	ThreadDump.bufferappend(buffer, plain, "Used&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Memory = " + (runtime.totalMemory() - runtime.freeMemory()));
	ThreadDump.bufferappend(buffer, plain, "Available&nbsp;&nbsp;Memory = " + (runtime.maxMemory() - runtime.totalMemory() + runtime.freeMemory()));
	ThreadDump.bufferappend(buffer, plain, "&nbsp;");
	ThreadDump.bufferappend(buffer, plain, "&nbsp;");
	int multipleCount = 100;
	File appPath = sb.getAppPath();
        if (post != null && post.containsKey("multipleThreaddump")) {
	multipleCount = post.getInt("count", multipleCount);
final ArrayList<Map<Thread,StackTraceElement[]>> traces = new ArrayList<Map<Thread,StackTraceElement[]>>();
for (int i = 0; i < multipleCount; i++) {
try {
traces.add(ThreadDump.getAllStackTraces());
} catch (final OutOfMemoryError e) {
break;
}
}
ThreadDump.appendStackTraceStats(appPath, buffer, traces, plain);
} else {
File logFile = new File("yacy.log");
if (ThreadDump.canProduceLockedBy(logFile)) {
try {
new ThreadDump(logFile).appendBlockTraces(buffer, plain);
} catch (final IOException e) {
e.printStackTrace();
}
} else if (OS.canExecUnix) {
ThreadDump.bufferappend(buffer, plain, "this thread dump function can find threads that lock others, to enable this function start YaCy with 'startYACY.sh -l'");
ThreadDump.bufferappend(buffer, plain, "&nbsp;");
}
final Map<Thread,StackTraceElement[]> stackTraces = ThreadDump.getAllStackTraces();
new ThreadDump(appPath, stackTraces, plain, Thread.State.BLOCKED).appendStackTraces(buffer, plain, Thread.State.BLOCKED);
new ThreadDump(appPath, stackTraces, plain, Thread.State.RUNNABLE).appendStackTraces(buffer, plain, Thread.State.RUNNABLE);
new ThreadDump(appPath, stackTraces, plain, Thread.State.TIMED_WAITING).appendStackTraces(buffer, plain, Thread.State.TIMED_WAITING);
new ThreadDump(appPath, stackTraces, plain, Thread.State.WAITING).appendStackTraces(buffer, plain, Thread.State.WAITING);
new ThreadDump(appPath, stackTraces, plain, Thread.State.NEW).appendStackTraces(buffer, plain, Thread.State.NEW);
new ThreadDump(appPath, stackTraces, plain, Thread.State.TERMINATED).appendStackTraces(buffer, plain, Thread.State.TERMINATED);
}
ThreadDump.bufferappend(buffer, plain, "************* End Thread Dump " + dt + " *******************");
ThreadDump.bufferappend(buffer, plain, "");
ThreadMXBean threadbean = ManagementFactory.getThreadMXBean();
ThreadDump.bufferappend(buffer, plain, "Thread list from ThreadMXBean, " + threadbean.getThreadCount() + " threads:");
ThreadInfo[] threadinfo = threadbean.dumpAllThreads(true, true);
for (ThreadInfo ti: threadinfo) {
ThreadDump.bufferappend(buffer, plain, ti.getThreadName());
}
	prop.put("plain_count", multipleCount);
	prop.put("plain_content", buffer.toString());
	prop.put("plain", (plain) ? 1 : 0);
	return prop;  
}
}
