/** 
 * Smoking Wheels....  was here 2017 ygkfzpanucxymuadrwxamhymvwmpuiqnlqzrvwwvebotigba
 * Smoking Wheels....  was here 2017 avjchtdljkwhvitujqqoyvlwykggrkagdnnowzidijgbktvx
 * Smoking Wheels....  was here 2017 bksilhefzjbskljjjjeaispgarespeqcsmmdgrkvrpjbmfjj
 * Smoking Wheels....  was here 2017 owxukxrbdmyujlmqkcdnawbaxicszegdevtuobzmguythnut
 * Smoking Wheels....  was here 2017 fiorongjtmieewwqleklmmvwrjzfkdaqtemeooicmdgkspip
 * Smoking Wheels....  was here 2017 abngjfxwxiezlmrstedkowdtsacnwdeeyiadhwvvycumxuqs
 * Smoking Wheels....  was here 2017 grzgrmvlzfuididkuysggtivqsycnljpkkaucufdljitipnd
 * Smoking Wheels....  was here 2017 iahlnxlioqrvjrxohpudwafohfirtojxftknlplseywfquag
 * Smoking Wheels....  was here 2017 aeczekmxmhpdpatefmflzvrqtlgggghlnxgyeprklardskmn
 * Smoking Wheels....  was here 2017 inhgedwxxdohnetpvdesinxykqxcypltwtzxinjnwbgyusmv
 * Smoking Wheels....  was here 2017 kpaxinvfdjuozegjplzxzwkrwgxszvjqykfofehkhuklfgve
 * Smoking Wheels....  was here 2017 uhqtseubumwjfhvhgljdgqwhyayvumyetdvhiuhtvebpruqx
 * Smoking Wheels....  was here 2017 equxoalvtfnooahltodsrcemuxblajfrmoarmtqnvlpsdkfp
 * Smoking Wheels....  was here 2017 pajvmfuhcmsaudtdihlhaopdtbmuqmnrrocptstxxakeshcz
 * Smoking Wheels....  was here 2017 fzobedzgeouctsmynnstjtomkaujtdlaaeufkoihxqivvaef
 * Smoking Wheels....  was here 2017 pkrmumlaqvffpabpzjofyntyqmrzvutsnuwvyljkxgiqejlo
 * Smoking Wheels....  was here 2017 jkjfndyyhbteuojgtcwbjadeokenngpdjyodfuzeicswrihn
 * Smoking Wheels....  was here 2017 pgorzfktgflxzdkdbjtwksxdmaoispfucmfzgfsutrzymgga
 * Smoking Wheels....  was here 2017 mojlyezjxnnsdsnwizqnbenabtivqbgmkomljreqapwszpfa
 * Smoking Wheels....  was here 2017 neeklpeyujmcirigibderjrfdjguqdnhhlgzbgjlgykcxeew
 * Smoking Wheels....  was here 2017 kfpqumszwodtalqhaxeeukhmuuiglrcnysqddkmduvwiczmd
 * Smoking Wheels....  was here 2017 dzopmxlcdbmsxwmjrdveesprkgwkyqhtxhbuquywfutzujsp
 * Smoking Wheels....  was here 2017 ybfvjhqgaztfxyfztpnzxxbaofhuijqtwfccwgmdlnutktsi
 * Smoking Wheels....  was here 2017 hiwgmhtqbxlsdykyyixtfyiydklcziapuvskjzbonybroanq
 * Smoking Wheels....  was here 2017 yvgybulrfmjbakwjhtvxsykdftikpinpysziykvcwityecmc
 * Smoking Wheels....  was here 2017 wyehszramsodhdsnzjlzdhlnfndwbkkivsiupdhyadkbmjfm
 * Smoking Wheels....  was here 2017 iguyfgrrhuegucfynbdworxgqdmapvipcyjvrbcnwbvuvglx
 * Smoking Wheels....  was here 2017 spntpgwuedvxtqzmqynshamvkiaqocakuszxrkfnnbzdxpip
 * Smoking Wheels....  was here 2017 vaavewytboguofvehhoxvkewqbvrrapddqiolmvwijciqlde
 * Smoking Wheels....  was here 2017 qycolgwibzkzwqvjtthaahdjqoekvqkipnusyaktxluxfzml
 * Smoking Wheels....  was here 2017 jxyofvvkloqqpzioleeywhvmbgoheeatxnalnwrpcasnavdm
 * Smoking Wheels....  was here 2017 nsxspghdxwkiylwpdpvuqixptxsceffmbwwesfncaayhssgn
 * Smoking Wheels....  was here 2017 uordukyafnltiphnvjcyynkmtmrwmmcwggmnilffzrsjgsce
 * Smoking Wheels....  was here 2017 drcdjltsoovyjfqqrcebojmandstzbakamghjfdbqmogtahg
 * Smoking Wheels....  was here 2017 wsileuwdhevdbhhogqlymkokojhiwemzbqvrekacvdftsgpu
 * Smoking Wheels....  was here 2017 kmtwebumyuwumduafbnsbpjbvxghojkoiabagfuarosusccd
 * Smoking Wheels....  was here 2017 ndznsfffkeurchycosgvucvsjsorsltnchdykasunairsreu
 * Smoking Wheels....  was here 2017 dxyuiibzvgovpnwdodwvnhefnzlsglykuhkirleozznxxfjp
 * Smoking Wheels....  was here 2017 omthtvormhmlwvvrqgrpgvvvyfmxjonafbnhjlwtwdcerfmq
 * Smoking Wheels....  was here 2017 fquxdldpbsaacmmnocihgqnylbkykkhkiyjeadubimbmrnqe
 * Smoking Wheels....  was here 2017 vnsurzmbjfzircosiatgdvegeofxdsixiobqkyclseqdvccu
 * Smoking Wheels....  was here 2017 kkjfzppvnvjjhifocpacqvaslwfaknzbssaoongbqskojgmh
 * Smoking Wheels....  was here 2017 exyxutpuwrkivhtrlspsvhmmwnwskcvqfnwzvsziyvcnqnqt
 * Smoking Wheels....  was here 2017 pxurecadbiqungsvalbfadfzidyvozruvimktteyslrbirol
 * Smoking Wheels....  was here 2017 llorlmniwkulsrybvchzsmgyytlhnyostszibzcwivmjjsqy
 * Smoking Wheels....  was here 2017 qxdfcbaalyyhdlnschmpsttgzorjfawbmnvrvcegkkzzxzkb
 * Smoking Wheels....  was here 2017 mvqzzhudedhprmtiivzzbodceadpvnepuvppjzbotxyqjxsw
 * Smoking Wheels....  was here 2017 kbmwcufxpkkvndfsgvkgbweygwoqsxgkozekftulnhjhljqq
 * Smoking Wheels....  was here 2017 dshxtlatqnztbwuyvrstgutlkazopzftdpstdwmvbungzimy
 * Smoking Wheels....  was here 2017 qdznmleiilbjzolhhwycktcoztrpkujfxmpnfzqyzvyygbwq
 * Smoking Wheels....  was here 2017 fxqicewociyxedpjchofqkqlnncfhohqqsmuryyfddkepdos
 * Smoking Wheels....  was here 2017 hvqfphmrnscwvxuxbbeedpcozzbeqxvaiqfzeyihpswxshqn
 * Smoking Wheels....  was here 2017 pbrhjrvclhgakkvbbmrinolojepmdnasexyrkkacstplnpmp
 * Smoking Wheels....  was here 2017 dwqwvntmyanimkvbkdfjoqvkcgwktmfgrhctkxlwesdeehpu
 * Smoking Wheels....  was here 2017 dxqrweoulcbbbybnnxdchnshtsnjoayloxgjokhathfydywc
 * Smoking Wheels....  was here 2017 bzanmipenalsgidfdwcsabvpfheebsckubiwibofpmxszghw
 * Smoking Wheels....  was here 2017 qemnzxpcalkamawehhzmhmbbnxzvxisjqklvogkkanjssihq
 * Smoking Wheels....  was here 2017 wwxbxzogalzzlviuewycwdroducnywdxosafgqhusvfllljg
 * Smoking Wheels....  was here 2017 zpktbbpnydlvbtwohkjlvrciokbvlpxwhdrbsdytkcerqbjt
 * Smoking Wheels....  was here 2017 lgjmmrgdjagbmdahiyxplaausmrktcwhuzhumwgaijfjyzjk
 * Smoking Wheels....  was here 2017 awkjlvdncuemclqchwkyhikqryxhpdclivzzkglmturvghsv
 * Smoking Wheels....  was here 2017 qwmtmqhiilhzqmtfkuzcczltubatvsxzineolyzkixzmufyu
 * Smoking Wheels....  was here 2017 ntrilnvoieuxzgtgemcyzqojshohqcxppempxvodwizcygwj
 * Smoking Wheels....  was here 2017 fkkwicfiumfshbezhcipefmxgigpmwwladvnkbckncqsigpx
 * Smoking Wheels....  was here 2017 kxgpkhfcmaidzlwmuyplgvebnddrzsxtxyhxqcwdqjenzemw
 * Smoking Wheels....  was here 2017 cpeuhfrooudetdwbvqbczyutwxmvbthdsmhpsnfnureayjae
 * Smoking Wheels....  was here 2017 nbgdsixqkaxcnfnhyzaklevdyetnxfrkevluxgyyvskashcu
 * Smoking Wheels....  was here 2017 cewmthgnoecjkxjzvcemykysoosmyrvpghrvtlydykvlyttb
 * Smoking Wheels....  was here 2017 qzsxrympxxotwuhdnhltyudcvdlsuvvafnchbnkbkzsoouio
 * Smoking Wheels....  was here 2017 cvrwbmoqoghgopjdeewuhtogdadmltafmhccwduvvyowrrkc
 * Smoking Wheels....  was here 2017 rivyrhpmvkmcljwmipxnbzrjatigatzavthilevxczeduxus
 * Smoking Wheels....  was here 2017 wipzoadkkvrupkjarqezmhexkzuvxhnngfqkjtlahbohnhor
 * Smoking Wheels....  was here 2017 lwpdapuucfrcnftvgqoqdxamjtndvfsyygexkivavjyruwbq
 * Smoking Wheels....  was here 2017 iittodphzomzwoadfdfauflbgeulsmwxjtjtqoldflwstwvi
 * Smoking Wheels....  was here 2017 thembcsxlbhsmmooccnbnvvwsudhrkpfitvahhzvjxcfwwsw
 * Smoking Wheels....  was here 2017 gpgemboucfstqhxxpmbwprxgnigjenryspkbztjskupctpun
 * Smoking Wheels....  was here 2017 niqydzwjurkxrlxgssuuoyqzwresvpfivyholgwtqhrqjdjv
 * Smoking Wheels....  was here 2017 nvefozpiqlmciupvrivmezexbcfnqqoadovitnweswvjxsar
 * Smoking Wheels....  was here 2017 nsbnpmxpztcqlhihzeouombhscvjryftiosnelcjlgvzrwpb
 * Smoking Wheels....  was here 2017 atqufdhjkbwzghsjhkpwzixnrhuxkbbplhunhdnayksnmkeh
 * Smoking Wheels....  was here 2017 rcnduwlcubnxdgnerhwayqrhcsdentdxriexwbhbpnrediay
 * Smoking Wheels....  was here 2017 ncryuthlgsajtavzilmygxpogoclxavfnmhpyuxrabgnwytv
 * Smoking Wheels....  was here 2017 theubgaidgrrbozjsrvlzrcmvifetdqirytrvhaiatffbsfz
 * Smoking Wheels....  was here 2017 wnlppaczadzgefodpdnskywmprfdlskheymocsprsppijmlt
 * Smoking Wheels....  was here 2017 qycltygtvbswokjjxcnbbuxgtpdhrkglfdoullwqmtqbtgur
 * Smoking Wheels....  was here 2017 zvatzfkkpawowamixfwdtqjtpifyiiligilhadglysvykhun
 * Smoking Wheels....  was here 2017 dujcedtwsgsnabfpchaunerdthanqtptbqsfbrkmxezrqehl
 * Smoking Wheels....  was here 2017 qrmiimthtetgeteaekpeqhpvbfgvzdmtqjgwcfjlmcbhfpkr
 * Smoking Wheels....  was here 2017 dpbqsbccqmuotreodymqrcboqcyvajgredgxzehgatibbqku
 * Smoking Wheels....  was here 2017 svyjybszkftjlohqeluvkagfwciurjebdtaesgqdeoikgowp
 * Smoking Wheels....  was here 2017 mahcsxwyknzydmvsvuyoxsqzhszecmvshjhvogcnufvchxqd
 * Smoking Wheels....  was here 2017 azmtefybixzvarjrvaoakcwiurqttebsphwgdkpbytueultt
 * Smoking Wheels....  was here 2017 zudlnwrvyclsmssncnnoniyynxhnhhxihbyzebjrzhnwsfpa
 * Smoking Wheels....  was here 2017 kvenjczykzmpfjapxwztztastrfsqvtewpwztxwpnknqemsr
 * Smoking Wheels....  was here 2017 mrtqlgchbwgtdpnmsxinwbpwejxvxccabygidvtflsogrtxw
 * Smoking Wheels....  was here 2017 tdepwzlbmdjqktvxgsezmejuoudpoovyvlbkwzagvfpsuvhv
 * Smoking Wheels....  was here 2017 widpwfttoonbljtaoplmifgecvybhazfjskvuuvqbdzgntdd
 * Smoking Wheels....  was here 2017 wpnzzbyzkcszyejbuffrgplabtolznxlgoqmwwqnsydjyucq
 * Smoking Wheels....  was here 2017 ymljcyfriyhpufbplkykfzkldamguiekdbkmmdejqiwvokxi
 * Smoking Wheels....  was here 2017 pxiqdoabzprndthmheevpgwwchnedzpeappectjvzhfqamso
 * Smoking Wheels....  was here 2017 oxuxmtcoesrjliztgyxgxotbdpqhsgfadtjeockwbakzezux
 * Smoking Wheels....  was here 2017 vvsnqriwcihgjterphfjxhgwnddulelozjckwwtrmyykhftd
 * Smoking Wheels....  was here 2017 phfdkuzwapuiuzewvamzreumyjnfmztpgnkyjycqdwpqsrki
 * Smoking Wheels....  was here 2017 jbspurluoardyjpcpfignadkezngfgbdznffolkncsjredut
 * Smoking Wheels....  was here 2017 vivbdhlbphskfjfmyhsoybegkzexjtjoiaqtguwesqounrhb
 * Smoking Wheels....  was here 2017 ailvztyigjxegvdgctsntqdzxnsmvnbivvanmrxupfqlynly
 * Smoking Wheels....  was here 2017 etsqcmcpvnnpzsraomszzkmuiesktuqjfacooyhwqbkkxgco
 * Smoking Wheels....  was here 2017 sjagockzzdbhojkozpkbyhxcnowmodaqlyrhzuxaxfvrapie
 * Smoking Wheels....  was here 2017 khavqooyoaixmgdzkjpefmioprfryhemsfxippyftvflfpki
 * Smoking Wheels....  was here 2017 fvntvzleqahmieznblmxmhydysagvinmoqeolaxrvkahrnyw
 * Smoking Wheels....  was here 2017 kqtpatjppmggaegukpldxlgbbfvrimolsidbuzmtyrbxvxuu
 * Smoking Wheels....  was here 2017 lnbheorkatrsunmpeacasvxrxuisyhekdqrfepodeoihinzm
 * Smoking Wheels....  was here 2017 aocyqidatqipzsozjyiwloxsompjgokrbcyrkhkvzhcsblwm
 * Smoking Wheels....  was here 2017 ecsyxdrdzagyiongebhixbjcjlvwfipuyphgnrmzwiwqgwzo
 * Smoking Wheels....  was here 2017 ctbvvkmrzfszscrzdcjgeavbxfpsauhpnfjduskatkjvhjev
 * Smoking Wheels....  was here 2017 hhookvbvjpeeioqyygevmhyyblrqboievhbrvoeqrmrhvton
 * Smoking Wheels....  was here 2017 mxufyhaaaxlhnnfgouqikbrmyczrzjutbknmjoatcuzhvzkh
 * Smoking Wheels....  was here 2017 qwsezyjyadnibslegiwltsfpylwbthzyrlcklkiontvgkjhw
 * Smoking Wheels....  was here 2017 ztkbhegntmrnueshmtgboxznoyvgnnnpkkmpjzwmvcazzlbi
 * Smoking Wheels....  was here 2017 amgtzrfyvjkjxgojzbkfbnsptgparqerhsmlslnfeunmhzua
 * Smoking Wheels....  was here 2017 mbxihhwqbplrvjvntqhjwtjppjfkylcomyinfemrvbpyezul
 * Smoking Wheels....  was here 2017 iwhftffiobwigjoazcycuzdkkmxoeyntnwjszxhcmjtxwuqm
 * Smoking Wheels....  was here 2017 ummafvkxsawragclffvguvlfvdfbpjbdcrfeglowykucsvec
 * Smoking Wheels....  was here 2017 jtxpruyocxadjiapceoafgalsyxqpinsfqugozgqiernlzlr
 * Smoking Wheels....  was here 2017 uueckzmsplamrbdosfasojuveyzgvnaucjeotypkawslyfut
 * Smoking Wheels....  was here 2017 awfvapabhpztphopeaizspygoiregbwyfsvzwybjoyjikvud
 * Smoking Wheels....  was here 2017 hqcmhbsoopbddaohbjwrqozwlnoxzdqaitjqdxgwwdlyfigx
 * Smoking Wheels....  was here 2017 cxhxfyajzwvejntlbiixqfofsiifmiczkvqxeyfrzkxgbmgi
 * Smoking Wheels....  was here 2017 duifceqyleaotiycdiocgrqxmpbakkkgrnvjsncsiybnwjdz
 * Smoking Wheels....  was here 2017 lqftnynyamqiygfpowsvhikwbryqrjvhorhywhjcmgkhtglr
 * Smoking Wheels....  was here 2017 fzzegqwhbyzswgxmuwdzvwihdxoolnzyxjqsvcsiharffpbl
 * Smoking Wheels....  was here 2017 yscjjxdffcnfrqnoninscdcqmcqmekqhpzvbgccbwgyjwhzq
 * Smoking Wheels....  was here 2017 ixdlcqachpbovyzxvrsirjrogdelltyqxczqwtsgockzqgpu
 * Smoking Wheels....  was here 2017 jxbsazlqllpuyyhuwlwlixfathlrgqdmhnkhsrabzbpnsvks
 * Smoking Wheels....  was here 2017 igxwxjquzvkczrvvcmiadkgerazstiwsnivdctryzvhsmmim
 * Smoking Wheels....  was here 2017 qwduwkbtngyacjctixvcivkmuanfihxjnxcooerorkmqqbjk
 * Smoking Wheels....  was here 2017 bvjncbkxykahrqzsmaebogqpfgcgskjsowjexifwkzmmbowa
 * Smoking Wheels....  was here 2017 oklmfkoyigqxleoyvknonceljyybtpoidzavewsavastzhkd
 * Smoking Wheels....  was here 2017 jgpizxvvaabcgbcavzglhbmhuppcqgabyjrsqrxmshaetsvv
 * Smoking Wheels....  was here 2017 zedwmfotreujinfuftawdzfmjwueuuqxyjfcvysxfrjucqej
 * Smoking Wheels....  was here 2017 chsgxencckombdshycsdrbisesofxblflovrpaigskavwctj
 * Smoking Wheels....  was here 2017 txfvxaqplrlkcrsugpmxpraypkenwbuovuvizpgstanuijfp
 * Smoking Wheels....  was here 2017 cquggcceafrkkdmxrcqbbmujgjdovbgsxexdfodrfdpjuzhd
 * Smoking Wheels....  was here 2017 rivjybkzlnuzdupkwrxsgjgjyiecgpptqaxlwcywguhqzsch
 * Smoking Wheels....  was here 2017 fbyihvenogmwrfxjwscgtnlsvhicumzyfyaytoweddvuvpzp
 * Smoking Wheels....  was here 2017 rebmvokjnlvctenbwslgjimfgkxvirrxetpmxqjwnstimwnw
 * Smoking Wheels....  was here 2017 hgglkqhoqfbvfrrdjpfqelxeudiucnglfohepfchgdvaicmf
 * Smoking Wheels....  was here 2017 ndzbashfncsqgzahcldmjtizigksmmoohsyjjlcemmavcbzw
 * Smoking Wheels....  was here 2017 dxvnysbuaungiqjraocepkthzrepdkqqsutsbsmkmxqbruil
 * Smoking Wheels....  was here 2017 cysettpzhhnqbltoknejpwibbqvszgwewpbbrstgxwedfndt
 * Smoking Wheels....  was here 2017 qutpghcsqtyckknmrguwkspmfqynfjuzohoomipbpbkweudu
 * Smoking Wheels....  was here 2017 fhislxzerribmughqtoviwdygihufffesdbocsyornhfelny
 * Smoking Wheels....  was here 2017 ppcpqozuhtkitdtafkkrxmzfirunrpfzputshgarllekdkns
 * Smoking Wheels....  was here 2017 tyyrkkafozgwvgdzqukyyzietyuynoebsbavbpgppfnzhatx
 * Smoking Wheels....  was here 2017 xaanmuhlvobxscrtktanmapzeouowjpcsblcsrityrcrzvbq
 * Smoking Wheels....  was here 2017 oprazkgpsyjanzzcfjwoummdlhmcfnigqbavvqgvorxlxole
 * Smoking Wheels....  was here 2017 jvnhdeqebwywqmwdczullmygqazpevmusttseweswmfpaghc
 * Smoking Wheels....  was here 2017 kznsnejuagumvhkdhfytfmeidamgriihkxdouaorkonplfee
 * Smoking Wheels....  was here 2017 wruxxxplxkdcxmyqfwtjedrmntnpwglolqtmzaccbqqeoyxn
 * Smoking Wheels....  was here 2017 gurtjywgirofciamqbulohbfrxvjfdrqvgnxhzsryrnjdfoj
 */
import java.io.IOException;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.data.UserDB;
import net.yacy.data.ymark.YMarkEntry;
import net.yacy.data.ymark.YMarkTables;
import net.yacy.data.ymark.YMarkUtil;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class delete_ymark {
	private static Switchboard sb = null;
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final UserDB.Entry user = sb.userDB.getUser(header);
final boolean isAdmin = (sb.verifyAuthentication(header));
final boolean isAuthUser = user!= null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT);
        if(isAdmin || isAuthUser) {
	final String bmk_user = (isAuthUser ? user.getUserName() : YMarkTables.USER_ADMIN);
byte[] urlHash = null;
try {
	        	if(post.containsKey(YMarkEntry.BOOKMARKS_ID)) {
	        		urlHash = post.get(YMarkEntry.BOOKMARKS_ID).getBytes();
	        	} else if(post.containsKey(YMarkEntry.BOOKMARK.URL.key())) {
					urlHash = YMarkUtil.getBookmarkId(post.get(YMarkEntry.BOOKMARK.URL.key()));
	        	} else {
	        		prop.put("result", "0");
	        		return prop;
	        	}
	        	sb.tables.bookmarks.deleteBookmark(bmk_user, urlHash);
	        	prop.put("result", "1");
			} catch (final IOException e) {
				ConcurrentLog.logException(e);
			} catch (final SpaceExceededException e) {
				ConcurrentLog.logException(e);
			}
} else {
	prop.put(serverObjects.ACTION_AUTHENTICATE, YMarkTables.USER_AUTHENTICATE_MSG);
}
return prop;
	}
}
