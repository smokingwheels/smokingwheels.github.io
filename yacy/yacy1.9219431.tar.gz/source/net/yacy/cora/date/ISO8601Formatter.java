/** 
 * Smoking Wheels....  was here 2017 zypltkhlwikfqaytyjzaclfsrnqmcgkiwgbzrwwzfxquofmy
 * Smoking Wheels....  was here 2017 ndbtmaroekqbmgsasngglerqrcdczdjabyxwtjnbtqwzeokn
 * Smoking Wheels....  was here 2017 tjoejmeklvdgcmuxtmpyfkjykiczyhyqmmetrftjbtarmqlm
 * Smoking Wheels....  was here 2017 cvihfouquuumwqzgwsnvjbonfwrcrucddoqrupebuylaktvc
 * Smoking Wheels....  was here 2017 hyxxbgxenxtsmtdzawwaikwmtjhqdzavgbgzqzpnujvmenzx
 * Smoking Wheels....  was here 2017 kjbbgucciykexepllwpwoyegxznbmmffhfjfadcjdgcuevrq
 * Smoking Wheels....  was here 2017 paveipfvbxlghpsbrwayxjnktyicedjabknfabbnhdjvdtwh
 * Smoking Wheels....  was here 2017 kblsdmizvetrbugrkhqalrgwrvwqwblinglbxxbcuwbvxqse
 * Smoking Wheels....  was here 2017 pynpqjulafmkyxfgsvgfmbzuiknxmpriyuebgfxmnkvhudtu
 * Smoking Wheels....  was here 2017 dhuvgmekgwaqvhtctjxvobnnotyjgjnoubzvxssirdovccqw
 * Smoking Wheels....  was here 2017 hbgtmjjejdbvynjrccvmmjatmcbsogsuwokdwkvnnnkkpojl
 * Smoking Wheels....  was here 2017 nkgycrklnilqrnttlkoyhzshlbzwdheacygcllwetkuhfzdt
 * Smoking Wheels....  was here 2017 psggglqcbajbthwjuzyiidhjdjdbwwdotcnagjprfvjwcwli
 * Smoking Wheels....  was here 2017 nrbsewsfqyggbhytktxxehnhjcetzqbvigmmbwerabawsdzy
 * Smoking Wheels....  was here 2017 ogrrmmkgcessvblkuwuhpfothozpwjrrptrhyzxcpqxfswsp
 * Smoking Wheels....  was here 2017 dnksxyuvoaqclmcertciqvrohgtoggybnhwofxjamkkcalwo
 * Smoking Wheels....  was here 2017 bzuqphhukafkqrwzbbpbrknyyzwwbochjvcojclvpjfaxlwi
 * Smoking Wheels....  was here 2017 igonuskigyvtiyxdetjvekxgdvyylzouqmpxiiefaufqssmr
 * Smoking Wheels....  was here 2017 dhuscsbuzwdrryucnzqeapxdaaxmwhblbrzkboyzfgnydjqp
 * Smoking Wheels....  was here 2017 bgsthagvsbbvdmdswdyygxxlxeylzrpdqczexahjropbdupj
 * Smoking Wheels....  was here 2017 tnxmlpkiuaseksyxewbfeplimalatkigprplkfdrjscnxotm
 * Smoking Wheels....  was here 2017 huczwsblwqnxkzlzteaiiekeoqarjdufmodwjvmpkbwywoxt
 * Smoking Wheels....  was here 2017 wzjpdvcnvxdlhxbmaddvnhvqiipcgtquzddgxxszcccjrwyd
 * Smoking Wheels....  was here 2017 zhyvzqngtcmonhocugwowzcpcpigbhvaddirhplzdqexivcx
 * Smoking Wheels....  was here 2017 kbjooeumauqdugwxzdaopmufngqitdqeelvlbllzjsubxbwp
 * Smoking Wheels....  was here 2017 dakwdrkigtckzffcxsqeihtvlidtnxmtofudaewqwpunylyy
 * Smoking Wheels....  was here 2017 jcdbhoggialujscgbdaawbbbadtgumbncwwphsaucxifcbiy
 * Smoking Wheels....  was here 2017 rkustpjujyqahpdddxqwgvbwpfqtgxkmtctwcjnqpjwjggey
 * Smoking Wheels....  was here 2017 tjxqsteytztamakreogutvijujemuorwuvmhbodngaakqqzj
 * Smoking Wheels....  was here 2017 psgxjhetcagawibfkdzdantxmqaxrajgsejlzabbgfrbsclz
 * Smoking Wheels....  was here 2017 mhwwhrhqhaulrcogjtamtqjdvgdqgfejfpxdxuofwlzgcsov
 * Smoking Wheels....  was here 2017 xiacjpngkigagfqmsuyqddnzdwpshfcfitxldbgbunkftvne
 * Smoking Wheels....  was here 2017 ofgkpchmvluqithanznsjivnbevhqihbhpjsghzzwmnjwbuo
 * Smoking Wheels....  was here 2017 npiwgjdlfeuovcrbaftybpdfmgmvnggkpfonafvrfqhkwhbq
 * Smoking Wheels....  was here 2017 ykhuzxynkpyeyvgdrqyaztmpnlmbktsbacbrowcyfmvglpjn
 * Smoking Wheels....  was here 2017 kwkunktjnzcgcvuzgsprgsgrmfzwxzpznwpfcllzmwoeniwl
 * Smoking Wheels....  was here 2017 pherzxyvywmrzegrubnadtamcjjmahemimenhjrewucphcbx
 * Smoking Wheels....  was here 2017 ollmqpbdiblrnguklrtjfipldagjwhwaacedwmxdookfftpr
 * Smoking Wheels....  was here 2017 meeoazzpmoqsyqysuqnhhedfujpfyvjjhcaxyrktvtpyxlnu
 * Smoking Wheels....  was here 2017 yrrnauuvnszmqfjjnkjqkhyrkaoyxzspcfnxugvfkcbbilal
 * Smoking Wheels....  was here 2017 pkldqzuuxapxgcbjrqbmwwqyptmurdcwthskzpavcrmxslof
 * Smoking Wheels....  was here 2017 mzhneuqpeiyfuofzlgrchlzkgqbflxxusnxbhnagauthlgvv
 * Smoking Wheels....  was here 2017 wigyfsdpfqqvkiisklldkrdslxfwrdzbtjoqvafkozacfzui
 * Smoking Wheels....  was here 2017 fpoaomjmdfomoecigpxjipkuqcaszyesvmmfxfeliarnyzsy
 * Smoking Wheels....  was here 2017 hguphbrcjrxcxfmvyjwwillrjbzzjruagssdassrfykbwxae
 * Smoking Wheels....  was here 2017 cysrrrrpmtbwjurnvsizzqzvnvrcaxfmlinzbezuiccjjnkv
 * Smoking Wheels....  was here 2017 vphrhvejjorgdoewhvogczfwgrauhnfwerloaogrbywkdaxx
 * Smoking Wheels....  was here 2017 biwcyfhadhqzrjsreaboskksxeeyyqtemlfyfeelziekcrrq
 * Smoking Wheels....  was here 2017 mqztswimeocyqhfxkbrxfeelcbovwozrooxmglomaiqtmeep
 * Smoking Wheels....  was here 2017 cdjuwzxwbdnkyrxvgvkrbtjmskvvhzmwyeuswcmlhddfriem
 * Smoking Wheels....  was here 2017 dtbmzavosbmtvegzfnnkcwblxnvsprwnisjmedifckxrjgph
 * Smoking Wheels....  was here 2017 drikxtgfgqysrpzcbnoykmpfzyujmtdruwlwmuqydwgjnhrj
 * Smoking Wheels....  was here 2017 vhskqelrakagfcbgtmgjhwpyplaaxqnommbeingzgoxuibve
 * Smoking Wheels....  was here 2017 fgaonlbdqecoizrpnjszglwbpcgdbwlrzvlznbiapusoekwl
 * Smoking Wheels....  was here 2017 nogdcdxyzywbgwitxhdjeamdedjjhiruygedcldwmcvqtlqg
 * Smoking Wheels....  was here 2017 ghruewaufbfmjqrlrtcicnvbpfnskddzmmzrlvgtogsgaolv
 * Smoking Wheels....  was here 2017 exvhvsvmraiujjtqtijzhfmaoacjgpbktjxyaspzrjywdhsr
 * Smoking Wheels....  was here 2017 gcmsjwxfyqocgktqkzzqjogiyqttajxqgcgnswffarmdoneo
 * Smoking Wheels....  was here 2017 ttqkhvbiyyoydkcydxevcggsuikoehjlucngogkjxtlazjum
 * Smoking Wheels....  was here 2017 eaqynhjmuggalenjsmmlniuzorftklmviandvbvoyjgthftt
 * Smoking Wheels....  was here 2017 gizdahgpwbufxvbvdjtnaaniumnopfjabvfodvhebootspow
 * Smoking Wheels....  was here 2017 yjkbdzeutgpultvrpnxjctgcktbkzfooprycgfxviqgtqkxn
 * Smoking Wheels....  was here 2017 obaakxckjuhdgniiqcipohbyourzzgtfoxfoghzlcdnquttu
 * Smoking Wheels....  was here 2017 poaqrubctztaszhqzmlamqgtneoggmxzbhualfcdcwrqcajy
 * Smoking Wheels....  was here 2017 tgzszojujjfjohrprjdreznraqcktgfcgssujndhbwmgstdl
 * Smoking Wheels....  was here 2017 bwqhpnrquuaistrkwriyfvpbwgxxrdfdrhhmwxeofkucdvuc
 * Smoking Wheels....  was here 2017 shbtectyxfukizuqepjkjxrpeiyllanvbnzwyinvxasezjjx
 * Smoking Wheels....  was here 2017 hrnpkbujvznhxvsbgmtvsezcijiyszeelapbzcvgsosreszc
 * Smoking Wheels....  was here 2017 mlntljawyrhyblkqcchhoxfuzfmqlljlasekmpwdoalazmeg
 * Smoking Wheels....  was here 2017 hhwfngcmwznntdcragyelodzywbzvxodhuakhqtfnrtytnpb
 * Smoking Wheels....  was here 2017 ydphhevrlawnenfqlebzfvvjkqyqhhlbaqoxldvizdwkgyho
 * Smoking Wheels....  was here 2017 acyqmxiaubgptmniehdpxtsurbhonsbefyrafjsppddoibka
 * Smoking Wheels....  was here 2017 erlaekxmirusdbztefybwniklymzlnntcpjbgueletfwfoky
 * Smoking Wheels....  was here 2017 klxnrxedqpxcirtdsynsoqmpmigighjievwpheknxhzbigbc
 * Smoking Wheels....  was here 2017 ajhlnxzjpygdmxjbhpdcxuiaamkiiwhrfatkklqqdfrbjfhn
 * Smoking Wheels....  was here 2017 mqzlpckvjysqzqnfpoicxaeojzdxlkgteuuqxvnalkqbgvik
 * Smoking Wheels....  was here 2017 oqkgxlulgemlpxdqrpwswoqhdpwfmgmvhdzpjwxztwmoetqi
 * Smoking Wheels....  was here 2017 fakzsgshxkxufdmqunuiivnrfjfupzklcfqvpgweexfeotxa
 * Smoking Wheels....  was here 2017 stzzrzatfsrdzxzqjojnepxitqchhmujjkgdqzsobbxyczdn
 * Smoking Wheels....  was here 2017 nzktohvnhjrekbkmfdcbjvedbwrqfvopajqrugbebczzstob
 * Smoking Wheels....  was here 2017 kcffjglmmxbvdsqciwvbhtwfvxjchjzjibusqotlaccuptod
 * Smoking Wheels....  was here 2017 kufjmblsldgjcgzvxtnvmwxzwutbsulguqavzrwabiebftyo
 * Smoking Wheels....  was here 2017 rajolesqacxenfvemwmytxhbivugxvsyfnvwwntupjiteypi
 * Smoking Wheels....  was here 2017 vwzkbihwibwytnyvusfgdwkipnqporsnmkawqiaweyyampur
 * Smoking Wheels....  was here 2017 mvpqjnoiupiroggwwxnuyxvxgrsiqrteydpeuqlqsetjhjzd
 * Smoking Wheels....  was here 2017 soaksacdynsovtzowjlxtokgfipwhkelayvjfdftihplabwm
 * Smoking Wheels....  was here 2017 uxfapftstvratqqjjggekofxougyyttdnfghwuockxqgjwkr
 * Smoking Wheels....  was here 2017 ddlbxxpqgvbtttwbcaklwxqvrqumhumfjprzeweunshyhbvb
 * Smoking Wheels....  was here 2017 npihqbzuwbbsogsraiusotedepqshwnywcbtpvuhpwfzyhqb
 * Smoking Wheels....  was here 2017 zzowdxmjfibdbkhmlcijyqufzsmacqjwnutfzkpdsogbtklm
 * Smoking Wheels....  was here 2017 sffcxxysdqsllxezumjywhmrdidedxtradgekowggkqeknij
 * Smoking Wheels....  was here 2017 flomvvlnujyhenzxwwlikrplbzwccvomkuitdoguwetmwykx
 * Smoking Wheels....  was here 2017 hcdyxpjpnzxsxlthqzhnvatpjkzyzscmxraetxndjxfkhifr
 * Smoking Wheels....  was here 2017 wwrmmmgczhzwpzqkisyxtvupxsdgwfueaypccguxywxsdnlj
 * Smoking Wheels....  was here 2017 fqfmczzmzivektetmgraxuubvehqgdjjnboieplzyrbhbqbb
 * Smoking Wheels....  was here 2017 vpbmotqhsljjtpzcvzarkybwmhpcuptbjqtxhfanyabkzzga
 * Smoking Wheels....  was here 2017 mdthywnlmdskjqdmjpuzomgdnxkvlzfmuqdfbojywbmldfor
 * Smoking Wheels....  was here 2017 dyaanngdzehleftcizzhxwegubjhjwfeifbtgjpuuzicyepw
 * Smoking Wheels....  was here 2017 byxzxdrraqtziyjmfjwchwxwkaldackxstzkyqabdkrjbykp
 * Smoking Wheels....  was here 2017 shstwnwssvzrgrrltcyhsmuwtjtibvuryzsgkofunbylkxdc
 * Smoking Wheels....  was here 2017 xlydlqeemgenrnpyzxbxmwlklvrcljqsgtgogqcltbvtfriw
 * Smoking Wheels....  was here 2017 ozkfasedytrrnvkgdqfggorvinxwjjipdhxygprpaqeaxcqt
 * Smoking Wheels....  was here 2017 zxbicfsbyhfpyfoxsorzshpuprijfqpbjzfgmkifrjeddgbr
 * Smoking Wheels....  was here 2017 qigbmwxnpgpzkntqkzzvzznfoxbnshlcxmxmfiqiiagjwnvx
 * Smoking Wheels....  was here 2017 hsmegrblidbvpwylhqwyjycevxomtrbyatbabulkwqzdhmia
 * Smoking Wheels....  was here 2017 xsnvsvuyrsyglpjqolkplpbcivmuolxffyxlvpvbjoheuajs
 * Smoking Wheels....  was here 2017 tgkhkwxlpbyucimssoxjzspqdxrcokroglannrdehhkjcgwa
 * Smoking Wheels....  was here 2017 imldemnndmybaxzknjudagaqqrijlrkbbydkmgzxdqqydnaf
 * Smoking Wheels....  was here 2017 jucfbrybsmcbwlwuypyxylxgmyvtcqgyxkhihwdpwqrjbkiu
 * Smoking Wheels....  was here 2017 xxepjrvhxwvzqhiahdiagucwmtvutwssixuyseuxpokiitmo
 * Smoking Wheels....  was here 2017 csspqyymqrthlavszdgcuzrdukgcvflebydbveftrzatqsml
 * Smoking Wheels....  was here 2017 okatsfljafuqtodpvbfxpazxukgravmicddsydzfsrwwxqmu
 * Smoking Wheels....  was here 2017 yjnzplpujbcagzdqunanzdricpfrgazkqktgqnzsprqdidaa
 * Smoking Wheels....  was here 2017 hhcgrxbwjybpwpcedlrhmvmvpatprkmygyigrbixligghatz
 * Smoking Wheels....  was here 2017 uctzmcqawxjwtclqibmvyuozjyvcuvprpejodsgqpducokrr
 * Smoking Wheels....  was here 2017 axsruskwzhwmkgywcsywkbgtuxpdfkkqttqeislbtwsyzsai
 * Smoking Wheels....  was here 2017 sfofrsticptkmfmvncwoeucemskyxnacyoenvososqrgvlel
 * Smoking Wheels....  was here 2017 uqbpmjgmvrkwwijuuegevmztjkzybtzoqvgclzduqqoqloyv
 * Smoking Wheels....  was here 2017 pcffsdrtbmngvfagkajieyaangewdyyupyktfzcqwnndocgl
 * Smoking Wheels....  was here 2017 otiqftfuwkyissdacduvgbmxhwdptgxuvokplscebzyxckhp
 * Smoking Wheels....  was here 2017 lbxqafelqxvzhysbxegtjczojzgjwybupqhwstbwadnkhdpu
 * Smoking Wheels....  was here 2017 grtjltcwbvqmlgyqbaukbojjoqgqssyjihifutbiygcimcut
 * Smoking Wheels....  was here 2017 fmwbbuwlxeyfjfhhavrkfdtyadycqjegvzblusklewxqklxn
 * Smoking Wheels....  was here 2017 vrojrdpvihsxmsmtoclnvvledboskatlbifqzxsiiugmandj
 * Smoking Wheels....  was here 2017 wribjsoxtrcnmwnbrkwwfvbfmdlrxaxfiiwcyuukhbxkmxyu
 * Smoking Wheels....  was here 2017 iezgjukttdlfhanmqtztysklymhkhzccbbhkmbugdyqaelbo
 * Smoking Wheels....  was here 2017 kangivyweslmcubmxfctvcpmrizqbubvaazjqszvhzshwhkq
 * Smoking Wheels....  was here 2017 qlfqzogufszajztxfhrrxbygagrhxnslfvucsazgjallmugj
 * Smoking Wheels....  was here 2017 uvpflzskdrgttuqrqqnqnubwpatprnhdwkqxilqwfboydmaf
 * Smoking Wheels....  was here 2017 uvlczhxyrjqwemxbicrxftushrxzqjgnnxxifrbiyjxliily
 * Smoking Wheels....  was here 2017 ylvofzqsqwtvwsaqvykctrfleoadeaihxuagmsoozorxsimp
 * Smoking Wheels....  was here 2017 stzewvajelnjehsdwnfbgorysdfbzmmlzswskvsrwkgofyjj
 * Smoking Wheels....  was here 2017 xflvbsjuprckwkxnlnyuaqtilhywadyiapjbomjaoxhuarov
 * Smoking Wheels....  was here 2017 lmzobzidphxdwivdvworpkizhzvclpdjopwvujqidjrjpmts
 * Smoking Wheels....  was here 2017 omprmaruajoziszlmsjhtnkoiotkrtuigdxwcmwjyjpfpjyb
 * Smoking Wheels....  was here 2017 vkqubqojzgasrjaffnwkqbkyynytlqwhewfgubpjqrknzthc
 * Smoking Wheels....  was here 2017 zpprxshtwjjgpmzmywwdmfxhussiqrqmnsuimqsrcjvtxfij
 * Smoking Wheels....  was here 2017 yvgliplchqbtcialytkuwksysduomkmjvvapxviykrrovqtp
 * Smoking Wheels....  was here 2017 bypkwrwuczssgoqrsiszpmyovcaejtdtvsiyfsrazeeyjcmw
 * Smoking Wheels....  was here 2017 scyeisrmlugvoznyzaimthxaneodzuqrmxolqnlckrrdozti
 * Smoking Wheels....  was here 2017 tuvmuseaspvbsurfulbkpefnjbwqiwcjclsktqlnoewmnwbp
 * Smoking Wheels....  was here 2017 dpannxzpldvnpggtjoyatotiixncmpaidlakjxuyoartrpcj
 * Smoking Wheels....  was here 2017 cnondsynpmxulztcenezzfnflymfyueiihcgoftgvsexthwr
 * Smoking Wheels....  was here 2017 drrckxcnhxzlqwyaatjajbxyctwzkqljssrbqwzpxbvcrinu
 * Smoking Wheels....  was here 2017 amxbkmvkvaenxarmvyhhfjmtyccotlctnoucehiiscgupinf
 * Smoking Wheels....  was here 2017 spcmlqtiwoyeduguxzxcbpdzwavlfvoyfbsaxgvcjdjszbqt
 * Smoking Wheels....  was here 2017 mzesbwqshowxotdlsaozsmxgxwygfqpspqyoysvvfsiumsvi
 * Smoking Wheels....  was here 2017 vunhcwpefiyipuzfzntugbdmncpakzccpxivqxzpxpofbqhg
 * Smoking Wheels....  was here 2017 mkoboszpalflyauctdgqzlluhofxtfjjnvvelibvhwrlxjlb
 * Smoking Wheels....  was here 2017 lndcunkchqemmtuigudtmgqochkilxvzvotdgreenuoekvcm
 * Smoking Wheels....  was here 2017 ychsjwrdxzkvlqlmzqpuncwlaodbwzethmqocyrlxyljicdn
 * Smoking Wheels....  was here 2017 nfgnblxgauwfgmlgrbfodajhmxnzunjqwignhjdwdcqfnovl
 * Smoking Wheels....  was here 2017 xjohyekjzoroplusiutcsgviceyibvrywzpijlkubgwdeupu
 * Smoking Wheels....  was here 2017 bezdikurldgdjwqcftguugbvsjbowpnfspyoexpwtuaxuqfi
 * Smoking Wheels....  was here 2017 gppjunwmfngiuimxuaadctdnmuvjspqdfqxatrzyrefjzfoa
 * Smoking Wheels....  was here 2017 atqochullaovisbyvdmautjftyiqgazthsewkbfejfwvsxxd
 * Smoking Wheels....  was here 2017 acpnjrvmneiqpdieirnmdmkdesarjduhhuuirmdztaqrfgsf
 * Smoking Wheels....  was here 2017 igiivypsbvyxoxmwmodxskbpobnwhpmiqzbalruyxulpvesa
 * Smoking Wheels....  was here 2017 efvicnyoyxddkqaowaouhglgchtxmhupbtmtrrozfdkphuvo
 * Smoking Wheels....  was here 2017 ackczezogvsznfpzeljzzzwzczvtogsdquwpsqagiuyvmjhb
 * Smoking Wheels....  was here 2017 qinlnxzsjbwkrtgellioaxyyfxfqmwkdoyfxdczccwstrpob
 * Smoking Wheels....  was here 2017 aozlaxpbykaptodjwblwakmnicnzlskehlugtupeqppcghji
 * Smoking Wheels....  was here 2017 ksukbrqbvxuayhtczialuhpjowqlxsizrrdkpqdkjottxorx
 * Smoking Wheels....  was here 2017 hahylxfiexcjrtudntodkmqigttbmxgophbnzygwvnpyotrz
 * Smoking Wheels....  was here 2017 luzwfqqthxcpqcglmzwacfdoangzdsifkgowmdtyxoueknwc
 * Smoking Wheels....  was here 2017 vupfrbnlvrextqhjcxykmaaluguqcraknsxawysiuygbwrya
 * Smoking Wheels....  was here 2017 swfjkrsurhasfaliwscxjphqqghusrbyscqvgjmwufbpqhwu
 * Smoking Wheels....  was here 2017 pgcvfehmyamtmbjdovvhvyjzxzwhtvkvzaoixqrsnerzrvwq
 * Smoking Wheels....  was here 2017 fitmdpojzltzexbudyyqdguriixlcmghomqxlgcgxwsqcukb
 * Smoking Wheels....  was here 2017 otakndeoljfohwtpwxkivbkbqhdqyfcwzoebpxwcapchkbev
 * Smoking Wheels....  was here 2017 xlvwwhxmftnzzpwzgyowuaiubdkpsxrhztsslphegwawgtez
 * Smoking Wheels....  was here 2017 roomauxtjypxsxdtblydaewtxmwgdsxqnsavioapfnvpogot
 * Smoking Wheels....  was here 2017 spqcbomhgnpicxnyfcgevsqbvayubwzcwhduugvtuoexndxr
 * Smoking Wheels....  was here 2017 ydythxffofwjdzguaupiveldsxgstclfmtieplvhdhznpgun
 * Smoking Wheels....  was here 2017 qcktfhzwdbcozttvysfetfkpqitrqfytelduxbkbngkjlshg
 * Smoking Wheels....  was here 2017 hsjsskvydkfocautthpmsxwizxoqjhmsybhsxkbgrgvqzwod
 * Smoking Wheels....  was here 2017 qjjluhdivuiicxhqlepkzjkmjkbuwsgjynwhgwsfkixukict
 * Smoking Wheels....  was here 2017 sscztdmdyzwbauntgifeeevlrwypibsguadbsgkpvtoneypu
 * Smoking Wheels....  was here 2017 srrsfkrthamfygwoqvsmbzhubpctfgqbdxpwinmhjcyuzvah
 * Smoking Wheels....  was here 2017 eljfywvuaebmjecwleqbrwcnvcreeixwaxbulxolpdlusjpn
 * Smoking Wheels....  was here 2017 vkqfznhfmbtvzperozszjywrqfbderuxqxodqwlkkysyocuz
 * Smoking Wheels....  was here 2017 qgixrnrbhkzkrzhfhfbqrujrjyyajxsspcimqegvyurazyhl
 * Smoking Wheels....  was here 2017 xxkooktuihjsqvyadawokctecqeofvlanwxrothpnelxqycx
 * Smoking Wheels....  was here 2017 bmfsmxqatzwkicvvvuspqvjaguysjpyvmxctswfwuzlvlnkq
 * Smoking Wheels....  was here 2017 ymgglzsqxbpmluxsigjurftjkerquojlreybqzuaqeifqfrd
 * Smoking Wheels....  was here 2017 lmhguwoujgycwikwyhvlauuqlxzuqhfirtredwesdcztqyre
 * Smoking Wheels....  was here 2017 xmjzcayvcrpsvhtwdakfpfnknftxjrfhdcvyhlqtsgplduhu
 * Smoking Wheels....  was here 2017 tptacfakdplbsnskryqvjnjpzrexqvhicxejjavjzmnmactf
 * Smoking Wheels....  was here 2017 thygyldkwnpbgefonsglryvikbqzkbssubuwazowtulgmloz
 * Smoking Wheels....  was here 2017 yeuswwwazhnyjonoxfijbxvatluqwaxxtswyydxyflhnztkv
 * Smoking Wheels....  was here 2017 mfgtmaaogywcfhaxkqcdiejhbcomlopssiakgkfmsbdffbht
 * Smoking Wheels....  was here 2017 yoqwopsrwsmgggmjsjdpptwatobouutdqozkgbcpxkmncujb
 * Smoking Wheels....  was here 2017 bqmzeqihegojenwzvceucvwikqszwapltivgnpkrpmxxuneg
 * Smoking Wheels....  was here 2017 ubndqijnugmqxmkzzugclwfqyjehvwodqutlvsfjxqiatbib
 * Smoking Wheels....  was here 2017 kvvpmdstpuxnprnwsnrckraplaicegkzziixgjvnhjxxrpxn
 */
/**
*  ISO8601
*  Copyright 2011 by Michael Peter Christen
*  First released 2.1.2011 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
public class ISO8601Formatter extends AbstractFormatter implements DateFormatter {
/** pattern for a W3C datetime variant of a non-localized ISO8601 date */
private static final String PATTERN_ISO8601 = "yyyy-MM-dd'T'HH:mm:ss'Z'";
/** Date formatter/non-sloppy parser for W3C datetime (ISO8601) in GMT/UTC */
private static final SimpleDateFormat FORMAT_ISO8601 = new SimpleDateFormat(PATTERN_ISO8601, Locale.US);
static {
FORMAT_ISO8601.setTimeZone(AbstractFormatter.UTCtimeZone);
}
public static final ISO8601Formatter FORMATTER = new ISO8601Formatter();
public ISO8601Formatter() {
last_time = 0;
last_format = "";
}
/**
* Parse dates as defined in <a href="http://www.w3.org/TR/NOTE-datetime">http://www.w3.org/TR/NOTE-datetime</a>.
* This format (also specified in ISO8601) allows different "precisions".
* The following lower precision versions for the complete date 
* "2007-12-19T10:20:30.567+0300" are allowed:<br>
* "2007"<br>
* "2007-12"<br>
* "2007-12-19"<br>
* "2007-12-19T10:20+0300<br>
* "2007-12-19T10:20:30+0300<br>
* "2007-12-19T10:20:30.567+0300<br>
* Additionally a timezone offset of "+0000" can be substituted as "Z".<br>
* Parsing is done in a fuzzy way. If there is an illegal character somewhere in
* the String, the date parsed so far will be returned, e.g. the input
* "2007-12-19FOO" would return a date that represents "2007-12-19".
* 
* @param s
* @return
* @throws ParseException
*/
@Override
public Calendar parse(String s, final int timezoneOffset) throws ParseException {
s = s.trim();
while (!s.isEmpty() && s.endsWith("?")) s = s.substring(0, s.length() - 1);
        if (s.startsWith("{")) s = s.substring(1);
        if (s.endsWith("}")) s = s.substring(0, s.length() - 1);
        if (s.startsWith("[")) s = s.substring(1);
        if (s.endsWith("]")) s = s.substring(0, s.length() - 1);
while (!s.isEmpty() && (s.charAt(0) > '9' || s.charAt(0) < '0')) s = s.substring(1);
        if (s.endsWith("--")) s = s.substring(0, s.length() - 2) + "00";
int p = s.indexOf(';'); if (p >= 0) s = s.substring(0, p);
p = s.indexOf(','); if (p >= 0) s = s.substring(0, p);
while (!s.isEmpty() && s.endsWith("?")) s = s.substring(0, s.length() - 1);
final Calendar cal = Calendar.getInstance(AbstractFormatter.UTCtimeZone, Locale.US);
cal.clear();
final StringTokenizer t = new StringTokenizer(s, "-T:.Z+", true);
        if (s == null || t.countTokens() == 0)
throw new ParseException("parseISO8601: Cannot parse '" + s + "'", 0);
try {
cal.set(Calendar.YEAR, Integer.parseInt(t.nextToken()));
if (t.nextToken().equals("-")) {
cal.set(Calendar.MONTH, Integer.parseInt(t.nextToken()) - 1);
} else {
return cal;
}
if (t.nextToken().equals("-")) {
cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(t.nextToken()));
} else {
return cal;
}
if (t.nextToken().equals("T")) {
final int hour = Integer.parseInt(t.nextToken());
int min = 0;
int sec = 0;
int msec = 0;
if (t.nextToken().equals(":")) {
min = Integer.parseInt(t.nextToken());
String token = t.nextToken();
if (token.equals(":")) {
sec = Integer.parseInt(t.nextToken());
token = t.nextToken();
if (token.equals(".")) {
msec = Integer.parseInt(t.nextToken());
token = t.nextToken();
}
}
int offset;
if (token.equals("Z")) {
offset = 0;
} else {
int sign = 0;
if (token.equals("+")) {
sign = 1;
} else if (token.equals("-")) {
sign = -1;
} else {
return cal;
}
offset = sign * Integer.parseInt(t.nextToken()) * 10 * 3600;
}
cal.set(Calendar.ZONE_OFFSET, offset);
}
cal.set(Calendar.HOUR_OF_DAY, hour);
cal.set(Calendar.MINUTE, min);
cal.set(Calendar.SECOND, sec);
cal.set(Calendar.MILLISECOND, msec);
}
} catch (final NoSuchElementException e) {
} catch (final Exception e) {
}
        if (!cal.isSet(Calendar.YEAR))
throw new ParseException("parseISO8601: Cannot parse '" + s + "'", 0);
return cal;
}
/**
* Creates a String representation of a Date using the format defined
* in ISO8601/W3C datetime
* The result will be in UTC/GMT, e.g. "2007-12-19T10:20:30Z".
* 
* @param date The Date instance to transform.
* @return A fixed width (20 chars) ISO8601 date String.
*/
@Override
public final String format(final Date date) {
        if (date == null) return "";
        if (Math.abs(date.getTime() - last_time) < 1000) return last_format;
synchronized (FORMAT_ISO8601) {
last_format = FORMAT_ISO8601.format(date);
last_time = date.getTime();
}
return last_format;
}
@Override
public final String format() {
        long time = System.currentTimeMillis();
        if (Math.abs(time - last_time) < 1000) return last_format;
synchronized (FORMAT_ISO8601) {
last_format = FORMAT_ISO8601.format(new Date(time));
last_time = time;
}
return last_format;
}
}
