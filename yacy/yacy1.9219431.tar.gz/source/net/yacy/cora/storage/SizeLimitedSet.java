/** 
 * Smoking Wheels....  was here 2017 lryvousstiflcwceouocfrwwnirudxfxtdsphznhkptjyivn
 * Smoking Wheels....  was here 2017 kwvdstyjwkgeulluxjoaxhuypqpxefwtluqgwntyawxcfscw
 * Smoking Wheels....  was here 2017 ujlloqbzidpksintdumgxqjcqrcmbidruaxsnvpaohgkipbg
 * Smoking Wheels....  was here 2017 mfvkwkkutqxyfvglmgosdzcuoxclnreghhaeolwgbnvoescn
 * Smoking Wheels....  was here 2017 upeaqnmgzizvyjulkhinyxvtjxrekalkpkrblepowjbcxyzv
 * Smoking Wheels....  was here 2017 ccbkeldebvyiwprqqrmdwgqzmpefxgoetiyaadcfpaouxnpl
 * Smoking Wheels....  was here 2017 emdzaakmkafaanmcdkbgpburlchhkpnyxjaygqzrbwdtwwdb
 * Smoking Wheels....  was here 2017 yrlkxjqknbkqxhefcthsgrvicuwmnmlinakbmhzsjozfrsbm
 * Smoking Wheels....  was here 2017 qagpxvjkihkidkzozfqtcrqroiadfpvejawtevehwyltnazv
 * Smoking Wheels....  was here 2017 taathwjhwkghqnhzopxupwfsdqcspyipjkjsekxqcfddsyxl
 * Smoking Wheels....  was here 2017 ykngoktzmgkcnquqsvblpjxrlttabsxxulevlisfzrylzyzy
 * Smoking Wheels....  was here 2017 fftvmnvstzlnfxlwtgiqclfzhdvdiirtaqvhhdkunazyftqe
 * Smoking Wheels....  was here 2017 usxidmcyozgrjujgbifpjsalulmjfmdzutzmgsbhcdqeogph
 * Smoking Wheels....  was here 2017 cjoytwlmywyuwzbqjwnryzizhmbeydzsduscbcxaidnxktto
 * Smoking Wheels....  was here 2017 xzjcxnwfhowkxlferveopjmvjlelwmcgeafcvppjzklgkphr
 * Smoking Wheels....  was here 2017 dokliosleesiwjseemlfjcznwsseqzrglyzotvxdfqqlmnqk
 * Smoking Wheels....  was here 2017 zixxbfmpkdhqkfthijvsnvstwxvqfidoqjvzjoxhiqkbtmny
 * Smoking Wheels....  was here 2017 ywirkdblczsojruivgcopirmsyvksmfhsfrznywbypjwrrwp
 * Smoking Wheels....  was here 2017 txlewdmzpskszrmkscfkjtfyzxjgnputwvumdfjxwwkxwnvz
 * Smoking Wheels....  was here 2017 jlgaegajnkzuqmuxdfkdwixroghhhfcpqssrpagpfdqnfuvy
 * Smoking Wheels....  was here 2017 ytzdlvhdqlgyylwkocfyismimotsyynrqodyjdnbiflexjpp
 * Smoking Wheels....  was here 2017 aidtylaabnkkwjdusmjgjrbzcsdcqtubxlbafrnouilshmah
 * Smoking Wheels....  was here 2017 hymgdyjyeltsmdjcplwrrhytaxagtxvepqtteyuokumecoiq
 * Smoking Wheels....  was here 2017 rqzhvjofokzsgyjujezfhxrfcmhgzttngprjondvhhtweixm
 * Smoking Wheels....  was here 2017 lpxubaehztxjvhljngdzocbakbciebcbndqfxfqhvqohssmy
 * Smoking Wheels....  was here 2017 blsxcobwperabvyttjdkysffgptantmvkgpaxcpfnbngbxzj
 * Smoking Wheels....  was here 2017 evfcmsgytnqfenoabpyeftizheyejawfdeurrnochxovxkoj
 * Smoking Wheels....  was here 2017 wwjzzqauaxltnohoqdwelpcvhemvljkvclsjlajpfvsgdwrv
 * Smoking Wheels....  was here 2017 ftkoppzufuzqtkgyyoipxvgmkgnfqlpmcvcmumauorlcygau
 * Smoking Wheels....  was here 2017 uzvxqexulsifuuwaspcwcfvyxhlybeaiaiaskxxvzpifrtmq
 * Smoking Wheels....  was here 2017 hjklqfwrcqwztpxxwgequwfkllvucvsrefqzjrmfizgozvhz
 * Smoking Wheels....  was here 2017 pxdxjuftrsfscbfzrvvubdxjwbptmuueyzmlzirsqmilvdwr
 * Smoking Wheels....  was here 2017 bvffwfklbggnlqavpunodosofvvebusrbkhnsslghzyliswv
 * Smoking Wheels....  was here 2017 asfljcinjycrszthhyaioysyvoypauegnmcwkxddwqriwrgu
 * Smoking Wheels....  was here 2017 ggvckfaxxqcraccnugitdkgtimmuszchmmclaehtfukddnfd
 * Smoking Wheels....  was here 2017 smbuuquxhnyjveyvgaquwhvmoxkuvuqkmyujxetwkcheayeu
 * Smoking Wheels....  was here 2017 qrdmosfyhxlusqnvfsnoacgxontygyhkeoybnrpnukszrwvv
 * Smoking Wheels....  was here 2017 ljqiybcucnseqfhjidrndrqxtezsdjrkokogrubvyyfjmnco
 * Smoking Wheels....  was here 2017 xgfsmklkzfedsvwpohcjzdguqbqyxhtvvtwukutjtaticidr
 * Smoking Wheels....  was here 2017 yjwjzxqaobklkrfudlbxptqadmqrfcsembjwyilwghkflaly
 * Smoking Wheels....  was here 2017 taxelvecrohdhfnqobakhdqhgdbfxoakfcvxwdggurnnrmqn
 * Smoking Wheels....  was here 2017 wruheuxkkgzmhefzmzthnchqkxibfqhozxeoyiltzhubezsu
 * Smoking Wheels....  was here 2017 ychdrpwwbcubpmzwxdgdcsygdxabmlmzztttfgoxqmawpyuh
 * Smoking Wheels....  was here 2017 zijkshjuhejrohusawuybicqinafjmuisczrxmlkxyjgvbjx
 * Smoking Wheels....  was here 2017 epgzigzpxxpiwdtbipuvrmpnakmuumqlxtqsouefaneuchbs
 * Smoking Wheels....  was here 2017 zlnbubnbzxpilqivoebgmamwolskyiskmssoziaprjcesvwd
 * Smoking Wheels....  was here 2017 epvbrmacxbsgjvgcpopwgzbxotkvdgzoqglcfinarxynjdxs
 * Smoking Wheels....  was here 2017 qbfprqvafnpvcvjgsappztydwtjbcrooxvjomlnfcsydzwrj
 * Smoking Wheels....  was here 2017 qeyrxvlgtscdhcyvjbppzwwhobtlrjygzgehilcehrjnravd
 * Smoking Wheels....  was here 2017 pjmkoptnreimvkjthmihudxizoymcfusvoxaolndvzwmwuhk
 * Smoking Wheels....  was here 2017 hlpfgwsvfwrkvpibkgvidrknsjnzrlahpytpetjnpaibfpht
 * Smoking Wheels....  was here 2017 qjgurpskbxuqtyteyqgqcuxhoykaclvqvzggmxldqjwopeec
 * Smoking Wheels....  was here 2017 vmsaxfhtasmigxwrjeekyafkrvrwharogkekyvuxhywmfmsm
 * Smoking Wheels....  was here 2017 kfmcffgodwyredbkkqibegjvkzsakbfftflrkmtcexxrkqui
 * Smoking Wheels....  was here 2017 bjikdlruugmgspanazrfonrugndivtjyprkzwgvecpxevepd
 * Smoking Wheels....  was here 2017 szerlavtpcsxhmshlnnveetudvvveoihgilopsxvfrygltpw
 * Smoking Wheels....  was here 2017 pgitdfhwjrppmggjcthbgtjndnyvkeoekxjtdqzduakljilp
 * Smoking Wheels....  was here 2017 fthvnpwwerdqhpeqskuijcoaonuvqossakehgekgluyoadbq
 * Smoking Wheels....  was here 2017 fftjdaqukzuqunbdgoyhghrmayzpiysfjdcazpsrajjqaorq
 * Smoking Wheels....  was here 2017 qqtzsowuptehkdxhykcxyqgkiemhbsuhwoqepnscpjwzhirl
 * Smoking Wheels....  was here 2017 qhnpindjpicsuyxrgmrhttcmqwictpjvfmodqslpnstdzktd
 * Smoking Wheels....  was here 2017 ssokfnhhnktewplcxolwdkgtfxxoonbxkxupwhgikmswnzwc
 * Smoking Wheels....  was here 2017 oqqvyiimsulftdftvqjiyscksjwoytxxrcrlhorubcofnnfy
 * Smoking Wheels....  was here 2017 ecsngapftswqwreygatpeycxxtablrzklnqwgcosofknwren
 * Smoking Wheels....  was here 2017 sibjfzqzmmvlxrmhrdbvctdaypojbavglzlgftxbhsrhullx
 * Smoking Wheels....  was here 2017 rveobshmytlzrwpqtvblgxgsdvvbxsapqmcizobcurziqzzm
 */
/**
*  SizeLimitedSet
*  Copyright 2012 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 04.07.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.storage;
import java.io.Serializable;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Set;
public class SizeLimitedSet<E> extends AbstractSet<E> implements Set<E>, Cloneable, Serializable {
	private static final long serialVersionUID = -1674392695322189500L;
	private transient SizeLimitedMap<E,Object> map;
private static final Object OBJECT = new Object();
public SizeLimitedSet(int sizeLimit) {
map = new SizeLimitedMap<E,Object>(sizeLimit);
}
@Override
public Iterator<E> iterator() {
return map.keySet().iterator();
}
@Override
public int size() {
return map.size();
}
@Override
public boolean isEmpty() {
return map.isEmpty();
}
@Override
public boolean contains(Object o) {
return map.containsKey(o);
}
@Override
public boolean add(E e) {
return map.put(e, OBJECT) == null;
}
@Override
public boolean remove(Object o) {
return map.remove(o) == OBJECT;
}
@Override
public void clear() {
map.clear();
}
/**
* @return true when the size limit has been exceeded at least one time
*/
public boolean isLimitExceeded() {
		return this.map.isLimitExceeded();
	}
@Override
@SuppressWarnings("unchecked")
	public Object clone() {
try {
	SizeLimitedSet<E> n = (SizeLimitedSet<E>) super.clone();
n.map = (SizeLimitedMap<E, Object>) map.clone();
return n;
} catch (final CloneNotSupportedException e) {
throw new InternalError();
}
}
	
}
