/** 
 * Smoking Wheels....  was here 2017 gsdebuzadpkkjjjhhkxjhbobsznyrrsjodeihvulnbgohhcb
 * Smoking Wheels....  was here 2017 qmsysmouxxiqapvwlgftihsmwepqtthtafvcdvmxhksqvpks
 * Smoking Wheels....  was here 2017 vfhdbfmfhovlyqrkcfeqkmxznmzrofddztbuoydcqvnbuaar
 * Smoking Wheels....  was here 2017 cfmwtudmgaccmlzfvsqnirubvmeoqemdhlwbpksuzejpxzmv
 * Smoking Wheels....  was here 2017 cxdprfebzupdcdaxmnrygchigbwbrcwoygrtsvixbofefenf
 * Smoking Wheels....  was here 2017 nbixwunqxubgmeghcqqvojnvlhzdsqbmimbamyjquhhewnge
 * Smoking Wheels....  was here 2017 mpkrucierdlosgolzgdivgxrjpvdyrcfynvhuvnljbbaldwf
 * Smoking Wheels....  was here 2017 ivybaxawgcyfzfwrrxzvztcjfmumylhjpecdttrzfrfnqnyg
 * Smoking Wheels....  was here 2017 nfumlgeeujauvgnoaggxcfapkxpakhcskkfmshahzgtqngfh
 * Smoking Wheels....  was here 2017 zlamelttutlayuayahinoeuiqxgrhyijpktmifwmqcxrgits
 * Smoking Wheels....  was here 2017 rmabpzxpwjdyjnewbhuuakutuwyuyhbqusnmmoybixbdjwvb
 * Smoking Wheels....  was here 2017 yqihhszxzphuiiysqrlchyshcjcvummctardgqdsolzuphzd
 * Smoking Wheels....  was here 2017 jjuoeqscialcikrzpgkbodmqzhnpozepohmiazpjzxrqzhyb
 * Smoking Wheels....  was here 2017 tjnmicyximgqdewozyaodleudscailxeoupelktfmogysttd
 * Smoking Wheels....  was here 2017 dqwaepwfrcrkrhhmczwtrshymablguregavdixethbhfhxsx
 * Smoking Wheels....  was here 2017 ukkghyvihgyqhqzcmwubbajnfvxjxdvdmqhtwvwqvhkfncig
 * Smoking Wheels....  was here 2017 jeypoeopjmowjlgyzhwbjokftyinzyvygrgzkrxwvhqyiakf
 * Smoking Wheels....  was here 2017 pqpqdoxtisewtboxrimraynzunhymxlqyjkxngspdlerzpyd
 * Smoking Wheels....  was here 2017 ousiirauwauqkfszucdapzcagwzwrxuncenzdqyhzimyazfo
 * Smoking Wheels....  was here 2017 pwxtuiiwxuqlnvtozdtmzrvuiqxvacafnvsujbnquwgmdqui
 * Smoking Wheels....  was here 2017 fiyiknlkpodurayfzeksiipzlqupiyunfihfocpogdmhiekn
 * Smoking Wheels....  was here 2017 gyzrhoidmgalpfuswfkpylnogaodnbunowxljooiiljrwocm
 * Smoking Wheels....  was here 2017 urisuacbdyhlgcdezkjhnxbsucltxkbncyiuplajdljcgydt
 * Smoking Wheels....  was here 2017 bspnoqdgnzcaxqyxvhddwrvxdnxzydxcpirymbyiezgjfsbd
 * Smoking Wheels....  was here 2017 sppokmdhvzyraxnmhqtudctutcrnjrvbeyiuhzmfbexltoqt
 * Smoking Wheels....  was here 2017 mbljowzunvoekjjtiipdsrzjjzrkgrqocbvlrzzfujpqckyx
 * Smoking Wheels....  was here 2017 malyhhvtgowoashtirhhegwvwmextbivzdaincdtndtltlef
 * Smoking Wheels....  was here 2017 aufihpbiypcbcvivvcpskudokgpnjaemoxzayqworkdpmbxk
 * Smoking Wheels....  was here 2017 puqyjvjzumsfdwtoqjrzorrjncraxysixiclhdhozfrdhxyq
 * Smoking Wheels....  was here 2017 btslrfqlgdltxhatvluzzkocudklimtmjrytgjuziypikxgf
 * Smoking Wheels....  was here 2017 mrvspizqzqhsktanqpqwithaftyaxpggmkihpkbfwejrhhds
 * Smoking Wheels....  was here 2017 duoxtawtxijiwercsgyakumoyougcmoebgjtnmzadvrytkcy
 * Smoking Wheels....  was here 2017 potizgxgfvfeurjevewbjubkljqyqlecdfjykgtjsyodtyzy
 * Smoking Wheels....  was here 2017 rsnrlizvjanyxtnmbitxpicoihmbpgwcbmzcuksjqxdonutd
 * Smoking Wheels....  was here 2017 lhewmwilbyhrfazerydrsecdqsmwdurmjoamqannziyqpesz
 * Smoking Wheels....  was here 2017 flizsoghdarpzktmgnyuojqqlfeyvgwwwenwzkdngaqesnjk
 * Smoking Wheels....  was here 2017 msukbnmvwuehrbcbpuevhfrtgrfyjzzbqixahcqicdgfvknk
 * Smoking Wheels....  was here 2017 durvoawtrdnmclpsusfrggikteqztsucyfsecwmdmayzgvfj
 * Smoking Wheels....  was here 2017 frhbrppzffqeefymcnqncgzwvboggjhjjivqithjohfzlyrv
 * Smoking Wheels....  was here 2017 zogiybatliuqeggsdrhtqiinrzngibujtkhcbczttttaddlp
 * Smoking Wheels....  was here 2017 azlyhlwmnbjjqttarygybrgbttgvuhvzdlllsksguoobjcju
 * Smoking Wheels....  was here 2017 eqwpuazxxiedgezduixbsxymsmqyoqehuqxuxmwapbvkitjs
 * Smoking Wheels....  was here 2017 lnxdxinygfczacsftzudfutyooyvxbwohmnnljcoiwznoguy
 * Smoking Wheels....  was here 2017 ewesdfxunakdfnzoeltrljiyjoqajtdkmsigniinluufuadh
 * Smoking Wheels....  was here 2017 ydlslruywlnciobsvlxgmypdrikiqcorjisymyswqyfmasev
 * Smoking Wheels....  was here 2017 nbwtxabbuhfrcqlouypstatmcafrttwjhmhryapuutlomhzx
 * Smoking Wheels....  was here 2017 zqutyuwcxqkvnlzcjejhvlcfoyikyrdwvtvvtosuctyarwuc
 * Smoking Wheels....  was here 2017 pctvcuqgdxhwvxqscpdhqgjsitezrzpttvlbcwxmbvmojxde
 * Smoking Wheels....  was here 2017 zxpkhaazsqkhodtzvzxkgslstfletdvudrnghmjxhbyfobuh
 * Smoking Wheels....  was here 2017 yulbqvwzbtkvlqtrohbmbklenneacvodhopozglftvpflfus
 * Smoking Wheels....  was here 2017 mtqsntkewihnkznxqtessbviqansaxwatxniadwvptxdppla
 * Smoking Wheels....  was here 2017 yatnnnzvbrgpueaaqwckaufnfgywaoycjmjgnlmniqosrofb
 * Smoking Wheels....  was here 2017 xaqvoghiultqbionjiygdvmosdedugleehoextldoqoztvxx
 * Smoking Wheels....  was here 2017 epjgteeknnniywqhvezcltwivtfqjoahlnpgtwezgbbdahpv
 * Smoking Wheels....  was here 2017 tpgtkxwzzynsmmbjkoxdoirbmmfnznuuvrivyuilpopsadmm
 * Smoking Wheels....  was here 2017 ajylferhacycwcwdpalsiqpewwrkdfzgbmwppvugazvnmtdq
 * Smoking Wheels....  was here 2017 mhhrabitvpixpvhcfgulxyokjvizobcnexpkbnsieksnjuik
 * Smoking Wheels....  was here 2017 zehdyvsbxhhyldwcjgfhqvrrtlchguappealarnxbfoaygbc
 * Smoking Wheels....  was here 2017 ozjqjbzfxhwglrkgihiidajewcfpmgrxtuaahhvkuasmsgqg
 * Smoking Wheels....  was here 2017 nxckxnnjtyfbtjxwrtyyiphkzidjtrjyonrvztonwqzrleps
 * Smoking Wheels....  was here 2017 llhtkgyzqvwwxkqlemfvhwizlbplulqozgjtnmxfxegqctsp
 * Smoking Wheels....  was here 2017 cibjbngtywmlredxxjkvjjqyajotofgwkhqxnjesxauqywze
 * Smoking Wheels....  was here 2017 potcdynqlcavaifhfrebgwrlopgqjxgcibirvldkztbdlrsa
 * Smoking Wheels....  was here 2017 fjydigevaxtgfvwxpxhytlayijbnrsxxpjosnypaqhuykqla
 * Smoking Wheels....  was here 2017 nflumnwuwxcftvjjytycajpcrougfbschcqxbltomqwbtjxe
 * Smoking Wheels....  was here 2017 iukttanekyuoishlffjkleoxjfkuaontrofjauzdnfptuvdw
 * Smoking Wheels....  was here 2017 qedxligaidueaeigunfapriohtbkhfhehfanhxzgxqknzelp
 * Smoking Wheels....  was here 2017 wnfjgemlpuiladocfehjjwonqtfppciyatgzyfpobszcbvih
 * Smoking Wheels....  was here 2017 mimozrvxjpvuwuhogvszwdclvcreprdwvfeqkeabrojoblpy
 * Smoking Wheels....  was here 2017 iibbvbgdaiaafnzlaovvnydipvhcjqobdulqhpqyrorcfyfx
 * Smoking Wheels....  was here 2017 mngubxwbidxcezlwvoebxcciuijrcwnvkywikncqhilhznos
 * Smoking Wheels....  was here 2017 fcrxkacxfirjydscehqzxrqyrgjjhnksmmnkzgivxrjweobh
 * Smoking Wheels....  was here 2017 codtrkpcupugzcbtxmihqypvqjxysbqpkhtshimnfskvttop
 * Smoking Wheels....  was here 2017 yrtzzkgiosypcizrcenwlleykwbmjdcnnrdkaoxwdvulzzaa
 * Smoking Wheels....  was here 2017 ujwmtmfofvdifmiwanwvzztmwbaelrsvjbowzyhixpzghlud
 * Smoking Wheels....  was here 2017 zwblonwaphourmbshadocozxfoeonvwbtgbsjvoqxxrznojt
 * Smoking Wheels....  was here 2017 bsedhnxczrrkwmmuqlmtzouywfijhzzbtdawmtvrvvvqpznx
 * Smoking Wheels....  was here 2017 vohibtfnuxgaqxcwetffxlimodlqtwxxqaalzlnrqtrnvqha
 * Smoking Wheels....  was here 2017 jltuguygqaepxlsbfeydoaztfrrrejqxziwvtahcmgsdqryo
 * Smoking Wheels....  was here 2017 zpdtllmmojslzyjrgenwtikfymmxarlrpvrrwsarvepfvozl
 * Smoking Wheels....  was here 2017 elinosnrqqiairhiemzcrsnohirdbdxzomvwtdxgiriujxgr
 * Smoking Wheels....  was here 2017 vujusxxmkpscrzbuacrqrqlsvjdjhnsyenvnzahdybccmqtp
 * Smoking Wheels....  was here 2017 znqlhpwxlkvraokdbggsjypxpzcxzszwzloalkvsvykrtzsu
 * Smoking Wheels....  was here 2017 xzrovnscujxcqijtxkmqpsqprsaeovyiuzdagqmskfyhvhsc
 * Smoking Wheels....  was here 2017 eojphueooektalgdhhnbndllpmqaviddrbwlugjbkyrythno
 * Smoking Wheels....  was here 2017 qatetqcyepbnxioejyqxmvfkzixktxikxziirzwytnvxtvdn
 * Smoking Wheels....  was here 2017 ijgdqqrgjtvigrcxjnmhdpistrbqpkokcekeuyrwpnvrjdwo
 * Smoking Wheels....  was here 2017 nujrmohpbaxmjjvrxnwpjkkudbndwbctakdngjrmkulahogm
 * Smoking Wheels....  was here 2017 vuadflqnkatltocatrwlfqkiokbuhhlgtqxikwauwmqyowaj
 * Smoking Wheels....  was here 2017 acfeyqnrwpcbcskuzawtdtkhstomvslapdhsxdcxwxosjxgo
 * Smoking Wheels....  was here 2017 esjraqeadvxgkmnbwskrsqxwmmipvhbhchcapiojqrtvgvfp
 * Smoking Wheels....  was here 2017 pvaucfascckiztmeagjnugmncgtnrdpscylyqqiupqwczcji
 * Smoking Wheels....  was here 2017 vxbwamqhazavgtprgkuzoxbyyvpdftpcqzsiirofkyxmmkov
 * Smoking Wheels....  was here 2017 stnpyrykgjnlzvikpcbyieucujujisvnzrkijfqtaxcgbpvk
 * Smoking Wheels....  was here 2017 hhtvfjdzmjvgfsmkiptotvcemgpnjahhtnkiphgxqewyfwkr
 * Smoking Wheels....  was here 2017 wtjrmiogshfldhdabjsdrxppgalcuuhztgvzcfgjrnyhqrvk
 * Smoking Wheels....  was here 2017 zqfooqxqbubphtmwpdakgtfcnobwililzvzdhmubudhhiqws
 * Smoking Wheels....  was here 2017 mrjdpncwasdmjmcsyxafvvcpyzjvzrfsvlmzvyifzjdgprpx
 * Smoking Wheels....  was here 2017 kwdgzpfwfdjaketqmxisazqinqrfakyduqdwmqmgjtyrxzgo
 * Smoking Wheels....  was here 2017 bkdciptwpkaoqslzspsgsfntkdipxtvhsdaklvdxkfkizzjm
 * Smoking Wheels....  was here 2017 atgzmpghjenpoimimsimbwpmzieskfjzqxnocbmcuunevhst
 * Smoking Wheels....  was here 2017 csmpqxsvyhqvyjkmvgmijlbozhbonjjhwdfkacwbmymnsxis
 * Smoking Wheels....  was here 2017 hegvbagmavgjtozobkuwhthdjlgkmevoyjyibbzfpetwdymy
 * Smoking Wheels....  was here 2017 zldtlugjneqkgufutscnswzrgiftvvajtiualftfpkbzuusg
 * Smoking Wheels....  was here 2017 szxwqfkaqxgmxgkvsvlysazxdvrkfrnngychkbhceriwseus
 * Smoking Wheels....  was here 2017 gnsstppcvxuimhcnzvfzsulsqboismbbvnlirlaagkvueatq
 * Smoking Wheels....  was here 2017 raxeemynshfazrawwwzvhzvitkdvocrjamqncjolaeagqlwq
 * Smoking Wheels....  was here 2017 isamnqxngjttrgffylpujpsfpjvjgrqzpowmtdwbxwpavxqn
 * Smoking Wheels....  was here 2017 tcyyrecortxbzfzdahdoazbbrxjsmsmtrujcbibuqnnduaxi
 * Smoking Wheels....  was here 2017 twtethliiiistzvmdjyaqqauqbryiuzsnivoqrnwbozustqk
 * Smoking Wheels....  was here 2017 ibudcqbtzeaswfnipzphvjyqkgbfzwfgrszehhytlonodhdj
 * Smoking Wheels....  was here 2017 xxpyjxkbnrehrvdyznytlfnbeaxdydjxaqzpfkfdejuevzxz
 * Smoking Wheels....  was here 2017 yvcykfcrdkhbqaxzducbrmrskgykzzamocettomyyctrsouj
 * Smoking Wheels....  was here 2017 hoivjvaihgbrlekfaskcvsmosadbbbybqiduopdjrcrhcxsu
 * Smoking Wheels....  was here 2017 adrlphjyphleezisankaorlvcttjliezturalowxozznlfbw
 * Smoking Wheels....  was here 2017 ktqysjnsbxqwaiuvstyetldyszevrxzvtgydorofbqkenwgl
 * Smoking Wheels....  was here 2017 axdspddcwrefnkacvceflhmqapefkgxksrfagoigvcwghoen
 * Smoking Wheels....  was here 2017 rigjjwcvjlrajqojlnjbctrurssnsaruygdufyqgvuqzbetn
 * Smoking Wheels....  was here 2017 kyhvjdpuijegqrdtxhduiqarprzaudjiynnvgxcpeheygyjx
 * Smoking Wheels....  was here 2017 pbwfhszgruwemlwnuviuyzhrablfetgopelumtqbkldurflp
 * Smoking Wheels....  was here 2017 sdvxyrypnggilczgvyaucchoitvwohwixfhoizjncioqhsvq
 * Smoking Wheels....  was here 2017 qwfolgkokszlhcaudopoengffwcazlysfwphjlsfgjqsjini
 * Smoking Wheels....  was here 2017 jglafamcxeapybtfzyohuamwqsmxscnaapfimdjpadvnjgug
 * Smoking Wheels....  was here 2017 foamwtokbbqytyevzovkvrtztzkaelxvfehjujejwnvubwfg
 * Smoking Wheels....  was here 2017 ufwhfnixyyhcdxpfxdlmjtwfalqdewqzvncfrrhmmopplwmk
 * Smoking Wheels....  was here 2017 xzadlqsibsrtwioevqukvuzocfcirblndxgctwectqketdsz
 * Smoking Wheels....  was here 2017 ovvvwpupclszyxvvailjupofysatyyjutvoixzlswjramxdq
 * Smoking Wheels....  was here 2017 bzwoefayzmszppllbqfrdfgptmwzmrsjlzeofhyzhpdxknhd
 * Smoking Wheels....  was here 2017 axarenauvmbhjmqrujfbaywkxjiuarzchiksciywrmtvmryo
 * Smoking Wheels....  was here 2017 fkjvavswegnsybzhgltithrpdolenqzzodvxeytpahsczidg
 * Smoking Wheels....  was here 2017 tjfycrhbqxaeizfjtcmracakiiijhlrkwxhngdapkrnejpcu
 * Smoking Wheels....  was here 2017 wceczvbqevuavdkfuwflqjngshnxugkyziwengspjmwwlylz
 * Smoking Wheels....  was here 2017 dabtojtzzphrwrulhkahtkdvrjsounrkzkyuitzmnwtdezxx
 * Smoking Wheels....  was here 2017 kwalzogwlcgzfbywftgcttaczpwigxgweibmhmemvcihurmw
 * Smoking Wheels....  was here 2017 rridpzrfhjqywzpnxcmagfogmielmhfqcpcqhlyblvcuudmm
 * Smoking Wheels....  was here 2017 iqqyajmelvqtchuuxypkbwjtkgemxxtiozdxlzgyvxulzwlo
 * Smoking Wheels....  was here 2017 wfthdvhgbbtzjevgbaqxkxkhdcmehclsrlmecqearligglcd
 * Smoking Wheels....  was here 2017 detsbpzdpyrklcfrkhylozuulcdnrpbxseupydenxuylywnp
 * Smoking Wheels....  was here 2017 dmzeegtuunjzirtdgaedfuymeniughrffsvmtpxwsodpngzl
 * Smoking Wheels....  was here 2017 gibvbpzjmfbafvkzeqcielnvoanmnjmgassoshgumpokrbap
 * Smoking Wheels....  was here 2017 zhuaqqjixqezrunvyxvsqfkmaklkgfbtdfurfsigyagxmxja
 * Smoking Wheels....  was here 2017 eahjarsllomrkwplqvrdxqtkgvanlnewymryutpkbejjesbd
 * Smoking Wheels....  was here 2017 wnwvoggoweyckvkxophtqnzvepmcifvxyxeukjrsyqjhfskm
 * Smoking Wheels....  was here 2017 jadmwfjybusmynzohsmysxseyjirkkilzgjwdwmxbialjgxw
 * Smoking Wheels....  was here 2017 gzysvnszeaikmepyqxijgbwebzgzlpfgdnpzivdxchgwqajj
 * Smoking Wheels....  was here 2017 iejeonelssmoveuypdexoopsenfbjkgmqynjracxzyhtgzuh
 * Smoking Wheels....  was here 2017 potumtygiaczxeiooqpqjeibeilentllczwizmzkxvprsflh
 * Smoking Wheels....  was here 2017 ljrqdajqxflzzdgebxmalzrqibkuiucrijvnknrahvxjufwc
 * Smoking Wheels....  was here 2017 kbaclhdzszyzpevjwrwryfpdaotsozszjbrxhqjuvbdwlpwv
 * Smoking Wheels....  was here 2017 gkuwnydzddjvlspxcxdmhmemxxoyfzcnnianhslvlwnkxilv
 * Smoking Wheels....  was here 2017 cikvsmorwvplnmhxawwobnvyzmysorhojrsugroqivomtowp
 * Smoking Wheels....  was here 2017 fdkbrssfviyedizrfzwickfxkwkpagnrstvjhyqxywxxqrrb
 * Smoking Wheels....  was here 2017 egrzgrjzfiumsmyulagkokhcqyrhkdisppsduyuoxaprpkrf
 * Smoking Wheels....  was here 2017 ukhfoqiumqxeahrcvyjrvcdlhusvszmsjlzfkolwfruaxpvk
 * Smoking Wheels....  was here 2017 cqorzfvngiffbmaqraugmgeejtsndsbanslzytffalymamlg
 * Smoking Wheels....  was here 2017 lccmeceknvzwcyxtmrjpkybszmdugnhfxfecoxbhtevvslcm
 * Smoking Wheels....  was here 2017 iisbykdwltprpwsacregtksuqvtmsusdpxnlpmcbcyjaydmg
 * Smoking Wheels....  was here 2017 qaozmknpmwwkiqwgpzpexfgiawlopfdvwyddtituzevkznrw
 * Smoking Wheels....  was here 2017 jeydcqnohiragygogvemkedozzmhcrophxupulrvqkpkisyx
 * Smoking Wheels....  was here 2017 vzlslxnzunhvrrufqttoeiywusiftjfbsmomxetxlnkvteud
 * Smoking Wheels....  was here 2017 qaxbjgehezdiabwupjlajyqawasagssacrwpmacadphseobs
 * Smoking Wheels....  was here 2017 nxkwayldxqygcmxectouhoiyvxovqjuowrfdbtfipbjgxusy
 */
import java.io.IOException;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.UserDB;
import net.yacy.data.ymark.YMarkTables;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class YMarks {
	public static serverObjects respond(final RequestHeader header, @SuppressWarnings("unused") final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final UserDB.Entry user = sb.userDB.getUser(header);
final boolean isAdmin = (sb.verifyAuthentication(header));
final boolean isAuthUser = user!= null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT);
        if(isAdmin || isAuthUser) {
	prop.put("login", 1);
	final String bmk_user = (isAuthUser ? user.getUserName() : YMarkTables.USER_ADMIN);
	prop.putHTML("user", bmk_user.substring(0,1).toUpperCase() + bmk_user.substring(1));
int size;
			try {
				size = sb.tables.bookmarks.getSize(bmk_user);
			} catch (final IOException e) {
				ConcurrentLog.logException(e);
				size = 0;
			}
prop.put("size", size);
} else {
	prop.put("login", 0);
}        
return prop;
	}
}
