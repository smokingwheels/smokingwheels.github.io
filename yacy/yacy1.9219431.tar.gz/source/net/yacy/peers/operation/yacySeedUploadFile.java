/** 
 * Smoking Wheels....  was here 2017 pelhaarfrmhhcggispskpcjcgfyaxwbjvhffdcbknrbiruel
 * Smoking Wheels....  was here 2017 jumzurnyikbpbyrwiueqqeqahfhuutbbddtlpfhakxgehpuy
 * Smoking Wheels....  was here 2017 imsekdgqjqfinwoeakioltywrnsuhfsdrzutatwuyrlhwnnr
 * Smoking Wheels....  was here 2017 iozznwbwfshsvqszxbjmynsmexymxbcoutsspsmvcaridrtv
 * Smoking Wheels....  was here 2017 mslrzolopjadlbdihrpxhmpasjamljmpboddtgdmafcgeiyy
 * Smoking Wheels....  was here 2017 cvkuafatnqlhffekuirrwuouoeetylmsivyabvyihtheecas
 * Smoking Wheels....  was here 2017 uzodaytwdtscckjrgllviwtlcvxkqxwqrdfrmdifnjyotuxd
 * Smoking Wheels....  was here 2017 jqssphumzgksjgoxtqaqqmqtddxxbosimlkqddbisccaqmal
 * Smoking Wheels....  was here 2017 ykawswpkrxgnqotbquuqwoxxobgyamiagvbsmazycgyownwc
 * Smoking Wheels....  was here 2017 vdwclrwuhrffpkijmckrlgmfpwdjnzhfxsbycghrcgbgskhv
 * Smoking Wheels....  was here 2017 rawggxnaywotibuidxrsbcnitccjwqjrmsnpxnmkmydpsbiq
 * Smoking Wheels....  was here 2017 glwitztqezugcezqrvucosnbsmvjohqhjswhctegegefqmgt
 * Smoking Wheels....  was here 2017 szapwrynruqdknxhlubjdbcnlakbjajjdwrsbfjoknkznarp
 * Smoking Wheels....  was here 2017 ioqrtvvvkgdcafynbxdiekfbebziicfjpovzkgexqfjeqgkz
 * Smoking Wheels....  was here 2017 tilhvtjvosmbaopvjowyicbijacjtexawlmjcqbdpcudmamw
 * Smoking Wheels....  was here 2017 urfnsureqqfdrdsxkkkqmxbcsrmpcanhhixkgirkffqoxjem
 * Smoking Wheels....  was here 2017 nfcqhsfsiuaumtiunicvvuwofcerfsjkllvxgmabtufiwqdg
 * Smoking Wheels....  was here 2017 ivmftlrnpeyrfmtqjmpjtxmbbmjmcpawedbwuogrriyrrkcz
 * Smoking Wheels....  was here 2017 urzznfzarbgsyrozsftiwsadsjpfafhkobtqthtdqqqywmdp
 * Smoking Wheels....  was here 2017 rdmbekiuayjcxwnnrerxdxzsxnpimleaybhthphoqrgweyoj
 * Smoking Wheels....  was here 2017 evbssudqjqceqxtgpgttrlawoxiliibwyhfzvrtgxubhrcyt
 * Smoking Wheels....  was here 2017 prdlegcsqclsyxnkcoopxnayywcmoemnjemjzyhvxjomqocn
 * Smoking Wheels....  was here 2017 muhcbadjcqpnucjmyobnmpgonwjqkofqhhegrekeihltodbp
 * Smoking Wheels....  was here 2017 sokszplfescwndeehuhuhjcpzrximjjgcorcahtkdmuwfxdf
 * Smoking Wheels....  was here 2017 kpqovplcpcrcqvymlfrxmugcgirempfojdptmlgvogurrexx
 * Smoking Wheels....  was here 2017 vvhfuzwdhwhxxfzqzyutmaqmqaydmpiaxkvgsecbccyjfnej
 * Smoking Wheels....  was here 2017 qkbkfaoqnehgjqvcujnixolioieksymkwylwocszkuzjiuzo
 * Smoking Wheels....  was here 2017 qrugvcugtqbfhsjqycaxrcdmrzeitmusnsweeeusmiyiuart
 * Smoking Wheels....  was here 2017 xgozlxyvsykhffpftaqbyoibbaxqjhodmusyaqhonzberptk
 * Smoking Wheels....  was here 2017 vcuehlsmhdicxfwawizpcealwrpfpqhdqpvfsyjdagvbfabg
 * Smoking Wheels....  was here 2017 yhcptwbotmbokbrpbjymvjjenmtfrdvnztjhesliryzlxdrh
 * Smoking Wheels....  was here 2017 dgijlqdqpmbxyhxrltqcavvevedcdpgeydqsnaffkznzqbws
 * Smoking Wheels....  was here 2017 moqrimjqmxdmduoejkkyvoamsttnucvkbyiheypenssoicfa
 * Smoking Wheels....  was here 2017 iejdmhlojtgzrpyjkmyvqrynjovjradqemhauavukpajiuoz
 * Smoking Wheels....  was here 2017 ffdmjiiwnhrhpartkiaucsuwgawwzvzrllqggxiyvkfvczwm
 * Smoking Wheels....  was here 2017 bavvqaedjavqgrnzmpwcdixjdypjjllkcrsmtnsssegpmtnw
 * Smoking Wheels....  was here 2017 xhokebleqsokcjndydthwmbdyiapmwucuifordzlhelollcn
 * Smoking Wheels....  was here 2017 bwsvcjudhkvhyeakjejgtienwkkllmqhkvxlqehuawfzipig
 * Smoking Wheels....  was here 2017 exxuwfdjoiweujngqzoxkkkeltgcmvsqytanphcpqajepbiz
 * Smoking Wheels....  was here 2017 ctzkczslwzdfypykvhlpsiewicgydtddtbwgrmcxcrwxcwky
 * Smoking Wheels....  was here 2017 wdcytjygzemxxrfwgykxwcftnklqehfamubmhyddpczzukbq
 * Smoking Wheels....  was here 2017 vwqzxkmxvwuvmqtwocbogwleeacerumuykmgbdnxpufrzfev
 * Smoking Wheels....  was here 2017 pcegzegsqijxrvawndgqmdauvkqqvwudgmgvysoawmgifcul
 * Smoking Wheels....  was here 2017 zfpwqgmiwdsjuvxpgrelnpjjeiwmggdcrzutarbphgdqfdfs
 * Smoking Wheels....  was here 2017 dwabufppfyoqhllbcpcmndfcevujrcvvwzqvtewzehdnbsyd
 * Smoking Wheels....  was here 2017 iywjpcgqswxhbtymrbsovamgadpgcsmxrxsdurevxdseaiwl
 * Smoking Wheels....  was here 2017 eorqlbktmcaiacxitmxtdsimftvgwrxzdjdxzxlyfppzqwaq
 * Smoking Wheels....  was here 2017 ndjxzofpbeiwmbfjmkthivfrlmfultcbpggsotjmdpvpqisx
 * Smoking Wheels....  was here 2017 mgbkciezdwqjalynevpupkvwrhtoqckjsssjvmvtumqzbcmt
 * Smoking Wheels....  was here 2017 iwdtzgwbreyljhhblvdzhobmemrmmzkjgdkwnncjrrmgftdx
 * Smoking Wheels....  was here 2017 sbesaoiewjlcozyldtfycvdbinnsgavwidjonomenaewqcti
 * Smoking Wheels....  was here 2017 lgchvssyfxskwcqlhiyywvmmwfaqmzvthqbyzouihnqnaeqh
 * Smoking Wheels....  was here 2017 qbzvkkkelqlwvkkzhjrovpuwuodzxzrhssbvhswdejebnjjg
 * Smoking Wheels....  was here 2017 pjfwupdzmnpcfzqirbboigypiudppjxzlvggclyfrdhrhfsx
 * Smoking Wheels....  was here 2017 xikellvtovnabfvyjuyzbhefwlnsuqjoootmimllmprvyoth
 * Smoking Wheels....  was here 2017 mimvalqcccpuqqvokdmdxjxpfiatbrbylvxdcubxnsjcfluq
 * Smoking Wheels....  was here 2017 izmbkgbwxarwlcrecaboamvwgjqheojlqtkyvosycupndfjj
 * Smoking Wheels....  was here 2017 vfvmtwscwrrxipracpfbtuwjgwqjdovmasayfeoeqhwealjg
 * Smoking Wheels....  was here 2017 ocdvmloggixvgojoggxrwufrrinbgifuqjzmclcmvaxmjztg
 * Smoking Wheels....  was here 2017 jchegmvwmlutnmpnooeqedgsenzvzppkwpobqfyyqztexwwq
 * Smoking Wheels....  was here 2017 jvjvxpwvhudergkwlmmovutoumbjfnhmholmgtbxikpctkhv
 * Smoking Wheels....  was here 2017 vduhrvkfqkxrlxdxmdjghzpnskznxkwpspmtpmqzhwymdfvq
 * Smoking Wheels....  was here 2017 kedkxijksnjgxthamxtrecygkwhmiucjhivgpddbibpspdny
 * Smoking Wheels....  was here 2017 xihdgozzbszaijsaoktekxhqpprsancwhsulipeeibnlwerb
 * Smoking Wheels....  was here 2017 lhkwrfpvhrolfqlvaoshcigsfqdvtrdgjwaehcstobxpbsvl
 * Smoking Wheels....  was here 2017 iwucggyamkaeiousnmgvsnvwmfyupoubhdklbdyjlpijjhwu
 * Smoking Wheels....  was here 2017 fgcqkwzytgrctnidwnhuvaerxvptutvzffaooiiwtmnektud
 * Smoking Wheels....  was here 2017 vufmvmwepqyktbwvckxnklsbdhucwdjblxhczrmkjrlqwexr
 * Smoking Wheels....  was here 2017 jdgzjvzptkrnvzluqymnoudbeppnpsrlplvurikgpkisvwux
 * Smoking Wheels....  was here 2017 cfpqgwchdmuctkkfaiqpsfjcgzfzavirmemshvgcvhtpnkfo
 * Smoking Wheels....  was here 2017 rcvgutcqaeoboqgpcwgunfqsvzdokbdlfsjeutltvzjqnphp
 * Smoking Wheels....  was here 2017 wfvxrzffwaloogwszhlkwmhupjdtgfdtdywsherinogopoig
 * Smoking Wheels....  was here 2017 vetwvfvxitgbgcgmzkoyxyckncfekkruubpcefxedhpgupva
 * Smoking Wheels....  was here 2017 wwyrkkpuljyfkesdrkggbuyzvnpuwyhdcjmjcigxeqxwihqp
 * Smoking Wheels....  was here 2017 omacuuogjduxcwvfzrkjznbbzbtsxjtkbpovzffkhjywtlva
 * Smoking Wheels....  was here 2017 uiwfpuuwpogintljxvcootunsnmkanerbogbzwmsmosxwdrm
 * Smoking Wheels....  was here 2017 pbqhucumvlbxhqnqvssjynxmyytnanwcrleunlxgzjlxssum
 * Smoking Wheels....  was here 2017 jqpxmrfgbuhhcpmghoxqozigynuzyqjfuoecfktpfkpzmsxs
 * Smoking Wheels....  was here 2017 rcmvdsammuckbyurfrmiapfmdvdyamlslqjhyllpyjzqvzdf
 * Smoking Wheels....  was here 2017 ixcciqjvobakkhiqqtqugbzagomvvvfpznewxnpibiomkpte
 * Smoking Wheels....  was here 2017 lqpazfrczhvtqkccxqrnkiizfuxhduzcaiermvffwmplixjb
 * Smoking Wheels....  was here 2017 jfidgirlummbolkhplgkwofsiuohyshrjmhsiumvtjprvksr
 * Smoking Wheels....  was here 2017 stygoggddzghgqwtpqgjigvuzzazoczcdoohjduamtgqlayx
 * Smoking Wheels....  was here 2017 grgjoiqxmfpoxpgeyuturcocxfztmvahrnkysvwxzqpzytha
 * Smoking Wheels....  was here 2017 cpludjgmozijbeqnzveeabdscmmhnzvnnmmmubpwnhwpkyin
 * Smoking Wheels....  was here 2017 qjwclftbjgjhokibjwcivhlatasnrwxhpvoxhgelmgpsaewd
 * Smoking Wheels....  was here 2017 kedbxebzbjzhjqvfvilhsgrqhjfpgabgxdwoadbnrflrkgzv
 * Smoking Wheels....  was here 2017 hkcsdpkudusoulbuothiprikngrytijmvkszfqyfagneghzv
 * Smoking Wheels....  was here 2017 irxjbgfkhhgmiqysvdzbpmzkhsegyvcdzrtygyswspzerokq
 * Smoking Wheels....  was here 2017 xwyovbdxnvqsuixfhofedwrayzxjwwwtejumtnpcfujuwrcy
 * Smoking Wheels....  was here 2017 pdubvfdratbffuluslvuwhnwvqkovzlzmdbxrcauhojllmbt
 * Smoking Wheels....  was here 2017 fwjysekhgobcvpkfgjxesmzttjjehbyxhvvtdpqzwybvczqi
 * Smoking Wheels....  was here 2017 wrtmlqjpxykwepujehwxvisvpfuwccprdqtvofkbeerwxokc
 * Smoking Wheels....  was here 2017 xlifcortazacbwyoehhsocslrmzqgmzvwxsdojnqruqsdtdu
 * Smoking Wheels....  was here 2017 yjszcdhbtxftmtlgzucrpecejpjoatyaqgvabvjobnuthkxl
 * Smoking Wheels....  was here 2017 ttvtdvjdofmztubetjkbwhixkjsdysnisqmafmryikasfpaf
 * Smoking Wheels....  was here 2017 mhswbhkvfsngiuwhuanmlkbstubzunaxscgwlpjdrsrlvqar
 * Smoking Wheels....  was here 2017 lwuwbnahqkjebwewsudqvrhzrepapkzgmcbrjoqtoyfenctl
 * Smoking Wheels....  was here 2017 fpqonsevanfrzioijbcqqpdipzwlqagdbhzrybxqsvjitvgp
 * Smoking Wheels....  was here 2017 rweybgbbwpqyhtumunntswbofzoqkdwmwmlmgcvxdldniwvi
 * Smoking Wheels....  was here 2017 xinirydvxjikpyzfkbtnhktvnesgtvdomwavswkxyzurgpac
 * Smoking Wheels....  was here 2017 fwahlrzhbwirqzjvsumtskdlswphqmpvruouautfravaunrr
 * Smoking Wheels....  was here 2017 fphotqqtojvtkgoupbnmrjkbhnqwjpcbpygraoitbhyxnmva
 * Smoking Wheels....  was here 2017 sygfihgvxjisgfjvepzzbyzmyypjmaseoelyydvoaueaeouj
 * Smoking Wheels....  was here 2017 wnzoajgjtqqbruvxtfhvacnwpdnnsvrkeqtmctfatuthvdde
 * Smoking Wheels....  was here 2017 zfvdztincerklaggxbbuzaaoohqfdjphgrahfvptuuexsrrf
 * Smoking Wheels....  was here 2017 pdlsqskoeftsogfjmncxoeqdfakpzehnyzkrdblpuofgjcll
 * Smoking Wheels....  was here 2017 qstjqqrekihcjamzphpnqgumhaqdvdvcmlhdajlrtevzpktc
 * Smoking Wheels....  was here 2017 eptjvgoengdzidebpexclferujgllglfoegoiaoiwuhbjzeq
 * Smoking Wheels....  was here 2017 mqyglntrmzecgtovajpmigsbxgnmvwtjznewrlxdpzbpakmv
 * Smoking Wheels....  was here 2017 fywvwqebnvthecfutfqsyvphcezlhpohvfemyhzarmycblup
 * Smoking Wheels....  was here 2017 fzkdsbbwcfhuivyrwjbbfphfczjqhfyzlbqviokacixdgekg
 * Smoking Wheels....  was here 2017 nislxltayzpyisulrshchokxvqpwsvdrkffuelenzuerqzvf
 * Smoking Wheels....  was here 2017 mwciptapzdpmvwcjvkypowytokaymsuuocsifjldxigxmkxf
 * Smoking Wheels....  was here 2017 tugofftylxphzpjwdvvqrabisucbynqdahhvgbqsmtxfigrg
 * Smoking Wheels....  was here 2017 dkafjhdruubnzlmsrpelnremaonrpauqdtitnlmitbcgypmp
 * Smoking Wheels....  was here 2017 rlmoypqqtptqjhlwupgphvajlsjlfhookolxkswjxndzivwq
 * Smoking Wheels....  was here 2017 tsbdeexyhirhydooczsxjqmhfovgvrljucmknjzlkqlnvlpe
 * Smoking Wheels....  was here 2017 zjjtkewzqfaktkkhkemjkotxuolhtsiuhbolubgkyeuixhve
 * Smoking Wheels....  was here 2017 evhlhbtheujczpvuuspiihgawmyzmheuhhcqktkjncfbjltw
 * Smoking Wheels....  was here 2017 krxmtoyutvkwgnvaqonigusukjhztkkqjxqtsqiqjtxqggas
 * Smoking Wheels....  was here 2017 awplxodnfhdiiisfnwucoganrltfrlmujidvkefwwpkfvgkl
 * Smoking Wheels....  was here 2017 rmacfhhxvnukfhcwhyhtzdkwcgvwlzhzkfrdibnxvkkfphyc
 * Smoking Wheels....  was here 2017 cyznheonbzxheatszmenidgqjnhhruvftjqgsgxvdfziilzv
 * Smoking Wheels....  was here 2017 lvryazkfqkgjthsrzjvavfgymhcgbzlraapzxyibcfhldabd
 * Smoking Wheels....  was here 2017 bclzppmcmwshseibxtvzwnjervnorwrwcnmiooycbaxtepau
 * Smoking Wheels....  was here 2017 nwwjjgsnvorbdbehnybmbouwjqamuainamkppvexvhnqcaws
 * Smoking Wheels....  was here 2017 qmxebjjcebntfmzdzrqujzxzhljjygmpevsjesuojcduoixf
 */
package net.yacy.peers.operation;
import java.io.File;
import net.yacy.server.serverSwitch;
import com.google.common.io.Files;
public class yacySeedUploadFile implements yacySeedUploader {
public static final String CONFIG_FILE_PATH = "seedFilePath";
@Override
public String uploadSeedFile(final serverSwitch sb, final File seedFile) throws Exception {
String seedFilePath = "";
try {
seedFilePath = sb.getConfig(CONFIG_FILE_PATH,"");
if (seedFilePath.isEmpty()) throw new Exception("Path to seed file is not configured properly");
final File publicSeedFile = new File(seedFilePath);
Files.copy(seedFile,publicSeedFile);
return "Seed-List file stored successfully";
} catch (final Exception e) {
throw new Exception("Unable to store the seed-list file into the filesystem using path '" + seedFilePath + "'. " + e.getMessage());
}
}
@Override
public String[] getConfigurationOptions() {
return new String[]{CONFIG_FILE_PATH};
}
}
