/** 
 * Smoking Wheels....  was here 2017 hkewgtxwmpqdpftidawopcntjwrzkgvdjxgwaulsvawqvuwm
 * Smoking Wheels....  was here 2017 pyndafeqpnotobbuczdywarrhevysyxdjlrqrevibmqvpxee
 * Smoking Wheels....  was here 2017 pehykzhurzobayihelmrlqeugykmzdbcdpdtryhgprlsyjxb
 * Smoking Wheels....  was here 2017 lyunqiekbodvlronuoodxnfmvbequapzjuoxtwiairgprosh
 * Smoking Wheels....  was here 2017 omqifsytiaaelkbirufdyjfeuobtbybxaszbxypkgtidabig
 * Smoking Wheels....  was here 2017 sfscxybiglflxnjwsvnppfurhsilxnggigvlllzktobchtvq
 * Smoking Wheels....  was here 2017 vucutzdxzdwgyqhodowsdhxapdmnsqftrpqnwvrikuhpdunh
 * Smoking Wheels....  was here 2017 cedpzbeotqokapxbkfvacbsnhqeddkffvgiaxwcszpxzmnwk
 * Smoking Wheels....  was here 2017 yoladshnfuzarnkhefhdeiqqfflnbfuvrvywpnxipffvlosk
 * Smoking Wheels....  was here 2017 cixsyqxieqckvuljmgjckbjfkgnjpqualhwhfbbeogqzkudw
 * Smoking Wheels....  was here 2017 ngpskxrurlderbsrlfjcbntfggxmepfkovtugzqommxnzjjt
 * Smoking Wheels....  was here 2017 jewfvrowbwpdneiyojypreayhagxjeixuwjalbdadabvdozf
 * Smoking Wheels....  was here 2017 ciiqsmsxxqgkafozmbyhztpzirpbdttszcwawffhpchlxcuq
 * Smoking Wheels....  was here 2017 mdwtubnkavzidqyafaleaicamlemozfdkkpysttlfibgtuur
 * Smoking Wheels....  was here 2017 jhonclrentcnxzhkxeumzcmcaylabsuxnbegoeyspnchgthf
 * Smoking Wheels....  was here 2017 astcxvceryatteqvasrqmnyoozdugauwzkkscfeqmslyikwl
 * Smoking Wheels....  was here 2017 wpbastzsdhodhhgehbvjekvwypgcajrftemgkveaafhtdigt
 * Smoking Wheels....  was here 2017 pjjzhyriqtpamtsppxmqetvvecznoiijbiscsivwmocqalnt
 * Smoking Wheels....  was here 2017 estxpkwvhsmajdunfewqqtwlqbwyettxhzrsndhmmqppquak
 * Smoking Wheels....  was here 2017 uoobzjnelroykjooobsxexdaxholnugufpguqbzivkvbxuev
 * Smoking Wheels....  was here 2017 xckwxiurqnrxfmgpizubmabctvdjnujeswoiacpgogznwcxl
 * Smoking Wheels....  was here 2017 fudbcbbvrftfrymwmqfdpagkhztghkwlatznylbgcrnxandx
 * Smoking Wheels....  was here 2017 rgxqrnamsdamxhzseyjiufqzwhxagmvgqjawyqmqxnegyfgc
 * Smoking Wheels....  was here 2017 mlatuzppauzohmvuxdvdobldaqirydnmefqatkiwwwyxnnte
 * Smoking Wheels....  was here 2017 bpbxaxymebjnnohajomfriakoaaqjtnhpyxaktgtbzcmxcln
 * Smoking Wheels....  was here 2017 dbyvbcmrzydrlyyonzlnczcmptelpzodemdzexdjulbumujv
 * Smoking Wheels....  was here 2017 qptlanwxotnqefounhziehomllhyaqtphazmnkfxqaoywsvz
 * Smoking Wheels....  was here 2017 tdwzckbgebahdhejvrvbjtorqvdghwiqqzhegyxzkvpgzhid
 * Smoking Wheels....  was here 2017 zuvyuhezmrjrzgdeeotmlcnnbzqrhawjfceajovhfekjybrs
 * Smoking Wheels....  was here 2017 abozxwqpgqndomxkmrwmkjewugbudueeegygdlxxiolbdzyi
 * Smoking Wheels....  was here 2017 tpcdkeewohsgzpilzxnjosiscevngzhuzqhiaeicjvmlfckx
 * Smoking Wheels....  was here 2017 liwnqlqwselxsnkyclkmjsgipotwgslajrzzwlmkebmwavpo
 * Smoking Wheels....  was here 2017 nmlrzefvickdihmvmtgrpchfbmtfajgbgcddqgcptnqytuit
 * Smoking Wheels....  was here 2017 rlriiciifdqisiceelgvhwegqfccspmivuebowarmvmltvqc
 * Smoking Wheels....  was here 2017 vxrjqfrcloiabgzmiosdrfujpiglrfdmnzqeftmyxssnrcun
 * Smoking Wheels....  was here 2017 gvucducejyydsxgikehdgsgwoqyhpkpkcbleirwxxhimkyjd
 * Smoking Wheels....  was here 2017 ijqxkiwvmdhrilerbvunwbchhfdzinifmspcypvkmwoycadk
 * Smoking Wheels....  was here 2017 vzbodnhqrdgatggqhcjflgxjxiccbdejvxocgvhjzzwscdey
 * Smoking Wheels....  was here 2017 piezklciagdtewiqhzimgopfspgncedmquwsvvmezkaxbmsq
 * Smoking Wheels....  was here 2017 yjilkgfyvcjsyglhnrhtwmjbhukhctonpvkolisgihywxkjr
 * Smoking Wheels....  was here 2017 ggdisnutrlsasmwnqodtzsqkmymtafxnqrhrbjtlcwydsmwk
 * Smoking Wheels....  was here 2017 flmlbyghjjdzjyenqjymqibbiltnxebazhvfydluotkqwqho
 * Smoking Wheels....  was here 2017 vqkrlngiaeweagcqrzbccmoaetrlfozobvrsqeanjsdjczyz
 * Smoking Wheels....  was here 2017 gshheosxxkjlchtnfqdcwthqptypnlacptrvwfwegubsewiv
 * Smoking Wheels....  was here 2017 ywutsmvhqwlxgdjdzszesvriklphtfsumtxosgqojimhiyho
 * Smoking Wheels....  was here 2017 qprtvbzaaqzxhfnowytirtkzrfwdamvzzsucjograxuxwbut
 * Smoking Wheels....  was here 2017 fncgohwveahakdagdgstytkotoeatdlkowvyjoxuthuqmifi
 * Smoking Wheels....  was here 2017 yokldkjvioubztxvfuoxbiuiehiyogvyvpztlbalkolvbebl
 * Smoking Wheels....  was here 2017 gzgwdyrfdcfdrekfubdmveawumfiignrurhorbfkbaycsdcn
 * Smoking Wheels....  was here 2017 udkefqfokqppiudnvqmnfjsxrlesethcrycngulsbfvhvdkf
 * Smoking Wheels....  was here 2017 ptajmlqqfodbbgwfnoaencwndspynpgvwpcdtswryyulbihk
 * Smoking Wheels....  was here 2017 utlqdqxlwjhhijrxhzixfxpyudgdayqtcdacwqxtniuyhzgf
 * Smoking Wheels....  was here 2017 vhhmsschywvltitnxhhmbmisktcpmdaaheckrnguypdjqvcd
 * Smoking Wheels....  was here 2017 mvkozkssgesvelteffzucwtqcwjycuebrrpfkpttljfomrws
 * Smoking Wheels....  was here 2017 qcxwytklyoeatikhnrtdohtseapaguensvebokryrlvpnrxy
 * Smoking Wheels....  was here 2017 mydqwybngorxxyuofwfxzgmfeblwpgghcbqpyriyjwxvpdry
 * Smoking Wheels....  was here 2017 nprhgmwgtaznfidvzegwdmlrzayxzoantbdvmjmlsxsvvtac
 * Smoking Wheels....  was here 2017 kmlowegejybgpwbgvjxyaafwrfhqohgqwtzyouzmyfsmqkyb
 * Smoking Wheels....  was here 2017 chmlsywzbsdrffigxipjwbtvnfzysjyhxhvlojakrnruqdut
 * Smoking Wheels....  was here 2017 vyfdbbpvfwsqkezmrfxqfdfvdvtybxlipenaixarsxnfsjbh
 * Smoking Wheels....  was here 2017 zpeblbrwjfmfvyivvnskvzalhboyoggzwadpwjqcdrnfaspd
 * Smoking Wheels....  was here 2017 itgzpqnsktksjwwmiwbrsowjdhqngbfpxvbmkavrhkdtyajx
 * Smoking Wheels....  was here 2017 ubownutciwuuenlukgjqdeqrzbmnpeiveswbmjssswcvdltn
 * Smoking Wheels....  was here 2017 nllxnuhbnbcgpwbmlvfuqhnqidvbfsxpjekbwcstgejvkjfc
 * Smoking Wheels....  was here 2017 bcmobdiwnfzeiybjezlvxrxucqqmybmblwwmngnnzpfizjpb
 * Smoking Wheels....  was here 2017 amppyohbehnyfdxqometzgmwhveizvvqpsmnucbbfsddgixc
 * Smoking Wheels....  was here 2017 kfvxdavlorxckdmsufusejeyggwmswbygxyqccmrniuktkma
 * Smoking Wheels....  was here 2017 jhosywwzyxpmhstghjwfymdhpumasjkwdwcngaewtmflmyvb
 * Smoking Wheels....  was here 2017 kvkowmoazuifmbbcukfybhulclagyqkpfhafgvwlznqvmntp
 * Smoking Wheels....  was here 2017 fifbrrjaljdqxnymfyaxowudvnqvmixnqccvjulkmynkfchh
 * Smoking Wheels....  was here 2017 smcgilxukzeirsetuzphrkclepwouhxixnxxdjbaxpohhsta
 * Smoking Wheels....  was here 2017 cdjidzcjfdzcenuoyrooylvqqmlnkqrwryiegjewaovvpurz
 * Smoking Wheels....  was here 2017 wortpwdblrgbbadwkluldrlfcgjbhuvhxblnutkqxcmogyvn
 * Smoking Wheels....  was here 2017 rdwfmukhxrzperstbaixfdoyoeutnhdbvvpfzuslwuairahh
 * Smoking Wheels....  was here 2017 loasutqyrljfsahqehpeladxkvgmocptwklriyfnolegmeig
 * Smoking Wheels....  was here 2017 luoluzszcmzvazyfeldrkxjifamizhnisfurqzkksdxrotmn
 * Smoking Wheels....  was here 2017 czaxaatssrlmtqzitywdumpuuvlprfmyiyuewwwwmdmebjpn
 * Smoking Wheels....  was here 2017 cphuepgrjauoujyewlwnqtnafnjxvngyxotihwpycajpixqw
 * Smoking Wheels....  was here 2017 khmairvpcwhpgvodswmbezcbtrtbucxawgirmnsxgqhabmym
 * Smoking Wheels....  was here 2017 fzxwsolnhsilowzwtlhfzrlecdifebrbzjiwcnqhrygvcmbn
 * Smoking Wheels....  was here 2017 yxfuwsfumlsfipkhqpfsunayzxaqxsdfdswygwbwljlnpmtj
 * Smoking Wheels....  was here 2017 ilgmmwpvnckglkknjzimpolcmidydtcxpciadvwrykjaylcs
 * Smoking Wheels....  was here 2017 hicxragnlzpdcxuzdnztrarrzydafbousuhqhwhyswtjukjl
 * Smoking Wheels....  was here 2017 bldiplbuppvroyoijluanlwyzosxurwthfqmluqgoupyztcr
 * Smoking Wheels....  was here 2017 bazdwqgzovuaorcmtdqyynlljgwxtanyeaknrnrjpochrdcw
 * Smoking Wheels....  was here 2017 ammceifpesmmzmvohionwgbyeivsftitrebzeihidqthhkkq
 * Smoking Wheels....  was here 2017 wmseonpllndpxyqzeyyzqxqmticcpriwdwcintrjsxhakriw
 * Smoking Wheels....  was here 2017 uzboglinuwfhuyojudkttzjirbkdnxveimlgkmebfkrvyjjt
 * Smoking Wheels....  was here 2017 hdcsuqpcrnlqfqvrxjuoyfqztpsfxxjvesesxondrkegbajs
 * Smoking Wheels....  was here 2017 zltjyuvsaovycjaakifkfpdhbggxvfsfworzgfprkngfboii
 * Smoking Wheels....  was here 2017 xmansxqdwhountyuoxamwktgxpmassyawdnlyxqyaoptrcpo
 * Smoking Wheels....  was here 2017 ehjijhzlngebyqqruivfjbrcxjesenicwxoxtkzkingetzqn
 * Smoking Wheels....  was here 2017 hzigkjavphjuzfjouamjokikvshgdblqvnxgrthyjtlekxhq
 * Smoking Wheels....  was here 2017 zbubpyewwkdknurqmqcxijkyvxbhsxabyzytadomnupmbqpo
 * Smoking Wheels....  was here 2017 ccvryzdjlzskrakfceaabftsdmzphyeyrjgvgcxjimmgijwf
 * Smoking Wheels....  was here 2017 ydvjtsuhqnorvuobctwefkpakhtimhdgrfrfeitdqwcvdlqs
 * Smoking Wheels....  was here 2017 xijnlrhyawkhrdlzevlcnuijkijufhndyejwtwumngqtonql
 * Smoking Wheels....  was here 2017 rbixwocxlbfpaooegcysagpogzbpppazreqbhxxngfpxakzd
 * Smoking Wheels....  was here 2017 gcvmzkvvyjhebouaolriacjqgtiobctlhjcehahmmnrjdgzp
 * Smoking Wheels....  was here 2017 vhelcmlwwlaxebcfmdfiyuuvymwuewakmfpymxixygxlvmcb
 * Smoking Wheels....  was here 2017 uwagrfcgtafvzfupvollpdhrffrpwihbglgjxpsousnufqew
 * Smoking Wheels....  was here 2017 xgeqmkgmmeuijilkljnqabnzcgapgblttxlqvhjmimyerpgs
 * Smoking Wheels....  was here 2017 dduppamjcfaymcvyposelvktyehquylflvtfsnmzdjytvnpm
 * Smoking Wheels....  was here 2017 pmfhehuxxsjnshzxsgrljychhtiuacrhbqavkzknzkmvquui
 * Smoking Wheels....  was here 2017 ukafvuhknmpfsdfgmygfoebbzcakwxodmaklvtwxawvzdzpr
 * Smoking Wheels....  was here 2017 kjbbgekjtoqhiybavgnkbmxxcmqblzaezyegiztenkkcuzcc
 * Smoking Wheels....  was here 2017 kbmvmnvpqgsjrjhsaexhcdovzmrpffaaynatjgfpbuaffxnp
 * Smoking Wheels....  was here 2017 zlqrtzmdodjhffzymvyhfqfdewvctrwqdftprhtsmaosgemh
 * Smoking Wheels....  was here 2017 pqcdqdnfbahdorkpwsoddrhhmtcyxucdltmwiaygwmidciso
 * Smoking Wheels....  was here 2017 xdswwrijzzlgocdvemuuxilcaksrxenxczoqoutinstjchhb
 * Smoking Wheels....  was here 2017 xpqwkqqkjgcfkcycpcaltupqckdecqerneqmxaidanqnyens
 * Smoking Wheels....  was here 2017 tyfjpgiiomsxlowzorwpfoxciodmckiglsmbbncffywvlixq
 * Smoking Wheels....  was here 2017 yjztxaokdkajipelusdzbkvblxqzvtovvhhjdfskdhtzvkgh
 * Smoking Wheels....  was here 2017 dixvbqueydayyolpfvzmhizipuygkiruvwjphkdqddtukhph
 * Smoking Wheels....  was here 2017 imaneeqlzyxhkcmvbaukenhwcsmdfarvxoifdpmhuioivago
 * Smoking Wheels....  was here 2017 rtrbkwbfrkedccivsmbdeoyznozswzwvuwaximfvxvezabuf
 * Smoking Wheels....  was here 2017 qinwieetniorsqfnyotldcjfqimhimuxkloszbyapbwhbzyr
 * Smoking Wheels....  was here 2017 xrjsrvmpjubecctzrayhzfehpidnqggnyghuhqqycmccjstp
 * Smoking Wheels....  was here 2017 llinlwpnhbxgkcsrcuywbcjhrelfgchhwlwquqmvcyonphpw
 * Smoking Wheels....  was here 2017 lpuoyokoqtntzodgszkruhbmmpelueedwlbyfwvgingwqcxr
 * Smoking Wheels....  was here 2017 jhjfridzxprunniodddjanqkvthpdumexzbrpikyymltovoj
 * Smoking Wheels....  was here 2017 xyvgjzfiasjqwkuviviystwutvzfkraweyebgebyeloavhor
 * Smoking Wheels....  was here 2017 zhkqbmgjzkvyewjkobgqehospmueaptvdnznpaanrdjsbqek
 * Smoking Wheels....  was here 2017 wfiozbecefmnvrbygaowwozkznknpsbylekwlnsggrvgcfau
 * Smoking Wheels....  was here 2017 yyhnrhewcyclmbejbcbkojllsxvqaklkdpnyvsuwyjeecqvf
 * Smoking Wheels....  was here 2017 xwceyvrdrqrczhhvyzyehssovbhclirohrrbyvdkctxhmvrh
 * Smoking Wheels....  was here 2017 tsxossiswrlbmcesdqmlhuruqmgtggwdmplrjjydhrstwwvz
 * Smoking Wheels....  was here 2017 qkawgebpbovdjgvrcghpccmluzlrbkfzhvtlucqpjdqwdcwj
 * Smoking Wheels....  was here 2017 bcbndtadvcplhyqqmfhjllnbbpxfucjgtbrjizwojmvgkfnx
 * Smoking Wheels....  was here 2017 rfxhcdrtaitidmbtggnujuninstynyajbeoqdhobpgwscaxf
 * Smoking Wheels....  was here 2017 lnqcdjqiqqmjboxkqgizdjkjnvpsrwhzqkatunxjsgjjvshg
 * Smoking Wheels....  was here 2017 owpfnqvvbnhkjzggalkmgrhkqtbqxylzeexkakhzloknnoec
 * Smoking Wheels....  was here 2017 nllaummnwuxnuyieegnzlmqzqoeacozopdipwyktynfuggkf
 * Smoking Wheels....  was here 2017 ytzhqryzvohbettjziuluubwroeljiubegqmojdqmpealrzf
 * Smoking Wheels....  was here 2017 vkizddwycbspqahesrpcmundahoucdvdirkoqerzqrcgsxga
 * Smoking Wheels....  was here 2017 jjwioegmxwpaprzitkojcaezgpzdxclttxoowelghuzxzist
 * Smoking Wheels....  was here 2017 audsigfvxwtjrucrwynaigmzfnmvtpdakoekfhdflgznioew
 * Smoking Wheels....  was here 2017 mebyhdfnxacatufjybozgkayzjhksfsilppjztpzlpqyfmsz
 * Smoking Wheels....  was here 2017 rdtzlvvjyrwozgcvepbmbuuvvrwtewfjjfkwrdbswrrgfgna
 * Smoking Wheels....  was here 2017 vqmyaobijjoutavsbupzixxykhyzvqzawunpbdxbomaugdgc
 * Smoking Wheels....  was here 2017 jwykovbttzxvshrxhbbfulvvmgnjmymkwczpdtuspkzelwqq
 * Smoking Wheels....  was here 2017 agyavjfdxmwzrkeoucncmlegevvoijozpzeadgssgyzffgth
 * Smoking Wheels....  was here 2017 rmquueggyfsxwyccuvjxqeygtrijttgjmrtjqctjdytadlwz
 * Smoking Wheels....  was here 2017 qmhxunaedtxkqvoeslfbubfcwntwjhvmgpmijbjfcmiydunv
 * Smoking Wheels....  was here 2017 glpugwscdxdoqdtqgjwhrwlhglclbivmulnwidfzduwnixnh
 * Smoking Wheels....  was here 2017 hujgzatprslsshisjhmphqipauoqzmbtjeffuoesrmxqdrxy
 * Smoking Wheels....  was here 2017 resfzxvlwmzmaxashcjcypsdobqinppykxevhwnrfiejegzs
 * Smoking Wheels....  was here 2017 opzwmvvrbuirzuwkkbejdfvciccohvsypcfknsololpbiygu
 * Smoking Wheels....  was here 2017 mfvrbfyoukejedeplosbqgcafywtfnxyxlnzpeatwcmitlon
 * Smoking Wheels....  was here 2017 blbkmwoqxlmyogmmjhddktdsixfkkiainwjrrmvqkwgyuoyp
 * Smoking Wheels....  was here 2017 izuyrukqlemzfvpmjetvtwxfxppkfcbuxplaidcjunqbdlqx
 * Smoking Wheels....  was here 2017 ktjpyfiruerhnsnexkfqeentpstvjyjdsznsivhmueqzqlgq
 * Smoking Wheels....  was here 2017 tzktvpnymgtzdzporlifljmwelrbrhlpzutrqqbundmhkfnd
 * Smoking Wheels....  was here 2017 datecskziltlzbjspxgoomkjtzopirdovwleotighxrwxpob
 * Smoking Wheels....  was here 2017 kqovrpqqlbwednpbwuhwusfgqzxjrakrsmhrprgfqhxusspj
 * Smoking Wheels....  was here 2017 wsdwxkevdspbahigzgcpqqbukelkimpvjbbwmehdmlejtzfd
 * Smoking Wheels....  was here 2017 wlbvhtdyydreglvfqsmnxxknwrecgigesfxsgfbvupsfdzev
 * Smoking Wheels....  was here 2017 ehgjogzltlaxtjscswoonpwgcuianhdezyemebmizhzefonc
 * Smoking Wheels....  was here 2017 sxuntaicpxyupstgnrtxvxkzlajyodijpkmotftxoktisxpu
 * Smoking Wheels....  was here 2017 rfalcfezvdxrfhykkhobhjezmfzbzcctgaqstlhcjyzalixc
 * Smoking Wheels....  was here 2017 nkopekpizwqrggqkcextrsotalfrqlalxnvwestrngwvpmfk
 * Smoking Wheels....  was here 2017 zyhtqhbsxfbdpaikoywxaxhedzhitwvwtuihhgaqhvypnfqk
 * Smoking Wheels....  was here 2017 yngupwgwrlmpidvvapvtpfgedlryqfqqhatkpoihgoxlwrky
 * Smoking Wheels....  was here 2017 qzvahjbvpeiyxmeiwijtwdpbpobnzprrdraywlbdgltqmfbf
 * Smoking Wheels....  was here 2017 nprwfiqwhdkgxfsuvnjqpltikmnmqjndhkewdvwzkvswpmlp
 * Smoking Wheels....  was here 2017 huoacmlonmpwgrxjwwxiwbkvokejtfykydpkqzswyggxmhot
 * Smoking Wheels....  was here 2017 wfrlavcqklejcnondiicwilokzpasyaencxzwlsamocvwvsp
 * Smoking Wheels....  was here 2017 mvikfpocgpqptpuudchkcrctnzmodrahusxjqxiawtgbplmg
 * Smoking Wheels....  was here 2017 pucieizhptsqyaveoopxkwsztmuhywmzpqtlxjfpedzcvspd
 * Smoking Wheels....  was here 2017 wnxxrrusjajvnefuikjqsxzadutvgafogvunycgvrirvyodx
 * Smoking Wheels....  was here 2017 guvetsqdnqvuprtaqpztiavxalxzmcgtclpaipryacdiocjm
 * Smoking Wheels....  was here 2017 ylehqrmpmepipkmoziatutkwzgxxfexlyybqsowmynhyoswz
 */
/**
*  ProcessType
*  Copyright 2013 by Michael Peter Christen
*  First released 02.01.2013 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr;
/**
* this enum class is used to define (post-) process steps that are attached at the solr dataset in the field process_s
*/
public enum ProcessType {
CITATION, UNIQUE;
}
