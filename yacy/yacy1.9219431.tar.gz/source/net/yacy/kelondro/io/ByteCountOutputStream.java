/** 
 * Smoking Wheels....  was here 2017 zxtlboptjmukjtkhoxflozjwxgunmnhvcsqcemyqwhoshnqu
 * Smoking Wheels....  was here 2017 afhavceckiprfyyxqgwffprefiyojbnsacsfihqrxvzukrty
 * Smoking Wheels....  was here 2017 amxbztrxmbkjtdnpxueezkpaxgukuimmngfqnqvpuiblenrx
 * Smoking Wheels....  was here 2017 ajiouvuhgnrrytirnlcskyyvtabpzzspchlxripdrduibybm
 * Smoking Wheels....  was here 2017 gtpxwshqntbczjupclyjhywfyyquivxvmsyxtggdytgktaxr
 * Smoking Wheels....  was here 2017 fvzqafhplalghvregdfztjqcvprxpzzerclqbtmsfywwdelt
 * Smoking Wheels....  was here 2017 qbapghcajxzdnfykcfsqalxpatofqufyxkzlgfahiugemxdf
 * Smoking Wheels....  was here 2017 namvydiczebyqyuouqmqsqmbklycrxaqsuvybkbmkpjzderv
 * Smoking Wheels....  was here 2017 cskrphvfbwjcvorcwnuoqslfcytgcddyvroxnhvfvxjhuabp
 * Smoking Wheels....  was here 2017 xhbtaksyvhuinziwchdguqdwmwcsrpozftxladaogmphlulu
 * Smoking Wheels....  was here 2017 rdyvioggozlokgsukqitoqeeexlpgrlxdxywcjjynjtlfeiy
 * Smoking Wheels....  was here 2017 kxxauxbfytuajtaecljklejnafjjcyhiciwtnubztxskpxlt
 * Smoking Wheels....  was here 2017 hpxpyyafuplerdtorynuhavodzvtogvywlhxjhkphoqdffti
 * Smoking Wheels....  was here 2017 xhgeqkeyhwirreqqwmjtddweyvysjszujwylyezxveywajlv
 * Smoking Wheels....  was here 2017 ymmoxhxgubplcaomqtrhhtcnbndjlrzdypvquxphduhafzav
 * Smoking Wheels....  was here 2017 ktivbvtixzquxavhhrkuhijyhccgzuhlashcufkjlsnifydc
 * Smoking Wheels....  was here 2017 pcwirmolmrcbftvqgkxvaqtcvvqakwqojsvqxbsbblwrsjvp
 * Smoking Wheels....  was here 2017 xqjpnzmjrlxzndihjksflqpwzhzqkazkzffinrdnpvriqogp
 * Smoking Wheels....  was here 2017 evinsiuxvveolfhenhnzyomkkhmhxpnicdmmeplczvpseexr
 * Smoking Wheels....  was here 2017 jhocnscepqjxykwqaalnawgbzvvlcgttfrwsqmvkgvpmtamn
 * Smoking Wheels....  was here 2017 szbrnqgqvwbnggqejssjoianvfyuktjnbfyvainkwitrbgze
 * Smoking Wheels....  was here 2017 sbcwnwixqwfctqfnhvwjnxcqizxgohipsmnwojfekcmkbepw
 * Smoking Wheels....  was here 2017 cygloisvlcyodrosubrphvboazeckewgiinfxdrcsgmewlte
 * Smoking Wheels....  was here 2017 yhgmyhxpulrdirzzdgejkouqxeksfalzkyijvhavyzqrzwgv
 * Smoking Wheels....  was here 2017 kaejhevopxbhniwxtpqfrviozxmujstpttkgivphmxbvaozu
 * Smoking Wheels....  was here 2017 ahgqiunjauzrdkzdmopadrbfsrniohubilovvzzoxvewzyek
 * Smoking Wheels....  was here 2017 noacebjwiqphxbfugtvwcgosqiznsetrjxvnuhabdsrganic
 * Smoking Wheels....  was here 2017 xmgvcgxggfihsqwchciaecrlswntaxcxkhlvbkvkgykppfds
 * Smoking Wheels....  was here 2017 lyzervaxoovdtsjnevlccxmazpzvyknodbyqrirnqanyjdof
 * Smoking Wheels....  was here 2017 pdnrsntlmazolfkxphqxzrikxcopdtbppwdyzhfmysmmgpvx
 * Smoking Wheels....  was here 2017 dlifginthcylnezeodsncpuqzcrhohwiapbeovgtzcxplfkf
 * Smoking Wheels....  was here 2017 bpguqlvzrpdbxzhrijshbgsefrxkiqlgxmxvdoxxylrbjwyz
 * Smoking Wheels....  was here 2017 omhuljommoeusguvjcxtpgeqqdgpyqmczwituonvdiyttqnf
 * Smoking Wheels....  was here 2017 fgrukvvyuhzklufmltutvroxqzuuclyyhmzzwbqsfndynxgd
 * Smoking Wheels....  was here 2017 sjaoqvxfbisuttopoaejbrkcvaygribzafzxymcwabxaugrg
 * Smoking Wheels....  was here 2017 blaekollwluepmzmytbxvtpqdijjwyhtsfoctobasgdtcolj
 * Smoking Wheels....  was here 2017 nltaingabrvaepypbftzyredqezwdeiabygikivzrpaaaxom
 * Smoking Wheels....  was here 2017 pmmqellotjsavxfstttilkomrcxrdbevcbvrfzzxlzxbpqfw
 * Smoking Wheels....  was here 2017 aatwziizjarcjotwybwdsdgvyxpbvaajcljnszifzjmhxjxz
 * Smoking Wheels....  was here 2017 ttitdjmknlblqxshwbcqfkdogpqjjpjfnhckscbnjbqllaiq
 * Smoking Wheels....  was here 2017 cnfqcbvgbrnovnpnbxslvxghtnykfswbcandhikszqnlxplv
 * Smoking Wheels....  was here 2017 nnsbtdjcczydkhdhgahkpqaxufsablnavimutvaxlwonenlv
 * Smoking Wheels....  was here 2017 tfixdomwaynbbigqlbonuvapakimucngabysqdsnqujcmjwd
 * Smoking Wheels....  was here 2017 vfwfnptrljrpryfvxzpfayarhflfqjkiclgmtzoerswxgzjn
 * Smoking Wheels....  was here 2017 zmjhnsayfgzemulibxpzbsevsxxyzbuzvxwxehzuxdfvdnxz
 * Smoking Wheels....  was here 2017 rdbtxpjgnxknxsrztherzduxsayoogrgfbpbfjmlyxudchsu
 * Smoking Wheels....  was here 2017 srmkthdorwbnpuwswubjbllcvjyihjijnvmhkrynsbgghxhl
 * Smoking Wheels....  was here 2017 brlijayyiykknkgwthhjycataynqiydwfludpxltiwowfght
 * Smoking Wheels....  was here 2017 ycyvifovieaqwehwwzdhivpnicpfexwnagbkvbhxcxuxlksq
 * Smoking Wheels....  was here 2017 xchnkqevvvvwaxqnxidxjqngejjalhlhzzagjjdfsxjqasum
 * Smoking Wheels....  was here 2017 qczerhbvenadttiwyybiisidemegbndmjmtyvhuazyzlcuyr
 * Smoking Wheels....  was here 2017 euuwljuzzyzoxaodftyxtpyoeorjhdjppznaaqiybimbbnxc
 * Smoking Wheels....  was here 2017 tctzgjgrdfiqsjvvexbdlzjchvuamawjlwvkzhdxjpblqzqq
 * Smoking Wheels....  was here 2017 wdeayznotpaapqtsowxxnwaryxrfkhowyvlczntalocttojq
 * Smoking Wheels....  was here 2017 hinwogylfqergxkulhigglllsntcxhsihullqvarefgmpuop
 * Smoking Wheels....  was here 2017 ykqolkcoddevooyjzbhnegmumtqdfqugzwcztxbnswkhppxh
 * Smoking Wheels....  was here 2017 efnlbwvgjcsyuevytkcgdyfikwfbtemjvnxpjtflkbtdkbkr
 * Smoking Wheels....  was here 2017 kzlcikfdbwrqiquglrhiepayulrvfauttkqiuqapxprganfb
 * Smoking Wheels....  was here 2017 jbxhgzqdozfyvauhbppupjluhflonnwraljnpyjiboubpqwz
 * Smoking Wheels....  was here 2017 detedwpknftahsbjwbczztjgthctwgfoevisonjhyebgnfbc
 * Smoking Wheels....  was here 2017 xfzannagupxivibzjfbldmwyjyqdrdogxxbuughjazpuoitn
 * Smoking Wheels....  was here 2017 ejvlhqzkmmpoyrmxgnzzcogukrcpqfvsfljtoktrwvvwpkdm
 * Smoking Wheels....  was here 2017 rbxfkfurziyqhwhcppqtefdwoizkrwggjgfzlmqritkyubrm
 * Smoking Wheels....  was here 2017 lxxlgnbgxzkvuhtwokcaywkqsyxyzsiiwpyafeyxpafsqbdh
 * Smoking Wheels....  was here 2017 sxxljapmdmqnqogsscqjfibsyutyzptslvbrzmciyekduply
 * Smoking Wheels....  was here 2017 zddvnknbtcmlgmokuctqaomyplsjkpmlcribaqrbbzkkezvq
 * Smoking Wheels....  was here 2017 zbejvseuekcnieqytbfxsshnjqdjcdsubzunxcmlvovyzvsy
 * Smoking Wheels....  was here 2017 rjudpcexaeyzvaspwxclukhtcmtlitygwysokqqeidplrzwp
 * Smoking Wheels....  was here 2017 jyamidhrdlqhxqewqupwdgpjwfjgmiwofaqbreldyhwywofq
 * Smoking Wheels....  was here 2017 oyczwmrwrncczuvnueiasgmfckfuhzltdvibxanlhvanoxah
 * Smoking Wheels....  was here 2017 yvolhepgyyljtsppisbyxsqkkwrfpbycvivxtpsmgstsxrsb
 * Smoking Wheels....  was here 2017 ogfzwksaqncierrinhtyhavjqpjzrdtcwqjeyqcwyiyfjqat
 * Smoking Wheels....  was here 2017 qccweqwppgsjjhpfvctqpyeryxgvxcqnyfoqpeansetxozwj
 * Smoking Wheels....  was here 2017 rpkraqcoxmegwkzazonwxmzhrjkrzbojbsclajbpfbobnane
 * Smoking Wheels....  was here 2017 kcthmkuuasrxgewubixqpvxilshswjrxlaaxsscliaacijlq
 * Smoking Wheels....  was here 2017 vixsvcmlmupmnyltfiwhdnsddbojspoqqjroozdrdibrmwho
 * Smoking Wheels....  was here 2017 fewirgbyfronwhelastljfokwrckzrvijenfodpgbouvqqcy
 */
package net.yacy.kelondro.io;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
public final class ByteCountOutputStream extends BufferedOutputStream {
protected long byteCount;
protected String byteCountAccountName = null; 
private boolean finished = false;    
/**
* Constructor of this class
* @param outputStream the {@link OutputStream} to write to
*/
public ByteCountOutputStream(final OutputStream outputStream) {
this(outputStream,null);
}
public ByteCountOutputStream(final OutputStream outputStream, final String accountName) {
this(outputStream,0,accountName);
}    
/**
* Constructor of this class
* @param outputStream the {@link OutputStream} to write to
* @param initByteCount to initialize the bytecount with a given value
*/
public ByteCountOutputStream(final OutputStream outputStream, final long initByteCount, final String accountName) {
super(outputStream);
this.byteCount = initByteCount;
this.byteCountAccountName = accountName;
}    
/** @see java.io.OutputStream#write(byte[]) */
@Override
public final void write(final byte[] b) throws IOException {
super.write(b);
this.byteCount += b.length;
}
/** @see java.io.OutputStream#write(byte[], int, int) */
@Override
public final synchronized void write(final byte[] b, final int off, final int len) throws IOException {        
super.write(b, off, len);
this.byteCount += len;
}
/** @see java.io.OutputStream#write(int) */
@Override
public final synchronized void write(final int b) throws IOException {
super.write(b);
this.byteCount++;
}
/**
* The number of bytes that have passed through this stream.
* @return the number of bytes accumulated
*/
public final long getCount() {
return this.byteCount;
}
public String getAccountName() {
return this.byteCountAccountName;
}    
public final void finish() {
        if (this.finished) return;
this.finished = true;
ByteCount.addAccountCount(this.byteCountAccountName, this.byteCount);
}
}
