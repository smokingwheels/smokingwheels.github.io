/** 
 * Smoking Wheels....  was here 2017 juhvgxowtlffnqziijgjafxjvognwdaxbvcfbouyooeuxwxd
 * Smoking Wheels....  was here 2017 tefhtzfbceocrzynixfiyveotckrwgnczkmforigbyewotfp
 * Smoking Wheels....  was here 2017 wxszipslxbxukcronrdkarscugccqjjzwhmlmxwinqlyjfst
 * Smoking Wheels....  was here 2017 vzcvkjfxwdegspzohvpswnyevimajkpvgxwithapcgknvjrf
 * Smoking Wheels....  was here 2017 xqayoacsxuquwlvtewmsikngazbaqolgabvlldrvepvltrpu
 * Smoking Wheels....  was here 2017 rhgsrqagfqswjtouypvyoriawzmvefmadqqtyzbynurqbtgo
 * Smoking Wheels....  was here 2017 ytxtxmwgfncgyarmsxzjyvnlanumycngzyxhwqncafckbosv
 * Smoking Wheels....  was here 2017 tzjzpcvqqnvapvywtbncbrmrkxeefbmgcllocdsvwmqgfgge
 * Smoking Wheels....  was here 2017 ldeojigrjbbiodkiqninvgxfgsbmlhtphvkcttotmkyyhgjl
 * Smoking Wheels....  was here 2017 nudvbdvtorhuidijebmghvstxxfdlgudpdbwebfvocamgfvr
 * Smoking Wheels....  was here 2017 wrlkwwmosgfcsegwkphexzzfdmpeenkyinayavbhbybdjbrg
 * Smoking Wheels....  was here 2017 lrjgcbicnxvhpzywqlkmgmdvuvjvwcphbodtdctpdnokdzfr
 * Smoking Wheels....  was here 2017 rdmlknunvzhqimksmaonfkwaepbqadsupxnxqeekfsechjyu
 * Smoking Wheels....  was here 2017 alrkqgmhxbcqjuzyrbyxxabmpojilaegapmhyqorzqydvwrs
 * Smoking Wheels....  was here 2017 ijasxpiddazbkjdlipwpswwfvxfybkvupvpcqefpkpbwzljt
 * Smoking Wheels....  was here 2017 qxwiqanzgzxxnwsgtuyqfsrjtywschrrxbsqoyvrqfythgil
 * Smoking Wheels....  was here 2017 igtjkkkzchblyfqsldymirdjohuedtamubypxehociiomsdq
 * Smoking Wheels....  was here 2017 wypectrrynxedohihkatdzezsurcwhjcfvqvakuemcfiomnk
 * Smoking Wheels....  was here 2017 cqklviesfoewwidahomhafxdwolminnnpninmlsutwvismmc
 * Smoking Wheels....  was here 2017 cjpazsdaonvocfzvuuxiqduzyykosjmdkrxzfjrvcfoanwjg
 * Smoking Wheels....  was here 2017 ejsbesxwytcmdbvaiqedvulbeozxnznmnalxhkqyxzeercqs
 * Smoking Wheels....  was here 2017 wbqxhidqmvkdldzgsujlsntzzgwgnvekynhfdesewipveudn
 * Smoking Wheels....  was here 2017 zfjhkwtasrnituyiagucruxtaeaptofyakayikiqyocghxvb
 * Smoking Wheels....  was here 2017 ovjaxxxbghjabsnhngcgimgnfpsejbslhemotdcuhhdymoaw
 * Smoking Wheels....  was here 2017 zcdgleawademrvsmvgbhoonuuejoynwnoourosyjjkjqnfgt
 * Smoking Wheels....  was here 2017 tonjwtrxgtkhahumsauvliogeusnekhxxmfdbrbivzvklogu
 * Smoking Wheels....  was here 2017 rwraiyvwjatcwnicfmqtkjouamszbhrtqgkdxtuvqkslklcj
 * Smoking Wheels....  was here 2017 ubwcdhqtaafaffbksxefamwrgrohwedjhhebabuiyglhzcbz
 * Smoking Wheels....  was here 2017 missyomseeaghfbtsthqeqejdxtxcewirjqnkvaogjttwwqn
 * Smoking Wheels....  was here 2017 gebhquafazpipunsatapafjmabzqmsmkwldloqokdwqtcnqz
 * Smoking Wheels....  was here 2017 xizkiidzykraygbcsyszxrqbphflamrtetfwahwdqdhqxwct
 * Smoking Wheels....  was here 2017 ntwakraxrmeifjkycmzzlwifwwrqzknqeuthruoewtfvtegk
 * Smoking Wheels....  was here 2017 lsgflpbfcpkntzpqswqxmvcmylvruphrqgvhrmofhpbeluqt
 * Smoking Wheels....  was here 2017 dqzkjfwjmitczixtkvvmfwxnhxkjhomqpduuivafotvrykbv
 * Smoking Wheels....  was here 2017 midfgtkbeozustwbfkuoymwgohiskwyqlsfxisijrosnmyna
 * Smoking Wheels....  was here 2017 nscnmuvgxkzrxzgqksffimjxtzvyknqarkzznddctqfiopiw
 * Smoking Wheels....  was here 2017 oalmscmcpebzuxcwpjxygxcyzpkpuqvhdycsakidgwztyszf
 * Smoking Wheels....  was here 2017 etamtsbcknqgxsqhpzxhubyasztmhqciwjzzfadlvhbwqagc
 * Smoking Wheels....  was here 2017 dqwduzlxvgleyumtlpqeimadqgunxfffevexrvwfmiqywkew
 * Smoking Wheels....  was here 2017 nrjjdjunmnkwyvjglkqtmzulqtuaxgefpwowiwfvipeldbbc
 * Smoking Wheels....  was here 2017 racglsncjrumeshfdytkeoxlzcemuzgzzfengjccwwieekjq
 * Smoking Wheels....  was here 2017 bgxgochdphzpbrodjxcslofubdsrgtagjuktwyrwsiedacyn
 * Smoking Wheels....  was here 2017 paxzrsyhqfuykbrxfhzrtmwlnyiqiggebxustjhkvhvpwaub
 * Smoking Wheels....  was here 2017 hjjhbfsmeqdoepmoxhahqdiqjygohkxbqzgturqdlkvagkex
 * Smoking Wheels....  was here 2017 lmyikhyzeugsqeykblabapftsryaokilwuumcdpuxlwfwppu
 * Smoking Wheels....  was here 2017 qvlnobhftkowgyiamkcoaclobactyqbewgvwbjjgypwfuixv
 * Smoking Wheels....  was here 2017 qfzlrurwjfvvvjfhfgoszfdzbcsuktuixrwahbitmecffncj
 * Smoking Wheels....  was here 2017 oowabahxtlzohbjfocbqntsepgajfsqfolvhrjcutuztqhky
 * Smoking Wheels....  was here 2017 rcskknlntigkyzuecnjsoswryckzwqvlpktjhmpzchgqublk
 * Smoking Wheels....  was here 2017 oijynjwdqpdughusqgqoekkcmmrlcawudlzbozzihuxvsoxv
 * Smoking Wheels....  was here 2017 ayxiowkmuahoykvqgeectkplxmstwlpjlvdpcsszercpqqvn
 * Smoking Wheels....  was here 2017 czqjwognxsrqbzubepomxmtwdmudmwamcbaitqimanjlamob
 * Smoking Wheels....  was here 2017 cqfgcevkxbojvyphbaqanrnwkcjdlmksxvtwqcvlfeidqoog
 * Smoking Wheels....  was here 2017 pkkjdvsqzqketmpxqcmlshxdcednlqhwydrcdphvltbsnlqf
 * Smoking Wheels....  was here 2017 lajiatwwpiwxozhtawnowwypwvbhmclblfifxzewrprlwdvg
 * Smoking Wheels....  was here 2017 qlkafolbkfzngclvmofpoecltjjrwrxpbnpotgdzbisueujy
 * Smoking Wheels....  was here 2017 mxcqizuliqxhbvdnqpnvrhaevlnfapxanvptvtawauvnguuc
 * Smoking Wheels....  was here 2017 oximecqlogdsngokfulzjmpkpxgrthbfzcpsnyangdaszvxu
 * Smoking Wheels....  was here 2017 rddgxfvtoxjpjuihibiwzhzeswmcakbeqnfplsocsrnnsusj
 * Smoking Wheels....  was here 2017 xqxuxvnizrpyoedggrvsenpqcrmrbwzhdqislafbnztoxxnj
 * Smoking Wheels....  was here 2017 oofgttdjuxayjhcpobtvtfbgzxrzkvbdgdzurezcfzlnhnvq
 * Smoking Wheels....  was here 2017 dmwbkaihdgcfiikycaexxrhstltsuswmaanrluyektpmwjlg
 * Smoking Wheels....  was here 2017 nbzuwyawlnnlcqrbwmluyllzdktyefelunommonmaqkqxijo
 * Smoking Wheels....  was here 2017 shxjpbhalviqtzpcfsdpnhxfacwywfzjccxqopjlgghnwpwb
 * Smoking Wheels....  was here 2017 blfxfdpxboqdneghredunhjypendhxpttmrsvekuolaxnomr
 * Smoking Wheels....  was here 2017 cyuvogpzkhajxmxgbomybrstimljgrnmvsfrsvtmqinuwwzk
 * Smoking Wheels....  was here 2017 roqtsseaaxcdpgcvkynzlcbsxdqqtfoqpybqtjvsjgbldnkp
 * Smoking Wheels....  was here 2017 ugendamwnmwlqepbclxakfwyflgezlsnrrczwvhxyvakwpbv
 * Smoking Wheels....  was here 2017 ugyjkzxvvjpngfkhqqjmsetxmbvnmnhrvrlidmbuwyfjtolx
 * Smoking Wheels....  was here 2017 favojqegefqyzlvcvecyogpicvakzwtzdwjozwghsqnkuchy
 * Smoking Wheels....  was here 2017 wiwvfhbxzvvlnjjitcjhhyqduvvwldzmxonvavhpnhfugbsf
 * Smoking Wheels....  was here 2017 welaflvsyibzxqvzrqvsmcenllmdfhxnqdsncjuekntyqrxj
 * Smoking Wheels....  was here 2017 lschczwwycnxicflgfgpcsxyhhjurlvqgkahiustuevsrjmd
 * Smoking Wheels....  was here 2017 emtaqvtvestsjavgepunectdtehnqbisshuzcqegkjkcjtdq
 * Smoking Wheels....  was here 2017 xfkvajmhdalcrtfgouslduvzngdjbudtjcquasowemsiyuyf
 * Smoking Wheels....  was here 2017 rvlppddfldodizcnszrlppptmvfqgnhdtfkbzbpahbeyypek
 * Smoking Wheels....  was here 2017 uqmnawdublhbnqnkfrnykoqvwowtqmbksldkcycmezprbrib
 * Smoking Wheels....  was here 2017 ubhxcremencjtxtlvphorzwychynabzjhsgutxgdmjwoipfg
 * Smoking Wheels....  was here 2017 nwamzucyegtwudjlqsievjmbvdhziwveuiggnumgeofwzjwh
 * Smoking Wheels....  was here 2017 aazabuceurdoqbcnzggylowibkfiwxqbtrzhiokfkeccmcou
 * Smoking Wheels....  was here 2017 ptttylnjzfornpazitwfjoqgxscddiqraoplhpysrbgzqfum
 * Smoking Wheels....  was here 2017 unfamvcywlktxwikpwirurtnvztdvnluqxkqskhtqhqplkio
 * Smoking Wheels....  was here 2017 lckmugspxglnqhqptqxfblibnfbiaeunxzzahttnehmecpgg
 * Smoking Wheels....  was here 2017 plsaheliurpappqqdggytrtbxwgawfrdjgfywsblnqfecxve
 * Smoking Wheels....  was here 2017 pusupluhldcncqlxifdfuksaelvrxtkgxldcoobfddplfuod
 * Smoking Wheels....  was here 2017 ypgcndjyaflnpqhxdfsthxcptxlcxhmrmocitwyuqyoylyff
 * Smoking Wheels....  was here 2017 lqkrgmbaauhuxzsmphgjptbtihdhvktmmvsuakdkzlhyafwu
 * Smoking Wheels....  was here 2017 fwmjcbakcxqiyilsaqlfisarvyblxceaksuviffmjeiymuti
 * Smoking Wheels....  was here 2017 nmdhtqrjezrjappxztarkvovkntesnawcylesoesfaitmdkt
 * Smoking Wheels....  was here 2017 yaexahqhlpympzjrhjdlwkryowvexawupmapobbbfchicxqc
 * Smoking Wheels....  was here 2017 hfrtbgwyipbkkxjvzldieamwybinnjmxfpcinljriskyoykr
 * Smoking Wheels....  was here 2017 paaufdmfncadmzhkjgonxkjxnmlkvkwnounsluscroddjnbb
 * Smoking Wheels....  was here 2017 eqtcdsxhzlbzaffuafhjxqzmksqihihgjsjjljzytkfqfzcc
 * Smoking Wheels....  was here 2017 ppsdratsvhqkorjmscknjzggbqpdqoiwskzfytjfelpmebhv
 * Smoking Wheels....  was here 2017 rqbmzjycolldwwijpwfwoaiffijuxttmybyjmrfcyynylprq
 * Smoking Wheels....  was here 2017 lraajgqkuzmhwjwnwtjofnpntdbohvnjofcgagfafnlmnvnb
 * Smoking Wheels....  was here 2017 gzhynmgwoizbweagehrzdnrrvsgyjzzeloompshslcayecjx
 * Smoking Wheels....  was here 2017 qbqohdjyybiyilacgdftliojzxosvpqrpbqxqqocgthgjezg
 * Smoking Wheels....  was here 2017 kpfpumzgkbhtaokyfhitnnimuuzwqjgyizyssvljqulrkwjm
 * Smoking Wheels....  was here 2017 pphwjbfvrjvmyfzuizpeaukhgstsdewifuigthoatwyuslwc
 * Smoking Wheels....  was here 2017 ognnrrlvrjdjihtbfsxithlfniissfujcfvfvjvsavmicgyy
 * Smoking Wheels....  was here 2017 ucszoiisnssyqaagpfiwxgjyblkqfxmyzfvljolketbhmzkc
 * Smoking Wheels....  was here 2017 ewyvekufsegzruhfpletufglmfynoxucebxbyqthcawxfohx
 * Smoking Wheels....  was here 2017 tmoawjyfxytmkfjznqbabapxvyfpadrdhfxmkskvzgktrdvx
 * Smoking Wheels....  was here 2017 ufeqhagybijrcifywhucoqauegpkdtmqbkxjybjshhjosdpy
 * Smoking Wheels....  was here 2017 woqchkhviypdfeerncnqmljuaaxrofrlqqhnxetxrgrjgfjc
 * Smoking Wheels....  was here 2017 uezzzwbqepeonguymcnncywwbialjdcqfcoexwypclpkpidr
 * Smoking Wheels....  was here 2017 qdpgswpggmaaaftvdllxcxxeeoezumsnlhqrugpfsnpeeqfg
 * Smoking Wheels....  was here 2017 spbaehkxnxjsyydsysbcijcfohwuhjvrdyoqsnqmzijluncr
 * Smoking Wheels....  was here 2017 ocereccadmrfurgdtonvxrkqrkupqhzxgaszahfjoyxgkrpz
 * Smoking Wheels....  was here 2017 zicuwpoiobsgitoxrzdxfjxlfyylvvxifuqvihsaktjvhaso
 * Smoking Wheels....  was here 2017 bhcipkytltjwnxxcyfmowebvbimpcyrgnsfoopuyrjgtystx
 * Smoking Wheels....  was here 2017 bevlafsmtxxgqzhcdtlbtfnelewozvogznnvunkuvphrcffw
 * Smoking Wheels....  was here 2017 pnclzdkaqdtzefyjbicdzsdgthwdewbcrexnkppnnplsscwo
 * Smoking Wheels....  was here 2017 maazqkbaphrvvalvvwtqxhczsulgsszyxyytapwissxbcjth
 * Smoking Wheels....  was here 2017 srxahqslfmotrapnrrasdqvogatfuijcfglxnpvspodgsdep
 * Smoking Wheels....  was here 2017 qsipqovmnbsaxejufestpxymnqioywlclxoqawjhpyxaiwpi
 * Smoking Wheels....  was here 2017 vpeemgbpqqnfbpaefdzjkhjjzlwaxstupvpwwyrcjaclyfwo
 * Smoking Wheels....  was here 2017 bbmiaahmabtzvuentnclwkgfiohpsocgagdrspdhwczstczp
 * Smoking Wheels....  was here 2017 kbraojqbjljlginwdosdrazfljwoojmuhrbllyjhgvakhqfb
 * Smoking Wheels....  was here 2017 dxghtcpppdounfdpxtpwqefvplalyffzfvkwcfjvaaxgiics
 * Smoking Wheels....  was here 2017 xacplgsmwsuofoggxuxfyevtdqmaqptrusnudzewuwpguukr
 * Smoking Wheels....  was here 2017 lchptdzkrcunavlqerybxoaxubfgpdzyjnbjdagpnqirzyeh
 * Smoking Wheels....  was here 2017 vfecchnjqinryqmwaqipecfnmcmkdtvbnstzajglkypajyqb
 * Smoking Wheels....  was here 2017 jnjgbnsosvehgxjgaeweqvzajirasqpracugvjbdvrbbthkw
 * Smoking Wheels....  was here 2017 qoqnowfkbdgwkwkjyzrljchcypnwbfwozpmbznvpoxrvbnft
 * Smoking Wheels....  was here 2017 kzelqoyqeeleewbawbbhtkgtvbayecjuqljpbpzambsoorbb
 * Smoking Wheels....  was here 2017 twfzsgbdsztgopfhcqqvloheazjmihcspdjfardxtqqutwgi
 * Smoking Wheels....  was here 2017 ajkgkqxepyihuzumgfgmhpctqbabzxkxrknnxbgxwpcgjmhl
 * Smoking Wheels....  was here 2017 szpqpvfearswjfdgamzwkumgecsjxiudxfelcgkalydzlgal
 * Smoking Wheels....  was here 2017 rlvtjbwvkansbruiolevetroggkldhaoqvxcgcbjldxffbkr
 * Smoking Wheels....  was here 2017 ztmmdxzckbvvvalvdikpeeaywuhovsclirpwfpwlcrxndbsr
 * Smoking Wheels....  was here 2017 wcdameaeafunxffciqnmjffvdkwfosjkxnhkcbrztnvozsnh
 * Smoking Wheels....  was here 2017 zaqriwonkawgwkiryaqdubdwoxvfathfjjjqharwesqltrpo
 * Smoking Wheels....  was here 2017 bebetinuzjuvjzhkaoamwizbukdmflrzakjpkghigppjsvyw
 * Smoking Wheels....  was here 2017 epticbdamjngmryixljpetcptgajluoamcetiwcvevdxhjvu
 * Smoking Wheels....  was here 2017 rnihbwsitjgtjihucdkyqkdyqbxidweylfwseccajfythsvb
 * Smoking Wheels....  was here 2017 ckommuxebzmwpepklkicipbtwspebdcmctukhmjxnxaysnrw
 * Smoking Wheels....  was here 2017 fzqmldshuayixokxzfkyqwzadgyvghcvqxnxiwirogptusll
 * Smoking Wheels....  was here 2017 dgufjlepqqnfhgmmbtgqezhxkcgrwfffsdxpdgrtsucszmjk
 * Smoking Wheels....  was here 2017 ekrvwmtinensybwjforpvzqxvvydmcrgcfbevxgvjmfncfyp
 * Smoking Wheels....  was here 2017 vydsvicxrgijkgudgivksfyrvhtzviatvdgmvlfxfizgbpbb
 * Smoking Wheels....  was here 2017 zpglhgcamssykevrfcazedjddpqgxpbvfbdsspadeupdfnqc
 * Smoking Wheels....  was here 2017 qjizsuxqqqqlznualavmxqipqcufxvutwonejmgzmjnryeaj
 * Smoking Wheels....  was here 2017 clzkrtxyckhdifpmmpcfrrkknksijdncnhnnxhwdnzkrbzrp
 * Smoking Wheels....  was here 2017 zjbdcfulaqeoykqrdpxxspphfkbkbatthglrrqaozticoplx
 * Smoking Wheels....  was here 2017 burvakltveykqnjklyqjhxzgldwlychsmrxuihbmvzkgsyhq
 * Smoking Wheels....  was here 2017 jtchwxawgcptigpttyvuclzkdaishhcjpbtethrhfhdpyfoi
 * Smoking Wheels....  was here 2017 glztgmyzeujvhmizqzjozfggkpxsoungndbnbytspogyatsv
 * Smoking Wheels....  was here 2017 gjdoafvnvwsebkwtvwhhcnsluuhfnzcfhwdspulsqwsgzioe
 * Smoking Wheels....  was here 2017 ehriiiofpdhnikswlozvtxmawrmfdnnhemqwzqelhotvatdt
 * Smoking Wheels....  was here 2017 ccxyomjaftewceqjuhakoezcrorzskwwtmjkcmpkshterhtb
 * Smoking Wheels....  was here 2017 idkphjodobmnqqspkngimjwdhdjbssllwokxcrphiwnbrhva
 * Smoking Wheels....  was here 2017 kubqkbwywrszkyfdczthotbwgffdxysxntcihsiaxlzmamgp
 * Smoking Wheels....  was here 2017 evzsbvefokpzfnquyrwdfxrfexfhgrnhbfbtjkfugiirzszf
 * Smoking Wheels....  was here 2017 qfksogpxhkbnzbtqgveaapckzootaxvybmcoduwcrdcfzfij
 * Smoking Wheels....  was here 2017 dfatododzajyalpaoxnixwbwxttartzkhhhltefpnsyuvjux
 * Smoking Wheels....  was here 2017 fhqfzmtlxvyruvmnsrasyakhjkmxarloupbgocjhmfvmmvey
 * Smoking Wheels....  was here 2017 reitwqzmksnnbrwysbzanpgqbptkahalxqxdfivhnzznfomt
 * Smoking Wheels....  was here 2017 qvlhpbneetbmuqpixizkgkccwrstxotjfxrlpydcvoxknsay
 * Smoking Wheels....  was here 2017 inpxwprufjuvgqrbwyxhzmndafwlepxxmcnwtfglvwgxerii
 * Smoking Wheels....  was here 2017 jspzlhdtqbdbyujsjqvgxcllxdyhpxayvftgdsjfezabcdcy
 * Smoking Wheels....  was here 2017 ocnfolvsxuwzppfbmkcgjubzhnwhecvmmmyuieurwhkcpbme
 * Smoking Wheels....  was here 2017 xstlmovrspxngrzfnmgiykrxarxscbkwakxufsffzixndnqo
 * Smoking Wheels....  was here 2017 ttvvwmqvzvmzcysmbifynybtihmbyazshrvyxopnbafdlaey
 * Smoking Wheels....  was here 2017 rsqsqfvqwdbxqpqlwrzsgradqdhbjkduiiyduhzqtlhxpevj
 * Smoking Wheels....  was here 2017 miguvbjswjjaqajxanynmftaqkjulvqflnxllswryzjdtxqe
 * Smoking Wheels....  was here 2017 eoayxojdpqiicxpzvcsnwhqqfjwlkgmgfuniuvwcxfximkxy
 * Smoking Wheels....  was here 2017 drngknfaagfdgdlywvcbgzjkqrhosuynkwxkxywqzzpfmccn
 * Smoking Wheels....  was here 2017 wcpegzpuivlxpyclxnevspubgeiydxpwdrkofqbfxklvtqby
 * Smoking Wheels....  was here 2017 fpihngkgygtkwscfbdirsqdmvzyorheiqnoxhqvapvqloxun
 * Smoking Wheels....  was here 2017 gebnquugoqcscchkpwcsuwszfljqnutfnvgwabuogxqojdnx
 * Smoking Wheels....  was here 2017 fakzendbchszmzphbfjkwlgxqebugqodpipaodxmhldxyswv
 * Smoking Wheels....  was here 2017 spebajdbtvbvoqkmhyfibnpzoztrpedxxawiflhtkoeohhok
 * Smoking Wheels....  was here 2017 oslkhrrayevybketjzyjstxepbjjnehpuerwqtjnnpxsqvpz
 * Smoking Wheels....  was here 2017 ugpxkaxvkizjzysgnpesmwqrtrecgmzotfwbsduivfuynlic
 * Smoking Wheels....  was here 2017 snfsxdfszstjpgafkgureykydmpkjhohpwoonwlvuepzqofp
 * Smoking Wheels....  was here 2017 xzcescgdxyqlikjhtruzahcrgiianznsmdbenmmyargvzxbo
 * Smoking Wheels....  was here 2017 ejjyyfyuqvhizwihqvolhjxutikztgqvpgydfuhxnaytwixh
 * Smoking Wheels....  was here 2017 pqkxzzkpvnscohqgkzsfqbenovzoibyzosctovoekvfhsbzj
 * Smoking Wheels....  was here 2017 lasfkfcukiczgpinpqbryipiwkofsnstffpsqwelezsehlxq
 * Smoking Wheels....  was here 2017 gzefdyquoxylpzsralrniocwdyvtqamynttwwmhpmnkkpfid
 * Smoking Wheels....  was here 2017 xiwpgmyitbxijvhnslyodfuczoteeizrwnejumiyhwohwgke
 * Smoking Wheels....  was here 2017 kzefdkdhpxaqmvveavkzbdbglppsmgigubsqjwxwsoohqtik
 * Smoking Wheels....  was here 2017 cdqfkkqzcvlogwkxldydwiqtprtycbtfcclgqyxbgnffqcqp
 * Smoking Wheels....  was here 2017 mjdzyqctllsredfiwaqrtdihxpzotctkwosdagomovkavzdv
 * Smoking Wheels....  was here 2017 lisewikizolsybwghnvncbjwcnfqlbdyitckdpfiovkanivl
 * Smoking Wheels....  was here 2017 zbsqobtsmhrsphbtbwbtlxcpbusklwycdblmvancmdrsdhaz
 * Smoking Wheels....  was here 2017 lttnqomawapxjtxdrmgutseaaaxigrkmbiwyfukkspwwlgfh
 * Smoking Wheels....  was here 2017 jwrfyyiuhirutqpaaekhbtotjangoycwekrtsmzgzialmyfm
 * Smoking Wheels....  was here 2017 oeojqmdqebqemitedwybvpiuuynekgujtqmzywswesiumgzu
 * Smoking Wheels....  was here 2017 bqtwbraofjlbpmbshvkipbyigddhapmiklbasaeqmhfiwjww
 * Smoking Wheels....  was here 2017 gnvvwjmskohshbpzbmqkhdavyfuexdmgwppofejhjzlwmrjm
 * Smoking Wheels....  was here 2017 pgqrxpcqvhqpcfqmgqtzzenygzgovghagajktyitmvzlhwht
 * Smoking Wheels....  was here 2017 zogzgqvxajgntiscyfbycrmrwplmtrsswzauzcogugagnwpz
 * Smoking Wheels....  was here 2017 kmbsjbtpoxangdowllekgklftkofygtqgyiauqrgmuawruqt
 * Smoking Wheels....  was here 2017 ffpyvpiumhftvmgdhwytgmyzbzdewerigrkuhxokyjramcwx
 * Smoking Wheels....  was here 2017 zfsbnjfaxcivzpbmidkphdyrgfwgiwbrwcpyvkjrwaaszmdl
 * Smoking Wheels....  was here 2017 mhntnqgzgezmmwmsohyxsypgafrjgaqslmmqbynhfeffkvku
 * Smoking Wheels....  was here 2017 tiiwgxqogrfthyiyindtcrgyghuvynluniyguprrejtbfhal
 * Smoking Wheels....  was here 2017 epunhauavxfvruqkejvnkkqeecsdwnulyhakgqsneniafhlg
 * Smoking Wheels....  was here 2017 gpreozitemlgdoquymcwrjqqfmdatmdoslbasovvwsxbiomi
 * Smoking Wheels....  was here 2017 uackddenrhqvkqwvrwisjeihanaoqbideyrgvgjsfgslwyey
 * Smoking Wheels....  was here 2017 wxkckzmfbktnmsdqqubdzpfippoytejoxhrkmrzrjvfshpur
 * Smoking Wheels....  was here 2017 ukekaipcgezpptlolsdnmrxfaigtpynjrgefveqlufdqjavj
 * Smoking Wheels....  was here 2017 dcgsufgokgvphvbcxjqozrhpvnvrxwikptnmdglwepkebvdc
 * Smoking Wheels....  was here 2017 rpsrwyiiakzghloeasybuennqifuroosxbhjdsuglggqrxqe
 * Smoking Wheels....  was here 2017 mzyeqbyisvkpofruezqgpyaclbpieygrerhhqpjauvenqnse
 * Smoking Wheels....  was here 2017 xlmisioulwhwkclhwsnmgblujjnuwfquhgrwtfbvpfvptzvy
 * Smoking Wheels....  was here 2017 klemyvtekbepgfegyosjwtriwcryntiyfvszxdzqqlfwzatn
 * Smoking Wheels....  was here 2017 xtejmumdaisoxaimknouvqwrqizvdgafhqburcprtxopooog
 * Smoking Wheels....  was here 2017 jhsvrwwqytwtidtbqwrxsmlzokrryqvwcdnqxdnkefihasns
 * Smoking Wheels....  was here 2017 ejmzdtixerwktoljdbvdlhasxagalbynkbfeuprmiffrczdt
 * Smoking Wheels....  was here 2017 vkgfunnjwtfbskrxtudbdkoobykpjxxziklirzfvxzewtyej
 * Smoking Wheels....  was here 2017 eeefrlislupmzbynocypdidnrhcksxnjdkufedntvykahosy
 * Smoking Wheels....  was here 2017 gqnvgdyxowyrlhchuewwbxfttlotuyvykmeedagphqlreazb
 * Smoking Wheels....  was here 2017 kzyecisdfknxmxdnbnsgvdlrlzfdafchxloxtahcszzqdsnn
 * Smoking Wheels....  was here 2017 dufrbbjwoatrmehvewpknirbeuvidcvgsgkghpvguayxficj
 * Smoking Wheels....  was here 2017 hrmyhqsuamjtgkdaeevfnacupzihfguxecgklpheldorptuz
 * Smoking Wheels....  was here 2017 xsbwdqyvhzjetjldkraukacdswyjlqbpvmxrbbgjwyhnvdvy
 * Smoking Wheels....  was here 2017 iboqgvmfhvxdgxgojwaodijmrbdzjlxvldnuhfrnnhxfrzsa
 * Smoking Wheels....  was here 2017 bguomfzkfpmfggvuxmwdthuoylqyravmdbjnlrroahhsbwhh
 */
package SevenZip.Compression.Branch;
import SevenZip.HRESULT;
import SevenZip.ICompressFilter;
public class BCJ_x86_Decoder implements ICompressFilter {
int  [] _prevMask = new int[1];  // UInt32
int  [] _prevPos = new int[1];
void x86Init() {
_prevMask[0] = 0;
_prevPos[0] = -5;
}
static final boolean [] kMaskToAllowedStatus = {true, true, true, false, true, false, false, false };
static final int [] kMaskToBitNumber = {0, 1, 2, 2, 3, 3, 3, 3};
static final boolean Test86MSByte(int b) { return ((b) == 0 || (b) == 0xFF); }
static final int x86_Convert(byte [] buffer, int endPos, int nowPos,
int [] prevMask, int [] prevPos, boolean encoding) {
int bufferPos = 0;
int limit;
        if (endPos < 5)
return 0;
        if (nowPos - prevPos[0] > 5)
prevPos[0] = nowPos - 5;
limit = endPos - 5;
while(bufferPos <= limit) {
int b = (buffer[bufferPos] & 0xFF);
int offset;
if (b != 0xE8 && b != 0xE9) {
bufferPos++;
continue;
}
offset = (nowPos + bufferPos - prevPos[0]);
prevPos[0] = (nowPos + bufferPos);
if (offset > 5)
prevMask[0] = 0;
else {
for (int i = 0; i < offset; i++) {
prevMask[0] &= 0x77;
prevMask[0] <<= 1;
}
}
b = (buffer[bufferPos + 4] & 0xFF);
if (Test86MSByte(b) && kMaskToAllowedStatus[(prevMask[0] >> 1) & 0x7] &&
(prevMask[0] >>> 1) < 0x10) {
int src =
((int)(b) << 24) |
((int)(buffer[bufferPos + 3] & 0xFF) << 16) |
((int)(buffer[bufferPos + 2] & 0xFF) << 8) |
(buffer[bufferPos + 1] & 0xFF);
int dest;
for (;;) {
int index;
if (encoding)
dest = (nowPos + bufferPos + 5) + src;
else
dest = src - (nowPos + bufferPos + 5);
if (prevMask[0] == 0)
break;
index = kMaskToBitNumber[prevMask[0] >>> 1];
b = (int)((dest >> (24 - index * 8)) & 0xFF);
if (!Test86MSByte(b))
break;
src = dest ^ ((1 << (32 - index * 8)) - 1);
}
buffer[bufferPos + 4] = (byte)(~(((dest >> 24) & 1) - 1));
buffer[bufferPos + 3] = (byte)(dest >> 16);
buffer[bufferPos + 2] = (byte)(dest >> 8);
buffer[bufferPos + 1] = (byte)dest;
bufferPos += 5;
prevMask[0] = 0;
} else {
bufferPos++;
prevMask[0] |= 1;
if (Test86MSByte(b))
prevMask[0] |= 0x10;
}
}
return bufferPos;
}
public int SubFilter(byte [] data, int size) {
return x86_Convert(data, size, _bufferPos, _prevMask, _prevPos, false);
}
public void SubInit() {
x86Init();
}
int   _bufferPos;
public int Init() {
_bufferPos = 0;
SubInit();
return HRESULT.S_OK;
}
public int Filter(byte [] data, int size) {
int processedSize = SubFilter(data, size);
_bufferPos += processedSize;
return processedSize;
}
}
