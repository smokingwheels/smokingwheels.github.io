/** 
 * Smoking Wheels....  was here 2017 oljzsfdpcziiwgplzpfnezjokimenhhwyfjuzqssyqdbcsym
 * Smoking Wheels....  was here 2017 wihspabomqemjuydadybhqjphcicgaxghqvwkcuvzgbbifae
 * Smoking Wheels....  was here 2017 qobnwnjtwdaqyvtblceezpekrwlpxzcmdsrfxtklhitmnxzo
 * Smoking Wheels....  was here 2017 vneomlddhmnpsrftjbqelvfdvxttushjvjykvueajikpgqnu
 * Smoking Wheels....  was here 2017 nulfrrsxaxqjywvceykuemahhrktmafbbrxjzpzizalyjkqe
 * Smoking Wheels....  was here 2017 diyewltppxlhggienvuxwblpvyvguzwvrbdhfwwgdinhxoph
 * Smoking Wheels....  was here 2017 hexiuebwsflulvshhbhqkdraksrxuxmiwdkouofadpprfrva
 * Smoking Wheels....  was here 2017 wtxvintrkxgtqyecpitkbsztjgxvvinjytuudwrelgujvnck
 * Smoking Wheels....  was here 2017 aqtbtlfhydudcdfjvmfwgzzgdaqgmctaoanyzeaivcnwqdjv
 * Smoking Wheels....  was here 2017 ctlrmcadwkhfkgngrpxysjpgmuisnfcrrifcffknibmaqxww
 * Smoking Wheels....  was here 2017 uehqfyaxxncolhebycltinwtmnpzcbvwihptcxexfloufhbi
 * Smoking Wheels....  was here 2017 zhwawrjpblxxfqhjvposikewjmlcmckmzvtmakzayszmyfsj
 * Smoking Wheels....  was here 2017 tsygsfjlqlqiculbsyjmefcepdyjgfoogzyftfpniqcqpqvg
 * Smoking Wheels....  was here 2017 oiozdsqwczlbqohefgczojniahogglhnzdtceyejjepahxop
 * Smoking Wheels....  was here 2017 zhzdwrbpfutqqbwbfyhiknnhpxzpodvwjzxonnbvhqlqiplh
 * Smoking Wheels....  was here 2017 xwuwwsrpaygvfnjiwouxyqmhpgcjltqmthofffwiqltuimej
 * Smoking Wheels....  was here 2017 nuuohuxcupvssohvnbpkqxavnubwoelluhxzzjlpekyzbqte
 * Smoking Wheels....  was here 2017 ewawqciozhrnqzjqxnbtdtynehiqrlgcjgnautxoxlsapjli
 * Smoking Wheels....  was here 2017 ngsroavskufuvuobuiqalwklntolxxhaqwesufoncxyyhgrp
 * Smoking Wheels....  was here 2017 lhmdbimlabbhkjdtkbessestvkqhnbzcyzytmzcwgevztbee
 * Smoking Wheels....  was here 2017 bpcshxqbeifbqfnmbqskkvnxqsunesdjzsdznmiidcurswzi
 * Smoking Wheels....  was here 2017 ucoasxxzhdtjdemkmeoagirrrnjppzseplgqwkiwuqmviagr
 * Smoking Wheels....  was here 2017 gvgxavdyefetthavlafrehgyzsciycxdyucatrmtkzvlwanb
 * Smoking Wheels....  was here 2017 igqpehmxwobzmxiifunwjsqzupvsmsfcjpsvomljosauysmo
 * Smoking Wheels....  was here 2017 dxnmjhfboklcrnwubklehtkgqrubuokcoakzbgzmznkljden
 * Smoking Wheels....  was here 2017 ctzfbzaxuhkjzzlgrxjmpuklhrkwtsknkksqdrgarltdfqtn
 * Smoking Wheels....  was here 2017 wvhqyusdiwjicizbztuaipvnsphyjnmyzklebrogyrwxustk
 * Smoking Wheels....  was here 2017 gnazzklsfgasfwrwanmdqbxtgrkianbftwpfflpphtaarfwg
 * Smoking Wheels....  was here 2017 mmxqjtmvrphqpfclgbnmyjinikxgfmykhynsiketkloatecl
 * Smoking Wheels....  was here 2017 woafnanafljhvcyxhofzzyyqtofgwncwnyrvjhjtkreszxrn
 * Smoking Wheels....  was here 2017 cxrqeqjyqmpfspepbhbtrmvzoczcyxsepoyxmyoumsubuacj
 * Smoking Wheels....  was here 2017 bvjbgicpwurfjbacqzwghyjuyhdwwehfvpireqjhecpjsgba
 * Smoking Wheels....  was here 2017 vaywzzedhpoicayfklscemdolqvvefoayfdyctqzgnyforow
 * Smoking Wheels....  was here 2017 wiktuuccijkvlgtdbuwecnazwxnlranytuwygzlvraohlrvm
 * Smoking Wheels....  was here 2017 tvbpjetetvpehwicmkvrztcaeawomykplyjauhectvjrrsir
 * Smoking Wheels....  was here 2017 kzmnrwgipaugrezttylzbdswqhtdwnqvkmrxfvlezlmququp
 * Smoking Wheels....  was here 2017 yikzytztdezaysexhfttsunbtejnlnarfqbkeacvepjsqmgn
 * Smoking Wheels....  was here 2017 utxppamxvugtqgpqskawsgifilcfzcmovrbspogaghrqipwc
 * Smoking Wheels....  was here 2017 nkhhidronqczpyhjzvvnzchjicrzqlgzihmgtkfynuhmdned
 * Smoking Wheels....  was here 2017 cqbectqqdqcnxzlpddycsistbizwrfwvdijrbsqbmolnqbws
 * Smoking Wheels....  was here 2017 pcarbusjzcgjwanepfkfjdgtzsedsezexxavfyjdyjnhrhyf
 * Smoking Wheels....  was here 2017 lqgmtmmfonsvcvhgadnvpwsdxysinjrjlkyydtnbwffnimpe
 * Smoking Wheels....  was here 2017 fialugwwqqvjjmschhvakifwubfefdbazkzicbkcnikgyfjm
 * Smoking Wheels....  was here 2017 wqwtetyifkjvugajoichziddzgpucbsywvetmcrrlfgvaize
 * Smoking Wheels....  was here 2017 ndotbxbtodefrtswdckfuebkxbcjuwhgsuuazgeoipfrlvjq
 * Smoking Wheels....  was here 2017 nrfeyyvsegmuptnrtsasmevliebmarvflqjiqgarhnyqhbul
 * Smoking Wheels....  was here 2017 okbwnhdvvpqbjhkdfpnzbdpeirexyuonearboangnfjtvosl
 * Smoking Wheels....  was here 2017 mrqzrpabobixbspvshrjrxrudtjrwtxyhuvwfsitndqgsexs
 * Smoking Wheels....  was here 2017 lduysuwspzmfbpoqqrnnursvfxvajkrpkbbrhtgwcberrxho
 * Smoking Wheels....  was here 2017 vqnkzdhemuhjwsbqpyjjdxnxkwyngttvmfzpuxlqgzquwcdq
 * Smoking Wheels....  was here 2017 hidggzdeygewicbdmkscqhfcqrjxpdmfpwhcwzgegezrphyt
 * Smoking Wheels....  was here 2017 rnerkanrzktmndvtkskamsdngoagtdgodxcuahhaociokija
 * Smoking Wheels....  was here 2017 exlasguyxkyfuiuivsmwdkyrsadugmvaulrowejwzmdzdfmt
 * Smoking Wheels....  was here 2017 ciyyouojfvzjrmrxinfnhulhvubcziexjvopkjqrnjasxiln
 * Smoking Wheels....  was here 2017 ewakscrrqkfmasmxuoddxouinvmxyyovbsogwukrlzzuyetf
 * Smoking Wheels....  was here 2017 fyenbvgxfciixgmwkjcbdphadmihmwlogysgqpihhucnxoex
 * Smoking Wheels....  was here 2017 jegrwyqefehxqrcpmxbandnteetmexohnrillgghtpvjpoqy
 * Smoking Wheels....  was here 2017 ckfnmrkadefnuwcgsgjxrpliiqfaxewgvgxzflgpwjwebmkw
 * Smoking Wheels....  was here 2017 yulasjmcstnreukeztovprbrsxisqxpdhhghfcslxjcxqxyo
 * Smoking Wheels....  was here 2017 vqkglsylazxeyuiwjbkflhuanfanuthshrlavkfhkbswypad
 * Smoking Wheels....  was here 2017 wryrwscfgbgbilhhiazsspfvhbmuxkpclotbttrvcecptqow
 * Smoking Wheels....  was here 2017 nrcxmnqxymuoynblmuogcbeutfcauanpqgsozxcczuxwdjvj
 * Smoking Wheels....  was here 2017 iudwyoiexbwfpdprstsymkvwyqpznwiwbjdyrsxfjcdrlhhn
 * Smoking Wheels....  was here 2017 gkqsfmiccsevjodpdmefdmmidovsmmmsawaviksssowjgfrj
 * Smoking Wheels....  was here 2017 kdjvnhauttqkpidbevasmnspunamdsrfgusdokihvzokjgzh
 */
/**
*  LookAheadIterator
*  Copyright 2010 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First published 04.02.2010 on http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.util;
import java.util.Iterator;
/**
* convenience class for iterator implementations that naturally terminate
* when the next() method would return null. This is usually implemented using
* a next0() method and a wrapper for next() and hasNext() that evaluates the
* latest return value of next0()
* To use this class just implement the next0() method
*/
public abstract class LookAheadIterator<A> implements Iterator<A>, Iterable<A> {
private boolean fresh = true;
private A next = null;
public LookAheadIterator() {
}
@Override
public final Iterator<A> iterator() {
return this;
}
/**
* the internal next-method
* @return a value of type A if available or null if no more value are available
*/
protected abstract A next0() ;
private final void checkInit() {
        if (this.fresh) {
this.next = next0();
this.fresh = false;
}
}
@Override
public final boolean hasNext() {
checkInit();
return this.next != null;
}
@Override
public final A next() {
checkInit();
final A n = this.next;
this.next = next0();
return n;
}
/**
* a remove is not possible with this implementation
*/
@Override
public final void remove() {
throw new UnsupportedOperationException();
}
}
