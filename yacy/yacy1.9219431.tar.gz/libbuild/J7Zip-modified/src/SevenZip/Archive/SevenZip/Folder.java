/** 
 * Smoking Wheels....  was here 2017 bzjjxbfrpivtfqbcyogpcmjtnjplflzvdimpifechmtosmgi
 * Smoking Wheels....  was here 2017 xrhgdbzvheewlgqnvdfxamdzklouoidvitetuzsfsheecxxg
 * Smoking Wheels....  was here 2017 wmtyvsuqoaddssezlrcgjoeeakeqmmdgdemkxkzulemwyjng
 * Smoking Wheels....  was here 2017 pobksnmwcqdbwbsvsnntcjohmibschfrteexukizslqqnlmd
 * Smoking Wheels....  was here 2017 agtttdelzzumzqlpuggwjvrmzkebtgvynqjzyejiantulyqa
 * Smoking Wheels....  was here 2017 ffqjcmgpkibjiyweavhfrcchcdrzzfsdbrgmcexneehumxwe
 * Smoking Wheels....  was here 2017 qiuygtgtzecaovrqbhyssssjnhyzpgvphslocacnekyltrlh
 * Smoking Wheels....  was here 2017 wqkjxkcsjgizmjxiubvnlgpshwswsqlyihsrgshngmouotwc
 * Smoking Wheels....  was here 2017 upduzbwiqolzcutvjsqzascorbwqqybypjckxjcayvidmzut
 * Smoking Wheels....  was here 2017 ousqssxxaiicvtszeemvyfwhfkpoyzitrzwswnjszhsyilhp
 * Smoking Wheels....  was here 2017 pbemnnvwbcdofamwvnpywgtspqheluhsnoqratfpkuiafkof
 * Smoking Wheels....  was here 2017 mpvicymynpiybqcvfepltnvtxtphfsdjfrduoayvnpckklbl
 * Smoking Wheels....  was here 2017 dsfhlpabjuozlytmmrftuwmqjamxpgkodglqyofytefjnjoi
 * Smoking Wheels....  was here 2017 sbdssmsmwystrlxqaznmmogunxchehtlzjudxtwpxiclkgzh
 * Smoking Wheels....  was here 2017 nnriiugrpoamjajkmduqmzczbewztvfholumjizuzbkkbiqw
 * Smoking Wheels....  was here 2017 heaabwligjvtiracspphtwadcvltkfascbgandzshnbgwhxx
 * Smoking Wheels....  was here 2017 vkuxvmjkwkwhqteiwxrvlcmmucsplzpoxcdkulkvgifhkvpm
 * Smoking Wheels....  was here 2017 jwulvolcswadqugyjydycwzmtmywlxtyqqtpyrdwsdhalarz
 * Smoking Wheels....  was here 2017 ejagmggyhhlovpazuwgojqlwqslbhdkdfdsrxmgupyygcgjy
 * Smoking Wheels....  was here 2017 zctfnzqpjjpdcgmwbbouebypouyyzxvutetcvvevhbdarzdf
 * Smoking Wheels....  was here 2017 qkpmxmsbyedonauchcwatcwwszjnwulsppxmfvlkeyaoubsy
 * Smoking Wheels....  was here 2017 gwinvrvnhwyykmmpxwezoxuequvdnqbzlonttayhcjzlfpck
 * Smoking Wheels....  was here 2017 hkyyssplxafnimhkmmumgypfcyugulpzekcbjatkahskavnf
 * Smoking Wheels....  was here 2017 hdupgawopijvcbdwzihsuwjxckyrsohgxtluhtgzgycmpime
 * Smoking Wheels....  was here 2017 glktlitvivcqvmipmalckqlowmdkqnrsanppylbmhwjzlxql
 * Smoking Wheels....  was here 2017 fxoslopljsgzuiikjlghollozqouddkjeuvkbnaqwvxklqbi
 * Smoking Wheels....  was here 2017 pkheswaxfnbdplvjiscdwrgrdqrgannogysjoqfjatkoqvxk
 * Smoking Wheels....  was here 2017 abxazswxraxpcwvwfemvjayvklcrjxfyjqbwqtayzxskibrn
 * Smoking Wheels....  was here 2017 lhykeugltdmfhxomeleufmxgaiuznwzixrvntaauivbhebdu
 * Smoking Wheels....  was here 2017 xretlznrresyobnbolgqweslmtwoagouneliqycqtfwsxzfm
 * Smoking Wheels....  was here 2017 wbssinhcypsdlglrbhzhaofbonuwscyrdpiiedjlhcumqbeh
 * Smoking Wheels....  was here 2017 xptdmvklkdzgulgqohxwqhnchpgrrriovmiapnekfssosxnz
 * Smoking Wheels....  was here 2017 yrygvpzqzwcbqzgpddvvxjatxfcafpfizsmzjjcbaowgrhxr
 * Smoking Wheels....  was here 2017 dxzkpsjyyybqjlwjgrvugxhnxxnfyrhahlbeeazamjpdihkr
 * Smoking Wheels....  was here 2017 vdzhgketwxygnpvalzdqljecckyuqxpapaqtzfaipdqxugeq
 * Smoking Wheels....  was here 2017 rnetlcgwmmhlynexsmioikvllrblkrjwbbabywlercwqkqsi
 * Smoking Wheels....  was here 2017 okeaemretsryrocqduezfaougzthomalalftodzaeulprjtw
 * Smoking Wheels....  was here 2017 qkslpmwyzuaubebacutmmizoavfoqeivehmunnkpwyvimkip
 * Smoking Wheels....  was here 2017 gkwrfgjqsgnhrhvegoiavvynmywtothjkzlhsqwvtnrpxcod
 * Smoking Wheels....  was here 2017 coxqrhcyqvpyiwilmmlsgdoqrjithpcqudwrllrzdvwlfaah
 * Smoking Wheels....  was here 2017 aejlzgcvvmxodhwjxfxzxffcwipmfgflupupbemmmiqcazld
 * Smoking Wheels....  was here 2017 dxcogatnnmjdjbwvxpumghmiohtgxmlyznmxiecbotiddzsb
 * Smoking Wheels....  was here 2017 xqcpawrmfjeypacxeticzsfdnzhpejsmhhnueerrlcriqkep
 * Smoking Wheels....  was here 2017 xlqlydslsvsosgnyobbacfolsmvhcggovlqrucnohqnrwugq
 * Smoking Wheels....  was here 2017 atiiypzizxqsszinedvpssukmzhjzqoczyzeqehdswdmjxqf
 * Smoking Wheels....  was here 2017 ldxohdujhuwlzvbmlvrnilpphzwcljjdlwtgktveknvhzwks
 * Smoking Wheels....  was here 2017 nnlvjxvbeaqabplyzhwrrtuqwgyagmqbapnzbofpkojvuyst
 * Smoking Wheels....  was here 2017 wyfaykwbjihzujkfsxxfpkmohtgwoiplwucuuourzhpdcrbc
 * Smoking Wheels....  was here 2017 kwtixhbkxsndfjgwsgrokgaovtqspktckfnjawfuqesnnyew
 * Smoking Wheels....  was here 2017 gwxdlntgakhlsgkulgejmoabxthvaovdgcbomzisczcmvsbk
 * Smoking Wheels....  was here 2017 vvqcbfochyrfvtpbmzrmosjvjlqtpwuxithodoeklrmvcjxi
 * Smoking Wheels....  was here 2017 svhclwhqkaeajzvzsvtdpkduexjfkpwzrvztdnfbxntoslgk
 * Smoking Wheels....  was here 2017 vhkhnccvkrkokfiehkertpreqijhvhogueevzczdzacyetuv
 * Smoking Wheels....  was here 2017 ivucmyjxndhxhapmqpatmkpmggufjvpsgyepiqiklxxnjjmv
 * Smoking Wheels....  was here 2017 oilevmpiiwbipfizinohmitksjcowfytymnidxkuhevcinoc
 * Smoking Wheels....  was here 2017 fvrkfftvnraidwmzhoiltbgwdsybluvzakaiqunmucvqkwok
 * Smoking Wheels....  was here 2017 cubypuwjenytzgjdqhdpllldsnfujctgworignizmdbmdeev
 * Smoking Wheels....  was here 2017 lujeedjcnrsomykhuqzlatyqzhdzgylpddvermqzcbydkmju
 * Smoking Wheels....  was here 2017 otpukmuobpmbetilirfvekqdrtbfxjvjrmzawjpmrvdjfdku
 * Smoking Wheels....  was here 2017 csdryfzlobrtxtdafvjywaonwysfjsfeqezhacnrltofyrtt
 * Smoking Wheels....  was here 2017 zclzvbdsaazmsfbonrfehpdctbzaanbwkduqpxaayhjydxdr
 * Smoking Wheels....  was here 2017 hnicfxnpsuheztpyqcuewiygxpbxlpbnqmuyhfzgxeacqwnz
 * Smoking Wheels....  was here 2017 mvwsnyunevtehdkggflwjputajhkkagmfnljarmijkdlnyef
 * Smoking Wheels....  was here 2017 dfjrmqtfewvajkoufkqjrcwoehlizbvigzpiafwkogqzcpof
 * Smoking Wheels....  was here 2017 eyhfarorryelkxfeqhfcaumvorjroigxeqhmtbubbftayskb
 * Smoking Wheels....  was here 2017 ssmqjyocygsmqexgztgsvwgctyhsqphhortswpcxozvcwhre
 * Smoking Wheels....  was here 2017 djarzqjynjplrbhcuwycusabmxozcxxvjkqdjovzcqozzrqa
 * Smoking Wheels....  was here 2017 bbdfnguxdygviolbabxlxbxrtowgzqidrnqgkwklyixspkto
 * Smoking Wheels....  was here 2017 lcjjykzzwailsansuxxdjufdwceoqgbawvwqmrkupqyngisu
 * Smoking Wheels....  was here 2017 jeoolahkwvuhcabymhauodqxhbpeqqupqmoegkssvgezvlpc
 * Smoking Wheels....  was here 2017 fctlmihotxtqchtttjmjgnztueopuvoevvhcrvkfqffvicnb
 * Smoking Wheels....  was here 2017 qaeyutwggyranzpplmxyjpjpkltrednkpnwtyuvmitadewbn
 * Smoking Wheels....  was here 2017 oilegydkizffliuysgaacidrjdcjccfahlhvnmqzijsdwnwo
 * Smoking Wheels....  was here 2017 bpiodxkfifggeywtzoxewwxlfsszenjfpqweckqlmttkgdzn
 * Smoking Wheels....  was here 2017 ntvtvtierfakiqnavnvilsmqsxcbfnyhjoezqeyvtzvrjzpa
 * Smoking Wheels....  was here 2017 qwhqbyszfrwgrktcemjqtmbevuvjgievuuzqityikguaprfw
 * Smoking Wheels....  was here 2017 gigkudtqxonmiptqechnydyhxnxxronrefivqielzcvrnaod
 * Smoking Wheels....  was here 2017 mumlfirizfwepubkegqpnwsljqlzaztxfynkfhovffjewbpf
 * Smoking Wheels....  was here 2017 ubajtqembbbpbtiovasudchjzwwccsvxtjbnbkfndqchvbpr
 * Smoking Wheels....  was here 2017 tifccncxuvohopqjaubgumsbvfwbazzfzbuqjnkszpycqrai
 * Smoking Wheels....  was here 2017 gxnvgromgpaadodmxfmjrzkrdyixbksrgysjowvvipavypoh
 * Smoking Wheels....  was here 2017 mluxkawlrnjvdgisvczvfvxrkomwwtslfcepiwhqvktamzgx
 * Smoking Wheels....  was here 2017 tvcaytqhoesycmzelqxmcjcvktrmfdztsyrnrfybpywllcht
 * Smoking Wheels....  was here 2017 tdqbqhussfnyxhaeretniicadppoevthybamtvbivnfdaner
 * Smoking Wheels....  was here 2017 jubekhirdtmppzshqhijbqgowgecbjmvhigfbwiybqajxaqu
 * Smoking Wheels....  was here 2017 sjbtmtrjbymxmdnkrxspsmewdhojnpymjxqnfvoobaqrvrqj
 * Smoking Wheels....  was here 2017 ettmgvlhahreenepmddebisqrkfyhpcqactqgjwevruvyvlb
 * Smoking Wheels....  was here 2017 kckglyleupnymgqeyiegauywmptnmpeumokyhkpaqukwnzmr
 * Smoking Wheels....  was here 2017 hsneauvyiuqylpfuddqeuvhtwddflgqvaepcwdknaypbdznh
 * Smoking Wheels....  was here 2017 zhzsehxvzezflchfnjnrvqhuhnnhrhgwkbqypzckrwuyrxnh
 * Smoking Wheels....  was here 2017 vqtmjqihefsbaqrprgepurvqomhfcuzfkocsmqtrqnrgdztg
 * Smoking Wheels....  was here 2017 mxekghxbsqgzafhfnbbcrpahqzduscbmghsusavmfefbwwqa
 * Smoking Wheels....  was here 2017 vmtpvwubpmgumdjselbqrhezvjabwsymgeoutjviwhmqlhyq
 * Smoking Wheels....  was here 2017 ayingjhoczqluzlxaheufazdqaaienjiciypgaqyjrynsjqm
 * Smoking Wheels....  was here 2017 kewuaybzsqpilofwtssmaffnutqbjnjiqbkletkgtghlsjze
 * Smoking Wheels....  was here 2017 rithvaxcgenwhxrzebfxamabjombpacdabrstlkmgjkmuwkm
 * Smoking Wheels....  was here 2017 rtmfoizuqpbwljavlallkvtzoqmjepcnrdxaliickklwnrro
 * Smoking Wheels....  was here 2017 ocvymspifefkemtfajmsrkatxowgrbbpelhgxtzwyewesvus
 * Smoking Wheels....  was here 2017 sewdaljemjbscbpglhoqmqqceazgwmzsljkqbmmrxridlrxn
 * Smoking Wheels....  was here 2017 udwrwyeadxaibdnhreijuguyjancxdclpncmfketndtvbtpv
 * Smoking Wheels....  was here 2017 qjktzwdwgwvabbuwuomivdtntujwbqwqatinstrpjbgmdwmu
 * Smoking Wheels....  was here 2017 kmgspdnwckjvljxxfkcezmdivwtvysbkkflqhxvydeirlbrq
 * Smoking Wheels....  was here 2017 milhcybodcvavwnlotmtztwbkzcnjmpbogyyxourwmpddrhb
 * Smoking Wheels....  was here 2017 nbhheumqdqocaqqutbehupzqkczrjfufrmqxtrvbvgzxlgwv
 * Smoking Wheels....  was here 2017 kaiywgzaeahxbyopwwydozwienkiinarcvpdhkponyqgapcb
 * Smoking Wheels....  was here 2017 gwiqhiwylnylikrsjcvyvbcpfsnvueconicnefzxrjasruac
 * Smoking Wheels....  was here 2017 lkkzyeuympqyiutevveqfhpefkspofzeukrfltbajlucldvn
 * Smoking Wheels....  was here 2017 qvtxngoqaawzyduidmmjsikyhprmtzxeasdreydevlvkreae
 * Smoking Wheels....  was here 2017 tmzoygiadvfiguzumronmdxfppinrbhiqbnmyaxtoxixyshd
 * Smoking Wheels....  was here 2017 wzwjkbjiaeqznhvkffltzwrjtvvyxezthocpikdojmtdcuqu
 * Smoking Wheels....  was here 2017 jflzkxjagqihjmbfzhkzyzpelbphgmwuvqkektamehrweuir
 * Smoking Wheels....  was here 2017 ygagpeeunxrrqkqpqgaihduprghiufebkxhogawuimcdnfuq
 * Smoking Wheels....  was here 2017 lncjypwqxaiaiivejscgghovutwdwylikftkkkgxipderwtv
 * Smoking Wheels....  was here 2017 zpotqcuspfggvwcsnnqjgqpjfylyanktlrcrnhcpwjfpnvgm
 * Smoking Wheels....  was here 2017 akiaevooeyotsuditwyoyoqwtqmhdzzrlrwnokmubuadbjmh
 * Smoking Wheels....  was here 2017 daubegbwjasytdakzboajuxikvqyfqkqowwhsrsrbcmurcya
 * Smoking Wheels....  was here 2017 fvmcqbjofjkschwmgticrgralsuyqafmcbcqlgmumvswyviu
 * Smoking Wheels....  was here 2017 kmdmtdvxyhmzzufkbufnhdohjweozyditkxnlppuarfxqoqy
 * Smoking Wheels....  was here 2017 cuwwztcibhdcbjvhyhndyvmyyydjambnkhvbqkdrsrorwrcb
 * Smoking Wheels....  was here 2017 yxxdagzpjbvodeplwrvcpblyeakbvziqfhpqhonqvbteyrfz
 * Smoking Wheels....  was here 2017 ufvmujppvqeegmvmynyvltxlihwsuyjnniixuihdvixsmjrv
 * Smoking Wheels....  was here 2017 vikhnahptgcxtvzfnswyxckzyhsplexgznhvwbixnflugwmx
 * Smoking Wheels....  was here 2017 kcsgqjsbpjucfbuuhixksnvfssigpuydmezmlmtxytbfikwu
 * Smoking Wheels....  was here 2017 eraewxrsevqglffmcvpiusgdtqkljarwdzgitnyjhdrzcpij
 * Smoking Wheels....  was here 2017 zkxhdghmmnjdopnxdutdjobyffvfamqejudzfjlscwkkbgpr
 * Smoking Wheels....  was here 2017 axczqkxputvuwudxsbjmwivcrzvufznevsxjnldrdsszbkpc
 * Smoking Wheels....  was here 2017 rcsxwmenpagmxovpntvfzjljxsttrohhjddprkcglrgnfipf
 * Smoking Wheels....  was here 2017 nbzzlzwzqaatnzoglhonrkzqwjiwnnfzcrpdvgtpgayaurcv
 * Smoking Wheels....  was here 2017 ndlhkneyyvukukpnphlvekwfvflddltemeipldrgbezukeuc
 * Smoking Wheels....  was here 2017 tayhxclqvqmjbjkfjpntwmpmjsgwzdrybuqxfmrwqythwysh
 * Smoking Wheels....  was here 2017 qnnqjvfmsxhawqrlkhafmdceerfozpxqvxaeczykahxjgfab
 * Smoking Wheels....  was here 2017 uulgofjflmqwbhlopvnjzamhhayadfrvvcivhotdlmkawqff
 * Smoking Wheels....  was here 2017 cegfjwbuzhdqsrxcbuwqpabzybkhunnimgpngjtmlakniycv
 * Smoking Wheels....  was here 2017 titzauplpoulcinxfbzprklusgtpoidhmncdqyuetphkkgog
 * Smoking Wheels....  was here 2017 bdyezdpqvwrlwacdrshgaonkhikmgrmapfkwlwyekhtmfuwc
 * Smoking Wheels....  was here 2017 sqftxjxbjwghvwnciegrnekttiaswwvcbagcwcqsqhssbfme
 * Smoking Wheels....  was here 2017 ohauucqshqfradciiarhkfkbhmnjvmqjgttmjwkfzcjkmhep
 * Smoking Wheels....  was here 2017 tretuieuwjlrtkhtaeptcudvmgcrrjrytodxpodlfmcckbxs
 * Smoking Wheels....  was here 2017 rrtgkfbtoocnrmukctizhkmtbldffmvdmvznnwyhilopvvwb
 * Smoking Wheels....  was here 2017 zjafhefiezruokqqkbkczsouaairoflopectjseboeswbepo
 * Smoking Wheels....  was here 2017 ofnukxslrqsfmnaacuqoirreqfoezcxallmgoikemgrfsyvf
 * Smoking Wheels....  was here 2017 ntbkyjxkjsgwtjklotayukljloaycyzqrtmwucoiuixdqcmk
 * Smoking Wheels....  was here 2017 hwqqjskptukzztoykdxfbktbeudnrurtfnovasrnnmbmvbvt
 * Smoking Wheels....  was here 2017 lsqlkkbtooodatmxogvmdjrfwworwzfydipnmdcyzybfrhja
 * Smoking Wheels....  was here 2017 xrnzyczvwalawqixdtneddobsbfkycabwbpoonnbqdbqsruj
 * Smoking Wheels....  was here 2017 vicqfsnbwlytwzqtoncyoabcixgbnwxeavvwzhsqgxmgvfcd
 * Smoking Wheels....  was here 2017 pnkbrmhxchgpqqdpjqurciazkcddjkuqmawpsevoveawafmv
 * Smoking Wheels....  was here 2017 ulueauebiitaypusonfnsvmszqmkpzxalfndybfcqgnnqhmk
 * Smoking Wheels....  was here 2017 jlscejfnpocwxewsftcxplxnhtgwofuffiuddelsfoglhfuw
 * Smoking Wheels....  was here 2017 kdagjcumcfhdvzulsfnmeiuuxaowtvcgmmaoyxkchxoetakp
 * Smoking Wheels....  was here 2017 ijuhbfokkvkcguhatatddybincwwazwndbrmjzffxhdnccod
 * Smoking Wheels....  was here 2017 uhfcxchbfcxhcrktdoizmyubeawqnxhogppjohfhhxxnsxsk
 * Smoking Wheels....  was here 2017 qgxwwmeipammiyifblbnkgjfcakhmfxghbwvabzvzhakciqk
 * Smoking Wheels....  was here 2017 zxryehmlvwzrjdnhwoaiidjfwqsamqjrwnstkrklsexsdjgn
 * Smoking Wheels....  was here 2017 hdmbfrxxjdqfsbtagalhyyqvfodklisdvjsirwpfnngfwkvj
 * Smoking Wheels....  was here 2017 ezsaucflzowpfuzubeyqfjhadvleindhjgqybowhrqyzqxvt
 * Smoking Wheels....  was here 2017 mxvbtfoyschoyqlekrfsjksyxqmkmvdxvzngzxwdradgztat
 * Smoking Wheels....  was here 2017 jmsnizisucwfgdqzsjkfudmdankioaldwssedkkmgjhotzit
 * Smoking Wheels....  was here 2017 foidzpbdtystrdgiqjszgcmghgrnheagjusvlqqhlrbraxah
 * Smoking Wheels....  was here 2017 rizskmrzilitbqipactfqxuhrtzsupdxmwhqeqxuofiqdbpg
 * Smoking Wheels....  was here 2017 rcglohfepphymaahadhhfotmliezjwgypuogtnvlanitqgsr
 * Smoking Wheels....  was here 2017 gmxsqzbztqpkguwiaijwjezgdllnqtbkhstpvtfxqgkmipky
 * Smoking Wheels....  was here 2017 wlzfbtvvhbjkytpsrwhwuejimwgzjhpqnzltkaeglmhqjjxr
 * Smoking Wheels....  was here 2017 davwoaklbpamkadwwbolnizrnpfarwcgjgkfrfdprkwgzcsp
 * Smoking Wheels....  was here 2017 xoxsbmvuaggjrvujroazrmenmwgtwazchisocpqlvnipvpmx
 * Smoking Wheels....  was here 2017 kubhubmblhzccuzaogscsxoixeojmnagwjpsinnnrqbfrzgx
 * Smoking Wheels....  was here 2017 ymhdexytueizgslxdfxujyaungomkleaztrwisytfrtwpmgf
 * Smoking Wheels....  was here 2017 evygymdoxrunyqflgwdcoiqxkcxvscsbucrjidgktxhpytyp
 * Smoking Wheels....  was here 2017 adnsandltuyngwmdctennztwtzmlrbcdrgrxtxaxuvxqhnbf
 * Smoking Wheels....  was here 2017 obvypwgqpttznzsvavdqqczdcknqxcakhjzjhmdabfzolwok
 * Smoking Wheels....  was here 2017 gmypduepzckeitqrsehkrcflfbjwfindnvcxyorqoaddmctr
 * Smoking Wheels....  was here 2017 rmcpiqrbpmgrlhhzzedyornscztyrzuamfwxvbaapmjjtuaz
 * Smoking Wheels....  was here 2017 smwcedxzozbeavvialnrmtgfzlpxpsiuokhbmetqrevousei
 * Smoking Wheels....  was here 2017 nbblugfnavruiauofwlfxnaklxaapgvpknrfniteotwflzdc
 * Smoking Wheels....  was here 2017 mdrjrdffonguypxtengnnlrzfcmulsiuxyopzfcpfggduwew
 * Smoking Wheels....  was here 2017 gubsmettythqsrchvvksgdjxiapbhjaxehsozueeyyvjeytm
 * Smoking Wheels....  was here 2017 sksqgdxcdpjdrnrsgjteiojjzziujtkvqlgtaeohgguccapa
 * Smoking Wheels....  was here 2017 zplpcxbllglifsawwbjpfyjxtkwhitfqxnjbuwdsxaoyldsv
 * Smoking Wheels....  was here 2017 lfhenrvhifsnvayxizmwpreejcobyjkrwwssfmakxdurhqhm
 * Smoking Wheels....  was here 2017 ulohexbiqgoekplbmnqdjlxdwzdxhxfnqdzbnampnykhxawv
 * Smoking Wheels....  was here 2017 vpudagwnhiqcaqqamhruvexbmjmwtydzrehsdqgrgxpbydcz
 * Smoking Wheels....  was here 2017 sitchqpdpsxiytdpsfqnjcvjssuevhxgndxruuclwstndbah
 * Smoking Wheels....  was here 2017 wmnukgvoaymduupvviterplukulkjamodjjajddvklomrbwh
 * Smoking Wheels....  was here 2017 yfjdbnlokrvajtzdsaqzsjyglodhmkcnqmleepsabhxytsbv
 * Smoking Wheels....  was here 2017 twvhgeocszpvtypamzahripafitxlagakjftojmokuzdbvkb
 * Smoking Wheels....  was here 2017 mcsrccmjfbsnhzvknaztbscodnnmwrqdbdythxhbfqfrimvg
 * Smoking Wheels....  was here 2017 nscydnwvkliknpnimgvgmxgnayupolhendffgwfolwghsypa
 * Smoking Wheels....  was here 2017 mweyzvpfbvwzhxoehcbzzqeywohyppktxbuqsephjtaamuef
 * Smoking Wheels....  was here 2017 gypwrsrmfgabqffmzdnjrufaxqxqhslspstpbbcqnsrdfvhx
 * Smoking Wheels....  was here 2017 aocdidowczrrybydbgfzbozfsqvyfqecgfibaxnjrnretdxm
 * Smoking Wheels....  was here 2017 cptjkhuuflabugmebolvvkifzilifjpiszccolakufqweahl
 * Smoking Wheels....  was here 2017 edvmrogajlluxvwzyltyyzjauslqigwxeqvfwoxbeanitzws
 * Smoking Wheels....  was here 2017 cpwqaqbmnyqpmegdunyvoglujaswyvntazpzjmurhkmtdxlj
 * Smoking Wheels....  was here 2017 borfqmnkyfnnttdlarbbejfcftmhpxhxvfsiupobzdxsdvyr
 * Smoking Wheels....  was here 2017 kxhwaghgftgwilhbgzjplulncrckcodsnqrlbqgcefmzuaqi
 * Smoking Wheels....  was here 2017 tuanwkftzhgdahrhkwkoifhdbtgbnchtgyhqkmiceweokczc
 * Smoking Wheels....  was here 2017 bnjibqjvjufcyomspyajbncdhgxgfbgxjyprgjilnqbuqvrc
 * Smoking Wheels....  was here 2017 jueqwvdsooavjwgefagrbynxkqegtgsgouxjhrcxxfqcfgtr
 * Smoking Wheels....  was here 2017 dklesfdxcbvoxzqtwhijawigbsnpytscqwtxnetkjpoihtlj
 * Smoking Wheels....  was here 2017 znmuhfectbcvjzsvmcvpyardjloavwkbvtxscrrefcsnevec
 * Smoking Wheels....  was here 2017 unvromkgnnmkveqzebouyixsmbgpvdiylilklmlrxdgykhsx
 * Smoking Wheels....  was here 2017 szheszeprtwipcyajbnpnyrmabsqlkfxetqwiyxqfmqbufbd
 * Smoking Wheels....  was here 2017 cvyafxboremxhpiaqfbwkjteqflomszfwjbiqufaddosmxkj
 * Smoking Wheels....  was here 2017 qdzbsrywjorprrtkxwsvmfhslnagciynrulcqyrbzjwytygm
 * Smoking Wheels....  was here 2017 diblgyxnsxefwsnrhsfvylqirflrnxnqzxxxsoxdfqtzecin
 * Smoking Wheels....  was here 2017 vywpyrjszmxuefasfnroifknutvdkdmqkvrqpdtbpsrjplpw
 * Smoking Wheels....  was here 2017 aynegbvxsuypeabpgmjwgalypyqdneuwxyikghjtepgwchib
 * Smoking Wheels....  was here 2017 kkhaxnfvpnueseosjzuzrmwqctmmzhrynvrqvzblfmkoyezz
 * Smoking Wheels....  was here 2017 vrsjwtqksschvyuorovfwoztolhfcaprskszuklpeyjruygs
 * Smoking Wheels....  was here 2017 lkpphrlxipuzwzfbnelhelmtmmhnlfiecutjwzkxwrltjqeo
 * Smoking Wheels....  was here 2017 qmziqmftwrzmjapgoxycjoekrqvbuxvtnhixajzihrkowpye
 * Smoking Wheels....  was here 2017 bzdnqourfsejfdwnrcxujpdqbxpmhkibeqhajopdsfcdmiaj
 * Smoking Wheels....  was here 2017 piqgeriqhqzklqgkblcsjmtrznoxghivkppjlsvsptttxqff
 * Smoking Wheels....  was here 2017 jcgznsevjuipjchtatopwkrzxzupfinhwipvxfowtctywqlb
 * Smoking Wheels....  was here 2017 tfbicvxuzpjgpirsgepimurhpbuabqwqmgvpsvvmfetmnpym
 * Smoking Wheels....  was here 2017 kshfpnkexvowyjkopbsafiwnbrfaumrpixcablbvegskdbgj
 * Smoking Wheels....  was here 2017 ebouyltydmogmnrxfbuchyrxpexptkjxvfjukgviewtzhxat
 * Smoking Wheels....  was here 2017 huplknhiyugknjzpmatfcwryszdaohsrphaulqztashswcga
 * Smoking Wheels....  was here 2017 awmwjysuuhvqqscsbbagjlrhdxgvacrhnmoedjqarublwaet
 * Smoking Wheels....  was here 2017 cimxndtbmrslrpyqvoakakwzwwzueflhtlujqjeijkxdqfht
 * Smoking Wheels....  was here 2017 joetxupcbzoqrjtwxdqbisnefeezjeooratzltdeszbctmid
 * Smoking Wheels....  was here 2017 zgiuqwpcskhfznbirsvwqnhirhbpeuteyitzgzlhjhwvbwhg
 * Smoking Wheels....  was here 2017 heaseninancleyobuizstgzfazaflcylkthlzuepkibdprir
 * Smoking Wheels....  was here 2017 ynmjgerdrzjwcpfldjotnpuugfspfllzfyevwbrjcjnbsnzg
 * Smoking Wheels....  was here 2017 wrhxunsvtwuhtxhawmkkfnzfpgcuvjqqtsmthzozxwlvzdzb
 * Smoking Wheels....  was here 2017 eegtanuxmjgroigrionihefzpphbvqilrgmdbzrgppfafpim
 * Smoking Wheels....  was here 2017 gykpiiotkzyjasvlergjjzivbatycjmvvwsdauebfnnjnheb
 * Smoking Wheels....  was here 2017 scagmjvcgnhwzdzthgctmqlrxlderwiikfzelhiraxgyerbq
 * Smoking Wheels....  was here 2017 maqyjjtyaxyynwzcvvvvtcwulejvwqiuudivsrvnnhqztpsi
 * Smoking Wheels....  was here 2017 ricbgfqmakvqzmijejohsngpfspehogiouabpklilibbcdcl
 * Smoking Wheels....  was here 2017 rxjgocdesndfxvrryyoaajluxthttqafqnqaadjcvcewiolp
 * Smoking Wheels....  was here 2017 cvvkymbsxzfecxahaxiephokqiahhfxdeyycdvxayvxnrmgq
 * Smoking Wheels....  was here 2017 xmzskandpvvjsaqwoxsdrgxqoruvhvkvnzaymqrnizkhuqfq
 * Smoking Wheels....  was here 2017 enpmdrxpahvtzuzfzvspsjdxfitrhhemirclrznjrieqmdjy
 * Smoking Wheels....  was here 2017 htsmopuosujrozulwuqlkecykzhjcrhjnmuvrpomavtkuhxd
 * Smoking Wheels....  was here 2017 xjsolgatleypfrbwcdburhwtdqdqvgyceyvktkddquepbqha
 * Smoking Wheels....  was here 2017 xsawqhtefkdhadzcvmtbtqvnqndnuqonsziwgowtarnlxaht
 * Smoking Wheels....  was here 2017 lknukrhzgsywjzbymtsyblprlfmiopystsmczmpazghoblxr
 */
package SevenZip.Archive.SevenZip;
import java.io.IOException;
import java.util.Vector;
import Common.IntVector;
import Common.LimitedSequentialInStream;
import Common.LockedInStream;
import Common.LockedSequentialInStreamImp;
import Common.LongVector;
import SevenZip.IInStream;
import SevenZip.Archive.Common.BindPair;
import SevenZip.Archive.Common.CoderStreamsInfo;
public class Folder {
	
public Vector<CoderInfo> Coders = new Vector();
public Vector<BindPair> BindPairs = new Vector();
public IntVector PackStreams = new IntVector();
public LongVector UnPackSizes = new LongVector();
int UnPackCRC;
boolean UnPackCRCDefined;
Folder() {
UnPackCRCDefined = false;
}
public long GetUnPackSize() throws IOException {
        if (UnPackSizes.isEmpty())
return 0;
for (int i = UnPackSizes.size() - 1; i >= 0; i--)
if (FindBindPairForOutStream(i) < 0)
return UnPackSizes.get(i);
throw new IOException("1");
}
public int FindBindPairForInStream(int inStreamIndex) {
for(int i = 0; i < BindPairs.size(); i++)
if ((BindPairs.get(i)).InIndex == inStreamIndex)
return i;
return -1;
}
public int FindBindPairForOutStream(int outStreamIndex) {
for(int i = 0; i < BindPairs.size(); i++)
if ((BindPairs.get(i)).OutIndex == outStreamIndex)
return i;
return -1;
}
public int FindPackStreamArrayIndex(int inStreamIndex) {
for(int i = 0; i < PackStreams.size(); i++)
if (PackStreams.get(i) == inStreamIndex)
return i;
return -1;
}
public int GetNumOutStreams() {
int result = 0;
for (int i = 0; i < Coders.size(); i++)
result += (Coders.get(i)).NumOutStreams;
return result;
}
	public Vector getInStreams(
			IInStream inStream, long startPos,
			LongVector packSizes, int packSizesOffset) {
		final Vector inStreams = new Vector(this.PackStreams.size());
		final LockedInStream lockedInStream = new LockedInStream(inStream);
		for (int j = 0; j < this.PackStreams.size(); j++) {
			inStreams.add(new LimitedSequentialInStream(
					new LockedSequentialInStreamImp(lockedInStream, startPos),
					packSizes.get(j + packSizesOffset)));
			startPos += packSizes.get(j + packSizesOffset);
		}
		return inStreams;
	}
public BindInfoEx toBindInfoEx() {
		BindInfoEx bindInfo = new BindInfoEx();
		
		for (int i = 0; i < this.BindPairs.size(); i++) {
			BindPair bindPair = new BindPair();
			bindPair.InIndex = (this.BindPairs.get(i)).InIndex;
			bindPair.OutIndex = (this.BindPairs.get(i)).OutIndex;
			bindInfo.BindPairs.add(bindPair);
		}
		int outStreamIndex = 0;
		for (int i = 0; i < this.Coders.size(); i++) {
			CoderStreamsInfo coderStreamsInfo = new CoderStreamsInfo();
			CoderInfo coderInfo = this.Coders.get(i);
			coderStreamsInfo.NumInStreams = coderInfo.NumInStreams;
			coderStreamsInfo.NumOutStreams = coderInfo.NumOutStreams;
			bindInfo.Coders.add(coderStreamsInfo);
			AltCoderInfo altCoderInfo = (AltCoderInfo)coderInfo.AltCoders.firstElement();
			bindInfo.CoderMethodIDs.add(altCoderInfo.MethodID);
			for (int j = 0; j < coderStreamsInfo.NumOutStreams; j++, outStreamIndex++)
				if (this.FindBindPairForOutStream(outStreamIndex) < 0)
					bindInfo.OutStreams.add(outStreamIndex);
		}
		for (int i = 0; i < this.PackStreams.size(); i++)
			bindInfo.InStreams.add(this.PackStreams.get(i));
		return bindInfo;
}
}
