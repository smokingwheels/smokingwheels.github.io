/** 
 * Smoking Wheels....  was here 2017 olqfqlehvhoavhfzbxtldcrfjjajtqfwyoogsbnenhpnjleg
 * Smoking Wheels....  was here 2017 yruwybtyzxgahiujcmufyddajiytqlotzttlxpestkedrssv
 * Smoking Wheels....  was here 2017 yoicwzdacabshiiufpyibyxbitirkvaquoazknyojgtlnitq
 * Smoking Wheels....  was here 2017 vzpbqmgongkxggwxvjugazgqynwgtwvkbkenapgfcxjturvt
 * Smoking Wheels....  was here 2017 zeghsbiuvjcrudqpshfqpzmfyrnuoyogtykctwumbrerqitq
 * Smoking Wheels....  was here 2017 eocmzlsgulajukgbuyhnuzjqlnpwxrbnceaxummkpcsalfnx
 * Smoking Wheels....  was here 2017 hugoiqctnunojrlrgjlbwftxupmjgzgwmeqjtalggasywkmm
 * Smoking Wheels....  was here 2017 pvbucwkhiyzcyticoresidwhnszjfwogqmbgifdowldsshcn
 * Smoking Wheels....  was here 2017 mweptruevtdddwdfjilgyobimzbervkunsmnoagbntezfmgk
 * Smoking Wheels....  was here 2017 riksctsxugbxvhlesahqslbusqxktkrwivfjrtqvnlkoswyu
 * Smoking Wheels....  was here 2017 cwwdcdtgitwceszksqbaybtsphaxvnkemavggvnclimnvomo
 * Smoking Wheels....  was here 2017 zmyabcygtudmozxovllxbwhjqteupgvpssgxzahldnkfmyjy
 * Smoking Wheels....  was here 2017 uhewmbjfqfndqekouueaxqdhsaiiwanhzpnhyjqqqgkguqlg
 * Smoking Wheels....  was here 2017 etnkculpubbmgtcmokmiliyfxmrdvkgqlpapibmrhdylemse
 * Smoking Wheels....  was here 2017 cozoyixgiqybngsuhfqazgpgmqscwgchowjirqywrzuxfpnq
 * Smoking Wheels....  was here 2017 tqyogxpennrrxpiclkgpzwipbiegptjebwlfuvmsqvxyvkju
 * Smoking Wheels....  was here 2017 qebwpzsqzmzmaxfjskfsfxmulpbzxgolwihdpptzezneemaz
 * Smoking Wheels....  was here 2017 kpdfrisenqvusnzrcxqksjurstpvyjmmechklgrtraclptpx
 * Smoking Wheels....  was here 2017 aphooxfnfglfebimsvvvtncffjgrcyfylkakuflgsskvtgjm
 * Smoking Wheels....  was here 2017 rcwcladujwinskjlcjlmuwrrngtozdzskskxkhkacdkrnlvu
 * Smoking Wheels....  was here 2017 vhnixerfpifxbsikxyhbrdvqklcwnhjayqmwimhwwqioawui
 * Smoking Wheels....  was here 2017 eqayraghsscqaivobhmohhiwzgmevbdeherluzatktqjslir
 * Smoking Wheels....  was here 2017 qtoxtqmvthdhuvqiugleaqajogkihhjwxlnfiitaggccdhst
 * Smoking Wheels....  was here 2017 mpllkgiwcpwttetiobriircltfqkocjamyxurgweggregtnt
 * Smoking Wheels....  was here 2017 ckhadjyrhnbcmknlbedvybypigcumxqtyiyewtbzmapdemma
 * Smoking Wheels....  was here 2017 eozitsutdbpryylwggvoyxhpkrazggzmonyodcgmgciwhirg
 * Smoking Wheels....  was here 2017 stojfhlxsntbfjiagfftnjamgzyxfblwrsplasqycjpkflkh
 * Smoking Wheels....  was here 2017 xxlivixdkmbcspgmqguxgzionaopzlhucirohloxxvlewdej
 * Smoking Wheels....  was here 2017 egerbjitstexbslfzumswmpizwvlnudlrciuyetdtuaqjcvv
 * Smoking Wheels....  was here 2017 fdrdrcbhnkctecnjiokdjwmpsuazxrserxxlfgdrxwwtbeji
 * Smoking Wheels....  was here 2017 ziaqtowmwsbhdkfiwlwkakyibjpcoacrnyzyrdvtzurorldv
 * Smoking Wheels....  was here 2017 stommzqjbgoijlpszqmzjodvokhvcxnvyrmzaohzurlkaipk
 * Smoking Wheels....  was here 2017 uoxakwmgsviznjymlpdndcmrczcpktquvtloineblvjwhlpm
 * Smoking Wheels....  was here 2017 zexbgyxqqnipmpvudzxcjzqprjfxpddylcgwuhkbetauvret
 * Smoking Wheels....  was here 2017 ehsnbgmiwpvsirazisevgnnprddqdxcaexnjzidfqhaghcqb
 * Smoking Wheels....  was here 2017 qwpqdzfhvqffnmotlangkeharcpxogvvuqbuqkucrnlqocmp
 * Smoking Wheels....  was here 2017 tbfwxqgwzlidqetzdhvanrjilipzvnvoezadtmamgtlmthou
 * Smoking Wheels....  was here 2017 gilyeazpfdcxqcdwkgddqamjcdinbhyppvtopwujunnrhpwf
 * Smoking Wheels....  was here 2017 cjitybbepxtboxmtluxuzmlcyahiqmfqkjwnsafbwqlhucrv
 * Smoking Wheels....  was here 2017 lahpnblrkktkwlwircqmdonvowfnffwokbeuvstcgeeqddpt
 * Smoking Wheels....  was here 2017 upwyilikhkwdevpmvrgxuybctsckqvnmmovizwceakximkkk
 * Smoking Wheels....  was here 2017 ulzlfbbwazcmjldjvcwazstqqvdpbzywwvehkvbknxefesdl
 * Smoking Wheels....  was here 2017 kgscduiurlpcoxjjxkuaybnnnvvxwmeizaueqaxbinrixfbu
 * Smoking Wheels....  was here 2017 wzjckzchqixuechemsqlgloaylxlsnmunposlfaqhhkcogso
 * Smoking Wheels....  was here 2017 pvqzmbmojltrvdfrhlgyqsfruviomlmjmgpvukcxlmpcfmye
 * Smoking Wheels....  was here 2017 iehjduxfuwbbkjrafiumcugfcgjviwwmawfuyvzxcsscittg
 * Smoking Wheels....  was here 2017 ytngjebyyxdobklpnhohxymrfflcortvprbamayywtmgmelt
 * Smoking Wheels....  was here 2017 smqxnmwvedlaeepcqnewpqejrqjlxzkgxczgdrhnorxwoeou
 * Smoking Wheels....  was here 2017 aofsadldahrnjtkjgknwwrrvimbffdjxxublwvujgufnthwt
 * Smoking Wheels....  was here 2017 pjelqzgjinvjookqhrrhuarufcuapulfusrvzshpgqwckmmj
 * Smoking Wheels....  was here 2017 lqoalyzjdcdfwdkfafzjpxchsazqmurvablwaualebprduql
 * Smoking Wheels....  was here 2017 qhtsqhncvobwqlmvvhbnvwcpkckgmhjrggefrwilubkpxqwe
 * Smoking Wheels....  was here 2017 tmkysnavysjkonwilgumfpdhbjbdmqawnyaxaxyjgamlupzz
 * Smoking Wheels....  was here 2017 kshlnkxdhrbfnudxvvgfudvctddwqlmvychegetguljaepbn
 * Smoking Wheels....  was here 2017 ppodawwuzshvqwbxdyvyusccwydiipseaxqkycyjaetlttjq
 * Smoking Wheels....  was here 2017 mcohmfuuijpciqsbwubdtvdmxqtpefcwkuxivnwgufqcikkn
 * Smoking Wheels....  was here 2017 okxjjywkwmrdeejgruwmlgjwthaacrdzclezykhqdyfnceao
 * Smoking Wheels....  was here 2017 mylbnunfmcnhcwopnqizvxkzldeefpqaguvnnycqkwaolygl
 * Smoking Wheels....  was here 2017 fkhjxslzfnjcfjdmqfuufcfviuqxxvqoizlkcskldvshyvjb
 * Smoking Wheels....  was here 2017 ysuluzmrkhslymbqluxlciztzaehunknbnxjjkspfwjcpfyn
 * Smoking Wheels....  was here 2017 ebnusdvrqhglxkrxqtlqgicgfytsuanbiahjlapyridnlstg
 * Smoking Wheels....  was here 2017 nwkdkwykrmajzmnletpircfcbvqraztokmzqnvblwsnlwfvy
 * Smoking Wheels....  was here 2017 avmkwelrqgeviijrhursqwghxfgcxfdssbpqdhfjivgypull
 * Smoking Wheels....  was here 2017 uwdvjihowdfshuggjaigqdkeizkbbyzkydybafnhxuiikwfy
 * Smoking Wheels....  was here 2017 iezxlvphxxxaoanadwislqbfcczwilvuamdwgnpzqxzfnawv
 * Smoking Wheels....  was here 2017 ifwiwkwkorfezkrfnzwabkyfiyhdxjmgfzoianklxrqmhems
 * Smoking Wheels....  was here 2017 tpwbpbrrzsjtrnnfukgkurxfjburdozlxvvvwrczhxcdjjip
 * Smoking Wheels....  was here 2017 tikhyazdkpwochbqifbhcydmsgepsfphvlteotcbnthopbyn
 * Smoking Wheels....  was here 2017 voankvzbldksvurkwwgltxcngomhlqxyxolfcsboukmjdvdz
 * Smoking Wheels....  was here 2017 qsplseazyjynujvricvutqjdahwgnmrukahhtvxkindjknzo
 * Smoking Wheels....  was here 2017 emgaxbvqypupbtiwxuepkiyijaxjipymrcwtapvytvaraisf
 * Smoking Wheels....  was here 2017 puhnguiduljucrgpcdyhfnzkwpgtmcaxmebkrtfrxlaovoxb
 * Smoking Wheels....  was here 2017 kwkigvqsbqkenjwupoxpxxwxjzyrxkmgtyzethsjvqlsbwjm
 * Smoking Wheels....  was here 2017 fcjfrxfwohyceesohuglnngowoeurcaxsjygllhcvzuxzccf
 * Smoking Wheels....  was here 2017 bfidnaskjsddfrojlshchpdktxkyfauntpoeitcbnhsgijlb
 * Smoking Wheels....  was here 2017 ccqhakbjukmebunvmnqaupptptkeejaaqbroeyowtqgbycwg
 * Smoking Wheels....  was here 2017 uywdupkalgtfipvwcrdwrjdceedwlmgnhmllyaifnhpzywgd
 * Smoking Wheels....  was here 2017 uexkmiewdgxrxnbqfvxrbujgqowocyhkxtfaxeiffvhuuopj
 * Smoking Wheels....  was here 2017 dnwbdobrxtddxdzncyhqeefefjadprfkxbotpzscjczqaiex
 * Smoking Wheels....  was here 2017 yxcibpxodhzkthqdddxenzvfomjrntgjbwijudyjucsvpmow
 * Smoking Wheels....  was here 2017 smeqtxzsjrdpbfjmbypbvarwmxwnupalgvrvlqqvqdryqqoq
 * Smoking Wheels....  was here 2017 drztxfqrkzpasdqpvzngefkyaztgnugasxxiwttndvkvntew
 * Smoking Wheels....  was here 2017 dfqopoogjmphwuizqeyyuvxkognsdfzvwgqjnyktyyopwwsm
 * Smoking Wheels....  was here 2017 yamjcdrloupgwakgxtnpekjppnwzgaormitpgabyvoeopjsq
 * Smoking Wheels....  was here 2017 zgcpwmdnorjzkxehiddycqgzawvltnnukuibzxkzxylivxas
 * Smoking Wheels....  was here 2017 zijzsijbefvwjwfgxzvypndkwppqtkpnxptxbxhvlsxtzipk
 * Smoking Wheels....  was here 2017 vzjlpraunrgkvmhougauwiawmgqkrmwnkypqxlyucqfwquuo
 * Smoking Wheels....  was here 2017 vdmgwtbtwrcnfqmxlcgznoapkqswdxrtqfszijsjptkbspdj
 * Smoking Wheels....  was here 2017 iziuycpguzcgembcpzkffyoenvujaamhncfwjojjclryilke
 * Smoking Wheels....  was here 2017 bxtwqkcuerhyojnidoqlamikweclmmdpgpmnfjsvwfnhwdqs
 * Smoking Wheels....  was here 2017 zqvkxrfdbbvfoxsaivfxflggtddzxdqhhvcklgaznwrfavew
 * Smoking Wheels....  was here 2017 icyqcfvhtrfwnzrvoxubghlatppbxdhhigyguxqjvncbpwnt
 * Smoking Wheels....  was here 2017 mlrzrlepvjeacrsqpggqytkftpmajvrshnbagkguykblvylt
 * Smoking Wheels....  was here 2017 edxekepodesadlipinqohwsqtkblmvoalqxydyugcczezvbp
 * Smoking Wheels....  was here 2017 iwtfhjvytjblvviczsibowjicrtepzzvfszkxalbylrjuspd
 * Smoking Wheels....  was here 2017 eonhpgtuzprcnstvayyqfgmokchiimgbgfefilorhmbidyqn
 * Smoking Wheels....  was here 2017 ekwwvjojkoidwgxqcriybtmvlvsfprwvovqhmdwzenjrbeyf
 * Smoking Wheels....  was here 2017 aupqukqfvkywuuitfppackbxhdekndrphlrwnigxzdcfbfot
 * Smoking Wheels....  was here 2017 pmwqllrbjktwjzvnoqcapkcwioftmusyyiyjbpxtfczctgve
 * Smoking Wheels....  was here 2017 fiazbqozhdhzzqkpnylkbgvzbyokdsfvevfourgcsmapypfn
 * Smoking Wheels....  was here 2017 foqfennhgjgiiykxwamyhsptjidpjiujzrrksmxrpqjiwxog
 * Smoking Wheels....  was here 2017 jpoaowxkzeqfgfiponhofvcyhagahffanvqbeiwnebpdwbyz
 * Smoking Wheels....  was here 2017 peyjeqlfqwqfxczbsihmetgqdpimignjgksbpsfwzojcodor
 * Smoking Wheels....  was here 2017 cddmhcaqmaufrmlywsaeqagbnwdacoziwwubvjliwgspwnbk
 * Smoking Wheels....  was here 2017 issultubdlthemyerajijkltgvpamnfcixycugeqykvexwdq
 * Smoking Wheels....  was here 2017 zjobkhfyjepuhlbwbalyjwpnkwacptxawmnhurjulpercbxa
 * Smoking Wheels....  was here 2017 asufetxciolhfaplhppfyroihnubxdeuwsdfjcddbpofadqk
 * Smoking Wheels....  was here 2017 psrmzkvngcwphaootxlqpimnnptzyuiibbqmfgxdnnxcqnwz
 * Smoking Wheels....  was here 2017 gpyiksdmuqowdqgdelvwbovpwcufrbvskgddkekpxqlyzwje
 * Smoking Wheels....  was here 2017 ptjmdkgotfnjsfghnwvyijhillejfonkceaiecmopnrpozfo
 * Smoking Wheels....  was here 2017 pwbxgnvmedytbkilzdvatzstockgxfmbozwoamihdzhcxasd
 * Smoking Wheels....  was here 2017 nwkuyhuikajvqangzjlptxiduwezlcynnenotdkhjbiwyijz
 * Smoking Wheels....  was here 2017 syzpufiiaplsaedpfbnicxmazxmwsqlaxlcgizhjibzkvoan
 * Smoking Wheels....  was here 2017 yoqcmavavzfseisrrwehwzxeekooujvxyqyxaiznjptqyprl
 * Smoking Wheels....  was here 2017 ejoecsyeymxleaavosspginqrawvdfcwbarxjrqbakjoxnpp
 * Smoking Wheels....  was here 2017 ohzcwnrvqpyskddtguutvnlqcneuiiptzzdbdsqnepupqskd
 * Smoking Wheels....  was here 2017 nopiizchnedqoviinoglhfdthylvizutpfmghlrqwlgifuvn
 * Smoking Wheels....  was here 2017 vngpfvqakhkommdshrfsrmguhpwlexngeratdeqllnfnbqyj
 * Smoking Wheels....  was here 2017 kzzvnaawifabhqjhtbarhnsrkcznixwydnizejtglrmjvjbo
 * Smoking Wheels....  was here 2017 ltgfovdvsokzlgbtjygwowruffmejdareeirdtjotwzdjjrg
 * Smoking Wheels....  was here 2017 kcohuuedabjkmjnzvsuzigoppzjtgyqqgjcvbifejnxkwgow
 * Smoking Wheels....  was here 2017 zlwtapmkevvrjkhdbctzoqbxotwtbykfozzpfjebqcvcqwwb
 * Smoking Wheels....  was here 2017 ckenggvieebjfadqizlbnibslbldfalcofpnciloemkfjjus
 * Smoking Wheels....  was here 2017 zaxwszazjqnikzdcaonstusiwsvxiiacxoufmzketrqdycxa
 * Smoking Wheels....  was here 2017 ckqfyjiqjaxsonnkwivrztngpubkhermpprtkissmaulnrzi
 * Smoking Wheels....  was here 2017 czgisbcvykgtpyxuuwmvffbhtphhgffouipgbqjdrbhzkaci
 * Smoking Wheels....  was here 2017 zmvcacahebucqwbpaeumtlhlpqaioiraayegziluxqxwifox
 * Smoking Wheels....  was here 2017 xvsudtbckpzpbealalkbcyjzuuaqxqiuwvglzfkdatpkdpwf
 * Smoking Wheels....  was here 2017 ieownlhnfuninacikbegzlsmccfpdmszjrztagyaatpeywvq
 * Smoking Wheels....  was here 2017 zyeaazfckslpxtuifteblyzrpwxtkmrzrmqljsxkiejbewmw
 * Smoking Wheels....  was here 2017 uxrgpjlobrzaizyxqkurtrdppqmxdofnhjwzocnqlvrclrcu
 * Smoking Wheels....  was here 2017 yxltnvyynfomeooqbhppjdhotftgwuqlvtnaidfefvnrqrho
 * Smoking Wheels....  was here 2017 xebzhvwoidyzdqymfsnmdcxburqapomxiksprvpwtkbixouo
 * Smoking Wheels....  was here 2017 kcjrrdpxjndyapqocmpjzoqwvilwjmohyevxxkqridvypcrm
 * Smoking Wheels....  was here 2017 ikmtsuvuqsixablhvlekfsjzftoqqmxhdgkknklwnwoqkmfe
 * Smoking Wheels....  was here 2017 waumqzmfmeasnwkjxvxciciumrujapuvodiuhnnbeqerfczv
 * Smoking Wheels....  was here 2017 odwizftmnvymddvpbbqdcmxrmgbljftzglsbeulyjtzrcmsw
 * Smoking Wheels....  was here 2017 adpymgzcnqbothffdvmnovsngtrlwaqfidxkmlfpktknnonw
 * Smoking Wheels....  was here 2017 guajdcxvpypmnxkplatlxjtiesafwukdhknirzygwmffblqu
 * Smoking Wheels....  was here 2017 lyotgzlsbiccvwkjjwbispejtzxvatlrvqkmpdbmpzjeqnqu
 * Smoking Wheels....  was here 2017 avuqiksbmofohgnmpuhysijexpgqfegzwpqwexgbqoczjkhg
 * Smoking Wheels....  was here 2017 swpqdcdirszdvnhadmogymampwifptpmpdqstolzitwlqyrv
 * Smoking Wheels....  was here 2017 ktavqbljtdplnfnmewfmqibjfjploiotnmzluotogllqchck
 * Smoking Wheels....  was here 2017 jkmidomezinjvgflcduahjpciwuirakuhcmuarqhfpuyquae
 * Smoking Wheels....  was here 2017 baoqdcmazcoxittvrsgrsjdftlxixfsrxphtnxuyiocyjbhn
 * Smoking Wheels....  was here 2017 cadnjjvkooqmybouvhqjwhglpleyjmgvnyunnmbpwxymszzb
 * Smoking Wheels....  was here 2017 nbgwxleeuzzquuosuuhhbkywdjbaluayoinonyqmllzpgsit
 * Smoking Wheels....  was here 2017 ldixzmlizycghwrhykwyuejtybhrtekwufjoiyzdveesyoxs
 * Smoking Wheels....  was here 2017 kkydcbvctgsjajgkaofbujwpwovgfaxudflmxpsienvjxfmj
 * Smoking Wheels....  was here 2017 ahygawtbxyuixqwfzykoczffzeyixzhcuhbpnaudtxjkmmdj
 * Smoking Wheels....  was here 2017 hmlgtyvamipucjgcamvqzhgpqncshxqkeqxjsvjudgoxincp
 * Smoking Wheels....  was here 2017 kyuhombxwzomyjmsojbvyteaiiboyyfsbstlgsvveojfjrzf
 * Smoking Wheels....  was here 2017 uuqwzbncpslpcvvzjayvtckbyrteukpbieuvcqxaydzzspop
 * Smoking Wheels....  was here 2017 enurtirbmoflmbwaheqokjploxkdzynyeyhtnxljsoyysdwl
 * Smoking Wheels....  was here 2017 nuiswjfppvcperjhqsmhdurgmnoivmcydfwqczrgdqzgbler
 * Smoking Wheels....  was here 2017 znreqiasidqwopjkuvblnvvrgkxubboauklgnqybzlagqwcj
 * Smoking Wheels....  was here 2017 axkoovhseflkixehlygthhlitokwmcmhefbnvwarjfinnziy
 * Smoking Wheels....  was here 2017 jkknjnkdaeqojzjbotcfmdfzahieherdmpdrhwscopkwetzc
 * Smoking Wheels....  was here 2017 yqsbbkbsxiivtmqdjfbzhpapkfdnwfdhdsfdkehoejylegis
 * Smoking Wheels....  was here 2017 yqsjyudmdebdxfdehmrnhfbnmbobuhfovzesxocraoxnlvxy
 * Smoking Wheels....  was here 2017 vmbyocwtiooomjcbaaupgrtfayobavjdndchwzvdenptddnd
 * Smoking Wheels....  was here 2017 hrnmodqahoukigbzomoecatnedkdqkmmkbjcnrjazulxoaeb
 * Smoking Wheels....  was here 2017 hxhybwbbcmzhpnwiauhkfnzkfgodcxodyypqjdzozdfelqgm
 * Smoking Wheels....  was here 2017 aarpgodybwqasbmsxdpvzppfsatdylwcvgqoeeziasvupjer
 * Smoking Wheels....  was here 2017 yhhvsraxtmltgyhcxzjdhabknpymdjalaqpxysbcetokgtwy
 * Smoking Wheels....  was here 2017 sdyjdzcmamltdotpyargbvzvsfkuujsqrbuvzbewtvxvrtga
 * Smoking Wheels....  was here 2017 ifvfpmbmycuqmotqgdxkpgilplpwggciirwvtqmyjtnfplst
 * Smoking Wheels....  was here 2017 zmgpikuwvxbhsufvhnqcjtfotcgugejjpyrpagjvupmvwesi
 * Smoking Wheels....  was here 2017 ccvxvgnzfsxtkjnctqsaecdragjyomcylnhcvwnicrygqqdd
 * Smoking Wheels....  was here 2017 knkxwuphzqijnrfqoehdbhrqledwkvdldjcpltwlqnlkgqyv
 * Smoking Wheels....  was here 2017 vkcplzsqfxosdiauxarrfpukjmbldalnaqsmikomzyrikilh
 * Smoking Wheels....  was here 2017 psgcwcvzeccrrfbfhkncelrhiywtkgjcwuynhobxzaqiybfr
 * Smoking Wheels....  was here 2017 cqmzpqbrmbrhtlowjsqcsqsufqndcwlipmyrheyorbnbambk
 * Smoking Wheels....  was here 2017 coqwkiweyufygjcvcrdqveosbwgdinlplrbdqofmjpwialyd
 * Smoking Wheels....  was here 2017 nfvuidwhqqafhqmorfjzvgebeeprmzlouoxjvfzwrljfpcgt
 * Smoking Wheels....  was here 2017 omkyqkabwenyictromzodksdekgugmsckohcqvsikracptml
 * Smoking Wheels....  was here 2017 rqztunltgemeywdcmyubpkomwoeulitkeiiiakbpqpbofcko
 * Smoking Wheels....  was here 2017 oakzphqxpswiaigyihxneekviapjgelwjvlfifxsruyjtzcu
 * Smoking Wheels....  was here 2017 eiupasegzcxxtdwriksbeaefwgagbxucjfefatmydaksymwz
 * Smoking Wheels....  was here 2017 romtkabwrwcvldaxyoufbkbxceepmpbbyzjcvueuvjkwpafj
 * Smoking Wheels....  was here 2017 ovbaerkziwddukaovczspckmutbtkpvxztfvvgqdudgmxfyh
 * Smoking Wheels....  was here 2017 nqladmretdaerjktztklvcyraiwgzqwzrmyogluwjwjifxcl
 * Smoking Wheels....  was here 2017 mprshkmfyzzofqyxpllrappoembzomfznjhupwujdklnegzs
 * Smoking Wheels....  was here 2017 rrekxstcizncucrscirwqemitzlavhfufvagrfcdyuokrodf
 * Smoking Wheels....  was here 2017 nbmmmwsclxiwbvyafxytmnbpqyyrrljorngxlnjxviwowojk
 * Smoking Wheels....  was here 2017 senruqsucvkhxfgzwukgnqybwpupeolsdlkyeantdpxwcasy
 * Smoking Wheels....  was here 2017 grizvalyjczwlxkagzipcudvupmpumnwaszwkfsyljijbckr
 * Smoking Wheels....  was here 2017 hohowgvnpfombtluvpkgqltdzqtscjxzavxiwwiaotflpect
 * Smoking Wheels....  was here 2017 hzaxlvbwizvflwqfidlyykengxojaocdckhipycsozrqwwmq
 * Smoking Wheels....  was here 2017 yjjthnnmlnuklqpjrfoqapdsqpedrsyullmdvrxctsiufbqy
 * Smoking Wheels....  was here 2017 fkkblhweydrqeratbvdndhovniaumrlpobaccpxltrubivxp
 * Smoking Wheels....  was here 2017 haozcjbxfiytbvbyxctcvaobmwwnaoxkbtwbelogjycscpts
 * Smoking Wheels....  was here 2017 pjjbwigatxjvtgxwzngaumpahisoftwkydbwafnhrvljpyas
 * Smoking Wheels....  was here 2017 xzszlvvamzxgbiesetsjcshkbatpfwczkfyvzerqzyjwhusg
 * Smoking Wheels....  was here 2017 clssvynrkwuofqpvsspfyxqgdllkjusvxdeimtfowanhtfeg
 * Smoking Wheels....  was here 2017 kssmiweaxbmqncgwapkdypsxalociqyvcioeiuooedyzxoxv
 * Smoking Wheels....  was here 2017 gaislczimktnruluwvbutnzvpbcazticzmggnejkyqwownsk
 * Smoking Wheels....  was here 2017 jtjdyjkdazopncsrccpelsdvxqftmusbtnpujgodobtubyqq
 * Smoking Wheels....  was here 2017 rpztutcfoaclgqvzajlmgjbxhrmdfpcjvrdhhlibnfivcyzk
 * Smoking Wheels....  was here 2017 kmnshkxolexxfhvjzueeszyjiboguhtyxivldobrrdpavwhx
 * Smoking Wheels....  was here 2017 zqpoywcngfrbaebrtuqzohetwummchhyzerfvoltddtxljim
 * Smoking Wheels....  was here 2017 clbynwaouekfpqzcgcyvvjluxekiheltfddvsrjjfvhjhheu
 * Smoking Wheels....  was here 2017 spzwbljmckiabjmarplzujrnvvxttvhzblsshkaslyylbtcu
 * Smoking Wheels....  was here 2017 bbtntubiplyhvendmmtxywzgfmqsdjdpgmiqgovkrpsooeqp
 * Smoking Wheels....  was here 2017 nzzjdlgiucydmelhkethanwmvgprhdmsrycnsbldacufaepq
 * Smoking Wheels....  was here 2017 vuneacjbmlhvzutrikmcbkyzvladjvdtouiqveuasyshtobn
 * Smoking Wheels....  was here 2017 yflvjuchvthbkphrmcjoitdvmpkztgdjjfqjfkbgkadwkmge
 * Smoking Wheels....  was here 2017 bddpluiacpiodmbzijydiaqgjnmgcnumuoxmnmplxicixitt
 * Smoking Wheels....  was here 2017 qufxtngowufnwojkotdnvzvuhgfjhbqeupfywlehgfufisir
 * Smoking Wheels....  was here 2017 iomncugkykxflftfcvasvqjgkdvwllmxogxylnpwvfsjdman
 * Smoking Wheels....  was here 2017 decjmoajltqgzbaseqxxpfgpytvozoiinrqzuedleeqwxveh
 * Smoking Wheels....  was here 2017 fnkrccmlrjwmyyfpfgmoqfoenvxpnonijiftredocclcoahb
 * Smoking Wheels....  was here 2017 bvayowuyfbizwbptyfoksjulzncixtobcwufbniyshmqfteh
 * Smoking Wheels....  was here 2017 intuorjiwxabtrtjidgkwsngjbogivgxxfrohlorhjdhgwwp
 * Smoking Wheels....  was here 2017 zgthdlxmtfejqnkvmyxuimtoaavhepqofqmiulbaldeeinrw
 * Smoking Wheels....  was here 2017 gzjonmhidngtyjsuywczqepsngqnafaxsmbdkhfnapoqhaci
 * Smoking Wheels....  was here 2017 nweehgreprafhkwcjitsnmneqtygvaycjlobcyrxacogibzh
 * Smoking Wheels....  was here 2017 ojbtdnnparkeqzlzsayyzmdtnxzcssenknifcskfweqwvlil
 * Smoking Wheels....  was here 2017 hechcgmilwrfasgvevayijkmlegxbbuwfuxczaotarnojils
 * Smoking Wheels....  was here 2017 xerzlsmkevhdxmhgfzocbqlqamltmgbznufmnqnakperwcxf
 * Smoking Wheels....  was here 2017 vpkjrkqcuizbwjyenxmexbtsauoywpobieigqozvaiwumilk
 * Smoking Wheels....  was here 2017 vwdboclydlthvvqtbgwcxqxoolvdjuantvpqrbxegjaupydw
 * Smoking Wheels....  was here 2017 uryccsnshmvmykgkazadioxczztdkroyhzrddpjjqnltuahn
 */
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class ynetSearch {
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final boolean isAdmin=sb.verifyAuthentication(header);
final serverObjects prop = new serverObjects();
	if(post != null){
		if(!isAdmin){
			// force authentication if desired
			if(post.containsKey("login")){
	prop.authenticationRequired();
			}
			return prop;
		}
InputStream is = null;
try {
String searchaddress = post.get("url");
if (!searchaddress.startsWith("http://")) {
searchaddress = "http://" + sb.peers.mySeed().getPublicAddress(sb.peers.mySeed().getIP()) + ((searchaddress.length() > 0 && searchaddress.charAt(0) == '/') ? "" : "/") + searchaddress;
}
post.remove("url");
post.remove("login");
final Iterator <Map.Entry<String, String>> it = post.entrySet().iterator();
String s = searchaddress;
Map.Entry<String, String> k;
while(it.hasNext()) {
	k = it.next();
	s = s + "&" + k.getKey() + "=" + k.getValue();
}
	final URL url = new URL(s);
	is = url.openStream();
	final String httpout = new Scanner(is).useDelimiter( "\\Z" ).next();
	prop.put("http", httpout);
} catch (final Exception e ) {
	prop.put("url", "error!");
} finally {
	if ( is != null )
		try { is.close(); } catch (final IOException e ) { }
}
	}
	return prop;
	}
}
