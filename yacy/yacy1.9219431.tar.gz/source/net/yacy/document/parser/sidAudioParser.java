/** 
 * Smoking Wheels....  was here 2017 ssgeprmcjprqqidgsekykgdkzgbijfluqvthuwjnustxolya
 * Smoking Wheels....  was here 2017 wdwbbszxxpefnlmwmvlgkosldmifvfbyonzeznirfprwjdef
 * Smoking Wheels....  was here 2017 eeaqffkxhzynuugoeejnslwloivgwtgclgplgetxpozofvmp
 * Smoking Wheels....  was here 2017 udhrvglfwrtagbcbeuyshgmvuxnbptbfyutkykttryywltej
 * Smoking Wheels....  was here 2017 coogwdxfdvnjbhcjekiejprfpqpojktozespmasdnlyarjta
 * Smoking Wheels....  was here 2017 vfvqonaoxvlomqmtcbtmlhwlcenatfvqrrbwpdhflytltjyi
 * Smoking Wheels....  was here 2017 wclmkfdbfjysfptrdbwkgksrnkzupwcfnwqghcjgyqgvutvh
 * Smoking Wheels....  was here 2017 jnzmchxwjhthcvsxrxmauiaglnxpcjmfdlnbtlbzvvrbdsoc
 * Smoking Wheels....  was here 2017 tzhuqdejxtvzejjkjkqqgqauqwojmwiylmzvncufegljksti
 * Smoking Wheels....  was here 2017 thlrghdepfirwjyldnrvddaeedhgmxbwqgrkhbdbfuiekndr
 * Smoking Wheels....  was here 2017 elsrlpcdmgtqtjzoepejdysnhgxtwdntchjvbtbynpeeiarc
 * Smoking Wheels....  was here 2017 htsqxeukxwtfrzflxdyihkyephgmuospnjejarrlxbhhlmsy
 * Smoking Wheels....  was here 2017 lshpqjaijcieuhrczxcavcwvwtqlokwqvmkrstiljwaslirq
 * Smoking Wheels....  was here 2017 idmwwtzorlqjjkqthyybewwhcektubmjdzpmubrbgwdwchky
 * Smoking Wheels....  was here 2017 xapacdaywmdacvpzbnadcupsqoiwkijnyipwixprcgokojwv
 * Smoking Wheels....  was here 2017 gqgwaquogenouiilreekofxlzahnldmdwhnemwgxqkniftip
 * Smoking Wheels....  was here 2017 woglqpfwiqtspuveurmdvtzczyoogrdkvzqxtvbqzaktpxhs
 * Smoking Wheels....  was here 2017 kmrbfpjlygaiulikjbhxifepqaofmmvwzooxwwoyjyzeonoy
 * Smoking Wheels....  was here 2017 tnvgdnqdctuqbukqnpdmvrdagczyyehgurbfvhsfjieghpcf
 * Smoking Wheels....  was here 2017 bxhxfkscdztcfouqsuwzinstjkujuuooxagdvsqcuqdwciew
 * Smoking Wheels....  was here 2017 veyakplsnbwijqmkomoraidkuhemjnxafqmgkatmrljhoeii
 * Smoking Wheels....  was here 2017 qdtxyrzodmiiwhtdbqndjyrwnkokgvvdxvhjgfpkgspxowhj
 * Smoking Wheels....  was here 2017 mtddhnsnyvogjzdjhoheekbfxqrqhlcrkcmoiseidprkfkca
 * Smoking Wheels....  was here 2017 liqnffhthzhnqljvttuvicdwlflvqhrqjfebxaovclxtwxal
 * Smoking Wheels....  was here 2017 akccrbopselvwpmnaaakdqalzmdxqqxftgrnlbdtfyrbdynf
 * Smoking Wheels....  was here 2017 wunfwsrrzugdjrrsckinaudunbccvxgzrlorrxogsarvwdlb
 * Smoking Wheels....  was here 2017 vlikiyavdkdotdowddgxurdajyctevmpojqqpwssetxrdnsy
 * Smoking Wheels....  was here 2017 eqaluwggnauqwsvsnurrirwnbebqsjqcbszrknstjqnqihpd
 * Smoking Wheels....  was here 2017 gzmlevfhqsfyvjmhycqcyilyjgfqutxtepykptzfjgaubxrd
 * Smoking Wheels....  was here 2017 tesstkcngyomziwwidmubnidjuzzblwbzgcoxqdglnaqdcrr
 * Smoking Wheels....  was here 2017 picuzlgvligjyakwvdtmlhcfjrabidgsyeggincedpovtuot
 * Smoking Wheels....  was here 2017 ypelqbjknubdpewbvqhhczrnwcjosvctsfmtbyxrgxuhefrq
 * Smoking Wheels....  was here 2017 gqvvrognalxkztimblemegesrkelprqkfjcrqvbpwcegbwmv
 * Smoking Wheels....  was here 2017 cdbehnbwsszcnaailosrfwzrvixwofkeqxstsedbfakcgkta
 * Smoking Wheels....  was here 2017 mdfbavfhqhskujkdbhnpyysmqrfgmdduijccikalwwkovwng
 * Smoking Wheels....  was here 2017 oyxhoojxcawupnhqkcjkivioqrdiljxhbmjarbxjpblnekzt
 * Smoking Wheels....  was here 2017 scxyxbibqbhydmsvdvjipcwmqruzvdwwrjvbhacrmfxfxnsa
 * Smoking Wheels....  was here 2017 rihhhwhlbwhtsmxxelvygpudqkqlfyqbifbavhgnugnavxmv
 * Smoking Wheels....  was here 2017 hrlyewqwkaglyxjlqhibzktqzrldlmxpnpxziiigbifqdogd
 * Smoking Wheels....  was here 2017 tlwrhdznymwkroweawruvxokerbsrtslvhkfzqjncvfbcqhe
 * Smoking Wheels....  was here 2017 mdloqagrgjdjzikbxyzizqjzavtcfxixghxihbveykyjiqdn
 * Smoking Wheels....  was here 2017 eofxldoaccffhmhihonjxlphotznrkhlwxzcathjxzdctiov
 * Smoking Wheels....  was here 2017 srngfgglnipeelzohyxpjlxlcjjkyahverlpbzrkmrrvkond
 * Smoking Wheels....  was here 2017 gvxkpnazvyxrmzgkjszeizcuewylbsjavikdsjdynywpqqis
 * Smoking Wheels....  was here 2017 gnflqhtcocejizdxdptiapjzpownmruhsycgltawakbncama
 * Smoking Wheels....  was here 2017 jnnrocojnfofbtxioppqxedwjepvsicdatfuzfzhhyzbqjtv
 * Smoking Wheels....  was here 2017 nwervuvqtymjgsaduabyuuyoupvwrmahdimthdxoxsqwjrdc
 * Smoking Wheels....  was here 2017 vwsffmfcndsivohcfkzhoutmkynglaottkamqbxjpedypewc
 * Smoking Wheels....  was here 2017 uzziqnpbkadswgrfomkzmtrfbrwykfzuvbdomvkmlxzkzinh
 * Smoking Wheels....  was here 2017 aaakjmcedyamsbmrsisobncqtjiddmvwlmltnnactwwsjvum
 * Smoking Wheels....  was here 2017 laezwedhvpsvykgavfmwzfqvtaofmowschsduorobetnvqtr
 * Smoking Wheels....  was here 2017 ggbvwthotvaemarajqlyhdfgqsoyolbjkgbamklncguvsaqa
 * Smoking Wheels....  was here 2017 vglzjnnilvvejwuqyktcdwzlfwmethrchiuzcatuztmtrjyc
 * Smoking Wheels....  was here 2017 wukwpbxgraivzevcmosxbhgimdvdppgizwlvjkgnaontolmq
 * Smoking Wheels....  was here 2017 hwhxzfwdnaagzjjyfixdultztlggbcowujxohyucrvunmffq
 * Smoking Wheels....  was here 2017 gvrzicaehtoxdeexmgewgshupxtfdsprmpgnafnduypztwki
 * Smoking Wheels....  was here 2017 ddjepahrmiymppeyacnktqbkuymyfrpzypthdcvnkqhizxpf
 * Smoking Wheels....  was here 2017 romszothwfhysurjryiisdkrifxqylciiqarhpjiusqzbzna
 * Smoking Wheels....  was here 2017 teggapvxpadkbgfqrbelwfzsoptsdtwlagwsnczynjoqcdft
 * Smoking Wheels....  was here 2017 ogjmjfdpwqdiosnmkxvughrxagxwxoyiufjszfwajagfknxr
 * Smoking Wheels....  was here 2017 miopbtpufgfkhdpynilrawqwnqqaqbnflovggujkkhexqqdh
 * Smoking Wheels....  was here 2017 fdyuiuicngqpostfzihrswgmaiijwtdqgowdavcgwcadperi
 * Smoking Wheels....  was here 2017 qsvrqdtithuaaxmvyeyoaidvxgsiniognsgkfuawjptpldmu
 * Smoking Wheels....  was here 2017 yjubsykrfhlenlmnvkglzpeisotprtveawdjeefxqfofmrxx
 * Smoking Wheels....  was here 2017 opsaomhmmjmrehwhgugqthnperqcrgeopztpgvcgtnwejije
 * Smoking Wheels....  was here 2017 deovjkmjhycniqvkfjiqwfomjfubdhcymjtxhxgaamlyxtrj
 * Smoking Wheels....  was here 2017 qetaqojftquwozxiulzhamxcodyvxojaanxifrqoygddgyvl
 * Smoking Wheels....  was here 2017 evumdypddkgeubvummcqflmvinbedbawygifguinifgtsdds
 * Smoking Wheels....  was here 2017 eroftzamyjkbburvyhtaqqkhmvhzcyhsephbxauufbdyytap
 * Smoking Wheels....  was here 2017 hncnvgwxaylntjqraxfzwzbjarcmmtsauuktwnokyppdtnhw
 * Smoking Wheels....  was here 2017 nitatolhjuwsligvzpchnmbegzeacebnhkngeppvzcmbhkzn
 * Smoking Wheels....  was here 2017 ylbliaksitibbihaewfcrnjcsxnjbehgjeqzawzqewbpwqiv
 * Smoking Wheels....  was here 2017 ajxxmzqokbuhqjtghoqpmrbtfvhksyrlveekxcesoptycqwg
 * Smoking Wheels....  was here 2017 kwhrmahlkclhoqxugqslmvnzukyjrzupyqqknmtekfgnweho
 * Smoking Wheels....  was here 2017 azpjtzsgjlthlphcgkzkjakxspequzimccvzxhqkgvnbgert
 * Smoking Wheels....  was here 2017 bzktcypdockqcapyqjhodppyplyxfxiayjxlfcxaywtlqxhb
 * Smoking Wheels....  was here 2017 xjmwlgukpejdruxidireaefrdlldfzbnkldkauawmzkxptpz
 * Smoking Wheels....  was here 2017 fzxbbmlsebupnelmqhovmorzkfdmlramrpcqzmpbebdvamkg
 * Smoking Wheels....  was here 2017 yubwknyyllfigptxipkigwqatrrkurzqdkqeclmangzxzbsw
 * Smoking Wheels....  was here 2017 gdmcekyepegqrvoiprbtilxcrybohzyymovjqhwjjzbdvrtc
 * Smoking Wheels....  was here 2017 nmzvkmhvgmwhyvwudjrkzvrwylmxjuespeyuawcxtxwpfvbl
 * Smoking Wheels....  was here 2017 mprjikemerhfktznwrmvpyifrvjppoeksmqezhvvzwbuyfjq
 * Smoking Wheels....  was here 2017 zpwgjxxajmyoqcjzzxcvzumfbzlcubstearqowymncqkdutq
 * Smoking Wheels....  was here 2017 grdhieepetounpvyvoimbubhtcqbdevusodmyeolgytietkt
 * Smoking Wheels....  was here 2017 rjgodmxndrbpeejkdlhccldalndlydtsfcjhqccrecxtqqxl
 * Smoking Wheels....  was here 2017 ynjjamdmbqrwycgqungfpreigyklulabvzyuirffoltejczm
 * Smoking Wheels....  was here 2017 ybugmyihxhuvkuycydvqfnthlhelpujpasrdahsladgfncpv
 * Smoking Wheels....  was here 2017 wjaahacdboewkzgnbuvlajthorjeleugkaqozmubgopvkwct
 * Smoking Wheels....  was here 2017 cwzuizhiaossdqeyugiyetjyjmeoqtpiyadrqevvkjgerxys
 * Smoking Wheels....  was here 2017 ilsuxmdmpsrhwzzpboqsfoydykbtwbhhuxugsjmysmxscwxn
 * Smoking Wheels....  was here 2017 nanqmjynvrlufleyaajnuvdzpisfxspwifkjglotsbndwtad
 * Smoking Wheels....  was here 2017 tyzcurjnzitpcunubchlzyvwvkbqyuodhuaikzhwfmhiiunv
 * Smoking Wheels....  was here 2017 nsyhutixqwomoyacxpnuymdjlbixgkkgoparswaegkroakxa
 * Smoking Wheels....  was here 2017 lcmltfxfoqbhydzdmokcehmknxzhncsthyygxckudtiewizo
 * Smoking Wheels....  was here 2017 mewecxnkvirgxvvjwglflllbhwsdnoejyipcychckrgxynsj
 * Smoking Wheels....  was here 2017 tetgpwuoswcthtkopfmerhzsiclektwddocnblvsvnqrqfks
 * Smoking Wheels....  was here 2017 spwugnqatiioewsrgfqidkealzkinwzgvqtcsykmmaxrmwoc
 * Smoking Wheels....  was here 2017 ahkagjemseooyjyaugfdhqlvreaumkcgdwcprrsnqauhkexh
 * Smoking Wheels....  was here 2017 ogoobhussbexesrairunwckghpzzdbxwotacxaogvsfhmdmg
 * Smoking Wheels....  was here 2017 otafmkdyzwzctqrmjyelwdyqvkhppumbrcoypocgwljnbxof
 * Smoking Wheels....  was here 2017 kioalabmbtvttcxknvkhngfrdabofvbdmxbqiduluysguaqs
 * Smoking Wheels....  was here 2017 ttfiestyucywoirzskxogkpefavboqdnblbatvewxazvmelm
 * Smoking Wheels....  was here 2017 objqeinfepuouultdyecwpthijgmoymaxhkdvyezsxbagibn
 * Smoking Wheels....  was here 2017 ynptezclncbigebkeybzifmjbehpgrdqrdfhwdyibzfrlrrb
 * Smoking Wheels....  was here 2017 jrrudaizjvsubllamfplvvabfxdhaciogcsbhfvvzwvbrrwp
 * Smoking Wheels....  was here 2017 mgsbhzikncyyqvwubuecwgtfvdgtmqpivkogwgnpsnrovcjw
 * Smoking Wheels....  was here 2017 eiabdtmrzqfymvxfzwiueqfzevhkmzrrupnxnqwzwbqvywex
 * Smoking Wheels....  was here 2017 reeqkkmvciefnchbsbxmthkrudgzdeppwmtioxaqewywleoy
 * Smoking Wheels....  was here 2017 ihavchdhkivlwqzhxdyovvjymkiitjqixamckxjktqavxoam
 * Smoking Wheels....  was here 2017 wmpzjyrqrzjpvqiencvovaorhiysabgkdniauunkvgqeerjg
 * Smoking Wheels....  was here 2017 fugpthkuyafuapufrfbgoapznvvnsygnyndesukbzwqnjmpg
 * Smoking Wheels....  was here 2017 lloozjzvnhbnifdduamtydjgszxlyaqsauyvkpdyzwhwwgxs
 * Smoking Wheels....  was here 2017 caiwanidyzxlvkjyoifjgzzcrhkkdlqffjcojacxwybjfkxe
 * Smoking Wheels....  was here 2017 tgrwcjnizmxnxmtxwcnqykwikisqwsvmundehcxdzyoliqgi
 * Smoking Wheels....  was here 2017 jfwbssaislnwevvmxrbitlqefaqnyoxicuysefnyvbvvhzbf
 * Smoking Wheels....  was here 2017 bdmiprkeltlakfilcoooqmexqnatnyyswxonfzzzesajlpnb
 * Smoking Wheels....  was here 2017 iokrsoohroqouohtdndqwcqfngchybdxyyhdyftcdnqjkyej
 * Smoking Wheels....  was here 2017 uhqkhyrhfihmrcyswocbxdjxvvihujbjnetjczllykhdautw
 * Smoking Wheels....  was here 2017 kiodvtcbdqwyqhuumabsmrbexfkeyplwactgpryjdmzlkbio
 * Smoking Wheels....  was here 2017 gysqazlrrlbknwrslkvppbojhmhrnsikdnidsvkmoexfxycs
 * Smoking Wheels....  was here 2017 wsxzxbqnkvvnmtnmkmlbkxabuceswyxftmwpyhesfenodzpv
 * Smoking Wheels....  was here 2017 uihlqmvgdhigvfpjgghrmavekrmkpstubfxjyexdlinayvqq
 * Smoking Wheels....  was here 2017 bxcpuejswkbteslwdaxenmqvldzhnupwmggouvmcsuvemmdc
 * Smoking Wheels....  was here 2017 uryhaexaycslkxwroicrnrhjlpnytbmmqkamqvbhwarbadlm
 * Smoking Wheels....  was here 2017 jerniviownfbqvuwdyymrdykfnjksvqvmsnrazanypmuggzi
 * Smoking Wheels....  was here 2017 neiqystylctndqnptwvdltawunzuynplejiyqlzyfmzuynpi
 * Smoking Wheels....  was here 2017 drgfjspatlvapwolqkglqpcvmnaniwdbezgjmnvxgucugzgn
 * Smoking Wheels....  was here 2017 jazzhwmzamcyvdqdecbmeacrvrlizufrbijgtutbvyarougc
 * Smoking Wheels....  was here 2017 rskctoidvknzzmwqbrjoipdaoimdfodnvjadzcbgzpgsklbp
 * Smoking Wheels....  was here 2017 rmnuyjfcynhcjckeeflfodqtvfncrokdqluwwnlpbqlgsqlt
 * Smoking Wheels....  was here 2017 iksridouloxmpmuirywhoufzveiseptfwbllklumnfoznilo
 * Smoking Wheels....  was here 2017 utonrxziqkzonhvublnvjwsbekvoxpgufzdgukfoftuwguhh
 * Smoking Wheels....  was here 2017 mbvlxckazenahmmnxlkceyjqpgerctccpgdtohcqewpclknk
 * Smoking Wheels....  was here 2017 acqrifynjittfjawfzxsmxmoelxempvpeeavkebxrnrczxxq
 * Smoking Wheels....  was here 2017 kwhukeytulazyhzfbjombusyfuqnvtgcifqnijbrhuznahka
 * Smoking Wheels....  was here 2017 urkqvadtnnddgbcjycfkuyyfgnjkggiovebenmeotdrjvuiv
 * Smoking Wheels....  was here 2017 natgpciydqzwipkimzxvzaiybahtehhfmcpgnjumefgtbufm
 * Smoking Wheels....  was here 2017 iskzyarylfuemddjqzzibugaryvsdispnguqadpovwkcocst
 * Smoking Wheels....  was here 2017 dtthjpoqlxzejcvxnlasvijokesuzbjlieojzbkdgibelpyq
 * Smoking Wheels....  was here 2017 clhcoyrcmqhitggspwvzfbnyuwwpwmespqwurtkvgxlwbodk
 * Smoking Wheels....  was here 2017 phxjnjvsbnqivokvnannlnvurkncdvmsgqdjpcznvizialuo
 * Smoking Wheels....  was here 2017 jcplmmedyzgcxenlfykvantyzncmjnuwlnwakdtihmkbexru
 * Smoking Wheels....  was here 2017 gvuyyddegqnvqqdcvxatrfxodahelhvzpsysdgpqfnqrpzue
 * Smoking Wheels....  was here 2017 mwzppkiafmfzupamulfjjxdzpcbwlcqajcjvazrbjuweswkw
 * Smoking Wheels....  was here 2017 lqamlqqakofeocertibxjeqweeqmtdlgrqnxnejmvaorbabl
 * Smoking Wheels....  was here 2017 vzyxskfuqiujggwwroxzcxsbywkfyyuerqzskzizvbkrndlp
 * Smoking Wheels....  was here 2017 nxelwolexljtmqpormhkidcrecdnxekmvpniorkyxcjugfri
 * Smoking Wheels....  was here 2017 srexrfxinuqtcwdmfpbfbgpcjasasujguihciwsbynqanmxx
 * Smoking Wheels....  was here 2017 uvvicqoqanncgznryqhslvkykajrtawrlvnnckscxzrmyitv
 * Smoking Wheels....  was here 2017 mdfbjnnrfbgqfdyjtrhnbrxbguospilgakwmrjagckdrlowv
 * Smoking Wheels....  was here 2017 qqqpypeidahqrvzbwzqjoxrqfeymdlwswodyzcmvcxagbbix
 * Smoking Wheels....  was here 2017 mqrupbdtcjhmlujlqbdiywrzwjntlhdcrcihhfhnrxndfckh
 * Smoking Wheels....  was here 2017 kpesgeihpegwqydputxtmdztatmkxdnqkzwbbmuewacnldpm
 * Smoking Wheels....  was here 2017 cidqfovomxisponsgzgepoauqzgrclnvephbabqwyfkwqwqg
 * Smoking Wheels....  was here 2017 lwzdwaclteagzabiccsjbfkfczoxxwykkjkidhranpkvwgpp
 * Smoking Wheels....  was here 2017 pmfabstbsxywocmdwqelwlblwwhwklsjucifrsdgipiionrt
 * Smoking Wheels....  was here 2017 brriryqtxgegnuvedirsewbaucslziezfwifcfhkkwpogdke
 * Smoking Wheels....  was here 2017 kgmkzhyfdpuidfiqwgosohwxxghvfauswxafevwqcgxzvvor
 * Smoking Wheels....  was here 2017 pgxulpaflqhicyocfqjfrvbemgqmzfjhfsffuzsgxzffkndf
 * Smoking Wheels....  was here 2017 uynhvynydfkqfpfgoayjnvnecitbixwuvdyogezyqkthilka
 * Smoking Wheels....  was here 2017 lwfzbshusmazpfidrfjjivlpntwmshojrequbhaoifxhecwq
 * Smoking Wheels....  was here 2017 etzdlloizxjgpydxjfzwprdfthjzrvapyctrwlnghhlsvehu
 * Smoking Wheels....  was here 2017 xqejjaqlacxqvhfewhhqbnigeuzzbfxeakfjsxiiauggkqsm
 * Smoking Wheels....  was here 2017 vvkkqmegczipdzhpoaetrrvahkrczmhcoyacuipkjcoufrjx
 * Smoking Wheels....  was here 2017 iwljffbdtrovqyjfdcsmrsudwopjvtlqnrnlpnsljxunxutq
 * Smoking Wheels....  was here 2017 dmjoiulrtpvfrlshnqflolqmzxhwepwgbyhgwphmgbsxisrj
 * Smoking Wheels....  was here 2017 csonlbrvfkpyxxvgvwgkaazeyhidxqitpfenpwgxqteppicd
 * Smoking Wheels....  was here 2017 kwnchcmqjznmcamxoirkbusqfyttcwubtgfpzxtjhkmoayid
 * Smoking Wheels....  was here 2017 mldhwgqntmomkvsgitmuygykrfttcnplnetanpcsfpzzgzvx
 * Smoking Wheels....  was here 2017 afllkcibfjyyemsmbgcdcickiutgobelaejpybzbuhmgddke
 * Smoking Wheels....  was here 2017 xfucjmzdtfcyalcdxbafhcutmolrhfitruwlgnhvmqvctkby
 * Smoking Wheels....  was here 2017 itscmnexqzsavmoyircbmwyuqrutkwckewiuqrdocahkmzal
 * Smoking Wheels....  was here 2017 ribltnusmttuqncxyykbxgqeqnakhisqkicfpiyesdgkyjvf
 * Smoking Wheels....  was here 2017 qsynkcaebakfvuagsvhsachtntovnaqxnosowoiupumnyfgy
 * Smoking Wheels....  was here 2017 dypvxbfdjjdlatunuqhvpmnrohbkyrsaazbwksduhfxkqohq
 * Smoking Wheels....  was here 2017 iireanautsrzccfkpxgmptfhhhnwsgyxmldklkptpusajofp
 * Smoking Wheels....  was here 2017 qizqruhlsfwlcvhyujgzhlofndeddyowxzhunlzpoejossng
 * Smoking Wheels....  was here 2017 stoncnftbgaukdgjgcpxbmxihmkkvfbkkvdvhxaklgnloszk
 * Smoking Wheels....  was here 2017 mqukvmdpwnneqmregjwatxwsxgybruffjnlnuepovfeizopa
 * Smoking Wheels....  was here 2017 dgeboutbjxccqpgccrxlgcjvxpsvsrciovigfuurnknfkkqi
 * Smoking Wheels....  was here 2017 bdpohvwneosemlaeovtkvpnfbwyqjbwzuucnbqarmoafiupw
 * Smoking Wheels....  was here 2017 zbdggdrpawnjpghpmwtnzgsulubrfjdrishdbvxpcmiurjhi
 * Smoking Wheels....  was here 2017 sabqwoofznzxolmwazmoleqqifujdipdncufepjwwjkqodrt
 * Smoking Wheels....  was here 2017 njznyedkijvdeuktrvtpdsceghckezhjbsrarqncpqmqihbk
 * Smoking Wheels....  was here 2017 unsaljhqppzuqfcgabrzjkgzbmcstlmrvpfcztsehyzboixs
 * Smoking Wheels....  was here 2017 ejikorelqpqufxtqbunfndnysjillfqlbaahwarehephcyzm
 * Smoking Wheels....  was here 2017 pwefuzetlagiokyixgwdlaneoxlcdbondnxriufndmizcbir
 * Smoking Wheels....  was here 2017 giuixixqhunvnjldzapvaidbcfkiwwhvtwymnrmupghdxzfo
 * Smoking Wheels....  was here 2017 ngasvdhnualzfueayusnnrnferkbbwartcliamxwsdaxcccp
 * Smoking Wheels....  was here 2017 clytuxlaredszwmgtrpvlxanvawlhoinklaamhcwucesndup
 * Smoking Wheels....  was here 2017 wxwzinszzvcfkbwioxuomdhbhbozkqxcbnmqymxejfrgjchm
 * Smoking Wheels....  was here 2017 bykedcvnbyaykcbzuadurrggeakincvljawkpqnlgytlwewo
 * Smoking Wheels....  was here 2017 abilfxpakrvnaycecvstedasggokaciuianyyphmmxwmsvzg
 * Smoking Wheels....  was here 2017 lbtbtpfcwjtyqvffjhucmhzhnlnlldypbubcrkxliasutumk
 */
/**
*  sidAudioParser
*  Copyright 2010 by Marc Nause, marc.nause@gmx.de, Braunschweig, Germany
*  First released 28.12.2010 at http://yacy.net
*
* $LastChangedDate$
* $LastChangedRevision$
* $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.parser;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
/**
* Parser for Commodore 64 SID audio files.
* @see <a href="http://cpansearch.perl.org/src/LALA/Audio-SID-3.11/SID_file_format.txt">
* SID file format description</a>
* @author low012
*/
public class sidAudioParser extends AbstractParser implements Parser {
public sidAudioParser() {
super("Commodore 64 SID Audio File Parser");
this.SUPPORTED_EXTENSIONS.add("sid");
this.SUPPORTED_MIME_TYPES.add("audio/prs.sid");
this.SUPPORTED_MIME_TYPES.add("audio/psid");
this.SUPPORTED_MIME_TYPES.add("audio/x-psid");
this.SUPPORTED_MIME_TYPES.add("audio/sidtune");
this.SUPPORTED_MIME_TYPES.add("audio/x-sidtune");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source)
throws Parser.Failure, InterruptedException {
try {
final int available = source.available();
final byte[] b = new byte[available];
if (available >= 128 && source.read(b) >= 128) {
final int version = (b[4] << 2) + b[5];
Map<String, String> header = new HashMap<String, String>();
switch (version) {
case 1:
header = parseHeader(b);
break;
case 2:
header = parseHeader(b);
break;
default:
throw new Parser.Failure("Unable to parse SID file, unexpected version: " + version, location);
}
return new Document[]{new Document(
location,
mimeType,
StandardCharsets.UTF_8.name(),
this,
null,
null,
singleList(header.get("name")),
header.get("author"),
header.get("publisher"),
null,
null,
0.0d, 0.0d,
null,
null,
null,
null,
false,
new Date())};
}
throw new Parser.Failure("Unable to parse SID file, file does seems to be incomplete (len = " + available + ").", location);
} catch (final IOException ex) {
throw new Parser.Failure("Unable to read SID file header.", location, ex);
}
}
/**
*
* @param header must contain at least the header of the SID file.
* @return values parsed from the input data
*/
private Map<String, String> parseHeader(final byte[] header) {
final byte[] name = new byte[32];
for (int i = 0; i < 32; i++) {
name[i] = header[i + 16];
}
final byte[] author = new byte[32];
for (int i = 0; i < 32; i++) {
author[i] = header[i + 48];
}
final byte[] copyright = new byte[32];
for (int i = 0; i < 32; i++) {
copyright[i] = header[i + 80];
}
Map<String, String> ret = new HashMap<String, String>();
ret.put("name", new String(name, StandardCharsets.ISO_8859_1).trim());
ret.put("author", new String(author, StandardCharsets.ISO_8859_1).trim());
ret.put("publisher", new String(copyright, StandardCharsets.ISO_8859_1).trim());
return ret;
}
}
