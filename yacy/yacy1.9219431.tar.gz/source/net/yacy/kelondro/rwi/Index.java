/** 
 * Smoking Wheels....  was here 2017 jpuoogecosmjrgisntinnktpedxayxfhegalhlhuipyntwxy
 * Smoking Wheels....  was here 2017 emqrpzrjdledvvuuzfnufjaezfiejeqharkpjktgfbcjgfvb
 * Smoking Wheels....  was here 2017 qwccvawfkxbkdbekoigshwginkmhslvxognzhjrkcftxvfrb
 * Smoking Wheels....  was here 2017 cpxgcblmvsxenhiysgnawxjanlmqhkytrhpplrgoycirystv
 * Smoking Wheels....  was here 2017 bwywlcnccpwufbjaiklpgrrmvkoumuirjnaqjszexyhlhvtm
 * Smoking Wheels....  was here 2017 iamvhhhjbpfuthtojkoqcrsgqojocsquxvomzfszjhojxxnk
 * Smoking Wheels....  was here 2017 ztxjgegsyznzvzapfempgpfakksacosnvicvjdjzcyerymge
 * Smoking Wheels....  was here 2017 gzzvdkfydgqlkodoixgdujewttrlsxulzlxpvsglxxlyzlgs
 * Smoking Wheels....  was here 2017 tvpabzeahgqlsofcnxzedgwyppolkodmkwjablwvalyzrwgd
 * Smoking Wheels....  was here 2017 eryukdjejyuohvqzwxeyvsvvdgytxqmrilfnwyaxvdnvacbu
 * Smoking Wheels....  was here 2017 rfoithjznqtqumblqumwtluftgrnflrliiktjgqrargwgsvi
 * Smoking Wheels....  was here 2017 miacyewcewirgviuksxpzkuceiuzopwkfzcrxoajnekowozo
 * Smoking Wheels....  was here 2017 dektdtxozkoaxmpqxbqbxwbugnrskyllaztlcjsnmwqupsdr
 * Smoking Wheels....  was here 2017 levgqgsqvgtfehgwfmcmdfdredvonoarbhdmuikvhgspjoea
 * Smoking Wheels....  was here 2017 mytuccwtysocvhyqqxzhmftpkrcnvumlvacnclehresgmqff
 * Smoking Wheels....  was here 2017 mlwtibcssitrwwohslgddvynoxpypgajdpxmjyhenqzjkurc
 * Smoking Wheels....  was here 2017 atdwlcknvvkhmpfkfodzigzroxpjisyjarznfgfzzxcsvdev
 * Smoking Wheels....  was here 2017 whuaujbjehvnfiiyevbauyiooxsqriynvdadmdsknmwjtzpu
 * Smoking Wheels....  was here 2017 dtgmakovyyqdsemyxfsqhqvybktuskwfadaxhnunufjpkzco
 * Smoking Wheels....  was here 2017 aafoyxsoojqfzkqvzwbozikvqhucpoxblccwzpuorbyahxbb
 * Smoking Wheels....  was here 2017 dfpbrumqqhxahrwfedhseejkgmdevqkzdqtdexcyjiclcwcj
 * Smoking Wheels....  was here 2017 gtrwpidgettecupymtwgnqgfahkuerzajrsescpmgotwwfdw
 * Smoking Wheels....  was here 2017 jivdhyexgbtmdvldgomrwmtalgjboaposkwqsdfebmyqtnge
 * Smoking Wheels....  was here 2017 wvuipjkjjstzjeheasbphryteddfgiihyelnnhggreyihqxe
 * Smoking Wheels....  was here 2017 fjmdrovqemuyakhsnqvzejatbzawskozcqwytzffhxksfqrz
 * Smoking Wheels....  was here 2017 gjelvtrxnlgzpjvpxygzcbokibqushywmtwjfywugecxmxmz
 * Smoking Wheels....  was here 2017 amfnrkmtrvqxvcnyjpzcymhojxsbekjfqpkmcdeziuddhzlu
 * Smoking Wheels....  was here 2017 tpjsbgawzdvtszhcnsayvpgdxhkajhzsjqqfstmbjtvafsyg
 * Smoking Wheels....  was here 2017 bxpucfghdfwvlpftcsnnbprktfaetuefrmatqhgmnjsjwgqn
 * Smoking Wheels....  was here 2017 suapenmfabcrmutsefyyhybweadjbaovxbhntmfahdreiwky
 * Smoking Wheels....  was here 2017 sxejwqfdwyceqqncadzsikfhodophhaxomjeeflrgwtvudjd
 * Smoking Wheels....  was here 2017 ldsoahfwbkqhvnjigqqliwcqoligqesdlfmshteskohvszyz
 * Smoking Wheels....  was here 2017 jrputlmihfwkhzlaodbcppadcxwwqoaipvagqpyowmvawktq
 * Smoking Wheels....  was here 2017 hwbalhgulkbanwezbgswubmjjvrfznoqiithbkmzbegmeurk
 * Smoking Wheels....  was here 2017 hkmmricurguzfhdkzxgftygztspkqkfleuomtduarlolytwz
 * Smoking Wheels....  was here 2017 repnhgtalgyikogpygstoghayjrswteiyqrtabdxphcopbre
 * Smoking Wheels....  was here 2017 xiixkagnkgnkhhrgsrfmoextwuhsdmueqnohlpbdazmowwtd
 * Smoking Wheels....  was here 2017 vhynjvunlfwskhtfhwhokdppqhzeeprcoixnxmikibnnunaf
 * Smoking Wheels....  was here 2017 mrvnufymukodjseozrnkyydksjpfznumhgrdnrxughgunnpb
 * Smoking Wheels....  was here 2017 ekrlovlevllqgvtskhzsfmnbuuectuezprabqjcmrsawpvvn
 * Smoking Wheels....  was here 2017 krmwsriqfaophhrggcukrzaxsqckaghknflnwbjztqlqsllt
 * Smoking Wheels....  was here 2017 aultryvawegoxwicqtkrwydksdwylasxjvpwamnbxngcwsfb
 * Smoking Wheels....  was here 2017 amziaclyzgcivsiiueozqbqgfviubkkwqqmwhnoruepohgjd
 * Smoking Wheels....  was here 2017 tquzpwzbzrxzcdpiimezdhnnvnpfczlxebgkymtdjqupmyfv
 * Smoking Wheels....  was here 2017 rkwlneljmiutysftzcmprvckmeztargvasjsqtpwudkadumf
 * Smoking Wheels....  was here 2017 qeioehbeldahtipkvrwbxfvlkdahomkwlooeecwqmhgxfezs
 * Smoking Wheels....  was here 2017 rqspcrjxalejjakmddctqcmiyxowrtwhzstmtmombuknarwy
 * Smoking Wheels....  was here 2017 cqrzeadjqtdbsemhmpcjzlcdugrsqdtulocoqcypmselzeou
 * Smoking Wheels....  was here 2017 kidjohjnywxqaiamqmawimyawesmxlkfwudqmlnnyienvsri
 * Smoking Wheels....  was here 2017 lejrnsiqwuwrtkixqlkkhslnjafzetmrohndcebyudetoqcy
 * Smoking Wheels....  was here 2017 eutcttmepuozskctujwkqumkrhzenkxnbferrhoytyilknyh
 * Smoking Wheels....  was here 2017 zcadbcrxoluqusfhpklporzqmsemczuldyjgmairsuwfvhqe
 * Smoking Wheels....  was here 2017 jfdjntvvjlsxhxvfyzgxkrglrkajkingvdlbeuvswxlupytu
 * Smoking Wheels....  was here 2017 dohuoxhezxokqvgjustmtdujloesdoscmtfmojwtqvwirvgm
 * Smoking Wheels....  was here 2017 htwptanlnbyxppfwlortlwidftknjahipwogurkuqjebgpgv
 * Smoking Wheels....  was here 2017 eureyvhkmksmdnocmpzlquxtptvdfgjoyxsgfzscwnsovadt
 * Smoking Wheels....  was here 2017 isogghqamuxkmekrriumqdumposdgdisqocslrjdkparefnj
 * Smoking Wheels....  was here 2017 nausaptolfwhdkembhrabintimrgesvwyrlahmastczkgohb
 * Smoking Wheels....  was here 2017 uhvuvggmnydxuimpymfnudujfaoqyktkjlqxxluumurdgopj
 * Smoking Wheels....  was here 2017 llhxpzupempimhflvalqwmqiyajnusfysgygqrwpqtjisdvh
 * Smoking Wheels....  was here 2017 arfskrlwargwjwnqohnitpjvkkmngnqjbtuibtuqgfqwiiqv
 * Smoking Wheels....  was here 2017 hiseppmnbmmbzwtaeyxuyzkkuomkzypurwxmbhirwsjubnxl
 * Smoking Wheels....  was here 2017 jcimugjbjfwsbkqsyxhljhpunxdfagbocsekthmrbapjfgsr
 * Smoking Wheels....  was here 2017 lwrbugxgjjeyovydkipycnyafhpioccidsvblymxueqffjnm
 * Smoking Wheels....  was here 2017 eutourccuunzrtxvkpcgnwqgwtdhcidyvmiruuxwflbdtaxx
 * Smoking Wheels....  was here 2017 ghtycqevnlglzyvtxjeofvgcpmhvjztomajoplmisjsdxmvj
 * Smoking Wheels....  was here 2017 uzdkhrrytqwcdokygopgacofuczcjkynpjwnayffbsrpvjjm
 * Smoking Wheels....  was here 2017 auojhmkdwwgbdwnwzifcbqnpfjfjgftlaaclkmjvbnfzbmxc
 * Smoking Wheels....  was here 2017 ovamdzhmnymofohbwaiyrrkosgiepfofsolminlrybzfhzci
 * Smoking Wheels....  was here 2017 dprtflqfrwvfvkckzjhanrunlcyjbobybxpcrugldwugmevp
 * Smoking Wheels....  was here 2017 vqaheiyumyxvtmpbpfxtkijhwkuzrndaofozngtegsqmxqgm
 * Smoking Wheels....  was here 2017 xxsouizzirolyerjhsavmqdvqyaiqtxbaymbgbfcgpykagtx
 * Smoking Wheels....  was here 2017 yoshfktuyvvjqblzuixeaulkrtxylasxmqvnmueshvfwpbxx
 * Smoking Wheels....  was here 2017 rzgiuuolemadiziteqzzsfsndccsvlhsfhiuabjtuyixokrx
 * Smoking Wheels....  was here 2017 fvsxczwlgxtpszyutoyrjstwlmiptklwtaxozwvgkshvewen
 * Smoking Wheels....  was here 2017 vawlbplopovvumembhuycfpmgtszllixyfttululbdmfxjuq
 * Smoking Wheels....  was here 2017 asqrtrhtuhibtadkwfqsgxlqnxpjlliuvnioyfvuynmvmxdi
 * Smoking Wheels....  was here 2017 qgelmlsgwboyelgngyzemgvtkfnqkldpqxikkypbljbuwwda
 * Smoking Wheels....  was here 2017 sjzaxifqxfdfsvewllntoaoqheitiuosylrzeofggmjjjvwh
 * Smoking Wheels....  was here 2017 nxutwanoigvzinswbvfdrcphwqcclcutopqfriwpgwqdjpua
 * Smoking Wheels....  was here 2017 qalkmoqcwztmidccwmghduexaocehfepnzpinqdqrvnwrimj
 * Smoking Wheels....  was here 2017 udgwccwkkjfjdnrmxcbiomxazfzwnfjjcnhrngsbwwvrfiwr
 * Smoking Wheels....  was here 2017 bxpihdsbcsuknsbclnjtvylkdfoddkgkwiravdrxotpwfeco
 */
package net.yacy.kelondro.rwi;
import java.io.IOException;
import java.util.TreeMap;
import net.yacy.cora.order.ByteOrder;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.sorting.Rating;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.index.Row;
public interface Index <ReferenceType extends Reference> extends Iterable<ReferenceContainer<ReferenceType>> {
/**
* every index entry is made for a term which has a fixed size
* @return the size of the term
*/
public int termKeyLength();
/**
* merge this index with another index
* @param otherIndex
*/
public void merge(Index<ReferenceType> otherIndex) throws IOException, SpaceExceededException;
	/**
	 * add references to the reverse index
	 * if no references to the word are stored, the new Entries are added,
	 * if there are already references to the word that is denoted with the
	 * reference to be stored, then the old and the new references are merged
	 * @param newEntries the References to be merged with existing references
	 * @throws IOException
	 * @throws SpaceExceededException
	 */
	public void add(ReferenceContainer<ReferenceType> newEntries) throws IOException, SpaceExceededException;
	/**
	 * add a single reference to the reverse index
	 * if no references to the word are stored, the a new entry is added,
* if there are already references to the word hash stored,
* then the old and the new references are merged
	 * @param termHash
	 * @param entry
	 * @throws IOException
	 * @throws SpaceExceededException
	 */
public void add(final byte[] termHash, final ReferenceType entry) throws IOException, SpaceExceededException;
	/**
	 * check if there are references stored to the given word hash
	 * @param termHash
	 * @return true if references exist, false if not
	 */
	public boolean has(final byte[] termHash);
	/**
	 * count the number of references for the given word
	 * do not use this method to check the existence of a reference by comparing
	 * the result with zero, use hasReferences instead.
	 * @param termHash
	 * @return the number of references to the given word
	 */
	public int count(final byte[] termHash);
	/**
	 * get the references to a given word.
	 *  if referenceselection is not null, then all url references which are not
	 *  in referenceselection are removed from the container
	 * @param termHash
	 * @param referenceselection
	 * @return the references
	 * @throws IOException
	 */
	public ReferenceContainer<ReferenceType> get(byte[] termHash, HandleSet referenceselection) throws IOException;
/**
* remove all references for a word
* @param termHash
* @return the deleted references
* @throws IOException
*/
public ReferenceContainer<ReferenceType> remove(byte[] termHash) throws IOException;
/**
* delete all references for a word
* the difference to 'remove' is, that the removed element is not returned
* @param termHash
* @throws IOException
*/
public void delete(byte[] termHash) throws IOException;
	/**
	 * remove a specific reference entry
	 * @param termHash
	 * @param referenceHash the key for the reference entry to be removed
	 * @return
	 * @throws IOException
	 */
public boolean remove(byte[] termHash, byte[] referenceHash) throws IOException;
public void removeDelayed(byte[] termHash, byte[] referenceHash) throws IOException;
/**
* remove a set of reference entries for a given word
* @param termHash the key for the references
* @param referenceHash the reference entry keys
* @return
* @throws IOException
*/
public int remove(final byte[] termHash, HandleSet referenceHashes) throws IOException;
public int remove(final HandleSet termHashes, final byte[] urlHashBytes) throws IOException;
public void removeDelayed() throws IOException;
/**
* iterate all references from the beginning of a specific word hash
* @param startHash
* @param rot if true, then rotate at the end to the beginning
* @param ram
* @return
* @throws IOException
*/
public CloneableIterator<Rating<byte[]>> referenceCountIterator(
byte[] startHash,
boolean rot,
boolean excludePrivate
) throws IOException;
/**
* iterate all references from the beginning of a specific word hash
* @param startHash
* @param rot if true, then rotate at the end to the beginning
* @param ram
* @return
* @throws IOException
*/
public CloneableIterator<ReferenceContainer<ReferenceType>> referenceContainerIterator(
byte[] startHash,
boolean rot,
boolean excludePrivate
) throws IOException;
/**
* collect containers for given word hashes. This collection stops if a single container does not contain any references.
* In that case only a empty result is returned.
* @param wordHashes
* @param urlselection
* @return map of wordhash:indexContainer
*/
public TreeMap<byte[], ReferenceContainer<ReferenceType>> searchConjunction(final HandleSet wordHashes, final HandleSet urlselection);
/**
* delete all references entries
* @throws IOException
*/
public void clear() throws IOException;
/**
* close the reverse index
*/
public void close();
/**
* the number of all references
* @return the nnumber of all references
*/
public int size();
/**
* calculate needed memory
* @return the memory needed to operate the object
*/
public int minMem();
/**
* return the order that is used for the storage of the word hashes
* @return
*/
public ByteOrder termKeyOrdering();
/**
* ask for the Row that is used to construct one reference
* @return
*/
public Row referenceRow();
}
