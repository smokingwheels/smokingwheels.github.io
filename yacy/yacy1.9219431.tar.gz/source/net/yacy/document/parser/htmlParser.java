/** 
 * Smoking Wheels....  was here 2017 hrvgndxovtfjdummlthuuogvhtyuoappgzvnxkoqeigvaoka
 * Smoking Wheels....  was here 2017 fbuwikqpeqjeddrlxovsiwqkqoucohenfoubuwplpavssolf
 * Smoking Wheels....  was here 2017 wsympbmpqzyvqvsurdjyfpwkhmovocwkipwocbijurasdncf
 * Smoking Wheels....  was here 2017 csgjembtdncjpxfiutedpiqgkkpdusoiwsnxguvcemmiuxni
 * Smoking Wheels....  was here 2017 yizefgckxedxipdbqzrctzcomomntolokrmdwgimkvzhlmeb
 * Smoking Wheels....  was here 2017 ueosdfrgkcszijpitrrxlrlgfidrglxountqvulrmlrncgse
 * Smoking Wheels....  was here 2017 dasbopbehsqiizcpyvcymthlnkopgiqfbpozhzxcpfyhalbs
 * Smoking Wheels....  was here 2017 wxmojruiotavklfsiuetawjpqtfmbmomoljaqtuleiizsoiy
 * Smoking Wheels....  was here 2017 afburcsdjdgttzxpfdkgmvuiaoqtdjvqwxyumfkoxgtkyizk
 * Smoking Wheels....  was here 2017 ykxqxsufeaxoycjqdpollvuohfsehuwfuzfsssgpurgltusw
 * Smoking Wheels....  was here 2017 fjuerskmsvvyrozhyinrvfxkmlosnsjalalinxeyzmgjjekk
 * Smoking Wheels....  was here 2017 qdrsxkacxiexajkitoqptpaitemobjfbcpdmfqdizxhphzff
 * Smoking Wheels....  was here 2017 havwrkmmyjgpespwwwhaqwbxpodfmgopjmyhmbnpkjhxiyow
 * Smoking Wheels....  was here 2017 moqmkqufherosdsbucgacdkcqbjimcweasybfmvxhnhfladd
 * Smoking Wheels....  was here 2017 voyqsehhqdhmjjdnlhmyztobxigyczupfrhjnpvruistynwa
 * Smoking Wheels....  was here 2017 cdqqnlmuyzghelpawtgjnjidnjefobfvfwmctfpnizcyhyxw
 * Smoking Wheels....  was here 2017 knadxzeekqwgjnyojaaezvsbzhtqlwjfqchiqmljrwjphzqd
 * Smoking Wheels....  was here 2017 cinyitkamhuvlejknynkdhbqznuxmdqgglqkauwkstooyquq
 * Smoking Wheels....  was here 2017 siwdjumivivredicdosltcxcmvkzrxrreguwatrzsmbdnfgj
 * Smoking Wheels....  was here 2017 bqcbynxelnbvqklljdvwawavqbadijkpsafpafxtagnumeeq
 * Smoking Wheels....  was here 2017 fmkifonzmsylaeqllhjmimmmymetwazflorssiwrloserfzz
 * Smoking Wheels....  was here 2017 omgtmujkldzavacjzvbkhbnxclspdqxdfycmxkdvwbuhakjd
 * Smoking Wheels....  was here 2017 qlkllhsiafchwqgtvuxyvztiaruqcftbansoudkqmqcivzge
 * Smoking Wheels....  was here 2017 fjuszlcydqjedatkamctbvydxctbbzlahubstkvuungupkti
 * Smoking Wheels....  was here 2017 lqsfgxiqzidxxlmhxmcqjocygxejmlfjopwdkgqemeckdlje
 * Smoking Wheels....  was here 2017 qupspmlbamayqjrsaosrjeorsnygdikopzabqcjxlfscjcrl
 * Smoking Wheels....  was here 2017 ipfirjscynxaeosgguwfzevmgpdqbrtkogwdpovlypnbqpqe
 * Smoking Wheels....  was here 2017 jdmkjxtxtdwclagppnuvjbtubddunsdysyufrmckjnbvkllr
 * Smoking Wheels....  was here 2017 vtsnushxofgkuagvlgzkwuifphnfzxtkrypjmbkrmkgbljmk
 * Smoking Wheels....  was here 2017 byinkqjtxarjqzvgivdaclwromengayjgfgxyoilfzdsukkg
 * Smoking Wheels....  was here 2017 oocntvhikzasvskhdihzzkxhxkftibmomdxlerrctccbrued
 * Smoking Wheels....  was here 2017 gryvurqubsikifsvvzqwrhfovzybmgfbtgevohmgnztnqzyj
 * Smoking Wheels....  was here 2017 dndaqtdobearkrpwvlroozxatlzzedicpjresmzxhcyvktcn
 * Smoking Wheels....  was here 2017 otezrzxgvorzoqhqsldefofqkdffgkgfwnltopudxctyadjh
 * Smoking Wheels....  was here 2017 cdtunkeucidapvdsfczzplrotvtrqbrfparegisirxpcsipu
 * Smoking Wheels....  was here 2017 prxtbmmivdnumhwvmrlpugdezjwqrklcdlwidnsfzsasauag
 * Smoking Wheels....  was here 2017 cuummurhexemnejbvtawfvpdmahnuwuebpuhwgdpoyxosjae
 * Smoking Wheels....  was here 2017 xyxvdfuhpvsoebvrvdlwmiijbfubvfcxenjihymsihiouzgk
 * Smoking Wheels....  was here 2017 rzawrwbgujatfrqehwrznbyzoomftmadpowdpfqymssxmyrx
 * Smoking Wheels....  was here 2017 dzbyydciteeaszmjhhytksekgbtfwwowpgslexoynjpdjrkz
 * Smoking Wheels....  was here 2017 lfiqcpqxqemowhhgeytaoddhowempxujukslqeoocrwxdyxe
 * Smoking Wheels....  was here 2017 wgguoeuqxpqweaecnqvxqlaoelpuuhefzculwieaejqfvtvg
 * Smoking Wheels....  was here 2017 ayomyytlgvlqmyqmcldtnzlibkeclbjcgofzzbfryightjcf
 * Smoking Wheels....  was here 2017 rhgcdhemqoavschdaqwchkezkugoulhcyllylgtfwuhnjhwj
 * Smoking Wheels....  was here 2017 zpofgwucgtsresbcqupvkpggrrjsiycmpofluyanqcqrkfpg
 * Smoking Wheels....  was here 2017 emzpsnqaoodqkgdrmszalrazoomfwhguawmuzoosfbktzewq
 * Smoking Wheels....  was here 2017 xseldjadgldlcmxjjmbziyyizdpbknjujunodrggumyxgkrm
 * Smoking Wheels....  was here 2017 yifakumogbwahjbykkzjfdvsfhdlevknwuupqgauuqvqulee
 * Smoking Wheels....  was here 2017 krgyrkvrtippgfmlxzizlautpfswttngdtazdigeyyyqiyte
 * Smoking Wheels....  was here 2017 piubibbfhnzqnmkdlcsxqtakyjcavacmaredmhmpfbkwxzdg
 * Smoking Wheels....  was here 2017 caplzyoalyxxvyeowufnttdtdlmwlqwapynnvulltynotuem
 * Smoking Wheels....  was here 2017 rxqlnithgkkhennmfjbjwoxhjifqvvrxdamcorfkatyfjwbc
 * Smoking Wheels....  was here 2017 nfcrcxnjxtwavohyuiqhkcjocgwtoctjguwwicbitynlpxfq
 * Smoking Wheels....  was here 2017 wonxdoxyuexpintggpukzmvobphzjfmztgpfajpkwfjijyix
 * Smoking Wheels....  was here 2017 hsphfjdyrdktkcfwickanbvjecphgdnnttystdnaoluazghx
 * Smoking Wheels....  was here 2017 qshdfrulmikkcjkoegutcmelrrevmevznwifyiyviwkzxhgx
 * Smoking Wheels....  was here 2017 ayxbierykrhtqnglbojlcpwkympdosorqjnufzesvwdyzvrl
 * Smoking Wheels....  was here 2017 sxvwxsvzxishobxsowwegofeszswhpcczinukmrwzeaxdvfi
 * Smoking Wheels....  was here 2017 hkwroknortltqttznfihistxywraqveaobnvsmhrbslzrotn
 * Smoking Wheels....  was here 2017 pozvgphuqqqcvonxawyjorizvbuvwoqntcasnwculrztdnnj
 * Smoking Wheels....  was here 2017 rpjwbyzcbxqnlucqjleggiybvsrsnjrvbhtolshcwlnwflxj
 * Smoking Wheels....  was here 2017 xdosjhpchsblzwqjesuadtwbqhfkiztnkrsrjknuhtdhziog
 * Smoking Wheels....  was here 2017 vzfjvukrdntrepprfutbakrdemmxijmhuobqlpmfxnggqlkd
 * Smoking Wheels....  was here 2017 gdkgjuabmbvdcyphoxhxbveqqfvjtvvgomjibcibdyjftgqf
 * Smoking Wheels....  was here 2017 hzhxbyfpoeqazdohorxkqyjhnrwhduxqhhhwwbgfsllxbnqb
 * Smoking Wheels....  was here 2017 fajehbzyubuvhssxuxhrkvoyngljfbeauawnrxvwosmhpgcm
 * Smoking Wheels....  was here 2017 qckdtiqbwfcgwkkrcqlbgxitosspapgcezhxsewjwqyopryk
 * Smoking Wheels....  was here 2017 jgiehbtzuhthrfikmepdhtkdvxzewqdystbwitkjdmjeohhf
 * Smoking Wheels....  was here 2017 nujwbycfsfaczildjbfsygxtvcwoetywacxmdvsvapqwhvqj
 * Smoking Wheels....  was here 2017 jhbaluskceoeiivbfebxvnbneqgmspbixducbrjwmtvquipr
 * Smoking Wheels....  was here 2017 mncsbsxjqpfglyzuymccvyloxhewofgdmcyigzdwsuhqhzce
 * Smoking Wheels....  was here 2017 tpmjvdfjhdchicobpjoucdvgexbzyvijzqxzapcmfzrjiihc
 * Smoking Wheels....  was here 2017 eukmwrksguolgdlxmixxzzhiktmhjynfbmhecrmrprvnqcqa
 * Smoking Wheels....  was here 2017 crkzoeodysfgtmvqfgxlepcpjehmpiggnsffhnxnwqvbghur
 * Smoking Wheels....  was here 2017 dbdwntyldjwkpxcsocnwmiuhyyqnrzefkrusuuclftbgldqd
 * Smoking Wheels....  was here 2017 bzqorudxsjswtkzzpgyqduetjyupucefcxpmyjddcecmsdjq
 * Smoking Wheels....  was here 2017 ztdpexwvxravngiksgsrmxhrbjlgnfmldehrljhmekvovbks
 * Smoking Wheels....  was here 2017 fycvjzgxdnlujxjilwobdtkxtqkdpblmipwocedpldijuxke
 * Smoking Wheels....  was here 2017 ikfiwdoadhvlccmgpfkczsdrkmugbqubulotcjmycfzdwwia
 * Smoking Wheels....  was here 2017 dcomqshivrgutwixhpolfleieuytcekgvhxdvvhcoxjjomho
 * Smoking Wheels....  was here 2017 skhwtjhhlpdznlwjunkwetqoosmeifmizyosxsxanpjsqnsg
 * Smoking Wheels....  was here 2017 kwxhpzomkhaoxifysvtmmuuffugflmkudmnxgjxwzzbfdxgy
 * Smoking Wheels....  was here 2017 uhdwwqlvkduethvbxpoqbyembpkvmywliebgykaaczubhyxq
 * Smoking Wheels....  was here 2017 qtyxkslmkvnuagkpjdbxbvpukdffrwuhwppqkshcivfrpctp
 * Smoking Wheels....  was here 2017 cnqbivivpiqrzntomysevhctpojvotipjoxchkbbjxevvdgj
 * Smoking Wheels....  was here 2017 lepdcxfplurhdoeeuwhlamzgjirlxjwyqdyalwwbexslabbt
 * Smoking Wheels....  was here 2017 hnpegzjprqnhgdzzdzsemstmrcfzsqdbtpyybsllzuhtkccs
 * Smoking Wheels....  was here 2017 kqpptmhadpgrjgxvpphvksfvsukrgxbzbnktluxxeskfntoo
 * Smoking Wheels....  was here 2017 xuxysbvhdphrsdvrngkiegkzyqvzzosabsanignjmdzodtvv
 * Smoking Wheels....  was here 2017 cpxcnmzactesuhyuktwtkmrubaiptlprqgvpnlvxvsdtfdoh
 * Smoking Wheels....  was here 2017 ovjcuzccrpuokmqtddqlzvnkzramnnjswlapezpzmkdzbcsz
 * Smoking Wheels....  was here 2017 dnghlwrtwsfdnrphtuxybvsgymgxnayebvchsuxgvjrtdeld
 * Smoking Wheels....  was here 2017 wbvhptmivdwrkctmqefdakjajrqhikliuftutyapoapthbdj
 * Smoking Wheels....  was here 2017 cxoyrnqmbzgqpihohegclqrnzqajsnjswrzmdvmfrdzxlvmj
 * Smoking Wheels....  was here 2017 jyehgijcfritwaobpuafiyhztcncpghcjnaxbadkjnenxrle
 * Smoking Wheels....  was here 2017 ofrtfngkgydyffgupktzsyxuuznsiyfnrgjxxmzxbmvzfcdd
 * Smoking Wheels....  was here 2017 szgvtrbsjsbmweitpmxialqpqloqjagghutphghpljtbbwzs
 * Smoking Wheels....  was here 2017 ewjkgtwtbdsujjyffxfhxrthyynpnhwvbcdictrqmwbrmyqr
 * Smoking Wheels....  was here 2017 mqvoiuyjzrxomnmthsrffxtardnotrrabntqmovljzcbupbc
 * Smoking Wheels....  was here 2017 mjorvfvscauvfrqbvfnsduneaaxtimqwqpblvpxppvnslikg
 * Smoking Wheels....  was here 2017 gjuhyqhfocruubhgeyfqafamlshqvexpievttydcuvdhfwbq
 * Smoking Wheels....  was here 2017 cebgbxloxbfwuernytmamhptqqnyynwuygayezbaytcucftb
 * Smoking Wheels....  was here 2017 qqarudnotjgvytemyqigmkteoosprmgfqfwpeimvhlskjpim
 * Smoking Wheels....  was here 2017 quswatclcswpgulvfzyxcdhejifwjjyxrowofwlcfdpqpoah
 * Smoking Wheels....  was here 2017 fyilxizpdzlkzokrchwuskgkpeqdlpccqcsywsgvkgpelvex
 * Smoking Wheels....  was here 2017 qrjfvsdrhlpsqngffkubzhzsvnvfsyeiiykabglbwlwzzjne
 * Smoking Wheels....  was here 2017 osnikcynhldfaljahisaufyhdbwzelulxjemxcuhusrgmlzc
 * Smoking Wheels....  was here 2017 tgvbovxjcsfychlxnlvghszoqretchxjoxncucidqesnkory
 * Smoking Wheels....  was here 2017 hmnajmupvfdadjkudgrpwtcduqhwaaqlzkeyjkknahvlombg
 * Smoking Wheels....  was here 2017 oaabhzsvabozrdkbspyedkqxhhddqjmfywbknjnoztbayeuu
 * Smoking Wheels....  was here 2017 aqchxlxzishnlivednphzbdcdktmzhakorlbjpnrsmvkuwtq
 * Smoking Wheels....  was here 2017 plszdexftwmpmykymjxoniiamvndjcfbcjvsizjmprsdrcez
 * Smoking Wheels....  was here 2017 isdudxoyklllbgakzpiufbikuubogggmdtxnarjykuoxhplk
 * Smoking Wheels....  was here 2017 nzuofkwuvqvnqtwuhdqcqkjcttfmkmneovrtizdfblnqrjfs
 * Smoking Wheels....  was here 2017 ucmicwdqqwmnaeirfzsvssbhiicvvusxjzjbjpkqtpwpdqlw
 * Smoking Wheels....  was here 2017 xdclpqxsvvmkencuvlxooqcjtnbvvmssytmgoifwylhfcxge
 * Smoking Wheels....  was here 2017 zjynxizjqmeklabelcqcnaqzjlrzxzrwvxskoiwwhkpgkyce
 * Smoking Wheels....  was here 2017 jjmkjujhkyfzgekertppiaxazpvyubcywobwfyytvfxqzsqq
 * Smoking Wheels....  was here 2017 oxkeqekiyslwltofhlwjuylrmqqtmsoqcztgqvfyrspoemto
 * Smoking Wheels....  was here 2017 lctdpwqrdlyaysedjnpzbmbhcmlohebbwshjhvrbhefnltrg
 * Smoking Wheels....  was here 2017 cfsykmurfbbqbifyhmhholuphjwwszsluqiitcralzrgpgtg
 * Smoking Wheels....  was here 2017 uwtjlvzcptlficuxoerkxzyksqtjnwyhqtymxztaavaspzsh
 * Smoking Wheels....  was here 2017 duqoidmsayykmuipbrtqymbyibeastklmkikybrjfqrbsell
 * Smoking Wheels....  was here 2017 zbjvzrvtjjqgnintvgspwnypjnnbnzbwrcyxfhnunqfvmjdz
 * Smoking Wheels....  was here 2017 ibdumcvpyxwxsagkembcbapzgfkymaawusncisnepemrrhek
 * Smoking Wheels....  was here 2017 ogkfgimycuhwoisvteogccibrprkjpuzqgbifuhrkbqpgxgn
 * Smoking Wheels....  was here 2017 gmyhykcpojswwaiohkckybryqhkjfsyzhavfabordcyvnmhi
 * Smoking Wheels....  was here 2017 futhkthuikgupbtjyladspmagiacfqlwcqfobklvgobvynlc
 * Smoking Wheels....  was here 2017 mozuuatxnvhybtyhywshtoszaubayvlypvalbzebmvwgjtdk
 * Smoking Wheels....  was here 2017 lgesnzooqultsozpynzysbsrrejwcbjtpsffwdhnsqkdsfaz
 * Smoking Wheels....  was here 2017 qtbbevasjsnyjfjvtjtlnlaicedptixagpzmpnqofwcqhcaw
 * Smoking Wheels....  was here 2017 xbpfryrmriqmasstlvgjhkkhnrqkewyvvawbqzfxjsnhpxij
 * Smoking Wheels....  was here 2017 inbudwihtndnxjzkikzpktyfkwnvuerkxuobrpilwqntkliy
 * Smoking Wheels....  was here 2017 ervozoatamrqooibzxsemqxbkfpmlzniizbvovogthezsqsl
 * Smoking Wheels....  was here 2017 citrvdzvfscltdeffjjmlkwxnjbkdicjdwpxlgqvdqxguujw
 * Smoking Wheels....  was here 2017 woslnxvqgulzmadrdeebkroexheucljmrbqfrsqumvhzejnn
 * Smoking Wheels....  was here 2017 oqalgnjojtdkanfmauqutjbnbeobvumanhytyjvanjewocnw
 * Smoking Wheels....  was here 2017 necokwogzsufvcnwncntdorxqkdaddxnmslycousfvryaacs
 * Smoking Wheels....  was here 2017 hzsvpatrucfctnmkjdsglqxjqsyoamfrrpkiiyhfsfdjuidc
 * Smoking Wheels....  was here 2017 tbvqskmxtrmbtttwsfnyufpkfzjxtckpjlhsyjjfmseqkouh
 * Smoking Wheels....  was here 2017 ytsnxqnkcgbhcahgvvkpoetqulzovkqnedwhqzipfsqkplnv
 * Smoking Wheels....  was here 2017 eptkooyufdmghxgwixcjlqrzdnrfzghaxsbhgctowzqtkaym
 * Smoking Wheels....  was here 2017 bluhhhbzwrprccaeakpngyyoewnugnbupmdkykjlqintblah
 * Smoking Wheels....  was here 2017 kisozgidypnnopibzrctethuclypxowyraojdsfyzbwzchxm
 * Smoking Wheels....  was here 2017 gouvvzqqsvpzxqammhbupyvhjlmalvvrpbbjleqyqnpdghaq
 * Smoking Wheels....  was here 2017 yrnwdlzdoomnqtisfahudotaqhzuqblpgtrrseeplludokzn
 * Smoking Wheels....  was here 2017 cmqvprqofezxoqphwxsbrbsdyqpxngiksjoxdiphstufhxud
 * Smoking Wheels....  was here 2017 mcbacdeapkgbripaqiogjalzklrnhqkfhlfxbmyswqevyhpu
 */
/**
*  htmlParser.java
*  Copyright 2009 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 09.07.2009 at http://yacy.net
*
* $LastChangedDate$
* $LastChangedRevision$
* $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.parser;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.LinkedHashMap;
import org.apache.commons.io.IOUtils;
import com.ibm.icu.text.CharsetDetector;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.util.CommonPattern;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
import net.yacy.document.parser.html.ContentScraper;
import net.yacy.document.parser.html.ImageEntry;
import net.yacy.document.parser.html.ScraperInputStream;
import net.yacy.document.parser.html.TransformerWriter;
public class htmlParser extends AbstractParser implements Parser {
	/** The default maximum number of links (other than a, area, and canonical and stylesheet links) to add to a parsed document */
private static final int DEFAULT_MAX_LINKS = 10000;
public htmlParser() {
super("Streaming HTML Parser");
this.SUPPORTED_EXTENSIONS.add("htm");
this.SUPPORTED_EXTENSIONS.add("html");
this.SUPPORTED_EXTENSIONS.add("shtml");
this.SUPPORTED_EXTENSIONS.add("shtm");
this.SUPPORTED_EXTENSIONS.add("stm");
this.SUPPORTED_EXTENSIONS.add("xhtml");
this.SUPPORTED_EXTENSIONS.add("phtml");
this.SUPPORTED_EXTENSIONS.add("phtm");
this.SUPPORTED_EXTENSIONS.add("tpl");
this.SUPPORTED_EXTENSIONS.add("php");
this.SUPPORTED_EXTENSIONS.add("php2");
this.SUPPORTED_EXTENSIONS.add("php3");
this.SUPPORTED_EXTENSIONS.add("php4");
this.SUPPORTED_EXTENSIONS.add("php5");
this.SUPPORTED_EXTENSIONS.add("cfm");
this.SUPPORTED_EXTENSIONS.add("asp");
this.SUPPORTED_EXTENSIONS.add("aspx");
this.SUPPORTED_EXTENSIONS.add("tex");
this.SUPPORTED_EXTENSIONS.add("txt");
this.SUPPORTED_EXTENSIONS.add("msg");
this.SUPPORTED_MIME_TYPES.add("text/html");
this.SUPPORTED_MIME_TYPES.add("text/xhtml+xml");
this.SUPPORTED_MIME_TYPES.add("application/xhtml+xml");
this.SUPPORTED_MIME_TYPES.add("application/x-httpd-php");
this.SUPPORTED_MIME_TYPES.add("application/x-tex");
this.SUPPORTED_MIME_TYPES.add("application/vnd.ms-outlook");
this.SUPPORTED_MIME_TYPES.add("text/plain");
this.SUPPORTED_MIME_TYPES.add("text/csv");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String documentCharset,
final VocabularyScraper vocscraper,
final int timezoneOffset,
final InputStream sourceStream) throws Parser.Failure, InterruptedException {
return parseWithLimits(location, mimeType, documentCharset, vocscraper, timezoneOffset, sourceStream, Integer.MAX_VALUE, DEFAULT_MAX_LINKS, Long.MAX_VALUE);
}
@Override
public boolean isParseWithLimitsSupported() {
	return true;
}
@Override
public Document[] parseWithLimits(final DigestURL location, final String mimeType, final String documentCharset, final VocabularyScraper vocscraper,
		final int timezoneOffset, final InputStream sourceStream, final int maxLinks, final long maxBytes)
		throws Failure {
return parseWithLimits(location, mimeType, documentCharset, vocscraper, timezoneOffset, sourceStream, maxLinks, maxLinks, maxBytes);
}
private Document[] parseWithLimits(final DigestURL location, final String mimeType, final String documentCharset, final VocabularyScraper vocscraper,
		final int timezoneOffset, final InputStream sourceStream, final int maxAnchors, final int maxLinks, final long maxBytes)
		throws Failure {
try {
Charset[] detectedcharsetcontainer = new Charset[]{null};
ContentScraper scraper = parseToScraper(location, documentCharset, vocscraper, detectedcharsetcontainer, timezoneOffset, sourceStream, maxAnchors, maxLinks, maxBytes);
final Document document = transformScraper(location, mimeType, detectedcharsetcontainer[0].name(), scraper);
Document documentSnapshot = null;
try {
if (location.getRef() != null && location.getRef().startsWith("!")) {
documentSnapshot = parseAlternativeSnapshot(location, mimeType, documentCharset, vocscraper, timezoneOffset, maxAnchors, maxLinks, maxBytes);
} else {
if (scraper.getMetas().containsKey("fragment") && scraper.getMetas().get("fragment").equals("!")) {
documentSnapshot = parseAlternativeSnapshot(location, mimeType, documentCharset, vocscraper, timezoneOffset, maxAnchors, maxLinks, maxBytes);
}
}
} catch (Exception ex1) {
documentSnapshot = null;
}
return documentSnapshot == null ? new Document[]{document} : new Document[]{document, documentSnapshot};
} catch (final IOException e) {
throw new Parser.Failure("IOException in htmlParser: " + e.getMessage(), location);
}
}
/**
*  the transformScraper method transforms a scraper object into a document object
* @param location
* @param mimeType
* @param charSet
* @param scraper
* @return a Document instance
*/
private Document transformScraper(final DigestURL location, final String mimeType, final String charSet, final ContentScraper scraper) {
final String[] sections = new String[
scraper.getHeadlines(1).length +
scraper.getHeadlines(2).length +
scraper.getHeadlines(3).length +
scraper.getHeadlines(4).length +
scraper.getHeadlines(5).length +
scraper.getHeadlines(6).length];
int p = 0;
for (int i = 1; i <= 6; i++) {
for (final String headline : scraper.getHeadlines(i)) {
sections[p++] = headline;
}
}
LinkedHashMap<DigestURL, ImageEntry> noDoubleImages = new LinkedHashMap<>();
for (ImageEntry ie: scraper.getImages()) noDoubleImages.put(ie.url(), ie);
final Document ppd = new Document(
location,
mimeType,
charSet,
this,
scraper.getContentLanguages(),
scraper.getKeywords(),
scraper.getTitles(),
scraper.getAuthor(),
scraper.getPublisher(),
sections,
scraper.getDescriptions(),
scraper.getLon(), scraper.getLat(),
scraper.getText(),
scraper.getAnchors(),
scraper.getRSS(),
noDoubleImages,
scraper.indexingDenied(),
scraper.getDate());
ppd.setScraperObject(scraper);
ppd.setIcons(scraper.getIcons());
ppd.setPartiallyParsed(scraper.isLimitsExceeded());
return ppd;
}
public static ContentScraper parseToScraper(final DigestURL location, final String documentCharset, final VocabularyScraper vocabularyScraper, final int timezoneOffset, final String input, final int maxAnchors, final int maxLinks) throws IOException {
Charset[] detectedcharsetcontainer = new Charset[]{null};
InputStream sourceStream;
try {
sourceStream = new ByteArrayInputStream(documentCharset == null ? UTF8.getBytes(input) : input.getBytes(documentCharset));
} catch (UnsupportedEncodingException e) {
sourceStream = new ByteArrayInputStream(UTF8.getBytes(input));
}
ContentScraper scraper;
try {
scraper = parseToScraper(location, documentCharset, vocabularyScraper, detectedcharsetcontainer, timezoneOffset, sourceStream, maxAnchors, maxLinks, Long.MAX_VALUE);
} catch (Failure e) {
throw new IOException(e.getMessage());
}
return scraper;
}
/**
* Parse the resource at location and return the resulting ContentScraper
* @param location the URL of the resource to parse
* @param documentCharset the document charset name if known
* @param vocabularyScraper a vocabulary scraper
* @param detectedcharsetcontainer a mutable array of Charsets : filled with the charset detected when parsing
* @param timezoneOffset the local time zone offset
* @param sourceStream an open stream on the resource to parse
* @param maxAnchors the maximum number of URLs to process and store in the in the scraper's anchors property
* @param maxLinks the maximum number of links (other than a, area, and canonical and stylesheet links) to store in the scraper
* @param maxBytes the maximum number of content bytes to process
* @return a scraper containing parsed information
* @throws Parser.Failure when an error occurred while parsing
* @throws IOException when a read/write error occurred while trying to detect the charset
*/
public static ContentScraper parseToScraper(
final DigestURL location,
final String documentCharset,
final VocabularyScraper vocabularyScraper,
final Charset[] detectedcharsetcontainer,
final int timezoneOffset,
InputStream sourceStream,
final int maxAnchors,
final int maxLinks,
final long maxBytes) throws Parser.Failure, IOException {
	
String charset = null;
        if (documentCharset != null) {
charset = patchCharsetEncoding(documentCharset);
}
        if (charset == null) {
ScraperInputStream htmlFilter = null;
try {
htmlFilter = new ScraperInputStream(sourceStream, documentCharset, vocabularyScraper, location, null, false, maxLinks, timezoneOffset);
sourceStream = htmlFilter;
charset = htmlFilter.detectCharset();
} catch (final IOException e1) {
throw new Parser.Failure("Charset error:" + e1.getMessage(), location);
} finally {
if (htmlFilter != null) htmlFilter.close();
}
}
        if (charset == null) {
final CharsetDetector det = new CharsetDetector();
det.enableInputFilter(true);
final InputStream detStream = new BufferedInputStream(sourceStream);
det.setText(detStream);
charset = det.detect().getName();
sourceStream = detStream;
}
        if (charset == null) {
detectedcharsetcontainer[0] = Charset.defaultCharset();
} else {
try {
detectedcharsetcontainer[0] = Charset.forName(charset);
} catch (final IllegalCharsetNameException e) {
detectedcharsetcontainer[0] = Charset.defaultCharset();
} catch (final UnsupportedCharsetException e) {
detectedcharsetcontainer[0] = Charset.defaultCharset();
}
}
final ContentScraper scraper = new ContentScraper(location, maxAnchors, maxLinks, vocabularyScraper, timezoneOffset);
final TransformerWriter writer = new TransformerWriter(null,null,scraper,null,false, Math.max(64, Math.min(4096, sourceStream.available())));
try {
	final long maxChars = (long)(maxBytes * detectedcharsetcontainer[0].newDecoder().averageCharsPerByte());
	final Reader sourceReader = new InputStreamReader(sourceStream, detectedcharsetcontainer[0]);
			final long copiedChars = IOUtils.copyLarge(sourceReader, writer, 0, maxChars);
if(copiedChars > maxChars) {
	/* maxChars limit has been exceeded : do not fail here as we want to use the partially obtained results. */
	scraper.setContentSizeLimitExceeded(true);
} else if(copiedChars == maxChars) {
	/* Exactly maxChars limit reached : let's check if more to read remain. */
	if(sourceReader.read() >= 0) {
		scraper.setContentSizeLimitExceeded(true);
	}
}
} catch (final IOException e) {
		throw new Parser.Failure("IO error:" + e.getMessage(), location);
} finally {
writer.flush();
writer.close();
}
        if (writer.binarySuspect()) {
final String errorMsg = "Binary data found in resource";
throw new Parser.Failure(errorMsg, location);
}
return scraper;
}
/**
* some html authors use wrong encoding names, either because they don't know exactly what they
* are doing or they produce a type. Many times, the upper/downcase scheme of the name is fuzzy
* This method patches wrong encoding names. The correct names are taken from
* http://www.iana.org/assignments/character-sets
* @param encoding
* @return patched encoding name
*/
public static String patchCharsetEncoding(String encoding) {
        if ((encoding == null) || (encoding.length() < 3)) return null;
encoding = encoding.trim();
encoding = encoding.toUpperCase();
        if (encoding.startsWith("SHIFT")) return "Shift_JIS";
        if (encoding.startsWith("BIG")) return "Big5";
        if (encoding.startsWith("WINDOWS")) encoding = "windows" + encoding.substring(7);
        if (encoding.startsWith("MACINTOSH")) encoding = "MacRoman";
encoding = CommonPattern.UNDERSCORE.matcher(encoding).replaceAll("-");
        if (encoding.matches("GB[_-]?2312([-_]80)?")) return "GB2312";
        if (encoding.matches(".*UTF[-_]?8.*")) return StandardCharsets.UTF_8.name();
        if (encoding.startsWith("US")) return StandardCharsets.US_ASCII.name();
        if (encoding.startsWith("KOI")) return "KOI8-R";
        if (encoding.startsWith("windows") && encoding.length() > 7) {
final char c = encoding.charAt(7);
if ((c >= '0') && (c <= '9')) {
encoding = "windows-" + encoding.substring(7);
}
}
        if (encoding.startsWith("ISO")) {
if (encoding.length() > 3) {
final char c = encoding.charAt(3);
if ((c >= '0') && (c <= '9')) {
encoding = "ISO-" + encoding.substring(3);
}
}
if (encoding.length() > 8) {
final char c = encoding.charAt(8);
if ((c >= '0') && (c <= '9')) {
encoding = encoding.substring(0, 8) + "-" + encoding.substring(8);
}
}
}
        if (encoding.startsWith("ISO-8559")) {
encoding = "ISO-8859" + encoding.substring(8);
}
        if (encoding.matches("CP([_-])?125[0-8]")) {
final char c = encoding.charAt(2);
if ((c >= '0') && (c <= '9')) {
encoding = "windows-" + encoding.substring(2);
} else {
encoding = "windows" + encoding.substring(2);
}
}
return encoding;
}
/**
* Implementation of ajax crawling scheme to crawl the content of html snapshot page
* instead of the (empty) original ajax url
* see https://developers.google.com/webmasters/ajax-crawling/docs/specification
* Ajax crawling sheme is denoted by url with anchor param starting with "!" (1)
* or by a header tag <meta name="fragment" content="!"/>
*
* It is expected that the check for ajax crawling scheme happend already so we can directly
* try to get the snapshot page
*
* @param location original url (ajax url)
* @param mimeType
* @param documentCharset
* @param vocscraper
* @param timezoneOffset
* @param maxAnchors the maximum number of URLs to process and store in the in the scraper's anchors property
* @param maxLinks the maximum number of links to store in the document
* @param maxBytes the maximum number of content bytes to process
* @return document as result of parsed snapshot or null if not exist or on any other issue with snapshot
*/
private Document parseAlternativeSnapshot(final DigestURL location, final String mimeType, final String documentCharset,
final VocabularyScraper vocscraper, final int timezoneOffset, final int maxAnchors, final int maxLinks, final long maxBytes) {
Document documentSnapshot = null;
try {
final DigestURL locationSnapshot;
if (location.getRef() != null && !location.getRef().isEmpty() && location.getRef().startsWith("!")) {
if (location.getSearchpart().isEmpty()) {
locationSnapshot = new DigestURL(location.toNormalform(true) + "?_escaped_fragment_=" + MultiProtocolURL.escape(location.getRef().substring(1)));
} else {
locationSnapshot = new DigestURL(location.toNormalform(true) + "&_escaped_fragment_=" + MultiProtocolURL.escape(location.getRef().substring(1)).toString());
}
} else {
locationSnapshot = new DigestURL(location.toNormalform(true) + "?_escaped_fragment_=");
}
Charset[] detectedcharsetcontainer = new Charset[]{null};
InputStream snapshotStream = null;
try {
	snapshotStream = locationSnapshot.getInputStream(ClientIdentification.yacyInternetCrawlerAgent);
	ContentScraper scraperSnapshot = parseToScraper(location, documentCharset, vocscraper, detectedcharsetcontainer, timezoneOffset, snapshotStream, maxAnchors, maxLinks, maxBytes);
documentSnapshot = transformScraper(location, mimeType, detectedcharsetcontainer[0].name(), scraperSnapshot);
} finally {
	if(snapshotStream != null) {
		try {
			snapshotStream.close();
		} catch(IOException e) {
			AbstractParser.log.warn("Could not close snapshot stream : " + e.getMessage());
		}
	}
}
AbstractParser.log.info("parse snapshot "+locationSnapshot.toString() + " additional to " + location.toString());
} catch (IOException | Failure ex) { }
return documentSnapshot;
}
public static void main(final String[] args) {
DigestURL url;
try {
url = new DigestURL(args[0]);
final byte[] content = url.get(ClientIdentification.yacyInternetCrawlerAgent, null, null);
final Document[] document = new htmlParser().parse(url, "text/html", StandardCharsets.UTF_8.name(), new VocabularyScraper(), 0, new ByteArrayInputStream(content));
final String title = document[0].dc_title();
System.out.println(title);
} catch (final MalformedURLException e) {
e.printStackTrace();
} catch (final IOException e) {
e.printStackTrace();
} catch (final Parser.Failure e) {
e.printStackTrace();
} catch (final InterruptedException e) {
e.printStackTrace();
}
System.exit(0);
}
}
