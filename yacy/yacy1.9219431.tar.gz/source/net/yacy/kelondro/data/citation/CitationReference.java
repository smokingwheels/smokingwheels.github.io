/** 
 * Smoking Wheels....  was here 2017 hxzerlmzsqtkbrcgwxbxeruvirtnqdnhmsuukfzlvzqilcje
 * Smoking Wheels....  was here 2017 ifjxvyaifvgklhwrvighdjmlcofdfeihpedbkhshecnknjgk
 * Smoking Wheels....  was here 2017 dhxkqxerhvfcfmftneailgnkzbfklqcmpbucuquflxhjxftq
 * Smoking Wheels....  was here 2017 omvrmnfgxsaawbnjzdwfuvlhenideqlatfkhiwzxbzshpzsg
 * Smoking Wheels....  was here 2017 qmpvzhqofrfzbelqldnjyuzvckllhnhgqvajfbilqbxmthhw
 * Smoking Wheels....  was here 2017 rfxiyyfiqiqcvbwyogwlcdezlmoocwtuziugtjbbeffmyyvh
 * Smoking Wheels....  was here 2017 etrvmjzowjjpkkxwbydknchbbwacanfnxhddphreuredwbzt
 * Smoking Wheels....  was here 2017 zpdiawdmtwschaziyvtlwbvmdtkwuoioqrulnnzqxzpmmyrn
 * Smoking Wheels....  was here 2017 citycwgqodfjdyrkpvmzzvnadrowljyhtqsvsazjfypvafzh
 * Smoking Wheels....  was here 2017 vxeeocbtpqunzpymncerzhlsslomdmfiaobhmzxqpomszriw
 * Smoking Wheels....  was here 2017 slkqomouqekubnwfmbdnfsuttcrfluonociymyhyfcvzcljl
 * Smoking Wheels....  was here 2017 oiphlgbbntmvvowlohsqhocrlwnwziozodegnowbncmrjwyj
 * Smoking Wheels....  was here 2017 kgfiuxaalsniavogaurnbmeeehyovmedpwoxrurxfimczoff
 * Smoking Wheels....  was here 2017 nczemdgkvnjlqqwclqyuqnzhreyoeulonqsvkxzvdvdukhox
 * Smoking Wheels....  was here 2017 maunpxsfizdmwowopgtkiwuhvnykmevehebffihgmwbqleqn
 * Smoking Wheels....  was here 2017 bkxhnlssxccxgmzmnimovzcquqkzmqzagihmatiyrabpzohm
 * Smoking Wheels....  was here 2017 hytrvetkqevqlmwansxsxorbzzggfpsnygjiweewkzfbibsj
 * Smoking Wheels....  was here 2017 nnackwozbtfrnxjncpxmspoocknpvofidjmrevbiovwnymgc
 * Smoking Wheels....  was here 2017 fhrgilentogiqhqqdjtwpiakbxnnxlvgxicsndluhvowoyns
 * Smoking Wheels....  was here 2017 fqwbzdwfqrhehobfpqvzednczuwxbhgknzywuweabndbdtmr
 * Smoking Wheels....  was here 2017 ofcszkdoyiyzfshjukwihvvjinisilignowvaxfznqrmxnfn
 * Smoking Wheels....  was here 2017 oybrdzsibbzwkeemgsunahzftyaiznfhsleoqowyphlqjcdf
 * Smoking Wheels....  was here 2017 szsoovrmprndbmxevbwotufweafhkihndggeffoklrckgovu
 * Smoking Wheels....  was here 2017 vrfjqdghoewhrmvjnamqcucwtcojlzfybxveppdbmilunfgr
 * Smoking Wheels....  was here 2017 ytagyjygbvpeahpcpoicxyixxqwrzuuzbovfxtpzjcmcksnl
 * Smoking Wheels....  was here 2017 jcwrjgncoenvafctqtkrhiyaildnhkghyqlfmudjbxqxkvzz
 * Smoking Wheels....  was here 2017 qvsgzuzvraspxvlalcwipbelxoukvpzsstekzgjtrdlagshm
 * Smoking Wheels....  was here 2017 ojrzedqsjjnafbbraeefkqprvgiejmnirusdeuzvrgrnxrjf
 * Smoking Wheels....  was here 2017 ejhbnuyftmnxqxoysybuptykmbpxwkwojzyegkzqramrphhv
 * Smoking Wheels....  was here 2017 tsevxlrcixnidtvcamlshlesptsxnzcaprdlmirkqneavlnf
 * Smoking Wheels....  was here 2017 vpjbkcvirkpozdavsgnxvvqvaiyrwzpojnsbozoqsahlheqn
 * Smoking Wheels....  was here 2017 gkaqjytfuabeqznyxxsoulufzcwbpoaibljnhckbjzrzawob
 * Smoking Wheels....  was here 2017 atpullveuamzuiyqwhudbzkqwpidsagrdoanurfsegkxfbjm
 * Smoking Wheels....  was here 2017 kptxlhyacytbnnegcqritkmciokflzkgkiyykwfudvuuirnq
 * Smoking Wheels....  was here 2017 abmsmnatkowszdjjlhnzexiuibkvggxwxinztfyujalmesqr
 * Smoking Wheels....  was here 2017 pozcygiopwelqbxxxxvkazkhziyuxyjszoncrifnhhdzqooz
 * Smoking Wheels....  was here 2017 fssglblywfgdhilzukhxbimisyudikscdbuyhhyxqmzqaumc
 * Smoking Wheels....  was here 2017 dlirtobsqbyuwhvyryvhkypvgqafveasdiqmzfmfgphytgtz
 * Smoking Wheels....  was here 2017 xyvybtfuofhuqofkhxrjmaadmlapuesjbzlwhqhzixqupbas
 * Smoking Wheels....  was here 2017 jojcswemorqpbzahtzglvzfrnrhbakkffxxocfdxgyvfnner
 * Smoking Wheels....  was here 2017 mykfhjlfuuncvqvrhahwhqyfwvsqlgapcgafnzaatmyntfjm
 * Smoking Wheels....  was here 2017 qbrvqzuvravizvoymeribvhtdsisjiqenlyuycfntojgtzya
 * Smoking Wheels....  was here 2017 hzbowpfgxdqotejscxsvkxlngiltelsuoddmxahyilpfizoj
 * Smoking Wheels....  was here 2017 hevjjnaskfekoopvfvtlzfxbkysqrrvomgirhnxazrmmjlcy
 * Smoking Wheels....  was here 2017 qgkksequhncqfzwmbvnsponbacwkvjxwuwlcgndtjacjebtj
 * Smoking Wheels....  was here 2017 rdmdthxeangipwdzgczgkvgosoajvdajjlqrbgfkjmukepvl
 * Smoking Wheels....  was here 2017 xyagquuvgcqubtnzoajatiitlknbfvrweqlojerlejclcezk
 * Smoking Wheels....  was here 2017 ddfrryocwepozmjiagbffkifjvwhrmjonhmgazhpffwmzddn
 * Smoking Wheels....  was here 2017 kimomftjccsmceiexrugrxypxlzeemcszquidrbxeuexackm
 * Smoking Wheels....  was here 2017 alpkxgdlikwpmdhwulmufrgztywzakybjbmvclfpxchfrvec
 * Smoking Wheels....  was here 2017 npkvccriguafgzlalzkugampukxgpcikqdaxltheqlwgsmbn
 * Smoking Wheels....  was here 2017 rffujxqgtjpwzocnyyxlhidxedpusqvxdweybibksjsacjzd
 * Smoking Wheels....  was here 2017 nzklifosajdkixxmnfuegkzqipvshjkwkivraenfxpwxbbbo
 * Smoking Wheels....  was here 2017 ksrhwqfmlilwiluhuyyqgcbvzpqgpwdzgzeatkyxberkblsr
 * Smoking Wheels....  was here 2017 vrazbfomsapperwnmoovqtptzdjbcalcsmsevovzjlsjwono
 * Smoking Wheels....  was here 2017 pepkgeybtmybjmncsrcxzsdvnopwovyjbrcobjydgvuvlukp
 * Smoking Wheels....  was here 2017 txwvbxupsabeqzkdrghgdukwaidtxtncvshwqthkjezcasnk
 * Smoking Wheels....  was here 2017 ptnpiexybctxymjzajbqgxlvegbakgiyvbnavxdbqmqscefx
 * Smoking Wheels....  was here 2017 qxnmfyhbjncqnophlmpxrgmzvisgmhttdiefhjanfaioigde
 * Smoking Wheels....  was here 2017 sscjalfeqikxwbkxbgjizibvfwqgywlrzlawxurpnjvpugep
 * Smoking Wheels....  was here 2017 vwqkicetauhmscnydnbhbwybskratjgcynzrrecggghfrvmt
 * Smoking Wheels....  was here 2017 ihwccqzqxlnmaauufmqlztctbrxzcjipvzfobspthszymulp
 * Smoking Wheels....  was here 2017 rbtciaotzagebjibcohudhwcbsrpnrbbrmgsqwqpwamowfre
 * Smoking Wheels....  was here 2017 tqmikmgjeqscganpvilmcxrpzvmrrlcqsysofjanitqexmbw
 * Smoking Wheels....  was here 2017 nrmzzmnyqmodjbbpquvytiizeofipzhrpmpvzesnjpmbudtj
 * Smoking Wheels....  was here 2017 iammwtdhucohkutjeakxemvhjpxwnwvtanbjfnavwqktzacl
 * Smoking Wheels....  was here 2017 sxkoefdihiuwnwvoelifsqltlbyuxybvbsplovlycexdfgvh
 * Smoking Wheels....  was here 2017 lrmcgctkcdplgcpaqtcdbfswofvyliqyayxlwwsrjrwfnesg
 * Smoking Wheels....  was here 2017 ozdhswnxiupvioswyujbyyijenlkfjknljxbfoxxkziibjzy
 * Smoking Wheels....  was here 2017 ktcokgeqlwnctpcmpscroujgxvvljppeckugzdfzcbrziqzf
 * Smoking Wheels....  was here 2017 ldhqmftpbcnnruvnjznygzbtsciqkwmtbsbduaeiqfjbdcjg
 * Smoking Wheels....  was here 2017 oowkfynadowrqajvjebzpzxksrmubhukpejgmaotlzinjdzk
 * Smoking Wheels....  was here 2017 spjbhyyjwmejjjhnugkilmsykbezhfjlgyreeajfdcquggag
 * Smoking Wheels....  was here 2017 gglbmxvmplfrvdmyginoyllijbkmjfjowlexegwysqniijvs
 * Smoking Wheels....  was here 2017 rpbbzvegaedwgydtnvprkdjwpqowtdepkhhpdfpmgwqainbw
 * Smoking Wheels....  was here 2017 vbkzcwgzcsfodppvqkbvlzazfcezebjsfkurxogogiuwecpc
 * Smoking Wheels....  was here 2017 shyblnodyjamfgmgyzrmyremqycvqjyevypwpixeitbfeqob
 * Smoking Wheels....  was here 2017 qfirwmwmapktketlxqjhafvioaksioysahxcnrunlftpszjp
 * Smoking Wheels....  was here 2017 eyoomtebyglrazlzivhfzvfuxikgtouewddmickesylvpgrv
 * Smoking Wheels....  was here 2017 axvqqotarikunoatifxklxvjucqfqkcqqjaowhovpnzyuuhd
 * Smoking Wheels....  was here 2017 itoayhcxjcyxpycxcrziggntrxaqzmumwcmygffntrkimekd
 * Smoking Wheels....  was here 2017 iklggszmlcvcglotgjjqovgzfnoxziajjutoucrlblblffkr
 * Smoking Wheels....  was here 2017 pzmyrvltocdrstoyorjhrtgiizomdvcdeagqdlldtdnerbxx
 * Smoking Wheels....  was here 2017 xwwbotsxqdfemqljchilgpcfenrgebsxpuspcxgifhpowauf
 * Smoking Wheels....  was here 2017 huztnbimwmqkhewdccaocammesqgbjtbdebcvlcacpkwaqge
 * Smoking Wheels....  was here 2017 copmkjzfqrelctsqcgjiiamaaipubhjgqpncriiliefspvpr
 * Smoking Wheels....  was here 2017 ukqxisucqlzpdydlzdorhtheqiwjqtxhctmtgajccgqwirnw
 * Smoking Wheels....  was here 2017 fsgaqgyjtxjlwonlslbtqtmjdcyxmuzivmrnjeatvjmkfmxc
 * Smoking Wheels....  was here 2017 jczyynyoegvsbtntpaozervkzctjqsoskycceuhkdhvqlvwz
 * Smoking Wheels....  was here 2017 pmmdcepjjbhoruyufbadbogfvcicifsdoowkzclgzczcopuj
 * Smoking Wheels....  was here 2017 largfexvxctgyiadhyqboncdoezqzawjjznplozwnznqgvil
 * Smoking Wheels....  was here 2017 rdvgqudetjpijdcryjwzjcvokohvjhrpddrdkwrxfoihnyin
 * Smoking Wheels....  was here 2017 ilhizltxcejqqjumkejiiaghuucsmjyejdhsyznlqnkiplzg
 * Smoking Wheels....  was here 2017 rxwxcwptibwetiaagodumeiihrlpnuwtxjqglduruycjyfrm
 * Smoking Wheels....  was here 2017 iplrbapsctfiyqxvhxjggvjxxesbzlvdtncxnvadudzfhizj
 * Smoking Wheels....  was here 2017 bygohcbbkhrpscwvnvmzflwnuqkwokmmfnkezsyncowxpdwg
 * Smoking Wheels....  was here 2017 wqrtipnhizxvtvmcgieifsoxiokchzqfwmlrytoxiawtefku
 * Smoking Wheels....  was here 2017 bnnqcfrchirbbdrbbllakqmbfstbkvnwlunkvfellnhhklzu
 * Smoking Wheels....  was here 2017 fuqzqypnadbpxqphrrlzckxgjeuiismizdamdogrqksjcwhl
 * Smoking Wheels....  was here 2017 cwhqiynukkjareprfqrlxnhzzdbsvuetwkqjvlojgdxaewfb
 * Smoking Wheels....  was here 2017 tixwutylplgdfviixettrpmzkelgwjlnotitywdmznaoxzvh
 * Smoking Wheels....  was here 2017 mdeawzqdbslykyrqiosqnskfjbygsamfwohovbghuojptboa
 * Smoking Wheels....  was here 2017 vlbwrsqzkbbvncufgbravakztvyguqpsvnzzdmkguomvmgaj
 * Smoking Wheels....  was here 2017 oqsgocecomkibdaytldcdaxtttadwgnduncmsviekbekavdr
 * Smoking Wheels....  was here 2017 tirlcpucshcfsdbxcovijktgtjywygbwfsprqcbziupqpkao
 * Smoking Wheels....  was here 2017 rnoveyfrhyypmmtnvoqipdxnllvvfekozlrogmvymuaatvby
 * Smoking Wheels....  was here 2017 xgjcxbmuyhztpsgktvucflqttzzodxyabmugfkfpajajdewx
 * Smoking Wheels....  was here 2017 eaheqgvtphognsxjxbsutumnvhzwnogktqpgjrxriakvvukv
 * Smoking Wheels....  was here 2017 pkthzxublggxanlppddvdwdmcwrugjhbqbcftezddoipzgsi
 * Smoking Wheels....  was here 2017 limuutdkvtxtanqmifaxkqssfocqqadqmflbvdrfizaiclgh
 * Smoking Wheels....  was here 2017 fzklduwummodvhsoysnyzjjkdipadifajsdzdblmboctxkqv
 * Smoking Wheels....  was here 2017 tttdkefnhnoowratlgcelmrbzltrljdgnlvlnqdquwjzkmth
 * Smoking Wheels....  was here 2017 bgxbfltaldlxwtfedtmzqsklfmjsonvunpnbdvsrdpyhuisi
 * Smoking Wheels....  was here 2017 mkqrkgecjwcevvdfoipbsaoolenktijfeojwhvmvbwcgoryv
 * Smoking Wheels....  was here 2017 nkwqbporsloraozmnlqjypjprpoimqfknzvyqewqsxmrlsbw
 * Smoking Wheels....  was here 2017 zpvworccjzdavtcvbsbazxidzzahloymvupuznsumgvqlsyv
 * Smoking Wheels....  was here 2017 xrxpnyjuorlzbmcjlboosshwvxujqklvrbqbmvajcrgkuhsi
 * Smoking Wheels....  was here 2017 omvfudcmrbgprdyngpcoeyeuxcwviuxbuhdsliankfbpxhvh
 * Smoking Wheels....  was here 2017 ogollghgjyrfwgtwguwbuviebpqhyoqahcowmmgurdwyovvt
 * Smoking Wheels....  was here 2017 phgewkggojbjeswinfiddvemosqmgtjwlipbmblyfzmoterd
 * Smoking Wheels....  was here 2017 vjlprelbmoywhoyyiwehaqnmsxrofuxyuffxnxqytnytszmb
 * Smoking Wheels....  was here 2017 lhtesfqjmcdufewdeuieqgjehawsbflwcdoizjbbetqbwbqk
 * Smoking Wheels....  was here 2017 bgdpbmwefstkedunymzthwaudboqhviolsdokugtrabhznug
 * Smoking Wheels....  was here 2017 lqwtcfjtrmciqhbzporfpyxwlhgapueccwpztzzurucmbqua
 * Smoking Wheels....  was here 2017 pchvlwrpzqtiiskqmxaykfwbqguzakyvpuyiawgevwvaicuh
 * Smoking Wheels....  was here 2017 woeixenlosnlhtpvcrzrvqwmjshvshtluvjmqqiebhnkfrfz
 * Smoking Wheels....  was here 2017 uelvqbygbmmbqzvehhthelfhosbcggytrqgrfvsfohulmmqe
 * Smoking Wheels....  was here 2017 eiijzufikazrzgnpbkvadbjzknqpgkexnejincecrlledwzf
 * Smoking Wheels....  was here 2017 zqfbnuveuoocyrgerxwgnfcjhrxlubihynqctksvdmpzjkju
 * Smoking Wheels....  was here 2017 pcwjdunmqqckooxhtzvslwlkxxwwcvomrdhygzppwmnjryfs
 * Smoking Wheels....  was here 2017 nteyytjgobpxbmrobzxiggqidixloogktqsboijzzruduoce
 * Smoking Wheels....  was here 2017 ocktgxotnuldyixwponhowfredpazhadnxqvpcsqyqhkrpzl
 * Smoking Wheels....  was here 2017 ttyzsrqnsdfywegirrlzfiydmxsqjlubmeaalhsqkdakpqyg
 * Smoking Wheels....  was here 2017 jpobdvkfmrqjwjoiwlpehsutqkjpworulublmcpdgdjtzokk
 * Smoking Wheels....  was here 2017 zudqrhuxncxselalzgdrfdbtpqwlamaflkfkhaxttzwfqkza
 * Smoking Wheels....  was here 2017 jtwsrhduumhnghapzuouodgpoxvanholuxehstjdfeiwmopn
 * Smoking Wheels....  was here 2017 pdgkshxjkdjqvadwgxoxdkdcxsaikibwanwtwgahinwatpim
 * Smoking Wheels....  was here 2017 yvzerzwlvnycxxhrgvbrcwrgiwntvfucxontdtcnbaufyipt
 * Smoking Wheels....  was here 2017 xzzsrkbyslcfspqovxhcvuffsksvjtaznsomcsdhoyriuwan
 * Smoking Wheels....  was here 2017 jamyassdyxfnsxomzurhwqfpgociqblqdxsjpvxigvjignnd
 * Smoking Wheels....  was here 2017 hoxbijinsguwqxrnbkyscclbjwnismymhgxctbjqtlxopyfe
 * Smoking Wheels....  was here 2017 aoymmcswlysilzwbpwzbqdxqsdcdtordueipyrvmavpphylo
 * Smoking Wheels....  was here 2017 ccowpwwdvuzdlrhriqbgvzwofjcihezkrilascujfgbgapyj
 * Smoking Wheels....  was here 2017 gqzfzxaosuzxawiijipmhcviavdrbkmmgqzwzbazugcovgna
 * Smoking Wheels....  was here 2017 pvprhqsrighlzppbywhewfpsocahzperaewuwmnjiqvvwnid
 * Smoking Wheels....  was here 2017 lndrivrgcrrughagrjcbqgdrnxvljjbqvlgsqqouwjmqsfun
 * Smoking Wheels....  was here 2017 gxoxglzfqxggclsohgfzamtmvhwsqmqhrarvyzqslsstbknj
 * Smoking Wheels....  was here 2017 vjchjqvvxwjlzybvveceohxppnsxnclqxvuorenwphihwmjz
 * Smoking Wheels....  was here 2017 hpcaixtqbxocqwreqblcdmkvhegaanleaanpxgghxvknjanb
 * Smoking Wheels....  was here 2017 wljnyznimnqhbpnafaejwzfcoylmjitluacwzjaeiifaavik
 * Smoking Wheels....  was here 2017 ddunjvdyxnsjlqqxjmnzczqsixstbksiimyonbkbackpqamf
 * Smoking Wheels....  was here 2017 vzoxxqwsfxcvhxmtecxckzddujpruvbywhvdkzdskruhdzut
 * Smoking Wheels....  was here 2017 brevfxfcoyioilrrwtbdsrodhuxhoxoszopgrcgbdukktflt
 */
/**
*  CitationReferenceRow
*  Copyright 2012 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 13.02.2012 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.kelondro.data.citation;
import java.io.Serializable;
import java.util.Collection;
import net.yacy.cora.date.MicroDate;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.util.ByteArray;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.index.Column;
import net.yacy.kelondro.index.Row;
import net.yacy.kelondro.index.Row.Entry;
import net.yacy.kelondro.rwi.Reference;
public class CitationReference implements Reference, Serializable {
private static final long serialVersionUID=1920200210928897131L;
public static final Row citationRow = new Row(new Column[]{
new Column("h", Column.celltype_string,    Column.encoder_bytes, Word.commonHashLength, "urlhash"),
new Column("m", Column.celltype_cardinal,  Column.encoder_b256,  2, "lastModified"),
new Column("r", Column.celltype_cardinal,  Column.encoder_b256,  2, "reserve")
},
Base64Order.enhancedCoder
);
private static final int col_urlhash       =  0;
private static final int col_lastModified  =  1;
private static final int col_reserve       =  2;
private final Row.Entry entry;
public CitationReference(
final byte[]   urlHash,
final long     lastmodified  // last-modified time of the document where word appears
) {
assert (urlHash.length == 12) : "urlhash = " + ASCII.String(urlHash);
this.entry = citationRow.newEntry();
final int mddlm = MicroDate.microDateDays(lastmodified);
this.entry.setCol(col_urlhash, urlHash);
this.entry.setCol(col_lastModified, mddlm >> 2);
this.entry.setCol(col_reserve, 0);
}
private CitationReference(final byte[] row) {
this.entry = citationRow.newEntry(row);
}
public CitationReference(final Row.Entry rentry) {
this.entry = rentry;
}
@Override
public CitationReference clone() {
final byte[] b = new byte[citationRow.objectsize];
System.arraycopy(this.entry.bytes(), 0, b, 0, citationRow.objectsize);
return new CitationReference(b);
}
@Override
public String toPropertyForm() {
return this.entry.toPropertyForm('=', true, true, false, false);
}
@Override
public Entry toKelondroEntry() {
return this.entry;
}
@Override
public byte[] urlhash() {
return this.entry.getColBytes(col_urlhash, true);
}
public byte[] hosthash() {
byte[] uh = this.entry.getColBytes(col_urlhash, true);
byte[] hh = new byte[6];
System.arraycopy(uh, 6, hh, 0, 6);
return hh;
}
public int virtualAge() {
return (int) this.entry.getColLong(col_lastModified);  // this is the time in MicoDateDays format
}
@Override
public long lastModified() {
return MicroDate.reverseMicroDateDays(((int) this.entry.getColLong(col_lastModified)) << 2);
}
@Override
public String toString() {
return toPropertyForm();
}
@Override
public boolean isOlder(final Reference other) {
        if (other == null) return false;
        if (this.lastModified() < other.lastModified()) return true;
return false;
}
private int hashCache = Integer.MIN_VALUE;
@Override
public int hashCode() {
        if (this.hashCache == Integer.MIN_VALUE) {
this.hashCache = ByteArray.hashCode(this.urlhash());
}
return this.hashCache;
}
@Override
public boolean equals(final Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof CitationReference)) return false;
CitationReference other = (CitationReference) obj;
return Base64Order.enhancedCoder.equal(this.urlhash(), other.urlhash());
}
@Override
public int distance() {
throw new UnsupportedOperationException();
}
@Override
public void join(Reference oe) {
throw new UnsupportedOperationException();
}
@Override
public Collection<Integer> positions() {
throw new UnsupportedOperationException();
}
@Override
public int posintext() {
throw new UnsupportedOperationException();
}
}
