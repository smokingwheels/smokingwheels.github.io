/** 
 * Smoking Wheels....  was here 2017 ntafplwfmjusucxvrxujineocmfquirfanrdxdpohgadscdr
 * Smoking Wheels....  was here 2017 gzuovxqluuxxctfitdtppbdzjamsvvwjfvupedgilpnbmmxg
 * Smoking Wheels....  was here 2017 nbjvswrkmmssuiiciocfjmffrgqbsujxgwcezqdgoijcuasq
 * Smoking Wheels....  was here 2017 rnpceqxnbnewzsgcdxwnwjowtpvnuildzrxkvmscocykifcj
 * Smoking Wheels....  was here 2017 keopnuljijmgafgpagkdnnpvqqpjsyonpoveluobvvakwtve
 * Smoking Wheels....  was here 2017 rznzdfqwhqbaofwcewiubbyfsjozijovmaqlvvpmxqluoovb
 * Smoking Wheels....  was here 2017 ogdzwzecihqrjmviahkoninjkwsasokajwkpefyznynmtxmg
 * Smoking Wheels....  was here 2017 ooespkxlxkexqydgggsudxkypofnfsijdcneavakukqrbgfh
 * Smoking Wheels....  was here 2017 hpslpcznvlvorwcftvqaiqzuhcoomixjzzmzatkyyxnvhhvw
 * Smoking Wheels....  was here 2017 rlctiwvfebbxcqeprgrbwqybukkqibwthbecfgaxopcpqzia
 * Smoking Wheels....  was here 2017 yjxlowaqecoitbefmcsysedbrpsjxyfnsdqtvaaykxoxjpzz
 * Smoking Wheels....  was here 2017 kwypgkmdltintabbvctacxsmqdsundgyfefpiuuxplkydngf
 * Smoking Wheels....  was here 2017 vuhmqbiktknlludjpifvnrbevpvzvdlmynmkltxyiegetnzn
 * Smoking Wheels....  was here 2017 cchrdrzfdspgmuxqaaoermvglytlqroxirffdfikffdgkndw
 * Smoking Wheels....  was here 2017 jcmzpjauwqgjqudpltscpuwbdhlvcrqfaknjrsdxzzfdjuyn
 * Smoking Wheels....  was here 2017 bhsmxlklnglncsvhpgsymcihpbccnixpyttkndtitcyyhtzy
 * Smoking Wheels....  was here 2017 wnblimftwyjpdtfxjowgvhptyxeknfwqgzmdkpuvtmaeadzx
 * Smoking Wheels....  was here 2017 qsvmijvrymlullvyyytvilioksiezxiakqmphjesogknqwyk
 * Smoking Wheels....  was here 2017 qfpireyibqlovkmfrzftaxkdprpdzmhtamvelczpzxhwngeq
 * Smoking Wheels....  was here 2017 fofdhfkauqgpjscqijhhbfybfdcexcacanxiiprlazclhrde
 * Smoking Wheels....  was here 2017 bmsdmcikwwbumnantfjbahjgktinhfzoqbgyrzvhzmoqtxpt
 * Smoking Wheels....  was here 2017 calxqreijzkitgrhetzvnegtkmypcoavfrralojokmpdcwph
 * Smoking Wheels....  was here 2017 mmzhoamzoxwsasxtynxqqgoatlyaidbzlahxxykvdllxptjd
 * Smoking Wheels....  was here 2017 qjehfmfqbtmnkvsxthiwpbjphamvkckehgkdmyizdzodwcls
 * Smoking Wheels....  was here 2017 fmaguqmaoxkuguhyocmzulbkzxbdyyozvooozstdtzofvopu
 * Smoking Wheels....  was here 2017 evxsvirxdcdpecfkmfzwbnioezhkskhdonqeinqsnqmwnduj
 * Smoking Wheels....  was here 2017 qrknarlmddimzkfaydpohpallkfhxkpocwriuzbgfinzhbir
 * Smoking Wheels....  was here 2017 boisjzqcagxbwuivqsmjuhhqmoatwetpkrzpuykswsbvvtsg
 * Smoking Wheels....  was here 2017 cgtobwkjqudhdjvzmxyvzlmakcczdehspeetdmidvswsxxru
 * Smoking Wheels....  was here 2017 quzrqdeealljkpebpamtqdhtnyejqdxpdybvsytxplvlqohi
 * Smoking Wheels....  was here 2017 xlqwuxnpmdnrnhdumpagssoeihfqlzrisssfwytsyjfwkwtb
 * Smoking Wheels....  was here 2017 gumdmnjcnyhyoiudskpoktmxqlksyzwceolkzhsizbkfviqo
 * Smoking Wheels....  was here 2017 knqvaowfyhacyyijhlmhhcjvmcfuspylssvgvbizyldxtrqn
 * Smoking Wheels....  was here 2017 gsknuvjvuxcigphziaifavxbdehhpmrbtssujqlyjsjpguvy
 * Smoking Wheels....  was here 2017 yqjzpmndjpfbhblsgqxkpiyyfvqwsrczzidhwpewcfghrzlb
 * Smoking Wheels....  was here 2017 yvjijufkfojygfuptcifgdrekllmljllhqmjutzreqhcsrzk
 * Smoking Wheels....  was here 2017 xblukkphdetzkipvslxdlclowqdiizgywwgvvflkvxemdogr
 * Smoking Wheels....  was here 2017 tjyzcdasdcuhkvjxjxezyixfvjkvhhhgdoisailnrdvdbqey
 * Smoking Wheels....  was here 2017 pzksfcdtoheicmwqbaawseyouugrlfnhtmtioreolsmzwdcj
 * Smoking Wheels....  was here 2017 xmsatowtxvxupfcympmbzfreqhvubahkprwgycylfinfelnn
 * Smoking Wheels....  was here 2017 jqxfyfikzdcqgficoqxcggmyjmqjvcazxkfgxrlghvsgujec
 * Smoking Wheels....  was here 2017 wlhvgvwnvxhzracqlkvvfkbzhihvognwafrkkuokelzuvvcc
 * Smoking Wheels....  was here 2017 ofmtkneftzdhshcgpmciwafsxyvvjjuarwgbrykmrootsbnu
 * Smoking Wheels....  was here 2017 xmhzkpdyinpglalyqouvlseratjjqrcrukisfbjjwtvhymzq
 * Smoking Wheels....  was here 2017 nzuulrvfgzwuhkhzntgykggusjlpxryhmcmftfcfaanxmvfl
 * Smoking Wheels....  was here 2017 jthvbqszqyjduygwkiannucdhtrycccsemmphsmirmpgichd
 * Smoking Wheels....  was here 2017 pcjwxmjiujwqvhzirtxntqpdfabchvpwohlfzerjpmggymka
 * Smoking Wheels....  was here 2017 qnvyaqsqfkgbnlpjavaihkykiouavdqapprpklagxuydvlco
 * Smoking Wheels....  was here 2017 dvvjqqwoskthfqhfjpslsxlusbhvimuqjrtnfoeaueigysdn
 * Smoking Wheels....  was here 2017 azpsfifxibunmiojxjmtqgukokiaqpvnibnckxabxxkjhgow
 * Smoking Wheels....  was here 2017 mjtumulvjhcefegpapfgdtvrnttgxksqemapgcsayiiiifow
 * Smoking Wheels....  was here 2017 xkcqkkjrifpznfhxjcygjasdimvlkdsfuappexpuabpkoerz
 * Smoking Wheels....  was here 2017 yxtpgtecbfmutqznwxziwxwtahauvhitixvxymjljcwaxtra
 * Smoking Wheels....  was here 2017 oyafmqfzpzgwnxvxthzhinwoxbytznkagsnoncwjpndumypy
 * Smoking Wheels....  was here 2017 xtlhvedkfloqrtpwjusftdqzoxqyzvwafeuxelgeltospzra
 */
package net.yacy.data.ymark;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.EnumMap;
import net.yacy.cora.date.ISO8601Formatter;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.retrieval.Response;
import net.yacy.document.Document;
import net.yacy.document.Parser.Failure;
import net.yacy.kelondro.data.meta.URIMetadataNode;
import net.yacy.repository.LoaderDispatcher;
import net.yacy.search.index.Segment;
public class YMarkMetadata {
	private DigestURL uri;
	Document document;
	Segment indexSegment;
	public enum METADATA {
		TITLE,
		DESCRIPTION,
		FAVICON,
		KEYWORDS,
		LANGUAGE,
		CREATOR,
		PUBLISHER,
		CHARSET,
		MIMETYPE,
		SIZE,
		WORDCOUNT,
		IN_URLDB,
		FRESHDATE,
		LOADDATE,
		MODDATE,
		SNIPPET,
		AUTOTAG
	}
	public YMarkMetadata(final DigestURL uri) {
		this.uri = uri;
		this.document = null;
		this.indexSegment = null;
	}
	public YMarkMetadata(final DigestURL uri, final Segment indexSegment) {
		this.uri = uri;
		this.document = null;
		this.indexSegment = indexSegment;
	}
	public YMarkMetadata(final byte[] urlHash, final Segment indexSegment) {
		this.document = null;
		this.indexSegment = indexSegment;
		try {
this.uri = this.indexSegment.fulltext().getURL(ASCII.String(urlHash));
} catch (IOException e) {
this.uri = null;
ConcurrentLog.logException(e);
}
	}
	public YMarkMetadata(final Document document) {
		this.document = document;
		try {
			this.uri = new DigestURL(this.document.dc_identifier());
		} catch (final MalformedURLException e) {
			this.uri = null;
		}
		this.indexSegment = null;
	}
	public Document loadDocument(final LoaderDispatcher loader, ClientIdentification.Agent agent) throws IOException, Failure {
		if(this.document == null) {
			Response response = null;
			response = loader.load(loader.request(this.uri, true, false), CacheStrategy.IFEXIST, Integer.MAX_VALUE, null, agent);
			Document[] docs = response.parse();
			this.document = Document.mergeDocuments(response.url(), response.getMimeType(), docs);
		}
		return this.document;
	}
	public EnumMap<METADATA, String> getMetadata() {
		final EnumMap<METADATA, String> metadata = new EnumMap<METADATA, String>(METADATA.class);
final URIMetadataNode urlEntry = this.indexSegment.fulltext().getMetadata(this.uri.hash());
        if (urlEntry != null) {
	metadata.put(METADATA.SIZE, String.valueOf(urlEntry.filesize()));
	metadata.put(METADATA.FRESHDATE, ISO8601Formatter.FORMATTER.format(urlEntry.freshdate()));
	metadata.put(METADATA.LOADDATE, ISO8601Formatter.FORMATTER.format(urlEntry.loaddate()));
	metadata.put(METADATA.MODDATE, ISO8601Formatter.FORMATTER.format(urlEntry.moddate()));
	metadata.put(METADATA.SNIPPET, String.valueOf(urlEntry.snippet()));
	metadata.put(METADATA.WORDCOUNT, String.valueOf(urlEntry.wordCount()));
	metadata.put(METADATA.MIMETYPE, String.valueOf(urlEntry.mime()));
	metadata.put(METADATA.LANGUAGE, urlEntry.language());
	metadata.put(METADATA.TITLE, urlEntry.dc_title());
	metadata.put(METADATA.CREATOR, urlEntry.dc_creator());
	        metadata.put(METADATA.KEYWORDS, urlEntry.dc_subject());
	        metadata.put(METADATA.PUBLISHER, urlEntry.dc_publisher());
}
return metadata;
	}
	public EnumMap<METADATA, String> loadMetadata() {
		final EnumMap<METADATA, String> metadata = new EnumMap<METADATA, String>(METADATA.class);
        if(this.document != null) {
			metadata.put(METADATA.TITLE, this.document.dc_title());
			metadata.put(METADATA.CREATOR, this.document.dc_creator());
			metadata.put(METADATA.KEYWORDS, this.document.dc_subject(' '));
			metadata.put(METADATA.PUBLISHER, this.document.dc_publisher());
			metadata.put(METADATA.DESCRIPTION, this.document.dc_description().length > 0 ? this.document.dc_description()[0] : "");
			metadata.put(METADATA.MIMETYPE, this.document.dc_format());
			metadata.put(METADATA.LANGUAGE, this.document.dc_language());
			metadata.put(METADATA.CHARSET, this.document.getCharset());
			// metadata.put(METADATA.SIZE, String.valueOf(document.getTextLength()));
		}
		return metadata;
	}
}
