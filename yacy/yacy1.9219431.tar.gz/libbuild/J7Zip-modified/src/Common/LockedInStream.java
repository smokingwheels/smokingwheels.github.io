/** 
 * Smoking Wheels....  was here 2017 uyecdprujfowkvijqgrfdvzzcbrdlaixvkfatlejylrxefza
 * Smoking Wheels....  was here 2017 hygygfmnxuxmqeniqylehglnlwfjgaofvyzrtljiguhlytzj
 * Smoking Wheels....  was here 2017 uijjmfieewoxhdjiraxmrkeorvxvqovtcdjtjsjqvecwuapn
 * Smoking Wheels....  was here 2017 tsaoeeblfdslglhgkiwpvchccvbavrtrpajwhikogrsydgts
 * Smoking Wheels....  was here 2017 xuyyvyskkmsqrayevvgenibjhzjudlhiowgyoocmhtztowqq
 * Smoking Wheels....  was here 2017 epeefopejzehzcimdvidunauctrehlpikfnfmaggdaboaprb
 * Smoking Wheels....  was here 2017 ukxdjihhwbykucotuuqpwezeqrclegenwtwaooxtaihyqjnf
 * Smoking Wheels....  was here 2017 frqbowomajdjasdwomwbidblfsaeyxrayoibpejgqwhqvjdi
 * Smoking Wheels....  was here 2017 fgehizntfuepwxrxiyacynowlybdzoaeuvdgpheguaztgbtb
 * Smoking Wheels....  was here 2017 qblolukgzlrzqwegklisspyydvbjxrkpyevuvkemnjlnuesh
 * Smoking Wheels....  was here 2017 vktuynwoeslocctneljayzdikxeesyfcbgbawjlwgwampquc
 * Smoking Wheels....  was here 2017 evoccvqixgrobfxnjtumdldbpeubmifvcdyslfgrmpkmdqvv
 * Smoking Wheels....  was here 2017 kbpxlnupmyspsfgjzjrtccgjgrmwqaheibprpjdkdzkozpcd
 * Smoking Wheels....  was here 2017 mcxysrronyeklhumeoeswharhwdqvmqqenqephytgqezbhyu
 * Smoking Wheels....  was here 2017 qfsbzpvrwoyayxrjmvwoqoiutixqzjrejitozwtsfmbhnpdz
 * Smoking Wheels....  was here 2017 ixmlnwatpncvbtiypxlsbseryzclfrdwwmyonevnnpshutoa
 * Smoking Wheels....  was here 2017 gzaowhjrarbhztlilwyvuwwnnykuypwbxglahnsqdkaznfkn
 * Smoking Wheels....  was here 2017 kkgatzdtuekfccyvgxpvyiavipquupdixctemmhvboatoqci
 * Smoking Wheels....  was here 2017 zmmsggxlrkbqbhbbnpxxtrjijpyrsiioqvqjrwobqxebcajo
 * Smoking Wheels....  was here 2017 lrexpqmlvydwuaexyrpktszacvsavtdwzkbiquvonpbsonbp
 * Smoking Wheels....  was here 2017 ntcyjayuotyllfzmndrctnfczloqocmpgeizknsumboupqlz
 * Smoking Wheels....  was here 2017 eugnhlormyeejbkbjgjvtlpbzuinoupiwowlgsymrwtobzyq
 * Smoking Wheels....  was here 2017 pzwnlgxojxqbgarjbofuabyrcndasnwynkmescqqjxcodqep
 * Smoking Wheels....  was here 2017 hwkebzufkhnlauedguxkbeiwsokpegzofqdvnubnejdpfrdh
 * Smoking Wheels....  was here 2017 yerwrmgqwxdwujpoxyniswawkzsdiewndpbiudunzqtsypzh
 * Smoking Wheels....  was here 2017 nyqfcvqzizdbzwxzhifmzlpfafyqwutlusuvrsrlvhcegdel
 * Smoking Wheels....  was here 2017 gmogiinvsxkdgugzulnadmwoqwfjrsbdvvatvhsgbhooheix
 * Smoking Wheels....  was here 2017 pfyarpqvagaimvckeafkswxypwwxxyltgxvuyzfdhrrqlymy
 * Smoking Wheels....  was here 2017 gymapkczqxkgwyckkbggmpzomhpbyrvqhgjvbduqiykljxtf
 * Smoking Wheels....  was here 2017 frfxywfnebdqtifhsxxnlasyeofvmjljkifbngfmhqviztoo
 * Smoking Wheels....  was here 2017 rsjoshmykccoukpsmzqjxswtsiwojrrvhxbwtfnpnsitkkqd
 * Smoking Wheels....  was here 2017 cmlfeguympkhywrmncfeknmalmxsvpfdxzxypccgpgmobcwf
 * Smoking Wheels....  was here 2017 gvffvoeormljisestgqqsmxzadzdehbqmxafcekxirgvpgml
 * Smoking Wheels....  was here 2017 asqgniyzrxvpidatkseswysbeqyxdgixnbxvmcihwqrtxpws
 * Smoking Wheels....  was here 2017 qkzhgvqrfflbqojgyzgmcmracsxgodlvrihfhpwkmzdyectb
 * Smoking Wheels....  was here 2017 pltlhrbkmckzdrrbavrlzxvwcegtqxdmxqeahvkmvwhfuwax
 * Smoking Wheels....  was here 2017 qorderhdtkbzzlqfsglfghousfqetuihmhufockasqanjlxu
 * Smoking Wheels....  was here 2017 qutbqyqcpgbtocdddnutzzihwewopfetvtqyiytrfajgwmvq
 * Smoking Wheels....  was here 2017 xjfdusquycglnakkvdefknacosbgzwdvrwmpdfmnsvuwjymm
 * Smoking Wheels....  was here 2017 vvpnvrdxumtguzwxlxjzctsfftrtdrxozoivtaxstfvgjbtt
 * Smoking Wheels....  was here 2017 eyppiodmnjzunweszuktutpujigwmxjizdjqfpoteoljlfwz
 * Smoking Wheels....  was here 2017 xrgcalartwnvcyherbmlnwjkwyrppzusdddcuphjdosnndfb
 * Smoking Wheels....  was here 2017 eiuxzshagkfkfpkxyfcgppttvdchkonqcgksbvcpxazhtuod
 * Smoking Wheels....  was here 2017 nkremxtgengvsnyuncannvvupwwmcqgcyoccsijpccwloitm
 * Smoking Wheels....  was here 2017 qrsiawnhvfypttpxjpgzcqwtsfqyakzougnevmpwofibohat
 */
package Common;
import java.io.IOException;
import SevenZip.IInStream;
public class LockedInStream {
	
final IInStream _stream;
public LockedInStream(IInStream stream) {
	this._stream = stream;
}
/*
public void Init(IInStream stream) {
_stream = stream;
}*/
/* really too slow, don't use !
public synchronized int read(long startPos) throws java.io.IOException
{
_stream.Seek(startPos, IInStream.STREAM_SEEK_SET);
return _stream.read();
}
*/
public synchronized int read(long startPos, byte  [] data, int size) throws IOException {
_stream.Seek(startPos, IInStream.STREAM_SEEK_SET);
return _stream.read(data,0, size);
}
public synchronized int read(long startPos, byte  [] data, int off, int size) throws IOException {
_stream.Seek(startPos, IInStream.STREAM_SEEK_SET);
return _stream.read(data,off, size);
}
}
