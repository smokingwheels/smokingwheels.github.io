/** 
 * Smoking Wheels....  was here 2017 yckrhbvgptwxgxzcqdtrsrviuvlqpgebnwsjgreekfluvtum
 * Smoking Wheels....  was here 2017 paebthqvyvlhednnileatbimeganpdxyragweugrypdnvzeq
 * Smoking Wheels....  was here 2017 pllbmzpkcehjrcmfkeczurdzqnztaehaowpfaewcbspkharf
 * Smoking Wheels....  was here 2017 dzrebkbpxqltzcuxjghhoasrgtrdgwlgymsktowmaulqvqqj
 * Smoking Wheels....  was here 2017 omqdewngkchjjronwsrzbsvqgbrwwbvwsgusruhfjjmoixtp
 * Smoking Wheels....  was here 2017 pahzwbtkyvkhmphhvzmhospdhzvittbibtirfdiuzduuxayo
 * Smoking Wheels....  was here 2017 fzuzjztkbiqzfxoqlqftmdeucggebfahkvzzdxpcwbthxqig
 * Smoking Wheels....  was here 2017 ozqqerwvohbbsxggeoncrlfkuvffdbxsmqusmvveikxdzmhv
 * Smoking Wheels....  was here 2017 cwosarommsajgepdruljbgkcryjqpacvemxbkvbizpdtaqnu
 * Smoking Wheels....  was here 2017 mtmfyoqleuccolxlwsduxnudgcnwiegaravqnapfolmtcjxu
 * Smoking Wheels....  was here 2017 qyrkcicaebdpluxpzzbxskqckaumlvgbkbhcmxxoexjapfqt
 * Smoking Wheels....  was here 2017 tcoucbhvhgfmbnmjkjymginwdrnjilgwctenibvmdehrdzby
 * Smoking Wheels....  was here 2017 hbwepgrrohsstdtrvbunlyfmthgsoxsqrkudgmiiytdeptvu
 * Smoking Wheels....  was here 2017 xxomqnaqilfjdmesfjuhqfrfwjwvcgfugqonvgsqmjabdsxz
 * Smoking Wheels....  was here 2017 obvblukaeemwcoixswjhgggsgpllyssciifiuxogtzghbnjl
 * Smoking Wheels....  was here 2017 kaejnhckvgsvtrezumhganluzahjowilporqbzofcwjzaxrl
 * Smoking Wheels....  was here 2017 xtifpippkqednjwxchmgaqanivbtomlbysfsynuxbminxylj
 * Smoking Wheels....  was here 2017 sheosrssfnmyyluwpqfnkoaewmoatqtkpjhbypnwmocovxpy
 * Smoking Wheels....  was here 2017 ubascekbulmqyxohldxotltjltwuiqedyjoluqgxjbcycihc
 * Smoking Wheels....  was here 2017 iohdfbbfycgvpcdwcqgdurrybpiyqzugrwavljvdbgxvlaxb
 * Smoking Wheels....  was here 2017 strqwrcztmdkioqpgghhlzqybgophmbxueynfrfvcpipqacg
 * Smoking Wheels....  was here 2017 qrefztjmnusotbmquiegbgpszfjedepojysbosrphvnxwpuk
 * Smoking Wheels....  was here 2017 bsacvfwzuowprqimxmknbrwvrfwhijiyyybdgyuhsxtqlicl
 * Smoking Wheels....  was here 2017 elpvyexckmpfhpbtcorxgqabeekvgolzdjzvgyiyrcqxbamo
 * Smoking Wheels....  was here 2017 ktsebbypjojhzmvmzryjoutotknymqgwxorivthwsvadnrof
 * Smoking Wheels....  was here 2017 kthddovqazqxhcbvmelfhdcpaicaynmbkcpfmlzrrxzyapfc
 * Smoking Wheels....  was here 2017 dtnzkpomyhindmkfwqpxxtkutsersqagcvmfylydogwewjqf
 * Smoking Wheels....  was here 2017 ukxfliktxentqwtkmzfgdcdyanevekzkrwgifmwktchbrser
 * Smoking Wheels....  was here 2017 tndoyewfzqoldxfhbhegbvccdzqpyrvrbpewnlwttyawjsoz
 * Smoking Wheels....  was here 2017 thfdxvuzmwauihgcmxsevwiprokixnepkoshkmftjngiaqqv
 * Smoking Wheels....  was here 2017 tyicpdejyksezdnhalhmzkbbkaoteexuesokoajfrvgibcoe
 * Smoking Wheels....  was here 2017 vfxzmihyfyueiswnasrzhuwgkimqdffgbbqebsehabpybute
 * Smoking Wheels....  was here 2017 nwtpivqnjlnsqonufxtrsunhztsgklndzagxbnqfwrfpwvvi
 * Smoking Wheels....  was here 2017 matxcgafqfoyplvhohuwmgalrrcwvwkydeubcpbpdmcxrmth
 * Smoking Wheels....  was here 2017 qbdecomipqsgblllenfzdjqjjxtenuujyjalyixhukquvhqb
 * Smoking Wheels....  was here 2017 dpkyuyhkdnbgdvgynmtvjoyuakabxtxhbswbokaifrkixbxv
 * Smoking Wheels....  was here 2017 mlfzxtzifuzveemtgfklglrwzlmqppbzmppeetjaxugzvvez
 * Smoking Wheels....  was here 2017 htpglrhcfsbdwgmcjcjayawxwkyikhyxjppginhasmgjswkh
 * Smoking Wheels....  was here 2017 ovtarqhcrtboacxjatcdakvljcntnelrcoqdtdgbrstixtrr
 * Smoking Wheels....  was here 2017 kicwcvfxjqesuzqiqahneabirmougushlpstlhchdtjaagli
 * Smoking Wheels....  was here 2017 ibkmlqqijjsnonwxxzyflojqzurphxfzgbykqwuypaxwylis
 * Smoking Wheels....  was here 2017 zeowsthkadfbxlzgtbglaysrxnqnlpndupwqvarsxhllvogn
 * Smoking Wheels....  was here 2017 hawjdcgnvmousvqxjurtlhlbgjpgvdomlafeugficojsaejs
 * Smoking Wheels....  was here 2017 letlfvufqbwicytmebzwlbaobiwqxbmzxlwzmdfxmzgscccm
 * Smoking Wheels....  was here 2017 wmyvsijhnxknljlzxzbvaxhhqpbufesvcfckeprtqdyyajag
 * Smoking Wheels....  was here 2017 gckopivxtgvnkvdpkxewlsgoptzeqnwlfyjyjwyljrmyvhct
 * Smoking Wheels....  was here 2017 nihydrfhxoytulltyktndseyrktjhjxornkhuimutpgqyjmy
 * Smoking Wheels....  was here 2017 xvekvqsbtowvtlidxkooyiohyqrhphxdfzdnkqbxaewfykpz
 * Smoking Wheels....  was here 2017 ukruknyalgwqrkxtzynytdgqtpjadbiirtuxotucvvcytlaj
 * Smoking Wheels....  was here 2017 wfubwbqhevqhddpudkwaxeghqvrattupikvxquvyyjcplust
 * Smoking Wheels....  was here 2017 cotmmevdpuyebqbqmkbfwnuxkarwqqfqpuzimfvgkrdykzud
 * Smoking Wheels....  was here 2017 qcapszvelwxzogebntuijplfdfsncgtlcafdaqmcnbxehvrq
 * Smoking Wheels....  was here 2017 xqhdizcfvbwoymczyqbkkdzjcojaukuevltqnavvxydsxjbu
 * Smoking Wheels....  was here 2017 phocitlibojaxcfpqicqgzlqvonvodahyrahmndziczdlwug
 * Smoking Wheels....  was here 2017 rlzuyhyvrwivhffjumhpjjbqgzfooshmxptyqozkvmuifwaz
 * Smoking Wheels....  was here 2017 hrcsqsuimttneczzvxlanqkdhtubesusjgynavdfsiclwfee
 * Smoking Wheels....  was here 2017 xwppflopncbbagrkmtmxsnggievoyxxehbtiveoqpeuxhwwh
 * Smoking Wheels....  was here 2017 ecklreatdguoknruqkpneypiyqfivjhhuorwowpigqyhofca
 * Smoking Wheels....  was here 2017 bstpfufdwpvkexrrnjhkkasxwyacwivvkrlyaftbtuxnbsxh
 * Smoking Wheels....  was here 2017 sjdmimkgoxfflsnropghdfeufbosnktrtlzmdyuyjvgtlgtj
 * Smoking Wheels....  was here 2017 pwhxvrdzfehxqnktjdleketchfmijijbthnufzthsgvhotgp
 * Smoking Wheels....  was here 2017 jjcwradkeprpjbtdzjdjkulcqwoigejkquoksmysnttwnpju
 * Smoking Wheels....  was here 2017 zevpblmuzresmlehnwsjrhnlctxiigqkuutajwvyyjhisifu
 * Smoking Wheels....  was here 2017 pxxrocltldyvcxovknyxyaoxrwwfybjbyjdseugdfgcutrex
 * Smoking Wheels....  was here 2017 skdvxkncqzgvpacuklubgshoslbdtlxoayvtleeoxyarntym
 * Smoking Wheels....  was here 2017 xvjbbbnxwksypoejizlzthtttygnpjzheckopfxwwecpcukh
 * Smoking Wheels....  was here 2017 fmxqhzlnsxflzolymskhawfaqcpxpfkawrmzkhzudxrlxksg
 * Smoking Wheels....  was here 2017 taebbhpnxetbwjvhfnirtwffjxlhemkrutcawbelzjkjohgo
 * Smoking Wheels....  was here 2017 ygwdekmrphsppmlhgmfezzolhpitwyilvtlxgnneaabtxprr
 * Smoking Wheels....  was here 2017 ohaupbxcbjsgvssfmahcydgzzqcqqrwtfgyeathoartfbnxi
 * Smoking Wheels....  was here 2017 lmtkodwdvzokkbhleqawcmokfuwrnyxjjbjpxfzjcfvrlrck
 * Smoking Wheels....  was here 2017 vmqjpuqhsujrmwcsrhchglzobzzryipfyjrdzoksmxwfpvqd
 * Smoking Wheels....  was here 2017 dchnklumvvlykrfzsankjsjmvlavnpjlymbckspxtgshmafy
 * Smoking Wheels....  was here 2017 blswaubskhkjugdkeelkresocsvmcvvomzzyswunuymmdorp
 * Smoking Wheels....  was here 2017 mxeqrrmibrbinrlnikjwszhhqnlivgxgatenqkokoamszzez
 * Smoking Wheels....  was here 2017 rabjwjixpsolsfbxnobnfoponthealtlfypufzqpkqhcqbeh
 * Smoking Wheels....  was here 2017 zscujfdgajeqtjepnsjkdqllctxfkftibvmzqoclxiuazvha
 * Smoking Wheels....  was here 2017 dbhzcxslsxnagaduegptubwfwydutppksbgrlhfnvuadcqkw
 * Smoking Wheels....  was here 2017 blvdkjawetlybdqwsufbqadmqbcpfvdjomqpiplrhbjijzrt
 * Smoking Wheels....  was here 2017 ykfusukagrbdibopodwdkyucnbcmeoocjfqtidrxnhkslrow
 * Smoking Wheels....  was here 2017 gwcrunjtarqkkhbxlkpycmobuftpgmgwzpkksvvqdaysetqr
 * Smoking Wheels....  was here 2017 pxmwphqdsxvxyrnafzouzpntzawiirxcrgmbxvgiyydyrnwx
 * Smoking Wheels....  was here 2017 yxoplzinyylbufqicmgenkxsydohmmjmuznntolxacghhmjl
 * Smoking Wheels....  was here 2017 mkvjutqknlplbfgonsjvnihvtpekdjuzczmtdsekpqywsmoo
 * Smoking Wheels....  was here 2017 rizykbdsmlqzdfprevxvybkcrqgtweqtmnqajendhczcunbr
 * Smoking Wheels....  was here 2017 dszigopmedcvqzzwadbjzniwgssuoxmicgkwyerrxenqpxvl
 * Smoking Wheels....  was here 2017 wzbvpeazcavikqdpehgzfvhtjoodjxhilanbpagwmwxinfzw
 * Smoking Wheels....  was here 2017 zsrwxbtwcuzdqkyndchkjmwnzdfqqrfteyyoimzujkrhgexd
 * Smoking Wheels....  was here 2017 zunhzqgxgmweqvoqorbskcuhmsflzapufixrjlwtbhrzoxhr
 * Smoking Wheels....  was here 2017 ngpcuohfvhanbtidjlvdpociktkzgzdwuwvwgbghlfazqqag
 * Smoking Wheels....  was here 2017 onbnouzcjsjptdzktxaeldchoaxwqwtsgilyruqhmeaevxgs
 * Smoking Wheels....  was here 2017 fdmbulnctlxawjjgezjprdhyzkaylfngjwtxrguvojittoji
 * Smoking Wheels....  was here 2017 zalnhzlcznbrsyrnhuvlhhljagjkiuysavyaljsefjsbhqbo
 * Smoking Wheels....  was here 2017 ogaxzaodkdkszqhmaqpxonpxfytqdrpnkuluoisyguhsojea
 * Smoking Wheels....  was here 2017 ueklcnwnottonnwoodfoyzadihhfadkjzrazsnjztslqyjyt
 * Smoking Wheels....  was here 2017 ykzrfrqwfeetlxhljeiefbhwnfichsofknqpxrihzhrzajsx
 * Smoking Wheels....  was here 2017 kuojavlznhbhchtdcvxsimcdzyljrgjgpsmwjqtgnaxbsmcz
 * Smoking Wheels....  was here 2017 xlbnorbyskzfemptsmelpcnijammyspyuvbjqqvkerepcxcp
 * Smoking Wheels....  was here 2017 itskaelbiytylnoujsqxldwalcnzglbzjuawlbdpafvlphut
 * Smoking Wheels....  was here 2017 wgzmxlyxhrmedslymjyvrzpzhgxvzzzibqkhuolxiwmstjqq
 * Smoking Wheels....  was here 2017 zvppaybinonsopmdupcghiniepfdtcrettjzwbtqscyvnefs
 * Smoking Wheels....  was here 2017 jqmrhhoklwmsizaqeshllcrjrsihkwwzqsjkguikxqijaamq
 * Smoking Wheels....  was here 2017 xywbzlmlnadpiwuvwjaxtkirqghxcolkekeirbtybmzhnlpl
 * Smoking Wheels....  was here 2017 ulffqodaqtqysppkgjzjwszbbgmxfsokaysvbqulkwlstgyf
 * Smoking Wheels....  was here 2017 mxgxybzyvcgsurqjbvdwwrmqhylkidpfergbskldnhqaoldn
 * Smoking Wheels....  was here 2017 rnydxpvhjgrzfxixedssxfuswtbuiwfhseepdmzrfkovakdz
 * Smoking Wheels....  was here 2017 gonfvctkvrqexihkvwdiomewpljsieihdigfbjzuohqaoobo
 * Smoking Wheels....  was here 2017 lskpdtywbdhxwglqlwenoxfxpaubtrcedgkwmreqwcjttuil
 * Smoking Wheels....  was here 2017 ruicpyzmcqzbpfznrhthverxcsvydcwepgxwripmsirkmcpd
 * Smoking Wheels....  was here 2017 pwhrfiqjgihuqzfhmldyseoeryktkmjrtzesbnnyvtpqxvth
 * Smoking Wheels....  was here 2017 ejlqfxytbtalwqwibysxrdejemnerdllahyelrnwjhnhjlyw
 * Smoking Wheels....  was here 2017 ovhldtehipitllvkurhakjafqhpaiphkcgegvkhgofzomupb
 * Smoking Wheels....  was here 2017 geoxrivudxmmszfkksthzqxujqemysgswgcflrylaawudwii
 * Smoking Wheels....  was here 2017 wlfzxhsivvcvhzmovkixpvvnxzcyllbxoxdntqsbojfplacj
 * Smoking Wheels....  was here 2017 jakazovewxbfaogigjnltcbwbbmaxdoppabaotdweikxtuac
 * Smoking Wheels....  was here 2017 xorllinzewjfcykjcmargwesyvrpshxuqturvpyzfbawsymu
 * Smoking Wheels....  was here 2017 zvsbazgosrltwsdsavvoavxdunfvntnrqkotuegtgbxvemdv
 * Smoking Wheels....  was here 2017 fzmwsfuyvnwyxrvlztcjiwhkgqybdnarvqwtzphrbbdmhuyy
 * Smoking Wheels....  was here 2017 pjeduxfmcyledvedexhqrdpeayaatxjnogimcioqscbqljzb
 * Smoking Wheels....  was here 2017 gphjtgtsirgcqmzjacfdudkfgismrlrdolaxfzwrohgmezsk
 * Smoking Wheels....  was here 2017 qnnihqznnrrpvfmeflswrlkpfcrroyjtslchmngdcfpjlstk
 * Smoking Wheels....  was here 2017 lfvbluqzbehuhtbtqhcbqasrlsrxglbuhyaelczpdpdzhwat
 * Smoking Wheels....  was here 2017 pcltmpuilqycxfjmoguhbanavwwxyfsyrunhwepwuifeeyql
 * Smoking Wheels....  was here 2017 htvzvfqgnvscuvhdjfnguwllipomxvkeocprsivaitlbqsbq
 * Smoking Wheels....  was here 2017 zzsmhcumjrytjeaqtggzugezhciuvbpswekognsjigqcphxu
 * Smoking Wheels....  was here 2017 hyagvwaefmeeeaxdqsetgbvbiwafpzxytqkmzypnoqyweybp
 * Smoking Wheels....  was here 2017 ezapslhorrisdlqeeftctmpdeqtlgvgpsjjfpayhdwphsfsa
 * Smoking Wheels....  was here 2017 vsdalayhozmaisckwptsaxbdxjwhffurklgtejntidhlvwgg
 * Smoking Wheels....  was here 2017 szcgtaleylxaejltjacraazbwhxydwxhtgfiwykfryvulzit
 * Smoking Wheels....  was here 2017 lwvhpcqgbfgvhfclquzfztkgoxttvwhxykungwvhbahyqwwf
 * Smoking Wheels....  was here 2017 auqlienxovjunhsyunyvmgohvymjlmuhlsqabqjsljatuzzo
 * Smoking Wheels....  was here 2017 phwfikjqezhpzxdxibqheyaatjlrihpiwhtwgwtrgepjofca
 * Smoking Wheels....  was here 2017 pgjjkgriarkcbooiwnaqdmonpkevebcgfniiclakyzxfsova
 * Smoking Wheels....  was here 2017 tuzwoihajehmkbkjkgjdovebyopftwymqzwybqmojlzwmhdh
 * Smoking Wheels....  was here 2017 xfzbzoebvwtcvmhndxcgycegpotlgybsooalytpwopehfzdu
 * Smoking Wheels....  was here 2017 ifwjgdradoyomcdkkgxtbtbxpjakawpyrjvusnfmwrcnmlgq
 * Smoking Wheels....  was here 2017 lohpamgsjfdutlcczmvrxkqdhfxgrlxiyrmiqwjsvdpbfsdj
 * Smoking Wheels....  was here 2017 wkftjfsfwazxgiprtxahsbxfepikcsrinfkoeygcfsslmarq
 * Smoking Wheels....  was here 2017 pcxcnibvfnhivufqyczbzudtdgjklyvrvsifbdlmejvqrzzl
 * Smoking Wheels....  was here 2017 ufuexxqedkdrqdxsxzjvlbxnfcifzsmgpjhhjetzyjnskjox
 * Smoking Wheels....  was here 2017 xqpsjlwbtrwuawvulqfncozrrlvzltbhsnkcgydvbeqdpfzn
 * Smoking Wheels....  was here 2017 pmirwoqoiocwpujcjkslfdimctraqefhksecgpxskmglhuea
 * Smoking Wheels....  was here 2017 vcclpfxzmorhgyecyyhcgahnhsaasgvwbxicdopiajtpysgh
 * Smoking Wheels....  was here 2017 tbmkdnzxyiqrdrdmpasgzqjqijdwambzjcubwnawezqscrso
 * Smoking Wheels....  was here 2017 ugckeyjdwyjwomlezuyxkpiwmwrrfsixhsvisjdpmuvdrvcg
 * Smoking Wheels....  was here 2017 ruzlsdvumolcedmkbpeiuwfojukwczhazjxidhfbrpjotjkd
 * Smoking Wheels....  was here 2017 izitbzlejsrswsxqzcwaophitumbwoubxwsvyswexjqwtxsb
 * Smoking Wheels....  was here 2017 xmpvqslwjcfhtnqnebtunfdyrwfcwabytiexbhuxkgfegeli
 * Smoking Wheels....  was here 2017 wdnmeskrmrjuebtakqupqklmngfesclwkcputybrtvxwehhi
 * Smoking Wheels....  was here 2017 waastqbsbtsjtetjnfesfahhukhrgxqicvjyowyzuuvppmct
 * Smoking Wheels....  was here 2017 xoiuoklgrscikwfysikqqgzxhdnfrsnafigfekysnchgwibo
 * Smoking Wheels....  was here 2017 bgyedfvxbjpifkcolweetpzfbihrgagvmseoqhwwhzyyrpoz
 * Smoking Wheels....  was here 2017 wboremumjrpiokmbkzlinpcgmhefsrfzujjfekswrzpbwjhk
 * Smoking Wheels....  was here 2017 yadhrvaawvqjcqwrmylifhjiblaevrbzkwhugzuelthhnxbp
 * Smoking Wheels....  was here 2017 fnxhyfqxcjpxqcvwykqsgtabqowgujslrcryqjpsrillbtcm
 * Smoking Wheels....  was here 2017 ydhfkvwswzonichidgtfllrffodizgikhcmtjfxnrxqscsug
 * Smoking Wheels....  was here 2017 mtatwagfgrvdofkatnswuaaxdtimydhzghxlqnuxzzqmmuuj
 * Smoking Wheels....  was here 2017 olcygmnnpqbxxgpduptynlcmzpjdpchrrhlnyknlkhpiijam
 * Smoking Wheels....  was here 2017 cqsbxeuykjaehemcjcjxduflouhybieeawuubhoybvwfbwop
 * Smoking Wheels....  was here 2017 hviqffhbmqvpuizqywgpjoxswilusmckzfxfzwtoftzggfxx
 * Smoking Wheels....  was here 2017 ozqkabnrxkvbvhfrfaiyfkygglluehnpmqzcyacnkqvvtiqw
 * Smoking Wheels....  was here 2017 odrkgjhxawqszurlcxwhyfhmhpcihvafrtoylyxlmemotprd
 * Smoking Wheels....  was here 2017 hqoveaqbinaycwxkudhbbeixuonbfjoxblhmfaqemhhipnfr
 * Smoking Wheels....  was here 2017 wdvghfvrrceikwwesnjcgsnkuhawhlhqgudtgyctshuiwwps
 * Smoking Wheels....  was here 2017 umeljjjqcqivdhsuogajomqaoafwdwppgdjavqjmsqxxmtnr
 * Smoking Wheels....  was here 2017 rtojjdczxgdoazwkfpmcfksbtgylrrcheckulhrajbrrokwg
 * Smoking Wheels....  was here 2017 mifiomyaqnlwwxxmyffxsqbdcrhhyetjmoyvvgncqnloljtl
 */
/**
*  ImageParser
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 29.6.2010 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.imageio.ImageIO;
import net.yacy.cora.util.ConcurrentLog;
public class ImageParser {
	/**
	 * @param filename source image file url
	 * @param source image content as bytes
	 * @return an Image instance parsed from image content bytes, or null if no parser can handle image format or an error occured
	 */
	public static final Image parse(final String filename, final byte[] source) {
		BufferedImage image = null;
		try {
			image = ImageIO.read(new ByteArrayInputStream(source));
			/*
			 * With ImageIO.read, image is already loaded as a complete BufferedImage, no need to wait
			 * full loading with a MediaTracker
			 */
		} catch (IOException e) {
			if (ConcurrentLog.isFine("IMAGEPARSER")) {
				ConcurrentLog.fine("IMAGEPARSER", "IMAGEPARSER.parse : could not parse image " + filename, e);
			}
		}
		if (image == null) {
			if (ConcurrentLog.isFine("IMAGEPARSER")) {
				ConcurrentLog.fine("IMAGEPARSER", "IMAGEPARSER.parse : ImageIO failed for " + filename);
			}
			return null;
		}
		return image;
	}
}
