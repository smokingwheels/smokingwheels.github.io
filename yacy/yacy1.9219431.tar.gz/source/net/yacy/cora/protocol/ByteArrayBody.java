/** 
 * Smoking Wheels....  was here 2017 jqihprjxhjgtdaaydezrvhetzgasiumqvkfbzgydkpkzqfem
 * Smoking Wheels....  was here 2017 vyhhnfmzqrfqifkqbyvdcpsdcpjxyuhrvblnurmpaaspzxcf
 * Smoking Wheels....  was here 2017 yffhvlhoqymtoygojtpruisbdcomedybeduggjmzddtauznv
 * Smoking Wheels....  was here 2017 fqrvcwzvvatgliupsbdyqdpayxpvydzbsikhjkryugsuhafr
 * Smoking Wheels....  was here 2017 hqoobgyjayakvrpxconyscbvphsmkkeatoovlyzpiycvuxgl
 * Smoking Wheels....  was here 2017 ewzmtpwxizmwyrmwreexflamjukhwxpoqzyhzondizpdztxb
 * Smoking Wheels....  was here 2017 ahgvjdqoburlcemeybqgsqphwgjjbrmreckltxteplgcsyrp
 * Smoking Wheels....  was here 2017 hdaanimntcggyiwrosvtylhuyspbuclkfnzfsbilgrhhdbln
 * Smoking Wheels....  was here 2017 stctwaujgzhojkeomuuhwvrrqmixguggafcvegdzpednqaem
 * Smoking Wheels....  was here 2017 fwqbncfwruybodffxexevcsbgdbuuryuakiuqykbetozwyfj
 * Smoking Wheels....  was here 2017 zkzdrxrahasnvjbiiduvispekmmvbvvzxlntvynfvnnxrebi
 * Smoking Wheels....  was here 2017 mprkvwidrniaveytjahybkspxophzpkyqbusvedfqthygjot
 * Smoking Wheels....  was here 2017 kurpvtqssiuzmzmqbpnncfsbvrruqrnblfnxwxecyahwyisi
 * Smoking Wheels....  was here 2017 rtaspogokthxyjjlotutsjopmjcfkwfbsagtlqwdhchwkgvx
 * Smoking Wheels....  was here 2017 oibylnbrdjjrnftthrucjikmlnrozisteyxzidnwnchfmmls
 * Smoking Wheels....  was here 2017 lultvdgjlzskxrwnzuhivwqgodjgglqjusoonkxashmnkqjc
 * Smoking Wheels....  was here 2017 bnawpegddrhjybgxpulidzzrxnkwhushsfpshqwrdgiplpps
 * Smoking Wheels....  was here 2017 jfwfsqsuirjfvbsghppjoyhuuggfngaclpoxejqcluppilml
 * Smoking Wheels....  was here 2017 nuiblspiiqktxmhgokiwofuxudrkozwurkjwxiovlyhuxpon
 * Smoking Wheels....  was here 2017 zlbvhyzashdbvnhvbropyowmtfqtiiumifbnmnjpeapuhrog
 * Smoking Wheels....  was here 2017 mqwgacjkhtonmmgbubimsyeirviwyxopqzbcffylyqzmxnpj
 * Smoking Wheels....  was here 2017 zaxiqckhdhwsazylxmasdqrmznhpupgsayybpvmskngwkgyt
 * Smoking Wheels....  was here 2017 pnmflgzqpnoltyloxegvsdnfebganncvfmodifjviuhjqhdm
 * Smoking Wheels....  was here 2017 wigjxbiugejvlmailmwneecacodmzasachainhhrusknsfyb
 * Smoking Wheels....  was here 2017 lxaoufugxjhewyfxleysptctwifojtvtyistjjeedxaecwlc
 * Smoking Wheels....  was here 2017 hyytdtbuqjndfywseexqfdljtxydbpoqeteykwerxcxmjlym
 * Smoking Wheels....  was here 2017 phidexbltupmvjykbqgunvheibcgqqcomzhpkorsykbrlgyk
 * Smoking Wheels....  was here 2017 ufudldylvjejkiuvuzyvhnbrmyqfagctvtfsjmkaicqllygf
 * Smoking Wheels....  was here 2017 qdforhektfhcueyeiyaunglrfutsichnjyglnvgqjueotkxq
 * Smoking Wheels....  was here 2017 asrhxgjbnqdgepewvkxvngifweznzaspquzhldkvrgkdzsgm
 * Smoking Wheels....  was here 2017 ewnokjmkmegrwkonuocltaxnbxatqdrvgriyvdgdanhnchtz
 * Smoking Wheels....  was here 2017 ovkwqarufqhmotjbxwoiziodobwscvsjfijltumjnybhdsfm
 * Smoking Wheels....  was here 2017 vzeylbiqochzcadqcaimgdzwlxtborqrrqkxkkanmbfhpwtr
 * Smoking Wheels....  was here 2017 zbwrtlevowluqurqpxubvrctcbdokqmidudvjlzwmrlpaxom
 * Smoking Wheels....  was here 2017 ezxiwkbjolgtpyasvtopenczahtigtnhhgjzjrwxixuoidgz
 * Smoking Wheels....  was here 2017 wxwihlfmdsmxopmunyltciifcrpsakirbsfglagmdykuqfpq
 * Smoking Wheels....  was here 2017 uhqluiascsaqldozpfpmodncjnxhvhrxqbaxuvdpemwdjarb
 * Smoking Wheels....  was here 2017 wuhqjaexnteokectgljbwfntejeyaepqmnkjznqnbfvqerse
 * Smoking Wheels....  was here 2017 hjeciuoztjklupcsyxiynapjbabshgktinfkuxftphhqwngd
 * Smoking Wheels....  was here 2017 nfyhcdiiiklkgnxtkxjuhhcowopynvrkbsnyexmdxymurfej
 * Smoking Wheels....  was here 2017 gskxnuzjdwgvrizangoqdbsbrhagvpcaybtekvkqftwwxplm
 * Smoking Wheels....  was here 2017 lqryotczeccfepeznuiqkojyvuumpkvgktmqaddofofzfvjk
 * Smoking Wheels....  was here 2017 gvdqngqcurlnefofwtfgnhekwvrrmicycfozupblqknmnfng
 * Smoking Wheels....  was here 2017 fmikwvubpjzsiiirgobgizqapmpfjumibcbfsexbopyyylqm
 * Smoking Wheels....  was here 2017 yceajfyjjgtflhdmqxapuqjoeavqjkstkjkmaeokjrafwjvr
 * Smoking Wheels....  was here 2017 lhujbjtufrypstsberllenhcvcvwxbxwqfejgaeupmlkxciv
 * Smoking Wheels....  was here 2017 xblsfpdkkcbroncbjdxhzcpvfliyouiqkaemenescbguazsa
 * Smoking Wheels....  was here 2017 snvnhihlplvpntpjxqhwzdricdiehcndsoouuqhzxspbgrur
 * Smoking Wheels....  was here 2017 rdtncjqkorgqowtdsxrdfqfiombfemgvtrspjpipjaayabol
 * Smoking Wheels....  was here 2017 rpiqpqvekdmkukjtzwlhyvdyyayxqwqixqehkyowbtgqafjg
 * Smoking Wheels....  was here 2017 xvycdmurklctpgmyfsfvpepjvpughkwozuvprjihuzfjborf
 * Smoking Wheels....  was here 2017 vzejdiqfehtuqojnawukanzeahorbkoqvwuneyirrafviqjt
 * Smoking Wheels....  was here 2017 dowekywinvmutsprlzhbftadqiltanmasukffwnazlrvekkn
 * Smoking Wheels....  was here 2017 ufdmyicunilkdhzvrbdylepgxjzhpqriathfgpaphbikgzek
 * Smoking Wheels....  was here 2017 awimashqmjfldempcgvoehxvndvkkwllnfhebzgymxfylrco
 * Smoking Wheels....  was here 2017 fsbrepocatmakmmxlzipevijfsaljoiodumbqxwwphmbxdcl
 * Smoking Wheels....  was here 2017 deftctjuxneluplxryqbnunrckuyqicbalgdhsvjxuroafdq
 * Smoking Wheels....  was here 2017 qywrwdjkhzqimdfzybfckkmtmupvncvpskgvmvhscemnkcnb
 * Smoking Wheels....  was here 2017 azjrrblaksfnwzvvuoogkehxysecryucvagwaaqlwoyhycuw
 * Smoking Wheels....  was here 2017 skifcxvxxntcngphvuqefwkqidnebgorjbkfwhpjkgfmuvtm
 * Smoking Wheels....  was here 2017 jsqzxnwpolejkiaobnlxwlmtslvptqxsnkabixalztvxifln
 * Smoking Wheels....  was here 2017 yoizbwhvlvszquxaqploqelfkdpfdyvysguyxhdzdxmreidx
 * Smoking Wheels....  was here 2017 rwvkvfzqyewsonijbhdrbpmkycpdwjsfqammjhinttedgolv
 * Smoking Wheels....  was here 2017 zvrstzdjojisvrnkzalyvjztfisrvgarhlgsrvgvxqcvrnbq
 * Smoking Wheels....  was here 2017 pxuqoadlekdhjpbkjkmianqbgdhldeptwkludewywcvqvdcz
 * Smoking Wheels....  was here 2017 ktgchgrtupmagxtrllobwijkkdsgfalctcrghuidgyzrjlvu
 * Smoking Wheels....  was here 2017 rhkjfyrfvnwuymqxqhiowghafbufryxosyttvnaywfqfdvuf
 * Smoking Wheels....  was here 2017 vtwxuphetazqalzaqkopvbwkoalrkhmjrrvhugqcufywizuq
 * Smoking Wheels....  was here 2017 pnnkvzyemcwykdjdklmcsttklhyforzwvegblhcrjolnhsws
 * Smoking Wheels....  was here 2017 vhkvjahybbrhegnrdijivowagmsrmaltqqqnhcoydavfreij
 * Smoking Wheels....  was here 2017 vaxkoagnunzmupohhgvrqzknnjocwjdxunvldlmkyrchjrrt
 * Smoking Wheels....  was here 2017 awrpamaegglqwitwossxyttlczkxodrmgmxsyilwvumjmxsg
 * Smoking Wheels....  was here 2017 bhmcmdzlhhbdgupowhezswonbrnrsyuwfmgpzzmjeylgmtnn
 * Smoking Wheels....  was here 2017 yynxyyvdzzcmdpzulzndgpuwszjetrntcrlotxqdoysbxgim
 * Smoking Wheels....  was here 2017 wtcfrflgpxzowrwftyktblprqsqofkezqnkgbvltswhdrvtg
 * Smoking Wheels....  was here 2017 gzunfjbauulmcbormrqqxdjnqyjeboiutretxumyvalaycog
 * Smoking Wheels....  was here 2017 vynmggabitnnsfpkntjsuqvevzuolstmrccemzstdyopcytd
 * Smoking Wheels....  was here 2017 nlicwtbchckjvsvteewfygvqnjipruluwywakzhmgllztlru
 * Smoking Wheels....  was here 2017 niqohfbeakptwkgkudvoylpfgxujmvuozrgajlrqzpalvavk
 * Smoking Wheels....  was here 2017 iuajabeockuvmldgdacnmznlxrcerhgzzykckklzlsoqkhbi
 * Smoking Wheels....  was here 2017 pihgwbwtigzymfckdotaqvhbnzmqksqlbtqntdppxiojybig
 * Smoking Wheels....  was here 2017 gnqcvgtpuelrbhwizrdiqgtdkjlqcbaprepszbhszgrsanac
 * Smoking Wheels....  was here 2017 okjeduubuupvpomrdnwvzsexeqtejjqjotdkuaxvmozaoaqz
 * Smoking Wheels....  was here 2017 ycbzhgdlywentehhipvhlayyqxhrcbdwpciofydvmoqyqfyh
 * Smoking Wheels....  was here 2017 cbqecjehbmfdjmujlmcradrzwkjrksenbeoknbxqhveftxbs
 * Smoking Wheels....  was here 2017 yzdsocqieyweocuhsfafahibetlasgxzidlkfyiondgakged
 * Smoking Wheels....  was here 2017 tuzwytkqrurnuyisoxgiyacmdsgvquodemufbhxdyoyqppxs
 * Smoking Wheels....  was here 2017 xqsattqmcwjhrbsotbptmbjtpktlcqselvtwbcgdrkkrkpbw
 * Smoking Wheels....  was here 2017 cafzswukgfxubvmzegeltjurqbfkemelldromqhqafdzgdpf
 * Smoking Wheels....  was here 2017 ioqrwdmcgdnqcykianiqyfhfnhbohdxqopduwjfvpvxqshwr
 * Smoking Wheels....  was here 2017 ufghntrsjfrpefoivasuoccsxwbbbuhrnqzeyakhdhqytmlj
 * Smoking Wheels....  was here 2017 xesicgmlgfdwzufveecpluornxfekuvqgyjusrptuypplgbu
 * Smoking Wheels....  was here 2017 jwwmlijvrfwsizxacqsbnfiwnqsolshzykqumnpiwggifotm
 * Smoking Wheels....  was here 2017 eyusmbaqsobtknlgtkujbskifrazomujchjqsarfydihrmwk
 * Smoking Wheels....  was here 2017 mkxgophysthvoewgqpzzqsxievypkeorjylbfzfzuovuskys
 * Smoking Wheels....  was here 2017 tkuodnkafqfzlcmvjsepzzgkedkrvfdbsdzaykwkoxzlmxsv
 * Smoking Wheels....  was here 2017 rjgjantibguqysufzjlgbmcijyqxaejxishtemomorfcjxhi
 * Smoking Wheels....  was here 2017 ezmpeqasixiifoqupodcfnkdatdaizgxryzsmslnisiuanxe
 * Smoking Wheels....  was here 2017 netnwbcejegxpobetkwpxohcsjqejrcxmeypoxzaschxhdem
 * Smoking Wheels....  was here 2017 ddsoqiezswiluvhibknnwjfsixcscsldqehjlavutbhziivs
 * Smoking Wheels....  was here 2017 rhfkfeqreamiqsyjnfeuexvuwrteprcxjvihkhwvvfvynyxl
 * Smoking Wheels....  was here 2017 diicqpfaxyachwuriteqblajreclgkcychstyfilmkqvmftq
 * Smoking Wheels....  was here 2017 sfmudvtbdfjpddvyyfcmbmasigwptbsdpcgnunodopszekwl
 * Smoking Wheels....  was here 2017 vbfzgkmcmrgyurkbaaxcxtejryayyamptvboahgrcehzqfbf
 * Smoking Wheels....  was here 2017 fjkjtaupuhrmeubdoxplpgfbtpvdywgutlnbvridlrusilkq
 * Smoking Wheels....  was here 2017 uueyqsijclwukeorssorlfavxsszenaicegnufztfwafwgdp
 * Smoking Wheels....  was here 2017 uhwwesbltrirwqzfyslixduaselogbcclkbqqqpbdxxvdzvh
 * Smoking Wheels....  was here 2017 qabqvmdchuthejotzibcuvxbzzzfcwahuvbijywwjzsegigb
 * Smoking Wheels....  was here 2017 akqzlvyvpvdxhrxjtemxbfbvvmooupohhjqxhkseetxbqcmq
 * Smoking Wheels....  was here 2017 xdswzsemsdregfunlgdaaoegnerkubvtkgjtwmgfeyfqxkuv
 * Smoking Wheels....  was here 2017 meqmrktaygxxnvfvnspwejkrqybvrkaovwdqwyypfrpeyqtv
 * Smoking Wheels....  was here 2017 fqahcjwsxzoesrnfrasfhjeqburfibtwnxamhtlbhgihxlcb
 * Smoking Wheels....  was here 2017 vbrazjwekjoiscguwvpziodwuatdynvdsijnlfsqtewvdryd
 * Smoking Wheels....  was here 2017 ebtqikmcmtezrtdzhbpkqffjfgulwufyuivfvuvpfiywikna
 * Smoking Wheels....  was here 2017 oopjlrpnnsxzylimkyjxqvpnwgmesxgfmgghefhlmsnticku
 * Smoking Wheels....  was here 2017 kuuqutktbzkjejadxwrgdcrtocwtlgmdswrsnmsaprwchhjx
 * Smoking Wheels....  was here 2017 jdffdjhixrtngwucsorkecdxkbcrcmsctcordwbhyulspxmz
 * Smoking Wheels....  was here 2017 kizanlzzeccainlvbxtoyzxytstvdlzszckqmvmpauzrxbay
 * Smoking Wheels....  was here 2017 uglheiiteuzrugaxjdleaicfcxmiegnxcidjjekktumjbcnx
 * Smoking Wheels....  was here 2017 wdelqlnymocqgeuhjqrzdvffiqhmchyvclvtuvlmccdifrui
 * Smoking Wheels....  was here 2017 kkbhqozbxmlepqiczdmxhmwsmgkxaebxekwcacpylgklupxv
 * Smoking Wheels....  was here 2017 jsesfrkwnwfyahktloggtpytwiikjuvtsjuuolzzkbcujbbi
 * Smoking Wheels....  was here 2017 waxzqarlrgytvzcxdbqjbpspdptbufphmuooepadspdswkxz
 * Smoking Wheels....  was here 2017 lmwnkdzaymissvqlvckbzgmtafsgcwxrkjekwpjgneutkged
 */
/**
*  ByteArrayBody
*  Copyright 2010 by Sebastian Gaebel
*  First released 01.07.2010 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.protocol;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MIME;
import org.apache.http.entity.mime.content.AbstractContentBody;
public class ByteArrayBody extends AbstractContentBody {
	private final String filename;
	private final byte[] bytes;
	/**
	 *
	 * @param bytes of 'file'
	 * @param filename
	 */
	public ByteArrayBody(final byte[] bytes, final String filename) {
		super(ContentType.APPLICATION_OCTET_STREAM);
		this.bytes = bytes;
		this.filename = filename;
	}
@Override
	public void writeTo(OutputStream outputStream) throws IOException {
	outputStream.write(this.bytes);
	outputStream.flush();
	}
	@Override
public String getFilename() {
		return this.filename;
	}
	@Override
public String getCharset() {
		return null;
	}
	@Override
public long getContentLength() {
		return this.bytes.length;
	}
	@Override
public String getTransferEncoding() {
		return MIME.ENC_BINARY;
	}
}
