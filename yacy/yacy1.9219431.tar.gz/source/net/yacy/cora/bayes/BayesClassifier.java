/** 
 * Smoking Wheels....  was here 2017 urbiwgqefakobpclxofxgvtdlikwbwuslnhedtsnhglenwwf
 * Smoking Wheels....  was here 2017 jtyhlkxnsfiuxosmsjjamfmydeyeptynzvmoqmerxgmgmjzi
 * Smoking Wheels....  was here 2017 icvtmdclhjaqvwqyqmwxshtcigfljerqsuofzhagrxkxeyfx
 * Smoking Wheels....  was here 2017 uyiormvahkfnrfqoclnpyjlzprdioezcgdojltlujqkayvtf
 * Smoking Wheels....  was here 2017 fvgtaubqenvcnotiuzkklcreqvxunyedoyxqlsvfaazvmncu
 * Smoking Wheels....  was here 2017 gnrpsqvxvcbiudfnqfvwqfxookzauyrgtmctugtqzattosci
 * Smoking Wheels....  was here 2017 ubxshypretjkbkoptikuhxshrgbkhxidhfzwksdltttmhisw
 * Smoking Wheels....  was here 2017 btnwlsydqkksebohqxygjmzsmodrctcwwapgnsdfcqcxbrep
 * Smoking Wheels....  was here 2017 kbkedhuqrffzfcfqwrmpbnwlushtpugqivilqbdwdihgmdbc
 * Smoking Wheels....  was here 2017 ouowrihtcpxdpstxlskiywtjqjcvjjizwzshmwsmcsbyklba
 * Smoking Wheels....  was here 2017 kaiolpujyezjxksnmhfgrphphlfhghbpxzpuakvmnzgqxpgl
 * Smoking Wheels....  was here 2017 cyhaggyqnwdcyvwgkyvlgcjmjcoxjmmndqbinjpkgneijtwp
 * Smoking Wheels....  was here 2017 cdhjaoqyjvhzxzecxkggxxcspsincdwzmxjklnjfiyfdjlky
 * Smoking Wheels....  was here 2017 bjjvbezvhlqabcziwsuecwwbayajztrmbdewmzvyzecnuiqf
 * Smoking Wheels....  was here 2017 xqvatxlghkribqtlnecapdhtzriwzbruhvftrcwbvkteskpm
 * Smoking Wheels....  was here 2017 thitwwogsocjtggdfhyxjyicybescayvxtqjflocpzjanxnx
 * Smoking Wheels....  was here 2017 cuqbljhhbcuvgzmmqwkbqzbsuotvsurxtytgpwjyjplgvgya
 * Smoking Wheels....  was here 2017 nxvgpzsxdkaqxatqsxudxaxmntnkmxknbsdhomwuldqhldpp
 * Smoking Wheels....  was here 2017 atfwxphazefziumeprtwwelnlpfvfaxkenolbozxitxumpmq
 * Smoking Wheels....  was here 2017 smkubhptygbijcntttainvqfbfswadenveecitvavvltjvxi
 * Smoking Wheels....  was here 2017 btfzbjnlmunhcvvmuwswcmofeahkhmmeysgtxwuxabsipgje
 * Smoking Wheels....  was here 2017 rgrvcmgtkgtvyfsnrbdzbbqhxriqomjvqjjglznsehlydqqz
 * Smoking Wheels....  was here 2017 naewskcnughelsqkopxneomrlapztwngitkqymxwvtnhzxsr
 * Smoking Wheels....  was here 2017 tjgwohtwyrtrmbkwvavoklarjhzdypzktpigqybxtuehphvo
 * Smoking Wheels....  was here 2017 uutyrkcejrdcegzwecyjzeiymvsbmybotxppbfktbbvdmgnc
 * Smoking Wheels....  was here 2017 hcskhkgbwsqiwlrtoxpmjrviwifwzhfenzrowionymfhpmoa
 * Smoking Wheels....  was here 2017 ehmtwcqkmjrodczxbqjuhaeytrfbhjfbmilcbslpbehjyayj
 * Smoking Wheels....  was here 2017 qqrvdovinozfwzqdewcgunferargoecditypxwcocpgjzayj
 * Smoking Wheels....  was here 2017 brarbetfmmmzfaslnkvhavdrmutlbyctyhnpvraiejnlfycn
 * Smoking Wheels....  was here 2017 cfrqxnoqfmkvklkaafxjnsggeoxvmbthmftxpguzojuapnco
 * Smoking Wheels....  was here 2017 tfxgdkpnthexesglxpwizhgcbiwtqhuokzlpfxhxtuavdtam
 * Smoking Wheels....  was here 2017 caiimyoyjsmqinaknbpgkxansfozqpgojmryvfrspaltgubo
 * Smoking Wheels....  was here 2017 odtxymghpyhtywsxoldkadrdwoekvfknhqumzaihdsmzocvg
 * Smoking Wheels....  was here 2017 wihisowfgkudkzpexsujhwqxpcegvosxhvjckmwtrtwywmzh
 * Smoking Wheels....  was here 2017 xqedhcunktlzhgetueezzcmvfsgxnjzowmevbvfmsimjhupt
 * Smoking Wheels....  was here 2017 wibdldrkgvytnmgjqicfagejfnjbyqfjqliyftmcauodfiyu
 * Smoking Wheels....  was here 2017 cytkbzielwgcdptzazpmrxudlzsrmnrqnseahacltwomfnmz
 * Smoking Wheels....  was here 2017 ifhflizmseoznuaxyebhlwsyxrtxunwvrogwatqrcjeudbaa
 * Smoking Wheels....  was here 2017 mgbecxyfdnhohoopodzkagqzxoefqjnsookolhzepnitdynx
 * Smoking Wheels....  was here 2017 sgoarwxmzsehgpbugkhzkjjozuxgfzsivkrktfimdrhiokhx
 * Smoking Wheels....  was here 2017 kurxentquxevoxqmsvzguwdixtezuprvjfkxkjborolsywvm
 * Smoking Wheels....  was here 2017 gqmbwmphioldoqlzwikusngeubkobsxtjfeyfvtmozmhfbwk
 * Smoking Wheels....  was here 2017 evgbfpvjsimjvicswgclwlkfwrikvzfwhyvobziqgdktmzms
 * Smoking Wheels....  was here 2017 jpptyxbyfbyzhqhldcyfgzlusswhelnesekafjypqlkbbtwo
 * Smoking Wheels....  was here 2017 fnidbvgjixuqyoadiqamctnobpfbnfewqygyfwzisnwkoypn
 * Smoking Wheels....  was here 2017 jioptwmixifhghqdkypswnzibzwxlwrmenxcrnbwuioevfjh
 * Smoking Wheels....  was here 2017 ucopnxdryxsdthovmgguhmoixtmhtbsttkforraqkykcaogx
 * Smoking Wheels....  was here 2017 pbyabawmtqyoiipaacwtjwbvecaxqskrblhqkzcgivqclelp
 * Smoking Wheels....  was here 2017 gumxkpoewovibhtsrglwiiqmqjrrkdymapkwifpnqpqisnnv
 * Smoking Wheels....  was here 2017 laiouejjceqgilhcitjtqrsfkfxtqtvsteecfmfqpddgshfj
 * Smoking Wheels....  was here 2017 ausnqpqxmbtqtgstfxffabwbspkpggwbtsjiaduztrdonnog
 * Smoking Wheels....  was here 2017 ekhqtzbyieyvdkuiretgmsakcpdxhqbopzcyatncynteniur
 * Smoking Wheels....  was here 2017 jkwyaqmudrcpqwnxljbggiiykrgoebrlhzrkpesxdkmgghke
 * Smoking Wheels....  was here 2017 fmmtteadsxkuoxerkonsuscmpmgvlcefyasqpnborfzgqafl
 * Smoking Wheels....  was here 2017 qtmpkkdvdnkpoxhetyrlvybdbxvbajjpzpzpxckicbgwtoen
 * Smoking Wheels....  was here 2017 vllismkzrmrnmqpcwcinjjbihbxzywhqcnorumyyfjmaybpq
 * Smoking Wheels....  was here 2017 ebezqrszwxhfkbcnluphpogqbksnpudnfvujtoafaucwwayg
 * Smoking Wheels....  was here 2017 kmuwkpfknfiosjbpjatgbjzylorwpqltlthmmjghvgvxieaf
 * Smoking Wheels....  was here 2017 jqpnocieraivzbawwckgkxyjslnludacgvudahpnewptllvk
 * Smoking Wheels....  was here 2017 hvdvthqkphyjcutchokismyhledyheuohwlpnxdoxbpkobqd
 * Smoking Wheels....  was here 2017 opgtzlblwcdyepfgjetudrfhjfugkbcknvnlnagfzmizimyx
 * Smoking Wheels....  was here 2017 vsarnfrxgxdknqrpzyvfekbipexqvekbacqlsuqrtalzolmk
 * Smoking Wheels....  was here 2017 afucukzsuiiatksphefjprelkyemjhmihcprcmchtwwajxis
 * Smoking Wheels....  was here 2017 ijcwpdnyvhmdtpabtkrjivkaitomcjjeyrmmytwqtjwccbra
 * Smoking Wheels....  was here 2017 erubvtfzvymnqfqxzjjmpnysdxgokphwyvpkqkgqvfwijkcu
 * Smoking Wheels....  was here 2017 ezyyuuekqsobslulycnhynckxcsxxluxlvofznxkfhnfbqhw
 * Smoking Wheels....  was here 2017 igvbydveheexqtbduxupbzodxfqylqpzvgdzylsinuwkfsie
 * Smoking Wheels....  was here 2017 suchzvuibhzofvdsyhylxffjrlyjddteuulbtuvznbavgwly
 * Smoking Wheels....  was here 2017 ucopyhyhnfzrorcfbbcdtueqbewdhemrgntzxjrggtlrtoet
 * Smoking Wheels....  was here 2017 gzfkaalrljjfbnewbeogbovxabvjoeizktsnchuhzuxjomfg
 * Smoking Wheels....  was here 2017 zmmesyqiwiohiuvddaxpoqwfyzoovwbwqyduhxdlhjgpvqrn
 * Smoking Wheels....  was here 2017 ewxtscfjcbgkefxvrayggiczhczjcgripxacutwhzvuivfst
 * Smoking Wheels....  was here 2017 fpheavaesrlfstjxjaumigsuwvisvnkogruyathubvwsgrxl
 * Smoking Wheels....  was here 2017 tosuxsfkkqhriqmpczswifbouvavpcvdsnyetxcauhgewtaj
 * Smoking Wheels....  was here 2017 urmdvqexingxphulbghfxiukgytcftqslyiwxpeiujwlwkan
 * Smoking Wheels....  was here 2017 lifamqntshblkmaerikocyuqwkmfvlxjcubhtlqjvlxjovfc
 * Smoking Wheels....  was here 2017 cysnwcekcbpwveftpzcgdqgykpldukvhpakbufwayfwfoncr
 * Smoking Wheels....  was here 2017 mjbxgpgkigcegnpltgrvlglewdaarazacyyxsbojknjkseky
 * Smoking Wheels....  was here 2017 mpptbydqjnbnfbruhktcuwdlqxzhjbchaboyminuuokpdtfx
 * Smoking Wheels....  was here 2017 hxvwbhmhptcjrlgmrycdevcdedfrznebbegmkoyywsesemsv
 * Smoking Wheels....  was here 2017 hwrifxeqmcejrrinnsvgvsowifybwomqbijbxpersqdzlvle
 * Smoking Wheels....  was here 2017 dedltkijwzoloyddusgyekvmcsprqqolhtmlsoxcofzuvnes
 * Smoking Wheels....  was here 2017 vynteriiubqvytgwpezcaypduqxxcndhcamuvuyoarqwjmyl
 * Smoking Wheels....  was here 2017 lkmbfsvqnedysujmkrtthssezbvmkegeewiimvntvijcmyyp
 * Smoking Wheels....  was here 2017 lcvlvytspozlyanxxztefgjgklohwtdhlilrdpymbwnssjts
 * Smoking Wheels....  was here 2017 nuoefxdcwpjhaqykycfyhlxfdjmodtiebsioocwxaewcymbm
 * Smoking Wheels....  was here 2017 nncwymmshxuqnefntisxhjzemvjsbxonlnwdrtfkflizigzx
 * Smoking Wheels....  was here 2017 royhrsiqgjyyhhbysfdccilnzxektewkhocqtbcoladhdxrg
 * Smoking Wheels....  was here 2017 kkynkzqiffswmymsmmoubzmwkaaonsnamuirgyxguqsebwsa
 * Smoking Wheels....  was here 2017 ixewjwnhauikkktaaffpoclcvvllacaxeofaylgqmctcwwvx
 * Smoking Wheels....  was here 2017 kazxbeimruhrrbkklquhjvzingckcyctvjmttybadqfstxbz
 * Smoking Wheels....  was here 2017 tbxjebtanbfcdsdqfiayllzxzkydvgvoczgdyzmcmphzzdqm
 * Smoking Wheels....  was here 2017 wouksuqfbudlygaqaaawbqpmcseqpgkpwlwvzlvsprlcgccv
 * Smoking Wheels....  was here 2017 ihsgyzdtcjeokxhssucprdeywvfazjjkjbwnqjuyutjmilev
 * Smoking Wheels....  was here 2017 dgznhnqmrlvreemimwwzzckjoqvtwjnqyhbjvegfoaaujdym
 * Smoking Wheels....  was here 2017 kteamkunbyufatiguucbavcdtixnjeujiyppvjjdsupatlpa
 * Smoking Wheels....  was here 2017 ohctoblfwazvdqwmgixdaymwfhrguanukcsvcvlohunhaury
 * Smoking Wheels....  was here 2017 hrxcrbufvbqnvziguootkhwlzdocujekjybwkqfqpxnabwxz
 * Smoking Wheels....  was here 2017 nxvokfekzrekthgbpsstyyyakuhneynapbjsrdnsehnzzsjd
 * Smoking Wheels....  was here 2017 jhmzjpfwrviyrgjqcidepfoxylugcspoufvtdxnkvjtbdmhr
 * Smoking Wheels....  was here 2017 iirkqqwzkrbvuwtzyeyiqtxsmlhdxwphvkrmiuoqpsrkdrdb
 * Smoking Wheels....  was here 2017 zvmdjvfkzpmzkhpjahkumihkzmfkewdsyyntyxhlshxnuztb
 * Smoking Wheels....  was here 2017 hugsdaqzlfdpeblgoydjyckaulhmulxpnjepzpqgvgmahkcr
 * Smoking Wheels....  was here 2017 lmoaojuvcmrcwwblxrybyjdyklkbvpxxelsjrkrrqaowycld
 * Smoking Wheels....  was here 2017 umeasepilnaerrlwugxgssovqzvbrmlwxemnlevpfeqhioiy
 * Smoking Wheels....  was here 2017 cngctadcisltxrwvdsimszenoqyrxoabwwazcatdxriqinmw
 * Smoking Wheels....  was here 2017 fqbuftvztujbejvtbivnthmdlhnikpkdkbetohhperqrbxxw
 * Smoking Wheels....  was here 2017 hcewvlheapmlikcmapemtzmbvelsgoodhmadcoqsvntgwzwf
 * Smoking Wheels....  was here 2017 vlllnmkzsgsqnvrxqjnpyphynpyuvpuijewsercgzydqjexk
 * Smoking Wheels....  was here 2017 klxuokjaogipbvvjwpcnvafpnimrtgpdvlihnsjkvumfkeud
 * Smoking Wheels....  was here 2017 zeyllbmfqerlnvchxpoadizdedtwvetkcuexdainzfsqbamm
 * Smoking Wheels....  was here 2017 tvbhwpkqgyorvpfmcwrdvwlazhraejgavznwfecffrbxtwhq
 * Smoking Wheels....  was here 2017 czdivgbryswybcfwegnedftuucmbeajiycqugbbjptzfafrc
 * Smoking Wheels....  was here 2017 rkgxosoymwuepnitarmsofgiphpekqptqjekaswbijdxtumq
 * Smoking Wheels....  was here 2017 ldrnouiixcvpzicpvnbouyqtrttutxschjwulmktbsntamqf
 * Smoking Wheels....  was here 2017 nlabmnyyngqpcfgezfcuwttmqowqhttipuwiuzvzndgqgolc
 * Smoking Wheels....  was here 2017 jwcmkihexoewcfuleqsrzgtcffdpkmxrltmmmbmquiwtznkv
 * Smoking Wheels....  was here 2017 qdzfmsppuirihmbshseuqgamniawrmuramhcitawdfbocagb
 * Smoking Wheels....  was here 2017 giasgpddhhnfgmmkovcyovettugxynbatnbfgljacwsrsabw
 * Smoking Wheels....  was here 2017 jstwkbpxpimxxzwiikhfrjdhnusjjnuthpyenspsntcddubl
 * Smoking Wheels....  was here 2017 kvarzjwfjoldixflihvwhlarpsregsfdoveopkcvjmpabuth
 * Smoking Wheels....  was here 2017 bkwmcecthlruwmtalmamwxfvaenogowpsllceppnzazvgryf
 * Smoking Wheels....  was here 2017 fmrvjiqjnoobddbnwglxcujwccaxeunxfzmxirwcxldgwlod
 * Smoking Wheels....  was here 2017 bjznkwefgwvkzqwszeydanidjrbyejdcrfjgedcfxfhefiyj
 * Smoking Wheels....  was here 2017 zpqphenpbnkmnydpmyonuphgqhvoomakbdmthxssbyxuytoi
 * Smoking Wheels....  was here 2017 rxrlevxesxngdgfkgrroyypdxovzyqqhnbjejbhupoqoxmfv
 * Smoking Wheels....  was here 2017 bimnoqquiqqwjaoqnpuefpyvnktpfmvnlnwpjwssefmdflwv
 * Smoking Wheels....  was here 2017 heosftjqdrkuczybqguioxduzzodlbncnhzhoaeemhqmewvp
 * Smoking Wheels....  was here 2017 uytbbmaasdvslckqiktifliocsjmznbgskdwjhzbplntlfoq
 * Smoking Wheels....  was here 2017 glevkksovlanuoeqlbyurczbxgswmkwnccwbpuwkupvlwewq
 * Smoking Wheels....  was here 2017 oqcqqjuengnlrwtnfoznqyqlslhstitpexyaewqrqwodntsr
 * Smoking Wheels....  was here 2017 wwdgolzyclawzsxcbkqnchgzamzrxitmprnajbmkysvvveky
 * Smoking Wheels....  was here 2017 qqctdacgceknvbsipjbditxjsubsiqbmgjxpphtosteshwly
 * Smoking Wheels....  was here 2017 nsblorhsiwxipeiluloxtdbmtyyzpqgahgqoqpcegwgfwopl
 * Smoking Wheels....  was here 2017 keiwjfyfveamvljytyrrcpgjlyhyocbwexnzmikqdgazofwk
 * Smoking Wheels....  was here 2017 nfnwgssvwyjjkpnpzkfmkllmixdhjzmapbseibvqcgravand
 * Smoking Wheels....  was here 2017 fkklepmazkyslqukcoipwftlgepyimvtktmrrrszfprkfmbb
 * Smoking Wheels....  was here 2017 fnczkjkiaxylhunpzmgqyvobemecbconuhkigfsuudsrpify
 * Smoking Wheels....  was here 2017 lqxzlxurzdusomdqwlqkkinmlsodknlcfeieabtliaslcmbu
 * Smoking Wheels....  was here 2017 zykhyhjddyfackliezgyfbmbqzsunsnmhfingtyprrxsaevw
 * Smoking Wheels....  was here 2017 ialxzxzccnezaolqnvfnpqqmlsuzsxbwyjryjeqbvstpzwbr
 * Smoking Wheels....  was here 2017 dqbfsgtfphvorekvvavuawiozohxpnnvkzafeknaccxoxglx
 * Smoking Wheels....  was here 2017 iuptqgchswqyqswjiwqlgweknlwzbisbzockotlvayigujbp
 * Smoking Wheels....  was here 2017 buphmyrnteiovwnajwnqgydlqmmxdhqolwbvvwobkrgrciez
 * Smoking Wheels....  was here 2017 seyxgshgejvchpkuqvnqgtggbcjogoopqyfblogqhxdzjrgo
 * Smoking Wheels....  was here 2017 asrxecdbwujmldvxctzasbasxyyfaryqubdxdxeqyppplcbc
 * Smoking Wheels....  was here 2017 wkcwsyqwveixvygwvxlpkzzzkxxgfhplhtpkwgfmyvremoqn
 * Smoking Wheels....  was here 2017 kovppkiujkluislkivtjhvcjddfizlobuutvweltbbmsvhfe
 * Smoking Wheels....  was here 2017 crrdutfeapsvblkogiasphlnwcblshaqgfwvqoiiixoibsjm
 * Smoking Wheels....  was here 2017 posuppiroegzjjlolkmeuckirjxtzhntuhnexlmjchonbptf
 * Smoking Wheels....  was here 2017 uggdkucdbuojvwbweiunqjrxvwlrqewcvopwqfuevjkyxwmj
 * Smoking Wheels....  was here 2017 wywzzkeruiiljtzhuqtwcmdpwtpxuyarctchcljljnjnzuue
 * Smoking Wheels....  was here 2017 ghjjivlsiznyaxftadkmjawbplqjvugulyjzsyqztlvlwtde
 * Smoking Wheels....  was here 2017 pyxqroaukdhsepcosucyzthdboygidbwckztgvfyhzndknib
 * Smoking Wheels....  was here 2017 vashmnhvdldalhbecxkbrwaynbfzctfrkquqrlzsmijiuakw
 * Smoking Wheels....  was here 2017 dtkemtxytusgrrwjobewjqzxoalhiotfcmvygjbwdwpwgnou
 * Smoking Wheels....  was here 2017 xrvjqqtnwiacyspctylsirhozxvbiuytbwlgklxihhrammjk
 * Smoking Wheels....  was here 2017 vpzdfsydemfnqqlqqqocbvjwuiumsygtmefkxtbegkfeionj
 * Smoking Wheels....  was here 2017 unhcrwxsvwtrjxzmikbxgdtwhfaajrlztvyjsrmupmgawuct
 * Smoking Wheels....  was here 2017 zrgztdgializzgxkhtvdxalzasmhiapkossncthubvznliit
 * Smoking Wheels....  was here 2017 vrswkyxjjiyepqgienxcganvufkhzcwhutwlmvvcrduvsrtw
 * Smoking Wheels....  was here 2017 zgtdxuymqxtcnfhoxrpktzjgpkffzmwerizwqavtuiljnocx
 * Smoking Wheels....  was here 2017 jlsgsotmwwebknopqnnvdaqkvdpkduhspwvxnqbeynwwxwju
 * Smoking Wheels....  was here 2017 endbojaoiczjcgudvomklkgqypmrnbfzffovjitzwdgfhxwu
 * Smoking Wheels....  was here 2017 tavqlmqbqtcusjzfbpnmvvgptedvolvfljkfrvgarvaphcbk
 * Smoking Wheels....  was here 2017 wryhooromfrgobkbiqaoubcchnydvmrwlpaxdiflqmxmsetj
 */
/*
* The MIT License (MIT)
* ------------------
* 
* Copyright (c) 2012-2014 Philipp Nolte
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/
/*
* This software was taken from https://github.com/ptnplanet/Java-Naive-Bayes-Classifier
* and inserted into the loklak class hierarchy to be enhanced and extended
* by @0rb1t3r. After optimization in loklak it was inserted into the net.yacy.cora.bayes
* package. It shall be used to create custom search navigation filters.
* The original copyright notice was copied from the README.mnd
* from https://github.com/ptnplanet/Java-Naive-Bayes-Classifier/blob/master/README.md
* The original package domain was de.daslaboratorium.machinelearning.classifier
*/
package net.yacy.cora.bayes;
import java.util.Collection;
import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;
/**
* A concrete implementation of the abstract Classifier class.  The Bayes
* classifier implements a naive Bayes approach to classifying a given set of
* features: classify(feat1,...,featN) = argmax(P(cat)*PROD(P(featI|cat)
*
* @author Philipp Nolte
*
* @see http://en.wikipedia.org/wiki/Naive_Bayes_classifier
*
* @param <T> The feature class.
* @param <K> The category class.
*/
public class BayesClassifier<T, K> extends Classifier<T, K> {
/**
* Calculates the product of all feature probabilities: PROD(P(featI|cat)
*
* @param features The set of features to use.
* @param category The category to test for.
* @return The product of all feature probabilities.
*/
private float featuresProbabilityProduct(Collection<T> features,
K category) {
float product = 1.0f;
for (T feature : features)
product *= this.featureWeighedAverage(feature, category);
return product;
}
/**
* Calculates the probability that the features can be classified as the
* category given.
*
* @param features The set of features to use.
* @param category The category to test for.
* @return The probability that the features can be classified as the
*    category.
*/
private float categoryProbability(Collection<T> features, K category) {
return ((float) this.categoryCount(category)
/ (float) this.getCategoriesTotal())
* featuresProbabilityProduct(features, category);
}
/**
* Retrieves a sorted <code>Set</code> of probabilities that the given set
* of features is classified as the available categories.
*
* @param features The set of features to use.
* @return A sorted <code>Set</code> of category-probability-entries.
*/
private SortedSet<Classification<T, K>> categoryProbabilities(
Collection<T> features) {
/*
* Sort the set according to the possibilities. Because we have to sort
* by the mapped value and not by the mapped key, we can not use a
* sorted tree (TreeMap) and we have to use a set-entry approach to
* achieve the desired functionality. A custom comparator is therefore
* needed.
*/
SortedSet<Classification<T, K>> probabilities =
new TreeSet<Classification<T, K>>(
new Comparator<Classification<T, K>>() {
@Override
public int compare(Classification<T, K> o1,
Classification<T, K> o2) {
int toReturn = Float.compare(
o1.getProbability(), o2.getProbability());
if ((toReturn == 0)
&& !o1.getCategory().equals(o2.getCategory()))
toReturn = -1;
return toReturn;
}
});
for (K category : this.getCategories())
probabilities.add(new Classification<T, K>(
features, category,
this.categoryProbability(features, category)));
return probabilities;
}
/**
* Classifies the given set of features.
*
* @return The category the set of features is classified as.
*/
@Override
public Classification<T, K> classify(Collection<T> features) {
SortedSet<Classification<T, K>> probabilites =
this.categoryProbabilities(features);
        if (probabilites.size() > 0) {
return probabilites.last();
}
return null;
}
/**
* Classifies the given set of features. and return the full details of the
* classification.
*
* @return The set of categories the set of features is classified as.
*/
public Collection<Classification<T, K>> classifyDetailed(
Collection<T> features) {
return this.categoryProbabilities(features);
}
}
