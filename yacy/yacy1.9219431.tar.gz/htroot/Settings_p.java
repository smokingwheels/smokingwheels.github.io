/** 
 * Smoking Wheels....  was here 2017 qbgpxsnfrwcrmaqpfnibgekmvhilvmeeoiytbuobleupocsw
 * Smoking Wheels....  was here 2017 vhzwkislyrtmoomhfiulvzmlqcptvxraprepggjdpaivrzij
 * Smoking Wheels....  was here 2017 ntchpvuiifaajqsdndcmxskklaayonqzzzyvayguzpujtatf
 * Smoking Wheels....  was here 2017 auyskoiisvuiqqltpmtiszabjqshxamxjbyxvsiavuoswcrm
 * Smoking Wheels....  was here 2017 svyjfcdfefdsghdzdcmltpkktxbjajxytxfnnqvatshrmman
 * Smoking Wheels....  was here 2017 iqwrlfgxafmsipnyczilxpvrfxryjtvjjuaobbkgqtvhfpzz
 * Smoking Wheels....  was here 2017 whsgzazqwakchrlzulngcjvjnbkcmqlwqfuftmumophxzdzs
 * Smoking Wheels....  was here 2017 nztbuwxypzvyuaeroyocrmgevzlckseghyiwdvcsvbbayasu
 * Smoking Wheels....  was here 2017 tglgdgunfsuosibyehdicseclpbmeytqhaqgzdodbhtkmnco
 * Smoking Wheels....  was here 2017 hwnfobticdtkgowvpliqfewjyzzbgmakwrxfirvfbsgdhair
 * Smoking Wheels....  was here 2017 bwzrwjcqwjhjuwmsbshyadxmfpzwgvgcmksykcqtyyrnfgwz
 * Smoking Wheels....  was here 2017 ildncmixiuhlytcfzppkugbdizgfcrvqwzswuecqcwjbldjo
 * Smoking Wheels....  was here 2017 ndkxlzhxocvyrweddwzlahlhpddpzylcylyqgameaqzojxtt
 * Smoking Wheels....  was here 2017 jsphnrbnycjjcfirlmltojjgrcgwfvavyarfuykvpqjbqzff
 * Smoking Wheels....  was here 2017 wfrhbqxcbzkoqyocdtegjtiliimaovtligjssmphymrxeceu
 * Smoking Wheels....  was here 2017 ewwwcfkascynynabresbubeprkyjvqcuvwupnndpibfocejo
 * Smoking Wheels....  was here 2017 tesexyjbaczpwrektnuqhdztagalfdszkxxnacjyknrwvlrw
 * Smoking Wheels....  was here 2017 jyxqbsvfhxzhqhrfjulprzbbbzhbcpnjhqajfnvuagxwbhhj
 * Smoking Wheels....  was here 2017 zdmwgodsepokqqlwsgwyyzxanzrgdktpxnoijkixfwavpmrw
 * Smoking Wheels....  was here 2017 tarwouwzlpnzldrzhlpukrjkoyhigiulzjivboyhjhkisyln
 * Smoking Wheels....  was here 2017 fezthztugnaiblvkubiopxnemrluphjcmehobbycaqqcrvqq
 * Smoking Wheels....  was here 2017 agezxzxdwhlypppgdecxhtrowjvloljwqfskifxxbiqggriv
 * Smoking Wheels....  was here 2017 fjfefwpgzakrlswvpaeumnjzpkhjuhzixzbnfqrioymbhcbz
 * Smoking Wheels....  was here 2017 xsiggyloibunhhvuqczilvkhtjzveorkafcjfcgmwjpbycke
 * Smoking Wheels....  was here 2017 qvbkhufwbcrvzayyyfiztkvjqffixccexzuocrymovpaqwju
 * Smoking Wheels....  was here 2017 cldbvgycmalctvwmniekelamwaqtjffzunlbxtjwmphaawdk
 * Smoking Wheels....  was here 2017 gqowrjzmfytcxxorntumselcigcbfgelejobxwiisjwiztcw
 * Smoking Wheels....  was here 2017 ipotwmxnbgmyeuedmyrlqgzyaltpjalksfuwrvuxqbqnqmzi
 * Smoking Wheels....  was here 2017 uxrxremzeorwkbeubsnrmkraiozwxjrzkdfhxtetutgimhrc
 * Smoking Wheels....  was here 2017 igprpgttvvtlutgrfbkvbuuovsksipvnmjbdrxzlavqwbpku
 * Smoking Wheels....  was here 2017 ysiulucdqdjlsaheffnwjrybkhvdfbcqjkvqgxaqlzvkjdph
 * Smoking Wheels....  was here 2017 umdefcaqlwiyvinwntjxssxecyllmmwevbfefojijbflnvxr
 * Smoking Wheels....  was here 2017 kdnyfuixjrufbjiqujrjoqtzgnpeiwwfuhhlgyitlelvxwgh
 * Smoking Wheels....  was here 2017 llgoyrcyrlduncmpacnztotqmexcciaelkgikklklukperxu
 * Smoking Wheels....  was here 2017 yigrevqaaiymqsvblfbpguoqpighmknqixpbamozmmdagafz
 * Smoking Wheels....  was here 2017 advfzomofsdibrornfvkkywssotbjstlcnczozsmxdcqhvxz
 * Smoking Wheels....  was here 2017 giliqmmjieuprrehywowsuvxeutxxglsthtuvbeehxwgrhxe
 * Smoking Wheels....  was here 2017 gswlpjrjtriwrrhzrehoxmrjoexqnfnullulwzommeixbvjd
 * Smoking Wheels....  was here 2017 agbgsijubihykvxczkemcgapracivbdgsoraxirdpppxjets
 * Smoking Wheels....  was here 2017 vgiqzqcdcmquoqdigcvunsrirbkftltagifbnxoexbbuthua
 * Smoking Wheels....  was here 2017 bfcurytdxvkuatllgyxvrsrowdfxljcdaujclvmtbqhipiil
 * Smoking Wheels....  was here 2017 lwedjahuwgblzemoybljjhhnvkedhzaaggketkblxufpnuoo
 * Smoking Wheels....  was here 2017 zgnhtybhovdoubgbnprgquerkfcyzutfjdujrfcwmdxwmizf
 * Smoking Wheels....  was here 2017 wpkfybqcvznddwxoldcstubtsgerjlspcghdubqceourqygn
 * Smoking Wheels....  was here 2017 omhbdyuaujknxivwmllcfcasbiswqxphlqwdvazhoelviugw
 * Smoking Wheels....  was here 2017 uqyhykqyswcgfjudnmtcvujwarkgekironvgvlsaljujhigv
 */
import java.util.HashMap;
import java.util.Iterator;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.http.ReferrerPolicy;
import net.yacy.peers.Network;
import net.yacy.peers.Seed;
import net.yacy.peers.operation.yacySeedUploader;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public final class Settings_p {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
final String page = (post == null) ? "general" : post.get("page", "general");
        if (page.equals("ProxyAccess")) {
prop.put("settingsTables", "Settings_ProxyAccess.inc");
}
else if (page.equals("proxy")) {
prop.put("settingsTables", "Settings_Proxy.inc");
}
else if (page.equals("UrlProxyAccess")) {
prop.put("settingsTables", "Settings_UrlProxyAccess.inc");
}
else if (page.equals("ServerAccess")) {	
prop.put("settingsTables", "Settings_ServerAccess.inc");
} else if (page.equals("referrer")) {	
prop.put("settingsTables", "Settings_Referrer.inc");
}
else if (page.equals("SystemBehaviour")) {
prop.put("settingsTables", "Settings_SystemBehaviour.inc");
}
else if (page.equals("seed")) {
prop.put("settingsTables", "Settings_Seed.inc");
}
else if (page.equals("messageForwarding")) {
prop.put("settingsTables", "Settings_MessageForwarding.inc");
}
else if (page.equals("parser")) {
prop.put("settingsTables", "Settings_Parser.inc");
}
else if (page.equals("crawler")) {
prop.put("settingsTables", "Settings_Crawler.inc");
} else if (page.equals("debug")) {
prop.put("settingsTables", "Settings_Debug.inc");
} else {
prop.put("settingsTables", "");
}
prop.put("port", env.getLocalPort());
prop.putHTML("peerName", sb.peers.mySeed().getName());
prop.putHTML("staticIP", env.getConfig("staticIP", ""));
prop.putHTML("fileHost", env.getConfig("fileHost", "localpeer"));
String peerLang = env.getConfig("locale.language", "default");
        if (peerLang.equals("default")) peerLang = "en";
prop.putHTML("peerLang", peerLang);
prop.put("isTransparentProxy", env.getConfigBool(SwitchboardConstants.PROXY_TRANSPARENT_PROXY, false) ? "1" : "0");
prop.put("proxyAlwaysFresh", env.getConfigBool("proxyAlwaysFresh", false) ? "1" : "0");
prop.put("proxy.sendViaHeader", env.getConfigBool("proxy.sendViaHeader", false) ? "1" : "0");
prop.put("proxy.sendXForwardedForHeader", env.getConfigBool("proxy.sendXForwardedForHeader", true) ? "1" : "0");
prop.put("remoteProxyUseChecked", env.getConfigBool("remoteProxyUse", false) ? 1 : 0);
prop.put("remoteProxyUse4SSL", env.getConfigBool("remoteProxyUse4SSL", true) ? 1 : 0);
prop.putHTML("remoteProxyHost", env.getConfig("remoteProxyHost", ""));
prop.putHTML("remoteProxyPort", env.getConfig("remoteProxyPort", ""));
prop.putHTML("remoteProxyUser", env.getConfig("remoteProxyUser", ""));
prop.putHTML("remoteProxyPwd", env.getConfig("remoteProxyPwd", ""));
prop.putHTML("remoteProxyNoProxy", env.getConfig("remoteProxyNoProxy", ""));
prop.putHTML("proxyfilter", env.getConfig("proxyClient", "*"));
        if (!env.getConfigBool("use_proxyAccounts", false)) {
prop.put("use_proxyAccounts", "0");
} else {
prop.put("use_proxyAccounts", "1");
/*s = env.getConfig("proxyAccount", "proxy:void");
pos = s.indexOf(':');
if (pos < 0) {
prop.put("proxyuser","proxy");
} else {
prop.put("proxyuser",s.substring(0, pos));
}*/
}
prop.putHTML("urlproxyfilter", env.getConfig("proxyURL.access", "127.0.0.1,0:0:0:0:0:0:0:1"));
prop.putHTML("urlproxydomains", env.getConfig("proxyURL.rewriteURLs", "domainlist"));
prop.put("urlproxyenabled_checked", env.getConfigBool("proxyURL", false) ? "1" : "0");
prop.put("urlproxyuseforresults_checked", env.getConfigBool("proxyURL.useforresults", false) ? "1" : "0");
prop.putHTML("serverfilter", env.getConfig("serverClient", "*"));
prop.put("serveruser","server");
prop.putXML("clientIP", header.getRemoteAddr() == null ? "<unknown>" : header.getRemoteAddr());
/* 
* seed upload settings
*/
String enabledUploader = env.getConfig("seedUploadMethod", "none");
        if ((enabledUploader.equalsIgnoreCase("Ftp")) || 
((enabledUploader.equals("")) &&
(env.getConfig("seedFTPPassword","").length() > 0) &&
(env.getConfig("seedFilePath", "").length() > 0))) {
enabledUploader = "Ftp";
env.setConfig("seedUploadMethod",enabledUploader);
}                  
final HashMap<String, String> uploaders = Network.getSeedUploadMethods();
prop.put("seedUploadMethods", uploaders.size() + 1);
prop.put("seedUploadMethods_0_name", "none");
prop.put("seedUploadMethods_0_selected", enabledUploader.equals("none") ? "1" : "0");
prop.put("seedUploadMethods_0_file", "");
int count = 0;
final Iterator<String> uploaderKeys = uploaders.keySet().iterator();
while (uploaderKeys.hasNext()) {
count++;
final String uploaderName = uploaderKeys.next();
prop.put("seedUploadMethods_" +count+ "_name", uploaderName);
prop.put("seedUploadMethods_" +count+ "_selected", uploaderName.equals(enabledUploader) ? "1" : "0");            
prop.put("seedUploadMethods_" +count+ "_file", "Settings_Seed_Upload" + uploaderName + ".inc");
final yacySeedUploader theUploader = Network.getSeedUploader(uploaderName);
final String[] configOptions = theUploader.getConfigurationOptions();
if (configOptions != null) {
for (int i=0; i<configOptions.length; i++) {
prop.put(configOptions[i], env.getConfig(configOptions[i], ""));
}
}
}
prop.put("seedURL", sb.peers.mySeed().get(Seed.SEEDLISTURL, ""));
/*
* Message forwarding configuration
*/
prop.put("msgForwardingEnabled",env.getConfigBool("msgForwardingEnabled",false) ? "1" : "0");
prop.putHTML("msgForwardingCmd",env.getConfig("msgForwardingCmd", ""));
prop.putHTML("msgForwardingTo",env.getConfig("msgForwardingTo", ""));
prop.putHTML("crawler.clientTimeout",sb.getConfig("crawler.clientTimeout", "10000"));
prop.putHTML("crawler.http.maxFileSize",sb.getConfig("crawler.http.maxFileSize", "-1"));
prop.putHTML("crawler.ftp.maxFileSize",sb.getConfig("crawler.ftp.maxFileSize", "-1"));
prop.putHTML("crawler.smb.maxFileSize",sb.getConfig("crawler.smb.maxFileSize", "-1"));
prop.putHTML("crawler.file.maxFileSize",sb.getConfig("crawler.file.maxFileSize", "-1"));
prop.put("server.https", sb.getConfigBool("server.https", false));
prop.put("server.https_port.ssl", sb.getConfig(SwitchboardConstants.SERVER_SSLPORT,"8443"));
prop.put("port.shutdown", sb.getConfig(SwitchboardConstants.SERVER_SHUTDOWNPORT, "-1"));
final String metaPolicy = env.getConfig(SwitchboardConstants.REFERRER_META_POLICY, 
		SwitchboardConstants.REFERRER_META_POLICY_DEFAULT);
prop.put("metaPolicyNoReferrerChecked", ReferrerPolicy.NO_REFERRER.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicySameOriginChecked", ReferrerPolicy.SAME_ORIGIN.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyStrictOriginChecked", ReferrerPolicy.STRICT_ORIGIN.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyOriginChecked", ReferrerPolicy.ORIGIN.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyStrictOriginWhenCrossOriginChecked", ReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyOriginWhenCrossOriginChecked", ReferrerPolicy.ORIGIN_WHEN_CROSS_ORIGIN.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyNoReferrerWhenDowngradeChecked", ReferrerPolicy.NO_REFERRER_WHEN_DOWNGRADE.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyEmptyChecked", ReferrerPolicy.EMPTY.getValue().equals(metaPolicy) ? 1 : 0);
prop.put("metaPolicyUnsafeUrlChecked", ReferrerPolicy.UNSAFE_URL.getValue().equals(metaPolicy) ? 1 : 0);
        if(ReferrerPolicy.contains(metaPolicy)) {
	prop.put("metaPolicyCustom", 0);
} else {
	prop.put("metaPolicyCustom", 1);
	prop.put("metaPolicyCustom_checked", 1);
	prop.put("metaPolicyCustom_value", metaPolicy);
}
prop.put("searchResultNoReferrerChecked", env.getConfigBool(SwitchboardConstants.SEARCH_RESULT_NOREFERRER, 
		SwitchboardConstants.SEARCH_RESULT_NOREFERRER_DEFAULT) ? 1 : 0);
prop.put("solrBinaryResponseChecked", env.getConfigBool(SwitchboardConstants.REMOTE_SOLR_BINARY_RESPONSE_ENABLED, 
		SwitchboardConstants.REMOTE_SOLR_BINARY_RESPONSE_ENABLED_DEFAULT) ? 1 : 0);
/* For easier user understanding, the following flags controlling data sources selection 
* are rendered in the UI as checkboxes corresponding to enabled value when ticked */
prop.put("searchLocalDHTChecked", !env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_LOCAL_DHT_OFF, false) ? 1 : 0);
prop.put("searchLocalSolrChecked", !env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_LOCAL_SOLR_OFF, false) ? 1 : 0);
prop.put("searchRemoteDHTChecked", !env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_REMOTE_DHT_OFF, false) ? 1 : 0);
prop.put("searchRemoteSolrChecked", !env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_REMOTE_SOLR_OFF, false) ? 1 : 0);
prop.put("searchTestLocalDHTChecked", env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_REMOTE_DHT_TESTLOCAL, false) ? 1 : 0);
prop.put("searchTestLocalSolrChecked", env.getConfigBool(SwitchboardConstants.DEBUG_SEARCH_REMOTE_SOLR_TESTLOCAL, false) ? 1 : 0);
prop.put("searchShowRankingChecked", env.getConfigBool(SwitchboardConstants.SEARCH_RESULT_SHOW_RANKING, SwitchboardConstants.SEARCH_RESULT_SHOW_RANKING_DEFAULT) ? 1 : 0);
return prop;
}
}
