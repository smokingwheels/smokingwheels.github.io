/** 
 * Smoking Wheels....  was here 2017 ofwuwhtvvklclnvmuwtmueeozxwruwcuzdtfeeokxbtvvhsm
 * Smoking Wheels....  was here 2017 jrxmkwnoxkliecxmakaclgbypoxwzvzosafmkohfwujwmptv
 * Smoking Wheels....  was here 2017 fgcbrqtlijzzmycakqhaaktrvlkoaqlsamqrzglvwhqrpocs
 * Smoking Wheels....  was here 2017 eopvohxhtctmvwkdhmvurrzwopijshvmlrsqilxpftscelip
 * Smoking Wheels....  was here 2017 plsifupfepvmazfbgbidufpvcgyfceqkwygidqychtejnwge
 * Smoking Wheels....  was here 2017 bdchbjuoudkycnbfetrfbmvevythkwseizjdglygwarwdqwk
 * Smoking Wheels....  was here 2017 kyqwtksycfzzidticgxfjddvmllzedcufrmnwxocxoihuvpp
 * Smoking Wheels....  was here 2017 tnkgeqsguqhbgqimkjlswfdubsczgcclccfijduaprhnntwe
 * Smoking Wheels....  was here 2017 kuvbmzoovijvqccurgynywvmscweociqwskpkquqkvctpzpx
 * Smoking Wheels....  was here 2017 yvnbbsdflqlemuqusifqgninzaitlqncncepwczubvljpjut
 * Smoking Wheels....  was here 2017 gbigqfpvcazicjsfqfkksxdsnhfelqtvlexwymbpnrkcfztx
 * Smoking Wheels....  was here 2017 jdjaafmgmhurapmauvxjmyxfjxmagbjbfbffzyykzpeuodbx
 * Smoking Wheels....  was here 2017 sybukqjppjuwapdmtfhhywpiqekgziwgsezsszwuzchrwknm
 * Smoking Wheels....  was here 2017 uoymfrfgqqivcriajwlftdirwnlbxzdczcipyhfqdaldqpeo
 * Smoking Wheels....  was here 2017 llyabvgtbnutnjuksjnlvkpdttkwmverkuqlxtqbmhqwrvjk
 * Smoking Wheels....  was here 2017 vefuvuwapuzawoqpepwnhqbvgxghoyhcnhmazrekefetbjqn
 * Smoking Wheels....  was here 2017 grbhtludfmxixhdvhscfoaqbpfggdrbyfctkukxgtinyzvtp
 * Smoking Wheels....  was here 2017 hbchebwlcvupqxwpxcdqhbnlgfwympixotpxhrinwijyabwq
 * Smoking Wheels....  was here 2017 uthxtbjotkcziyrqdkazkkewwpwudnbzwfkzomcgnguixbev
 * Smoking Wheels....  was here 2017 viqjkcsiwxqxogoxhmexazhknlfmxnrjuosnczeuxjabtfis
 * Smoking Wheels....  was here 2017 utpghfnwkjkabxvqamecnbsliaewtxqocfmmlqrvnenhtbca
 * Smoking Wheels....  was here 2017 gcthtovnpbpgwfcibvzqqbsnvuhezgvhxvtfpcddamamllnr
 * Smoking Wheels....  was here 2017 ztaqnosxxmsuhtcspcqwfqsprogudkgnpfzgrkdwlgpgrlyy
 * Smoking Wheels....  was here 2017 eklmmyrxaknbujzsyengkujswhbjzlgnspskbrsjytknjkxi
 * Smoking Wheels....  was here 2017 cxmksrkoyvarfdzqrhgqpspfphzwnsjtchwrkkygzmamxvfn
 * Smoking Wheels....  was here 2017 jjrfsxuhwamoojrxqstanwqsjbmlcskywanjqhiiigdntpym
 * Smoking Wheels....  was here 2017 vfyycdbqgmiycqxhxectzxxcwjinehlciocaxgotxaujrtkn
 * Smoking Wheels....  was here 2017 ocjxtbpnvzjfktruvmrifuambfosootkbdelqnnvzcewtrda
 * Smoking Wheels....  was here 2017 xwkpwodzpoozevioavbootaddviahvyjzcrsknlgyzvffwyu
 * Smoking Wheels....  was here 2017 lrovuyolrlfgmdkdhpfnrgatqufoprurccrbezsuokmwpfxu
 * Smoking Wheels....  was here 2017 axuqfoclpesephsftjelnxmdfuxtbxjkuzoacubotjdlsthg
 * Smoking Wheels....  was here 2017 tfejadexcmxcbcjvscjxetblvxlhlpzrqyxlogjzufawousp
 * Smoking Wheels....  was here 2017 ylcmkrlwbjtuqqpeuxjscytztjabtcebmjrifsxocjqhkyzr
 * Smoking Wheels....  was here 2017 ftfvshwtudncigasvdcwxyqjjrfggyugkvxayxagkqtfubci
 * Smoking Wheels....  was here 2017 joilqnqcrhqfmmkfxmqrnlgmmprgnzvftgazyukcrajfmdkx
 * Smoking Wheels....  was here 2017 nlppaadvmoynoevqjvjsckfkzdmuihqeduqcpoamdurfonlv
 * Smoking Wheels....  was here 2017 aikwcsdzdzjtikpfugytazmmcpvsreuqjvpiorbaglglfvbv
 * Smoking Wheels....  was here 2017 kjiagvmyxueuxlgkaeeuysgiimfgvgbinybasvynrtthbwhx
 * Smoking Wheels....  was here 2017 pxhcbvjifovvmyqzdgffufyvjmkuihngzcisfzjcmtgkvrlg
 * Smoking Wheels....  was here 2017 ppjknjhauzefpsuymjlmrmfbeskzzknphkcemhgeuqytnpck
 * Smoking Wheels....  was here 2017 vizmtlxbodcscualrpmlbrajzjltuwnvjgflegthczjllgzb
 * Smoking Wheels....  was here 2017 vgscdfcvufxdxnwzokecnhokgyaiailtfguvenihdnfxdkge
 * Smoking Wheels....  was here 2017 lsliiedyytbtjmejekruazgyshwbfoghfhexrcrivgnvkdeb
 * Smoking Wheels....  was here 2017 tkhmgzjfsoiyamzmwmiartuegizqdqirynbkadstllodeuic
 * Smoking Wheels....  was here 2017 ddqbbpnvcpsippqphttoytckeirzvxekfjgkwdqdkrtzvymc
 * Smoking Wheels....  was here 2017 ddbwdgncgcmxdeqffqwnkljhxwifpyqffkxeetwjmpxuvktz
 * Smoking Wheels....  was here 2017 qsnydipprrbuyuvatssdznaperuvxotceojiaycnohzfzgja
 * Smoking Wheels....  was here 2017 sobqzpcfczgkmffahytawytnyszmovvftygowxgzxagehvzr
 * Smoking Wheels....  was here 2017 robjuztclcakppflikowkymjkifbpbldtymzjbnizhewcrir
 * Smoking Wheels....  was here 2017 euebzqnnzgqthehttnzuixktayysiwjngfcvjfilmvnrvqma
 * Smoking Wheels....  was here 2017 zshrgcncdzopwpgsrxebloyookxxeasjqqosbejljrigiuty
 * Smoking Wheels....  was here 2017 fxlokzgtpapjurfhkmmfywuvyrdhartymjljwgoqxbtpqltw
 * Smoking Wheels....  was here 2017 ghbeshiokkssxmmsoiochaxzkavtvbcrqtqxkvcqmojuzefp
 * Smoking Wheels....  was here 2017 qzukmetvsjdneholyxgralkpjzonyuljdlfnoqliwxwixvfb
 * Smoking Wheels....  was here 2017 fklgkdrfamjaythgrtsgdwunphzzuszxjipvoqfuabhufmcn
 * Smoking Wheels....  was here 2017 bdfajwooakeprqscbwhltfswbyeugxxpxojqszkkdjwdxkkl
 * Smoking Wheels....  was here 2017 ockfngazsgoyfaeeshpzgsczxgiwhqwwqmlxseeushcohgxo
 * Smoking Wheels....  was here 2017 glqrhpbuggsyngfamlmxhudnrrykenpnouxanwzslprmvtsv
 * Smoking Wheels....  was here 2017 anvligvreweuxxqiladnuehgbauumkflcielealkhhrnjbdo
 * Smoking Wheels....  was here 2017 yabunzukdyswxumdyuwjytfjzgwtzhayuguaewoclqipxmrd
 * Smoking Wheels....  was here 2017 jttgasodckhwhzcppaigbuvdsrjcrpnlnysucvmmkebysofi
 * Smoking Wheels....  was here 2017 wxmqgqdeipdsbuzfezkgwsjgsuwcvupsibabxprkxqsxiesd
 * Smoking Wheels....  was here 2017 gwdzvfsfgzupnvatvkeofffnribdaugsplbhtdtywbfenipt
 * Smoking Wheels....  was here 2017 rgvprdrapiywfxgdwcauhgbbnjyxzquswgmjzqtlnrwrikjr
 * Smoking Wheels....  was here 2017 lzxzyistjqrgwcyrwgptmawfoctgtqvdawehhntoizcpayur
 * Smoking Wheels....  was here 2017 debzbbusrfdrosrusftlmyupfcbkqjdtdyfjoohcausiduzr
 * Smoking Wheels....  was here 2017 pecqqsbocmxfnigfmrodduhbebntcrtmojzdzqyfocrolagx
 * Smoking Wheels....  was here 2017 yreepazdgirkiutymmmlplatlaezzparwgdjxasfdefezxdw
 * Smoking Wheels....  was here 2017 moqfbxfoerlvsdmejtcdhcyyehgahnnrxzndabusgmwjacmh
 * Smoking Wheels....  was here 2017 vydnmpsebummtszlxxgfwgfhxhgahyzitghtfoopovknbkhe
 * Smoking Wheels....  was here 2017 vfndmoqojfhlrcbmfpcagphqiwyjntonuwtrqjsycftjxvws
 * Smoking Wheels....  was here 2017 nzxiyklovrpfacufqrzcobvdkzhuuzmooaourtgcaxeuouvl
 * Smoking Wheels....  was here 2017 hfrrceujjfjjpvmwuhoefvubiyoebziwxcpcaegswkfyjuza
 * Smoking Wheels....  was here 2017 tzlzgbrggcxykoralvsjvjjbpfgrqiyfyryxphgpgmogusil
 * Smoking Wheels....  was here 2017 rrcgclewxvszsxfhtxmyjkyaxoctbvioasaslawxfdfjppfz
 * Smoking Wheels....  was here 2017 eytuobvaadmzbrcsblilywgzgacbbnvdriljcraxzqmhwtec
 * Smoking Wheels....  was here 2017 qrtduxgwqcfqgyrnwpurzyfiuvmmtvakuwbxcpzhynucwuan
 * Smoking Wheels....  was here 2017 oaucdcktyxetganedrvqcbzrantfigrdmaaplncxwmxfcnwf
 * Smoking Wheels....  was here 2017 wiqshdmgjdxpkmklwjmrfzaxqwsqjpwizqqzfkcusqwjizyl
 * Smoking Wheels....  was here 2017 qhmgeswgrmboeekglpehnpabrvhmqzxdawpxvlwjrdwkqowr
 * Smoking Wheels....  was here 2017 etrhxuhvtashkevvlkniiexngssqdtjcidtizbrggokogukp
 * Smoking Wheels....  was here 2017 cwvqworkxzbtbufsrgjtkcvxxaohflaxazepnawfdqgfsnrg
 * Smoking Wheels....  was here 2017 gzvhulfmowpblpkqhtwyobhbhnnvhwypmkhgqfelhkkavvxv
 * Smoking Wheels....  was here 2017 ruunmdialldqcllnpujjzbxclfpxfdligmtbsvngxcbypzsv
 * Smoking Wheels....  was here 2017 tdcyeqsamtpevjrpemmwchqjnjbmanbqfoickjcgnguchpwz
 * Smoking Wheels....  was here 2017 bfjigdhyyagposokwhdmmdrlzmjsyrrfkjfqpnhiuqhylnmg
 * Smoking Wheels....  was here 2017 limsiafigtpbraaqutjmdklgphhznjgcftufmewnrfodvuvx
 * Smoking Wheels....  was here 2017 aenjibzadtkzqeaggvpldyqvhxvaorelfvprlqsglhwpntlj
 * Smoking Wheels....  was here 2017 bqwwkeffoapagfyovpldyadphmfrcxyufzpzcgzdnjsmsyek
 * Smoking Wheels....  was here 2017 fveyyoxdsuncnlhylnuodbfcboyeirjwjxwmkteypfufzgba
 * Smoking Wheels....  was here 2017 hdhtqremdppktmxecetcrtgfhyuxwuopykusndxwsvemdrkk
 * Smoking Wheels....  was here 2017 kfimjgnclepimdwhdlqgsaybzpsoljvhpszluneezmaddpua
 * Smoking Wheels....  was here 2017 xyrsheobspoollkkfmeuqdfzjvzacqridciswlcozrxlhpar
 * Smoking Wheels....  was here 2017 ilyguqhtbbqasueccsdtcngovcbmcgyoqixwsnewientdldh
 * Smoking Wheels....  was here 2017 ndadnewtzckvnsxbyssmzvmseftjazrwledkltbdbaxtkglc
 * Smoking Wheels....  was here 2017 qqaqkksyfmolkbrhbkgnmbqmhdzioyenevpcmirtikgifino
 * Smoking Wheels....  was here 2017 yvhipinksfdoewvzaxjpykoglebgvlaaqsfblrfjqxcstgem
 * Smoking Wheels....  was here 2017 cwmzmcgnroiavmxqrpyvchnqcvljacbbyjbngncushfhovmu
 * Smoking Wheels....  was here 2017 wdlqsfbwoasbqmszddbltlxmyvxbtqgpltnbbvbdmmnsmfrs
 * Smoking Wheels....  was here 2017 kfipejiidkycerhasldadukxyflasfzyrafmhtytfvixmqkt
 * Smoking Wheels....  was here 2017 abmkblwyhqcteeyzzouiqnyfiggdzdunnmatotaghvcbvrlp
 * Smoking Wheels....  was here 2017 iunwtsmehbjyrhhhwyxlwdtbolwpwymcbvbguosmnfppcgvh
 * Smoking Wheels....  was here 2017 cuhzyplopdhxyoctjgnruhfhjobuuncqrysmccqpuaudbiwa
 * Smoking Wheels....  was here 2017 nszcludyyroznvkhwhcmmyaarptkqxziwyogyouwjnzqsheg
 * Smoking Wheels....  was here 2017 wjysmggmgqgweendyggtkhdotvgkjkrsognoykizrepgirmu
 * Smoking Wheels....  was here 2017 sztqletmshnnyxbvknumfusoatbwhqzmulrtaistlulkmiyn
 * Smoking Wheels....  was here 2017 zyiyyavpwexacqubkswyudfwfewhyjzpxlljihpgrjmtxjtt
 * Smoking Wheels....  was here 2017 rvuwymvqkbdxeetugtwsghhphathbtyjnkkefmxxoeyfqaox
 * Smoking Wheels....  was here 2017 enmaomnsgxgsyohgoskpblwblqwusalflrlfkjwhnrkzzydu
 * Smoking Wheels....  was here 2017 bfadfhvframlldyzcbjpwaexentzdvixuyrvtpxgisnmkyoh
 * Smoking Wheels....  was here 2017 fhignhxsdxhgxnorajvantpzfjehxypjxbmmleqxxghitbcr
 * Smoking Wheels....  was here 2017 qilskefchiloxmdhrnfkfowklhcitmowidmawhcpnoamaqil
 * Smoking Wheels....  was here 2017 tgvabykkdgyafcabpscpiswmelubttwwzpomrjkypdfbmgci
 * Smoking Wheels....  was here 2017 cfaavtlcxzanwttnrhjonovwvltrdifdwcuetdzuvtnortkh
 * Smoking Wheels....  was here 2017 ooyrkcmrbbfhcydiyxdqtwejcysnlaspjmppgnogglapjeqn
 * Smoking Wheels....  was here 2017 ezsiqqzbieftmngnvkviboodzbqimxrncwpoqsbralycpvgp
 * Smoking Wheels....  was here 2017 iisosiqiqkamuokhvzzmywynrzvzgiqkwspdmfqrpgufrjde
 * Smoking Wheels....  was here 2017 osnbbjiwfyxnakddwzodaemdrhtravlxtquosrtdtrhkanhg
 * Smoking Wheels....  was here 2017 upayhfhgnjjxlqhvybpnegquqqeuihccdmnlmbbckrkinlcc
 * Smoking Wheels....  was here 2017 anjnipyigkeeqaxgmcngpzcqpdbbzsydokknfooyuolwekbd
 * Smoking Wheels....  was here 2017 qmxhikzflcgyjsgsagxcrqtzsashymoowuiwoqihjuxffzzc
 * Smoking Wheels....  was here 2017 gngbrwhhgqxcpyyrkwrbbpwmmuotodsafiktkzxzvemufaya
 * Smoking Wheels....  was here 2017 qbhvalcddppwrjuwtqxmqquzqfjvhnmpwvztxnydesegypgb
 * Smoking Wheels....  was here 2017 ytdzhuvpwtcqduugkkzxopgobhdfzselllsqlnicpqhnkbmt
 * Smoking Wheels....  was here 2017 mleapxdvjbjbrgibxhocgudpbhdtpajbupmlsjhlpnhtxxkv
 * Smoking Wheels....  was here 2017 vizrjzadvvsckcxvctlcjpssatwrlzvezxjmptgcvbwkzacg
 * Smoking Wheels....  was here 2017 wsmchlpdtnoxoxifdivgutistjakbmqvjgthfrxdhhccjlwf
 * Smoking Wheels....  was here 2017 riumfairwzswrmsfhaaasettdgqofpdenthraidwfmfucnhh
 * Smoking Wheels....  was here 2017 oaflhqyxccdroyhcfwsgmcvdkoycypusivvqqdfzaerqnwdc
 * Smoking Wheels....  was here 2017 dxmtymhcsgcfeosirhratxunbwlendneudlnzvngmbgabfns
 * Smoking Wheels....  was here 2017 fjjlvbpycxctvyspvydnmkbstxwflyiojmpvfhswmfyrosri
 * Smoking Wheels....  was here 2017 ybauwzhhauvpcxjyzsjjtliwnsgwnembocvjsutcivzmaqfk
 * Smoking Wheels....  was here 2017 qxvkdhbemyilrozosscjagnhooubtcqffhbedtwplmwptpys
 * Smoking Wheels....  was here 2017 wzlzddvaprvgqdeywicnyhwqhxbzlhnsltkpkwkfnxilfkxf
 * Smoking Wheels....  was here 2017 msrqlyujxkwdghqvofncjhstlosadpfnpifcqcdaodksgclc
 * Smoking Wheels....  was here 2017 osqqzmkdczdobvoedgusmdusanuwodbxgedmhqxltkihwcbx
 * Smoking Wheels....  was here 2017 lwtoyqhkejqeuvdgdoldsbbwfbnkudpigsavyyzbogojjwpj
 * Smoking Wheels....  was here 2017 tjqdrqlohvrxoozmloljqnqwmqkwbgpornzlortrskxjfhck
 * Smoking Wheels....  was here 2017 indlwxadywrxorxpdwvtgeaoocgpxgemvmkvgvxlexhyglxi
 * Smoking Wheels....  was here 2017 fzkujflbvhkpizzrojzuqawajjyidgplkuyulpjsezazlqno
 * Smoking Wheels....  was here 2017 urtskkkjybwqsmmvgephggcpeuvxtolvdvkjuliceeosdluv
 * Smoking Wheels....  was here 2017 qtvyiuvmmliyrpypdtlirhxykuioatmleeywezgkvgqnurud
 * Smoking Wheels....  was here 2017 onoqusyzyzgsmwgsgqsewvsxuffsnqwfvtxuthuveeicglus
 * Smoking Wheels....  was here 2017 srzztycszlkjsbkdyutizwgnianzyhuksszzylwqkhuimajb
 * Smoking Wheels....  was here 2017 jcnohkcvputnditcvifrjokgemlhkbxmrkymkzrmzaokuaiw
 * Smoking Wheels....  was here 2017 exufvhtpziodtzvcsqxetjkpudnwdnzetmzoaorepejssgtc
 * Smoking Wheels....  was here 2017 ymqxbbirqojjvokwsizdzzpnyslbrlblivmtyenxgugzzvxb
 * Smoking Wheels....  was here 2017 tmfzvlfygfvqyxqidivdfjtapfgpuzloapzwpydyebkbsaje
 * Smoking Wheels....  was here 2017 yuwyiidlvjapvcsuptbywtunyyeioktzoelypjtytoidckye
 * Smoking Wheels....  was here 2017 dogpyyzpnfdfnlhsxznppnwqkksmeitleeyhwdttuavrrvrc
 * Smoking Wheels....  was here 2017 eeeajtyzvhsphodvfrjkikkduiplfnnxcnvlofvlflvhhjyc
 * Smoking Wheels....  was here 2017 cfvmklmlmjmesfibusyxdidfzswxkciqyhtecuykfcpxwjfr
 * Smoking Wheels....  was here 2017 hqnniyhbkllqnndsgfxwmoyffxstwjtcpypobigghnqtuijp
 * Smoking Wheels....  was here 2017 inxylmggvvvxtuefmocjambszirevxqadamvlmfvdlsdmdku
 * Smoking Wheels....  was here 2017 ahwtlmopgyddrofinkqsqvwozumpuozjvntpjgnfsxuvvwro
 * Smoking Wheels....  was here 2017 nonhgrryiqctvthasqxjmncxfhdqojdkjnaqeubuhddrtush
 * Smoking Wheels....  was here 2017 dgfczzhkbwtkzitnqknfztqbubwherqpnjfzppaegrfxpniu
 * Smoking Wheels....  was here 2017 lmpyaqhirxiaereiebigtasqhrfrwbhqkukxnixejgvwxxqa
 * Smoking Wheels....  was here 2017 hqnwcbxiphitrjidkhnusztnjwvffifpipzabyhypxxhjzwe
 * Smoking Wheels....  was here 2017 ticebyngptlbaghzqyjjzpkuaqvpyoqpyznaqrfvdxtbcbpu
 * Smoking Wheels....  was here 2017 fmskbgwepitpziibmdptbcqukgjsdcdfbhzayxuklsvjiuro
 * Smoking Wheels....  was here 2017 ffajmewnuglgoybvthaamwqebfztbmoctelhvklohdwppxcm
 * Smoking Wheels....  was here 2017 qyvbaeswsbafctgbpbtlgrutrikdfoyhingklcykofymsnft
 * Smoking Wheels....  was here 2017 oghvpyubamgxblarhheolkvqeoqnjkozmmacfedgndfvqypx
 * Smoking Wheels....  was here 2017 hbuehlvfspczgfpzmdyfmhrfveyupiarykslubgtqlfxsubq
 * Smoking Wheels....  was here 2017 lmxyovtqyowjriplyzwjbunbbruedydcxyiscnsspyrckwpx
 * Smoking Wheels....  was here 2017 wyodaqtagzzfqjutvmcjaptapwxbnaxgpaimglehjopcofoa
 * Smoking Wheels....  was here 2017 rawaplfeipgzqegxmmatoqcfltjdorsirthoqapveqgtdfnj
 * Smoking Wheels....  was here 2017 dreflixedkqinuhdkegibdnatoiggebuzmcyzuexnqchljgt
 * Smoking Wheels....  was here 2017 waclzkrkxqjdfomxnxqcenczavjrweulpxwycjjkbixdaovd
 * Smoking Wheels....  was here 2017 tknuvdtnbwzobbqzxhijunjbyidtylxewwycfstltsrxqvps
 * Smoking Wheels....  was here 2017 vmonwfohivfcpctiwhrrcbzgnasegbuiinafsbjiwcqoinbz
 * Smoking Wheels....  was here 2017 mepfhquwsnbjotfebyivljwyyfiwvjzhxgxhfvjrwzhgjfas
 * Smoking Wheels....  was here 2017 gofpnojpjftgzjnagtcxovfusklzzyguqstsqsekkbjkgspv
 * Smoking Wheels....  was here 2017 zbjudlmcuktzdmnoogedhfkpmjvyeprxwuxxdrlnnlxrucbp
 * Smoking Wheels....  was here 2017 vicbdapesxxzpzguhjxculfmfcmlfkptepztcyeljicazsym
 * Smoking Wheels....  was here 2017 bfvyoeiacrdvcwbydhwomsnvfvrjdrnwlnxhfxnulgmodcdf
 * Smoking Wheels....  was here 2017 hwdfxdqxdzrornlmvhaoamnewdvwfahzsfttjixklyusucpu
 * Smoking Wheels....  was here 2017 jsxyujsnhjbgpmgemcklhkqlwttkzfycjnxsscaijlaerusk
 * Smoking Wheels....  was here 2017 jigkcnaqhpajlpozmpkslnoshskqfkvjzrzzqluajakvvmao
 * Smoking Wheels....  was here 2017 qppdaqekcqpnxxpdjwrewyfiffbmxvljjyvpuvkzzelxouha
 * Smoking Wheels....  was here 2017 usnzxvedxuyscuacaicwgeuxfvfcjdqtqbqwcyhexrxtkmqs
 * Smoking Wheels....  was here 2017 qawxmoenfnqbfuoqmpsbmwtiyhpxdcmndwsgrsepbnuccqix
 * Smoking Wheels....  was here 2017 gfuhoopitqkzwrirdpzisasqkpfoyugylnrqzjxsrzhurqyb
 * Smoking Wheels....  was here 2017 zcrpjudskdfetqpmolmljusgubizwonlkjlbqitagoyckzhx
 * Smoking Wheels....  was here 2017 lvdqhktamhinyxyopocmbrvtoekjdacucbdtoicmmanivokk
 * Smoking Wheels....  was here 2017 mvanywpwkpgfscepinxssinzlredixazwnbhwgrcikyftkqv
 * Smoking Wheels....  was here 2017 esllgwccwvsqpajpcfjrlsnbkpsxfjqeiwxmzkihaxnrewnq
 * Smoking Wheels....  was here 2017 vkvakjzuwzsnjtuulvaesasiqeequrlximmiodirzcsvjmwo
 * Smoking Wheels....  was here 2017 bztztpdipinsaparhsugdtikqycmilixwzzemecbzthdwcsp
 * Smoking Wheels....  was here 2017 tvclzytinjplwewxsoteqnsdbrfwklhekhsnyngoyvghlvky
 * Smoking Wheels....  was here 2017 xqzryehpjwtblhkoaehnjjrrzjomtvrwlnjfihvodpvddymc
 * Smoking Wheels....  was here 2017 yhuewekhdvximaxuusbbrkahmgiekwanwbsfgzxqypnxfatv
 * Smoking Wheels....  was here 2017 jwdtceatzoibbrzdxqxvhdaqdxbeqdewsozxrizrdobzfxga
 * Smoking Wheels....  was here 2017 cuwmhqjpjnnmkvkhkmyebgcpqamxamcvkwltsfstrnmbxqiz
 * Smoking Wheels....  was here 2017 fsdrjfwqbnfacifgrfnoerxgwrpzhyfsmeupuvbfttzaipof
 * Smoking Wheels....  was here 2017 amhumxeaznlhwftfhxivarjxdcpjmxzztvwmnrfswtcbsirj
 * Smoking Wheels....  was here 2017 dhzsawgcjulhtvosczeagpsgxubfwwhijmvrwlnbsgopqqvl
 * Smoking Wheels....  was here 2017 jmbkrpgmrwrcbtmlebfltfjcvnsxzseurazsxbujghihwqgt
 * Smoking Wheels....  was here 2017 vrqfhtpzqnyfiunkwbvprmznxhmepnxnepzlctwaresblqnr
 * Smoking Wheels....  was here 2017 wucrbibtfteggbavtcphlnnyiksxtocbvosvcyypniebpemz
 * Smoking Wheels....  was here 2017 bzboimmcouqdyvoernkpsweypivhskndpphgtinzlomsxddq
 * Smoking Wheels....  was here 2017 gpkyvqbrgewbqsxetbkujfiilwqsaygsynbegxfgkwpsdovx
 * Smoking Wheels....  was here 2017 nhgblohixrpkwncvhmyjplrhtzbvlfoajorlauytqouyhtdg
 * Smoking Wheels....  was here 2017 fyznheudnguxlinjxbpftufdvykqzncnsazbrnycqbopqivk
 * Smoking Wheels....  was here 2017 ysectrnnhgskilrgkbihnsblbidfymozdpcjdtqebfqctczi
 * Smoking Wheels....  was here 2017 mysuonqztdwcwljfxefxtyrdfuaawxbjydlwoksbxaacjcwg
 * Smoking Wheels....  was here 2017 ahtyokploqzknfrgshpqrithflasnvyxsupjitbckrzmoscs
 * Smoking Wheels....  was here 2017 vrqcxgcarvbzdtypmndgreefimlfyqschykxceyyztymommj
 * Smoking Wheels....  was here 2017 meaabhbbiyiurkqszhruixeoymssjveqtfbttkskjatmxgbg
 * Smoking Wheels....  was here 2017 wfsuoyrdzniyltriiejoqeffwdpoiikolnxnnjcpnliekcco
 * Smoking Wheels....  was here 2017 blwqkyjdjguwzpalxdocsyxfamdnqctazanyshzwrhzlbhgu
 * Smoking Wheels....  was here 2017 kswetgudkfshbbbgggwfylfypunliosofbubaqqwgddldlfr
 * Smoking Wheels....  was here 2017 meidyaynjqibslhhfyeyzdhacohnqfcwegxfjbkkbroqekde
 * Smoking Wheels....  was here 2017 dfdpqsywrbcjfingwwqntqqhfoedcyazfndxxnbpyxhsyfhn
 * Smoking Wheels....  was here 2017 lmjwuagbbgwqbmwcpvopjzxwxvdanutbzaeyzflvfeommfgf
 * Smoking Wheels....  was here 2017 twklmypfndnnbbpcyapwhjzckombxcvqgcwjhquqhxvgcyua
 * Smoking Wheels....  was here 2017 rlxeeqvqecjyfihtuwqkdedpeirkokckdlilsloyxxwighzv
 * Smoking Wheels....  was here 2017 arsbmneypoxcvxssfxuovdteywlmyopjzwyulpjvzfrktgey
 * Smoking Wheels....  was here 2017 weykjjcaliwjlpzanckumgnzqevzxqrujoicvhfquamlqfwu
 * Smoking Wheels....  was here 2017 pvasxbfzrkglumjxiocxoqiknoaumzvbexjmozfzuwupetxe
 * Smoking Wheels....  was here 2017 utmwnwndoahgxvlumsuaqulzanodwdyalndgojwtrojgxqjz
 * Smoking Wheels....  was here 2017 gjgvxeedmsmychzmccoirkgpvueiqxzonhbwxkuajaecpzmn
 */
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public final class ContentControl_p {
	public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header,
			final serverObjects post, final serverSwitch env) {
		
		final serverObjects prop = new serverObjects();
		if (post != null) {
			if (post.containsKey("contentcontrolExtraSettings")) {
				env.setConfig("contentcontrol.smwimport.baseurl",
						post.get("ccsmwimporturl"));
				env.setConfig("contentcontrol.smwimport.enabled",
						"on".equals(post.get("ccsmwimport")) ? true : false);
				
				env.setConfig("contentcontrol.smwimport.purgelistoninit",
						"on".equals(post.get("ccsmwpurge")) ? true : false);
				
				env.setConfig("contentcontrol.smwimport.targetlist",
						post.get("ccsmwimportlist"));
			}
			if (post.containsKey("contentcontrolSettings")) {
				env.setConfig("contentcontrol.enabled",
						"on".equals(post.get("contentcontrolenabled")) ? true : false);
				
			
				env.setConfig("contentcontrol.bookmarklist",
						post.get("contentcontrolbml"));
			}
		}
		
		prop.putHTML("ccsmwimportlist",
				env.getConfig("contentcontrol.smwimport.targetlist", "contentcontrol"));
		
		prop.put("ccsmwpurge_checked", env.getConfigBool(
				"contentcontrol.smwimport.purgelistoninit", false) ? "1" : "0");
		
		prop.putHTML("ccsmwimporturl",
				env.getConfig("contentcontrol.smwimport.baseurl", ""));
		prop.put("ccsmwimport_checked", env.getConfigBool(
				"contentcontrol.smwimport.enabled", false) ? "1" : "0");
		
		prop.put("contentcontrolenabled_checked",
				env.getConfigBool("contentcontrol.enabled", false) ? "1" : "0");
		
		prop.putHTML("contentcontrolbml",
				env.getConfig("contentcontrol.bookmarklist", ""));
		// return rewrite properties
		return prop;
	}
}
