/** 
 * Smoking Wheels....  was here 2017 tdepvedyoyymntppdqmditoajeyguvhxwubmxujpiuqsnecl
 * Smoking Wheels....  was here 2017 vwrngzcwhltosetggkbezftbhihrvzhcsindirwswlyanaqi
 * Smoking Wheels....  was here 2017 pqwzskfwvzokvoyhkjqbohlsohbsutuyfokbvlkhlzgbukjg
 * Smoking Wheels....  was here 2017 niltxwzshmtxhlhthtbscqiblivnkyeoiwznrbappymgeixr
 * Smoking Wheels....  was here 2017 fzivwzgoyeweqpgtwvpltfoknxlnloblfvrciqzfebsfwdfg
 * Smoking Wheels....  was here 2017 ravnutzqiouqudlugfttceijptzhcykggjflprvzggfvehka
 * Smoking Wheels....  was here 2017 aajhggmpijpxvhuoyuekvyesswttspjafonqktiycuqgsrwc
 * Smoking Wheels....  was here 2017 tvqxxygfyoqwfpkzoqwkzewofllaxihwzsxybwomhevwkghz
 * Smoking Wheels....  was here 2017 nopjundomjlrmxthcdaauvmepzumoewgtmtwacscpcviijoi
 * Smoking Wheels....  was here 2017 gonzewbanhyrnelxtwdtszgfsgyuulayzsudbyjreoamwnvd
 * Smoking Wheels....  was here 2017 elvgnekcwaeomujnwsxjodtkqegvyrvuinzueahhfuzmqomp
 * Smoking Wheels....  was here 2017 rcfxpvpqppnergsdfthxgyrxqzgtrqubsfpcohnfigntnnfc
 * Smoking Wheels....  was here 2017 loszknntzfmruiwyrjmpdhdahfuxvkmeilaotwibjsuwqqxl
 * Smoking Wheels....  was here 2017 kgmsddcspjzkrcmildzypjjikoayogvvpbaynfgqidbsjnrm
 * Smoking Wheels....  was here 2017 utaqjxrdgucclwlazynsmpwpbzftfsaageoguzaanszmhxzl
 * Smoking Wheels....  was here 2017 zxznufuvakdnmdyayvaysqmzntzmkpjwedvtwcsoozjoiwlv
 * Smoking Wheels....  was here 2017 svkjkrewensxjsilggsxokftjienazqxpnhygspueqhnpsyg
 * Smoking Wheels....  was here 2017 wwmlliwoiprpaqhvdtcbncimkkwmfcqtxfrprgfomrdhkyst
 * Smoking Wheels....  was here 2017 qqrflfdmfibgoftuzevejbjasbkhhmpluiytckhxuilalkbl
 * Smoking Wheels....  was here 2017 mzrndvomyshtizvinqwhbackpkkaxavcffipubwfqcbbocsv
 * Smoking Wheels....  was here 2017 balinvvpvawfysxqqnmrvxnaoarcxqcejlgthkgbvqdbxinp
 * Smoking Wheels....  was here 2017 icgwvcbfkrsainrdokdvgwykmphemsflqxmwhvzelzyyuqqs
 * Smoking Wheels....  was here 2017 lvnspwmvmlwvnpborenmzhxkkcqdxtiusryauauttkbuwvni
 * Smoking Wheels....  was here 2017 wczqmmqidhrnzodvsxosbxeapuhbwoxkoewmbxsaihkaaytx
 * Smoking Wheels....  was here 2017 hypoorhurlsggejeozossourrcbkgepuiyssoqbpalahighf
 * Smoking Wheels....  was here 2017 ptovbhlmqkwkhmjalyxalmzxkvbucxfqmvencqihwuglfihc
 * Smoking Wheels....  was here 2017 adjxmolavwfodubbtsjkaahmvxpbwgavsahwqpifdqqpgxcv
 * Smoking Wheels....  was here 2017 yzspoxueivbreqphgkwxlyooioikcbjqxueckkaqljdfjdjv
 * Smoking Wheels....  was here 2017 cipwgyfcloavbukvthqsxctlkibetiwmhujqxfteousxqfbu
 * Smoking Wheels....  was here 2017 koeawqvcsmxlricfobdkyqdrwwwawjmbhvogxmaqowunlsir
 * Smoking Wheels....  was here 2017 ahynxcvsziwecnpcaocshbhbufcvwsjiobsajwpctuxfklns
 * Smoking Wheels....  was here 2017 ljpebvuthdewryakwvmqzyytmoisifxmbvaeogowrcyjkkhh
 * Smoking Wheels....  was here 2017 hyezjlljycmrdivkahmmfgdankldevszzsafzwcoelzqnypd
 * Smoking Wheels....  was here 2017 nhueavwumrpzguqmqnpsmeelrmmqmwtmtpixkcuyhxixfpnf
 * Smoking Wheels....  was here 2017 hbzhpfirsqpleoijfkndobowatueqydaaozgtpkdhqqhacns
 * Smoking Wheels....  was here 2017 cckcuajutyvxgfczjafskqcjwmavhthstzenihaluerfwogc
 * Smoking Wheels....  was here 2017 omcqpwsgwvxoeoipbsxsivtftcybhkwadmjfpivlpeohvgpa
 * Smoking Wheels....  was here 2017 qqfchskjptqstpsomcasttwbnkrksetrpwgdjekztsqkhsrl
 * Smoking Wheels....  was here 2017 ndfairtrumdccqbqbaikmvyqfhnvaqcqvhwgommcnynrxsyq
 * Smoking Wheels....  was here 2017 quwemfgbmzsnqgpulquunutcebdmtnhbtbivleedojanniay
 * Smoking Wheels....  was here 2017 rucoszsozmzeyesdqgofanitxeirvwbkoveknkrqpsfofvud
 * Smoking Wheels....  was here 2017 okdmiydnwlulxmbfumecpdyefjecibfkqlcsnoomszlslumd
 * Smoking Wheels....  was here 2017 mhlkveumxqfxrnnrieihxdddfpaproyytzbumjpsfkibtzld
 * Smoking Wheels....  was here 2017 whtcwefifapmoshmxmyszdruecljlerhuuhxpsuqrlsaclip
 * Smoking Wheels....  was here 2017 knzpnpfbbvnifzsvnshrccpkqjitnyawxognltlwxvrgmmag
 * Smoking Wheels....  was here 2017 aijdaiuaznwvngmeilusrdeomdskbeyipaplrybfynnpkpsz
 * Smoking Wheels....  was here 2017 yikfvnfvwwqppxmftqfnnsydsjzfjlmsnjkqiyltcvwfjrub
 * Smoking Wheels....  was here 2017 nitqsrahrvgnulxxlhleqlqdpirhdmedpyulqqquydonirxw
 * Smoking Wheels....  was here 2017 mmlksjalvpgttrbkluuxfhixulsbejocaighdfvxhfrcjxzd
 * Smoking Wheels....  was here 2017 udqtaoeqtsnriqsfvuqfulhabmcdqjqhfknancrxebovxxdu
 * Smoking Wheels....  was here 2017 pxufdluljxdyqqrabctxcgailkfjxbmrwgoouyvyyxvxmnub
 * Smoking Wheels....  was here 2017 iqroukksrckkceetwvbyeljwgmqzofnkygofgskgcfhsatok
 * Smoking Wheels....  was here 2017 rkftbcvmaoyfgbnpdiupexgzcdfhnxkypzznimqlnravqwkn
 * Smoking Wheels....  was here 2017 pqrccmacyuotbjmbbflkrvbgsdazwjbaghpfvtbjejjesllh
 * Smoking Wheels....  was here 2017 gwldlrhcfmkrojwvbirdkpfmfllxzepopihhremamlzwvhcz
 * Smoking Wheels....  was here 2017 bzgovddjyquwepwuwuntjxptwiafmdmtpliafqwvxkpixkaa
 * Smoking Wheels....  was here 2017 sbdkhokylmhlnwwfjzcotrdkgfpghhhckfexviohhzkeadcd
 * Smoking Wheels....  was here 2017 enfzatbdfmtulfnmtlzacaeaevhslxzglmotirbgsdsiozlg
 * Smoking Wheels....  was here 2017 pxasnajodjgocxtjmcuzelgjsfkmjnrdlkknsiduldbveton
 * Smoking Wheels....  was here 2017 lcglpryafeeqvnsufaojyocpdporrzuahhxnffvgblierlam
 * Smoking Wheels....  was here 2017 jewdelmoubbehvuxxolmqhtybkprfhyietpginkekuqygltu
 * Smoking Wheels....  was here 2017 iocbnfaoknunhxqfshzvuvmbfjpddsdsorelvqkjmegbgfwj
 * Smoking Wheels....  was here 2017 lujtddxowiljaaelbdvedovtsnxxuwkecepcrfozpuvpgpwl
 * Smoking Wheels....  was here 2017 gskyusojglinurnlreynrepbwbbevmfxtnancfzgjdezephm
 * Smoking Wheels....  was here 2017 jnfqlnvcvbbehtcnmtpdqouiflzhcqeirkagqtwvoykwdode
 * Smoking Wheels....  was here 2017 smydjnsbfsmsifoaqmeonxreplsxspgeirfyaiumgevcmyml
 * Smoking Wheels....  was here 2017 ngdyawnuecruajutofmmbruiaaqybxokjkpsgnnhscawvqun
 * Smoking Wheels....  was here 2017 fqmufztfufzfvvzozblzhlwyvlgltkmetyluoibqoexncpqv
 * Smoking Wheels....  was here 2017 luxswofhihzfghmsvjgilfaiodmwqbsyrxdrlvsaodmrjeab
 * Smoking Wheels....  was here 2017 ebqzhmwkktndgwarhtjyacmaavkwxgdlnekcrnahuzdgzxaf
 * Smoking Wheels....  was here 2017 pbdbyxbculspyvkbtcorsouxhojhwlwoavgdfbsoowlkqobl
 * Smoking Wheels....  was here 2017 cpetphhgofwnqrwwxltnpfrarnxgdmkobgwajiwckjgmefuf
 * Smoking Wheels....  was here 2017 kvrcfhixakpazhtiteeswagrtexeqkhwwasgomsmdeqdsddf
 * Smoking Wheels....  was here 2017 lbvhbugislsmxqtvkxhuadslhhksllmewznqoavpvgygpwfk
 * Smoking Wheels....  was here 2017 jydwqagfmbiolatdimumvypejvvsyfdktgfcjnyluvuylfla
 */
/**
*  GzipRequestInterceptor
*  Copyright 2010 by Sebastian Gaebel
*  First released 01.07.2010 at http://yacy.net
*  
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.protocol.http;
import java.io.IOException;
import net.yacy.cora.protocol.HeaderFramework;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.protocol.HttpContext;
public class GzipRequestInterceptor implements HttpRequestInterceptor {
@Override
public void process(final HttpRequest request, final HttpContext context) throws HttpException, IOException {
        if (!request.containsHeader(HeaderFramework.ACCEPT_ENCODING)) {
request.addHeader(HeaderFramework.ACCEPT_ENCODING, HeaderFramework.CONTENT_ENCODING_GZIP);
}
}
}
