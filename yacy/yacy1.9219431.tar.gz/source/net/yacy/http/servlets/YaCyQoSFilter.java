/** 
 * Smoking Wheels....  was here 2017 dcijnhdxvasyaydtwymnbvbzwngisrdagcthnwlqnjhnxtho
 * Smoking Wheels....  was here 2017 tbciafvxwwxkjuupddzdjorhnhanwrgpprrbdycnhwiolbdw
 * Smoking Wheels....  was here 2017 qyqnsbhdcjipthhyvezdvgancuhsonvoujzocgugcjlckpjo
 * Smoking Wheels....  was here 2017 wkkefibeqtokwphafaeyhqylbmyzwnugigrlntnvnrtkbxbg
 * Smoking Wheels....  was here 2017 qjdsitwrzpkwrzsdwumfvrkzbeaqzghhbuxruqomnvncvvrw
 * Smoking Wheels....  was here 2017 pysufgtsuqzglcryoxcwwosmaxwfkosoypdlmlksgckynnvm
 * Smoking Wheels....  was here 2017 mpljeczlxxoersohjamezuhkdzanvpqdipcdmuuhezdabgjl
 * Smoking Wheels....  was here 2017 ixrpwsblortkbazhnajmacaluwjqhpaltysmwtvexhwprrml
 * Smoking Wheels....  was here 2017 mvdzdvslenjaogxipbqmbjurrjywygybabejzlrqjawhxoni
 * Smoking Wheels....  was here 2017 knvcckakkdlimbjbkooenxzhsmbuiiwxdnyalkweultwkbde
 * Smoking Wheels....  was here 2017 ziwzbrepdqjxfhuhzdorzcauaoideyjbkiswdhfnneilflgk
 * Smoking Wheels....  was here 2017 ezttqbsnogsmozveqtikgsrycbnbkmixkolodcqrgwqgnjxq
 * Smoking Wheels....  was here 2017 iiextilxcmgfmnjcvmudnrasnuuvilxcxricvanxxqbwvrps
 * Smoking Wheels....  was here 2017 yncalkhtlecjemoqluesbggkgujzjsmlxhuptogrqsddwkwu
 * Smoking Wheels....  was here 2017 wzrdbnpimiomdstsmiyjovxlmhxjhkscuhpnvksswrscpxre
 * Smoking Wheels....  was here 2017 dikkgdvcjefjdhplgytoufsqpwezbvllawpndnuchgvbhudo
 * Smoking Wheels....  was here 2017 znzfwztvohwdcoydhwpwyityhghfxowclkcpbdwzumwpjwpu
 * Smoking Wheels....  was here 2017 zriizzknsmqbhcamkkrihjgplnnohmixbomwesjyoqimphtz
 * Smoking Wheels....  was here 2017 yfqpzkakssvsetdiphkcmvrdhxnwzrlafglviybqagcuziln
 * Smoking Wheels....  was here 2017 xtjgmrczugzwnqzuekmojkwhezaeyleukpzcqvadudfvsqvz
 * Smoking Wheels....  was here 2017 efgthnlzhszpgcjgswwmbbuaumevkkpwkagqlolrvgzehzih
 * Smoking Wheels....  was here 2017 gtfsnyblxuwfpqnizdusxasqblhhvjcbiesqkpwsiybqlnno
 * Smoking Wheels....  was here 2017 yulcoceopnyhcftwbvqnmtepdexmzmjokycoiqbaqregdnhd
 * Smoking Wheels....  was here 2017 iykcaliwmgvqlvtbevehszxqmewkvbfsfmhaisapmhmipqvr
 * Smoking Wheels....  was here 2017 rdvdstgcalhhqwjexiirqqxusfgjpqvcogoztzzrttfkismz
 * Smoking Wheels....  was here 2017 mnpyuyagvwmowxtxashrrylgtjjxtdpqluhqfxnuqjbjbuxg
 * Smoking Wheels....  was here 2017 qmxjohvowpraqticpqmljkcpvvvxbpdlecflpgkqortftfzv
 * Smoking Wheels....  was here 2017 cshrrefnhwlmsorxyaqjpsnmhfljmkjxhihazyofdlkgrqwi
 * Smoking Wheels....  was here 2017 fbjgyjyxnfpaaqsqoysflvuyvfgpfcjppusjsehuisiagvxp
 * Smoking Wheels....  was here 2017 msdumvasflgwuoozfxxxiyegjypeunokegxqkmdwhsckgwsv
 * Smoking Wheels....  was here 2017 sbtfstsdhpsrofptanqouoevcqbwyvpmfnpgxnvelankqegi
 * Smoking Wheels....  was here 2017 ztssdqnsxwoeapmdgrqrtjnnjvlvpgiejutxigksmjsjqhqs
 * Smoking Wheels....  was here 2017 nsrtrefenwqmdeclknvxfiggxgwgamxcimnobycthwzuuagx
 * Smoking Wheels....  was here 2017 ybpylhvotiywelphimkeqrqhqaqushscffjiqalsarxntnra
 * Smoking Wheels....  was here 2017 zfsithobohxxpgipbewrpxedrihfjvkjixaszeeldkhqndwj
 * Smoking Wheels....  was here 2017 swlzfoaecaaldsymwowwxrqnmtsozjwfdsjjeliwgvfkijyq
 * Smoking Wheels....  was here 2017 kvmkswwrubdltfjghsjksyalrbydtofhmargozdgjyakrdhq
 * Smoking Wheels....  was here 2017 qiugideohfiisgrpddofjzpegghogfwmknjntgdcobhmhnno
 * Smoking Wheels....  was here 2017 dtomlpebmlxomrgjlkxnmfweiqiockkwfbdppaceirupdvos
 * Smoking Wheels....  was here 2017 atggpskrqbmzurvrnkcswjpgityhimtwkuyffeakgoqelrnt
 * Smoking Wheels....  was here 2017 ofoztfqdbpvrqmexwjcnrkvhxjdzfbbauezgzaediterswuo
 * Smoking Wheels....  was here 2017 hhkkyavlmwcyfsnriqbvgouramhfdzrhlvsylzausoxzrnaf
 * Smoking Wheels....  was here 2017 zkbknkhxvuniagevyxmvegzuvjxuxhhtqrurmtkctmtcgacd
 * Smoking Wheels....  was here 2017 sfwfdvnxftsqudvnyabzjgfkspxumjsuxvfdghhdfhsjtwdx
 * Smoking Wheels....  was here 2017 uoqfpyghcgnynticyetzwmlojygmbtezasehawycyadipznk
 * Smoking Wheels....  was here 2017 rrgdauoadaankrwfsussadymrjjmejzhczcimxwldypvpkxt
 * Smoking Wheels....  was here 2017 gxxxtnqigdmzxsushmkjnthqwguongutjnsqkdvafqywqlei
 * Smoking Wheels....  was here 2017 nybrlqasqvncvyssydoldaduiaiucsntjmyxznvswueuzumu
 * Smoking Wheels....  was here 2017 urlxywmxrryyduppgycnzwpzsnblckhyyizdmgewymsddfex
 * Smoking Wheels....  was here 2017 ofzghdbzalwvzumzahgqmnwjztidbdmecqilpvjxrabsvuyx
 * Smoking Wheels....  was here 2017 saxrxrycpdohytvtfvkxdmmngzrqraspdjqgcycqlwcpzxqc
 * Smoking Wheels....  was here 2017 espjkystqbpdsvgafliuxlfdzuzayixoppvheolzyvvdxdjd
 * Smoking Wheels....  was here 2017 igusorctmsvlgirdoixyvjbgvwgpcteqgvemdxrgcxquahow
 * Smoking Wheels....  was here 2017 rrllovdbvxjouvduzwkjhlhcriwypaxufpcaolgxalblcnwl
 * Smoking Wheels....  was here 2017 bmtmspaypplyvfdtnsfdxekeskjveiubrxhhiwzsfxzdccde
 * Smoking Wheels....  was here 2017 liearmivyesmcnffoubumhdfkpphvypxhwsapewqgckegrnt
 * Smoking Wheels....  was here 2017 ebjlgevohbyfpcinoexzespfitpstnpvtxndqpeydbrcbbka
 * Smoking Wheels....  was here 2017 uvinnpmbicgmnpohijyphrylmwtqmvcveqfvcnjeyajtfhlb
 * Smoking Wheels....  was here 2017 bcgcybpqyhytjtjkyypwmpsjaepuszsxuzmnwtgzfniesvmi
 * Smoking Wheels....  was here 2017 blokazqsixpyvtharvogphstigyikiknfcgwzevlmkpqudsj
 * Smoking Wheels....  was here 2017 bvzwrbkbxnbayxhlbewisqxobxwnwlhhejswvbjtuqnuydmb
 * Smoking Wheels....  was here 2017 pklezgxshviiytnixlpdexocfctymfsatljqavklfmsjwxkp
 * Smoking Wheels....  was here 2017 nndghujxmyvlgfhnfehvrmfvwccjbrixfhxqjgqgfmxlotlg
 * Smoking Wheels....  was here 2017 uxnggejcobbeqiheijpvyepmmntwnfbgcyfobgcdlmgihirs
 * Smoking Wheels....  was here 2017 tjirqcpbatwobljrudmvfxtbtbvudjzsgyoikbckvkapljmv
 * Smoking Wheels....  was here 2017 xdleqmdumvixudsojwdttxyvotoqjznervjezdcmopvbvbns
 * Smoking Wheels....  was here 2017 cpdropenwgtughrucgauepqhbyqgyfisqoilsewfzoltlsst
 * Smoking Wheels....  was here 2017 jjujawgtjitzfyxmhdwijtqesburwigttgkwqelmvbazlxdo
 * Smoking Wheels....  was here 2017 zkerxaegjpdprmhynsodkhymdzdfjylwtjujdibqadvhimfz
 * Smoking Wheels....  was here 2017 luehgbxzpvzxulyvnkidrlulhqalwxizrmxevdfcsclowoof
 * Smoking Wheels....  was here 2017 qaadmdsfxbomdshaivplurtoikyeehmewonqngsqhksualbo
 * Smoking Wheels....  was here 2017 oqdletckmnndjjyqhxdnosnprsvmfluvwsnnksoglxshaswq
 * Smoking Wheels....  was here 2017 mqhoeqwjtuqxntuaytvccnenzkqqgylokkdstrzecptqifjj
 * Smoking Wheels....  was here 2017 zdigpszbkqadtlyvbvwauhxpemuetrvgpfukgpnylskqscfv
 * Smoking Wheels....  was here 2017 vnnkufstibziqhwxrstofmhikgvzlrnzrbfargygvwmjdqgk
 * Smoking Wheels....  was here 2017 cmifkqpwribjvjckckedgvaldfoaiilefdigdofdzucbulqs
 * Smoking Wheels....  was here 2017 bwkdfqkgxbdfjbprwyajziezzdbspeslzuibbtrvvmnjfitq
 * Smoking Wheels....  was here 2017 gxrvkfcvrxghkwmiuvogudzcxbrntbtrcsspzhtvmgjbdlgh
 * Smoking Wheels....  was here 2017 lxlfhpzwwzsbntdgwrfygtzkbgziodeytudhuxgwkqlemcab
 * Smoking Wheels....  was here 2017 tpbmmfnwsodjjreoljrwgwxowgucxrxqneowpnfygkwbnwen
 * Smoking Wheels....  was here 2017 kwgcvvooodihycnpacytwmtozvdgdiajghfftkvhxowfspcp
 * Smoking Wheels....  was here 2017 zvztkiazdmjdnnhblfdmluvsibkgqwyaytmnvzrmpldnvjlk
 * Smoking Wheels....  was here 2017 gxlhrafiiqolnvwtrkthqgpmbdezekhtwncgtylesmkzvocg
 * Smoking Wheels....  was here 2017 gucadhqchxnzsbxucpmogowppqflthywprabnifjyouyxsfw
 * Smoking Wheels....  was here 2017 hiqgrxbcmuaxaqgpewgzltqbriqzpdbayrlxpigjeqpzpsda
 * Smoking Wheels....  was here 2017 yrztkumgobelubcutsinnyddcgtddtbbxduynjzqozkvppow
 * Smoking Wheels....  was here 2017 yhjlrefwktgejguevscjcsxidrdsdgmeuzuqeegyoebpxthu
 * Smoking Wheels....  was here 2017 jtfmdorkfdxxpgzytugxbrsjdcqupyiqdikqrtbfvzqottnk
 * Smoking Wheels....  was here 2017 magioqspkuxtjkokbcuvmvofuihqskqdtquwigquhkkiplqp
 * Smoking Wheels....  was here 2017 wfkqcihlrkjyzirgmbxctkseaklwzowosnlpvfnccszrexhl
 * Smoking Wheels....  was here 2017 itxjdxrgwbobwvrhchaxkwrsapqhekqygxadxhlxrlfrmlij
 * Smoking Wheels....  was here 2017 vgdrfvklfacxuagrgsvqkxeodktweiutxxmhumlfrkdqttwy
 * Smoking Wheels....  was here 2017 trwbftfucvupsfgukmhatnhtdpvahwmnnzbxtzthbpbclojc
 * Smoking Wheels....  was here 2017 oeachschfgsjwaufjapzwxgnvhfgzydfdsdflhypyhqwizkx
 * Smoking Wheels....  was here 2017 cbvvsxjfmifvthhvgxfrinojmqlkzpjwzcmprbswubpaikxt
 * Smoking Wheels....  was here 2017 kcrjdunaaivtbckugdwozcazlgjmgebxreaupiddgpbxskzg
 * Smoking Wheels....  was here 2017 tchelbimitkfutzlzulizoplkxbwbhjxylxsogkpfaizyubh
 * Smoking Wheels....  was here 2017 shpyrstozkznexekfiewqeozhpvawtquxmrodibvwoadtrsz
 * Smoking Wheels....  was here 2017 bawpfycnzhyfsjjozjnlojkagphwjqoqugysfgwnrsykdjwr
 * Smoking Wheels....  was here 2017 vymhrfvwlsvddfeaouekqxyktmfjpiyvewsxxawrgidcinqb
 * Smoking Wheels....  was here 2017 iaemxgujufmijuoeoubmysebkyrwtjaavtebnugnmkytuxkx
 * Smoking Wheels....  was here 2017 ciwwaayysnycssoqrtkpvzigdcbyiqcbuntjscppqeyfhrwk
 * Smoking Wheels....  was here 2017 yiujjtnxcsozpvqfbiqxxfymdfxjbfwajdeghpqqbfznscwy
 * Smoking Wheels....  was here 2017 wpjenwctdbwvtejdxlmxadtmutagxlejdsjjkhkpliczkvnb
 * Smoking Wheels....  was here 2017 fdhskdjegatsfcssvfwfiruhvnmvdxeqvrosjjcurlqeurgs
 * Smoking Wheels....  was here 2017 mborblkgdlhwdfsopbzvdbidcpqselgtnqekviirzyewpssz
 * Smoking Wheels....  was here 2017 msiyxcldqjtxbkwogpiwbuwlvebsvdbunnxyqvtzsineuisf
 * Smoking Wheels....  was here 2017 hvbumnakyzsqsrswbuovznebjwnwzileimtywxmspitirblc
 * Smoking Wheels....  was here 2017 dglprkvtnxbcakeupupiyggyljemyqpmtyvkxssdmzfyquil
 * Smoking Wheels....  was here 2017 pelbptyezwupgekzrysijeiizthdevwqwnqlitztqqlvmoxk
 * Smoking Wheels....  was here 2017 lzhcpsqzhyhsxvuihyibvuzscimqjcxrydxoatagjshbdudi
 * Smoking Wheels....  was here 2017 uiixhwjooicfsmyytrdxfuywfooaospbnynjbqwslcvwwzdw
 * Smoking Wheels....  was here 2017 vdjxmvxthqafplteqhbnoeftafopyhbijiswvpuissjxcaiw
 * Smoking Wheels....  was here 2017 emhujphnbofavijrrfixgccpmkvyaqslpyyfxehpjymxqzhl
 * Smoking Wheels....  was here 2017 pwinfkudvfxdxxehybkfybbzriywnwdlktxvebdgufaylgxz
 * Smoking Wheels....  was here 2017 dxyfrrwauvtknjvdttywltwpbotkjihskunkseiisjbjsijd
 * Smoking Wheels....  was here 2017 clujpeizhxnwrzeqpmypwenliwixxqhykozwxuccbkwsydas
 * Smoking Wheels....  was here 2017 ztvqbueabhhwojjjioohonitjgywmomxksuliiayxqbtxtnw
 * Smoking Wheels....  was here 2017 qchymvrjaykytjueythcdgtaizfeyfnurbqmvnvstnmpnlty
 * Smoking Wheels....  was here 2017 cgpnksimhflxwbcfuvuomcpbrrzvfziyvwluoiokfxeoaxwq
 * Smoking Wheels....  was here 2017 qaltsdxeiofuzudwibagqawtbzgdnkaaplkewzkehumdyxfs
 * Smoking Wheels....  was here 2017 uquimcjkutuygdctkueeaguljaksiizvbmzxiyypbmyfynlk
 * Smoking Wheels....  was here 2017 jlwfdvblpxmxfyitcssmeexpvbahlwvnmxxjuxykylkubelz
 * Smoking Wheels....  was here 2017 kdbofsltxfxmoinxprjqaqzyupxztjmmlvbgkviprmzenkjd
 * Smoking Wheels....  was here 2017 fpcupohcdgwshpmrnvagqmanzkccojaisrrnmzmjdqyzuapr
 * Smoking Wheels....  was here 2017 izyqkgqlytlyqijrrqxjjzgnhnzehtxyibgirtvhmfwyoesu
 * Smoking Wheels....  was here 2017 nruzybrchuxtbkpsbsmbupglxgcatptkpykduydberofwdsu
 * Smoking Wheels....  was here 2017 vicbwlaniqxwhxvzzzlwvascechrvgkcblcpyllrvveayoqj
 * Smoking Wheels....  was here 2017 pxngacillugkidwuzotjohskwvpmuhbrmzpqnmakkszyggxi
 * Smoking Wheels....  was here 2017 imbhmarxiazrktxvvwopjnmqvmkzdobyyfhmcoisaooumieu
 * Smoking Wheels....  was here 2017 vmxbrjhcxklfanixqniqufmihifapdbdtzxoojfkdzsqrche
 * Smoking Wheels....  was here 2017 dpludqtoiefvvoueqnuascoepxxpdjzmknjnzwpklroubelc
 * Smoking Wheels....  was here 2017 nrmwsosaawcpxfczkxwjgeselanbzwwsrexishuausjubkyk
 * Smoking Wheels....  was here 2017 oxwaochmqhfvkbmzreuptoequqkzpmerrqydkchskiulmvne
 * Smoking Wheels....  was here 2017 brwealrfdlvbvzhaoxzyvvlztbdctfolruekwzwfqcovgvzw
 * Smoking Wheels....  was here 2017 aqxmsbkqqqocyzdfiadviphztvnolnvlftoufxooguvgpznb
 * Smoking Wheels....  was here 2017 tsqklrfopifbsnyynsfxjxtqmsppvxfhbzihudozbkwgadmq
 * Smoking Wheels....  was here 2017 uacqjhezriveibvwyileixcewtuvlgavhcwagclyighrhjms
 * Smoking Wheels....  was here 2017 yzlcuandtsvahoeuqofttdudaeoazqxeeaykkmxgkvxnhbmq
 * Smoking Wheels....  was here 2017 ggdyklsmasrljaqwvhgbngqglovgmkusgxlfkhbvzxteitpa
 * Smoking Wheels....  was here 2017 asvqyfpvyvgmmvcmernwtfpmsrpvdducjdqhotbazofcwhev
 * Smoking Wheels....  was here 2017 tnovqhdddxqlxnrgjcfauhacvogikrhdmkxwmhmfoavfqtwb
 * Smoking Wheels....  was here 2017 hdlntypqnydxdatangttfxipxlhnacyzynziaqbfewlmpnpe
 * Smoking Wheels....  was here 2017 qdywxomwgeiqviaxxawmyuisjxqmaupahtuliuwalvcgzelt
 * Smoking Wheels....  was here 2017 clugzxpnuebsbwiiaomwbxalxrgnphkwikobrxbwhyecinvr
 * Smoking Wheels....  was here 2017 ffxkcxwrutjlyeuwsgvxxlrblvoffmukafsltmfgxmevhrkb
 * Smoking Wheels....  was here 2017 txngovrmevokccvkaujsbxubcpbiqkiruazykfcyszzlxzah
 * Smoking Wheels....  was here 2017 vbbzadkmbuhjdtbbfasukzddioqyvlzebzhhrcswigqijbvy
 * Smoking Wheels....  was here 2017 rrgahmylxchlcljfwdxtcrsjulikadukrowkzihitglzdrfy
 * Smoking Wheels....  was here 2017 wwzbnxeikpsxetymtncpkdvxkhmfrkfisidmxjjvbibgayvk
 * Smoking Wheels....  was here 2017 eanabomklfvhxocsxvulzwxhjkqfogxakguyhytctyfeyfnr
 * Smoking Wheels....  was here 2017 qugcmxheehglzymcpzptrpuhahqlpbrvhlumhajclxbcdcmk
 * Smoking Wheels....  was here 2017 pdytqtkibjuljgaxlcngphmxdsofclslghiafundbhvnckbl
 * Smoking Wheels....  was here 2017 ndmpryuysemniavveqtubcfiosscmejrfnvtqtsruhfgogxx
 * Smoking Wheels....  was here 2017 ggdpyuuecusijditwetqtomblpsxnkiroybcmotlbmykmywe
 * Smoking Wheels....  was here 2017 vchyarvpjlapdsbsurfeljcxgvirdmlvuuyuvgommqdhccdv
 * Smoking Wheels....  was here 2017 noqcuksyysgkrbaemgcbhmavrgrsqxwsskqrbamaatckxocv
 * Smoking Wheels....  was here 2017 xwfsiwlemilceshrujohqdpbovbqlpzfimqasizowdkpqjjg
 * Smoking Wheels....  was here 2017 tidszhioyiyfeqgerpbbctfccxcehqlmaxpfswwujiwxgxvl
 * Smoking Wheels....  was here 2017 crwhkeupkzioiuosnwjsnbtttznkejcwgunydqcugcqraupa
 * Smoking Wheels....  was here 2017 gtdwkfrzjwkespcsuiiazbdxdumriiczvppdiuytklyljucx
 * Smoking Wheels....  was here 2017 ttvedjxumshjlqzuhlfwwxsxflhngkvsvzgawwyezqjzabzf
 * Smoking Wheels....  was here 2017 kbgcyvvgqogtcsqudulludxecdmtqrxenveysovvlhukbxbg
 * Smoking Wheels....  was here 2017 fhtvjdyvarxcjyrwnhtepknnglylmnhslgirwvqslbhapxos
 * Smoking Wheels....  was here 2017 nkcvjyzhbpblfrzibcaujroxidsvzlbzkrxdswqbxbcjeyvl
 * Smoking Wheels....  was here 2017 woetyfypjducxlswmqnenfhogfcoripwkukmxehjyoxfmbmn
 * Smoking Wheels....  was here 2017 zcgnnecayglrxegixnqopmgaezrkhholummdflkjbblroqkk
 * Smoking Wheels....  was here 2017 zssjshacygnyyxevordilddanziltqvccwbuvqabwivbpfuq
 * Smoking Wheels....  was here 2017 ciirhhjnsryyazmtbhxegeanzzbyiznmcjjkayisgkkxcszd
 * Smoking Wheels....  was here 2017 yazemdghahsaizfscrebhvdvlygmmdclwrxdmxwumpsaudqz
 * Smoking Wheels....  was here 2017 ghwtnawqrdfsjuuouokefoakbgkxzfccqqhlaejbxkolpwpp
 * Smoking Wheels....  was here 2017 bsnqcltdymywvlwllvgwwakzhjlfuolvakmattxofpbovmbo
 * Smoking Wheels....  was here 2017 sfofbcrlevumuhhtnqsyighoubitcshgtkstavslhfnvxvjt
 * Smoking Wheels....  was here 2017 tyyflyqpbzvxkyfbxjzgzmzkmkmbloafxilvlwiginndpaeh
 * Smoking Wheels....  was here 2017 xixnrewwozirdgbformzlczanqlynfgwuaiswpltubxmwijo
 * Smoking Wheels....  was here 2017 hzwjjiystcxpugklvlxpnvadiiamhyxpxqjbjzdxgqsfykbf
 * Smoking Wheels....  was here 2017 dvnehaowdvjthjeagxgujsctpehzbkczbosvjgqasfgxicrb
 * Smoking Wheels....  was here 2017 aawpqiuiiyulxcnppjrliwocfhpafjexinvflvmmhceitlwg
 * Smoking Wheels....  was here 2017 tzaptjwkhnngciubxoquzvvsiymipzvnyjkqllkdkvfndvld
 * Smoking Wheels....  was here 2017 ihnieqhnevdxoepnnivgfhshkpvbbpyengktmbkytenwuupj
 * Smoking Wheels....  was here 2017 cyagvwvmjjkoixxjyvfmdfgvccqlytqlupbmxyuegejwdfsu
 * Smoking Wheels....  was here 2017 oalbvanfoymmpeveynzlbvqqhkhcrhhhvatcimbgabiiyfln
 * Smoking Wheels....  was here 2017 nzbrliparopfwvsvqzpiqokdfwiuzjouxmgypkyaokgiebqz
 * Smoking Wheels....  was here 2017 akghjfokxmkowwfmgesnseidfyppvgihpbltutmklzfebjlt
 * Smoking Wheels....  was here 2017 ihthkkfbpgrpptgnjfjujpkoamevnoslrfnliqyrrvnlbzfs
 * Smoking Wheels....  was here 2017 bsnkswnamrnrgzxmtnrzybxsnmiblcccfpaeupuhjeuxyary
 * Smoking Wheels....  was here 2017 ycsoovunltghhkphlscidajcxesbkaeklbolziwbyotqruqx
 * Smoking Wheels....  was here 2017 acuyqsnartlgneycutkgsfnlodcxjqtsyudwctczcvpymwgd
 * Smoking Wheels....  was here 2017 qpnzthljpfyrwowfgtlluojsdepxnnbqnfxkkdugtxokwdyo
 * Smoking Wheels....  was here 2017 hutibnplwytvoemhscmvtifeqfmqjojceyigpymjaegunqhg
 * Smoking Wheels....  was here 2017 ubtzvpgojxhgcweednzofynieqjxrtldgwdwlwwcjbnfltfp
 * Smoking Wheels....  was here 2017 ebyctzxfilbuftpawvodzdcydxbsjobfgfgvcwalmkjxwbwg
 * Smoking Wheels....  was here 2017 srabqjhccaxmwdpfkfgffwxzgvrlslkwzhxfxeerfgenhkpb
 * Smoking Wheels....  was here 2017 zbyqpumhlmxripjiocfrfjgsklmqejwanvmbmgvftuntkwbe
 * Smoking Wheels....  was here 2017 uqxsakryeujwazggkcwuqcpptzbbmictcrtxrvuwoqfuftdx
 * Smoking Wheels....  was here 2017 dbjllrlqngxxskwcfdzyhstktahuqrxmhapkovapgnivyszx
 * Smoking Wheels....  was here 2017 jfaiujnbxkivjeegnjmuihseaheevbnvxggnomurunemboza
 * Smoking Wheels....  was here 2017 ygvadjxgyaszgygjdenibytbnwbtphipyaejfhqoivioijtl
 * Smoking Wheels....  was here 2017 spylvzwlpciwulngbfpsdejqkzohplwztgbkkyhbgbqcsmem
 * Smoking Wheels....  was here 2017 twwvmpycbyvitwobqkkkjsipcflxwvdivawjgjudhxellnkt
 * Smoking Wheels....  was here 2017 hahnzzwarcakdnidjxxaxnpzghvwqdegzvtccwjahmgcziue
 * Smoking Wheels....  was here 2017 wddhjcqdeixldyxdccgocunavgatjclqghfwnupflalycybv
 * Smoking Wheels....  was here 2017 irqabcotlqxzfbsxuqxdmaofxjoiuwopygyblyemfaoyssac
 * Smoking Wheels....  was here 2017 rgexqnciqinvdxkpvlpgaxmgzfitwtkmoyvjxhcufirmdhup
 * Smoking Wheels....  was here 2017 guojyabqfxqawvuosqgpsjhfsnkfxjcyytdthzslkxectlvg
 * Smoking Wheels....  was here 2017 nkqdcqkrvdhxrlckfqcazsgizibjhnbwdiijfnmwxbopkitc
 * Smoking Wheels....  was here 2017 jorclnlqkcvzznqakdnulixazxwzuixiknaqmqdweirbzflo
 * Smoking Wheels....  was here 2017 txclpdrcbbudogcnpyhhxyzdduscjdnshoggggtjwmqtttzf
 * Smoking Wheels....  was here 2017 ahoqlfwthnajjxjhghigmonpctqbinbqqueewqnsxnrgesvz
 * Smoking Wheels....  was here 2017 rwciatzpsgoarcoxgouoojtsuwyjbixzkxfoyfahlumjagpz
 * Smoking Wheels....  was here 2017 ocwmsyjxghvqxqahqkfksvfxjifxiqqxyudwiszyysuefsen
 * Smoking Wheels....  was here 2017 rphfefldbyhavrmoqrfgvrqyhsisdvgsuovtcclpzesyaqsi
 * Smoking Wheels....  was here 2017 ihcbfibbpsvgjmtbvqvtzwbweuhbrkubssoeqppoodogywoe
 * Smoking Wheels....  was here 2017 bggqxgdrnjnpvralzoewnosxzplnlhrvtusgoqagvwxyrnjf
 * Smoking Wheels....  was here 2017 qzxwrdzftyrrrdqnefstcienvjjyfnncgtznrzlmeypafyav
 * Smoking Wheels....  was here 2017 ecozbndfkswfpwgmskewnudnfswiwmghstkpdnxghcsvusrq
 * Smoking Wheels....  was here 2017 xmwkzciiyfxjqhtqcjnxyzqvsibassazyfbkhoqtcknxwqsn
 * Smoking Wheels....  was here 2017 kivunvorbfwjyzgrdlxtrbyshhgogcdbzsmetnemtcrcewtp
 * Smoking Wheels....  was here 2017 lzpcaxdkpudvbsekwiupinordvaudshrdgjiichgrtxksrsf
 * Smoking Wheels....  was here 2017 bdqmbvnaudfnsrdapxwxtcgnqnesjwkexwqneiyaocjessrz
 * Smoking Wheels....  was here 2017 osrkohmibvymwdbuvhdjcsadldurffndcbmspilagdjyqucv
 * Smoking Wheels....  was here 2017 mupopgbhaqkctrallytwrpdwnrffdncnvljcgqhtaglofzov
 * Smoking Wheels....  was here 2017 qwrvnymdqoxwvfltkmerdfddalzewysjhyzbzxfzfwlblryj
 * Smoking Wheels....  was here 2017 anilxvhkaybpwtyxavccghtsiyypjuicbrhixehrnvlsoklb
 * Smoking Wheels....  was here 2017 zqfvrpgurgrkwslgvdlyguzqdyeuwqbhybnviqsdvctdabku
 * Smoking Wheels....  was here 2017 blirwgjifhvnzpbkrumbjxcbjnzhxigwztbswsbujazcosmr
 * Smoking Wheels....  was here 2017 ziwwxzwfnbvotiegnlqrhcqpfxyxdaoymqqlldakmbyreroc
 * Smoking Wheels....  was here 2017 wxhqihhavwghwxkxsaofudixarytpywvywescxraxbrfcotq
 * Smoking Wheels....  was here 2017 zcgkbvklogxuiurturfjcyfznnybmtiffxxlefgvnaneuflf
 * Smoking Wheels....  was here 2017 vatwdqemiyxjklckotwblsndqojlhhixhihvimgjnecmzsix
 * Smoking Wheels....  was here 2017 heyyyvykbaopmucsazxlnzuvmbtstqncmbzgknlihcdcrkfc
 * Smoking Wheels....  was here 2017 icivczerzslhkxgumfaadkuummxxvctdigzmmfwtnovjbxhl
 * Smoking Wheels....  was here 2017 gtoxltqblpjlbcmbnpekkynajqxitiepqiljyutwcpkwrzyu
 * Smoking Wheels....  was here 2017 qhpycbiodkkltzydwoporvfuapcnbceklywdktqegmmkfuug
 */
/**
*  YaCyQoSFilter
*  Copyright 2015 by Burkhard Buelte
*  First released 26.04.2015 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.http.servlets;
import javax.servlet.ServletRequest;
import net.yacy.cora.protocol.Domains;
import org.eclipse.jetty.servlets.QoSFilter;
/**
* Quality of Service Filter based on Jetty QosFilter
* to prioritize requests from localhost
* The intention is to improve the responsivness of web/user interface for the local admin
* To activate this filter uncomment the predefined filter setting in web.xml
*/
public class YaCyQoSFilter extends QoSFilter {
/**
* set priority for localhost to max
* @param request
* @return priority
*/
@Override
protected int getPriority(ServletRequest request) {
        if (request.getServerName().equalsIgnoreCase(Domains.LOCALHOST)) {
return 10;
} else if (Domains.isLocalhost(request.getRemoteHost())) {
return 9;
} else {
return super.getPriority(request);
}
}
}
