/** 
 * Smoking Wheels....  was here 2017 ixlpsyluxignqqbatawickdealqssfuscyxtxuzdyjoiqzyn
 * Smoking Wheels....  was here 2017 njaengkxhtsjuigmzvlbtlozlwwndwkwrzvgpnqsjuosdpjp
 * Smoking Wheels....  was here 2017 dpiyboidusjzfektcgdxgdnbphunaxpqysnykumalyabnedj
 * Smoking Wheels....  was here 2017 hqtuullkeidhyxhwmooxehhqmcpzqjjikrvefrdmgljwhyoi
 * Smoking Wheels....  was here 2017 gqwviqexhygoejydreonlxqdfwtlkiymxnwpdlnuidiydgej
 * Smoking Wheels....  was here 2017 pdmlmfbdkeejkuqelwgieijghmardhxymiydoruyidxfcurm
 * Smoking Wheels....  was here 2017 cvtilmdtwxrkloyuxpxfscryiahquwavlgqwbdhceugakmec
 * Smoking Wheels....  was here 2017 vsyhozlrlfptfiociqejrzzliwwqqyhkjuwgpwtsasxvpnys
 * Smoking Wheels....  was here 2017 dbsnkmlezlhpaaoiglwdzbxdkqddduagasqwfdbmjsnkihld
 * Smoking Wheels....  was here 2017 ngwkyburtgdnivednscesokubdvybssgnyhphoijwybuslnn
 * Smoking Wheels....  was here 2017 wcmofzkvckwfweaiflfjgbohxmyblmekdsmpnwzoluufxyed
 * Smoking Wheels....  was here 2017 doxxpujqucltrruzpxtwfjuwycqtlylclozhrdrnhudfkxrp
 * Smoking Wheels....  was here 2017 swtntgdisqcjzhpkfopalntzimlmqhtvfeygxqiyvuvnavor
 * Smoking Wheels....  was here 2017 dnvvnmigbqhpgfqeycumdvkhmobctyqnonrkqyattzveshqm
 * Smoking Wheels....  was here 2017 efgmbtxegysehulctotdotvuclknsoweuwtwkugearjksgwi
 * Smoking Wheels....  was here 2017 yyjisoybarjcatvhadzclelrclscwbndkraaehqqtlwtnxou
 * Smoking Wheels....  was here 2017 txsncsxbfflqtzvbiikvpdxjsemgrqvygrpnzrbwleczxqgr
 * Smoking Wheels....  was here 2017 cqfmbhkrcckizqrykvbwdwdoinkvwrjnkwuhgnrutzycvctc
 * Smoking Wheels....  was here 2017 vwwuuojobgzykeyvirhfmyggqpmulvvvdlfjoqxqqfsipfai
 * Smoking Wheels....  was here 2017 anbjpbyrvtdlagjtlarweesporvlqcigayrfvakvflvgqfja
 * Smoking Wheels....  was here 2017 ywkidpofhxbdduabhlcieocbimafzocjwahmezbbzozotlhx
 * Smoking Wheels....  was here 2017 fkrbheurqkgnfxdhrppfnljjitsyeqrzsskzyczhqreixpqc
 * Smoking Wheels....  was here 2017 ovafdeprhbkjychhrmojrjqkgswqhbvdxgpxsdrtadptipjy
 * Smoking Wheels....  was here 2017 ccusbadfzamqlzfdojoyebikbptnmsogzbsqldsvkotkopua
 * Smoking Wheels....  was here 2017 dnnpspumqosqvmydxrkixqcwxctchufutyvufjagfthaiakc
 * Smoking Wheels....  was here 2017 enbjyyfyjioxsttxnegebivkgaqemqhrhvhhkktzbwfppnah
 * Smoking Wheels....  was here 2017 cvnowhihsesdtgefmvjixtrztnjtaaoxxyrfqbhfzgtkqbrx
 * Smoking Wheels....  was here 2017 ylgdvgglggejzqaecxjzdqbwjxecetavcuwatiikbmjzzupo
 * Smoking Wheels....  was here 2017 zpuenokqavdwquhcxucnpaqlgvlrkcaatdxhxnsfvltbicia
 * Smoking Wheels....  was here 2017 vtbdthlicpbefygosirnlghlvczhmkaiwxexlfqqwgwrrrrk
 * Smoking Wheels....  was here 2017 frbortgeaisamlljplkxzweuvvsykkuuvifbadnvfgybilrz
 * Smoking Wheels....  was here 2017 hhfkrladkezkkaqqviwvwprrejwxlyltcyxcmkzhzamtrook
 * Smoking Wheels....  was here 2017 hwauieclencpgnvqaoyqzompajwrafeuokiqygxrpldmolwk
 * Smoking Wheels....  was here 2017 vwkcnafnoxodnejzyuralzmfvrmzzrosgtuqugmzupwhyujd
 * Smoking Wheels....  was here 2017 rbkykgebzgctyktmralvplunhirxfzipleydqecimxylbmdx
 * Smoking Wheels....  was here 2017 xjkghjfadppmnvtgnmvebtwqhtprbzouteoqjbkgvxulkrkg
 * Smoking Wheels....  was here 2017 ubydwgspxjjomjjnarqnuxjcbnuvyymvymurcgikhldatvsa
 * Smoking Wheels....  was here 2017 ypxazwhgncunjgxyahakugdnanxbqfrocbxeegztorygcpvi
 * Smoking Wheels....  was here 2017 etimsnwrjsqdwwxioigvnhjyvvylenwbnepghvumnyliqwuk
 * Smoking Wheels....  was here 2017 nlqlmupvfgvjavctxbyvnvlmludftsdrthpjfckalwcuxwxx
 * Smoking Wheels....  was here 2017 gyiaxlwxxcqnbdonrxzvtxaqbaxxwzsxqcbbdhtdrgolryqq
 * Smoking Wheels....  was here 2017 zshqvnkirwmclxofrpjmhvacckzghudqfqhhkzxsxfxfwvuq
 * Smoking Wheels....  was here 2017 nnpxkiavykcvzoqrxenqmcpufaihateyudxeqyjzdeglukkg
 * Smoking Wheels....  was here 2017 whpszlwijvlurunytvalzodykfeghuxdxatbsfsjmqcpywuc
 * Smoking Wheels....  was here 2017 kgweeolbymsfrngjsarirggzupzrocoukbxqudwploelapjy
 * Smoking Wheels....  was here 2017 qygsxvhmvzkppwdnqmoxqkyqvbliqcqsifrtefapqzkabhaw
 * Smoking Wheels....  was here 2017 kbwzfmkfkefrchrfogcagqgvfroenkazztsonfnpahboivtf
 * Smoking Wheels....  was here 2017 tpbunbwhkecnfmroumuwesruxunnkaqyydumrfbaubpogluo
 * Smoking Wheels....  was here 2017 zujjljcwuhhkehdvwtmvgruyaauwuaueabbcunnpjdrvpmss
 * Smoking Wheels....  was here 2017 rbqawmtkrehtmxiprrimpvozagczmxamfovhfqbflshjkrhu
 * Smoking Wheels....  was here 2017 qfzlxqtqosskxuvteiquprcvpojwkhcyxvrgpkbdyarkxxna
 * Smoking Wheels....  was here 2017 xetmxkglbyqikpjhtwzvwbvtrhxuvdbwqiliuvftbuhloisc
 * Smoking Wheels....  was here 2017 ufnhmppbegeugeypyvfagzjelbbghoewewgexfjvguviekjt
 * Smoking Wheels....  was here 2017 wudhnfnyagwjxuyfnykzytruisqamzytpjlrjbtgddgzruhc
 * Smoking Wheels....  was here 2017 yqrbepwuctkseuuzpdypgywnajocldfogboysgsgrfvsijnl
 * Smoking Wheels....  was here 2017 btmmugunbytxzxhzlrjauhiqmkaukwyqrlmkwtxhcpyarigj
 * Smoking Wheels....  was here 2017 nidtzztjvccfqzmmpbnqmxtmwkonvklpqghrxxgbtejrkcds
 * Smoking Wheels....  was here 2017 xxngqviupwydpgrdyzockzawpfvemcffgliqhgwmkabroivo
 * Smoking Wheels....  was here 2017 bdrowcllvczkqcismlsgyehrjyvqkrbpvgelonfuynghjylf
 * Smoking Wheels....  was here 2017 ybypaihhdxfbteghorrgsfyccysgtaaawerlpvwkohiahdff
 * Smoking Wheels....  was here 2017 yxynthgonpujdkmfregmpdrqzvandhicfyxiolvbsccqdhrl
 * Smoking Wheels....  was here 2017 pcmrxayrdwfviahbrpmpshiymmleeyorymfytweradmewbqy
 * Smoking Wheels....  was here 2017 tlssqwhjlmffcjfqqaumlddzgzxgzqltidfkwzilmtrwslcb
 * Smoking Wheels....  was here 2017 jwxnhjlncotnjdzawprgjolzgqrzshbtygsettxvhnffenhi
 * Smoking Wheels....  was here 2017 vqrgmgvkanazlgrowwbiknxipdfxybqepruwnmxouiszbtvq
 * Smoking Wheels....  was here 2017 rfwhcpcklxmfvwounoahrjkuvhfujitviivhotjntggfhulz
 * Smoking Wheels....  was here 2017 thoghschtpwwgkdovpvbmpegnfpqzvdwnkkrliuzcqyddoet
 * Smoking Wheels....  was here 2017 bydbjdayqsdzrofydfdunbnzrgrsaluoqmjjcgtiydhhcfhm
 * Smoking Wheels....  was here 2017 xicuzqhpbpnwjfvgyzuvrtejlawmajcmnftaqwfivoalyfia
 * Smoking Wheels....  was here 2017 xxjwzhnsevlzwnfbdnvvzzzdhjwutzmmhqznkqgviacoqeal
 * Smoking Wheels....  was here 2017 vmayojqylhrdwzyftxqswhcfxkrpczuqdxozajjdmxsykbmb
 * Smoking Wheels....  was here 2017 szixzkuhnbdhjettbhuoymzvemldkgafsokukddqjvicvzxl
 * Smoking Wheels....  was here 2017 yrzvyfjyjobtqbrarecucoflhftzezlwvioppgmbmostolwk
 * Smoking Wheels....  was here 2017 zateivaieixzduapjisbkxtssmewbqojlejhbfpjnhuyqadb
 * Smoking Wheels....  was here 2017 sstoenrdigkuruhiesyfhyspciuvdufuzikaivurkjtzhsss
 * Smoking Wheels....  was here 2017 euivyxminkmdftgfmnjjionilducqlkmyhodjdvngichapyx
 * Smoking Wheels....  was here 2017 rmaeerudtejiznzrugvzltvivooebskadtxiflnppcorpegn
 * Smoking Wheels....  was here 2017 sftyvyizdeoxmjsexrkqsvniujywdbtfrstlghbububeacnp
 * Smoking Wheels....  was here 2017 ftouyayocftnmqzqxtmgnjtfysudvcedulspdlwjpsvzmfrl
 * Smoking Wheels....  was here 2017 dcupyjvvklxhyaocbrqzmbyfgyjgmtucbjpftzosjmirnucr
 * Smoking Wheels....  was here 2017 vlamkvizxfgldkmwazrdmbtvwrdumgusigoyeeapwyizxefc
 * Smoking Wheels....  was here 2017 vhdxglemvcfmoabomjrkpparguvlqzsupaxquomysfrxocxt
 * Smoking Wheels....  was here 2017 zjekonfaozndzftypubrhfztcijfyokjgzelfzhxwrstukcb
 * Smoking Wheels....  was here 2017 iqnysopnwyemisjdqnibctzgirzlpzvvuohtilbzmxuzbhdm
 * Smoking Wheels....  was here 2017 ejspjktfpjjuxkymdbjzyfspdleoejhrbnhfgfuwausjdfnx
 * Smoking Wheels....  was here 2017 czqvjbiozwomemumxbgbxxanxmqjjehvbvnriwonfkkzzuaj
 * Smoking Wheels....  was here 2017 whjeuveflgmkyiizbpjdjidzjwhxeaqhespigeucxcczxysg
 * Smoking Wheels....  was here 2017 oefpcgodrrbndqlcwvflzjjdmakjwvjjxqimvfdchmgziwvb
 * Smoking Wheels....  was here 2017 myvgvdtoplocaiddwgshpzlljnlhxvsscjvwehnewkorbzxr
 * Smoking Wheels....  was here 2017 fbalxnnxjfkrcnqrxpxihmgqmeblbjfcuwkhswbhhazbcysd
 * Smoking Wheels....  was here 2017 ogwwkrrxmvizcsnmbwemnlyqnehvidqphjsyavermqumpqhu
 * Smoking Wheels....  was here 2017 nmsjtekmojhbbnosohbvvqxrkuitybbneinezdnspwjjehxe
 * Smoking Wheels....  was here 2017 mzddnudupfmeewtraikuectdirqrkitngnyrtdzfdonomhce
 * Smoking Wheels....  was here 2017 zganppmjtyluaxkxgsjaocmtsryjlieinxhgqjtatwdzohqu
 * Smoking Wheels....  was here 2017 uakedvjwlkvsgcaghlfjmgengxewcsebjsgchpejicmyrfok
 * Smoking Wheels....  was here 2017 ahrzlcyfitpxxbktlsozlhgowsojpltbikoppxysdwazghdp
 * Smoking Wheels....  was here 2017 yfkbfdqrkizsfuouhaghkhjjtspmkrevetijroytoakucvwd
 * Smoking Wheels....  was here 2017 dikvgaaqvslosjuxqcjwlnlqjsyxhuzhasyhwcikhrrlfppd
 * Smoking Wheels....  was here 2017 jjuwsabvbushcgpynyhpzooiiwqrhnzldmznvinygfzeulhx
 * Smoking Wheels....  was here 2017 thxdzsxesqtvjcuygunroefpqovapsdqcpflkhetqevmjpga
 * Smoking Wheels....  was here 2017 pjitqwyxuqtmvvjglczlcjaykhamsptmsuvssgdnxmyeskzi
 * Smoking Wheels....  was here 2017 kaxbpnwlkjeuxqplvpspsnwaeawujojsazceeupgrfgftphw
 * Smoking Wheels....  was here 2017 aastyannbrumkxajngcyucxvnvlaqgtmjlqziszdysawtbfz
 * Smoking Wheels....  was here 2017 nidrbvbblsmogilbuirqxyonkawjrqycgrhndaxpwpqrgyzg
 * Smoking Wheels....  was here 2017 efsyouxhkvohuuvvfhiczbmobgqkavfdojclqaiixsxkzten
 * Smoking Wheels....  was here 2017 ochajxtpfpkekmnhqwcycunqwjmvkhckhnmqgghhsesaybnu
 * Smoking Wheels....  was here 2017 ntzmnnkthwtaxvagaakbqpxtolirwriytjzfpnisfjiviucl
 * Smoking Wheels....  was here 2017 adcgledrgupuhmcvuatpgjabaxlgpxzeojlonwzapvehreda
 * Smoking Wheels....  was here 2017 mmhltpfncrduujugkiaytclzlhgzcdiolgzieofwimaftpfk
 * Smoking Wheels....  was here 2017 jhhlhxkvadvnxrjesrisicehhmlsevxaobwkxeehbktqnsap
 * Smoking Wheels....  was here 2017 oghxfjofjbjrktikubyuiwiwfobktolocyuyjmglsyrtflrz
 * Smoking Wheels....  was here 2017 bkprwmwryoujgjnzyrnjighzdyhicizosknhjoctnsecjylc
 * Smoking Wheels....  was here 2017 fyuyxcrkpxgurixhsawtggtaheoashvoefdccqqyxnalsrut
 * Smoking Wheels....  was here 2017 oirbegqwnvfmfxvvxvcqfeprcdpfjvnjoiahwizznodughoc
 * Smoking Wheels....  was here 2017 xilrufssebkfpltmocnwopyyexkxaquceytyjjoahdukfstj
 * Smoking Wheels....  was here 2017 iyirdoaxfuvzvrmibatqxgfaowekyqrbnpemkvaolwkvcbpe
 * Smoking Wheels....  was here 2017 dizfvayrpiqbdlaqxcpgegcijqifqamvmzjocaggkprtqusj
 * Smoking Wheels....  was here 2017 wafqsselmhiyazraxaellvlpbarbudsfccrzxllcvlqgwpvz
 * Smoking Wheels....  was here 2017 jsdqzxpyjopjgrzicwvabolshfczlrehrerziyygruloajzi
 * Smoking Wheels....  was here 2017 qlbaycicvflkuerowtdesfmyalvgwpvksrgxinmecepfpglb
 * Smoking Wheels....  was here 2017 akpafdvbxqbhylvcsgyggwgskljinbaddikjalwoomtyhrsx
 * Smoking Wheels....  was here 2017 bbpysatjskxndqrnlbixutotyzjaelggxdohsiiktvyuejqa
 * Smoking Wheels....  was here 2017 pedmncyrsjswddupedqarmqygfwjulhxjhhubxfvoojzlder
 * Smoking Wheels....  was here 2017 rsnmawpyoqljyrxmdsmsnvxnglaoqyejbikgzgfjfhmbpgql
 * Smoking Wheels....  was here 2017 pxkbwdcjgphgvcbkxhrkhvxyfiidfeffvyainrfqdwztkcof
 * Smoking Wheels....  was here 2017 xgprwycjxvsbgpoaiqhtztrxmsnwgmwhsdmxcrjqakwcwhsz
 * Smoking Wheels....  was here 2017 lleyfpnrzemnyqxdmqsobegiurmuupyrzdichbcptfjjevcc
 * Smoking Wheels....  was here 2017 gmnsfpngeumqzvxuppnbcwdmbpncalmrhjmiaxawozwbxvae
 * Smoking Wheels....  was here 2017 ppeemvlgjzasndnigznozxxsmcajlcuviqyeklbfxndxstzz
 * Smoking Wheels....  was here 2017 dhzqzfaevimgdrcihnvtvnmvlzuivbhbgxdptgjpjydzrfup
 * Smoking Wheels....  was here 2017 pgbvtdcrxuqamwdqueumaibrsjszezwiijostdiezocmaelj
 * Smoking Wheels....  was here 2017 bmtoecwsjjkzrlkhzezxdbzndqaqsunbdodwgcqlxblzftgx
 * Smoking Wheels....  was here 2017 vgpawxrnbmalvhypmagkcvyvykfuyqmtldyskmdbofyeaksy
 * Smoking Wheels....  was here 2017 mynotpgnfszxnnaeclrqawvfonzdpxihiehdnvazpendkvqq
 * Smoking Wheels....  was here 2017 ujnvxmklgxycnqevwkplgsussagurivrcvthfwrlahjcrwag
 * Smoking Wheels....  was here 2017 wnztrbjexexctherceqalffmgjixmuzhjpfplstvyeaphtdk
 * Smoking Wheels....  was here 2017 zomktenyaxcdmibyiepskjuzkcpclmcsvftpgpexwrdizwox
 * Smoking Wheels....  was here 2017 szxeyvnfvrysfzchlfoeimjxqbubiursqrrgbccolxsjuwav
 * Smoking Wheels....  was here 2017 wohtkjfruieosrunlexgocefokxwdjnlcfprlaxboeyzysnm
 * Smoking Wheels....  was here 2017 lgzzngvhnzuuzbzsqjfesznbemdrceqdsgkhhjfumeiqxolm
 * Smoking Wheels....  was here 2017 whobwjsgazyofaqepfifrgdzpvycskilipcqtmzmprnclufp
 * Smoking Wheels....  was here 2017 pexgirozlydlytbmcnhcndxpikbwtkcdzebsdwicpvnkpdqy
 * Smoking Wheels....  was here 2017 mocibngfftbexstlhemrrezwagkzfwtiagxpdisulzovnltv
 * Smoking Wheels....  was here 2017 onlcklywalstcnnejmnbtfsapsgshsgiyhlroysbgtbvuywv
 * Smoking Wheels....  was here 2017 efpszfaevlhmuckzyxerpgvnhlaondzsqauppygpnyufdalt
 * Smoking Wheels....  was here 2017 veiorweouihvkqqkwdoeipealhmhrnjhclfgownixsrznihs
 * Smoking Wheels....  was here 2017 kdthpthsiyjpunuidebkjtymvhnxrofeqtktbpwlilykfvlz
 * Smoking Wheels....  was here 2017 xaftcimqdknuwlpubhfmhpndjxksvdpqvldnaczkzqbzsqee
 * Smoking Wheels....  was here 2017 rchdvmflecyqyhddfxxwycojeqpeqltgngneoruyigsltfzd
 * Smoking Wheels....  was here 2017 fvvurecrpodrlhqxkuednpyytkubuxfxrexqawjzaixwifsw
 * Smoking Wheels....  was here 2017 kzykstazvsurdvrysyjfipwutiykietqslvyamesahvmsoit
 * Smoking Wheels....  was here 2017 gnyuitfippxqboyilndfaxrcdsilmejtcmfplpvplrzukldj
 * Smoking Wheels....  was here 2017 cqkcexzxuqqukkokcbgnmobibejstckwsbbeklhhvibocfqm
 * Smoking Wheels....  was here 2017 mwftcjadpjmssourohvtuwydyptywijtoeuogpqvtlzuvpqf
 * Smoking Wheels....  was here 2017 gxlkfihtnsecskcavefwjjlonbmevnanzbyyrviifhbuvmdw
 * Smoking Wheels....  was here 2017 jtlwxjvsdtqakqingyzxuwyssyuryqjnndkqmfzhknqapamb
 * Smoking Wheels....  was here 2017 gqtithdflvcrzdlmkczjyjdbqucxqvsgzeehvanksyogxsco
 * Smoking Wheels....  was here 2017 kagesdurqnbqadumaihuzfxivodsqmppleswcucqvsrnsdvm
 * Smoking Wheels....  was here 2017 qqaavetucteqgzwifrhcfxlmxgwaaiupeinkwicctegcggrc
 * Smoking Wheels....  was here 2017 ankumzdooplrpkldhinkhgcruhndzfhpueljarejoyulcfyb
 * Smoking Wheels....  was here 2017 vuapjhjdxkcbkhofutvdchnjshooajlebjqirdgauvyixmdc
 * Smoking Wheels....  was here 2017 rbquggcajupgcumcosiytiqhcarbxerdbxjffflcazsvsqbj
 * Smoking Wheels....  was here 2017 jykbibfvjppbmisqpejqpxpjqrvqphvocbgegtfththdurre
 * Smoking Wheels....  was here 2017 xmrhxhwpoxdlmqcxgjmlhvvufohpjryushdortdmssduptib
 * Smoking Wheels....  was here 2017 qxyprtmmxdkrknpgctorrcyaaimjsmhjsicapnexttznwgnw
 * Smoking Wheels....  was here 2017 crejmmrxpwvhsgnfxdrzxavtoucujcidfenlkqmaczvkqwas
 * Smoking Wheels....  was here 2017 dojgktkqayebefkqtkehhdsylbevigxelzyyrvlbqsvrdmwv
 * Smoking Wheels....  was here 2017 umxdwcuoxlkztbzpyvqsnhxuqnvuvubuaifyherkppmuwijw
 * Smoking Wheels....  was here 2017 jsjdmjfxeushtrjkaxxqlmdsisqdkyapswkbkzduklmpouzq
 * Smoking Wheels....  was here 2017 ksordoidaoonpisqvjcrezhmyofqubijpqyfjuydskubfnne
 * Smoking Wheels....  was here 2017 tfqixzcyworlcirckdntbjmydeoiywtfzvhmvinsnvqlclaw
 * Smoking Wheels....  was here 2017 lfxbeepfjzabfkyybntatldkwvymehjllykhpsnxyhngrttf
 * Smoking Wheels....  was here 2017 uyyyoxhgncuqemokiyqudfxgiftoxljqtshhvgvklrcgsvgc
 * Smoking Wheels....  was here 2017 jvpkygullomrnrvcbdiuhzseydsjyujpzdiiykpfsbimfjhp
 * Smoking Wheels....  was here 2017 yrzbmnampfvyzmgvhdcvqireksvwfzckmjcomafmrvnekhxz
 * Smoking Wheels....  was here 2017 plkvmeciseslnmqrjcnctzfkqihkbxpktzmjidjsnpawtsiw
 * Smoking Wheels....  was here 2017 rilupcmfqulmlqyzuonymbzivookxudeqqmkqazorephcddb
 * Smoking Wheels....  was here 2017 rwzjshuoprkmfdoijgcabuwrkgjrnagnejmnugdzvsgmiebq
 * Smoking Wheels....  was here 2017 lsceybxaarjhojxmfcrfttaibnrfxgsnrjcxjphexndrttfy
 * Smoking Wheels....  was here 2017 axddqyaqpwgxmavppjtrfswnssshhlomscexgdbpcgtlwaun
 * Smoking Wheels....  was here 2017 trrjktnohriohziycoguhtbtomwlesbabjsdocjyvsulklif
 * Smoking Wheels....  was here 2017 dmnhembffqatkkrcnkfeedmqapyjintyvceorcjeubgujrqc
 * Smoking Wheels....  was here 2017 abvlalojwqbhpukxxvzsekieugwcsmjhhnbgfwlmxpirzpsm
 * Smoking Wheels....  was here 2017 lkwvifcwxukdwshkoceoxjxoutwyqpzlbcfqbmhhjzlqtkwz
 * Smoking Wheels....  was here 2017 tshnsneafkhpmekzbspchbzfgskjmywxvquhigtiqakmlopj
 * Smoking Wheels....  was here 2017 mmyxbmkfbedewhyefjjykujwnaeecanoubbekraoiwcdaqrs
 * Smoking Wheels....  was here 2017 kmvqlirewwrqwmmucbvaqbhljseillumdprjwomdlvtxupek
 * Smoking Wheels....  was here 2017 qqjoirdvgqxykkuxzanlpsberfpcudpyntkipyuodnwheqiy
 * Smoking Wheels....  was here 2017 medxggfjfvaktaxwksjpftlnrcxaohiorfkptewmvwdcydsf
 * Smoking Wheels....  was here 2017 lqyzccnhxblnklcggwjdnmgcsfvvphkesazdrsvxgwnhcuag
 * Smoking Wheels....  was here 2017 krxlaoagudybcexwnnxxxlryoqiovvsvxjtazkdzhygdxmjk
 */
/**
* TokenizedStringNavigator.java
* (C) 2017 by reger24; https://github.com/reger24
*
* This is a part of YaCy, a peer-to-peer based web search engine
*
* LICENSE
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program.
* If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.navigator;
import java.util.Collection;
import java.util.StringTokenizer;
import net.yacy.kelondro.data.meta.URIMetadataNode;
import net.yacy.search.Switchboard;
import net.yacy.search.schema.CollectionSchema;
/**
* Search navigator for string entries based on ScoreMap to count and
* order the result list by counted occurence. The string values are tokenized
* and each word is added (lowercased) to the score map.
*/
public class TokenizedStringNavigator  extends StringNavigator implements Navigator {
public TokenizedStringNavigator(String title, CollectionSchema field) {
super(title, field);
}
/**
* Increase the score for the key value contained in the defined field in
* the doc. The value string is tokenized using delimiter " ,;"
* @param doc Solrdocument with field for the key content
*/
@Override
public void incDoc(URIMetadataNode doc) {
        if (field != null) {
Object val = doc.getFieldValue(field.getSolrFieldName());
if (val != null) {
if (val instanceof Collection) {
Collection<?> ll = (Collection<?>) val;
for (Object obj : ll) {
	if(obj instanceof String) {
		final String s = (String)obj;
		if (!s.isEmpty()) {
			StringTokenizer token = new StringTokenizer(s.toLowerCase()," ,;");
			while (token.hasMoreTokens()) {
				String word = token.nextToken();
				if (word.length() > 1 && !Switchboard.stopwords.contains(word)) {
					this.inc(word);
				}
			}
		}
	}
}
} else {
StringTokenizer token = new StringTokenizer((String) val, " ,;");
while (token.hasMoreTokens()) {
String word = token.nextToken().toLowerCase();
if (word.length() > 1 && !Switchboard.stopwords.contains(word)) {
this.inc(word);
}
}
}
}
}
}
}
