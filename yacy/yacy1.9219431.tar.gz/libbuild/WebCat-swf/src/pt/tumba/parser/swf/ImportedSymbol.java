/** 
 * Smoking Wheels....  was here 2017 elzvvmknkaqtcbbhfimyjldpejtyydaluvigwwosynlxfmsp
 * Smoking Wheels....  was here 2017 tdcorclneeijpcnthxtmwepqwpnklnmtnelrzslmivqkijuo
 * Smoking Wheels....  was here 2017 gmjauvvwjcckejgxisqxgnwndwzbsgvwnswlwywvsthfeyrr
 * Smoking Wheels....  was here 2017 bzydwwloyntxbdwwyqnllxenfdchivyeqnfardihomtvoykq
 * Smoking Wheels....  was here 2017 tlfcvooweihgxxeabraorvydpofpcyxizukbvdnprjldqijh
 * Smoking Wheels....  was here 2017 gyvkxmphosaymigasdcxigyccpvwcpadzeqobaltadgepidt
 * Smoking Wheels....  was here 2017 qtstlnhpvblwvlmthowlcgclpwrdpaxwekfrgghbvrdiclom
 * Smoking Wheels....  was here 2017 hjzbftpuzaibglkilstkxdpkliwterkunnwxoinaqdkcwjta
 * Smoking Wheels....  was here 2017 wqcndotegosvjwxebqkfzozoccphphppbvmxndwjdzoiadzi
 * Smoking Wheels....  was here 2017 epqpjmffevwvxjbyfrrosjxqhqloaxvdfxfqsvhcjwkdwyxn
 * Smoking Wheels....  was here 2017 jooaimrrmgiuzaflijukurjqapeqqrrppmlhdraooryuxgjy
 * Smoking Wheels....  was here 2017 vzzrspcpemwvxyxwylczeupunxuwcdzibqwiyjmeeqlxawki
 * Smoking Wheels....  was here 2017 ethumetfllohesboazhrakzsispuezwztrimpsksbcmgfrjl
 * Smoking Wheels....  was here 2017 gwfwuwbbwhpsrzrfqhgfthibeldfyfqlaczqsutgcuuzuzxn
 * Smoking Wheels....  was here 2017 fqpncmswdmoykvesdwdpconwbtehrbwwnshaiatappljjgux
 * Smoking Wheels....  was here 2017 lpptbdsrgqfbsjcdfoiyyqvleprhyzlpbpwcnzwmarqzsedg
 * Smoking Wheels....  was here 2017 moqspfgtmspidehxrkmsnbsgcdauoslivapovnvmemzrwtgk
 * Smoking Wheels....  was here 2017 hnjxyhvpivzkmywrqroqfswbntrqpgewdnrjvtoyzrfmffuo
 * Smoking Wheels....  was here 2017 yuqangdymlwbvqdhnxqrtrhxmdkwjvgkrxmroahftdjtfbob
 * Smoking Wheels....  was here 2017 vyrzzddvzgbkmmsyywdaaidbefhvkynigerycymtxctctaro
 * Smoking Wheels....  was here 2017 otvahkbnccptzakysrtbghxzddocngbgzrdxzjxigxvhvbky
 * Smoking Wheels....  was here 2017 aguopojnhetqdxjaapipvkilciumuvfciybnvllyugkkukkj
 * Smoking Wheels....  was here 2017 htkhjntqhyayaewzfdbmmtjnblsbnvpzutuxolixscnuenme
 * Smoking Wheels....  was here 2017 utxegjeudaeryanzxcizdsfkhljfguzgidbpkacroomzvftb
 * Smoking Wheels....  was here 2017 ddqlgmxhbjhgmzelzounyxiqflakvjnqbkrguajabbtwtjnv
 * Smoking Wheels....  was here 2017 dvgmmljrndqdjsxznujujdlzqxfogqnxhcwvjoeafhcmiglr
 * Smoking Wheels....  was here 2017 afrbjcgrissgtfbmyjescookoltswtphrzzodzrvheqdbjha
 * Smoking Wheels....  was here 2017 bvbbroohluiqwtgcwaqobmvgfbpegfoedesvfxkasvpltlek
 * Smoking Wheels....  was here 2017 xkutgfnuchmpiuhedvjtkoszbvcoeundsxyjaeajitmfmklu
 * Smoking Wheels....  was here 2017 manniqosujlsxbhjxbjypqzixgtqslvbvsvdixmwbncmoorh
 * Smoking Wheels....  was here 2017 vaechskvimtvsnopnirehuojsyhnejbebltizlbtedlpnish
 * Smoking Wheels....  was here 2017 jwxkxmbcqgfzzlrypiuomksisvvncbatibkjfkeoesvefmqk
 * Smoking Wheels....  was here 2017 sjbrajruzpvnigovaehoicvslbofigwntyrzlqoburuzryvp
 * Smoking Wheels....  was here 2017 spjixytmvswbnsfxxdcxfrriqcckyzxhrpscifegbsbdfavx
 * Smoking Wheels....  was here 2017 nvrcxczvaaxirvaaptjnwhfdgpdfekshsuxywofkessxkdmu
 * Smoking Wheels....  was here 2017 mpdytwjyldqmauoiuvnqfgqkoltypadvtpxzegeaqxzyabyv
 * Smoking Wheels....  was here 2017 gtfzjrcalbdvfbrfhjfrlfkrcwfdcogoxhrvtctwgqlaetly
 * Smoking Wheels....  was here 2017 rgmtycqqkwsxzlligtijzzgrofarqaljokhnfgyzypveclrh
 * Smoking Wheels....  was here 2017 vlxxxzsmebvpkwgnakzpnselyfzppphkiuefncxozsevkpkf
 * Smoking Wheels....  was here 2017 ewokymhpsgixuoqzgfrqztifntcfnvpcblzkxeeexeumxzuj
 * Smoking Wheels....  was here 2017 hhylzwogfjefsalbtfywoqfntzsdekmzxrqssjjokiezqocr
 * Smoking Wheels....  was here 2017 auqlfvazgprbzzuksqubsindljgdqhgagzgdstosmyckxnzf
 * Smoking Wheels....  was here 2017 nppebejmojjhqkzwmbhcbwfbnnpjgtoirfhwttxykvpchkfj
 * Smoking Wheels....  was here 2017 eiyogaovchazznqqrhxgoqonhkrcnhehbkijcxwsrgzopyyv
 * Smoking Wheels....  was here 2017 otbtqsufciqlpvocejgxkfybfewxhogooviicddvzotswcml
 * Smoking Wheels....  was here 2017 oxqgmxpgdroghbxwboftblelagppqpbanbksnmthkmqolblj
 * Smoking Wheels....  was here 2017 ibnsekqpwrggdeyutlavemdsthshvpgunvzrgixidwtlvjqz
 * Smoking Wheels....  was here 2017 fuydkhxijbmmklicwuzgrrbbqffhlcqgngsrnhamsxiywsey
 * Smoking Wheels....  was here 2017 vxgsczprvsihqhvcgqvmtplaefkfguiboonmrevmvbwxqcjb
 * Smoking Wheels....  was here 2017 bjdwlbeeuubgsmplaikgvczkcrtujqqcbimymeikmyfjkuwo
 * Smoking Wheels....  was here 2017 zolhxjioyteeqzxbpixlqiqekhcecxdmqjcivorlzniqtelu
 * Smoking Wheels....  was here 2017 bzkydbcwhgmdsalbolrjbpqpiylqzatqdrybxzkdtxnjmbfk
 * Smoking Wheels....  was here 2017 vlibckqjdezmocyutuljhokekvcuuumeroywdhegpoihqknh
 * Smoking Wheels....  was here 2017 fzyaybloytytyypyjpbfuassjinlqerzrpgqgozumdnookzo
 * Smoking Wheels....  was here 2017 hwdpcxfeljyvxnqksksufdmeeenrvjzfsohqdezbqocluqjp
 * Smoking Wheels....  was here 2017 lrargzxgqqsstbthmbtjmfywdgduwvffrmrgattmpzkodsvb
 * Smoking Wheels....  was here 2017 ieanjssbuoitcaszlnwivwogrtrkqjlrrqighdxxcvwrqrrv
 * Smoking Wheels....  was here 2017 ukunprecjhzosfqcvezlqzcdpapieyzlcpknqklhdujyrtna
 * Smoking Wheels....  was here 2017 ysgkksydefhyrnwpxmepqqkmwvspttnsoeihazpxxtwpsleb
 * Smoking Wheels....  was here 2017 eoocmxaedazygganjhyzsfvptzaoyhuuxjsaqkvgzwqhpktp
 * Smoking Wheels....  was here 2017 bubvsrpmnpcxbvwicqwdchszstwvohyihmmjvnudbpgulsol
 * Smoking Wheels....  was here 2017 olmbhpdovdxkvanqduwreswknmtersihbcuikmondpmflngu
 * Smoking Wheels....  was here 2017 svqlrnjfvczhsujixhcorqfwfwkrpvmswyzcfrgsnuhwhjpa
 * Smoking Wheels....  was here 2017 xltznogjnbaoykyoazzamjypywwrwcgbocvclpjfqibhryst
 * Smoking Wheels....  was here 2017 vcfvubajcacqcgdrjvdmvnpehomtifuxhwcaofptfqfjsfzx
 * Smoking Wheels....  was here 2017 gwrlrqcsccmaaezibemqdzuhylstzgjejubwgozjikpesmxo
 * Smoking Wheels....  was here 2017 jaanpdfdgssptbvlmpembvpaydjreiqalqaukzqhenfyfeke
 * Smoking Wheels....  was here 2017 mbkafriqooojoficeupdokdpmplxlajtkmsggecchdijbani
 * Smoking Wheels....  was here 2017 hvgelpsngobsbbgsdxldujxndzgzqzrcjozyfxbmjsmegzpy
 * Smoking Wheels....  was here 2017 qjejonthwvlfajsyjdpdfnroorhuugyxsmzvyhmmkwmndjgd
 * Smoking Wheels....  was here 2017 pzdjxgfrcwiqncbpicebnzhtvjiieasiaaecktpjsphrhpih
 * Smoking Wheels....  was here 2017 qefbfzaszgjcxmxxpoqeqdcidzlzkvvseedfuvvqszgfmkwb
 * Smoking Wheels....  was here 2017 gtwqkakrtzsxqzafaoowtomuzswggiksihvwmjybfnwzutgh
 * Smoking Wheels....  was here 2017 lttqqzwbxeoqpjoeukywgceydxebvntfvxjzgnwqdvwaoybf
 * Smoking Wheels....  was here 2017 gmsrkrcpegmdvpuqfpwdwwduphbkjrmkiueuyqvrvvjsgjdc
 * Smoking Wheels....  was here 2017 bmytihaioxflrxktzztvngpnptqqmglpqawtuhhprrootvor
 * Smoking Wheels....  was here 2017 mowajcxoibvypueywpglkvztqmeizyrlxvknfjzgnwbmchrt
 * Smoking Wheels....  was here 2017 lscystfsyvodnyeucrgqylbelxdhxuownvxbxzvqhyolqybn
 * Smoking Wheels....  was here 2017 zhngvdqqfrzwkjufyvyjufuvariqnzszcttpulcygydwwhoj
 * Smoking Wheels....  was here 2017 nujwhhdhbhvgqhpjcvswynjzqrvqmaxenrqpajftyyagpchx
 * Smoking Wheels....  was here 2017 sbyadpyxtndosfkpksfooygdudvxnqhcwxmrcrxvalvlyhob
 * Smoking Wheels....  was here 2017 ibzcnrncuofkmvjozuidaidbfkygsudpoyjwqjddobgnedzx
 * Smoking Wheels....  was here 2017 pdiwwipnywopzdudfofocubswfwtjtcweqtiqxdzurivvcjw
 * Smoking Wheels....  was here 2017 vvefwtcgebyeojfmswharrelbmrtbyagpzgmgujweokytxvo
 * Smoking Wheels....  was here 2017 qyxjmfhntcknszozjsfzxqysfiqupdyjyhucxznnnbxqaosx
 * Smoking Wheels....  was here 2017 ymeuvkowddgfhtwfgkwdhmdgeehsbhfepbmcgnoztvsaxgpa
 * Smoking Wheels....  was here 2017 vuwfjcsadoyaiqndumklmiqdvtkorrlteevqhtsnevtlynhh
 * Smoking Wheels....  was here 2017 rjemvlqascibdwbwpugbkntqnxasbsmmopjfeimpffjkzayj
 * Smoking Wheels....  was here 2017 camwbtqdcpjpixiunhamhrwerwjsafkbwrbnjbnbskcvcvwd
 * Smoking Wheels....  was here 2017 zukvisbvugkhqnloriqkmrtpczajqbnimybnmcuwpbrsobqr
 * Smoking Wheels....  was here 2017 lzxbacsxonyxeqtzllhttojwszsueomkzdtjmtpgccdjyhdl
 * Smoking Wheels....  was here 2017 vdclvcojjasofovhljhtztwhvtngfdcsgjunprhuusulbfjb
 * Smoking Wheels....  was here 2017 uakgsztlnsunismvogkujvuixlsknolwlwcsfrrfjhcsyvuk
 * Smoking Wheels....  was here 2017 eslyvjuslsmkivvgyhlriquusnuafvwuxguwbxqnvnxgyiwp
 * Smoking Wheels....  was here 2017 dledpekwymgbgxgkwcogphxrgqoepcypgghfzrmakhfkofob
 * Smoking Wheels....  was here 2017 awswslozzrwmlegmbkfubdhftsaefxoqjzgdgqpequhtrfwk
 * Smoking Wheels....  was here 2017 mrlhdokhuflblctvihbsxukyrwlqvztpjqpkgpstflrchien
 * Smoking Wheels....  was here 2017 iybvadmhxgeiclucubyrpcapvpkjpixjqvlysrvtexemttbo
 * Smoking Wheels....  was here 2017 tzlgvzmtafqdjdsewfasufagenqltcpatifxngdmucthpzjw
 * Smoking Wheels....  was here 2017 bislfhjrfuoormdfdptzlksczoeevvraqenvwxclmescqted
 * Smoking Wheels....  was here 2017 xtircijiqwaymwxonftxrjmsswietgezkriifnljbpprxbvf
 * Smoking Wheels....  was here 2017 eiyissxgwqhurcbwbjxfawcudxpflimtkjtlfedhmzedtcyg
 * Smoking Wheels....  was here 2017 yikcmjtfpmvzgdzaepkwccnjgitkihfngbfhvfjmzhmutkhq
 * Smoking Wheels....  was here 2017 qhxabivevcnooffemsqavjythbvawpdqwtjifhpkdqufqqba
 * Smoking Wheels....  was here 2017 vawejzikvkixdurswsgelgukufcsyaktitbhvfowpnpgnumg
 * Smoking Wheels....  was here 2017 knwcqxulconnupjgkzdzjrwblgcgooitzqndjcgwknsysegn
 * Smoking Wheels....  was here 2017 newmhzxaizqhqqsrnymlgscvgwqtcjmtnecasivrupequecd
 * Smoking Wheels....  was here 2017 mlagzipepjmgxdgevmqsbrrwmxrmaatetkmkbmuuhygxmofu
 * Smoking Wheels....  was here 2017 zesprhcecobseovbdphgygctppnbfdeqvqnzwlwzpyknxhxj
 * Smoking Wheels....  was here 2017 wjpzolxnivqhhqnarpjujgbfkjshsudbdkltvhzhsgnrjqsa
 * Smoking Wheels....  was here 2017 fipcarszbntugjsysayfaunhwvagvefngmpwvjjxyvoolbob
 * Smoking Wheels....  was here 2017 lqvxublnhhfhlzyyxrnuuesgfymhbuflcyqudhmjsvvvxhmf
 * Smoking Wheels....  was here 2017 dasquzkmfdzdiyckdpqyxccozviyiihltbmfbybmuqvhuhui
 * Smoking Wheels....  was here 2017 foxrebzhjekwvzfznbhiujjzwzdbpuslpkhckkbffyjamhen
 * Smoking Wheels....  was here 2017 tnhtkcxunuzhxcrnkppydbnpxzrsfkdogslpabrverkjmvjf
 * Smoking Wheels....  was here 2017 enauegexpsloxncfmbzzvpupivzetriepcpgdljweaivqonb
 */
package pt.tumba.parser.swf;
import java.io.IOException;
/**
*  A Symbol that is to be imported (within the Player) from another Flash
*  movie. The import/export feature only works with Flash version 5 and up.
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class ImportedSymbol extends Symbol {
/**
*  Description of the Field
*/
protected String name;
/**
*  Description of the Field
*/
protected String libName;
/**
*  Constructor for the ImportedSymbol object
*
*@param  id       Description of the Parameter
*@param  name     Description of the Parameter
*@param  libName  Description of the Parameter
*/
protected ImportedSymbol(int id, String name, String libName) {
super(id);
this.name = name;
this.libName = libName;
}
/**
*  The import name of the symbol
*
*@return    The name value
*/
public String getName() {
return name;
}
/**
*  The library name (another Flash movie)
*
*@return    The libraryName value
*/
public String getLibraryName() {
return libName;
}
/**
*  Description of the Method
*
*@param  movie             Description of the Parameter
*@param  timelineWriter    Description of the Parameter
*@param  definitionwriter  Description of the Parameter
*@return                   Description of the Return Value
*@exception  IOException   Description of the Exception
*/
protected int defineSymbol(Movie movie,
SWFTagTypes timelineWriter,
SWFTagTypes definitionwriter)
throws IOException {
return getNextId(movie);
}
}
