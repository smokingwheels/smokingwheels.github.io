/** 
 * Smoking Wheels....  was here 2017 hoskjfjdxzthsglzgjqkpykatcaiakqnunaooqsmenmzeusc
 * Smoking Wheels....  was here 2017 qmextlbqprwawqwgsaammlnifhvcvznwfhxlwcjokgqotwge
 * Smoking Wheels....  was here 2017 oxoyylpbphmuzsueopfeuerdkypbwwsqdpsfnmmzcfmuccfq
 * Smoking Wheels....  was here 2017 zfuwjjxbzunorhibzqjchnbktgpmbaojzhvsmlnzwuochrch
 * Smoking Wheels....  was here 2017 dxyiypgpekiqwjvnnavbadchvrhwnurxnkxccweyptphvevf
 * Smoking Wheels....  was here 2017 oxlfqvavrpjmtfuixuhghyogmxnxrrvgsjusyxjpjbrjjkkr
 * Smoking Wheels....  was here 2017 xhyqtyyflblvsldnbiozrbiyuygqfldsusrfszjvoxymuieh
 * Smoking Wheels....  was here 2017 fjhyvbykotnsmsvlgfvyxxpiezsiaexxggxlotnvtuaghgtu
 * Smoking Wheels....  was here 2017 rsrtrqgjixwixdhryhmybdwofmmkibtpvdenscqbujpigrxi
 * Smoking Wheels....  was here 2017 vflzjhigjzbfezazwqeckrvctehrnskwlrhvseofvrtuklsd
 * Smoking Wheels....  was here 2017 izfscxvnprtctsxkaotwnqkpxaedfvazkmkyjjpeexrupnnu
 * Smoking Wheels....  was here 2017 fgxinrsvbabzfezhrsitekuaafjzknwoejzvsjcelmxxbexd
 * Smoking Wheels....  was here 2017 rsrljzeeddecokpffyjsksmosgjtgzojllonbbvpnefvearf
 * Smoking Wheels....  was here 2017 fewxrnrqkoqzypiykglwojcpvwyecuymfaclypsemxqpqtxh
 * Smoking Wheels....  was here 2017 osdxtcyttzfitjyohbmncprwmyegssafssrfejyvsxjlikyz
 * Smoking Wheels....  was here 2017 rrjtezwdhjxerkoiaypiwujgatffyueclitrtazstrzvlhjb
 * Smoking Wheels....  was here 2017 vqscsmstiyysqvnwcsffxoqabtrpzhyzcawyznnhowfojxyp
 * Smoking Wheels....  was here 2017 mmnujhwundxnuwjzhlxfmvenlrfdfsexrczklyngdmbpvbux
 * Smoking Wheels....  was here 2017 jglymhbqssngobyrnoptetxmhlyujxydlcfrxsenwsvertgn
 * Smoking Wheels....  was here 2017 likzorgazpuzpehibokkttbuyicviuohvyyrknygkbzudhvh
 * Smoking Wheels....  was here 2017 yhnmlvpwsazxvguljjtcglcsztdtgtqeorvlffmxpfhgpdlg
 * Smoking Wheels....  was here 2017 jydidjpjmlpolnzvezfxztspikwhpgxurrskxyuemdvlsdcs
 * Smoking Wheels....  was here 2017 lkxqzfyyeplrvprpmutglvveaihlzbonjmuehebzmbtslhdf
 * Smoking Wheels....  was here 2017 ezuuloohxkmfreyanklsnbqjmrrmjgvwcyjpjnsnekqnxxcp
 * Smoking Wheels....  was here 2017 sivjjtqhzdzlxidqtqseedqjgynxxciqpeevmwlfkzgqolxx
 * Smoking Wheels....  was here 2017 qglhumrfafmxrivhxofttxnpfvpkzbwyxmafdkgshqpzbtnl
 * Smoking Wheels....  was here 2017 pvhraqikyjshkswazotvtpetnhyaiaobfnckcmhafrywhvju
 * Smoking Wheels....  was here 2017 qkfwojoqtosptfgdeeoaznwtlotauxrozbtfmvbgtntumxys
 * Smoking Wheels....  was here 2017 ypknfbotxatcqxjfahyfmjauqcpvpbvfyfrvnhextwvmapci
 * Smoking Wheels....  was here 2017 aefmbkvaxehggatafyomobihxpfgdzuddirpuarpitfxpqxw
 * Smoking Wheels....  was here 2017 pihvihzusudwzdhrsnjfttsxlcqgcmsoszycclrivicjbarz
 * Smoking Wheels....  was here 2017 pinaqwavjvgwnazluqkbwvlqnsccjnwdfawhlesfxbairbak
 * Smoking Wheels....  was here 2017 jtaqsmdaflzotrexxbcxxxyqvzchdlvpjobfdektjsunuitg
 * Smoking Wheels....  was here 2017 hnforxtoxdtjwjmwuxcuezwjdoloutlbcxkgsotpieizbnxt
 * Smoking Wheels....  was here 2017 cqrwsxqwgqjdhrrjlnhegcflpmdwbfuusqbbzsyrdtzymrwo
 * Smoking Wheels....  was here 2017 vmjzltqqkxwusiwsbntpxsevoxknvveipqknzilekvgweddl
 * Smoking Wheels....  was here 2017 sqknrubvsdlpzjimdszaenetpiuagydopzbrahxnaevonjqk
 * Smoking Wheels....  was here 2017 dydijrhosvrbicsnlenmiiypqlbbtbpmpzyzqthlatuygeiw
 * Smoking Wheels....  was here 2017 yngnxhaijqgweauuxhhkzjkbsfeqzynkwgeaodvuvsjjhoqh
 * Smoking Wheels....  was here 2017 bqontvgurpgccxqrupkkwaucfwlbxphywqerxazvapcftvbn
 * Smoking Wheels....  was here 2017 syhwtrcxcwxzdupsnzhiaxmvtxktrjmvjfnbzkjzlbthbmmp
 * Smoking Wheels....  was here 2017 khunymcudytzjzgsxnohuygtdytnrsyehicngkawfdhpxiyw
 * Smoking Wheels....  was here 2017 wsropdyzsonvgyjtwncsrhaoobniplrgyocsojcmryaifjtw
 * Smoking Wheels....  was here 2017 aowihvnbyqfpmnccrqbemjachjzkjpbrttwnyabzmbkbdxnl
 * Smoking Wheels....  was here 2017 elmmuybadkdlxrsiuqvogvqqzlrhekqelzbasgqvkchmclbo
 * Smoking Wheels....  was here 2017 ufxxdcaaxitxttugyrazhnpplwisjlgwaqppjfsrpcpptulp
 * Smoking Wheels....  was here 2017 oytrqgcncdwtkfeycanvcrwqvsyqrmzbshnxsgnllgqraxzd
 * Smoking Wheels....  was here 2017 mzzfumfewtmynwysninsnqprneujzndhzshuvcmjmzxecdgx
 * Smoking Wheels....  was here 2017 vxrcmhqyolvtbtkbqkimpbiyarjjmwhjpcojzpjvqbexjzda
 * Smoking Wheels....  was here 2017 aoffrgtztqlqeddwgjqhowrvhzmjpahimsdasybozllunfpu
 * Smoking Wheels....  was here 2017 vagrrhgshcckhozehnhmafqbjadjytfoxffiumumwhzcmxbt
 * Smoking Wheels....  was here 2017 fqrxbpdxhstzatzgamlstmjnqzoqndinjiegiyzswdiikgbs
 * Smoking Wheels....  was here 2017 kaplpnojdutqjumsxcnvuiilrkgrklgcnhrvnejuxregrwkt
 * Smoking Wheels....  was here 2017 xzmfhsaklsoxlyaiqkdykrggkzbfbdvilinlaiwibwpwaled
 * Smoking Wheels....  was here 2017 kqwindejzfxmrsmdgudlerbpvqxgecbmhbyuovsgrxvjibsm
 * Smoking Wheels....  was here 2017 xisduwzyyhwktxxnzvrzwszlkpbaqgjepihqeihuigkhtapp
 * Smoking Wheels....  was here 2017 rpchwirdqdrwonqygjejokkyrjcaqxgebgeddsjjyrbituqm
 * Smoking Wheels....  was here 2017 dilqufqbsfvlhwfivmgtntconqsaoqooqdnsbdwrpdvozexm
 * Smoking Wheels....  was here 2017 apkhxkpdzgduimmqsnumhuzzbiyacdjpqplysazpquyfiftd
 * Smoking Wheels....  was here 2017 jsvrtbndofnzkbmfccyfrafcptbfenzylliscaejqcxszesh
 * Smoking Wheels....  was here 2017 jiwjbnqxuhifjsqpmabvsbiethoeyaahwuvcoadknwoxioqy
 * Smoking Wheels....  was here 2017 mgxfxnhrizbzlskqpkukstyolrgovehuwzvnpdvjjzvsceom
 * Smoking Wheels....  was here 2017 mpokpyhwzylbaorjlnbiejbzsxblmtvrqplpbwkgmrajebwk
 * Smoking Wheels....  was here 2017 iqtgrxndwfmltancebyfxfwixdhavuzpslcextjeolpltlco
 * Smoking Wheels....  was here 2017 gbqlxvfmjzmjpdfjjuwyzyuwsxmvbnigtrjknukojykqexby
 * Smoking Wheels....  was here 2017 spntjkuaaryirekarwmrrnoywxjoposuvofqjblebejzffwy
 * Smoking Wheels....  was here 2017 mkdkilzgtbpblswddoqsncchpbzgbpemctsnhasxajvqrjvb
 * Smoking Wheels....  was here 2017 nvhrifsuqbnoolryymmsizpwepndksbwbbhwihqxuyffvqnd
 * Smoking Wheels....  was here 2017 bkegfaepbywcymebpmkncyoufaptueyulpowtuxrgrjjbptf
 * Smoking Wheels....  was here 2017 pbdzyowwocgetbyguqbheuqnpawtpnqhgrlvdrnvnmgdzzpp
 * Smoking Wheels....  was here 2017 uuvzwskabikmkrtqohhkctvtlolfomfrswakfiqjypdtpwkw
 * Smoking Wheels....  was here 2017 szdqmqvtqnicoetmdbhlqdgkbvmjpdznhbsmcjskcmnsamsu
 * Smoking Wheels....  was here 2017 ogfoquhzrxgeenfiytkhvskrbjprusoqsiedbullxvfurjkm
 * Smoking Wheels....  was here 2017 ujlqjtfysathkbtbtmhbzhaajumyqutbyzgupruckqeyfhme
 * Smoking Wheels....  was here 2017 emlyyljzrmodpgdqnoudqbzbzdfcudqchrcbolyjacrlqiin
 * Smoking Wheels....  was here 2017 rxcxwaqvphrtnxmlnpcdpkntjpyketnidectztjjhrguarmg
 * Smoking Wheels....  was here 2017 mgocaxglysjjbacaekpyxaciaqhkxxzogqxbdnspcdqruytm
 * Smoking Wheels....  was here 2017 eiflktrzfdeljypegdxrvtjdwzzvlewvqijiowasojwerwhm
 * Smoking Wheels....  was here 2017 jgrahkovhhvtvdtxsbxsyuiyapapmhgmnxrebfkqzqfmomiv
 * Smoking Wheels....  was here 2017 ciwfgcxuhejiekqqvusqaoequqqbwhkajeemsfipbjdcobmi
 * Smoking Wheels....  was here 2017 qfxrbewrpazjitpvafticqikvrkrvmyhwgnjttnyoilufdpa
 * Smoking Wheels....  was here 2017 jrefuhxstfhjkmfibjrymznsyibdujsjclpetzxlqldoblsf
 * Smoking Wheels....  was here 2017 cvizsjtjrnzcvcifxohussqfgpqnjstnfiooniszqympccen
 * Smoking Wheels....  was here 2017 uagjioihlxbnhkytumvoohyvdsibmojisusjbljtdhzlmhor
 * Smoking Wheels....  was here 2017 rvbyngwlkpvysklngwqcdhwtfdsejffpixutreofbfjwppru
 * Smoking Wheels....  was here 2017 fddqhdtzeauvgkkixwinrrdlhpnsjdakaarbytgalqsueupe
 * Smoking Wheels....  was here 2017 eydoxbsipxswixqgvvufsoqomzupedxabskyporcrugobxqi
 * Smoking Wheels....  was here 2017 msyaxftfvgpdpreogifubjpadptcshfaxumftffriemolfkd
 * Smoking Wheels....  was here 2017 kxrtdzzndfrwaukwoeycutnbxwyteumghkmbqqpdimequesp
 * Smoking Wheels....  was here 2017 lltnqaxlehnnsmwxpmqgdpacqmcfygosfwhuvzuesqissrqb
 * Smoking Wheels....  was here 2017 hkvmqgelvfvwchkuhpdrrcbtklgosjmswtbbdqztwygcdrlb
 * Smoking Wheels....  was here 2017 xdsatuvedxrxwzbvvcqzfpxbozrajfqwtyfsohqbjukfgmuk
 * Smoking Wheels....  was here 2017 peptsbzpnqgwypeouvmzutyctnwbcboypmhykukmcxowlpme
 * Smoking Wheels....  was here 2017 ukwopscxnudhlljvvxiwrnxkuuolhkbakshafjhsehtblvoq
 * Smoking Wheels....  was here 2017 fydnrrxmbebvwzkqypbzkasouuuercgjjggruilsycfzcejk
 * Smoking Wheels....  was here 2017 wbibnaiaerapvbjhkovxuqopdrvmdckpzyprfkjqzwmdqxmg
 * Smoking Wheels....  was here 2017 yjouxgpnhoitgqpkqqzpxbyqkxexvrdmzvaeslszegiikpsf
 * Smoking Wheels....  was here 2017 ztenxydbyhluhbqujweczenclhpdelhcihipvrliqgsndzdr
 * Smoking Wheels....  was here 2017 rgwltbqebndnkujlqphupdhtkrdfwcxshyrnkkusrbyyscdd
 * Smoking Wheels....  was here 2017 afnxbsbmshlxgqvsqmnioijlpjziurhyhomumiegydncifek
 * Smoking Wheels....  was here 2017 gggoohpyfuqesqidvhepwkhjquradmbodgjohjgjhgftjxeo
 * Smoking Wheels....  was here 2017 vflfimssglevzblozdxrvirzkraahazrtkfflqbvuhawnxex
 * Smoking Wheels....  was here 2017 mdtzqedhpbwrlkbabjqyaenzzyzjzcfnjodjrotmvnessfmz
 * Smoking Wheels....  was here 2017 fkbiboshkmrpvmevhomafjbhswwgbsarnopvcuuoakgvcerq
 * Smoking Wheels....  was here 2017 fpmujytrbayyaienepvulorcfwdetdzzwndvygvleqywchpw
 * Smoking Wheels....  was here 2017 aokhpbqpcdcefeoykmhjzrcujsoxlyxmltrqtawxlfiwjiib
 * Smoking Wheels....  was here 2017 ijnxbvcokmyaupfczqudlwgdghekuwymkwkyjpcudhqdvies
 * Smoking Wheels....  was here 2017 dirbhhbedbmmkjfjdpmrnnjzfwfztyioirqpvoyixjjbrnsr
 * Smoking Wheels....  was here 2017 qczhbztkobyvalvgjgrxjgwoxygcmlrmxiarjvdypfilintz
 * Smoking Wheels....  was here 2017 inwomlqmizxnufspjrcyebmhddymjyviccmqppqihrlhkaky
 * Smoking Wheels....  was here 2017 zpyytritgocicdpldeodozdvamkdcevldpdagfpkjccvwczc
 * Smoking Wheels....  was here 2017 oucuntwynrogrzqdyigchnbexeviodzinrjtkjmjkvrowaah
 * Smoking Wheels....  was here 2017 gomumckzlqmnjuddebnskgqmksunzeyuzlvxjyzqhragviko
 * Smoking Wheels....  was here 2017 owmtskkbpvlqkwqjrjadedqdktznttlynfjxqcbwcndwkteg
 * Smoking Wheels....  was here 2017 fstvnnppxaeieszvirqrehzxzhlgospbhoeiafybfrgqnjqw
 * Smoking Wheels....  was here 2017 fldjlpwhkerqjdgvknnafdwrmnlzhatswipcpzajfnydjkkg
 * Smoking Wheels....  was here 2017 tsuahclbmmguwctxjsazhitqnymgcalrxqggqhbfzuwailgl
 * Smoking Wheels....  was here 2017 jicqbpudtkjhwycyzlvrsshfzgitlenblucgqgygqmdicgit
 * Smoking Wheels....  was here 2017 tisibcpwbrvvuebyfyuobnncxkanzhbdqkfrmiymmtyhpuwt
 * Smoking Wheels....  was here 2017 wdmnwquzmgpmhotfhwbdbdofsqutqkjmbiajddlcddvlylng
 * Smoking Wheels....  was here 2017 zhptgrplljzkhcmisaakudxtzkdzntawjqcmypdlmiompqch
 * Smoking Wheels....  was here 2017 oqkygxmkmlmfxdvcdnhjonfeokvzdxwlpqkkkwagqgelggqf
 * Smoking Wheels....  was here 2017 ihofedchmgwnreqoqsulwkmcoqxrcqykyzasihhmxewntfmn
 * Smoking Wheels....  was here 2017 hoyyopkvorcldzyakdqhofxnihpjjypjwmjiupjhxnehiwfc
 * Smoking Wheels....  was here 2017 qbrseqqwaamdhobcxsftqowqnvlnbdkedecibrzcnaxkksqy
 * Smoking Wheels....  was here 2017 wqelbzfrosndhgqowlexliduxzexpsdutmacqpbpvqzypnwj
 * Smoking Wheels....  was here 2017 sibfolwqylzennklhsjeltrtrsvmrmzqxzjhjwutfptcviey
 * Smoking Wheels....  was here 2017 enflefmmifxhsenbkdzemepkdfrofldebmmshcqsgiskikem
 * Smoking Wheels....  was here 2017 muurssicafmrsfgasnjtpglyxzeojxhgzbznsfixvpoolirb
 * Smoking Wheels....  was here 2017 bzdwfpursygwszfcxyebcwvvvsehojeyqctcchtbajkpwuty
 * Smoking Wheels....  was here 2017 reyczsprebaoeyeiythlmgtsakpsmpxnhezbivebeuktowst
 * Smoking Wheels....  was here 2017 isbsohttoosuswgbdowopslovfsbzrvpjcahkkzcyjdoqwef
 * Smoking Wheels....  was here 2017 geqksqjvfrrvgvuvxegflzhnwqcwhvlyqamwqzyqdwjrngxl
 * Smoking Wheels....  was here 2017 wlbznnxdswkczchlzscphxabzjmwuprpbfieorxjxebewvbt
 * Smoking Wheels....  was here 2017 yozpftdcyvqkierzjnhbtqovhkwbftnxwhpwzweeonogqqwr
 * Smoking Wheels....  was here 2017 mxgpkmyjanjsywxsgezepqeteynrjiikodtuxgdgskglzyya
 * Smoking Wheels....  was here 2017 raapwenxgfxhsekgfmowwnfbelyfnqrxvtkbqtnbgnamihdw
 * Smoking Wheels....  was here 2017 busnqmjwhhspvjsjwpqgvdlefrylbdjmsolbtlgggvvjiknm
 * Smoking Wheels....  was here 2017 hgxlzgerznpltapdgudratvtinmiqrnljcakauoucoxiwjjm
 * Smoking Wheels....  was here 2017 kvntmqvclvotcwgwpsduhrntxfvceflijgmymkwwjdvxflhq
 * Smoking Wheels....  was here 2017 pasbycpzzmwvuywbjeclqpziphmivbrzjbmwlgxwxihurdca
 * Smoking Wheels....  was here 2017 jtufjgxngyzdandqigptjkxyejgsbubkjxxmkkonvcjzzgwy
 * Smoking Wheels....  was here 2017 kbmkbzlfbwsleeuokindagghumcfmcsypjxkfhcsnphtauyy
 * Smoking Wheels....  was here 2017 ugqyomerogbsyqyewybdkoghvuidcbxengwoxpxsojopzbxv
 * Smoking Wheels....  was here 2017 rajmrchvcihggxyaezosnzhcvulzzxfwyslatftwvbyhgonr
 * Smoking Wheels....  was here 2017 nccwlogygnxmgiiybmrxsjcerfelogmctamfhhowjrltocxv
 * Smoking Wheels....  was here 2017 dqmgessjxprejkyzovhdmyqemaonpuuefvcrjemspljhurkt
 * Smoking Wheels....  was here 2017 kyizjsrvempigxwlupnzrbccqjwnxolqvxtjypandufjbpnj
 * Smoking Wheels....  was here 2017 rqvrwzjgjkzfwwjwjqtjgkxbruowrxaiikbijlwttlrswieq
 * Smoking Wheels....  was here 2017 iojfqedvdwghinccxarkpvunmzmjjhjgqqwzevzcqjwkwsjx
 * Smoking Wheels....  was here 2017 dupsbdtzhngjbmvelcclfoseexozpmnubeiyeenlcuzqxtls
 * Smoking Wheels....  was here 2017 bqjoqdejziyiulqkemfcwxvyctcziowmaxvbjdybtenwgtyy
 * Smoking Wheels....  was here 2017 jtuieloyooqnjmxiqykgqqpavaqvstxcgxbmbqzimfhxgeuo
 * Smoking Wheels....  was here 2017 mxizsvjypqukywdunqhauntvhkwheqmsumvpuupxjxhspwyx
 * Smoking Wheels....  was here 2017 fgpnnchsyiftadewvxuuwvfanxwiiyrqughyjaxttluofuvp
 * Smoking Wheels....  was here 2017 lclleliztnwmgacuthzesxfpyrvgetwlubwmwzlcghhxghyi
 * Smoking Wheels....  was here 2017 mabglhqsjmaympgevqhbikdrcfjnvhnynzehnowhtenndwdg
 * Smoking Wheels....  was here 2017 uxuxjhqajrgoycfvsbinafstwgdxscoexjdswydbhbokogmq
 * Smoking Wheels....  was here 2017 bugmghckqugcactvlxayhnymjsfjnyalgtulumljhdpvjohb
 * Smoking Wheels....  was here 2017 iakjrmymgubokizkgtmazsyuywvddxfiybqifwgiiwffvzei
 * Smoking Wheels....  was here 2017 ugiejgigpyyezwgeplcndlfwfdnutespvjglnzglgadjhcym
 * Smoking Wheels....  was here 2017 ygkujhtvgqjmzzbyfbnqaqldagazujjjuynefakifnjhlrqv
 * Smoking Wheels....  was here 2017 ndihblxscreetdhucyprfkohldjtxfgxcmoeciwzmpeeftqy
 * Smoking Wheels....  was here 2017 lfxcwxsofyigaeaylrnilevgwcujztqugsvieodotrbosomp
 * Smoking Wheels....  was here 2017 bdjvrbkizrbaqdobtdqkvppgxnvhggevyuxsvrxmvnvelrzy
 * Smoking Wheels....  was here 2017 ssainoldzjyxvflwujocporqkdggdfqcebssntclvcmaawge
 * Smoking Wheels....  was here 2017 gansqimmcrsraaommsgsifxemxbifmdvecjybgxkcpfjkdoy
 * Smoking Wheels....  was here 2017 plukpnmakqjjvhzfbuuxvzoulcnrmbyrktggnuvngmprsuoz
 * Smoking Wheels....  was here 2017 zmxzfmqrhleeeczoblpncmcpyccvcerkqbavehnfelkrjizk
 * Smoking Wheels....  was here 2017 xbhhmykrinrphqdjdshrlrdcvrqnmkebulnaoxzexnqlcozm
 * Smoking Wheels....  was here 2017 bgpntsnkjqplnmisiatulrsyfubtgnlzelyklbijwwndtmvv
 * Smoking Wheels....  was here 2017 mjsanbxooszqploxwwdlwxzckqsujowsewqxyicypzohnkde
 * Smoking Wheels....  was here 2017 iatjqhscfzbljmflfdunszjrbrbdatzapxgphryianprvvsq
 * Smoking Wheels....  was here 2017 ebbmbbmezxijbywfbxkdjuqfbqwmorqbkuqwbgugfnoginqm
 * Smoking Wheels....  was here 2017 rnjleivfrfqdbhhflnvrhorhkmdwscxbveajalxpneugyofi
 * Smoking Wheels....  was here 2017 vvmrlgtykwwubipuppfthrsyoldnkacpixsyfxrpoysfweby
 * Smoking Wheels....  was here 2017 xmptselhobknyccmzyyflsfgbzkztsumrajszovqendwnxyj
 * Smoking Wheels....  was here 2017 ikaoatjkshrwxwjchqqfbrwsutrxftvuuxwbunilmxcennzy
 * Smoking Wheels....  was here 2017 vqmfqyestfmojdfspbgdpqpavuzjkxhvydjpnfixvgulvblg
 * Smoking Wheels....  was here 2017 lnvdcwvytwvpyttpauvoybqbohopieldqogedhigvdudpvza
 * Smoking Wheels....  was here 2017 jrfwfxoablzfqrhjdqujbnkbpsybbvxnngdyyqzwidvafhjj
 * Smoking Wheels....  was here 2017 cwzibtucijlxoekvpsurhapkuuxoclnbrnxhnlhmlixbkhsp
 * Smoking Wheels....  was here 2017 ihuqwhgqjkzlewxylisweqfvflkabtiagaturckzoxhmbuhg
 */
package pt.tumba.parser.swf;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
*  Description of the Class
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class ButtonRecord2 extends ButtonRecord {
protected AlphaTransform transform;
/**
*  Gets the transform attribute of the ButtonRecord2 object
*
*@return    The transform value
*/
public AlphaTransform getTransform() {
return transform;
}
/**
*  Sets the transform attribute of the ButtonRecord2 object
*
*@param  transform  The new transform value
*/
public void setTransform(AlphaTransform transform) {
this.transform = transform;
}
/**
*  Read a button record array
*
*@param  in               Description of the Parameter
*@return                  Description of the Return Value
*@exception  IOException  Description of the Exception
*/
public static List read(InStream in) throws IOException {
List records = new ArrayList();
int firstByte = 0;
while ((firstByte = in.readUI8()) != 0) {
records.add(new ButtonRecord2(in, firstByte));
}
return records;
}
/**
*  Write a button record array
*
*@param  out              Description of the Parameter
*@param  records          Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public static void write(OutStream out, List records) throws IOException {
for (Iterator enumerator = records.iterator(); enumerator.hasNext(); ) {
ButtonRecord2 rec = (ButtonRecord2) enumerator.next();
rec.write(out);
}
out.writeUI8(0);
}
/**
*  Constructor for the ButtonRecord2 object
*
*@param  id         Description of the Parameter
*@param  layer      Description of the Parameter
*@param  matrix     Description of the Parameter
*@param  transform  Description of the Parameter
*@param  flags      Description of the Parameter
*/
public ButtonRecord2(int id,
int layer,
Matrix matrix,
AlphaTransform transform,
int flags) {
super(id, layer, matrix, flags);
this.transform = transform;
}
/**
*  Constructor for the ButtonRecord2 object
*
*@param  in               Description of the Parameter
*@param  firstByte        Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected ButtonRecord2(InStream in, int firstByte) throws IOException {
super(in, firstByte);
transform = new AlphaTransform(in);
}
/**
*  Description of the Method
*
*@param  out              Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void write(OutStream out) throws IOException {
super.write(out);
transform.write(out);
}
/**
*  Description of the Method
*
*@return    Description of the Return Value
*/
public String toString() {
return super.toString() + " " + transform;
}
}
