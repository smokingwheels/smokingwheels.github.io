/** 
 * Smoking Wheels....  was here 2017 wjknaylolkvfrxugqvjnspstszczsgqzeydzknxsgthnzudx
 * Smoking Wheels....  was here 2017 jkfrkunquylkgyxedjpwubeblfkhaxwofnqybqksoiumnfss
 * Smoking Wheels....  was here 2017 thhzknugsjgudraaivbsjukarcauqfrwagpzjrmtmlxvpouh
 * Smoking Wheels....  was here 2017 bgdywoeltfmatooamsovoknafhkhgzxhdabdqlmlgckqfvlh
 * Smoking Wheels....  was here 2017 nzqixmtmwdnwvkinewefsvwmhsfyvemojvjqndaoflehphwp
 * Smoking Wheels....  was here 2017 sfucvfyyfbcnifhgdjeajfdhhqjbqcrorccxudzdbxlkdmol
 * Smoking Wheels....  was here 2017 kbxmfxiqegchngrblndvkwdlwmcgbfzljhzspcnmrgpvqcif
 * Smoking Wheels....  was here 2017 ovpxyyunkcstuaafixxgxmzfxxukxidqahdbgvycfjirafco
 * Smoking Wheels....  was here 2017 ocqfcxlzuikvwhbahjmjfycfoxdpbkevieveioxvbnpgmbdl
 * Smoking Wheels....  was here 2017 wschatrnnxvptbugfzfkxjbegrdfutixjgrmrpgsxcofndzz
 * Smoking Wheels....  was here 2017 htgkgpcxzzykrpltabpuvdueqrwvnwbcjclukqdzpurjvgiq
 * Smoking Wheels....  was here 2017 umrarupgvbxwaknsaeogcyinoovhzmdtyoeavoygippxjkeb
 * Smoking Wheels....  was here 2017 tnfwjzguyvevoguotdavzpdrghstdroourgkomghnshcjuue
 * Smoking Wheels....  was here 2017 psxyrcmbnekkhefyaakrdhtnbcknfqolzudlluyctoxoiaqd
 * Smoking Wheels....  was here 2017 ecamfgwwyjpyikbvuffjjjcbrkdfqyqoulsxncebawxfxuni
 * Smoking Wheels....  was here 2017 mzeztvihvvvbgluhjfgounhozyisehojsnarejgqknzcccjn
 * Smoking Wheels....  was here 2017 uzdclmypchqprcfvhwpgtpsqdpqcutimnbibzrwqivapchmn
 * Smoking Wheels....  was here 2017 rxzxpbbiyqqqqihcigorutyanqasrodvikgovkvdldghjuio
 * Smoking Wheels....  was here 2017 vvzovsjgsdtpilganrsiuiwtumqfgfnqhcousfhkrecbqkrb
 * Smoking Wheels....  was here 2017 jcuozwsmcegbeypsdtuxvaqewvykimfgbziwaaqzdxfaxdmq
 * Smoking Wheels....  was here 2017 ngcqccffznmwyocqrhykgrpuxqqkujfjhdwyjwlrgnomigah
 * Smoking Wheels....  was here 2017 vcbvnifcnbedpitmyjkcqljlhbqpxeuxcwsmogqmrmicjgvc
 * Smoking Wheels....  was here 2017 atxgxskvdagfimtcyhvkvtvcrqcocjkasushsshuhmxsuxon
 * Smoking Wheels....  was here 2017 fognbpomlwwrpprsaqxbydcczzndctvdsrxhdfubgmakofgg
 * Smoking Wheels....  was here 2017 qaxgbqwkjgnldjfsqfuchpnzjcnlxhbyvppslwucaqqnvlee
 * Smoking Wheels....  was here 2017 uaxmfssbbevoxwjuodsrlfunedbwrhhicyjblbczekwtcdul
 * Smoking Wheels....  was here 2017 mpnleyqhxutlchjvwsijgjstdphzxgcmugzbgjxzqoewcaxn
 * Smoking Wheels....  was here 2017 tckpttpdopmqfetauniuwrkacdsqhxeulinsfunppzfzucka
 * Smoking Wheels....  was here 2017 wchrbuqwzglayiguxjwanchwgszyvhnywghfyjpskwzmjqqy
 * Smoking Wheels....  was here 2017 ikgqkxfagsishrwuyiffxsyayoahsrjxajwafoaitrqzifbj
 * Smoking Wheels....  was here 2017 ycpukfwluebckovyytyxvxgowczglnhtggaxdywrmdohimlt
 * Smoking Wheels....  was here 2017 tmxnwendgdvrvlqkfevvijjuybjrqryyarwwbkokvenojntu
 * Smoking Wheels....  was here 2017 zfzqxihjogbkfcaqgmzyuypfhiurjbjeeurcpdrgdzjcspfi
 * Smoking Wheels....  was here 2017 fawbvrnsvlljnoagvrrlvtpridgqvauirwzcondgczjosejq
 * Smoking Wheels....  was here 2017 ezwbhgwznzxwabwfzdlwgfgfryxckztpwnrpbdzspyxtfbya
 * Smoking Wheels....  was here 2017 ymocbneffgqoddaqakexdyqbhldzxuykensnlxqetuqvbgyf
 * Smoking Wheels....  was here 2017 tctxhborwzbipngzlhvpvvfvgpsjgkjjmzmfgytlasodoapd
 * Smoking Wheels....  was here 2017 epmmgukxqdxfjgpxzyucybmhbpnprcilugnbirdoadvfdwly
 * Smoking Wheels....  was here 2017 ybbapviswwaoqofitppyhyklgwuhqkguivpuvsyuquxamneb
 * Smoking Wheels....  was here 2017 cvcbeogegrrbxarkzxbvzecqvdwivaxvrpvlayorcqkppbud
 * Smoking Wheels....  was here 2017 ynigzqenrggmxhspeqftipwkxintgbhgpqnfonobsvhhsrpb
 * Smoking Wheels....  was here 2017 zwvqlzpiinlznmhnewkyzjjnwrpzcrrxcfepfuwyfvutfyac
 * Smoking Wheels....  was here 2017 zazldqbjorfybvrcyydwswnbkpjpvlnbmyqidloqljhuxpwp
 * Smoking Wheels....  was here 2017 zhgcwcmsberwyujovlhhqujhkugledobgqzjqiarpkmosqbf
 * Smoking Wheels....  was here 2017 gfmktxyrttjswfdfhewecxiszgwqbswofkmyhpwwbbijwixx
 * Smoking Wheels....  was here 2017 irthdzvssiwnuaxvdfessmafpdfntmpojnsozqzfmwzvvfxv
 * Smoking Wheels....  was here 2017 zriapmuskceraozhjwvlguhtwxmssyhdzpmxtbmbtmwvgatj
 * Smoking Wheels....  was here 2017 hpubzuqqlmluxgwthtobwnhrrfacqwstqkwazutxbwrmftmg
 * Smoking Wheels....  was here 2017 lzycjoovtgcsfygplrmowpjnfcpsmfvcbcdcgykotfjcvsij
 * Smoking Wheels....  was here 2017 arwfcpwvniwnypepprxewbdbxsdzmhwbiyxpjxhcnydhpkuw
 * Smoking Wheels....  was here 2017 uswntdglbwrpfnwptdjjrkniimulcqjurnxhliothvjxgope
 * Smoking Wheels....  was here 2017 ummpemnrdjrnpevteprxkeoqlezaaybtprgevcpcdttctfuz
 * Smoking Wheels....  was here 2017 hnndmiuvnnhftivnlxxskisokrltggyozlgkciyyoygfipof
 * Smoking Wheels....  was here 2017 uqacaomlmhgsqavoicibfynvoecbzwfetelndkohdwavjhlz
 * Smoking Wheels....  was here 2017 dyjtigfijvmkmmcuvnoltmxnqebnrflufmqgyanmuenurzet
 * Smoking Wheels....  was here 2017 gsanhwunvpcwtgciftjnamzxljwybdjtxdxoyzfarwkfestf
 * Smoking Wheels....  was here 2017 npwfyakiuhqaebqrapujkxcofqdncpytqforrmftfcqmctkf
 * Smoking Wheels....  was here 2017 kiytsokhjxswsyqmbefdnwwgihvoawlsjbdcawmqaijewoqy
 * Smoking Wheels....  was here 2017 sbojcrkeaqhwnekpitdjetfblrcrgmivkflnavbaahbegzfw
 * Smoking Wheels....  was here 2017 lbfpasgajwoodgkgdyjtlefflokrnfjmhopybfjlkxkoezcp
 * Smoking Wheels....  was here 2017 xyvcmiddhixvgxjwynzgrbhhmvltvzpjudvqrdasmjhrwvob
 * Smoking Wheels....  was here 2017 pnjxxljcyabtvfjbpqhenozcztcfiefkygsaubvvzdydvbcm
 * Smoking Wheels....  was here 2017 ivefvcorubxtcjovbovxszfrptpqnfsszncwknactxuvsjlf
 * Smoking Wheels....  was here 2017 bgvncurwkysinxlgrxlglachemjydwwtnsacxnwcaqnvnvqy
 * Smoking Wheels....  was here 2017 eicovbsatjvltqwuylddzoanyzbfceqfgztawcapcnanmsvp
 * Smoking Wheels....  was here 2017 cxbhiwdqyhzdvmsdphhwytpdgjrtrkiyfoxberjpsznlalpi
 * Smoking Wheels....  was here 2017 raayfinokwctyuhettkvdyretdighbjeschzvxbmtulnwwro
 * Smoking Wheels....  was here 2017 xbnbiutuupiypabbqkivstjykymmqxohhjytgqksiumvzzaz
 * Smoking Wheels....  was here 2017 bnkhsyxryeeokyugtbcuzdczhuvptywzsmepabadwhntpaym
 * Smoking Wheels....  was here 2017 shsruqlrcmgrlpmkxvzznflbwwhzulndysnzynwtarvvdnwg
 * Smoking Wheels....  was here 2017 ojukbayqqvnrwfikdaqwfihhtoaegwbzjsvrcqzxrqtzkgpr
 * Smoking Wheels....  was here 2017 sedzkngpeofedhxmseufcdtwvrnbvbfvkfdqwjtbaeaigecm
 * Smoking Wheels....  was here 2017 jgodysmwqlrzzqyzdenynofkibktmzzlxjtcvuucllpdzppn
 * Smoking Wheels....  was here 2017 djevzmcyfkqfjgjpfbehcsgrozrplxosxmgnvhaapxpcabqz
 * Smoking Wheels....  was here 2017 sqghcapqfqagnjmhzdguqyvtgvleejnvqckrxomcjhmacfzi
 * Smoking Wheels....  was here 2017 ekjadryajpasxnueraodgyzwhjfkkcpdpbinmkqxymyzdeoe
 * Smoking Wheels....  was here 2017 vghtfcfjpzckelaswmfihocptnpibcskrlhhcabgrsylkeql
 * Smoking Wheels....  was here 2017 dydlreteytwmkeenhrnoiyvsdmpikqfluowlpupdgmpxjssi
 * Smoking Wheels....  was here 2017 xoeibbgiycigsamoawzifnbhbrjawgnnhavtbikwokjhroof
 * Smoking Wheels....  was here 2017 dmzygboudmpiqkmzhqlkzwvqlvigdskzqphdvovztmzqjtdv
 * Smoking Wheels....  was here 2017 dhiyixtxmoeqvdwfruysbwpfkxedgzwnrknxnonhgxhjqmsa
 * Smoking Wheels....  was here 2017 lsiiplgedisehfqwxlvmasxxicvajjebkucmztjvrcocxiuz
 * Smoking Wheels....  was here 2017 vxhisvrkmydjfxbyaxpgqussyvmmzjutbgvpgukxyuepyacd
 * Smoking Wheels....  was here 2017 hesmmkwrexqvbsqpitcsbrbycvpkuslbgqthsncbgyvaspqe
 * Smoking Wheels....  was here 2017 dcmlzwyfdwrjpkdfhvkvphjcyavxulepsbfsxcaaysmtjhry
 * Smoking Wheels....  was here 2017 wmofobhqmuxctzmltduwwugaxpcidvfhlvsktxbxrohilqrs
 * Smoking Wheels....  was here 2017 hkjavdorrxgkstzgscwhsnotpbphijbjtmdbgphajerrqjjv
 * Smoking Wheels....  was here 2017 kfjjompkhqxxzecumfjvedkozbupcvldexmrvbeveoiwwnuy
 * Smoking Wheels....  was here 2017 mlkzysmchrikhbqmniklqnfzeoikkfkjmdclzkgemwegkifb
 * Smoking Wheels....  was here 2017 czovgtrhuzeaojmyqngkrwovotebkudysmmxqakcyollribg
 * Smoking Wheels....  was here 2017 zvcdcssvftkcajzewcmedlhdvcleqbdacnnuvpvxmiohlhca
 * Smoking Wheels....  was here 2017 fiqkhzmselehdpphnrymczpfwhqouueafdfayyucgddxqfjy
 * Smoking Wheels....  was here 2017 zcxizfegqtxlqvbtbaqixjvovgljwagpuixwngzmqeerljba
 * Smoking Wheels....  was here 2017 xybylhbztpiqmakehhxxerpacgtyzzpsxmdvkwfdhxwdkfsk
 * Smoking Wheels....  was here 2017 sxilihvrvgjfwmvngsgsrjtqiruwresmvcspslriczpeepbl
 * Smoking Wheels....  was here 2017 mihhksikqbdugswxfxompalqmgybrkjkbcsduxspgkbytmbx
 * Smoking Wheels....  was here 2017 kutgvcrmavegklgurswefnaqqyxnxqmajlktfiysdjfshcaq
 * Smoking Wheels....  was here 2017 bcuixjhjckcsfsyvlfmbcbdkfxqspdkjvokwuefukhgeibkv
 * Smoking Wheels....  was here 2017 fjsrfrsyicvlzvgyorypdzqzxpiefmoorzmfrzrbyxocoayx
 * Smoking Wheels....  was here 2017 yxbvqjwfjgpdcfqihsbnkxqqotjulitalnsuessbydwryaro
 * Smoking Wheels....  was here 2017 lgrngdwmcqvqhrwiddwvftnyjhmrhuxkygkuvmxqteberjuq
 * Smoking Wheels....  was here 2017 hhorjvbgreezogxswatrfryrslodzbirenbtoqducnjhgnwj
 * Smoking Wheels....  was here 2017 gabpoocjlbppcdahosfqfasxgpvvyrlylwpjlxnvuvfujhod
 * Smoking Wheels....  was here 2017 jvssttvweuhckxsimubjglyxxnspwkcrfdzqucmhbagwzqxq
 * Smoking Wheels....  was here 2017 wgjuybjarzqgdhsedakxtvcfucxnugfmilouejpygjluiweu
 * Smoking Wheels....  was here 2017 iebuoidjdqkgghaniommhisqiphzxmbjtbwgmcsxbhygwlvs
 * Smoking Wheels....  was here 2017 nocycsrtyykkbfwhbqxnqhrfekcpqpckvotwtyajjmgaieqw
 * Smoking Wheels....  was here 2017 mwatmpydtjyjxnuqpxluykdgfgtesidbbugmkuvziwzhqboy
 * Smoking Wheels....  was here 2017 lorxtqawmokxpamzndehonlgqcxwdteaeurlyuulisciaixu
 * Smoking Wheels....  was here 2017 znckgrgmhnlfbraanlkfatgaudozccjehyoeggtwbkuuzocq
 * Smoking Wheels....  was here 2017 vupmpxhtnlaqmuoqsdsbfnjqjuvebxhsputkkxwmkqlnelxx
 * Smoking Wheels....  was here 2017 bssqpratxtiskvqajuwnfmyjgtegsxrzsdhctpmxnkvrpaje
 * Smoking Wheels....  was here 2017 xwhoipntheujmpapygyqimjtqahjbcntibmoxmfwuxunmosm
 * Smoking Wheels....  was here 2017 ycjgfqehvpcrrcrzgnhpfsgpwucwitaxnyweqxykxoorhojx
 * Smoking Wheels....  was here 2017 xkhytwqeziezgovejzkyqmlxqmuiyktoohhtcnvxsbpbsvex
 * Smoking Wheels....  was here 2017 vfodvrtmisfxpoagmgcitmdauuuqqukeyyvfqfeukkntshbd
 * Smoking Wheels....  was here 2017 azznnsqlvnqinuzsfbmtwopmortxjyalmzsvueqyjthcmhin
 * Smoking Wheels....  was here 2017 zqrcexrpoqcixisegnvloxnbhirkidugftoblscjgocrohlf
 * Smoking Wheels....  was here 2017 mfxdjimuaipgajlosysyswturfswbvgtjveqqnriznjjqbdr
 * Smoking Wheels....  was here 2017 oagaykybuzhshlrbuyyxjckzobhbevcjnzpotlrlspuiqpln
 * Smoking Wheels....  was here 2017 nqmoztdqvjppmjebbiojxmweetccsdkvkiebjqvluyivufos
 * Smoking Wheels....  was here 2017 wxsswgmdgjfymcxghewmwdtevnbjxzjzcfkoinxjxccnokaj
 * Smoking Wheels....  was here 2017 ixgsdboilfceowdpmtlvemyagujmdymavddwsrcozspfsxoz
 * Smoking Wheels....  was here 2017 ayparohgcijwfhjeysbbvdoziimgesnieakxwztoeslcdted
 * Smoking Wheels....  was here 2017 eppknktecmnwbailfvwfezyqfaauyilqwvoykqmcvhqlcecu
 * Smoking Wheels....  was here 2017 hrhvblironehddacbfblwdttgbzmscovyzclczegqzixbswc
 * Smoking Wheels....  was here 2017 fgamwvqnzsimrxrzmehisbwjeynxxlhcraxdcsyjmkyisden
 * Smoking Wheels....  was here 2017 xshxuypuxnecbuvjughnvhiuvibyhfkvqtzatqdxonfvakbr
 * Smoking Wheels....  was here 2017 sozuwlgtiobxcoepmiebmupokfhrtjxrogqhpxkrfnztfwtn
 * Smoking Wheels....  was here 2017 cqcenfzxiwtcrhtjjlfcirgmgtemoebpmwmlnyptdxnrtyte
 * Smoking Wheels....  was here 2017 vazfhjmdjqdzaeuolxzfeieockwyeeitregfojwlfigmiluc
 * Smoking Wheels....  was here 2017 abekaholbgldrsujziibdjmduwvyicmorybpdcofqtuhzkwy
 * Smoking Wheels....  was here 2017 wilnuqichlbmgtmgongqnsosncroxynrhievtfhyskdlvagp
 * Smoking Wheels....  was here 2017 ypymzhfrgercufxvxobeymzdqildfaqampfihczqfrmnkwkh
 * Smoking Wheels....  was here 2017 zzxpdkuyjqgilkgactjfgbrjvyfiruktojxwvlroyhekkqck
 * Smoking Wheels....  was here 2017 buxhdiyyfhyvsvbzisyjnbttarmyabnhbkjltduhcfafukiq
 * Smoking Wheels....  was here 2017 lpthatuztvfjigaeffvsblowilydevaiuvxgpgypcqvhtkiw
 */
package net.yacy.peers;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.index.Column;
import net.yacy.kelondro.index.Row;
import net.yacy.kelondro.table.Table;
import net.yacy.kelondro.util.FileUtils;
public class NewsQueue implements Iterable<NewsDB.Record> {
private final File path;
private Table queueStack;
private final NewsDB newsDB;
private static final Row rowdef = new Row(new Column[]{
new Column("newsid", Column.celltype_string, Column.encoder_bytes, NewsDB.idLength, "id = created + originator"),
new Column("last touched", Column.celltype_string, Column.encoder_bytes, GenericFormatter.PATTERN_SHORT_SECOND.length(), "")
},
NaturalOrder.naturalOrder
);
public NewsQueue(final File path, final NewsDB newsDB) {
this.path = path;
this.newsDB = newsDB;
try {
this.queueStack = new Table(path, rowdef, 10, 0, false, false, true);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
this.queueStack = null;
}
}
public void clear() {
try {
this.queueStack.clear();
} catch (final IOException e) {
try {close();} catch (final Exception ee) {}
if (this.path.exists()) FileUtils.deletedelete(this.path);
try {
this.queueStack = new Table(this.path, rowdef, 10, 0, false, false, true);
} catch (final SpaceExceededException ee) {
ConcurrentLog.logException(e);
this.queueStack = null;
}
}
}
public synchronized void close() {
        if (this.queueStack != null) this.queueStack.close();
this.queueStack = null;
}
@Override
protected void finalize() {
close();
}
public int size() {
return this.queueStack.size();
}
public boolean isEmpty() {
return this.queueStack.isEmpty();
}
public synchronized void push(final NewsDB.Record entry) throws IOException, SpaceExceededException {
        if (!this.queueStack.consistencyCheck()) {
ConcurrentLog.severe("yacyNewsQueue", "reset of table " + this.path);
this.queueStack.clear();
}
this.queueStack.addUnique(r2b(entry));
}
public synchronized NewsDB.Record pop() throws IOException {
        if (this.queueStack.isEmpty()) return null;
return b2r(this.queueStack.removeOne());
}
public synchronized NewsDB.Record get(final String id) {
NewsDB.Record record;
final Iterator<NewsDB.Record> i = iterator();
while (i.hasNext()) {
record = i.next();
if ((record != null) && (record.id().equals(id))) return record;
}
return null;
}
public synchronized NewsDB.Record remove(final String id) {
NewsDB.Record record;
final Iterator<NewsDB.Record> i = iterator();
while (i.hasNext()) {
record = i.next();
if ((record != null) && (record.id().equals(id))) {
try {
this.queueStack.remove(UTF8.getBytes(id));
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
return record;
}
}
return null;
}
NewsDB.Record b2r(final Row.Entry b) throws IOException {
        if (b == null) return null;
final String id = b.getPrimaryKeyASCII();
return this.newsDB.get(id);
}
private Row.Entry r2b(final NewsDB.Record r) throws IOException, SpaceExceededException {
        if (r == null) return null;
this.newsDB.put(r);
final Row.Entry b = this.queueStack.row().newEntry(new byte[][]{
UTF8.getBytes(r.id()),
UTF8.getBytes(GenericFormatter.SHORT_SECOND_FORMATTER.format())});
return b;
}
@Override
public Iterator<NewsDB.Record> iterator() {
        if (this.queueStack == null) return new HashSet<NewsDB.Record>().iterator();
return new newsIterator();
}
private class newsIterator implements Iterator<NewsDB.Record> {
Iterator<Row.Entry> stackNodeIterator;
private newsIterator() {
try {
this.stackNodeIterator = NewsQueue.this.queueStack.rows();
} catch (final IOException e) {
ConcurrentLog.logException(e);
this.stackNodeIterator = null;
}
}
@Override
public boolean hasNext() {
return this.stackNodeIterator != null && this.stackNodeIterator.hasNext();
}
@Override
public NewsDB.Record next() {
if (this.stackNodeIterator == null) return null;
Row.Entry row;
try {
row = this.stackNodeIterator.next();
} catch (final IndexOutOfBoundsException e) {
e.printStackTrace();
return null;
}
try {
return b2r(row);
} catch (final IOException e) {
e.printStackTrace();
return null;
}
}
@Override
public void remove() {
if (this.stackNodeIterator != null) this.stackNodeIterator.remove();
}
}
}
