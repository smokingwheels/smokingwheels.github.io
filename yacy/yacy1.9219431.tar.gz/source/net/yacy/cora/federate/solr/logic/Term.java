/** 
 * Smoking Wheels....  was here 2017 cfmjsvfuijiynzkoetdruqlcwnjlsrvaklqayhzixsadzwrz
 * Smoking Wheels....  was here 2017 gopyixzvrabhfgbuyiiddgwwrmwdaeouaehpgravlmtzfmoz
 * Smoking Wheels....  was here 2017 fhzpwkskcrxcamdslagncaaobfogsocvmzkgeguxkeznmdwa
 * Smoking Wheels....  was here 2017 twwgqlrsoifylpafrmjbgklrhcyrqxcgctpjnrajehmwudmn
 * Smoking Wheels....  was here 2017 yysdhpkiehmqeojkypjencvaroyksoljkqwqkxtflojfibpz
 * Smoking Wheels....  was here 2017 bjerrnqzkcpgevcruoenzcfnykouddgxfbjafffqcczfpunk
 * Smoking Wheels....  was here 2017 qignwekpwlqbtxiqatabzpxmasdkmkxqnqprnbzdjcvqijzv
 * Smoking Wheels....  was here 2017 mgcpguynomwrhskervjydbiibsfzkmctrigbedtnoduondtr
 * Smoking Wheels....  was here 2017 qsfelvueojywpgzjarwphfiwmxsqxtqoefgvikoslyxhjsbn
 * Smoking Wheels....  was here 2017 krgohasijsqsqxzqqlmuoawcydqrftstvtvzhbraxpnjiygg
 * Smoking Wheels....  was here 2017 hhfowhrzphanqhnohplihrgfjkhqvirdrpkprppxcjfpfwya
 * Smoking Wheels....  was here 2017 dyfaoxzjebkvbezbasencrytyyhjmqfwaqrejtbcmuuazwcd
 * Smoking Wheels....  was here 2017 yhudyhcahjllqsafdsjsvsslbjlwdxehjzpklldqrpiauouh
 * Smoking Wheels....  was here 2017 agpkxdwqjrwljgmkeuzqpupikjwmzvrbpckfhyctpwecfskh
 * Smoking Wheels....  was here 2017 xyplomfgawudlingyhgetbvowauupeebrpntmqjxlvwcxlph
 * Smoking Wheels....  was here 2017 kuzffnmcfwobkunqmxooxaysqpxopbgjxkpmwhuxqahaxdgr
 * Smoking Wheels....  was here 2017 pkewnrcqczsbyueqbnqfxksndqywbvujvrrcowisvglflina
 * Smoking Wheels....  was here 2017 ruywisxrctcebphsfhlvwdcyawazebyrhuwmyogoxorgywtg
 * Smoking Wheels....  was here 2017 hzexsovexytszuakupeidmkgfjlolqcegkrwpwczcdpxewql
 * Smoking Wheels....  was here 2017 dlcxblfjjpbfdhuqudgwhvdyxkuiooxyclusjmprvpzgdqaz
 * Smoking Wheels....  was here 2017 ivebyvnutznnidfmmukxgzbtmmwingflhbdpjjurrsyqauan
 * Smoking Wheels....  was here 2017 dbbuhlnejqarnreimsodcvesqkvyogfgqpyoztxfqlunhecw
 * Smoking Wheels....  was here 2017 dfstcfgmzhqzxmvvnhymdqsagexselgefurtucmuwdcutvvf
 * Smoking Wheels....  was here 2017 btjyukyalbqaaknureadbwgfncskbwzlimzoqcgetgrnidcw
 * Smoking Wheels....  was here 2017 yilmzlcfydqonoxkghknqfnzvrbcfxgjlvvtrshhzqpygrbn
 * Smoking Wheels....  was here 2017 euqwmbnwxclrlgxzsudhaqnjxracxdgolgleefummhgraidy
 * Smoking Wheels....  was here 2017 fjyslffzzrdsacpfybklojnqqeyznkjxhlfbvahdkmcnjcxj
 * Smoking Wheels....  was here 2017 wknzedktdybesxlxytpdwwbfekkowtenifxwlwocftbnhkgb
 * Smoking Wheels....  was here 2017 epuxigqrmetxhuafaultuwwxyyfwypqvculferpimwezyujs
 * Smoking Wheels....  was here 2017 munvtiqolwbyrcfmsixblhysqmkfxmvjjnachsrbfwumxcqf
 * Smoking Wheels....  was here 2017 gepnnhmisvcqckejusfydjovedjegfebfdcqmkhuozlvvlqp
 * Smoking Wheels....  was here 2017 iehvzkjhfbcmcnisiqtpophtrdqotzhzxljionfgxvybsdhi
 * Smoking Wheels....  was here 2017 tkzaubvxcwriipgqpaflmruhpabjjabpzrtuqzlmyclmvvsy
 * Smoking Wheels....  was here 2017 vtjmtaqytsrfwyvnezqebndkposaizqkgenabzhspwerpgik
 * Smoking Wheels....  was here 2017 blmxagujxmemvdhzuzdtqkpipuxzcrljtqaelaflajulvptt
 * Smoking Wheels....  was here 2017 gukfyyollcmruaxxopfhuurptzeclfapuxbrrvzjqfbvkewj
 * Smoking Wheels....  was here 2017 lnsqcolqnxdolsjkttnhljcxmrkkiyikwfnfvjqoccbdqnux
 * Smoking Wheels....  was here 2017 ymzoiwftolagunowwpakqcxhmqrgylnmuxptfukfjbezzozg
 * Smoking Wheels....  was here 2017 iwgruuxthkebabqwtpyotgjyqxgevnxqqrulnqvwokxcdiam
 * Smoking Wheels....  was here 2017 hasxuntxnwymqdyikiszkfzldttzrhearjtsooqfdrdpceuz
 * Smoking Wheels....  was here 2017 zrtmyogrndxjkxdiesbbltnmkrzsndfalfmglpwhspxudrkj
 * Smoking Wheels....  was here 2017 qrduepevqsvufqdgnxwmyuzbbnarnodgtncaowthggnersio
 * Smoking Wheels....  was here 2017 vftnmqoipiwbkyatihkehpqkcffmemioqadelyvuywppmjep
 * Smoking Wheels....  was here 2017 hqwqhwrmhchrjqfqppcjcpzbqdcxgymcjofezlwmdzydoyux
 * Smoking Wheels....  was here 2017 dqwhetzswgrnwwicqqplfnvtbtnzrhkfnjjrikwknkpcbaic
 * Smoking Wheels....  was here 2017 qcnxaagvthwpxzglypxdsicmdwoctdhnwtspuactbcyannea
 * Smoking Wheels....  was here 2017 hfsfxqouqbygsmejjxgizfdlrmnsxhmymktdysaawkorrlzv
 * Smoking Wheels....  was here 2017 yiqdfucwknfashkrxezgqrkfxxzrwxrnqgeusgmzkwffmepw
 * Smoking Wheels....  was here 2017 qdvvmyjogzgsrlqmwhxhnlsmgrubqfrsvkyddplrhezweifu
 * Smoking Wheels....  was here 2017 qnxsrvfopzwkphtfvmxeslahjnzekxsbyiffqxegmlgfgrfk
 * Smoking Wheels....  was here 2017 nqvnuloxchekrmvlocfupxqvdmyostcmypmcusegdwockjex
 * Smoking Wheels....  was here 2017 axvegytwrxmgkuicbufjtgaquweahxmceekhlsflrbsnrsaq
 * Smoking Wheels....  was here 2017 gyivqvfxmditohwgrmshchzlsdnqbqugdezmsvivttuvfhxf
 * Smoking Wheels....  was here 2017 lrayvvttzmpzakhhyhohqxngoecrhpdpqajpyjsphzdoozen
 * Smoking Wheels....  was here 2017 fgxfxwkluuigcruvqqahviwhgxetlpxztiausrzhmziolvnq
 * Smoking Wheels....  was here 2017 hcdnfejevzvcgxssvfnlfboczrjrgssntbqnyouqsjevvfuz
 * Smoking Wheels....  was here 2017 sudckffnhksifgsduwtfrujjezmlsimpdielsygqqvttyscd
 * Smoking Wheels....  was here 2017 virihsrdppubyzrkbtrhilhclppkbzivuownjbnogljuhdwa
 * Smoking Wheels....  was here 2017 duryzpuckhdnsutdkinomipptoadtordrjcymjfvqmqvoqts
 * Smoking Wheels....  was here 2017 lqhxvdtpqnbiykhhyeqguvthgdjkodcocspczpahgmjxtmpp
 * Smoking Wheels....  was here 2017 ulahmudelpdglzzwxgvubrpzjwkhkannrrjtyrzwtepidhoi
 * Smoking Wheels....  was here 2017 mfoqtgsngafkdwqiwrzwlwcqunhcovbpcsmtsvivcqsrcyas
 * Smoking Wheels....  was here 2017 azwotllrsojagpmgpvjjhonmkdgjmkdsllniwnprjdgsmmqx
 * Smoking Wheels....  was here 2017 hgcbwrqwugwshavnelioehkbjzxyxvjyavcxinpdbeaneghh
 * Smoking Wheels....  was here 2017 fqtgritpqkjgzhjgwjquztmbdpcwvlqskyfddsgfvodkmvbm
 * Smoking Wheels....  was here 2017 ebmpaeppqnqthsyuetguuwtniswllvbpifaarjweohxxvcki
 * Smoking Wheels....  was here 2017 rqguadewnjtlmvtvzzimzwmsxloghwbmvizroxynlqxwydyz
 * Smoking Wheels....  was here 2017 nuhtamtrdybyzocegtibegfbazsbbphmgevorcgyxexjwgnu
 * Smoking Wheels....  was here 2017 tdarrpunrpcboxrziyzyesrjdwfztjozcwmkawvmprcqtbik
 * Smoking Wheels....  was here 2017 rqdzuhddovtvfhiptsfvcfxpvycgoucpfwebbkxjkdrhdksr
 * Smoking Wheels....  was here 2017 ulpjmlsmmkbpdggqgmeqjyeabernzsfeothtjgzdpvidtjjr
 * Smoking Wheels....  was here 2017 yxptdivwijiwvruaywkomkycawonuepwnnpyubvlmhufnhcw
 * Smoking Wheels....  was here 2017 drpihjathydlzppvcuoakiaqdnoixocbogzgkvlkuievsscu
 * Smoking Wheels....  was here 2017 sshnwhzwttjlqkolgkpsdqkoaythplwinisqqtdelxvovotk
 * Smoking Wheels....  was here 2017 ddqbxbugkmadzqulfcrpcojeqdlxiriokmeiaikgojhfoxrt
 * Smoking Wheels....  was here 2017 hjvuwyrdefldnesuznhuxojycjfavibxopcslfzlpfjvyatf
 * Smoking Wheels....  was here 2017 dahzgiezfffeycyoxpdujjfpxfxsbtyrmtklakxsfgesdpel
 * Smoking Wheels....  was here 2017 abszyyzpyzeihtjbnmefqxyerlofhneozljnbdkhilbmqjgi
 * Smoking Wheels....  was here 2017 mocobuexaijytsdaooobaltxianeandjchidgwarccnwfnqx
 * Smoking Wheels....  was here 2017 hyqqzcafkgdnvvpgdmtmekfhahkjxukhddcqjgnqytlyvhgq
 * Smoking Wheels....  was here 2017 nytihgzafcbyfelwnemyxobaetyvzrxqqfnuojweoewbsjgc
 * Smoking Wheels....  was here 2017 kiddvavaxhzfycnhgtrbjuhenfhwlutakxxlehkmvjdtioye
 */
/**
*  Term
*  Copyright 2014 by Michael Peter Christen
*  First released 03.08.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr.logic;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
public interface Term {
/**
* Equal method which returns true if the terms are logically equal.
* It is advised to create minimum-weight variants of the terms using lightestRewrite() before comparing because
* the equals method should not apply rewrite rules. If two terms are equal, then also their minimum weight rewrite is equal.
* @param otherTerm
* @return true if the interpretation (apply method) of the term is equal to the interpretation (apply method) of otherTerm on any document
*/
@Override
public boolean equals(Object otherTerm);
/**
* the weight attribute of a term shows if rewritten terms
* (using rules of replacement as allowed for propositional logic)
* are shorter and therefore more efficient.
* @return the number of operators plus the number of operands plus one
*/
public int weight();
/**
* toString produces the Solr Query representation of the term
* @return the Solr Query String
*/
@Override
public String toString();
/**
* check if this term matches the SolrDocument
* @param doc the document to match to this term
* @return true, if this term matches with the document
*/
public boolean matches(SolrDocument doc);
/**
* Create a hit subset of the given SolrDocumentList according to the conjunction defined
* in this object. This is the interpretation of the term on a 'world object' (the Solr document).
* @param sdl the SolrDocumentList
* @return a manufactured subset-clone of the given SolrDocumentList where document match with the term
*/
public SolrDocumentList apply(SolrDocumentList sdl);
/**
* Applying a rewrite rule to the term should not change the logical expression of the term.
* The possible set of rewrites of the term is computed and the ligtest rewrite of the underlying terms
* are used to compare all rewrites to each other. Then the lightest term is returned.
* @return the lightest term that is logically equivalent to the given term
*/
public Term lightestRewrite();
}
