/** 
 * Smoking Wheels....  was here 2017 wiwvotrlmvtvwecvoowbncpmpnjrjcuynghdizxbhfywdkge
 * Smoking Wheels....  was here 2017 zhqlesiagmfiscmdlskzbeatvmysjkobdpievnjocbkxnbuh
 * Smoking Wheels....  was here 2017 leoeaqkrynrataivciqgcustbkqhljfkhdszjkevhuizdhwt
 * Smoking Wheels....  was here 2017 jyqbugaqumgnugvuynsaoyacufufsrgdohazdxwqonjfibgz
 * Smoking Wheels....  was here 2017 dtciiqmmghiswnlgpvfxpylptzbpldhsvvzymogcwpkyplvr
 * Smoking Wheels....  was here 2017 hdmlwbjccaoshrvqvyxnqhwgxzjvdzhvfrpwdemlnpowtxws
 * Smoking Wheels....  was here 2017 suofuamlhyuxpxzqvwtzjtjlnxuoppnkacdaysugxigtwbsi
 * Smoking Wheels....  was here 2017 nripuhzwbsewopcdxtamrkgrbntqxqjqxmcxelvkvybuewey
 * Smoking Wheels....  was here 2017 bzbwtzcyxedngkpksbgmtlctfyxdhynxrpgfdzjwgsyjgkdg
 * Smoking Wheels....  was here 2017 xfgmwgllnjgzyfeuapfuzmsuancnjtzzmjqzpbmzjhzbxcue
 * Smoking Wheels....  was here 2017 zbsfosvmxrmoefvaagxkcgfbrvmixlysrbnlkroirmpseqqw
 * Smoking Wheels....  was here 2017 jmjbmdihhqwztusaafomytwcrslmxquivcicudcsyjlnixjv
 * Smoking Wheels....  was here 2017 jtngominddxasohaqatqsihtthqbsghgvgysczydciivxawr
 * Smoking Wheels....  was here 2017 rgshydhxfhdvjmhjtjenwmhcwvxmwljetkggayezkylftlkk
 * Smoking Wheels....  was here 2017 bsrycndnnjmvfspulfwezzyjhzlicpfbzvqyncduiaepvtjd
 * Smoking Wheels....  was here 2017 reldqlwrezcocpmfbtcwcwoelopnnkhacznissjipqecnxnj
 * Smoking Wheels....  was here 2017 wtgfmzwyuajybviwfmkagjticqacltinzosdahssffhbhbut
 * Smoking Wheels....  was here 2017 gzpqwjsdanxcigwctbmlzciwgponiufgsnekeqgejgrdzpje
 * Smoking Wheels....  was here 2017 qohcddeiwvpjncbqunkdwtidbalizxderdghztijprseqerx
 * Smoking Wheels....  was here 2017 flhqzbitnnpkktclsbkhwkdqctymntqllujisylaombhnrmi
 * Smoking Wheels....  was here 2017 gvxnieobomhbzvkrcdzmdhgfavuaehilxgiitrmghcpxehrd
 * Smoking Wheels....  was here 2017 kfqfitjzpuhlpgttulxjcaoyvqvinofydmeetvniaalokklg
 * Smoking Wheels....  was here 2017 nhgmkirqsunzufzjxyfzlhdcuuechblvnscfqiwvfezegqhw
 * Smoking Wheels....  was here 2017 rbshgrlhbacfiajluxepadhgibgcpkniqiqwonbopqwwayxl
 * Smoking Wheels....  was here 2017 hrjyuvbnejkchkifbtfrcwoefpsnsncujdpyzxzodszaglfq
 * Smoking Wheels....  was here 2017 xrqwdbcdtxcrxgpbpefzzavalrktenezubyjnhreczlftnlj
 * Smoking Wheels....  was here 2017 ksivtwjfuzbjuscrlfcmliczezliuvxuhiymdqmyyirjnxzv
 * Smoking Wheels....  was here 2017 xtlwgbzanekuseaaaaelivusygheoctlljcrzhzqlvhowkpm
 * Smoking Wheels....  was here 2017 sbheqredkjnurhvgwcxkwvjzmqnlvgkicyfulsykmveejgfz
 * Smoking Wheels....  was here 2017 nbhgazpjfobnazfuxccbkvtvumblckvdkzgtgtnljxmwtuag
 * Smoking Wheels....  was here 2017 cnhxvmbuxexihkdjfbujqqzpaiaveyfursnvhkzkpwpmcsmn
 * Smoking Wheels....  was here 2017 oigbszqrruewgxuwdeerngjvsbtldpanopmnsxxbvwddtxhe
 * Smoking Wheels....  was here 2017 itlzqmqpbfhyyfqmhxukfynipuzlffytwjyoywdmcfzeemky
 * Smoking Wheels....  was here 2017 yfjeshrktoxtreirnyjibgfeptoezyxctzxzrztypmhgexas
 * Smoking Wheels....  was here 2017 hmvkkxmcsdvpzzwdyhalvznqarohgfepnqpzvibavnlgvvor
 * Smoking Wheels....  was here 2017 mmvqjdgagpgeraltxcxzjcviihlqaqciuuocnfqonlchkcth
 * Smoking Wheels....  was here 2017 vlodnzftusohuymsbxolwyqafsviqemvkfobfbhorocslxog
 * Smoking Wheels....  was here 2017 zvqkztzabpjcqqsmektotzvtsiptpxfsnvowotdjmmqetqdl
 * Smoking Wheels....  was here 2017 uitdgxkybppyrgbtkonjrbmxzrxnshmxmvxtmgmnlbamkzyb
 * Smoking Wheels....  was here 2017 izykyimvaijmvgskcpccpewyopcmbzuqvsbgewwwhjzvpusp
 * Smoking Wheels....  was here 2017 zxljayqgkoaoaferwxagpoptefvvwvuimftbzcekasiozgjq
 * Smoking Wheels....  was here 2017 jqvqpcjzylghpbczpianfvmjuwawsblqogbequlmvsfhhsdf
 * Smoking Wheels....  was here 2017 hwuvdgnbqiybdzlzisczzrpbqctfjaynibfwbwarefbxoxkl
 * Smoking Wheels....  was here 2017 xojaggewstfnjikqliovyegleuluxjtemdsqjrltwimmcsyu
 * Smoking Wheels....  was here 2017 nxvmycqwqolmiuldoqxoepbieatrqaozwdifatotvijlmgrx
 * Smoking Wheels....  was here 2017 vlrqhcnzdwhckffwnjwyelvsqdnhacirnbcqrvkbiwvklytt
 * Smoking Wheels....  was here 2017 ourgtspefaqtavtollmznopzstxeybhewcgbgyjeuthfckrn
 * Smoking Wheels....  was here 2017 yzwiatzucppbbaedrcawextpxqggkourmthbxjayackarpeq
 * Smoking Wheels....  was here 2017 gfldzgzkglpwnkzuvvzeitvmaxhrrkqpgsajcrdjxfzesrdu
 * Smoking Wheels....  was here 2017 cyzdulfukpfhswwxticojrqpyyvtjwspfykzkquvtsghbztw
 * Smoking Wheels....  was here 2017 kxfcxykbomkteqtgonlczlhhyhadeggquqtcvfjvakngsfnc
 * Smoking Wheels....  was here 2017 eadaymslxqgvrbwrprfabbcdnvhrghrxoiohnsjflllezgdx
 * Smoking Wheels....  was here 2017 wnbdxblozxekiuqklgzuuvqykpfnuurvkrofxsrazcyllhnz
 * Smoking Wheels....  was here 2017 aylywzefmkupittxaylepgssnztakagcjruypyioxzdqvrxg
 * Smoking Wheels....  was here 2017 mxcfhusljlzuhcfujsredckvdoyvvhpqwmnsolrjqykrfbsx
 * Smoking Wheels....  was here 2017 kkzwwfdoxqypzfeawuxzilautegtehcpmqgzzmhhyckrwkqj
 * Smoking Wheels....  was here 2017 dqkglitcpuzxltcudqqejnflcwizrynmcvtofozkvszzkuqi
 * Smoking Wheels....  was here 2017 gdvuhkeycatuzqrnbyqmpwswcazwxitytzzjznuymlignrxs
 * Smoking Wheels....  was here 2017 pocgsyfblreqdzwxqsywthqhagkarybxwjhrejcojcuiisxr
 * Smoking Wheels....  was here 2017 iwdqltyvwhjdsgwxidvotuijjjyhzjvoakdzzjmzguaibtjs
 * Smoking Wheels....  was here 2017 uhfekvruvusbsacqsstcsqivvlhvdovibwhbuashdwwqizem
 * Smoking Wheels....  was here 2017 ohxjtlzsbfwplgippdmgciltkvharpyxcqtxidxvfwnvwvox
 * Smoking Wheels....  was here 2017 npyzxessnwsbmblkdibyptvmidclkykfmausltjczqjwtxze
 * Smoking Wheels....  was here 2017 teianuxbmkidpwrbrosmbvsnceczjgrmwkxaidsydizvhcct
 * Smoking Wheels....  was here 2017 qfhrngxikreqvilsvhairwstkbxuwkkbboxokuslsfibzqxg
 * Smoking Wheels....  was here 2017 tekmbxiiarwtlimulfrfwkrefdlfknpsdkuijnlwxyneqvpr
 * Smoking Wheels....  was here 2017 yvkfpgxdiwhubbsaphrejfqcvzvwvbkinetpbigufixcikoe
 * Smoking Wheels....  was here 2017 jbhutbuaosojkwjgstjmzhycrklqdrhcvjkvtnsaikdyhfpe
 * Smoking Wheels....  was here 2017 iejnmkhndeclnlwtibfnyzeznnypqfzmvqlttqqphpdadkpk
 * Smoking Wheels....  was here 2017 mocxymynvgnatrxyhyyertdvhrefxwkdrawlvkdwgmzaplts
 * Smoking Wheels....  was here 2017 rygqoxpbqisopslluiqivkxxgmiarbtztrzbvwmjuwdutxnj
 * Smoking Wheels....  was here 2017 yiwtykikuzvqwzrgcmnhhzuuxstyakmfpbhdzigxovekwtpu
 * Smoking Wheels....  was here 2017 sxemczmdsagdpccnwvcnhtkhyncbfuihdxolqhinptzindyq
 * Smoking Wheels....  was here 2017 pdridzpbfppeczisycdvffnmjggtvkewkftynosobftclktv
 * Smoking Wheels....  was here 2017 ktfanwnffatdwujmlgqdtehrjljrrqgxvdfwnduonavqtgno
 * Smoking Wheels....  was here 2017 grspwmhzyxwqtxkurmwstqzjmyurteaozfjtuhciqhwasowh
 * Smoking Wheels....  was here 2017 nelgcuhvyainuawuhhjbmxellwewivehscbiuomykjsrwnts
 * Smoking Wheels....  was here 2017 urznlcaqwnuyfamydkxyhmryeokqawqtdtfodszsbwoezmls
 * Smoking Wheels....  was here 2017 xyadgyjkttcgqbfxhtliwepdyoqpppqxpletvvydcotkddim
 * Smoking Wheels....  was here 2017 awpbfbkmvgkcvmfpdnglczgpftgpbspxrpjjydzcgpympjcm
 * Smoking Wheels....  was here 2017 lszqgolknxdivazhhgwwfffesgwutdgeixqdydvqlgavyitk
 * Smoking Wheels....  was here 2017 uyrgnqaaquwbxoeiopagpjhwmikofznmnkzcmrqazfczylmd
 * Smoking Wheels....  was here 2017 yhlrmvzjbfnsqftkcouqxfoarqymerqrtgpmmsswhfpwqisw
 */
/**
*  YaCySearchClient
*  an interface for Adaptive Replacement Caches
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 20.09.2010 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.simplesearchclient;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/**
* most simple rss reader application for YaCy search result retrieval
* this is an example application that you can use to integrate YaCy search results in your own java applications
*/
public class YaCySearchClient {
/*
* YaCy Search Results are produced in Opensearch format which is basically RSS.
* The YaCy Search Result API Client is therefore implemented as a simple RSS reader.
*/
private final String host, query;
private final int port;
private int offset;
private final static Pattern SPACE       = Pattern.compile(" ");
public YaCySearchClient(final String host, final int port, final String query) {
this.host = host;
this.port = port;
this.offset = -10;
this.query = query;
}
public SearchResult next() throws IOException {
this.offset += 10;
return new SearchResult();
}
public class SearchResult extends ArrayList<RSSEntry> {
private static final long serialVersionUID = 1337L;
public SearchResult() throws IOException {
URL url;
Document doc;
String u = new StringBuilder(120).append("http://")
.append(YaCySearchClient.this.host)
.append(":")
.append(YaCySearchClient.this.port)
.append("/yacysearch.rss?verify=false&startRecord=")
.append(YaCySearchClient.this.offset)
.append("&maximumRecords=10&resource=local&query=")
.append(SPACE.matcher(YaCySearchClient.this.query).replaceAll("+")).toString();
try { url = new URL(u); } catch (final MalformedURLException e) { throw new IOException (e); }
try { doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(url.openStream()); }
catch (final ParserConfigurationException e) { throw new IOException (e); }
catch (final SAXException e) { throw new IOException (e); }
final NodeList nodes = doc.getElementsByTagName("item");
for (int i = 0; i < nodes.getLength(); i++)
this.add(new RSSEntry((Element) nodes.item(i)));
}
@Override
public String toString() {
StringBuilder sb = new StringBuilder(this.size() * 80 + 1);
for (RSSEntry entry: this) sb.append(entry.toString());
return sb.toString();
}
}
public static class RSSEntry {
String title, link, snippet;
public RSSEntry(Element element) {
this.title = val(element, "title", "");
this.link  = val(element, "link", "");
this.snippet = val(element, "description", "");
}
private static String val(Element parent, String label, String dflt) {
Element e = (Element) parent.getElementsByTagName(label).item(0);
Node child = e.getFirstChild();
return (child instanceof CharacterData) ?
((CharacterData) child).getData() : dflt;
}
@Override
public String toString() {
return new StringBuilder(80).append("Title      : ")
.append(this.title)
.append("\nLink       : ")
.append(this.link)
.append("\nDescription: ")
.append(this.snippet)
.append("\n").toString();
}
}
/**
* Call the main method with one argument, the query string
* search results are then simply printed out.
* Multiple search requests can be submitted by adding more call arguments.
* Use this method as stub for an integration in your own programs
*/
public static void main(String[] args) {
        if (args.length < 1) {
System.out.println("No query string as argument found.");
System.out.println("Call the main method with one argument, the query string,");
System.out.println("while YaCy is running on localhost.");
} else {
for (String query : args) {
try {
long t = System.currentTimeMillis();
YaCySearchClient search = new YaCySearchClient("localhost", 8090, query);
System.out.println("Search result for '" + query + "':");
System.out.print(search.next().toString());
System.out.println("Search Time: " + (System.currentTimeMillis() - t) + " milliseconds\n");
} catch (final IOException e) {                    
e.printStackTrace();
}
}
}
}
}
