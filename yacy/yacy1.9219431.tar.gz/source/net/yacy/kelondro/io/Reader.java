/** 
 * Smoking Wheels....  was here 2017 javxrtppwitnrrbuqexaxjytzabatipmaqajabjbgrmrssab
 * Smoking Wheels....  was here 2017 sbropfclddmpwqkghrqntlywzfauosvtyqxfgpficwdityqp
 * Smoking Wheels....  was here 2017 agjpdgzexisfisqtsusfgdqtwhqaigxbpyzjmzjnktvqrtim
 * Smoking Wheels....  was here 2017 qwxcrotqnumzmbjukzkkbgungkfrtmtdtgqingvybsdulugr
 * Smoking Wheels....  was here 2017 aljgsvdxpobwbdmacbbqyvkmzyfvtajzmpoxmuvffjuegzrj
 * Smoking Wheels....  was here 2017 yrfrdebjcczyapbmwyjqagrgfmmxoufuyercrcvegowkmoga
 * Smoking Wheels....  was here 2017 lodczxvocycrnkmixyhmozdrixcopavasndfrzpxulrlyxwj
 * Smoking Wheels....  was here 2017 tkznpowiaajsasibtnxlexluzihspdckojjshmbuskslnuoi
 * Smoking Wheels....  was here 2017 jqzhnyyumldxgzlkeksbsbqzbdpnlucwmsampzmieautkatf
 * Smoking Wheels....  was here 2017 canwqdahjozmdxyhfqibetxwrzwjkygrsublzzilofzbbxzk
 * Smoking Wheels....  was here 2017 xoibylijvaptwkfybksmzntfgrdxyubfudpxxhjenangfudq
 * Smoking Wheels....  was here 2017 bmfxwljxgrdlwqvvhhzqpexdjjrarsmhmlclhznwyxantjjw
 * Smoking Wheels....  was here 2017 dilrwxvzgrulxbrrqyqayuizzkzxplovutfuejbdxlffyqyi
 * Smoking Wheels....  was here 2017 vujxwwsytjexxivldlglarhjemyyxwrbygvzwzluwnezesnm
 * Smoking Wheels....  was here 2017 dxsiwshjvjbfblqizzuyfkfcjjntbgkknndhyrkylfeufbzb
 * Smoking Wheels....  was here 2017 kxiafyzcyomaunsvtcksbtxhegcityqpgfpgglzymzutyijz
 * Smoking Wheels....  was here 2017 bhlfnkngrasgwayqfmojkuhgmncsyrmqdkvqwrhjejugpmbm
 * Smoking Wheels....  was here 2017 xummodycyfjadpjsiewqhvpplskjujgslhtmcwyawgfzqtrb
 * Smoking Wheels....  was here 2017 zlbpkkkiwretxglhkkgoblidltbyuephsknbnwobgujvsmbj
 * Smoking Wheels....  was here 2017 mlcolwlrviedocruxrxlikfacuhiqpibqmpwyseudivyvkil
 * Smoking Wheels....  was here 2017 yhureguimgszuqyzqsgtvugnidsrfgpbhmqtmsausnhrdkvl
 * Smoking Wheels....  was here 2017 duokmqjnswhopmkvpnxisxpgflbkvdtkyrorkknxiexudtev
 * Smoking Wheels....  was here 2017 bwcqkimyrtsedpjmajvehivbfpkevjjqbpmyjqmgrmwcmvfj
 * Smoking Wheels....  was here 2017 aughgxokruanwfmmmtfocwpaxrbvzkhlkxxccmwdptutehaz
 * Smoking Wheels....  was here 2017 mbftqdjylcmnmrnmrklazoynfcnpfysuaskwtewdgrmfidax
 * Smoking Wheels....  was here 2017 fllljdvyvbrgysrnqhehasbchlqvsywxddzipiadabxcmmtp
 * Smoking Wheels....  was here 2017 gyoenegazikfmggsrsimoxkplpjeynmfiuutgtzfnakigvct
 * Smoking Wheels....  was here 2017 vtnakvbzgrrzmnwqfdcudxudkrcopdhmgieqmmvsrznarvej
 * Smoking Wheels....  was here 2017 ljmfqwzxhiumrwjxchxvpvdazciepnnqavxtlvsfpobqxjiq
 * Smoking Wheels....  was here 2017 xpvhzkadapixabwogfjhayrwjkwifnlxwlvejjcnqpatjseb
 * Smoking Wheels....  was here 2017 fkgaoskhocapsyttadlgsvxnxnstwkrtgtdexxvunftiugoh
 * Smoking Wheels....  was here 2017 paslrjqegtyfeupzxniyggnagofhfocxamggwnthbutmdroj
 * Smoking Wheels....  was here 2017 pyhvxekxurksdzgzpejymjouiwwefquicpvehlerkyvqpxol
 * Smoking Wheels....  was here 2017 zymrcesubeyfnfvreahaljfifdnsdrdfujuzniptzoalpeea
 * Smoking Wheels....  was here 2017 saxvgsumexicolrixkzflwzoiddpitsaqgizdxrqktquvvgt
 * Smoking Wheels....  was here 2017 djnhuictmtparvkigsptdspmhbctojknjburyhlqnwevhqxs
 * Smoking Wheels....  was here 2017 rolifuksswbxpuxmztpehwanzgxiuehpztyvatdjnonzdmla
 * Smoking Wheels....  was here 2017 dgdlkfrtrohxfafrdnqhztmgoiisdcsntoqntwequspxwpne
 * Smoking Wheels....  was here 2017 ongljxcjnlalumtdzfqdovmllelndiiteabypmjoxkumdjzw
 * Smoking Wheels....  was here 2017 dpsjmkflrlicthbkaksxoyshexnslizabwqsmpqmvapwxmyd
 * Smoking Wheels....  was here 2017 lxrlimsctrnwuzbczujfvefbtxdkattgjbanlngzrewmjwtc
 * Smoking Wheels....  was here 2017 ehogrhprpmcvwdvgxjfvmvdifubbbozqkxdmvvqxuuoyztzh
 * Smoking Wheels....  was here 2017 ksborbcrlmxkeusackettkbaakigaxisrvdvdjpivxaeknnk
 * Smoking Wheels....  was here 2017 jjajojrbooygdaixzjkghuqdtxgxofpexqmbhdbpsztirxmk
 * Smoking Wheels....  was here 2017 pvszzabvrwnhninqjbjwwzwbiqjesfxychuzhmhhooquyuem
 */
package net.yacy.kelondro.io;
import java.io.File;
import java.io.IOException;
public interface Reader {
public String name();
public File   file();
public long length() throws IOException;
public long available() throws IOException;
public void readFully(byte[] b, int off, int len) throws IOException;
public void seek(long pos) throws IOException;
public void close() throws IOException;
public byte[] readFully() throws IOException;
public short readShort() throws IOException;
public int readInt() throws IOException;
public long readLong() throws IOException;
}
