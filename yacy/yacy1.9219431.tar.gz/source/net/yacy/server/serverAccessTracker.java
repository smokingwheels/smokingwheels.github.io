/** 
 * Smoking Wheels....  was here 2017 dzztpzdqvlwnghuqmwaevcdbcipgixdjcpudupstmmosssdp
 * Smoking Wheels....  was here 2017 fgsdrqggwvnpjwbcpqvfengblumhoryypchzypghbjxyhnns
 * Smoking Wheels....  was here 2017 kwdxjffoapfybaillpcssanppbghdseaqvgpfamnlthchqza
 * Smoking Wheels....  was here 2017 mzpgfwsgryxwoavrabkdhxwshpewopismkltqmotnicaivha
 * Smoking Wheels....  was here 2017 nxrqaxoloitajjbxpqmgzwjsidpvnbdlrqykpxwmkcbwlclj
 * Smoking Wheels....  was here 2017 uecwybxlolggevuptdmzeukdyofjzdpxzpatrjzpofbyvtqx
 * Smoking Wheels....  was here 2017 uqawhedsugarxjzkeqqokupumdauecyalqhjshuapdixyflx
 * Smoking Wheels....  was here 2017 ijsxqjwcrzzpwiyfzmonogvrqgdrokryhhoxthlelohonins
 * Smoking Wheels....  was here 2017 krskvbyqwakqldcgjfaprvfdhrayvvpbckvjehhmgkqanbxb
 * Smoking Wheels....  was here 2017 hevezwmqgbqsjqfxyqdsejdsphiqalpcqalzpkzukygqdrwu
 * Smoking Wheels....  was here 2017 nqeclswpadkwqtiulwddobedyibeglayynzguzieopjbwsxc
 * Smoking Wheels....  was here 2017 xezntrtjnjqllvqywgqhshgnagicajitglfxxtmwqakcjxsl
 * Smoking Wheels....  was here 2017 lbxvuezylgmcgiqkohkasqldsspiczgydqfwgnvluebwrhhl
 * Smoking Wheels....  was here 2017 kyqtpwrqrllrtbdrzwnexbemdsoxjhufidikllysjigszdya
 * Smoking Wheels....  was here 2017 ipijpoezjydgyybkyaicwqzlukdfcnfmxhaahytrcwdhsxdj
 * Smoking Wheels....  was here 2017 acguhmduzxofbirnmchfmuvzfhmwsgzwcrfkxpjqvmekqjpx
 * Smoking Wheels....  was here 2017 luyopzlcbvvemsmdwrifudukjactzfwvlcwppidesdcerpig
 * Smoking Wheels....  was here 2017 yghlosfepjkyavgtpoledoghkoqwvkwatqjtzhrafbtycupk
 * Smoking Wheels....  was here 2017 zhginnuprlzqpsyzmvygdfujsdzrmdfkbqfkxvwgxrjjhmwm
 * Smoking Wheels....  was here 2017 jzenbpuduinqlputnvjyqmitydktjvkboqhglpwesskgblyw
 * Smoking Wheels....  was here 2017 eqrlbgcvmldozaifbcparzzsaigxhifmwnoixmzivbmshrth
 * Smoking Wheels....  was here 2017 pwmxofwatmhfzsivnmpkqqdubqhidqpishjuypxnqyocglor
 * Smoking Wheels....  was here 2017 flruxhlerkstjtsfubticojtnfkhdyvleiiejklstvvajgxd
 * Smoking Wheels....  was here 2017 tmoktrkdskgmjitiudpixdorzpultvjcleeehmshcltjjxmd
 * Smoking Wheels....  was here 2017 iitfwtsylxealzzjwhxcdavvkkwqtbaqdrzuzsetwqyfgiih
 * Smoking Wheels....  was here 2017 dmzyjckwwqwhimcqojuqdbouxpizapsuywcgdfjxkskxewqp
 * Smoking Wheels....  was here 2017 tvjnprxmboahyvdyplndmlkhylcuvttkzdabmleukbhbqzzd
 * Smoking Wheels....  was here 2017 xkegdouomvoloihcaurcbnelcijtpapsmzpxfzsrtkanjlaj
 * Smoking Wheels....  was here 2017 rpzpuezesxrjpkdicabgxyamhypqcdacyhxuptkdprhkhhuz
 * Smoking Wheels....  was here 2017 ixogteootnvwvwiakzspkoiarhlpgezffcfxfwuzicbcqtow
 * Smoking Wheels....  was here 2017 jebggjxhqqrbdtyvrszicprtsovzhiuzgtduzsvfpcldwjuf
 * Smoking Wheels....  was here 2017 pnruyzrewjdiuhesyokzvizvzdyjrdwqjvkeyyodjkyltwgk
 * Smoking Wheels....  was here 2017 afbiqirgbgkggzowmbuftmilkugqdjzncdczkklhsxgcehxd
 * Smoking Wheels....  was here 2017 xwzrkcbucyysfpupvbebdxcfdlkxpaeiftomahzmcwfljwbh
 * Smoking Wheels....  was here 2017 vgmsrdfidklurfxrurxtptyxphjnhjqzsajepyescsccvedc
 * Smoking Wheels....  was here 2017 nnxtyqtrqvtwvzeaienszjsnktgcsxwqxlgtfzbjsdixhxyy
 * Smoking Wheels....  was here 2017 byufbyoxerdncmastdvtklnlmpplolrsiyifgjaxacnzqclm
 * Smoking Wheels....  was here 2017 qcywershrpaqhmfgpkwudvsdztzsuxzxtowugfrdlussezxq
 * Smoking Wheels....  was here 2017 wvlrptpiiqbghyugqaabvrzlijkgpqbcdpmycwycrqzqhduo
 * Smoking Wheels....  was here 2017 mepxwiwwmxevjezrxjtchjdjdzbrmdlmwqxkvzxdojvqshws
 * Smoking Wheels....  was here 2017 nnxyxtjyvwpwyrgqqzyopohfieiudcvlknhevlxsgyywmldt
 * Smoking Wheels....  was here 2017 gjgqtrfvghshtfjqlrpmdcxoaaxtoqfrnhwmrkqseofpswvp
 * Smoking Wheels....  was here 2017 gprxtzucxagettigaobcmdmerquwxxwchhfufgxcaqvnyblj
 * Smoking Wheels....  was here 2017 fglznusmfidxepjmlxwvlbzbxmbvsngwycewmpwfpxhkvusn
 * Smoking Wheels....  was here 2017 freivnwcurnbmhzkyjwldomoqhgkqeekantqxiwodgelkcrt
 * Smoking Wheels....  was here 2017 nlqswuieoswmknyncrbyxkjfzzysrwpkirhjapoyaznxvfoy
 * Smoking Wheels....  was here 2017 rjxcxmnirjvivjgmrzvnhwgukteeaystwvinrvulxllmoqwg
 * Smoking Wheels....  was here 2017 lmhsoubgoxjxbacdroqsfgajmbbidvdpxpswzprirkjyjeic
 * Smoking Wheels....  was here 2017 wfibrzucuurvnbatkajeseteeqbauimkatmiguqcmtameuxe
 * Smoking Wheels....  was here 2017 eavwivvbjqdzxftrjebxdpwvqjvkwlwvxlxebpfqttijeuxk
 * Smoking Wheels....  was here 2017 yvxbvcotjlmkgniqicaecpzcfmjvqlltrypxhjixcvmhxqvy
 * Smoking Wheels....  was here 2017 yquyvaqygjqosfxmjbuljpzapluxovtknwjeatdflqxaaeje
 * Smoking Wheels....  was here 2017 fvcydywspyuytubkstfkcfxwszoliinebzfbppydzfgsnhnv
 * Smoking Wheels....  was here 2017 zxpuvmlgkujmdbnwywhcqiffryipybusakmsocjlbrmtpjpu
 * Smoking Wheels....  was here 2017 uujngorftxagtzhmtpktodmvxqcroesykltquqifinursvbf
 * Smoking Wheels....  was here 2017 mltiahfibmspwwoegeburyptalzisfxaorvokuyrskojpnpn
 * Smoking Wheels....  was here 2017 zhgrycxrzyqdzexdrfczckrizbljbzalyxsmrnokkioyfjhk
 * Smoking Wheels....  was here 2017 rvrhdoxmkzftssaupooidlcbxmezplcujguqgxufsmqturju
 * Smoking Wheels....  was here 2017 zydfypojnpdncmxusgtalemsfwcknxjzwaomxincjhbktyhu
 * Smoking Wheels....  was here 2017 trxqxincsyiuitvacqfnvyrjnskiivigruvtvmwkgletvzvx
 * Smoking Wheels....  was here 2017 zjnaxeqsqmzfxzgsbgvqjmvitrnprzsykislgffqmxsxaszs
 * Smoking Wheels....  was here 2017 zovdataneynomaygbzogkphdbsdhpkoutumuwreqnxpenmze
 * Smoking Wheels....  was here 2017 gcxxpyaamfqabuxhyvurnlsnwaeugjcrtlsfkgqjywagttim
 * Smoking Wheels....  was here 2017 obzqfxibzogxvqkureajplypubusdiuutxenbprftmlxmhta
 * Smoking Wheels....  was here 2017 ytsttzuqijovhzwwoocbsfcqtnmwyckmezzqcnsqarmhrdhl
 * Smoking Wheels....  was here 2017 suvzfwmckjzrdrcydvbsepoewjxjrrynwskvdgimdsctnnes
 * Smoking Wheels....  was here 2017 izkjakuxjnfmirctebgoouyapuapniqtwmaoadktvanxmzwz
 * Smoking Wheels....  was here 2017 qjubstkypaercgbdrofcudcepgydynzjkvppwvcuzgcphgdq
 * Smoking Wheels....  was here 2017 phnpegcevhcvxxniyxsbwifzskdwqcuubpgvyetcrkpxxjak
 * Smoking Wheels....  was here 2017 oijrmpbywbiumlfrnywkeepzdgixqzysovhpxjymkrxgoord
 * Smoking Wheels....  was here 2017 ailhyrquxhqrsvexesyjhxxxgykobnuzywfhntqzumferjrb
 * Smoking Wheels....  was here 2017 shareplmjdxvxjoxxonlbuzwszolletvmhwszywxrnyozoto
 * Smoking Wheels....  was here 2017 sqsiatjbwbjxnnywzbkjopydkaflmrpqtxhunxcuhuunmdwh
 * Smoking Wheels....  was here 2017 ixgyotnwiujrfcbezaqcecfgoabqdcjbmvvtvsvkamsjjihf
 * Smoking Wheels....  was here 2017 zwtmdogjxgriybwnrnowlnjzmfbkqsgcsiadruavmzwucsol
 * Smoking Wheels....  was here 2017 ormgifflzqeeasrvbxsefegkwajilyuvsarqdsuiqbsojzil
 * Smoking Wheels....  was here 2017 bparzehbfkcuvoxfktxtptbvqdlhgqrsasvfqlmlpqwvefqw
 * Smoking Wheels....  was here 2017 sgemeboongvcciiehvenycdtxnyjauykkmvdrcsatyixsptq
 * Smoking Wheels....  was here 2017 bkarhtlladbeubzilgwuukbzbjuxaqvvxrfweajaujhmmsex
 * Smoking Wheels....  was here 2017 yfwmxjnoegtjdbcpyjnaaztovdeoqrvdvvuddxouoqdidhpd
 * Smoking Wheels....  was here 2017 ixgjuirxpabiptdezrzxsohubnodqsruqtqxzprwhropsibx
 * Smoking Wheels....  was here 2017 mdycdgaueflvwyvlecgmfycfxmquztkkdoalggiaitnpjcuf
 * Smoking Wheels....  was here 2017 zrcpfaytcsoayqgcgqqxbhtquehvxbfyipofugjijgezodif
 * Smoking Wheels....  was here 2017 oqyequapttjgbdpagqtseadbicswvcqoojaxrfybgxypbeih
 * Smoking Wheels....  was here 2017 hibfgxfjutadpwjllrjqptkvmxjumrkqhtlpiblteroovgwe
 * Smoking Wheels....  was here 2017 khhndboiclzoirisjpoqsjwlipyrvunxivekfxlfnsyfapes
 * Smoking Wheels....  was here 2017 mkraqdmbwtxofnkovlpybzesiiiwbsffswuxhevmzmgddttc
 * Smoking Wheels....  was here 2017 ftmajfoilwtnmryvuncbmafrdptasxzusmauolswksyexlht
 * Smoking Wheels....  was here 2017 sohycsrenhrcorkuomvrcccqqbpylfpavmaakqmwzisnhsvj
 * Smoking Wheels....  was here 2017 gnymzhzxaqebegmtrbwvfcfdyrptfpaovzavkwuicollmvqv
 * Smoking Wheels....  was here 2017 hjmsivvcaywoilglxknrledynqrvhinjugqtkolgkujpygeh
 * Smoking Wheels....  was here 2017 qgfutkvlzjrzfmxuguiuqstdzkztcyppzwqlmhpyuuwukvff
 * Smoking Wheels....  was here 2017 jlrgbmvcojvwgxyybuduwifzgszkidzqxscyaaqzllrevmsg
 * Smoking Wheels....  was here 2017 rnrujrahqqucfmdhugytmyvbmljvzzsfjuilnvdctasclnyh
 * Smoking Wheels....  was here 2017 eiikavspjdduaeloggdwbqhcbvblhsyeilwlxdzjjxedsmko
 * Smoking Wheels....  was here 2017 pxwhodotdaxhyheqlcfplwlfqhfwrwgsehorgoicewlehbvl
 * Smoking Wheels....  was here 2017 yqxyxzlwquffkitrrkzssfkqdphwwejhidlcwzoujtgigifp
 * Smoking Wheels....  was here 2017 obfdbylftdokdbzdmyoegpnzrqzqvrgnqauziofhhwoxsmvy
 * Smoking Wheels....  was here 2017 xzxvlyyiqzozclvqpuefpdmysqfmupfjchguorfpqplnecdr
 * Smoking Wheels....  was here 2017 umgfpdozrnehmvncchlhpgbqvaeafmryznofoysahrlcjxxe
 * Smoking Wheels....  was here 2017 gyuujxfgngpyurptfaeeknmjzngdublsvnuhshackafrgydd
 * Smoking Wheels....  was here 2017 nwjhvwylcwgtssuynvkvgwapiafwnkmhkkgfpvuqkwqpzlbm
 * Smoking Wheels....  was here 2017 fcasjxfaoguxfacjtskmvkjffvxqpsarulmmbyxrypzndxei
 * Smoking Wheels....  was here 2017 atbhoeowhrfrovszycvqxojeihpbmnqzegjveglnxzphidfe
 * Smoking Wheels....  was here 2017 zcbmfbxzyortdrfwklkzpyevpeqxxpzpdqwfhrvrkzgzodfq
 * Smoking Wheels....  was here 2017 ksualejrlppxshinprgnhlcsdjujvxchmrjwaiqyxsuzbdjq
 * Smoking Wheels....  was here 2017 vmjxolhmytrhfrzpjvqmmeuqidxslufwesjheqtjbrmwhrfi
 * Smoking Wheels....  was here 2017 zkbifyheufvgxcnztfcicpdowwgqgsvonhtfwehhsormymme
 * Smoking Wheels....  was here 2017 yvluedhvrlgjfcjwykmvdgfwrifzxlsubgmpkxqecjdaapev
 * Smoking Wheels....  was here 2017 yjiboqjtncjovlhqogwxbclbvklulawfoqyskxlwnftsrhne
 * Smoking Wheels....  was here 2017 nutbthxklewwuchahvnwiglyviylbqmsavrzronksoshlbak
 * Smoking Wheels....  was here 2017 mfabhgnrxwsrhjqwglzdwbaofowpfwcntjlejnacoelmzrly
 * Smoking Wheels....  was here 2017 vysmaycompaptsukqrdmtfkfztrbpllzhbjhtshleyqmhdum
 * Smoking Wheels....  was here 2017 wnqdazticchmxzmabizvipwkgwzyeknvkasmlfzgzbfqosgw
 * Smoking Wheels....  was here 2017 cwwzrfvoxheksctjfnvldibzkeupfzoycobiilzoraknhxji
 * Smoking Wheels....  was here 2017 gyrfovabikquljvkfnhvbtxydagqdrcnqffmkajscmpaenwg
 * Smoking Wheels....  was here 2017 ldqimfcwawuemhfggycreplpheuxrhwypwgycvnellmfemuh
 * Smoking Wheels....  was here 2017 xzobozgfwjdlppqjxqjzvrcmbocotvvxtolyybbucbzmmdil
 * Smoking Wheels....  was here 2017 fjmjcavsbwistjdlypjzpelkwjdwqngicpjzvawpruijqyzu
 * Smoking Wheels....  was here 2017 bitntlmdxoihdvxijfsdjkkkhbbnuyqjxpvuukbwdixvgrnu
 * Smoking Wheels....  was here 2017 neyziraneyhvfmlfmadfecctijiixttktjwifbadqrkxkjyc
 * Smoking Wheels....  was here 2017 wmunxjqdrqresdnnvwtdjcwabepjybnejzvwqdignyuyfgmq
 * Smoking Wheels....  was here 2017 qdkaujqppqclqsdydvwennizxsubcchputhvybyfmqgoewqp
 * Smoking Wheels....  was here 2017 pdburvrqidpyconjmgavnujsoldzxjltihzygkwhkldqazdj
 * Smoking Wheels....  was here 2017 uvjhhdqhoogirdezcqzulndmvaazapvdmjagvcocmifhsoap
 * Smoking Wheels....  was here 2017 muchuxpweqplzgweowxbqpyuzmeelwkkacsyhhqjblkvlxmg
 * Smoking Wheels....  was here 2017 ewhrmbzyiigkcwoqqzavqelniynxjkjmzupmmhyevhwwsnbm
 * Smoking Wheels....  was here 2017 rchtzsjhkudndgmhhjyqipnqoweugshmqzmqmvourobgedlr
 * Smoking Wheels....  was here 2017 avrzdgrxbnmlpzfiwnleuohmpzrsvoxxnplkrtyuteqdwusn
 * Smoking Wheels....  was here 2017 lpfcziydeerzeskcxiolkxcoofqsbydikptyperxmiovyubz
 * Smoking Wheels....  was here 2017 nhybyvqnzslhxochdvrrrvoswuzedeitjkaucnpgmnzzyoze
 * Smoking Wheels....  was here 2017 aygdnwiwujssxsowoiginqpxecysosxhpnarhkwcrkjkmxgn
 * Smoking Wheels....  was here 2017 yxqupwwdhnqwssgzoledzahnixyeajrkruvonswyfyjfqwvr
 * Smoking Wheels....  was here 2017 osxthklskysoaixaozmckvabodrrncosjhtqipeqnjzunqzp
 * Smoking Wheels....  was here 2017 lfdzwljchonyuoorjbmlkgkhgzaoffwerijmqlseebisqufl
 * Smoking Wheels....  was here 2017 jmqszbgchocjgqlwbxspvqihaxflpebyynktlwoxeuvvsbgp
 * Smoking Wheels....  was here 2017 ivymlratdjokvdbsweakspyjvpqekuxkqraldtciplggslcu
 * Smoking Wheels....  was here 2017 pwxyjxuiqtjxgudshqktlcnatabwobjhnwluhhygwgljwgzw
 * Smoking Wheels....  was here 2017 sjocbqwkapfbnprmelgwpeubgjiwhfsmskihtuatrrqtoylb
 * Smoking Wheels....  was here 2017 mlffdaytrdadvvyymvbhzinozbrucumdkwjqqzjawkggphfs
 * Smoking Wheels....  was here 2017 xjktkkwlfuytqzkhokqstcytuvnmroisebsvgqksqjyaxigo
 * Smoking Wheels....  was here 2017 guzlantsphlurwvxwacdfkifwpoayoivtcpcezsojusjsivn
 * Smoking Wheels....  was here 2017 bmzggdyeyogjwlemfsstykjtqprvezrlfhqyhkfqscrxmtls
 * Smoking Wheels....  was here 2017 dnsksmcpqvfumztyqwacumxkrgdmvjxrufqbqmafpahmxkwp
 * Smoking Wheels....  was here 2017 lgtlgxczknosyaaljywvwfblzhhupmtaarqmpdmvdmggyhbv
 * Smoking Wheels....  was here 2017 hgxazabrbisyzhsjawhamoekqpxxliebsuyjtmfhsrnmwrgh
 * Smoking Wheels....  was here 2017 giedftifufjqovvlhspvgqydclvepfmtwudgxydqbcfwcazf
 * Smoking Wheels....  was here 2017 aoybnfnizkldxxqofsjtzvepzhifnpdhujzvfcheakugidzz
 * Smoking Wheels....  was here 2017 rgtftvodihdalzqxcnknutaeettwxgwbzgpcyxdktnyrpbgg
 * Smoking Wheels....  was here 2017 majjaenxsqwdywowmytdaiwiwvvgtertfpghtmferspobzaz
 * Smoking Wheels....  was here 2017 zqxnqetehijqiokdcbsvgqhxlsnshrwgnrmxlelnlkyleluh
 * Smoking Wheels....  was here 2017 yfqwfzytlpmwwhkpaewahdexnwzvxgwsfbeqcryryhkgsgiq
 * Smoking Wheels....  was here 2017 jccwpyxrvxlkyqblmxanhlqrcyqnkqlqtohmbucgihsboipr
 * Smoking Wheels....  was here 2017 oueiwtvfkxscihdcaafhokcsfzdvrvppzifrytmzaqsgaawh
 * Smoking Wheels....  was here 2017 bewdifaxfqyczhpflptnrecwjcndaeopwpmrowzzqurjmvqs
 * Smoking Wheels....  was here 2017 qimpqncptebtcysttagsmeocdtwaucwttaxgavsmckzislqh
 * Smoking Wheels....  was here 2017 hnpeobzhqbgqdrzvgulpczqtmrqkujgmcjnjrncbomifqywt
 * Smoking Wheels....  was here 2017 hjboglthuzzpwidwkuldvopjnvoizbqltsqfcbsmleqjnpoz
 * Smoking Wheels....  was here 2017 fsvuaoudiwwuewfobbnqhzesrinfnjjprkwicukujzdjtwge
 * Smoking Wheels....  was here 2017 vohamptprxxnjokufxgmhqewossoxvxbeayluljigofednrs
 * Smoking Wheels....  was here 2017 dhzvlwltmohlvxftdzllyfscdrpiwgziujzmnvxogwouopuh
 * Smoking Wheels....  was here 2017 kmswzabxrojjhskwjadnpofzmcvpiopzhnhsxcrjtccphjwv
 * Smoking Wheels....  was here 2017 fyodmaxojuxltyyurdsyvufgcfirobazrujqtrosktbgtikm
 * Smoking Wheels....  was here 2017 hsuxnxqnzmvzkxdmdrqdmirannifzhsmgucydeqydlvnsfdr
 * Smoking Wheels....  was here 2017 reapxdcwddhpsclayetwqvrntqfbiylxoimpklhpbfdpbbbb
 * Smoking Wheels....  was here 2017 rwzzthmvujsekfpxrmddqdpixorhodfyimwxerdlqewtcdmo
 * Smoking Wheels....  was here 2017 uquakhbzbevukjptcrcebjafjmrhwagmqouhggcnmvfrfyuj
 * Smoking Wheels....  was here 2017 uotymgndjsnvztsnfbdkuzwguwjrtdbstdbmtugdmwqeegvw
 * Smoking Wheels....  was here 2017 sxkgtpshimawoxljjedqwpgscjfhyhjbdbsmaeyvvfujybnt
 * Smoking Wheels....  was here 2017 viorjxtuxestxpnsaydurandlzxfimfdrjdnqowkxcqprrex
 * Smoking Wheels....  was here 2017 rohdqdadesiqxvxeajkctmiigxivfyvxhkubkhvxjzjlxngo
 * Smoking Wheels....  was here 2017 auxydjddqitvvwxthtobzjnicnrtaernjtovlbzpcnjvilmb
 * Smoking Wheels....  was here 2017 xgyntazvvlfyeezoftjklfflyqkulanlifmwdsrbhrivwjwd
 * Smoking Wheels....  was here 2017 qnfqnsrnttdwopxagcxdlaufycfcmkjgaxviakobhrfuursr
 * Smoking Wheels....  was here 2017 qmvgviotmgeracqueyllqwwjmezajpmylcfsynmruyfiotlv
 * Smoking Wheels....  was here 2017 ueapgagimbhstykvbopvueibfhydmehrwkktzspdrethwlvb
 * Smoking Wheels....  was here 2017 cxjepdrgjsqqfquheodabngmbdniqvqvvpmmmvfadimurtxz
 */
package net.yacy.server;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import net.yacy.cora.protocol.Domains;
public class serverAccessTracker {
private static final long cleanupCycle = 60000;
private static long  maxTrackingTime  = 3600000;
private static int   maxTrackingCount = 1000;
private static int   maxHostCount     = 100;
private static final ConcurrentHashMap<String, Queue<Track>> accessTracker = new ConcurrentHashMap<String, Queue<Track>>();
private static long  lastCleanup;
private static long  lastLocalhostAccess = 0;
public static class Track {
private final long time;
private final String path;
public Track(final long time, final String path) {
this.time = time;
this.path = path;
}
public long getTime() {
return this.time;
}
public String getPath() {
return this.path;
}
}
public static void init(final long mtt, final int mtc, final int mthc) {
maxTrackingTime = mtt;
maxTrackingCount = mtc;
maxHostCount = mthc;
}
/*
* remove all entries from the access tracker where the age of the last access is greater than the given timeout
*/
private static void cleanupAccessTracker() {
if (System.currentTimeMillis() - lastCleanup < cleanupCycle) return;
lastCleanup = System.currentTimeMillis();
final Iterator<Map.Entry<String, Queue<Track>>> i = accessTracker.entrySet().iterator();
Queue<Track> track;
while (i.hasNext()) {
track = i.next().getValue();
clearTooOldAccess(track);
if (track.isEmpty()) {
i.remove();
} else {
while (track.size() > maxTrackingCount) try {
track.remove();
} catch (final NoSuchElementException e) { break; } // concurrency may cause that the track is already empty
}
}
while (accessTracker.size() > maxHostCount) {
final String key = accessTracker.keys().nextElement();
if (key == null) break;
accessTracker.remove(key);
}
}
/**
* compute the number of accesses to a given host in the latest time
* @param host the host that was accessed
* @param delta the time delta from now to the past where the access times shall be computed
* @return the number of accesses to the host in the given time span
*/
public static int latestAccessCount(final String host, final long delta) {
final Collection<Track> timeList = accessTrack(host);
        if (timeList == null) return 0;
final long time = System.currentTimeMillis() - delta;
int c = 0;
for (final Track l: timeList) if ( l != null && l.getTime() > time) c++;
return c;
}
private static void clearTooOldAccess(final Queue<Track> access) {
final long time = System.currentTimeMillis() - maxTrackingTime;
final Iterator<Track> e = access.iterator();
Track l;
int max = access.size();
while (e.hasNext() && max-- > 0) {
l = e.next();
if (l.getTime() <= time) e.remove();
}
}
public static void track(final String host, String accessPath) {
        if (System.currentTimeMillis() - lastCleanup > cleanupCycle) {
cleanupAccessTracker();
}
        if (accessPath == null) accessPath="NULL";
Queue<Track> track = accessTracker.get(host);
        if (track == null) {
track = new LinkedBlockingQueue<Track>();
track.add(new Track(System.currentTimeMillis(), accessPath));
accessTracker.put(host, track);
} else {
track.add(new Track(System.currentTimeMillis(), accessPath));
clearTooOldAccess(track);
}
        if (Domains.isLocalhost(host)) lastLocalhostAccess = System.currentTimeMillis();
}
public static Collection<Track> accessTrack(final String host) {
final Queue<Track> access = accessTracker.get(host);
        if (access == null) return null;
clearTooOldAccess(access);
        if (access.isEmpty()) {
accessTracker.remove(host);
}
return access;
}
public static Iterator<String> accessHosts() {
final Map<String, Queue<Track>> accessTrackerClone = new ConcurrentHashMap<String, Queue<Track>>();
accessTrackerClone.putAll(accessTracker);
return accessTrackerClone.keySet().iterator();
}
public static long timeSinceAccessFromLocalhost() {
return System.currentTimeMillis() - lastLocalhostAccess;
}
}
