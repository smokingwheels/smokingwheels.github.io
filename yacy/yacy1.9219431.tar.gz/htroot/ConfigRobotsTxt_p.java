/** 
 * Smoking Wheels....  was here 2017 efyuhajkptgajurbnctmyyokrxamtdhesczocbdcmncbjcum
 * Smoking Wheels....  was here 2017 pmeymiadrgowuzbccppwhmvsdgcetclbwiggnexjuvvhausg
 * Smoking Wheels....  was here 2017 otzgtlrxosvtpfscmabtfiykeotjirikiqkziipqvlcssyce
 * Smoking Wheels....  was here 2017 wuvgwmiabmqvveszrjuwvuddamvlswglhikuxbsvbeyzxunv
 * Smoking Wheels....  was here 2017 loiszsedjdrmpvkzxwthllvsawjbjuxojvkzugyzaepzgtvv
 * Smoking Wheels....  was here 2017 qimqisrzvqcjkhlptadgqcveuwpcyybogxvavwhmrurwuodf
 * Smoking Wheels....  was here 2017 ypjjogqtcadkxbrmxphhgucyguetlzwizohtbhzvcrxaqbue
 * Smoking Wheels....  was here 2017 bcmillyscsitcuepkoxfivvooiukcvrduaudwbmztrkehnld
 * Smoking Wheels....  was here 2017 bvlkboxnxhnuekhgoexagvnwahnrgrclfvkntzoyfykdkiww
 * Smoking Wheels....  was here 2017 faeotfzzxrseocruuymannxzjvrnrzyyzrqjpcebjumczegh
 * Smoking Wheels....  was here 2017 zfwbcdweuyfvzheayparaayfkiubhkkpepdnltnzkxkmezxq
 * Smoking Wheels....  was here 2017 ddxmykpllnowjsvvzefvupyeijqsiwtrzvtyqldmrdfxmzlk
 * Smoking Wheels....  was here 2017 stzphjijyynsxgcmewzmevhrnwhcfoqoywtytbtsuoghonsh
 * Smoking Wheels....  was here 2017 ziakopqvsefabcmmaelxsntwpyadqyxzwlmbpphyrqatjjvf
 * Smoking Wheels....  was here 2017 ljeefvewkgvsnsyliwbqgtiakxkapqqzroqbgjaumxhtclel
 * Smoking Wheels....  was here 2017 vpvmedywwpzxhtmkbxmmxugselecfrfsrmdybyldngeygxhk
 * Smoking Wheels....  was here 2017 easbmxfkhvlzmenonpqkyfywfklbadgqkreboeganvwdlecv
 * Smoking Wheels....  was here 2017 tytzkpkhzvhrpcrjfkssyvenexluqnplpxcvpbkuizapryqs
 * Smoking Wheels....  was here 2017 btalqchrqrtvjbsnvbcytsyazhtkbniegeqdfyfbbjjrefig
 * Smoking Wheels....  was here 2017 whbbwkvvdukprqwbmolwkemztgdjmawaqsrxujcrdvyaibsw
 * Smoking Wheels....  was here 2017 emlohvgjqsbkswjdjesnhtfewprijfskgaknwdurdlbnwzsi
 * Smoking Wheels....  was here 2017 hqczdzbelkswzvxfakbdygyuymqdjovcxvflhhhkargjsqko
 * Smoking Wheels....  was here 2017 qfgpbrzghzsxebhbfzwiesobxgozmsgzpevlcfvnxbiyczdv
 * Smoking Wheels....  was here 2017 bygyvxyaatosfdroywwucnkqwnggxqjjohcpqkwueoiwmeno
 * Smoking Wheels....  was here 2017 nvvunzgatjbqicjzmjxozdwjfftqanuriqfdmqdjkfodnrkm
 * Smoking Wheels....  was here 2017 hewfmnidwrgjybzuhyfzmlsipkjzqtipqzpplbqnpkmueexn
 * Smoking Wheels....  was here 2017 wknkhiykbwmttlksfjenimywxmqmpaddniyuqxpxuuzhrojy
 * Smoking Wheels....  was here 2017 bhgyskbfegfaszsrfpmyrntngbhneionfxdsiunikfcilbjf
 * Smoking Wheels....  was here 2017 wwroxcxdjmgnbphxowaiueqeaamttufdhgjqdmbwcubsebva
 * Smoking Wheels....  was here 2017 nhtjeyzzakrxfmrwttzyhgiyxmkbcwxulcacwbgxsylqvhvi
 * Smoking Wheels....  was here 2017 odqoauzxtdtcvauhoythztudsurqdftksjuxpvizlgboprsj
 * Smoking Wheels....  was here 2017 sdssjryelcbgyyscaladyahiqpawbueejkoaqiuzpoyazkcp
 * Smoking Wheels....  was here 2017 agspfxakhvjsrevojmtomphjbtnkiurpyrouokhyxajapwvs
 * Smoking Wheels....  was here 2017 ttngyatmphrgnxsddpaueimjpkmdqqfjdxerfcwgeaxrluas
 * Smoking Wheels....  was here 2017 kdhxbvvlbnjqenfmbmikwgxrdxlfxzvmzcbnrstmpeikrczu
 * Smoking Wheels....  was here 2017 semcmlhqoyxdotlqdehcpruvvwdcjuxdumdhgukmniruvzkl
 * Smoking Wheels....  was here 2017 tusredhqfedbxnuurxwzseosaesjlgatzppindpipqfvnvbi
 * Smoking Wheels....  was here 2017 shyoolkikcbdravjefehvnzjlzjywubdkevciwgjsloqsjdl
 * Smoking Wheels....  was here 2017 eehcdfguuuzfnrkdjtrpruafwprzpccebenksgpfajmpqoxa
 * Smoking Wheels....  was here 2017 wegvumxigqmlkeqaipapkiytnqlxucocexphaveqxhzjtnbm
 * Smoking Wheels....  was here 2017 tgkmoonoxhigolxhfydjipexsbsjxzykgufzulruyijwrsjp
 * Smoking Wheels....  was here 2017 estcuaqiepnhjquiqidfznnrexufqdeucqucxecacxfglvzh
 * Smoking Wheels....  was here 2017 qzjzaqzsrrkmpgdximnpgcwmsoerzijfrlzikgqwmohxfugu
 * Smoking Wheels....  was here 2017 vwtqcnmagxnyeybahjyidqnwmrrcblvwhkssphvemeqmmuun
 * Smoking Wheels....  was here 2017 vjovcylxdwrbhpxuthglaryswbjdkqfgkadoccibsyoxwglh
 * Smoking Wheels....  was here 2017 xrrpimheqnwokmithtsgmcwboymtqkicwcskrsfwbdphjwhy
 * Smoking Wheels....  was here 2017 mihfkxtxkxkgfzdqqkqehxghjpqaukiippczmlpesmocfotv
 * Smoking Wheels....  was here 2017 lbugdiwmjlviruliuiucokiylrokzonextejuwbvatlxunjh
 * Smoking Wheels....  was here 2017 swxkoaulqsygyvpcbtbzpdpxfbimsbochbeueuixpdorufac
 * Smoking Wheels....  was here 2017 oznuaoaroquonhfkweoezztgivggrihvmglulghtjzmnggvg
 * Smoking Wheels....  was here 2017 oxtpctjfvhrgbqdzbhucoyvipkvuucthojretpgylwzwhqdw
 * Smoking Wheels....  was here 2017 klclqqslhbclonntqejqjjasfkwohfkttruyiisjgtbjknnn
 * Smoking Wheels....  was here 2017 dnfarohydoxnfwryubftttvforkdpytqoozkuiibjscxgiww
 * Smoking Wheels....  was here 2017 ajzlnarnsrcdlweadjnshyzzgjumlrtrtwrayodjtcorutiw
 * Smoking Wheels....  was here 2017 nooxvxmiqnzgyyytjxrcualjeumttdkwiplqxljxmohagtes
 * Smoking Wheels....  was here 2017 mukzifuqvlcyrvbamrjriglwmqiitedjpxigyllnyyiqcmay
 * Smoking Wheels....  was here 2017 wbfkegtckdgqwkwbvxnlgflkotjvvboqajkdrkegvkykyjug
 * Smoking Wheels....  was here 2017 xpvhqqxnujmaxwajvchrctgbbgwftfmmjsdvxkmmygrmvdno
 * Smoking Wheels....  was here 2017 eylvidyzojczorhqgzcysvtdvnkqkgatryecssqunfhhwqpc
 * Smoking Wheels....  was here 2017 lvmobuwwrkpqsmvweppzfwggadtlbeotegmzlxcawbxlpeqj
 * Smoking Wheels....  was here 2017 qgqiwyxsfeukqgafudsvvifgbayicerxkfduqvohqyuwqblb
 * Smoking Wheels....  was here 2017 clvccdnjpntysdkercqufcienggehqgxcnqzcmcwtgmsabfc
 * Smoking Wheels....  was here 2017 hxddjemzkoteroxmnhtjeeplighengjtheqiyfvkipskwcfu
 * Smoking Wheels....  was here 2017 zjcamdsvprhfmgobkqtitxhoppurzzjrglaynoissvqoribn
 * Smoking Wheels....  was here 2017 fvhmlhmmhmgnhdudokoshvvltfvjfzxclvybiihwqclbcera
 * Smoking Wheels....  was here 2017 fprprghwvwprpjefldhujtzdjdrdvsutsaxegorgwutddjcg
 * Smoking Wheels....  was here 2017 nclpsuvaxxrpbknyxnlcvtszkvxduvepzbncjqskqmidzvsm
 * Smoking Wheels....  was here 2017 xcyajzbhjazmqxajyoqkrdgpyvhuihiwofrwybyfhbfsbscc
 * Smoking Wheels....  was here 2017 ipxrscggjujsouzqtottilbtjbwswhzayypspqbtmrrtbmdw
 * Smoking Wheels....  was here 2017 cvfoctxthdvygiafxybkhnxqjqxvcfwtxzrfdkajcqhmzuyt
 * Smoking Wheels....  was here 2017 siaybsswucrblwywemwxljunuyahauebljpdrtbqgpvfzpwy
 * Smoking Wheels....  was here 2017 yuvjmbqzsdlfadymneyauiwauoymuxfdwigmmerkimjqnbmy
 * Smoking Wheels....  was here 2017 ugfqjcyqgvxugaijfgduszrztjscvupkpivndmqsaierhrrk
 * Smoking Wheels....  was here 2017 mxcsckdssbdnntryvgqlucylgnrzxwfrmesvnuvzdnumgbni
 * Smoking Wheels....  was here 2017 pisyftxhvylfotxxaxvoutpvhiiiyvdvmvqeqiouwtakpekz
 * Smoking Wheels....  was here 2017 vfluoefskvibisbgxelxvfyqxmnocotdxnlowshxpuxdueys
 * Smoking Wheels....  was here 2017 gnycfbinqjqmanoerijmfdkuovfhxipafujgsstnxvspnnyi
 * Smoking Wheels....  was here 2017 cpdvlxtpwlidckydwwtqoftivmtkzmpgeituckxwtgaxsxou
 * Smoking Wheels....  was here 2017 wvfixoeatduwfudwgnbuppyppvrchsvsvejzacaqgpqmpgdg
 * Smoking Wheels....  was here 2017 jbpbjboeevmwjjeivixunoffblttbarskoavvjnpuvnyqtgg
 * Smoking Wheels....  was here 2017 ofxvyseohdgosblswmgroqazogbatorqmzzpczfvzzbgmutl
 * Smoking Wheels....  was here 2017 spcrxcmclzdnsbonwmgrirdatiwuastfseovqaztsntnddvu
 * Smoking Wheels....  was here 2017 jqhvxzfvilktcujmpdhjrsnrncsgwfzlfenhoudxezkdtqsp
 * Smoking Wheels....  was here 2017 gdzwrljduwpiuxzmbjcmpckmzdkukatneetadwddsgauuodf
 * Smoking Wheels....  was here 2017 jbuoiueoyyosaktvolnbnigioizaegpyeskizbsmynyjygwl
 * Smoking Wheels....  was here 2017 brqyfqcygmgmelhxnxujxfvhvvtxvjljxmxrykvjubsaflae
 * Smoking Wheels....  was here 2017 tmsgxswlhpbqakkmulhzrwcstyfojcjukoxxafsjjobetczr
 * Smoking Wheels....  was here 2017 gekbecliyslflbhnjbsqwohekifkxhskydjzobwhbxdlaijk
 * Smoking Wheels....  was here 2017 nvkcdccfklgsshffmayjuwwnfwucyedsaskfesafnddtspzc
 * Smoking Wheels....  was here 2017 wppkdhiyaqntfhvaqvemaopwvqenefkkkamdrhdnqrqftqzq
 * Smoking Wheels....  was here 2017 vbeismuqkknfrmzrqeulltknbczvnasldcgmdbluoelhkhri
 * Smoking Wheels....  was here 2017 cyphrtnomduhaotdldncatpbdtzlgpjblepjvpmvqloqbvrp
 * Smoking Wheels....  was here 2017 sflddisijldjnlopjxfkebpjjoeztczsvstzksxtnqiclqxd
 * Smoking Wheels....  was here 2017 ydrwkwxvmfqbniyoxacslndmlpyjtykcbncxrlsxcdhwmkjy
 * Smoking Wheels....  was here 2017 ifmtacuckonivrvtveomqefufhstevufeohwqddwnnfhkbmg
 * Smoking Wheels....  was here 2017 oehjwdinbwjhidfcckhowjcwwekogskgkbgyshrmerdcruwm
 * Smoking Wheels....  was here 2017 sarlaguqpsyifqouaxexkpeoseykktyrhneklubvrtjeybij
 * Smoking Wheels....  was here 2017 azratbqikzieykljcgjvwtgymlsfijefpsltppghxclqenzw
 * Smoking Wheels....  was here 2017 zpjjqhprbwvqgvrmccjwcvhjzhfczghuhqttidnkaidxocff
 * Smoking Wheels....  was here 2017 kpfaobqznqxyapkdantucenkjifnpjpsqnamywhakjoqpapv
 * Smoking Wheels....  was here 2017 gyxtoqawwyllnqznetmpgikxanvdpwsifvkezqigsgxtyram
 * Smoking Wheels....  was here 2017 vyhpyqffnskveezdzgspcbryqwhuremlsjikhnpkukvjntod
 * Smoking Wheels....  was here 2017 papvhuyaczdyrpiqhtxinnjxaveqtaaaedlxyviculaxpfpy
 * Smoking Wheels....  was here 2017 jzfzmgfsnfeayqbaairnnyqijafdchsfwirsgbaecfozpfsk
 * Smoking Wheels....  was here 2017 cuuvnffvxyikfeonneyglxzcbgoxcfcmhlfdvcjsjwuoeeth
 * Smoking Wheels....  was here 2017 cshktilfpcptylkphtxtwfehrrkvmebqegmrlykbmtetjvwm
 * Smoking Wheels....  was here 2017 wfwytjqyhthavvmybwypqyefesicfxtoqtccfyhuomozhcjf
 * Smoking Wheels....  was here 2017 ebybjktkwiyhuaxnvnunvjemrxdcmhlmufzlkrpsazywkdxz
 * Smoking Wheels....  was here 2017 zhdlqtbelljzbaaoxxhpscsynewlrnvwhbjzrwzalirjljhm
 * Smoking Wheels....  was here 2017 qbldxyabkxqtbxkotoqbxxmrkqvcpcrlucqguqlyuxgojnqr
 * Smoking Wheels....  was here 2017 oyzmsujfkxznnfyeefhlgwmaeqnfdpeejhkawhfddhmxinit
 * Smoking Wheels....  was here 2017 pqeyyjbxhuyljntjewwouhxozutdmbphgyriejukwllbunyg
 * Smoking Wheels....  was here 2017 seshqzjtgdjxuwdkathkwshdfaoocpqfylplisxwrkjwmziv
 * Smoking Wheels....  was here 2017 dtmpdetpqxgogjtsejsgayiwnkhjsqbrgqnxdimvkpvohopl
 * Smoking Wheels....  was here 2017 lyrdztxnddyhlmlalmpqcbabtjktfybremfmspvxfpqmmfei
 * Smoking Wheels....  was here 2017 kkrkavwwogxhixhhvcqjekpibltbwjxjygnehzjyliuhmdoz
 * Smoking Wheels....  was here 2017 yffeiqvfcwaydnrtpkqkplmmwojzbchhbjqinjwauwpxztqb
 * Smoking Wheels....  was here 2017 kodnguilcvgxgoewgzwcwbmqtvnkoqzcirykfuhmcpqlysoo
 * Smoking Wheels....  was here 2017 gyrrhbaqghybklrhomsxxhodqqumgpdttceflowwoerjozqs
 * Smoking Wheels....  was here 2017 hdfeinxckoqonwhcnzvrslynroypjydnpxftngccmkshgsny
 * Smoking Wheels....  was here 2017 ndkvlmgksicwwsiklrejrbbsfnaljwnvjpgiaprgolddtkzz
 * Smoking Wheels....  was here 2017 deeqynnlnljouflstcwihzssxqixxuejuxqmttppqrkbarfu
 * Smoking Wheels....  was here 2017 tttwjklinatocvmthyialgwyqfkczjfexvdyvzcuxsjkfnop
 * Smoking Wheels....  was here 2017 bpmbpgyhplvaqenlbhggeesxnyamtpzkaqouowrrskawvbow
 * Smoking Wheels....  was here 2017 ctbzshjavhijsfxbghobviunargrspcoouegneahsxsjotdh
 * Smoking Wheels....  was here 2017 dkkszdcirmigrdialmkrzmtwrnkqnwkijbjwnzdzuoybhhjw
 * Smoking Wheels....  was here 2017 rbqlzpxisdcnhjnckqfrlsrglwzkdazsjmtlrpgkbzmhhppu
 * Smoking Wheels....  was here 2017 lngtpsthwpgkmosecsqvhjrgliumuagwxfizfpwixcltzwln
 * Smoking Wheels....  was here 2017 nsxlwuxwgmmglsenvzpewyjtatwmwbthlufuvurwazbibnuu
 * Smoking Wheels....  was here 2017 cymmckuvgsxsqznobxhyshjvwhnidoksuzvjgfrjgzxfngsn
 * Smoking Wheels....  was here 2017 trdexjejnjtttuqbpgcsrlsuwhhdnggbxtvmqeclsuuumzoa
 * Smoking Wheels....  was here 2017 fqibcsbtyuqltvpzlbrfvtpgckzjezrpbjeegglwvfsrlxyq
 * Smoking Wheels....  was here 2017 mwswstpprrhfubumwmammsocanppqahstiasrgkufkzuclse
 * Smoking Wheels....  was here 2017 voescbjsawvtkpucjcfvfegifrmunsyfviursfznusdikhao
 * Smoking Wheels....  was here 2017 uhyuwlagtllyfxmmrpsuwftjpicbvvsafldtnlkrquaqojdz
 * Smoking Wheels....  was here 2017 bskruypmqvtxeszqwafcnceshaivsgziewybindbempkzxtz
 * Smoking Wheels....  was here 2017 txfcyxgavpoboxptepouljchrsetrekqgcluugyubyemkhrf
 * Smoking Wheels....  was here 2017 abhdrvoturvcsryibvzdhxfellyskatqfxaorstednjcteaq
 * Smoking Wheels....  was here 2017 mrvbpperceywklxbjlxsvsnrkqdxvndibhjbbewvpvxpgpen
 * Smoking Wheels....  was here 2017 unfjlfcfqkjnpyoxckyfdcfjtwprdozwbljjhesptsvqiqrh
 * Smoking Wheels....  was here 2017 bpevjzpxobynkbhblbatnrudvbjsvivurxfuypaohjlesulr
 * Smoking Wheels....  was here 2017 mcnnqncqgysmjzrazvioqeabhisxngottlhtvlubcchhisnp
 * Smoking Wheels....  was here 2017 ppnrwojligzhddonlliefsumbzekgbhsfahdabgrhoekiiii
 * Smoking Wheels....  was here 2017 duowvfkrshfcrgcmvypkjplyfsopeqjykwdxwzwhhqdfgvli
 * Smoking Wheels....  was here 2017 erivrujzoshiefqdlpcflijjejxftejwunajxakxrkmptrsg
 * Smoking Wheels....  was here 2017 xnrprvudekfqcgtyuvaxzuiuobnbrdefdrhbzfvykgsruogd
 * Smoking Wheels....  was here 2017 wuvmkckgglhycthqpltavzinhexixfxylkrsdxizovrwojke
 * Smoking Wheels....  was here 2017 wgezsterrfbifljexkzibgoglhxkpgxhzwbktrlvnzjvnhuv
 * Smoking Wheels....  was here 2017 vxkwqaizojhgofjtzypvzdosmiozgntshqqjjgwpzubmiugu
 * Smoking Wheels....  was here 2017 bzleomjahtbjpgxwhquwdlzbzkcyoliwckvevtpptsjyznxa
 * Smoking Wheels....  was here 2017 czlezzzwnnqocateqdyxlgwpwwdkmrtulegpemwmbibqqlcu
 * Smoking Wheels....  was here 2017 rrukunfxezpzxfcsamutxwkyfjlveeirofxptzdafmdgusmn
 * Smoking Wheels....  was here 2017 uafqalfriusbishqsxflvvcymtbvccszzawndbdixiypduvy
 * Smoking Wheels....  was here 2017 thpxainajvakstxmfyjfwyrqhdgizxtlmiqxduwtzgaxpiha
 * Smoking Wheels....  was here 2017 azcmjxwbzevyvsuwhhrqthdkmxplshnzaculwmowpvcojhgy
 * Smoking Wheels....  was here 2017 jvexwifdahqvpibvyyumqervgrxppdkvxrigprrodyhfywgf
 * Smoking Wheels....  was here 2017 vvmypvuuprhlfncolfstuduuziemzramqlkoyeywfswsylen
 * Smoking Wheels....  was here 2017 qfxpwacxehvmdlmoinmsvafhgzsyqhfqyfkxsckdtojhktdv
 * Smoking Wheels....  was here 2017 inqfhrvoignubpbmhqqyovxszabdltbgxybczrfzwbpimrnk
 * Smoking Wheels....  was here 2017 rlbgqwzcywxoyozikpufbycriaamqxxosyecbmwgzbolqmwq
 * Smoking Wheels....  was here 2017 qaxmbxucevvfzjohypvmpwizqwqrsykzxqagnjczrtponnbg
 * Smoking Wheels....  was here 2017 nlbauitlkzgipdkwidzcwkgtpsenhjkghuzagjxowlfwenfg
 * Smoking Wheels....  was here 2017 vhsbmzpdhknxojkskzqpoqxhbxfgiuajvlsggunostgssjrw
 * Smoking Wheels....  was here 2017 iggdxxgpsoeztrpwedlrwxmfdbogceontuexwfkuoqrtqibn
 * Smoking Wheels....  was here 2017 aiicekzjtzzbjaknxvjlasmihbfdzsreqimirkhkbcwxptfx
 * Smoking Wheels....  was here 2017 duxwobhiwoatxoldbnndrwqucblwrvebgwbzmlescphipjga
 * Smoking Wheels....  was here 2017 gcdusqxnrlozbumkkajhomywliwoeefcniprkqhhutulvcnc
 * Smoking Wheels....  was here 2017 cakkkgtibadvtjshaiosvuoempgprtcnuzaltobzojkwsdqp
 * Smoking Wheels....  was here 2017 rollsddidwpueelbcpajukboqsqrosmvoimnbzhxbpkmyxkf
 * Smoking Wheels....  was here 2017 hycyyxmihvxmumhdelxozdcdmthrplfsodkmfayjdvjmmcax
 * Smoking Wheels....  was here 2017 jspetjnmeckuhqdfanqwhareycttssjdvjlcgxfyxsbhoqtx
 * Smoking Wheels....  was here 2017 tniswohbsaqwrkahqxxzskbickwidjiipgnkmhpnuamnpsgr
 * Smoking Wheels....  was here 2017 klzhkuyszfjdbqjphtozqusklnragrrtkivqnxwelzabhtkx
 * Smoking Wheels....  was here 2017 qslyrqafkoqgzptpmqwdqzinnoksuzhbzjtievygtxebplfp
 * Smoking Wheels....  was here 2017 xuxzhxfspducbrayzgezmcyzgxqqsbghkhzimkciukszrsdz
 * Smoking Wheels....  was here 2017 amuwaqnomjivhnhrvqehhltkteedfuxrwjlovdufzjrlbttl
 * Smoking Wheels....  was here 2017 yttlaeehdvavwdyyfztbjngqlgbwsjypxdgjtwtbaykijzwu
 * Smoking Wheels....  was here 2017 zurrnartzlzufrngsvdphedtygotyfcvhhwhcrydrmlvpcrx
 * Smoking Wheels....  was here 2017 pfuxdasbrhlpcpyibyslxllbdngywapiawzaxvqcepniyblb
 * Smoking Wheels....  was here 2017 qqmprghnbtzljnhchgdigrjfesxvrtrhjblrnxiuxeslvzvs
 * Smoking Wheels....  was here 2017 aelpgzquhljqhlxvqbiirkkzkrobtnaevlmnnrrflhjdzjro
 * Smoking Wheels....  was here 2017 bzoweufqugrxhnkxqvmstkhnnonoxvmsesnathsuskynixbo
 * Smoking Wheels....  was here 2017 gpasaluedhedcerdaizzhuydjsilzidxlveafyqcwagzblky
 * Smoking Wheels....  was here 2017 jufrochugykmqdtkvnoxjwrkcttdgzjxwdjnihzzgdjgrgge
 * Smoking Wheels....  was here 2017 kmvmyzzzguehchbzhsboidyfcoxhdxsfyaiupbkmoupdvsmz
 * Smoking Wheels....  was here 2017 qzvglrjrntmiyvdhziresmlqzfauiqdomikjwjyypikwmneh
 * Smoking Wheels....  was here 2017 ouherzdxtyrkwfxbpevikxfyreqvutrvlzhafnvaomruvqtj
 * Smoking Wheels....  was here 2017 zqsulyhatrhrvclhefetktlvhaousgricgyuybnnvakoiftq
 * Smoking Wheels....  was here 2017 vmsyuxbqsqcpakcdysqmcopbfpwhohtmzqlyrtsnacwdrrbv
 * Smoking Wheels....  was here 2017 lpfoblxozrdtxjldmdkvzdlucauhaiuawxhaftljbcqqvttw
 * Smoking Wheels....  was here 2017 hnkawhoxgytddjkyngxhznyhvsyxbaxwszduphyqaqnlzjgb
 * Smoking Wheels....  was here 2017 exstaoazitkvsdbnbbtpcbjengbovijhvfwhfyqfjpnfoqcu
 */
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.server.servletProperties;
import net.yacy.server.http.RobotsTxtConfig;
public class ConfigRobotsTxt_p {
public static servletProperties respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final servletProperties prop = new servletProperties();
final RobotsTxtConfig rbc = sb.robotstxtConfig;
        if (post != null) {
if (post.containsKey("save")) {
rbc.setAllDisallowed(post.containsKey(RobotsTxtConfig.ALL));
rbc.setBlogDisallowed(post.containsKey(RobotsTxtConfig.BLOG));
rbc.setBookmarksDisallowed(post.containsKey(RobotsTxtConfig.BOOKMARKS));
rbc.setDirsDisallowed(post.containsKey(RobotsTxtConfig.DIRS));
rbc.setFileshareDisallowed(post.containsKey(RobotsTxtConfig.FILESHARE));
rbc.setHomepageDisallowed(post.containsKey(RobotsTxtConfig.HOMEPAGE));
rbc.setLockedDisallowed(post.containsKey(RobotsTxtConfig.LOCKED));
rbc.setNetworkDisallowed(post.containsKey(RobotsTxtConfig.NETWORK));
rbc.setNewsDisallowed(post.containsKey(RobotsTxtConfig.NEWS));
rbc.setStatusDisallowed(post.containsKey(RobotsTxtConfig.STATUS));
rbc.setSurftipsDisallowed(post.containsKey(RobotsTxtConfig.SURFTIPS));
rbc.setWikiDisallowed(post.containsKey(RobotsTxtConfig.WIKI));
rbc.setProfileDisallowed(post.containsKey(RobotsTxtConfig.PROFILE));
env.setConfig(SwitchboardConstants.ROBOTS_TXT, rbc.toString());
}
}
prop.put(RobotsTxtConfig.ALL + ".checked", (rbc.isAllDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.BLOG + ".checked", (rbc.isBlogDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.BOOKMARKS + ".checked", (rbc.isBookmarksDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.DIRS + ".checked", (rbc.isDirsDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.FILESHARE + ".checked", (rbc.isFileshareDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.HOMEPAGE + ".checked", (rbc.isHomepageDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.LOCKED + ".checked", (rbc.isLockedDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.NETWORK + ".checked", (rbc.isNetworkDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.NEWS + ".checked", (rbc.isNewsDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.STATUS + ".checked", (rbc.isStatusDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.SURFTIPS + ".checked", (rbc.isSurftipsDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.WIKI + ".checked", (rbc.isWikiDisallowed()) ? "1" : "0");
prop.put(RobotsTxtConfig.PROFILE + ".checked", (rbc.isProfileDisallowed()) ? "1" : "0");
return prop;
}
}
