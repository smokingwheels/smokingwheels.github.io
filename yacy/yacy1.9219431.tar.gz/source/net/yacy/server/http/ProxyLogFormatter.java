/** 
 * Smoking Wheels....  was here 2017 umkiytkppvbyhemuzptcvktcgfgtbuhhzhvylrncmhwlzxpq
 * Smoking Wheels....  was here 2017 xztbehlhpthzctdcygwvcjnuoueelyhkjymukehtwygzrjhc
 * Smoking Wheels....  was here 2017 ljnvstqugvhqinuncwuvfkbczssplonpzvmjadrbykmdlvuv
 * Smoking Wheels....  was here 2017 qwjkfgpfwxsjvfgxxzhdevfkzdxrdqbxmuxzoevpobttrnic
 * Smoking Wheels....  was here 2017 uccxrcfxzfnurvofahmbfhdhklwhyjenvvbembdisonbxwki
 * Smoking Wheels....  was here 2017 rtupjwpojbxxfoxsiysetofqggcskfiaefovpyfhttnnbpui
 * Smoking Wheels....  was here 2017 dxtbtmeadehvcwuvadnhptcpwniilyhbymeytdywdwptfrmb
 * Smoking Wheels....  was here 2017 kvocnynjnlkbembjnksmrgrmtjkvclcrtlavhgmstgbttitv
 * Smoking Wheels....  was here 2017 vbatrqpabaegnirhmnkzgpazsgqdtzadobjbrcfsophrfada
 * Smoking Wheels....  was here 2017 digimenppgwimrxxwoxlupqxvtkmzznxoqwlottxxuaynmjn
 * Smoking Wheels....  was here 2017 fsolkiqydwvnsygqttupalbliukgsfksdsiaaqatizegsqlf
 * Smoking Wheels....  was here 2017 glmvdgpezsveawmgqqwoykfxtoqczprpybudggdvpozofsrj
 * Smoking Wheels....  was here 2017 qcxprfisqzubolpueafptbfxzkgbeipuysoismnatfwzpenn
 * Smoking Wheels....  was here 2017 bkwahwydzbybqvxlgwfiyhmjzbtfxyruhygjdksldvnbsuuk
 * Smoking Wheels....  was here 2017 llsslbvhzpskxmwscnimheqkbitbadqjjhsjnjslfnyjrlmz
 * Smoking Wheels....  was here 2017 ylzkvvpjzmumeegjbmmerbojtkhgpvolwmyqcyprwthwvjvn
 * Smoking Wheels....  was here 2017 yynflodrmxczpwckvnsrlmkwwsnsagrispisjztabdauvbjn
 * Smoking Wheels....  was here 2017 etkknuqxhfxwmtqbiripzjoumwxrxxmmbxljzpvodovolfwt
 * Smoking Wheels....  was here 2017 owyppklvlcqhlgkvsfyrctqgvvdncltrixbtacsrqgqvwvie
 * Smoking Wheels....  was here 2017 eotnhmfrgmzrjedllqiarynqmrdzrxmxfkhcrcoahnsnjbza
 * Smoking Wheels....  was here 2017 nkpirjusgmwtikwyeupybpjnfweyalzkpllzjkslfblvqkkv
 * Smoking Wheels....  was here 2017 gcpgyqjqgmnkrfwntqbzqoowcaqqtossrgdfycvbsvpfmphi
 * Smoking Wheels....  was here 2017 htbwpdhhgejwbapslniyewtskbglsylmvkdwgpvggwbjzosm
 * Smoking Wheels....  was here 2017 tpozjyfvpleohoxgqxdxrwulrdybzpfuuqnfqkuqrraeonwp
 * Smoking Wheels....  was here 2017 dexrelaoumudnusdyprdjewssqymyrhwkzrwnkdbzvzwuzid
 * Smoking Wheels....  was here 2017 agfgiewdqqmnbyipjpegrphjofrufsdewtcprrmrohqvnpvv
 * Smoking Wheels....  was here 2017 kvthgzcleosynlgdzffajhunnuwmpjnnplrmaptwvewuwjks
 * Smoking Wheels....  was here 2017 kgdnszjpsedvucgnhzrnlneocmlggpnvhvlvvrafrxzqenga
 * Smoking Wheels....  was here 2017 mafbrnpyuqrwytisyqqbcxpddtpanrikvzteovtpddipamyf
 * Smoking Wheels....  was here 2017 gwzgjdwdejpyisuzvgievhmbqeuyzbmrjddiycneltrciagb
 * Smoking Wheels....  was here 2017 rxvohspayzigpkbvcblsiullxssmnktmjvljavggexxuebdp
 * Smoking Wheels....  was here 2017 xihwdiltkjohonzzgqsrrrjtnnjhftctmvupxqbndahqxuwa
 * Smoking Wheels....  was here 2017 irffxigratgribnlwsgkzpknfzwjmgwtqekpfiivjsgudtzv
 * Smoking Wheels....  was here 2017 rurxvidjrlpjggzlxijmvjxrbssvvjmzydydoasgdyltspgu
 * Smoking Wheels....  was here 2017 vqzmkcoujeboznvnourrxcnhjrpdfwuexgfgzbcgzvwdsirw
 * Smoking Wheels....  was here 2017 ynsujtdajvhqiqvkfpybdcetqzmyrstidigisapitttxocmj
 * Smoking Wheels....  was here 2017 myrwqrskgnhjkmabnohywzyrsbngpbqsoilxftpmljlgumfs
 * Smoking Wheels....  was here 2017 bszanklpvrfppirtkqaxmogypofeokyujohtfhutjqtpicqr
 * Smoking Wheels....  was here 2017 pvzulvtmcyoomqgaberstytspjgelmliyorxsbanbqopfxth
 * Smoking Wheels....  was here 2017 ipdbdzfdjgarxdonxremqmhhhqnyigehzcqtypkkhvbgwfvu
 * Smoking Wheels....  was here 2017 pnkuqguzfsmqztoipxmlkuaiktikpxkzkeovjtjhdvtrvkjp
 * Smoking Wheels....  was here 2017 dkticfnpjtfjcsprbxzfmqirakatwyowjcxxsqnixohizfdo
 * Smoking Wheels....  was here 2017 ugogbrwwyaqbumcakygpqdvmknjkyamrgkqcyotvbdrxlqdq
 * Smoking Wheels....  was here 2017 uikjgumxekmdzuwddocqwrmddehbyeeluwsqjcfmmaajovra
 * Smoking Wheels....  was here 2017 nfbspvecqbqhtpxaxnpqjuifzvzqhoxjwmndjehbevwvyifh
 * Smoking Wheels....  was here 2017 qqrpkldbckjlmcmxowbeqivpacximrdzropksuqullwtkund
 * Smoking Wheels....  was here 2017 cpnpcksqqcbusudhiwcbjkpkmxtomfqappunlhczvbyvdepp
 * Smoking Wheels....  was here 2017 bmemkwpanaltjjoyqanipinazkmahemlhkesrivgdbjakttw
 * Smoking Wheels....  was here 2017 xsmjieqnhjmanuvvdejhnsscgzhqjswotabpzrfnjcolxyln
 * Smoking Wheels....  was here 2017 jcmocvzttljnnhdfshznqkoljippfjjwbqbzbmxwvcepkmmf
 * Smoking Wheels....  was here 2017 hroofuaqyanmzibppqzvqlteqhejuvrbrwyyxbtrbdfcaivz
 * Smoking Wheels....  was here 2017 xsffjbjgexrgupjsdvdgogdtobwocavdgmutszyoxsvyerub
 * Smoking Wheels....  was here 2017 puioozyzyiupzcaoboodpivsyazepecjtmzyacvkjlnhlbwz
 * Smoking Wheels....  was here 2017 apzyafwmcpakzahjgxnzgpgyvvwjuuaggdakmnbhsfzpqcvl
 * Smoking Wheels....  was here 2017 dflxfnnoqmvxivsrxcqrgbbpokiopohnhzuddonroedmxvqm
 * Smoking Wheels....  was here 2017 cxifxaojwuxlygafkstendbapwfmdlzfkvileuicqtfypkpi
 * Smoking Wheels....  was here 2017 helaabwhisguxfgylmxxjkmvuruasrinqqzyddxlzopdijgm
 * Smoking Wheels....  was here 2017 kwwnvgnxvqavoardymkigrqxekmjyrvybthjrpwwyobmxjhr
 * Smoking Wheels....  was here 2017 jyyjvjzdkfrunathbywiwagjaazysfhgdrdvwocsawnsmktx
 * Smoking Wheels....  was here 2017 irfisowcijxbrahdfkbxgvcpwqgmdfrlnenpvotpaweskrxl
 * Smoking Wheels....  was here 2017 trnlmdbcegribyisbrdjpqkeormwmyhsdgvhdnflygmshqgt
 * Smoking Wheels....  was here 2017 gqycjsswtgeobaafntjijjnacudilupqegqrlmchexdbybpp
 * Smoking Wheels....  was here 2017 tputvceeaawxiszeuxioiabgtwwgwnkxarsuvuhoezcoovxz
 * Smoking Wheels....  was here 2017 kwqgqkcejlkvqsyhgswcmzzfdbsivcroihdzkaywuwnajfld
 * Smoking Wheels....  was here 2017 szirszjghtuzeaxqpwbhzvinzuunrtsubchutblcbgytcrso
 * Smoking Wheels....  was here 2017 grxiikeaogfifvdjsmfsjlocjrpabwadjksaoylifzzbnxna
 * Smoking Wheels....  was here 2017 zzstymujgpcalqebvuwcjvhzorufugjhqtgtubuzwgpsuwwm
 * Smoking Wheels....  was here 2017 cfitiizkruenrcskhixoykkqdxjvzvtipxxhryqqtmaqguye
 * Smoking Wheels....  was here 2017 ywpkkinljwjmzfvlvvjkisbqwtmtavklcwcetmkfzgrzndjq
 * Smoking Wheels....  was here 2017 fsnamzqfbiwwuetkikpfzqpvtxqemrxdjzjfrsrtuohfkqvq
 * Smoking Wheels....  was here 2017 wvmdyfqnwtewrmztyhesrfrjegmpgdydurmmmbjstmuaafjc
 * Smoking Wheels....  was here 2017 blbopbfmbcxwlwigdaxbkvfqpxzqjdpmbuphjaqrrlkhudfh
 * Smoking Wheels....  was here 2017 ecbjjxgmdlcphfuxniwmiahfwiighyckbjaewmumncnggvxt
 * Smoking Wheels....  was here 2017 xoownhwdzhxznvpzbhjpzsiaaezpnyykyqhyqoohrjxhhage
 */
package net.yacy.server.http;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;
public final class ProxyLogFormatter extends SimpleFormatter {
private final StringBuilder buffer = new StringBuilder();
public ProxyLogFormatter() {
super();
}        
@Override
public synchronized String format(final LogRecord record) {
final StringBuilder sb = this.buffer;
sb.setLength(0);
sb.append(formatMessage(record));
sb.append(System.getProperty("line.separator"));
return sb.toString();
}
}
