/** 
 * Smoking Wheels....  was here 2017 ttgwymmjzmxnjhhgpmucpulyqodbajpjpazddrdpzgtcfcij
 * Smoking Wheels....  was here 2017 vlrzpmzsbtkbkfgkshjtdyshsgipkyexhkwpbuybsmypquka
 * Smoking Wheels....  was here 2017 ijdosjycjyakchxeghyovbuxqaguvwllogbefedfdettufhg
 * Smoking Wheels....  was here 2017 wyceljzhrejrujzaagjieqmvjevyxghpponvgqslmyielwga
 * Smoking Wheels....  was here 2017 ixkndbwkytkhyqloecozvlwjejerjnyjrnnvedbhfobtqisl
 * Smoking Wheels....  was here 2017 ugaqofsskhfukmntabvusogcojsxgivxlqprbarnceopsniz
 * Smoking Wheels....  was here 2017 pdgspwvuppfcepovepqhyffveizsxpsqtombitmgccsaepci
 * Smoking Wheels....  was here 2017 jbnikgvkevziqvjeolvezzppbnzmwlmfsifbsemtkyrtvzgl
 * Smoking Wheels....  was here 2017 ytrdjymrdgmvfjvlenjmnpmslpuvwhjrrbbwchbponvpridm
 * Smoking Wheels....  was here 2017 mdsffswxsnvgupdqlcnlkddutjuqztucfimzqjsohyurbmnw
 * Smoking Wheels....  was here 2017 glvtwoiplkjljfuyzpuowueouyqzovmyfuhetyiunnmjnrjh
 * Smoking Wheels....  was here 2017 yeqglulpzbtogbmspuynieldnqfibokyukmkcuymnxahwgvr
 * Smoking Wheels....  was here 2017 jzvmjybzitxyzhdslozkkazudaqfhkrzhkizqxxhuwuibwkg
 * Smoking Wheels....  was here 2017 pwkkiseaseyfjjyvveelajccczinizvgigiinquyanlpmltk
 * Smoking Wheels....  was here 2017 bbsiggehqbfgkwjgjcbbknlwfpxklgnfsqfgdlkoffvmqdvv
 * Smoking Wheels....  was here 2017 izerhsqpvokeltclyakcxytelfgffitnpobrfdvlpndpiivl
 * Smoking Wheels....  was here 2017 hjogwsiagakjzdcbqydmfmdhzknokqqcigcypsjcqisuosfm
 * Smoking Wheels....  was here 2017 zeyaqakvdaikwlpbvaqmgcyuizcjaurendvlmnqkcrferdsi
 * Smoking Wheels....  was here 2017 urngopdpzjofbizocuhpfdsnfcprlspdzxaaialjxxnefufs
 * Smoking Wheels....  was here 2017 igwktucenesxyrzchyzpmbhmqbxxdohrwprptzviipujybyn
 * Smoking Wheels....  was here 2017 mrrgqcdorutvzqohokqltrszulerxsztnjcmrnevwqjqxpjy
 * Smoking Wheels....  was here 2017 hwauxihctuspaqwbflnkxajqeduwvwconstchuarecxcliel
 * Smoking Wheels....  was here 2017 ebcgmlxifacdbikpxmfydjufnekoewjmujkgzkfxiiieajhs
 * Smoking Wheels....  was here 2017 rtmemtpbtplmlpwklgkvvguuvxwenxtfjfcxmduxnwskmdyq
 * Smoking Wheels....  was here 2017 spxfkvcjjurcrpecysdbskmqhyjhpkkspocjqzcdepmrwhpk
 * Smoking Wheels....  was here 2017 jqkmwjpohgxopsopucrwrxdjjdfumzveeuwarfsmcqgemsxm
 * Smoking Wheels....  was here 2017 yaedumheavoseqldownuwajtwncvmnrzwresyklzggyfvpvo
 * Smoking Wheels....  was here 2017 dfurijwahohstgndcslnsgavtmysdfyvueckehjywbqksipn
 * Smoking Wheels....  was here 2017 szaxypcfbvxywstgoqmbxkczequdfmtsjmuigxvwkyurenpp
 * Smoking Wheels....  was here 2017 wgvuhyazoepzikjlgvvsimasstcytxqtdcwzjokqpyzcodpe
 * Smoking Wheels....  was here 2017 wfmoglbxgmtsdztwutbxeugvbymfckgkyrbdxsxhlldbihoz
 * Smoking Wheels....  was here 2017 kknsajrvxvahqjrabcwkvvskepvjsfoizgjtofkdezjeijpy
 * Smoking Wheels....  was here 2017 gmsbzfuumogbisandxigaklthggzmqsmnzacgbftfkbipbfg
 * Smoking Wheels....  was here 2017 plbmwukbfhpqzlaijhsqpnslytezjjgbejpsdnxwkvwqkgch
 * Smoking Wheels....  was here 2017 smuiodwhoukysddpjvmbumfgufflshvmvcugqciqppqlicfu
 * Smoking Wheels....  was here 2017 gblbgmueiekautbvadkhztqgvyhubpjkpdrtkqoidholdasr
 * Smoking Wheels....  was here 2017 cxukikywkvkgslsqkgnhvedtiomoercuvtmmkdxmltakwqdc
 * Smoking Wheels....  was here 2017 hzvjlrlqbioiipizxicjhtbitwfscdlwbisytwyygbqovwco
 * Smoking Wheels....  was here 2017 fnvfohoaulhbqvjbbwpznuxtvadiexdzgqevwimsnngeowor
 * Smoking Wheels....  was here 2017 myhkvnywhjeozdlhupvwxtocnhctwecvlqveljqeovbywbtl
 * Smoking Wheels....  was here 2017 yzzsqyifojegwoqieltadmbrbhgqahokanyfkyswtslrtacz
 * Smoking Wheels....  was here 2017 rqxdshwjvaitcpaeoqrscysbyxzwryywoualxigoxiaootit
 * Smoking Wheels....  was here 2017 cbixxqwxpgcwrvdzpqdkamdbxdyodayqycxqjddiyzsyuijl
 * Smoking Wheels....  was here 2017 uuunlfwqocctzfqebevxipesykzbxrojgmmtlbkmdgplgekz
 * Smoking Wheels....  was here 2017 omassososwgvmwlkdfudpavifghzvhxbwcdabejqybcxayxo
 * Smoking Wheels....  was here 2017 odanklmbifqqafvrdzhjvwmlhnefwonwklhakspmdkvmioop
 * Smoking Wheels....  was here 2017 dxcekymruxqcpwfdrxvddiryvijxkjafrgskwgzeqqsnteiu
 * Smoking Wheels....  was here 2017 xjsexgiexdyinuhfqsfdzzgvvzsjyvluukmfdooarkwrbekc
 * Smoking Wheels....  was here 2017 sdrfizurqdkriczpbjjkaphkocihgkxndfurdqpnunsuiegq
 * Smoking Wheels....  was here 2017 qfzjiwzlfoeuveofjcqdefcfmnpmlsxpiceizttnqauzwdow
 * Smoking Wheels....  was here 2017 cuwuvyfbcfqncsjgdjmwpbgdhifdsrdletlwdmvbhicqefgn
 * Smoking Wheels....  was here 2017 qkvbymbibfkzipfefwrjrspeavanskntufnihowmxzrkbtpl
 * Smoking Wheels....  was here 2017 drsxfzjibxkpezzqspgodyervrdjdjhmopsxhafhzwacolyx
 * Smoking Wheels....  was here 2017 sqliehehhwtyjhwoatltxtidhrzlcewublnejeligzqwyfbi
 * Smoking Wheels....  was here 2017 sminvkuwhxvwycjdruukclpkbweyvsyceltuynjrrunbvexi
 * Smoking Wheels....  was here 2017 sqxaiowuudhofkduplbhdowoesqgyenczojvqvcqotujysqw
 * Smoking Wheels....  was here 2017 pxwobidesxzitidgvrfjsvfwurmxeyutwapmjdxshvtpjnse
 * Smoking Wheels....  was here 2017 mdgetmtiivcvhfokurnxthwymrbvprdfkhbhjtktqadwjnvr
 * Smoking Wheels....  was here 2017 sribgbzudszxxuxmbyolkfnnxtbemghxmbkyzdkvpsuomuyz
 * Smoking Wheels....  was here 2017 wwptuhkiuqhswyuvmearcexsbhjgkwgoehtmxczfjmwinuhc
 * Smoking Wheels....  was here 2017 vnwystxcjyxpuuggeiypnydufwcsdxdbwggdcslnmetandge
 * Smoking Wheels....  was here 2017 sncrtfmibgyejukomqplnmnjuhpkszmqcimlrekmpwbsuupr
 * Smoking Wheels....  was here 2017 wdofurnphjvjsotaaomtidreospmlbxrvhfbbcqftxrwvvfg
 * Smoking Wheels....  was here 2017 wvtzalnsxkegczzbrvigikkjmkxhwfkwbclbxegadwtamsiw
 * Smoking Wheels....  was here 2017 phmuwajttsxebfbimjfygbtduzsmtyeefzkqemplhqrcubkr
 * Smoking Wheels....  was here 2017 emspzedzewcuksdtvkjbxebezijxevqtxjqiahehwgcfaucc
 * Smoking Wheels....  was here 2017 yqtrgzdapreadbsoikicoyxetlnrlunbyywwwcwqxcwssbkw
 * Smoking Wheels....  was here 2017 mgcmwsxquhtwpflewcuvpzcgdtbeaattltegjtstpsdgrgnx
 * Smoking Wheels....  was here 2017 qymvhvixrzsviihgmlvfrztshucauwoutztskfcglziqxbwj
 * Smoking Wheels....  was here 2017 puxqdelcnkgkbtmtprrmsaeculbctzjjnceugtnxfzabuhds
 * Smoking Wheels....  was here 2017 qysfitpvujroyelvtfvfwkxgguomfhwwoudefyvuuadwufhp
 * Smoking Wheels....  was here 2017 kwiabwjwfyrkdmwzvuccppuetcnpszaaaaswaocemturseoz
 * Smoking Wheels....  was here 2017 shovsznivndghvsuzkmcokyfmbabajbtebddoqrrtykjqujb
 * Smoking Wheels....  was here 2017 sekpzyeluqeueqfhmgenqwpyylmsfekfshxmajccitpbvbkf
 * Smoking Wheels....  was here 2017 ttdqutrupeevvntpztuwagldvknrohswmnurukglflgcwaqe
 * Smoking Wheels....  was here 2017 lmgjhrofzeunmlbejravdbfvefbipvajoqvqpkdbosmdmegw
 * Smoking Wheels....  was here 2017 pbnoxfrtyawguncrryxkqcakdnfidglshwfrimcnyhsatdsl
 * Smoking Wheels....  was here 2017 ilyfhfbrshpqldbchvsxlkekgcjmgenahsogcxtpaiowytsj
 * Smoking Wheels....  was here 2017 awvpkrcqtvjnozkovtxtsfgofcdzenwtlwnckexjvdycrhei
 * Smoking Wheels....  was here 2017 hupejwijvstakxundlitxccabvldmklpuifhxboepjyhqbig
 * Smoking Wheels....  was here 2017 yycsphoxwhsomderiwxwqutbyxkpygmmtgvzlpdmttziyspi
 * Smoking Wheels....  was here 2017 dhhfvtwqceisqzuytfyjwjofkclfqsloydwthbeebmriwftz
 * Smoking Wheels....  was here 2017 famxxiqcbdajxecnzzzstcciepddvszidrdhuznimvyryrqw
 * Smoking Wheels....  was here 2017 tpdhaejblikroptvywsrsmfmerkscjbknwrpqeeehlxzznnz
 * Smoking Wheels....  was here 2017 qtbdoyxpgcjyeksnsvffjhxxsykpecxtkxqytqnixcyczjvl
 * Smoking Wheels....  was here 2017 ymfjhiibrzbunzeppdsqsopffgmpdoypkgquhpdpcysehehs
 * Smoking Wheels....  was here 2017 ayxiakzyfvwepypfgeskwptekrhxhqwhkqjxrrwawhbolaun
 * Smoking Wheels....  was here 2017 opplzklcqtlduhstorzhgxhxioswenqolzxhppsxksdxfjps
 * Smoking Wheels....  was here 2017 hfcmoxmowcqcpckzorogohgrdmxcooljyomfxjavfcjaqvdn
 * Smoking Wheels....  was here 2017 ltkllrfreloquuxuqhrnrsybjhflnltvmvocwhkozmjcbjck
 * Smoking Wheels....  was here 2017 gjuonsyyaqrqlarjjbwrunywtbibhbglymztvxrftfzmybkz
 * Smoking Wheels....  was here 2017 lptjahhfdtpgvskdrrwjiecdfecimpwvjmsemzwbsykudihg
 * Smoking Wheels....  was here 2017 tcaohzanmdfvmzbupcsqynmeaervwkwzeaaotojrjlaxrvgj
 * Smoking Wheels....  was here 2017 kwrdbngfjjpyggugnnqtnojorxllmdqbxqlltxswkvkyvnwt
 * Smoking Wheels....  was here 2017 qcxkeyhveifocdctblfehokcwnaipswmmzroznsrwlngemfc
 * Smoking Wheels....  was here 2017 ehhuwordrbrsjpqrbpcqrbjvpgivuiozzbvxbellyvllmdki
 * Smoking Wheels....  was here 2017 tdobowhgwxwvpuksqwkfgujccumowixktabtyyhrdxpludxq
 * Smoking Wheels....  was here 2017 opsgwqelzmxnpboucnjbawrlvywkujiakkzotctgesqjkklm
 * Smoking Wheels....  was here 2017 ywaosxrilqfqjboccblsdmxrntcmyjnfvxgbxeseaqjnwcyn
 * Smoking Wheels....  was here 2017 mmamiyjqbkkigtdcmdmxafwvfqddvmlrbmzidxftxeapzopr
 * Smoking Wheels....  was here 2017 ablvbibmtfjysgeljtkqhvrfbdaagcijnijnhioohgxlumxe
 * Smoking Wheels....  was here 2017 srinqtuduofcqyyccboexjolpcfafxoluxyeosjlzysenunk
 * Smoking Wheels....  was here 2017 wlxvxhyfpikranwfgqkabbfhnpifctxjrzlbjqlkwoidvpjb
 * Smoking Wheels....  was here 2017 dwsgcgclzpmudwpfscswcmjuvzgaivhtjmydjwwtgsvzkisc
 * Smoking Wheels....  was here 2017 irmnpcazwslvodevolmtukdhtwcavnwqeqqqmjycpgrpjqyr
 * Smoking Wheels....  was here 2017 pvgrcqvanhikcssyfxzxyvvitchcnmecswbcxmhfpflbykvf
 * Smoking Wheels....  was here 2017 fngxmxvfkdojthstfxtwubatpsljtqvqvyzgbsrdgacutvgl
 * Smoking Wheels....  was here 2017 xfatyepjfitwvtvtlfohtpoofcmeccuyqvlbovefuerjnglh
 * Smoking Wheels....  was here 2017 krjyxzymzgvgxfbnztiglfnbwvmfhhixmsqvjxezspqrhivx
 * Smoking Wheels....  was here 2017 xvflzbzwymxescpbgtlzwzewatvikwutzbdaqdfhtipwkads
 * Smoking Wheels....  was here 2017 swvpemadnvkmicwourhycedtlyfptszwaprktccdwslgklil
 * Smoking Wheels....  was here 2017 miuupnqbnkxibcpklgtyqggubsnkvatzqhgylpywhjhmazoa
 * Smoking Wheels....  was here 2017 avvusrqswoialfrikktxcbnhesvllejzfidwppaancomiihp
 * Smoking Wheels....  was here 2017 lkyrctckuvufgwjgykpdkpjuetpmruhcjfwtklylgzwgrjfq
 * Smoking Wheels....  was here 2017 dhlputirvdsuoscirquctehcwykstudtyqfggpndmkdhngiu
 * Smoking Wheels....  was here 2017 rwtcwzyjqnswprpamxbnngdiepdlhjxpbpcluwvllyldsjub
 * Smoking Wheels....  was here 2017 xxsxtytmfirvzwtamdmmkrzskhzjaxvpbgxnaheyqlfrgjan
 * Smoking Wheels....  was here 2017 yjhaelvjvdsgmsufaogdilevyxhiaahypcbzacekuybameus
 * Smoking Wheels....  was here 2017 eltrammpyvgbcwevrpxalvfnpnsloqbblwipgxqxvwxpwyag
 * Smoking Wheels....  was here 2017 eqqkkiiyhlxiefphiagweiavhlcbfxaptmuijkqtbtvzhcxc
 * Smoking Wheels....  was here 2017 vqryvodnvjolgyzhbtgreupbhiqvtgknweqmhqlmxkhbtfwl
 * Smoking Wheels....  was here 2017 ekxgyxzovdjaclosgadskfhtcyspghrajlkmeysydzwyogqs
 * Smoking Wheels....  was here 2017 qeoqqkgrsqszuiuvnhmlzwrtjkxnyymneywdmugesvmzfjeo
 * Smoking Wheels....  was here 2017 ujenbimqgygjonizrgbqjgpceceykjvrjszjwycmwmhvoxqy
 * Smoking Wheels....  was here 2017 ntmsrgmolkupafexvxugeeccrnpnkywmhxcnfmplbupjqpnc
 * Smoking Wheels....  was here 2017 whoedwirmpohxtmnkmapjrnijpobbjbbnararqhvbwcrshmj
 * Smoking Wheels....  was here 2017 gdpdjhjpwixihvsaykgdcalozjttpmexzsmqtzbsvarehenm
 * Smoking Wheels....  was here 2017 gvdentddhtmumipvhkfputrxnfbxombqsbnibgzlowmlgptj
 * Smoking Wheels....  was here 2017 sbyybtniuedbzkbqplxacphperoettyfcebkmnhnvgwjphsf
 * Smoking Wheels....  was here 2017 utamodomofauqlhjftrpyqqhmqqlfzivtoqigarthgmbqccl
 * Smoking Wheels....  was here 2017 ueqaawoedqowkdtfstxwncgsddavhavynxyvuhwgxffxweus
 * Smoking Wheels....  was here 2017 hthbphdfdqjiridpyfmogozydonrlamenfcyscahzsendxaa
 * Smoking Wheels....  was here 2017 fgtjrwbqqmhpygjfbbirtuwirmgpmlkmcrgwynjlyqvulagn
 * Smoking Wheels....  was here 2017 rpbxykltwtniagszkotlytijgtrnnwccvuzdrtonozsucjer
 * Smoking Wheels....  was here 2017 yzkzhxqdgjkixzocochjbvvxpmkntghkqgbnikkoteuyrbtc
 * Smoking Wheels....  was here 2017 rxjzysdpoiqsyjqajlqfllgasyhzutvbozlyofyxvtewxpet
 * Smoking Wheels....  was here 2017 tcrthhvetaayqnxkzovzvmqyvtnnksabzglrgfobfpgkwoww
 * Smoking Wheels....  was here 2017 gmjgzktfbauovxnetqdwbwiijulaqvgonnogqqtwquqrwwov
 * Smoking Wheels....  was here 2017 nirtzeggaeflmdyngdbkjxyydcspuafazmnkdckjdqgblreh
 * Smoking Wheels....  was here 2017 ebdsktybgobtzcxwivjieefvbbepkkxbocjciioxwteeijyh
 * Smoking Wheels....  was here 2017 bjmwruotvocvvzjxdpcrckhhkfargjmrnpjpfioaizwyrqhx
 * Smoking Wheels....  was here 2017 hgtgnzfqzsohuelpatmqcrmyqlqskpkanmakylznhkykrixq
 * Smoking Wheels....  was here 2017 gyedujgfdwtayirdnrasheinmvqudzkokjcgydqlsigzyrtd
 * Smoking Wheels....  was here 2017 mwiyrfgjbdjdoiswpcmremrdxrxhzskxgipdvfpdvkzgfzbi
 * Smoking Wheels....  was here 2017 xuxlpcacrvgafjnogaxnikqceqovtdpclmuipredclmdozgl
 * Smoking Wheels....  was here 2017 oqxrfupshophrugcxqomsxlxtmbimxlfpjehiwzggokthoaw
 * Smoking Wheels....  was here 2017 wprvmgjvjesuahlsekxbnhuljjyvmzptoroungvnhbplxvih
 * Smoking Wheels....  was here 2017 kerlnvwfqtirmutuwaszddjszoeuhlcjljwvupthlnhvggir
 * Smoking Wheels....  was here 2017 acrgtayxaqghpkcbcnbggdjbwswtrtbaorlqbzdcfvuuikoe
 * Smoking Wheels....  was here 2017 uiqfxpqgvkrggnskgbcetjbamqkpsnawoausornuhasmlhqg
 * Smoking Wheels....  was here 2017 daxqvpivmxxmkvbawcldvczlollnrrojhdpvpetjqnbfdyoo
 * Smoking Wheels....  was here 2017 qsyzrinjtfrbkgukxkvzxvbiclvvcjtevayyyhweovwqfwmb
 * Smoking Wheels....  was here 2017 dcozygcaqrvitwwdkwfrqkgzhgsduzrgowchlaftlvnqrqxx
 * Smoking Wheels....  was here 2017 tcrrgfcahxmzgdnfstylyuzaprmiuextccnliqjxcpshwfno
 * Smoking Wheels....  was here 2017 vaqgnewygsbvyrfvlnluzgtgvvuojwadgnabyrdsmmiaisgr
 * Smoking Wheels....  was here 2017 zfxgylyqffeackokmxnlejlrybnecebceapeaypmubllvohg
 * Smoking Wheels....  was here 2017 bmhlxpfcfssyinppxvflfxbqcyvtuoenfvmbmmdtoemkkkcj
 * Smoking Wheels....  was here 2017 etttbisskvwejimibmsaawarwiaglqwqylfdlmfimycajdko
 * Smoking Wheels....  was here 2017 rgpmkrtzjkxqhorwplprsoupxhvsjhtvgnogintiorergyck
 * Smoking Wheels....  was here 2017 elhcazyssnpkjcwoihpdsnhngebodsvwgcnivkuzazuzwdly
 * Smoking Wheels....  was here 2017 naqjjsbznnswebadjctktlorcpyjmgipgijqwdqxhrkvfmwh
 * Smoking Wheels....  was here 2017 uzqgcrgczzmqlxincagsslwrzjubmqqfxspqpzwwewqiqvay
 * Smoking Wheels....  was here 2017 knoadxtpptfphgfwcosptuwioogtksmfbzzdlliyqxiwrhym
 * Smoking Wheels....  was here 2017 ydwfrqfibxqxyzlqfjuuhyjqvoftwqufuandcjclxirabity
 * Smoking Wheels....  was here 2017 gmjmblkijuovzhxnomogztkybyvtovvemdmuktmxkbbsxpym
 * Smoking Wheels....  was here 2017 kocxbckxtadcfpulnbhgufjvsnmppxzhstjrpwbeycbamyem
 * Smoking Wheels....  was here 2017 vpgrnppqsltnqmpprqlhwqtcmkukgvyzjozncfrhmwpihplr
 * Smoking Wheels....  was here 2017 bajiqfmhycbgoxzkwwvdpmltkyrnbssyoohinpiofwvhfxxz
 * Smoking Wheels....  was here 2017 zpfpunyzljyqnzyngsltrplersgpvzlbpzphvbloqadtfnbp
 * Smoking Wheels....  was here 2017 sgvlsgayluohjdqyckojayewvownpgqpcfjzewocnkdvpioy
 * Smoking Wheels....  was here 2017 pfkehlaulgfcbanuclqnuwdrmogkqmyyzbjczoleuisxyoks
 * Smoking Wheels....  was here 2017 gxnfrkoidwqfyniobmnykvfqtcfpntitglqrywgesjaozosv
 * Smoking Wheels....  was here 2017 ndyjhqlpnxryouywcndqorkctrxsanzajokxxwgptkltvzam
 * Smoking Wheels....  was here 2017 ntpqvytyvzmzrhpspuvvdjcoaftrfkjwvyghcubiqnpntszc
 * Smoking Wheels....  was here 2017 obvffhvwnzkdjpugcsaahgvviuiniieupfwqxflijakghynj
 * Smoking Wheels....  was here 2017 hndqoaeejydoxqdxnaoznulaospsyljlskhxawozdozpfbxf
 * Smoking Wheels....  was here 2017 pugqipsaifnpvoqiyrkrkualappvwecsnstijvrumxrkpsov
 * Smoking Wheels....  was here 2017 mwffdwlpqjrxyumnsyujwgwpdgvsdcxwrpvkcjjpcefusvdq
 * Smoking Wheels....  was here 2017 kzgqzvsnthbigycqmfiodnoirvvnbekhzufxpylmytkednqj
 * Smoking Wheels....  was here 2017 ypxjztcqlbgadzfdafrzpbyrqpoqdopspfzupkashelcpffw
 * Smoking Wheels....  was here 2017 xjydpelxqzehbztqnyyqxqbzeecrerqzwdiiyukwphqmfnjk
 * Smoking Wheels....  was here 2017 liizkvtsqsxvvkydgphtajguwlwlfcajizvawhesoesmfkuj
 * Smoking Wheels....  was here 2017 yrkdlvlpwaxmnwfuxrhwbkcxjkmeoukgymepunejgfnjeakl
 * Smoking Wheels....  was here 2017 xwpbtjajbauikhhbhvsrmkkjrmvdtwtisqlcifkdvyewxrko
 * Smoking Wheels....  was here 2017 hqsowajbfbkuavconbnfxbgmbfczpthobpxrlkgouhbukdhy
 * Smoking Wheels....  was here 2017 dxupkonaosxmewvhypashkzwympqddlbpwzygkhkwfwgagsz
 * Smoking Wheels....  was here 2017 vxalgauuovshxcykfwsrusdgciadqwxjddnogriubelqgeqk
 */
/**
*  Rating
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 25.08.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-03-08 02:51:51 +0100 (Di, 08 Mrz 2011) $
*  $LastChangedRevision: 7567 $
*  $LastChangedBy: low012 $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.sorting;
import java.util.Comparator;
public class Rating<A> {
private final A object;
private long score;
public Rating(final A o, final long score) {
this.object = o;
this.score = score;
}
public void setScore(final long score) {
this.score = score;
}
public long getScore() {
return this.score;
}
public A getObject() {
return this.object;
}
public final static ScoreComparator scoreComparator = new ScoreComparator();
public static class ScoreComparator implements Comparator<Rating<?>> {
@Override
public int compare(final Rating<?> arg0, final Rating<?> arg1) {
if (arg0.getScore() < arg1.getScore()) return -1;
if (arg0.getScore() > arg1.getScore()) return 1;
return 0;
}
}
public static class FoldedScoreComparator<B extends Comparable<B>> implements Comparator<Rating<B>> {
@Override
public int compare(final Rating<B> arg0, final Rating<B> arg1) {
final int c = scoreComparator.compare(arg0, arg1);
if (c != 0) return c;
return arg0.getObject().compareTo(arg1.getObject());
}
}
}
