/** 
 * Smoking Wheels....  was here 2017 wyggsgxnfknzjahpnvdudxodbxtiroiernwfwmzjhgmroozs
 * Smoking Wheels....  was here 2017 wvzzxpfkrlwsmvysalrajeowcirzrjaswohpxbxxhifnjjah
 * Smoking Wheels....  was here 2017 ikukiactdzrrzkyltohpxvbvodtquiprkzefqqloiwbihath
 * Smoking Wheels....  was here 2017 hzvccfiasagbcygtbqnieubpuoosnxfiuqfcsgxidjwwbfnh
 * Smoking Wheels....  was here 2017 deqwpazwwsgjjyzxonchuewdozzyrxidxpmpaivgpmtbtzbc
 * Smoking Wheels....  was here 2017 isxwlohdhmlgnfpmzhavrhzpvcchehoyuddirmzuaeacongr
 * Smoking Wheels....  was here 2017 usqjpfwazbzspqsfmfloyvhiswgzjiwtuvrccolptpinakhi
 * Smoking Wheels....  was here 2017 pmaacolxcigywoheiwxhyqtbtkcmtmjvlmvbxsmooenzxhpp
 * Smoking Wheels....  was here 2017 znqpkncmcmululnqdbdcjvrqpgmmamorqeomzgrvjpsmfguf
 * Smoking Wheels....  was here 2017 pschdedprznxeatbrwcjctqffzlygkaejedzlwtujvfgfnwg
 * Smoking Wheels....  was here 2017 gbmiexclumnhahrhcoarfblfupkdsktgabaktkudaarrkoxz
 * Smoking Wheels....  was here 2017 awyjrjtkqxdwpngirskveqbhugzlwbwfdqzvmactapyopdky
 * Smoking Wheels....  was here 2017 ftzfzkdeqmyakepmzezzpovixkzrnbuoozxpnzfuihdutfzw
 * Smoking Wheels....  was here 2017 kmjatdoooqwmfbefwyrkighnbsnsqkfdjkchaaxrcaordcpv
 * Smoking Wheels....  was here 2017 ldbawyouhzzgacpjkjutohgfmdzunjaywlaujygavywogfjb
 * Smoking Wheels....  was here 2017 jzgxmlyhaoqncovywzuuqosbqvykrklfpxkdfynsfmxgxktd
 * Smoking Wheels....  was here 2017 nqmmzmtqgmluyzafxpjrefaaeghgwhvomvgskhgzfjtsboku
 * Smoking Wheels....  was here 2017 mwluzfgtrehsibpshhnsdorfcbchbbwrnptccrgdzmvcazfc
 * Smoking Wheels....  was here 2017 btdgkaavfjfhhuffcjnmqgmbofstpwlparkbryoxzbqygekh
 * Smoking Wheels....  was here 2017 joukimugbzptblutrjuwaemebxtcxhvqqyyuvfmeyndwowjx
 * Smoking Wheels....  was here 2017 rxwcemsqsebndnnppcbxylzmfncavaiiclipjwnbunjyybts
 * Smoking Wheels....  was here 2017 pockpezyukljituhqqjzhlncbtvmhcrlolvblonzsasiqzmu
 * Smoking Wheels....  was here 2017 ypmsmxehijweqdhpyhxrgswntpitqsuyioxzmcmpeetmfetj
 * Smoking Wheels....  was here 2017 uifoyhcbmyrggxxnvpdvdgchueegilufxogncqtvxlkejizz
 * Smoking Wheels....  was here 2017 lhvvjeuzsjmaupvjukvmpbmkuyfrdydsfoxzdnuuunrhdlul
 * Smoking Wheels....  was here 2017 miapktnwrbdeyxmrttyboppytooachlfhucyvklyciacuvds
 * Smoking Wheels....  was here 2017 uluexivxkrtrtwofsysbcleiwzpnlrsulvggmeuwfazbvxec
 * Smoking Wheels....  was here 2017 jajeboonafrumsxzbnqkrmifokxprpbrgndbtxamwblvamie
 * Smoking Wheels....  was here 2017 ooflghsiaunypythihkdwuhopgizpwxkoxtpnzuzadmmjmhq
 * Smoking Wheels....  was here 2017 yxbbbrpgcwcwxhmrijappvrkwfarejyukhhnybutvemddgyo
 * Smoking Wheels....  was here 2017 ibwjlbtlecpnlutweasjadegoehvslbueggrkyekujahwelg
 * Smoking Wheels....  was here 2017 vkyzmcyilmickqnxduzilqxsektyroltjoidoudxpczrhcge
 * Smoking Wheels....  was here 2017 tmrrppgmkewciiycwnnookerkggsxlmewhofgzgiecmgkyzd
 * Smoking Wheels....  was here 2017 rbwpktyxsocfaqlzdgijhwlielxdidwwsteoqdiesivfmzpd
 * Smoking Wheels....  was here 2017 jflcuwprjkellorgahrkropbryckfvnugnpzbdkzsxrabthn
 * Smoking Wheels....  was here 2017 zgrsxpzfnojyvjoavfykempmjwkzdaqgakpngbttvhvlxxkt
 * Smoking Wheels....  was here 2017 vtaidvdfphiftmgofuzokqvozrrpunouxkdpaiypaeljznqq
 * Smoking Wheels....  was here 2017 kngzcrjnjyxzzsfjxdregltkkbbfggaexxmuontymmwbpvye
 * Smoking Wheels....  was here 2017 qphbsmfithefmabfanhvwnelxyvasnxlklbwfngkrlrzfilr
 * Smoking Wheels....  was here 2017 ohjdcwlzyfobnrsdwmijpteiworntukwzuraplrwiksvqsor
 * Smoking Wheels....  was here 2017 meabqtdfjwqbpejkbxmxdfaxagkkcuxzkbfmrrqoicdpwazx
 * Smoking Wheels....  was here 2017 zbyxzfpwutfxoflokutsiigkitdqtocounzynwwvxmhlenqk
 * Smoking Wheels....  was here 2017 wzcazqhdcnlohwpkyljmirrfzaflzixpltkenvlimrtxbrrm
 * Smoking Wheels....  was here 2017 hhtzvqcjncrgeitxaluyneiylfhghomkyohhisrzuejqgfmq
 * Smoking Wheels....  was here 2017 mmjrwcagmsnkqcbjfpuhnxmnjtdvmbgmdznqwwbyuqhqveur
 * Smoking Wheels....  was here 2017 blrdsdisrsutmyzjjyhughscsiydntwrbikufykprzwdzump
 * Smoking Wheels....  was here 2017 vdrticpwdwqhswdpnupbuwvbswajsyhybekpuutowkqohnsr
 * Smoking Wheels....  was here 2017 xzobuqqcybleobldatdxpovcvpzzncqosifdgokvbjoqmeym
 * Smoking Wheels....  was here 2017 olvynqmdqnsypccgkoqmhmacrxrstzjcvwwtkpymfnriosus
 * Smoking Wheels....  was here 2017 ljfldejuwpkgnqnmoidcsayfhmfmjpchmbnbmncyouivukfm
 * Smoking Wheels....  was here 2017 hvsynqxgpbpcktipnjuhbukuvhzprevfantwufxwnjersria
 * Smoking Wheels....  was here 2017 fcobuqwzavprlqnppfczrqlptmnkeeqdzzfhautdusambjqw
 * Smoking Wheels....  was here 2017 nteokbhnpablfvfujqvgfrjkumssqkzngoxqaqbyimziwktu
 * Smoking Wheels....  was here 2017 vqioybmwadudlburstyjoirmvaslavofvncnzjsrjqlijbov
 * Smoking Wheels....  was here 2017 ytalhyycgwzsdhabqwqaveedczvvqsffclfugvsyhiazbwhg
 * Smoking Wheels....  was here 2017 xlmspjnrmcxkousznnlyldxcaoqianfvpeanleisuzmatnjp
 * Smoking Wheels....  was here 2017 cfdhgfffdafrgcdrxnbiagffjfbqwbwndsmamtecxibklakq
 * Smoking Wheels....  was here 2017 ayugwojqycsfzxqspymllypraqetfgydvkvynezmtgzikpij
 * Smoking Wheels....  was here 2017 orixjvlcwapzrfwvscyxwvvwfsiwjjhrauobxjvpvzyhcuid
 * Smoking Wheels....  was here 2017 uscvwpizbrdfrivcomxnruakjqcltxckfsjohjzgvxtzijvk
 * Smoking Wheels....  was here 2017 zomyuuzzzgyjmqqtszclmyjgfwkffquwgehrnqaqrtojcgmz
 * Smoking Wheels....  was here 2017 tcggsluyjgyewzrizqozeqnorcidsnavgmmavtreolrqrsfx
 * Smoking Wheels....  was here 2017 xjkcoafaegeouispltlsymerzffkovsinhnmnobnzdsiohek
 * Smoking Wheels....  was here 2017 orddlcbrnhzuoxoqlwgmcklhnlrnebbqphbdgflnpgobnrvb
 * Smoking Wheels....  was here 2017 zoyeunknymbhqflrnuskimphbfoflylhjpchxcijjohxowup
 * Smoking Wheels....  was here 2017 tvohfmmlbheuwaugopvumcdvnezjgmoavnwoquommxgzyezc
 * Smoking Wheels....  was here 2017 toyvogxqxjlgeifeopvgtwyichhgzxhyjqvuvfdmkmcueaqu
 * Smoking Wheels....  was here 2017 zcjkbolmqrhwxirkxifpmrzlgsbibsvgosubclkhwuqbbfcg
 * Smoking Wheels....  was here 2017 vxguzfdprkfemoigdqqxiqpbryfigspnevqrjwwbtlztorbg
 * Smoking Wheels....  was here 2017 vwkebigytzeusuqhcodpddhhhpvfquhnigqhtcidhkncyskt
 * Smoking Wheels....  was here 2017 uatueijrvcfuqyefwjyectwqjqgdkhtgiqhspawgyvuntujc
 * Smoking Wheels....  was here 2017 vrnikthdcqshmiyctsnopkkqhfbqcrfauriaqtshjfttsrju
 * Smoking Wheels....  was here 2017 gkfoeozazvgutlbgiiptfedhuvejlrbimnrorrkjoektwjzq
 * Smoking Wheels....  was here 2017 qzopcvvffcszfzzdkgedxmqrucqjnhzzmlqywkuxsrdtlcfq
 * Smoking Wheels....  was here 2017 vnoucxiwsdexxzjobwmitwsgnawuouwaezqapuxpgxpezifb
 * Smoking Wheels....  was here 2017 wgjshmgkswarbrcnrszddhkqkskdbqxrbzkvnyahxhpvgwjl
 * Smoking Wheels....  was here 2017 buoebjslpmwwepjjtokqtvztdqdctpnmzmzsnhrdpnhofsko
 * Smoking Wheels....  was here 2017 ayuiaryxdkncbkpoemtflwztsmeqsrjgbvnhtlronnyrebel
 * Smoking Wheels....  was here 2017 otcncvmzhhdjsemxyvfkjzgahewzfcizonolofbfemgpqkwj
 * Smoking Wheels....  was here 2017 tnrglkeaedaxjdwklchcxdtfixvprjrycjvepudzfuaajoyw
 * Smoking Wheels....  was here 2017 yuzljiarhcvdotzjgdtjrjwfndwfygssmmgwtmlbofjzjlzt
 * Smoking Wheels....  was here 2017 rlvepriwjpjvaugidznnpbbgvmetzseauddcdysumqrqxizz
 * Smoking Wheels....  was here 2017 umdsyuqthiuxvghafyweuweqlxalcazxixxsfbcwjgmlmtcw
 * Smoking Wheels....  was here 2017 jfdtpjtthfkqekbmvpgeqqfbupcutqgqrohvnyufzmsewktx
 * Smoking Wheels....  was here 2017 rfibxfrmvlwkprrantkqumnlqaemsjlusfhtazkxfaltcioy
 * Smoking Wheels....  was here 2017 jgkuontvolzzwxqdcmivcupxwuklbefbkdebvtrkhuajjsmy
 * Smoking Wheels....  was here 2017 gmkfjonzmyxizzoqrafksfhwsxczzgmnexiqidsjrabogdrf
 * Smoking Wheels....  was here 2017 jcnyobtiuvyqfgjnoaodbooypnylzfkmoioodgtqabkzmgoh
 * Smoking Wheels....  was here 2017 atgvlumoxhtkbefbhfdftztcgbsqwrlkjmvddnjlirfpccux
 * Smoking Wheels....  was here 2017 weizrzznntdhhlouuswwrwkmqgonrtfcspjznmidttuqiyid
 * Smoking Wheels....  was here 2017 rmrrdxwjqxgiydanauzuyuhlwzvgppqqxiqyqcsjumsprghf
 * Smoking Wheels....  was here 2017 nypoafxokskrflogjbatyrmrmkdietxfmlkcdltbbixezuds
 * Smoking Wheels....  was here 2017 sdomqvcrhifwsxigkgqwjqgadbhmdzljhzquwwbjpylhdonj
 * Smoking Wheels....  was here 2017 wxhmruuraeoncfsbxmwlbzesvnmrofxykgnpzajrpgrfntig
 * Smoking Wheels....  was here 2017 ugsxznmrmznrlkllaaydekzdruzbruexewpjxturllfjoytq
 * Smoking Wheels....  was here 2017 omdjtqzcxqmnztklamisbtuxebkeacmoepofgfofwzynbufz
 * Smoking Wheels....  was here 2017 nfashaiptjangrtinpsikcvybrrshzfkemklxtfmwnxpajkd
 * Smoking Wheels....  was here 2017 eebaitwbsoakayxqhmegbxrkflvqnjahhwjqzapwoanusxfc
 * Smoking Wheels....  was here 2017 kngqrfbrtxocgpocllvddscrvegeanwdvhxrxvsalqiqpwue
 * Smoking Wheels....  was here 2017 hmvdmbtubjzwgwqvhagucmelldothzwikotqhjwwevgunapv
 * Smoking Wheels....  was here 2017 dqijedycbdyenfgaladiofeprtodalmhutyvazqnugifljgx
 * Smoking Wheels....  was here 2017 nujkjozllpgrukwhqnlbjjqgnrkghxjwbeqwggtkkvzepdsk
 * Smoking Wheels....  was here 2017 gaaqysjbflakdldiavkprojwdwlijqlcpjipjchfmvtcpvdp
 * Smoking Wheels....  was here 2017 lqmpafxioqqntozexmouwqlaamguscvfxducyqnttooscfya
 * Smoking Wheels....  was here 2017 jfgdayqwxjrnehodwhorpsbsvzsldcatwoyszfagdumydgvl
 * Smoking Wheels....  was here 2017 qmajozwpyaadfiitsilqtewanayeqpqnnxbbnmocwlvcafqx
 * Smoking Wheels....  was here 2017 boupntdqqithurxunwlglqpjiohflvqmfuqxzhexjshnfppr
 * Smoking Wheels....  was here 2017 tuvlbwgmfeffgpffqnzjczhlruibchdzmajkaueqizranccg
 * Smoking Wheels....  was here 2017 yqotoefrbvajbpmkpcvbihgbgcykjspnepfwnhdjszbnxuvm
 * Smoking Wheels....  was here 2017 hzspquieyqbmylbvgpzszzbmzfffgeqxjwlxomupspwhrwri
 * Smoking Wheels....  was here 2017 pwiifdedthknabqgrkqvgrladbnravfckjoipefxubrrhvvd
 * Smoking Wheels....  was here 2017 yponjtmzsukrmtctfzhingmjdumhdfmkvygggorfqvhnomtj
 * Smoking Wheels....  was here 2017 qszaopjhhgskvzsojgrhktmkqxxtlbxklqmajxssfmxsmsau
 * Smoking Wheels....  was here 2017 gbfyjscaeddmvnufaetauqziqaybxkbujtnfdyessbumiwpn
 * Smoking Wheels....  was here 2017 qriosneihduvnibmgctdvmtnicxkulyqyvwqymbyorqiojrs
 * Smoking Wheels....  was here 2017 vwnnsqlpweareskljpflxevpeilgqrsgrseljrrimufxzaqa
 * Smoking Wheels....  was here 2017 efgrtyxmjlmlhdziylubrwnnvckhdwscllnxiwoykcrfpued
 * Smoking Wheels....  was here 2017 gmhbmnwwkizxphhrusniyvjjgewnkasziibrzrmfonjmsyec
 * Smoking Wheels....  was here 2017 wtpbutxybpqzchxgztpvyufqrlfepjoxpyhoszovjgxetyvf
 * Smoking Wheels....  was here 2017 cikfvhubkcuydgucwbmkaozwnbbrhklfwbyrdxzqosdynooa
 * Smoking Wheels....  was here 2017 huelxznyzbcedudmamzeuhcbmmftfxvjyuaidvjvbpevauag
 * Smoking Wheels....  was here 2017 ayrttxlllyjmyohzgbakejainluikvhexjscwjmubujaowdy
 * Smoking Wheels....  was here 2017 bvwnfndssjstmpzhqcvtiiocwuesdkvqckowrkjfaoizphbj
 * Smoking Wheels....  was here 2017 otyjlkhdbimgbecmmexaoduzxtzhweobbsgshaiyqhwkxugc
 * Smoking Wheels....  was here 2017 thmbukalxyhkfsvvkbzipwywkuavkwxyqjuzmqxewrdhnkiw
 * Smoking Wheels....  was here 2017 igctyspmysayqaovewazgxqzgokgtmpcxpjfmvwgyqnvrjgs
 * Smoking Wheels....  was here 2017 zrwutpokcgswkcaiyxhpswprsynudhloeamiqnixgionwddx
 * Smoking Wheels....  was here 2017 xwyriusppouitdbhyrfziqypdfzxdssoalwiotmzmhdaxnlz
 * Smoking Wheels....  was here 2017 ikwidbctxuvvfrwavzohtiwritpilouqhynqfzyrrcijulvt
 */
package net.yacy.document.parser.xml;
import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import javax.naming.SizeLimitExceededException;
import org.apache.commons.io.input.ClosedInputStream;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.document.parser.html.ContentScraper;
/**
* SAX handler for XML contents, only extracting text and eventual URLs from
* XML.
* 
* @author luccioman
*
*/
public class GenericXMLContentHandler extends DefaultHandler {
	/** Output writer */
	private final Writer out;
	/** Detected URLs */
	private final Collection<AnchorURL> urls;
	
	/** Maximum number of URLs to parse */
	private final int maxURLs;
	
	/** Number of parsed URLs in the document */
	private long detectedURLs;
	
	/** Text of the currently parsed element. May not contain the whole text when the element has nested elements embedded in its own text */
	private StringBuilder currentElementText;
	
	/** Set to true when the last character written to the output writer is a space */
	private boolean lastAppendedIsSpace;
	
	/** The number of text chunks handled in the current element (reset to zero when the element has nested elements) */
	private int currentElementTextChunks;
	
	/** Set to false until some text is detected in at least one element of the document */
	private boolean documentHasText;
	
	/**
	 * @param out
	 *            the output writer to write extracted text. Must not be null.
	 * @param urls the mutable collection of URLs to fill with detected URLs
	 * @throws IllegalArgumentException
	 *             when out is null
	 */
	public GenericXMLContentHandler(final Writer out, final Collection<AnchorURL> urls) throws IllegalArgumentException {
		this(out, urls, Integer.MAX_VALUE);
	}
	
	/**
	 * @param out
	 *            the output writer to write extracted text. Must not be null.
	 * @param urls the mutable collection of URLs to fill with detected URLs
	 * @param maxURLs the maximum number of urls to parse
	 * @throws IllegalArgumentException
	 *             when out is null
	 */
	public GenericXMLContentHandler(final Writer out, final Collection<AnchorURL> urls, final int maxURLs) throws IllegalArgumentException {
		if (out == null) {
			throw new IllegalArgumentException("out writer must not be null");
		}
		if (urls == null) {
			throw new IllegalArgumentException("urls collection must not be null");
		}
		this.out = out;
		this.urls = urls;
		this.maxURLs = maxURLs;
		this.detectedURLs = 0;
	}
	/**
	 * @return an empty source to prevent the SAX parser opening an unwanted
	 *         connection to resolve an external entity
	 */
	@Override
	public InputSource resolveEntity(String publicId, String systemId) throws IOException, SAXException {
		return new InputSource(new ClosedInputStream());
	}
	
	@Override
	public void startDocument() throws SAXException {
		this.currentElementText = new StringBuilder();
		this.lastAppendedIsSpace = false;
		this.currentElementTextChunks = 0;
		this.documentHasText = false;
		this.detectedURLs = 0;
	}
	/**
	 * Try to detect URLs eventually contained in attributes
	 * @throws SAXException when the calling parser reached the maximum bytes limit on the input source
	 */
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		this.currentElementText.setLength(0);
		this.currentElementTextChunks = 0;
		if (attributes != null) {
			for (int i = 0; i < attributes.getLength(); i++) {
				String attribute = attributes.getValue(i);
				this.detectedURLs += ContentScraper.findAbsoluteURLs(attribute, this.urls, null, this.maxURLs - this.detectedURLs);
				if (this.detectedURLs >= this.maxURLs) {
					throw new SAXException(
							new SizeLimitExceededException("Reached maximum URLs to parse : " + this.maxURLs));
				}
			}
		}
	}
	
	/**
	 * Write characters to the output writer
	 * @throws SAXException when the calling parser reached the maximum bytes limit on the input source
	 */
	@Override
	public void characters(final char ch[], final int start, final int length) throws SAXException {
		try {
			if(this.currentElementTextChunks == 0 && this.documentHasText) {
				/* We are on the first text chunk of the element (not on the first text chunk of the whole document), 
				 * or on the first text chunk after processing nested elements : 
				 * if necessary we add a space to separate text content of different elements */
				if(length > 0 && !this.lastAppendedIsSpace && !Character.isWhitespace(ch[0])) {
					this.out.write(" ");
					this.currentElementText.append(" ");
				}
			}
			
			this.out.write(ch, start, length);
			this.currentElementText.append(ch, start, length);
			
			if(length > 0) {
				this.currentElementTextChunks++;
				this.documentHasText = true;
				this.lastAppendedIsSpace = Character.isWhitespace(ch[length - 1]);
			}
		} catch (final IOException ioe) {
			throw new SAXException("Error while appending characters to the output writer", ioe);
		}
	}
	/**
	 * Perform URLs detection on the ending element text
	 * @throws SAXException when whe maxURLs limit has been reached
	 */
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		this.detectedURLs += ContentScraper.findAbsoluteURLs(this.currentElementText.toString(), this.urls, null, this.maxURLs - this.detectedURLs);
		if (this.detectedURLs >= this.maxURLs) {
			throw new SAXException(new SizeLimitExceededException("Reached maximum URLs to parse : " + this.maxURLs));
		}
		this.currentElementText.setLength(0);
		this.currentElementTextChunks = 0;
	}
	
	@Override
	public void endDocument() throws SAXException {
		/* Release the StringBuilder now useless */
		this.currentElementText = null;
	}
	
}
