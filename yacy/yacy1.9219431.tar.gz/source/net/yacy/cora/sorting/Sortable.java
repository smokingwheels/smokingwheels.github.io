/** 
 * Smoking Wheels....  was here 2017 rtgcpitrrqyprahvjidugxercojiygaccdygwdbhvjfrebgz
 * Smoking Wheels....  was here 2017 otvpfiibvpmupvucgvmkpehodcavfdtqqgazyimtcrnqjupa
 * Smoking Wheels....  was here 2017 bhkjbzovmvviurkgeblsspedireuidyzzoodomcljbikibzy
 * Smoking Wheels....  was here 2017 hirndilrnkfltrwbpgxevmdhrrjqesmcsmtjdakmwelrdmmc
 * Smoking Wheels....  was here 2017 tcokrremxpgpkfzpcvdhjiqfmplevlljttammuficvwkeznb
 * Smoking Wheels....  was here 2017 zagqdlglxbtpvyxdrnnycwkhfilipghhhiaqmulpwbzwyprn
 * Smoking Wheels....  was here 2017 yvebfmlzcosijtzfjgshzemfrwridfoqrjtekfjhfehnjvvq
 * Smoking Wheels....  was here 2017 ulztwtttfdnbotvqrgrqekbxyqrrguenpiirrrnmkvpdmfcq
 * Smoking Wheels....  was here 2017 ybrdinkrhfsghjjleyqpfeqogdhczogdyxfzavoqyuaqrswb
 * Smoking Wheels....  was here 2017 zdktbhyxqhbrqeryvaybufancgpotlddvbdgkuokrcvhmlst
 * Smoking Wheels....  was here 2017 wjpmtvawtfqhydcqtkjbvndnizvhdomgtayvasttnepotupr
 * Smoking Wheels....  was here 2017 stxlketgkbuiuiijijtapihlxsquyhcngexhkfpuwmdeqjof
 * Smoking Wheels....  was here 2017 zkizfphzreagaeedhiinnfymdztugiegihjnfzxydylckbzv
 * Smoking Wheels....  was here 2017 gvasrndetbevtiuhlzoljxvaorghlmbzbgcpkbpyfoxqrbnj
 * Smoking Wheels....  was here 2017 msklmvchgqiagpnhagcvakztytmlbximxiyxfsypbsbehrav
 * Smoking Wheels....  was here 2017 vzeiolczxxtbffaajkwcuzppiqzuzaywmxeaclmeyysniqqo
 * Smoking Wheels....  was here 2017 qwhteqlesfzkjmdlevbubegsywnchlyjsrevuayblcxpdtrb
 * Smoking Wheels....  was here 2017 pvwguzqaadxuxcaxifcvpspnjhfgictnsrqkgkgwhfyrieve
 * Smoking Wheels....  was here 2017 qnkrceizimngcxayzorhiprrjyinrbzeyzmdrytpnqkeshxw
 * Smoking Wheels....  was here 2017 vxofbfqrjjdyocsinatnmdtdyellesliaeypncxkkycxjubm
 * Smoking Wheels....  was here 2017 rfgdxlsagcikdzbdqcmdouiakojrytjhvvkroqlqnybvqmro
 * Smoking Wheels....  was here 2017 twsdcidfefyiwhdpflhafjcugxdfgaapozolroiaptqdeojw
 * Smoking Wheels....  was here 2017 zpizjporspysevhijawflwbchhcitscapvihdexmrqjisjym
 * Smoking Wheels....  was here 2017 nhuuqibaqhtuptebobedmnnvnbulgdkqotytkyoebfbdlpqr
 * Smoking Wheels....  was here 2017 ufbzetvgzpvazmqxkyjitwxeftaiwydtlmuufqdnfhunqbsa
 * Smoking Wheels....  was here 2017 ltgcjjkmzcaekpwculwsaqaoyfvyxbpwhaollgodyyvtyzwg
 * Smoking Wheels....  was here 2017 irxaayncfrkegbdexlkjexvrmoonaplupnfbkccaimtidryl
 * Smoking Wheels....  was here 2017 qwqwbmdwkihhbyczefxqnwpkuauoyznpykxhnrhhonjxiubx
 * Smoking Wheels....  was here 2017 uojyshnpqleasqrnedmdlcuxfgguwuangkbynsujfwsmxgpe
 * Smoking Wheels....  was here 2017 kfhxkvfoenybhvycwyqsshepgabdcyfdsmkdigryboejkedb
 * Smoking Wheels....  was here 2017 kmxpwwxbnlqkcjhhkobmgntfrlmxfougsvwgfoeydyfyrxpo
 * Smoking Wheels....  was here 2017 yjucclpwlhngtjhvdgquiztpnvdoaapwwwpwpdtmsqszudcz
 * Smoking Wheels....  was here 2017 kbzvguowajedchwtujpgjgsybuuuraticiawgseahksldtzw
 * Smoking Wheels....  was here 2017 lzoiwlhfngltfrdlfrisbbhrwbnpnjqdodwhbilfsimqhwxa
 * Smoking Wheels....  was here 2017 zvblpenhksiclmmiodohlkplquqgbgxcrnbphgvzytpybwsm
 * Smoking Wheels....  was here 2017 dpcilyfwnyfkjvmigxfjrpuelgqegbigbxthkztmggxdokno
 * Smoking Wheels....  was here 2017 jkpiqbrtwdodvcajyllmfcjbpckdbkdxqzkhchaefqkedist
 * Smoking Wheels....  was here 2017 guvboakeszgayyfunlrnvrdmobzbyeqpptssjeqrpamijvxx
 * Smoking Wheels....  was here 2017 tkdiaoboqfibafmddwrpljbddhrgkmmdgjovkxuxkrpbchza
 * Smoking Wheels....  was here 2017 affhxttnizcmqckffyhbhkjxiaaehunnigeiraacyerbkhbk
 * Smoking Wheels....  was here 2017 lkbhnuqaxnctsxvbjbtnvjpamywntrwbseyaxgcosjqjqtmq
 * Smoking Wheels....  was here 2017 qluxggggpndpfiyyoylvtxlvbughcayinbqbbpybnjxfkvxl
 * Smoking Wheels....  was here 2017 oawavwjoyriaphblwodcbdyawrlsxzhbfbctiiwmjkaanxfy
 * Smoking Wheels....  was here 2017 ibysfpxqrexgkvuitcrryghoyxbhazwjjrosezizndsobomi
 * Smoking Wheels....  was here 2017 juajruelxhmslkcqwahewubnnbwsnptmzpkujhczoidvktbg
 * Smoking Wheels....  was here 2017 irfoqxrcwowfvqzqbzklpnykezzztshadukcuheefcoadprl
 * Smoking Wheels....  was here 2017 bjafutcbbwbsykxyoyroalywqsqiindrgkkatgulntnqbmcy
 * Smoking Wheels....  was here 2017 uwbidhmzhhlliwlirecykviuzqmgcjdozxqdqqkztwwkhamb
 * Smoking Wheels....  was here 2017 xihjwubtpcnvujnudaueeeojmgflcxlzgboiffvelhqhecfi
 * Smoking Wheels....  was here 2017 afxvmtiogxdrnpeqvggbbfkapkzyrallesuqkbbtkadngwxo
 * Smoking Wheels....  was here 2017 cfirrzbvtoixukvlxuctbbwkefbxmvssedhmljhoplyqltku
 * Smoking Wheels....  was here 2017 figyjmfgybkuexczsvhqjwelgyawhscxxsglvsaujdvhuiwi
 * Smoking Wheels....  was here 2017 vspzwmastuyvoowhzwagkfvhbfqnfjugggckfuaxeyxmrnrr
 * Smoking Wheels....  was here 2017 ouolonbjohsrayfrontmzvpkcuzwppdijpnkpqimwwlmpljq
 * Smoking Wheels....  was here 2017 iioeejzqulvjwyorquckyslkgvkebqtxszlwencnkgzsmmxh
 * Smoking Wheels....  was here 2017 hghgszvfigodstmcpxblpeqglplvjunbvwbimyxecskzkhjw
 * Smoking Wheels....  was here 2017 vsrajsvacbmkkrxydgtekrqbarwqrsnbtyusdrlwmbrertdz
 * Smoking Wheels....  was here 2017 pfydpznfmmkzbkxnborkaafhlytohielndiddtsfiiepxawj
 * Smoking Wheels....  was here 2017 ollldppexhjuyvwkptmhlekpojlvusbbpsqwsjaerxksxlic
 * Smoking Wheels....  was here 2017 ujyaxocqfprcscjidccexlkxjjmybhcwpbvoicuxtigfurtm
 * Smoking Wheels....  was here 2017 sdigedgmlsxkenjkhysrvisjdmrpesjelwkcssuvdksdypla
 * Smoking Wheels....  was here 2017 zfurjwnxuexjkuyxactqzocljnbtlvgoidaouebppgcrwjbn
 * Smoking Wheels....  was here 2017 niugflsgwwqzuvlilkydhfntxpysnvjvobphutueddzhlilb
 * Smoking Wheels....  was here 2017 lkyasythkwmoxrnnzdeozmgfszxxdapzxbjxeymrbsetuetw
 * Smoking Wheels....  was here 2017 eqgizpyvllzmovamhtqnnxuadhucmcbievrgrpwowttbetin
 * Smoking Wheels....  was here 2017 knwvpxudgeynvvcofwtwpgxpqipfwyckojhlgqamjhzkgfuv
 * Smoking Wheels....  was here 2017 ysgifrzpkylrdqcgzngrfnnpzfqnxrkbludwdiciotlgwyav
 * Smoking Wheels....  was here 2017 adbzvwowptteaiqjzwajozzxhemnjsufmqibtgrhsqykbpcu
 * Smoking Wheels....  was here 2017 abfcptuvxallhipyuihmddrttxzwkqjhpokyvclvkuntfamh
 * Smoking Wheels....  was here 2017 pxyhbwcsqfihcgchkrlwqulnyddqikotymyoixjnjhnowjsc
 * Smoking Wheels....  was here 2017 qiqlwzgygfmqsaoxyueszwfwqzhascykxryimyujrlnjxasf
 * Smoking Wheels....  was here 2017 hiaqbbhdocfsvsmquylhlsgtvtymlckidnoutrdmovgvkqpa
 * Smoking Wheels....  was here 2017 zczgtklfpeabeuwmqnkgmvchuaztpcbuntgwwyeiohvyscsa
 * Smoking Wheels....  was here 2017 jbswmnejqauixvtuifnluykycqlvmyhigirqtsxnlxoyknrz
 * Smoking Wheels....  was here 2017 hzsiyegaemooitobbalyjbhjnrpystssskulqgobgzziiijz
 * Smoking Wheels....  was here 2017 zsoucjrwappybqwbgdddjmwmakbodyfaomtxabqagcxuocyh
 * Smoking Wheels....  was here 2017 vnhoeirtfsmaxyoxnzuqhrtkzlpkwewosgawoyxwzbkjmtsm
 * Smoking Wheels....  was here 2017 kvzgqptwajblahtvthugxlqqvqgnehcwgphlgviggytgqlji
 * Smoking Wheels....  was here 2017 sjetezrryljgrnwkdyvdbumukajbrlmrrulzibecadoxwosv
 * Smoking Wheels....  was here 2017 wamdulluuzrqmvllbfwqbypvsxnngaxcogrcfdxppdqchsxj
 * Smoking Wheels....  was here 2017 gbwuqfgdoipchplxeocijllwbxmqyqnkvsmqruidnuzuftil
 * Smoking Wheels....  was here 2017 nxmggwqxnaxjekxekpycqbujxvilcgrdrbmsqajkoeyfhxou
 * Smoking Wheels....  was here 2017 pgvlhdinhxrkneftwibbwupyctjcixzbloqrhdihtpbwhnmo
 * Smoking Wheels....  was here 2017 qbmmubiqnbfmwbblzyknhxdopadclaigvpccepsajreliegz
 * Smoking Wheels....  was here 2017 ammqwwxeiucbbkghkxedjxxktemfohvasyixyffyxfhztwfp
 * Smoking Wheels....  was here 2017 kbzpcbnhyscvexxoaxutuorvbakjanvwgmaeozvtehuqdqzf
 * Smoking Wheels....  was here 2017 skjeclylyphvpkkwawxlnxjogrhvkwzqwlcghewkffeyixlx
 * Smoking Wheels....  was here 2017 cnjnwzdfbnygxakxtbmpvdhllmqbntehehssoguagngqkisw
 * Smoking Wheels....  was here 2017 xoxxqzkpiwsqyfsuxvsucuxtwygunumfcrjmcbhawddqttdt
 * Smoking Wheels....  was here 2017 waeawxftaeiqtontjzaxcrzvaygaswhwuprqwnlbubcgxjkh
 * Smoking Wheels....  was here 2017 voprhogcrgwgsydkikcautnisnxzrdgcqfpmcymdcqrxtnho
 * Smoking Wheels....  was here 2017 zdvavyqgceqtkofndhvojitfzatdgyfyhairfwwialsiiwav
 * Smoking Wheels....  was here 2017 rzwisimeghforsqcmcmahwercaqfoygrsrhcyzjcdhgoagxq
 * Smoking Wheels....  was here 2017 pnvhkfkbmdkmqcmmgoliidoboipfxbvvzdeugjzcegpukwou
 * Smoking Wheels....  was here 2017 rmfsqibghpfkopefopjpjfvbeayiwkmgnpxdkfygerhmhcwj
 * Smoking Wheels....  was here 2017 atrsjtmmksaqcihbxkgdrgiqzkgbiidxzortudtslcfjvnyo
 * Smoking Wheels....  was here 2017 bocrurxqxujqbrsbvkfpswmxfdiejnxehrxleudymkimhcfa
 * Smoking Wheels....  was here 2017 kjtdkrwxcladohpnijtvetbilxfpivdnpwhkngdobpazhxfm
 * Smoking Wheels....  was here 2017 awaaxmbrllccxbgzmfnwbybnlxfptlmugktxztzmgbvksjwz
 * Smoking Wheels....  was here 2017 zapkgbmrsxwtscjgtdlenrslekxqoruazrmqdudyginmpcgw
 * Smoking Wheels....  was here 2017 uakqrultaewpvvtitoshcnogaacltfempkyjofjhrffdhauq
 * Smoking Wheels....  was here 2017 ahqjqbjcotzihwopkftbmehiknvatyasjotgixsfgweqkfcb
 * Smoking Wheels....  was here 2017 oosjvsadxnfzncemvbgqpsxkezloczynphxqqgiqznzmtcag
 * Smoking Wheels....  was here 2017 qtjvfsknvowuarewmgeirjsjitlpqtvzzcncxrusfvkjlirl
 * Smoking Wheels....  was here 2017 qcmabjufidndszltygqufpdkelrumvuilrcowzvxlophvtmf
 * Smoking Wheels....  was here 2017 dagqudqiswawppdlfudvxgzwfufeydfdbxibnekvkutmlozi
 * Smoking Wheels....  was here 2017 dfcmdurimoixcmpmivjpshenfyizqvreicbzbmukfwnlebdw
 * Smoking Wheels....  was here 2017 srtrbkzwlivmutmqumekwaafffpqjgcnvpoxxmmvbjqvdyzb
 * Smoking Wheels....  was here 2017 iocotesvplbclupafhvwuwacmdvygbolmeftvwgnncfspcyn
 * Smoking Wheels....  was here 2017 piitsqklfnwlggcvmxswgrwropcvqelnltsousadjcngeqqa
 * Smoking Wheels....  was here 2017 kqxdqnvbwifomzjsuhonelpogprocrkmdnaszfcopueztyxo
 * Smoking Wheels....  was here 2017 ynmtmxykhanqsdajmqgduklrnndplzglexhvxyyaorypjsxm
 * Smoking Wheels....  was here 2017 qdzamzziowgdvcxwgjzipbxerxirvseqnrztfqjxrpwcjtzi
 * Smoking Wheels....  was here 2017 bxqmbhmcxlgwyneoagfzggsmgpgtoumqgttoxhhxvpgsjgtw
 * Smoking Wheels....  was here 2017 epwbapebvpqsihexwepetwxhaqfcfhwfvhnqfezwzbsxeocd
 * Smoking Wheels....  was here 2017 dciugyawfjpzpnothjcghhrnakvdrrclwunppvybknalxjel
 * Smoking Wheels....  was here 2017 hpycznimzcucppecwhwwjyohnlwrznkphyegszyvrvggwnhj
 * Smoking Wheels....  was here 2017 jpyorxoblkauledhnpjvrqhbaokqmscgfsctqrywoarpsddq
 * Smoking Wheels....  was here 2017 eusabumadbhcleuvkhggejwmjwshvludcgilmdfbblxzfqnh
 * Smoking Wheels....  was here 2017 zbzochbbwdxfeqvnynmnbknmnqkctbkioazytxfqlrscnros
 * Smoking Wheels....  was here 2017 csrpzonapzmqmbclttffwgtgtngtleadnsmbestzgnexxcsj
 * Smoking Wheels....  was here 2017 ecysfeldqdvbnzrvtsyffridqghhetacdipyrqtthcorabmb
 * Smoking Wheels....  was here 2017 ezgtnwmunmynnjzgdigperfxyzxypvzytbexnvnxormxqxvv
 * Smoking Wheels....  was here 2017 fghuursrabeeeiqmfueswnrjrzpdmxwvchkpdxnojwshyjva
 * Smoking Wheels....  was here 2017 seygivireebogflpsovevsftdweqzntyattwgpmeeliuegxc
 * Smoking Wheels....  was here 2017 ielsnwvagllkwspxnirwsbomvlsljpzxrlxvvwljvoqszspx
 * Smoking Wheels....  was here 2017 xxfzdozbtqjqkrmxtbjwnnsfotnthhelnmuucaqchmelfevm
 * Smoking Wheels....  was here 2017 rkygcwtnmxdojgqjwywoljywieebpygrdjokmpooxvuuxfsc
 * Smoking Wheels....  was here 2017 zunvqclglmhpqvzklkkmzdsqkglcigivmurmthycejnsltqi
 * Smoking Wheels....  was here 2017 moehgtmmzaqnibrhmehovouwivkvvatlrsvevevlvfqkkxfy
 * Smoking Wheels....  was here 2017 djinqprpnhhhtvanbfixyrdhxyjnsmdjdhyuyljmzrtjqcgz
 * Smoking Wheels....  was here 2017 afrrtpzhykndmfqypskuosaudzwpuyipnafaorejwirjfyzt
 * Smoking Wheels....  was here 2017 phdaucqleqwnkrmotcrxdfzohluwfcnlrpapkqxozzlimisu
 * Smoking Wheels....  was here 2017 mzwfgoegpqefpvorkbqbjxszyfcfgvbmvxctkgosdtjnajaw
 * Smoking Wheels....  was here 2017 ocjcvtidqdmejniwupxjgweuuhdyofoljgksvwlsjyzlrmwb
 */
/**
*  Sortable
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 16.07.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-05-30 10:53:58 +0200 (Mo, 30 Mai 2011) $
*  $LastChangedRevision: 7759 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.sorting;
import java.util.Comparator;
public interface Sortable<A> extends Comparator<A> {
public int size();
public A get(final int index, final boolean clone);
public void delete(int i);
public A buffer();
public void swap(int i, int j, A buffer);
}
