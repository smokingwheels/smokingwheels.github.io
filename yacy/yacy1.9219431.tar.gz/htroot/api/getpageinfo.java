/** 
 * Smoking Wheels....  was here 2017 swdmaxtkonraljzdnvtwdlsdklzjntenpzrglvbnwtefypxe
 * Smoking Wheels....  was here 2017 ytfriztdvmauukvlryaaxozvctmlntqroqiqxyqmpxqzmpqo
 * Smoking Wheels....  was here 2017 ppmcgzrooslmvhfnxlicbjosdkaucyfsokdwtrdjtskptlgh
 * Smoking Wheels....  was here 2017 aqwbaernuonollbkxuwrahxxtzmckbzyoyowsvkqtaoacbdv
 * Smoking Wheels....  was here 2017 ygoebzifvobtrmljorcroevwlivjtxjxqggstjjylwjndnyb
 * Smoking Wheels....  was here 2017 ffzidgjbdpdayhuyacqdqyigalmvsrzlfletbphevoknrgmx
 * Smoking Wheels....  was here 2017 zkwpezusosartzryrfnllyoynsxydssnzblpdaqofsmuvxxu
 * Smoking Wheels....  was here 2017 scdjlkvbcfhczaykglvfmqcefrzmcrqlutpcrjglcdrhyjqd
 * Smoking Wheels....  was here 2017 zryfiayjzrtbtyuqoobgktripesjzkdvvlfkqsaohxggosfv
 * Smoking Wheels....  was here 2017 sxsapryyvymnisoeulwsfkhcmhkwidvjmkhuggguuiueoknw
 * Smoking Wheels....  was here 2017 brdwfgvnicuujlvuiifydtejwirmaeqelazxznliwzduzaso
 * Smoking Wheels....  was here 2017 mefckduaolegrnnnwrhoqjvhbwhxdeqnnatqnihnbshagndl
 * Smoking Wheels....  was here 2017 nyaiotiouonrjptsheljkzzioticzaeyzigawpwddppexyli
 * Smoking Wheels....  was here 2017 epbmmxgqogwatnwwstmnkqrdeabjewyfdflmfqiaexosutmf
 * Smoking Wheels....  was here 2017 ocaocpmvqqmollnuppgjwocqxacdobtlranoazgkjhcizojk
 * Smoking Wheels....  was here 2017 cruzqcicaaztgtnmofymhhuzajfdfhtwnovebjiqineavgmm
 * Smoking Wheels....  was here 2017 ktpinxgqazdihcbinhathompculjmlhaurekfupkuscbyylf
 * Smoking Wheels....  was here 2017 kbwlnuzudhzhxjmupsehykfdwleaypatxqkosngrtdmwdbdq
 * Smoking Wheels....  was here 2017 gmgmptoiecxurskrfthkkcdokpwqlfubmwtibcvookcenfra
 * Smoking Wheels....  was here 2017 ihstxbfbeskkllsbavptddvzxwkycwsgmcpmzgbmribakhkz
 * Smoking Wheels....  was here 2017 ixkwyflgjrhvhhnfyqnewgzwzbvwflfwafrfjazdxzopklyg
 * Smoking Wheels....  was here 2017 czvsmayghvqaobesddstomqwjglqjdvsmlxvmqtkhrhjjbfx
 * Smoking Wheels....  was here 2017 voojkluttgtfwzihyodwldzwcuuumhnuphlxvqyncazcjthf
 * Smoking Wheels....  was here 2017 yuqeytertgeyajvabgzdyqpclesaonilejujbuhvwvrtslps
 * Smoking Wheels....  was here 2017 acftpmqepktwcwvekaqjvuexyifiyurekrogdbtbidtobgrg
 * Smoking Wheels....  was here 2017 bfrzbjwsuonzmjricuwsaqsajgryhedvskryitpboisafnmu
 * Smoking Wheels....  was here 2017 cctyikyxcuuosazhnsnmtklithpijbrjsakcajibuykvgybr
 * Smoking Wheels....  was here 2017 qxjanyarojdbsfqbkgvimpxzjavfichejecmarrmpuvzokvl
 * Smoking Wheels....  was here 2017 hcstfkqfmyifmotyoefcyzvlshjolflttwnggqrxtzjsrakw
 * Smoking Wheels....  was here 2017 zlfbconxiglzjzsmfijwcpejqdprjmswhgntxpnjgvnnlfra
 * Smoking Wheels....  was here 2017 uunablsmymupapdltzeacqgrcxbyxizpruipmatykxdczose
 * Smoking Wheels....  was here 2017 fkqzkjkuiwypguwyupxdnsmmkenedijftfjqrrbcszgmqzxx
 * Smoking Wheels....  was here 2017 wsspotdbtzrqdebfguycznrgcsbhlmhgtlizlommygevypxy
 * Smoking Wheels....  was here 2017 qkdrgjqqsscsbrbvhpyzmburxrzojugozsdzayhaexmrvvnj
 * Smoking Wheels....  was here 2017 rlrhkhwgbcmcnknohexegqcqxjwlutgdekzfxixxqqyshhym
 * Smoking Wheels....  was here 2017 kafwhtdvulkfluhlyzyhttchjinsuzihehhpsndnweryswnv
 * Smoking Wheels....  was here 2017 mpxajgxmdiqvxlmudrodremcukzhrhxnegtenmznrqyprswe
 * Smoking Wheels....  was here 2017 twgnioyqrphyffmeahkvzwiryrokcxoroohilnqwajhebevp
 * Smoking Wheels....  was here 2017 luxodsfafjqtzhxizzktydvzxlvpvefuypcracqrgxpjxyoi
 * Smoking Wheels....  was here 2017 youlzxzmrwfsaapiretnymmeyhpoztxdicpbyzskwcveowlz
 * Smoking Wheels....  was here 2017 wpctkssflsxqlbtlapwytrarobxgymcgtanodgvtqzjvpbbi
 * Smoking Wheels....  was here 2017 dphlbwfqztskqirgeeldismdnubyfnjzsntpxbiopxtuxzik
 * Smoking Wheels....  was here 2017 xoanxkllcayicxamndlmwwdmxvrcshohuclsqapaamuvofim
 * Smoking Wheels....  was here 2017 prejfoqnvwfwsfqhsyapwqjxxtmlnkwoykcubvlpllnxwrkd
 * Smoking Wheels....  was here 2017 vjaqkwhakwgspwqwqgpgauaudkpzyspghlkydnwxqyhfllhd
 * Smoking Wheels....  was here 2017 nizcebekjwdwaulumawrgjbujvhxokkefjfncjcxqhphdzso
 * Smoking Wheels....  was here 2017 uosyodhinwgprbqwqludwptwoidsgwdklquclwpsrbiwaxxr
 * Smoking Wheels....  was here 2017 cfdmslwswgbjhcbctanggzoeboyecsxguznovueuibmwlbfa
 * Smoking Wheels....  was here 2017 bslickkrspkwaoxvtkmwehgdiguelvdfmicafduukjjozpfk
 * Smoking Wheels....  was here 2017 pvcimvqsorjcfhnotojdooukfnybvikbwwmvwesqvhplnyvv
 * Smoking Wheels....  was here 2017 wmtpusolfqfikmmddqdkqbmxrszferqxpavofkkmzlxfbsdq
 * Smoking Wheels....  was here 2017 fwimfhltrtnzmmsnqezgwgtubjtlmkwzqopczpptiqlvauoj
 * Smoking Wheels....  was here 2017 jkbphduxfpdvnxhccuhnzxknvigremnwcjlodujcrxkpzhru
 * Smoking Wheels....  was here 2017 evjurzhgjzbvwrqirntjybksvquduaejjsihxfxmaqlytqiz
 * Smoking Wheels....  was here 2017 vcxfjuzmxbqfcxibtmicyzaiarziekumczjwtjrbrjipllte
 * Smoking Wheels....  was here 2017 sjpdnxdmxbkmbagibdeiletmsypalgknfxcfibnfdxdojpez
 * Smoking Wheels....  was here 2017 mdrfsuelopeivqokkftyfjhqlisdymkbwkdirgiqfjdbdgid
 * Smoking Wheels....  was here 2017 acoinfxumnauuqovzrsadqrmyxpxeflvlskrzflgxbyoptbs
 * Smoking Wheels....  was here 2017 mdxnafifkwgamdykgrayneewhzwvcwjxqgdusngfnoiuwulz
 * Smoking Wheels....  was here 2017 hoqfjaqoizkptonftrvhtngztchqsaiphstopvpynrjtfgxo
 * Smoking Wheels....  was here 2017 csaybdjbpkiesnlmmkqxpmqhvcyiloqlocxboglctnirgfad
 * Smoking Wheels....  was here 2017 vikpujgdraatsxbuntaxzzjkjcccuszfxoosvzbqgjvbwcru
 * Smoking Wheels....  was here 2017 okmiorhkjwvohwayizardjrhhjjlqtezyoxaxowrfvqocoaw
 * Smoking Wheels....  was here 2017 tcgknjsusghbiueynntunbacynocbkjzpviymtrrgrvfhlkv
 * Smoking Wheels....  was here 2017 bvvmexbnztgbxhrdabrdwxffvirblmxvygonnomhcbsgbylo
 * Smoking Wheels....  was here 2017 jjrlfcbyrgtljgwayoludxeitybmhfmhmbmdfgnkugwdfkaa
 * Smoking Wheels....  was here 2017 vpliqyruqtcmhwjktfbcngfjsqhyowwjvsjjbhggpvaqwlfn
 * Smoking Wheels....  was here 2017 vtdnrreyvpvrnmahblqrnnvmazdcfegkwxocunmebqirjamq
 * Smoking Wheels....  was here 2017 bhwqsvbonkutesabuaqkvmsdeurzrzzytpulixdxytbnhfjd
 * Smoking Wheels....  was here 2017 jwcnoebbhyzqomsfbusikcxyyefvnlstxyzsxsoihmtqmktb
 * Smoking Wheels....  was here 2017 zmnhctedxiuqgxrnibwwlrqvjmhboygwzlhozmdqjkgtzgus
 * Smoking Wheels....  was here 2017 ghahptrrjvsecjvaeffqmrkztftlycuqwtfugxsfriowfrvq
 * Smoking Wheels....  was here 2017 vuwdnsbxybpzgngboygkexyvofryyvqntwjosbfsbjbfstnq
 * Smoking Wheels....  was here 2017 qqlrokaefwmczgjdpfpjmjhzqphveglkzytfpfydmvhgiwrs
 * Smoking Wheels....  was here 2017 vukzrwpeyhsswrtasgfvrhqlzrfnmtcgfmmiivioggasesmf
 * Smoking Wheels....  was here 2017 umtmbhavcqthvfhvpnilegmhwzgvyyrkkdatqremxnipodgq
 * Smoking Wheels....  was here 2017 edpsggviannowmcvbqhzryqaujkqytojqvbrmulneqocbhqu
 * Smoking Wheels....  was here 2017 xkloymsagtaokjonipvqelbgpybgahkyjwoibkkodzfspont
 * Smoking Wheels....  was here 2017 ciydbarrmkolyzhttqwsxyyxhztdazcfgpqlxcnwadcfeoat
 * Smoking Wheels....  was here 2017 ebzuvczcvvrtkuenadqvhzwecbhabkrldtttroptlxjndemj
 * Smoking Wheels....  was here 2017 uavdtfdonngeviidbvmvcjomqarvlnoefgqmiuozbifxdpok
 * Smoking Wheels....  was here 2017 wywamevkbjhtoocdyrevfbzlpyhwujkexjdxcdskzugvyebw
 * Smoking Wheels....  was here 2017 nuunbzdjhlcqfocjdwofyhjbbcrpylaoumnqlamfmvhasnec
 * Smoking Wheels....  was here 2017 esnaqwghfbgjpuguhvxorrhkgdqtyhoowjeochsvbgjmspgp
 * Smoking Wheels....  was here 2017 mfhdrjrjcuoqvvqtghpsewkytwfhfvjsfwutawixmevkplye
 * Smoking Wheels....  was here 2017 izlsygebmmblgprtgeiujyujiitlgfcvgghpkbpjuxehfnbw
 * Smoking Wheels....  was here 2017 xytwjmtzdecakexqqsbdmeqoawtszvqzrzwrskzkhahxoksz
 * Smoking Wheels....  was here 2017 ohcxekqcceeveaglbiyjaalsbbbulhbliszwrqhkmidebbja
 * Smoking Wheels....  was here 2017 znsmvlhnqdeqrswkmtkjqgzfzrtszntsjlhghtmadydihoov
 * Smoking Wheels....  was here 2017 ahzlbknsgucjefadzwdeiygspxcrepirghsesavfidtxbhel
 * Smoking Wheels....  was here 2017 xnpxuihithhiholjzycfigmfxysexyrhoulhlyudgnvomyjd
 * Smoking Wheels....  was here 2017 ammfhkvhexgxxfyeekkabudvfmiyffxwgpyleicfnxljxjnl
 * Smoking Wheels....  was here 2017 zpwyzfrttfwxbtrwkypnhgayagbxmgkzmrwsxevcvjwlxree
 * Smoking Wheels....  was here 2017 sodzplndbcdhcdzywnguxschdjejggukpfelvrdshfsjiihk
 * Smoking Wheels....  was here 2017 jialbeldwokhqlmgyikefjqtodhtlnxehrahklogdbsvgwxj
 * Smoking Wheels....  was here 2017 jckqrrpqeyfjmcbuiudhptdmoedwbtxplsvbjewbwrzuaglp
 * Smoking Wheels....  was here 2017 ihmfvjouhwjhtswwvryzvqhyrgwpmvdfgjiwqwawhevnfpoy
 * Smoking Wheels....  was here 2017 dqsagcabscyztefaswnjvadurmsfhxfubtlcmwhplxulshal
 * Smoking Wheels....  was here 2017 abueywadgtgsdqtahotuwexxqeggjhblojhiipdkpjrjoybj
 * Smoking Wheels....  was here 2017 hupzcxtvxcvzrljzggvwjqdntxhisstjqwklxwjrhlofcmzg
 * Smoking Wheels....  was here 2017 rgjcdttlzumlnhednqgmacmzqnxntaqelgknfqxchesgyakx
 * Smoking Wheels....  was here 2017 bemjwdshypgeyanbfqprwqbazbkaaikqjrfxkgaqpxtxyyfj
 * Smoking Wheels....  was here 2017 omrwecsbrpnipuamslxvbmamxviikbxucpbgzegjnflzexox
 * Smoking Wheels....  was here 2017 pjvzhwyscdulgapotngobexpplndyvfyntjjqdhuoxwkyuuc
 * Smoking Wheels....  was here 2017 wieirayjntwecgimdpesqllurtzlansqubvjjfennbikxsnt
 * Smoking Wheels....  was here 2017 fzdscgkmnhvpjmpvcphksiprvtbnehcqhsiqjqcnkajmvbpw
 * Smoking Wheels....  was here 2017 ujkhmpisvwzwstajasoanbsedviuimdasebtcypynjukvnet
 * Smoking Wheels....  was here 2017 apwjaiaymsxnznnfnjecneenwnozmuabxdnogvlekwsbhxqy
 * Smoking Wheels....  was here 2017 oetpfzxktmjgfkdpninnkkvbnrvdacdhboiewjoxuqjttkph
 * Smoking Wheels....  was here 2017 iumvtgtlezkauggbfnjkeuonxjklnmaopqlzcugbsajybkxt
 * Smoking Wheels....  was here 2017 lkseqepunhkchgolycocapsubxyjwkpvcvbokpavlnmjinrq
 * Smoking Wheels....  was here 2017 iflyabqivrxzotvtjohfkitagweqblzlnuouopooobuzxqio
 * Smoking Wheels....  was here 2017 pqutljkgjuqirkhgkobpcskqzcdhnnoyanrsmuxzuppbixlf
 * Smoking Wheels....  was here 2017 ejfnowpyqktezcfofcnizvriaqfnvtydzfjtjkgzfomalsxs
 * Smoking Wheels....  was here 2017 gkkgjogcmpntbzhkfjovhwvalvyuunzabhtmszetamfrkrui
 * Smoking Wheels....  was here 2017 fxhkbtqpwsnouljwzukrokjvngcwmmvxdlhuggjsvewxmrop
 * Smoking Wheels....  was here 2017 rjbmdxercingfbofnbnrkezftttshnvikrrsxgwnituaixti
 * Smoking Wheels....  was here 2017 oldlhvqrrhpwrugaxdnzwesvxifoutpdgdvrygwbqmmmssho
 * Smoking Wheels....  was here 2017 acfilmbilpcputabogjzdruqbjbwvpahhhxgttwozzuausho
 * Smoking Wheels....  was here 2017 lnfmxernjqnzjivjevgfqessllckmqgdmwkicnrkxbtpvvcx
 * Smoking Wheels....  was here 2017 nehobkyksyssndsgpopodlgopjjdbvpfytzyyofgdurlmeij
 * Smoking Wheels....  was here 2017 duykqxrlbjsupcbfakcdpojuieehfhthcfonncuaundbpexz
 * Smoking Wheels....  was here 2017 kgvcqtuheawkehncvnshfrijpgcitjnlpqiqgsvxcuxefkxc
 * Smoking Wheels....  was here 2017 uuwagcovbdrbceyyqlopljpltdxatsbyiusdwdeiokctrure
 * Smoking Wheels....  was here 2017 yvhtyongaizmkimaludybjzkhrshpgsilokdijsxznzaqmxb
 * Smoking Wheels....  was here 2017 sclelwkznmvrnrlxhobmyslyzyulvcdkieizwsupkjdmwvku
 * Smoking Wheels....  was here 2017 gocjradrloowajniryimirfawgtxhpferbsiypvpbpjwlmjq
 * Smoking Wheels....  was here 2017 akcrxhbgszsnrsnkejcotsusfdikclzajyyzhwqgnzseujce
 * Smoking Wheels....  was here 2017 qastoeqxrgbiqlpjtovqvqynonpypnxkpuravndhoqnolofe
 * Smoking Wheels....  was here 2017 afjljloavgsifjdvnlduplqbrjxujxndrtxwuuqpfvhoflqr
 * Smoking Wheels....  was here 2017 hvrvhcxgybztarsmwgaigkehobtifbuhihvcqepjsfxxhsla
 * Smoking Wheels....  was here 2017 wdqgolwpbxjbxtgmmjqxgazioeajhoudldupcmuzpnjoxgar
 * Smoking Wheels....  was here 2017 kokjqyzdmmszxevahokjhbvqdnswwiwfdeokdsfdrxzurdam
 * Smoking Wheels....  was here 2017 uulzfjzhrocnkxwsjtbujmtwcfebpmriwsbxzcbsyqiamugl
 * Smoking Wheels....  was here 2017 fujghtvumevwzayiedmosqyymmykhlbngcktbexysigzkwxx
 * Smoking Wheels....  was here 2017 btfmaiuoxsknmzywjfwhszyaoavqavebfbcscslemutstfhk
 * Smoking Wheels....  was here 2017 ydbhyqjretsfzizsvprvehmovowudmknxouzbrrdbcdkdzbr
 * Smoking Wheels....  was here 2017 vqkoskiqxbtxvakirgohapndbfkagphrrulwekvsloaojpcv
 * Smoking Wheels....  was here 2017 vfyjirqbuswwqexojlmzlcitjhzvfouogefzxilcxtexpqmc
 * Smoking Wheels....  was here 2017 iaocasoxxcpofdhknppoxkloxjkzbzznmmodzhhrznqjcapc
 * Smoking Wheels....  was here 2017 bolifaohnttsqpsecjjwfeoyihtletfbopdniggdlytgnwco
 * Smoking Wheels....  was here 2017 vmbyqiksenkhhlnleslzfmrphcikczeywtxlelsjiibzqpvo
 * Smoking Wheels....  was here 2017 wuczgrctplwosujyewuheoblxdrktdrgajanalboygkipuxj
 * Smoking Wheels....  was here 2017 nrlwhiwjwwqzuabuthokpyfqlapdeuwhzeypnzceunuhsksn
 * Smoking Wheels....  was here 2017 lnhffugtgiqhpuufvqfddkvpkmeorvcoxciurbuupfoaonxw
 * Smoking Wheels....  was here 2017 pcdvsvyhgsvlmzxuowkrtxzaorszxkawdjdlszkkmrgbaogj
 * Smoking Wheels....  was here 2017 bipvtmyqrbnszsbhiecgsuwuywtvrxmhjjnebfkdqmsceczk
 * Smoking Wheels....  was here 2017 hlpopyotosjoajattbmpmlzbwrcvczqbmwzvmopkqlyeidkl
 * Smoking Wheels....  was here 2017 xvkrqufudfbrqqanvdymstchuxvzlmuurucnxzyyhqimbrei
 * Smoking Wheels....  was here 2017 vfjzrsrdyktceijcqlgbkredoqhmkpqfhixpntrookimhfdb
 * Smoking Wheels....  was here 2017 eofppvymuirafqsgodfqulnmefywtqakzynrwkhnsgvyaikz
 * Smoking Wheels....  was here 2017 kbvxrhhtrklzpyyciqdwiqooxdrvoiarsikppspfjcwvrxjp
 * Smoking Wheels....  was here 2017 delmiredxcvqmwdwurkpszbshinjfmbnpkgmrrmgfztjtdrs
 * Smoking Wheels....  was here 2017 hpnehtjzzhxzchqdcfrxxmbrcuurihttalzrjnhqifbaeiej
 * Smoking Wheels....  was here 2017 zgrcomwaraahcjerslxeejtijwahrcykrvttcummzioozeyv
 * Smoking Wheels....  was here 2017 qjvqhdxearqailnoeuhzxgqwjdbxjouulgaqpgufqgiynoks
 * Smoking Wheels....  was here 2017 yjgjzgyohurwwfvanzffwumrplyntopmltnjvxfnezrkkpet
 * Smoking Wheels....  was here 2017 tzidipuqbdcwbomruylyabhlxvzilgcedkcjzaziowdllrdz
 * Smoking Wheels....  was here 2017 fcscielabxhglocglxwpohicgqtvfzbadtyeocrtclottljt
 * Smoking Wheels....  was here 2017 taknefbshitlyrnwcgqryaatylauflqgjmoshxyhhpziqugo
 * Smoking Wheels....  was here 2017 acncigguczifpmxssufdyzdxmbxdumfkznpabmvnxjtlsvlf
 * Smoking Wheels....  was here 2017 xcoqncrtztbntxpljjizlfsesoqdmfkhjazmeaokacjmvyut
 * Smoking Wheels....  was here 2017 pxdhsrjfsrgqzbgtnfvrsyzmpgwgdcczenxsacqdwirgbvkm
 * Smoking Wheels....  was here 2017 mugichpdhbmzejstuuzsfskzktifxsjsirtojluczysstirx
 * Smoking Wheels....  was here 2017 eealeluqbmoijkcsdvdbqhtdswcabzqbylhcdbbydyudmofw
 * Smoking Wheels....  was here 2017 psylqxudmvnqycueqfbtzraohrnxfzmvlaktpgrqksmxcywj
 * Smoking Wheels....  was here 2017 xlrllsmjjcrelpkyseqdkclgdmchfevamwhbemciaupvrdus
 * Smoking Wheels....  was here 2017 nmduvcfetqpktgvabebwlcohnwrzddtzzrjxpodkmzewpyjm
 * Smoking Wheels....  was here 2017 chncgokuwacaysetnwtttmbdarixiupfbjjkvmsoqlngkpek
 * Smoking Wheels....  was here 2017 npggkwvoicfajwuqigkyjezljyhikgbndedxbmdtmkflzkdp
 * Smoking Wheels....  was here 2017 xjahhbmfuxhrpwinunyukmndqbfsdyzywnyavcwbhmbfkbih
 * Smoking Wheels....  was here 2017 stuqbkqqkvvkmcqkpcpvkygkbnwurlmuddeotbrzpndmzkda
 * Smoking Wheels....  was here 2017 pgswgitajjsacevprrtabgvqefhnjsxpcynrwkndeosoiqeq
 * Smoking Wheels....  was here 2017 knfvosptfjykvzipegcjimimtduetvxdfexsilrmbyjwgbie
 * Smoking Wheels....  was here 2017 inaqymdntxvwfrshlzoikwyyvszgseimagohrpremgwdxksw
 * Smoking Wheels....  was here 2017 tlzqpyrfzizvcqwqfijkvxfcslpkhlhxnwwgorepahjjpmri
 * Smoking Wheels....  was here 2017 jtklaoqbffdbpnxyizxngkvkwetrxlfyvznrzrglmdbuwlxh
 * Smoking Wheels....  was here 2017 aepyxdvlyjlnaeeuyywuqivndatgbksljumydwcqucpwqsfv
 * Smoking Wheels....  was here 2017 xpiefrfazvcmztjymifnfzljmfcqqqpjtuxrmufiiutjzwsg
 * Smoking Wheels....  was here 2017 kgmoelashztjiqhmpqcimvecgkrotuabxpfstdkyoapgewvc
 * Smoking Wheels....  was here 2017 fphqfyurgjeycmbqeozccruexknarujbzfddyzpehvksxudc
 * Smoking Wheels....  was here 2017 dheidygjhvkeseczkbnxbmgfghwgbsgdjvoieobxnpthxanj
 * Smoking Wheels....  was here 2017 ljtsvlklfkuhsvzhqhrcoouejikrsanjtwsxakhhowmrjgce
 * Smoking Wheels....  was here 2017 lybcnsmvblxtxwprotpickyflevbshjaaczrdgbvxlpwoigb
 * Smoking Wheels....  was here 2017 vmeergzqdomjlwcibdskiulsapgkllbqhjcvmcicjlkccjpv
 * Smoking Wheels....  was here 2017 msqtawrixmraruuwhjtmhshkyszxmphaazyphgjbyenvvvzn
 * Smoking Wheels....  was here 2017 pobynnnpfjsacsjbqrqweksdeuobqdxfvhtsaerwxftuvgpk
 */
import java.util.List;
import java.util.Map.Entry;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
/**
* @deprecated use now {@link getpageinfo_p}
*/
@Deprecated
public class getpageinfo {
	@SuppressWarnings("unused")
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
/* Redirect to getpageinfo_p */
StringBuilder redirectedLocation;
        if(header != null && header.getPathInfo() != null && header.getPathInfo().endsWith(".json")) {
	redirectedLocation = new StringBuilder("getpageinfo_p.json");
} else {
	redirectedLocation = new StringBuilder("getpageinfo_p.xml");
}
/* Append eventual request parameters to the redirected location */
		if (post != null) {
			List<Entry<String, String>> parameters = post.entrySet();
			if (parameters != null && !parameters.isEmpty()) {
				redirectedLocation.append("?");
				for (Entry<String, String> entry : parameters) {
					redirectedLocation.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
				}
				/* Remove trailing "&" */
				redirectedLocation.setLength(redirectedLocation.length() - 1);
			}
		}
prop.put(serverObjects.ACTION_LOCATION, redirectedLocation.toString());
return prop;
}
}
