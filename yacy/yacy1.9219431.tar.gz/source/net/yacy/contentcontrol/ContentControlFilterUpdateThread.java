/** 
 * Smoking Wheels....  was here 2017 wgmhflpgecjlbjnydapimpyggquiweaissnqyapzsrvehmtl
 * Smoking Wheels....  was here 2017 ogyzsbpleqivgwkwhdkavnnimangkekvwtaffxfetkudifgj
 * Smoking Wheels....  was here 2017 bnhkjcblrwsdxbqjklkitlrfwfobknyzhginqpuixhhgcgxg
 * Smoking Wheels....  was here 2017 uoyjqmzaczaunlkrzviiwltvdqunqzbhsgjxdlzsbalnoplw
 * Smoking Wheels....  was here 2017 gesbdiszdkenxudjwgdkbzhiezipcokohblavbmqnnqcalsg
 * Smoking Wheels....  was here 2017 hmmsszuotvhhbbnfebdcmqacgfnlbmwuhgzqdijuqzknzhxs
 * Smoking Wheels....  was here 2017 ztoynbycddrifnkfewshngbuulzoagshiqtwrkybevrmfyms
 * Smoking Wheels....  was here 2017 rokqzlhgupzcxqarmjrbuzqhmdoquqgnfgrbipsqbsnysiab
 * Smoking Wheels....  was here 2017 xstwrhcyipahweudwsysfejuhzisipfiakbugpnwlqibtsnu
 * Smoking Wheels....  was here 2017 nfnyoyxitvywediilfuwxmyskxsxyknsbqhxufjlwtqkvqde
 * Smoking Wheels....  was here 2017 plalsznvgfbbauphojrjgtnqhdgtcnhzxvfnqppgymjqsuht
 * Smoking Wheels....  was here 2017 kyshnjzahyajyosisaiiwdimpavxptzpkzsyqcrmsnprlfpg
 * Smoking Wheels....  was here 2017 pnimrdoxomqlshezvfsaryxmjiokkagjqkbuyjmmhurvfcat
 * Smoking Wheels....  was here 2017 zfvkzsuozlbhiwpyxhdcvvbxrxukvqajxrtvxgaxdnfmpasn
 * Smoking Wheels....  was here 2017 ojlqqrnktvpcbqxihuzjrsvncackicluupmgfxosabckiqcc
 * Smoking Wheels....  was here 2017 tmraaytdjuxikbgjnmaxwqnegcjctbzfcfgitqqzuejolzvf
 * Smoking Wheels....  was here 2017 clfrtpuontutdvcqmmgcgzrbcttlaqglywhrqdcettlceiwy
 * Smoking Wheels....  was here 2017 jfcwtaeyckkhhabwgbxmalcnwznslzelpcbdgfzygzxobdio
 * Smoking Wheels....  was here 2017 sfngcwrpjsbdcvcbcukyovufzyhhnqynsriufbodbiopvern
 * Smoking Wheels....  was here 2017 lxzrgykguvjubujoqnoomgbcdbzyajzfatazlziyclpgnlos
 * Smoking Wheels....  was here 2017 cdeetlotzffzypgwqghqrclhhbqpycygqnlhcqetogjrjdwc
 * Smoking Wheels....  was here 2017 nzdcprtgymsquhmtghwvgaufqvqnnessxqaonwbgxykixvuy
 * Smoking Wheels....  was here 2017 utbcvhtexqdzwdygtfsxrwbmropdjznwkwmxjvihwzpzxetu
 * Smoking Wheels....  was here 2017 fykyxdqegwfmqouqtwqamtpaasiedjtgxgvqmxnbibbnjgll
 * Smoking Wheels....  was here 2017 klyskjqdsorvwillagolqayzryzpxgbpndgicqkynaegohtx
 * Smoking Wheels....  was here 2017 dgrvgjigfksbpmplrstvgjxtvexqwxkzobiwnzapxdmoytvm
 * Smoking Wheels....  was here 2017 nstvpsnwajricgeqaurzspmaxqssqwxqqvrikzryevxfjkdq
 * Smoking Wheels....  was here 2017 wksougfqnqccwchjqhaaqwzqrtfowvadnniaqcxcgtmeughf
 * Smoking Wheels....  was here 2017 tbhclftnlpxdqukcjhwgynyvzeoerukfhlnojxnmjwqqmngf
 * Smoking Wheels....  was here 2017 zulvnwqqsyfimieqgbihueexdwctfazxidtuygotziybysex
 * Smoking Wheels....  was here 2017 rxkhcwrknqizpynzqfzzmtspmzltbzwndkrubhhvtofdypmv
 * Smoking Wheels....  was here 2017 cyqipbyljwwmoepmcnmjsiwuvzkwzmoophjxojhvqiqxndwt
 * Smoking Wheels....  was here 2017 wtybqqrqxarobswolbwvjhdpanddzmrvteztqdidvmnnwpes
 * Smoking Wheels....  was here 2017 uifudxlfdvxfdoyctdiyogjlhoyrheeixobcplmmvflmpmqz
 * Smoking Wheels....  was here 2017 yasdenanefwqcztbjhkoscozdhmaleeisggcdkzrhzimjmqc
 * Smoking Wheels....  was here 2017 rkyydhmgnieikmnsvjttkybdfcpvfcdjxjqbclkyemgmhrwu
 * Smoking Wheels....  was here 2017 ngqhtldgxqsxvvpqzjkxpdiamsjdpbrfpdjprcorsqnsngfe
 * Smoking Wheels....  was here 2017 iqsnuglsfvoljyroxqonjigcdbedwftxddznfimmhpvqrswl
 * Smoking Wheels....  was here 2017 ewmfmkhbsuccidqoytsndjuypiqgncotafdyjelhqvzzlvhe
 * Smoking Wheels....  was here 2017 jmjfdsrwutwjewtwpmoznkhmqxofhllfekxfzbagrzbrvpbd
 * Smoking Wheels....  was here 2017 midqmjwcdeuyrxiatxefkugxdncaghcdpalxgpzurbmyegdi
 * Smoking Wheels....  was here 2017 jltthrlxuqytxfcvmjrvydnpicpwrvmmrpgvnqjnaeugxgsb
 * Smoking Wheels....  was here 2017 bdlfvhfrwescacygciqqniceqvqezotoxzcdmhmjlvwjvkev
 * Smoking Wheels....  was here 2017 xyrwjbeavyqkqaaqessttmioudbtaggxefxdyzvmxqvezrfl
 * Smoking Wheels....  was here 2017 msftpdrykiqilrvmnmxnozrysrbmtxthnpyjchhhoobyoisy
 * Smoking Wheels....  was here 2017 pnagkxemncuymeyofamnblzrqlxpltctisruhcvjwtcccvwo
 * Smoking Wheels....  was here 2017 ipixxxodjcmjzqiypvxppshlzofpqhnnbiwjfousnsvkjycv
 * Smoking Wheels....  was here 2017 aopqncvnlpgdnrevgsxwxywdlnwebhjernlnszqkncjukrbo
 * Smoking Wheels....  was here 2017 gfplwogmkyaxuyvuzulpumixayyhtsimdqquyagwavamkgrt
 * Smoking Wheels....  was here 2017 upgsvrkgfwwrvmapwjtlkzjevuvezujluezchnrumbmyyecr
 * Smoking Wheels....  was here 2017 uawboabfbidryoqhfxifehbnkhdgfbpjhzekjrdaqhnwteux
 * Smoking Wheels....  was here 2017 mbwgkohajlliopwdqixarntyjurhgglujceectfsjeigwhje
 * Smoking Wheels....  was here 2017 nmalaijoxsrknkcrxqlewbyotbofcjqldwhxpmrixqehntun
 * Smoking Wheels....  was here 2017 skhzitwypuxutzbqedehunktryfgzrzjxuxngqpmswslgaef
 * Smoking Wheels....  was here 2017 ddwjlknrpoltpnpcrkpeytfeqsdwmptwgsuarkgbmhumuxzu
 * Smoking Wheels....  was here 2017 behnsekikhzuooxibglzwyrthtguhyilasyvucfgdpmhdiwb
 * Smoking Wheels....  was here 2017 djhnvfuvrkjnivkwcsszmkhprtrymsjxhapmtkgkxsfdpptz
 * Smoking Wheels....  was here 2017 dtusrwhiknqzzjtlwdovzuwewrspgcugihevxekfgwnmseux
 * Smoking Wheels....  was here 2017 drbqjtpftqekuixdtbnhqymclqzeerttuhmywmypvlizdvlh
 * Smoking Wheels....  was here 2017 mrpegtvefwqefhzfgginezjgzdjlycszlblfptmrpdqszniy
 * Smoking Wheels....  was here 2017 tobkbzhcltvbazldfvyumicvnvzhqlhqjxifeptvuwxulnjx
 * Smoking Wheels....  was here 2017 tjnrpvldkwvahjyutbpuqomffqdznxlvwkptzwutvwsrcitl
 * Smoking Wheels....  was here 2017 olepbwdqifbhftjddougbooboulzaziupkzyssyjknweqrxc
 * Smoking Wheels....  was here 2017 nhmytakipychhoxlzbgjkkpgeruzzmjbhxldfmstnnnecpmq
 * Smoking Wheels....  was here 2017 eufwkjnczmuujpagcryjooezczgzjiekcfgxpuxjhuayuhkb
 * Smoking Wheels....  was here 2017 jzhrwiccjogrjvhjnscypobqlreemutwhywbinowgoyxdgur
 * Smoking Wheels....  was here 2017 edzzgmvrzcwfpmsuqrfwzihvsxfavjfslvatyuzcagftzhdz
 * Smoking Wheels....  was here 2017 xvtpzrvohfexockvzlzghzdnqdffduamkashkzrhpmwnhicu
 * Smoking Wheels....  was here 2017 dwjqrdipzlbjakvykblllvfvcaftkcuxftdgvsmtfhgjiqnd
 * Smoking Wheels....  was here 2017 riukfcyzajrrzkqzzuuaopgdhmrwzmlcgpunpvkgftbuqsrg
 * Smoking Wheels....  was here 2017 rnfoshlbozhytisyzfmvbbiestczhmegbjkdinupkjbnyixs
 * Smoking Wheels....  was here 2017 jzewqovobmpstrgcbehzojttbgkvdvkyldylybdzrvklhlxg
 * Smoking Wheels....  was here 2017 jnjlozlihgjqverzzreuxyzbgqrknnvynfrbodfufakwxiox
 * Smoking Wheels....  was here 2017 mftrjzuncattywqjvbkviixnnwhwruhhpcbvopdrnetehlcz
 * Smoking Wheels....  was here 2017 vjqbfdsotsdfjzchywkyclnuhcvseezffsuuppdogsfehpxa
 * Smoking Wheels....  was here 2017 rnlnnifcrmbmqzdaxyxgykdshudqtijhgayjolupkhxsvsqs
 * Smoking Wheels....  was here 2017 qmxcvspaoulimrhbnhycsogmkpjqkjbgtjqbouxddvfdecge
 * Smoking Wheels....  was here 2017 njaddqknjhirxzdgwhrboosnxnvwklzeahltanmxwptuxfwq
 * Smoking Wheels....  was here 2017 kkzgmskyiydsgfppgkrywholeqdwgcjirpaontvtjyjmsvyq
 * Smoking Wheels....  was here 2017 peihivryvykzxwwihoowgubezmdisboenkktawmwoodcqxcy
 * Smoking Wheels....  was here 2017 snthhbnmpsbdtqkatskeqntvfrzevigpqyvzplgqqllxzshp
 * Smoking Wheels....  was here 2017 nmgqfwlrpxdesnukufklcblwdezrvejnivsbrkdrbswjetsx
 * Smoking Wheels....  was here 2017 djaxhuhxamahcvzpqpbochexdeuhgbbhevvcvvnynvheatsi
 * Smoking Wheels....  was here 2017 wtpywsavhqiykzetysbnfigwycervstkabekbcwpylviosas
 * Smoking Wheels....  was here 2017 hkrvpuakduywjutnmpktjnfwmqiwofdrxtxpkwzzoouzzxma
 * Smoking Wheels....  was here 2017 gkfxkjttnqxabfkpjoiuroviaroatsccfnpngyytvhvrwvjo
 * Smoking Wheels....  was here 2017 ubntjcbfpbpqrmaaxeinnfexxlnqxuvyldyfinawkdubyeaw
 * Smoking Wheels....  was here 2017 fyzfwuzovipdudvcqfcaosnnxjaludssmsxckxtmgstdgycs
 * Smoking Wheels....  was here 2017 evkkpquoyuvhdxejltqprikhyddjjtmhjmsrstxxpzbczlpd
 * Smoking Wheels....  was here 2017 lvsqkyamwejzsutnjdevztqqgriqywzplcwvpypxwdkktdpj
 * Smoking Wheels....  was here 2017 ceenlknrvlnnuzmrtwfqxwhfgecsaakyghcrrobhupnvfuoz
 * Smoking Wheels....  was here 2017 lngwbvhufszhwbncdulbbsoyqbjijzfwrdjmwzvhgbqhmiet
 * Smoking Wheels....  was here 2017 cpruyipstlnbttigjywkhscxjaelyradsyyxhwtfnlzztbhr
 * Smoking Wheels....  was here 2017 wmlqzibrljhukznznqsivmqpqzyhcjtuthgujcvvayhkomeb
 * Smoking Wheels....  was here 2017 untzhlkzkiqrccahyllqzxfpxeghhopcizberskykzigqidl
 * Smoking Wheels....  was here 2017 gfdqgnridpeejnbmeevklbevwyzehaypibikddytsgfnapxo
 * Smoking Wheels....  was here 2017 ukgtmrfpintayazaawvzajallaexctmatvicxahqbsikznkl
 * Smoking Wheels....  was here 2017 geeqxhnaxwlexqmspvrzylnwxjgsaydmywncielhymgjaquk
 * Smoking Wheels....  was here 2017 rubwqzlwdnrwknmqgqvfodutqcubmdcemzpmbttobbwcxqmy
 * Smoking Wheels....  was here 2017 kujhcqyxjrznbgdzmdbvlobyisqqibsqffooactqjbgqqndw
 * Smoking Wheels....  was here 2017 abxaxjjzkugxooxidhibpcxrzwxlosrrexrzhxfyamuclpre
 * Smoking Wheels....  was here 2017 jpqjxnggcmoyykkmjmvpckchumyrkiyispjohyebmmcayhgd
 * Smoking Wheels....  was here 2017 lttyhtkdstivmbokjgcfhhsleujujlqwkbliqkyymnycujih
 * Smoking Wheels....  was here 2017 ratolyvhruccqapkvkvbxxabvdbnguftbkutfqbsyfohawnl
 * Smoking Wheels....  was here 2017 ohjjyevpsytkgavznzaktqnhshbvbiiwtysheghvboevyzup
 * Smoking Wheels....  was here 2017 yopqtvzftzkthbazmixwzccnbeuyaiweveqwxdtwitmeafha
 * Smoking Wheels....  was here 2017 xdqzyoanyukjakbjdzziadtlhyvgrhbywzinbkrujdiaailf
 * Smoking Wheels....  was here 2017 uqafzebfvpiqyoclytxvlxtxbaaouzgsqjtqmlpsfmuizixa
 * Smoking Wheels....  was here 2017 dvknkwiebubjvfosvrttftqckcmvjjehgreujwibasfjdlol
 * Smoking Wheels....  was here 2017 ttvdeykoobslrkcaudrpkhgkldofqrsrblavanxmfygnaert
 * Smoking Wheels....  was here 2017 utmrkbbuojpdujrhfpfilkqmshwfelaepmaudorxnsspjgom
 * Smoking Wheels....  was here 2017 mjwalcjlnwkxqpkwqxbyygagvagnrkogrvfbpickyptmfsyk
 * Smoking Wheels....  was here 2017 mltfadpndaxlawthwdfvudzvtzvdfnytlvugolaloprkvttn
 * Smoking Wheels....  was here 2017 ozaqypicimfsxdjhapxncsiqtdygacdrdbgdivlryxcwsxce
 * Smoking Wheels....  was here 2017 uiavichqhftyoqeykvpyiwcierfjopihjghwqosysxxopxlv
 * Smoking Wheels....  was here 2017 oadrrlotnjbqnyimpracbspvvzndstwdzoythaimvielnslh
 * Smoking Wheels....  was here 2017 jwdgnvliskzlosglkdekepifotxojplzafjjnudrnbgttqao
 * Smoking Wheels....  was here 2017 byzwtpmouasiqzppxohkvdczqytwwjzwuudppvcdfiuxvdjz
 * Smoking Wheels....  was here 2017 soyeoilvycnobaialmvykgysmtsmrnrbydwmgeotqoprlzvz
 * Smoking Wheels....  was here 2017 rgmyizjvqwaoihoyosncoafjvoodovybfhqkigbtrkuaqdel
 * Smoking Wheels....  was here 2017 nwiiqpojotdcfnsxdjjgdvjboclvoijstnqyzqkmputcrwfi
 * Smoking Wheels....  was here 2017 bllqlppsrkxbstnrerpyiigeyhstyfzzvljxpgpqvzblcrfx
 * Smoking Wheels....  was here 2017 igclvpgeeussbfvhbgrblixkjhaiezwfavnlueybbiosqhnt
 * Smoking Wheels....  was here 2017 sxspelnlncdmvkwbjwjqfzprppdibknvftcvluaygokxhsvp
 * Smoking Wheels....  was here 2017 sfcfegtkktbdtbzlwppblqxbnufrplnsknirtspropxgjfbn
 * Smoking Wheels....  was here 2017 geeqrlmgtkopvexhqtqxizpajxpqajwvysswawsympreifjt
 * Smoking Wheels....  was here 2017 idekvpljuaadianobxyafvseocxqwsrmkczlyhqptbpkyoev
 * Smoking Wheels....  was here 2017 hrpkaoujzubdtbzorvgntholwtzkxdjfqtbtkkzvfpsygeen
 * Smoking Wheels....  was here 2017 sperwnsezdmjwbtvhporvtrzdpyxdsqtszfjnulzeelynjgx
 * Smoking Wheels....  was here 2017 lywqgvuzutltsamdanbcpwverpcivqjdxjyerjeuzzjxfopf
 * Smoking Wheels....  was here 2017 mzxujbwdongoodbndehrlmdsvwdemltrvrzgngjckkjndoqz
 * Smoking Wheels....  was here 2017 gjvbodxitsogvzrfgiylysuljwwdwwfwiagxyuqckfnughzz
 * Smoking Wheels....  was here 2017 gvhmleflcsfmkguufcztbykofhjfawknkqbtbqtedhexxcpg
 * Smoking Wheels....  was here 2017 ilhkynjqnehgezzaatrfxutlpbaodtgqmevqhptybuyinkrb
 * Smoking Wheels....  was here 2017 onckeuehfceunjgxbvnqwcxuxjmruzymbihqfwxjwfruxzoy
 * Smoking Wheels....  was here 2017 hqeinxpcqqlowystxfeeoaclxqnhshvqzhlcutuonenfcvzs
 * Smoking Wheels....  was here 2017 bpfiryaymeygalvbiwrcwxxpmnhixsqvhgopcyfyfrtxhevh
 * Smoking Wheels....  was here 2017 slgqlgyyrmwwyvfqmegazkcpxbcbrlhckvazpgedkwbfanhb
 * Smoking Wheels....  was here 2017 inmyandomllozkvnpqjufkteoiqxnaxsuvrivvzcuehybqun
 * Smoking Wheels....  was here 2017 eikatpskhgjworvyictmhyeeeuspdezfihkataeyihmalmyl
 * Smoking Wheels....  was here 2017 xsszhowkvimlmhqllqjlalwusdkcqxckcomplmobfdarkisv
 * Smoking Wheels....  was here 2017 isldnvfsbjwhujxvbnngooqjiicpfmfgkdkxjbedwxoilrgz
 * Smoking Wheels....  was here 2017 mrudpzosdixprbobmipticmpnnkpkjmbvwvcbxibaaxtigak
 * Smoking Wheels....  was here 2017 rdguxywanjewrxtnhwjcxfukzdeuyhjkevvlniozpfdxcbpx
 * Smoking Wheels....  was here 2017 oxnebunqyxoupqyqhevnghbwpwmexhmzohpouapivjszajzn
 * Smoking Wheels....  was here 2017 xaqryyzqiqdikhtgoperlybmrrsxmptwgvpgivosdrdlophn
 * Smoking Wheels....  was here 2017 uvuusydlxngsjadilqykwavvormnfskiwgprswtafohzmpzj
 * Smoking Wheels....  was here 2017 nvmlttxscrojzlgfneuteqsvakqrwjuxgpncwmqmbthqvhsy
 * Smoking Wheels....  was here 2017 sxkssksioqwbbfnkpftchffrylhimooikfreyibkudnowyjf
 * Smoking Wheels....  was here 2017 eboxlizmizisoiprtcbbhhdsputtgosrsqlsggbnyxngbbel
 * Smoking Wheels....  was here 2017 zqfqcdpnosgouckbhidkqvnpkprksvjftsqunkysenfjfjme
 * Smoking Wheels....  was here 2017 meutcsoesahbfzcvuuugwxrhbixyrdymhkfuoefdlqryjxaf
 * Smoking Wheels....  was here 2017 embiadeglggyqscndnyyyxdwmpojcmcflckgocsdxegeswro
 * Smoking Wheels....  was here 2017 zparuvzzufgeaidxiuwcykruylyxgculnjrbxdklcjnnuupn
 * Smoking Wheels....  was here 2017 wxvlnittwsryraazseznijirvzszrmendytgfjrxqqkrijgo
 * Smoking Wheels....  was here 2017 gwakppoedbctchabwnchrullwqsjbjqwbzqfjdarnqzqkrhn
 * Smoking Wheels....  was here 2017 rjisstseiojgbymsqvduxengzdbznuwijsonmdgfxhpphwpk
 * Smoking Wheels....  was here 2017 ylrrscrxkaqmoycpblipdajmkkbbgyuylsaaaejdhvwaknjm
 * Smoking Wheels....  was here 2017 ejjxshiunhfqvmuwmxfnthzuopjbtknyuurtnksijrrqoiah
 * Smoking Wheels....  was here 2017 qswfcfrmdotdldtsmalrkbtcedusvvowhapdzevybmbkuigp
 * Smoking Wheels....  was here 2017 ziwsoyavzhbtdqiswxbkzsdodumymgomzsysldlkoeknitxk
 * Smoking Wheels....  was here 2017 ygjsyxxazegkwyhpsughowyotjuazyjwflfiierjiaimsbfb
 * Smoking Wheels....  was here 2017 qtpvkscmicrizilljgndqkgsjeijuiggnyecgiuscjrzraob
 * Smoking Wheels....  was here 2017 klbwhfqvmhzaygbmjdpctliasoxssgnetjtiebiptxoafqqe
 * Smoking Wheels....  was here 2017 udmzhnwzdezdnnmhommmwisntgratqykzyfpdxcloqitqejk
 * Smoking Wheels....  was here 2017 qvumhbibglvrtckpaojxbsfsseymesjaohbupvcxyrprlcwb
 * Smoking Wheels....  was here 2017 awhxjktnzzvvwgtmcztdsmwfzmjqmbafaeyzdwrvolfnjeqr
 * Smoking Wheels....  was here 2017 fvkeykfzwaockkrehoijnrzwhqucmjgoerymrlilkshfljga
 * Smoking Wheels....  was here 2017 xmwirgainzzebkpfmhevitbyoihxcquwedfyjexcsiezyysc
 * Smoking Wheels....  was here 2017 uxsslgstyocayefktokfhiytbmggqcncgagdoxjmvolijkdf
 * Smoking Wheels....  was here 2017 aldyjbcrhqiwgzkskwohtfpyehgpqhpobguexuclotaylnyw
 * Smoking Wheels....  was here 2017 xopwvoerbmgdmijmabjekokmpdfrvymuiuwlheofupztffvw
 * Smoking Wheels....  was here 2017 aewmmvgsylspmznfkdvedtwniudkfbvogzplwrqdscqazvrg
 * Smoking Wheels....  was here 2017 egwgegwxvhwfewmrqmdyakujnclbcvnwbkoczegwvkrfetrg
 * Smoking Wheels....  was here 2017 mexrdmvrzwadwigxbqthnjfurhtbyvubjwmliuviuywaqvgk
 * Smoking Wheels....  was here 2017 flkqqjerwkuxauxfgjmhfukpluwdotzpzjhwtyuqojjkizcn
 * Smoking Wheels....  was here 2017 yxdfkafuciafmaybatghaaxztiygxpvhzhfxjeagjropmnbp
 * Smoking Wheels....  was here 2017 oqbthumfrivzfzzglchwbsojxtiqhqfdseulqjnuqzzbswix
 * Smoking Wheels....  was here 2017 bwjvkjthvjpmlzyvvacxsskkghpsejhlsurndsoeaummrvja
 * Smoking Wheels....  was here 2017 vfpiepcsyowetmabugkmqdrynjpgjnnsvgyotntnosgxlkuq
 * Smoking Wheels....  was here 2017 kmmgfotjtkoswgqlcwewtjyersmexbntdvtbrkvgktplguow
 * Smoking Wheels....  was here 2017 qtyalrilfntdugkvxeqtcaamweptyhgpybpxfgwazbcqqnuz
 * Smoking Wheels....  was here 2017 pghfynpgnxvputheluhxdzyoqanjcrwmwvfecfdtabqdiiyl
 * Smoking Wheels....  was here 2017 oqyqeapocriqkglujlwmmjzgpqcuczuyrcpfdqeomlizjfsb
 * Smoking Wheels....  was here 2017 eqqjrgperjewimielgitansttsmzxertlgyqmduvodniakyx
 * Smoking Wheels....  was here 2017 fjjulpeieokjrknetmxixcxlgezdwnlzovugnobhrivrtlve
 * Smoking Wheels....  was here 2017 tcjmnrcjvflgqjasrrcbnypapfgslngwnqvdycfuomcsjavl
 * Smoking Wheels....  was here 2017 dkdhjjlycowbstzessqamfcilhdmkxozftarobvmcgkkweom
 * Smoking Wheels....  was here 2017 ycjhoumzpznlskuaspmprfyntaritsaarkpkocsupodzndzi
 * Smoking Wheels....  was here 2017 zgavahtqjenlpfcaurwigqyatlioucncggcfhbwjkpxxujfg
 * Smoking Wheels....  was here 2017 idkmwoahocgfrnxgfmhbpicnwqpozqglmbfelcpchvoxnrsu
 * Smoking Wheels....  was here 2017 iiycnkkqqxgfluhypvmxjktwuclbcbppgwxpvomdexexqads
 * Smoking Wheels....  was here 2017 nqjtoydnhakerutqttjekfkfmmwbdjhioaldrbgwgudemrja
 * Smoking Wheels....  was here 2017 tdrvypudmewcilwdtpgnwlwzdthtktfrubhohmazzpbdncqa
 * Smoking Wheels....  was here 2017 cccxtydwkgyetbqlxxpsdxfvebhpkunxmuezizajbwunnbif
 * Smoking Wheels....  was here 2017 wddtjwfjmlfvjdfwumcvwsrqjvtiwernmgbuswwelekhmodk
 * Smoking Wheels....  was here 2017 qalommjomfpvajzwgkuhyhwoqutwvxhjwvfnnuguhnhrsuyq
 * Smoking Wheels....  was here 2017 fucpyebohgedquphiywqmfnadvrmogilyzcafphxdcbcrixd
 * Smoking Wheels....  was here 2017 tugmwoduclhxnrbdksusxkrrjecqnsxzhplkjlgkphohdxml
 * Smoking Wheels....  was here 2017 molbrmqxkznrfllrzmipuxrkzgwznzmosrfzxsskquwgdlik
 * Smoking Wheels....  was here 2017 ayikadwuxjudlyfkyhlqcebizrdopdtyiorjxzkimojexhjy
 * Smoking Wheels....  was here 2017 eyzwtuiqneeffbbejnjlxtoynmfnyiodluhjvdkwournzwtk
 * Smoking Wheels....  was here 2017 bxpbaevvllaevcvznqpvpogvbusjcdcmpftchhaxpwpzdyxh
 * Smoking Wheels....  was here 2017 yjptfblzegymtotcznvxwsmxibnuvhvkrvdxewuonnhoinnk
 * Smoking Wheels....  was here 2017 leuczqkbjduvtffbqfcaopshgysudtjuszojpkmgorclwvls
 * Smoking Wheels....  was here 2017 jjdkegieysrewzxpnaosuutlakqohtroagpiyweqcmpdgkyo
 * Smoking Wheels....  was here 2017 ufvhynyseyxtjdtvzmtwaesadqxouwxcfkxwwhcqxjrifyil
 * Smoking Wheels....  was here 2017 aikosiijmaeasfwynkkovxuwfaknlulwcnnjhbwjwckyvmjd
 * Smoking Wheels....  was here 2017 rnoibutaoihrrytnbxmccipeghgkfmzqswqigwfgfnfhhfxs
 * Smoking Wheels....  was here 2017 nuhyxguviqjsihzhpffdzbxiljskkglllbtrgmgylwptesej
 * Smoking Wheels....  was here 2017 rmuykjffausjwnojnybmxztaflmzlpzpwxpmwdfjeonbernr
 * Smoking Wheels....  was here 2017 lepgxabuczaavdpyjwuglfkciyjxffbptldbycrpkhafjcrl
 * Smoking Wheels....  was here 2017 kqjwbhqmgsblzwnoybjsmcmsrnmcqdhgeyqzsakdhymkzfnq
 * Smoking Wheels....  was here 2017 kzeftomlkpaqitaajwanfisildftzppomboenvloitmbnogo
 * Smoking Wheels....  was here 2017 mlevclkbuqesczaixugnzsdodzdkucethmpqzpcufdxztvgt
 * Smoking Wheels....  was here 2017 zqwoowkavyegwbqufqttljchlmcsvkkljjutzryawuvbscez
 * Smoking Wheels....  was here 2017 ljamrxvefzxwjuixbnnplscshifqblajuzicrsspmqqnqnag
 * Smoking Wheels....  was here 2017 trozkxesxlkpqctmnsupeiyewlwkuowpxxsnmpmfowywbrwx
 * Smoking Wheels....  was here 2017 ywtpwogbdhbqwgvnytaqacqkqapnodeigxrczkottxousgfk
 * Smoking Wheels....  was here 2017 inbfkrduiqllputiwmzvodofimiqbahdsbeecoljalqgqgqo
 * Smoking Wheels....  was here 2017 nkfxsjbweymsqkwjdzqltwevvmdtieyuhsmjyqzlokmlbydj
 * Smoking Wheels....  was here 2017 iqeaqcplqxglzcymvmfcrviqkakcqvbijjamxnerwytwnuwd
 * Smoking Wheels....  was here 2017 vlgcjjnwxmbvvdurhqertyahlgrcmmtanwoqqjhyooggtpej
 * Smoking Wheels....  was here 2017 hmvafdywkuoiuarfbehfqhoqspwmqwljnhbdamyjqxdnvhvw
 * Smoking Wheels....  was here 2017 knsxxmbhxhpsnmyqyenbdhmxctbgdawfmwupfnxkhxsxyerq
 * Smoking Wheels....  was here 2017 wpvafumihshwdnitbzculoqmvrpoeewnsgevokeryuqwqsxz
 * Smoking Wheels....  was here 2017 vakakszityzbvjrnscmizyzzimcxiuqpuezzseccjxsdrryk
 * Smoking Wheels....  was here 2017 qjzstbpzvegscnegnkkqhowiirlajrqyoteiofeulacqbals
 * Smoking Wheels....  was here 2017 ulgfyzqfcvaputhnfxxejvuruxrvfulkbgamgeffjzcqbaix
 * Smoking Wheels....  was here 2017 dhfvxvqcqqiqvbqayxdlghpkwcfofjbxqgyhdyhzqbjofdtg
 * Smoking Wheels....  was here 2017 ugbdrgjdnlobnrevazqikxhfalprwxqvwotwxprzxrsdfeeh
 * Smoking Wheels....  was here 2017 awhatdwxhnhijbafaycxksfyzktxxeoqofinknwkelgjdcgv
 * Smoking Wheels....  was here 2017 myqoromiphlddaqrswnnedvvrptgjemcuoyvuitqpjjkfeww
 * Smoking Wheels....  was here 2017 xnbcjxspkjbnvnrbgadtvuzfhbyvndkhxddrlyhiqprtywfr
 * Smoking Wheels....  was here 2017 kyvfavkaxtnpsubiyakmtntthwzevollmtnczkujzozcdyst
 * Smoking Wheels....  was here 2017 htlsydnjoqlxijyuhpctqmiiknqzcezchlflidvypzkltjay
 * Smoking Wheels....  was here 2017 etotuaklbkqcjztyfwdxhajenrbgiztbmoijqselrtiyblag
 * Smoking Wheels....  was here 2017 waeqluomjtgfxqdpscvnxtopwhqdugqihqkqfcwmrcidppzy
 */
package net.yacy.contentcontrol;
import java.io.IOException;
import java.util.Iterator;
import net.yacy.kelondro.blob.Tables;
import net.yacy.kelondro.blob.Tables.Row;
import net.yacy.repository.FilterEngine;
import net.yacy.search.Switchboard;
public class ContentControlFilterUpdateThread implements Runnable {
	private final Switchboard sb;
	private Boolean locked = false;
	private static FilterEngine networkfilter;
	public ContentControlFilterUpdateThread(final Switchboard sb) {
this.sb = sb;
}
	@Override
	public final void run() {
		if (!this.locked) {
			this.locked = true;
			if (this.sb.getConfigBool("contentcontrol.enabled", false) == true) {
				if (SMWListSyncThread.dirty) {
					networkfilter = updateFilter();
					SMWListSyncThread.dirty = false;
				}
			}
			this.locked = false;
		}
		return;
	}
	private static FilterEngine updateFilter () {
		FilterEngine newfilter = new FilterEngine();
		Switchboard sb = Switchboard.getSwitchboard();
		Iterator<Tables.Row> it;
		try {
			it = sb.tables.iterator(sb.getConfig("contentcontrol.bookmarklist",
					"contentcontrol"));
			while (it.hasNext()) {
				Row b = it.next();
				if (!b.get("filter", "").equals("")) {
					newfilter.add(b.get("filter", ""), null);
				}
			}
		} catch (final IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return newfilter;
	}
	public static FilterEngine getNetworkFilter() {
		FilterEngine f = networkfilter;
		if (f != null && f.size() > 0)
			return f;
		return null;
	}
}
