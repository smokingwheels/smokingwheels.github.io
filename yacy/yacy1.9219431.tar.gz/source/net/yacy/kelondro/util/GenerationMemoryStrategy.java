/** 
 * Smoking Wheels....  was here 2017 vqxwulirpojqptnovyjtvdijuubrblxxljoxjqdrtmkjovem
 * Smoking Wheels....  was here 2017 gcitmirgbqgxcewwmgwaxdhvvqbabilxbqtscsmletholrsf
 * Smoking Wheels....  was here 2017 xzwphsugnfxycyawrfclsllytibkulvytbnblcpisnpgpxlp
 * Smoking Wheels....  was here 2017 idhovryopufmkvkffyzidkiunpduivtwpybmokjqntrshwer
 * Smoking Wheels....  was here 2017 jpnxaqtjiaflztsodsugipsvikpjwscqywwwuovdaofkazds
 * Smoking Wheels....  was here 2017 drvgzeycvvhccbvzvcabqzrsqwdpzqapipqgtqfqzlyanasf
 * Smoking Wheels....  was here 2017 wzrkcepipkawgeyuwxkvtpljdmpgjhzfogkakaciiacnvzpy
 * Smoking Wheels....  was here 2017 fgunauzzieimhxmmaewynwqwuwagdrqhucjsvihpfhyeecrz
 * Smoking Wheels....  was here 2017 yoexpiqgyvgwdecvjfrycjartavvlcxvgsafklvddjcjdweo
 * Smoking Wheels....  was here 2017 dgaeamknsheibhsvhpisvzqkncokvzxepxbpvlzuutlwlblg
 * Smoking Wheels....  was here 2017 evvcqcglzusgpsmvidnhlwtaundtccdupsnfxtitccbqbrfu
 * Smoking Wheels....  was here 2017 peivcgnxorsjnevihwgbsjypmzqvflfmjmpqwzqkhjixixif
 * Smoking Wheels....  was here 2017 fhnsgjubhshqvskcgdtpwcapulkvmhcgfsusazylvrvcsiav
 * Smoking Wheels....  was here 2017 cmqhibtilvtitpedpmmsgyyqfbcfjcxkrhvnaxorinkxzpsd
 * Smoking Wheels....  was here 2017 pjckpenjmdtvwghuvrfonacrkgmrrpblqerkubajwofjduax
 * Smoking Wheels....  was here 2017 hrsfuwkaaddxwlenuwwknrztjssgjwheduozkddvnsprlcxe
 * Smoking Wheels....  was here 2017 ynkztlwncmanveldogsxlokkfkectblpmpybizyuufdglamg
 * Smoking Wheels....  was here 2017 seliqpugvdtwzsbqmmgwqokemmlrissahmqsdrrbklrwwifp
 * Smoking Wheels....  was here 2017 wggcufevtfxkuofjciejttgavjitwpnyjknjsrzxhcjltaua
 * Smoking Wheels....  was here 2017 zmqjxihengjwckhugvmuronceuagiqnduuxngnoqpdofhibp
 * Smoking Wheels....  was here 2017 xznnvjslbvffxhyraikrnozuuqvkaerrwdgabdnywsuqctgn
 * Smoking Wheels....  was here 2017 sbebsxgapzwrklccsjkwsprtbdjrmqctefgawpcssgzlwbtj
 * Smoking Wheels....  was here 2017 sgbxyxxopuwsejyiyugnwwxxsrmtkufzoexumixcdmgpqegy
 * Smoking Wheels....  was here 2017 mjwdekzattczyvxwmpwxwsgjszhpvpsdcglzcxrniixhrlqf
 * Smoking Wheels....  was here 2017 wmqbgubmzoqntupnkcnqwtlofydmbjnecakjbflqtyoalhcm
 * Smoking Wheels....  was here 2017 xxpgiswkncxnvnahbxrngwodsuqvooukcikcakohbtbltmbg
 * Smoking Wheels....  was here 2017 yefpuankupllsmglbucsqdxawxrjbyykaenmvuosfmoppzei
 * Smoking Wheels....  was here 2017 nceeivgjmlcadmuodvsnxyzhrahbrlpwvxydsaehlbjrgcit
 * Smoking Wheels....  was here 2017 ntnitopmpjbeelgjlivngyplhawdokuxxbewzznpeqdcfitu
 * Smoking Wheels....  was here 2017 zllqftkdhhpezroxgvvozavbedazhhosvmxthuvqdrrpgiwy
 * Smoking Wheels....  was here 2017 gsmxdiszajileqxlfdnsugxcbuplpukwkedfnurnfvcfjfga
 * Smoking Wheels....  was here 2017 wjhhcktymbdsmbrobivjozlrvqsjnzydsmcsvqwqrbubvdya
 * Smoking Wheels....  was here 2017 rnwcbjddqbdywzoyxtbckxeetqtahaeoczhfpfkqyoiqeqag
 * Smoking Wheels....  was here 2017 tkmycuqzrgrirqmsbwpsswehfzgwlnekclltmoqmstorclxf
 * Smoking Wheels....  was here 2017 kqppqogdbwijinpcdoghczsxyccqtckeoynqhdbgyhqdrois
 * Smoking Wheels....  was here 2017 fzyghvinmizuqjiqxwygnpjeyqkgewnrnusngnljudvfdfet
 * Smoking Wheels....  was here 2017 anmdzzkgxisnqfjcmczcbjxnionzazlyjnofspxmumvkaypq
 * Smoking Wheels....  was here 2017 xpmyuogsmtxuofomfutscdkoobafuaifqzuuhlsnosmkbmav
 * Smoking Wheels....  was here 2017 esjldmypsvebxzddpuafibcfjovtgqqbdfjpxnkqbpvehuce
 * Smoking Wheels....  was here 2017 jrxsqxsvgaialennndvwomoqssamkxafznngrjsfozhyyeur
 * Smoking Wheels....  was here 2017 jocefdemcynsfuimadihzbpftnyrnbjtmmsoaxuwkcleobfq
 * Smoking Wheels....  was here 2017 fsdjzvbakobgldnzljajzpfqzceubovyfwsqnfwpkkeoxgvn
 * Smoking Wheels....  was here 2017 gqndivlcqbpeqrgijpqdehttbxqnwdxgztmucsmlkmnbzsie
 * Smoking Wheels....  was here 2017 beynwiqpnwyepdyapyezllstyrjvxwfowlgrwzkxrjxyarno
 * Smoking Wheels....  was here 2017 ljlznpdryrggiogwfqwlysxawgtymyqufnmbgxtoqfxqorsa
 * Smoking Wheels....  was here 2017 lngzliusekwnbddxnidkbzkgfwkiawlhouybwpujzlkvjmfa
 * Smoking Wheels....  was here 2017 mfulzjpkqgjoikrkdtuxkjlhtyerjjyouhoaplalrtlolzsk
 * Smoking Wheels....  was here 2017 aguktwvqaqpawckvwzujxfphjfezmmwjxiqnpbhfyblyboed
 * Smoking Wheels....  was here 2017 zrhgsdcnhgswtfxbuiihrdrsintmrkcuhmpkfipheoyospto
 * Smoking Wheels....  was here 2017 junoxvenpabiezcbfkxocbreadmokrvbmofudigqcrwaexvd
 * Smoking Wheels....  was here 2017 nexdvvbgmdfwrxfcsyggvbxoekhamamrhplyfmvjrdijllcr
 * Smoking Wheels....  was here 2017 aqfcagcqobafatptdajssnyatcftwmsmwxmopkbwbuptvmmf
 * Smoking Wheels....  was here 2017 sfkulmuuukqifmztozmoxboaxcqbwfkmlcwkqyavtxisuncz
 * Smoking Wheels....  was here 2017 rgsueczekekknkfdgjapvouddpehyuuyrxhobfadlvkwchlo
 * Smoking Wheels....  was here 2017 egryqzrkwnxxlyofvyuxcdyhdbqgyxhjhkukqppybixhuuds
 * Smoking Wheels....  was here 2017 vcxjlhdjvxzpuwimdvsvpdorucfwupmpmynnpsnqvhecchdl
 * Smoking Wheels....  was here 2017 luninjzggyukmfgsfibalfkqksekuckqmbzthmvxeyvvngob
 * Smoking Wheels....  was here 2017 dqqmyvyljqrnwegykyhgbgowibeglxcswoyeiyvqvrsdxkvb
 * Smoking Wheels....  was here 2017 eguqeocpodelkgllgodpaihhiobentcknmjdrncyreybdurg
 * Smoking Wheels....  was here 2017 ejsxtrtppxgwxfiupeomhvdziyxcarzmmemfjujhzjxspqyq
 * Smoking Wheels....  was here 2017 xciqrojqkpxuibmrncvkzjxkmcchfwtzcetgwrsheldrsmvn
 * Smoking Wheels....  was here 2017 ntzjzvvbedokyaxejykglwreiggepvmdxgxiuhlvyxoohztk
 * Smoking Wheels....  was here 2017 hwazdiepjtvehorprmadjjqgnuflyirnsoyvazbdfifkifjb
 * Smoking Wheels....  was here 2017 ughoseqbqvnvdnikhtriphlsakcdhjyxridhrjkngsnjcjqo
 * Smoking Wheels....  was here 2017 vyrkrvurzcthlukkgcomhgvazbflwefhbdwpeimslfbzbzrc
 * Smoking Wheels....  was here 2017 ohmebukvqlxvnrxqybdkvdwuxxfuegsylvyvdzpoohrxbtxh
 * Smoking Wheels....  was here 2017 fwdriaodybowwrajxlffvbvymkyxajtlqkhhlthfmplcbtbx
 * Smoking Wheels....  was here 2017 lkkzcoonrkoefnbdyitffigqqfmujlcotefpgejdkcuviezx
 * Smoking Wheels....  was here 2017 zbhlfwxduebqqeureayadrygphfqnvphctcpyevyvyhnjmvp
 * Smoking Wheels....  was here 2017 abyrxnkklgjoiycbwbhlxwyluutxyymxgytjdvamkpuwynco
 * Smoking Wheels....  was here 2017 tzxmmjcycwcivhdorgmpfcndyexhlpczbtdgsomadskxcekm
 * Smoking Wheels....  was here 2017 wrwzpohsmkdryzirirpvyrgmzdvuzsegnnmvwzzwegmuburl
 * Smoking Wheels....  was here 2017 ddwmdmmunpoppzjfzqtsfhyvcowpxoqtaufyxxosakqaiuct
 * Smoking Wheels....  was here 2017 ptbqgsoqkjshdoeexsncltpxtrpfqrptdjdsnonlhosgszbw
 * Smoking Wheels....  was here 2017 rzaeielvpxgfafwwsqocfgnorwxizumvriflofkfalvnehfp
 * Smoking Wheels....  was here 2017 vskhzyojupzcarwufoxzmchztwxwywzrrartfnaljziaaaoz
 * Smoking Wheels....  was here 2017 zaehdkijyeawdyxtlsujixqnfpxdteaknxzlvjjttivfsqeg
 * Smoking Wheels....  was here 2017 ddqtwepegnturgwtusqdepqxngonzetguwwqbwucyyevbxna
 * Smoking Wheels....  was here 2017 rqgnqdlndxticdxbuifjqhozjgstjrptgyhrtjvpvnmubugz
 * Smoking Wheels....  was here 2017 cjsrakchirwdfilghrmjphaxsglvxqgraloccofqqzbiyohe
 * Smoking Wheels....  was here 2017 hjapyjdpuofgzudbizssfhscsfdxwioakybvlgbwvnpxhsvy
 * Smoking Wheels....  was here 2017 iykvnqjwsmewsuyngwjhwdtfwijnuftdzfpwmoqgcnxguaft
 * Smoking Wheels....  was here 2017 mrjfebutnqikwvaxrddffxkdwaaikbgmoidqawmwjsbjmlfj
 * Smoking Wheels....  was here 2017 kipwmusexknqgrttiubsbbfapzfisvrxgpwrgvjevamjqfrw
 * Smoking Wheels....  was here 2017 vacdjdrgwoxmwhvwjfjmqdzgjcgtzvzjjphvohjuzqsvuwum
 * Smoking Wheels....  was here 2017 xzcoyvnkoztezxefcxmihbtonqtatnjelceenjtqmzqjqczu
 * Smoking Wheels....  was here 2017 yvcbqqfhlvtfbbydbsdjqyutvyqvtqdvjflcdlcvhtjafzwn
 * Smoking Wheels....  was here 2017 mjuqbtcufpsgxmodcrkwpdrafuxfaecddfjdkcevqwgzvrlt
 * Smoking Wheels....  was here 2017 jqercmscvxthoesyickmigeuwbajvlbdeqkevgzgynxsytvs
 * Smoking Wheels....  was here 2017 rymuwnvontgofjhraosadejrgxnsqvgbyihhaaxzwdexixly
 * Smoking Wheels....  was here 2017 swetvrnwrhtmlolntwzotbmqbvgzgebmjjauuulglkeoaezf
 */
package net.yacy.kelondro.util;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.util.concurrent.atomic.AtomicBoolean;
public class GenerationMemoryStrategy extends MemoryStrategy {
	
	private final static long M = 1024l*1024l;
	private MemoryPoolMXBean eden, survivor, old;
private MemoryMXBean heap;
public GenerationMemoryStrategy() {
	name = "Generation Memory Strategy";
	error = initPoolBeans();
	heap = ManagementFactory.getMemoryMXBean();
	if (lastGC == 0l) gc(10000, "initial gc - to get proper results");
	if (error) log.warn(name + ": not a generational heap");
}
/**
* memory that is free without increasing of total memory taken from os
* @return bytes
*/
@Override
protected final long free() {
return youngAvailable();
}
/**
* memory that is available including increasing total memory up to maximum
* Smallest of both old and young
* @return bytes
*/
@Override
protected final long available() {
	return available(false);
}
/**
* memory that is available including increasing total memory up to maximum
* @param force specifies whether ignoring prefered size
* @return bytes
*/
private final long available(final boolean force) {
	return force & properState(force) ? Math.max(youngAvailable(), oldAvailable()) : oldAvailable();
}
/**
* memory that is currently bound in objects
* @return used bytes
*/
@Override
protected final long used() {
return heap.getHeapMemoryUsage().getUsed();
}
	/**
	 * currently allocated memory in the Java virtual machine; may vary over time
	 * @return bytes
	 */
@Override
protected final long total() {
		return heap.getHeapMemoryUsage().getCommitted();
	}
/**
	 * maximum memory the Java virtual will allocate machine; may vary over time in some cases
	 * @return bytes
	 */
@Override
protected final long maxMemory() {
		return heap.getHeapMemoryUsage().getMax();
}
/**
* get the memory that needs to be available for properState
*/
protected final long minMemory()
{
	return getUsage(eden, true).getUsed();
}
	/**
* checks if a specified amount of bytes are available
* after the jvm recycled unused objects
* 
* @param size the requested amount of free memory in bytes
* @param force specifies whether ignoring preferred size
* @return whether enough memory could be freed (or is free) or not
*/
@Override
protected final boolean request(final long size, final boolean force, AtomicBoolean shortStatus) {
	if (size == 0l) return true;
	final boolean unknown = size < 0l;
	final boolean r = unknown ? properState(force) : size < available(force);
shortStatus.set(!r);
return r;
}
/**
* use this to check for temporary space
* @return bytes available to allocate in Eden Space (Young Generation)
*/
private final long youngAvailable() {
	final MemoryUsage usage = getUsage(eden, true);
	return usage.getCommitted() - usage.getUsed();
}
/**
* @return bytes available to allocate in Tenured Space (Old Generation)
*/
private final long oldAvailable() {
	final MemoryUsage usage = getUsage(old, true);
	return Math.max(usage.getMax(), usage.getCommitted()) - usage.getUsed();
}
/**
* alive objects get 'moved' on gc from eden space to survior and from survior to old gen
* in a worse case (all objects of survivor alive) all objects get 'moved' from suvivor to old gen
* this method checks if there is is space left in old gen for that 
* 
* @return Memory is in proper state
*/
@Override
protected boolean properState() {
	return properState(false);
}
/**
* @param force whether using used or committed survivor usage
* @return if survivor fits into old space
*/
private boolean properState(final boolean force) {
	final long surv = force? M + getUsage(survivor, false).getUsed() : getUsage(survivor, false).getCommitted();
	return surv < oldAvailable();
}
/**
* based on my research for a proper running jvm, this gives a guidance value for the  heap size
* 
* @return bytes recommend for heap size
*/
protected long recommendHeapSize() {
	final double factor = 1.2 * heap.getHeapMemoryUsage().getMax() / getUsage(old, false).getMax();
	final long neededOld = getUsage(old, true).getUsed() + getUsage(survivor, false).getMax();
	return (long) (neededOld * factor);
}
/**
* @param collected specifies whether trying to get the memory usage after the jvm recycled unused objects
* @return MemoryUsage of given MemoryPoolMXBean
*/
private MemoryUsage getUsage(final MemoryPoolMXBean bean, final boolean collected) {
	if (collected) {
		try {
				final MemoryUsage usage = bean.getCollectionUsage();
				if (usage != null) return usage;
			} catch (final IllegalArgumentException e) {
				log.warn(name + ": ", e);
			}
		error = true;
		log.warn(name + ": no colletion usage available at " + bean.getName());
	}
	return bean.getUsage();
}
private boolean initPoolBeans() {
	for (final MemoryPoolMXBean bean : ManagementFactory.getMemoryPoolMXBeans()) {
		if (bean.getName().startsWith("G1")) break;
		if (bean.getName().contains("Eden")) {
			eden = bean;
		} else if (bean.getName().contains("Survivor")) {
			survivor = bean;
		} else if (bean.getName().contains("Old") || bean.getName().contains("Tenured")) {
			old = bean;
		}
	}
		return eden == null || survivor == null || old == null;
}
}
