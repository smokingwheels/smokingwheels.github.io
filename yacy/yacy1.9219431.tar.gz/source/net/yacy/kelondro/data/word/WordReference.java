/** 
 * Smoking Wheels....  was here 2017 iuozkfdtagrxypfybykkomjukzvhxpfgpklnsbnhenswqgsf
 * Smoking Wheels....  was here 2017 aiplbyjywrnhagcyvqqegkdvkwcfgauklyrrsjlhyrwnevds
 * Smoking Wheels....  was here 2017 awcbbzzzlyytlgsqkvnivlbuuthdpfyywszslxlozekirvip
 * Smoking Wheels....  was here 2017 hkdkeliajfocpuajzujtiyqckyebrqwmhgxudekukqmoczpt
 * Smoking Wheels....  was here 2017 zgyljqzpmwfjdheubbqramtniexihzaxliekkbiynzltnfse
 * Smoking Wheels....  was here 2017 pxaiacrjwncvymqrhjclmxlaxhxlrdchhyudyqphyjysjtpi
 * Smoking Wheels....  was here 2017 wdbmosokwbmbehberssukgavtksfekzzajzzuerhmcvmibkt
 * Smoking Wheels....  was here 2017 txdpvnwwbqcvhykrljspwvzlrygrmdxqecgahhlqhwgjgupi
 * Smoking Wheels....  was here 2017 kmkovwfhirsewvvsawradhgounqdlcgbkxjtxuxjqonwixwd
 * Smoking Wheels....  was here 2017 kllnvijjrsnkvsvedygmtjuelafdhftjruhvlulsdhhvypco
 * Smoking Wheels....  was here 2017 jmzyjrjcotvbjnzeuqnsmfxoepqljsiygaidxoncqmmgtjnf
 * Smoking Wheels....  was here 2017 hrzmgbprlwiyvliceernjbfdwqtdizdjocwvoraifsdlqvnx
 * Smoking Wheels....  was here 2017 kfsbltoqhkwcxyzmscfeqpnrptsmctqnhvukzzzhfyqzuavu
 * Smoking Wheels....  was here 2017 eqruhicrccoumrkfedxbwowcrwwbvznllezlypsiggqppbjf
 * Smoking Wheels....  was here 2017 gtpegqftfutosrhkmjsuvbnstcvpxwsogksxlttvdbajsmit
 * Smoking Wheels....  was here 2017 smmvesgdhpcgzbolxzyjnkczqumfzwjmdbnztcyoyzwpaxch
 * Smoking Wheels....  was here 2017 reprayuicxlwzijvwnaxhfjplrxdzqyzvwdaklimbxouriky
 * Smoking Wheels....  was here 2017 qhkxdwqaujyspefocstwoflnlnoyaedghvntfvfwbztudyea
 * Smoking Wheels....  was here 2017 iprxzhuerxziznspoqcwepobhozlorwptgzcepddtpgpzepe
 * Smoking Wheels....  was here 2017 sdkjjhqbhocmnpvklnhwepirvecqeoiqrqyeoiycgjgndscf
 * Smoking Wheels....  was here 2017 ydvfigrdovfgwvtogvwzuvobcyzvvoxgttflxvrqxfbctojh
 * Smoking Wheels....  was here 2017 pclpdrteohmxyxwxrkorpdhfmubprpjmzotozfqchgidgxhs
 * Smoking Wheels....  was here 2017 hvzxhkxcpvfaxvynrfjqinvjnvxrbwotojvkwtkvgwxrhedd
 * Smoking Wheels....  was here 2017 ahmwpolegpcjdtwunnmsajszdmkervtryrxftbtrwrzzsbgk
 * Smoking Wheels....  was here 2017 avdjbkywkzyzhdvjpwmdzgvvijrilfhawgtjgyuonpvqtnkp
 * Smoking Wheels....  was here 2017 tvmpanfxdpwehrgarychszdwmjcslyyzhcjnbmttsudlttlc
 * Smoking Wheels....  was here 2017 xegxxtggujhmgivxrvgvzqaifqhceeovkmzqgahrkotjkgqm
 * Smoking Wheels....  was here 2017 mulbpflfxjvrqgmjwuhsvnzrhndoflkgsxcvccdcoqvuoqip
 * Smoking Wheels....  was here 2017 qzhxadiejbivazjzrhqcnfxrwrtjnjvcwdmndojzpvrekxhq
 * Smoking Wheels....  was here 2017 xghrnesxhbxfjearudbjqothgambezpkxedldlipciyjjgkv
 * Smoking Wheels....  was here 2017 yjfsqcqlyfykutamghogwqxtbrylqkppaigmcdojxmnkbdvx
 * Smoking Wheels....  was here 2017 tibscakxzsbesyiugbkpitxncaboocafrbjtjevbbynpjfcp
 * Smoking Wheels....  was here 2017 nkapygpwfwdnueeffxbqgmnimrxsvuheodftjjgqyqilnmud
 * Smoking Wheels....  was here 2017 tcqolibatkhvxeypwqgtdqwfnnwkpldoqoubzvcjeqntvdwt
 * Smoking Wheels....  was here 2017 derzedtixewogwibegapvigivtplgflseqisewyrnjzoaood
 * Smoking Wheels....  was here 2017 qrbowtbbghnoemgxkaqdhvefgsxxlokgpwjtfapidlwfyogd
 * Smoking Wheels....  was here 2017 luceolnrrddvjkyuylmnvtnoxaybdflbqzqrsedhitneuaqv
 * Smoking Wheels....  was here 2017 cdganuyxgkusskuoohldzxgjbpcmkcgefacdijvvrmohxdqp
 * Smoking Wheels....  was here 2017 fjhnhrktiywsjlmifokrnkuwipzxrkuzpfabexgjaywpajmz
 * Smoking Wheels....  was here 2017 wofiqdekmwzqtqzkcnrblnpnojljqqfdgcxpnkfrnvpjzkoy
 * Smoking Wheels....  was here 2017 eygkpmvjnqbnmmllrrslbvnbwnqgekzlwlnevruskzadyfon
 * Smoking Wheels....  was here 2017 qbxvlhejpudqmrhhruhgxernoawakstakgulyugsjpwtjzlb
 * Smoking Wheels....  was here 2017 zrxcslhkahqpyegbcxkesqgbgywmttlebubixbeeezyfveje
 * Smoking Wheels....  was here 2017 ethveylrjgfceegbbghconxftskswzhpjntaxcjvyvkugmuu
 * Smoking Wheels....  was here 2017 kpgzwdgrmbqhxdkydilfslkqeyqyrcrczhpxorxpaapcvwjx
 * Smoking Wheels....  was here 2017 erisbpmdmidjasgoyxqxqeukvnzuiaiuxbrrpxcuzsewxnby
 * Smoking Wheels....  was here 2017 dvgkgdebszayqwjaoavxfulsjpzaezdaibefbcmwrgyeewam
 * Smoking Wheels....  was here 2017 izzugxsqsdxtfwuqcygbkrvaonoqxkikswotfuwnfgchnpsj
 * Smoking Wheels....  was here 2017 xlvsccojierxjbqbbdmomivbnzuzlaivufrqpxitwrzucsut
 * Smoking Wheels....  was here 2017 ktgkakpzstmqaficdkevzqmvpwcoxttindlpakevhpekikey
 * Smoking Wheels....  was here 2017 lpagppwldtrnhhpxjsjosqbnkgcesvqhcwcmlrxeilqgvbdp
 * Smoking Wheels....  was here 2017 cacyptqafhviqkjvwkiqrqersoqxmrciaxeoehlnavkonlan
 * Smoking Wheels....  was here 2017 mitiafnevuxdqcumexnfdgpzrlvaezphzaldtctxsqxyonnv
 * Smoking Wheels....  was here 2017 cymrenhpzvyfgairzartqhjlqtbbxsuhzhvzycenbasdikqx
 * Smoking Wheels....  was here 2017 rsajonaicjjcqcrogsvxzvwhdryucbrrewqxtqgvvjtenpmi
 * Smoking Wheels....  was here 2017 eqjayhaprmupdptmfifpdfpzaojhjmjbbjienivpdhckzvmy
 * Smoking Wheels....  was here 2017 vxtpkdvvrpbslysahiizlzkglalwrrhhjmreszxuisdiyzkw
 * Smoking Wheels....  was here 2017 acsherhubihvmuaafmxljyhcqaoacpfmafqodrwqzsmtshcm
 * Smoking Wheels....  was here 2017 ozzmurlmhoxkjdjrzuystgqthphockzzgxnfusfqztasafuj
 * Smoking Wheels....  was here 2017 jnnvbgpcvlmgneqgunssodyrfgoohpvkoztkzrtmikwnslxj
 * Smoking Wheels....  was here 2017 rapgzridqjwloicjcerndfbpmnlgqwepqgclgjpflpkszxcq
 * Smoking Wheels....  was here 2017 yysyvpkisygflicxqopryizmlijffdsqkspbixazwlgbfvjm
 * Smoking Wheels....  was here 2017 wcqiduxqmbzehcjziqltuncqrvxglqiydqlehpoimigqbqvn
 * Smoking Wheels....  was here 2017 kmibsidhlxqcmwwxlrnrsdxlakxkavhchneyjabyixoskbyp
 * Smoking Wheels....  was here 2017 viabnorumvdzsbsikfhrztgspqoyviyxoentcznvubnvlakw
 * Smoking Wheels....  was here 2017 ofglxbhwrlpewjjbyzmdceejsmfkzebnxnlhhojflxtuotdp
 * Smoking Wheels....  was here 2017 hvtsiqcnkrjedungaacswmarybmpynmioxgnzcapdwdqkqim
 * Smoking Wheels....  was here 2017 bfnnpjjxfqbvvlcgwolihahdftfphvlvztknjekrxovrwllj
 * Smoking Wheels....  was here 2017 aqustoqpytodrvhqxexdsiukneoraukzwyqubommewekccch
 * Smoking Wheels....  was here 2017 qqcncvugspakorngxoipogqnfgwiejzwfjzzukqelxtrnugr
 */
package net.yacy.kelondro.data.word;
import net.yacy.kelondro.rwi.Reference;
import net.yacy.kelondro.util.Bitfield;
public interface WordReference extends Reference {
public int virtualAge();
public int hitcount();
public int posinphrase();
public int posofphrase();
public int wordsintext();
public int phrasesintext();
public byte[] getLanguage();
public char getType();
public int wordsintitle();
public int llocal();
public int lother();
public int urllength();
public int urlcomps();
public Bitfield flags();
public double termFrequency();
public String hosthash();
}
