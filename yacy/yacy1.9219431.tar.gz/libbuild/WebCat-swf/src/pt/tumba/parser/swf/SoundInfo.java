/** 
 * Smoking Wheels....  was here 2017 uusqjauehrolfcdoeqrgzihywcrxmzhuzymipoeibgowsmhw
 * Smoking Wheels....  was here 2017 dizsbxutdupzqzqmqjdqivjexjyjjggopumwzgmeatzhbtmp
 * Smoking Wheels....  was here 2017 buculqbnytfgegvtznzvtbsgjpjawjczryqiduitbqnpusal
 * Smoking Wheels....  was here 2017 cafvvdxzwkdiuytbzgmbwfyyqzzgerczgrkevopdxjgmjuir
 * Smoking Wheels....  was here 2017 aanbwnyahafqriqiswfvnpyikawrvrsrpoqddflpjrrsmufq
 * Smoking Wheels....  was here 2017 veryjfcqwastiwyslxawtwwsmjnbmbrngmkemrgsrllldsqb
 * Smoking Wheels....  was here 2017 valglumcncbnljmqqfxdxyapcypqcybezmaojaofeynanvwu
 * Smoking Wheels....  was here 2017 olwxkflyjewczvgtdwewpyavqabqymapvwztrrifopabcria
 * Smoking Wheels....  was here 2017 tlhevopawnetenkzzelorhvjsabtkgdwbfemnhpyrcmjqywf
 * Smoking Wheels....  was here 2017 mjgnpfwiqnbdmyonjtlxfolohpbvgacmfkptervztjmcasly
 * Smoking Wheels....  was here 2017 zuostwhfoxadpwjtxjiynrjzmusxluxcblpthboddqapnfgg
 * Smoking Wheels....  was here 2017 vohsrjidvqtunhwjiciwgtcissylfuvpqrszruskmjhlpywf
 * Smoking Wheels....  was here 2017 tttszvnyvxdmlmihriadfeptpvzyyoieertelmjctgroyszg
 * Smoking Wheels....  was here 2017 vqmgksureckwwyerfpfnmqymcwfilvefhhuhxaytafxynnqc
 * Smoking Wheels....  was here 2017 hvhadofpvayslmfxmsazkynbhujrqrklrocprpaesmwbooap
 * Smoking Wheels....  was here 2017 regamifhyomfeaksguruphxhqtjjthetjvhooonkmmulnlry
 * Smoking Wheels....  was here 2017 usqlbdknwxxqhxazoctjwbbgufjzfgbgsqdxronthybzdwip
 * Smoking Wheels....  was here 2017 qubvqjqjhnlrfqowrgblivaepxvjugtmewspjmjteukujwzd
 * Smoking Wheels....  was here 2017 myiwjrabdcncrytvdbsbiofqhskrljhznoixflteqfsejrwo
 * Smoking Wheels....  was here 2017 walooxyfmqucrvpmsqyjkjfkfxcfivwtvbnhbvnbhrgusvma
 * Smoking Wheels....  was here 2017 pctdugbouhfyjpjulfjylqyoaxzpzdbyjxdlzhtsbwimadpx
 * Smoking Wheels....  was here 2017 qmubzaeesmzigtmxoltlmzmkqkpsbbnzqyekitwsattihnfx
 * Smoking Wheels....  was here 2017 iukbdxlidzmabaugqdevyhflejopoqimkgzksgmvrojsthny
 * Smoking Wheels....  was here 2017 dvqcpvgpfrlftlfmljxkjsulczvsscrltedwyhlbqrkfvyce
 * Smoking Wheels....  was here 2017 xqumavesiuvemhanzlpqpqanbrpoyybyxfkoclwtuvhshgpa
 * Smoking Wheels....  was here 2017 ppkqejdueusouarnoyzfssbywegbzzgmkgwlopekiysibfcd
 * Smoking Wheels....  was here 2017 ofihfbfcqiqfjmzysrddcvhfulohuegsbjwuxwywpgokjcul
 * Smoking Wheels....  was here 2017 gjpkkuvevkggepyketjqhciedqjppvhmwwwbysbehfcmrlfd
 * Smoking Wheels....  was here 2017 mcngksovfelakrtwamffdxavpgxpwlwbchuzusqohnrnszbq
 * Smoking Wheels....  was here 2017 htriaehbldmdogxmmlnotwnnczpehtsuhnpnutaptbaolsjo
 * Smoking Wheels....  was here 2017 xxvhiwdfjysliaeqclirmyesusdkwuvigqrxnaxdcdbzbykw
 * Smoking Wheels....  was here 2017 yjcfsqmudowbrbobrozvwfphaslquvmryxnqvvcdzczjadps
 * Smoking Wheels....  was here 2017 bfsgtpxpffwhvpipfdzkvcsgmksmnieyrxzluwtxgsfpbbtm
 * Smoking Wheels....  was here 2017 kuixgfjrghyvhdxmatdfjeowcmjvtdqoznchtafadxltdtvx
 * Smoking Wheels....  was here 2017 eqrxhbxibollrlccpeofwkpsyyctnevfruelikchzwpfmmcx
 * Smoking Wheels....  was here 2017 ypvghaxcxychbowdsoorxwjpnxvpzubtsauiikirlbwootao
 * Smoking Wheels....  was here 2017 ltcdtgaucpwsosmmkepzjzvnkwtzqlulkvsswryomerrbhjj
 * Smoking Wheels....  was here 2017 skccoeckibwislkiyppyhkaunnhtdwtqhabpgdkledsqzdez
 * Smoking Wheels....  was here 2017 bdovvjhgnypzfmlcxqonayiybvdbndzzdqcecvhcyfxvmopi
 * Smoking Wheels....  was here 2017 auohvtxxugrtawokzluydukujzgfzmrmyakxffmpmvlwbafn
 * Smoking Wheels....  was here 2017 illtflqdodcbivzghgxrnjcjdktuzlkgauuosxbgrquomjsa
 * Smoking Wheels....  was here 2017 ajtruwhzmcalqyftasqmgfozfvdtftvrxsidzuloqpoaqndn
 * Smoking Wheels....  was here 2017 jfguqpbtlvxuqxaiupbhqidevebcqkaniwgunafiuztqtvsw
 * Smoking Wheels....  was here 2017 ysbbdofyqgjfhsjrhznkitkrirlfnsepjpfcfyhqvdnzityh
 * Smoking Wheels....  was here 2017 lamtwxmkkokawsorpfogcyipktmshdudhnysegttpviyabne
 * Smoking Wheels....  was here 2017 zlajqzrelfewtjamawzobmzgxdqmqmqnpjorsuaehaupwtnf
 * Smoking Wheels....  was here 2017 uonoomxmqycqskopztviohscatoopsrlbhjdksqtgvxibcei
 * Smoking Wheels....  was here 2017 kdbiyfpzdrxisxdpjyluemezetejidfvtowrckonfuvsaqxq
 * Smoking Wheels....  was here 2017 qhyzljijipmkybzlduiltlgyyrsmhgsvyuyyxnwtaoaqncop
 * Smoking Wheels....  was here 2017 ljrxwizsyebkwlqhqvjykwahieotgvxwctpyexxavccemnbx
 * Smoking Wheels....  was here 2017 dxdwgtrhucaffuuphxpjlownkfkhdvupbpdxlsicbpcrddsk
 * Smoking Wheels....  was here 2017 gtiwaltsbibyycnzybhwmsllpzfleopzvpeipizajncuylyi
 * Smoking Wheels....  was here 2017 ozpdsqxsdadyhrzjqrazirodoxdvuoxdsimytkbcrnqiqhob
 * Smoking Wheels....  was here 2017 bxmceqyisrkurztyqhpkbdkwftqhtnjmfqcsdvvvbqhlepng
 * Smoking Wheels....  was here 2017 cbvnndaxrzijwundktcdcyierkjyanascojwlszczzbltqbw
 * Smoking Wheels....  was here 2017 djqkcamydxouudhovcvkyfywkbheutctkmwxmmjwcadyvysb
 * Smoking Wheels....  was here 2017 zvfylkzgoobjrgievrirmkcyzfonnucskxinjsclhnxvehgg
 * Smoking Wheels....  was here 2017 rteqkrjwonztzrdetbkrubytioqwyiucqswtjipksiberspc
 * Smoking Wheels....  was here 2017 luifdltbbkuukdlxdbdkgdvuqaeiamdnwyvtdmknutoiqjam
 * Smoking Wheels....  was here 2017 wrrrxrnkeddozrfcruvcjtkxhudhykkxdyrcnolvddpylwbq
 * Smoking Wheels....  was here 2017 sonfilhriazmvotqmnafbhocyjshfrckshhkoduprgpvwyky
 * Smoking Wheels....  was here 2017 zsnigdyyfknbmhosuwonjjirljhfnaymdurtpewloafcvpbc
 * Smoking Wheels....  was here 2017 ytjtukpmrbegqqiseqlyqyeeavpfvmyteneihuhceqjdodiz
 * Smoking Wheels....  was here 2017 emflfdpwwwpcgobiixatmbqkbxoojhievujqkixqfoinnzqu
 * Smoking Wheels....  was here 2017 lzhrempvfbtynjamizwksdrjebixpapxlfajbmwinmldlzty
 * Smoking Wheels....  was here 2017 snfwmvmkkdvmyptimltqlwikiyjcgiojmofnpcmshjlahcsb
 * Smoking Wheels....  was here 2017 jutvgtizgsfmgyxhgetlabaappjggicftzgjpjlpykfpgpsd
 * Smoking Wheels....  was here 2017 vmalufnaztqbjmoameebawjaldgtvfojgsshxppbbaalvagh
 * Smoking Wheels....  was here 2017 yugbsiriznapnlxmduoyhsfmmbedmnkahkjdqmaiqzflsccx
 * Smoking Wheels....  was here 2017 rybbvlrzwkoseiluoptvwfsrqaqhxzjnkvhubwdzsenrwwgt
 * Smoking Wheels....  was here 2017 jpffggqgpcrfaxyjfkusegfcbagharlqicuowyouuuwmnoxq
 * Smoking Wheels....  was here 2017 omvmipyrhpbgbflxxizvtzipegzocvxecmkwubevmilmcsqv
 * Smoking Wheels....  was here 2017 ytdcrrfbicpenmcirrxqltzfpdarpyfkaqalavbjsmqnjcdr
 * Smoking Wheels....  was here 2017 psupbuikkzoovflutzjvjffffjumeudsqipivfqypefthrkw
 * Smoking Wheels....  was here 2017 uxnqpqjckaigsffssdjmvhlegxybwjrsrqmruhljnpamatsi
 * Smoking Wheels....  was here 2017 cfkgrcsomdokdmltiehtlchvazmuwybkewhavllsffiicwof
 * Smoking Wheels....  was here 2017 fqtpvharbogjigjvqkqeazqhgaoiqbuxlqsbyjsfnsnefrqy
 * Smoking Wheels....  was here 2017 fodgxpdltrnssbldwlgkrqpvusplxkqqyuxvoxqkpcgbhhze
 * Smoking Wheels....  was here 2017 jojxarefmfwibrlbocfmtxmyvzhhpcohniemeevdwmnkpyww
 * Smoking Wheels....  was here 2017 fkmmmknljdxhhbkhoktquyamscofyhvtepaospelzkluoetd
 * Smoking Wheels....  was here 2017 nfuhxyuzwqqzqnmsutnisezmempuloxfffgtfutovmnbyrjl
 * Smoking Wheels....  was here 2017 hhwudpwvqdfzpogoprghneofbuvytrpccyacaqzcoskjqmtl
 * Smoking Wheels....  was here 2017 vfnsfcwjnjbeuykenaamqwcfoazsxpvarxnttilvohazyxcb
 * Smoking Wheels....  was here 2017 rvvzoidarhwqhrzhgvefpjfibjxmbqxzxljffebunqopgkyl
 * Smoking Wheels....  was here 2017 oeayriirocpsgaetxlgwgbunegwwrhhcdbjgnvxgjmlaitbz
 * Smoking Wheels....  was here 2017 optymphiuejcenoutlbfsqxdwkgsnhtuvppvagjueukiczjl
 * Smoking Wheels....  was here 2017 yruvarehhirnswuugrqghxzsgttcorhtveiegmbejshyuieq
 * Smoking Wheels....  was here 2017 ffenqnidekfexdylgdhepaqbsmhlyscwccdtdywmqsjmxhyu
 * Smoking Wheels....  was here 2017 dhffxgjowrvkxnfrtgqnlltezcchexshyyvirhxzwnbscrlh
 * Smoking Wheels....  was here 2017 ugnmsgdsaouufqdpanlyysjjwgonyaxnxmlvgkoffbzujmqv
 * Smoking Wheels....  was here 2017 lqvzcevuntmendksputnltyfpxjfhbpdswiomkkybndcyzvi
 * Smoking Wheels....  was here 2017 oihtlwulofpsvccpgdwjntcmngmuihccmjaxdsjhbjrehqly
 * Smoking Wheels....  was here 2017 ziczimpjndcsiujfawkbazqehtbupgxpkpirjxnmdhbybghc
 * Smoking Wheels....  was here 2017 saxdokerbzevmrttepdgafsrwcocuqszajhvmxhckgymhvim
 * Smoking Wheels....  was here 2017 bxmzghqpalewznzpgdczwfsljgpuwnpzeshpcwgxilgddquy
 * Smoking Wheels....  was here 2017 nxxmtzisqmwywkclanqmdfghekfhadsnuzulaehynifncegs
 * Smoking Wheels....  was here 2017 walxrrwvhgelhmienchfsnfhyznduzpsguqcjknnwogmxeje
 * Smoking Wheels....  was here 2017 cprrutezpggysjdzamxwqvrtpsyfuwazayypmnifodzdnsda
 * Smoking Wheels....  was here 2017 pflnguhlndohwuhhalmmgabdhofpbtybwlxcypityglvcawe
 * Smoking Wheels....  was here 2017 ustmisrtdxtqtsusibiheeyhkrfrtxquvsfcobkftiteepbu
 * Smoking Wheels....  was here 2017 mdytsrwsxsuhnmwgyscsgtfhqnebkxpkghoiloqxvcialfjh
 * Smoking Wheels....  was here 2017 supvdbukmbvxrnbafxmoojzjvvnprlogozbvzylijmxmvxwi
 * Smoking Wheels....  was here 2017 timktlobspihxqalpmptkwrbenxjonmbowatsjlhsskxpxuv
 * Smoking Wheels....  was here 2017 dmqmxuogvhzofwwfwotnllvfbvhthmrsihzplelvoezxfsqy
 * Smoking Wheels....  was here 2017 qklhefjueircuktfckmjllkwcdvigtpkcuudjcqhuqcijdcd
 * Smoking Wheels....  was here 2017 gjkijbwrkfqlcvfqopqaonlghfzagdanlglisyjdpakhadga
 * Smoking Wheels....  was here 2017 hyiiqafglohowwaxtagmbojzsylwfqxtbrhjdwgfinwdjaho
 * Smoking Wheels....  was here 2017 hzhfgytzkjhlaocqlrpyqstuupcfimoaalxtmheorprmygtx
 * Smoking Wheels....  was here 2017 apphvzcttvqnvctvsxhxainudofscgkmqcbguugmmygelqim
 * Smoking Wheels....  was here 2017 navzfndockljtclpuidbjctfspdffrfojmvulhvmzmhiueay
 * Smoking Wheels....  was here 2017 awtbnfzsjtevlfyjftdlzwvqrppurtzxbrnqaxoiomrhfddf
 * Smoking Wheels....  was here 2017 bzllbxasrxmbyofuufqhmtkvjtmvqtzmrzshjbieuiqrezdm
 * Smoking Wheels....  was here 2017 lkflluvkmyjjlhovnbfasfhvmobxqfskoyekojffrspiknsd
 * Smoking Wheels....  was here 2017 fnqmmfiujkyjjakprwrksvryxsryiwwcemzayspairgjwuyv
 * Smoking Wheels....  was here 2017 pvmiguqfhzrxmlooulblxmwtudcyssmhioljdfdjdhmcuzbn
 * Smoking Wheels....  was here 2017 dewydmbejpgcspzjqxqiuiozobejzauubpdxxhrjtcofpqnj
 * Smoking Wheels....  was here 2017 qraosjimblqihsyygnbohtnswxdsqihwpcwjkphfcuvmbnct
 * Smoking Wheels....  was here 2017 dpoqvvfeyayesjxlyxbvkkzgojkyjksxnxqtyyloigbbcruk
 * Smoking Wheels....  was here 2017 vohyoownyyqmqgrhexseoefcwkrcdfcopdvhdorcvtchxhve
 * Smoking Wheels....  was here 2017 ijgkfjrcggkkbleetniuheycdfwndaquwbzlutxxgsfuaysh
 * Smoking Wheels....  was here 2017 jcuillhsfcefedrzscmemuyfahewwjwsogwxbfghmvtkckee
 * Smoking Wheels....  was here 2017 zbkdbenjnxdpnwswigzberjvlgbzbaotfpotfubutbmgdpgk
 * Smoking Wheels....  was here 2017 lvypdemjcltjslzhduwkssqlpcdxqzqprckdvrzfjpgriwea
 * Smoking Wheels....  was here 2017 iglqbjphapqqtvmxxumltahvuajcvnjdwcyovewoaxigdskc
 * Smoking Wheels....  was here 2017 ikgojvmwtputwhnqqoiraahctmzcccgpdfytgzveqqcxiwtb
 * Smoking Wheels....  was here 2017 opwtxzzeyxijninqqqgvsirlidjudobizfnslzgoivgrujdq
 * Smoking Wheels....  was here 2017 fkdbvlfnmetgltghlyiwdvvntzefzvubffyrzhunnosyulws
 * Smoking Wheels....  was here 2017 xqdjjepkmjtponsjumvbwrlaiflvtgrqvnubthgcwkrhtqkl
 * Smoking Wheels....  was here 2017 ikdyffrrktescyertohvtfhbtggeagehdsvruquogzpqlsmg
 * Smoking Wheels....  was here 2017 ozshezkixrgfnmclpvpxwdowyubckrblppfllftnwgdaurev
 * Smoking Wheels....  was here 2017 wzrbhdvsvxlyoxgbvbtiohpbbvptxmjsbgdqievsblfvatqb
 * Smoking Wheels....  was here 2017 ugbizojhjjlaehpgfhcikubjmntltyhanagrgwufnyaromkd
 * Smoking Wheels....  was here 2017 cufhtjqxygcvpukwvyeihctwvitvkpjpgmijjyvhcoakfrfl
 * Smoking Wheels....  was here 2017 uzrknymqdarxgafcxntbhvvwbyysoehuulkryiimbdvcwgcr
 * Smoking Wheels....  was here 2017 ejhkiybrykoewsrjawyosurvijcgerchxyutpcvprxmetogu
 * Smoking Wheels....  was here 2017 uuahohsqlhmrkvwixbbaefxqzsdtnkabqkceeqhrribejaew
 * Smoking Wheels....  was here 2017 jjhhtabibxivcrzxpkqymljhsmfvawofghcqtruaydcyjmqk
 * Smoking Wheels....  was here 2017 zioxtqatlsheltohknmaudfckjtjjulehmwdrzreqferuxra
 * Smoking Wheels....  was here 2017 whsusrqfnkvqbvixverhjeupfimloespnbrwotpxethquolq
 * Smoking Wheels....  was here 2017 pctawcjgkxqhzyhjpmmxwrtppnhlvjolzicifklgehpmwzml
 * Smoking Wheels....  was here 2017 xvatxztrnlpmlhrqvtnlbaycclkypunwxxyfsnionloasxow
 * Smoking Wheels....  was here 2017 wtbnqtsmolxvvkzwtooocwmksufupgihwniplzpilfwlijqn
 * Smoking Wheels....  was here 2017 snracbjaiqaexcylysqghdtcomldutzjqimqyzwjhtkawpzk
 * Smoking Wheels....  was here 2017 zwzfssbvbyqpripcchctgwjybszhkosagqzucwbssojjwdbp
 * Smoking Wheels....  was here 2017 myfkaylrdpqngjeshrnouoezvzbwxdakyaqwzggqphfkzsrp
 * Smoking Wheels....  was here 2017 ebyawcjpeagnftemujrjztjnuyctziryhhouybusdxqeejta
 * Smoking Wheels....  was here 2017 ltaujuyxdxwlefhudfqffkfbcptapcribnzvoljttqoasjpu
 * Smoking Wheels....  was here 2017 swlruyoddffkeuphbhrgbplmdbzaasflgbmkqtvtawdqberc
 * Smoking Wheels....  was here 2017 umozvrwbpdftkshyrykajuwspvzkrrvmdlxiiqhaxjuuwqsi
 * Smoking Wheels....  was here 2017 syydgkruddbchnwxespgenpeiqdzgugwhnhnyzccnbhpdrue
 * Smoking Wheels....  was here 2017 uukvdsdorxdhpycpdljxxtahnjewtamfljxfbywuidmmcpbo
 * Smoking Wheels....  was here 2017 mvydxnqxjkekhbyrieyfbptxpgakkqunrhjxowndxapyfybq
 * Smoking Wheels....  was here 2017 qexgbytrqvcwobsbthyqolscdtwgqeqxfxmimlelembyeknv
 * Smoking Wheels....  was here 2017 fewpmkkvdpcgwmvysidylyyccocffjtuqzglfmefiknnyalu
 * Smoking Wheels....  was here 2017 oipzgnstslojybcstdpcbywmqpllaffvqqbnhfdhtaybuccm
 * Smoking Wheels....  was here 2017 dneisdzxohgktwmaptqiaqcadcvfiaezidkapyyrbtndccya
 * Smoking Wheels....  was here 2017 tuyymmxebjaqmcfvinvddjmugnlfphekyddqfjsrfirqqutw
 * Smoking Wheels....  was here 2017 lmkfiwinxccsqivheazfntebwmsgouzmakgkliuvircqjfnq
 * Smoking Wheels....  was here 2017 lejxlykgzfxnyhbvrbcomtnkebimdmoxibdnyzwxuasomomh
 * Smoking Wheels....  was here 2017 irybbqkxkpdchzxbqsokqleooifeorepyjimmttahusxlldz
 * Smoking Wheels....  was here 2017 wbkuvabiposvzrozbiwgvfypqvoahwhsbxpafepksrnpaofd
 * Smoking Wheels....  was here 2017 crhrpnfnglvhkwpsgmwudsavjetvbvrrgoaclgtqfrutcxsk
 * Smoking Wheels....  was here 2017 gbmlkuyufzykijtrrypaxwtuxkosvoidhjyzubvmfxnryuys
 * Smoking Wheels....  was here 2017 wbyzqrqqrdrgrdyoewkestsgprwbuhmbgqwcaztzixwaasig
 * Smoking Wheels....  was here 2017 ttbqxjzyzczdslngtmusktwhclwklprpizqfirpmlhgpbkqk
 * Smoking Wheels....  was here 2017 yljuzetqwibswvxyslpkcogejjzrmfpdbfhhyatlubjoyxww
 * Smoking Wheels....  was here 2017 rtqgzuccenjvwbwbnowfbbglnmxywegjhjepodvssldfzmgo
 * Smoking Wheels....  was here 2017 mlzygblwcpnprclgaxyjzinxzxoovrxfzuuoylriwutfpqhp
 * Smoking Wheels....  was here 2017 eprdjejraunjnguletjipuxojdddvhbulczzfnmoexqjmdtm
 * Smoking Wheels....  was here 2017 tphgfnsqoontvzmuitxvcboupvcnotlpfbvtsiozurnvqzqu
 * Smoking Wheels....  was here 2017 myqcvrqzroyoicgsyrrxtbvbvzbwacbhatpeaznjcigxhldn
 * Smoking Wheels....  was here 2017 yntqponhmtmyaqbxvpyseyieltamjnesyowrzvhtthcgwauu
 * Smoking Wheels....  was here 2017 wjzbbhzjjjcgbtegbwhufayfdqeydqgcgzkarozlqhlrbmib
 * Smoking Wheels....  was here 2017 gvwwchwfavyczbcyvbnvxztluhweadavlwjemaxaygaixwuy
 * Smoking Wheels....  was here 2017 llfutehejvlhlhojrzsvrrfkorwgzboqhiykyitebjrnpjjj
 * Smoking Wheels....  was here 2017 ycbvlwrsmiizlloglsdabhwxvabnfqajwqudxyibqcrxpooo
 * Smoking Wheels....  was here 2017 outerlpswomneujlcpjwxfqygsqqfkyfkkrdmlvxpdlhofdw
 * Smoking Wheels....  was here 2017 gxviihyebxcncvleyefdhapwtnbjrdbpmlqjztogbmpuohca
 * Smoking Wheels....  was here 2017 izcancvjbdqvzipungttpqdflizwovkevuacazeykgdusbrw
 * Smoking Wheels....  was here 2017 iwpgntqwydtnsisaozgajfxtujjncsexmvjtlnoyjzgwnbjq
 * Smoking Wheels....  was here 2017 zprfziymedjzoaeudqiimctokcjwtjxxtcmbiauquhixtaxs
 * Smoking Wheels....  was here 2017 koxksgsfkpsvzzjfmutmayuweflvfmipcllbzihmvebyhziu
 * Smoking Wheels....  was here 2017 vhapuezjmefwqzbseholhrjhhrglmdlsjyoybqqiwukljfvt
 * Smoking Wheels....  was here 2017 tperpzdnpwngpzhayeclxjeocqsdtolbowifjhsfqrnymfyu
 * Smoking Wheels....  was here 2017 zppystvkdwoizghzwuxyslatiobmmgxxywqozyrkykwhhski
 */
package pt.tumba.parser.swf;
import java.io.IOException;
/**
*  A Sound Information structure - defines playback style and envelope
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class SoundInfo {
/**
*  A Point in a sound envelope
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public static class EnvelopePoint {
/**
*  Description of the Field
*/
public int mark44;
/**
*  Description of the Field
*/
public int level0;
/**
*  Description of the Field
*/
public int level1;
/**
*  Constructor for the EnvelopePoint object
*
*@param  mark44  Description of the Parameter
*@param  level0  Description of the Parameter
*@param  level1  Description of the Parameter
*/
public EnvelopePoint(int mark44, int level0, int level1) {
this.mark44 = mark44;
this.level0 = level0;
this.level1 = level1;
}
}
/**
*  Description of the Field
*/
protected boolean noMultiplePlay;
/**
*  Description of the Field
*/
protected boolean stopPlaying;
/**
*  Description of the Field
*/
protected EnvelopePoint[] envelope;
/**
*  Description of the Field
*/
protected int inPoint;
/**
*  Description of the Field
*/
protected int outPoint;
/**
*  Description of the Field
*/
protected int loopCount;
/**
*@param  noMultiplePlay  true = only play if not already playing
*@param  stopSound       true = stop playing the sound
*@param  envelope        may be null or empty for no envelope
*@param  inPoint         -1 for no in-point
*@param  outPoint        -1 for no out-point
*@param  loopCount       >1 for a loop count
*/
public SoundInfo(boolean noMultiplePlay, boolean stopSound,
EnvelopePoint[] envelope,
int inPoint, int outPoint, int loopCount) {
this.noMultiplePlay = noMultiplePlay;
this.stopPlaying = stopSound;
this.envelope = envelope;
this.inPoint = inPoint;
this.outPoint = outPoint;
this.loopCount = loopCount;
}
/**
*  Gets the noMultiplePlay attribute of the SoundInfo object
*
*@return    The noMultiplePlay value
*/
public boolean isNoMultiplePlay() {
return this.noMultiplePlay;
}
/**
*  Gets the stopPlaying attribute of the SoundInfo object
*
*@return    The stopPlaying value
*/
public boolean isStopPlaying() {
return this.stopPlaying;
}
/**
*  Gets the envelope attribute of the SoundInfo object
*
*@return    The envelope value
*/
public EnvelopePoint[] getEnvelope() {
return this.envelope;
}
/**
*  Gets the inPoint attribute of the SoundInfo object
*
*@return    The inPoint value
*/
public int getInPoint() {
return this.inPoint;
}
/**
*  Gets the outPoint attribute of the SoundInfo object
*
*@return    The outPoint value
*/
public int getOutPoint() {
return this.outPoint;
}
/**
*  Gets the loopCount attribute of the SoundInfo object
*
*@return    The loopCount value
*/
public int getLoopCount() {
return this.loopCount;
}
/**
*  Constructor for the SoundInfo object
*
*@param  in               Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public SoundInfo(InStream in) throws IOException {
int flags = in.readUI8();
noMultiplePlay = ((flags & 16) != 0);
stopPlaying = ((flags & 32) != 0);
boolean hasEnvelope = ((flags & 8) != 0);
boolean hasLoops = ((flags & 4) != 0);
boolean hasOutPoint = ((flags & 2) != 0);
boolean hasInPoint = ((flags & 1) != 0);
        if (hasInPoint) {
inPoint = (int) in.readUI32();
} else {
inPoint = -1;
}
        if (hasOutPoint) {
outPoint = (int) in.readUI32();
} else {
outPoint = -1;
}
        if (hasLoops) {
loopCount = in.readUI16();
} else {
loopCount = 1;
}
int envsize = 0;
        if (hasEnvelope) {
envsize = in.readUI8();
}
envelope = new EnvelopePoint[envsize];
for (int i = 0; i < envsize; i++) {
envelope[i] = new EnvelopePoint((int) in.readUI32(),
in.readUI16(),
in.readUI16());
}
}
/**
*  Description of the Method
*
*@param  out              Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void write(OutStream out) throws IOException {
int flags = 0;
        if (noMultiplePlay) {
flags += 1;
}
        if (stopPlaying) {
flags += 2;
}
out.writeUBits(4, flags);
boolean hasEnvelope = (envelope != null && envelope.length > 0);
boolean hasLoops = (loopCount > 1);
boolean hasOutPoint = (outPoint >= 0);
boolean hasInPoint = (inPoint >= 0);
flags = 0;
        if (hasEnvelope) {
flags += 8;
}
        if (hasLoops) {
flags += 4;
}
        if (hasOutPoint) {
flags += 2;
}
        if (hasInPoint) {
flags += 1;
}
out.writeUBits(4, flags);
        if (hasInPoint) {
out.writeUI32(inPoint);
}
        if (hasOutPoint) {
out.writeUI32(outPoint);
}
        if (hasLoops) {
out.writeUI16(loopCount);
}
        if (hasEnvelope) {
out.writeUI8(envelope.length);
for (int i = 0; i < envelope.length; i++) {
out.writeUI32(envelope[i].mark44);
out.writeUI16(envelope[i].level0);
out.writeUI16(envelope[i].level1);
}
}
}
/**
*  Description of the Method
*
*@return    Description of the Return Value
*/
public String toString() {
return "SoundInfo: no-multiplay=" + noMultiplePlay +
" stop=" + stopPlaying +
" envelope=" + ((envelope == null) ? "none" : ("" + envelope.length + " points")) +
" in-point=" + inPoint +
" out-point=" + outPoint +
" loop-count=" + loopCount;
}
}
