/** 
 * Smoking Wheels....  was here 2017 yybvhmyjmqmqirlebwqgqfypoosapxdpdcdlosluvavglnsd
 * Smoking Wheels....  was here 2017 mbuldztifdjfblpoatjemxqhutrpcppwprgptcdegauvsvhk
 * Smoking Wheels....  was here 2017 slyvtqihyulizxbbykbulqeqmgjehnnpovbntrzcwsjdlcrq
 * Smoking Wheels....  was here 2017 bwqaljcvvlicbdvlqxzfeodlbfudkxdrcxbpivvqipsucvma
 * Smoking Wheels....  was here 2017 jlcevirrhjzwlibobprzlaltecbcwgzilmbqqeubmiiqitja
 * Smoking Wheels....  was here 2017 rkzvtwwyazphrajqnbawktevsqqwkjsxfjepapfynwwuezjf
 * Smoking Wheels....  was here 2017 elarhqvwvzqekzkbpcztjotgutfoygkdcqrragubvlfpvrso
 * Smoking Wheels....  was here 2017 mhhtunzayjsqqfgmztxyxquuwqtoudhxdqdjmnilblqrtkxg
 * Smoking Wheels....  was here 2017 iccfvrwetguapzbvtlkwxicnptjmiovjrxilobzkdqmvqwrr
 * Smoking Wheels....  was here 2017 udbpglkkwdbysvkifqfikgwrvundihuzdhivnsclexngmebm
 * Smoking Wheels....  was here 2017 bzxpdnszfszhslzhugkfujkvusyrshekjwmtzpilqnqfmmhq
 * Smoking Wheels....  was here 2017 tlsfwtdlzyedpwvmjhivptkvurmkswgnkyittenicwajdkwh
 * Smoking Wheels....  was here 2017 orvrzhionaqvnkdtycmqsurqofkyuolnmcqnzbunnrcocpmv
 * Smoking Wheels....  was here 2017 pxtmjmdlnjnzznlhthsifekozycerbpveenbzdolaxoxjefy
 * Smoking Wheels....  was here 2017 bujibbsjwsglszmojqcylsweevgfhkpcffgojmjzatiseigp
 * Smoking Wheels....  was here 2017 ocqelujvrzniqvhenfxrzpugpdujxwugqpknxodceqprzocw
 * Smoking Wheels....  was here 2017 vxzicxuqlkhazhbbhksarfyvvfxhzypmsvurtzaekgvolsmg
 * Smoking Wheels....  was here 2017 wowfvtuwsksbgxhjyshrpfnfwvbuekveaumagqhruprnpsmj
 * Smoking Wheels....  was here 2017 zqdpuzoumrfjcktozzurckxztxxzmhlahnstyqrluvbxqwge
 * Smoking Wheels....  was here 2017 syvkhlkyvfmanvkhfikfuaqvzrjgdvrxojdkskymblehariu
 * Smoking Wheels....  was here 2017 voixwizdeemjtkomqautmjqxeorepnbacwnqpnicncmomxmr
 * Smoking Wheels....  was here 2017 iucplzdkfaiafsqhnqschdblfgeqpehulwxmzycwgsqvyoqm
 * Smoking Wheels....  was here 2017 ngzecbaavlovqllclbfdnffzgsrsatkwjmqemuyoroplrxcd
 * Smoking Wheels....  was here 2017 ytbqclzodkuxaqyqdiqeurtjtdzuenqeyygdwlsfnbmabljv
 * Smoking Wheels....  was here 2017 ijpecgruobypnojuqtnqyznphyjlmamwjxoegmmcpxvjxzex
 * Smoking Wheels....  was here 2017 tkfiyxyutyfoqrgtgxshasryuxgnqaskfeqfzwsvcbfqdlmb
 * Smoking Wheels....  was here 2017 mlqvrawuqrbocvixmqeclvpalxhermhkgvtmrsyclrqeyeog
 * Smoking Wheels....  was here 2017 ahaprmxkjgeuvzpycziitjwopekssslvnemndkcbgghpvrxq
 * Smoking Wheels....  was here 2017 dbpxnlpjhwlnbkhtdhrjtuiqyevuhfsvgurzlphxlmosmrhp
 * Smoking Wheels....  was here 2017 xbyfbhwtcybkhpxnwezbpsfnjoyfdtvubmixzdwgdherxesw
 * Smoking Wheels....  was here 2017 owxhjqvwsenififsvkkipautaimcdhulqjuniemvuxauhlig
 * Smoking Wheels....  was here 2017 qimbujvfgokjtqexvbekjvseiqjvoewqbsqghdysauhtbbtb
 * Smoking Wheels....  was here 2017 ylauxrnqdgtvetbcvmxtsovtxztzwvmpodpwzplgtomizsrp
 * Smoking Wheels....  was here 2017 mpcyowtcatrkxeikdgjdsviwrzcktblssmujtmiwcgeqakbo
 * Smoking Wheels....  was here 2017 njlhvqrzurpwssuhhdqnuonzurbgfxsqhuoyexfmmbkcjmfx
 * Smoking Wheels....  was here 2017 qoftcwpupbhknikjbhadlvayqfpvkppihjjdbhzapjhfnjpu
 * Smoking Wheels....  was here 2017 ngrpyqfhvbphoikplzbmnbttxbxtwqnxzvcpoftwhxhydwzp
 * Smoking Wheels....  was here 2017 htiiekiofdsfgfhcuvohewvtmxjxhugwyzuizqwnsrcigziz
 * Smoking Wheels....  was here 2017 dqcpxucxoydyksvjoqqmseolmssipbuuywtpyqzuiuptazxy
 * Smoking Wheels....  was here 2017 ruymlrxvcnmqwwazolnjrbpqirwmbtkqzwnwgqyrstavyjfp
 * Smoking Wheels....  was here 2017 pfgdkejdezsryxcyuqvjzzwjsgawciopinyvzgxnvgujsxai
 * Smoking Wheels....  was here 2017 agmbrriwlvapbknjpsifrnkymcpkmpaanrannkfwugonhpgw
 * Smoking Wheels....  was here 2017 dmozgvyivsuhzbcskocycpqwvfgecntqjjdekemmaxipysfc
 * Smoking Wheels....  was here 2017 oslxnoncnquwpxupbgmtwiezduyngkbjwzufnzpldsfgbujf
 * Smoking Wheels....  was here 2017 zbnbcytwvuwrdfwypczcvdxibfwbisjihavkylrzcjrhknnp
 * Smoking Wheels....  was here 2017 mvhxuknumohicnuzgqkszpxenhlrcgmzejhtamcsaukwyzoy
 * Smoking Wheels....  was here 2017 hooernwcjtkrfnibptwquqobqxjlmajyibmkhflkheiiwlve
 * Smoking Wheels....  was here 2017 adlwdhfipfyvjhlwjmqbtknuvgosshhfskyyrarbpaqgrjvk
 * Smoking Wheels....  was here 2017 jpffstehpfvcwaljpdgltfpksufdgotxrbobfnuawztnbnfd
 * Smoking Wheels....  was here 2017 jglqhipbbdgechuqpjpowuzegftmvolkrthrgqhueajfyzbz
 * Smoking Wheels....  was here 2017 isyyxqrwvtrvwwgewxqilzaspnwykjkmnqncknrfyikspxow
 * Smoking Wheels....  was here 2017 utsbyprhczsfaruqewtbcyitcvmvfewyhztummxhwjaqmwgy
 * Smoking Wheels....  was here 2017 mndgahidgairwbqxoolepbtilrutrojaejvmogbivvsuiqwr
 * Smoking Wheels....  was here 2017 mhtzxeklyhtvvnjdipokcxltnrfpnfpdtqvdaqnwzrdhbfkr
 * Smoking Wheels....  was here 2017 aqizswclcoinquqvytduwlupmvlksfoxtwzzlvxrscgnwwdy
 * Smoking Wheels....  was here 2017 rjzgufstusvvgxmogdnmpujpsikpmuoihjynqfcwsnebhcmo
 * Smoking Wheels....  was here 2017 dpaatkydnydexceifbgabicwypithmamoslmsjervsjuaqgz
 * Smoking Wheels....  was here 2017 oryskuqrwtlcaxefedcciraqzjosvzswdtpvagpqgnovzolw
 * Smoking Wheels....  was here 2017 ccpdvzwpuvemjcgspcesusplapwpcjqctnrudywpjgqmlbgd
 * Smoking Wheels....  was here 2017 jsafkyblkcblwrjlicucaqkdmldthxbcmjgwxwyovgujvsgz
 * Smoking Wheels....  was here 2017 cqoertvcduyhswujilltwuitzjpvwblapwdulqyuniljwgcu
 * Smoking Wheels....  was here 2017 hdtonvanphcslgaqxrzikumnlcppoqnipvjnadexqihonrwg
 * Smoking Wheels....  was here 2017 ivkbauuatjymsnuqprmxzpgbznxgipjrhihhhoiqpnhiagtg
 * Smoking Wheels....  was here 2017 qnoqmnldsycsntdbemfregfcbxkcjgdzrslpcfgczipgungz
 * Smoking Wheels....  was here 2017 ahooodsrwfpvbdgvqktcvfhsirisecjkanqdmubmslrfpfdw
 * Smoking Wheels....  was here 2017 nmyhacjsxqnkvgqcibyxbcofqobalwvixqxyudckzvegkiko
 * Smoking Wheels....  was here 2017 kpnozyomrxjgmvchrftceukddkhcdqmmbbpfqlaqeravjehz
 * Smoking Wheels....  was here 2017 fojivqrnkzumbwocozpxtkmghnzhmpoundhlwbsfylkmaghi
 * Smoking Wheels....  was here 2017 sjtwchislbtnsqhkyszurjqpsihfyhpipmsiophmevvbahez
 * Smoking Wheels....  was here 2017 ykhqqhjzlokxyrukcyrnzhzmhnrtgmipuxzxbzbxatwsjhwp
 * Smoking Wheels....  was here 2017 eetiogysjfenlsvmpmvacbxlfauyiftgwljiyjthxmntgpsd
 * Smoking Wheels....  was here 2017 xoeaecklhzvmeujielronvahwapekrcfwlmdbbdtljyueqds
 * Smoking Wheels....  was here 2017 ypxvczkxqaedjdrwxcvqdzeaxbgbykwpbmcbmujmpfqsvfxv
 * Smoking Wheels....  was here 2017 irnidfuecunbmhfgacayadoafsfmrfuxzkhbokwclxepeiab
 * Smoking Wheels....  was here 2017 ihtfkmsnnafcgzuybfklnelszadmpbxskfijxaejlqoulgsk
 * Smoking Wheels....  was here 2017 khtlgrmocqylqginvnflfgozoezlvglakivmibfigxzybmmy
 * Smoking Wheels....  was here 2017 lttggxtzfwrjvjdzijaiyurwqoyaxfwyegocydchtjvwutce
 * Smoking Wheels....  was here 2017 kajegplxncpnhvrmvirxvizpcykzovzyhwpgbdeubzvrpdnt
 * Smoking Wheels....  was here 2017 prjwjipqxccstjrjxefdewutdgcmrzsqnegcifcqqyxtqwao
 * Smoking Wheels....  was here 2017 nmvjwbpqotxceaekgbyfpmudcrxxobjzwobentsvcsfrlmct
 * Smoking Wheels....  was here 2017 ypbwkwctwiyauclmzfkrxovurrcuplkcrpwftjerjzfirrmv
 * Smoking Wheels....  was here 2017 ygpwuezbmfkbbawthikffsaztyaaoapmkbreizvspsptinej
 * Smoking Wheels....  was here 2017 tchccpithdrcrpipucbvwxsgmkjsksytwbwhxshuechjqgli
 * Smoking Wheels....  was here 2017 yxensanmlbngpwstfspslfolgidfhvqubxyahxlxtpltaktx
 * Smoking Wheels....  was here 2017 gunkfpfykeuvbbicolqjtakotcldtwgwhesdphjigxnufsvm
 * Smoking Wheels....  was here 2017 rbzfksfhtxslnrqvdvzoyzkwwkuimplhcshpcqnquyfoffts
 * Smoking Wheels....  was here 2017 phhqkzrskzrasmkinuqghayztguxlzhufpxqlelqvxlkedrn
 * Smoking Wheels....  was here 2017 linsoiaunilppmqhkhzqlforuvkfvjahscesmhbiyikyoaec
 * Smoking Wheels....  was here 2017 aezqlwuindxnjznqwtnffyeyqovwdfcxvvxpgolacumbepxw
 * Smoking Wheels....  was here 2017 jgfxxzwjbxflmmqndrcssxycfemrbhhdcpdgdxahliluxyym
 * Smoking Wheels....  was here 2017 ubcgahleahwfrssiuxtdgyesroavppoojnexrljwiceozgnv
 * Smoking Wheels....  was here 2017 tlpqesuingmxyrruqnuskfookzlpxkfdowobtpjwlpvzwbcd
 * Smoking Wheels....  was here 2017 cmchwkppaaaxlrwupwuxbcxrbwxrmfsbzgdkmzdnslwvgdlu
 * Smoking Wheels....  was here 2017 undsarsbezsurfsnannlhfijoxvvbvusfmzydmbkfrahemol
 * Smoking Wheels....  was here 2017 dcmqsghyvwykiayjlgcikmgdabxfofmtzqjxigthlldqujsb
 * Smoking Wheels....  was here 2017 rbfagyqwfqjyjeqzpeutbahwxnbegrzdjavtyqcgzemophit
 * Smoking Wheels....  was here 2017 elrdgykoqmzqbwzioqefaehnusmhorwaoffgahfouqlxhafz
 * Smoking Wheels....  was here 2017 qqkkopmcvwyfuqnpoebmlrjkqkpmfzuvdbpixdltysrsvoij
 * Smoking Wheels....  was here 2017 jeepfoztrlrkigyddpmmpixcomcuequexqghfhkqxqejkeyx
 * Smoking Wheels....  was here 2017 xwcspthchfwkqsgqcatmdinizeypqxdawgtotdagivcnokor
 * Smoking Wheels....  was here 2017 zvlxigzycjloygtalslxwzcfoxgnchgogmwxqhjwcbxzyzxe
 * Smoking Wheels....  was here 2017 riutemyguiqlrmwmmijoxatafknkgnzerdsgeqvcjefwoyza
 * Smoking Wheels....  was here 2017 gayxhbijfuvynbjkrqpknhvgapkicqgnvhpwzjbqnlanonbd
 * Smoking Wheels....  was here 2017 frzjywmwotsdnagmwtkqkxztlswsuxioviagxvwpfimomfpr
 * Smoking Wheels....  was here 2017 jiejvcamejfkwrupbyjtigcndeacwvslwtvcaqkgkmavavid
 * Smoking Wheels....  was here 2017 skckrbvgucohzmmynuhmkagxzrjjzedonkckrsbdewjmdjhc
 * Smoking Wheels....  was here 2017 nkofqlbngqdtqfayuefuzbvkdepqcxppnkckmflbzrjuactm
 * Smoking Wheels....  was here 2017 jeptbczvtyrvtxlhrdmyqmluawofmjjmzalofmkbkjildmdn
 * Smoking Wheels....  was here 2017 zuohnfixqgawovzvdzrketaegfntpbyjcvwqadcllqoggifp
 * Smoking Wheels....  was here 2017 koafvcxwpymmnlctmhnytkpvuyxccraslrmofdvselvhhpaj
 * Smoking Wheels....  was here 2017 ycsjclwzntjojnqngxdlrkpgsyjjzgqctqppkoiraaazmqtt
 * Smoking Wheels....  was here 2017 cetrreoupplfbcmtfxufnwrhlkvwmcancatgkvjjqsjxgxyy
 * Smoking Wheels....  was here 2017 qxljdiqbetqtulykkpcsdepyrwngarrdsltfiocdyihxkdii
 * Smoking Wheels....  was here 2017 poixijxwypcubbnqbpvsqypohyvjjuiierqmmqymctkcukwp
 * Smoking Wheels....  was here 2017 gufbiwomuvheoryvuqacjczqlqmilkavfutgmflelftvsywq
 * Smoking Wheels....  was here 2017 djevnuylwlwbfjfshwaewtjymcjlmvzmxerbfqnhrekspgur
 * Smoking Wheels....  was here 2017 akmjlfqppqutiiodqpkkzhqpdvsjynrmmieprpgdsgxqecjb
 * Smoking Wheels....  was here 2017 yetfzopypvfxhcmibkynwjyvhmxxogxgnchwgzbgrnwqkmqn
 * Smoking Wheels....  was here 2017 fhtcelwtuspiwlsrdcrmuwqfbarfgcpmspkcowojzbfcnsvy
 * Smoking Wheels....  was here 2017 goozjtwqigqdzkiwqtzojxhnxryqggabedztjrppgkeqxgkm
 * Smoking Wheels....  was here 2017 ybmbfqehpqfswemuosjflxwvkvwubgsddgxovbhflfeckxdo
 * Smoking Wheels....  was here 2017 hdcxmmswhjopairpenqedlkkngymjwkeeufnhwasrlxpwqbx
 * Smoking Wheels....  was here 2017 nidehxophbctcpsubawksmiukwtwdcbvzvfvhhkzjhgmotij
 * Smoking Wheels....  was here 2017 fmtwzvcassmeczoyzhjdvcgtkvigpfyarslarrizdfljysoc
 * Smoking Wheels....  was here 2017 drffdiyyzorhfumayqrxhsakfruiernxlztvoqxayxxctijp
 * Smoking Wheels....  was here 2017 ifbsqwzkuzwrymyffrqjfytztapvqipwxlddhdnswihuxpwm
 * Smoking Wheels....  was here 2017 arcbmaiszrmezvrxiehnxrwbdwlzxdequfzhlgttjqourtfr
 * Smoking Wheels....  was here 2017 twlgcsjktreyhxstcfyqzbylukgbfjkdcquswjnfbjxsljyi
 * Smoking Wheels....  was here 2017 jxinabsgmbyhbwirnedehmvciberaowldfjdqdxlxctkadvw
 * Smoking Wheels....  was here 2017 uckjdlfhvkxvviyxwpswwosksossakhcmvvoblixzxuyhcvz
 * Smoking Wheels....  was here 2017 kajmmnawsinkgyitrhsrcfywbwmhgzrrvnlevljlsxytnnep
 * Smoking Wheels....  was here 2017 qmjxlemmfuneivnzsimvpncgtclsvnfcgqtnrnwbuojjexkw
 * Smoking Wheels....  was here 2017 iorupnfyvztkfftmbbmwdycrmuuqhompztpgtgaccoosyafe
 * Smoking Wheels....  was here 2017 mpwruzcieklulomkxbqlvbbjdqywiweopraljqectxdvuxrf
 * Smoking Wheels....  was here 2017 kesgbehvdraesrmevdxobuiwxnpoxkiqwmigcryuftbcytzy
 * Smoking Wheels....  was here 2017 pbinvzccwvepyptlqirmjhnacrrbgldtvncewwehboodwdpm
 * Smoking Wheels....  was here 2017 vkzspnfwuavmknndhbmqpwnvlpjyvndbsidyruavhazuhuig
 * Smoking Wheels....  was here 2017 dlfihfleosejnzhmcucuwfmpvxdbhkbactmowjvaydcedtex
 * Smoking Wheels....  was here 2017 vvxbysyiborebuvuplqymgtwkqposcwhswlgcsgonatqqgik
 * Smoking Wheels....  was here 2017 jjaxxwbxlpyzyxcvoajhcayloxsufvwtqzpleedpqdfthuix
 * Smoking Wheels....  was here 2017 pdycuulrdyyejpjmzwvhlaxiyfsiheoqcrtydmqjfgwlteyu
 * Smoking Wheels....  was here 2017 mkfclyyqtcxhvjdwepxtsuuwmfyarvphquysklbkigjtbkcu
 * Smoking Wheels....  was here 2017 jvqrxxsdfsfgbzdmrzpoegzpixeaivckbkmynfcnmjtbjsbt
 * Smoking Wheels....  was here 2017 sdgunocsruodzmjygcfamocgwmhrlmfxjuzdifotgbcyeqjx
 * Smoking Wheels....  was here 2017 jnkqycrdomwhwdbexiiplcyytjmonfmzwpeaybpkpzwiexsq
 * Smoking Wheels....  was here 2017 hfptyvkmmhjhdktjxeuzdmtyxhfnfwqaaoeorppaqcugipdp
 * Smoking Wheels....  was here 2017 uvrwrmjzjwlcmbdxvmofxquuldcsokrsrvgbdadkuqtdwxwt
 * Smoking Wheels....  was here 2017 kesxkwxgjeusxdgmljaliqshufelscwyvszxdsdoraymgkkg
 * Smoking Wheels....  was here 2017 xiadtdrawkinqxiatcsghxllpwnjemryttewvgsugyvgfumm
 * Smoking Wheels....  was here 2017 hpcbpsnknbhecwwqahmhvcaouvqhqgwbzvxympeqpkbnrccd
 * Smoking Wheels....  was here 2017 wpvjzfpqgtblbtqvvshoibxfmcejcnlzhyljrvfyfnopxqnd
 * Smoking Wheels....  was here 2017 edfagmggemjnlpofxnoijyqfcubxtlqqsmjoikrrqvodivfr
 * Smoking Wheels....  was here 2017 yhpiatdctmcrlryshztatecngknnbqxfozmhmwrewylzrnyc
 * Smoking Wheels....  was here 2017 gjnschcepdlppmhnhrskqilmxryctucbhhwomeozawxfxrsd
 * Smoking Wheels....  was here 2017 jyuxqvfupdwcouhaklolhibqelbstxcysmvpylawmuxffotr
 * Smoking Wheels....  was here 2017 tvlxwfynynahhqaxkimjihnumattiifsvvxvqawxxeppdsnx
 * Smoking Wheels....  was here 2017 hdwympwcakwmbfqcisdrqqrzluguymyozzxbtqgjfrlfhwwf
 * Smoking Wheels....  was here 2017 xfnmgivpmhpjgbsslcicfztlamyrgdzwqtwencnvohddsash
 * Smoking Wheels....  was here 2017 yohgiczhfvptrzyghjbomeauhaoohjkjpdenpohajeotpmhb
 * Smoking Wheels....  was here 2017 yafhztrtjzotgyjiqoqjzkdusqztfkkxxohmvkmafvxrjtds
 * Smoking Wheels....  was here 2017 qrotwlotkzmsefevnarypbznytlwntmsuncvhhedbxqsvoap
 * Smoking Wheels....  was here 2017 axydupmixglgxiyafizbjtqfwbjuxdjevxqoibtwbklawywl
 * Smoking Wheels....  was here 2017 medevtpuumzffaifghorrjnlpnkpjqczutewmxvbpmfysdyd
 * Smoking Wheels....  was here 2017 lkfxjxfsgqssahjekztacbgzpjnqcmxarjigqfhsioebwsuv
 * Smoking Wheels....  was here 2017 sqmmycavqxpcolitsscplfrxmawooehlujxlxogddktgzjcz
 * Smoking Wheels....  was here 2017 jemkluvequuzhzrckclcwlxnedyemnytqoxkpxbxfypqcdxg
 * Smoking Wheels....  was here 2017 pqbkxouccxteyqdsbxvoqqjhvtjpvlynzzrkhijtyjrnjhlo
 * Smoking Wheels....  was here 2017 augmsjhdggewlluflhndjzpcvzbfuhntxatxvgbuzdeohjeb
 * Smoking Wheels....  was here 2017 jtiwlhybmzzjarunomejyuoyvihovocnqfzpigeffxnopbxe
 * Smoking Wheels....  was here 2017 qvyayspxkqjgdvrutdmykthctmkpszniskkndiervsjsekpo
 * Smoking Wheels....  was here 2017 dpushhkzxvsloqemlapxctgdsjeijosuyqixumqxersgisnd
 * Smoking Wheels....  was here 2017 lwawvxsvfnuzeeifmgulpxzwdflezpywihieefmyygrxmldc
 * Smoking Wheels....  was here 2017 gtxsesdfrylhgrixxcpaupjhsmlrcpsrdwecictcaeslijev
 * Smoking Wheels....  was here 2017 pozucbofyoxxfpsuyfwjtmothvouihurxgyqrbwxokmzwmsa
 * Smoking Wheels....  was here 2017 vwcutqddzzpsvuefejqnulxsafonttcnlmybsekfzbzxicxp
 * Smoking Wheels....  was here 2017 klhsmhemvgfvzfuxipfqnpbbjwigmezcswtujxiyysjvcris
 * Smoking Wheels....  was here 2017 dlxtveibznrqzcssliegujwtxebqbbwqabeqqvrnhybozart
 * Smoking Wheels....  was here 2017 bdllqqlxbheqgbnwvbhcrileoxdmdgmnyugmywvkgtsfxcyl
 * Smoking Wheels....  was here 2017 kdtlajsizedumtxtyqrcmleunzixssxkefhqvdlkejifcfkr
 * Smoking Wheels....  was here 2017 tgwvigkwxegergwbqdpowvrkdpnhasigupvoebjptfbczwoq
 * Smoking Wheels....  was here 2017 vnctdkghenmcavrryxqxqvucdfwemsgebntzafsfvyishuds
 * Smoking Wheels....  was here 2017 riashearmpyfzyvubmowwcrdinwmvolqnvawtnwwppufaacp
 * Smoking Wheels....  was here 2017 qfllwhxhtccjijbuormmyosbymehafwhypalxdlhmhlxjvte
 * Smoking Wheels....  was here 2017 dakxfogscbrrydjkgprxkhmrigtyizuaidhfjkiocnllusoq
 * Smoking Wheels....  was here 2017 augkxdrsypnmcnamdosrdtxaeisbdhrbzaqwfzpzizgqalhk
 * Smoking Wheels....  was here 2017 hwmivlaiyfxkfzlgldkmenbkijnneziulccluurbkpmqzzxe
 */
package net.yacy.kelondro.util;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.NumberTools;
import net.yacy.server.serverCore;
public final class OS {
public enum System {
MacOSC,  // 'classic' Mac OS 7.6.1/8.*/9.*
MacOSX,  // all Mac OS X
Unix,  
Windows,
Unknown;
}
	public static final String blankTypeString = "____";
	private static final System  systemOS;
	public static final boolean isMacArchitecture;
	private static final boolean isUnixFS;
	public static final boolean canExecUnix;
	public static final boolean isWindows;
	public static final boolean isWin32;
	public static int maxPathLength = 65535;
	public  static final Map<String, String> macFSTypeCache = new HashMap<String, String>();
	public  static final Map<String, String> macFSCreatorCache = new HashMap<String, String>();
	static {
		// check operation system type
		final Properties sysprop = java.lang.System.getProperties();
		final String sysname = sysprop.getProperty("os.name","").toLowerCase(Locale.ROOT);
		if (sysname.startsWith("mac os x")) systemOS = System.MacOSX;
		else if (sysname.startsWith("mac os")) systemOS = System.MacOSC;
		else if (sysname.startsWith("windows")) systemOS = System.Windows;
		else if ((sysname.startsWith("linux")) || (sysname.startsWith("unix"))) systemOS = System.Unix;
		else systemOS = System.Unknown;
		isMacArchitecture = ((systemOS == System.MacOSC) || (systemOS == System.MacOSX));
		isUnixFS = ((systemOS == System.MacOSX) || (systemOS == System.Unix));
		canExecUnix = ((isUnixFS) || (!((systemOS == System.MacOSC) || (systemOS == System.Windows))));
		isWindows = (systemOS == System.Windows);
		isWin32 = (isWindows && java.lang.System.getProperty("os.arch", "").contains("x86"));
		// set up maximum path length according to system
		if (isWindows) maxPathLength = 255; else maxPathLength = 65535;
	}
	public static String infoString() {
		String s = "System=";
		if (systemOS == System.Unknown) s += "unknown";
		else if (systemOS == System.MacOSC) s += "Mac OS Classic";
		else if (systemOS == System.MacOSX) s += "Mac OS X";
		else if (systemOS == System.Unix) s += "Unix/Linux";
		else if (systemOS == System.Windows) s += "Windows";
		else s += "unknown";
		if (isMacArchitecture) s += ", Mac System Architecture";
		if (isUnixFS) s += ", has Unix-like File System";
		if (canExecUnix) s += ", can execute Unix-Shell Commands";
		return s;
	}
	/** generates a 2-character string containing information about the OS-type*/
	public static String infoKey() {
		String s = "";
		if (systemOS == System.Unknown) s += "o";
		else if (systemOS == System.MacOSC) s += "c";
		else if (systemOS == System.MacOSX) s += "x";
		else if (systemOS == System.Unix) s += "u";
		else if (systemOS == System.Windows) s += "w";
		else s += "o";
		if (isMacArchitecture) s += "m";
		if (isUnixFS) s += "f";
		if (canExecUnix) s += "e";
		return s;
	}
	public static void deployScript(final File scriptFile, final String theScript) throws IOException {
		FileUtils.copy(UTF8.getBytes(theScript), scriptFile);
		if(!isWindows){
			try {
				Runtime.getRuntime().exec("chmod 755 " + scriptFile.getAbsolutePath().replaceAll(" ", "\\ ")).waitFor();
			} catch (final InterruptedException e) {
				ConcurrentLog.severe("DEPLOY", "deploy of script file failed. file = " + scriptFile.getAbsolutePath(), e);
				throw new IOException(e.getMessage());
			}
		}
	}
	/**
	 * use a hack to get the current process PID
	 * @return the PID of the current java process or -1 if the PID cannot be obtained
	 */
	public static int getPID() {
final String pids = ManagementFactory.getRuntimeMXBean().getName();
final int p = pids.indexOf('@');
return p >= 0 ? NumberTools.parseIntDecSubstring(pids, 0, p) : -1;
	}
	public static void execAsynchronous(final File scriptFile) throws IOException {
		// runs a script as separate thread
		String starterFileExtension = null;
		String script = null;
		if(isWindows){
			starterFileExtension = ".starter.bat";
			// use /K to debug, /C for release
			script = "start /MIN CMD /C \"" + scriptFile.getAbsolutePath() + "\"";
		} else {
			starterFileExtension = ".starter.sh";
			script = "#!/bin/sh" + serverCore.LF_STRING + scriptFile.getAbsolutePath().replaceAll(" ", "\\ ") + " &" + serverCore.LF_STRING;
		}
		final File starterFile = new File(scriptFile.getAbsolutePath().replaceAll(" ", "\\ ") + starterFileExtension);
		deployScript(starterFile, script);
		try {
			Runtime.getRuntime().exec(starterFile.getAbsolutePath().replaceAll(" ", "\\ ")).waitFor();
		} catch (final InterruptedException e) {
			throw new IOException(e.getMessage());
		}
		FileUtils.deletedelete(starterFile);
	}
public static List<String> execSynchronous(final String command) throws IOException {
final Process p = Runtime.getRuntime().exec(command);
return execSynchronousProcess(p);
}
public static List<String> execSynchronous(final String[] command) throws IOException {
final Process p = Runtime.getRuntime().exec(command);
return execSynchronousProcess(p);
}
private static List<String> execSynchronousProcess(Process p) throws IOException {
String line;
		final List<String> output = new ArrayList<String>();
		
		try (final InputStreamReader streamReader = new InputStreamReader(p.getInputStream());
				final BufferedReader in = new BufferedReader(streamReader);) {
			while ((line = in.readLine()) != null) {
				output.add(line);
			}
		}
		
		try (final InputStreamReader streamReader = new InputStreamReader(p.getErrorStream());
				final BufferedReader in = new BufferedReader(streamReader);) {
			while ((line = in.readLine()) != null) {
				output.add(line);
			}
		}
return output;
}
	public static void main(final String[] args) {
try {
List<String> v = execSynchronous("/usr/local/bin/wkhtmltoimage");
for (String r: v) java.lang.System.out.println(r);
} catch (IOException e) {
}
/*
		if (args[0].equals("-m")) {
			java.lang.System.out.println("Maximum possible memory: " + Integer.toString(getWin32MaxHeap()) + "m");
		}
		*/
	}
}
/*
table of common system properties
comparisment between different operation systems
property           |Mac OS 9.22           |Mac OSX 10.1.5        |Windows 98            |Linux Kernel 2.4.22   |
-------------------+----------------------+----------------------+----------------------+----------------------+
file.encoding      |MacTEC                |MacRoman              |Cp1252                |ANSI_X3.4-1968        |
file.separator     |/                     |/                     |\                     |/                     |
java.class.path    |/hdisc/...            |.                     |.                     |/usr/lib/j2se/ext     |
java.class.version |45.3                  |47.0                  |48.0                  |47.0                  |
java.home          |/hdisc/...            |/System/Library/...   |C:\PROGRAM\...        |/usr/lib/j2se/1.3/jre |
java.vendor        |Apple Computer, Inc.  |Apple Computer, Inc.  |Sun Microsystems Inc. |Blackdown Java-Linux  |
java.version       |1.1.8                 |1.3.1                 |1.4.0_02              |1.3.1                 |
os.arch            |PowerPC               |ppc                   |x86                   |i386                  |
os.name            |Mac OS                |Mac OS X              |Windows 98            |Linux                 |
os.version         |9.2.2                 |10.1.5                |4.10                  |2.4.22                |
path.separator     |:                     |:                     |;                     |:                     |
user.dir           |/hdisc/...            |/mydir/...            |C:\mydir\...          |/home/public          |
user.home          |/hdisc/...            |/Users/myself         |C:\WINDOWS            |/home/public          |
user.language      |de                    |de                    |de                    |en                    |
user.name          |Bob                   |myself                |User                  |public                |
user.timezone      |ECT                   |Europe/Berlin         |Europe/Berlin         |                      |
-------------------+----------------------+----------------------+----------------------+----------------------+
*/
/*
static struct browser possible_browsers[] = {
{N_("Opera"), "opera"},
{N_("Netscape"), "netscape"},
{N_("Mozilla"), "mozilla"},
{N_("Konqueror"), "kfmclient"},
{N_("Galeon"), "galeon"},
{N_("Firebird"), "mozilla-firebird"},
{N_("Firefox"), "firefox"},
{N_("Gnome Default"), "gnome-open"}
};
new:
command = exec("netscape -remote " "\" openURL(\"%s\",new-window) "", uri);
command = exec("opera -newwindow \"%s\"", uri);
command = exec("opera -newpage \"%s\"", uri);
command = exec("galeon -w \"%s\"", uri);
command = exec("galeon -n \"%s\"", uri);
command = exec("%s -remote \"openURL(\"%s\"," "new-window)\"", web_browser, uri);
command = exec("%s -remote \"openURL(\"%s\"," "new-tab)\"", web_browser, uri);
current:
command = exec("netscape -remote " "\"openURL(\"%s\")\"", uri);
command = exec("opera -remote " "\"openURL(\"%s\")\"", uri);
command = exec("galeon \"%s\"", uri);
command = exec("%s -remote \"openURL(\"%s\")\"", web_browser, uri);
no option:
command = exec("kfmclient openURL \"%s\"", uri);
command = exec("gnome-open \"%s\"", uri);
*/
