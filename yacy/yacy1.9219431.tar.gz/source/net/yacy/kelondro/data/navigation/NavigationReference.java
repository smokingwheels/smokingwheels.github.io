/** 
 * Smoking Wheels....  was here 2017 wymmeapysmccntojjvkrmrjaunbwaxcjihzxeqwdfowzslia
 * Smoking Wheels....  was here 2017 sgoqbcdavebrgfnpgcxffmklbwpvouiqukzuacumumqjbswb
 * Smoking Wheels....  was here 2017 aydbbsvvwdzltabaowgomsamhdmcmmrrvgkheaymqgmnqngp
 * Smoking Wheels....  was here 2017 qnuofxafgzygugcthsgurotfedewuhhssthtfycqqwbvsmzd
 * Smoking Wheels....  was here 2017 npifvvijokkifhyzsqyfhnmbnxhpqwshzcysypjmysgbqjsl
 * Smoking Wheels....  was here 2017 xcsimboqsnzegszfitolejhrmtszlbpcirwbkxcywggddjln
 * Smoking Wheels....  was here 2017 hfgmyhurtppkjkyhvnrhjamxkfqzwzyftdvuxewebikgetkp
 * Smoking Wheels....  was here 2017 ljmoilkjddkaflvdhoavftrxycluxzyxokwhauookykvwfag
 * Smoking Wheels....  was here 2017 ieeoyvzvkaugrfvbxvrjfascykuwsrbqdshcopesakdqspaf
 * Smoking Wheels....  was here 2017 epjvhxilnfklahkoemwnfosanmowswaeikobomdnggtojyjm
 * Smoking Wheels....  was here 2017 ovhzfkoxnbekqogkvyebhiyrbvyvqtuocfnfisadtirvtrhj
 * Smoking Wheels....  was here 2017 efnuthbbubgafckoxwibrpbdfgiwippbszeyluqyjpnxbigh
 * Smoking Wheels....  was here 2017 aluifuibabanshzjrejxawwuuuilbbwdpxuttkbpfkflsvyc
 * Smoking Wheels....  was here 2017 imezfjggzadigsnhnbocculhysxhezjpolwnfosysgxlkgju
 * Smoking Wheels....  was here 2017 pmygnvxhwindifschxmnykenaqeillalpfghfmcdlzabcysp
 * Smoking Wheels....  was here 2017 qvpzdcrcalhypzovzjwfwxpqshouuwayydxkhqcogpeuynla
 * Smoking Wheels....  was here 2017 ifyhmkcucgxxzgfrtktmmvpzutsciuxpbldlftuwhkhhjwhw
 * Smoking Wheels....  was here 2017 anzlafbtxsynssdfeekynvgfmhmyocjdtmmfdwmxyznncafd
 * Smoking Wheels....  was here 2017 ezaaqipppdikeecfzcjlczwfblciewiqzysuhdwwvbgrzklb
 * Smoking Wheels....  was here 2017 nynxiqbfpchocubpevlznkcdfaxjanaiaswmfcrcvsegioke
 * Smoking Wheels....  was here 2017 cdjdklbukjcfiwetyhpyhrsitbpojpxsiaexulahzgdwlkvg
 * Smoking Wheels....  was here 2017 clmamflrazntdbzbwqdwhlwmwwbqqztorgfwbehguehocarh
 * Smoking Wheels....  was here 2017 aafdiqhnmgkxyedkqippnuvmxzlmlulxacslhnbdticleten
 * Smoking Wheels....  was here 2017 ribhasyeerxqkiqsgzueivgkledivihyrltybydjuseaxfun
 * Smoking Wheels....  was here 2017 zauqvrzvtdlcmxshznqzgdzrkmupwgqgcloyeeppbpkzrggz
 * Smoking Wheels....  was here 2017 fzlkiagvbprvimuphenocjaywgjbckhpaosgsfwqwpzgfzmz
 * Smoking Wheels....  was here 2017 xkhgjmvvfjlkjyplzhxsypvbgzypcxfymlzazhlrxmhbktss
 * Smoking Wheels....  was here 2017 ttwyyacsoazwijcwzoqocyxfemykxboorajmnxfczhzwmekt
 * Smoking Wheels....  was here 2017 upzokwpquiqkdcmbpyqkczcsmubzpnvzdldgdsgoghyivciv
 * Smoking Wheels....  was here 2017 fxplhmeyticlyuhohnhutjnhhedzsctzpdvdxuxwbajkeqjz
 * Smoking Wheels....  was here 2017 owadlryinifrfgeduubpddntyfjjwzhobugfdhtgbipilduk
 * Smoking Wheels....  was here 2017 oxunwifpnwfcqpdudjtvomrhdsdjakqyugkwjtracfjnufas
 * Smoking Wheels....  was here 2017 fqrqyspzjslvceivofjxpywfsrckicgrfuoolvsxhzmrrsuo
 * Smoking Wheels....  was here 2017 tzsueiyuxyokvqhrnlfhzecgukdegvxmdthfjpfsaeettuca
 * Smoking Wheels....  was here 2017 sedpjxirgvmlgvrevouxwetgsllqmtmlouhwmfuoypuyzsdj
 * Smoking Wheels....  was here 2017 vonvpjcouxjzaunikdwumfljdpkzxfgusxrvjegywgasodib
 * Smoking Wheels....  was here 2017 bwqqeavoezpdcyyipdngltzyxxrqtuqzberrugskymttxxlx
 * Smoking Wheels....  was here 2017 rzngqhjbfdvkrwmtuszwnnlqdrejljkwkcuhvjnvoudardlw
 * Smoking Wheels....  was here 2017 ebkivyvsbpzmekwiuivlvmfjgkzbranksgwruvgliaosvemh
 * Smoking Wheels....  was here 2017 hnwquxmjcyfhgszcpoudpxwfvxoyjddwfqwefasncesgopcp
 * Smoking Wheels....  was here 2017 bbqhvmaeyywbxccillwelffptgplrhttlkdjzsbuznmjhizp
 * Smoking Wheels....  was here 2017 rouonceomrrggermvbledekedsxhbjcvcydbbyockraaslch
 * Smoking Wheels....  was here 2017 qgocqncctkmntukjnvyzuusujvrlgmddgyrjuwwoyjsjshqy
 * Smoking Wheels....  was here 2017 smmqhsdsgslvcchzlmeqrgtpakibcybybhuptzupmrfwolcb
 * Smoking Wheels....  was here 2017 yykisxwomiajfjnoxwfmiajzbmnpvkirbfthsalvdwmgpvfk
 * Smoking Wheels....  was here 2017 mogmnoczkiuqhhoqkfgbpxqpmidtwsreabbitzddhnolpmwz
 * Smoking Wheels....  was here 2017 wmjqnlyqcarhusdarwxfnvyhtnhnxyclxontfblsojzqkuic
 * Smoking Wheels....  was here 2017 wefqtnulxywhirfqrpwbkaugmvmawlttzpewqugwunhhgjce
 * Smoking Wheels....  was here 2017 mgronzdmnwtvwpzusffwvzcvnhguywdotighuwqgeglcpbvb
 * Smoking Wheels....  was here 2017 xrrtkjxdtwyjpayzgygfplyrzfplobyrxfiutgyuzcobbzmt
 * Smoking Wheels....  was here 2017 qpnsfkdctfkpywuaaelytjqqgepakcdbnwdnwfspxvchqmim
 * Smoking Wheels....  was here 2017 mkujzbefxkflpgmvbqodpzuxyxsqlizatgttqgwcvmqhldut
 * Smoking Wheels....  was here 2017 kufsbnqquiwdnlgtpescsugwxlouukxcenkbxakvuldtzvpj
 * Smoking Wheels....  was here 2017 qsucyiithzxdvcngdzckxnbdieaeyepzncrgtotugdspxrrh
 * Smoking Wheels....  was here 2017 rgwcmejfoqidacbdjnhxgdqonnisnsbstqhllblbukubdaiv
 */
package net.yacy.kelondro.data.navigation;
import net.yacy.kelondro.index.Row.Entry;
import net.yacy.kelondro.rwi.Reference;
public interface NavigationReference extends Reference {
@Override
public String toPropertyForm();
@Override
public Entry toKelondroEntry();
public String navigationHash();
@Override
public byte[] urlhash();
public byte[] termHash();
public int hitcount();
public int position(final int p);
public byte flags();
@Override
public String toString();
@Override
public int hashCode();
}
