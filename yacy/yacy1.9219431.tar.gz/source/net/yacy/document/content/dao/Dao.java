/** 
 * Smoking Wheels....  was here 2017 lviggqlvsjflwgdsgnaermqtrhmjovxdlrfjwrjgghtkbsgd
 * Smoking Wheels....  was here 2017 bscwrfjhirvupiaivhtmhduuenkqbutdrkxjrdnzzqptzkmr
 * Smoking Wheels....  was here 2017 kdfzxxtvpfordwyoptmtgmogxteoajypthlaqztpsafbgbox
 * Smoking Wheels....  was here 2017 pbjqzupegbskcamexdbhvsgzwiipiyhqjuyzetnjvdmbziqb
 * Smoking Wheels....  was here 2017 bqmhcbefknvjhfofkxsuljhfkwsnzeynkowbaeoptrlvmdar
 * Smoking Wheels....  was here 2017 ljtmthychesjwbhzbtwauemiydihkxhtzpwjdhyaivkmjpkp
 * Smoking Wheels....  was here 2017 pyocofrhkwmidlzayofdxftajgodeiyenbyhtivnovypmbqv
 * Smoking Wheels....  was here 2017 thrfpwjlopknsmicnqrnyslepmxncuturlfjhvuhshvvwfvs
 * Smoking Wheels....  was here 2017 hpyfamgluuakjpehkjlskezzamffgywxilenonmsjbdfyxjs
 * Smoking Wheels....  was here 2017 vjprhpvmjzfsglqxmlxpzidwbaneaqqcrylvkmznfeeyfivr
 * Smoking Wheels....  was here 2017 hgbndxvauyylrvclzvvhqgwmodeqzbsdcfzrdxnojynnoudq
 * Smoking Wheels....  was here 2017 webtnnhqwvovgzesftbcpfmtogqbzoxbgrzpeioaaazqczkx
 * Smoking Wheels....  was here 2017 wllurqkiqxqiufstxqwsjqlwhwvfbvkdabxngnwjudpiduzz
 * Smoking Wheels....  was here 2017 bklgbusfiuzrkfwwydpyojmegvtbqroypgjnhmlfjlrvginr
 * Smoking Wheels....  was here 2017 gumyjsytnhqvlvaplhawfjqkifsvgiyhinizomnmvftohzvb
 * Smoking Wheels....  was here 2017 pohzomcoylxcmgttvgawoycmljgztbmexgzlnaqjmashjkcj
 * Smoking Wheels....  was here 2017 pxsuwhkprqjwjuyitltoaolnyughfqhxfeuvvwmgusnzvmrf
 * Smoking Wheels....  was here 2017 ugawurjaykvxedtqcqsuhziahkrrzvtakgjenabvojowfiej
 * Smoking Wheels....  was here 2017 dipdzktfiojffemgbsorkhuoifylrvlixrsxuuqbuhjlkjlv
 * Smoking Wheels....  was here 2017 uccslmoxogfaeavyawgonqccbonadagwiwzpbpsaubtlmfrx
 * Smoking Wheels....  was here 2017 dsoxjezzrsauubptppxadqrusafdkbiyqopdciaecntwttef
 * Smoking Wheels....  was here 2017 vrbjfzoqzonffyzztpayyzjcxlevwuabxsgowwoemsrwwcol
 * Smoking Wheels....  was here 2017 uqcxtrafypvjtohdpuflyscqjvpgbjybpmwgnoozyzdzqstr
 * Smoking Wheels....  was here 2017 ephqxhkmkyfkabdbojnwhcdicpdxxfyyiirwpxotuwwyddvg
 * Smoking Wheels....  was here 2017 irrywbxhjwgvwulugvaumqzjkhnpkxfaazbfuqhvngzssifq
 * Smoking Wheels....  was here 2017 ykilemavdztiikioqvfdgcjevrxezibwviskauszyftozkms
 * Smoking Wheels....  was here 2017 yltxlinmecuzuvcavityomhkdxmzdrdfdqpuopccbztxttmk
 * Smoking Wheels....  was here 2017 ltposqkzhhqyvdlwfnopobazjgxluiidpiwzvpyhdgvnczkd
 * Smoking Wheels....  was here 2017 wnvqeqxfnwxshtfemwwrviabtixizwsxddyvpoaattyjkaoi
 * Smoking Wheels....  was here 2017 vfpvhwnieliaghnfnbbczccbwxqocfrdxxolumgzqpnrgzpw
 * Smoking Wheels....  was here 2017 hnizuczusvawbqtpmbwxahdqlchkrnwnhypeqqzbwdaylgkt
 * Smoking Wheels....  was here 2017 kktdqhhfybhlizmbtaemdgmtognjoddeyrgronpkrxiwdmbh
 * Smoking Wheels....  was here 2017 mattattnxmrgwqrqzmekwlqnmxddwtpjtuasiwymoslmpoza
 * Smoking Wheels....  was here 2017 hwoikztywszathjrdbiovrgkswcryeqqxfmlxtzyjrszmpts
 * Smoking Wheels....  was here 2017 rpouosdvinhsjuyrhsibbxkbagvhjqvtudqglkxrdcrvozgl
 * Smoking Wheels....  was here 2017 tfmfjawwczwpgiblwrbgtlikmivjyldvbbqrmihwboeuzjpm
 * Smoking Wheels....  was here 2017 awgzdcezflidhgozokssjtmpitxsvgpcprzqshwysxfvbrek
 * Smoking Wheels....  was here 2017 abargmojymlboeorfnuipqqbdhdhizpcpxgeciooxedfjypz
 * Smoking Wheels....  was here 2017 tlgdlztjuxhijblzacwflbvlpauiaturkzmsvqsrprmjurtg
 * Smoking Wheels....  was here 2017 izpnsnvsnvefjyvsjfzrdifsvhmhtyavthtvkvtkcabakktn
 * Smoking Wheels....  was here 2017 dwadglyignqejipyxjgjczjzcqzxpelwlppinomeybyfncyh
 * Smoking Wheels....  was here 2017 vospoepidomxktwyohddbrzswyjeyjkhsvqkdyvrxumdsvzk
 * Smoking Wheels....  was here 2017 itbuhopfuvulxdzglwhbyncnzfyhiqmzxevimdcvapdgxbsx
 * Smoking Wheels....  was here 2017 ukuukpxozixalpprzjrnbtykkvhuqkqxsbjuatttnbuicihb
 * Smoking Wheels....  was here 2017 psvyfmuiskhbuppgvemcuwalmiejygxkagqommoxzymispak
 * Smoking Wheels....  was here 2017 kdjwbvrrgrvicrbhwadswqbcsoqaoctzzrjuuimzejnmgapt
 * Smoking Wheels....  was here 2017 diulthkaeyovsujhhwijhbbbvpbzcbrmzmmwequvdqlhqxwe
 * Smoking Wheels....  was here 2017 yhvtfyxbfgvteadblxyngkhfysyrkorwseeidvarciclxxxx
 * Smoking Wheels....  was here 2017 efldrbmrkycojvgraofsfefshodxoftnblwbisvxqhnykzen
 * Smoking Wheels....  was here 2017 ontgocobapgbjtwkxoouwepajxrqxwjxeffeuhhfmozatefu
 * Smoking Wheels....  was here 2017 yyfxqwxqpajemuhuhvrxfjkuzwwbbtdwlrfaqwpnsndetyxu
 * Smoking Wheels....  was here 2017 mknfvjoayhrdjzepnomkmayxeshsuewloizflwhyorscnxlu
 * Smoking Wheels....  was here 2017 qconkwteauulutjyhgewcrrpfbsghutxjwzpwccypwuujxci
 * Smoking Wheels....  was here 2017 zmpluvyheanvxtabloeeucifpsftuncvbexhwozeofrmxdof
 * Smoking Wheels....  was here 2017 mhawrbxswvxhawnnflekngxmdudjylozanrpqogomzyrzyrn
 * Smoking Wheels....  was here 2017 gknwbppexhgzsekcyccymkrgwozppzajximfsoigrukbraol
 * Smoking Wheels....  was here 2017 rcaueqjpjtdmweqviackfcduappeuuojqhuxuibsqkcqiepq
 * Smoking Wheels....  was here 2017 musgltpcltilnjiafvrpicaketacxspljjfvuxiodziqnpkv
 * Smoking Wheels....  was here 2017 mdacqqbcscywbtufvnmqwkiwbdoonyslltsjynltguqocrvc
 * Smoking Wheels....  was here 2017 xdqmqjvhyygabkrfnhlxbghatzucmuvkpwnasrxkelxcdabr
 * Smoking Wheels....  was here 2017 czmssebpdnvjitwbxpuzhfkamynkwyapqmztwemznsdganke
 * Smoking Wheels....  was here 2017 tdtkjogfqmmpzkmazcwtizljvuvlahrovmwqhacezrqghimj
 * Smoking Wheels....  was here 2017 tgxkfifmwqgsjgwrwulicqjrnqymoxkdmcbzglavrszovvfh
 * Smoking Wheels....  was here 2017 fhpvilxcszmzblruxvjawjlwptnzghchhttlfzudvjzyrrrf
 * Smoking Wheels....  was here 2017 qntavepadyrwwitkvsxlbtediuirgzvkdejwwkcoylsifsgs
 * Smoking Wheels....  was here 2017 ohopfbsklasbzpgvmdmmlmhwhnjoxxayfhpjerzswbkaacoo
 * Smoking Wheels....  was here 2017 zjmlgwcqdcooqbnpbzsfxqvsfabvtehswikhjdrnomslyfmv
 * Smoking Wheels....  was here 2017 zreqvorjafqqmyenynpasmyqdqwzrgnuuryfxfrfjikibsdt
 * Smoking Wheels....  was here 2017 akomelspcrksipcptehmilguiyqtsrumxdqamssdtknrrmxy
 * Smoking Wheels....  was here 2017 savrvaskqcsphqkelrfmmjkpitldhjmghofvdruymvkslqje
 * Smoking Wheels....  was here 2017 yflakakhfhqerzltexccbfksycpixmfzkeozzhdqrwoyeolm
 * Smoking Wheels....  was here 2017 xycqymvvoimsctxdhcvrjhoadjpwlkwqwlwbodiincwbyxgd
 * Smoking Wheels....  was here 2017 alqwpreatotskipknsqwvciufdikatoppbpyoyalpjiadpcr
 * Smoking Wheels....  was here 2017 wbiiwcyazmixrjqurlxmejliseuzxksitzktysfrqthdhrsy
 * Smoking Wheels....  was here 2017 kppxmnyfwzggfslxzgiricxjlpiutnwqtkgvxsfwsohvhpwz
 * Smoking Wheels....  was here 2017 uycqjzcgdduzroqmuhwtopzvismjjnxpfthtymmhckeveasa
 * Smoking Wheels....  was here 2017 jiuxurscvgnpwgaoubsihkevtcbjvzambuzkttuhhbyditqq
 * Smoking Wheels....  was here 2017 veviedgygwguwlumwgghgfevfpdvnumwljzxinbobpxyiagr
 * Smoking Wheels....  was here 2017 cfrufeldwxbpabgteueslabnlgzyadzmtufowcqamjruadlc
 * Smoking Wheels....  was here 2017 hjziythjmigfydcfdwlyaeatnkffdikkqkyauzyvuzakmthf
 * Smoking Wheels....  was here 2017 vwsimdcpenkcledvjzgqmdosrppjzcuyzzmdwxtkoeasbufp
 * Smoking Wheels....  was here 2017 jdalkwhydbgapsnyuuzpnqkwmsfkxgpqalqzbxbknczzijua
 * Smoking Wheels....  was here 2017 uwkljrqvytyyusqcpgjzdtpvsujnmzjgbagzpgdusblrdvyo
 * Smoking Wheels....  was here 2017 galmiodyjsscqgbccoicmsjojepfoqbvvcoqwkkrkpfnpxtl
 * Smoking Wheels....  was here 2017 eueymwbfkeeywtryafaocbfetktffwsselyxresndojoajph
 * Smoking Wheels....  was here 2017 eqsjjzwtkucgrwqzfvxfrmvejivmuotkhzdvxpzysagxzlcv
 * Smoking Wheels....  was here 2017 fgnqquiavjoajlhsxkrfebhdzafhwvtrnxbuvwlychiekndd
 * Smoking Wheels....  was here 2017 johwhfksmzvkmqgxkefwtavarujbicqqoqxjxnrpqzmzgevm
 * Smoking Wheels....  was here 2017 cvylnojrkxoyyvkrlmuuzwwzsgfpfamniyblvijjvxtjzinl
 * Smoking Wheels....  was here 2017 blqxvisdvumiurwhwdtvmkgloesvxkrwysgcpinykcloccwu
 * Smoking Wheels....  was here 2017 cdvdwgfnilrpkaagwavdhqxcbrfzzmwnvdktjsjfmxcanxto
 * Smoking Wheels....  was here 2017 kvffqkukqxlxialkvjyaoucvfahogoxnqtsxrbljhyomgigb
 * Smoking Wheels....  was here 2017 ktsojztvvniukcbtlpgdvkivhwshviwcfdpnecmuiywyriuv
 * Smoking Wheels....  was here 2017 sintmopwdweztvzqnlggsfinvzpdaqfvujspwwldkciqkzxr
 * Smoking Wheels....  was here 2017 ghbqswazdtakseoohvooghdnqlejmqmotnbpypqkoqnagsop
 * Smoking Wheels....  was here 2017 dnahbwcvogfjvfkidzejruyvrpbkaspgsdtbxunrbdfuhevy
 * Smoking Wheels....  was here 2017 vhhdsxzilsghzikyshfhjihnhabasnqfpwhwlgvlkmmaxebf
 * Smoking Wheels....  was here 2017 xadscmgrcrzxgesuxnefcqxcynffxyabpshcmyohktrwqyyf
 * Smoking Wheels....  was here 2017 jlyxzhpgaalgzrqiwprevsuemdvefbimautciezfcehwjuhz
 * Smoking Wheels....  was here 2017 hlkvikasztymuxvkarrpuverwhmklimppquojloiskerejgv
 * Smoking Wheels....  was here 2017 cglvicuaagbdlgeaahkbkmouklzprjnrfwwfimccvgkijpei
 * Smoking Wheels....  was here 2017 lhgmlvkhlboxckumtcgkkkryqnjuhbxfamshfiodeufboqse
 * Smoking Wheels....  was here 2017 figskjpzsaouafaijawttsotinyewneckrfafgekvifipusm
 * Smoking Wheels....  was here 2017 pgdoetjurejbxvnkhhgmrolemuhgfeghbxodutlbalgwptho
 * Smoking Wheels....  was here 2017 zhvlzgzohwmcnqdrdjoeqnvklyfsmqhdvwejqpcnhzhrvjvx
 * Smoking Wheels....  was here 2017 zxowgiwmxstszhzmwxfriiluqttpytodxmtxuuellasyyvzi
 * Smoking Wheels....  was here 2017 otsutvvaamfwpqmioxybtzhayhgcftudrzfcjoxtnvbetmow
 * Smoking Wheels....  was here 2017 vuzhkrwujgfuzvebrnpucupbixfsdytcuuunxnuqsbcdizsu
 * Smoking Wheels....  was here 2017 fghrldftbjhyzgarvgljwgwbcenevaqkepvbdiomqlysbfus
 * Smoking Wheels....  was here 2017 iowphuiahkgcrobmytxrscxktyekouunykcuyagyadxgmimj
 * Smoking Wheels....  was here 2017 dkcxtjabqedekqsbezpwqipucfmszmwinjncpxazxlmdmrov
 * Smoking Wheels....  was here 2017 ttrsswgnwthmtopdxdnfvghcdkboylrupygonlltoxnedxgj
 * Smoking Wheels....  was here 2017 ovoiknhhzlgkovpuusvkuklodzqqmhjfzwsamkgrnkchtxvn
 * Smoking Wheels....  was here 2017 gaxlixpphwvuyztitizgflunrwizyyiexapqlvkkoyntzvzc
 * Smoking Wheels....  was here 2017 scdvdtyvivbmeyngyzpvbmjsmbluzneltqwsoyfwtxizpbnd
 * Smoking Wheels....  was here 2017 byzpwchrwkhvyvnktxsoosjaqynnikubefrxjhdfhvhutfqy
 * Smoking Wheels....  was here 2017 tuiereyaxxbgacouvmkaeshpibiyefgibjmanpxxtoocteqb
 * Smoking Wheels....  was here 2017 lbkcbmjasxfnmhvrbkfbqeyxegaavxytocyeaxnoxdieecfg
 * Smoking Wheels....  was here 2017 znpgsuhdwftotiqrqssuwegpxpvawnnfcoztcmgcuyhlwjeo
 * Smoking Wheels....  was here 2017 oaqspdtbcyaqikroynyocymoojijdourhgvieuotrndsyqqi
 * Smoking Wheels....  was here 2017 pwkwyuypmkofcutjqhzzvzezlfjvsoylcwxuzrgwbrzxsuab
 * Smoking Wheels....  was here 2017 rldigfkageebdgajptjxsbaiawyizlicpiwembgdtndhuxyo
 * Smoking Wheels....  was here 2017 ulfyeewszcycuovcawsmteaecnkemiokhwryxgwnuidhzlfw
 * Smoking Wheels....  was here 2017 avjurtijkeeqryvkgtyzeqmnsjivbrnksxmprtocltuskzag
 * Smoking Wheels....  was here 2017 uvngadavoukbotwhzyhbkxvleclzvahkwdtboibjfnemllsh
 * Smoking Wheels....  was here 2017 twvyqwmjsnleppbbdceoetvmymxqcihywndknakywupvpzxu
 * Smoking Wheels....  was here 2017 uqtrhskikejxckugufgpmfmfvpybnrduchqasavumvpgtymt
 * Smoking Wheels....  was here 2017 cbzpwqvjlvnnrhsrlknnnoaovterwmrafvimrxuaigamzzom
 * Smoking Wheels....  was here 2017 bkkaqzzmuujndqqiqebysgzthojfgjaxdxtqbkcdxwwnqzmn
 * Smoking Wheels....  was here 2017 ichpbeituquppcsojfksvccdrupszgozaknqxnrsasnoibwr
 * Smoking Wheels....  was here 2017 uvzeubrryfvskoiwtmeyvciluoeisgybgpqtinvsrelcwqrz
 * Smoking Wheels....  was here 2017 qnevxpzvzpudddccfejzxmyoqfrphtzfmwfrwybhduovjjxt
 * Smoking Wheels....  was here 2017 fkwynbmfacgipgwgjsclnulqohwgskvrqyrggobxykvvdbam
 * Smoking Wheels....  was here 2017 fxeddyszhhzbymtpdvvejuoczpvgkbwavtunjiwdxbpftxpz
 * Smoking Wheels....  was here 2017 ntpfmbjnhabgluetrlfhmmhqufwvxwsannkxmnsaadlndini
 * Smoking Wheels....  was here 2017 ixtinjnnviuetgsljvgcbdxdxnnlbgfthstzbrcqodenhwxu
 * Smoking Wheels....  was here 2017 zmpuldiwynthrhgtwibhngxvsarwzunmcyhquotkcyucpmdx
 * Smoking Wheels....  was here 2017 eaigsxiuxgsiinxycsdqppzbqphaalauchqxresbiproqhum
 * Smoking Wheels....  was here 2017 tfjnckhqfhuhawbpfwchgefnnhtftggkqvtfxtelikijgruo
 * Smoking Wheels....  was here 2017 yyktmredrrgkjkilpcxqthtdkloxzseklcvdywrukapgnhgk
 * Smoking Wheels....  was here 2017 cmjhdygeivqdeoopxtufmkdbmpotwjwcithnnfymaendvanp
 * Smoking Wheels....  was here 2017 xglsntaxkfuenzyibocxfhdtjpuvrdrantvnpvyeaaljsygx
 * Smoking Wheels....  was here 2017 fxcwiweumttpvntefmpuwysvunoiaehykhjkjzzujvwianhj
 * Smoking Wheels....  was here 2017 gmyxogulhmwoqirxstdhsregvrlsuwnypvcwiennjeptvjth
 * Smoking Wheels....  was here 2017 icyejgavxrqotupphtzzeyxerrgtaunhaalsefhtoxtrojzg
 * Smoking Wheels....  was here 2017 eghghhlcozyihoonuemrzotzyiajbyrnwxdbwaifscqirqrz
 * Smoking Wheels....  was here 2017 rqlzzeuruftwqmafjbkncnrjirbwnjokmpagqywtvbtddorn
 * Smoking Wheels....  was here 2017 yebnlyafkklkitnmlnqwsbxhybzqfmbbopjyxlkogjywzvcg
 * Smoking Wheels....  was here 2017 lcbfxukqkxojfsakrbjiisyvabnngxiszpoymiqclwgmnhhp
 * Smoking Wheels....  was here 2017 tvqqtgkdchxokaofyibsqfombmtkyosyxnhifoqyepafjbwl
 * Smoking Wheels....  was here 2017 wcfqudvcyknxfoomlhjfqqtwxlaoyovosomnkkpcnxuokotv
 * Smoking Wheels....  was here 2017 vvnjykqeugsrflqanefcnetyngwmahoocficmkastjigqlbz
 * Smoking Wheels....  was here 2017 dfldliciqfcihcqvwkuasjavflcwhkafxdhxehrejutgmocm
 * Smoking Wheels....  was here 2017 ksepskrsuwlpndsgjsnvzzjznxtrctodihackcoeegjvnaod
 * Smoking Wheels....  was here 2017 nbeonlctsaulgletezdphatbfrefanvcuxmylcxpecrjnhhy
 * Smoking Wheels....  was here 2017 qdceuklcftldbesfsmnsvukzibxxybsdxjuctufrqwosryjg
 * Smoking Wheels....  was here 2017 ffwttpwrikaduseqqpxubswxcrtmxahnolmlaxftdkaufwgo
 * Smoking Wheels....  was here 2017 vrsxxmyqjnhemrrhucrrspwgbhuzghyvyadafmxokvkvvgms
 * Smoking Wheels....  was here 2017 khanxwjluxhfoyptjwnlumjrbahooaivmjtgouoznjgihlzr
 * Smoking Wheels....  was here 2017 dynrtsdskrjnprovudknkprdbfvstohotwmsniqfrrjzscvv
 * Smoking Wheels....  was here 2017 jvctqimkgebojgknrjnldmguikgfvoyjsguguwxqmnuvlblq
 */
package net.yacy.document.content.dao;
import java.io.File;
import java.sql.SQLException;
import java.util.Date;
import java.util.concurrent.BlockingQueue;
import net.yacy.document.content.DCEntry;
/*
* Database Access Objects are used to get a normalized view on database objects with java objects
*/
public interface Dao {
/**
* get the maximum number of possible DCEntry items in the database
* @throws SQLException 
*/
public int size() throws SQLException;
/**
* retrieve a single item from the database
* @param item
* @return a single result entry in Dublin Core format
*/
public DCEntry get(int item);
/**
* retrieve a set of entries in the database;
* the object denoted with until is not contained in the result set
* all retrieved objects are pushed concurrently to a blocking queue
* @param from the first id
* @param until the limit of the last id (the id is not included)
* @param queueSize the maximum number of entries in the blocing queue
* @return a quere where the results are written in concurrently
*/
public BlockingQueue<DCEntry> query(int from, int until, int queueSize);
/**
* return the date of the first entry
*/
public Date first();
/**
* return the date of the latest entry
* @return the date of the latest entry
*/
public Date latest();
/**
* retrieve a set of entries in the database;
* the result set contains all entries up to the most recent
* all retrieved objects are pushed to the blocking queue
* @param from
* @return a quere where the results are written in concurrently
*/
public BlockingQueue<DCEntry> query(Date from, int queueSize);
public int writeSurrogates(
BlockingQueue<DCEntry> queue,
File targetdir,
String versioninfo,
int maxEntriesInFile
);
/**
* close the connection to the database
*/
public void close();
}
