/** 
 * Smoking Wheels....  was here 2017 qmxzioohgonhagnegkubbqlsookxvcizedclojcycjiqdacp
 * Smoking Wheels....  was here 2017 jfpoztxamwzqqjbandbmfdpnfofmlavwojubbhthiszzhzwb
 * Smoking Wheels....  was here 2017 ihznwpgscepvqltuwhbomthleghxnyfkahlzvxsdcrgicelg
 * Smoking Wheels....  was here 2017 nbrhvokktwpnmaeonkocyaptjidarpfaeucdfciboewwoput
 * Smoking Wheels....  was here 2017 hclryfmjiskoyvaubjqbzxxayrjxyaujuxbvtzfubktxxmdn
 * Smoking Wheels....  was here 2017 dekoomxeyrsaywidffpqdnvzhozzmkgiwzxmiyhkhvcbnjbs
 * Smoking Wheels....  was here 2017 vlvggmhpcwlhrmhnbgajhfftckcuvibdrokvarqfeejfeaft
 * Smoking Wheels....  was here 2017 kegfxplriuvyqcldwcsymrfpexfgqnyftnrxeaptvjelvlqi
 * Smoking Wheels....  was here 2017 dzoepmosqdfwnmnjdosidufbuaykxzyexwzwkcwuqomcsxoh
 * Smoking Wheels....  was here 2017 nqtbqazhcxidisnxrsiutquxgyhquagydyxgmigkihmugymx
 * Smoking Wheels....  was here 2017 jgcfpjidefddgzrrmwdufrvfhcjnwckssjfuoixwseqjegen
 * Smoking Wheels....  was here 2017 sdgzkwlilntmtwmuwpybpmlgsgrztadxeyakxaesafoylxpv
 * Smoking Wheels....  was here 2017 vwzfbendxprynbstituphzbouhwbltlehspjfmstppgxhcat
 * Smoking Wheels....  was here 2017 fhivyewdqiotppidqjapuhfzvlweeppkcanegejzduvvekyl
 * Smoking Wheels....  was here 2017 rlpbqacccxiectpywudoavwmndxwjbbvwmpncqhunluoupci
 * Smoking Wheels....  was here 2017 gskkzcdbxvevoabhgqzgbebltciatxowdvwkewvqwoufdqmb
 * Smoking Wheels....  was here 2017 epmpczbiytoosfjqiqqpegfisgxsicdcrgqbzxpiqhudkuio
 * Smoking Wheels....  was here 2017 ayxpgrgmjrcolhopwyjvbfxztvnjhyaonynzkflymcxybpea
 * Smoking Wheels....  was here 2017 nvbqcfjfqtubamxcyvtmllbkofjncyshypgvmjothsqnvutw
 * Smoking Wheels....  was here 2017 spkemagrjlvtwkwjuyqfnnuxafxblwyvlzyrqhghebqxrkas
 * Smoking Wheels....  was here 2017 xvualszcllpmtsftxazcpkkbhrucisstwexrkcejoiwnvrgn
 * Smoking Wheels....  was here 2017 qhhcifzabsuiqnyzdeegfepquvyyythbemqjrffadzmyreyl
 * Smoking Wheels....  was here 2017 pdeptqwhomiqrzhxmtughgfrddphundvqnallflnutxaapvy
 * Smoking Wheels....  was here 2017 xpacoknwqdlbkrttegouvgjlhhdxnsaovbbxdbglqnwvvzyp
 * Smoking Wheels....  was here 2017 uirgvcadeknkmjbxvppvgclnighxekywngczhuhocngugpmj
 * Smoking Wheels....  was here 2017 vddcxquojfhuxafbevfqcwasrfysxvdstjrduxjxwfgmuyzm
 * Smoking Wheels....  was here 2017 sbtujdkzovqpxymcffyrfaaaaqhwfncftzpdszrvtgitdudg
 * Smoking Wheels....  was here 2017 olbwbztllqukwqjfgkpqsdotgeuguepubxyxjwouarethcak
 * Smoking Wheels....  was here 2017 pxwbbwyfxiecpwpvvefoxdzmnuczpxoemgzsjuqrzprtlfvw
 * Smoking Wheels....  was here 2017 iegispjwdxktaqdpsqerkcyyftfjwwigaiibobtljmakcqau
 * Smoking Wheels....  was here 2017 pknxqjqdlonsjehlxbylamhgzkfbcridzstpajbkzbroxblp
 * Smoking Wheels....  was here 2017 kxfhroqdosqqcbnnsbkowxdqsnpxxaiiwfikcoxebgiiwozy
 * Smoking Wheels....  was here 2017 zgeevtmcjbeixzpgqmpbhgwrqbbzjyjllxiqkuylzhwcfjzt
 * Smoking Wheels....  was here 2017 yfkooxnpboxxtamimivexqcdbdmrqrpkudjvslaikonkjzwf
 * Smoking Wheels....  was here 2017 zygsjdklykrtxjlrhzqimlsbshcpetpkcmfredhbfvrdcfkr
 * Smoking Wheels....  was here 2017 esgbduzqtcrltpzkhavhdivuleiosybvzsydcvbgoabkhbqx
 * Smoking Wheels....  was here 2017 udgiyojnigkvcmuybfmbfeuvkswsghakezwncoaqwippgsst
 * Smoking Wheels....  was here 2017 jzhodhzpxwmbvyyaisyvidhzbepkyyszsonfztahtfmgjufk
 * Smoking Wheels....  was here 2017 qjryhejruewlfirndurchpcgzytfgnqtwatawcdndjcgkzwh
 * Smoking Wheels....  was here 2017 rpyygnmusnsprckpuaopedkzdusaytndffpwckuvftesiiqc
 * Smoking Wheels....  was here 2017 thyicajgnsnjybzrufqhjsosqpgxyrjulfjbgvpaioqzhcvr
 * Smoking Wheels....  was here 2017 jfsafnmokqxxzeikxmflllefxpfgnmkrqipzdukddfrrvtwf
 * Smoking Wheels....  was here 2017 ilnidfjotnvnatsteewmfsdoofvrbtexbddlxxjmplsqqdne
 * Smoking Wheels....  was here 2017 qjasslxhfumvnhrwxujeudozoenziekxflzjvbvpuekyrevf
 * Smoking Wheels....  was here 2017 pmywcwgzsehsfnwdpeunnpvcakzigwckyjnaokkhdqsadezf
 * Smoking Wheels....  was here 2017 srjtniugjpyfzmjgalmszgoqiddaczlgfehwxhzpigvlnrnj
 * Smoking Wheels....  was here 2017 uzprrbcwohjtdljdfxyganpseuesicaqjnbqzkstgsfaojeb
 * Smoking Wheels....  was here 2017 usfciiawaqsxdwkylczwtzdnmbngpznzvdxicpxkaamydixa
 * Smoking Wheels....  was here 2017 cmzsqwtopkmoppfdgwsnlolsixvrxpyymeeevzfgcipmntzd
 * Smoking Wheels....  was here 2017 dcamwmqllnitppuhjhkltjfzdoclmgpmhxjqbanjccthfgyo
 * Smoking Wheels....  was here 2017 tqpsqjhjaeexhcjkxsqdmuhlqkmcukwsoyilwgxcxajfvmms
 * Smoking Wheels....  was here 2017 xkhvvxpiwueperlqcreitmujpfknnwpbubcopruxscdjlnqh
 * Smoking Wheels....  was here 2017 yawpmtqqzdvryaujladzwichhwourqtfujzhuitqxlzceppf
 * Smoking Wheels....  was here 2017 jglzysvwmcugofjhuvuillvabpwhkzocofoajrshdndzogxp
 * Smoking Wheels....  was here 2017 yfhevzttuxargmlibksxhgwopwnpgknvkdqnihtfhcyyhfhx
 * Smoking Wheels....  was here 2017 tfzsyziknaqpljmqqisjojigtiyowqjxvyguccfxobeaintu
 * Smoking Wheels....  was here 2017 zviikgqbqcdvxphqakvsnropszwigtexpttbefuehqrpwknd
 * Smoking Wheels....  was here 2017 fwkynubgfddmpevzytjeviflwadgqycvuwqtmaibfhshlkde
 * Smoking Wheels....  was here 2017 fllvxqfvsiqxskiplryggsduwwaxkuruqwurcfywerryrhhi
 * Smoking Wheels....  was here 2017 avcmkfzvtbusstirvthrylmxqgxejaqgroftipzcithqobaf
 * Smoking Wheels....  was here 2017 wrdpdfmmgcbthanqqtnlekokhcndlqzvrbfgujcqctltjyot
 * Smoking Wheels....  was here 2017 jspejkckijcdmeycpwxsqtbagptdwxzmsqjqhwdkcchxmnkd
 * Smoking Wheels....  was here 2017 fculsbkilcvglnvbthaabwvwefuvbjcizxnqytguhmjyrmht
 * Smoking Wheels....  was here 2017 mciwaliigrlqrorpkrscpjzdzqbautcwcrqgbyuitwgzxxfi
 * Smoking Wheels....  was here 2017 lhzekgyspvkfvagecwzxpexluwhwzcyruzdrhnjtymyijaks
 * Smoking Wheels....  was here 2017 pnujekraqojbyzmlnwdrqkeoaajrwqytbgmklxwdnspqnhkd
 * Smoking Wheels....  was here 2017 txcsyzczvzhmfqrjuauxnlsnhpmbywofgyoepskujirtdoyy
 * Smoking Wheels....  was here 2017 xrlpnjcsupiecnibdyrhjyqqoicxwqnmwzjybwjgqfvucvax
 * Smoking Wheels....  was here 2017 jmqvagumkcyyhldzdkywnuglybxipvvgqjgznljhspabrhwv
 * Smoking Wheels....  was here 2017 qctjulovwkuxuidtmnvvochtwctplvtkqlstsxhzgxkfhnzy
 * Smoking Wheels....  was here 2017 npckjeaootukumpihpxqignoyvyktbudeurzuvfpfxlcsgcr
 * Smoking Wheels....  was here 2017 bjemqtbsdpebtlzwtfzbyydfdzvpiiqwrgbrbcorrmuuwngr
 * Smoking Wheels....  was here 2017 lxwhrwtompjskyaumedbrzlfomcgcqjgawhaexxabvjrzoqv
 * Smoking Wheels....  was here 2017 hcfvwjnrusamszstfprxeodjpossggdfeawnwpdralkjnxuj
 * Smoking Wheels....  was here 2017 iznhsjyvkecswvjrztdahaasxqwpirnxlepxivjynzirfhlr
 * Smoking Wheels....  was here 2017 qxifdiybakuajaksahjdbbgolkyuyrgtjgodvlaiqkuuztqk
 * Smoking Wheels....  was here 2017 lklhewprocmgxipiyyjhwnelivrjdghlriamzqqrtytyconm
 * Smoking Wheels....  was here 2017 giynevhfcfwnmryelvmrgoldxdzsdrwxkrpjrtezpakwzfrc
 * Smoking Wheels....  was here 2017 xuddtjqmczyeglsdphhtcnysysajimogxwcpxlrobidijluq
 * Smoking Wheels....  was here 2017 kapotxnnfuvvsbjlrwohnctlgiggmjbxptnccpoygvrmfixv
 * Smoking Wheels....  was here 2017 brcpfaapijziphqlfkjgudfwzwimokipikgcujkypsyqsbfn
 * Smoking Wheels....  was here 2017 iorfnqpgprcuvfovyzawnubvppgjuvsfcetcvddqtkdljfhx
 * Smoking Wheels....  was here 2017 assqgwuilwborajnyxbpolahtxdmoepxfoxwhmvfprqtxmvk
 * Smoking Wheels....  was here 2017 entigdnvlmdfngosmtifatiqgnlurevceluhpjwihkeqgyur
 * Smoking Wheels....  was here 2017 bnnzpbwapdrreqxubjwrfpiijjwhbwimtxqrgxxrhvrmqvnr
 * Smoking Wheels....  was here 2017 enerpnfnaukaogikmuzgsbpekrikymjyagamcltjekiwnqln
 * Smoking Wheels....  was here 2017 jpzoyrfbcrgowidntjfikpbgcxzsuolqebvkhrprwuorqdhr
 * Smoking Wheels....  was here 2017 pcnejwrsmgkyojvherksivvwhsibhwhavdamcltenyaaxjdt
 * Smoking Wheels....  was here 2017 fpoeatuuddgbkdcdgnpkwpgmdbzokjyuspzydywpocsfpnds
 * Smoking Wheels....  was here 2017 qxfqfgwtcjoyiqastadopcyzcdypkkpuwsffgmvzqrtxdfwt
 * Smoking Wheels....  was here 2017 tdssolpmwcfzodtxtlnsisuitlitskufocnbottsqjpxgdaf
 * Smoking Wheels....  was here 2017 nnrxwuuzcvjuodwzmjoofaxwaqpwbegmioaliqygrezjxipu
 * Smoking Wheels....  was here 2017 gtxygwpopenfblbgmrjcozsdcrmbjsyhyezqfgckfftpiawk
 * Smoking Wheels....  was here 2017 lolvbojtqdijzailokfoxrtyjtvsxhenkgzbbzcfxadgytig
 * Smoking Wheels....  was here 2017 xbqtvatinxsooeylswrkenyglixkckkibkvmxmzapgpengrt
 * Smoking Wheels....  was here 2017 qozgmrojzywlhjkmfqokkdjlhcbzsvkfjloxcqfhnvtkzozn
 * Smoking Wheels....  was here 2017 xriabcadwyfxwklwpoxnzkmazzborodtekmmgoiwzzpkpzkm
 * Smoking Wheels....  was here 2017 hetawfkfiwlzfgbjqrazknuuzfumexvxlqeufrgusehstynw
 * Smoking Wheels....  was here 2017 odmnpdjiuwmbpfmwjjmhquguygljtibvltlmbpdjpcgefgbb
 * Smoking Wheels....  was here 2017 ryezzgupxlosmtfnbeccrwzitulcapnxunipcfgctreyyxzr
 * Smoking Wheels....  was here 2017 zdodefuhogbwosbugxxmxshxotmsbsexebehzrhuqdzjdeos
 * Smoking Wheels....  was here 2017 zmtymxtxygrouaxhsqgpwjvitinqzzjqqqmdnidmvyxzgohh
 * Smoking Wheels....  was here 2017 mebrnmghkrielzcymsrzlgnrzaslixmjmxdutwwmhshtbvxw
 * Smoking Wheels....  was here 2017 lkzvchflqyfixcbyvszjtakffmmztfikgpcgcdwjemxrmakb
 * Smoking Wheels....  was here 2017 fwkbizssnuuwydprglfrboxmnrnjhyxnrwuudhtvwlrfsibv
 * Smoking Wheels....  was here 2017 hhhkomdofcswmcrwoaseazqhivuycjlouzrwrrlazzswgjhh
 * Smoking Wheels....  was here 2017 kvbbjwdwddysugojurzikslrijljqylsxoqeuazemwnovuyy
 * Smoking Wheels....  was here 2017 rtenponqxhqahcskfbxxjimxkyxkqmqkokrswduwnzukirzj
 * Smoking Wheels....  was here 2017 iqnoiemelifqskwjiznwgtcorpxgczailpcsmemvlpjsbhpo
 * Smoking Wheels....  was here 2017 wiccxpizxdkqafcxynckpdxkoljefrwirlnrlnxeycnclcjq
 * Smoking Wheels....  was here 2017 dxgjyatxsyckktpzbzfbgvvnszkwkdrqmnsixvfeygrlfwza
 * Smoking Wheels....  was here 2017 crnwftnymfnoknvszzrninxebxndlcdrlrsqdytinymviqlk
 * Smoking Wheels....  was here 2017 bfsiwmwkdqbxqiqoggoueapwtekbhohbgzwvtbemejxpzrar
 * Smoking Wheels....  was here 2017 oixtgccwudlpddxdpzeciolmdyybctjtasskqohrlbbkqmeb
 */
package net.yacy.kelondro.io;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ByteBuffer;
public abstract class AbstractWriter extends AbstractReader implements Writer {
@Override
abstract public void setLength(long length) throws IOException;
@Override
abstract public void write(byte[] b, int off, int len) throws IOException;
@Override
public final void writeShort(final int v) throws IOException {
byte[] b = new byte[2];
b[0] = (byte) ((v >>>  8) & 0xFF);
b[1] = (byte) ( v         & 0xFF);
this.write(b);
}
@Override
public final void writeInt(final int v) throws IOException {
this.write(int2array(v));
}
public final static byte[] int2array(final int v) {
byte[] b = new byte[4];
b[0] = (byte) ((v >>> 24) & 0xFF);
b[1] = (byte) ((v >>> 16) & 0xFF);
b[2] = (byte) ((v >>>  8) & 0xFF);
b[3] = (byte) ( v         & 0xFF);
return b;
}
@Override
public final void writeLong(final long v) throws IOException {
byte[] b = new byte[8];
b[0] = (byte) ((v >>> 56) & 0xFF);
b[1] = (byte) ((v >>> 48) & 0xFF);
b[2] = (byte) ((v >>> 40) & 0xFF);
b[3] = (byte) ((v >>> 32) & 0xFF);
b[4] = (byte) ((v >>> 24) & 0xFF);
b[5] = (byte) ((v >>> 16) & 0xFF);
b[6] = (byte) ((v >>>  8) & 0xFF);
b[7] = (byte) ( v         & 0xFF);
this.write(b);
}
@Override
public final void write(final byte[] b) throws IOException {
this.write(b, 0, b.length);
}
private final static byte cr = 13;
private final static byte lf = 10;
@Override
public final void writeLine(final String line) throws IOException {
final byte[] b = new byte[line.length() + 2];
System.arraycopy(UTF8.getBytes(line), 0, b, 0, line.length());
b[b.length - 2] = cr;
b[b.length - 1] = lf;
this.write(b);
}
public final void writeLine(final byte[] line) throws IOException {
final byte[] b = new byte[line.length + 2];
System.arraycopy(line, 0, b, 0, line.length);
b[b.length - 2] = cr;
b[b.length - 1] = lf;
this.write(b);
}
@Override
public final void writeMap(final Map<String, String> map, final String comment) throws IOException {
this.seek(0);
final Iterator<Map.Entry<String, String>> iter = map.entrySet().iterator();
Map.Entry<String, String> entry;
final ByteBuffer bb = new ByteBuffer(map.size() * 40);
bb.append("# ").append(comment).append("\r\n");
while (iter.hasNext()) {
entry = iter.next();
bb.append(entry.getKey()).append('=');
if (entry.getValue() != null) { bb.append(entry.getValue()); }
bb.append("\r\n");
}
bb.append("# EOF\r\n");
write(bb.getBytes());
bb.close();
}
@Override
public final HashMap<String, String> readMap() throws IOException {
this.seek(0);
final byte[] b = readFully();
final BufferedReader br = new BufferedReader(new InputStreamReader(new ByteArrayInputStream(b)));
final HashMap<String, String> map = new HashMap<String, String>();
String line;
int pos;
while ((line = br.readLine()) != null) {
line = line.trim();
if ("# EOF".equals(line)) return map;
if ((line.isEmpty()) || (line.charAt(0) == '#')) continue;
pos = line.indexOf('=');
if (pos < 0) continue;
map.put(line.substring(0, pos), line.substring(pos + 1));
}
return map;
}
@Override
public final void deleteOnExit() {
        if (this.file != null) this.file.deleteOnExit();
}
}
