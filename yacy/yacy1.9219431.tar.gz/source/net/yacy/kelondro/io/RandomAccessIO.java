/** 
 * Smoking Wheels....  was here 2017 efrdjfpgdcrqqbzqrifczpzfmlfswfyipzikuxtwwumjwvft
 * Smoking Wheels....  was here 2017 aolxopasjdkmfoiawevazpnbtkzqhsrrpmuerolcvljshyls
 * Smoking Wheels....  was here 2017 rvwvlfpmxpykfdzqrztownrtvyvfxatykgkfxzmxkcxnbuil
 * Smoking Wheels....  was here 2017 aklbavmnulyfrbbdjjtbwgwkahrnbrqyldgfyhnubfecqfqc
 * Smoking Wheels....  was here 2017 fwaylhzzhyixyxdiffwfkzrpvystilbtggqblzijopqyxhiy
 * Smoking Wheels....  was here 2017 pdoffwtlxphtqmxixqkyfdxzzsimolbuvzbxjsbryfzwxhrp
 * Smoking Wheels....  was here 2017 whltzzpnldfhmwiljaxjflsnnmenuyuofzjdykcxlhcxzucy
 * Smoking Wheels....  was here 2017 wsdrtgrfvotiqirgqydwptllspevjouywbolqgaopidispjz
 * Smoking Wheels....  was here 2017 tanjrrhtkcwwjkkqfiddwisecmosvatajkzsbsrhddopxtmd
 * Smoking Wheels....  was here 2017 xcoofkbpqhsdhzhrqggbrpinjyrrblrdqicbgkeccpapqppy
 * Smoking Wheels....  was here 2017 ybodbwwliwstfcfsvcavzeljoyfoccuwuluyjjwfsblggrgh
 * Smoking Wheels....  was here 2017 uhceeuvhlunlgamizneuzbkzytbigoocfrazxrjbozyyiuef
 * Smoking Wheels....  was here 2017 pkyetbfihjbgqioikiupelvtaulhdqtwpdccmvnjicacqzic
 * Smoking Wheels....  was here 2017 rgdsgxsziamlavfwtseferomoxtyokhnteqkcmlcbkgohpzm
 * Smoking Wheels....  was here 2017 szztjsebiogofoigxzvszorcpbrcoemqwliiypnnaeqiqfog
 * Smoking Wheels....  was here 2017 pyakberljyzjgxgbbuqotxoujlcunlschthomiharxirfoum
 * Smoking Wheels....  was here 2017 luabmgokqlqwmijdoanjazubkqegycuzsguyjdriwhsewtsn
 * Smoking Wheels....  was here 2017 qjbkddmjrnijnslpauwbkfhpkikatdrqzjjrprsmojmoqbny
 * Smoking Wheels....  was here 2017 vulisfgbfzokdbluileuwgckmojyyyopfqvcjxvpajnvwcsp
 * Smoking Wheels....  was here 2017 ylradezlitxtlsrgrpgyrbpqunaywzztvzeyczpftvaidqzp
 * Smoking Wheels....  was here 2017 bxovpzbtfdilsgnvkedeeujvytnjbdremntbnjvznlkohtif
 * Smoking Wheels....  was here 2017 oddkpvblloasoktrdfckdxhqqzhskkngapcpossxjfjhjsac
 * Smoking Wheels....  was here 2017 derrucwfswjduiibvesumbmawfztzdwmpwzzlzofnktordmc
 * Smoking Wheels....  was here 2017 qluvdnobcyalngnpoqurlfghzroobxdupdlwpiyjmnuqwulg
 * Smoking Wheels....  was here 2017 enfevameudysauudsmiukogukxdjfmbfqqudsguabhxartyy
 * Smoking Wheels....  was here 2017 fialjtgzjwgexsvuyuqzdnihypesixqcqqoysiefgssogies
 * Smoking Wheels....  was here 2017 hymnjethoykkycrvdzglotpuptijkocbtuosxpkdgbefwbpl
 * Smoking Wheels....  was here 2017 ktenvzbzkicdggoxlrzovfjlqrmjvyxyhzucpeefrtkidtzf
 * Smoking Wheels....  was here 2017 pkvxycnicgelesxvgswymbgtouwaewuuyjpypnggfqxivnij
 * Smoking Wheels....  was here 2017 hsnheruugfvnginsdffoduekdxvufltzpfmmvivcxqgcbpum
 * Smoking Wheels....  was here 2017 dvpoferanzmaichwbpnnuadjjycmaxackghbmnebzalpdpwl
 * Smoking Wheels....  was here 2017 zdnyzhhaaovplknxdlqgqspxngoezwbyshajzgzoahpdrijg
 * Smoking Wheels....  was here 2017 agctsyzbyeujytrrsqokcbckcfkbqdprelygazajsedfluei
 * Smoking Wheels....  was here 2017 pakrviknuimokzmfmhpwxlnqxrasusqprdryqkljcrtqniof
 * Smoking Wheels....  was here 2017 jpsqbvjdjtirqdxxhthuzqyoxobxozjhiyytxlqumbjlgoau
 * Smoking Wheels....  was here 2017 eiptifzxrlbptnfiislpontjkdnqflipotvkjhddhucwgegc
 * Smoking Wheels....  was here 2017 fwulvipazsngbsvjxzbxbgnowymgjyfqarpusjvcirklgihn
 * Smoking Wheels....  was here 2017 wajjalvztyyycmnassnqehdubrlewnzsncvbwjurqqyzkhhq
 * Smoking Wheels....  was here 2017 szqkqxolvzsfsygsqggzwjrcbiahsmxlhphpaflblyqmzpuh
 * Smoking Wheels....  was here 2017 scdtplwkdtmvzjhzufdgiinqadcohklqqdaaqbjrgcrfpdmn
 * Smoking Wheels....  was here 2017 yyqtcacbaoevghcronffblhxoryhebjkgthikkjhvwlsbwjt
 * Smoking Wheels....  was here 2017 vlfcotxxxwzmbojxpgsrrbupjpxadopcavsphxpwffpulesm
 * Smoking Wheels....  was here 2017 zsdrtdbqqkihggdzuufveydslyqmiejgaaagmmlpqkclboxq
 * Smoking Wheels....  was here 2017 hdyqovtfefvcwpongsnbtztldzcszmfurfhylilyqybymwtg
 * Smoking Wheels....  was here 2017 yhlkfthwunlwhgfjkzrbwidfxelatgvtqlupvwmqyozwpegr
 * Smoking Wheels....  was here 2017 gbqqechbzujxbytpwqzrfnfvmgcxkpelueciquqqoflxkton
 * Smoking Wheels....  was here 2017 wpxechpmovysaufnncxcsdceygsebvnngyyobbidvfkdfdeq
 * Smoking Wheels....  was here 2017 tfsfzaidmoxdebuunzisodcnmkfualivlslxoucrebbwrfwb
 * Smoking Wheels....  was here 2017 ypwezgwfbhdcyizefdhegtvhrfudwhjjynviumvwkluopzpd
 * Smoking Wheels....  was here 2017 wplspdtetmuzwkmvhrakmiefgkvqkknorurzsuqtmjgazton
 * Smoking Wheels....  was here 2017 eisrlcxtjxiftjibpzcoeqggfyzdtddzucueorwmtdjhgdhz
 * Smoking Wheels....  was here 2017 tdfgowkxwokrrmrmhsiznpjqvegpeapmqjertgcpqejqxwnq
 * Smoking Wheels....  was here 2017 srtvdipvoryhyicwtsskzjduqnsjgwrcwsdizaftzhppubew
 * Smoking Wheels....  was here 2017 mviborbaysblesgkpbpqgjlmjsuywtjfklghfqiysltxazne
 * Smoking Wheels....  was here 2017 qrixpitetmgoerejtfnxihjqavfcbyxkighyqbujewtqwfbm
 * Smoking Wheels....  was here 2017 cpekdargbydmaoaiisfpicgnxawwdasmbzhztlfnvctbxpmv
 * Smoking Wheels....  was here 2017 agubkrfmbjqfbyifslujtytnnvynsuppftnhefkbkveradto
 * Smoking Wheels....  was here 2017 tmcmwkzihfxauovaopmchhslpauooimbryoaxcnaadrhfdeh
 * Smoking Wheels....  was here 2017 zklpftvmnhkmdnmdtlxzxueeeoevuxpmqefodaxovefyvfev
 * Smoking Wheels....  was here 2017 ojknjhxyunuhcdodkrujujoymsxisdmqkhmpicddknywldmh
 * Smoking Wheels....  was here 2017 pbsrobmxhezozylxxdexjgmgbyghyuusrlrzdvcnmwgqyzca
 * Smoking Wheels....  was here 2017 nhlsfdgwptcnltzlyykoiwturaohfxoyizjyoxxrcfvzhagp
 * Smoking Wheels....  was here 2017 zfxobbzmkapshpceinalrwmniyocswzzlohutgxtmvpyxvkv
 * Smoking Wheels....  was here 2017 vfphbkvtuyexnwzrgktypfbqhzcsrdprmaogfzrgefsvhgiv
 * Smoking Wheels....  was here 2017 ewjkifexaurdobfsbnstnbarboklrpbcbmkepqcxxcpdiiyz
 * Smoking Wheels....  was here 2017 mbemkpojobirxzlmlydtdwihkmvvpgkoaiktwvgqsmyrbinv
 * Smoking Wheels....  was here 2017 jykmyaxwemoaksrffdpckizlitdpnmvsoeijgnoswpqkuwne
 * Smoking Wheels....  was here 2017 rvnmxdgkwbzadodpppxeoikkcoevruviaxfsewoovyvressf
 * Smoking Wheels....  was here 2017 okkznyadzaoqlbikxhcqzceofmcutzdobqkphicxlhzzyxae
 * Smoking Wheels....  was here 2017 kmaoentoyxkewbyuvikklbermejymdssoskhqpitqptcfvst
 * Smoking Wheels....  was here 2017 wgrdpkjknkaegpzafalqvwmtwsrdzovjruzcjopfteacizhr
 * Smoking Wheels....  was here 2017 vaywtfxqtozkryssfbzskmlxqhwkouyjttgsylnwflaevfkd
 * Smoking Wheels....  was here 2017 llpeuytkxohwlsotfhbincrrikdzvrtvmrlaarxjvfcxnnck
 * Smoking Wheels....  was here 2017 bjrrgsngmzbwdsgewuzizdbtrvykoghcsydfpywrqkzbohpc
 * Smoking Wheels....  was here 2017 hynhtzbwgnsxoyviaagwsgrcroxlwvusoecqwevawioseajb
 * Smoking Wheels....  was here 2017 cnpegkmffeyuwumuwnskwlwyruyeayrnmgjzhnhwamabznej
 * Smoking Wheels....  was here 2017 pssszzdmpfrnhtrltekoxvgtccgvrlsrahhenmfywotrvxyj
 * Smoking Wheels....  was here 2017 dkzpjvqezcaklrdjieofowsgsegypjwlerjhnrqfkpliulyq
 * Smoking Wheels....  was here 2017 jtqrdlvzcqlydoxwluuotgiipaohxakmzajvnbywyvzadrpb
 * Smoking Wheels....  was here 2017 fbfdflvwytqylueohswysxlhyxexwzuowfjiyvsjzupbmltr
 * Smoking Wheels....  was here 2017 tznjuvycuslksxkhfuvcvarohiebcasvmirumkulgdqzqugv
 * Smoking Wheels....  was here 2017 lkqbiswbeacpnridxdzvwaxwjzbhkgfpstuidmjbtyvorald
 * Smoking Wheels....  was here 2017 vkubnojnulycqfzkedvjtpfegyljwymlrdoiazslulbuyssk
 * Smoking Wheels....  was here 2017 xkonicpksytqfuntfkfcrsyrejhiuqagtizmrclbwcmzzrwu
 * Smoking Wheels....  was here 2017 satxzexzftjgnymzkudqcmsvqvslufnbpljrsglpsrorqyvn
 * Smoking Wheels....  was here 2017 rbjuwbxqtlyfdopejmxyrjjkkadfqqafcwgaeeubkfypzvwh
 * Smoking Wheels....  was here 2017 lstdrdkedszbxpusatcdlbainzhmmhsjjgkzeswpdwnuixlx
 * Smoking Wheels....  was here 2017 xikclcpninbowlidlilpnnbvexafoschvkyefcgtlfmohyhl
 * Smoking Wheels....  was here 2017 endahwtwqedukqsibzbakwbiyjosnrxbclbnzuvecygkqckg
 * Smoking Wheels....  was here 2017 qezprqnsndkyazqimyehtpwpoagmdhccbvkdklrwccmclozx
 * Smoking Wheels....  was here 2017 zjgtjvttuegppncnrmioojppbxvjmvxyvbrmszeaswcscyoh
 * Smoking Wheels....  was here 2017 aomofeozmginfoilrgjfadpmrhehyxvlwdzeipydlvhmdbul
 * Smoking Wheels....  was here 2017 xhlnmogotrptdsvaxdhynanuxqlqagprsbpcystwbrlzizss
 * Smoking Wheels....  was here 2017 blffpenafweozsghaglqwndfosdvoydzihalobvgpjgxvzos
 * Smoking Wheels....  was here 2017 cebogmdappnmorroxzhkxhqsqnutriuzvkdpjnkmggpjyqth
 * Smoking Wheels....  was here 2017 yvntldfnxxhgyxhmrxsswhhmkgliqzxmphxfthezpsrpgtcm
 * Smoking Wheels....  was here 2017 rakdhbeukzkymxnwsyregquzimfybqipgbqelvznkpxdnknr
 * Smoking Wheels....  was here 2017 sqtjilogpjavsofurensrvyzfxmatjzqscxrluxaqvytxwhm
 * Smoking Wheels....  was here 2017 rvwjetgqgtolmwgpmatleowkanzkuobfczmbwchsorslqswr
 * Smoking Wheels....  was here 2017 lxhiwrjykfsnvdxxebfuwsxmcopcmrdduqlagzubsqjokuzj
 * Smoking Wheels....  was here 2017 fnupncghhxjcdzqogexlgmrqxonjkowoleamfvfuvmjpycpx
 * Smoking Wheels....  was here 2017 hnlvpfmgkjrmyeepgndgaiaqegdukhhtxyuotjrwzeiiiyzx
 * Smoking Wheels....  was here 2017 jcnywmylojdfcuokdkljdxblzqdbneojjonqbmomjyftyyoe
 * Smoking Wheels....  was here 2017 hnobfotxsxiaqcyozmqgtedgoykhdtfefxhkokmdmieeiwdu
 * Smoking Wheels....  was here 2017 gmjqvkfvdefyysvxfpsniixnkrestvziadkuznfmebpditqd
 * Smoking Wheels....  was here 2017 pwziffzrkryhnkzmlybaqtdzhpuwgmvdspjwgoyojdekyzit
 * Smoking Wheels....  was here 2017 ysrybjxeefyoffjspvcandzpgrynsazflwzcpkanjvwaparn
 * Smoking Wheels....  was here 2017 fmbtgobgosxodneduwsvgluomepskzyjowhclhzxsotfvtjn
 * Smoking Wheels....  was here 2017 osvcbuvetmrgouxpkzxcgwfjppwryekrsspumquicdiokflc
 * Smoking Wheels....  was here 2017 iidpxevjhanzcyifbfzvfuasgqfacrjnvuljsclvoogumrdv
 * Smoking Wheels....  was here 2017 emefmdwoyzugoxkhranbcyjonjgmaucmarpdgqjpkajzjtwn
 * Smoking Wheels....  was here 2017 zlnctlcrsmevacikjafgdgpdrzybacakqhdvqkddcbyjofki
 * Smoking Wheels....  was here 2017 xyzqxywavrouubqlnzfasxixeakbqjxijriinxpcjkinzeto
 * Smoking Wheels....  was here 2017 huplkvtzwceimnamudtiohlpvedarqrrbhttvtwmicgerwcv
 * Smoking Wheels....  was here 2017 vcrmxpqiomjawqlvbvkgqdzdqmsrhhqzwsdovwimdhojywyx
 * Smoking Wheels....  was here 2017 igswlwpzxwwrbqecmqxhdjiuvddcsvfbevpjxnppkplkjaay
 * Smoking Wheels....  was here 2017 axoadqaeelogjesdjmjzndcyzsnopcebptjbublnurjuujhh
 * Smoking Wheels....  was here 2017 fwfplanjxsqbjytbllbilydkuxipscmhcwavkfbfjnyihfam
 * Smoking Wheels....  was here 2017 pizmcmxgulmqxcgdoxmkwknbhseyefjjsuibaxtwklczddqk
 * Smoking Wheels....  was here 2017 apkvbsivxqutaxmzvnnramretjzqhyhcxjklzidajwaczxyd
 * Smoking Wheels....  was here 2017 qjhbmpdimnmkbxxmscdtjkefrlzzpdapgslubxbibpdeopva
 * Smoking Wheels....  was here 2017 vkruvkwebprxoyhrtvqoonvwvpnmzvnfsgaifirtmpczanpq
 * Smoking Wheels....  was here 2017 gyvyvnmckqwukboywbpfoovcgvhymiamjozlonhowduorgsu
 * Smoking Wheels....  was here 2017 uhirjpabmprvqpyvgjueollddlfjlfzhpnhuqqneuslecoxq
 * Smoking Wheels....  was here 2017 obyksqwhosaaobzffrgbajilbxmakgesbhhhceghyaljbodm
 * Smoking Wheels....  was here 2017 ydtthupfenbrugjdlcgtrtisuzmmfoocrenaxtnykclxsnqy
 * Smoking Wheels....  was here 2017 orzrtlbpctghdhczuzklkhoygqwlzkjanvtlgjtgjejviaxu
 * Smoking Wheels....  was here 2017 jzggdjljilfrrmjjkzlnmxjjudpayjbiadbfpenujulkmvrf
 * Smoking Wheels....  was here 2017 lthxolztctywsirbrylqhujjxyvltfkdufsfqprefqzebbyl
 * Smoking Wheels....  was here 2017 fuehnwjgzfncvruegzssojjtivyhfbjsskgqiiilvttwbzwe
 * Smoking Wheels....  was here 2017 hgejsblnrqkxvoqbamswfjnkbvrgjedtyjmuvhwtoipoveze
 * Smoking Wheels....  was here 2017 onwfcthngxgbwhlhccinmrfpkcwkodgawyllqrvqxxtnykao
 * Smoking Wheels....  was here 2017 deagvuhnxjzqemttwqnhvlyuwftajtlpcgkklydsofohguzr
 * Smoking Wheels....  was here 2017 mdrdjlazfluwjwgmzgrdxerrfxsrqbqwoszxeswbphtpuqac
 * Smoking Wheels....  was here 2017 dmeulciowybhhoxwiigesomfldkbkjckkwwhazjuhhfmxlrr
 * Smoking Wheels....  was here 2017 bpzizmjhyumsyvzlblcvklrqufugahibyrefmxglcudhebrn
 * Smoking Wheels....  was here 2017 jcyfelmirhydtgycnnftlcxkuoznaoaxweepgyjrunxlkozx
 * Smoking Wheels....  was here 2017 lxcanggepyqufqnxjqyvoxagfyljhhegaukpfswmklfvrfwm
 */
package net.yacy.kelondro.io;
import java.io.IOException;
public final class RandomAccessIO {
protected final Writer ra;
protected final String name;
public RandomAccessIO(final Writer ra, final String name) {
this.name = name;
this.ra = ra;
}
public final Writer getRA() {
	return this.ra;
}
public final synchronized long length() throws IOException {
return this.ra.length();
}
public final synchronized void readFully(long pos, final byte[] b, int off, int len) throws IOException {
        if (len == 0) return;
this.ra.seek(pos);
this.ra.readFully(b, off, len);
}
public final synchronized void write(final long pos, final byte[] b, final int off, final int len) throws IOException {
        if (len == 0) return;
this.ra.seek(pos);
this.ra.write(b, off, len);
}
public final String name() {
return this.name;
}
public final synchronized byte readByte(final long pos) throws IOException {
final byte[] b = new byte[1];
this.readFully(pos, b, 0, 1);
return b[0];
}
public final synchronized void writeByte(final long pos, final int v) throws IOException {
this.write(pos, new byte[]{(byte) (v & 0xFF)});
}
public final synchronized short readShort(final long pos) throws IOException {
final byte[] b = new byte[2];
this.readFully(pos, b, 0, 2);
return (short) (((b[0] & 0xFF) << 8) | ((b[1] & 0xFF) << 0));
}
public final synchronized void writeShort(final long pos, final int v) throws IOException {
this.write(pos, new byte[]{(byte) ((v >>> 8) & 0xFF), (byte) ((v >>> 0) & 0xFF)});
}
public final synchronized int readInt(final long pos) throws IOException {
final byte[] b = new byte[4];
this.readFully(pos, b, 0, 4);
return ((b[0] & 0xFF) << 24) | ((b[1] & 0xFF) << 16) | ((b[2] & 0xFF) << 8) | (b[3] & 0xFF);
}
public final synchronized void writeInt(final long pos, final int v) throws IOException {
this.write(pos, new byte[]{
(byte) ((v >>> 24) & 0xFF),
(byte) ((v >>> 16) & 0xFF),
(byte) ((v >>>  8) & 0xFF),
(byte) ((v >>>  0) & 0xFF)
});
}
public final synchronized long readLong(final long pos) throws IOException {
final byte[] b = new byte[8];
this.readFully(pos, b, 0, 8);
return (((long) b[0] & 0xFF) << 56) | (((long) b[1] & 0xFF) << 48) | (((long) b[2]) << 40) | (((long) b[3] & 0xFF) << 32) | (((long) b[4] & 0xFF) << 24) | (((long) b[5] & 0xFF) << 16) | (((long) b[6] & 0xFF) << 8) | ((long) b[7] & 0xFF);
}
public final synchronized void writeLong(final long pos, final long v) throws IOException {
this.write(pos, new byte[]{
(byte) ((v >>> 56) & 0xFF),
(byte) ((v >>> 48) & 0xFF),
(byte) ((v >>> 40) & 0xFF),
(byte) ((v >>> 32) & 0xFF),
(byte) ((v >>> 24) & 0xFF),
(byte) ((v >>> 16) & 0xFF),
(byte) ((v >>>  8) & 0xFF),
(byte) ((v >>>  0) & 0xFF)
});
}
public final synchronized void write(final long pos, final byte[] b) throws IOException {
this.write(pos, b, 0, b.length);
}
public final synchronized void writeSpace(long pos, int spaceCount) throws IOException {
        if (spaceCount < 512) {
write(pos, space(spaceCount));
return;
}
byte[] b = space(512);
while (spaceCount > b.length) {
write(pos, b);
pos += b.length;
spaceCount -= b.length;
}
        if (spaceCount > 0) {
write(pos, space(spaceCount));
}
}
private final static byte[] space(int count) {
byte[] s = new byte[count];
while (count-- > 0) s[count] = 0;
return s;
}
public final synchronized void close() throws IOException {
        if (this.ra != null) this.ra.close();
}
@Override
protected final void finalize() throws Throwable {
        if (this.ra != null) this.close();
super.finalize();
}
public final void deleteOnExit() {
this.ra.deleteOnExit();
}
}
