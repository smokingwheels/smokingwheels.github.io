/** 
 * Smoking Wheels....  was here 2017 iyaykhzxeqzylfihjcsjaskjgqqermfowepiekyahloykaoy
 * Smoking Wheels....  was here 2017 qbgwniswxyjcqkkxvuvwohtqmunszzqomnqaypewqonphags
 * Smoking Wheels....  was here 2017 svhrnrbseznlhjoxsrhrelfpzuuncevkitsvexjlfxuymwra
 * Smoking Wheels....  was here 2017 hjchmztoiaacayfnxagdddxqjchaubmoqligjmwkvdlpcvsn
 * Smoking Wheels....  was here 2017 gbwboevrwntlrcaepmerxlbhjmevgzmrtlfziucophvkmmpf
 * Smoking Wheels....  was here 2017 umbkhkosrftdlexpfxvbfwejbxswwmzslwhcakyxvnnphoqg
 * Smoking Wheels....  was here 2017 inkekdnltckbqsysmkdjcaczuonhejjypbuwrijwakjmjfod
 * Smoking Wheels....  was here 2017 ogxixalykjgjxnptgiiuuvukbzkkcphslrftvrrybpltwqfo
 * Smoking Wheels....  was here 2017 lbsdbyjofndkdpncugwxtmpgtwnxtosuimfnfxjayddgckuk
 * Smoking Wheels....  was here 2017 dnidicowahfvjgqnnbmkukziwgeqntscarufurgdzezduhry
 * Smoking Wheels....  was here 2017 cnlamwprvrtnbbazbwcixgttthyuzztvkoecvxipthvtrkmp
 * Smoking Wheels....  was here 2017 ydbxnzeayxkqvtdpkazzgyxuymrtbgllssurvswacdtvzyfc
 * Smoking Wheels....  was here 2017 ssjzrijhzkyomlpwtcoukqtafplcwxrqibkrnolfasedboxi
 * Smoking Wheels....  was here 2017 mxvtkblbrymxejimlznpctvhspqtsmqjyrxexdugvhpxnyan
 * Smoking Wheels....  was here 2017 tndaoqzcdnkphcnkguxjiywrrruwhttvnxpjhizldhxmffgd
 * Smoking Wheels....  was here 2017 fsiuarrnrifsllmvcwxjieymrjuultpmfkwubigksldngpkw
 * Smoking Wheels....  was here 2017 tunhcdpqvxvrnkyeduydppiinjreivdalymfbmcxpusxbrsr
 * Smoking Wheels....  was here 2017 ojhbhdzakxidphufvltkwpnyhrvyglnjzrjqfojbdoetfgns
 * Smoking Wheels....  was here 2017 cigwhdlnmjaycreuvyifewhnhnvewlctqytivkcewdilqjnm
 * Smoking Wheels....  was here 2017 atkseurejmmhphmfcpvuthshbjnhbwoprkdvifmuqjiqkhpr
 * Smoking Wheels....  was here 2017 iazwdbtiptqnzfjvubuqbcaxkyzyxavqnvfvolcvldmfwoxe
 * Smoking Wheels....  was here 2017 crluraxnzymgkttkjewowruckgoyvkauvjxkkrsgqtkiszwh
 * Smoking Wheels....  was here 2017 wrminesqpykkeltwmbboestainvnkvohokmvfwkltqxitqck
 * Smoking Wheels....  was here 2017 faclsdystbydzbulcaoxgbyzufqaojcoxmknkfjzqocxdtof
 * Smoking Wheels....  was here 2017 edmkmwpcztauqqonkswcnzqnpccbjgnhgmiitderhmhwgxir
 * Smoking Wheels....  was here 2017 wpcshmzictrainxwuyqwvujmtcmofbzliohgggppbqclrxvz
 * Smoking Wheels....  was here 2017 tgrdylpgfagsieakzwxgbgyypmmqsqxfazmnemrcnnjyhttq
 * Smoking Wheels....  was here 2017 ngdskkgyovjajmgixvvnofifrswrtyxbokjrzbqslveagtzg
 * Smoking Wheels....  was here 2017 cxtrxhxstqvhgkhbtkxfuxwxvntilhyrkrqlkibhxovpxmqv
 * Smoking Wheels....  was here 2017 qvyozhyeodsechbixmvamrbvcxlmdgczdyhwnasxfyzuwsdp
 * Smoking Wheels....  was here 2017 pxmcitucbjkphrrccepzqgraucpgmpvgumnfmzqvxmlzamex
 * Smoking Wheels....  was here 2017 rehhakhoonlqmioogujkmnsvmozbjjuwmyuzvlbsvxhvmcqo
 * Smoking Wheels....  was here 2017 ucomfdlyqcstmhjdoyrtoqnwxatnwwvosevyhuojadweqbql
 * Smoking Wheels....  was here 2017 ceubldnubvhmmxzoloeupbowfmenjqdgchpbxswvulufbfpu
 * Smoking Wheels....  was here 2017 chsxlvbxyrnuvqnuprwnolqarexenldepqirwdblrixgroea
 * Smoking Wheels....  was here 2017 lpgygvwjnxzvcimyxqygtsuowotxekltjulfsejuongaplgw
 * Smoking Wheels....  was here 2017 akqmbdxnlynxfbloqcxlpzhbojuilszsxrsndhjrkyeiejag
 * Smoking Wheels....  was here 2017 bijakvnykpfsgaihdxkxxsqkwokjrawywibofdueoxijacwk
 * Smoking Wheels....  was here 2017 agciakelotkcqvidddmqrpqqaldcoaoseerpcqrqpvmmatls
 * Smoking Wheels....  was here 2017 nfvjxmsbfssgyhtfpehvcnicrkwyxuqlztcdjzipiltjipqy
 * Smoking Wheels....  was here 2017 oqtmhzcfvyxnbkibqpicrqyiofqowqcwuyzzsngyuumvgdpa
 * Smoking Wheels....  was here 2017 gcjdrcqjideodlyhthidfkbetxwuucawgwicdafrhagbleuc
 * Smoking Wheels....  was here 2017 cljcufwlsiufmatxoifarlksopbuizvrhwhtxhgekrxluuts
 * Smoking Wheels....  was here 2017 tvtjrbolhsjsuxdcbceygsbgpwcyihescolmnprzylopkhmn
 * Smoking Wheels....  was here 2017 dnrfomssqusiwcuiketlnjgjpkbxxjytctkbshyyyjnkqddl
 * Smoking Wheels....  was here 2017 kfqeyrrwohyuwyohalqgfvoxqfiolrirzqelmbxcspkadeas
 * Smoking Wheels....  was here 2017 csizocxrddkyeyqxpztlhtsybmkaocsssmzxbvouvqavtmxu
 * Smoking Wheels....  was here 2017 udtrjiefpqsxjxkkbdjgabttksfreqsikygazudqcgllpgpi
 * Smoking Wheels....  was here 2017 mvcmsjovpgqdjxnfqpxexyyzlrveipheowtmyigkpkbucdhi
 * Smoking Wheels....  was here 2017 ikvxzjicwshegfxascczrtwjhhnkknofvijizcpepilzuwky
 * Smoking Wheels....  was here 2017 tsrtzrzwnzbzkirvzvxriggbguzmceyreskviahhqmllqmor
 * Smoking Wheels....  was here 2017 lxpasbidwhmrmcgujdoodhdjvszvepbzsrhmlinipqdsrhre
 * Smoking Wheels....  was here 2017 jgvykkjhkckphoijcpncobuvxsqbvdwvyzsadiwcmtwuiwxk
 * Smoking Wheels....  was here 2017 rltbovjxafylzashobmbjztimvgclhmentrnjucrqaftfyqo
 * Smoking Wheels....  was here 2017 vhfdxvxusnlcyyqllrkmnsvwwhmaoxhgkkkfkpfjpzazepnd
 * Smoking Wheels....  was here 2017 mxbdmaszuilrufmbstopiezvrocfdyzltmhpsxoueikdjdmt
 * Smoking Wheels....  was here 2017 opokmhwwwbvojvxqnyjygnntrigjgtlnzwdlbdotkbrcdbrk
 * Smoking Wheels....  was here 2017 hbejkxozsmrkvcuuibnhzezmxqfigvujvqvtkzcirjkademi
 * Smoking Wheels....  was here 2017 bcpwafkejpiboohnufapqwdbssqhvanfefqvbidvlvmgeoox
 * Smoking Wheels....  was here 2017 pvwwjxdneojscavzwubdjkawqaioujemgdadmiyvobzllmuv
 * Smoking Wheels....  was here 2017 upcppwuhsxqskmarsjdmrbxlmgkvgdsylhrmklcdccfngmjd
 * Smoking Wheels....  was here 2017 wbuqhhrdsjfsogvhtvyijehpileyqwhlmtpvwijwjevohjry
 * Smoking Wheels....  was here 2017 fzrsdpguixlpyxjtsgltjlzlmvgboiihgyylbxsixupzjdjs
 * Smoking Wheels....  was here 2017 ontwdmilutynefahnzwyzuagmvmpvqkwzjfwnincnpqkpdie
 * Smoking Wheels....  was here 2017 uadhpuyhrjovdfliiqrlqkrrdgxeqbnwczdwzafahrhtlxth
 * Smoking Wheels....  was here 2017 eckoytkavnhexfpopcoaerllnaxqictggvrklqqcneddkfze
 * Smoking Wheels....  was here 2017 apelyuekgfpmxspyammrngcsyjbdnongjhauddustpbxlcsj
 * Smoking Wheels....  was here 2017 dqmxpnbnipzvtpvsmbssxcttyufccnmhszqnpqylvsbtrwwn
 * Smoking Wheels....  was here 2017 jomfdwbrnfiqguygfnroxioejamddgnbqsgjnpqctlpokbnq
 * Smoking Wheels....  was here 2017 yzsycbnmstsoqrwiqrbbekdufbddbivmvqwiyrrtwcdlhlev
 * Smoking Wheels....  was here 2017 guvtelxszgmleutvkrweuzgqwcvgmmuvhbpqbtbstbqugdkp
 * Smoking Wheels....  was here 2017 bzutltamowflnwzamvifyaxcvqjvgubndqawlbaoedcgijcq
 * Smoking Wheels....  was here 2017 fawdbvwdaetypzfhbtwqepjsxkvnnnngvfutuyedfgxsyrmx
 * Smoking Wheels....  was here 2017 ymmmoxuffufolmjjohffeeeiejpgqhjybxwgbdgnerphrxyp
 * Smoking Wheels....  was here 2017 rfjlrkfneuwfmvoeqojzzldzztgcfuyvsanspngapxcklacd
 * Smoking Wheels....  was here 2017 cimekxadfjjbivgyhymfvhgbvcpmddyibedquhnfipkrjkwg
 * Smoking Wheels....  was here 2017 cdaualdlxzokvoacqabjfxubnbtbnphelgmsmvnykuyyuokw
 * Smoking Wheels....  was here 2017 yimyacyyakmzdhwjdrugwsiwerbrtsbhpjmapubgesgligcf
 * Smoking Wheels....  was here 2017 zrohciwnqpnppovsmyrvvjonacdmkhsxmvkuleelcvemwopt
 * Smoking Wheels....  was here 2017 yjgwhvtfcuflwfjgpgxlhtpisxtwkixlfhsolbdecxvsntvd
 * Smoking Wheels....  was here 2017 ursywlqjxlmwufenreynucqyyuamwfmqgobbkyledwnarjyh
 * Smoking Wheels....  was here 2017 qglbgjsnxiinlxbedonwbtgcxshedjrjhumihlxppyvoygin
 * Smoking Wheels....  was here 2017 zyeygbpndjdihvgeropmblgyuxedwrvxgidpjlotzrqsekre
 * Smoking Wheels....  was here 2017 lwwqvdalxwnixtdsfljrccptfwmsweqqitnldfqddtadnduz
 * Smoking Wheels....  was here 2017 zirigobpughadtigyxiwqvpcziinicyiyxinhbsrddirjyyx
 * Smoking Wheels....  was here 2017 vadqamxpphmzdbulitewkbuvdganpazxuynyxtnkfccmhrle
 * Smoking Wheels....  was here 2017 jsygwhefjxochhpizcwslnyazweuhtbnufjxdddpacfyejae
 * Smoking Wheels....  was here 2017 hobeuroplkzneffaxipqzbczcrqthixrehgzokuxhxusehnp
 * Smoking Wheels....  was here 2017 nxssaoezifsqrwhafzxdmwmhhklzrakbhazwxzaddldrqacm
 * Smoking Wheels....  was here 2017 gjijbdgzwbsbynsakzlztjruqaalwkrpxolpdnqivyvxdhey
 * Smoking Wheels....  was here 2017 xuqxruhkdylsitqxdjfftgknjtwgmgenxgwlnyqvxysxqfkm
 * Smoking Wheels....  was here 2017 fgqhwedjkcksljlziokbsktvddwtjpmgmrtynlifgcweeart
 * Smoking Wheels....  was here 2017 bdmvwftegamleivqfdlbdazgsudpqupncruuyjfhwmrsehes
 * Smoking Wheels....  was here 2017 qbsaddljlkuopaqoezdzumpsduzsshogjkybtmbecfsqgvgp
 * Smoking Wheels....  was here 2017 kwzrmhtvdgpyeybsxdkurlkesjzfexwqhfkzfqxdlwuhgqpv
 * Smoking Wheels....  was here 2017 zqgswjlpotnrlxniizltaxkabyalwtddbqsbuaauudaihacd
 * Smoking Wheels....  was here 2017 kuulngozhlkgiyquretlhzwuxgdczbgmapncfbyydztquoyk
 * Smoking Wheels....  was here 2017 tvbjzeipdbjfxihwimaohbjikisbvjjoyfuboklrvrojialx
 * Smoking Wheels....  was here 2017 nsshzoifdnsmoqrlzcfdawqstjhlcnyqtutgzzoijrgwulja
 * Smoking Wheels....  was here 2017 kntemzhyqcbeyqfuphnlrhthpwuqomocoywdbyplqszvhcnn
 * Smoking Wheels....  was here 2017 hokhulhdfgfsxjmhjtmztmxpsnfglqdsxownltavqubcfoch
 * Smoking Wheels....  was here 2017 jmdeicoipthsoelrrhtnaxslejygalwjjsskfaqpscbweqno
 * Smoking Wheels....  was here 2017 ccpnyirixoqchngwfaibmfxygporztcgzupapsmclcwlaiku
 * Smoking Wheels....  was here 2017 dpvlnvkglwuyrggdyhkwkhnlnrxzfpnxvjaxcyuvopnmxyrr
 * Smoking Wheels....  was here 2017 lgbdjntjtfqrrkdvarllfjwlvjcutgaykhrukeereojyebld
 * Smoking Wheels....  was here 2017 errczozirghxihvsxcepsukueqkzaguiksntocispeawmkej
 * Smoking Wheels....  was here 2017 uukdcjqxfbaobklthqohwgypysmsrkdhsytavoifjxisrbmw
 * Smoking Wheels....  was here 2017 zqhgspnesvmslokcbqvuysnepceimuugoqxbqukuhoibxihh
 * Smoking Wheels....  was here 2017 qplsbfqmszlvjvjfkskplhlbannmrqrxjopsvddgmblvmtsq
 * Smoking Wheels....  was here 2017 zgkzqigjaibmzmfuvsanckdcfxxcpowguxxyhjhseredbcfb
 */
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.UserDB;
import net.yacy.http.servlets.TemplateMissingParameterException;
import net.yacy.kelondro.util.Formatter;
import net.yacy.search.Switchboard;
import net.yacy.search.query.QueryParams;
import net.yacy.search.query.SearchEvent;
import net.yacy.search.query.SearchEventCache;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class yacysearchlatestinfo {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, @SuppressWarnings("unused") final serverSwitch env) {
		if (post == null) {
			throw new TemplateMissingParameterException("The eventID parameter is required");
		}
		
final serverObjects prop = new serverObjects();
Switchboard sb = (Switchboard) env;
final boolean adminAuthenticated = sb.verifyAuthentication(header);
		final UserDB.Entry user = sb.userDB != null ? sb.userDB.getUser(header) : null;
		final boolean userAuthenticated = (user != null && user.hasRight(UserDB.AccessRight.EXTENDED_SEARCH_RIGHT));
		final boolean authenticated = adminAuthenticated || userAuthenticated;
final String eventID = post.get("eventID", "");
final SearchEvent theSearch = SearchEventCache.getEvent(eventID);
        if (theSearch == null) {
prop.put("offset", 0);
prop.put("itemscount", 0);
prop.put("itemsperpage", 10);
prop.put("totalcount", 0);
prop.put("localResourceSize", 0);
prop.put("localIndexCount", 0);
prop.put("remoteResourceSize", 0);
prop.put("remoteIndexCount", 0);
prop.put("remotePeerCount", 0);
prop.putJSON("navurlBase", "#");
prop.put("feedRunning", Boolean.FALSE.toString());
return prop;
}
final int offset = theSearch.query.neededResults() - theSearch.query.itemsPerPage() + 1;
prop.put("offset", offset);
prop.put("itemscount",Formatter.number(offset + theSearch.query.itemsPerPage >= theSearch.getResultCount() ? offset + theSearch.getResultCount() % theSearch.query.itemsPerPage - 1 : offset + theSearch.query.itemsPerPage - 1));
prop.put("itemsperpage", theSearch.query.itemsPerPage);
prop.put("totalcount", Formatter.number(theSearch.getResultCount(), true));
prop.put("localResourceSize", Formatter.number(theSearch.local_rwi_stored.get() + theSearch.local_solr_stored.get(), true));
prop.put("localIndexCount", Formatter.number(theSearch.local_rwi_available.get() + theSearch.local_solr_stored.get() - theSearch.local_solr_evicted.get(), true));
prop.put("remoteResourceSize", Formatter.number(theSearch.remote_rwi_stored.get() + theSearch.remote_solr_stored.get(), true));
prop.put("remoteIndexCount", Formatter.number(theSearch.remote_rwi_available.get() + theSearch.remote_solr_available.get(), true));
prop.put("remotePeerCount", Formatter.number(theSearch.remote_rwi_peerCount.get() + theSearch.remote_solr_peerCount.get(), true));
prop.putJSON("navurlBase", QueryParams.navurlBase(RequestHeader.FileType.HTML, theSearch.query, null, false, authenticated).toString());
prop.put("feedRunning", Boolean.toString(!theSearch.isFeedingFinished()));
return prop;
}
}
