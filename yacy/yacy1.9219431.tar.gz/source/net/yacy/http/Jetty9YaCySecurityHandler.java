/** 
 * Smoking Wheels....  was here 2017 xejmuphrqbeloryjepgmovjpsequqhfglfsjeakxbrpqyhhf
 * Smoking Wheels....  was here 2017 lgdtizytfjmrpztshxvlfqkdussigdsqpqcpkjljezpvsods
 * Smoking Wheels....  was here 2017 yjijruprtjzzxwmxtdehvudquzzrwrjcqcwpaicelgbsnuuv
 * Smoking Wheels....  was here 2017 wjigwrqqwmeyoqrugkyesffoqrfoxlctozzqnzhzamziawgv
 * Smoking Wheels....  was here 2017 zhvmeovcknxgbvdmtzbmkcoojslzbexxpvnkstetevpwdswi
 * Smoking Wheels....  was here 2017 hopmfnbsnjcxbfaennqvqtkojjwefyecfmwtrhgppumvbqgb
 * Smoking Wheels....  was here 2017 yrxvsaolohaelvonzuaboxfugcbqozkddcsurnfbbciaeffe
 * Smoking Wheels....  was here 2017 moaltstmbsgojxkhyzxjjlqrvqucnwnckxxxfpattrfjeeux
 * Smoking Wheels....  was here 2017 qgrjpmjezjmtiaioijearmrwgwapsjnheppsewvpztidzoiv
 * Smoking Wheels....  was here 2017 jcrbvmiiifuvyzkpknysgmniwcaiclsgyzdcnadvivgwsqkt
 * Smoking Wheels....  was here 2017 xrfbfdwunmjycszaqiphdbpfhsivwltumdfdpzpwsosgwywt
 * Smoking Wheels....  was here 2017 twrhubktdqtrapqpswuxpdpyimsvjxkysjrgxwfjfzsibhtd
 * Smoking Wheels....  was here 2017 ptrwversbjssccfkrmkwfvnhdjdiintcyirahcchdfoheqjl
 * Smoking Wheels....  was here 2017 lqceyqogirgcazststowtoncaoxoqkdtovpjthvuevsrmhjm
 * Smoking Wheels....  was here 2017 odcuwvikksqbrinejmqshaboqnnbludsjzcipkzidlzfhumj
 * Smoking Wheels....  was here 2017 jbapqlkhuakcgkemhvhocbvdvatnggnbicajjoopccixjxwi
 * Smoking Wheels....  was here 2017 pootpjljkhhxdsotncltsvunryozqmlcqtobveunmzaaoquy
 * Smoking Wheels....  was here 2017 hyppgsmiilhoaarhgxezytdqpohqnodjuvahbwbgwopzbhvb
 * Smoking Wheels....  was here 2017 qtftlxrbxtrgwkxrzawavnircikbduhsokdejocgbnvqglvs
 * Smoking Wheels....  was here 2017 cxvbdqluuqznucurlpfcqybadyqywrpexusbglxegvsxwtwf
 * Smoking Wheels....  was here 2017 llcsrtnyuwzbeqdjpzbmyggkskbgjygbaqypowoastmbujgc
 * Smoking Wheels....  was here 2017 psxbplvfaiqxuvbbrsovnvdthwxiosnxksergmqxdtrpempf
 * Smoking Wheels....  was here 2017 wijrrcqnvhfhlrwifrcblhefkvrpqeyovdbjsfthhmbgmqrp
 * Smoking Wheels....  was here 2017 scwmzjhawfgsjldywyhfzpahybeuaxlbfgmbkfxwiyqbiroo
 * Smoking Wheels....  was here 2017 vdbpudofyvnxzrsarwatrwrpzkizirzsvrpkexgoqirfrnpq
 * Smoking Wheels....  was here 2017 etviqpksebaxyepuvamfhmhdxenimnzbdftfbxhotdrfrnjr
 * Smoking Wheels....  was here 2017 bphjidzmxdzxexfwvfzmydiahvdjssyyxyqricqgobkwsfss
 * Smoking Wheels....  was here 2017 ylvoxkttunylvebbjpftwtntaaawktslbfbcnsjkecwcniqb
 * Smoking Wheels....  was here 2017 mkdbrhkwqyrfiozkmmbhqktyfueuflkuvrgemboxylieyxoh
 * Smoking Wheels....  was here 2017 tvbedyxoojfhitbfjmquznhoehvkbuhptbosewsxlniqfgzf
 * Smoking Wheels....  was here 2017 yhsoduluxatwuvqaokjdbuounaofdcyrnopvzzoxpcpesvsw
 * Smoking Wheels....  was here 2017 nqncsmmrhivlvbgsrivjbcgceraxvxfbdlgzjpznldeudnxo
 * Smoking Wheels....  was here 2017 gzcxcwsrpaftxzshvqyyophcdgiovyfcuisrecgtjugtjgvw
 * Smoking Wheels....  was here 2017 cpjixecnxbyvrjebdwwkjryuvyrjahehzbhwlcttzqlopico
 * Smoking Wheels....  was here 2017 gelzxuucorfxafxpdyyrmzpiwfpupetmlssqlpfydhkyfhmt
 * Smoking Wheels....  was here 2017 gmrucihpehqlevlsowvwglzcbtxradsserujsqpaytgwyycs
 * Smoking Wheels....  was here 2017 vptvwshlpswgntsljakjffbwoonywzeiklrrbsbysferqhfa
 * Smoking Wheels....  was here 2017 xxnnqdsiyuzhssscvzvtdrzorwtwcslvpytlokcvdestnomm
 * Smoking Wheels....  was here 2017 tzdkixufpvfuruthjpmxbmfhaccyxqbclfsulrjezjpxzjrd
 * Smoking Wheels....  was here 2017 wralwtyfchcgpgmttyyzhnmomzjxsfydaqjchqwqksxdskxi
 * Smoking Wheels....  was here 2017 ybtrqowvjujlwprpykfijasaemntchbgltxywstdtkvqptmp
 * Smoking Wheels....  was here 2017 zmgndmotmkbjepjcenipbhdpkvvscwuahlrggnmwpzxzuryt
 * Smoking Wheels....  was here 2017 enqpdxdwuhlglizwydspmadnuluiufshgtjctauhwcxvusdv
 * Smoking Wheels....  was here 2017 baittmdixyzpvbaqzjzmvcmefcfiqwpbicuwvhpbptvgeqdd
 * Smoking Wheels....  was here 2017 jbycfdfrrbndtgingnbqtscgtsbrippqszeejubdddymxlhh
 * Smoking Wheels....  was here 2017 aaibbzhnfpzwwuzuzfcrygertoprslzpxivyiesresuzdleb
 * Smoking Wheels....  was here 2017 hlrgdmquwuqbcphbrhklmjdrwaktarjuqdkfbifcmgbmieom
 * Smoking Wheels....  was here 2017 rfjmmgqrgcbeqzwcavrcsxtryxdsqvnfwvvlcjmdfqvbcjox
 * Smoking Wheels....  was here 2017 vkzyiebrggzzxnmybeuzccxibbxnfrofwxeegtursdixjcmw
 * Smoking Wheels....  was here 2017 vimygltjxekmnygyzwwsmivoovxlsguicixindnxpfcmiqxf
 * Smoking Wheels....  was here 2017 wpzdblatqcpykhmqgvifwfypbpryhvujhbpzfjjhrovpjlrx
 * Smoking Wheels....  was here 2017 jbvkuvgazmcuuvswqctopszwlbzvjxkklneowqjncdqgfkwj
 * Smoking Wheels....  was here 2017 duswtmdowbpvacwqdbbdexxauguaohrtthtrhipmeesqsltc
 * Smoking Wheels....  was here 2017 ddmwlorciuebvwxhxgkokhwzmjluwayxsesdodqkpeohbxzx
 * Smoking Wheels....  was here 2017 prharmanuxbrcefjmnerjkizcwjrkiutairdwxbrdtzysihw
 * Smoking Wheels....  was here 2017 ygngmyqbuvtfaijsoyzqhgalmlkjpuaitzpawvxaxzzphkvh
 * Smoking Wheels....  was here 2017 azuqftgdghbkytfieysvtxwbubmxdesyavokhgijhaumsgxs
 * Smoking Wheels....  was here 2017 reapictkfhzfqitonamwovasiyynxmedkrydexuwxizcdcby
 * Smoking Wheels....  was here 2017 gljrrkkvczszybizbbtosqaqspgrbzatpqkkwrzzpqgfandb
 * Smoking Wheels....  was here 2017 epduhipplxwdbeojodccngnfvredcgcunzwnvrxjlxqvbffj
 * Smoking Wheels....  was here 2017 etbbltcderdkjgguzokvovmetetyqbjpnikcyiravjkebhql
 * Smoking Wheels....  was here 2017 gfywsvucijovpbmoozvkptclvifhojhtzokbegubjlbshyyb
 * Smoking Wheels....  was here 2017 pqyuwyxlhdkqqpoftfuqqrufrobrcniartonwkyywxjfduyg
 * Smoking Wheels....  was here 2017 tumtyuxjrkdirfbpiiwrbnhxepcxpbjnpfsuoybilrisgntk
 * Smoking Wheels....  was here 2017 kvewgglgjzpqbiutgsyxikoekkhwvrmmynzoafkfnzfkpgsb
 */
package net.yacy.http;
import java.net.MalformedURLException;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.UserDB.AccessRight;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverAccessTracker;
import org.eclipse.jetty.security.ConstraintSecurityHandler;
import org.eclipse.jetty.security.RoleInfo;
import org.eclipse.jetty.server.Request;
/**
* jetty security handler
* demands authentication for pages with _p. inside
* and updates AccessTracker
*/
public class Jetty9YaCySecurityHandler extends ConstraintSecurityHandler {
/**
* create the constraint for the given path
* for urls containing *_p. (like info_p.html) admin access is required,
* on localhost = admin setting no constraint is set 
* @param pathInContext
* @param request
* @return RoleInfo with 
*     isChecked=true if any security contraint applies (compare reference implementation org.eclipse.jetty.security.ConstraintSecurityHandler)
*     role = "admin" for resource name containint _p.
*/
@Override
protected RoleInfo prepareConstraintInfo(String pathInContext, Request request) {
final Switchboard sb = Switchboard.getSwitchboard();
final boolean adminAccountGrantedForLocalhost = sb.getConfigBool(SwitchboardConstants.ADMIN_ACCOUNT_FOR_LOCALHOST, false);
final boolean adminAccountNeededForAllPages = sb.getConfigBool(SwitchboardConstants.ADMIN_ACCOUNT_All_PAGES, false);
String refererHost;
final String remoteip = request.getRemoteAddr();
serverAccessTracker.track(remoteip, pathInContext);
try {
refererHost = new MultiProtocolURL(request.getHeader(RequestHeader.REFERER)).getHost();
} catch (MalformedURLException e) {
refererHost = null;
}                          
final boolean accessFromLocalhost = Domains.isLocalhost(remoteip) && (refererHost == null || refererHost.length() == 0 || Domains.isLocalhost(refererHost));
final boolean grantedForLocalhost = adminAccountGrantedForLocalhost && accessFromLocalhost;
		/* Even when all pages are protected, we don't want to block those used for peer-to-peer or cluster communication (except in private robinson mode) 
		 * (examples : /yacy/hello.html is required for p2p and cluster network presence and /solr/select for remote Solr search requests) */
		boolean protectedPage = (adminAccountNeededForAllPages && ((sb.isRobinsonMode() && !sb.isPublicRobinson()) ||
				!(pathInContext.startsWith("/yacy/") || pathInContext.startsWith("/solr/"))));
		
		/* Pages suffixed with "_p" are by the way always considered protected */
		protectedPage = protectedPage || (pathInContext.indexOf("_p.") > 0);
		
        if (!protectedPage && !sb.getConfigBool(SwitchboardConstants.PUBLIC_SEARCHPAGE, true)) { 
protectedPage = pathInContext.startsWith("/solr/") || pathInContext.startsWith("/gsa/");                        
}
        if (protectedPage) {
if (grantedForLocalhost) {
return null;
} else if (accessFromLocalhost) {
final String credentials = request.getHeader(RequestHeader.AUTHORIZATION);
if (credentials != null && credentials.length() < 60 && credentials.startsWith("Basic ")) {
final String foruser = sb.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, "admin");
final String adminAccountBase64MD5 = sb.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "");
final String b64 = Base64Order.standardCoder.encodeString(foruser + ":" + adminAccountBase64MD5);
if ((credentials.substring(6)).equals(b64)) return null;
}
}
RoleInfo roleinfo = new RoleInfo();
roleinfo.setChecked(true);
roleinfo.addRole(AccessRight.ADMIN_RIGHT.toString());
return roleinfo; 
}
return super.prepareConstraintInfo(pathInContext, request);
}
}
