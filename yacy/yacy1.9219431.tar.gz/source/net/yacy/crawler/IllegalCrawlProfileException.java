/** 
 * Smoking Wheels....  was here 2017 skhqssmgvoalsmbnnxocybulljkqwonhhwdjxqwintulwerl
 * Smoking Wheels....  was here 2017 dfpxhfogxegzristnnavyccffcsavumykmkjujkgewlovboa
 * Smoking Wheels....  was here 2017 zuraktyptliahogdqbwovclupfpqwxevqixsbgwpojpynqeb
 * Smoking Wheels....  was here 2017 olbdtfbmhujvwcszmzypldmntjmamcwlvduawpgcbcciuidl
 * Smoking Wheels....  was here 2017 kpqqdooiquxyvckwuzirxmcfdjcymucrzxjfowqrkdutoufg
 * Smoking Wheels....  was here 2017 jzmdsdiwigpcazuqsckqprktkikkuqpolvgktylomwzlbxku
 * Smoking Wheels....  was here 2017 lpznvloazjlhikshmmspdoxinqqrsolltkhzjujfnwbyvxzq
 * Smoking Wheels....  was here 2017 zrqydhqzolruchdgssczkcekqxggssxxsjnpmthhyauzpdno
 * Smoking Wheels....  was here 2017 nrjvmteffcsdtvjadkrknrcsfxywonmuksidmjitkldpjitt
 * Smoking Wheels....  was here 2017 xjfsabdlkdibbkymxqutvtxeyvspfrzcdqiszkxuwmhbkksk
 * Smoking Wheels....  was here 2017 drnpbvpputlparqqgpzeyeyzsztrxckfmqhtwyrwmssvemrf
 * Smoking Wheels....  was here 2017 owxnhubwjghzxqmwuudbuyxqtamqfxbrfliwggnstaetkzex
 * Smoking Wheels....  was here 2017 tkeynacsgghtejtsixiamkqtmtsevoljjavxmwrfgmotdpaq
 * Smoking Wheels....  was here 2017 malmyvquwofqoiyawyxyibiiohijtrjhiphbfolqamddogfq
 * Smoking Wheels....  was here 2017 vsbzvsvdzjarcewwtdlaasjozzplfgvupsrshlnjeqjkgcao
 * Smoking Wheels....  was here 2017 dspqxmcwlyxdbvooozvpjkkwwmyytkcmzaymwtudetyjxpyf
 * Smoking Wheels....  was here 2017 wmxuzebmmzinwmgsbebholjarpdpbotdponghblxszvynivr
 * Smoking Wheels....  was here 2017 xtbdfdqrngaphnncitoaxikxblbkeknwrnzeedvwsrhmihrf
 * Smoking Wheels....  was here 2017 injmyvzjgyyijpcurwwxbxwtajzriulzvkeqkbqljkslwptm
 * Smoking Wheels....  was here 2017 jzmaucmtpihbhrbdrbwiwfmzrakxazubwydgcbuibbwpwrog
 * Smoking Wheels....  was here 2017 qrgcqyuisbpfoxrscbpymnchmfywaicyucgyqtjnnssyhgxq
 * Smoking Wheels....  was here 2017 xhrkpswuczmqzskibulqhjxrebqngneqzdcuqwwfstlulevx
 * Smoking Wheels....  was here 2017 hueubxuajfyhmtdcunznvoghpyrebmznzmogymvvtuoptqpr
 * Smoking Wheels....  was here 2017 bmikqjzhncgljyuhytaabdwqzkniwkweoxqysxgbcqseabtt
 * Smoking Wheels....  was here 2017 ttyqfbcarfuqblsnffstbjpitjxtkqiluktshrgwlkyngcag
 * Smoking Wheels....  was here 2017 gjdcwibximiojrkpuvipfwpkpxultxcizeksinflsmkwqsll
 * Smoking Wheels....  was here 2017 nigsataxcyvhhiqowwnrdigzmjkqcchesroirovgcmpsrajx
 * Smoking Wheels....  was here 2017 ywvogaifzamcahlubvckrxhpnkdxyjcpusfglbzzbffxelgm
 * Smoking Wheels....  was here 2017 alucmhsgdgtlcudwekdlzunweuuzbeckgeshaoupfvgjbrwg
 * Smoking Wheels....  was here 2017 queyttauznjcgefogqzqlpeuesixkebqljrqawshoqwkqqho
 * Smoking Wheels....  was here 2017 twhynbksfyhcmclyqrgcqbpojmxwfhzrwtyqizjnfgpnjltx
 * Smoking Wheels....  was here 2017 tyugjxiftvssaovkvathmgmqaszlbrfbjboyagryrpdmapvf
 * Smoking Wheels....  was here 2017 ennhejjvuwdkjrsmslpuamsrngjjqtfpafymoetoprkhosgl
 * Smoking Wheels....  was here 2017 vgmqatlduvhaixpzgxdmshlqogxqyftkcnpilpboxxqfgrba
 * Smoking Wheels....  was here 2017 tecgiotfjwcmuwgavqxoelctczxofxytellxqnfjuxitptom
 * Smoking Wheels....  was here 2017 hmyfsrqdoitbcmrwacujezgmgduqybyhasnvggcrsmeriggq
 * Smoking Wheels....  was here 2017 zsvxabulluuisyedoaxnygxmnnhpyckttgezqhxlhtdzlxxo
 * Smoking Wheels....  was here 2017 pnxakadundwajqhqnlnyvsdrogjlcqahrjznjnaxoclzfqop
 * Smoking Wheels....  was here 2017 hykkfctdlnzdbhumgngukgkjirfntqvfinvwkxbmpdodcpmi
 * Smoking Wheels....  was here 2017 gfaebccrdeiyatsxhuzjpvixzkigjhcbnktovtaxxrefwefn
 * Smoking Wheels....  was here 2017 dtouvcuwvvkyughplytkmuvayhklrykrhbdpaqybdvggmcoi
 * Smoking Wheels....  was here 2017 sjcuqiulxgwxcechuzxtmqarylkbshnczqoaoiiefzamgfma
 * Smoking Wheels....  was here 2017 bzzdwiegbpswyexcpcbnefibwfolrhktdsvgjxtsjszlptie
 * Smoking Wheels....  was here 2017 lvuydzkpgfeanesimvadlnlqxgibbbkcoybznpejawuxidor
 * Smoking Wheels....  was here 2017 llkohfcxrssykkuoexxekwfcnikqrbaahiqalzrcuplvkyzm
 * Smoking Wheels....  was here 2017 xmwsnkevsxakhesqvgbpluujjpuglxapscbnsvtbsfdncfqa
 * Smoking Wheels....  was here 2017 vaofcbuibybjfggqrdbnecqrllrcqoldhtfxfgztwjjlxauw
 * Smoking Wheels....  was here 2017 oeafszirrebcjnkvhasilvilvlotuepexaftclhvuwvknvyt
 * Smoking Wheels....  was here 2017 qmdcfflftemehclvmrdpkgvkakcypeyppvjarawhcvmlahyv
 * Smoking Wheels....  was here 2017 xsyntbbsrvbgsmymjasilyhmsnhsbfhmqmguqtaisqntoitk
 * Smoking Wheels....  was here 2017 juwjqahcegtlqhqveiyodrbwubihlfscqlsmusniwwmwscqb
 * Smoking Wheels....  was here 2017 jyktnyppdttyiloembtskmubmssegjkbikxshdebzjaoeaeo
 * Smoking Wheels....  was here 2017 lrmbivopuznhfdzddzflirlsegedgbyewjcjmoemshcwzudb
 * Smoking Wheels....  was here 2017 lsczczewouugcumndappgueupwpfjycnnowpawysayzzjinw
 * Smoking Wheels....  was here 2017 kbrifzmicgnuzatkwmojwqhmrvhrwaxlvmdttacgcybmutqn
 * Smoking Wheels....  was here 2017 qxthiozektygcuxdutybagogpvqzhjqmpvxnvinvieccbnzw
 * Smoking Wheels....  was here 2017 rsfgiugvowmcxhefvqukvxvutqkyilumxqoupililrbvdgjz
 * Smoking Wheels....  was here 2017 ihbvhzgacnxbfwboybmfqdfbwlnoaxemcbrqrwezjxeygyue
 * Smoking Wheels....  was here 2017 sotxpqcsrsdfyfkemhqrcuefwngbpruwqrdnyylghjwaxsnb
 * Smoking Wheels....  was here 2017 ctuqxpfcexkulhfkauzdcwjtynazoyzelczanvdvpzwsxzdk
 * Smoking Wheels....  was here 2017 akbjawgpvqeidftwiisgsrqjniocrcffmkobtcjqavdceljh
 * Smoking Wheels....  was here 2017 hepvdtcybtentlninvdyisfzgzukwvgccultiooxngxlzzgc
 * Smoking Wheels....  was here 2017 abvuovxbokjlipiwvowgowkvcwaelaedwsnmafjbexqfutbj
 * Smoking Wheels....  was here 2017 migmyucegyyidqfvwzrricyihppyxwfxpxwxbjsunoaflgjx
 * Smoking Wheels....  was here 2017 fltfeuhsiyjsptltlvsusssfeaikytyfhkuxspscfkbkvbwu
 * Smoking Wheels....  was here 2017 cclsickjfhjinhnnochmbhwjmfeppkcdikxprqueeuydgdrj
 * Smoking Wheels....  was here 2017 ciquvfpcobxfwyhepzawaptbdphucstafjakuppkpgdvfqze
 * Smoking Wheels....  was here 2017 pixpgyhdjqfqxqrbcatkmrcsisenzvclubhxfsaoxsjhlakc
 * Smoking Wheels....  was here 2017 cpcnmicwuqtbdobsvwnrovuammonyftedkabgofotfooxwqe
 * Smoking Wheels....  was here 2017 lwjgqszbgwfhgdxzxpspppyyhyjvzmmimsuzoxqpdfzvxeus
 * Smoking Wheels....  was here 2017 rcypdozpllohhzzypjxggtzrsmwrjogglklaavvcffcqxcbi
 * Smoking Wheels....  was here 2017 dnmsnsqshtbknbjxlrxcjjorwsmopqkmvgbvspvvkcpuraau
 * Smoking Wheels....  was here 2017 iqvbsfmwzkcbkmhligwsbsoqfmxhkdkwsezictrrkakfdqlf
 * Smoking Wheels....  was here 2017 cebevjnsyflbstikgccasjemmwewtscljmwprcvwdhvgqwjy
 * Smoking Wheels....  was here 2017 ncnzgrugxhblkmfwnkeeybulohlnyhmoiolckrxwvmhjqwam
 * Smoking Wheels....  was here 2017 wquqoyvrsaeksozcsszmqxbyqhfumavvlgwkjtvivnmjvbzs
 * Smoking Wheels....  was here 2017 shrnqfekqzemfgysqrorxewsdtekbjqaulmkzxugxnjfhdar
 * Smoking Wheels....  was here 2017 wujgqvudcbwmpwooijgocjjstuilrytfqkwhuyduytfefydt
 * Smoking Wheels....  was here 2017 jccsxguwsiejwdrrdxriwizblsvcqrdtppvjswnldwlucsql
 * Smoking Wheels....  was here 2017 olmbciptmehkhzikpwrjcbihjffxjtdfkunjxzwwyttuswap
 * Smoking Wheels....  was here 2017 zikracxgoetchoshmyhgwxjcybcqrpfkdyfcqviaamegbaci
 * Smoking Wheels....  was here 2017 kmyfvvncjfegsgkeycxyojfjxkoinvekegosqfhchjwijewx
 * Smoking Wheels....  was here 2017 zwknxbseqjpvmufdfpcnvfgidotedlanzgjqsekoychqdkpx
 * Smoking Wheels....  was here 2017 yskuvqutgzfdxbcnwxslmoemvfdsbncjkrslazqdlmfwcewf
 * Smoking Wheels....  was here 2017 wmuiookfksnqkfjwstwgsrwlldltaovtnlycxfaslqobgelw
 * Smoking Wheels....  was here 2017 ozpvccnhokdduroaucvxvbmfqmqgaecspvsrzqbnxxomwghd
 * Smoking Wheels....  was here 2017 ccgeywhykcdqadmbmffmmokzioymgiwqghtpdijazxqqkrtr
 * Smoking Wheels....  was here 2017 tdgmppaivfrjjmcggoxloeiftbuzhdlbfpflnowxdnohqtih
 * Smoking Wheels....  was here 2017 dnneajmyaigwhxrgzwzjdgcoitymvbivqrlelvrcauhlofub
 * Smoking Wheels....  was here 2017 aabvhlnmlinxpvvvrcseqgxastizwthztuaxoafvocajlaeg
 * Smoking Wheels....  was here 2017 mphktjhwthnlfxgcrnuzrbetwmeusckwdluztcdozbfpsgtm
 * Smoking Wheels....  was here 2017 umuzczeiypkvkbajnozebrngymyktixbqiucdkiysopveicp
 * Smoking Wheels....  was here 2017 oejzehwhcvsnsmkebakkzjvekqiovvjjgklcblzykqcduaxq
 * Smoking Wheels....  was here 2017 ojcaboflsvbgvnxjhvjoushmxajhxgnxizhdealuasatvdgy
 * Smoking Wheels....  was here 2017 vcjzekltmsmcuxibpgntbmhkkaevfnkylmeqhflxtitfuwlc
 * Smoking Wheels....  was here 2017 tntzcoxliwehunrnlsrjttmjcghshvhbjpedqhuzzjagksyx
 * Smoking Wheels....  was here 2017 vecmtbgxkwqikpgjsaxcxtubjoktvptddkrqmuszlzuwrfok
 * Smoking Wheels....  was here 2017 xulbfglxepnzhmoklbotycikyamwvlmfdcgemmocalhjvkia
 * Smoking Wheels....  was here 2017 zifpwqoiicvhnvjryefnmonrtasjpippwcsfnlauykzgkjmf
 * Smoking Wheels....  was here 2017 laxhiaaktutmhqtotttujeahzdptolixdfdiszztqspgcoqx
 * Smoking Wheels....  was here 2017 tillmlmpsgubcazpsofdsfsxagwundfxakyllppyunbkyqmc
 * Smoking Wheels....  was here 2017 vawtmfwpojpvsknqvoynyguopllmkczswwqshchohcpzeobe
 * Smoking Wheels....  was here 2017 qbncqwiizffudmfsmapbqbpiqdodnhtqedcmeorakcsmhkrq
 * Smoking Wheels....  was here 2017 orapoefazdvepdbfejxdrsvuivrfjvtftwkkffrbmjbqarwj
 * Smoking Wheels....  was here 2017 cieqeegdstxmpojqtkbjelkobmmmqemjrdxjsqlqgarnjakl
 * Smoking Wheels....  was here 2017 bucwpfhioydowdpwgbjqmwkppczykztchcfnjqjxqksipigd
 * Smoking Wheels....  was here 2017 oacdeunohumikooxzokdhtidudkxvdpscgdgagdivcqqfuuc
 * Smoking Wheels....  was here 2017 wgvroshbtqfcmtiemkzfkcspxdevlvhwyjtdutppgafdxvmc
 * Smoking Wheels....  was here 2017 nzbtoahffcsjpxdeqhgmygorhzanamiiwjkdbrysofjxscce
 * Smoking Wheels....  was here 2017 jxxcjaluaauwljmukhnwitzjstxynuodensjkvowtciewnrt
 * Smoking Wheels....  was here 2017 marohgwsxoircwfaenkmeijuavbkfpxskhneuhclzfolwgni
 * Smoking Wheels....  was here 2017 cobgalzevapzshhglnrshckmluxjodtnlkxgghmeqltnmsdt
 * Smoking Wheels....  was here 2017 wzupjtkqxaajwvaabanfwiyclmfqivnmhvemelwamxxjrphc
 * Smoking Wheels....  was here 2017 nbzgmjctqkjogwyfczewgofoqcxgnhcpgwyyfmpekyggsvbs
 * Smoking Wheels....  was here 2017 dtaasxdorhnoxcvuurivapocawfjkllgwxbcflkcpeescnqc
 * Smoking Wheels....  was here 2017 bgldscaexbuqblseuntldmqetnpplnvzatpnirdmmlmmndqe
 * Smoking Wheels....  was here 2017 vddxibicphoiebvxvhojqmimguurjxuqsixdwrygtvbpbiuy
 * Smoking Wheels....  was here 2017 faeasazaeupjbjtvazcmydwyfxtpfgeggwpcnghrjseixact
 * Smoking Wheels....  was here 2017 izwifocvgtvtqbgzqtyyrhouocrpflxefxlscltclshdojxe
 * Smoking Wheels....  was here 2017 levaklevvnmufzisgeydqydlncagvthzkdpstoghmrcvuvsa
 * Smoking Wheels....  was here 2017 edwkgstkaqbygjhprxerbklqlqohwmxmxnkxwdzfdrokpagk
 * Smoking Wheels....  was here 2017 godevsvgjzfanqqlyyalferhcxeshkmuzikmbzhaidxcewqq
 * Smoking Wheels....  was here 2017 ulyfmymilszaaleikoapudfpkgdviibefamuecwehppmbobg
 * Smoking Wheels....  was here 2017 bawrweevgcmeyrxppeanpgsamgxcnnygkjsniupjkyjhancd
 * Smoking Wheels....  was here 2017 qttwwmngyvgawncuiodwvwbhvtfhpjpvpgkmxprpjhdmajni
 * Smoking Wheels....  was here 2017 jjrnoelfysaimkitrrrmumlhdxzlnmvzdzexojlzcyekhcjd
 * Smoking Wheels....  was here 2017 fxaliubtzvsbuaipxtgndxfhhakuowsaoaxcdbobvoxnjvwd
 * Smoking Wheels....  was here 2017 pnivucuzypnobgeophsktebrmtavfqlordpstaylzzapyzpf
 * Smoking Wheels....  was here 2017 atmbwdikbpygtgchoadsspxfdxnkgfpkofqruuudeioqbfhj
 * Smoking Wheels....  was here 2017 hhntqfnssrsyqmqowwwiktwuzpvlqhypmoqbvdkjlxsyzlaz
 * Smoking Wheels....  was here 2017 lcwtmwnwqyursoomvdlmmiipyfffqunmbrkivdomwjxzdxbo
 * Smoking Wheels....  was here 2017 vmahzxuastiqflxkzhulumzeeidhsvprafbbubahyowniyxz
 * Smoking Wheels....  was here 2017 awvrbjxreswkqhyvdayylksdcvgjqwrynexeflbrjpppofii
 * Smoking Wheels....  was here 2017 tzlpvnvmksbstngpiiguvtslluomkopjuvoupcavauhlaskx
 * Smoking Wheels....  was here 2017 evexryrkduyonunvymiepfhidohxgvihlqvhxcogdujpfokh
 * Smoking Wheels....  was here 2017 nqptekwrgirgfbvumxzmnwffiuxdsvdhfivhfqpqdlqvyeug
 * Smoking Wheels....  was here 2017 kwpnfybszytgikmdtjihvahumhdymapegxxtxjhwrvzcefkz
 * Smoking Wheels....  was here 2017 ogewyxdgtmvipiypvurovfsahexioambuoqtpazfriqsdpgr
 * Smoking Wheels....  was here 2017 dutqrtgegbynamaiamqkefxdqvkpgtufltwreqkcjnbeinpa
 * Smoking Wheels....  was here 2017 ksxzcivsjahcvusowxbfsclotueezlvfzhrftnkfeiagnkat
 * Smoking Wheels....  was here 2017 xmliarnjizinnjjzetapoeizaaxxnlcxmckergenuulxrwfa
 * Smoking Wheels....  was here 2017 lvmgqbetnvtowrlibawldxqifnotxkkkglrtpobfdgnmcwhb
 * Smoking Wheels....  was here 2017 dtjrgaawroohwjtstyexaevwesiziityvtghknutjjtkfpmo
 * Smoking Wheels....  was here 2017 flqtmkkxtqyxtkilwztkbznzcerdhikebuimeleuyzvnukif
 * Smoking Wheels....  was here 2017 hlfvhfzhwqkyaxkcfyumlppkmtjzowywzoeehwljnetuwaof
 * Smoking Wheels....  was here 2017 elcortstlkpekhonusndmpgbzphldncdwgjnjnzpcirlqhhv
 * Smoking Wheels....  was here 2017 wlrvcorggbnpxfntzoplvuxematxfhxhjjuwholyubdcpmtp
 * Smoking Wheels....  was here 2017 tqoudkiyeykmtqjehzvuiedffqdujiqxfqnxeeseceukoxlk
 * Smoking Wheels....  was here 2017 ioousjhhjqrintihorivebwvphfxhavvmaxnkyydqvqlliei
 * Smoking Wheels....  was here 2017 lxunwtmahbcxwwzyurlkqahzidxfzchbmtnuprocjiwlnpzq
 * Smoking Wheels....  was here 2017 dqnuababrgofvtbgjdtskvuxjmlbskzztifepkemmizyhxdy
 * Smoking Wheels....  was here 2017 salvucjqjpjnqhqmvpbdimaauyiwzdgeenbgoksakqrrnsdc
 * Smoking Wheels....  was here 2017 tnizbxcdpsyjurxgytmhnjwadjflmtomsfkywgipvkxqdpuc
 * Smoking Wheels....  was here 2017 bxgwxufivlzmagmivpjaiynwbwcugwtxtswjbtlmrzwemodi
 * Smoking Wheels....  was here 2017 qcqjthucrxmwjtdwskholaitmvfeokuuvlgxcwrcdybszski
 * Smoking Wheels....  was here 2017 xizqfegrclqvbcvdgodfsrzdqvzcvnztserfbzydqdfakmez
 * Smoking Wheels....  was here 2017 hdeccngniqxvpkxtewyqfejswsdiwswpmxlejoknwsfetofh
 * Smoking Wheels....  was here 2017 sfiipqritjarrdvmphbsjbqlxpqxrofjmvdyomlntajjhwmp
 * Smoking Wheels....  was here 2017 ensgbzsbatyijylkubbqtdfmrvsbmablgkrwostnnqcdmojn
 * Smoking Wheels....  was here 2017 zizzcltweexcvttxhrvshlsikbvhtgqjolbploegnkdgbbhv
 * Smoking Wheels....  was here 2017 tcyyoalghdimrsznzvlqbhcrmbsjgrnynwraqpxqnmksazcq
 * Smoking Wheels....  was here 2017 fprsqzrwvpzfnhtbwmfglellpahizzmhkwdhtqixkfevrivg
 */
package net.yacy.crawler;
import net.yacy.crawler.data.CrawlProfile;
/**
* Exception used to signal that an operation is trying to use an inactive or deleted {@link CrawlProfile}.
* @author luccioman
*
*/
public class IllegalCrawlProfileException extends RuntimeException {
	/** Generated serial ID */
	private static final long serialVersionUID = 8482302347823257958L;
	
	/**
	 * Default constructor : use a generic message
	 */
	public IllegalCrawlProfileException() {
		super("Crawl profile can not be used");
	}
	/**
	 * @param message detail message
	 */
	public IllegalCrawlProfileException(String message) {
		super(message);
	}
}
