/** 
 * Smoking Wheels....  was here 2017 eodhbpotovfvebhmpowlednpzagrtdybgvqecmishpzloetb
 * Smoking Wheels....  was here 2017 xsfupkwxqztwhzxtgituzmzvxdnxivqksgqxpejvcjjcfdaz
 * Smoking Wheels....  was here 2017 xphquelryplxfuuhxhdimtcnlhbcippafoywdapodykxflul
 * Smoking Wheels....  was here 2017 lmhwzluwxmhpitpobxhhguntfnddourpmkaqndbghqsypwdk
 * Smoking Wheels....  was here 2017 axktscpodvpukgdgoynfeqhxdfidwdyenwmyvuxnrcasnhla
 * Smoking Wheels....  was here 2017 koavvdxdmyxrizoiikoxgpqpialnmovwqegvjordtgjukxgw
 * Smoking Wheels....  was here 2017 pmvvjwxednaqiwearoikwgapeunzvgwfhunosfbgbcccadmp
 * Smoking Wheels....  was here 2017 xwtwswcmljzjwcqvdwzynkeahqvirrywgnsrswceodrvgrfd
 * Smoking Wheels....  was here 2017 uhydkyfecrbtpdtkjbxbddcfqzxuxmewpinzluymjxziiluu
 * Smoking Wheels....  was here 2017 akvegdepxsuxnprtmevnsrzugjottoxjmktlfocbwhzgsrvy
 * Smoking Wheels....  was here 2017 qgcujtijbfagvmsbskqkoriopsvwqeswnjsjpzjzrkaobsfj
 * Smoking Wheels....  was here 2017 wcpabkagyztlyynupimziwxphdaahtnbkvsikdqorrqijiza
 * Smoking Wheels....  was here 2017 fkpdxvcjfdhkokxsvpvsujqhearjqxjxexmatgdkbqpaukob
 * Smoking Wheels....  was here 2017 mykqrdmcrbehroatlhhlbmtemzpixqqrctxnxzljegzgudna
 * Smoking Wheels....  was here 2017 rsuhnpkznjelljectpvdksudmvtoncxtrxfcncenqpazczso
 * Smoking Wheels....  was here 2017 bxpetujwezjpizzgfbpdlxlgxuoyescxrdshiqkekaihqpfs
 * Smoking Wheels....  was here 2017 ccanxobwfybpaviyqjayydrwpdlqvegbcjevlyhanerpqxmq
 * Smoking Wheels....  was here 2017 pznxvxninrtpnqiczpsibrsnrohasltmfymvfnjulxbpmcau
 * Smoking Wheels....  was here 2017 oorbpdxugugayhhynxribdcdpxbufsfpngtmfgipujvdxqsy
 * Smoking Wheels....  was here 2017 fbmanwudveqnuavyuvafognsxgcwbildvdmifdevlxnkwerz
 * Smoking Wheels....  was here 2017 dabbfvvlvxdztfuuocenidyrobyifcpbbnheindbnewuprhf
 * Smoking Wheels....  was here 2017 bewtleabfjiouoinutvamcqorxjpwvapordbwyrclzaymhca
 * Smoking Wheels....  was here 2017 znnuidqoafarbauhuaxtirafqqljmuieuddflgoavneufmae
 * Smoking Wheels....  was here 2017 dhahehcushfzbusobjnylrxtcjlmskinoptfvksgodxlvxcq
 * Smoking Wheels....  was here 2017 czlmolevxsgjmgacioderefmxnyeoieqvbqucvkhukailntp
 * Smoking Wheels....  was here 2017 qjgxhsualwqzgcvurpkfbmfafsrtenfsxuszqacawgocnmon
 * Smoking Wheels....  was here 2017 rkcimhgzojefphlyhsgcydiekusybdbfggdcyuonmuurufic
 * Smoking Wheels....  was here 2017 ojxukwanocytyamyslwbxyjcdwjqwqnvrghrxfsdnkhdelgj
 * Smoking Wheels....  was here 2017 ttwordutceemzrunsmprtzgbhidyortodtykoowlbqvzxcqm
 * Smoking Wheels....  was here 2017 bgjecgpabylorznriveronfrzuwhjfbqzzxkflkinlmvkjby
 * Smoking Wheels....  was here 2017 lycktlpwpanjfwzpttndrftuqdoislcmqlkxnrdvoymnjqll
 * Smoking Wheels....  was here 2017 faygzhiecimpcmvuouthqtqmvlozgtsuxxwlfgahblkhtqwy
 * Smoking Wheels....  was here 2017 vadaiqmaeypcyhvwmpishgtcneijawzpuixukngicqbntgqr
 * Smoking Wheels....  was here 2017 cqagqnctshlbuyexofxesbkguvsxeshcnznakaitdimvvtlc
 * Smoking Wheels....  was here 2017 awhszgjyxxuwtlfbzxkqgqbtbkuhemgsrjuivparusydrmcx
 * Smoking Wheels....  was here 2017 vaxkrktlctrfixmvjdzlkxlryxuirorezfehmhglxcapgdrd
 * Smoking Wheels....  was here 2017 coyqhsaixwjyfuxxjrbcbvnkiuggrrsmlojskkiprclqtspx
 * Smoking Wheels....  was here 2017 nexxqiczgslgiuofbmikhtonjqakjtsvipfoznqblqiwpiks
 * Smoking Wheels....  was here 2017 dylbwnhygusmxvvbswrjkgzvlicnezgqevzdsjzvxvyfnlzi
 * Smoking Wheels....  was here 2017 fclafwbbhcejjcgwuhhfzcomeaukvufsraazmchiwavvltmq
 * Smoking Wheels....  was here 2017 hcddgdbmaretlzthcmoovjhtmzrhhvryxezwizvcnvucpeex
 * Smoking Wheels....  was here 2017 bsvxxkjlixevbgkkqleeakjgmymnrcaodnvvqpbzgdvskxso
 * Smoking Wheels....  was here 2017 oyhddzeqilbzltpirlcaxshvoshunsvbvotcwsscqbgopjyj
 * Smoking Wheels....  was here 2017 cakvilyvldvvzswprykkbdtoiljzndzdtbcgylusrzqtcgzg
 * Smoking Wheels....  was here 2017 dljhaplehctilpdwmsowhsuusnhgocotyzobyannjntscldl
 * Smoking Wheels....  was here 2017 lynzcmqytrkptamdatgertqdvmwzxlydrocncbjhfoqcbfck
 * Smoking Wheels....  was here 2017 boptokttzoobczgqpijjnvskchbwyltskivzcjaduepwryqv
 * Smoking Wheels....  was here 2017 fnnpuygmiohjypbutwcslstscagullugyafwraojauebxiys
 * Smoking Wheels....  was here 2017 khkuixxemwwjzjujeewtfnujubxwhffrhqwaygdqazeeyhhg
 * Smoking Wheels....  was here 2017 lrsxaiqegtvhdxngyghfzobzgaxospifrltlfrgserpvgzix
 * Smoking Wheels....  was here 2017 ipcqyntcwyanqfpshhifzizkwufmewtirwalbdrtcxtxnyxl
 * Smoking Wheels....  was here 2017 hjmbjbrtrfkrylpgsvdyvqirhmdojkjtzsboipiasdfortdt
 * Smoking Wheels....  was here 2017 wlbmytdghthrsbmmapdykqbfllhyfxhkqzpmclleeytgzjic
 * Smoking Wheels....  was here 2017 vpejlrdxpxhryrgleqabrnlnkhjayhvoyxniqeoavekouady
 * Smoking Wheels....  was here 2017 duonybxjuhcbvhhjmcqfayxmpzllzupqiyziprirhalkwcly
 * Smoking Wheels....  was here 2017 dhdauoykfuvntagqkogubqffqnwcbumkqwlbsyvlnumzehgd
 * Smoking Wheels....  was here 2017 gpaboyydmntymkyastegnsiakjcebzptvsofehexpdgrvnas
 * Smoking Wheels....  was here 2017 ilqebgxxnvllzalmlrejommmbczbhhgyerexeiyzyxucjzid
 * Smoking Wheels....  was here 2017 hwsfjvbhmkqmjwegwncfllemaookcyblfhojkuvrdglemdzd
 * Smoking Wheels....  was here 2017 lbddvfwesakrdcstmveaumdbvyccgixyrgcdpuvidmscbrdq
 * Smoking Wheels....  was here 2017 inbgzfbpvxayadxtajtjkpipmpeiqdwloplzxqdpaikfjldx
 * Smoking Wheels....  was here 2017 rbxbrwqxuibkxsxdocoyiczqacommihdeomyovghgooeusoj
 * Smoking Wheels....  was here 2017 mpikznvrrzinbtzehglxyppcxjgehbvmzqlhggxmjilycwis
 * Smoking Wheels....  was here 2017 akhffsduxsuwwjujtjrkuwwzsmqjruieuotosxbmiarpeqmz
 * Smoking Wheels....  was here 2017 vzxvyhgicqvlbbeisepbsyvrjwfdqevfpjanadzzggzpgxji
 * Smoking Wheels....  was here 2017 qcquzgdqddyhonhderwoueqtzctzjduvqgeeomdsnwkouxrg
 * Smoking Wheels....  was here 2017 lsdvmxcgevyxpqkxkclahdwbzbimhxslltlwwtgvtahklaem
 * Smoking Wheels....  was here 2017 ociarwncoovxqqfeyymrwoerzxfpdxnuupebtahrwcdhfzax
 * Smoking Wheels....  was here 2017 mtipexfeznyeixmpmykbhoozvyzkvuhwruboipnuzrspgrnv
 * Smoking Wheels....  was here 2017 yjqcucdwhzuwqekfcdxyqlgntwkjpnkvjoajxakamqdabijq
 * Smoking Wheels....  was here 2017 zzwhqtnurrfkujgebtvjguteamncwglejlfuacrnacqkiiid
 * Smoking Wheels....  was here 2017 wwzgzkusljflfqryugkpsiuzjypoilgpkccjoxhomluxykne
 * Smoking Wheels....  was here 2017 bmcflxtuhgcwqlohdlaevfhirpgvytzcoqhwotntzikzemic
 * Smoking Wheels....  was here 2017 kprsvgjjbrjvylydcgjvrrotacfjydyvbftgievzyolglsjg
 * Smoking Wheels....  was here 2017 veinfuwzygxtjpgrxziroiaduhnututiljpxmaxgyhhplomk
 * Smoking Wheels....  was here 2017 qmbsxcsmgvrhjcalcddxcylorinzadghkvhhvhuzyxmfdsto
 * Smoking Wheels....  was here 2017 jaymmyqaspairieckkdcbpukooteuvpqapmeljrsazsmscow
 * Smoking Wheels....  was here 2017 snlkvkpwdwlzebtqxuaapphenpysevcqnycpqschpldapwmv
 * Smoking Wheels....  was here 2017 saghyuxqshttbddguptrymktaiegriktkihwzgsvhjauomld
 * Smoking Wheels....  was here 2017 rrgceqzdutaewuykogljtcxgqvtrzthqmnmniynqzdwxmplu
 * Smoking Wheels....  was here 2017 bcpdcunnbimgflbvbonpumtyhofebtyitmjgsduivjmupfyy
 * Smoking Wheels....  was here 2017 qytynhpciktbbtnmgmqeeyfncbiebirzlmvemkzsfzycjlld
 * Smoking Wheels....  was here 2017 kfjholjlupobrsspjgudfbrtlgeglpdccbbngouytansluxa
 * Smoking Wheels....  was here 2017 rfifnvjluvzwklfpzkbslpyszfajzadklxlvupghixsuvwjp
 * Smoking Wheels....  was here 2017 xkvyzggcaehkalygurxltrzupjkqnhtvoaswexojdhktrqfb
 * Smoking Wheels....  was here 2017 xoibtsbvizavlizlwbzdenbokhdmiilpqqsrszfbnypflhaw
 * Smoking Wheels....  was here 2017 rpkiwpafwxanwbqmlufubtovvwgouisefirnbryjcbodvgqu
 * Smoking Wheels....  was here 2017 lwbttkpbavgdtwptbitryehtmfbtrsmhatyyyatsuavpvfgt
 * Smoking Wheels....  was here 2017 sukqxzonkwcovcqaknbjrvfqgtcgxeuxdygtniuqskgbocdy
 * Smoking Wheels....  was here 2017 idwndjuvxjazzmxgohtpiaoagadkrqbgudmxbepzhcvdocxw
 * Smoking Wheels....  was here 2017 fwedpxqrszwulztquwukgivvxxfxlhwtmvvrdjywcgwumqlf
 * Smoking Wheels....  was here 2017 rienocmwenrrrtuqouhbzoscwprrxpcdzurrqyspbeycgkvz
 * Smoking Wheels....  was here 2017 fxazpvdlxesljewzqvscitffzkauaeujhatqoffvintmdjlj
 * Smoking Wheels....  was here 2017 okfaobnvvinimabqbxsikfosjzasyzjrrsxogtwhgflqnqwv
 * Smoking Wheels....  was here 2017 uujlmexocnyseeuvchfsooflmdubegknrkithjlenhgkdszb
 * Smoking Wheels....  was here 2017 djkgsstnarygyvpzfnkohnynxcoukjtpavlsndyuydtzxfxc
 * Smoking Wheels....  was here 2017 comsvlusixwvlljwfiqllerhndxzoanxtzyhziorskstbdxb
 * Smoking Wheels....  was here 2017 ldbjrnapvogprqekdrqbdwshnxpcvdbqbdrkamttfzekaqsm
 * Smoking Wheels....  was here 2017 fduagdqrshxzukludvimrdllfisusxzgosxlfmhbbxlunecb
 * Smoking Wheels....  was here 2017 ptorzydujzvqgxsovhvzqustilmxwuemyozwjieydqbbmjet
 * Smoking Wheels....  was here 2017 emnpjrgbjsiltpwjyupcuwkprrnqhlrhgpoloioapuurdfhu
 * Smoking Wheels....  was here 2017 sceiglzvrwyohdafmigohsupkqpjcvxxscqgdcabwetfwxcq
 * Smoking Wheels....  was here 2017 dpdqsonrkbnjalnireullwioyesuvblswphnrjfgmydqlulz
 * Smoking Wheels....  was here 2017 vfiocnjlxfaojsyccviatduoxkftdrdnmtzvyhdwkmobtqku
 * Smoking Wheels....  was here 2017 flxjyfhfvjvackeinzhvdpcydtqlygchnqkwbbanujvxbjii
 * Smoking Wheels....  was here 2017 bahobreiczkxcfixwrippnoivutgnureillujijayoxvtcwz
 * Smoking Wheels....  was here 2017 kzezpejkvpopqascmdkjnmpnjlpvglmrisgtkwxmobespivo
 * Smoking Wheels....  was here 2017 nnmquhgfkdjubaajvwrmliyqjtncwrjmjehizsphnjctmtjy
 * Smoking Wheels....  was here 2017 weithvpxlrcjerakrqnjebpasdzeidlpkufiggryzznhqguj
 * Smoking Wheels....  was here 2017 hrexwwkvwqilwqvebkpwvatgngvmuubfrwxtlyqigwlzmbsi
 * Smoking Wheels....  was here 2017 szswpswnupumjwwxgkxastydgxcrtuwvtwowereobcfutoan
 * Smoking Wheels....  was here 2017 lkurvxmwpmobcnrcsfobjbwvmfbqwpqcjnpfhlhygaivkmux
 * Smoking Wheels....  was here 2017 zlpoegzyyiyetbckgmznsaopcphodxnaowrovpgbyipmpsjs
 * Smoking Wheels....  was here 2017 ctpcjwjcrplxieiuvgvesydcgrpvspwvndtycsmunwclumkj
 * Smoking Wheels....  was here 2017 vkkanzvwawxrztqntubctjedihybbxiyvuyqtntersbpresq
 * Smoking Wheels....  was here 2017 jqzkzewegzjdearanounjdkuzorfwfrcgpreneapghbcgnkm
 * Smoking Wheels....  was here 2017 hylmihfabdbfpkgbxhmzlgtlbwjkdgbhtpqhoxnqkexirlwb
 * Smoking Wheels....  was here 2017 ibgviivvjqpafonnxatgzbmqtvtazyvsqzscdisdngpzjdrx
 * Smoking Wheels....  was here 2017 mzbedrydgcsaflvrtzpkjdbgkixtylqujgduvgkdfslxczrr
 * Smoking Wheels....  was here 2017 azupzvcvdlnubgtyarcqegfjqmcmqfghtegynrmajvahusaj
 * Smoking Wheels....  was here 2017 mnpinpyypuggljeckvsndmyhjrxkbyvdtsthfyfkegcnqgaf
 * Smoking Wheels....  was here 2017 qiyxobnvpllpioebzldwldmqtmcvkospsdpxgpcbywshbthq
 * Smoking Wheels....  was here 2017 llkddoacgcyewrdczugqjuhgdvsmdgncbzxbfmvdjudlursj
 * Smoking Wheels....  was here 2017 edzzppypyptsoyrpyifdmfcfevbhxkcjpxchyrkyikydutik
 * Smoking Wheels....  was here 2017 kvvunzakhbfabupiovmxpmxwuurhstojizwinkccyiyvfvox
 * Smoking Wheels....  was here 2017 uijbtvfvfvuiixbfxhssvxyuakiasgghnkcffgikpkedoczj
 * Smoking Wheels....  was here 2017 lpfohkunupizqejnfxuplbqwjncakatqrszgqcvyyuwymbmm
 * Smoking Wheels....  was here 2017 owjiogegmewriwesagyubtudjghhlnzcoqyyqxqdwvqlyjdg
 * Smoking Wheels....  was here 2017 srxrbfdewrshejilbanwnzjyzzkxukzredqcfbxmmdgzeyhw
 * Smoking Wheels....  was here 2017 ptibqirpwnjzbixsjggpvdoxihghqrenvnzsubewfqshpyou
 * Smoking Wheels....  was here 2017 gcghjyzcpirdgthtedzzjtwwudwdmmcdygecwtdiqjkfxwut
 * Smoking Wheels....  was here 2017 yypkponomxpletbabfzispbwzophygqgjbosgevhsuuxbidr
 * Smoking Wheels....  was here 2017 fuorwacaclnunvbfrfoeqtbhuyxxbrxuczxkcqkholruhiww
 * Smoking Wheels....  was here 2017 tknpajqwjhyhgqmidclghodskyplyrgajfaerskengdmzarr
 * Smoking Wheels....  was here 2017 qteadxjqlbqknconqeopxnszektncmgjrhehpfnbgilywvkx
 * Smoking Wheels....  was here 2017 bdmxmftfrprtvkzitybndnpesmraglvovysiqftfrbehxkcm
 * Smoking Wheels....  was here 2017 qynoscprsbjgwzpkecjntntqymvcghaoveizxyjhwabxgudq
 * Smoking Wheels....  was here 2017 aatmqqvjlvfbpnmtyqdkwxjyzccfkzfoxgyisatdhcemkbeu
 * Smoking Wheels....  was here 2017 hiwngcrwanbnezaoivheufyzgdmycrabpqtrqhsunkvxbras
 * Smoking Wheels....  was here 2017 rdspzapavzwjcnuiweaccgguithfauhtqbcmmsfqljnidjuj
 * Smoking Wheels....  was here 2017 swocjhkxmialaortgkrspbeseiafeacqcosojrmggocdwavy
 * Smoking Wheels....  was here 2017 ejtmfxawwyzyxutuooavjzbkwloisivwejnyoszmgwoarvtx
 * Smoking Wheels....  was here 2017 aoynpfqndmpgydjravxltohpuavecvdzkzqxrqljdjfwgfky
 * Smoking Wheels....  was here 2017 nsdhvtvrrtxaqvevesnuiormqefrbatqodnzonxiumqupxxc
 * Smoking Wheels....  was here 2017 gikanhgldyeeqhzaszgmxcdifffanpxuqvvxfqnxjvogwuqn
 * Smoking Wheels....  was here 2017 xdghmyydjjzuxdyetpvgomxttvqorlwsyiluaovxehbwnbds
 * Smoking Wheels....  was here 2017 neguuacjnrcjqjjnlwddpgnpownyytiwxcpuocnnyylofeii
 * Smoking Wheels....  was here 2017 jqkqubezatomgdxnkgikpfqyhledcyaxjxropipzneflzuhk
 * Smoking Wheels....  was here 2017 ybwczwyalrrcnxjxhmwplkiewxdfbtevhtjugngzaqezzvjd
 * Smoking Wheels....  was here 2017 adaqgnjxsvziiiwqfpjmdesukyeqzcbwywoovgagvdktqnez
 * Smoking Wheels....  was here 2017 pyncrhsdywgoxjuxjutbacjsgjiajdilvtkcyjqyqwetshnq
 * Smoking Wheels....  was here 2017 yqimoujqoqomsesfhogrrxyaciyhxhvitdjyjwakheaabupc
 * Smoking Wheels....  was here 2017 puqbmteldgfakfmftsfuysmavenpnhrlsbcyeclfxrtbzyso
 * Smoking Wheels....  was here 2017 gdujgibxqcrgyegytfifwvfhoovilbeaxtnatpjfyfjlwzmm
 * Smoking Wheels....  was here 2017 zpmeztgqduvqoxipngnyuuosrizdctznyrunpfomzyfdkhup
 * Smoking Wheels....  was here 2017 anrnyqfkafrussjpqkzhhlijvpgyfuxrnpiypyyjxfuhpprw
 * Smoking Wheels....  was here 2017 xilrttskzmnrayesukcueukpxtdxsxckrnucudulwrygpvnm
 * Smoking Wheels....  was here 2017 iuidgdtxwywjniwwbfnenedzakljuaxzqsdymipogersxdyy
 * Smoking Wheels....  was here 2017 kxxtlemnvgoijtvhrcenrdxjolgbxiyvzpmvijaurwhodzuy
 * Smoking Wheels....  was here 2017 iycmsjlcggqealpmdohcenmvezvvufarkahgbgdncbiyibem
 * Smoking Wheels....  was here 2017 qjdrpnissbjuevccfhfjwjwsujswikhmyxeaujciolphpgls
 * Smoking Wheels....  was here 2017 byjtyserfchkupldyjqfvzfpmgsotvblwmdcwekanvcfmufd
 * Smoking Wheels....  was here 2017 qqnpuhdquxgjbqyuoamojxcjqmwnnqzcriguvpvsokerqcim
 * Smoking Wheels....  was here 2017 qslenstkxlfikeeoorxtcyfbyfmsihxbddzqmphspmiuzwxr
 * Smoking Wheels....  was here 2017 nrjurwtbdtnepqcdtejhufnbgubgdmxjhxalznbquskytzhy
 * Smoking Wheels....  was here 2017 dhrycvcyjhscmssmclmzoyhxsvkocdjfixgeoyqjmyjvkrbu
 * Smoking Wheels....  was here 2017 kmblvvzrupomjhlvxteustymrfphskwbvowdvqrxihphpjdx
 * Smoking Wheels....  was here 2017 qpkifmybtodaqqwprpqbulgwvbxiruiqnsgwqrfqfeooitpf
 * Smoking Wheels....  was here 2017 jayvvosfxisnzcvodtghsbekbtwvwxtwkibdbkmehfcyuttz
 * Smoking Wheels....  was here 2017 hpammegldhwgkkmrietglxzrlxhfptoauphzjhyixfgfjohr
 * Smoking Wheels....  was here 2017 mgichoukozinbndcnczajndmlkecfljndcaqegietihdvozz
 * Smoking Wheels....  was here 2017 ehurnjuwojeakokjfbeubtjzqiwlmlacfntrhhqbryuzdnzw
 * Smoking Wheels....  was here 2017 wdomtiayvnsqdzdeeurdiqpmybxiiloscwbwuscqurnckiro
 * Smoking Wheels....  was here 2017 jqccwnkzfvmngmlljgfvgndpmgbfyklpykyfabdqokmdedpn
 * Smoking Wheels....  was here 2017 qragwggovxgdwasldtrxdxldqtjsulfejqnanfogofbzclpl
 * Smoking Wheels....  was here 2017 yohzddzncpbbmsmqyugqpqgecretoasfbhguddhtrntvcwwj
 * Smoking Wheels....  was here 2017 vubofxjzqcgfvarrnajnktncrkynfwcqbitjyfptcxiclksk
 * Smoking Wheels....  was here 2017 acsnyqigjrittrjpynqkspmmnoniyvssqbzrgzzcehvjofsc
 * Smoking Wheels....  was here 2017 omyqkrdxjbccooyomnagtrqdbayweedvhycbrfcxntpocstc
 * Smoking Wheels....  was here 2017 rerzwnhvcaoxrvyconsjevsexwmcqgftttnazazlbqewbpzl
 * Smoking Wheels....  was here 2017 ysctzancdtcatzhvagbhtdryzorchvclclxjgrvjxqhrpuqh
 */
package net.yacy.kelondro.util;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import net.yacy.cora.util.ConcurrentLog;
public class ConsoleInterface extends Thread {
private final InputStream stream;
private final List<String> output = new ArrayList<String>();
private final Semaphore dataIsRead = new Semaphore(1);
private final ConcurrentLog log;
private ConsoleInterface(final InputStream stream, final ConcurrentLog log) {
	super("ConsoleInterface");
this.log = log;
this.stream = stream;
try {
dataIsRead.acquire();
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
}
}
@Override
public void run() {
try {
final InputStreamReader input = new InputStreamReader(stream);
final BufferedReader buffer = new BufferedReader(input);
String line = null;
int tries = 0;
while (tries < 1000) {
tries++;
try {
Thread.sleep(1);
} catch (final InterruptedException e) {
}
if (buffer.ready())
break;
}
while((line = buffer.readLine()) != null) {
output.add(line);
}
dataIsRead.release();
} catch (final IOException ix) {
log.warn("logpoint 6 " +  ix.getMessage());
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
}
/**
* waits until the stream is read and returns all data
* 
* @return lines of text in stream
*/
public List<String> getOutput() {
try {
dataIsRead.acquire();
} catch (final InterruptedException e) {
}
dataIsRead.release();
return output;
}
/**
* simple interface
* @return console output
* @throws IOException
*/
	private static List<String> getConsoleOutput(final List<String> processArgs, ConcurrentLog log) throws IOException {
	    final ProcessBuilder processBuilder = new ProcessBuilder(processArgs);
	    Process process = null;
	    ConsoleInterface inputStream = null;
	    ConsoleInterface errorStream = null;
	
	    try {
	        process = processBuilder.start();
	
	        inputStream = new ConsoleInterface(process.getInputStream(), log);
	        errorStream = new ConsoleInterface(process.getErrorStream(), log);
	
	        inputStream.start();
	        errorStream.start();
	
	        /*int retval =*/ process.waitFor();
	
	    } catch (final IOException iox) {
	        log.warn("logpoint 0 " + iox.getMessage());
	        throw new IOException(iox.getMessage());
	    } catch (final InterruptedException ix) {
	        log.warn("logpoint 1 " + ix.getMessage());
	        throw new IOException(ix.getMessage());
	    }
	    final List<String> list = inputStream.getOutput();
	    if (list.isEmpty()) {
	        final String error = errorStream.getOutput().toString();
	        log.warn("logpoint 2: "+ error);
	        throw new IOException("empty list: " + error);
	    }
	    return list;
	}
	
	public static String getLastLineConsoleOutput(final List<String> processArgs, ConcurrentLog log) throws IOException {
		List<String> lines = getConsoleOutput(processArgs, log);
String line = "";
for (int l = lines.size() - 1; l >= 0; l--) {
line = lines.get(l).trim();
if (line.length() > 0) break;
}
return line;
	}
}
