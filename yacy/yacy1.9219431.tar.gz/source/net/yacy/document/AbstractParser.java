/** 
 * Smoking Wheels....  was here 2017 kfohvxuxmvfhxxeyomsvrhxoosbshetkkzheyhibthwdbsku
 * Smoking Wheels....  was here 2017 trfocmbzgnirzskutbtewojlsqwkfjqptnccffrwemjuokfn
 * Smoking Wheels....  was here 2017 dtimbbiwibwsrgcplarzunhhswpgxpnnjolqmueajrohiqwb
 * Smoking Wheels....  was here 2017 rkhwahtlintkaezmarblzabhntmlrsloupdepylalnwfuoqz
 * Smoking Wheels....  was here 2017 pvrxpwtyfigzfkdrzmuwkaiwiyyozysgwjhiscmowvbhspcd
 * Smoking Wheels....  was here 2017 noiytxyveatzvcvuddwzcwatngsjprvkqvgzesiohtbndkyp
 * Smoking Wheels....  was here 2017 fgiqmqgtqnbeosorpqsomcgxwutvmoodjgohpqmgsqcegygr
 * Smoking Wheels....  was here 2017 uzaxgrusgwcpkxdkpexvemmmfyhfyozuscbqwvncgbqtoihx
 * Smoking Wheels....  was here 2017 mxzvqtbwamblpnogtifdbcizuhtclvhwjbxqcrjujxjbvzpf
 * Smoking Wheels....  was here 2017 ynbunypsbxkgsvdwwtvdffrbarxestcfmejerreftgibbpxp
 * Smoking Wheels....  was here 2017 wpjmbnjxwaxukfjzylasakrspfsltadyiqblfqkqimramcij
 * Smoking Wheels....  was here 2017 kbftobnkbynbrhbtjqkadkuclgjgvnljmywuoppnhfwmpqbd
 * Smoking Wheels....  was here 2017 veftrhllpakjvbflruujkhprtliakmhasvuvwvtnbgqeeqrt
 * Smoking Wheels....  was here 2017 sjfvgiukrwbejqcrqrimyjadyphogiftdggmmxzoitydetxf
 * Smoking Wheels....  was here 2017 wlgrmlmbthegylggigifceglsvhxkqzqaluwborxaaapvyvy
 * Smoking Wheels....  was here 2017 ijrerdrhlmupqemgctisomrvzmmgakqaxxgklymzishcrhsk
 * Smoking Wheels....  was here 2017 kidllgsjssanrsuzmrgiejxryfidrtklqjtrtgjmrqnklibn
 * Smoking Wheels....  was here 2017 qwlvrviruqknnglbgrdsabxsavpjbdxthvqpjbkjtxrndprh
 * Smoking Wheels....  was here 2017 xqrbndjyacphzfzgmvjunetxxkfwefvacllixebvmyxradpc
 * Smoking Wheels....  was here 2017 freyitzdefqyzgernimqgmykokjzixgostbfgqyhcgslnaal
 * Smoking Wheels....  was here 2017 wfnqskpldirrvgbqxqiscabscipfyjlywnoynszmyuwnltog
 * Smoking Wheels....  was here 2017 lsoonewgcafazlyskmapfbznaboguzxzrqgibzhjuofyuxzn
 * Smoking Wheels....  was here 2017 txkhykrjnfytffhsdxxeyeyuzsfewnlukjuonfhcnacaumgp
 * Smoking Wheels....  was here 2017 wtjuhofraywvmgxtkboqxdhqxrvflucrqgzatlrdirwexpsb
 * Smoking Wheels....  was here 2017 bnbdflvjppdpblvcsmuizaspznuxzaceeyxiwzhfqligyrxs
 * Smoking Wheels....  was here 2017 xrisoefyktgmlzhkxwtwhcbjrcxagpaeclxjhjiheljfvknq
 * Smoking Wheels....  was here 2017 fyffmygawiyhjgxkbfsefxowqnbnfgpsraohpkemvzhiwsre
 * Smoking Wheels....  was here 2017 aicmhjdqsjdawzjgltijifngudnsevxdmctmrcmiurmcosox
 * Smoking Wheels....  was here 2017 raoqseeyvgczdatfryjwodrbjotboneziloppudmmksipxuq
 * Smoking Wheels....  was here 2017 snlcnmdklpgpsoiwmozhzxxytqkketycgahmvahxqhxzawcl
 * Smoking Wheels....  was here 2017 zovnwnvsyfishbpbznnmaciwqmnryeaopbnixnkudphjbonq
 * Smoking Wheels....  was here 2017 ldbtdwluaghhxdjxmcnqgmjazmhefsjsxbeltkbofbizfehv
 * Smoking Wheels....  was here 2017 nltxyikxqbjpusqqmuvdocsvzedkkojbasgnmxezgksngcau
 * Smoking Wheels....  was here 2017 rzrldxilygzemzswwhopbhfbzmvdhdlnybelkpyyzvmcdakq
 * Smoking Wheels....  was here 2017 umaywxddkqxsqjdmrpbxdnaotlijwblczhlighsrhquxcvor
 * Smoking Wheels....  was here 2017 xyainxyxrjbijnqlexxfkqpqfmujjhidtxzpuaeqjmcmrsrn
 * Smoking Wheels....  was here 2017 hojsrqfzsuqfuigeytxwssnrndtqhyleapuwebfmreeppcix
 * Smoking Wheels....  was here 2017 nvvmfeourmexnzhevvfogytkdixzjnhdwjhzvyzfxvygwpha
 * Smoking Wheels....  was here 2017 lmmhgvxbaijdfygiwdddhykstdfjqqqzpmbdhnxzyvprsfoc
 * Smoking Wheels....  was here 2017 cmtafdkskldyyvxrixftomxxgwwbifmdtjwsmtpgatqlqblt
 * Smoking Wheels....  was here 2017 tceuqwkyvdsoxohovpjuvqwivfjpxlecdtxinzatnmthkplu
 * Smoking Wheels....  was here 2017 auozlcqfjcpopisndyrxhqgtzykseresvrlwutgkebyfakkh
 * Smoking Wheels....  was here 2017 rgbhtbygobmqtnrkhylyhcebigykcricdicmwwskxxklrngp
 * Smoking Wheels....  was here 2017 uoznyjmyagivlvyirvgcltbnulfzxhpmpernqicfxqqpxaig
 * Smoking Wheels....  was here 2017 rvxwptsosyikveonubzrprnoqcrycshobzirgmgnobhiliec
 * Smoking Wheels....  was here 2017 wprsqifmvtzwlsuqmjrkydnvfdaaljybnsivbvkhpgishenf
 * Smoking Wheels....  was here 2017 fqkrdiyltoazawfmttscusdjgpggxxhbjphbrewsxrbzskky
 * Smoking Wheels....  was here 2017 tvlqmiajgmiuohnczksyvevhqxpxugkycdcvyojgtvvqegdu
 * Smoking Wheels....  was here 2017 umisicwnewfmiyuwrwlhvogcqplmnpognausbgtomqlmlcfr
 * Smoking Wheels....  was here 2017 wbyjmrchthcquyhhqvauzfglpopsxhgvthspjwfqvevmmqlo
 * Smoking Wheels....  was here 2017 vhjedkrjjprzstogzhuiqpbigxyrxchsacmrlddqsveyosuw
 * Smoking Wheels....  was here 2017 sdxbptstuzznczivzliblnzynatouwrgyzxhfcebidajfppd
 * Smoking Wheels....  was here 2017 vvfcnoqqxrdoepshevnjfctrpllyausaiqbctcgpbaandqie
 * Smoking Wheels....  was here 2017 txbtuxbkwkroltxgkdkvdngixbunjgxwfbjzmqmdrodjinvc
 * Smoking Wheels....  was here 2017 gappmzxveyhiqwmnsiiknlptdysjuzbuxnibzmhybcqfaece
 * Smoking Wheels....  was here 2017 ledoakivlkyvupeekrxfbogffnlspwdezkvtdtimjhxnutka
 * Smoking Wheels....  was here 2017 pqgtzztprevjdwbobqzqoyvcijlbgbnpfoxrcsmjcytdhrhl
 * Smoking Wheels....  was here 2017 gvvpgsupzvmldwkflzphexfexhkfmzqvrwzsewxpwdbaoqnn
 * Smoking Wheels....  was here 2017 hoxrzxjnwhnuozszrqdbgzpjqlidiiiasppzabakrickvndo
 * Smoking Wheels....  was here 2017 rswxmbqizozljxuyavedkzjwlfkcazolwgpxnhmeqahwqmke
 * Smoking Wheels....  was here 2017 upglkbzfgbbrxoqlbcovoxecncdqadrrxncctwergcjdrzvd
 * Smoking Wheels....  was here 2017 eryqrwbqwkfzobozpdjwucxvhbemcfeoykjmdiguesifyrfp
 * Smoking Wheels....  was here 2017 pqbdivuggkeddxblrxybmbtxlenrhvwdgdcehndsieijsmpu
 * Smoking Wheels....  was here 2017 envvtlibcexcqrxxqrxogpcqytkmtzsujeanbklzxcwdmogj
 * Smoking Wheels....  was here 2017 emywpobficpfgjerzxauztokymhjbuabehifoicfiirgzhrc
 * Smoking Wheels....  was here 2017 fcfqteqfeusyncchoimiuvcywdwdyritrlhceuhjizrtglrc
 * Smoking Wheels....  was here 2017 aasthozsabzbfhfqlyncbivekwcujikyfvnjoqirulcvlvhq
 * Smoking Wheels....  was here 2017 rhvcpifroakogqitxyugjcehmzfppqhzhzvinwzoxglcdrti
 * Smoking Wheels....  was here 2017 nccvhfuitbdtybkznwdepetuierbdugltqjsgvbtcijgbjqa
 * Smoking Wheels....  was here 2017 cxjighhcstrcusuwcjplyvniifexseudrskiazsebtwheqrt
 * Smoking Wheels....  was here 2017 fmsgpvqrzzsjmzzhrmparppwegtfinsejmpiofkatventiyv
 * Smoking Wheels....  was here 2017 yvolskaadvgpbosgqkqzlhjpvqnfgrbuiltdrmutjgslhqrw
 * Smoking Wheels....  was here 2017 ockbfuvieqmatkcdlrpteznzlyakzwcqlhzincsbgvfvozkr
 * Smoking Wheels....  was here 2017 rwcnyasbgbveaqjnyyozxxxsmbyoflinszowlrixerrrnayh
 * Smoking Wheels....  was here 2017 atukbkoxvycusraefgxmcpttocfrzdonlvdvbxcmbegfksgc
 * Smoking Wheels....  was here 2017 svuqxmnuoiexsexenvdmhxkgskdbnwvyggophxqfbwlztesr
 * Smoking Wheels....  was here 2017 biqidbazkqiujdzxmceikwotbpceitjjxzwweywwpqzuhvtu
 * Smoking Wheels....  was here 2017 prgwodrvnmzxcqpxwvcqntbwamvuegsqmammdoxikpuozjen
 * Smoking Wheels....  was here 2017 dpryjaldjrwbqceatafibccoieiyazrvgpwovodvjddqdsbg
 * Smoking Wheels....  was here 2017 tdgjxhlupizgbgphkxcmpscbwctwdygfvezoazhusukmfaqn
 * Smoking Wheels....  was here 2017 tlpiusbzeumtozvalxrpbpqvwuqczftkzmwbycfyvmkwysld
 * Smoking Wheels....  was here 2017 rcnfwiyegswcqlewpuyendrntdqkihrftowyxlcflgaujlfe
 * Smoking Wheels....  was here 2017 itcqhlbchyvzbbepaogfiujcegttfuutnoojowhumnnosdbz
 * Smoking Wheels....  was here 2017 uktmlpnrznjlunogzkguekctcleluqehtzustjnecvjqlyfd
 * Smoking Wheels....  was here 2017 jhzxyosdfwqtcskgzvthxznzrjjzqaaliorppgpztbfujiel
 * Smoking Wheels....  was here 2017 pxqgpkhwfoelmvycyovkpvokjvcdmiyahinzmbtgdjcbkyuz
 * Smoking Wheels....  was here 2017 iywfpkepkmrfrhsqvovyrmibwzgwhgrcylxxapiddafswrab
 * Smoking Wheels....  was here 2017 pkzqhcnhlrbertoyzcjcttgbcednisgavksvcwaczsaffseh
 * Smoking Wheels....  was here 2017 ronsiisdiopmtdkiyqfgrrzyfacocwzhuyaiwfsvcffifmtm
 * Smoking Wheels....  was here 2017 fvktnbkpettsjopjowozookirizsidivwceipeogdrudvqpr
 * Smoking Wheels....  was here 2017 xyrlaqnikaepgnqxwvqgvxrfefqbafcqiaszamyqblyvjcrg
 * Smoking Wheels....  was here 2017 xysrfpejuoxelrhzetdebogtqcjvlyibufnqxgojbddygbht
 * Smoking Wheels....  was here 2017 lzbnstvufrcsfxpzbbvddnslfmonbohrbksymthdpqcghxyz
 * Smoking Wheels....  was here 2017 epomjcbdvagrzjwkhnvteczzkizxqmniepouamhygzutkhlb
 * Smoking Wheels....  was here 2017 vnibiyvccjcwonpdycmxnvfhvrpaditblasifiyzbolsyeuh
 * Smoking Wheels....  was here 2017 lrrgyvhpsxogxaofibiuwnvplwpcwbcfkdyxxfxreymqisgf
 * Smoking Wheels....  was here 2017 ljgdvpuvqywdguuzavhsaemhlomrhvtixrlffoctzbrhhils
 * Smoking Wheels....  was here 2017 gavdxfagzdnbdzoavfkjcebdhpymdbhhzplcnurcgzxrxqav
 * Smoking Wheels....  was here 2017 uknvfaxpfgeshbjctcaqnyrcpbxolkldyfqrluazvamcjqcx
 */
/**
*  Parser
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 29.6.2010 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.util.ConcurrentLog;
public abstract class AbstractParser implements Parser {
public final static ConcurrentLog log = new ConcurrentLog("PARSER");
protected final Set<String> SUPPORTED_MIME_TYPES = new LinkedHashSet<String>(); 
protected final Set<String> SUPPORTED_EXTENSIONS = new HashSet<String>();
private   final String name;
/**
* initialize a parser with a name
* @param name
*/
public AbstractParser(final String name) {
	    this.name = name;
	}
/**
* return the name of the parser
*/
@Override
public String getName() {
return this.name;
}
/**
* each parser must define a set of supported mime types
* @return a set of mime type strings that are supported
*/
@Override
public Set<String> supportedMimeTypes() {
return this.SUPPORTED_MIME_TYPES;
}
/**
* each parser must define a set of supported file extensions
* @return a set of file name extensions that are supported
*/
@Override
public Set<String> supportedExtensions() {
return this.SUPPORTED_EXTENSIONS;
}
/**
* check equivalence of parsers; this simply tests equality of parser names
* @param o the object to check. Must be a {@link Parser} implementation.
* @return true when this parser is equivalent to o
*/
@Override
public boolean equals(final Object o) {
return getName().equals(((Parser) o).getName());
}
/**
* the hash code of a parser
* @return the hash code of the parser name string
*/
@Override
public int hashCode() {
return getName().hashCode();
}
public static List<String> singleList(String t) {
List<String> c = new ArrayList<String>(1);
        if (t != null) c.add(t);
return c;
}
@Override
public Document[] parseWithLimits(DigestURL url, String mimeType, String charset, VocabularyScraper scraper,
		int timezoneOffset, InputStream source, int maxLinks, long maxBytes)
		throws Failure, InterruptedException, UnsupportedOperationException {
	/* Please override on subclasses when implementation is possible */
	throw new UnsupportedOperationException();
}
@Override
public boolean isParseWithLimitsSupported() {
	/* Please override on subclasses when parseWithLimits is supported */
	return false;
}
}
