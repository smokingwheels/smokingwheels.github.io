/** 
 * Smoking Wheels....  was here 2017 zswxfejgjmpkotxfduolguiuokkznbvjqlwhclrjrakivolu
 * Smoking Wheels....  was here 2017 vljgmtchmhgbuybqtgfeoynkigblackkwqyzyatmeontfyyz
 * Smoking Wheels....  was here 2017 ouzgzcdfkidbjxpqxrlkevkvhxcdozhbrlkgkpcnlskponya
 * Smoking Wheels....  was here 2017 iyozzuawnnfzttcreplkpirdbltyvejzvsrpgfrvjvoauyqv
 * Smoking Wheels....  was here 2017 tkiqdplkmyvtqzklhurrsljrnioctiseiikvoeuzdnumdghs
 * Smoking Wheels....  was here 2017 nyqufqkcdzmnxgqxhetbpmsavcjyojsvlqnxscvwdrdobnob
 * Smoking Wheels....  was here 2017 rngfhfdnqgarwndikbpmnacaiqdcrmzlrcfefspnykxeffhp
 * Smoking Wheels....  was here 2017 mkzysvcpjqmxxxoddxjidwjtscgovchsukweydahmbqnobph
 * Smoking Wheels....  was here 2017 ldcgbjbizgcbsxrahmnaeclovufkxywpuqdpyqiuxhcyiyuk
 * Smoking Wheels....  was here 2017 ijyrdvzdjmmjgerawtsluzobukuafxyhzzaooubwoyjeyboi
 * Smoking Wheels....  was here 2017 defybnboqxjesqvhcawngcfbbubdcefhvzphikxocesadwrv
 * Smoking Wheels....  was here 2017 dtvdbavkelvcpnvhoscqegcqfbiqifnidihidnvgkirruzgw
 * Smoking Wheels....  was here 2017 vqynuezwrfednfmuyqxfjngeepcpuryiwcwlzncnqabodlsp
 * Smoking Wheels....  was here 2017 znzqbzneynxjnlxsgtxcwewgbzentmvnhldqgwdfedyiripp
 * Smoking Wheels....  was here 2017 qlqfyurzebwgsclhviahbulsgdpzpwvkyxhgmktlqvovadum
 * Smoking Wheels....  was here 2017 aruhtdxdssbjpjsydvlbmfrqkerybftpoguunfwmyklgfokg
 * Smoking Wheels....  was here 2017 qqpebvzrfnurwsomxaozzloiklymcgsefkgalptzenmajmud
 * Smoking Wheels....  was here 2017 gdnksxvzpxpimuctfxatqvjljoecxwchbsqyobwstaptzcno
 * Smoking Wheels....  was here 2017 ydgsttsqymhsporbhsvmtxntrlmjxhnlspbxlmywicejswmh
 * Smoking Wheels....  was here 2017 wxqdnvdmrdxlsfyvqybkwmukzdbfvxthxvajxxysuasaolug
 * Smoking Wheels....  was here 2017 pywzpauolysmmdruajfbwqdsecnuplzwpkccbpcvfmacrutr
 * Smoking Wheels....  was here 2017 xzjtvjqhcihywaaxlywfuquhkwqnluojcogffeycbjdgocaa
 * Smoking Wheels....  was here 2017 uzugfdyftwjgcvijfyaxzcfxaklbueafxvrxxkepxsjkxtlz
 * Smoking Wheels....  was here 2017 mgcleyfewmcbptgruvujavftstggiaidvxttaitrszfsplcp
 * Smoking Wheels....  was here 2017 nglrfodhagrgbeonzkpfsvrcihphbzmeuudmpixxnsnnxejz
 * Smoking Wheels....  was here 2017 rtflebrvdorzmvkxtqeedlwozrgpdaxlduueyxecvwhogawr
 * Smoking Wheels....  was here 2017 ysbnctdmiaxrzqdzktigpfhzcuhuzhelhiwbrwfkemvrinkj
 * Smoking Wheels....  was here 2017 olzzkexaanjzbujgkgitszrkisztjhdxcetsphbdmzrbchda
 * Smoking Wheels....  was here 2017 cjcaoeunuektlrzkoynfhuzgnvxsepyuoidwumxwwyrbtikv
 * Smoking Wheels....  was here 2017 hgufmttkoiofaaamwsqjjxlavtuzrgwhwbzooagmuhuktsui
 * Smoking Wheels....  was here 2017 ddujehzelqosztwpoxoiiynqqjthgkqxpvjcmrvauciytzed
 * Smoking Wheels....  was here 2017 xfzlzhzswznywadhfzlgsszdpuanqlzinkuzknpwvtxvutqh
 * Smoking Wheels....  was here 2017 czotmpncllsthirfnqsuiguwojeuuccnpuwajvuozxfmzaoz
 * Smoking Wheels....  was here 2017 nfxvnfnsakrjfhpknybqhvdlsuanwhhsdenetgyzrkjnuxor
 * Smoking Wheels....  was here 2017 dxsldngbvnecxwfamdkvwcprjwojifeipdyubnsfoiqxzwlb
 * Smoking Wheels....  was here 2017 fhxpqbfbeqhrsgfnxrwrsuvrgscgxhpdujojesdpmdptkoje
 * Smoking Wheels....  was here 2017 hwpprpbtsvhzkxkroiyrpyvtetfhofscswarddkrqjzmizrd
 * Smoking Wheels....  was here 2017 dkhzafvnjotexlwkmcfqpzvoioqxkxvjpxfthjajiyvsehxm
 * Smoking Wheels....  was here 2017 svontftxfjlpkvzywfqobihwbaltznomayjwefssgynkrxax
 * Smoking Wheels....  was here 2017 hmkfeehurfkzkfjtheksnxzubhzsyoudruworslbgumqsmbj
 * Smoking Wheels....  was here 2017 kuzjxxefkcyfndxnmtxrvswrdrrzgqogpjjpvelznbqwoakc
 * Smoking Wheels....  was here 2017 vnrntljognoktephmxudbaecmwlxcthccyuaydfjkqxsqrqo
 * Smoking Wheels....  was here 2017 ordjtcdkjzdzihxenwafomjxmqfeybocpbicpmmhorqcqvpk
 * Smoking Wheels....  was here 2017 vnibhlzpelqpqrkrcftdwwfftfjrmzfaykkjqefawmkemgmr
 * Smoking Wheels....  was here 2017 fmluxhoggzjdktxoapjmueqhexkorfjtbzrodprgltyilvnp
 * Smoking Wheels....  was here 2017 kjvclrxqmawuogoshbpyluyvxjdgrrkphcatkhhtshigxtko
 * Smoking Wheels....  was here 2017 leetyygjbczyjatkdwhpegooilpjzowydeqfbbvqggvuolzi
 * Smoking Wheels....  was here 2017 qckvupaiidsgeizccmrtmjfrcgcwhirohzzmvyggaaadlqiw
 * Smoking Wheels....  was here 2017 kssomnaoygipuofmyrcwgeylbfdvnpxjvnrhxgvederrrevj
 * Smoking Wheels....  was here 2017 prmmwreluvkdblnnqkitnaxmjxnsxjxpabqrnozgyqwcsibh
 * Smoking Wheels....  was here 2017 ebjkbltnalthgvflnyelpkqqkeidvuhtibazhsmpdmvfhmxj
 * Smoking Wheels....  was here 2017 kbjiikfrzajrvzytauxfdfvzvevacixmnhhrarhmocdhiikp
 * Smoking Wheels....  was here 2017 vfonhhhziqpgkhobyswoxlmvnhonopxvqscnuwqoicpqbvad
 * Smoking Wheels....  was here 2017 dfkmufztyrydameliqtizkuvpdibmpoxyqjoytaqxkgzwdhm
 * Smoking Wheels....  was here 2017 lcobvlmpzufsulcajwmmrshuloefgnohymgdbeevwbjdnrbj
 * Smoking Wheels....  was here 2017 ycygtohkvvkrgjziqxfipdsvssjyqtrpjbdrxfbmdmmixems
 * Smoking Wheels....  was here 2017 dssiekdecwxxbrrbvljjnszghymkozcwghtapdxdvhlyhnws
 * Smoking Wheels....  was here 2017 vrivxzairjeodcgeanqkpujqixhzeddgwnzemnfriigqcxvx
 * Smoking Wheels....  was here 2017 aakmzpdjtwbasodwlkxmbxjwekwialkhseakcfsdhtehzugz
 * Smoking Wheels....  was here 2017 yzxkuwzgqhozgfwrqnjvowrzmqmisitqoaghhfiyoxvbyvgx
 * Smoking Wheels....  was here 2017 dazuvohyatahlmifirkzxshjexqfflgglajncwjqilyjezdv
 * Smoking Wheels....  was here 2017 jxafztawtpxefcpnovstcvkpixfhusjjomgfwshbyfpwclni
 * Smoking Wheels....  was here 2017 qptlislpalcyuzbtogfeosonjlegujomlwdpepuhbiblmoga
 * Smoking Wheels....  was here 2017 ekamdbaydfoiphilvkblvelfxqvzavvhxyjfwnwroewgedmx
 * Smoking Wheels....  was here 2017 ovbqbomavzqeilggfcsfsgbawyuritesxrrvzutvpjwrlang
 * Smoking Wheels....  was here 2017 noglvhuexcwrzfxepgtdhipnjwtraczbsiylwayontakskal
 * Smoking Wheels....  was here 2017 apgqonfzogafslrljeeixxppujvrlawrwjikbaezanshsttf
 * Smoking Wheels....  was here 2017 kfahpwfhdhemzidlzidzdutgtohpizrjcpgflukkxzkoityo
 * Smoking Wheels....  was here 2017 exsqndmehiphmiezelasubbyetqorrnbkykparvlktyovivr
 * Smoking Wheels....  was here 2017 aksgdibaxsvwfdxzzpmhxatdeptypztzcssregayvtjzqqca
 * Smoking Wheels....  was here 2017 asswmueicbqphrqqrynrwfhtdaplqdzprkiqmhqzvbxrldoi
 * Smoking Wheels....  was here 2017 kcroycgahiddfdaltagefmkwsbmykobpwsrbsvrwibevfmin
 * Smoking Wheels....  was here 2017 rarobabddnokqxxcaobiuwcvudzpxxcztqjrzgjglkyvcruw
 * Smoking Wheels....  was here 2017 qgfkqqpblcmmpsjpkoryrroemvwvielymmkopbeyoxgiqvnv
 * Smoking Wheels....  was here 2017 htxwugbjlqrwfmucghzzelivfbfgdmrzrrxzecwbitkglkjb
 * Smoking Wheels....  was here 2017 wvravlxwlafdzjudzfetwacuoyguzhstbailmklwpgytmbmp
 * Smoking Wheels....  was here 2017 xxtcjzyrdjjfowejlcquokwmmuopwhqgpmhtphbaobqeauep
 * Smoking Wheels....  was here 2017 dulpdycdjbqhypbuqybwjzvlbhybyktsqhsyxhfinangktbp
 * Smoking Wheels....  was here 2017 plnjhqpvhrxshowquzjzohmnshlvsvtopzvgxgsyfhyvlizf
 * Smoking Wheels....  was here 2017 odwkcqzphddebwchkssltcpucyiwvykoihzflflclfkczgbn
 * Smoking Wheels....  was here 2017 nipaetxnaorozzsohwmuumcqaodggnwpufwpqmrmkkskhmrq
 * Smoking Wheels....  was here 2017 gufrjajyihazzpsjkmkurugprtrkelmzgzlmuqxwluxmudkc
 * Smoking Wheels....  was here 2017 tniertqmkzaygroxbtjlunnommazcwwdfcudkmvjflhderco
 * Smoking Wheels....  was here 2017 gtxomndypmrzgiustfobsnrpzukxrhwtmhkakbliqsjpkuwa
 * Smoking Wheels....  was here 2017 iabbicqlowhcragkfpidgvqadckivipvapyzvrzjuhzgslcs
 * Smoking Wheels....  was here 2017 saghbpdhdpkklmcamxlmltqmbzvpvzjocfhazwygbzesmtjb
 * Smoking Wheels....  was here 2017 ktcyshubngvgvortvjtdqwfteislbkwkgrqkmnaddyeylfnu
 * Smoking Wheels....  was here 2017 rmpcrtercsojfnobtnlhlzayahhsgawcftjrcqfiwopbolrw
 * Smoking Wheels....  was here 2017 bsvamuydmbyqitprabyprddlpefojnnqajepyntkkkelzlen
 * Smoking Wheels....  was here 2017 hehgyldvosnfdyynpzysirstzrelovedyvagitcgdjzufjqf
 * Smoking Wheels....  was here 2017 kxpneayjlhaluaxwvphtvdguopgyielelpavvdayspizyqyr
 * Smoking Wheels....  was here 2017 pbrxmdvnoqobueddeifyshmqzdtzjxdjjkoxgslvzltedyev
 * Smoking Wheels....  was here 2017 mfrqlnokowkxuwmbkycvugjpdpftoultphkgsvrlcnatxgqx
 * Smoking Wheels....  was here 2017 tcchvhdkhkcettzqomqfehfgdpkpftqnnmjxmzdrlsfkuraj
 * Smoking Wheels....  was here 2017 krnpustbwvkgwtczvdsbdakmkbkfrxidpmsdfboprdoamsdy
 * Smoking Wheels....  was here 2017 ufwpqjwgtzkuqciruknshesjocmnstlipaumqbzoqdrswbdp
 * Smoking Wheels....  was here 2017 ifjqxcganbkrsepjebmrkwdgnbepfybamdhrwiodnjhyfoho
 * Smoking Wheels....  was here 2017 ulkdlxwtcjxcbrabacgsqjwrioixlkmlpadugkuersniymgg
 * Smoking Wheels....  was here 2017 gvqyiczzposkwoxyottwhglommxbvjjckemcjblutgottgxk
 * Smoking Wheels....  was here 2017 yszbxhapknwhozwlinekwjnxoygabfnqrjuczllhrjbkpmha
 * Smoking Wheels....  was here 2017 inqtrftrdirrxjujbdxvgsddlhxwcrdclpqpfucgmstsqfvg
 * Smoking Wheels....  was here 2017 fzzooadotksrultpvqpzoqmuifqbcqmqxcbqkrvoqdrgknbp
 * Smoking Wheels....  was here 2017 qeshoykvhirrlcdjuffvarbtnnnfoiftqkclbxjhttdznxxt
 * Smoking Wheels....  was here 2017 vhsyzobifzsjiomeokwsgqqbrjvgedddkehobosutyrbzblt
 * Smoking Wheels....  was here 2017 hvfumrudenaqcgtsvybccpdbtdchwtkuemfvmxcpshcvywas
 * Smoking Wheels....  was here 2017 unojwjqqzgfrtvyzqvjtpvujukduwdjwfovepozpbtlaxnfd
 * Smoking Wheels....  was here 2017 ikmkdytjuvbulfmdghuucycugbzkpmqxbwhybhcwkjzmonyu
 * Smoking Wheels....  was here 2017 fsvasyreadqtqqzqevlkesumsfyyueaomfaqqeltrohjvlho
 * Smoking Wheels....  was here 2017 xxwlcfdeihejbnfgfeteqfwscgnrjyrulnsajngwzxdcxips
 * Smoking Wheels....  was here 2017 etxfdtcsnqfvqnjyhkjvotncouoynsywgbgerwzzrhoighmr
 * Smoking Wheels....  was here 2017 bhrbxyuiuvqooquxsrglhwgmlsbjsqkgkjuibakglwwyptuf
 * Smoking Wheels....  was here 2017 vscbtgsxoskehyaoamogjjuzkdjxreypreuzkblaeyqcwmqg
 * Smoking Wheels....  was here 2017 yninfoonjlvonzzsyqrvqjcwilyshzrxblxashjvzfoffiiz
 * Smoking Wheels....  was here 2017 fmuwdxjneimyfjtgmdixecluifqeubxkulbjihqngnuxemoy
 * Smoking Wheels....  was here 2017 poczpphmcbcqnbslxdjniegovinxrnholrkiwuzfqyodkldu
 * Smoking Wheels....  was here 2017 kagvxewhnmujzgkstfzzpjihlyuwovqbswildylgaxlzvvem
 * Smoking Wheels....  was here 2017 ekjsqmuybsuafiuvucquwtphckcekqcxraoneadfnaeyrpzh
 * Smoking Wheels....  was here 2017 pjxdqocwqcrsfbwrztytfqhdwjegmyagokanjpqxoewokygq
 * Smoking Wheels....  was here 2017 szmxysypkhgwehanplwvypxteqbtdwzpwmutfkrmsluvrhtg
 * Smoking Wheels....  was here 2017 tlbaxmwarendngxvernjqkedrkbnewwrkaktppegyfmvmhrc
 * Smoking Wheels....  was here 2017 hhtucspeevvlyjiimfjwcebrfzsumqtldzlhpljuicsaayhk
 * Smoking Wheels....  was here 2017 bgbsimblsrqxlilynaackdvzyavygcacirvjmnuyhzoarjgp
 * Smoking Wheels....  was here 2017 ciopraokmhvyebnxnjmcyxxvgjlpzlhdnouhwpdvlaisgakk
 * Smoking Wheels....  was here 2017 psflmynwvojeptgraswdehciuevsicjfljspouktsnnippwv
 * Smoking Wheels....  was here 2017 dzfnibrykpqpkvlzuvptaihwkvojftkjddgbqiuhedyfzbza
 * Smoking Wheels....  was here 2017 lvykakbacubgpyfuwsisniuyhxlayistvbirlvuigtqzunjn
 * Smoking Wheels....  was here 2017 nhcuphvpbtophcxhlpabawbnuhlhwzywbrctnceyomxqulwy
 * Smoking Wheels....  was here 2017 ronulhnprichzlezbzubatupncycsfxkprausfwmarhgxnoj
 * Smoking Wheels....  was here 2017 jemqcevboszfkluomqcflaanlskplrtjkdtpckdntyogiswy
 * Smoking Wheels....  was here 2017 kxjxkbtipftolsyztnoihzyxqtrefiuxvgeeahlwefuhmdid
 * Smoking Wheels....  was here 2017 uruhlfoaylfqhfymcxelyfboncunohrohomvzrnrvoggchvr
 * Smoking Wheels....  was here 2017 tttwmgqyzikfmdlnahavxncqrwbmcafzpscbwqifsjnidumn
 * Smoking Wheels....  was here 2017 vrjxexufiypcqyfuhkpabyalblzgvgoftvsrtkedxgjxuqqw
 * Smoking Wheels....  was here 2017 tdayhgzexrknshkhygntmubntkjfxwajbberxqlhucuqmzwg
 * Smoking Wheels....  was here 2017 pemuxqljvdnuyckefbsclrrufqhavbgzyysizcxrazekxhbh
 * Smoking Wheels....  was here 2017 oapkjpqsmgbrtouaqjjhpirgzhzpggbtffsetvosljzjbeia
 * Smoking Wheels....  was here 2017 eenbgxifmbhzwdkkzwwxrwziasabdeoqxxwzhdqzhubydqap
 * Smoking Wheels....  was here 2017 fjsjjslguztwfmikfqxrvpvpknfwsrdwgfbvxpohwdktnvto
 * Smoking Wheels....  was here 2017 rpwaufhlmpgvznaepvjriarvppppkbkwuqmygbduvojtzeio
 * Smoking Wheels....  was here 2017 vdvcwbhoyvvkqmzfszmduaifeblfxqekfyowbnhsbklblkyp
 * Smoking Wheels....  was here 2017 fluwdaetvuuowtcfgvqpaprabgiveeokpcyjmhhtshlbckww
 * Smoking Wheels....  was here 2017 nhewldyiauqlqamdgkmwcbaviwzwkoydfkpluzosddklkjsv
 * Smoking Wheels....  was here 2017 vrrvwtuxqnelcgnfzxyyiavolsnybaxzniploixrazpcbtkg
 * Smoking Wheels....  was here 2017 jveuslhhcwmfuptxywfchgufayfavyhsiplwqmgzfgqeagza
 * Smoking Wheels....  was here 2017 rgwboybpbwuqjncxxzrwvuxexxogqaghqgtmcrwfwogbmsvk
 * Smoking Wheels....  was here 2017 msdegjdeiysxtrpfwiabzzkahflztfdxrmmhgmegjumlwknw
 * Smoking Wheels....  was here 2017 udswvatocsakdaracberdjvpnuvwnsmbzvuprszdjaqextzb
 * Smoking Wheels....  was here 2017 xwleqlkrtbsuaswvctgzuuuagrawtxflhzcyelffsrhlnkgb
 * Smoking Wheels....  was here 2017 hinkgltnxbdzcfchqctmvgjpjiochmlaraacwyddpifryisz
 * Smoking Wheels....  was here 2017 thjbncwnmdubhelktdgaictxzihyllmaidobbveqixklqryi
 * Smoking Wheels....  was here 2017 hurxmrxeoxmnuofjrbtpoxlvnnfcowywvvudhxdxplgtgxvv
 * Smoking Wheels....  was here 2017 ezialujkpehycocryljmdkdkqbpkkhriwvfwleyfikfrtsmk
 * Smoking Wheels....  was here 2017 wlmqagageemhwoxbhyoewtvadibcxivinemzoyvfoicqizfi
 * Smoking Wheels....  was here 2017 ewphabvceepqbhskspynuetffxingxsdacmoywhrtezhmyra
 * Smoking Wheels....  was here 2017 chitnozmuvkmvqyznrmmihkxgrlixhydwckvfqbtnzcnvzsf
 * Smoking Wheels....  was here 2017 xypbvizhjaakswdhfqijzwncxutmpvkcvxqjekdtsecokvkw
 * Smoking Wheels....  was here 2017 ciomndpoowqijifzngxsozaezptbfgezynxxxksgoiqsikef
 * Smoking Wheels....  was here 2017 leqombtrgswkttfammvhfyfsstgmzlpalebnsghcjjwrcxnr
 * Smoking Wheels....  was here 2017 ymmcsktfofnaaaoripccehnplbhkiriqvkhkespkukailsja
 * Smoking Wheels....  was here 2017 xmaboszaxgowrkuiqcwkcwswuretaheoxxbedwpmstrwfove
 * Smoking Wheels....  was here 2017 tsltpvfewxivjgvuctmvustwsylqyagtqszpqbnyicqqskgj
 * Smoking Wheels....  was here 2017 ixdsrumakpkbdhszumrbgdvegowniuxlicaqbuxqygwiiifc
 * Smoking Wheels....  was here 2017 qausvxydpwnyblvcxqjdxsnrvinaptucmmhqxwkpfktvuwoz
 * Smoking Wheels....  was here 2017 wjitktckwrserxuqapsjhfmkdkralkskvqgcbjagbxuiarmc
 * Smoking Wheels....  was here 2017 pkxdycrvvciprclhvfcgfsrtzcwrwkujkpouoqacpitefqfp
 * Smoking Wheels....  was here 2017 pwxkibrwjnxkysxakkfptokhndxlaqjemodttewafptbwamy
 * Smoking Wheels....  was here 2017 vtbipxhaqneztrnbzmajfgcwfhvxkjchobcgevhdouawqebw
 * Smoking Wheels....  was here 2017 pigxbebdabgandwwbxqygqnoptyaqytkjvyvsqgtmicsmwbi
 * Smoking Wheels....  was here 2017 jcrlisriedjiypwekkmtptqrpvtxtcnozwigkxzleuvcpywo
 * Smoking Wheels....  was here 2017 yuslfodyxgdezsoxbzfqjxrwjeczwusxpkcoofzbycfomrca
 * Smoking Wheels....  was here 2017 jjbsubqolyhwukiigxupxrcygrawnezxuymatjztnhoctlok
 * Smoking Wheels....  was here 2017 udpgjsradcwdxwuwnrjxswrzyltniqcihgxdvkyttvkukxjr
 * Smoking Wheels....  was here 2017 vonjnjzjqvfvynufpajcsnijhvxahygcchatwqcsthocqbxc
 * Smoking Wheels....  was here 2017 fkgobcoavnvcyckknykyxyjqlmgwpztlmisverymxnbqxbub
 * Smoking Wheels....  was here 2017 xqmqdeqouvnkzlbposmmqserugupsyfuyvfqjgfdxreiwivi
 * Smoking Wheels....  was here 2017 gnbozeqtzojiqvhhetranqpnyhwfhgmxhpxuelwaodlhnodw
 * Smoking Wheels....  was here 2017 sofrfwjtawpumqzeexmahunnvxaviqrsnplzupercmszarcw
 * Smoking Wheels....  was here 2017 bminrjtwuduzpoggobohclfinuavzzemvbthlfoavqzzwxiv
 * Smoking Wheels....  was here 2017 hicujzbskysgbnlroouwgeetmtyxsmnqvnayteuckrohtqql
 * Smoking Wheels....  was here 2017 rgkpsftdhflhktdytwiaiucvizaygoqwerqnnmvgtzzzoodq
 * Smoking Wheels....  was here 2017 tvlefyoebagzhqguvsrgdiyzyuwbnxofzohtvlxcyfaloqfs
 * Smoking Wheels....  was here 2017 guraselfptsnrwvewckksdaskvfssmsvlkxsarnlleukezlb
 * Smoking Wheels....  was here 2017 fdrzhfrvbbogtkfhbgmlmttyeyenhlrecsqqrxkkvamsccsl
 * Smoking Wheels....  was here 2017 wbkbhrswuuxvzkcpztbryzxswhzjygharfwbognhzesohrcu
 * Smoking Wheels....  was here 2017 sdbngihkmbzechgvjfppxwkkjfelqorhgyiuvacscehhzpzi
 * Smoking Wheels....  was here 2017 pbzwafjvzfjmzuvygtrantnovjpephffacyvstpmnxeqobyn
 * Smoking Wheels....  was here 2017 kvyyqrfqlyvbvueevoiyafsapohderlfnevlwgvtwnsktnvc
 * Smoking Wheels....  was here 2017 nsuslghtgblqenwyrdprbztxizmhedgbozkecorubjlvmquz
 * Smoking Wheels....  was here 2017 jfsnbuifbrmcqkuanfatlepoxztumhtsbljvlblfgcegaidm
 * Smoking Wheels....  was here 2017 tbcvghhksfmpfbbikvexfclomdxzieijjwpkgfoxuoyjtvmy
 * Smoking Wheels....  was here 2017 sfrkdclwjhgnbnaboeaerhvtljzpdwnmxriddxuxiwzbjose
 * Smoking Wheels....  was here 2017 kzhjztgmltwnqxgtnutwmolekugmqxgtnrxqvddotkxnwexb
 * Smoking Wheels....  was here 2017 lvexkblinsnnrqqcbksmkzgggthutxofewbqmgtleunclqlx
 * Smoking Wheels....  was here 2017 omspgcztnnwqdlgadaquowonexwysuwaelrekvelaxulmcxc
 * Smoking Wheels....  was here 2017 uzpenediowqidgnubxkwftuvmcboyusrzyxndpcqxvbmtadj
 * Smoking Wheels....  was here 2017 iosrpviwbpweffzuhmeyymrgwlcpdiawjdfeosoitzwjfchs
 * Smoking Wheels....  was here 2017 srglbxjnqvwezumvrpkoqbeefjofgcvpjyfzskscqzznzfqj
 * Smoking Wheels....  was here 2017 tdpxrlepdxfjmrevedtmhvpdqkgsmznafqwxxhdwzrnnopxs
 * Smoking Wheels....  was here 2017 kxmypszrumqgwukaaldthjjannfwhftqltigsdlqkerjrrvn
 * Smoking Wheels....  was here 2017 yftmcihqxkgkohtvtzsqflfxmtsmjfhdvaaoaasvvwbdfcpt
 * Smoking Wheels....  was here 2017 xoqwsbvndvguiqdzelxrvdccmniuqqhnikpovhdyjkkhkwnp
 * Smoking Wheels....  was here 2017 atmpjapsjchnbnomgxjrftifplvdjldagezimkfxjpvlscfn
 * Smoking Wheels....  was here 2017 isblbluttvcayvmnfpaptwhdfjgfyvjacvidogqtoqomvfoh
 * Smoking Wheels....  was here 2017 bsemdywnrxsynvkoqzbtzguwakxwcfwiqcbmxwkvtvfprzqv
 * Smoking Wheels....  was here 2017 tgcxeiqculldjwhhhuwrszuuvzhhthtvwaxepottcvmemguj
 * Smoking Wheels....  was here 2017 ebdiapauyvwvosetccdcbjmmvrhxdzjuburgxxdizmnxrhqi
 * Smoking Wheels....  was here 2017 hebmsdgggqskefkbkbudhzjvkjwirlirsxqxmrircynpzlbm
 * Smoking Wheels....  was here 2017 lutkolvgeubmtpqtsgzzbqfweejmbeldpedubzicgocmildu
 * Smoking Wheels....  was here 2017 bljjejmyikeayhsntidfciyzamhmhuxfsnxoubhfpzzyxffk
 * Smoking Wheels....  was here 2017 ywixkyeqowqctzsiokxpolvscxlunhacifuiyoswobhqeyxw
 * Smoking Wheels....  was here 2017 cahugndybsgehpakjqfdsnixuiwafujgzuaidejdtwglwbcv
 * Smoking Wheels....  was here 2017 uffbcpxqdxzwcigesnfddiestvwbbtvkjyzdecfjbwloxhwi
 * Smoking Wheels....  was here 2017 nxfzmadxnnfcuqekiwkcsyjkvvzcaxnmprjmdnmdqqrimmon
 * Smoking Wheels....  was here 2017 bwtbgvvzaykajdaahpivlscpdxznhdusvgbjibrhvaylawuw
 * Smoking Wheels....  was here 2017 kbmdligovulaaubguaaisdxddyyzipgoqegdjnmyieouhwkc
 * Smoking Wheels....  was here 2017 wshelcvkiyhtfvxojpoxbcmclcejvutuueihayxkzmbnefnf
 * Smoking Wheels....  was here 2017 xkkmuzjqcmgeqplruckbhouvxsdwsjjhggaqkrdgyngbxtnj
 * Smoking Wheels....  was here 2017 hvfoiytpcvyifwtobmfonxcysjswfgmiiqfdvftjpfeaytzb
 * Smoking Wheels....  was here 2017 byjfbjhwkpbtdnfklaymbrvffaxatqsjnwacwkjuopdiypta
 * Smoking Wheels....  was here 2017 lbumkukhlqrzxtkrlesbmruvbsafbzxcoqybiibxtdqexzye
 * Smoking Wheels....  was here 2017 zrrpxzwyvbdzfafcwtyvpyyacwopcxemnyquigzhgknxzvxu
 * Smoking Wheels....  was here 2017 kmkdjbrfmhxwzzsrqsipmvmlocjpzlwtpczidtrunhuerjgg
 * Smoking Wheels....  was here 2017 tnrvwizpmxvbkohocitimvxysgmvgrojiodykqvlextxqzwi
 * Smoking Wheels....  was here 2017 gaktsiibhuyfyyngsbljevyphmdgpbdbmapewylrbqzgvjua
 * Smoking Wheels....  was here 2017 mmtdovlomanghpglhrtfjvpsddyzxistboytqatajbfpllll
 * Smoking Wheels....  was here 2017 dqdndyioybdhleqdudjqdebxkvrkkkpsikdtbkgilcnpzlke
 * Smoking Wheels....  was here 2017 gmfsozdowlotnpanmtfrujvalljfpkliuailsxpryveebtnv
 */
/**
*  WebgraphConfiguration
*  Copyright 2011 by Michael Peter Christen
*  First released 14.04.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-04-14 22:05:04 +0200 (Do, 14 Apr 2011) $
*  $LastChangedRevision: 7654 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.schema;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrInputDocument;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.federate.solr.ProcessType;
import net.yacy.cora.federate.solr.SchemaConfiguration;
import net.yacy.cora.federate.solr.SchemaDeclaration;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.HostBalancer;
import net.yacy.search.schema.CollectionConfiguration.Subgraph;
public class WebgraphConfiguration extends SchemaConfiguration implements Serializable {
private static final long serialVersionUID=-499100932212840385L;
/**
* initialize with an empty ConfigurationSet which will cause that all the index
* attributes are used
*/
public WebgraphConfiguration(boolean lazy) {
super();
this.lazy = lazy;
}
/**
* initialize the schema with a given configuration file
* the configuration file simply contains a list of lines with keywords
* or keyword = value lines (while value is a custom Solr field name
* @param configurationFile
* @throws IOException 
*/
public WebgraphConfiguration(final File configurationFile, boolean lazy) throws IOException {
super(configurationFile);
this.lazy = lazy;
        if (this.isEmpty()) return;
Iterator<Entry> it = this.entryIterator();
for (SchemaConfiguration.Entry etr = it.next(); it.hasNext(); etr = it.next()) {
try {
WebgraphSchema f = WebgraphSchema.valueOf(etr.key());
f.setSolrFieldName(etr.getValue());
} catch (final IllegalArgumentException e) {
ConcurrentLog.fine("SolrWebgraphWriter", "solr schema file " + configurationFile.getAbsolutePath() + " defines unknown attribute '" + etr.toString() + "'");
it.remove();
}
}
for (SchemaDeclaration field: WebgraphSchema.values()) {
if (this.get(field.name()) == null) {
ConcurrentLog.warn("SolrWebgraphWriter", " solr schema file " + configurationFile.getAbsolutePath() + " is missing declaration for '" + field.name() + "'");
}
}
}
public List<SolrInputDocument> getEdges(
final Subgraph subgraph,
final DigestURL source, final ResponseHeader responseHeader, Map<String, Pattern> collections, int crawldepth_source,
final Set<ProcessType> processTypes, final Collection<AnchorURL> links,
final String sourceName) {
boolean allAttr = this.isEmpty();
boolean generalNofollow = responseHeader == null ? false : responseHeader.get("X-Robots-Tag", "").indexOf("nofollow") >= 0;
int target_order = 0;
List<SolrInputDocument> edges = new ArrayList<SolrInputDocument>();
for (final AnchorURL target_url: links) {
SolrInputDocument edge = getEdge(
subgraph, source, responseHeader, collections, crawldepth_source, processTypes,
sourceName, allAttr, generalNofollow, target_order, target_url);
target_order++;
edges.add(edge);
}
return edges;
}
public SolrInputDocument getEdge(
final Subgraph subgraph, final DigestURL source_url, final ResponseHeader responseHeader, Map<String, Pattern> collections,
int crawldepth_source, final Set<ProcessType> processTypes, final String sourceName, boolean allAttr, boolean generalNofollow, int target_order,
AnchorURL target_url) {
final String name = target_url.getNameProperty();
final String text = target_url.getTextProperty();
String rel = target_url.getRelProperty();       
String source_host = source_url.getHost();
String target_host = target_url.getHost();
        if (generalNofollow) {
if (rel.length() == 0) rel = "nofollow"; else if (rel.indexOf("nofollow") < 0) rel += ",nofollow"; 
}
StringBuilder idi = new StringBuilder(8);
idi.append(Integer.toHexString((name + text + rel).hashCode()).toLowerCase());
while (idi.length() < 8) idi.insert(0, '0');
String source_id = ASCII.String(source_url.hash());
String target_id = ASCII.String(target_url.hash());
StringBuilder id = new StringBuilder(source_id).append(target_id).append(idi);
SolrInputDocument edge = new SolrInputDocument();
add(edge, WebgraphSchema.id, id.toString());
add(edge, WebgraphSchema.target_order_i, target_order);
        if (allAttr || contains(WebgraphSchema.load_date_dt)) {
Date loadDate = new Date();
add(edge, WebgraphSchema.load_date_dt, loadDate);
}
        if (allAttr || contains(WebgraphSchema.last_modified)) add(edge, WebgraphSchema.last_modified, responseHeader == null ? new Date() : responseHeader.lastModified());
final String source_url_string = source_url.toNormalform(false);
        if (allAttr || contains(CollectionSchema.collection_sxt) && collections != null && collections.size() > 0) {
List<String> cs = new ArrayList<String>();
for (Map.Entry<String, Pattern> e: collections.entrySet()) {
if (e.getValue().matcher(source_url_string).matches()) cs.add(e.getKey());
}
add(edge, WebgraphSchema.collection_sxt, cs);
}
add(edge, WebgraphSchema.source_id_s, source_id);
        if (allAttr || contains(WebgraphSchema.source_protocol_s)) add(edge, WebgraphSchema.source_protocol_s, source_url.getProtocol());
        if (allAttr || contains(WebgraphSchema.source_urlstub_s)) add(edge, WebgraphSchema.source_urlstub_s, source_url.urlstub(true, true));
Map<String, String> source_searchpart = source_url.getSearchpartMap();
        if (source_searchpart == null) {
if (allAttr || contains(WebgraphSchema.source_parameter_count_i)) add(edge, WebgraphSchema.source_parameter_count_i, 0);
} else {
if (allAttr || contains(WebgraphSchema.source_parameter_count_i)) add(edge, WebgraphSchema.source_parameter_count_i, source_searchpart.size());
if (allAttr || contains(WebgraphSchema.source_parameter_key_sxt)) add(edge, WebgraphSchema.source_parameter_key_sxt, source_searchpart.keySet().toArray(new String[source_searchpart.size()]));
if (allAttr || contains(WebgraphSchema.source_parameter_value_sxt)) add(edge, WebgraphSchema.source_parameter_value_sxt, source_searchpart.values().toArray(new String[source_searchpart.size()]));
}
        if (allAttr || contains(WebgraphSchema.source_chars_i)) add(edge, WebgraphSchema.source_chars_i, source_url_string.length());
        if (source_host != null) {
String dnc = Domains.getDNC(source_host);
String subdomOrga = source_host.length() - dnc.length() <= 0 ? "" : source_host.substring(0, source_host.length() - dnc.length() - 1);
int pp = subdomOrga.lastIndexOf('.');
String subdom = (pp < 0) ? "" : subdomOrga.substring(0, pp);
String orga = (pp < 0) ? subdomOrga : subdomOrga.substring(pp + 1);
if (allAttr || contains(WebgraphSchema.source_host_s)) add(edge, WebgraphSchema.source_host_s, source_host);
if (allAttr || contains(WebgraphSchema.source_host_id_s)) add(edge, WebgraphSchema.source_host_id_s, source_url.hosthash());
if (allAttr || contains(WebgraphSchema.source_host_dnc_s)) add(edge, WebgraphSchema.source_host_dnc_s, dnc);
if (allAttr || contains(WebgraphSchema.source_host_organization_s)) add(edge, WebgraphSchema.source_host_organization_s, orga);
if (allAttr || contains(WebgraphSchema.source_host_organizationdnc_s)) add(edge, WebgraphSchema.source_host_organizationdnc_s, orga + '.' + dnc);
if (allAttr || contains(WebgraphSchema.source_host_subdomain_s)) add(edge, WebgraphSchema.source_host_subdomain_s, subdom);
}
        if (allAttr || contains(WebgraphSchema.source_file_ext_s) || contains(WebgraphSchema.source_file_name_s)) {
String source_file_name = source_url.getFileName();
String source_file_ext = MultiProtocolURL.getFileExtension(source_file_name);
add(edge, WebgraphSchema.source_file_name_s, source_file_name.toLowerCase().endsWith("." + source_file_ext) ? source_file_name.substring(0, source_file_name.length() - source_file_ext.length() - 1) : source_file_name);
add(edge, WebgraphSchema.source_file_ext_s, source_file_ext);
}
        if (allAttr || contains(WebgraphSchema.source_path_s)) add(edge, WebgraphSchema.source_path_s, source_url.getPath());
        if (allAttr || contains(WebgraphSchema.source_path_folders_count_i) || contains(WebgraphSchema.source_path_folders_sxt)) {
String[] paths = source_url.getPaths();
add(edge, WebgraphSchema.source_path_folders_count_i, paths.length);
add(edge, WebgraphSchema.source_path_folders_sxt, paths);
}
        if ((allAttr || contains(WebgraphSchema.source_crawldepth_i)) && this.contains(WebgraphSchema.source_protocol_s) && this.contains(WebgraphSchema.source_urlstub_s) && this.contains(WebgraphSchema.source_id_s)) {
add(edge, WebgraphSchema.source_crawldepth_i, crawldepth_source);
}
boolean inbound = CollectionConfiguration.enrichSubgraph(subgraph, source_url, target_url);
        if (allAttr || contains(WebgraphSchema.target_inbound_b)) add(edge, WebgraphSchema.target_inbound_b, inbound);
        if (allAttr || contains(WebgraphSchema.target_name_t)) add(edge, WebgraphSchema.target_name_t, name.length() > 0 ? name : "");
        if (allAttr || contains(WebgraphSchema.target_rel_s)) add(edge, WebgraphSchema.target_rel_s, rel.length() > 0 ? rel : "");
        if (allAttr || contains(WebgraphSchema.target_relflags_i)) add(edge, WebgraphSchema.target_relflags_i, relEval(rel.length() > 0 ? rel : ""));
        if (allAttr || contains(WebgraphSchema.target_linktext_s)) add(edge, WebgraphSchema.target_linktext_s, target_url.getTextProperty());
        if (allAttr || contains(WebgraphSchema.target_linktext_charcount_i)) add(edge, WebgraphSchema.target_linktext_charcount_i, target_url.getTextProperty().length());
        if (allAttr || contains(WebgraphSchema.target_linktext_wordcount_i)) add(edge, WebgraphSchema.target_linktext_wordcount_i, target_url.getTextProperty().length() > 0 ? CommonPattern.SPACE.split(target_url.getTextProperty()).length : 0);
        if (target_url.getImageAlt() != null) {
if (allAttr || contains(WebgraphSchema.target_alt_s)) add(edge, WebgraphSchema.target_alt_s, target_url.getImageAlt());
if (allAttr || contains(WebgraphSchema.target_alt_charcount_i)) add(edge, WebgraphSchema.target_alt_charcount_i, target_url.getImageAlt().length());
if (allAttr || contains(WebgraphSchema.target_alt_wordcount_i)) add(edge, WebgraphSchema.target_alt_wordcount_i, target_url.getImageAlt().length() > 0 ? CommonPattern.SPACE.split(target_url.getImageAlt()).length : 0);
}
add(edge, WebgraphSchema.target_id_s, target_id);
final String target_url_string = target_url.toNormalform(false);
        if (allAttr || contains(WebgraphSchema.target_protocol_s)) add(edge, WebgraphSchema.target_protocol_s, target_url.getProtocol());
        if (allAttr || contains(WebgraphSchema.target_urlstub_s)) add(edge, WebgraphSchema.target_urlstub_s, target_url.urlstub(true, true));
Map<String, String> target_searchpart = target_url.getSearchpartMap();
        if (target_searchpart == null) {
if (allAttr || contains(WebgraphSchema.target_parameter_count_i)) add(edge, WebgraphSchema.target_parameter_count_i, 0);
} else {
if (allAttr || contains(WebgraphSchema.target_parameter_count_i)) add(edge, WebgraphSchema.target_parameter_count_i, target_searchpart.size());
if (allAttr || contains(WebgraphSchema.target_parameter_key_sxt)) add(edge, WebgraphSchema.target_parameter_key_sxt, target_searchpart.keySet().toArray(new String[target_searchpart.size()]));
if (allAttr || contains(WebgraphSchema.target_parameter_value_sxt)) add(edge, WebgraphSchema.target_parameter_value_sxt,  target_searchpart.values().toArray(new String[target_searchpart.size()]));
}
        if (allAttr || contains(WebgraphSchema.target_chars_i)) add(edge, WebgraphSchema.target_chars_i, target_url_string.length());
        if (target_host != null) {
String dnc = Domains.getDNC(target_host);
String subdomOrga = target_host.length() - dnc.length() <= 0 ? "" : target_host.substring(0, target_host.length() - dnc.length() - 1);
int pp = subdomOrga.lastIndexOf('.');
String subdom = (pp < 0) ? "" : subdomOrga.substring(0, pp);
String orga = (pp < 0) ? subdomOrga : subdomOrga.substring(pp + 1);
if (allAttr || contains(WebgraphSchema.target_host_s)) add(edge, WebgraphSchema.target_host_s, target_host);
if (allAttr || contains(WebgraphSchema.target_host_id_s)) add(edge, WebgraphSchema.target_host_id_s, target_url.hosthash());
if (allAttr || contains(WebgraphSchema.target_host_dnc_s)) add(edge, WebgraphSchema.target_host_dnc_s, dnc);
if (allAttr || contains(WebgraphSchema.target_host_organization_s)) add(edge, WebgraphSchema.target_host_organization_s, orga);
if (allAttr || contains(WebgraphSchema.target_host_organizationdnc_s)) add(edge, WebgraphSchema.target_host_organizationdnc_s, orga + '.' + dnc);
if (allAttr || contains(WebgraphSchema.target_host_subdomain_s)) add(edge, WebgraphSchema.target_host_subdomain_s, subdom);
}
        if (allAttr || contains(WebgraphSchema.target_file_ext_s) || contains(WebgraphSchema.target_file_name_s)) {
String target_file_name = target_url.getFileName();
String target_file_ext = MultiProtocolURL.getFileExtension(target_file_name);
add(edge, WebgraphSchema.target_file_name_s, target_file_name.toLowerCase().endsWith("." + target_file_ext) ? target_file_name.substring(0, target_file_name.length() - target_file_ext.length() - 1) : target_file_name);
add(edge, WebgraphSchema.target_file_ext_s, target_file_ext);
}
        if (allAttr || contains(WebgraphSchema.target_path_s)) add(edge, WebgraphSchema.target_path_s, target_url.getPath());
        if (allAttr || contains(WebgraphSchema.target_path_folders_count_i) || contains(WebgraphSchema.target_path_folders_sxt)) {
String[] paths = target_url.getPaths();
add(edge, WebgraphSchema.target_path_folders_count_i, paths.length);
add(edge, WebgraphSchema.target_path_folders_sxt, paths);
}
        if ((allAttr || contains(WebgraphSchema.target_crawldepth_i)) && this.contains(WebgraphSchema.target_protocol_s) && this.contains(WebgraphSchema.target_urlstub_s) && this.contains(WebgraphSchema.target_id_s)) {
if (target_host.equals(source_host)) {
Long targetdepth = HostBalancer.depthCache.get(target_url.hash());
add(edge, WebgraphSchema.target_crawldepth_i, targetdepth == null ? crawldepth_source + 1 : targetdepth.intValue());
} else {
add(edge, WebgraphSchema.target_crawldepth_i, 1111);
}
}
        if ((allAttr || contains(WebgraphSchema.process_sxt)) &&
((this.contains(WebgraphSchema.source_id_s) && this.contains(WebgraphSchema.source_cr_host_norm_i)) ||
(this.contains(WebgraphSchema.target_id_s) && this.contains(WebgraphSchema.target_cr_host_norm_i))) && processTypes.contains(ProcessType.CITATION)) {
List<String> pr = new ArrayList<String>();
pr.add(ProcessType.CITATION.name());
add(edge, WebgraphSchema.process_sxt, pr);
if (allAttr || contains(CollectionSchema.harvestkey_s)) {
add(edge, CollectionSchema.harvestkey_s, sourceName);
}
}
return edge;
}
/**
* encode a string containing attributes from anchor rel properties binary:
* bit 0: "me" contained in rel
* bit 1: "nofollow" contained in rel
* @param rel
* @return binary encoded information about rel
*/
private static int relEval(final String rels) {
int i = 0;
final String s0 = rels.toLowerCase().trim();
        if ("me".equals(s0)) i += 1;
        if ("nofollow".equals(s0)) i += 2;
return i;
}
/**
* save configuration to file and update enum SolrFields
* @throws IOException
*/
@Override
public void commit() throws IOException {
try {
super.commit();
Iterator<Entry> it = this.entryIterator();
for (SchemaConfiguration.Entry etr = it.next(); it.hasNext(); etr = it.next()) {
try {
SchemaDeclaration f = WebgraphSchema.valueOf(etr.key());
f.setSolrFieldName(etr.getValue());
} catch (final IllegalArgumentException e) {
continue;
}
}
} catch (final IOException e) {}
}
/**
* Convert a SolrDocument to a SolrInputDocument.
* This is useful if a document from the search index shall be modified and indexed again.
* This shall be used as replacement of ClientUtils.toSolrInputDocument because we remove some fields
* which are created automatically during the indexing process.
* @param doc the solr document
* @return a solr input document
*/
public SolrInputDocument toSolrInputDocument(SolrDocument doc) {
SolrInputDocument sid = new SolrInputDocument();
for (String name: doc.getFieldNames()) {
if (this.contains(name)) {
sid.addField(name, doc.getFieldValue(name));
}
}
return sid;
}
}
