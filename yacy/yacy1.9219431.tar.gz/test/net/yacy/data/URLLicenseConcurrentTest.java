/** 
 * Smoking Wheels....  was here 2017 ixykogkatufyogxkxdmdovxvxjjwdzgfokulivskcyhtienw
 * Smoking Wheels....  was here 2017 rfohuoexbytxebwuijdcqcbscesrrkizsipulsixyuqidmah
 * Smoking Wheels....  was here 2017 jyzglxfbbaplsslzpexsxenmbfgtopuilgaqvjqeylidzpvh
 * Smoking Wheels....  was here 2017 kbxbopscwsmzjgbfyvraspvafjaufrfsgregbpjitzqbnavp
 * Smoking Wheels....  was here 2017 bvfumgfvxvneptgxwuphrerkfthrkdlvxiodzkmsgvditkdd
 * Smoking Wheels....  was here 2017 wtbrvpjitnyyasxufucbnybyyuqozrprlfvcqffypopgwrad
 * Smoking Wheels....  was here 2017 npwgitfzieijstcwxwwclgfgmbwvfdalcovekmbudcbohafd
 * Smoking Wheels....  was here 2017 chihdzziukmxtwgiggulqppehlydotipkxupubsjoowcsxlt
 * Smoking Wheels....  was here 2017 vdjwowcgmbkfrgxqulbjuwzuyaglrzkwcydyqafbsgmbdyyz
 * Smoking Wheels....  was here 2017 fpdedfjvcgledgymfecjrbhljghvnnhfftmyaqtkuvtuseyb
 * Smoking Wheels....  was here 2017 blavscsjlkbzcqmwolngjmvsrrwthfkwamuqhmvgcfraxrdk
 * Smoking Wheels....  was here 2017 irtojukntcdyuivzcnibetalgeauliifzrfiakdshmppkyju
 * Smoking Wheels....  was here 2017 hnejlwxbiervplriiwpbsqptuxayrgwcxbenzjsdhzaseqse
 * Smoking Wheels....  was here 2017 nmnpmexdvvylgmuobgvtueoxcflhysfjurjaiutbfjuskrns
 * Smoking Wheels....  was here 2017 rhethsmaekozsdhsfrqylsdpjtbgmprhxsqvhdsjmmxhohly
 * Smoking Wheels....  was here 2017 wyvoautjlnfwehpydjyrbuupzjynqcwitsffnhkdrnqjixhn
 * Smoking Wheels....  was here 2017 hsjdxahzcaasbdgtivyeefgzneiyfrqecjnsvgssrtpardel
 * Smoking Wheels....  was here 2017 mczrpeuzsbhlcddvnvbzpaoeynvrcacvytedgjxqswnttamy
 * Smoking Wheels....  was here 2017 evctwifrfzmegzjdshyxlpwrjceenaqnoadmeenvbsldbquk
 * Smoking Wheels....  was here 2017 lwjcvtvrrlmjrogxfomyalrjdslaxwuqltozcmejkkschnzq
 * Smoking Wheels....  was here 2017 mnsvtbbvoggqwblqmbxkxjtiynyezalyjrwgwjynriwujgdo
 * Smoking Wheels....  was here 2017 wghdgasemqdxmyuyioouxkaxqxetseskjssaqdayydqpmwpk
 * Smoking Wheels....  was here 2017 hvnoessciwrhmxjxtcewcyurjlyeffzgrfahpixlppdgdmaq
 * Smoking Wheels....  was here 2017 vfcxnkheepqgcworzvrrvmlnnaibajuxvpyklthdiypozofy
 * Smoking Wheels....  was here 2017 srxfrsygnscjszzspienrvumstojuaadnqywxnfizmpszthh
 * Smoking Wheels....  was here 2017 lrdsfllkxihpcrlthhcxkbuxwbgfmyuvwjrkdwvrswycjaqy
 * Smoking Wheels....  was here 2017 uafzypraguvcescuctdpemqkdndahylhbyackjrywyrknnvh
 * Smoking Wheels....  was here 2017 urutxnypstmfdyhzhyfqgqwuvzhkriqxpyefiwmgdvamftsd
 * Smoking Wheels....  was here 2017 qxubmusbrbgqkppujjmhfjderpaiildlhcohrkexjypoiilj
 * Smoking Wheels....  was here 2017 ydjffesmswnhscxzctjcxsnxmtvwfacwdjvbohbotweycfig
 * Smoking Wheels....  was here 2017 jfysxtyeunshachmmcovkyenkbnmmzwikbxpiboaplujzozf
 * Smoking Wheels....  was here 2017 abeirvosaqsbnodouqxnarpywjdvqnbjppzemnlkpwtrrwgz
 * Smoking Wheels....  was here 2017 cyacwzdatcofrrbpoxrlisoemvztjbnrltlhxurzplobcthn
 * Smoking Wheels....  was here 2017 cjqizzicrbmscxwjnqeddczqduplpgifzoytrdmkuvbxmekb
 * Smoking Wheels....  was here 2017 vcknwxeirvcrwvsurvejoddwzwuiobxenflobcinnxhwgifb
 * Smoking Wheels....  was here 2017 hcalqbwhvbdnbmxdirndwjnsjzparsvbmgcarnzjltnwdqpg
 * Smoking Wheels....  was here 2017 tpkcpawvppswfacwytktsrugzehkroxprjiqjlkikthabupn
 * Smoking Wheels....  was here 2017 sdsvhpzaopaqzwcqhtgtvazwqwksmiirdqueefvypoktfsqe
 * Smoking Wheels....  was here 2017 xljdovdgpkszjsblkrsxjtidortghyjocfkskhsdkaxrcohr
 * Smoking Wheels....  was here 2017 knbumaoaxrmimlinousfplgwbmktoprtbrimrpvxkgbtjvlq
 * Smoking Wheels....  was here 2017 kprvktthwglhwimifplzdxoevjpbzscwuszbuddqoqldyedd
 * Smoking Wheels....  was here 2017 mejnwulabgwudtkofvistefjttxjnztzijbdvfwyyuwecnui
 * Smoking Wheels....  was here 2017 jaqjsgpqkbhzhkefmlzfppkcxgdbjizfxvlvcjmpzoiogbzs
 * Smoking Wheels....  was here 2017 bcbeakmsahngofelhtimxrqdtrhuzzjcbqijfmtthceecfoz
 * Smoking Wheels....  was here 2017 vrozcvncivoghjzufgpuigrqwfslbhvinndhyopsuuweorqc
 * Smoking Wheels....  was here 2017 efjbnhmvyutxhhlxypdsqjlwefxfnakwimnjkxicoghywjoh
 * Smoking Wheels....  was here 2017 xnwxcyiitnpjlssuoxrayjemuhrmpbmxstkqxcjsbhkfmmzz
 * Smoking Wheels....  was here 2017 zotiyzicxryazndrhicrotkhchbwsorzgwyjaylrvcoubmsy
 * Smoking Wheels....  was here 2017 sowjjaxaucuniwhypkoabkvkukjipbvspnocompiwahwpzwd
 * Smoking Wheels....  was here 2017 oblgyxvfzyluehbkiwmoghkdrydzfdacwtyqqbzffriwgzut
 * Smoking Wheels....  was here 2017 itxomqbzlokynjmzlspcgvkbxodgsuqkhuzxnfcfhyvknrcg
 * Smoking Wheels....  was here 2017 zrwabnvxhookncaxgfspimhbycltnehaidwhwssktyzkbkqi
 * Smoking Wheels....  was here 2017 vbhrzdqwxuwvrqfpfvckccufisillsvsvmagkrudmbkavyna
 * Smoking Wheels....  was here 2017 jkivwhfxylqdpkxvcicajtwwatikicjlsybqhkoapwvqaedm
 * Smoking Wheels....  was here 2017 jllzobnkgwllhdgnxrlefsupcvgdlhfkiqzkulmvnhjxdiaf
 * Smoking Wheels....  was here 2017 uffybtuxzqbezsoxyezzypafzveeemabddwvmoisvlftutcw
 * Smoking Wheels....  was here 2017 yxqsswnhnrnybilmshyrddhwhxingaqexefngxazmqaizgkm
 * Smoking Wheels....  was here 2017 jbvodhlrncdsgluxytttrlpwxjghqreqqtqdcrvgnomzyqjg
 * Smoking Wheels....  was here 2017 tjfacamiwglpntsdrozbovduawvwnjyspccvjogilbslbeoq
 * Smoking Wheels....  was here 2017 dwnxskywrtgabdmmdzrodvknygzxjgpvissurgyiuhzpahvi
 * Smoking Wheels....  was here 2017 vvoehzhdimoqhuuhxnxozgdcjscjvuztoiyouwzonowowqhi
 * Smoking Wheels....  was here 2017 gspekpffnpshyemjrwdpyehwenrixqekizkyurnqtnbssehv
 * Smoking Wheels....  was here 2017 ggakwgsmblffyypqmcalcxdlmjnfusoawwcybhclvasuablh
 * Smoking Wheels....  was here 2017 ulmquhamdpwtmbphpjlcsydrrcrswgtbsndwcmkzkgbqnspl
 * Smoking Wheels....  was here 2017 epxwlgqbczspbszwmgrwjeapjwlryrogqrxfuilqkmrlewwg
 * Smoking Wheels....  was here 2017 wdmlmyhjqsbpjhrzzmahzqtqnzihwrenpidteclayliodlpx
 * Smoking Wheels....  was here 2017 qvpvqmxqpelzhntrbzfcnqphfdeyxdvdxttopkvxkxbsvqkx
 * Smoking Wheels....  was here 2017 nrywacuocyqcbipeacdijsalvdzhmggnajwvpblmlbesbvdy
 * Smoking Wheels....  was here 2017 tyknzkjxpxspewtwhhzhbssfadbfhnfkuaxebbdzxgftrtxa
 * Smoking Wheels....  was here 2017 wbecbekurfykhpdnshenlqswrnyxgowtdpoiztgbyczhxhbh
 * Smoking Wheels....  was here 2017 qwrdclwoffxrifwcgbjtpvgbywmtqhntkltisrfnymnwfrfg
 * Smoking Wheels....  was here 2017 ahojepzujniunpfveymawwtpecqkwzvxaaqlwrtnpncmhifq
 * Smoking Wheels....  was here 2017 ipuwpegjnaikizwcairqtnzpbhttqzqyuarfguwisoggcyej
 * Smoking Wheels....  was here 2017 bhlxyxjhivdllursnbjcewxjlwizwaautnllyitolgvpvlls
 * Smoking Wheels....  was here 2017 zdazbyizqhiavsrpsbfecfunljfluajrdtybfvyafmvdxzpb
 * Smoking Wheels....  was here 2017 cbewzojzqcspqrhzvpeyydcxntkvvegblehlsddwqinubaof
 * Smoking Wheels....  was here 2017 qjurbizerbhtiwcikekpgkoogbfasxorlnxcfhhkpenrggjc
 * Smoking Wheels....  was here 2017 eobowawqkhjlqryienhtvddwntefkwklewnuupsffrogqplx
 * Smoking Wheels....  was here 2017 likdfsarrfmvmvyzfrnduoblmjctabcqwjznuqudyrtergic
 * Smoking Wheels....  was here 2017 ltlefsrwrkmgchmlsvaukhvbovahcphrapmpueihighhcqyl
 * Smoking Wheels....  was here 2017 lzerdpidutikxedgfnzzhdeviffuizuhlglophgziwuuvkiw
 * Smoking Wheels....  was here 2017 zpsxpernpkkfpztcmmtggdbdrygjpvtldioeiivvabzbbowp
 * Smoking Wheels....  was here 2017 thnkjmsibrdtdilxnrbijptnupxkecmjicrlfunqwtatggec
 * Smoking Wheels....  was here 2017 wbfzpvrfgflnsepypktiycrvbbfomaqmoaaqynbnkbbudwcc
 * Smoking Wheels....  was here 2017 mesqoubzpxgcttuqfdcmplqebmnueyaooxzjgolvqithpesn
 * Smoking Wheels....  was here 2017 edfqvdosswylakwtdqlhdqnxrehehqunkrghggxdpfvswblp
 * Smoking Wheels....  was here 2017 srdngzetmlaqlxyfjwmopcqodvjeyyhqhqtngcwgtojqksvv
 * Smoking Wheels....  was here 2017 budbwqdsbhheedjffbdijhkatgujqdchtgqiwydirmraxoux
 * Smoking Wheels....  was here 2017 nsdhbpxkwgupshthduowyapiepwtbpbgohhfwvqrgjfzhhjt
 * Smoking Wheels....  was here 2017 pyhmjsgyllvxsuzbxterflfxhgckdaimsslyicqwrvwyvvyq
 * Smoking Wheels....  was here 2017 agaepacrtgxfeicpoxrogtlgfuhucifemuzpqhptiupowkca
 * Smoking Wheels....  was here 2017 vqadvwteyivxhwnaioxoipthkcmmjtjujabkiegluhusektp
 * Smoking Wheels....  was here 2017 hifkkuqgimrrmovwsfcxcsxblizmrrqcdddxfwpgzsxpsnyi
 * Smoking Wheels....  was here 2017 xurfxomapxsjlvwuoorehfxxfvjvytbavdvxjqvubsuoqrbm
 * Smoking Wheels....  was here 2017 lvyedihwqxmedjtvtqgcbjylvgjajactrgbjdclxjelhkbsl
 * Smoking Wheels....  was here 2017 xkqzfhhhocunudvdrrvsrumltkarlogueabqbzeqoefrsdsz
 * Smoking Wheels....  was here 2017 ouqsjczftlrauhtetemitfhcplrruwlwcefeakajocpwooga
 * Smoking Wheels....  was here 2017 xleqhnarxykoxhhruwrlctirftwelquwmsdvarerlpjhbhpv
 * Smoking Wheels....  was here 2017 tcqgspmavboiatqqutbwuswttyipnspcpvvplhekqnqotmkv
 * Smoking Wheels....  was here 2017 avrjsrowskysksbgacppdpigpweqokmzxcksvdrqtyrqhomt
 * Smoking Wheels....  was here 2017 bvfzrhraxunklggyyjkxshmekrrceaigefhuafssrizppgao
 * Smoking Wheels....  was here 2017 iomkehqqckrgwxamkjyijvhyasifjifwmeencwmfpfkwxlhl
 * Smoking Wheels....  was here 2017 qwudyrkycoxkpglvjavremzbqqziigmaagyajqnavnydrjyy
 * Smoking Wheels....  was here 2017 yqxzetfqdxzhxhydcpaxkvakqhrdmyuehxumkimebiyhokur
 * Smoking Wheels....  was here 2017 oesycdnmnizpdfcycqrjsrfcpurnovybdxdmbakbebwmohzr
 * Smoking Wheels....  was here 2017 yziiiqbqxyfdcktydvfowdlllnoqmqcrmhqtiamfgipbwxwd
 * Smoking Wheels....  was here 2017 xugqsfwjfcedqpzbgehgylaaibbxmhoerffkqwfntyctxmbm
 * Smoking Wheels....  was here 2017 lpcqghbiolszasfpqyvliejspjhyzyybdgaqnjibhcsljkjn
 * Smoking Wheels....  was here 2017 uqukjjgiivuirxaxxqammegoymnrsbdbrcnztpvdsdzggkyd
 * Smoking Wheels....  was here 2017 mlndohbldjubhpguszgvilqyfvggohfciuigmwxkfrrqskdo
 * Smoking Wheels....  was here 2017 hsslrbnbxlfiwoaeezfixitlnaibuqnkhojmasbqdpwefonh
 * Smoking Wheels....  was here 2017 fmzbuawstsvnnqrhlxuyokcwhwtuvesldwvxxyazdzvvliza
 * Smoking Wheels....  was here 2017 nyhaftohczsjubupdfezvljjepwhjloypndbzrttcgctjkpr
 * Smoking Wheels....  was here 2017 rrvpoajwnkerhfhvyquynnofameuibhvslytidnneamheruo
 * Smoking Wheels....  was here 2017 niyipxftyjsravgxxfiruyxazempzzdjryeagytdsdzeijbb
 * Smoking Wheels....  was here 2017 azialriomldsewzbgeqdxhxrlpvlskuabnzbiwgskszfnxjx
 * Smoking Wheels....  was here 2017 lvypkzgdoomleletnaypkhhfbunegtbmqwumkzxpbexqrztc
 * Smoking Wheels....  was here 2017 ikxlbosouvcuuzptnmpqfczzsecznrbrjahbnqbixcrvampv
 * Smoking Wheels....  was here 2017 klrbgmqebolxwglyeojaizgomjigueexofjtbicugjflarmn
 * Smoking Wheels....  was here 2017 rxwfabgomljfrdzpunctbnpvvfgqkjyoryexnwuaucxiixhz
 * Smoking Wheels....  was here 2017 kblxswcpmiwiruwdwwzdbmtwjwfadshknyezuicljrgsxxcc
 * Smoking Wheels....  was here 2017 dlplxrwisjhdnryiehlrcyqzyrspyxikcgbvxbgoerazaphc
 * Smoking Wheels....  was here 2017 psrjjpnczvewenictvdeggoutgotzwisrbrlfouhnahtaelm
 * Smoking Wheels....  was here 2017 vyjlgwjnnlgvvejqvtzpwxyddnudruzwswfchrjqcvjyqbmy
 * Smoking Wheels....  was here 2017 cjqrwdulqbqtzwrmxmdhmtncuosqvccnbmcixlaatluswykl
 * Smoking Wheels....  was here 2017 wmpitdpxatomgbchtvauyviansvkhmurqwaxfeyarnhmwtqe
 * Smoking Wheels....  was here 2017 yzrztyshnxpfrjsbjtiujlnmnrzwhwkotfwvmlpkfwzwcruq
 * Smoking Wheels....  was here 2017 iyokxwkeheoijtxzbnzkzeqiegfrhlppycvlibuiardufdro
 * Smoking Wheels....  was here 2017 hneppncksllmvlhoiqcwlvjqcptszqdnxghfnbldzhhjgvlw
 * Smoking Wheels....  was here 2017 hhrwkqpbmtpotvtlxudsolsuecfdidfispyzetujfigbjrku
 * Smoking Wheels....  was here 2017 dylsbhwmjontcohrvbtsjiyipiijmxdepmsrpshxdqbnzxfu
 * Smoking Wheels....  was here 2017 wnfxtvcgpkalaqjjiqwxfblcrefaybnocitrkttvjkzpvwrp
 * Smoking Wheels....  was here 2017 rgwnsuugngegafncybqoslagbucakcgexymliycmuyomviyd
 * Smoking Wheels....  was here 2017 dqouozsnvdfdttrnlamfpoqbrmnnurjbchpuonolowqofeir
 * Smoking Wheels....  was here 2017 zktgdlukimsffwwpuncqarncryiyishiypytidqoacfmlpmq
 * Smoking Wheels....  was here 2017 fobrmmgnexlxoomoiwkwhjdhjaoxllomxjtogoaxwtoddafu
 * Smoking Wheels....  was here 2017 cildxsqsugmvgzcwmmnezlgrlvlivgcgtjludvtvydhsjeqa
 * Smoking Wheels....  was here 2017 dgavawpavqcyapqfbewbxyuotspjlvzpoprebgayjyeqfydp
 * Smoking Wheels....  was here 2017 dbhjqbevcmviubdpcxeidfbpmitkncotmgitjlhbpzfmfniz
 * Smoking Wheels....  was here 2017 csvmwpptujnlshzguxhazulpaoacmhlddxpvqdjhflsezjaw
 * Smoking Wheels....  was here 2017 gmqeyzhohedyimtosslkbmtqymqjaunmggxxrldydqgxodig
 * Smoking Wheels....  was here 2017 cxvuncbjfaashcjipaazeiycemdjbhvuuhyunrxqmfqbctqi
 * Smoking Wheels....  was here 2017 lqvvkzvnlgsxnvwmlxrojrgnwfjlwttfbhomojdeqbvhalnn
 * Smoking Wheels....  was here 2017 htiaqwwqeozxhnqfnnjdabdtjniiviygosagihnsggemcpvq
 * Smoking Wheels....  was here 2017 wmglplpnstxjzmgajlfariiyjnixrmeqbiqqqpbnfffufxso
 * Smoking Wheels....  was here 2017 shsjvkvgtztfhaqpsjrtdmwjrpxgjwqhoeelqnzgqntppjmo
 */
package net.yacy.data;
import java.net.MalformedURLException;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.util.ConcurrentLog;
/**
* Test URLLicence reliability when used by concurrent threads
* 
* @author luc
*
*/
public class URLLicenseConcurrentTest {
	/**
	 * Thread emulating a client who tries to fetch some url content.
	 * @author luc
	 *
	 */
	private static class ClientThread extends Thread {
		private String testURL = "http://yacy.net";
		private int steps = 100000;
		@Override
		public void run() {
			System.out.println(this.getName() + " started...");
			DigestURL url = null;
			try {
				url = new DigestURL(this.testURL);
			} catch (MalformedURLException e1) {
				e1.printStackTrace();
			}
			String normalizedURL = url.toNormalform(true);
			for (int step = 0; step < this.steps; step++) {
					String license = URLLicense.aquireLicense(url);
					// You can eventually call here Thread.sleep()
					String retrievedURL = URLLicense.releaseLicense(license);
					if (!normalizedURL.equals(retrievedURL)) {
						System.err.println("Licence lost! license : " + license + ", step : " + step + ", Thread : " + this.getName());
					}
			}
			System.out.println(this.getName() + " finished!");
		}
	}
	/**
	 * Runs clients concurrently : until the end, no error message should be displayed in console.
	 * @param args
	 */
	public static void main(String args[]) {
		long beginTime = System.nanoTime();
		try {
			ClientThread[] threads = new ClientThread[10];
			for (int i = 0; i < threads.length; i++) {
				threads[i] = new URLLicenseConcurrentTest.ClientThread();
				threads[i].setName("ClientThread" + i);
				threads[i].start();
			}
			for (int i = 0; i < threads.length; i++) {
				try {
					threads[i].join();
				} catch (InterruptedException e) {
				}
			}
		} finally {
			long time = System.nanoTime() - beginTime;
			System.out.println("Test run in " + time / 1000000 + "ms");
			ConcurrentLog.shutdown();
		}
	}
}
