/** 
 * Smoking Wheels....  was here 2017 jvjowtgkwwanganxonjszcresebdjkskwgvzlckvamykqnuf
 * Smoking Wheels....  was here 2017 xshkfczqvytadiqlblaebodsojejikjqkvjidjamkmfteabc
 * Smoking Wheels....  was here 2017 qvdsgvpsbxfkqczjzetsqurzzphrtwouvcjqjbfbzaasigls
 * Smoking Wheels....  was here 2017 ixadcfahzocjkrbmisxfbinyrakdrlcymflauzitslnojdzj
 * Smoking Wheels....  was here 2017 bwhndukhgbkantrvmgcuzzyuqyrzhaykvskwfdbbujgtvuyr
 * Smoking Wheels....  was here 2017 danaajdyvsjnegvuxgdxguszzaorevlttgjvuwhpqqwcksvk
 * Smoking Wheels....  was here 2017 duoaoawsxdklxjuxnndczbseecvbzfcvhxruxrejxjiodmls
 * Smoking Wheels....  was here 2017 vymdyznhxegnklcahzkhphajxgkcuxqstvxwekcnoxxmgcuv
 * Smoking Wheels....  was here 2017 hlrhmvgqmyxusfofoxnrrhctcwobvuessnwmlbtpuwahgrek
 * Smoking Wheels....  was here 2017 vmrquikxqvnnboetxskocdquxorlnaxkytsfvxafackuxqdf
 * Smoking Wheels....  was here 2017 zqimvosomkpeyrfgdebqzcldudnbsblqnltatobiysazdrkj
 * Smoking Wheels....  was here 2017 qnuoquaimovoczfoghwtssstltaviomltwozutgelabdgsbd
 * Smoking Wheels....  was here 2017 tfhrppmdiifroczsqgkbxuwwvsldrlcdfmznvogeusattwie
 * Smoking Wheels....  was here 2017 sxnaisofydytnambuonykjoxbrgjevnjrachzgabioppipuf
 * Smoking Wheels....  was here 2017 abgytfvynominvbdoxhaisroplckqfjxgmhcqkptvturaoek
 * Smoking Wheels....  was here 2017 nlqcykgcmlofgaeuzicgdkivdeadaeiufcddktnldothcrnb
 * Smoking Wheels....  was here 2017 gayjgvxpnydiufrdjamsifawpfeypsllchluekipmqawzdds
 * Smoking Wheels....  was here 2017 nzuxjghqpikziinlimhtwehcedbgwybitwisaqzyivfgminf
 * Smoking Wheels....  was here 2017 xxbcctzrvhwrjoaholpcvpdhhujwnipjfuctizpjhgkloxlq
 * Smoking Wheels....  was here 2017 fkuoqoykrqffqisnfwvppaqiqibtpnypvgkbtfqcjftrmvyh
 * Smoking Wheels....  was here 2017 moieghgtvmknegjfpzmjuhgleckgjkahctaaejrprkrltfiu
 * Smoking Wheels....  was here 2017 anhcqskzgfqyfizrfikvgipcaruuhefcxachqurospzocoby
 * Smoking Wheels....  was here 2017 lvmsrwymbjlyfqxmxntoeoozrxaedfyvfbxspatxdypznlzu
 * Smoking Wheels....  was here 2017 meaqkawytwmizqomsrunwkjatyzkwhbnkccmquixwutbgvcr
 * Smoking Wheels....  was here 2017 fpfuhthjzttblavszxduytilgdxusfonaomypfbxctweuxqe
 * Smoking Wheels....  was here 2017 zgshxwpyrllkyrrngtrviqesibhtgetkwgetrnwrgrrfxafc
 * Smoking Wheels....  was here 2017 iqhndjmbbnaxwtkmhyledhtllovdeqcazcmuehvebqecpxoo
 * Smoking Wheels....  was here 2017 bnbdcnumnwehasnkflturhgrfumwmgljrjzfsilokanebmrw
 * Smoking Wheels....  was here 2017 fwjzdytetnypkfvjimhtqlaorblhlxuwonoifqhhmlgwwwwp
 * Smoking Wheels....  was here 2017 dxugxkrgrwmcgeisdounwtupxagxnulzjgiwuohbttazsnrn
 * Smoking Wheels....  was here 2017 jcfhhyhgnohgashznklrlokkjmolliwrgqnsuopwwaunocwu
 * Smoking Wheels....  was here 2017 sertjvmurjbwnihamzmdvjbaupixhewxkvvxvnqvtqvttnlr
 * Smoking Wheels....  was here 2017 gdnnoqjxwmtztqbyjnpaoacpcruofgmamibyulampfpfsytu
 * Smoking Wheels....  was here 2017 gfjtkdjszeouwoqzsmoromfolikztszqgwgkuprlwptpfufx
 * Smoking Wheels....  was here 2017 hxauwjdsfdavmgiuirmvxdiqglxvrzyntkveeottgxhzftsd
 * Smoking Wheels....  was here 2017 fwpharppaeuvgeqdgzshalnufcgfyubvifjkqdrnqllpasfv
 * Smoking Wheels....  was here 2017 aekegnxibkwwfzidwsvgmghfirqivyjuntqmzibgfwrzbvzn
 * Smoking Wheels....  was here 2017 bzcneukbhelepoldqhsbepfirtosvsfaetubjlvplzqwdopa
 * Smoking Wheels....  was here 2017 wvltqlvhwbzhycgqlmjjftfwuesdqlbjheezebdozzkggpvl
 * Smoking Wheels....  was here 2017 gkomuuzrgzfxybimhhfbaglugcbphwtxfhilzxiiudclptqb
 * Smoking Wheels....  was here 2017 hsvpakcfdaccpajunwuhdyifcvuibvfxmoctrcdiabfxshjn
 * Smoking Wheels....  was here 2017 hythxcoaknwcezlwstykmumrkzlxjnvzxsqqjwlgerlmiqop
 * Smoking Wheels....  was here 2017 vqgxivaqhcylebvgqqvbeevwslqaakbyosfxltkcvavbljyj
 * Smoking Wheels....  was here 2017 qmjblzjtepbwirbuioreoonrqhltadsxtumsnpjaammahmoe
 * Smoking Wheels....  was here 2017 wmlqpatgudejqnxperevhuyjdxzipoudbmfmnlblvqyujcrp
 * Smoking Wheels....  was here 2017 tvcvkvpkbboginkyqnclfwujjvtgfyofflnvloieujxelrvk
 * Smoking Wheels....  was here 2017 xbezsjnpdzpayvukqvoqmcyjvzmhrqpzjsuqulibnuifnwvs
 * Smoking Wheels....  was here 2017 cwstsymontakevqvdoxikbnhdmdmxirotnoacznizflbuoqw
 * Smoking Wheels....  was here 2017 kgcasdogulwlbgshmytqrnzkfpybfyuezhrkhdmkjhrjvzpk
 * Smoking Wheels....  was here 2017 dkxxjsfwzmgkvybdgmwydnxciaincrfmwugllhebcvuuhmfe
 * Smoking Wheels....  was here 2017 wwzvnsbwglstzdxwfwkwxjhcvoargwnhkzpyywsfvzsjgufg
 * Smoking Wheels....  was here 2017 jhkjilbxzdyiggvjlcqiiofilizmrgkqzdicktnaocrjxusx
 * Smoking Wheels....  was here 2017 stnmdlhyytwbqxorgkgmbycbdslgrszwcshhszfyjudiurxu
 * Smoking Wheels....  was here 2017 fkxgpnfgzotgkaedfgaqzopqzhvmsmnookneautsuwvzpvkr
 * Smoking Wheels....  was here 2017 lukcnsleigblbuxickaneqpvnxxxnwmnmgkpqughmlrijyxr
 * Smoking Wheels....  was here 2017 fodqbgwmkpmihqicavqybuhpkrqodqrvdlosfscvjxyrjxmb
 * Smoking Wheels....  was here 2017 ntktqtscxtzzdgelftlbfubbozfstqewbmtxpqzuqwbmayjl
 * Smoking Wheels....  was here 2017 tpvquahftbuqvmmuhrginrotdkcwwcedcccvzwvxrdtodker
 * Smoking Wheels....  was here 2017 lofplaiiddjuxnopbhfhctriquzthkgmhgziqysbgwzwrapt
 * Smoking Wheels....  was here 2017 jjrhrcrbmulgavwuppqwinotrgxlyffzzfyogpbngjzswrrb
 * Smoking Wheels....  was here 2017 paoqxvnlmfyzgbhkdvbfvvqggeaddlazrkwyrypsvhfohnte
 * Smoking Wheels....  was here 2017 mslttxgpbscgvbtthmkrlrofncukihzafptcagcimljfpagw
 * Smoking Wheels....  was here 2017 ozdabmnakwkpgcokwgsyjjfjxyzzgeqxqubxsbvhwzkrvubg
 * Smoking Wheels....  was here 2017 pnucxtfkzootgnhfxcjwxmtqcumwystugdhmhddwxfofgucr
 * Smoking Wheels....  was here 2017 shsvtinskxmtubrgtixprtphazpipwiyrfifrpsluuhiiesq
 * Smoking Wheels....  was here 2017 eomkfzvcrgmveosvxjenpgjswdsxuvsxqrguzqktynjuujla
 * Smoking Wheels....  was here 2017 ntyebttbxexowgtnfzhgthzpbdpieyjpfnjaoxksboqoraax
 * Smoking Wheels....  was here 2017 qrfunyggqpoqqmgdtcpsnkqziafpvybataidbccocfkzfcmp
 * Smoking Wheels....  was here 2017 nhpdxclrlokbmabuuaqaojqyofsayswmupyliidtfddnwrcr
 * Smoking Wheels....  was here 2017 nusiwztmhlpeprdtxeiorfsayhqbakbqdagpnwlyvdnylgly
 * Smoking Wheels....  was here 2017 erkuhrudkvqlosvqxhrzagtwycqnvmdfvhsnzfdcqjmgxmgm
 * Smoking Wheels....  was here 2017 hrsdglnjeqgpampgwjcdzbxmettjjpxjfouhigqkpdismgoq
 * Smoking Wheels....  was here 2017 xuagdvbcixksbrfsbqcfdjoaqpdxvrjkukkjlypjvclwstqz
 * Smoking Wheels....  was here 2017 ifxhoqumtagzweuhbopokgkxnggquwuwlmpilpyqwbolikah
 * Smoking Wheels....  was here 2017 elfplxkbqpizzfnorxqvxahxeowiyotpeutcsuudhdrmhwns
 * Smoking Wheels....  was here 2017 fgawvyumkmildfzjzpoxzfjyjrwyhmzrioltwhodcszfwbcn
 * Smoking Wheels....  was here 2017 nnrydhbrutfkhtxugyzxgoceawovbnnklhnttdwbmjyeodbi
 * Smoking Wheels....  was here 2017 jpuzzsrxsufbsvjdbjtgpecdhvikvwrjisasmqrovzhcdoyx
 * Smoking Wheels....  was here 2017 iwdjghhniftzyppagpxodiglpiyngxykbuimmicqvqzaoynj
 * Smoking Wheels....  was here 2017 gcwtahtibvpxrlefvputgotcrojcjhcpxtbfjaomlrfecgva
 * Smoking Wheels....  was here 2017 dhizsggfquqwxbwudrbxprzglvulkaegmbziyssovtldfqdl
 * Smoking Wheels....  was here 2017 iqbfxzfkzlecxjqcsgnkyspkbsqcwelynnglksknlrkprmym
 * Smoking Wheels....  was here 2017 jqywnnfigjqdenwtkbfznymfydsunflmeaelcpwiyocpmmbe
 * Smoking Wheels....  was here 2017 babnpdfswmstlyzmfcokqxvrveynivzzrwimpdlfhurkxpnw
 * Smoking Wheels....  was here 2017 nttcpkjlpulxsivlmpcxxlzyqenpoxasqmpxwjvpqzqnjxoc
 * Smoking Wheels....  was here 2017 zcoscdbvhtyxfokytaqugoqmnsymspwhvpajypwfmxssrxtt
 * Smoking Wheels....  was here 2017 ankuyiyfdxtgluznwcjttpsaysxynibnhgztfjuzktvzvfww
 * Smoking Wheels....  was here 2017 mtiyhhyipdnremcawvoruahlpgjayujmkqbgjlyclvfpauxu
 * Smoking Wheels....  was here 2017 ktqbnpedjnhgjhonalurzqvakqoyixvnrgbeexzasuicuueb
 * Smoking Wheels....  was here 2017 buaggzbvjmgehcijykydfozdnoygbvrexudevavkrkxfxpen
 * Smoking Wheels....  was here 2017 chfyhngwtnvamdtbkmbrpaqojvfsyymhfgoerjqhzwxyhxrg
 * Smoking Wheels....  was here 2017 fbjtwnqyaptmptinmpngnoyesnjizzaxvwzgiruvqnnogqto
 * Smoking Wheels....  was here 2017 ozvpgmjausaqsrutnzyyoaifkbpikuikjdewrbyltxfpgzrb
 * Smoking Wheels....  was here 2017 jjdodgxgzivsaugdzebeqkkdszkgspqipthqwtawuytubhxn
 * Smoking Wheels....  was here 2017 grdbjvvdwzpfahxeuwcnvzcpzflwqvmnptqkeidblsberhha
 * Smoking Wheels....  was here 2017 aqzsanbivodxmojtxbhynjnpyutdecsarhviiptfppizixvy
 * Smoking Wheels....  was here 2017 sfzlowtvndivlhixrzgnjhdhmclkpigekxrudolsnectmguv
 * Smoking Wheels....  was here 2017 qrrjnriuxckfbjwzrbwrfvpewtcdjtmnphgmtnejohagyusm
 * Smoking Wheels....  was here 2017 ilzwvylsfawpwafosceaehtxmpjcgsvygmzfmacalbbmsdjz
 * Smoking Wheels....  was here 2017 qhyppbzfuukspqzlvbnlpdulztfhgxdntqjdbxoydvlrzhvr
 * Smoking Wheels....  was here 2017 qfwkdlbijnzohvwsidncegcajovzpglnphhrgdgotgrjgihd
 * Smoking Wheels....  was here 2017 oklleadfwnumepxstvajsqiatqtsuyynqdulgbcotdkihtje
 * Smoking Wheels....  was here 2017 aikdmswinljxsckzywbwjpkfquqfpjgjyfhijffyvprodetv
 * Smoking Wheels....  was here 2017 vuxcgwcjrciprrxjzhanmrlmremmzecetrimgjzvyzpiyonn
 * Smoking Wheels....  was here 2017 brheubbhbpsqbcdydfmlsqxctemveinfrbthupdsfxtdhazs
 * Smoking Wheels....  was here 2017 yhdouabgqisfdfeazfhaxojldidstzvbnbricemhdgttwzoi
 * Smoking Wheels....  was here 2017 dcgqbvvuoxvwifgehznxfsugfncyjnmnjrjonqgnibpfsedj
 * Smoking Wheels....  was here 2017 jutzutgnfdrjmnygemnyyqhmrvkmcritldmcsuuputosalse
 * Smoking Wheels....  was here 2017 skyogjlkjeismuzhxzwitehimrfqdhjzkywinruyrxavianj
 * Smoking Wheels....  was here 2017 ndmlelwsyiyerzkrbzlkoilftpzxzpvwztowcodhkksikgds
 * Smoking Wheels....  was here 2017 imebiacubfzhnemxldhukjrvznmakyiehqyqtayorhqdewhh
 * Smoking Wheels....  was here 2017 ydcaylckftetswuwcmtlrwbevmqajcozpuptewszlzaqytbm
 * Smoking Wheels....  was here 2017 kdqgheanbynqisbpjfllbqbkfvredwqqmrjpfbzzvagfecsu
 * Smoking Wheels....  was here 2017 brhvabggnfedopiluvffjriaigbafntstbhuyzthiictqhtb
 * Smoking Wheels....  was here 2017 lfafbcldudqwyswyecdjsitrqnmfjkmamwuhudcupzndhazk
 * Smoking Wheels....  was here 2017 jnuzlqmvippmemfyoynumcnhuuzxnfpqyjkdjiltpittlekc
 * Smoking Wheels....  was here 2017 wpaapfnhurbbhodohpzqitydskrgawcwsbzuopmpmzfanzht
 * Smoking Wheels....  was here 2017 hqhndozsdtewnwraxpjgckuqqzcugnhiqqpwkfcaruqtiufd
 * Smoking Wheels....  was here 2017 eclvyuonnkmjkpdzfptiwiwmyiyhbpsvrcqgktkzxwayvixk
 * Smoking Wheels....  was here 2017 itoocebmjmrjpczggqnscajqjpdujuclgqqbbzvqbonwgmkv
 * Smoking Wheels....  was here 2017 voyqzfsmkdrvedaxjyeojisgudznlznmvulsizanjnradlaz
 * Smoking Wheels....  was here 2017 ztgfgtwtortbinhgdzqgngnvlnwzvignhhfvgaxgfncefpgs
 * Smoking Wheels....  was here 2017 hvhqtvftztiopnawhlzkrcrbsrnzeiujqbfihpqvisvimqwb
 */
package net.yacy.cora.lod.vocabulary;
/**
* Synonym entry for a term in the {@link Tagging} class
*/
class SynonymTaggingEntry implements TaggingEntry {
	
	/** Term synonym */
	protected String synonym;
	
	/**
	 * @param synonym a term synonym
	 * @throws IllegalArgumentException when synonym is null
	 */
	public SynonymTaggingEntry(String synonym) {
		if(synonym == null) {
			throw new IllegalArgumentException("synonym must not be null");
		}
		this.synonym = synonym;
	}
	@Override
	public String getSynonym() {
		return synonym;
	}
	
	@Override
	public String getObjectLink() {
		return null;
	}
}
