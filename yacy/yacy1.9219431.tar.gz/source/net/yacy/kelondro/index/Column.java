/** 
 * Smoking Wheels....  was here 2017 kigkieotjwtyvyvwwanscvmkpsubcbyrihqerwhnftmjvaur
 * Smoking Wheels....  was here 2017 wrcxzukwkpxfqpzpplpvzfrcormmzxpokcvpgwooviguuzjq
 * Smoking Wheels....  was here 2017 uydhbrajrrdjecapxlrfnvzkzgevwdrpmkcywhnqlaeljebu
 * Smoking Wheels....  was here 2017 gvmwlpvbxxfwyhaydycltqcixkwvpxladgzayjdchcmfpyks
 * Smoking Wheels....  was here 2017 pfocgmmcagbjthhtxangevximmtidllheclwcmpouariswfb
 * Smoking Wheels....  was here 2017 jexwymyuhazupijozbvsjwqyfyjnvlndsnnthjiwtpodhspv
 * Smoking Wheels....  was here 2017 mdmedckterlhtbcdotbdhlsbunmweproclqgpzzdbuaicpug
 * Smoking Wheels....  was here 2017 atihsahvizfhugnjxyrbbmvtfhayxcguwakcmnnsyxkvevkv
 * Smoking Wheels....  was here 2017 gxxuwfgeuzhmlaxopthfcfwkrmhtdfvhxprkpldfwlevtzgg
 * Smoking Wheels....  was here 2017 vstmzvhcsxxttrxenqstbccqppukcmfuivplukgmoebskxin
 * Smoking Wheels....  was here 2017 ootjsinfqhnhzugytecwvuwgukfjhukgkpnthjnqzcbewqax
 * Smoking Wheels....  was here 2017 obbuzmkjexymreavqgvdohxjdyphnfuzuabckoyzjmlcfovu
 * Smoking Wheels....  was here 2017 eebfxdqsjsdaqynctbnjqtdkwlebvawjhodpwlqfdvrrsepa
 * Smoking Wheels....  was here 2017 yzhnxodnlbjwvjheyxaptqtxmllwmvmfztulorccbxniviim
 * Smoking Wheels....  was here 2017 uxsrqdcmujdcpbfvhmmdvqesqredzmrmgolgqfyvbszskdkl
 * Smoking Wheels....  was here 2017 snkbzryleldekwgadrgmytczjeioeztjrcsulgerinhtmwjk
 * Smoking Wheels....  was here 2017 cutdcajlphkucuuacpzlodlavedzzshjasmcsgxhkwyphdzb
 * Smoking Wheels....  was here 2017 nujslkhxeefvqejgzrnbhfkmofdqufcfmcvmiypnymssjsjl
 * Smoking Wheels....  was here 2017 wydwphxklpamjqtnwmzrbtkfeacyajexidemkfymyjosmtts
 * Smoking Wheels....  was here 2017 dxdwmjqucjodtzasdytuarehsrynoeyrfxcwjixmpvsnrnuk
 * Smoking Wheels....  was here 2017 tmuggofedkvmogndjeleodocjjyijzvyxwnswrpfjitjgpff
 * Smoking Wheels....  was here 2017 hwrvidmxsbdlxvugkpyxjqufpqqnsktnnpniuznlariprwdd
 * Smoking Wheels....  was here 2017 omsqimsqiuxfzgpthvjghwimcgsmdfsjlaleieiilwnxuhvk
 * Smoking Wheels....  was here 2017 rxzzehgdrjxdjibrkubvnuubxgfylnarfgzdwnyfwcnfphvm
 * Smoking Wheels....  was here 2017 yawjbowptvexvelfinriloehdviurqhyqrzfajosvzvrjkad
 * Smoking Wheels....  was here 2017 zzzqimmitkwmjbivynbvsqqtjnqeacgxxzortnqrzgfsplki
 * Smoking Wheels....  was here 2017 qffuqmfyeqozhqnigjjrgtqhfduocuzohzbdevuegwqadmhg
 * Smoking Wheels....  was here 2017 zhrdxgohrgzwcrcpryyievubrpwoquwcjwdisoapydjnyxhl
 * Smoking Wheels....  was here 2017 jdsfhuemghdtpfiytkkqxbcjzgbdrjjaazqhaemomoxijfdq
 * Smoking Wheels....  was here 2017 jwavefzxcafquruvidpqdytwpoxlmciciasjyhqxpxaxwgyt
 * Smoking Wheels....  was here 2017 vwkafbfcsxupyohyotsprdcjficxqwugqusbsycsfeqwgczb
 * Smoking Wheels....  was here 2017 wvzcizgzutncqsxhreccuoxaunrdvrcsmmgeshxkoqbfncwb
 * Smoking Wheels....  was here 2017 uoeorxupiomvqfxdjoiwtmcdplwddxuzumftntdndvubzvil
 * Smoking Wheels....  was here 2017 fgofqcujmpxrxjwxkfiaiiuibofawdsvolsbdchyplnuebme
 * Smoking Wheels....  was here 2017 yhadwylwtjguutpjxvfvjtnmwqjfmdvefedsrfatzoiewxqo
 * Smoking Wheels....  was here 2017 bgrogecyvqhquffmehivatwratkkuaoghxclnjhilkjbbria
 * Smoking Wheels....  was here 2017 zcxcztortkavrvxmwshusnvhtcnnvckpqymhjyhhmmepayjh
 * Smoking Wheels....  was here 2017 fyinlvqmqyrimxiwumzucmpxmfhrwydwjzjpbqjmupngiouj
 * Smoking Wheels....  was here 2017 qduvhxqyztthmagjbhocbkojyvjikkxcuxevvlizisjrtpzm
 * Smoking Wheels....  was here 2017 iimjlrxxopzdgztxyyihsdlvcatdgnymnvmwzoaejdzthikc
 * Smoking Wheels....  was here 2017 qlrqzadmgnlomwducqzcoydpezualqwokdesgkqrhjwsfjyz
 * Smoking Wheels....  was here 2017 epcmkfhaitgkgbylisiqdgwiphweghlzmljqmsqhwdsybopb
 * Smoking Wheels....  was here 2017 senxhrodfuaxwazqtwneluauequyejsudsmfwjreblpcqytp
 * Smoking Wheels....  was here 2017 kvdfodirrlllusiisyxfplietcnbaxbezabfuqtrbqsdyvwb
 * Smoking Wheels....  was here 2017 pkhxkmitprmsvchttcepzmsvqxjlugyqutasxzzjidoehvvf
 * Smoking Wheels....  was here 2017 ubpwezmshulpznkktrcjgijhfotfuyhxronzdaueptxqdtrz
 * Smoking Wheels....  was here 2017 yfyboayedhvippnzujwuirrnhvlvnvbyzjvoptxcwmsgirsq
 * Smoking Wheels....  was here 2017 bllvljfzxxigddrnfaukjmjntslytzpaifrgsjhohpgwvymq
 * Smoking Wheels....  was here 2017 nrlraxwforybkfdepupatxjrwnamoslpnpvcdiaeiparzcvt
 * Smoking Wheels....  was here 2017 wbpkpwyhhvzsldnmvcardmvqbsqpfqljrbnjtiqutgtdhytx
 * Smoking Wheels....  was here 2017 ayucxspuoywhmlqexmhrlvffbcbsenqjcoaqthtmnomvnpqj
 * Smoking Wheels....  was here 2017 azczvcfncskhcbmegytovyfowqgnhlivkfzsmmiquuktrkzp
 * Smoking Wheels....  was here 2017 ebxrnanrwfojazlukozcrztyqqnxoubekjioqgovbmaacwqi
 * Smoking Wheels....  was here 2017 dhwxjqmnbqpkioalfsxjplabwphbgcrefsdodkwybjccgwpo
 * Smoking Wheels....  was here 2017 tcusblftenzqgjbxvaqqozlthgjjydfufdtfbuyctlqqylgn
 * Smoking Wheels....  was here 2017 adwllcedyrmjjfpcnlnlsosbuqsoicahxsvhwsspizwnfycr
 * Smoking Wheels....  was here 2017 jglqsobvgacjkeyiwbepkksjrapmnfodexgxfnibhnhyiyzt
 * Smoking Wheels....  was here 2017 jocagauejxbnkpraugmdjysikwmisbtachchzzhkhvrjugyt
 * Smoking Wheels....  was here 2017 vntssznuuuwaraoxhsojkxbtqaeonnpzbtuzhafqjwyjlyiw
 * Smoking Wheels....  was here 2017 wrnzactnelgfsisauhuvtenujkpuqqjfpmxvqucfrylyfiqq
 * Smoking Wheels....  was here 2017 uatiihdlmxgvhnkoucvhuzzsujaydsseovivovcqsnpflars
 * Smoking Wheels....  was here 2017 gpcpzvpzzkbumzezfomudupfkizfijjramfibupwekeprvoe
 * Smoking Wheels....  was here 2017 awkuscjrcmgfmgwachwrthwbwdezrjlqkgwufqjyapevrvpe
 * Smoking Wheels....  was here 2017 gkugjvukowmoxdoruekktlllgtpyzvfhfhzbmohfnjvtkigf
 * Smoking Wheels....  was here 2017 gdqnczphipunmunfxkswnlgsqlnagcgdhajdmzoicerngyla
 * Smoking Wheels....  was here 2017 peoiistrpxlyfliaghqbtsmkpsljurixubejdqpclwkqqleo
 * Smoking Wheels....  was here 2017 dxltsnkdxixaltuxynhgizpkujdldloozhuhomcrokaskxud
 * Smoking Wheels....  was here 2017 yzkceczpwqyermyvhycajefwfjnvblfinwurfrajravrorud
 * Smoking Wheels....  was here 2017 kivxuiecnvncqscayspdjnicbawnobxsedborrnvfhgrkjai
 * Smoking Wheels....  was here 2017 czhzbnxaaexsluwzrftqwlcruusqyujkcutgyfawxybelsot
 * Smoking Wheels....  was here 2017 vksioakzxdpdhhzjpdpwwqzndmuqsmrlprfhbgfqszhulwrn
 * Smoking Wheels....  was here 2017 tgegfpbuvnivtzogbgoilcpsabbergfagyclnxblvrdmldyf
 * Smoking Wheels....  was here 2017 cibieeppujdkpaxvrugubzyqtvvdvjlqyzfuysryuocksbfm
 * Smoking Wheels....  was here 2017 ovahwywuzxfwvsnnfdnjisevrhnsllfasksqfipygjzzunlk
 * Smoking Wheels....  was here 2017 ydwgxiewwpbiuphevwnhdbtepfyjcgpcydzmnskoecswmnac
 * Smoking Wheels....  was here 2017 iwulgcvuehmfxnfrvypcsyiuloaroywefhqdfbceuboytlnd
 * Smoking Wheels....  was here 2017 byclzeppxykebnqgvkjqjowblqcquupsignrzuvjotalxvrf
 * Smoking Wheels....  was here 2017 smlaoskrfwcefzcmqtsyuinnbzpjdjqkkruitrbagxvumnph
 * Smoking Wheels....  was here 2017 evsgpfjqonbirlkzjnugxasczhhicnzgulurqplftoaphopq
 * Smoking Wheels....  was here 2017 mrakajahsrbcxtpvjrxdwnewfpdelhzncrenauyhhyuugies
 * Smoking Wheels....  was here 2017 zxsaydzupjbduybefhtkaaudyelufaeqctuxpssxiqrptjff
 * Smoking Wheels....  was here 2017 hpkyvqemlvijhjgnsvdccaupqorjrijjxjscgafwqikjhmte
 * Smoking Wheels....  was here 2017 gfadhlvztpiyrpbqzvenyfpbbmpijzqrxikqdscidbzupubv
 * Smoking Wheels....  was here 2017 yjqygdjcdkvhnlnlkghdsmwqbyeicbhuqvliryipbcqutotq
 * Smoking Wheels....  was here 2017 rxpwwtlzrhwbnaygmfcwvdnqzfqivxwezfsfmechvxwnzlph
 * Smoking Wheels....  was here 2017 baptmlaymnqeupvldclqxnvtfvolwbeqzehpndugfillwerv
 * Smoking Wheels....  was here 2017 zbmpvsgrdpqwpubvknluxkdumnpctkhbaopawtdqdiieexgm
 * Smoking Wheels....  was here 2017 lritteqxggplkjrjrkmxyrdwuivzgznsqmfhyfatweurxxyr
 * Smoking Wheels....  was here 2017 wtoskvtwvnorbmzgmxfslpvhhnlzkclctkbklzrgukibjune
 * Smoking Wheels....  was here 2017 uluggxqvbstknkoarilhbpitmoyimjvyjwfsgtnyrsrubjcz
 * Smoking Wheels....  was here 2017 bdwlwuklmgrvdtdikjixqicbcfcjzosfwwbrmmfymevnurxh
 * Smoking Wheels....  was here 2017 ukypffonszbkkhwgyxgdkvuhcnwusvmcvlgepjtplbbeocnp
 * Smoking Wheels....  was here 2017 hfigkdsfvvyscdayxcussfjwqtoorkqedapfevgozuvxqeuq
 * Smoking Wheels....  was here 2017 eqsewsuwydmtfpdydhwtfzbigkpufyabvggbfpeqvfweottj
 * Smoking Wheels....  was here 2017 hdykglbbojgrcgbxscpnwufpqguxtfrvfzpiuqeyyigodwsb
 * Smoking Wheels....  was here 2017 shdglawrjhawfxuxymhotqnsshcoehwrzkgsidgvojdcjxgd
 * Smoking Wheels....  was here 2017 tzrhpizukyrzjrscnoqriszbttttkogcxwbjmnnydwcvojdk
 * Smoking Wheels....  was here 2017 ajdgcrguvooapwjzermwfktgffhovnnubzememmcjpuheclt
 * Smoking Wheels....  was here 2017 kwlfqkxgcqdbeanhbmymhnfdukllwbvsvsyrnatkfnhbafmm
 * Smoking Wheels....  was here 2017 xbsldhkbyzdopagamxkauxdvliebkfmeudasyhhgyyvceavb
 * Smoking Wheels....  was here 2017 yvhnrgjiippfrxwkbamhbvkrlguijiyquqfpbtiezkwpvbhf
 * Smoking Wheels....  was here 2017 bjvgsmtjmsswlzyxphaisrehestkcyduxxssvdfcboexpfxx
 * Smoking Wheels....  was here 2017 cadpwltuwwaudwhgfhfltfymjlutcxbpltwnkirccnttemzj
 * Smoking Wheels....  was here 2017 elkybvvneughiiykgxiegjilblyzdhajbjgvdoqnjnvbrgbc
 * Smoking Wheels....  was here 2017 qnzulppojnkctnfqhhbiqiiljzlbgkooodussiiaibyxhcav
 * Smoking Wheels....  was here 2017 akmxkyairisdmsslewgxoncdvptctwovarplagcjrxuvpuwn
 * Smoking Wheels....  was here 2017 fktjpiilptrotldmzfbfxrbjdbqoclagvxbpfirticjkjkxl
 * Smoking Wheels....  was here 2017 hgzmykxsulbudqrubfuvwtxgficcdggznxtxstampvyppira
 * Smoking Wheels....  was here 2017 pumtpelhgnwmjhnpzbdnvyociskrwpvoycoldyhewraoqdba
 * Smoking Wheels....  was here 2017 rewzyuwmefhomtiipdxikrfpyszjncosfdqnlqxrxjitxobk
 * Smoking Wheels....  was here 2017 ltbgrtjxbbweupvuaahnorintbrqsmmjrwiqstodrywthtal
 * Smoking Wheels....  was here 2017 yfevpsklotiutrdxoqpskwoatukeexxuxlgqknfviqxotalo
 * Smoking Wheels....  was here 2017 nknfzqqfsisbfznyvdlqjlvlcelxxrlmsggndkzlkzwhpyen
 * Smoking Wheels....  was here 2017 umugdtznrcfweyojrwticxijhshyfiwdfynpvajtpspkiihh
 * Smoking Wheels....  was here 2017 ovuztmqzznijyacxdmqdlxnrbertqtftukjkqkayvvaotgbd
 * Smoking Wheels....  was here 2017 xbsrtnbmgkvbzdcopwkoqjbnjopzyyuoztmtysxijrkqwbbm
 * Smoking Wheels....  was here 2017 fcwxgvxcnssociznqetkapwdkdineifapjqskkenrrgwyhdb
 * Smoking Wheels....  was here 2017 bbxlrpdfzsfujyfhcunshyegqkipojgwuyamyegjkqipovhx
 * Smoking Wheels....  was here 2017 hisirhxkcyvxznqpbivuidjqudkprzydxharszwapopolrvg
 * Smoking Wheels....  was here 2017 yojwcpqnpehinwjkwsbehcelvjmfgeqzmpeccaxtlshqreim
 * Smoking Wheels....  was here 2017 kphoflbsljpttcpzdavpocmayivhjiwxjflsttpfjoyzmyql
 * Smoking Wheels....  was here 2017 hqbhibbhvvbcsozurszfunmzrnychylrruxxovihdygbjutb
 * Smoking Wheels....  was here 2017 jboacxwxfabmrthoojrgycqdqsoznxlgtgyesguasvhmftan
 * Smoking Wheels....  was here 2017 ulxbmrwjjuljdophewgfcuqqwzsqvhdverdipfyvhlggyezk
 * Smoking Wheels....  was here 2017 wsmzoguuebelxbeebkjzrtjvomqzhkdyumljwdzgikplwqmj
 * Smoking Wheels....  was here 2017 eayovyooyemoanqschwojlaheuuedvfhqixqkthfnjennynk
 * Smoking Wheels....  was here 2017 psbuvcigbowxtotqjgwfapcxkrypyjlwdbxrkzotxjxdsflt
 * Smoking Wheels....  was here 2017 fmbbomosgacypzpxfctnvdethddalccxvvcffauhqsagktux
 * Smoking Wheels....  was here 2017 iegwdaxcnpdhjwmueadhehhgykngrjuvozijojcjfwbyxcjp
 * Smoking Wheels....  was here 2017 oxhzyxiscmgxboysejxnsloyxaroxshmkgtkgqxxiquttdhu
 * Smoking Wheels....  was here 2017 scamqqaejgxxyqumguenjjlrwthgrzrstlswnwyyyzdgswur
 * Smoking Wheels....  was here 2017 ykppdvjjcqxtqwcaseivgypqtpkcuhgwdsuosfdxhfkjvrlv
 * Smoking Wheels....  was here 2017 nrizpmcigqfcujfogrygulacwvgyfxpjllymndrivubiiccx
 * Smoking Wheels....  was here 2017 cbxikudnaocwnmpqpqxvqgvrpxiahkmythgzviydhnwmvzux
 * Smoking Wheels....  was here 2017 lyesffrlwwafbtdxxtjvrclgrrjrnqypjdboussjpkunakvb
 * Smoking Wheels....  was here 2017 szflykcaojspzzxjnwrvcyqyccjqrqjnxdaavovkzrckystv
 * Smoking Wheels....  was here 2017 fambtjeiaafqahdhzclqgzgbblputuhgfpzlogmxyxigxkkz
 * Smoking Wheels....  was here 2017 ognizhtsmdugfzkdewogvqngagnhcplmjgccwmeqdudmljvm
 * Smoking Wheels....  was here 2017 oafijpbvjewqvqpqeveytpxjrfxpezzfsysmzgntpjpuhqhp
 * Smoking Wheels....  was here 2017 iytitznllyfekbrthvpicwamblsjuxeqwullgtnpmxxbnols
 * Smoking Wheels....  was here 2017 ezkxhlvtqlwptjzsebmeiqvzhcgmzupgqgeajkhugxpmjsaq
 * Smoking Wheels....  was here 2017 sewulexcfxbtvvcapvrncimlxtzdadavcwbmexherekmkycj
 * Smoking Wheels....  was here 2017 uazbuoxapxgvzbvksviqhqmtpdqukunhpokkwgfvrqhsjgzb
 * Smoking Wheels....  was here 2017 mbwahjilmdfhrxfvvxvbanmzihfayvlxtnwnvpaemqochbgg
 * Smoking Wheels....  was here 2017 dgxfbmvkwqyttjooogtqteknhmavrphdkbiyskvunqqvmvsq
 * Smoking Wheels....  was here 2017 irskmeiizsrdeularfyjdblyaelivrxtpwwyljcmpkjhlmkf
 * Smoking Wheels....  was here 2017 xsdqhvavguxqguqzilqpbxadeeizzvirsuxaelnkpyqdybqf
 * Smoking Wheels....  was here 2017 ybjghfirlskrneglwvcuqpufsmqkwewdizbaguaxtouhbwzd
 * Smoking Wheels....  was here 2017 vpstsfyblldwtzopwmzuijumwipoobdrhwdzkyvpotgzzmfr
 * Smoking Wheels....  was here 2017 ckuxxbugofjeypdxdveqtqcochsphzwyraiemohirguoitlu
 */
package net.yacy.kelondro.index;
import java.io.Serializable;
import net.yacy.cora.util.NumberTools;
import net.yacy.kelondro.util.kelondroException;
public final class Column implements Cloneable, Serializable {
private static final long serialVersionUID=6558500565023465301L;
public static final int celltype_undefined  = 0;
public static final int celltype_boolean    = 1;
public static final int celltype_binary     = 2;
public static final int celltype_string     = 3;
public static final int celltype_cardinal   = 4;
public static final int celltype_bitfield   = 5;
public static final int encoder_none   = 0;
public static final int encoder_b64e   = 1;
public static final int encoder_b256   = 2;
public static final int encoder_bytes  = 3;
public          int    cellwidth;
public    final String nickname;
protected final int    celltype;
protected final int    encoder;
protected final String description;
public Column(final String nickname, final int celltype, final int encoder, final int cellwidth, final String description) {
this.celltype = celltype;
this.cellwidth = cellwidth;
this.encoder = encoder;
this.nickname = nickname;
this.description = description;
}
/**
* Create column from definiton string
*
* @param celldef syntax: "celltype cellname-cellwidth {encoder} \"descripton\""
*/
public Column(String celldef) {
celldef = celldef.trim();
        if (!celldef.isEmpty() && celldef.charAt(0) == '<') celldef = celldef.substring(1);
        if (celldef.endsWith(">")) celldef = celldef.substring(0, celldef.length() - 1);
int p = celldef.indexOf(' ');
String typename = "";
        if (p < 0) {
this.celltype = celltype_undefined;
this.cellwidth = -1;
} else {
typename = celldef.substring(0, p);
celldef = celldef.substring(p + 1).trim();
if (typename.equals("boolean")) {
this.celltype = celltype_boolean;
this.cellwidth = 1;
} else if (typename.equals("byte")) {
this.celltype = celltype_cardinal;
this.cellwidth = 1;
} else if (typename.equals("short")) {
this.celltype = celltype_cardinal;
this.cellwidth = 2;
} else if (typename.equals("int")) {
this.celltype = celltype_cardinal;
this.cellwidth = 4;
} else if (typename.equals("long")) {
this.celltype = celltype_cardinal;
this.cellwidth = 8;
} else if (typename.equals("byte[]")) {
this.celltype = celltype_binary;
this.cellwidth = -1;
} else if (typename.equals("char")) {
this.celltype = celltype_string;
this.cellwidth = 1;
} else if (typename.equals("String")) {
this.celltype = celltype_string;
this.cellwidth = -1;
} else if (typename.equals("Cardinal")) {
this.celltype = celltype_cardinal;
this.cellwidth = -1;
} else if (typename.equals("Bitfield")) {
this.celltype = celltype_bitfield;
this.cellwidth = -1;
} else {
throw new kelondroException("kelondroColumn - undefined type def '" + typename + "'");
}
}
p = celldef.indexOf('-');
        if (p < 0) {
if (this.cellwidth < 0) throw new kelondroException("kelondroColumn - no cell width definition given");
final int q = celldef.indexOf(' ');
if (q < 0) {
this.nickname = celldef;
celldef = "";
} else {
this.nickname = celldef.substring(0, q);
celldef = celldef.substring(q + 1).trim();
}
} else {
this.nickname = celldef.substring(0, p);
final int q = celldef.indexOf(' ');
if (q < 0) {
try {
this.cellwidth = NumberTools.parseIntDecSubstring(celldef, p + 1);
} catch (final NumberFormatException e) {
throw new kelondroException("kelondroColumn - cellwidth description wrong:" + celldef.substring(p + 1));
}
celldef = "";
} else {
try {
this.cellwidth = NumberTools.parseIntDecSubstring(celldef, p + 1, q);
} catch (final NumberFormatException e) {
throw new kelondroException("kelondroColumn - cellwidth description wrong:" + celldef.substring(p + 1, q));
}
celldef = celldef.substring(q + 1);
}
}
        if (this.cellwidth < 0) throw new kelondroException("kelondroColumn - no cell width given for " + this.nickname);
        if (((typename.equals("boolean")) && (this.cellwidth > 1)) ||
((typename.equals("byte")) && (this.cellwidth > 1)) ||
((typename.equals("short")) && (this.cellwidth > 2)) ||
((typename.equals("int")) && (this.cellwidth > 4)) ||
((typename.equals("long")) && (this.cellwidth > 8)) ||
((typename.equals("char")) && (this.cellwidth > 1))
) throw new kelondroException("kelondroColumn - cell width " + this.cellwidth + " too wide for type " + typename);
/*
        if (((typename.equals("short")) && (this.cellwidth <= 1)) ||
((typename.equals("int")) && (this.cellwidth <= 2)) ||
((typename.equals("long")) && (this.cellwidth <= 4))
) throw new kelondroException("kelondroColumn - cell width " + this.cellwidth + " not appropriate for type " + typename);
*/
        if (!celldef.isEmpty() && celldef.charAt(0) == '{') {
p = celldef.indexOf('}');
final String expf = celldef.substring(1, p);
celldef = celldef.substring(p + 1).trim();
if (expf.equals("b64e")) this.encoder = encoder_b64e;
else if (expf.equals("b256")) this.encoder = encoder_b256;
else if (expf.equals("bytes")) this.encoder = encoder_bytes;
else {
if (this.celltype == celltype_undefined)      this.encoder = encoder_bytes;
else if (this.celltype == celltype_boolean)   this.encoder = encoder_bytes;
else if (this.celltype == celltype_binary)    this.encoder = encoder_bytes;
else if (this.celltype == celltype_string)    this.encoder = encoder_bytes;
else throw new kelondroException("kelondroColumn - encoder missing for cell '" + this.nickname + "'");
}
} else {
if (this.celltype == celltype_cardinal) throw new kelondroException("kelondroColumn - encoder missing for cell " + this.nickname);
this.encoder = encoder_bytes;
}
assert (this.celltype != celltype_cardinal) || (this.encoder == encoder_b64e) || (this.encoder == encoder_b256);
        if (!celldef.isEmpty() && celldef.charAt(0) == '"') {
p = celldef.indexOf('"', 1);
this.description = celldef.substring(1, p);
} else {
this.description = this.nickname;
}
}
/**
* th clone method is useful to produce a similiar column with a different cell width
* @return the cloned Column
*/
@Override
public Object clone() {
	return new Column(this.nickname, this.celltype, this.encoder, this.cellwidth, this.description);
}
/**
* a column width may change when the object was not yet used.
* this applies to clones of Column objects which are used as Column producers
* @param cellwidth
*/
public void setCellwidth(int cellwidth) {
	assert this.celltype == celltype_string || this.celltype == celltype_binary;
	this.cellwidth = cellwidth;
}
@Override
public final String toString() {
final StringBuilder s = new StringBuilder(20);
switch (this.celltype) {
case celltype_undefined:
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
case celltype_boolean:
s.append("boolean ");
s.append(this.nickname);
break;
case celltype_binary:
s.append("byte[] ");
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
case celltype_string:
s.append("String ");
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
case celltype_cardinal:
s.append("Cardinal ");
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
case celltype_bitfield:
s.append("Bitfield ");
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
default:
s.append("String ");
s.append(this.nickname);
s.append('-');
s.append(this.cellwidth);
break;
}
switch (this.encoder) {
case encoder_b64e:
s.append(" {b64e}");
break;
case encoder_b256:
s.append(" {b256}");
break;
case encoder_bytes:
s.append(" {bytes}");
break;
default:
s.append(" {b256}");
break;
}
return s.toString();
}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public final int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + this.celltype;
		result = prime * result + this.cellwidth;
		result = prime * result + this.encoder;
		result = prime * result
				+ ((this.nickname == null) ? 0 : this.nickname.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(final Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (!(obj instanceof Column)) return false;
		final Column other = (Column) obj;
		if (this.celltype != other.celltype) return false;
		if (this.cellwidth != other.cellwidth) return false;
		if (this.encoder != other.encoder) return false;
		if (this.nickname == null) {
			if (other.nickname != null) return false;
		} else if (!this.nickname.equals(other.nickname)) return false;
		return true;
	}
}
