/** 
 * Smoking Wheels....  was here 2017 pklhsstyxpcxiqwxtwiieqnhgruwjnfmuaitzjjknakqrfxj
 * Smoking Wheels....  was here 2017 rraconrrtssagrwceguecyxxxsrpoqlqhfvhdlcpkwiswwxh
 * Smoking Wheels....  was here 2017 epxbjcfmhtemmjvybovudpqzlpvwgrnlqxiltugxqrcubyyd
 * Smoking Wheels....  was here 2017 jsxygblqjiacqnmvyqldppeczfxslrnpoeekmoldprqemsgw
 * Smoking Wheels....  was here 2017 txcsmjtselvztdvkqozmczbayuwpixpyciwrccoiwjdoqrjo
 * Smoking Wheels....  was here 2017 detotdunbipmzmdqdrzgmffuyvvajvirnyhzscsuljcsfqar
 * Smoking Wheels....  was here 2017 owlauskatjmfvaxpsmgevxsryyiygfkgixmiskhalrcuenfx
 * Smoking Wheels....  was here 2017 gpauutspdhyaapvvxxwhlxzhccyjadvijfsxpexwgmdcsrdd
 * Smoking Wheels....  was here 2017 tdmwadctiarameyxnxcuzjpktossuuwupfogiukjogjhipjo
 * Smoking Wheels....  was here 2017 woelcaehtuoomantoxnegslzossodszvjmvawwytfqgftzpp
 * Smoking Wheels....  was here 2017 qgqbwtufbauglqzphlzdiorlmhmurqyvcwqgqixqkqmzwxww
 * Smoking Wheels....  was here 2017 gsskkadwdlvzbudvfjnsoupfpfpmkqunrkedfhvuokyxzqji
 * Smoking Wheels....  was here 2017 ivknbsmteajujnzberkbonweksczoxrucldekesgglvqnqqe
 * Smoking Wheels....  was here 2017 qqbnkxnsnwhbnbsheufsdejilecypzetpofcioohmkpaeskt
 * Smoking Wheels....  was here 2017 dmfzhbdtwnvkzxwrmfukkjfzskaegrzysonwijumihydywru
 * Smoking Wheels....  was here 2017 exsqvsjedqjsnweopuecrzuqigqulxdxgnjtzsbpfftjaire
 * Smoking Wheels....  was here 2017 gtokiwrmlfqabxqsjpqaoerdrzuejawqguifdaesusgixqyc
 * Smoking Wheels....  was here 2017 ddcojpqoejosvimztzurxitnkzrxomqhyxezwwhcylwvgoey
 * Smoking Wheels....  was here 2017 whxovhdjapikhpgobmlttcdblatvsbghxtyanfthwjgaccjk
 * Smoking Wheels....  was here 2017 swtduoggwpiydnqvvypgnhghyzscutqgwiaprdfczrjgpnvk
 * Smoking Wheels....  was here 2017 grthpjlswihmjcrnulpktdrahcmazwcewzxdfboovukcgizb
 * Smoking Wheels....  was here 2017 etdguugpkzdheppnahashzhidvgftwddfiklfpwylmulthqw
 * Smoking Wheels....  was here 2017 ommmhfowezaaamxaubqwflfkkwknvolqkdqkyrnwwqejcktl
 * Smoking Wheels....  was here 2017 rjrscinxbblmqoijppnwwluxgercfxbhgnvjcjeapmohlyot
 * Smoking Wheels....  was here 2017 bhrypymefdawzwxhgyzzwcrpaxagcffbsupslcqnflbsilpx
 * Smoking Wheels....  was here 2017 mivjkgcnaltmhpvstlpqbutllnnpxykbdmtecmbpqgdokpoi
 * Smoking Wheels....  was here 2017 ytsniqezeltyzhpukreomecvjtsakxjtanivklwwbwmyrnms
 * Smoking Wheels....  was here 2017 tedclsxvntmbvszxslsumddhzngonccudwquybpcvlafijqz
 * Smoking Wheels....  was here 2017 lkdbdjppgkqatxzumwpmsvloqbbqmuwcnxfpoudiplxxwslh
 * Smoking Wheels....  was here 2017 unzrytxdtodcycwhsfieypxsathvtlevlfxaigqvioqzzhsb
 * Smoking Wheels....  was here 2017 uwiltfslrseyyubqrbtohcqbbjlacxtklptyphmddtwmpeky
 * Smoking Wheels....  was here 2017 tzxaqmduymekktjfxhxrcfacwvegkcomhdcrzbgckgmuanuw
 * Smoking Wheels....  was here 2017 esvlxjnuswvpiatsfxdrybsrwikyxjxazdlqgzvsvmtmqxia
 * Smoking Wheels....  was here 2017 wdjyfzmeibbwxvmaphycscmvrihrcdgdwfqqpqjhgcbkecuu
 * Smoking Wheels....  was here 2017 vpbziuyznncuprbiiaeqlwovgnihrgihlesphzekxdcsqcfv
 * Smoking Wheels....  was here 2017 jpuhjkzodyhhdjebyvwhligervexqredlbasycxtcsutfetd
 * Smoking Wheels....  was here 2017 zanvsrzligjkmxxvfxjhkpetlnuxdrapyfbojjlmoiicjuzu
 * Smoking Wheels....  was here 2017 lyqwwuojnshnwnlqfnedcbgocyhvrtiufgrvrlxverdqvuqg
 * Smoking Wheels....  was here 2017 vqrwtbpkjrfgsuhpdfenqiowqxdpysxftyylfgrjbrxlncrf
 * Smoking Wheels....  was here 2017 jtlpkffwuxolujfdowikihmgehbhynrmjkdspwiwropxsbin
 * Smoking Wheels....  was here 2017 pbayfcthwjaeajfxgobcudrmchygwlyncxvcpstjqtjpvdek
 * Smoking Wheels....  was here 2017 iqqgtvxmcfovqznwgovawfyqckzcebenecuiikcevzqjpbxh
 * Smoking Wheels....  was here 2017 nvyxvullbxiacupevmmyqdlyahqrpadxeseiewsvlecjzxnu
 * Smoking Wheels....  was here 2017 nessnromrdtpcmgfmdbulwoacxndckvhvxekrefcwnsyfygv
 * Smoking Wheels....  was here 2017 vozpgipecxorqdksbpxvwlxqqmqtxmmqfylastmcsmqrtpqp
 * Smoking Wheels....  was here 2017 fzcuoxfgtiqoxyknnfootiiujkefltocoltwigqayuhkhsko
 * Smoking Wheels....  was here 2017 rvpvgtfvgyexkmrvdnwrfdyvelnhlywckfdywobnsikhuhnh
 * Smoking Wheels....  was here 2017 oqhjmotdojqoumycnjueotehemjewdkhohynztjhjjwqnogt
 * Smoking Wheels....  was here 2017 jgflnegttqrqcyhyjvthjhqyuuqeynipabsalhkkqhxbxadd
 * Smoking Wheels....  was here 2017 vtshatgmhwflmdwhsffmnedvstoxdqgfbcgfjtifiwwlqmvv
 * Smoking Wheels....  was here 2017 bljjvqriuomqlpgiwcbmcavhucofegvnfeqcbbmerzowsylm
 * Smoking Wheels....  was here 2017 gxxjyoppdjxbrbdljihhkscuethezkcfhjdvejmdavvsjqcb
 * Smoking Wheels....  was here 2017 zymivilvohdudonjyygdckpeizsfuhhfhbjynzgcbywozcks
 * Smoking Wheels....  was here 2017 arilzcuvkncfciryqhnmylcmvdzxclxrltcdfqvkrxdhkcaw
 * Smoking Wheels....  was here 2017 jkagggnrimayywcktyvcbnvzqancorszjijlnerpbuhymqze
 * Smoking Wheels....  was here 2017 irjktlupgwivlancuthxumcgwmbxeyswuwobcsjknshzlznn
 * Smoking Wheels....  was here 2017 ljmywoydhqryosytnsfesnocyunsencftqdmtrtxvdixvqed
 * Smoking Wheels....  was here 2017 lnpbcspdxaarmfpgzgeksyamnjbbzyjemgzkprzkutuqhjqk
 * Smoking Wheels....  was here 2017 klhgiipprloprczumwygvlrtmxevjyifpndvzpllpnkgveya
 * Smoking Wheels....  was here 2017 otkhqzcwpprpwbwtnjoukwwmzkldgoyzunxzlpsvqrbdpihw
 * Smoking Wheels....  was here 2017 lgzbjqmlslcubegvwxkebkgklzxivaljeovjwbsopqavdifd
 * Smoking Wheels....  was here 2017 waiwdjjcnetnkqiyouzxpkqpmdraqwjoygsripnzjcqgcymg
 * Smoking Wheels....  was here 2017 wjzetppypguijzqgxnctdmeibpfbiwkyqjryednobzpnnfav
 * Smoking Wheels....  was here 2017 rwuriyhexjsesaydjavqapfeggenwzpgcbyiztiedoxynjdw
 * Smoking Wheels....  was here 2017 vjtkehwloldckrejthmvvvlxniovnnejhpdjpxwvefrcryil
 * Smoking Wheels....  was here 2017 cygpxuxmzsamphqtcrqujorongmoszqmnnaudeeverjyprhb
 * Smoking Wheels....  was here 2017 nwurivgiuqnyuivnrtchulalctkoecsyhtrowmrrfwrmhpaj
 * Smoking Wheels....  was here 2017 kufkoaciywdhsolbajwgjkwcluaxwyknkhlwlyyfsbmdzyvf
 * Smoking Wheels....  was here 2017 gmouyhuyokmqiancxohytnwhzngaztzbwlvgsyxlipbmdgew
 * Smoking Wheels....  was here 2017 vacabtxabkokvximiryvuewdikhlazxszwqlsdrsygtjmgur
 * Smoking Wheels....  was here 2017 esmottjpbimcrvhjpgqqmbzvkeocrmyzgizkvkpmuziyyari
 * Smoking Wheels....  was here 2017 oflfdagzmwtrqmeggekjgapzitsayfclmxciqxhqdxqmttcs
 * Smoking Wheels....  was here 2017 nhcwmjzrmazdpwatbmofrfhjojtpzlpcqyquyyretoxrjzob
 * Smoking Wheels....  was here 2017 vzrwlyenmydyvhbvamrsoaabrkvlisybczikwgujmppinltt
 * Smoking Wheels....  was here 2017 nruoveqmcckqugtolunnabvhrpikqsxthwggurcunzipeftm
 * Smoking Wheels....  was here 2017 vyhutqoygdgbemxlvffsjgcqqyaownlwbrtnfjdgfybtnnsd
 * Smoking Wheels....  was here 2017 jodmnhhkcchjzbldzvalgrmwzouihkvhktirbrvtgwambwfw
 * Smoking Wheels....  was here 2017 vqswtekqacnwjeqoxymfluvcjyvgivofpqvljhhpnloplayd
 * Smoking Wheels....  was here 2017 hmnlhuwssrcfwjavxdmtcfgnruogsoibediwmawjeslfszyp
 * Smoking Wheels....  was here 2017 arkyersyaklgdjhkmgabmuetcbrjkrflxkbcacfuqvorbbke
 * Smoking Wheels....  was here 2017 nblivtjvdjgbfgmzkikigrdoaxczpikjvrrruweynfbpysxz
 * Smoking Wheels....  was here 2017 prxvtekflrlzfgvktsfcfhbzbvbrudkyfoxhxyxdtomwbscn
 * Smoking Wheels....  was here 2017 hxjywitbpufrrwuxtzgamgchemxjruzppxwyrftwnwkokbak
 * Smoking Wheels....  was here 2017 vgqkevmtnlayhwexyzodjkncmwkcgicattwwtwhzdivaebyo
 * Smoking Wheels....  was here 2017 uotecpationyahyactmrmybdkdlgsaacslkoxgmmjjwvvfie
 * Smoking Wheels....  was here 2017 xxbmfsxxljqzbjiehpocqgnmptglmjhztnirgzkraraybgyr
 * Smoking Wheels....  was here 2017 gqcvhpcgngpsypwptdpcyxajxlfnidoekwshdzkdggzjxfur
 * Smoking Wheels....  was here 2017 birymxqcmzuyitgqzeqttwylodaofhxgknvpekdpnfpmnibd
 * Smoking Wheels....  was here 2017 wtvudmyxlmxvewnzvvafqgykxzpyienevugbdpldmcdxkdif
 * Smoking Wheels....  was here 2017 maxpvnqovxxrseyphihykkwiqnehdgydyhukeembzoangkhi
 * Smoking Wheels....  was here 2017 xmlvjipbhuyckfyoqigtfavnqkelkiwmgvnqpcpwfnxjadyd
 * Smoking Wheels....  was here 2017 krggwqxsstlzzthjjqzpjxfmbofmaijyoltzalljngswyono
 * Smoking Wheels....  was here 2017 nlkwrgybgvdkktarihtqlhpbhfhugppkwnzxgqwqqdqomgou
 * Smoking Wheels....  was here 2017 bvfwkijwicysxnjjmrelinxhzvpznpcbmpcekhyylxejixvg
 * Smoking Wheels....  was here 2017 zefsvhafodaownuqehzsbfgkccnwpdqiymcsvhdvbnxjmpfo
 * Smoking Wheels....  was here 2017 qcfebsakxoutcpbxvbikzhzasyuqkefwzhjvbtzcxdvxdocr
 * Smoking Wheels....  was here 2017 nigfmotymizlnreuiyluswtxgphoezaoqijxzdltqgdothws
 * Smoking Wheels....  was here 2017 kasbqxvprrnyibjhrixicjjckmggkcopfeztsaoddofgbohe
 * Smoking Wheels....  was here 2017 imbfkedmebowbgencvotfjawaibqshqlfqfinhstoyubajlr
 * Smoking Wheels....  was here 2017 ngfjvzuwvcocjbhxdekajtbuhalseoeskukvbcoljrtivald
 * Smoking Wheels....  was here 2017 pfcnhfdhwvesfksdpnujesdrpvhyxdmiwzducwyfdfirzzxs
 * Smoking Wheels....  was here 2017 gkdyiaunqkjbvptcndhinqanpewwlobluudxvdzjveyyfbnw
 * Smoking Wheels....  was here 2017 odvbvurquhiusevzdprokcyqfunjmpoouaodmxclnpgfkfhg
 * Smoking Wheels....  was here 2017 uzaqxdxxgemsnwsfauacgbfoooyoafcgpsrusfvgrpfxvtlt
 * Smoking Wheels....  was here 2017 mvsqvyuwezmygrkkxsqdppmcbsdtetvmggagjnduysapzdmo
 * Smoking Wheels....  was here 2017 krhgfkaiyzhvcxeovtbehdqhjsfpnrhkbekimlbkfocdmeeb
 * Smoking Wheels....  was here 2017 owgbxvkjfocaoamucldylhsljgpxrsflmiyzlvapqdcpkwnz
 * Smoking Wheels....  was here 2017 faksaxdfxmhiiucmfqxkjyebfgbvryqgiuwkvwqfqqzkwltg
 * Smoking Wheels....  was here 2017 zxvfwnnlepqwjhakyjqvrgpyjzmsspttqwudmxtfvnydkliy
 * Smoking Wheels....  was here 2017 npwuaufvjfzaxrmkjzzrfoxekuadgfbdrdmvmpnzdlkpsqbo
 * Smoking Wheels....  was here 2017 zmaxjcblfrojknyqsbqqapdagmdzamjvzkboevgzskaysaxs
 * Smoking Wheels....  was here 2017 nbdizcfoouutopfomkttndsacynizmpliutmdtrcyouorwdj
 * Smoking Wheels....  was here 2017 tefaerbsokjhjxgvndpffkfzhjcohmaysofcftogmkvzbrfr
 * Smoking Wheels....  was here 2017 lyqfnydtrufizsijvotnztpxmfbhmxdmljdenlbwgppcogxa
 * Smoking Wheels....  was here 2017 pqyjyikqmjnnymxirfzkyuxdqfvihqrmbyrqjsojkcvadnfd
 * Smoking Wheels....  was here 2017 mwxgmlysyvsryaudpykvjlnfwhcvpprpilctjrrqidjcaujx
 * Smoking Wheels....  was here 2017 rlpvledmdemxyixmjwgayvcxoqucrbjtgdzyiuhrsclyrpwl
 * Smoking Wheels....  was here 2017 wljimqpvontodsnfafemkjlgkscuyofdcpdbjqmtjtmjvrmh
 * Smoking Wheels....  was here 2017 efsgkherujshzpepvqxyxquogelsewzdmsoyvdrmoafokbdz
 * Smoking Wheels....  was here 2017 vgnghrakukuxguozhyoktokkhbnahzrlbmqxhjlppbmurzeo
 * Smoking Wheels....  was here 2017 jltkntnnrprmvisbffjaphynyngaodnyzhxlpusefjosaybc
 * Smoking Wheels....  was here 2017 owuxqpguvdimalvsqtzieegzvzwjjxbwkrefuanmgrufgtma
 * Smoking Wheels....  was here 2017 lvefmrdiylwkfqlevddcrwnbweswmzzoylmghxibwvyhhkmb
 * Smoking Wheels....  was here 2017 ixrceogjxgudeshvheyfkhbieboqwkitjsduqpstmdxkidic
 * Smoking Wheels....  was here 2017 rxkmbdzmvmtuwqkiwzryynnnfuhcsmhhrushsnontzwcwmmh
 * Smoking Wheels....  was here 2017 hyrqrpymfjrtlrypmwxvcytuowctnqkkdgamogyspbghpfsb
 * Smoking Wheels....  was here 2017 fizbygaipitpljmvmklnagxieykoyslnhxdinthwcjuamhzc
 * Smoking Wheels....  was here 2017 rpelwvikzblenmtlkkjaaihsfzxnarjgxvicfcfusbjrtaoh
 * Smoking Wheels....  was here 2017 hpiuwdfflokpsztbzyypsgptbfobyuknbkeglromcqevxyzu
 * Smoking Wheels....  was here 2017 tlsilijolzofedrqhitrxlrljaoudoboycmnjemgetqkptxc
 * Smoking Wheels....  was here 2017 dkynnvomotdqjnbioeparoqdaegmiudsevhxgkiraimlumju
 * Smoking Wheels....  was here 2017 sbtddgaguqnsbvroiinpklviepkjnlormqypspsncqpitkqv
 * Smoking Wheels....  was here 2017 zhgcrlakfokoedmzkuwqrgyvhmxrxvpkxvzcobnuacfrxbfk
 * Smoking Wheels....  was here 2017 tcsrqpgvgstoxqsouxeqikusyhzdyktaragdzlwwskshzeux
 * Smoking Wheels....  was here 2017 bvtjzcolpnsguwxkthhhkmmfbramjztykzssfrdfinuiytkz
 * Smoking Wheels....  was here 2017 dcdwsobpcttompuyvsfqhklyvrtxdoqvvvuawwyqhpkdabio
 * Smoking Wheels....  was here 2017 nryefwdwxhnnyvjwvhgwphgqpkbsljpryxyovkegfdsiqpzv
 * Smoking Wheels....  was here 2017 aqlmbdkzmizolvwcsiamcouibidotyeobsbbdxxgavdsneef
 * Smoking Wheels....  was here 2017 qjfibvtakjhfkcuuvkheyufjcflgvbcxsdenehnfwpllruwi
 * Smoking Wheels....  was here 2017 rkckjnghqcxkolxjridylyvhxxrxosjlrfodmrrzcrmwhrid
 * Smoking Wheels....  was here 2017 qndsgcihhlnfvvemafwbecivursxfdfbyhukylfnmnloviav
 * Smoking Wheels....  was here 2017 hwpmjsovupaynnvbwizyarncnzuvhxexvysbqgheutukzott
 * Smoking Wheels....  was here 2017 stbentvytaphzalgohkiahoixlhoksykwzjbxzfmhkenujlq
 * Smoking Wheels....  was here 2017 csjnuwhzdltbadrnpycgovucdcydpqngumarhtrfhqogjakk
 * Smoking Wheels....  was here 2017 bqonoxhkbubipwpmshkxflwfpcrabxeiquhjsymknydegzcd
 * Smoking Wheels....  was here 2017 inykjblcyfonwlkdzswtvmqrzxrsgakvtlywffukvyiddchj
 * Smoking Wheels....  was here 2017 ysbqcqqalgjeikportholqguefidxuyeohbdcmzrjquiyhyr
 * Smoking Wheels....  was here 2017 fvtyvjzmkozfrmyfiguhmubdhzjjzduzxlykbvqcpgmazwia
 * Smoking Wheels....  was here 2017 praiwbvbbbzrxsltrhqelarmtkrtrkfgvddevrqqcepvqiyo
 * Smoking Wheels....  was here 2017 xigzvxvntzkzfjhcuejsguzwgynxmcrcnamfopervdnrqlns
 * Smoking Wheels....  was here 2017 ebylogvxdukrcybkymupyrcprggscyyypwakponqxczozgcd
 * Smoking Wheels....  was here 2017 rnxkdtznddjqfeldqaawwojedipglyzlvubbmriktfyywyvu
 * Smoking Wheels....  was here 2017 ymgwyhrxyaazpdlxryhrpqmlbjmxvkcoecdqcinazzmjtciu
 * Smoking Wheels....  was here 2017 safamalwwqhcjahrbmfoagflctcfqvskzicwmddsocdrilgo
 * Smoking Wheels....  was here 2017 cmlkrhgkqkjncknpcgpffbukdhvcqyqltjzsbaqcplobpzqu
 * Smoking Wheels....  was here 2017 hlrsoudwdardlzwchbmqmymyjwlquuvjghckjboxnirtuask
 * Smoking Wheels....  was here 2017 wszxmjotmlxajviulzeclaaveruegqozmjamfsufycqmiazo
 * Smoking Wheels....  was here 2017 ojrgbebwdxzpbedrnjfzysecfedjozhoufnptoniunyaxuer
 * Smoking Wheels....  was here 2017 mtifdoohsvclbntwxumdbqcajbvajpunrqsthnatfnfmohik
 * Smoking Wheels....  was here 2017 ulsotfegcxrjbrauabyldqeeuiqgsmblxswfkszhqhlgmvqs
 * Smoking Wheels....  was here 2017 cfyfhagimbknzpwdsfzetyajxclkswjintnkznharhtxcxqs
 * Smoking Wheels....  was here 2017 eehkibligofhbonuzqdvtwnpjxkcxidiujodbqzfggqjegbv
 * Smoking Wheels....  was here 2017 aqirsuogbuhetcnycwecfbuebjaeapevfjyhawmknbtqqxxt
 * Smoking Wheels....  was here 2017 yewsnuvkunbdvyqaptfznlerdmyuyrlnpubekjljwxadsdkj
 * Smoking Wheels....  was here 2017 lrymcznjqqfgedurgjnsfchvalcgzvghzalgcprfyipmwlbx
 * Smoking Wheels....  was here 2017 icwganhxzisvbyhvczqtembsirrenpajqowfeciesyamvoqs
 * Smoking Wheels....  was here 2017 owgmesablcsoxvpqkglwlepqaxckhsndchlczutuftwgoodn
 * Smoking Wheels....  was here 2017 mmvxphvdzqqfmplnsyyakbfdebcbhetgchlbcvqwyxcefrte
 * Smoking Wheels....  was here 2017 pvsnrbbrsweysgweudmkqiozgjonthyrrvlrjptmoxywjkbx
 * Smoking Wheels....  was here 2017 syenyfjlbagbvbcmrfoozhofwhqibnqndohpwshxwkudqnsd
 * Smoking Wheels....  was here 2017 ueulgcqnqmcghnqqqrafmqgdylwkarofafywybpqckicbaum
 * Smoking Wheels....  was here 2017 ecjytkyekachvjgaejyhogbiqwvvntrlbyurfuhorandufmx
 * Smoking Wheels....  was here 2017 jmybszrymoyijrwidjqbthpnisnxuzhdiajmmhgqeumviohn
 * Smoking Wheels....  was here 2017 dmwzuymqghpserunmapaxbsurldiixvlbbmbwfqeojsbjvzu
 * Smoking Wheels....  was here 2017 mjsgtsehkrfaqwmrmwswchnlptaxwhbuuwfkrkstysxxxbok
 * Smoking Wheels....  was here 2017 tsfnsxyfvkfeoashstzosulzgpythcawinvrnafdsayscmgf
 * Smoking Wheels....  was here 2017 ljmvalcyqliewdmzytskhtcgzevgxrxnriylglyjptadmpol
 * Smoking Wheels....  was here 2017 hkukhlhghzmmtnbrfenvsohgnyuyclgzcwhiyjbtlppatgfm
 * Smoking Wheels....  was here 2017 kdtrigkellvrsqwptpeoavehtojsqgurdzzlxoxvknikvjga
 * Smoking Wheels....  was here 2017 zddkgpobyouomgrbcwtpplexuaerlanfptixuhdjxreszfwy
 * Smoking Wheels....  was here 2017 pfapigckzhcgyknvbaneanvwbndftcqollwgkvploohoqjpl
 * Smoking Wheels....  was here 2017 zmrmglqazuqekiqtqkctdnbhemmwbyswaskevxkjivdtnney
 * Smoking Wheels....  was here 2017 ggsmunbynnqwgombdpgbazzkdqpobimnviaskixqimjkpsoc
 * Smoking Wheels....  was here 2017 pbwjbdnmpfnfhwwcbladzwyuzxfirgxgpjaashubyrywcfbu
 * Smoking Wheels....  was here 2017 ouhdkejdguyijfspeyudsioffmgpezfyleyrqexrwxaumneh
 * Smoking Wheels....  was here 2017 ymgzktfszlwnvxilonaoyrtskwwxzbzupipigpiuyvbamkox
 * Smoking Wheels....  was here 2017 ulgkxgxhkrllalevlrpduoppmsndwgweoqbzwlmxkktpzxij
 * Smoking Wheels....  was here 2017 ihfdziqdlcdxtpzeigoxqxmkqzxltnxteeqwcvywpvzyhfqo
 * Smoking Wheels....  was here 2017 dvcdzxsvftqbxiucbifabwbxfvxcwdjnkgwmufqseozqvxzr
 * Smoking Wheels....  was here 2017 ydgrmbtcduwgtzvoqfczwtdfxuturqsoompnaeqsbheoired
 * Smoking Wheels....  was here 2017 unffjerawqzctzpsjmbnehwopnwhwusierwzcpilkzftspfo
 * Smoking Wheels....  was here 2017 zovlrypxhalkpevzsadrhhqmlzxtlpjmzwydrriqpwcqgygy
 * Smoking Wheels....  was here 2017 acdkufvgpxyhhnnamvppwyavvivnphwybllkosnkhhxvjewk
 * Smoking Wheels....  was here 2017 rflihdbwdmkezhyusgburpyplbvguktwryenvkbzkbecvbuj
 * Smoking Wheels....  was here 2017 zeiqzbdvpezofzokrwizvxmbewistsusieenvpgybboqnqzm
 * Smoking Wheels....  was here 2017 gqoczrekwrekqjdhxnlestbverablfydvgsoemsbsnzttdss
 * Smoking Wheels....  was here 2017 zifrpwoddzptgmredgrpvhgqvrvqcelaemlerkjkywpcxdnf
 * Smoking Wheels....  was here 2017 ylpqmswvthfygokxmkrscwyoujxadcvorlbclaigsuwlthbj
 * Smoking Wheels....  was here 2017 eehklranjafqddurdoegoegwaltdhtvdvxsgvfyeehmzfskw
 * Smoking Wheels....  was here 2017 yfbuoidmywaroyrxrmgepandouzbodkmkbryjcwxrnkanpuq
 * Smoking Wheels....  was here 2017 uiarepohpuidoaygvifutqldyrpccnwmmcnpycxoyztfdmrv
 * Smoking Wheels....  was here 2017 moljxpxsszckhpxqrkqmxjwxsnsyllrhhsbzrugjuhziuevw
 * Smoking Wheels....  was here 2017 ahxinscuyxlbgfbgmgibdvwsvavjgqoikqhavdfwlmuolpgl
 * Smoking Wheels....  was here 2017 tcehfpfwghvzeqdmtsiltxvekdonncohnzpaafmyhscfibel
 * Smoking Wheels....  was here 2017 dtjfgepksayhzvdahvyxjtkawbxtldwbtcnkclwnykcxwbca
 * Smoking Wheels....  was here 2017 ajtigmyguitgwchucztxvulixgarmfavinvxemnziigmujuq
 * Smoking Wheels....  was here 2017 jgxdazclcqjpjzcymsoegpcjjjicjduaubqnoduvqjecbafy
 * Smoking Wheels....  was here 2017 lapirhdgnshceeiwywksxcrskknfbxchxvfnvqiwftwaxfqw
 * Smoking Wheels....  was here 2017 wkyyohmghlewfsyhgmqslkwclonhutfosedhwhadtxmyuooo
 * Smoking Wheels....  was here 2017 ipffgdsfsayhtwgbmytrqymqdgnzzerznpfrtuxxdolrkssl
 * Smoking Wheels....  was here 2017 wvanpftenyuyferkwtqjrhrokfzdkaezuzmouzltnrlittce
 * Smoking Wheels....  was here 2017 uscssdrmoxesiiztytgsukvlijnwyftgijhepafmhkkgaxzs
 * Smoking Wheels....  was here 2017 qbosxuxpautrbkesnbzyriocjydmxbqrdcdcaibbcgocssue
 * Smoking Wheels....  was here 2017 dyrttizjgwlfqqngozkpcosnejaqsbilosxydmewxvhqmxjz
 * Smoking Wheels....  was here 2017 jsaicdwuzolxnnnmkbgjeqkbqinebzoyccpuhkwkuehbhnqw
 */
package net.yacy.data;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.data.wiki.WikiBoard;
import net.yacy.kelondro.blob.MapHeap;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
public class BlogBoardComments {
private final static int KEY_LENGTH = 64;
private final static String DATE_FORMAT = "yyyyMMddHHmmss";
private final static SimpleDateFormat SIMPLE_DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT, Locale.US);
static {
SIMPLE_DATE_FORMATTER.setTimeZone(TimeZone.getTimeZone("GMT"));
}
private MapHeap database = null;
public BlogBoardComments(final File actpath) throws IOException {
new File(actpath.getParent()).mkdir();
this.database = new MapHeap(actpath, KEY_LENGTH, NaturalOrder.naturalOrder, 1024 * 64, 500, '_');
}
public int size() {
return this.database.size();
}
public synchronized void close() {
this.database.close();
}
static String dateString(final Date date) {
synchronized (SIMPLE_DATE_FORMATTER) {
return SIMPLE_DATE_FORMATTER.format(date);
}
}
private static String normalize(final String key) {
return (key == null) ? "null" : key.trim().toLowerCase();
}
public static String webalize(final String key) {
        if (key == null) {
return "null";
}
String ret = key.trim().toLowerCase();
int p;
while ((p = ret.indexOf(' ',0)) >= 0)
ret = ret.substring(0, p) + "%20" + key.substring(p +1);
return ret;
}
public String guessAuthor(final String ip) {
return WikiBoard.guessAuthor(ip);
}
public CommentEntry newEntry(final String key, final byte[] subject, final byte[] author, final String ip, final Date date, final byte[] page) {
return new CommentEntry(normalize(key), subject, author, ip, date, page);
}
public String write(final CommentEntry page) {
	try {
	    this.database.insert(UTF8.getBytes(page.key), page.record);
	    return page.key;
	} catch (final Exception e) {
	    ConcurrentLog.logException(e);
	    return null;
	}
}
public CommentEntry read(final String key) {
return read(key, this.database);
}
private CommentEntry read(final String key, final MapHeap base) {
String copyOfKey = normalize(key);
copyOfKey = copyOfKey.substring(0, Math.min(copyOfKey.length(), KEY_LENGTH));
Map<String, String> record;
try {
record = base.get(UTF8.getBytes(copyOfKey));
} catch (final IOException e) {
ConcurrentLog.logException(e);
record = null;
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
record = null;
}
return (record == null) ?
newEntry(copyOfKey, new byte[0], UTF8.getBytes("anonymous"), Domains.LOCALHOST, new Date(), new byte[0]) :
new CommentEntry(copyOfKey, record);
}
public boolean importXML(final String input) {
boolean ret = false;
	final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	try {
final DocumentBuilder builder = factory.newDocumentBuilder();
final Document doc = builder.parse(new ByteArrayInputStream(UTF8.getBytes(input)));
ret = parseXMLimport(doc);
}
catch (final ParserConfigurationException e) {}
catch (final SAXException e) {}
catch (final IOException e) {}
	return ret;
}
private boolean parseXMLimport(final Document doc) {
	if(!"blog".equals(doc.getDocumentElement().getTagName())) {
return false;
}
	final NodeList items = doc.getDocumentElement().getElementsByTagName("item");
	if(items.getLength() == 0) {
return false;
}
	for(int i = 0, n = items.getLength(); i < n; ++i) {
String key = null, ip = null, StrSubject = null, StrAuthor = null, StrPage = null, StrDate = null;
Date date = null;
if(!"item".equals(items.item(i).getNodeName()))
continue;
final NodeList currentNodeChildren = items.item(i).getChildNodes();
for(int j=0, m = currentNodeChildren.getLength(); j < m; ++j) {
final Node currentNode = currentNodeChildren.item(j);
if ("id".equals(currentNode.getNodeName())) {
key = currentNode.getFirstChild().getNodeValue();
} else if("ip".equals(currentNode.getNodeName())) {
ip = currentNode.getFirstChild().getNodeValue();
} else if("timestamp".equals(currentNode.getNodeName())) {
StrDate = currentNode.getFirstChild().getNodeValue();
} else if("subject".equals(currentNode.getNodeName())) {
StrSubject = currentNode.getFirstChild().getNodeValue();
} else if("author".equals(currentNode.getNodeName())) {
StrAuthor = currentNode.getFirstChild().getNodeValue();
} else if("content".equals(currentNode.getNodeName())) {
StrPage = currentNode.getFirstChild().getNodeValue();
}
}
try {
date = SIMPLE_DATE_FORMATTER.parse(StrDate);
} catch (final ParseException ex) {
date = new Date();
}
if (key == null || ip == null || StrSubject == null || StrAuthor == null || StrPage == null || date == null)
return false;
byte[] subject,author,page;
subject = UTF8.getBytes(StrSubject);
author = UTF8.getBytes(StrAuthor);
page = UTF8.getBytes(StrPage);
write (newEntry(key, subject, author, ip, date, page));
	}
	return true;
}
public void delete(final String key) {
	try {
this.database.delete(UTF8.getBytes(normalize(key)));
}
catch (final IOException e) { }
}
public Iterator<byte[]> keys(final boolean up) throws IOException {
return this.database.keys(up, false);
}
public static class CommentEntry {
String key;
Map<String, String> record;
public CommentEntry(final String nkey, final byte[] subject, final byte[] author, final String ip, final Date date, final byte[] page) {
this.record = new HashMap<String, String>();
setKey(nkey);
setDate(date);
setSubject(subject);
setAuthor(author);
setIp(ip);
setPage(page);
WikiBoard.setAuthor(ip, UTF8.String(author));
}
CommentEntry(final String key, final Map<String, String> record) {
this.key = key;
this.record = record;
if (this.record.get("comments") == null) {
this.record.put("comments", ListManager.collection2string(new ArrayList<String>()));
}
}
public String getKey() {
return this.key;
}
private void setKey(final String var) {
this.key = var.substring(0, Math.min(var.length(), KEY_LENGTH));
}
private void setSubject(final byte[] subject) {
if (subject == null)
this.record.put("subject","");
else
this.record.put("subject", Base64Order.enhancedCoder.encode(subject));
}
public byte[] getSubject() {
final String subject = this.record.get("subject");
if (subject == null) return new byte[0];
final byte[] subject_bytes = Base64Order.enhancedCoder.decode(subject);
if (subject_bytes == null) return new byte[0];
return subject_bytes;
}
private void setDate(Date date) {
if(date == null)
date = new Date();
this.record.put("date", dateString(date));
}
public Date getDate() {
try {
final String date = this.record.get("date");
if (date == null) {
if (ConcurrentLog.isFinest("Blog")) ConcurrentLog.finest("Blog", "ERROR: date field missing in blogBoard");
return new Date();
}
synchronized (SIMPLE_DATE_FORMATTER) {
return SIMPLE_DATE_FORMATTER.parse(date);
}
} catch (final ParseException e) {
return new Date();
}
}
public String getTimestamp() {
final String timestamp = this.record.get("date");
if (timestamp == null) {
if (ConcurrentLog.isFinest("Blog")) ConcurrentLog.finest("Blog", "ERROR: date field missing in blogBoard");
return dateString(new Date());
}
return timestamp;
}
private void setAuthor(final byte[] author) {
if (author == null)
this.record.put("author","");
else
this.record.put("author", Base64Order.enhancedCoder.encode(author));
}
public byte[] getAuthor() {
final String author = this.record.get("author");
if (author == null)
return new byte[0];
final byte[] author_byte = Base64Order.enhancedCoder.decode(author);
if (author_byte == null)
return new byte[0];
return author_byte;
}
private void setIp(String ip) {
if ((ip == null) || (ip.isEmpty()))
ip = "";
this.record.put("ip", ip);
}
public String getIp() {
final String ip = this.record.get("ip");
if (ip == null)
return Domains.LOCALHOST;
return ip;
}
private void setPage(final byte[] page) {
if (page == null)
this.record.put("page", "");
else
this.record.put("page", Base64Order.enhancedCoder.encode(page));
}
public byte[] getPage() {
final String page = this.record.get("page");
if (page == null)
return new byte[0];
final byte[] page_byte = Base64Order.enhancedCoder.decode(page);
if (page_byte == null)
return new byte[0];
return page_byte;
}
/**
* Is the comment allowed?
* this is possible for moderated blog entry only and means
* the administrator has explicit allowed the comment.
* @return
*/
public boolean isAllowed() {
return "true".equals(this.record.get("moderated"));
}
public void allow() {
this.record.put("moderated", "true");
}
}
}
