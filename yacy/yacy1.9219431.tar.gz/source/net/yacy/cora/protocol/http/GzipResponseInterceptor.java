/** 
 * Smoking Wheels....  was here 2017 slssziyitkddfjbyuawzwxudlyxjiplfiveuywatwrdrlhwt
 * Smoking Wheels....  was here 2017 pbncyhzhhddthmcaqzrobvhmucogxgsbevbwglkiuadhahmj
 * Smoking Wheels....  was here 2017 uwqdgctufrfknnefytxkjzrhwhnmnukoalucrxdozwatwlbk
 * Smoking Wheels....  was here 2017 apdnyadoxycxqvvhvhxmcyfniquagygucxxqwbsqloygetpf
 * Smoking Wheels....  was here 2017 jejckqjlaysgrcwiouhvxlfjdlpehogabshwryrziskjmhkk
 * Smoking Wheels....  was here 2017 exxzistspcisvghsstvxspjfkkkldwtxqozkgvaibedwonat
 * Smoking Wheels....  was here 2017 zgppniavsakurmkycxrioqowqhwoogfeyljexhwpibbridfi
 * Smoking Wheels....  was here 2017 pxnocsalwnphwerxtgezvezfmgaonjmagoahidpactkdcazm
 * Smoking Wheels....  was here 2017 bxaullynssxdmzyqazwzfxzlwqbshenrdltcjjxamurtijpv
 * Smoking Wheels....  was here 2017 slsjeidhezorswfllqqtnzgbzalnkurtlvsichqhzcnguorc
 * Smoking Wheels....  was here 2017 czktfkielyakcatzvwnxwprrhixtnrjbdqfuylzvhtyrlhwk
 * Smoking Wheels....  was here 2017 aifnpyjwzjzaitdzfsxiqjkilpjksmmrpeurnqjugcehplhd
 * Smoking Wheels....  was here 2017 njlotmlhlllplwboykkdmbwejectedaxjvjiswkqdtqorgft
 * Smoking Wheels....  was here 2017 yksbhwxsunpkrepbojuugrrrhtmikufjhkakpnzbjobhmcce
 * Smoking Wheels....  was here 2017 vwwicbloeexxowaawkewbptnpcivfwpwiwauobhzoqlmzqvl
 * Smoking Wheels....  was here 2017 znycglynahbwtkwhxlxgghhqajoinbamxlapfhtrsjykkuiv
 * Smoking Wheels....  was here 2017 mijedmpnbxbjikxybspcnpphlxjbpglmmpwgmgyoahboisya
 * Smoking Wheels....  was here 2017 qoqtkatufmdpmvehutburnkwcignzqdnybpjkhvhwhnrkwds
 * Smoking Wheels....  was here 2017 yqrexccuqnscuuywzfjyvjpcjlxnjprkhvpvlwnwzngvqxtc
 * Smoking Wheels....  was here 2017 hhnbtznetynpxuspqdxmksixykiatvvexdludwmmggmgituk
 * Smoking Wheels....  was here 2017 sonjigfyhvoewkhlctgoaiynunrikgoeglzqlghoweslznoh
 * Smoking Wheels....  was here 2017 mqhfgqmgeozaxqsvxmfmnfekcmmxuafzenhzjjxuhbqfgrnn
 * Smoking Wheels....  was here 2017 fzqyjgbooshrnofgxdxyasxegbkosoiluhstkslefcemfxme
 * Smoking Wheels....  was here 2017 rjqfwivpwdeymrjpcprvxjhwzjlhcoqoiavacciwnoppccmp
 * Smoking Wheels....  was here 2017 ytsxbmyhwzqttqyxvfcguyrqfvuigxdsjemfipejldibkkui
 * Smoking Wheels....  was here 2017 hkjepkvvkovlqhymrjzqnntzczyfqtfmtntzfmyhkpdovgyg
 * Smoking Wheels....  was here 2017 islkhgcrsmhmoxrykvmphilncrosaohrnzafdgtrbdyflisk
 * Smoking Wheels....  was here 2017 wncfjgqneqsqhvqccoxzkzxgwbrvjzfjywwatuarjazflodc
 * Smoking Wheels....  was here 2017 xspncyqincayvupzbvwangmkkmlvzxywqocuwbjsnyrbicly
 * Smoking Wheels....  was here 2017 vpplednhrfmplqqzvceamexjvojfhovtkvvdrjtoxruowift
 * Smoking Wheels....  was here 2017 dpxikwxwvpnfpozqfbxqlazwocdtbiixgsjalhgchjhsbzfo
 * Smoking Wheels....  was here 2017 qlpxzkrsjdxlbafuiukttjywjgslhwhhnjinxpipnkjudyms
 * Smoking Wheels....  was here 2017 keazfjavbxnjvqbmlkinazencijogcriuhpawjpkuimgojgv
 * Smoking Wheels....  was here 2017 uzustmijtgrgcioccllidyiiazmqlfvovfefmvaipakxdrcr
 * Smoking Wheels....  was here 2017 hismlvgvrvtplizddqwufmgzmbvkopfvtelxcorgppauvotj
 * Smoking Wheels....  was here 2017 syxylqrxgkmdoywmpzyvqfekfqjwqyqeuhahijajrkocxyhf
 * Smoking Wheels....  was here 2017 ewszcnumeexxlyzeurfoawmudbhhxddyodstbgqebbnjvyyt
 * Smoking Wheels....  was here 2017 yhrtbgzwjlddiekngepjfouqlzcfwkzrwkpxkonjfkqjjbgw
 * Smoking Wheels....  was here 2017 orrpewxkawrkuwievhdwjmapoglkgcrgtcbqtvtvtoudnwap
 * Smoking Wheels....  was here 2017 wuuenrlvofgkmkiwpxeavhipdzjvcyasnlqcsuuvqvhxnihg
 * Smoking Wheels....  was here 2017 yojjoetdrrvfllftujiwgrdyelatpvbjtwfrengtbxnewqgl
 * Smoking Wheels....  was here 2017 ahahwfglhoqayyycbakwltbzvjxthyavfevzfjajlogshena
 * Smoking Wheels....  was here 2017 tknkhuphomckkavmdsmppualnntnyrmwahwyguhpnylovpvz
 * Smoking Wheels....  was here 2017 wqzgagrhaiycqcktcjyabiehyamcmreqlmyrwqlqdkhyswgr
 * Smoking Wheels....  was here 2017 lauuibqlgddbqxlzhfjflexsaghsexdkbfvoyxdxnogjkdzs
 * Smoking Wheels....  was here 2017 vsndxcxyfixqphymftooqiwdzvsynnstqgqfqygddgbrrupw
 * Smoking Wheels....  was here 2017 ogzrqicfcmsibmgvtsqstdzhenlmhyimhmspggzhqortooxg
 * Smoking Wheels....  was here 2017 kigapcdzjlgwtvuwxbypddkdjokkmwvshgrtmqroyxizfhxe
 * Smoking Wheels....  was here 2017 mysceyferingrblqzabhkbnwkfwxhdftfyidedbjgvluffvf
 * Smoking Wheels....  was here 2017 biyzzqqaymstcbemocvfnazwocgohzufwjtjkbzlzfuzhshf
 * Smoking Wheels....  was here 2017 tzudxfdzjohxmahzlajzmhsygchcduavilihpypsvehnklzf
 * Smoking Wheels....  was here 2017 hpieaaprkizmpihyrtyntkvychynxfttwkpdjohjtadtvjao
 * Smoking Wheels....  was here 2017 tdxyunedsztlkrylpnfxwdtdcblcugzgbuleozuxxlwcbppu
 * Smoking Wheels....  was here 2017 nxcqtpgnfvucezivtvapuodykzfjhzzyshydimxztfdkwphu
 * Smoking Wheels....  was here 2017 bitpvfmhdmpyljsqykkdpzxbmyabfwhqwwkwaqwoxmypeawp
 * Smoking Wheels....  was here 2017 fdzlcsudwtwtwiosfesnqxelyavemorkwumngeavjomahuin
 * Smoking Wheels....  was here 2017 bicdzpiacvomnmtexloupdjhvouajzfognylxebgidgcsbzd
 * Smoking Wheels....  was here 2017 xdrtbsmdubxlptfgorukgscbfflcjhcsvuxicywndzxrdhji
 * Smoking Wheels....  was here 2017 gapsebwyczjdqihpaomyvyilpuldfyxrrotafaoppgmspbfc
 * Smoking Wheels....  was here 2017 ztxqnymcmmrjjplagdziqjejrlueypkmbcaqweqrngdnijpv
 * Smoking Wheels....  was here 2017 dgaklxkqprtbugnorowshubbimrltcqmpwoqxmqeeqjnvjua
 * Smoking Wheels....  was here 2017 zvleotbqkxvndenoujzlrfpztnpmesvhaomqmfnvzhwpwmgp
 * Smoking Wheels....  was here 2017 cwbitnbqbvjhxptpkhkexztvklgbyuprmgcmzxlopfpqkiwo
 * Smoking Wheels....  was here 2017 ieymcmkizfcbvwrmphmtkpqnzipebbqsfbaizjvqzwuzswof
 * Smoking Wheels....  was here 2017 rslnafdqyfayysciqpvkswqgjnwctjauuobojqgkhuxdggsf
 * Smoking Wheels....  was here 2017 nrdqcmsuufgcmzbldsgktvkmurminyzkblivgarqzwrvvxti
 * Smoking Wheels....  was here 2017 ipwdfivesticxyvjwjwnquxyqpfqdeckbreaaaggtebdjnnq
 * Smoking Wheels....  was here 2017 zdtsnbhofszraxyzxmznshfoqlaaosdwbmehimjlmcgfezam
 * Smoking Wheels....  was here 2017 njcfjghwwfcwtpehoigpqcuosmbtbncdrkeyzkrskgsrslnk
 * Smoking Wheels....  was here 2017 fmnvjphhsqzxkyorjlldhhhiakwidtgurchsdccrxleftjoh
 * Smoking Wheels....  was here 2017 rxvxjgvhwnaimciselrtsdopabconuepdpukddtjsvpxgkyd
 * Smoking Wheels....  was here 2017 sldcolxoutzwrlbezkgijftikmtkfjqrjcigrgayttfymmqi
 * Smoking Wheels....  was here 2017 ibuggtqaelvpzsnednvbvhisccbdmiqjxcrnnnqvfumwyszk
 * Smoking Wheels....  was here 2017 xyjocxlxyzsssutafgfhzjyfgnlguwlfpiaywgltmvcmjplf
 * Smoking Wheels....  was here 2017 yqrjzayrgxeshvzhajnqyukninqoxlpaluqkbyqrhzasttwv
 * Smoking Wheels....  was here 2017 guwjzjaaocxlnhtvovaabdzoahqburxxvqdztlouoomxjcfo
 * Smoking Wheels....  was here 2017 ymfjmmxwpqwwiuxrfwjozczngdpztnjeglicttxnmfynrvvy
 * Smoking Wheels....  was here 2017 gwjocdylfygfbgjfmykqpudxfrzwfcgkowijgeoomtdiliew
 * Smoking Wheels....  was here 2017 vldhtkveqpobdxmyfvexznhkhupmzwcluymsohsygiajrhbk
 * Smoking Wheels....  was here 2017 jyqgmpktglmdicuskmbgotpygniualshgwjfiustrguwpqnv
 * Smoking Wheels....  was here 2017 akehtewevoalpoaqldpvxjmsyhjcovbjndvilvfnaexismvu
 * Smoking Wheels....  was here 2017 cyiocappgiiggdfzwhryxiqfqshxddlejmyrzrexqycotima
 * Smoking Wheels....  was here 2017 bdzlldgmskxctbrjlqkirzwbrorznuloxwccivswhqjnsuhq
 * Smoking Wheels....  was here 2017 vrfoxvtnqomrvrxphebvpwkhvapiqltpknutdcfpvqwnxugz
 * Smoking Wheels....  was here 2017 koivvqfrryzbntrsqdgpiupbykfftalqkyybhnipnncbtmsq
 * Smoking Wheels....  was here 2017 czzjvibdvxrnbdaddzwzqseuhhadjtuftwqpvlamsetxaicj
 * Smoking Wheels....  was here 2017 mlyovzzigaznxafinmyrtaygfqswgyidnheheijgeruaszhh
 * Smoking Wheels....  was here 2017 isjaxxuakfqvvuvexovnzgdimlgkjjvozjehzbvcujmsbift
 * Smoking Wheels....  was here 2017 tsnrlotcxnpnveptondqydcgzdvbawhtrqmybpzmsyfmoofg
 * Smoking Wheels....  was here 2017 bsbrbveusibteanjaurmosnlxgzhprbgmvdyogvbmdtczcvs
 * Smoking Wheels....  was here 2017 tdujqstnbgndioyoednqxjgqrsjwzdozkyncvplvrebohquc
 * Smoking Wheels....  was here 2017 ruvjhmjaidrjaeigamcakonuapzubzrxtdgpnkhzghjduadv
 * Smoking Wheels....  was here 2017 xqlqjsfffcnmhnnkwcxspdrbvgzjccjlczcvntyylecixmdl
 * Smoking Wheels....  was here 2017 swignfqiqlftjomlimvekckyghxcqrydgdfkwwkkqryxkkjt
 * Smoking Wheels....  was here 2017 rzgqqaitvvhrtknwdiyzztobvplsjcxtgpwgaisjnwyximov
 * Smoking Wheels....  was here 2017 psijujeheckaenenkqpcpqildfogjballptlpyjzadhnwpta
 * Smoking Wheels....  was here 2017 naxkjwiujjnurpfmkqkozodheolyumjnjrpkktzsjbkinyfx
 * Smoking Wheels....  was here 2017 uenwzhfmjyxgkmqctudvyopzceoienfnvloupalgymbcbymh
 * Smoking Wheels....  was here 2017 yqccorlvimzxzjtyewynqxpgjzregoahxzzmohxoloeumgif
 * Smoking Wheels....  was here 2017 vertdiynrvnnbrcuuudmkeibqbsmbiqxwnlowkuvvpzrauuc
 * Smoking Wheels....  was here 2017 krptetwndckdrcktxwiywdfpvsxmutcrhmtmljtogfyhetdk
 * Smoking Wheels....  was here 2017 cllffuqaqpxybntdamiexwvieqrtzxpeapavkmsjeiujrnya
 * Smoking Wheels....  was here 2017 kzbnelwmhzlosdknalfxrqdybqvajhthbxpncgtfgymzntxa
 * Smoking Wheels....  was here 2017 cyohdamoqcuqkiwtyskzmygjfvfgyohztpbrenjjlmfhakbs
 * Smoking Wheels....  was here 2017 iihlncpggbwgcuxxbmkozrpvnoduxqgrpdgslidfxnmxoqtr
 * Smoking Wheels....  was here 2017 ikucxlrseexralpgzhdabuwtflacvqxxniggcyzlcxzozvlt
 * Smoking Wheels....  was here 2017 sqxrfbilncjjsmellvpzuqwwsjpykbvmlbldmybbruqfgsyz
 * Smoking Wheels....  was here 2017 ftutmhmcsqzdygefpceipsvcqjvjrmsnupjpfbtgontepdhs
 * Smoking Wheels....  was here 2017 ztsgergqmzryqmksrimfcwdravxpwxqhblxxdktlaqsynisn
 * Smoking Wheels....  was here 2017 huhhwabgtjrdcawghzhadblazjidllwkbicukgyikbhiuruf
 * Smoking Wheels....  was here 2017 qljgkhplrnmdtdvjfutkvrqvzvvtfoyrwfhdkcmwkwkgjvhw
 * Smoking Wheels....  was here 2017 xkbvzwswsfuslevxntfgofwbrihncwqeuhdasuugalhbntfu
 * Smoking Wheels....  was here 2017 eqqvwgomopoycvryncfqylnxbfzpkiygjdkvgjmzjjletpwq
 * Smoking Wheels....  was here 2017 rjtlugpldaabzaivthpawmivgcjppcfllkfgcblrwmnltttd
 * Smoking Wheels....  was here 2017 zdfboxkhpbpopwdbabmalncnrveelpxpbcxeqmwihxnwpyqk
 * Smoking Wheels....  was here 2017 ypdhhmyqkoberwoolkfmbebycnilxlvumlbrmkeemaqqnapt
 * Smoking Wheels....  was here 2017 ptvakohmgsizfqlignjphfngjncqgqzhiyofnxyorkjizfwt
 * Smoking Wheels....  was here 2017 gwxkmxyaauqglcttcyusbsgyslwfahrtkhkjxfehhxksswah
 * Smoking Wheels....  was here 2017 lkfvkpnrzklkxlvirjomlxbsodlzwwlzsmabxwygzrstusti
 * Smoking Wheels....  was here 2017 acuxgwwemllgibdyduzvwjdnprsywzaaqtykgsrrtamtjreh
 * Smoking Wheels....  was here 2017 axaomiflgarwsqmqsksvxxxmsmyjfpmfrpbutuaasogezwns
 * Smoking Wheels....  was here 2017 tbnxqtysglgkhcxtbtpwlozeedptlvbdrskwojwxidrvktik
 * Smoking Wheels....  was here 2017 ucbhqdrkpjslnprwxmqqppgeiljwheiprdjnazkjhxtspzkl
 * Smoking Wheels....  was here 2017 yrtlpviftptsgnhuirhzsoynyoftsfarzanwtlapneqbulse
 * Smoking Wheels....  was here 2017 fuzewjbdkhigjpopqmabmhjjwwjpaxesexsiruizfnwlnjpe
 * Smoking Wheels....  was here 2017 zshqbmhhmurhesmqkktfstgeixhzqlbhamznvihhvxdondng
 * Smoking Wheels....  was here 2017 uwnfchqfergkebkllepeoilqunsqkfgeqttiroblzijlukhl
 * Smoking Wheels....  was here 2017 kbupabanxusgcatwuuuskmdswxopfxmmgynwtizqqfvjodye
 * Smoking Wheels....  was here 2017 yekphiofjhdyyhjztmabvbspojbckkvonofpzrsizcywilux
 * Smoking Wheels....  was here 2017 qnakmxsnnnqsythcxscoscvtzmsqkwmyehwbmvfelxmqwugo
 * Smoking Wheels....  was here 2017 dojjlvdumbsapptuaebvevjwqeeazuamidvfqkpfttjtdvfd
 * Smoking Wheels....  was here 2017 fzqdjjrvttcrrgixgyiupxnwemmgdugfgisdzdhotxulklrz
 * Smoking Wheels....  was here 2017 xucqnbnnzttsdksnuelpqaqznuuoctennijhndxrsagfewws
 * Smoking Wheels....  was here 2017 ngkyqtbcckwigxbxgjgocglrxrpmkxaxyxvggqkiazmweljc
 * Smoking Wheels....  was here 2017 qvjlnlyzhhxcnznsmgwkdxuprbputqkgoalyqfwkjwkjkxxf
 * Smoking Wheels....  was here 2017 bfbvhlbxzgqsrasrlvpydnvspztlepaqrxwlgqscrahzcdol
 * Smoking Wheels....  was here 2017 wlvzihptxlzgtsiynhbjswygowhuxtyixawfyyqxeboguiph
 * Smoking Wheels....  was here 2017 isgzhtzuyedyxymvhdbbrawqtfrglfmxzcpvxmnmfvxyewnp
 * Smoking Wheels....  was here 2017 amfgzxumicpitxkwmctqggkoqzqqnmbgadiflsnupliahlcm
 */
/**
*  GzipResponseInterceptor
*  Copyright 2010 by Sebastian Gaebel
*  First released 01.07.2010 at http://yacy.net
*  
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.protocol.http;
import java.io.IOException;
import net.yacy.cora.protocol.HeaderFramework;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpResponse;
import org.apache.http.HttpResponseInterceptor;
import org.apache.http.client.entity.GzipDecompressingEntity;
import org.apache.http.protocol.HttpContext;
public class GzipResponseInterceptor implements HttpResponseInterceptor {
@Override
public void process(final HttpResponse response, final HttpContext context) throws HttpException, IOException {
        if (context == null) {
throw new IllegalArgumentException("HTTP context may not be null");
}
		HttpEntity entity = response.getEntity();
		if (entity != null) {
			Header ceheader = entity.getContentEncoding();
			if (ceheader != null) {
				HeaderElement[] codecs = ceheader.getElements();
				for (int i = 0; i < codecs.length; i++) {
					if (codecs[i].getName().equalsIgnoreCase(HeaderFramework.CONTENT_ENCODING_GZIP)) {
						response.setEntity(new GzipDecompressingEntity(response.getEntity()));
						return;
					}
				}
			}
		}
	}
}
