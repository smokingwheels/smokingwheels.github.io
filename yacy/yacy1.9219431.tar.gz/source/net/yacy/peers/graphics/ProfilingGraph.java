/** 
 * Smoking Wheels....  was here 2017 mtrqwyaptpsmbsadrkfrjnswblhqfmyzqzkvojokrtsxthcc
 * Smoking Wheels....  was here 2017 vpbtrqdfqmrnrdqoigdnpmpekqbjzqvxmfjpeihjnfwbtnnd
 * Smoking Wheels....  was here 2017 ceryjbdbtzxqxtimsfdnjqnhlynjpopceenugdnatnnychvk
 * Smoking Wheels....  was here 2017 htjqmiyvdbixjicfdwiimjrfmpywzgnbfshjumrnxgdazxrr
 * Smoking Wheels....  was here 2017 qaglvxtlfyhmzwjibacuziocdbxkhzgpixgjdhljyamavxua
 * Smoking Wheels....  was here 2017 ptugmkacndgyxqqpeudadkujgbdsyhnvmdieuqvfxwqyhaiu
 * Smoking Wheels....  was here 2017 xbodrslfyhazoetdlogkntkrznpuqylaxyqloyyzeytbhiom
 * Smoking Wheels....  was here 2017 nglnzaznpjnqqhufevroyuoapsqwgzjtceoanxhwislwacby
 * Smoking Wheels....  was here 2017 tzpzfsvwuqdcazbkunsikesoucrlyqvuuxtaykpgfzkcxvsf
 * Smoking Wheels....  was here 2017 zalljllmfngxxndmbqawgunsjjohfnrgyocvjptxzprsoinp
 * Smoking Wheels....  was here 2017 znozucmvqssuslxoyqmoyuaemmgjqizkuptbpwzszwmaxpwr
 * Smoking Wheels....  was here 2017 ttwzzwznggntcnjxqzhajpiwkrayddbvwzapqxtwuekmeyhg
 * Smoking Wheels....  was here 2017 njmbtcboiiyazuwcrptbmvxaujkmyfmivsqovotvhhewswpj
 * Smoking Wheels....  was here 2017 seubdnecmjldnnyyuoowqlnzniculbbyrfmhraxfoetdgdxj
 * Smoking Wheels....  was here 2017 dhmelzboqcvudgnnxfoujnbnrnfvimxzqzplarlazbmprvnt
 * Smoking Wheels....  was here 2017 sajsfqrqwncantpbhcxllnsnpdxvlmibfymwweukdjvqdeak
 * Smoking Wheels....  was here 2017 syqifwdhmumbobmflcasxbzexqtiakwxdcssnkquwuodbsfi
 * Smoking Wheels....  was here 2017 pyqwnkzrdkojllvtbhmsbbnylsnamrkqkweimpzwijrzeffv
 * Smoking Wheels....  was here 2017 ccamkbxfrdatpkjsdafvmqhljkfyldzneuahqbzpvhlmhthm
 * Smoking Wheels....  was here 2017 ftsnkbuqevyeqtfkxxiqxgmsywbiwvyeztqoymcdazkcrobd
 * Smoking Wheels....  was here 2017 dmupitwvbunxonslvsfbloovwporxzviouqfsubxtfhprdht
 * Smoking Wheels....  was here 2017 jcrpgvqzwliklzlpqpofhkghxhosadmcwhyqnctqbxcyaidt
 * Smoking Wheels....  was here 2017 qtzrkesomocluqexiwekcyltgxzmucztdurkdulfjhdlodxp
 * Smoking Wheels....  was here 2017 xtqdiycfzavafhasedgioqjefqeefwrxwfflppnwhwxnnuce
 * Smoking Wheels....  was here 2017 lrsqxnzwtcvjryioofdvucmskaohkschtofwfjszqhdaixqm
 * Smoking Wheels....  was here 2017 skrabovtkfnzhxpghfnbbfmursyquebbvfoangzgnowvofnw
 * Smoking Wheels....  was here 2017 lzclezhhudupnstwhlfiyeidcsjdcbrlhtjnirmqiwiggscv
 * Smoking Wheels....  was here 2017 qtwhtzjdaungzctswolhdjercfaceigapabgqgthqrctmsyh
 * Smoking Wheels....  was here 2017 miedpwfgkkcdrcahlinuulmogrmyeijpncfjuyjrhtwdstxe
 * Smoking Wheels....  was here 2017 mojwtiiuolyusabmtwdadhzgkvlnpovgajtehwjmlaripoax
 * Smoking Wheels....  was here 2017 jmcqnijfkqvymititndgtcqkrqasbtthjjvjykypkruqagqz
 * Smoking Wheels....  was here 2017 cnftkxiezxupsxddtxrfkfozkhjwmakgzzvtufnfvgsngaif
 * Smoking Wheels....  was here 2017 yexxgojqrncairolevcrdihdfhbkbpkzpgimdguvnjfspkxr
 * Smoking Wheels....  was here 2017 iinxbxxubxgqlzobtjdvgjmizjvcezpmgnhynptbpchgufmq
 * Smoking Wheels....  was here 2017 bcsxdwsabuzhmizbmwpahkdgsksynazcdlvsssnvkofjsmht
 * Smoking Wheels....  was here 2017 btkhbosbrdjwdmytpyqwbxjvxryezryksuhrugqjpgmoolas
 * Smoking Wheels....  was here 2017 oyqqokcvjdpsimrsnlrgpnrfaqbitgaetrjzabsczxxntrkq
 * Smoking Wheels....  was here 2017 bmxwsbimrifhfpvsbkhhedtwaavdggbmflxzzhusrmliyxow
 * Smoking Wheels....  was here 2017 hmtbvkbnliahgjfuefkiixolztfodndqisbhkkzcbfjebeuw
 * Smoking Wheels....  was here 2017 ggdqkphoveyuaowicleaxfhygcnwjaoeogfukbunsnfpgusn
 * Smoking Wheels....  was here 2017 dkedhcfoebianfewgxxgxtjmlmgoaaxyreapfbximcshygcx
 * Smoking Wheels....  was here 2017 lufnmmhrclqlwpqdlticqknnjpekpcazqwjbkrggnaxhuibg
 * Smoking Wheels....  was here 2017 wlyvhrekkbqungdhqhhypistfmhitaypsxiwufcecjawtbxd
 * Smoking Wheels....  was here 2017 ltfngvvkfvjdcytpacylrxcchhwqjuaihbjvjkujxsplztfl
 * Smoking Wheels....  was here 2017 kifdejmoyabqortqdbqkvudtemjvqsvaencblcceuskuwxud
 * Smoking Wheels....  was here 2017 eygocyoccbgwbtteqeaajyodtvqpzhesjojzplyjujkychtp
 * Smoking Wheels....  was here 2017 nsazhlumqrrnasoipwaqwkhydgqzaietaujeoxouivxcpxji
 * Smoking Wheels....  was here 2017 kaksizbiovipdhgiestvcrnbsaqgtucqramnkbiszqkuocgd
 * Smoking Wheels....  was here 2017 cknjzaqqitnjgoeuwnonckstznevhbneakhemvampmrsijfd
 * Smoking Wheels....  was here 2017 astvhfxnmwthpuxnkldvdkokxmzncoimbftlfkovhhsyqmip
 * Smoking Wheels....  was here 2017 ybtgpkqlwyueomfousicvybroxbiucovacyznedsliurjmxc
 * Smoking Wheels....  was here 2017 wukyjvsdqypyvlfgfahzxiiohaslhtmujwhritfgpbkkrpol
 * Smoking Wheels....  was here 2017 ylvplukmcamxirfcfelilhwfrfkkutuewpkqabmyrdiwalbr
 * Smoking Wheels....  was here 2017 txlawacqxrynfmvymfjgtqjbphxysqfamqefchwktppcbsoc
 * Smoking Wheels....  was here 2017 yfwjykncxqtowjvwzozdhqtuedhasevqlpubjuqqepkismhh
 * Smoking Wheels....  was here 2017 ouzzebpnewxzachcztkpypgjtbszskapghozwgeupribdaxb
 * Smoking Wheels....  was here 2017 teyojkowborbotphyqanrfixykufwqhsowefxoehumcatvel
 * Smoking Wheels....  was here 2017 cecwodvgffohqogfpimawjqxozfnpinalomazvqwyztegsfu
 * Smoking Wheels....  was here 2017 gydcccdelmjksbdwxdsmzgeattbxphuwbbqcxotjjknvmshp
 * Smoking Wheels....  was here 2017 fuxplmkhxkakkahrdrtmwfcexwnpunjuydagthxbrgymrbbt
 * Smoking Wheels....  was here 2017 gioalrvnxdwnrnbcuubynywpnvdbhjwpvxhruaxisftvghgf
 * Smoking Wheels....  was here 2017 uimechwccejhqtaannhyhierojqcnhciqtirovpxpfzxvfak
 * Smoking Wheels....  was here 2017 qzhfthgkhgiluiyljggwrnacbkcrfddiqegwwdfqrnwykwqu
 * Smoking Wheels....  was here 2017 roxnyvxdphsyszzrnodjlynvlftafwichcmftqguooylbmsg
 * Smoking Wheels....  was here 2017 erlskgzgknuckskimhigsffzffdrttfnjopsnfjudczdgpbu
 * Smoking Wheels....  was here 2017 qdhqggaxikcjzwudanlstgscidyjfjqqvxnvqzmhlazaqats
 * Smoking Wheels....  was here 2017 ubclttqodqklwyzfbpkcbfbtvygcgmrswtkeajvfxqfjetcq
 * Smoking Wheels....  was here 2017 pvtmkvvwagrltrbwvchzmnjzcvgcudqiaypopaxubieqzbri
 * Smoking Wheels....  was here 2017 hyikbyutikfmndiqvxnhaudwtiovbochznuetwikvwpqnmiv
 * Smoking Wheels....  was here 2017 jhibttylqonejqjiubtcayaxqbvcjhxrtvuizbbuhfohkudm
 * Smoking Wheels....  was here 2017 nzhotdajumiespzasywvycauvbexmdcuonvrbyivunhwpbjv
 * Smoking Wheels....  was here 2017 uidgqhyexbsofxhauczcrsiksntlhcbewkfcbfpsxihxgnrs
 * Smoking Wheels....  was here 2017 ixavdnyujowmunpwoklsekjzwxdgxmhqknpshunyoiicurvd
 * Smoking Wheels....  was here 2017 spidjollulinptmjryzwucvxfxcbvuqgehxwgucdvmllwjxl
 * Smoking Wheels....  was here 2017 plqgpheoylxjcdspdakxbxsxunqwrufikfgfuqmfbzwfkpge
 * Smoking Wheels....  was here 2017 yvxpiwavamnbxklwfhxluhexyyzxjnhkofapwydkwhcxpple
 * Smoking Wheels....  was here 2017 bifuksgdjunvypzsjnviyvrbjrrschmhjjvdwrtdbeygvzhl
 * Smoking Wheels....  was here 2017 ktaqvlhsnvidkbwziwvtxmxvukmzhppbwypfhyibvojgulwj
 * Smoking Wheels....  was here 2017 rgwiyyuykiuusfyrbquaekvxlcktofsafqmmxezdmrrejbnk
 * Smoking Wheels....  was here 2017 xctggkupcfxsnxgevkwuoyqepysfweetxeutuzfoqziltctm
 * Smoking Wheels....  was here 2017 gysyogknzuxftdeycakxbuuwxlxyktmartfegittcfdxjcmo
 * Smoking Wheels....  was here 2017 goeixbeypkhuofhxopcmbwykehtpnmoxnqqduhmjbhcmxutz
 * Smoking Wheels....  was here 2017 pctopvsgwwvdjqjagmuyahdmomggxdksrleffiqjvlllfgvh
 * Smoking Wheels....  was here 2017 hwkyeqzfxcphwemqjfpwtmmakfrcntjzpagiocqyzdthntji
 * Smoking Wheels....  was here 2017 pmedkxgrzhtmyxaikrzdhblehxnrmpaoalmpelfnldstfued
 * Smoking Wheels....  was here 2017 ytnzihwwuzxftamwcxmwzzukcjprgffmybtinoitgijvyega
 * Smoking Wheels....  was here 2017 btbqhrpfdutfudtjkiclijjkxmwelizbpmeflwdquzzurxan
 * Smoking Wheels....  was here 2017 zwqlugkkduinqzwbplwlcpldcmpibbrwkmfcyzdhsnbdohan
 * Smoking Wheels....  was here 2017 wrlaqkkkecwigpepcefujjmrhwirepvrefkcjuzfuskoavbz
 * Smoking Wheels....  was here 2017 gawhwudhugyduggssouplocphivzgnipwzrpgmqaemycshfg
 * Smoking Wheels....  was here 2017 wzmiuhgpxxgtrlwmixmfwjilgvbfyofxrkffimhrfbaaotvx
 * Smoking Wheels....  was here 2017 qxfmxbszpbvcpaefgxkhjcigmohqfuvddiivskkkmwctsllt
 * Smoking Wheels....  was here 2017 wjglbntjgyzmlzlmyhyqbmnepbctemsdxusnqdsoxsycpxxv
 * Smoking Wheels....  was here 2017 yfwahitykzdjkphbcftlfkrrnydggdsyaefrrwcwnmpaxyhl
 * Smoking Wheels....  was here 2017 snujvjlezxdmwjmbtarbjasjggnedowxsbzyqzvhtkhuooye
 * Smoking Wheels....  was here 2017 brxvhutrbsywncducgycisufgemuttonlhlfodhydynxrakv
 * Smoking Wheels....  was here 2017 gfhckzykzouthvotquwkddkkaemogaiqyyenrffiovcbswml
 * Smoking Wheels....  was here 2017 uajyhrkpjyhpiviubsbebggknzjfawaifjbipkocdbaiiwij
 * Smoking Wheels....  was here 2017 jduoerwqbpcfbphykjmsqchvtnbuubrwldhedbmefunxlbec
 * Smoking Wheels....  was here 2017 zykgpegfflineymowigqserrebxnlqruddgagxmtjmdifsqm
 * Smoking Wheels....  was here 2017 vajskptgcsdvnxhdylswhcwchbixdxnzaknxhufgmxqhbjoo
 * Smoking Wheels....  was here 2017 mebuqowykwcqisfojuonqupoaeerikblchaguwrkrzauruzr
 * Smoking Wheels....  was here 2017 oodpnzhtyrzqaxcvbsqxjjurmkkvqvknpkxrnnachyndzagj
 * Smoking Wheels....  was here 2017 dlmmrzxivatwghagivcsggrlzzhpagwsypnaomsnygrtchyl
 */
package net.yacy.peers.graphics;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import net.yacy.search.EventTracker;
import net.yacy.search.EventTracker.Event;
import net.yacy.search.query.SearchEventType;
import net.yacy.visualization.ChartPlotter;
import net.yacy.visualization.RasterPlotter;
public class ProfilingGraph {
private static ChartPlotter bufferChart = null;
public static long maxTime = 600000L;
public static long maxPayload(final EventTracker.EClass eventname, final long min) {
	final Iterator<Event> list = EventTracker.getHistory(eventname);
	if (list == null) return min;
        long max = min, l;
synchronized (list) {
EventTracker.Event event;
while (list.hasNext()) {
event = list.next();
l = ((Long) event.payload).longValue();
if (l > max) max = l;
}
}
return max;
}
/**
* 
* @param width width of the graph in pixels
* @param height height of the graph in pixels
* @param subline the eventual graph subtitle. May be null.
* @param maxTime maximum time range
* @param timeUnit the time unit for the time range. When null, default to seconds.
* @param showMemory draw memory usage when true
* @param showPeers draw peer ping when true
* @return a RasterPlotter instance drawn from the event tracker
*/
public static RasterPlotter performanceGraph(final int width, final int height, final String subline, final int maxTime, final TimeUnit timeUnit, final boolean showMemory, final boolean showPeers) {
final int maxppm = (int) maxPayload(EventTracker.EClass.PPM, 25);
final int maxwords = (int) maxPayload(EventTracker.EClass.WORDCACHE, 12000);
final long maxbytes = maxPayload(EventTracker.EClass.MEMORY, 110 * 1024 * 1024);
final int maxmbytes = (int)(maxbytes / 1024 / 1024);
final int leftborder = 30;
final int rightborder = 30;
final int topborder = 20;
final int bottomborder = 20;
final int leftscale = (maxwords > 150000) ? maxwords / 150000 * 20000 : 10000;
final int rightscale = showMemory ? ((maxmbytes > 1500) ? maxmbytes / 1500 * 200 : 100) : Math.max(100, maxppm / 100 * 100);
final int anotscale = 1000;
final int bottomscale = Math.max(1, maxTime / 10);
final int vspace = height - topborder - bottomborder;
final int hspace = width - leftborder - rightborder;
ChartPlotter chart = new ChartPlotter(width, height, 0xFFFFFFl, 0x000000l, 0xAAAAAAl, leftborder, rightborder, topborder, bottomborder, "YACY PEER PERFORMANCE: MAIN MEMORY, WORD CACHE AND PAGES/MINUTE (PPM)", subline);
		chart.declareDimension(ChartPlotter.DIMENSION_BOTTOM, bottomscale, hspace / (maxTime / bottomscale), -maxTime,
				0x000000l, 0xCCCCCCl, "TIME/" + timeUnit != null ? timeUnit.toString() : TimeUnit.SECONDS.toString());
chart.declareDimension(ChartPlotter.DIMENSION_LEFT, leftscale, (int)((long)vspace * (long)leftscale / maxwords), 0, 0x008800l, null , "WORDS IN INDEXING CACHE");
        if (showMemory) {
chart.declareDimension(ChartPlotter.DIMENSION_RIGHT, rightscale, (int)((long)vspace * (long)rightscale / maxmbytes), 0, 0x0000FFl, 0xCCCCCCl, "MEMORY/MEGABYTE");
} else {
chart.declareDimension(ChartPlotter.DIMENSION_RIGHT, rightscale, (int)((long)vspace * (long)rightscale / Math.max(1, maxppm)), 0, 0xFF0000l, 0xCCCCCCl, "INDEXING SPEED/PAGES PER MINUTE");
}
chart.declareDimension(ChartPlotter.DIMENSION_ANOT0, anotscale, (int)((long)vspace * (long)anotscale / maxppm), 0, 0x008800l, null , "PPM [PAGES/MINUTE]");
chart.declareDimension(ChartPlotter.DIMENSION_ANOT1, vspace / 6, vspace / 6, 0, 0x888800l, null , "URL");
chart.declareDimension(ChartPlotter.DIMENSION_ANOT2, 1, 1, 0, 0x888800l, null , "PING");
        long time;
final long now = System.currentTimeMillis();
        long bytes;
float x0, x1;
int y0, y1;
try {
/*
Iterator<Event> i = serverProfiling.history("indexed");
x0 = 1; y0 = 0;
while (i.hasNext()) {
event = i.next();
time = event.time - now;
x1 = (int) (time/1000);
y1 = ppm;
chart.setColor("AA8888");
if (x0 < 0) chart.chartLine(ymageChart.DIMENSION_BOTTOM, ymageChart.DIMENSION_ANOT0, x0, y0, x1, y1);
chart.setColor("AA2222");
chart.chartDot(ymageChart.DIMENSION_BOTTOM, ymageChart.DIMENSION_ANOT0, x1, y1, 2, ((String) event.payload), 315);
x0 = x1; y0 = y1;
}
*/
Iterator<Event> events;
if (showMemory) {
events = EventTracker.getHistory(EventTracker.EClass.MEMORY);
x0 = 1.0f; y0 = 0;
if (events != null) {
EventTracker.Event event;
while (events.hasNext()) {
event = events.next();
time = event.getTime() - now;
bytes = ((Long) event.payload).longValue();
x1 = timeUnit.convert(time, TimeUnit.MILLISECONDS);
y1 = (int) (bytes / 1024 / 1024);
chart.setColor(0x0000FF);
if (x0 < 0) chart.chartLine(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_RIGHT, x0, y0, x1, y1);
x0 = x1; y0 = y1;
}
}
}
events = EventTracker.getHistory(EventTracker.EClass.WORDCACHE);
x0 = 1.0f; y0 = 0;
if (events != null) {
EventTracker.Event event;
int words;
while (events.hasNext()) {
event = events.next();
time = event.getTime() - now;
words = (int) ((Long) event.payload).longValue();
x1 = timeUnit.convert(time, TimeUnit.MILLISECONDS);
y1 = words;
chart.setColor(0x228822);
chart.chartDot(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_LEFT, x1, y1, 2, null, 315);
chart.setColor(0x008800);
if (x0 < 0) chart.chartLine(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_LEFT, x0, y0, x1, y1);
x0 = x1; y0 = y1;
}
}
events = EventTracker.getHistory(EventTracker.EClass.PPM);
x0 = 1.0f; y0 = 0;
if (events != null) {
EventTracker.Event event;
int ppm;
while (events.hasNext()) {
event = events.next();
time = event.getTime() - now;
ppm = (int) ((Long) event.payload).longValue();
x1 = timeUnit.convert(time, TimeUnit.MILLISECONDS);
y1 = ppm;
chart.setColor(0xAA8888);
if (x0 < 0) chart.chartLine(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_ANOT0, x0, y0, x1, y1);
chart.setColor(0xAA2222);
chart.chartDot(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_ANOT0, x1, y1, 2, ppm + " PPM", 0);
x0 = x1; y0 = y1;
}
}
if (showPeers) {
events = EventTracker.getHistory(EventTracker.EClass.PEERPING);
x0 = 1.0f; y0 = 0;
if (events != null) {
EventTracker.Event event;
EventPing ping;
String pingPeer;
while (events.hasNext()) {
event = events.next();
time = event.getTime() - now;
ping = (EventPing) event.payload;
x1 = timeUnit.convert(time, TimeUnit.MILLISECONDS);
y1 = Math.abs((ping.outgoing ? ping.toPeer : ping.fromPeer).hashCode()) % vspace;
pingPeer = ping.outgoing ? "-> " + ping.toPeer.toUpperCase() : "<- " + ping.fromPeer.toUpperCase();
chart.setColor(0x9999AA);
chart.chartDot(ChartPlotter.DIMENSION_BOTTOM, ChartPlotter.DIMENSION_ANOT2, x1, y1, 2, pingPeer + (ping.newPeers > 0 ? "(+" + ping.newPeers + ")" : ""), 0);
x0 = x1; y0 = y1;
}
}
}
bufferChart = chart;
} catch (final ConcurrentModificationException cme) {
chart = bufferChart;
}
return chart;
}
public static class EventSearch {
public SearchEventType processName;
public String comment;
	public String queryID;
	public long duration;
	public int resultCount;
	public EventSearch(final String queryID, final SearchEventType processName, final String comment, final int resultCount, final long duration) {
		this.queryID = queryID;
		this.processName = processName;
		this.comment = comment;
		this.resultCount = resultCount;
		this.duration = duration;
	}
}
public static class EventDHT {
public String fromPeer, toPeer;
public boolean outgoing;
public int totalReferences, newReferences;
public EventDHT(final String fromPeer, final String toPeer, final boolean outgoing, final int totalReferences, final int newReferences) {
this.fromPeer = fromPeer;
this.toPeer = toPeer;
this.outgoing = outgoing;
this.totalReferences = totalReferences;
this.newReferences = newReferences;
}
}
public static class EventPing {
public String fromPeer, toPeer;
public boolean outgoing;
public int newPeers;
public EventPing(final String fromPeer, final String toPeer, final boolean outgoing, final int newPeers) {
this.fromPeer = fromPeer;
this.toPeer = toPeer;
this.outgoing = outgoing;
this.newPeers = newPeers;
}
}
}
