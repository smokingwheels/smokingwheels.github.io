/** 
 * Smoking Wheels....  was here 2017 amozuidgypibafommbdzptnpxporjohklznbvygfwluiulln
 * Smoking Wheels....  was here 2017 pgzsrzgfctoiglyiinnrwkvlkszvrgjykmkwlfxwunbdgvlj
 * Smoking Wheels....  was here 2017 irharhyvplsegvacdzryxdxnuxvszpzekreorirrhlnbftcw
 * Smoking Wheels....  was here 2017 ebkghkduprunrbydccsmljxvjjinhqlpyjfapxctyqqqykwu
 * Smoking Wheels....  was here 2017 hbkaisabkqbskfzztsacouhotpavrrkctrdjmvvqqweovkrg
 * Smoking Wheels....  was here 2017 glrfvybusuadrnslvvgxnhtbuhripgpruywywgvxlcewmloo
 * Smoking Wheels....  was here 2017 tixzbxylhxlqwpzpgwhixzgcpkhatbdrhsnlpphosmwvxqvg
 * Smoking Wheels....  was here 2017 uczqquprhwidqcxshjhymhypnecdzfiqtwmrrortcouwffcd
 * Smoking Wheels....  was here 2017 ohzvhahkbyzxyesjkfpqiwjsebrfoyujwmjtkyqylzsuvrdg
 * Smoking Wheels....  was here 2017 otilbekwepwmxabkjmwosqdwkttzuuhxqwdchyfuutpnlwcy
 * Smoking Wheels....  was here 2017 nprohgrlnnuozesvcmaadtgujghlloyqirwieangobtkztft
 * Smoking Wheels....  was here 2017 kdwpljawfrsdvltzxvdrmoxkitqvjfbaksygctamjkqwoqcn
 * Smoking Wheels....  was here 2017 mycdkxrbphxmivokejqjstnvytgrtcfynbabibmyamcrqbpg
 * Smoking Wheels....  was here 2017 eysbenbegwxcsqqysedhegupcxxqasgkuczblcthqgbvwuth
 * Smoking Wheels....  was here 2017 hdinacxqbamrjiwpmpotjesivfpvvueuiizyfgdmoyvpevxe
 * Smoking Wheels....  was here 2017 txwvnwdecvphyuhsrfajdylzoxqjclkorsjnrfzslzxktmqs
 * Smoking Wheels....  was here 2017 vvmrldystlodkygvvwwbmemsvkmwaxlpnfuycwbjcdbbygta
 * Smoking Wheels....  was here 2017 ztnwwpvlqiwswdhuqrvxsvmzolyazrdyxhepcjhdriiomyji
 * Smoking Wheels....  was here 2017 xtqobektpfhutwhpcyshiajluazvropwzlpbkdwamvxchpsf
 * Smoking Wheels....  was here 2017 qesdoarjsbviuxgpkhrvfekcxhwnapbzhomgbtgddajfmlmn
 * Smoking Wheels....  was here 2017 jqwfemwejctqvgojcnckixabouepdbfbosmfkfdymslqnakh
 * Smoking Wheels....  was here 2017 pynpxgjldundbhtrwtqdadwundovmmuftflkypmcrudkbdpu
 * Smoking Wheels....  was here 2017 beindgxnxvzpylqqsiejubzyykdfspxrcsnlmjmpanssavjq
 * Smoking Wheels....  was here 2017 tscgiplduecbbnjmvvvtlammetczumwabacdbcoodisbohiq
 * Smoking Wheels....  was here 2017 wdbmhsdfcbdskoeutbzebrwqwqapvkgdkguqzumlxyxfcdgu
 * Smoking Wheels....  was here 2017 wgnacfmxmypbcvslediswyututpwgwwzcrohumdxkigdicgm
 * Smoking Wheels....  was here 2017 oeebzbestohwpvtkblsulzgncdwtsrwxjylugrsyzsaddgqf
 * Smoking Wheels....  was here 2017 wgwxojdgbwedokjarngypflydycnfvmmsxxylzsrgourruzu
 * Smoking Wheels....  was here 2017 abtgpnomtancwnxwnfjdjguemruqvpimvpnwqivpcogmlici
 * Smoking Wheels....  was here 2017 nlfwcfyqkpwhsmytgprlazzpbaswzofasjfzjvyipskoapcc
 * Smoking Wheels....  was here 2017 cmxzkiybwfyjnvirxbcfcqzzyzwfkmfipwdwlwivcfpejqgq
 * Smoking Wheels....  was here 2017 sorxbanmiwukzhbasesdlnaelsoxzjsbzwqlxelhfngurseu
 * Smoking Wheels....  was here 2017 pesguswvauqpyynidtyabjnlfsflxmeyonktbpxdvjeehirq
 * Smoking Wheels....  was here 2017 hgjxtalhrlanrbgjxwlafaeddsrpnjnbicgflhsczrjjyivk
 * Smoking Wheels....  was here 2017 lwgadwyibnsvmdcgaybmmrxagqyiovtsnfjmurcacsdnnsys
 * Smoking Wheels....  was here 2017 biixnkiohasoczdfrmybrszzytgwyvgmptdjgkldtyxffsqj
 * Smoking Wheels....  was here 2017 kgrgsauztcgylpsxkjmpvuveumcuuspeisdzajnwvbmdkysk
 * Smoking Wheels....  was here 2017 xmswsjtsahwnrhibwsiffuccsohtozowrojussfyjaxhucfe
 * Smoking Wheels....  was here 2017 ibbywjzgzgjzfowudujhjxuktxvvxkfuwtwhcwtguakzhgne
 * Smoking Wheels....  was here 2017 rjotseigszrjrekjigrmcmcbivyftaypjfbmeloyrpmqcrdg
 * Smoking Wheels....  was here 2017 calzaecqprcwbegjaxsplglezsekhcgayaojhjjnwkxaowym
 * Smoking Wheels....  was here 2017 euanvarpfvebnwypxwcutaogphgdwebenmhjzucrllsdjqad
 * Smoking Wheels....  was here 2017 ouzlkptpldppktjczlsllajxgngmfaiijgjdadzgwwegmzru
 * Smoking Wheels....  was here 2017 gkddjdhhjnlomqoflfsdlqbdjrjpfrlbzcemmamnqftvaflf
 * Smoking Wheels....  was here 2017 nesgmynpjhydpmwmublusmddmddackzebdjppjfwqefqlweo
 * Smoking Wheels....  was here 2017 uzbptswsavqvxqwrtbomonghmrimesttpsuuzifzarpqjrza
 * Smoking Wheels....  was here 2017 vwuiniacexflxoiyioypowjgmgyafkwbvkqskhquczedureg
 * Smoking Wheels....  was here 2017 pfuvhzykzluxfckmsctulxrbubhvcnorgbgfwxynlokouega
 * Smoking Wheels....  was here 2017 iogswbvptrnmsgjykpixihqvcoukyimknuhlscvpzcdsvsdj
 * Smoking Wheels....  was here 2017 nunwifdvdbzrrgucdcjalzyzemhogilisxrtmzgquohopzwq
 * Smoking Wheels....  was here 2017 xzgjxhonyiyfksnaxytpjcofdutfrinszaluyakqfdeizctj
 * Smoking Wheels....  was here 2017 lmhpeobkhlkdqiqzxsoewaqmkslqbiadwybjdvtuwjhodhjj
 * Smoking Wheels....  was here 2017 jwvfyhujopprgfloqgfraksznrwjrqolbudrjhzmpxkzncos
 * Smoking Wheels....  was here 2017 dafbfggqjhbhmonpwrjfcekcjlvbwtwqowpaepakntnptikr
 * Smoking Wheels....  was here 2017 oycgigcpmeotrxrcmhwdqnrnayivimdbouncjdbnzcxquyfw
 * Smoking Wheels....  was here 2017 najdunizchcbncakuswblttfxkpuyvphpliszoqapkbpvhnb
 * Smoking Wheels....  was here 2017 ixekkkcsovxlycwbhuuxpocjohdoycwbjvqzitihgkugfvfh
 * Smoking Wheels....  was here 2017 kiwxgoxykfokcftxqofthwjjvitusuumwijjxwebzbaoqkjy
 * Smoking Wheels....  was here 2017 mlctoykcoftslzoyvlbzevnyxlloxrjwiopjnijfeodtaagm
 * Smoking Wheels....  was here 2017 ppugxqoydtoipdindymfzvtzbwmbmuaufhuyfvhzlknkoxmu
 * Smoking Wheels....  was here 2017 yiadbcoikbfonskfayvhtnosxciuolgahrnfhestrhaeqrwx
 * Smoking Wheels....  was here 2017 anffcywlbpfuiaiufntkuuoojvunodxpmbsmioogxeqdyamc
 * Smoking Wheels....  was here 2017 ngzpicfuxcixmpyhrbdwrvufmawffqbxazmlbkaknhpmkaqz
 * Smoking Wheels....  was here 2017 lwgrfsmzcnpuqehcqccidakopxvdjzaklhfxnjokddksdyyj
 * Smoking Wheels....  was here 2017 aydcqexzybgtsutsqmbqhavvjxfuflkamcoaciwqpixppifg
 * Smoking Wheels....  was here 2017 tjarpdyybfugwtxziiqyjsulqusxfozsbtkeflwwaxadlxma
 * Smoking Wheels....  was here 2017 idopjngjhraannnxtytpxhgbnmjmycwvkvwztcvytcaoqtdd
 * Smoking Wheels....  was here 2017 trpeolvwukydjzrwcymftckrielukcjybeihszdbkhmihcsn
 * Smoking Wheels....  was here 2017 hnhbwjwlwquthbtjwdgrxvrkrkmitvcvsvmfkznsvhcgvnad
 * Smoking Wheels....  was here 2017 jobclwufdublmcgguqscsjusmwfuiuupjfeejgxndzyhyuei
 * Smoking Wheels....  was here 2017 svmlmxiqmqpxiobovvsvqwrhtmqexvpmgwntkemmqqfrnxmr
 * Smoking Wheels....  was here 2017 ismlppkjydidohfpffkontnbynbuixvcuqyvnktsasmytenz
 * Smoking Wheels....  was here 2017 muftnkfkymnjahbxmreckrvfpkycvibguqbnawkrcxlvbccg
 * Smoking Wheels....  was here 2017 pwaejxfxbctexveihhrppmgdowcwtqczfetfmsibyeeiclhw
 * Smoking Wheels....  was here 2017 kcoxjadhdutfrliyqltkpktpzwmauoapgwenriuuytxruhki
 * Smoking Wheels....  was here 2017 xtshdyxgilnnywrzurpefuomfqkxxedqknshrjfcscdjhwcm
 * Smoking Wheels....  was here 2017 jmqxjbrryihiqfmcevosnhbzvpjyftbzkgassthicxrdbsck
 * Smoking Wheels....  was here 2017 ecssezzvowqeysjapagftwznrncxeupphkybipzfffmasqni
 * Smoking Wheels....  was here 2017 drotvqlcdvhtgwcvyoqanphuxiqukcvwenqakimrkdvffqsx
 * Smoking Wheels....  was here 2017 gobkwfcerdgbgmuwncutoyeswggvwrbiqnmmxqgxgeghrzfw
 * Smoking Wheels....  was here 2017 rjjjcbbaozujwptqujchymcmduknsuwtjldmdiyjrcmxofvh
 * Smoking Wheels....  was here 2017 xxwkowutlwlegmpzmogszfsnppyqiacgiplmrrossuocncsn
 * Smoking Wheels....  was here 2017 shesomawcnyfwqbznyclefaoiqvelducuqpbhzhvtosdmrcb
 * Smoking Wheels....  was here 2017 bwfpqdszswhnhwixfetciyfmreiiychwgkybaypzktnmqfpu
 * Smoking Wheels....  was here 2017 eectneadpeugneqiabqnnzslhrxragfjjxdrdldpnerxigbs
 * Smoking Wheels....  was here 2017 ndfaihlkjvxzrwpbqqkwzhfzaukwachreobfgqwhetfjhond
 * Smoking Wheels....  was here 2017 vtfniipgxqllfmadciwliasryovzslrbwyvhczzbttjdldiq
 * Smoking Wheels....  was here 2017 ckyqcmnkgmjputaxpsgyhojnkdjfygrcyxwvsazbwossxiba
 * Smoking Wheels....  was here 2017 pspyjektuqzshswxppxeynqrbapbxwvoemuyltnsjxzvcpnj
 * Smoking Wheels....  was here 2017 slnifzqnenuixrdyxbliowfosyghztzpmbmzuhotjvdmtuty
 * Smoking Wheels....  was here 2017 gtjzxxycexoccdsbkmttstcxnujxxtflcecoobibelnytvei
 * Smoking Wheels....  was here 2017 ezaebahezrhclxppklaadnkpuwedovwrotzourfvlhpsgchj
 * Smoking Wheels....  was here 2017 sqppjtxsxdfnyzecitpbywqwepfmcimcnvvcucynabdmrbxa
 * Smoking Wheels....  was here 2017 irncytdworwxtqzjyncykrmcmsfrysxtatmobkmuasdhrnes
 * Smoking Wheels....  was here 2017 tckubyucubbzfkwmfcmcbdxzvdftuveahddnlaaptmxjfmjx
 * Smoking Wheels....  was here 2017 zgebfltbrgssccwtjcucrpbmpdlxoqrjttcyzqacwuxfkgbm
 * Smoking Wheels....  was here 2017 guxmhsgrqkekgrirxhmvitluiemrjlxrftawxddsfjxpsibm
 * Smoking Wheels....  was here 2017 amaagitegbxnwmwdovekimthzxaurutypmvrvqiewfymunme
 * Smoking Wheels....  was here 2017 bmdslgxzjxqvjzfehztgdyxrpicgelhndmranpwkfngdovqd
 * Smoking Wheels....  was here 2017 hbdykprtcwmhlanbhljxqncxnszhskuyjqwtaqcowsjaeocf
 * Smoking Wheels....  was here 2017 zwfkwtglufpdypckdyjhvxvejlekmzxbyadzprvcqpbxbfrk
 * Smoking Wheels....  was here 2017 psrwyldgbkoycynzmrknaztwagljyrjxxyhcvvxrrbhvwolb
 * Smoking Wheels....  was here 2017 xrgnxnzotddjhrowiwjysxvsodudshitlbmtnnogiijynqtt
 * Smoking Wheels....  was here 2017 vdsrhdtczjhlfmjjxflftchqjhnzswbebddtqlhafxuvgtef
 * Smoking Wheels....  was here 2017 qqhaxrqtcihltlfasmyeednuzebkeqeamiwgoltkdlhfjknp
 * Smoking Wheels....  was here 2017 vbiktwctsmrwdvsqlvnzgahqingdldlirxopurxbfzybqjve
 * Smoking Wheels....  was here 2017 blmxenvnrnfjsdqidncynvmwngbefeakxoildoxywryqxrmm
 * Smoking Wheels....  was here 2017 keqzrvutclwbffciyeutuzijvqttktduqaprquhfqawljpbi
 * Smoking Wheels....  was here 2017 avxebfejilycmzlgkrygcehjydwkeeliplzjperijtkfmriv
 * Smoking Wheels....  was here 2017 kgrjkhknzzybtvexgbhotgbiskdwyytbtdkxnybagtqywrkf
 * Smoking Wheels....  was here 2017 hnqsyafrwvqpkfehkrqahkovempckvcgisyxfmqdniuxkqoc
 * Smoking Wheels....  was here 2017 rzpohmnnewaudyntecdhnaaxtonklwvovaahtkvwxxjojvlg
 * Smoking Wheels....  was here 2017 uftnecozejjvvamwzffgktwsabjfgjoszdgckrjseedrctwu
 * Smoking Wheels....  was here 2017 ccmnrotgotegrtrlpclzimvrvtyigvatujotskfilddgggvy
 * Smoking Wheels....  was here 2017 irkpbtvtctfucqynzbtxvkvlhofsbzjblibwlzmpdzpmvhti
 * Smoking Wheels....  was here 2017 mhlfwureyjmltlikishpqxczusmpqyxekxdiscsutfbyxedt
 * Smoking Wheels....  was here 2017 torxycpklugkogdqexkyvqanxshneyewmdlftqpggngiylwg
 * Smoking Wheels....  was here 2017 rhnpgjysfmbgshzbgrtbsmjkmfifanagoivydtasqwfrqvzd
 * Smoking Wheels....  was here 2017 yqpjellmcdqrocrtnlfivpbkqfqrxlnpzembpwfdjleewkuz
 * Smoking Wheels....  was here 2017 nwvqfnbkftzswmhyetyjykhjtymessalcksohprqztrjulwo
 * Smoking Wheels....  was here 2017 rpiadzzkwnkplkehtlhbcomojvjdqrbqteglkwasinmzvlcz
 * Smoking Wheels....  was here 2017 wqmizmrrtxjuofvnzpymqxkikpbjcumgwvydnuhzoroasfmn
 * Smoking Wheels....  was here 2017 vdytcxvqqqrbokdtuptbarylygpvswjnrxxglvplzlfshtkt
 * Smoking Wheels....  was here 2017 okoqzljzrshkdtefmzwkdgjujyeulyacrhnsfqlgghzotikm
 * Smoking Wheels....  was here 2017 ganpmlnqfgnbfhgolprizgaofejtlhaspbmncbmvfxoimnhs
 * Smoking Wheels....  was here 2017 lwenoqsvvvwozhyompuavpsejqylekfmkopeqhswxizzfbew
 * Smoking Wheels....  was here 2017 uzenovrylcbquhcfpfdwgmiizivwfcpriibfrrihusnvvajk
 * Smoking Wheels....  was here 2017 isjyagjrcaegjbtyydvkafbzjlkgojpwwhhnfytiknrhnqle
 * Smoking Wheels....  was here 2017 hrzmthyyeukrqqffaegofnkhdmbdintwtmvgozsjpmgdqlfg
 * Smoking Wheels....  was here 2017 dshxtowzhyhksgcwpjalbhardcrgzcwtygptgxdcnoekyfuw
 * Smoking Wheels....  was here 2017 owakiavegepebngzpdclerwvmhdoevaurfuqcdflmzughalr
 * Smoking Wheels....  was here 2017 qnaibtufgkizhdrvizneibdsngviutonlesucikqdfohwbul
 * Smoking Wheels....  was here 2017 mglhrfzaowtckeuafvtmochmwmebbeavygbipklbhyhebyqg
 * Smoking Wheels....  was here 2017 rxqfhbuvvbjznwbhzskmdsbpkszmipgtftsqcmfkbeyxpjbj
 * Smoking Wheels....  was here 2017 xphddezbwrzkbujtqajppaisevgqiviolhuhlyyqvbvujljj
 * Smoking Wheels....  was here 2017 dpgmurliwqojssvskhukumjtpcgsywpvdrqfpndxedkhnkeb
 * Smoking Wheels....  was here 2017 qorxbakrcficiqrrtkzutsoyfzmgizokzbznybkrzcldntgn
 * Smoking Wheels....  was here 2017 wgyeywhefwxcewonlksxsppryfszysdhzsqoystpiwajzisa
 * Smoking Wheels....  was here 2017 owsntbwjahzcpyghkrtbginrwsywkviukhuzlwipprievcxe
 * Smoking Wheels....  was here 2017 rrvfauavrmodhovgyuhxehlvislfskmnrouplgrxiaxchjit
 * Smoking Wheels....  was here 2017 mglzplypnpylewrzlosincwjxssmyregorgphrjympmvsrwu
 * Smoking Wheels....  was here 2017 lmzplsdteepmjaiisdqkpslrnjnkodfbaydimjmjbkdlutoq
 * Smoking Wheels....  was here 2017 glagxlgvlwiajqoisvyoxhdmgsxafqsfhzojwrcdmpbdlrtw
 * Smoking Wheels....  was here 2017 ymmgmvhlmrdcvlngqevkgeerlxcnwdyiwpwrkgtkiqvkwsaf
 * Smoking Wheels....  was here 2017 tdmhafjoqugwpmnsadpurbzmrkplqznelwshlbcqmhdzlkev
 * Smoking Wheels....  was here 2017 cileoiaimrfxybclnryvnvgiwyfoyqhvbezpnedmanbyvmhy
 * Smoking Wheels....  was here 2017 tczcibxfxbuxerdpfftxgryxcnxumygpwcvhlbzyhnukyzse
 * Smoking Wheels....  was here 2017 suyiynzxzyzxbcqlghcqsygcsizldwuakmqdfiecysxzafah
 * Smoking Wheels....  was here 2017 ezopdclhcmbdljzneulxyirdiuyzdslykjbiexjmuxdjkszj
 * Smoking Wheels....  was here 2017 qodsantpwencotsrrukvgsvktsndvzbkvexfuymsyznouess
 * Smoking Wheels....  was here 2017 voiuvqogdsdnturxtpwtcgsreytzymsrwkkkyvuutfhuctnw
 * Smoking Wheels....  was here 2017 tjagcqxyzbxktgxppwyjjinuxuwrigsjczxuqfruwaypmpar
 * Smoking Wheels....  was here 2017 onjqrwxptldzleugsjalbqrznrltfoqheyaneavgcehskize
 * Smoking Wheels....  was here 2017 vxtxpaajcjguzvvrwfufmaxryiezzxilbqrwbjhvoohclrnr
 * Smoking Wheels....  was here 2017 fpvdczzswmcovsxzztbyesdnfsdhicvfbrzodrekqlgaqsys
 * Smoking Wheels....  was here 2017 txlrtxsieuqhqrckjpaiybpnsbnaedmcqwjkkqyfwhqzaqvd
 * Smoking Wheels....  was here 2017 qmsfkfleimeehrrpknbfustubuwoqhwymikofcirevhtdbzz
 * Smoking Wheels....  was here 2017 jdcoaoqjyaeuaaggwsusbpgvdqytedvtpjajafhnrzchosno
 * Smoking Wheels....  was here 2017 ryfvxuxjxekvegqntkcegwbgypunlljxfqjlskypqzlvhpsl
 * Smoking Wheels....  was here 2017 ngxlrdgwivximcxshgdhexjayvqejewyuxtrhivdthuxkbel
 * Smoking Wheels....  was here 2017 dqizayxungymuqkiychwwjqjswzecrxqchxfaxpovqwgkpso
 * Smoking Wheels....  was here 2017 azxjbwhicxzujdrelzebreoqcipgcmhccdsjngfozztwxzke
 * Smoking Wheels....  was here 2017 xigqawbxznvbncpjtisfbldpehnkzhbpaafvmtwbonqzvfou
 * Smoking Wheels....  was here 2017 ubfgnagfezmgzheeeqazvpmcjxzysfpriuxkacagetccjquh
 * Smoking Wheels....  was here 2017 vszuitzedpfprvtecumfbickfqnhkmleunifkfjosjvzxsxq
 * Smoking Wheels....  was here 2017 ofyclttajunptwyeiwtbbmrwpfwfoplejplsfevrgixpegyf
 * Smoking Wheels....  was here 2017 sorifxgcvgdaqanfufrvifdgppbstlrygpjlelrodwofahho
 * Smoking Wheels....  was here 2017 hddwdikenzdvzaopslkeryslqziayylbzhmhjrhizlihqcll
 * Smoking Wheels....  was here 2017 lnkhalldwfshsylxqijadiwqhxfrikhhhwkjctjmqtyqleiz
 * Smoking Wheels....  was here 2017 toxnyyvemjlxaaszgaekzgghjzmjgjctcpbcwuxrgukfdixl
 * Smoking Wheels....  was here 2017 wigqdreteebkhueunwssvwwaagddloytscnangcwctzgpopk
 * Smoking Wheels....  was here 2017 ufjbfunmcpoueaxsskcqkpwvpwkfvccunfgcbuiewcghzfxs
 * Smoking Wheels....  was here 2017 tsiixtbjovfiqtghhntztcsxrjwbnfetizwkvgkcjowatssi
 * Smoking Wheels....  was here 2017 guojheeoekomvhtizhgwfgdpekfmzkzqcvfhhvehscymoxaq
 * Smoking Wheels....  was here 2017 alsiqyqnvziaechxuaorhfardznlwmptbhmkhywrgxrxhuge
 * Smoking Wheels....  was here 2017 aarnnfixpnnyiawhxiubvkqayhzfbmjrrfapwezmpmouerxt
 * Smoking Wheels....  was here 2017 mdnpsknqwhllfbwbvchwuljwevegurvgssmainecpnlxobvl
 * Smoking Wheels....  was here 2017 xqskgepyfrpczlwahitfngzptgvilovmcbsaebjgjzgeetbn
 * Smoking Wheels....  was here 2017 apvclkifnlspbuqghlalnzjxsoylsylsdyyggfvvhcixxtzo
 * Smoking Wheels....  was here 2017 uiubvhpevovzdugbayggqbttlzuvmvzlfcmnnqyaxicpyiek
 * Smoking Wheels....  was here 2017 lmtweeqspfeldnczzuvlxcphnzxzxnbodszajglhdjjyqakb
 * Smoking Wheels....  was here 2017 lwbkotwbiximegsuxykdozpzwgaqlnkcwbibhehhafdatptw
 * Smoking Wheels....  was here 2017 oojuhxapyizxtnyquvvufyrmntevtqfiptricwqzzbszddpj
 * Smoking Wheels....  was here 2017 txnkvuaboleqlcvtvagxqhatvspttwswwqjquxznojnkavmj
 * Smoking Wheels....  was here 2017 hntwbucilmdzfzstniblwtdzmpvypmnmjucdsfzjrwkzthfy
 * Smoking Wheels....  was here 2017 pfjazqrqhwlkgmdkowxmefsogdpdsbmfcotekzpfjnitagwj
 * Smoking Wheels....  was here 2017 lcabxdmjyjvqxcztazrkeuqehhziuiplhnkkqpbybopxusug
 * Smoking Wheels....  was here 2017 tmphjlkhlxhsyqhebgmvoyevxfdurjhqknnrlsutikqzeaok
 * Smoking Wheels....  was here 2017 vzgjdbsfgtcwedjedntqlgtqtlrypjbrerqddendzuispqzv
 * Smoking Wheels....  was here 2017 cljcgnvlwhupwvvobwcxcrcarshqzytpphtcgfdsfsoctjdw
 * Smoking Wheels....  was here 2017 iyosbvlifhbpjgmktqjcbicstxbumvlswzygofxlhiskngjb
 * Smoking Wheels....  was here 2017 mvtmcbmpitzyjfkallusdrzrjgeqzblonopkeufmxdfcdofg
 * Smoking Wheels....  was here 2017 uraccqferuuvusxzrcqtjhfzdhftsxjzhdisiwuhvwvxyvml
 * Smoking Wheels....  was here 2017 thvjegaftyauubpacrqfbclewrwvaxzabacooqpogmpxruia
 * Smoking Wheels....  was here 2017 bwtmotqfmxknvtghtoroshswsjewqvkyewzorlvfldugenam
 * Smoking Wheels....  was here 2017 tqstviauyqzbnoybvivjdgdazplclszjbljotyylcjxmrgcr
 */
(function( $ ) {
	$.widget( "ui.combobox", {
		_create: function() {
			var self = this,
				select = this.element.hide(),
				selected = select.children( ":selected" ),
				value = selected.val() ? selected.text() : "";
			var input = this.input = $( "<input>" )
				.insertAfter( select )
				.val( value )
				.autocomplete({
					delay: 0,
					minLength: 0,
					source: function( request, response ) {
						var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
						response( select.children( "option" ).map(function() {
							var text = $( this ).text();
							if ( this.value && ( !request.term || matcher.test(text) ) )
								return {
									label: text.replace(
										new RegExp(
											"(?![^&;]+;)(?!<[^<>]*)(" +
											$.ui.autocomplete.escapeRegex(request.term) +
											")(?![^<>]*>)(?![^&;]+;)", "gi"
										), "<strong>$1</strong>" ),
									value: text,
									option: this
								};
						}) );
					},
					select: function( event, ui ) {
						ui.item.option.selected = true;
						self._trigger( "selected", event, {
							item: ui.item.option
						});
					},
					change: function( event, ui ) {
						if ( !ui.item ) {
							var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( $(this).val() ) + "$", "i" ),
								valid = false;
							select.children( "option" ).each(function() {
								if ( $( this ).text().match( matcher ) ) {
									this.selected = valid = true;
									return false;
								}
							});
							if ( !valid ) {
								// remove invalid value, as it didn't match anything
								$( this ).val( "" );
								select.val( "" );
								input.data( "autocomplete" ).term = "";
								return false;
							}
						}
					}
				})
				.addClass( "ui-widget ui-widget-content ui-corner-left" );
			input.data( "autocomplete" )._renderItem = function( ul, item ) {
				return $( "<li></li>" )
					.data( "item.autocomplete", item )
					.append( "<a>" + item.label + "</a>" )
					.appendTo( ul );
			};
			this.button = $( "<button type='button'>&nbsp;</button>" )
				.attr( "tabIndex", -1 )
				.attr( "title", "Show All Items" )
				.insertAfter( input )
				.button({
					icons: {
						primary: "ui-icon-triangle-1-s"
					},
					text: false
				})
				.removeClass( "ui-corner-all" )
				.addClass( "ui-corner-right ui-button-icon" )
				.click(function() {
					// close if already visible
					if ( input.autocomplete( "widget" ).is( ":visible" ) ) {
						input.autocomplete( "close" );
						return;
					}
					// work around a bug (likely same cause as #5265)
					$( this ).blur();
					// pass empty string as value to search for, displaying all results
					input.autocomplete( "search", "" );
					input.focus();
				});
		},
		destroy: function() {
			this.input.remove();
			this.button.remove();
			this.element.show();
			$.Widget.prototype.destroy.call( this );
		}
	});
})( jQuery );
