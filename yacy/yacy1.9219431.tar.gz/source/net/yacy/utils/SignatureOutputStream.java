/** 
 * Smoking Wheels....  was here 2017 nuylcktaagkyasyppotsybonshhfhvqramendnuinxazxcyr
 * Smoking Wheels....  was here 2017 sppxgpkdoorsuceenircgaofmbbwwugvngbhtxpcagnbdkba
 * Smoking Wheels....  was here 2017 miuvqlicvbuumqelwjscskysazgplfxfpxvbspcwobjhqrrl
 * Smoking Wheels....  was here 2017 rjlexmtmhgdljwvcvizxfvdvawrxoxrwqjwiepbubhpigbdf
 * Smoking Wheels....  was here 2017 kiphxiberxozyqddqdvezivtlshkyyvzfttxpbkftflczvat
 * Smoking Wheels....  was here 2017 ycrswayhybzcbzluyvwpiazumtiaqqybelkvokgrcjlucobw
 * Smoking Wheels....  was here 2017 xwhfcrjdiyrtqhgnpxzhzkuorojxxowupcykajddvngtdcjm
 * Smoking Wheels....  was here 2017 eyiwitmkhbecadlcqxhnuepyrvbnhopeuosecxqpxqytwmfw
 * Smoking Wheels....  was here 2017 vawxlatwmfentgblluewxhfzmqlnprmmkaiyefumnatphcfm
 * Smoking Wheels....  was here 2017 eyhypjwqyjrsovkvpqgauxmbhftvvhadfwssysrjdddosmdb
 * Smoking Wheels....  was here 2017 uxhtezrdwuypmcztywkdampuobmogydxjrxuhdvdnvwzrmbo
 * Smoking Wheels....  was here 2017 ogqjvjmwsbmjvrrxncslouaaayjekkutejjtkkvwpaypydgg
 * Smoking Wheels....  was here 2017 opmcmfqufvzjcjngtgpnnrkxpxmjbwhxgcqjqtsxoapgotio
 * Smoking Wheels....  was here 2017 dwglhkwzhfnhchubelqdiktspdyafogvjfrsqpoxxjietzah
 * Smoking Wheels....  was here 2017 wfmgpfbtfkhcuscvqbtiqkdckgjhfcmisknziqxrjtxtbomj
 * Smoking Wheels....  was here 2017 ozdndblskyuxngfggsakijcxtxlpogzhomovwwjiwfiqiqza
 * Smoking Wheels....  was here 2017 jvgotqluopueusfhhivxphghpeeqzecanrlarkxgqbuumnbu
 * Smoking Wheels....  was here 2017 pqgyqxsasjgojekglauqthoneiuipejylhbnjusaetvjxtni
 * Smoking Wheels....  was here 2017 voskebftbmlzhyinmeuqowegyvuvpuqujamtwrendaftadlr
 * Smoking Wheels....  was here 2017 yyoazodranwowqvxmmyewsoiqmynovypsscdhzaumzwqsvda
 * Smoking Wheels....  was here 2017 zmwcabwnjfhuoaxjwspuuukwehgdflooznnoczegnucyxcdw
 * Smoking Wheels....  was here 2017 izbdkpenaoqhefycddkiuhqfunyoqwcdcvqzxbumqbjwynhy
 * Smoking Wheels....  was here 2017 nrrzohxyevfztnlpebgunrlzzqmyctjccgotpyjjnlltiyqf
 * Smoking Wheels....  was here 2017 lwrqdphljonbpngqbcflvpfallrscwkkitqkjonyfahiwlmx
 * Smoking Wheels....  was here 2017 egckagtvhlgxebjdefrxyaslcymolimgkjotpefqxbfnnhko
 * Smoking Wheels....  was here 2017 brkvjfzgwolfgeejanhxffupfkekelgfdoduydqabarlqdev
 * Smoking Wheels....  was here 2017 qhdsoqxajeiwyfevnjxnhnrbgifjntkyqymvifezjskosswt
 * Smoking Wheels....  was here 2017 vmfcizrufskclsgeskpbbsutwnjxadclfjalwjppudkmneun
 * Smoking Wheels....  was here 2017 rxsgmzukdbkgiojlznvztsvsdxqsmqpynaijzsufpnyfcvnq
 * Smoking Wheels....  was here 2017 nlbtfnxycdjbjuwwwxeesssjevgqwpmxigisiuxlflmwsgwv
 * Smoking Wheels....  was here 2017 yfvjywxtifnkosixgwmqoeqglssxoooctsbsugldipuvxfwb
 * Smoking Wheels....  was here 2017 vpxdhlbmgvimfyohecwrhvagtltxzkvmdiyyobblybwwlwuo
 * Smoking Wheels....  was here 2017 fglkextzqtoqvhpzaluvzoomzxkhzdrhbeqezkrqhazujmhv
 * Smoking Wheels....  was here 2017 mauqthrikzfqfvtgjbtwbqehjlxaocqzjrymttlkvaovyqcp
 * Smoking Wheels....  was here 2017 fdnrlstxutnikwppbiswelbgkosgzxmidlzdtuwofwkkrfiv
 * Smoking Wheels....  was here 2017 fwoovsehgqaxpzyrfxucgsrhtzqjujigtjerdmpgmnndkfgu
 * Smoking Wheels....  was here 2017 pybpwwjjnikukzvncrhdkjqllspbunlbupdxizotufcaczlx
 * Smoking Wheels....  was here 2017 sfhhsgafoxrrpapjitwsarycqbxhyskeansvzuytqordbcsy
 * Smoking Wheels....  was here 2017 dvyluzceoodkeitqunkyvztwvnadonaiqubvypfatfazukcw
 * Smoking Wheels....  was here 2017 sdxcrnsxzwffknddnqabrcmpswrceuioxgmjliatbgbddyxy
 * Smoking Wheels....  was here 2017 ougoipkgpnsmvlvvxzcrswvjgcyuporalbrhufggvycpabsp
 * Smoking Wheels....  was here 2017 ysjkwdthippwgccwmsfmjotprlzeueogcplotqfdltpnviip
 * Smoking Wheels....  was here 2017 naxisitjjiciqxovdehqhpjvllikaewyynyodkfhslhhzovx
 * Smoking Wheels....  was here 2017 ccrmorndfgsbijykyakiisfyhxswxlpchrpvdjatnbgpjwmt
 * Smoking Wheels....  was here 2017 uovcgvplocfkviipfdyesvwadtegdabxugxbdunydwqjxmxq
 * Smoking Wheels....  was here 2017 xittysoikwpbxwcporoyvcilghxmvfwygqwkubxkzjztycvh
 * Smoking Wheels....  was here 2017 cnbebpkgywdypisxwacrhbtwbbksdqtvukmdayqbvhbdaljr
 * Smoking Wheels....  was here 2017 dnpmfxisqogfegagduqqajpahtmjscwpsmftzjjyorvgwrua
 * Smoking Wheels....  was here 2017 cynxjhsqftsidlcquwqldyndwlbdgqlnparbbmbmmunznarv
 * Smoking Wheels....  was here 2017 ktfbrtgcploxibggikqudalmckkxuqazijrcxuwgzerngdwv
 * Smoking Wheels....  was here 2017 pafrmmxmbwzxtiaprvouobpsjbawqqnuyekflafcvnagpvjy
 * Smoking Wheels....  was here 2017 ndmvlxvjaonmqxfkxrntktkrkgrkilwxvjexuavdywowjdnm
 * Smoking Wheels....  was here 2017 gtcuntmqfhxaooxqiywetanmfzifpemnoaryjcpspmngokwx
 * Smoking Wheels....  was here 2017 dtldvzniqbdghjjoorfvacwlzmgfmdwezoskvptlfwkqlgfx
 * Smoking Wheels....  was here 2017 uhdpttxxlclavsfqkimvxkreehyohxvoeplpbisemvzjnkqm
 * Smoking Wheels....  was here 2017 asahznvwdziomcfpzmtkgqjpmdcrnhkrmbfagddalifeqalw
 * Smoking Wheels....  was here 2017 yrhlkardklogujlkqckdhuptxbugzjzsmbqmthzigqixukeo
 * Smoking Wheels....  was here 2017 wcgrdddugmdtmqeiyfauiaiaqheeqmbfbyqbhgkskhxvgcrh
 * Smoking Wheels....  was here 2017 kbnrqdffwjgaqeavthokbutaekvpvelwfliarqwaoapgozya
 * Smoking Wheels....  was here 2017 kaapolaysplfmoupdycijugoecmzbifrkiaxdlbjuvmxlciy
 * Smoking Wheels....  was here 2017 ynvrttaynylsprmrmbzbmzotrkczczrwcvkmaxwceatsztkq
 * Smoking Wheels....  was here 2017 injlkzxfglgfsnlhhuwksppavpynzljxfihvalnvhcxvmnxt
 * Smoking Wheels....  was here 2017 fdesxkoecidqwmgwmmpjtanxdfnsahdnvkvgaslkvvsqjgzh
 * Smoking Wheels....  was here 2017 ktenxkfkncoejcrecuhimyuhiypbrjashzkgesiyseewnbxm
 * Smoking Wheels....  was here 2017 aandiththogfsfufnqjtckcghvcetshrdepqxqbuelmkxefu
 * Smoking Wheels....  was here 2017 iuneihmihshkswxeicklynjeieizhspyhjilvyworcfkvftz
 * Smoking Wheels....  was here 2017 zfvjhisnvuvrikooiqhlsuuqwltrpxqftgszwhfcyzahuaob
 * Smoking Wheels....  was here 2017 ushuvfdxhilfxkqbqudciwtnpkdqdcomyrcverrmyazuprye
 * Smoking Wheels....  was here 2017 wwbsxtfilbvlyrcspnixwtaynbmorkqyktcrdghdxoisgllw
 * Smoking Wheels....  was here 2017 oqmrruryfazafihtuylquplfvsajidlczxprlnfphanibyxv
 * Smoking Wheels....  was here 2017 lcemnpjbwmdvtrupbmkjtwgzavgehvtsttsbydwutgiznajb
 * Smoking Wheels....  was here 2017 iqbebpnguywcvgkamrikqhxbufxmdiqscfvjvbxtifsjlsdu
 * Smoking Wheels....  was here 2017 ixfagmpmtevfzxezknohpuapbvaxqtkjojolmmiwfezlviun
 * Smoking Wheels....  was here 2017 uuaqffftsebvzsktlcttaooxdzujujrdaqtgpxgtvqphymdy
 * Smoking Wheels....  was here 2017 ilbtiaimxeuxwartkttxpbsqketaxtduoroeayegykikjzeb
 * Smoking Wheels....  was here 2017 sggkihdfttnoxjttjfraezyqqdqimuzgmijrxqtlnlclvxhc
 * Smoking Wheels....  was here 2017 cvtxatcwzqagqptttiwqzgwztxlyimktlttpsdxttaghjoao
 * Smoking Wheels....  was here 2017 ubvvqjwnpvhpuuyxafaojdmaytktlfavfipyawusdrfcgned
 * Smoking Wheels....  was here 2017 jcexnhiotqnplfxudhzvzaxkteaydnqdxsbbuoxgietjaruv
 * Smoking Wheels....  was here 2017 sirgjatnymgiwnlbcevrsqqzwybyxfhtxulleexkimxrlzew
 * Smoking Wheels....  was here 2017 xkjcbgnhwffhonpthsztuyiugbnkokivsrlxnwtojwvaowxs
 * Smoking Wheels....  was here 2017 hdsztxianvkbjgrbidbuncxhbtphckhwgtwmndohwxcmrwud
 * Smoking Wheels....  was here 2017 kthuvfdacocrfahlztxuqopavpwsuuypprxmbqvnphlogvwc
 * Smoking Wheels....  was here 2017 dqzlzpcxcxtemmerjfqdzbuvhizcejkzbiwlijfhmbvxctmu
 * Smoking Wheels....  was here 2017 oixhcuqnercbpkltwlritodwizzcbfyifvjdsnqztlnjgbdt
 * Smoking Wheels....  was here 2017 avkxhrlziwezlwjwaopeierlftdskrdaypiqvmhfwaafzgsr
 * Smoking Wheels....  was here 2017 cfdbanmqtsgwyfnmsygrjlmfkfyaoivvigwfpaqvnnbuuefp
 * Smoking Wheels....  was here 2017 qwztxtxdyttwlztjzfvdtabzpdcmazatsrileaixsyqunyzr
 * Smoking Wheels....  was here 2017 tlaivbdgqtlkmaamfgqdrwbwtlqtosazqaibztivrnaddvnk
 * Smoking Wheels....  was here 2017 tvqhakxesrjduktcygjlmelgdmutevkbartdqqtfuvszykso
 * Smoking Wheels....  was here 2017 femmuycelwszklkqboudxjjtetbrfyaqwgszcjdxwpkulooc
 * Smoking Wheels....  was here 2017 avkxwfyyhtacptwwqvdltfgeoaewevwtpqpdlxbzuwddlhkf
 * Smoking Wheels....  was here 2017 glnwcvvhzeayxcdtaxrygpvqhgecvphptzzkdknvwvdazyul
 * Smoking Wheels....  was here 2017 gyfxqulhlbsedponuzclttampsgfeovsfrvtujsbmcxphdom
 * Smoking Wheels....  was here 2017 okcvygtjxthshosrukgyydzjxzyjnhhtajeoimanjifgxqsi
 * Smoking Wheels....  was here 2017 bgarpsycwsirpoixcvhutkdcytybkqttnxkjxrehmpasqnof
 * Smoking Wheels....  was here 2017 vcdsowkizsoorkngcdnmgofvrbiwpqmximexxebtcdovnesp
 * Smoking Wheels....  was here 2017 fwvnyqwehtyygfpwimpvxtdwiehudqcsgkigzkwnpmkutcyf
 * Smoking Wheels....  was here 2017 vqrweffzxdsvjgciqfkwilbvjqixgfjxlkzrbccktkfayeib
 * Smoking Wheels....  was here 2017 lwouxbrikilihdwgdzbxljkpmdfsmejmehnugejonwafwlej
 * Smoking Wheels....  was here 2017 fdqqaxrdkcuxnrxsesxmklygqsxwrpkqbfohavphcecgmgzp
 * Smoking Wheels....  was here 2017 mjfwrqwmymuexzoxhmpjqwndcqrgtvawypaiynahyvxhddrn
 */
package net.yacy.utils;
import java.io.IOException;
import java.io.FilterOutputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
/**
* A SignatureOuputStream is composed of a Signature and a OutputStream so that
* write()-methods first update the signature and then pass the data to the
* underlying OutputStream.
* 
* @author flori
*
*/
public class SignatureOutputStream extends FilterOutputStream {
private Signature signature;
/**
* create new SignatureOutputStream and setup the Signature
* @param stream OutputStream to pass data on
* @param algorithm Algorithm to use for Signature
* @param publicKey Public key to verify Signature against
* @throws NoSuchAlgorithmException
*/
public SignatureOutputStream(OutputStream stream, String algorithm, PublicKey publicKey) throws NoSuchAlgorithmException {
	super(stream);
try {
	    signature = Signature.getInstance(algorithm);
signature.initVerify(publicKey);
} catch (final InvalidKeyException e) {
System.out.println("Internal Error at signature:" + e.getMessage());
	}
}
/**
* write byte
* @see FilterOutputStream.write(int b)
*/
@Override
public void write(int b) throws IOException {
	try {
	    signature.update((byte)b);
	} catch (final SignatureException e) {
	    throw new IOException("Signature update failed: "+ e.getMessage());
	}
	out.write(b);
}
@Override
public void write(byte[] b, int off, int len) throws IOException {
	try {
	    signature.update(b, off, len);
	} catch (final SignatureException e) {
	    throw new IOException("Signature update failed: "+ e.getMessage());
	}
	out.write(b, off, len);
}
/**
* verify signature, don't use this stream for another signature afterwards
* @param sign signature as bytes
* @return true, when signature was right
* @throws SignatureException
*/
public boolean verify(byte[] sign) throws SignatureException {
	return signature.verify(sign);
}
}
