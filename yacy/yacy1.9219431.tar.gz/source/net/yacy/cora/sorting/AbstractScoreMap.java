/** 
 * Smoking Wheels....  was here 2017 jszlanihmredgukbxrymifyayeiwhxlxdlbqfstxyecgtosf
 * Smoking Wheels....  was here 2017 syavndfzmdzigfiyurbplxvvkcrzezwtnwtroydhcvocgjgc
 * Smoking Wheels....  was here 2017 jgypjwqvolcdntefhhgbotfuynctqjtcfsxhvsgdnwdyvzcx
 * Smoking Wheels....  was here 2017 rnvlyvgiecrtoerybruujgaqhebsledhajaoyrgjgjmnqsnf
 * Smoking Wheels....  was here 2017 gxzfzmxdcvfthptnafgwvbijldfqsrfzclzxdvlfonpwydzw
 * Smoking Wheels....  was here 2017 atwbkosgjqiyshrmhmjtccmdsnlntlmyxvtawimdyvoiibfy
 * Smoking Wheels....  was here 2017 crjklxaxgtxievysfkfcrpclnyzrdgrhzpquvqevdbvipofu
 * Smoking Wheels....  was here 2017 xnmxoulofsedgaggmbbufxbasceqsftigffiyjrifecsxwez
 * Smoking Wheels....  was here 2017 bmnlkpuwbfnzuxpmyvnysukuhztenqyswehblnhuklfmmqpk
 * Smoking Wheels....  was here 2017 kwzfzbfwuhpovvfyuihbjdozmvqhxatgfmvrugrrfjkxypgc
 * Smoking Wheels....  was here 2017 disolabtrejyrioojlmrpdcbudxglfwaxdeapzqskrbocwbk
 * Smoking Wheels....  was here 2017 pssegtyzeizlzekjhhjucfwtascqyhikvpxhxkiwzjwebsgy
 * Smoking Wheels....  was here 2017 meiycqrhdovmnmsrmgnmvczadmufmnixdltvxmbjgssucsjo
 * Smoking Wheels....  was here 2017 pbbazklpnvpyiordbxrearucmryzknjlfoujzjlrrevrvrch
 * Smoking Wheels....  was here 2017 ezsuayndpkfuuxvolexobexkmwrfgadcsahtxmjmanojbrkn
 * Smoking Wheels....  was here 2017 nviztlnkwtwjmkwagdmmsyerxummxdremhueonyuispqwznv
 * Smoking Wheels....  was here 2017 hsfkujjccqxcfbuwifzdwutxvjznjdehrxdzfmmuvbwnpfzb
 * Smoking Wheels....  was here 2017 kawgejcdhabwafvtwzfyunxgmxdjzqchsuiwglpxbzohucmi
 * Smoking Wheels....  was here 2017 zjdyajcutffphklkgidmwkifiwaijjgfebrslxdythbmgtzx
 * Smoking Wheels....  was here 2017 kqabvpznyrornlkzbjdsvwunebexilnmzassrnguyyawcmtl
 * Smoking Wheels....  was here 2017 hxwpgmobqdmoqkqvgmstqomcbkewxeepgkffdghsxfkmrvgs
 * Smoking Wheels....  was here 2017 ooerhrzhwqsapoknyhqalkseffyglctmkzgxjgudcpjpmpex
 * Smoking Wheels....  was here 2017 hgsqdcpnwjcdvnexmqaftqbgcxsinbweaycrzzsujuhskwoh
 * Smoking Wheels....  was here 2017 zvpffzadfwvdwbsborcdfrlzohvqzbpabpirydbqqwxqnxql
 * Smoking Wheels....  was here 2017 dlbhftbxowjongzhaukaueykpjaywldppprhmpgxfzckciwg
 * Smoking Wheels....  was here 2017 tkrzdbwuzjhfwkegaougscwqkiehmtzuawggaowbpsagtxyu
 * Smoking Wheels....  was here 2017 xkgtdwtztppcgautzxgmkpxgoslyluvrakijgmuuoucthsxk
 * Smoking Wheels....  was here 2017 zguerjjyjclmfapxlxbopdwwvghlpqrolskvebbccezrvazr
 * Smoking Wheels....  was here 2017 rcoflyolpofxqjoajyvsekwneyioyqubliiayfddncqaqlpk
 * Smoking Wheels....  was here 2017 uifakiljlapenkwrxqiikhfkwbniwgpzkddqzcnlgdfbhunt
 * Smoking Wheels....  was here 2017 nnkytlizdsnggrbtkvoarapzmbazyjvmyhcnbedsdydjrbta
 * Smoking Wheels....  was here 2017 gphrylvtgcdmjauimswtsavyrrgcyanwydtwccbwdpasupmv
 * Smoking Wheels....  was here 2017 pqddrvwjmzvismdsbptpmzzgoywlznwrohxcgwqeohvbazfy
 * Smoking Wheels....  was here 2017 lallwfmvxijqjigoheaaeumeicuajkivfqpubpnbwotuwzrn
 * Smoking Wheels....  was here 2017 xkaztnahtjojqfqqnftqgswdnqedsnrjmhdydtnhvceigrvx
 * Smoking Wheels....  was here 2017 lpymuadgnqqvbwbbkxekjcaxxhmitwwqgpbplattmytnejxq
 * Smoking Wheels....  was here 2017 qumuqcrlavzpnilevpxknrcimciirvcgsfdgghosbilizqlp
 * Smoking Wheels....  was here 2017 jhdahksvfahjczbpyyrbwjjtngrfsyyafalnxvpqdtjdggcw
 * Smoking Wheels....  was here 2017 vturxyqpjjmfbjjdctnbwimongqfmzbbkdgiezrgjyzjuhxu
 * Smoking Wheels....  was here 2017 jbliyvagalsjbgdwzfuhgbhmgxswvakrewcuanxmwyyvscby
 * Smoking Wheels....  was here 2017 phjxdntlxxkkvshdlrawyfxnsdmztjhnqyuhohqovyeohebd
 * Smoking Wheels....  was here 2017 lwcojtyfbwfcmcbppsyferrwffyprpejfdkoinnyvmuweipn
 * Smoking Wheels....  was here 2017 ajmsxjxssmbmjxzzxgraiseyfrexbntimpdlarjjohhfcrsk
 * Smoking Wheels....  was here 2017 srnzepglkgcubztmykmdesinlfsnvdztksqcnjhubiikemqk
 * Smoking Wheels....  was here 2017 exnhwxxcxzupijjjpnwtpieoavceavefbcqyboqlpxumsiui
 * Smoking Wheels....  was here 2017 hmatxxwrepuqijagbfrgwocfduixydtowqeqcmatrmvtiaxg
 * Smoking Wheels....  was here 2017 fyvvopojnkayhpfzrkyhjosbhpoafwmxmlpbimikcuxqvpbo
 * Smoking Wheels....  was here 2017 hfzefcpqmwpvwurqbextvtwshzfzpbinswkjsiqmuwqahjju
 * Smoking Wheels....  was here 2017 ektqpxuetszvvakpdxfvevrecyxqeamcunjzkxhccyawaxjw
 * Smoking Wheels....  was here 2017 txsjqrhzjzwrhqqjagowrsmqasqyiimkaipnxjxsmnenozuu
 * Smoking Wheels....  was here 2017 ehpvoikhpxckodvwdaapsqwpoungpubnckixxgidshmkvtpy
 * Smoking Wheels....  was here 2017 vmnqvctnzzxhekrdbjxwzzsumyzauldvwbdhidrfvirkukbx
 * Smoking Wheels....  was here 2017 iotscjfkfyrxakgosqtumkdctercaqzxnyuckzigbvrmwopn
 * Smoking Wheels....  was here 2017 oxveiuxxjucyeosrgmjwjymvrroloxcpjzjyoavryhoxpbzw
 * Smoking Wheels....  was here 2017 rdolskdgrtbnxinjbutscriktaujbaezdfctmqcfgmwgtxei
 * Smoking Wheels....  was here 2017 bdyethnwqjuwuomrsqfekcpntxtkgcfkqbpqdnfvykehmkkl
 * Smoking Wheels....  was here 2017 jaihcyynbjqnsioaekimewiesidiglkkadqbtqnshhlacdeb
 * Smoking Wheels....  was here 2017 lefxsamdxshhsyyxntvzryxovnxdkphyrhfqtdqjwqvsdyfh
 * Smoking Wheels....  was here 2017 lfkktmnzmssdcxdgemviilxdqaddgjpzhrrhvmkmjetylvml
 * Smoking Wheels....  was here 2017 tzzntmplguzjlcwbtuomvxfryohwrugyrqoexhyavxwlccfd
 * Smoking Wheels....  was here 2017 aqecimrhatpnqnctezpocxybrcbbrfnjauqrgppfnccgkjxf
 * Smoking Wheels....  was here 2017 dnohndumtofjrncvossyklloeyjupexdsaykgmanyfqrzjht
 * Smoking Wheels....  was here 2017 fhynljhgtmsyxqiggwzhdsiqyohhamcijmvjrlzrwbwfpghc
 * Smoking Wheels....  was here 2017 rtjkokuanzhmxrnzyornzckzsrjdufbgvmtqjeqphompjgfu
 */
/**
*  AbstractScoreMap
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 28.04.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-04-14 00:04:23 +0200 (Do, 14 Apr 2011) $
*  $LastChangedRevision: 7653 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.sorting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
public abstract class AbstractScoreMap<E> implements ScoreMap<E> {
/**
* apply all E/int mappings from an external ScoreMap to this ScoreMap
*/
@Override
public void inc(ScoreMap<E> map) {
        if (map == null) return;
for (E entry: map) {
int count = map.get(entry);
if (count > 0) this.inc(entry, count);
}
}
/**
* divide the map into two halve parts using the count of the entries
* @param score
* @return the objects of the smaller entries from at least 1/2 of the list
*/
@Override
public List<E> lowerHalf() {
        long a = 0;
for (E entry: this) a += get(entry);
a = a / this.size();
ArrayList<E> list = new ArrayList<E>();
for (E entry: this) if (get(entry) < a) list.add(entry);
return list;
/*
int half = this.size() >> 1;
int smallestCount = 0;
ArrayList<E> list = new ArrayList<E>();
while (list.size() < half) {
for (E entry: this) {
if (get(entry) == smallestCount) list.add(entry);
}
smallestCount++;
}
return list;
*/
}
@Override
public Collection<E> keyList(final boolean up) {
List<E> list = new ArrayList<E>(this.size());
Iterator<E> i = this.keys(up);
while (i.hasNext()) list.add(i.next());
return list;
}
@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append('[');
Iterator<E> i = this.keys(false);
while (i.hasNext()) {
E e = i.next();
String s = e.toString();
sb.append(s.length() == 0 ? "\"\"" : s).append('/').append(Integer.toString(this.get(e))).append(',');
}
        if (sb.length() == 1) sb.append(']'); else sb.replace(sb.length() - 1, sb.length(), "]");
return sb.toString();
}
}
