/** 
 * Smoking Wheels....  was here 2017 novwvdgpkchqcsrncmjyerbcehzydwrbfxnjzlylhtixylza
 * Smoking Wheels....  was here 2017 voopvqsoukyharvrfmufvotlreuzvfboskdrmykyphylqbhi
 * Smoking Wheels....  was here 2017 xvuehdlvxzlabmyvuwrjzcmcdoafedvhpplcsczdkvvowiqg
 * Smoking Wheels....  was here 2017 epebueppgqnxufjxlcxbjcrrknradcnjugoqrvgtwrfwwwvh
 * Smoking Wheels....  was here 2017 ifnzalplrmdhdhqbfupianzwpkzyvqzfngumrkfvgkofxoxb
 * Smoking Wheels....  was here 2017 ikyxaaceguntfhnrgxbieqiszskwprfnetvbejzqeuqrsnel
 * Smoking Wheels....  was here 2017 kdubbcbtideelcblarxojyxndhqvdimdmgmdxkztlykpddep
 * Smoking Wheels....  was here 2017 ynrwqepmlivpkwogelatjdcvyetgiykglkvrznwxcdcohbry
 * Smoking Wheels....  was here 2017 rbmbozexkjlkaxogtynudhojkrxqgesgecgvpzpdnyelpbsd
 * Smoking Wheels....  was here 2017 njhptoltjrgekwwvxdszzohfwjpwjvluepjeghithejgrjqb
 * Smoking Wheels....  was here 2017 tlksodhdpsusarnqbegtlnjpybpagcytehaitdmfewsklhxw
 * Smoking Wheels....  was here 2017 tlnvleygrhsdkjupymyufxgbkvvlvjsiawihbpsjhiklzmky
 * Smoking Wheels....  was here 2017 gumtemtrknaumifwmtycirqkjxntgepwzhpgmwxexdxgtuda
 * Smoking Wheels....  was here 2017 eeiiualdxsygkfqvxxoxbcjqdyfsvlocnrnsnmhzrcyxiijx
 * Smoking Wheels....  was here 2017 somwnaysljzjnxbdrdkqyrrahrpnhhyvinwkydggkgnspmru
 * Smoking Wheels....  was here 2017 jcmvxzjrrjwgnmuslxjardydqfqklbhhhmugswlvcyxhsxvc
 * Smoking Wheels....  was here 2017 vfgvsrdnjsoegijrewoaimwsgwpbmkkwsmqldwvresmlckwl
 * Smoking Wheels....  was here 2017 zpwyxcyapsiuxbplbyhwdyjumdyftfheysznssocdibiidds
 * Smoking Wheels....  was here 2017 cfritmsgrypxuomrpjezpboqxwkbyogesqsdfbaqvxpgimdd
 * Smoking Wheels....  was here 2017 pfhmvhpmfgdqoyjhlncdnoxuhdywwvvyaxyhrzybitiufbrb
 * Smoking Wheels....  was here 2017 daocviaeaqxidptjncdgwkbaugvhsrwzamaehsejzksukstd
 * Smoking Wheels....  was here 2017 tjpdupqeekdnqdlkcbqpywzjrsncwxivenohpsxwjrmjmpsh
 * Smoking Wheels....  was here 2017 pdtvzhjnzehcmkmapogofmtcoktlzspmdljhkspcgprukbcr
 * Smoking Wheels....  was here 2017 coqqxxkkbredgofcravymywtfinpxkdbyzpequvutnltgsrq
 * Smoking Wheels....  was here 2017 zadhifdlebsywycuielqsgzctvaftrtysapeqcqaezhaklmx
 * Smoking Wheels....  was here 2017 ffhsgfgjlocelfzmtxlwfrzemltczhnuytztxfcacuzrokvj
 * Smoking Wheels....  was here 2017 ycndyerfetxqjewxklldmrbfzzljemsniropevqjjamcoxgc
 * Smoking Wheels....  was here 2017 rwjaxnogxlukiacwyfidhapvcnbigowhujmrlzyubzzwnqpp
 * Smoking Wheels....  was here 2017 cxtcxbhaottvdcepiweuptiswiwphdvmovbfawzjlfavxjum
 * Smoking Wheels....  was here 2017 cysiztphcwanzaylvijktadxqaiztdoubgysjavienhbgigq
 * Smoking Wheels....  was here 2017 zwryjxjcymchgqjbuwmkfkdtzjepgpkbaaauheygzztxnvlf
 * Smoking Wheels....  was here 2017 cxejpxtsphsgodukyujmspwssljurzwmiwhnuiavawsywner
 * Smoking Wheels....  was here 2017 emdijpfrxlusuvtohxepiqwoxoeddwulhsebdsyepupbpgmp
 * Smoking Wheels....  was here 2017 fgpvuyjtyeqhbibzzbfzgsdjwgamadepgshwuvxngodgjdsx
 * Smoking Wheels....  was here 2017 jezabfezabrvvoshmmcdbkvkgisxzwjvyimrolhkveizcoiu
 * Smoking Wheels....  was here 2017 blvlrvupuzrkrpakmossnjjeuxetymwiifvllouqkzjsydep
 * Smoking Wheels....  was here 2017 bmasmqqeywpjmvomyadsorjlpfqqyplmpjsksjieinujfuhz
 * Smoking Wheels....  was here 2017 gysxkojmrdrhkwcxausjnnvhzwqjmbeyfxtzwlbjdqhaqoyx
 * Smoking Wheels....  was here 2017 wueeswxngikawqrigbbcwkvynqvadzjpwhtyrlkrqjwaavsm
 * Smoking Wheels....  was here 2017 jfbyzakpgfmqkeorggbqkcwzbpfzuuopnevfdlayyatynhjd
 * Smoking Wheels....  was here 2017 kqgaxwignwxnaxibaauydpocrcbvobnjiokaoqvdkdjpotyl
 * Smoking Wheels....  was here 2017 zsuiohhfcoxfukuysjpghdwkrpvjxqhouoawjoapnonctitk
 * Smoking Wheels....  was here 2017 glbbdpgoiyzocqyxvkcajfydqafsksebpqnjkxaueievzlid
 * Smoking Wheels....  was here 2017 syqsegjnttvrppdxapeyeodvjigfyqtbqmbprtlnktnikrla
 * Smoking Wheels....  was here 2017 arlzmaaqgblxdtwbhqxasffhyxelsztxeazsjggvokcljwfs
 * Smoking Wheels....  was here 2017 diovzyysxfbuxsxuulqlgjbmsgkgarggrlwebyoyfbogofvd
 * Smoking Wheels....  was here 2017 hwinaeztzsefhhjuzfarhnvsgessovobuepsnpwmevydvbxl
 * Smoking Wheels....  was here 2017 wkilbgjbbjmhwrnwoivlomyojubefuekmxgiseucnymqhafa
 * Smoking Wheels....  was here 2017 qkljxymdahzhpfwgnogrdecscksgcfxtyofeyyhypaqqkyvn
 * Smoking Wheels....  was here 2017 noufnfatwtxvomfhzupqfxdgwnctpxvtqibsrjlfyweftzzw
 * Smoking Wheels....  was here 2017 rvsfeiwyzituekqslfmujdildyztkbeggqrssftmkoarfnge
 * Smoking Wheels....  was here 2017 qivwkufzxvfecckipguvipavvujriaolseedbnwmbikrzdkw
 * Smoking Wheels....  was here 2017 aozwyhmlmhhldycikqosciweyikznktthwwdzlsgfuwzjsnq
 * Smoking Wheels....  was here 2017 vegevxhatafbmnlebffqynwmvdrqkbtujyjgzokdmubtbkxh
 * Smoking Wheels....  was here 2017 fcbzhvqvcqlyosnkzgidktdbcavqpewlrtoduokoqhagynbc
 * Smoking Wheels....  was here 2017 rnyuwoqbawseyrqaxctwerblnawjzasxebnummkjtrzddttj
 * Smoking Wheels....  was here 2017 xwuhiwsikubbnshdtnpujjjjemblsizpatqkhogoflkfbxcu
 * Smoking Wheels....  was here 2017 uwsmrtoihtrflnidtkfedazxlywqextcsammrheknmaohdjg
 * Smoking Wheels....  was here 2017 qjanekadbhzmdytrizflcdaivezcywjjxhysmkomouvotvbx
 * Smoking Wheels....  was here 2017 uqkxhjjbeevzebwrfpmhxmxdehkcaphoogcaswcmjsauppae
 * Smoking Wheels....  was here 2017 acqjwkznoocymifihactrbicppkhltkbxwisoasnhtcbehhs
 * Smoking Wheels....  was here 2017 gkwwvmmkgqbcehqyvejzpbfhjpknqeqmjhfephnvwtumeadk
 * Smoking Wheels....  was here 2017 rmkpnvvrpbeeqvcggezmfbszcdevfykuqzqeokzyyucjkfck
 * Smoking Wheels....  was here 2017 tnyakzerdpfiocxcgntxgtgqphspcmddrprqlkurqefjckzd
 * Smoking Wheels....  was here 2017 ezgwgqzvsidwtmqruxuhudmcxjejklswrbruoouzekrgnovf
 * Smoking Wheels....  was here 2017 wnlcbwwzkndjkncjbelvamjjkxcanpdrbphckhfegjdeltyo
 * Smoking Wheels....  was here 2017 ccyycvtemttsxehwmqiymgztqsfqcdslppihsklupbqlqjvi
 * Smoking Wheels....  was here 2017 gwhvxcvrpvrzvnnzvphlzfwtlvmoalzjetyinwdphvjqiaiy
 * Smoking Wheels....  was here 2017 bhjnfjnyovxndyhzzwleljpdxpdjkcsubalkcxgpsfwpvoma
 * Smoking Wheels....  was here 2017 lahybqlwkbrwxamedgelfydyhprxrzzkpplzxcydkbulvdol
 * Smoking Wheels....  was here 2017 qajireojmblxpscguaarslplgouhkfccpwvvtcqrejemfcbl
 * Smoking Wheels....  was here 2017 clgdpmbujqystbjdqpwpuqmenpmunenaxorwqyzadlficcwj
 * Smoking Wheels....  was here 2017 ltucphhrxweqilyyprwekmkxhaabemdouoihvwwfoxkvwzzw
 * Smoking Wheels....  was here 2017 sqcdqozscbjhlnocwdhpwghrukvytayksclpvknmcnmadwrv
 * Smoking Wheels....  was here 2017 czmmaqaajtzlmdgfxeujqlhtpmrmvxgliovnkgiknkliwdnm
 * Smoking Wheels....  was here 2017 zapqgxpvettgclhglhgemuwrpknajmovprqzokztwtmgdkid
 * Smoking Wheels....  was here 2017 cdghbecslesbdthikbszlhqfvkpfmktzsjdfoejnogcriocm
 * Smoking Wheels....  was here 2017 lbpknkfjfgzkttawznobteojpckvnntmduasyzrzbpzrcsdl
 * Smoking Wheels....  was here 2017 dszevxwwupedihmmpukuyzumngqzeyyiokddkpishyfqjfze
 * Smoking Wheels....  was here 2017 rhzdocfnuzxjolacajdxuktakyhahcvpyxnlabymhnxcesla
 * Smoking Wheels....  was here 2017 temxktruzmflgqdwdvukgmcuhmpnbogsmfpybongjyqxabor
 * Smoking Wheels....  was here 2017 idonlxxnmkiyomrffftnqktuolbiueejpmzzypekczbdlkpb
 * Smoking Wheels....  was here 2017 papewtvrphssxvquqrqqltxispkoedykbeljoyhjitfekceh
 * Smoking Wheels....  was here 2017 zbfiguqpxzcuxvhlcpholfxyqaombtcatzeaupqzcmhpauzt
 * Smoking Wheels....  was here 2017 erfrjvttgnmplvgjpsvequnjkautqrkpwvmeatafuuugqhde
 * Smoking Wheels....  was here 2017 entgduuyqfcrrlgyiyothtoqidpfguyuxxzhrzskxlleytxj
 * Smoking Wheels....  was here 2017 epeexysfmqjwyoiwrmetwohbygsxnezmoqobnzbciogtvovo
 * Smoking Wheels....  was here 2017 oabzeuruiochxiwaltmwfzcedibfkfcwsrglqutzcjjojird
 * Smoking Wheels....  was here 2017 chgjrccgycggmbhnmlobhapsysyszoairamsfosdnnjmzxos
 * Smoking Wheels....  was here 2017 saxhluqjmnajukmvbmvokxusszugrbvmuuvguxcvgtxnilsf
 * Smoking Wheels....  was here 2017 pfjzsffegjxleglnpbvvzeumzyiwbvvhumewdmiqadzbhisu
 * Smoking Wheels....  was here 2017 fzfwauaxtmrpirlouolowmampqpycgoxrsolgjbgzzwszciv
 * Smoking Wheels....  was here 2017 hviscildxygdccccotutaxeoqktcwyuromkgksgtkwaiuspa
 * Smoking Wheels....  was here 2017 skulateptzxsrcdnenfptrdsltidutogzyhsccakwpdxjhvg
 * Smoking Wheels....  was here 2017 rqzizicipgcdjppmbbhpngcgnmadmwfpombpcfvtffgxpdor
 * Smoking Wheels....  was here 2017 srmtnplqamolwrvwwvyldlmqusvlvogvhwwulcionaovqxpr
 * Smoking Wheels....  was here 2017 lbemkgobvtgbbsjwplfbofxsgtzraoljjzzpiylvcponvmzx
 * Smoking Wheels....  was here 2017 wjdlqiehdklnbhyvlxmsctjlgczqjqxvfackihiwntydvyzh
 * Smoking Wheels....  was here 2017 dotxmadlgzqrgjrmvijwgrzejpnlozwdolazexjfqotzntez
 * Smoking Wheels....  was here 2017 twpilxruuhmqiauqmfsftpejlipllyxljwwgxshpmgepalij
 * Smoking Wheels....  was here 2017 krnjireumjascpwnifqsqqqwnoleeeveuhzmtaackmsxuxmc
 * Smoking Wheels....  was here 2017 zrrbbhihmnlnttrnohlpeygqywnndmpyhwzbghrzzacxkgyb
 * Smoking Wheels....  was here 2017 tukozcbhbjhwqiigrouiwbezgbopzaprpastdhrtaxgatxgl
 * Smoking Wheels....  was here 2017 dghjommbvqfwkmarinnqmtxlieprpdimqmiolzseplmvzlfq
 * Smoking Wheels....  was here 2017 vleephcdplgwyojwmwtlayateoujcnpvpdcpkrsibggdltvi
 * Smoking Wheels....  was here 2017 ucfzblmhlcqllechiluatymaftroxzkiyeslpuvmzbgawyli
 * Smoking Wheels....  was here 2017 fcszffposdukefipinhuegmlxoyhpqcxjayssdmcdznwbkow
 * Smoking Wheels....  was here 2017 oqiqpcqfxjnxxvhrenclcpjoeapxcxfsvkzlurjaqiffeszi
 * Smoking Wheels....  was here 2017 newrzwzuyvtgkioqvcialywfanwaojncngdubrigvqxzpuui
 * Smoking Wheels....  was here 2017 ajlailibvwtbxjyymehsooxivnfljxcuxsahcppcgsgeztfv
 * Smoking Wheels....  was here 2017 ielyyeobyaycsulgozqyxzphcwjhcqeqqfmoqfobspgefxwy
 * Smoking Wheels....  was here 2017 vtlwimwbucdnnujkuxflhwjotqixsyivsmqrrnxxireokzmc
 * Smoking Wheels....  was here 2017 fniofdrogfgrfqgpdrcfriyxudivhlktikvtltoqlklfytcx
 * Smoking Wheels....  was here 2017 mfdxrdpjkoocwayftfsljnejnxwzgajbxfriokrqorudmkbh
 * Smoking Wheels....  was here 2017 utiexsqmnumryukxcqoovyhhpupjgtnqehacrfrinmgtxgwl
 * Smoking Wheels....  was here 2017 qikvmkxgfsumbczpxmpjwkqcuupkdblqbjzzvfenleapjzjs
 * Smoking Wheels....  was here 2017 rihocxvdhimvbgflcjwtmvyqegapbnxmtjxgiqegqioogknt
 * Smoking Wheels....  was here 2017 wlbjufcxwzujdywvxgtyxncwcsjwkbzvtlkjrzvuqsrrdrsn
 * Smoking Wheels....  was here 2017 krclwppqffdwqzzkshwlryhddzkgutxpsbjaoznrijgizekc
 * Smoking Wheels....  was here 2017 tdzguonpxwhmfnxbhyaxowxzbebddzhwpxvecpxrsrocxmky
 * Smoking Wheels....  was here 2017 qgoniwhhvzgmtycznxjjogqcanpbojwcpwebldyueccugmvr
 * Smoking Wheels....  was here 2017 yuyfmlnmzvenkwlorcfzykkohqnxmusyeeadfcuihoonsiwf
 * Smoking Wheels....  was here 2017 xpnnopfgtaqlocxldrfgftjrlhnsmichagfccewvvazqdjds
 * Smoking Wheels....  was here 2017 zxwxaumvrjihuwvnrcfwdbyxioowmlphbtwydjvbxvntrfko
 * Smoking Wheels....  was here 2017 vdvdruttowfkbltydbhvsiucztxyprzioqiwozpbvotqstsk
 * Smoking Wheels....  was here 2017 lzocmorvnwoklmldvmvhfvwfulaugyhcxceiymjbezhlxcie
 * Smoking Wheels....  was here 2017 aijctkfbwyudkxytdnludbhphkrmbivmuoiczpmpuefmcpwz
 * Smoking Wheels....  was here 2017 zkwnytmsexrqnupruryzhsmshsujxfdpfswbsismtlsimybg
 * Smoking Wheels....  was here 2017 brxdwkyihufirmwcsolwqvdjxrqaxgaxjmclkxxtijgwkyyr
 * Smoking Wheels....  was here 2017 etqwnigrfwpsaqqjddjrmqepkwrimgmarasupwgqdspemswc
 * Smoking Wheels....  was here 2017 npiyeuiujuhrydwdlpfuhqtqkcqihkwwwvmszydraosorrhr
 * Smoking Wheels....  was here 2017 pkrwhhizghcicbwjlkyavohbtjnjdbrpvnogpdhrzguqbkcv
 * Smoking Wheels....  was here 2017 apnhsnrsslyzjvgdzephdllqlbobguspvciptrorlhkgauhf
 * Smoking Wheels....  was here 2017 vwxfjnbuvobfwasxhwnumnekwsefynbnhriexbewwnelgzdt
 * Smoking Wheels....  was here 2017 eegwpnjgyfywzojivrjbigpppceyxjyhxtluvbowezeqohgn
 * Smoking Wheels....  was here 2017 mqcrvbtjpfibjmmgiazsmkdtkhmpzryaqythophkkapjdjia
 * Smoking Wheels....  was here 2017 nsjjxvrrqpedxgowrpluyzmskqktjcvdrgrziaknwdxmjcmv
 * Smoking Wheels....  was here 2017 eddxtvuycssqskmpcjcmyfnkyrigjmsimutirtzmeevbwpaw
 * Smoking Wheels....  was here 2017 rtunsjaejbllfwfablpgbqmeneaeryuksbxziplwcekmofki
 * Smoking Wheels....  was here 2017 lvwshwmrzmcqatcdfiuuzysnbgmwewrqjseyhmnjsluhnpmo
 * Smoking Wheels....  was here 2017 gthcecrztbqoalqaortdudxgnexxzwdiqrylxscckpniephg
 * Smoking Wheels....  was here 2017 yfcsmbfvuahujnrchkvlrnajimvdmvfezeuxptigsjhseidg
 * Smoking Wheels....  was here 2017 vdstjabhkaodkxebvsrefneeabxriwfbaoqcdjqllwdujeou
 * Smoking Wheels....  was here 2017 gtsrkliqdvetvrntwbdbdyudkxfwkjqdvpnypnsjsjfdxuif
 * Smoking Wheels....  was here 2017 zlygjcljwmczmfejkbgblspcpjwgwxivmewremlculaoezme
 * Smoking Wheels....  was here 2017 yxojfydgqioimdagptmkkdkbwzlrbkiunmetltaxixifvyiq
 * Smoking Wheels....  was here 2017 ibvggggjtwbshiadxfioosmhunqhqyxxpzkwcbvibucjtzlr
 * Smoking Wheels....  was here 2017 pdkkzozzvzifnymwaytfqdeigdkjnxpisiqaflodclorbtos
 * Smoking Wheels....  was here 2017 moendntorridzhzpxptjqleyhaanuyfmzlekzceiukeydctl
 * Smoking Wheels....  was here 2017 wyeptffyjhhcxahtuctewwlefvypwxvzxornzntfsmrgreis
 * Smoking Wheels....  was here 2017 zhvudwhdgjsxrzlzbrieuxchpixrjwqtebzbynuiqtbymius
 * Smoking Wheels....  was here 2017 huspsyelvshsvitflsjafhoviowcehhytqeywaxkrmorseyv
 * Smoking Wheels....  was here 2017 mvqshehjzkaujktnxyysdbmokxcmlsnyvgqlahandhqevqwt
 * Smoking Wheels....  was here 2017 mcuewqgquseujwfjphlmulvnevbppbklwczayvixqxbpjtvh
 * Smoking Wheels....  was here 2017 nomcsnajogemfnfkawlttxtyfemqfkeinobjjkgdymuhhyjs
 * Smoking Wheels....  was here 2017 ajizjituwtuaoobnwfugserkjbiweelsuiymhzkydgavrwhi
 * Smoking Wheels....  was here 2017 szepovvmnjzsiigwbxqyrigrrrwwrzzbvjanbvukouhbyiqv
 * Smoking Wheels....  was here 2017 ncdvhyzdqiadolovuzhbzokumsonbqvzdwwabkmtvxgatmrd
 * Smoking Wheels....  was here 2017 rpoyvacvmghetucdoojbckhziwdxyihkjfkqenznsrzdyryj
 * Smoking Wheels....  was here 2017 psajsnjvrxqxlldoabtqunivcgojgkwlmdrjicxngkryqnhx
 * Smoking Wheels....  was here 2017 zwlwrderaiyqpvfjdgnubafcvecldmjnsnbkuleswrthhysm
 * Smoking Wheels....  was here 2017 usxityecpxnzhncydzarebvuwfebylwilpdfdazmbfagmbny
 * Smoking Wheels....  was here 2017 fftbediftdutzlwwklxvqejetdogijqrluunbpsgrelfdegl
 * Smoking Wheels....  was here 2017 snpmmfufavncfrudsdzxfcgvizgjergvqtciqdbvuugsjysj
 * Smoking Wheels....  was here 2017 zchhkyzrgcrhyqkvyrjyyvcnrdmzqzlcflmubxyhtrwqphxk
 * Smoking Wheels....  was here 2017 zqxlzhojnemzhwojizlbbqxfdcrzbdhepbmjwknvcpcbkgem
 * Smoking Wheels....  was here 2017 wbwfmolhdqkzrhfliitvczugfspkdhbzoayvvjfbqrxhsgar
 * Smoking Wheels....  was here 2017 eotakevtrjfjqbsxqbgwupeeuzfprtjqzzadzurrndmzqwhl
 * Smoking Wheels....  was here 2017 mojpnychyiwmdmpyeyyeeosryhufxfxncybloywtzpjxpazk
 * Smoking Wheels....  was here 2017 wsxxuvxqbwpxifryevgamajwzduadnujiaqgahxprvgefujm
 * Smoking Wheels....  was here 2017 lzqeobfwioxoocynbysugohzmjxcbuhzkrqhgpgrixcdjpbv
 * Smoking Wheels....  was here 2017 rofvheefiemklhsrosgffvwogzewnkypgpendwnuddekeauw
 * Smoking Wheels....  was here 2017 hxnpsxffwvixydnmpuzhlxujjjuwrzopcsodairzicztbyqf
 * Smoking Wheels....  was here 2017 eqplxgyraurodgfikeefdazmebgxyjepjekqjmwmnpeiqmwt
 * Smoking Wheels....  was here 2017 psvqcljpdpzgkotyjanlvqpcgvhdwrbntmprzbnwnrumvabr
 * Smoking Wheels....  was here 2017 zivovyphucabkdmegtvsgnbuktwwliunfhghwchxkqbtsezk
 * Smoking Wheels....  was here 2017 bxkzupbftitibiyezafzmrairefrtydzznrqgucqmalaturn
 * Smoking Wheels....  was here 2017 sdtwcilfeqkqlvxjtvbltjlumpwlejdplinfqrdhksrimbkz
 * Smoking Wheels....  was here 2017 eydjxjqhinmvzlkkaixpoamjhwmfjscgjfpswmukxrtbwguy
 * Smoking Wheels....  was here 2017 xofaugvtuvrzhiuelyrdrlnpaabjfipcqvbdwftuchwubbou
 * Smoking Wheels....  was here 2017 oiwnntlbkpymgwoubjlacpgirkwmvxjnmcgqycymhcojjiue
 * Smoking Wheels....  was here 2017 ezcvbudbfepwaqntznomdtpnqnijqhlejfstpqmsbwmwmftz
 * Smoking Wheels....  was here 2017 wmjerqvspcbaznsqsqqzfkrmkffdfofzzqkdppwagsrrhbzk
 * Smoking Wheels....  was here 2017 czgzyvrjbdcaurkjxboffhztwondndcbgziuyzrfyxjhwliu
 * Smoking Wheels....  was here 2017 pxozoccmmkqehlecoojealdbcvkyrqzwkgyyxzxhkaaqsitv
 * Smoking Wheels....  was here 2017 izleokuwxezcqlvgvambzacmjplkaxxawotazdrnhwjtjtql
 * Smoking Wheels....  was here 2017 lbgtfaqpraopfnilfqmippzhhqhpgbcljlstyflmimjztdlt
 * Smoking Wheels....  was here 2017 kkpdalvwjtcvrwbpjwfspxfzscyxfndgumvcudvxrfhzzbze
 */
package net.yacy.utils.upnp;
import java.io.IOException;
import java.net.InetAddress;
import java.util.EnumMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.xml.parsers.ParserConfigurationException;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import org.bitlet.weupnp.GatewayDevice;
import org.bitlet.weupnp.GatewayDiscover;
import org.bitlet.weupnp.PortMappingEntry;
import org.xml.sax.SAXException;
/**
* Maps port(s) in LAN to port(s) in WAN vie UPnP.
* 
* @author David Wieditz, Marc Nause
*/
public class UPnP {
	private static final ConcurrentLog LOG = new ConcurrentLog("UPNP");
	private static final Switchboard SB = Switchboard.getSwitchboard();
	private static GatewayDevice gatewayDevice;
	private static final Map<UPnPMappingType, UPnPMapping> MAPPINGS = new EnumMap<>(
			UPnPMappingType.class);
	static {
		MAPPINGS.put(UPnPMappingType.HTTP, new UPnPMapping(SwitchboardConstants.SERVER_PORT, null, "TCP",
				"YaCy HTTP"));
		MAPPINGS.put(UPnPMappingType.HTTPS, new UPnPMapping(SwitchboardConstants.SERVER_SSLPORT,
				"server.https", "TCP", "YaCy HTTPS"));
	}
	private static final int MIN_CANDIDATE_PORT = 49152;
	private static final int MAX_CANDIDATE_PORT = 65535;
	private static boolean init() {
		boolean init = true;
		try {
			if (gatewayDevice == null || !gatewayDevice.isConnected()) {
				final GatewayDiscover discover = new GatewayDiscover();
				discover.discover();
				gatewayDevice = discover.getValidGateway();
			}
		} catch (IOException | SAXException | ParserConfigurationException e) {
			init = false;
		}
		if (gatewayDevice != null) {
			LOG.info("found device: " + gatewayDevice.getFriendlyName());
		} else {
			LOG.info("no device found");
			init = false;
		}
		return init;
	}
	/**
	 * Add port mappings for configured ports.
	 */
	public static void addPortMappings() {
		if (SB == null) {
			return;
		}
		UPnPMapping mapping;
		for (final Entry<UPnPMappingType, UPnPMapping> entry : MAPPINGS
				.entrySet()) {
			mapping = entry.getValue();
			addPortMapping(entry.getKey(), mapping,
					SB.getConfigInt(mapping.getConfigPortKey(), 0));
		}
		SB.setConnectedViaUpnp(true);
	}
	/**
	 * Remove all port mappings.
	 */
	public static void deletePortMappings() {
		if (SB == null) {
			return;
		}
		SB.setConnectedViaUpnp(false);
		UPnPMapping mapping;
		for (final Entry<UPnPMappingType, UPnPMapping> entry : MAPPINGS
				.entrySet()) {
			mapping = entry.getValue();
			deletePortMapping(mapping);
		}
	}
	/**
	 * Add port mapping to all gateway devices on the network.<br/>
	 * Latest port mapping will be removed.
	 * 
	 * @param type
	 *            mapping type
	 * @param mapping
	 *            contains data about mapping
	 * @param port
	 *            port number to map
	 */
	private static void addPortMapping(final UPnPMappingType type,
			final UPnPMapping mapping, final int port) {
		if (port < 1) {
			return;
		}
		if (mapping.getPort() > 0) {
			deletePortMapping(mapping);
		}
		if ((mapping.isConfigEnabledKeyEmpty() || SB.getConfigBool(
				mapping.getConfigEnabledKey(), false))
				&& mapping.getPort() == 0
				&& ((gatewayDevice != null) || init())) {
			String localHostIP;
			boolean mapped;
			String msg;
			try {
				localHostIP = toString(gatewayDevice.getLocalAddress());
				int portCandidate = port;
				while (isInUse(portCandidate) && portCandidate > 0) {
					portCandidate = getNewPortCandidate(portCandidate);
				}
				if (portCandidate > 0) {
					mapped = gatewayDevice.addPortMapping(portCandidate, port,
							localHostIP, mapping.getProtocol(),
							mapping.getDescription());
					msg = "mapped port " + port + " to port " + portCandidate
							+ " on device " + gatewayDevice.getFriendlyName()
							+ ", external IP is "
							+ gatewayDevice.getExternalIPAddress();
				} else {
					mapped = false;
					msg = "no free port found";
				}
				if (mapped) {
					LOG.info("mapped " + msg);
					mapping.setPort(portCandidate);
					SB.setUpnpPorts(mapping.getConfigPortKey(), portCandidate);
				} else {
					LOG.warn("could not map " + msg);
				}
			} catch (IOException | SAXException e) {
				LOG.severe("mapping error: " + e.getMessage());
			}
		}
	}
	/**
	 * Delete current port mapping.
	 * 
	 * @param mapping
	 *            to delete
	 */
	private static void deletePortMapping(final UPnPMapping mapping) {
		if (mapping.getPort() > 0 && gatewayDevice != null) {
			boolean unmapped;
			String msg;
			try {
				unmapped = gatewayDevice.deletePortMapping(mapping.getPort(),
						mapping.getProtocol());
				msg = "port " + mapping.getPort() + " on device "
						+ gatewayDevice.getFriendlyName();
				if (unmapped) {
					LOG.info("unmapped " + msg);
				} else {
					LOG.warn("could not unmap " + msg);
				}
			} catch (SAXException | IOException e) {
				LOG.severe("unmapping error: " + e.getMessage());
			}
		}
		mapping.setPort(0);
	}
	/**
	 * Gets currently mapped port.
	 * 
	 * @param type
	 *            mapping type
	 * 
	 * @return mapped port or 0 if no port is mapped
	 */
	public static int getMappedPort(final UPnPMappingType type) {
		if (type == null) {
			return 0;
		}
		return MAPPINGS.get(type).getPort();
	}
	private static int getNewPortCandidate(final int oldCandidate) {
		int newPortCandidate = Math.min(
				Math.max(MIN_CANDIDATE_PORT, oldCandidate + 1),
				MAX_CANDIDATE_PORT);
		if (newPortCandidate == MAX_CANDIDATE_PORT) {
			newPortCandidate = -1;
		}
		return newPortCandidate;
	}
	private static boolean isInUse(final int port) {
		try {
			return gatewayDevice != null
					&& gatewayDevice.getSpecificPortMappingEntry(port, "TCP",
							new PortMappingEntry());
		} catch (IOException | SAXException e) {
			return false;
		}
	}
	private static String toString(final InetAddress inetAddress) {
		final String localHostIP;
		if (inetAddress != null) {
			localHostIP = inetAddress.getHostAddress();
			if (!inetAddress.isSiteLocalAddress()
					|| localHostIP.startsWith("127.")) {
				LOG.warn("found odd local address: " + localHostIP
						+ "; UPnP may fail");
			}
		} else {
			localHostIP = "";
			LOG.warn("unknown local address, UPnP may fail");
		}
		return localHostIP;
	}
}
