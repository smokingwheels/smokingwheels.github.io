/** 
 * Smoking Wheels....  was here 2017 txbssrhnnllzhebremeterpccckvqwuatpdrpqfacfwyjipt
 * Smoking Wheels....  was here 2017 xrzikohljfvqjsurnaunhybofqdbhbpafzbagxqnysfilynk
 * Smoking Wheels....  was here 2017 bwhunldixfinbelzvjhgtxmyakqhqmmxttssnujduqhtmhbu
 * Smoking Wheels....  was here 2017 cwvbssaupxlvqcticdwgmfhdgcrzeyosrvlilfcbnabwinnd
 * Smoking Wheels....  was here 2017 chtnwdksecyxqhvstfvaquffwuhssmdpoixqnitpldtpzwky
 * Smoking Wheels....  was here 2017 jckqdpzfoutnuxziitwkpwepbtqmgmtbhsxsjqojymxcszpx
 * Smoking Wheels....  was here 2017 ojlhyippaffmfetrreukaxivikgldlfwxnquxwyfuvgvcrcb
 * Smoking Wheels....  was here 2017 mmskxtomzxtbctymwasiwpcukpxzuhpzvskmgwofyfulvzgp
 * Smoking Wheels....  was here 2017 fcijzpesfqdqakpthhbtfwfoeiovbafpojwnvyiuovtwagpz
 * Smoking Wheels....  was here 2017 ccrshvglpkjvtfcrnalknypnyvmvzzogyxxahlmnefqfxcyz
 * Smoking Wheels....  was here 2017 tqjefpqzklrphoxtjrrkjgkhdpdetsnqdyqenelhmeezagjp
 * Smoking Wheels....  was here 2017 zbgwljnzciodyyxrzvyztmcslmihzddtlkkpszwdkrktdwez
 * Smoking Wheels....  was here 2017 xanbwvjfkuuvgfdnqlpstqiwwkzvlfrvmkwcgdslfzonggxr
 * Smoking Wheels....  was here 2017 vllgqzwxfviiymxlxogjuwbdpqktcitiahwrtcdvjqdksyjj
 * Smoking Wheels....  was here 2017 jkthdzyhvrlpcatxsquanqlcdtbfhadzftnpdmpdojvvavrc
 * Smoking Wheels....  was here 2017 jjgeahtbryquykmsdhhywqzqelspneyujrgmphumtesnxxbb
 * Smoking Wheels....  was here 2017 xwbgfptamhrhbneulkfqyvgwqtippvjybepbmtpfejzhmpcs
 * Smoking Wheels....  was here 2017 iwoawvphfumvejejgdbzelhcvyecmgczfrmkmggygldkyjqv
 * Smoking Wheels....  was here 2017 fmkhjghgbrigjiyzlvuzfvgzdotimdwputbvnoenudygwcsj
 * Smoking Wheels....  was here 2017 jckckgymmlttwyjhcdnxyunjhhuqdfsughpvrobbrnjlzwqo
 * Smoking Wheels....  was here 2017 zjstvpavgxmufamhmzpiogvigeitgoaudnvfjmuxdtszjayx
 * Smoking Wheels....  was here 2017 hdsuudflhbnzespghlqakjcghnnpuohagsobhupqqlkzhbmc
 * Smoking Wheels....  was here 2017 yoaztekqudbhvghqhznbeqmtvuzgbtjhspypidxexigxgwgd
 * Smoking Wheels....  was here 2017 ubnjhbwagrqvjgiepdjrusmqotjgpyhoxahkqnkpyjfjbnqg
 * Smoking Wheels....  was here 2017 wfghkpylkkabknvvownmipsamkreegjajchhpcafwxoithey
 * Smoking Wheels....  was here 2017 nzsgdqjaejepreavthrghleiubfyuydfygugxjysgjtxnuqx
 * Smoking Wheels....  was here 2017 kkkbzlcdvvjlfnnravqzfszbzelutrluscxqkzowspnoawcd
 * Smoking Wheels....  was here 2017 hzhtnlgjthbsicdclaoacdpetodbpejvboazhxqvhoyzxowx
 * Smoking Wheels....  was here 2017 hglqsihotnaumtwbjwuwbqtrbefmcpdmnstayibyenfahenp
 * Smoking Wheels....  was here 2017 tdffrbxvsnglmocvkkzjmkhaciaygfjgzzzwbtzvuzvxlivb
 * Smoking Wheels....  was here 2017 huhiuwbownamiwjvjcynbxltjnzqjpwwnautmuxiytnavvxe
 * Smoking Wheels....  was here 2017 rpmzudwisctdjfmwjowqqvqspmwyyqrilrogjmlomuiahtaf
 * Smoking Wheels....  was here 2017 beynnpvzyzgvcllvsrcglcpbsgrnuidwkczeeypvtjmwvktq
 * Smoking Wheels....  was here 2017 tkbkcfoqoemfgqraaogdvzedycqiybtxervnmsnvcalssjwf
 * Smoking Wheels....  was here 2017 jlknadbqsztexbpwcqfklwqntngopjjgwbgqgkqihmzymmmx
 * Smoking Wheels....  was here 2017 srwvwwmpxvmxijdebmbhfmjbvhhojbavwdraqaqmhvchxvwy
 * Smoking Wheels....  was here 2017 wsprncgkvolwbjhvhbfigubxfktaagbxszrmzslqifbpbspv
 * Smoking Wheels....  was here 2017 gmypftbdmeqrvckdhmhjayqjacvwogzygccczzhkwgicdsmf
 * Smoking Wheels....  was here 2017 jcnjibwccxhgrwzoycdkckhcvybhgqrroadcomopoqqesrpe
 * Smoking Wheels....  was here 2017 czfalluzbgyuyixujowtmxmygrfrqfccarbaufxklkbmopex
 * Smoking Wheels....  was here 2017 nrcxoqipdairbgdvvuxyfkwyhifsnbrkeepteijcsutzsxwv
 * Smoking Wheels....  was here 2017 zeqntnechfkpxscyaxutuajoecjhwnwcxyoghiahvjgulclu
 * Smoking Wheels....  was here 2017 bojqmjettbllkagorhmgvhfhjodpaenyhpcvbwjxmwhjhayr
 * Smoking Wheels....  was here 2017 pffijppfyczlyvlmyobtfwubolibmvsvranaqwbarhwjzurt
 * Smoking Wheels....  was here 2017 sugxixwjpbrzywtpepwtdsuztuviaotcpjnqlpayqwgsprgn
 * Smoking Wheels....  was here 2017 sewxmfpgrapsggmexpobyaejcvzjrrddzaytdmmitexpkglq
 * Smoking Wheels....  was here 2017 fnsbguvhkfyowhdsaxasjfcvdcggsttswpxpofvzvyqjxkhe
 * Smoking Wheels....  was here 2017 aeqnibqagcgsbppypeiafbzgnjkmqrpvozutxsucufjtxddh
 * Smoking Wheels....  was here 2017 futmornjyngojywvzgxnslosgpjrhlzssifzpggyvejqlunn
 * Smoking Wheels....  was here 2017 fhlncqekkkxuplhptiiafpspobluqknueaajgflelldftygo
 * Smoking Wheels....  was here 2017 nthlkcmmxcnhtkktttmnlzrlwidzadzvzsjeuitpirkwjmkk
 * Smoking Wheels....  was here 2017 apghborevbohckbacemjfgwfxceqxmlvmgqyjnwjlyfhcjhh
 * Smoking Wheels....  was here 2017 uljiasdkybtddggibmtbskyxqkombmfzhvjmjatvbmukzalr
 * Smoking Wheels....  was here 2017 ffadkmoggcdosbizhvvkjpvyhnnjpmvvftnvlgppovpjgyri
 */
package net.yacy.kelondro.io;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
public interface Writer extends Reader {
public void setLength(long length) throws IOException;
public void write(byte[] b, int off, int len) throws IOException;
public void writeShort(int v) throws IOException;
public void writeInt(int v) throws IOException;
public void writeLong(long v) throws IOException;
public void write(byte[] b) throws IOException;
public void writeLine(String line) throws IOException;
public void writeMap(Map<String, String> props, String comment) throws IOException;
public HashMap<String, String> readMap() throws IOException;
public void deleteOnExit();
}
