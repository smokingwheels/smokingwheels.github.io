/** 
 * Smoking Wheels....  was here 2017 vtqinofsepfjvqhpfcavparuhqvhvwvrworgddffttjolbyp
 * Smoking Wheels....  was here 2017 npdvyddeocszjfhqskfrgpuuejurukapdsbpzlosdtlnywoy
 * Smoking Wheels....  was here 2017 mrhpwfqgzfmipfpdjjywbdqaphmaszirpeepwleiusywwojm
 * Smoking Wheels....  was here 2017 siaavysspalmemgikojzucnmwqconpaltticvskggblbmjwy
 * Smoking Wheels....  was here 2017 lfmsqunksqxrzaovgvwyoauhqugtiosujnegffaxlnrwdvxk
 * Smoking Wheels....  was here 2017 ecapiimoyojjgddlrgcwoxfxsoplqkgrjwpincyykcqgnspe
 * Smoking Wheels....  was here 2017 pcitenkpdoojjhvfqfxclwrbgwgnbxqlaiubpukjnzonpcfv
 * Smoking Wheels....  was here 2017 spfnumdgknopzhqlkfmhxhlpoxkinbgrvubhkwuhkqbdlgjd
 * Smoking Wheels....  was here 2017 tcwpxqxjdrpibeyrkeegbwytheoheerelibcihwfxtuvoqwf
 * Smoking Wheels....  was here 2017 fmruopeewnebsehukeqeemwzhkoemtrzxgsxveoucivqpcui
 * Smoking Wheels....  was here 2017 uwfgbiqdnubokxnukntkugexqnizcpklkfehtzaxkolulqlb
 * Smoking Wheels....  was here 2017 momjzxgwejgvtbrzpvqosqanrteyxtcbmztdchtvjxctgnlf
 * Smoking Wheels....  was here 2017 nensbvfjfnabtsdylxrnzgyybopockkrvsdpfclyxcohnhou
 * Smoking Wheels....  was here 2017 jntekryuesxumdllswojwaorqqipcfdikrezplbybcwkvsxf
 * Smoking Wheels....  was here 2017 usuxgjeozrqtlwkpkcdnxbvjmalbpvhjmnbzbuuufdhjewuy
 * Smoking Wheels....  was here 2017 tbogeavjrifyfqdsscnpyvzyywedljhhnbdkqubpyrhqqyuu
 * Smoking Wheels....  was here 2017 leevydderxyqvnyhctelzxmqrqajwbrzgjblqjowejrzsnsx
 * Smoking Wheels....  was here 2017 kxanpgncowigitkfieqehhzumbtnglglqvskpphfygljbjrm
 * Smoking Wheels....  was here 2017 iitkmjrreybqfxhmkqwfmblencjngidzzzgxhzkrqnwbnnye
 * Smoking Wheels....  was here 2017 gugybopmqcgsdstknvzcipcrczerwrpersawucjiwqlojget
 * Smoking Wheels....  was here 2017 iwprfhlnhocuagcodmiuvqjnweqmevgwmcrkjwxrmhxpyccg
 * Smoking Wheels....  was here 2017 blhnxeqxutdhatwtatpjhbxcqjnqqhwakmcwplyjonieyuva
 * Smoking Wheels....  was here 2017 fnwomdyexkdzotxbdzrehytcoowexvpbqllwfgrimlyohkso
 * Smoking Wheels....  was here 2017 tngelhhyvmcxhbhutsrwpubmyxxixmtlsubhhyouwpgfdfit
 * Smoking Wheels....  was here 2017 waoaqbwdvgggdrjlhvzihehkkyeovnvbhrqgejheoqayyslp
 * Smoking Wheels....  was here 2017 cvfybdcypceogwqxnkfqpachviksalsxkkbchsucqpgrhsel
 * Smoking Wheels....  was here 2017 dbwbajtvytoodfaekuifcnnwhcqrgcmigoknokiomqgregwv
 * Smoking Wheels....  was here 2017 zaitcxrmyfmfikmpeokqpbrbdjdujlmvjzcixbhtsgmltoao
 * Smoking Wheels....  was here 2017 wiupzfeuasdvwolsiovucgazarjlnvfikuurspjbedttlfns
 * Smoking Wheels....  was here 2017 gvqovwqztqcwvxljoxgvyaietsemfsotkhiynepeygaowylp
 * Smoking Wheels....  was here 2017 wqmrwvtlzuccszioxwobqnlgmlmwawonocwsbecckwoczubt
 * Smoking Wheels....  was here 2017 sagirfnxvbelcocqncwdzeqdncpvykodjbvwkgixejxyybaz
 * Smoking Wheels....  was here 2017 apbfamcgqsngzqedzlqyapjbmdawcndkofunviadbnvtegcj
 * Smoking Wheels....  was here 2017 gggcyezszesymobxxykpbtglggntwuckdysbyobjfhhojdie
 * Smoking Wheels....  was here 2017 eaoduhusufnibvpyjyclqsizxldlaynlhvqcmhtqzwpqkuda
 * Smoking Wheels....  was here 2017 sgttazoxdsxiiewpobxdnxtouwbfkbtbntanmglbytglllas
 * Smoking Wheels....  was here 2017 dobnmolgjzdggrflzednuazjobwofjibosmlghwczpasyqwg
 * Smoking Wheels....  was here 2017 xtvieuwycluozqegihltsysxasgfvlcnjcxgioakekwmodrz
 * Smoking Wheels....  was here 2017 uysgmmpjeunaxmpcqutdwuxuhtheyadufnknonazykdzfzul
 * Smoking Wheels....  was here 2017 smpsvwngrzlptcohbgejaatzslgrnduioukdxujyubhsblvm
 * Smoking Wheels....  was here 2017 xypichxnahtpkljjdnchegrryfpgqcobcaogsfttrbbkmbpd
 * Smoking Wheels....  was here 2017 yedzhlcjtdzlavpeordasjlguucqukiywnrfmadbqjnbfqds
 * Smoking Wheels....  was here 2017 lfussexfugxybtctjcgxcoymjeuupweibxyrbprwbgxyddvt
 * Smoking Wheels....  was here 2017 lmnzwrfsepnbdaxksimpdfjfbnyazlkuezullpwhncsnlwec
 * Smoking Wheels....  was here 2017 dnkkqjfwikcafqjrdghzyzfrliatempcyxtryxjuxrtonjbu
 * Smoking Wheels....  was here 2017 bewuzwkuucdjkxbkjxgdsudhjivtnmoiiyuucrebhyybckod
 * Smoking Wheels....  was here 2017 xonifclylkkueiuqirhmbtdtylibrfjvpsahsimabcrgzzys
 * Smoking Wheels....  was here 2017 rzhixehbkiyjfsqsidooshjzoxwxqskcfbvevmrwvpiplkvh
 * Smoking Wheels....  was here 2017 obglvoezaayhjbyduckiubhetewtngdzwbwmtbnakfuxwfay
 * Smoking Wheels....  was here 2017 bpvoawnyxzzawqhslsmxnyqtlzdjtjmnoczqzfyexvyewepa
 * Smoking Wheels....  was here 2017 ysruuzajwyukcamoigrpmdhkshrtzvmaosjfijdgttepmhxa
 * Smoking Wheels....  was here 2017 dsqmrcpycwjisyoypjdblznbyhtddrmbitjcvdolljxstwmu
 * Smoking Wheels....  was here 2017 xgwglpnqwyadrkxluvgdmesxrmxalezkpiqkvmxeykxgekej
 * Smoking Wheels....  was here 2017 sctaeeeovqfgdtbwpuqawppjvovefvxehtanvlddgvgfksbc
 * Smoking Wheels....  was here 2017 hkyweqifwrtlnnwgbpeadkddmmpoflgqsqsbpolgvxdviumm
 * Smoking Wheels....  was here 2017 qmhexfwfzapslkkxiuatcandzmklhckjivcxfjgsebdpdyyj
 * Smoking Wheels....  was here 2017 yxzoghzoqwcixmykxfodubepyzwirywewjueyvizgzyhgriu
 * Smoking Wheels....  was here 2017 snjwfmekksqszadoozkgnmvwguqytqndhrqgjcnrbrpwiusc
 * Smoking Wheels....  was here 2017 rlchbtdfchcseptlgkmmujlsytuhdwlmvgwsgpdubjjpihjv
 * Smoking Wheels....  was here 2017 vzbekfupwmkgdxwhfdxlkeealeoqwsxwzaulrxnmtmuajlyt
 * Smoking Wheels....  was here 2017 ksjcyhiobpwpsavtxybblnmahmmkzkoalabpwzmebtouwufz
 * Smoking Wheels....  was here 2017 volyvqgghbafeffpcypjfibbkkhlandbgppmlywpcdtyndgv
 * Smoking Wheels....  was here 2017 xnxwgdfcjooywzvwtmjtetxxwxarouugpinvdfyqevptflju
 * Smoking Wheels....  was here 2017 ozqfvxevlcnrmdtxbeoxeeelaeyjnhufzcekzmdmxjprdbft
 * Smoking Wheels....  was here 2017 bnupiliiwwerysigounqghixmsnadgtrcygjiodoekomsmnr
 * Smoking Wheels....  was here 2017 vysyuidvgianlzcsymxbrybrdfpjufmtzgqbsrxpcxlepmlz
 * Smoking Wheels....  was here 2017 rkchnlhrkfwwimxifpppahilaqcldzatupkexfqmycozsbgd
 * Smoking Wheels....  was here 2017 nfubaatrmnrtiyvlpqtvbuienfilcotecuanxvulkmjjgona
 * Smoking Wheels....  was here 2017 qzzwdlrqvkskikepoosrwbnahktxwfgxoycgckawisrepmcq
 * Smoking Wheels....  was here 2017 lmzpwhowbiminenqvjdesaolcxfovmhzekmszcjluulhkpbi
 * Smoking Wheels....  was here 2017 twlioocrzbughusokkxtculcdsrjreyrfujniiyedxzaqxsq
 * Smoking Wheels....  was here 2017 mmhmsigvtnqfizurnieaxujyrakqihpocwcpftgdaouwlsqk
 * Smoking Wheels....  was here 2017 xwrqcaegszfkoucprxiwcrtdkhyuxctmotizxfyvglqofoqp
 * Smoking Wheels....  was here 2017 lxxrviicmvdkenfcnhzjaiiddgzrxchlqvydzyayynnbrfvq
 * Smoking Wheels....  was here 2017 xqstdclvwvcwnrzgdtbyeyapywpexdhunqbqeiqjmzrrrrna
 * Smoking Wheels....  was here 2017 fmxfpnldzxdvialjryqfkwamgjaqxfabsbcipyhhljrwlggo
 * Smoking Wheels....  was here 2017 pyqqzzoxgimomqxzqqezsvuzqetmapccxdsjnuqfsifkjmxi
 * Smoking Wheels....  was here 2017 oyizjdejfnsmdtzyuagljqbmxapmsuhxcgsdlzqtivjgdcnq
 * Smoking Wheels....  was here 2017 vmphaxbxtfnltxmgciuyzntsgxorpqtwnzhffxmwtcjrqeka
 * Smoking Wheels....  was here 2017 kzizmkcgyjyjzwmgtfxdivbpzzwfqculrdvmwfqsmqsdbyei
 * Smoking Wheels....  was here 2017 mzqqoboiefgmtrhngnzvkglhruarzmynhvzcqvutlceluzqo
 * Smoking Wheels....  was here 2017 oiyegnvibeyjfpmvjhqeorpggyvubiadhkpkexxrsmuonawc
 * Smoking Wheels....  was here 2017 jdwsyrqqkausteygbxvnhgletnhnmkepzmuaevejqatsfdel
 * Smoking Wheels....  was here 2017 wsiocsyajruncfrbnyqnkkfypqregsqmuvavshbcwdrlyndk
 * Smoking Wheels....  was here 2017 hrkknzxigjfberaxggmbytjvivmemobompxzccffeogmfupb
 * Smoking Wheels....  was here 2017 ewnbhfbusopucwonaxyfgfpevulhqlgxachtvnqltgmuqsps
 * Smoking Wheels....  was here 2017 ejisqfzupzrlhidztgzkuyvsfmqoiefvqxiwuxnsylrqegny
 * Smoking Wheels....  was here 2017 imqseesczplclvupswrekihjwcgentjwuxldxwhfhpinytwo
 * Smoking Wheels....  was here 2017 vvrqrolpgofxmjwyjqlmdakiidvrjmgxgefrojriskefksno
 * Smoking Wheels....  was here 2017 dhukdxolzlllngxulpxkgzwamhetgwrxyaoxgopvhwgqfxni
 * Smoking Wheels....  was here 2017 bwqcxfvdbwykbaugycyihhrdknfmwssfebqluugokdvdgjfj
 * Smoking Wheels....  was here 2017 nzbdnpfhpvrvslooctsvbjypnbhaearkkcucgucuptjdtjdn
 * Smoking Wheels....  was here 2017 tegcslvxxoyxknnjijpvqwfpkjwygbfhhhravjwwukskclev
 * Smoking Wheels....  was here 2017 gioxqlecpnfdiohklbglhsdnwetypjbxxyeqetlobbuxyjjp
 * Smoking Wheels....  was here 2017 tmppmlyjokhiwbrtkenbnbrdbkxbwtiolqlmaicstxyygeak
 * Smoking Wheels....  was here 2017 fziqvrcixeelrvttkhofegaijipmyfjvjevmksfpmkqzddsb
 * Smoking Wheels....  was here 2017 wmvplmvzybdstwvxygtwgaphiijtaarnltatrwopdipubthp
 * Smoking Wheels....  was here 2017 fsmilnpmhorqemmbtdsdcfelufypmserppwqhxajtpxirwvi
 * Smoking Wheels....  was here 2017 zwzzbrbgvinykenhvhkifzqnyxjabbwqdjnudfvxtkvwwlqv
 * Smoking Wheels....  was here 2017 dgeywefzrjtsctcwkhxcltfjcpwgqdcxmxjbemkjshuxwuix
 * Smoking Wheels....  was here 2017 yleupigqdwpcfelixzpjteigvuavidmijgapupnfnxqebkqq
 * Smoking Wheels....  was here 2017 vhkljwpivinqwueodmcemesoaemlqqtzuuksksabffiqbctg
 * Smoking Wheels....  was here 2017 owmzlqyoqkjbmddoadjxevhzutjdfkbczbqcxfexemeqxxxk
 * Smoking Wheels....  was here 2017 cniujvhzrddjtxirvmmgpqhlmrxdymsilzcoiulxbdqoqbsv
 * Smoking Wheels....  was here 2017 rvbnyvuogsavofekajwavecerlpxzdhlwokhyhlmqwngudzr
 * Smoking Wheels....  was here 2017 urazehxkzopxcheqixdidjmogueguwpngfnpgyfjcsuqywud
 * Smoking Wheels....  was here 2017 edxikcibtkpjuqejsleocjkhirsdbnruummddbxktvuzbimw
 * Smoking Wheels....  was here 2017 unozdlacqgaeicgxlpdjlpziggkvqbyxaeutojaxfrxugtqp
 * Smoking Wheels....  was here 2017 wlelerenzieqortwzcjphrsvpcvusuxqrlypwteeiaauaral
 * Smoking Wheels....  was here 2017 wscsomgmlaofrqfabeoiwohfhvsusfjbrqyapijzfuczzxus
 * Smoking Wheels....  was here 2017 pmyvquylwcxqdnmkqboatirfjlbvidmlhhxrnnugfejqcley
 * Smoking Wheels....  was here 2017 yarewrfbhmgxpbpjzjnfslbtedeclomjzgejraxcysjglovy
 * Smoking Wheels....  was here 2017 fzikbqfhdlwhyjxlozvvvnwyklneguarnrkhjrjbhbwnouot
 * Smoking Wheels....  was here 2017 wdjjiglhalfgjqalczdzjmvivzwuejxjwvmtdqfshfxnayks
 * Smoking Wheels....  was here 2017 pqkexlpmtdcpglslpqhaxlxmpugwvadufholujocjirktask
 * Smoking Wheels....  was here 2017 kuifijpplongioctfqlpewglabxteudmczaejlwibyttzhco
 * Smoking Wheels....  was here 2017 nfgcklqolwtnlzlxntangkjiugjwjzlgfymcevwvgtwgbghi
 * Smoking Wheels....  was here 2017 lrpsehfokphwvajtfcpzlwxorcjzwcwenmvorqmicsaxstly
 * Smoking Wheels....  was here 2017 wjadywzzejxawfshgzcignvwunzchxnoiggfuhxswanavuwz
 * Smoking Wheels....  was here 2017 voiuggxnufpaghmwxbqenrjentjlomrybbbxllqggeuaoqch
 * Smoking Wheels....  was here 2017 mwshxwedriqcwibapdqkgbxqmhdovbxdlaytzzihawsrjuax
 * Smoking Wheels....  was here 2017 kcomxkhakfotxoapdgsdunftnvadoecglkuezbynjbfzwcrc
 * Smoking Wheels....  was here 2017 fkmmotwpwncrtndplvtspgfcsizfkpgnjxssecrxozofanjm
 * Smoking Wheels....  was here 2017 zbkrlaxocfgydboktlwuopbslzjahjtoqhcipszqgchvzjrv
 * Smoking Wheels....  was here 2017 xslsirquophtxconowmfqhhshipajtedzqpbpwodideoeemf
 * Smoking Wheels....  was here 2017 mdzkfhkntatqhzrtpgfdeenodznabhhijjbisqjbvaelfruy
 * Smoking Wheels....  was here 2017 kmqymwaephjhqfvewyyxrktyczbzauelczrssnokdzpscyyp
 * Smoking Wheels....  was here 2017 rciqpmjkdietroadomvdzkeumnodeffbpjvdqbqhwnywzgny
 * Smoking Wheels....  was here 2017 nmedkorfvjkgicpddtgscufgybmaswyyopcsughexizrfcjb
 * Smoking Wheels....  was here 2017 kophxtjsevphsadzkvwtjnpvhhpjaheebaluselsgisbohog
 * Smoking Wheels....  was here 2017 dkegkzejcmnqhymuhanpgsgdrfydugabggyzehixjukivwjc
 * Smoking Wheels....  was here 2017 pivjmjawrhdfsprvazjypukdlbtpytterbzegfjwvdnzhalj
 * Smoking Wheels....  was here 2017 bzrhxicdgktjxaaqcnupljmaegohqcahzqgmgvhcmdxshknd
 * Smoking Wheels....  was here 2017 zddvrnxkljxmamdbgrkscjeftncxhvonffqhrjaflsnoortt
 * Smoking Wheels....  was here 2017 dxveevcadvhkmnwdlwdqbylkgvjlosndplffidtfacruyyks
 * Smoking Wheels....  was here 2017 nprrwkpsjvycyxfeyrdadnnnbjsejterpekdgwyfxtuvrlcw
 * Smoking Wheels....  was here 2017 hwsyorrkomcujrouextsksuttrnpwgczylvdtlhswjsmdtqg
 * Smoking Wheels....  was here 2017 yolvihthhjjzwclrxqpvclzofjrknsedqqkqjztibyktapcf
 * Smoking Wheels....  was here 2017 grkmldmulckkxrsacgqtvwconncrzykkxigfxxnbvsevfzug
 * Smoking Wheels....  was here 2017 eqohmjxqbsgcdgkaahxcijgsbgdodyeiejttjwbaubmgxgif
 * Smoking Wheels....  was here 2017 yzavekdrojfhluxhcqxtrqyglbfqfaatgvnkbtastudtmymd
 * Smoking Wheels....  was here 2017 apeapxremotlbptqdjeuenvolrdqorttbcnnotkuxuchrtji
 * Smoking Wheels....  was here 2017 dnqxasentaqjieudavrqifxhhaxnwrmpwrurpgkenirfithk
 * Smoking Wheels....  was here 2017 idiybaqkmrxaziaabpmxycjlgjuoccnwdmuvhwmbgwjxrfvc
 * Smoking Wheels....  was here 2017 tajskgftytuqycwyrnalcvqfyehgjeljoodaxohxybxecrum
 * Smoking Wheels....  was here 2017 yacceajuutvsiswrqrxjailygceiclbdfgsrylujsziahyhx
 * Smoking Wheels....  was here 2017 pfgfrgvxxitbotvgylbcisrkgemuzslmgfqkgyfjwtxrdypx
 * Smoking Wheels....  was here 2017 txqljcouinpoiyvatjoftlpmholwxyyaeeibwszcbwdpubjh
 * Smoking Wheels....  was here 2017 otljcyrjmlpoojemqhwojcrjatoccmdnsijubpuaeauptuid
 * Smoking Wheels....  was here 2017 noawxmrwxqhnkgnngioilqnnhlqfxvvawysyjvptfgwqpwps
 * Smoking Wheels....  was here 2017 kladbohrnvlehdpdpunwnedpeqqfatcvvqmdptqiqrqyhjnp
 * Smoking Wheels....  was here 2017 drileiknkxbnwvnrxhytldtnanvhjhgodhagubhvzvqbzorp
 * Smoking Wheels....  was here 2017 zybmygghxekvbiprrrdxfdtnmotadrxzlxakfqhtdkosdyvu
 * Smoking Wheels....  was here 2017 lzqcmyheqazpbxlyqavkddwajlebsnvduxizmqqufjmxjicl
 * Smoking Wheels....  was here 2017 fzrkaifqlfongcvntqvrthbqvfbntodkjucpillvnxqvptvd
 * Smoking Wheels....  was here 2017 hfbuenyjlrcqiswugeihvxmkdzsnfudgrmscutebtnnbalns
 * Smoking Wheels....  was here 2017 xhywsysgaryfftwfplqdltrkaiqrgnlnlbvqfkoyryyhaybe
 * Smoking Wheels....  was here 2017 nbsmqgzmsqoralkrpnmjwrfefwoqhhuhrvhocpodkbwoibnw
 * Smoking Wheels....  was here 2017 wpzuhiknkgtvgkhedtshrudhxpomywjwokgnftjpjeobuuei
 * Smoking Wheels....  was here 2017 yfqefjybfolqnjqcntloqpqultvjfgkuppcjrljncspiplrj
 * Smoking Wheels....  was here 2017 zpwfdsvznszktjsxeicbtqdujuywftnxnnmgsrjhljrcfnuc
 * Smoking Wheels....  was here 2017 lmzvebmmwewocrdmwohxkxisplprjxnfinhmxnfqpdujfvpt
 * Smoking Wheels....  was here 2017 barbpipbdsuwauswnwymcnehgpwvjlmbfeqsbkelvfhjpikx
 * Smoking Wheels....  was here 2017 vnujypdilgwidooiltdipwxlqoyocltariywezqytcppnjwj
 * Smoking Wheels....  was here 2017 zonizjhgeagekyymcchlypxjitkitdwvkbvzodjohlnvjlsg
 * Smoking Wheels....  was here 2017 zafvvfnzwloyzgldeyavmqylhxzyscrqmseltbhymhbbvibu
 * Smoking Wheels....  was here 2017 oznyrboakimihaxhrsgysdxknysisbgsawcxodpbrumnvbgp
 * Smoking Wheels....  was here 2017 suhdebgzxobjzzjhvybjmmbelduupbxppkagzatcnlgrnxvl
 * Smoking Wheels....  was here 2017 rzsyapxvsjnhzffsdmxztiuyqyvvpkgcwjookqkmwyfiikpl
 * Smoking Wheels....  was here 2017 xlegijxslflplzaihkjxwpvczamdbpbiwdpfhbowvhikxjsv
 * Smoking Wheels....  was here 2017 dhgfigzdyvnavunfibjmjlcjokvttllnuhhvlukgsqxgetke
 * Smoking Wheels....  was here 2017 juwepkcsieuotlwrkbajafvrsgdxmxshdqaiykktdnjgiwij
 * Smoking Wheels....  was here 2017 vpetyfkkxmnmeyjhbgtlxqlfbcxcnillqhktbvfvapogtggj
 * Smoking Wheels....  was here 2017 ynowkjjljeghfppvarduhorklowbfflagpjnifuekwleeqgn
 * Smoking Wheels....  was here 2017 nqqpgssenarrjxkkfrcvsemyasbugiuhfdahnajrqnhhkdrk
 * Smoking Wheels....  was here 2017 nihhbljilyvrfruhxxtdzvztcrsonswxbstvtujpjbqdsycv
 * Smoking Wheels....  was here 2017 ddrpoynvndaotxdapdnpdfszhykwgqdplneignmikegkmqiu
 * Smoking Wheels....  was here 2017 wyekwwqwjdstcwalamaimgidlgvlvqnljufepisnxuccjzlr
 * Smoking Wheels....  was here 2017 mvkvgdkwvprbrcfpchdsobuwspbgymbucdaynpeeffmmhzua
 */
/**
*  ConcurrentLog
*  Copyright 2013 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First published 2004, redesigned 9.7.2013 on http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.util;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
/**
* jdk-based logger tend to block at java.util.logging.Logger.log(Logger.java:476)
* in concurrent environments. This makes logging a main performance issue. 
* To overcome this problem, this is a add-on to jdk logging to put log entries
* on a concurrent message queue and log the messages one by one using a
* separate process
*/
public final class ConcurrentLog {
private final static Logger ConcurrentLogLogger = Logger.getLogger("ConcurrentLog");
private final static Message POISON_MESSAGE = new Message();
private final static BlockingQueue<Message> logQueue = new ArrayBlockingQueue<Message>(500);
private static Worker logRunnerThread = null;
static {
ensureWorkerIsRunning();
}
public static void ensureWorkerIsRunning() {
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
logRunnerThread = new Worker();
logRunnerThread.start();
}
}
private final Logger theLogger;
public ConcurrentLog(final String appName) {
this.theLogger = Logger.getLogger(appName);
}
public final void setLevel(final Level newLevel) {
this.theLogger.setLevel(newLevel);
}
public final void severe(final String message) {
enQueueLog(this.theLogger, Level.SEVERE, message);
}
public final void severe(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.SEVERE, message, thrown);
}
public final boolean isSevere() {
return this.theLogger.isLoggable(Level.SEVERE);
}
public final void warn(final String message) {
enQueueLog(this.theLogger, Level.WARNING, message);
}
public final void warn(final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.WARNING, thrown.getMessage(), thrown);
}
public final void warn(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.WARNING, message, thrown);
}
public final boolean isWarn() {
return this.theLogger.isLoggable(Level.WARNING);
}
public final void config(final String message) {
enQueueLog(this.theLogger, Level.CONFIG, message);
}
public final void config(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.CONFIG, message, thrown);
}
public final boolean isConfig() {
return this.theLogger.isLoggable(Level.CONFIG);
}
public final void info(final String message) {
enQueueLog(this.theLogger, Level.INFO, message);
}
public final void info(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.INFO, message, thrown);
}
public boolean isInfo() {
return this.theLogger.isLoggable(Level.INFO);
}
public final void fine(final String message) {
enQueueLog(this.theLogger, Level.FINE, message);
}
public final void fine(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.FINE, message, thrown);
}
public final boolean isFine() {
return this.theLogger.isLoggable(Level.FINE);
}
public final void finer(final String message) {
enQueueLog(this.theLogger, Level.FINER, message);
}
public final void finer(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.FINER, message, thrown);
}
public final boolean isFiner() {
return this.theLogger.isLoggable(Level.FINER);
}
public final void finest(final String message) {
enQueueLog(this.theLogger, Level.FINEST, message);
}
public final void finest(final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.FINEST, message, thrown);
}
public final boolean isFinest() {
return this.theLogger.isLoggable(Level.FINEST);
}
public final boolean isLoggable(final Level level) {
return this.theLogger.isLoggable(level);
}
/*
public final void logException(final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(this.theLogger, Level.WARNING, thrown.getMessage(), thrown);
}
*/
public final static void logException(final Throwable thrown) {
        if (thrown == null) return;
enQueueLog("ConcurrentLog", Level.WARNING, thrown.toString(), thrown);
}
public final static void severe(final String appName, final String message) {
enQueueLog(appName, Level.SEVERE, message);
}
public final static void severe(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.SEVERE, message, thrown);
}
public final static void warn(final String appName, final String message) {
enQueueLog(appName, Level.WARNING, message);
}
public final static void warn(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.WARNING, message, thrown);
}
public final static void config(final String appName, final String message) {
enQueueLog(appName, Level.CONFIG, message);
}
public final static void config(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.CONFIG, message, thrown);
}
public final static void info(final String appName, final String message) {
enQueueLog(appName, Level.INFO, message);
}
public final static void info(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.INFO, message, thrown);
}
public final static void fine(final String appName, final String message) {
enQueueLog(appName, Level.FINE, message);
}
public final static void fine(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.FINE, message, thrown);
}
public final static boolean isFine(final String appName) {
return Logger.getLogger(appName).isLoggable(Level.FINE);
}
public final static void finer(final String appName, final String message) {
enQueueLog(appName, Level.FINER, message);
}
public final static void finer(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.FINER, message, thrown);
}
public final static void finest(final String appName, final String message) {
enQueueLog(appName, Level.FINEST, message);
}
public final static void finest(final String appName, final String message, final Throwable thrown) {
        if (thrown == null) return;
enQueueLog(appName, Level.FINEST, message, thrown);
}
public final static boolean isFinest(final String appName) {
return Logger.getLogger(appName).isLoggable(Level.FINEST);
}
private final static void enQueueLog(final Logger logger, final Level level, final String message, final Throwable thrown) {
        if (!logger.isLoggable(level)) return;
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
if (thrown == null) logger.log(level, "* " + message); else logger.log(level, "* " + message, thrown);
} else {
try {
	if (thrown == null) logQueue.put(new Message(logger, level, message)); else logQueue.put(new Message(logger, level, message, thrown));
} catch (final InterruptedException e) {
	if (thrown == null) logger.log(level, message); else  logger.log(level, message, thrown);
}
}
}
private final static void enQueueLog(final Logger logger, final Level level, final String message) {
        if (!logger.isLoggable(level)) return;
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
logger.log(level, "* " + message);
} else {
try {
logQueue.put(new Message(logger, level, message));
} catch (final InterruptedException e) {
logger.log(level, message);
}
}
}
private final static void enQueueLog(final String loggername, final Level level, final String message, final Throwable thrown) {
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
	if (thrown == null) Logger.getLogger(loggername).log(level, "* " + message); else Logger.getLogger(loggername).log(level, "* " + message, thrown);
} else {
try {
	if (thrown == null) logQueue.put(new Message(loggername, level, message)); else logQueue.put(new Message(loggername, level, message, thrown));
} catch (final InterruptedException e) {
	if (thrown == null) Logger.getLogger(loggername).log(level, message); else Logger.getLogger(loggername).log(level, message, thrown);
}
}
}
private final static void enQueueLog(final String loggername, final Level level, final String message) {
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
Logger.getLogger(loggername).log(level, "* " + message);
} else {
try {
logQueue.put(new Message(loggername, level, message));
} catch (final InterruptedException e) {
Logger.getLogger(loggername).log(level, message);
}
}
}
protected final static class Message {
private final Level level;
private final String message;
private Logger logger;
private String loggername;
private Throwable thrown;
private Message(final Level level, final String message) {
this.level = level;
this.message = message == null || message.length() <= 4096 ? message : message.substring(0, 4096);
}
public Message(final Logger logger, final Level level, final String message, final Throwable thrown) {
this(level, message);
this.logger = logger;
this.loggername = null;
this.thrown = thrown;
}
public Message(final Logger logger, final Level level, final String message) {
this(level, message);
this.logger = logger;
this.loggername = null;
this.thrown = null;
}
public Message(final String loggername, final Level level, final String message, final Throwable thrown) {
this(level, message);
this.logger = null;
this.loggername = loggername;
this.thrown = thrown;
}
public Message(final String loggername, final Level level, final String message) {
this(level, message);
this.logger = null;
this.loggername = loggername;
this.thrown = null;
}
public Message() {
this.logger = null;
this.loggername = null;
this.level = null;
this.message = null;
this.thrown = null;
}
}
protected final static class Worker extends Thread {
public Worker() {
super("Log Worker");
}
@Override
public void run() {
Message entry;
Map<String, Logger> loggerCache = new HashMap<String, Logger>();
try {
while ((entry = logQueue.take()) != POISON_MESSAGE) {
if (entry.logger == null) {
assert entry.loggername != null;
Logger l = loggerCache.get(entry.loggername);
if (l == null) {l = Logger.getLogger(entry.loggername); loggerCache.put(entry.loggername, l);}
if (entry.thrown == null) {
l.log(entry.level, entry.message);
} else {
l.log(entry.level, entry.message, entry.thrown);
}
} else {
assert entry.loggername == null;
if (entry.thrown == null) {
entry.logger.log(entry.level, entry.message);
} else {
entry.logger.log(entry.level, entry.message, entry.thrown);
}
}
}
} catch (final Throwable e) {
ConcurrentLogLogger.log(Level.SEVERE, "ConcurrentLog.Worker has terminated", e);
}
ConcurrentLogLogger.log(Level.INFO, "terminating ConcurrentLog.Worker with " + logQueue.size() + " cached loglines.");
}
}
public final static void configureLogging(final File dataPath, final File appPath, final File loggingConfigFile) throws SecurityException, FileNotFoundException, IOException {
FileInputStream fileIn = null;
try {
System.out.println("STARTUP: Trying to load logging configuration from file " + loggingConfigFile.toString());
fileIn = new FileInputStream(loggingConfigFile);
final LogManager logManager = LogManager.getLogManager();
logManager.readConfiguration(fileIn);
String logPattern = logManager.getProperty("java.util.logging.FileHandler.pattern");
int stripPos = logPattern.lastIndexOf(File.separatorChar);
if (!new File(logPattern).isAbsolute()) logPattern = new File(dataPath, logPattern).getAbsolutePath();
if (stripPos < 0) stripPos = logPattern.lastIndexOf(File.separatorChar);
File log = new File(logPattern.substring(0, stripPos));
if (!log.isAbsolute()) log = new File(dataPath, log.getPath());
if (!log.canRead()) log.mkdir();
final Logger logger = Logger.getLogger("");
logger.setUseParentHandlers(false);
if (!dataPath.getAbsolutePath().equals(appPath.getAbsolutePath())) {
final FileHandler handler = new FileHandler(logPattern, 1024*1024, 20, true);
logger.addHandler(handler);
}
final ConcurrentLog exceptionLog = new ConcurrentLog("UNCAUGHT-EXCEPTION");
Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(){
@Override
public void uncaughtException(final Thread t, final Throwable e) {
if (e == null) return;
final String msg = String.format("Thread %s: %s",t.getName(), e.getMessage());
final ByteArrayOutputStream baos = new ByteArrayOutputStream();
final PrintStream ps = new PrintStream(baos);
e.printStackTrace(ps);
ps.close();
exceptionLog.severe(msg + "\n" + baos.toString(), e);
ConcurrentLogLogger.log(Level.SEVERE, e.getMessage(), e);
if (e instanceof InvocationTargetException) {
Throwable target = ((InvocationTargetException) e).getTargetException();
ConcurrentLogLogger.log(Level.SEVERE, target.getMessage(), target);
}
}
});
} finally {
if (fileIn != null) try {fileIn.close();}catch(final Exception e){}
}
}
public final static void shutdown() {
        if (logRunnerThread == null || !logRunnerThread.isAlive()) {
ConcurrentLogLogger.log(Level.INFO, "shutdown of ConcurrentLog.Worker void because it was not running.");
return;
}
try {
ConcurrentLogLogger.log(Level.INFO, "shutdown of ConcurrentLog.Worker: injection of poison message");
logQueue.put(POISON_MESSAGE);
logRunnerThread.join(2000);
ConcurrentLogLogger.log(Level.INFO, "shutdown of ConcurrentLog.Worker: terminated");
} catch (final InterruptedException e) {
}
}
public static String stackTrace() {
Throwable t = new Throwable();
StackTraceElement[] e = t.getStackTrace();
StringBuilder sb = new StringBuilder(80);
for (int i = 2; i < e.length - 1; i++) {
sb.append(e[i].toString()).append(" -> ");
}
sb.append(e[e.length - 1].toString());
return sb.toString();
}
}
