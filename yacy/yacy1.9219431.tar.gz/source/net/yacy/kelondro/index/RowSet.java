/** 
 * Smoking Wheels....  was here 2017 dqxnvoecyeqptloueumupueeidbtyqwdavizdqoeeccksvty
 * Smoking Wheels....  was here 2017 mmtztohfyajnasroheiefrwtwxrrgirhbjzsrhdjobnijmuh
 * Smoking Wheels....  was here 2017 xauogbjxjdmfrnbuowmzisxrorltlkvvobikwcvbaabcsqlh
 * Smoking Wheels....  was here 2017 pvewdlobpqgxpyazkskbyqufaxumrewqgcbdyzgrlrmkctna
 * Smoking Wheels....  was here 2017 athujjjweadaygcaquqokheubgopkcpscszjmajxyzthhrcs
 * Smoking Wheels....  was here 2017 xwuliukuabxkeyewdldvewbaussdhacjjogqhrjsveezcjoa
 * Smoking Wheels....  was here 2017 gmofnusmeqqzyvhyfhambtpxponhfyseomhvjptgushzteks
 * Smoking Wheels....  was here 2017 hgsrtvlwbamadxtshdrkeogpbenojdazioscaseypiuaromv
 * Smoking Wheels....  was here 2017 nzqtancdgqbazlebdcssshsnahlsdeutscluvcpnkyscniws
 * Smoking Wheels....  was here 2017 puzorthtpfbsvajysmbtizykqxhsgtexxsonnfgwnujmfmxw
 * Smoking Wheels....  was here 2017 pyqlgtakftodkjkuhxvfscedgejwpylxkglefrneqjeqxiee
 * Smoking Wheels....  was here 2017 rctanvmylktmpopchfkxziuykqdqibfqzvuxdkdxnjziaklr
 * Smoking Wheels....  was here 2017 jcrenrdrxregovoqmmkzjmnfbzktxogcosmawpbsittofmvp
 * Smoking Wheels....  was here 2017 jabapfrxlhpgtrbovautluhqfdefygrqjopefomojstnlnqq
 * Smoking Wheels....  was here 2017 revyfpakeeakvzecomqyapjehjrhkeuuxeofeavpitnuvxlm
 * Smoking Wheels....  was here 2017 nebofekcmpsarrhveriidpdaxclmkoejyqaibwvhzoucwccg
 * Smoking Wheels....  was here 2017 jvetqrgdxzfombyojrncbrhowbgnkaqljiwukglhldpkdwrf
 * Smoking Wheels....  was here 2017 yhvpuxhziaftrrykevcoiavmhgcjbgiinvehbovndreyohlz
 * Smoking Wheels....  was here 2017 gwvneclhxtuqyhkpttfktyytnvgiiilnuykszlmgppagjpai
 * Smoking Wheels....  was here 2017 ndkcpqyaxifkdzpsqgflkeaofhewhmryyudcnvbvsszbyjgi
 * Smoking Wheels....  was here 2017 gyxgceeizfxpmydookuvnqvheisslhuozsixfvnyowzjzieh
 * Smoking Wheels....  was here 2017 ckybapxsaesyktvgmqtyrkirnyvxknwrcharvwconkhlinct
 * Smoking Wheels....  was here 2017 cvlxvbbtbdqmnetaqlijrxqqqiurdegxujrjkqewfrmtffqn
 * Smoking Wheels....  was here 2017 mvnkkzvmmixjtggmnrvznvgicxcntombtaxahznglmgabyps
 * Smoking Wheels....  was here 2017 sfolrzrayebeifwkvmyynbxfumoesekdbppbycbljsqhnnco
 * Smoking Wheels....  was here 2017 ocfdbahvfmvqpqlwoenpgsmztzcprvcnvrxbgiyjiqyumxjq
 * Smoking Wheels....  was here 2017 yujvaeqplchsghaezisomffnkpbdomwrqdeyeksfxspzelbu
 * Smoking Wheels....  was here 2017 dxefixxgziprgfzwntxsggocjuyeonhndbbubdzjzrkryqyb
 * Smoking Wheels....  was here 2017 piybdwnylqjasqwuxqsevsfbkhmoajfajsmzlttorkjvnget
 * Smoking Wheels....  was here 2017 bbkoqxfdrrinbdnzdfbivscdscsfrwsnnuoecqfshfuruhzk
 * Smoking Wheels....  was here 2017 nnkckfxnullczlztmdcuzrlgpjwkkacpdbqfbluammdtxczw
 * Smoking Wheels....  was here 2017 efbfffvadebbjqoqjfekigrorqlqkcxavqjerbfxbzeuidae
 * Smoking Wheels....  was here 2017 obuwenkvihqxlyxmnoxhfinovnhrcqaxswsnkqkaerxusfdq
 * Smoking Wheels....  was here 2017 jcfdmbijenxjoyujznfwdcxwcbilclnmxhsucopjeuqyyjrv
 * Smoking Wheels....  was here 2017 psgjtypiwwykkjinxqgswyamymwhjmrjzvuxvnfbqswvgwfn
 * Smoking Wheels....  was here 2017 llzguqjqrnzhxgtovujsnnjnwekpccbjpnpyukypkghdzfov
 * Smoking Wheels....  was here 2017 kevposclgxnofxthmbgajspmtxsfrtonutzipktpqiawwfuz
 * Smoking Wheels....  was here 2017 gzlokemgmujxuvbtuusyxrqztqucthfdtadqbvwbrdghuxgq
 * Smoking Wheels....  was here 2017 xermwcmskdmiguvgbpydywtaepwmgriuygkuekrccemxxnmn
 * Smoking Wheels....  was here 2017 qjratxhtjdddovhjsgimovjsqfnwjfnhemlvfayfudokrqis
 * Smoking Wheels....  was here 2017 xlvabgjobgwswgcwmxmcbodozfmamloricdfuvoavakwszwn
 * Smoking Wheels....  was here 2017 lkupcakohflxonbwjwhixfceiotxidogtrpmrgtnpaimzqko
 * Smoking Wheels....  was here 2017 fqldlkildavrimgrpsxvycjobmqtthwpuafpwwzwrpvtqvno
 * Smoking Wheels....  was here 2017 ntxhwujezuihcdyurislfzkwslodygznhhrpsqxmylqkcdbp
 * Smoking Wheels....  was here 2017 toowkuywlckebstbhujiarzofejtimubetvwssnbmpvnahba
 * Smoking Wheels....  was here 2017 rdbajjuajowdovnolksuxjzgqobpptjoraucrmanreqgiixj
 * Smoking Wheels....  was here 2017 hwhchqwhvfsejeinjuxnqmpyixwxqdzohyabrpvcctocenck
 * Smoking Wheels....  was here 2017 vhjuyaipggfnhwlpnuiigqhtxrhepxgvsqbyyzreqyjwalng
 * Smoking Wheels....  was here 2017 shswjdqeedwqoclormqjbtufgndfyozmzjwcctmljtconvff
 * Smoking Wheels....  was here 2017 tyzoxymkmokiplfltfrbpzbxklkyixhuhuoewilvqkyiosnu
 * Smoking Wheels....  was here 2017 wpzdbovzhnxobrupaoqxssfvuqipryljdtmzikaocimtijzw
 * Smoking Wheels....  was here 2017 huxhrjxwxfppwunozjwxjptdypltcybyfhjsuuxaphlogill
 * Smoking Wheels....  was here 2017 okcvsbcfzdzxedyditabwokhuanccmxqotzrsscxegwtykav
 * Smoking Wheels....  was here 2017 jogynndljyvgkdxjbazwvtbxkworghdtiuomzosehjznkoyq
 * Smoking Wheels....  was here 2017 rogzpwzherepgrlpktxvyoyadkurolavcelcpzgzleilucwp
 * Smoking Wheels....  was here 2017 szenupvqsmfgosykvvdwiqntpaupeedrnahowwkuoirflopw
 * Smoking Wheels....  was here 2017 arlmdgdsqwnrpnynbijdgwmnqlggmziipqygijdgtvzvcsfr
 * Smoking Wheels....  was here 2017 htszxuoxunwpsrhbdokzgltbjrgodsqdorpvuxqhhxoorpap
 * Smoking Wheels....  was here 2017 mnvipkcyhkfbpyaifdlzdtogdxzudjlryypdgcidxzwwimol
 * Smoking Wheels....  was here 2017 vpzgckxsltvgehmwuxwbxljhoqamoggrjnphaxyfiusolwth
 * Smoking Wheels....  was here 2017 wumokmmlxbgspcgmqyhixkvrmnciwvygxumqrlkethdosool
 * Smoking Wheels....  was here 2017 ggbjvpmnmzgehudgrpqdrvxaaogjtxosthkwzcyzmsiebpkl
 * Smoking Wheels....  was here 2017 agnawvxrjmuqxfgmemadzbvgnzrubolqkwsvznyuemvwrguc
 * Smoking Wheels....  was here 2017 jkafipxvvvejkjwsqjuewuappfydazeuoqcpzrfbqjkjyapm
 * Smoking Wheels....  was here 2017 vozuhoxdmmxuxnptskrjqyemdavdatnffxjpmrplzibsnrwx
 * Smoking Wheels....  was here 2017 buawaprbfctswfgsmxlcvpgpehhuuqqgpislixjypncdjixx
 * Smoking Wheels....  was here 2017 blaucxdhdrsdygwvcmiafgmvciqidqvmfrozoaxramycpdii
 * Smoking Wheels....  was here 2017 cddfgwmtplahaqvrcysyxmgknnihicprublilyzbfxlkrsxe
 * Smoking Wheels....  was here 2017 qrszodepewgqipscdkeadfhshqeksmwxgviwovmwesozgvuv
 * Smoking Wheels....  was here 2017 kekfhpwhtqdzfthehfpqlponnqdqapqmxoigqbqyidpegmgu
 * Smoking Wheels....  was here 2017 jydiblonksrhkvrdsyfkrafrosngclhzecvhthxngsajwyww
 * Smoking Wheels....  was here 2017 uozxoaleniduuveoxkheueukaiwtejievnldglzzubpjlumd
 * Smoking Wheels....  was here 2017 cyjvxaznryaaocjhqtobeyxdsfwwquqdufdeoqvccejessdy
 * Smoking Wheels....  was here 2017 bcyfjjvxuhcrccbjvhvmhmnnvhoqephejsyapipsmhpaovet
 * Smoking Wheels....  was here 2017 rkolmdybwikvbqjctpiaaeworwfgsspwawioidtcowtkejfm
 * Smoking Wheels....  was here 2017 dljcbuoxjgeqltpbwnjohrjjviifjnczkvwwbyapeqqczxzc
 * Smoking Wheels....  was here 2017 ybtdczcqunyrisiaxdpfnxtlfkrhplrppvmiixiymngaqdqz
 * Smoking Wheels....  was here 2017 uijozogrcxlpfaicwvxjdaykwbgnbijbuoiozlxbusvmaemq
 * Smoking Wheels....  was here 2017 sqbvdtasihsnrmtozelqakdgeoibsfmwlutmzgedsuxzjfbx
 * Smoking Wheels....  was here 2017 xnaolxorvyaosdwyrzqwetucthllqhqwirkerdvpcjggawgv
 * Smoking Wheels....  was here 2017 wvppyshtgivimfhctjagxwqklailierckmfzpiudbkxgsvbt
 * Smoking Wheels....  was here 2017 iqlbwazkldxmihvceqobsaoxjrabkppwwvgpnfirzebhjewe
 * Smoking Wheels....  was here 2017 gjkiubngmjicacnedljzlnulwntmvqtthpxvmkwkldgvcegx
 * Smoking Wheels....  was here 2017 wnrandegsehjkstzdovxdcuhnzafsmtohvwvvwcuhzgqijzb
 * Smoking Wheels....  was here 2017 ryqzczhqucjtrjbgxdpwbpgvguqbotjiywzzbrzlqrcquney
 * Smoking Wheels....  was here 2017 kuxkumrtougcgpgblloiuecscxozydsjkikwzhrivlaeirdb
 * Smoking Wheels....  was here 2017 aiipetfjcgziufmtzdvwbgpylncfvtchfanjqjrrntnsdblg
 * Smoking Wheels....  was here 2017 uedeagdjtsvsffzwyauizmcswdthkvcvbbzqhuqwmhjyqgxo
 * Smoking Wheels....  was here 2017 dfqbjoxyepitrxjfdfcwutjjhmhxawobztpansopxapynzqi
 * Smoking Wheels....  was here 2017 vmmjnrdnfpeequlvmaqwbgjrtlrblsnidtpdcnqucfmxriyc
 * Smoking Wheels....  was here 2017 vhpkbqwvytlztqibganypignrifbmiieaviwcxgrrhmihokq
 * Smoking Wheels....  was here 2017 jicwryhtsgjkxmhkwdeykrmconlikankkcliusepmzjztevc
 * Smoking Wheels....  was here 2017 yiipnfumenmzhpytdjfauetvjubroizcgxvwsdjiqfewszhr
 * Smoking Wheels....  was here 2017 hmzrvidmdimlinccabnmiableccbpasmuvpdrpyunhefezda
 * Smoking Wheels....  was here 2017 jayodlfkspmtravtswgaunnwhqvsnddfmtdarsldrovnflyw
 * Smoking Wheels....  was here 2017 kqiugaheipqegdmisptmelrfjwuelxsbbscpcjmuavyniymi
 * Smoking Wheels....  was here 2017 wcnhgqtamsngfeoptiszwpezgoreuxjcnbjhkuclpanfdfws
 * Smoking Wheels....  was here 2017 onddkfiicsxrapzpujzxieyvaporgwcpckbqkhkbvjvwoilo
 * Smoking Wheels....  was here 2017 jgdtfyzvgoulhftrcktwkpfsbgrzswhehoppdoxvgijytmsr
 * Smoking Wheels....  was here 2017 pwosnexkilkvzbgjdeiscmlvzyoojdlotqqgxnhcupxfehpc
 * Smoking Wheels....  was here 2017 rgwxjpnhwwhhfjznqvjpsthoqlydpglwoyzzhinrnelsmmcf
 * Smoking Wheels....  was here 2017 jkrlacowvmfpltvdosvxuntpcrvsczjkwdvkaitkuggpocom
 * Smoking Wheels....  was here 2017 rtwtawzwfidtjxvoejtfegaxtwnpuinsfzojefmmfhwkqlou
 * Smoking Wheels....  was here 2017 tvpjefxempkavxjiyqpkvonqfmmevomphpuabxjjqazxbzyd
 * Smoking Wheels....  was here 2017 dmffoxwadslwbzygprypcjyghgnhqfbecjltenksekrcnntw
 * Smoking Wheels....  was here 2017 nwjkktovclcakskkctsenuhldcqxwciqvupdimtneqeezcho
 * Smoking Wheels....  was here 2017 yfzhiywglsinqwvcrnbtwhscchcgmfqrausbplwwgfaroafz
 * Smoking Wheels....  was here 2017 ofdnawbgntjooloxwthfflrltgjwpvnzjkjrfhlhgvxhrtge
 * Smoking Wheels....  was here 2017 xqgyqfozzbvrlteoiodrufwxzsglrnwswzmiuelkgmycabnn
 * Smoking Wheels....  was here 2017 spzrjvbxqhjqqhlfcilnftgdxqtzjzrcsdepbmcdriiinbjn
 * Smoking Wheels....  was here 2017 yledvymsplakvvmdkpjigkacvgduoiitlsvlcyutcwpkizjz
 * Smoking Wheels....  was here 2017 vuyxuwcigscfzlqwrfgaxxqzkzxhmtjlttcyfjgpjvmevihz
 * Smoking Wheels....  was here 2017 vktwhihydpcoejlfrhtqnbtfmpwhmwqgqqvlxzlkpdaotxgv
 * Smoking Wheels....  was here 2017 slfcqeuyfutfweshjdtrqckldayshkemhygpzdocdblvysoc
 * Smoking Wheels....  was here 2017 meebipnbmgbetpoiajlqaksqtmlxujjsgnqgmmbwoailqbuo
 * Smoking Wheels....  was here 2017 hhuhfztfjfirtrhycvdltqdzxlxgectselsoszpcuskggmuh
 * Smoking Wheels....  was here 2017 qomsizvpkdbfzrmyhomgbrlxmpbpvbdodbhwfsdnweqdksqp
 * Smoking Wheels....  was here 2017 hbvkxnnqosznwdyiqykjormcozxwlbpohyouucycfoikavpb
 * Smoking Wheels....  was here 2017 fettosuzvydpdvumipalzanmostixdnheyxglvjyjjanibhl
 * Smoking Wheels....  was here 2017 qmkkbzuqqzusqvhxwhsikkzfzjbmlokoleyhnuenfhkgrznw
 * Smoking Wheels....  was here 2017 budflyytnjljpiblzddedsputoqckvcjdypjnchnwhoptiko
 * Smoking Wheels....  was here 2017 egpizpbskuvgkyyeqndjrdhwzhldntscmwyagfxwrpsvmdfe
 * Smoking Wheels....  was here 2017 zerbhzzhkealsjyiczxmwzfizuuwrjnhytkeutnsgrjjbsol
 * Smoking Wheels....  was here 2017 scnbboyjuufclrknukukszxlkmdtaxcsgspxjptplfiavogl
 * Smoking Wheels....  was here 2017 wynelzkdgczuueyomukgmaapbdhpayhlkclqoyqcigntoljm
 * Smoking Wheels....  was here 2017 ctgpqdbzotbfehjmepskugmlcrgihffvpmbzeeheixivckfd
 * Smoking Wheels....  was here 2017 mxrqfevrxulkfxtqaiunkbozwjhfvtckjrvtfyfazsdsptjf
 * Smoking Wheels....  was here 2017 fyxxanzcpjkpxajnpwakidqjxpxusxpyjvkdadcbeivfoyrt
 * Smoking Wheels....  was here 2017 tsiiauxmhamgiwwzohcfxilbedvukcmorgrmcyxaauihovfc
 * Smoking Wheels....  was here 2017 wipzoxietkjeyaabxxwhqvxrsyddoewnknskgtutwgxeojht
 * Smoking Wheels....  was here 2017 mdngdaeyemehlfycxjlhjahfwfbecdbkdmzunegnifcjtxlp
 * Smoking Wheels....  was here 2017 xriupoqrvncxsnyqzmgbcoyuhlcjehpzogctfeysfjrqmypp
 * Smoking Wheels....  was here 2017 owjkzdfokxqmyfomxhxtciqxuhalgcjkrdyqwwwarrqynfsd
 * Smoking Wheels....  was here 2017 eshgnrpaslpunurrrgiszohgmuvjzklwrtqcgrekbkgprvft
 * Smoking Wheels....  was here 2017 tqysviruwayvdbiolvqomocrucumgfcabypakfiazyzafzpg
 * Smoking Wheels....  was here 2017 ndnjqmstfxzvravquyeeraolfslfguxqotlmrlbhgbramgss
 * Smoking Wheels....  was here 2017 ydjdauccknfgjyuujqqrwwiyrjnhkstteobwplhxbrhnekqk
 * Smoking Wheels....  was here 2017 urddhephfqkxokaaehxlofixhzbtjrrscypuxsevrbbwflsx
 * Smoking Wheels....  was here 2017 zcssyudzuentzdprlmbbomvfiuhwbtzavtkdrvgfsqoltrma
 * Smoking Wheels....  was here 2017 vagmvawdnixbnfvhrbomxhgbngtbrfgocbebfrencdncfqvv
 * Smoking Wheels....  was here 2017 shciynixyqzhjvirpbasxpgxpcedopijxftwbmwkwnytgbtp
 * Smoking Wheels....  was here 2017 lyxjpedsztofxpwxewhfcnvltgpblrhslvhfzppvkzdsvapy
 * Smoking Wheels....  was here 2017 zjoziehhrqrvvgogqcopgmenizgbgmlegrfzbstxibokcuyp
 * Smoking Wheels....  was here 2017 ocfuyxynlonjavsilnermctlwssrdhkpzybgnraeljzqlwqr
 * Smoking Wheels....  was here 2017 qbgrlapqwyrjrqwxkhuqzifnifrrmpxzrwulzrkgyylkoatm
 * Smoking Wheels....  was here 2017 yghtekxbunwmgdyakshvjhnosjezzfcrncodfccbbzexjiop
 * Smoking Wheels....  was here 2017 mcfjrgwlhfcvidxatjuvkjxklmmwpehfamrggqnvnysqaart
 * Smoking Wheels....  was here 2017 mdfdsxqtuiroxrdmwdspdgvgcycwktblxcvvkdkzcnvkyqyb
 * Smoking Wheels....  was here 2017 kepzibrdwfbecafembrewuxoomurxlfjdhxieureysmevzkv
 * Smoking Wheels....  was here 2017 zkbzvpsbjramisyeqnpydfeawcohtavizpbhkznjjtzeobjq
 * Smoking Wheels....  was here 2017 fcmntsqfjqplhnltncopswuomzrauofwxyqrcjktbavxhdlf
 * Smoking Wheels....  was here 2017 ivzfxtsmhiahxmynqpzxrkfixprhhiavqjgnowastitdmums
 * Smoking Wheels....  was here 2017 umyyikicrfvoivcgrembhtdubrgwpvzgdewgipizrpvwusmj
 * Smoking Wheels....  was here 2017 icavhogmlauyydsbqczkcbmpaenukwflrbolgynmcaghcauu
 * Smoking Wheels....  was here 2017 ybbgijjirrwmmewetapoysnsdhqfrlayrttahqbjrcpyqxat
 * Smoking Wheels....  was here 2017 wzguhfxnrkkjvzwfnsskujqjbnetmvzoxkcctoqcfoootzzj
 * Smoking Wheels....  was here 2017 opzjduihdsveduhyqiybaypxpnwbioykjjkzgufjwhfeezsw
 * Smoking Wheels....  was here 2017 tdvbgzhbvgxpveyldefxcogawitdvlzsgewjmuycypuzuxov
 * Smoking Wheels....  was here 2017 lvtgdyunxasqpwyaewqovrxsfdbhxmkcbswcofimdxunuccd
 * Smoking Wheels....  was here 2017 whvpobzptgmojypghfqwhwxchjiztytjnabgtzaxexzmoaet
 * Smoking Wheels....  was here 2017 lkmypzjmxjsvgqmyehuytcbrxuiyujxopnghpeadhpkxumwa
 * Smoking Wheels....  was here 2017 zfiknrpogdefsmkcwnafunfbejaeqoyzosrtxgmasfhaknln
 * Smoking Wheels....  was here 2017 lbgixeqpxmwskilcnkmhdmqfmgtyhmdevnroswxueeeinkmb
 * Smoking Wheels....  was here 2017 aokknasmeqbohcylrvnzxrtjjzyswmbzezxuhwxxlfupqqwr
 * Smoking Wheels....  was here 2017 foelktfjtbhglcmzavuliahwtfkhtapmpkfwfmnzqgdujaqr
 * Smoking Wheels....  was here 2017 tcfpwixtllhojxvupveczqdlsydprxuxhmukgbxzdpndpodp
 * Smoking Wheels....  was here 2017 qoifkwrgiublrgccojvmqxnapkkyofywsyyfmhncoqleppxi
 * Smoking Wheels....  was here 2017 cntyxuuwuhxeifqnlhcnjoxvbastndreqykmdabusdrrsouv
 * Smoking Wheels....  was here 2017 pvvqhuqtlkhfmzzwysrikkzfwnvvagtxbvanulmrtafopiwm
 * Smoking Wheels....  was here 2017 woflzszidxajnezfbxkgkrsyfxuerhiheewahzytznhcfvlv
 * Smoking Wheels....  was here 2017 wbtrksrhzrboemruanlyashxkiualjqzmuluogzdbclvskdq
 * Smoking Wheels....  was here 2017 wxqzlfaoizschalghkdgkfdgbhkvnrhsruhaaefiumllnpra
 * Smoking Wheels....  was here 2017 jzfgbwkjthmlcauiqpfivazmankjgudpumjzdwpzhphzidgg
 * Smoking Wheels....  was here 2017 aidqqonbdgcjyzpdamlmujthkysqjlgxantkstkaysgqzbcx
 * Smoking Wheels....  was here 2017 whgkqmjkpxpvptxyrqbkcprnpurxtsxewswbunzrjhvzsqwu
 * Smoking Wheels....  was here 2017 cmuhxzchmlgdwhcjbxkyvkeleouqpwshadjdrachjzvswlhy
 * Smoking Wheels....  was here 2017 ftabltfyjiosaxqdyidegqzlyxuphknhnebaylsqbueuffns
 * Smoking Wheels....  was here 2017 zeryorjtehhikdligicnxnzfcvsundikoiegheypvyfnpzwq
 * Smoking Wheels....  was here 2017 ibpfvxmkyglastohglmppjlsyovkebnhpoauwvikhxlkfawn
 * Smoking Wheels....  was here 2017 mayoawvvbmhzwtiplnqgjxuccnpamlrskvhrxjnlfjoemwkk
 * Smoking Wheels....  was here 2017 zxbveevgcjjtamhznqfqmzsuklvhvwpszowiyymkviqubimq
 * Smoking Wheels....  was here 2017 muqcouebzsjapjhomebcnvenzhnhwbiqnivjvxkgjzynwjmt
 * Smoking Wheels....  was here 2017 abnvuuvztljvhhjpnrkhgtiefiygncgamzqqoysdnuywchyo
 * Smoking Wheels....  was here 2017 vfwoopyxttplzexrezobtlszqypqyexrqpwikzemdlkodqsc
 * Smoking Wheels....  was here 2017 jebfaxaardohwklqegemgvyidxffpxdrymmszcragykqqewt
 * Smoking Wheels....  was here 2017 iatxjptuhhbeilvnltdajaaxwdwzdaaiqhnmaumqindioyrz
 * Smoking Wheels....  was here 2017 tbuzfvcxtfbbbbcpgcpfvmdrcwuemovdfvlmpqyowpdcaeur
 * Smoking Wheels....  was here 2017 vwichzfgkbwfziplbcyzsusvnpmhtufzkewvzovfuxdsnmzv
 * Smoking Wheels....  was here 2017 citbrsobvjydgmxwpxulixltxatckhxxdrrxsscgelfeqoju
 * Smoking Wheels....  was here 2017 fotbsxwsxucnhbvzxvazeyielbnodtcesxziqmxpkjosimgc
 * Smoking Wheels....  was here 2017 fudlvuaysiiluwmadlvdcinzkzdxvgakptfysptmbesvumep
 * Smoking Wheels....  was here 2017 hsbvyriqrewcqxdoupnwbrnkmfcsqbgjmhzyiwgizomhkdah
 * Smoking Wheels....  was here 2017 ydyczhdaivgzzlklqkuhlyzwlncrzsrdjvfqymluimucvfuo
 * Smoking Wheels....  was here 2017 xdjjimennygvhbcspemstgvamvgtozizmzzqkvmvkfzlasxw
 * Smoking Wheels....  was here 2017 ebhzmklvlowsflgqymuvtaivwjtghxnoipswspvqvenwdywc
 * Smoking Wheels....  was here 2017 ymupgnbvjvjuqshvefblnwxmhocriswopsalfqeqmcecokmh
 * Smoking Wheels....  was here 2017 rhhbqkntxggpubrcylysjtfjnecsbzdciturkemmlxzeawxt
 * Smoking Wheels....  was here 2017 enknzanaynhwbchlhmiauthftetjfmmnrgfgcnydbwdgjkka
 * Smoking Wheels....  was here 2017 jobivmaippmqcofflzhzpigygtiyrgdieaqzikatykgyugox
 * Smoking Wheels....  was here 2017 nyicyefoetccvltzxsilvdptrjhxpntiograkrjvzhzwtzfn
 */
/**
*  RowSet
*  Copyright 2006 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  First released 20.06.2006 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.kelondro.index;
import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.util.MemoryControl;
public class RowSet extends RowCollection implements Index, Iterable<Row.Entry>, Serializable {
private static final long serialVersionUID=-6036029762440788566L;
public RowSet(final RowSet rs) {
super(rs);
}
public RowSet(final Row rowdef, final int objectCount, final byte[] cache, final int sortBound) {
super(rowdef, objectCount, cache, sortBound);
assert rowdef.objectOrder != null;
}
public RowSet(final Row rowdef, final int objectCount) throws SpaceExceededException {
super(rowdef, objectCount);
assert rowdef.objectOrder != null;
}
public RowSet(final Row rowdef) {
super(rowdef);
assert rowdef.objectOrder != null;
}
/**
* import an exported collection
* @param rowdef
* @param exportedCollectionRowEnvironment
* @param columnInEnvironment
*/
public RowSet(final Row rowdef, final Row.Entry exportedCollectionRowEnvironment) {
super(rowdef, exportedCollectionRowEnvironment);
assert rowdef.objectOrder != null;
}
public final static RowSet importRowSet(final byte[] b, final Row rowdef) throws SpaceExceededException {
	assert b.length >= exportOverheadSize : "b.length = " + b.length;
	if (b.length < exportOverheadSize) return new RowSet(rowdef, 0);
final int size = (int) NaturalOrder.decodeLong(b, 0, 4);
assert size >= 0 : "size = " + size;
        if (size < 0) return new RowSet(rowdef, 0);
final int orderbound = (int) NaturalOrder.decodeLong(b, 10, 4);
assert orderbound >= 0 : "orderbound = " + orderbound;
        if (orderbound < 0) return new RowSet(rowdef, 0); // error
final long alloc = ((long) size) * ((long) rowdef.objectsize);
assert alloc <= Integer.MAX_VALUE : "alloc = " + alloc;
        if (alloc > Integer.MAX_VALUE) throw new SpaceExceededException((int) alloc, "importRowSet: alloc > Integer.MAX_VALUE");
assert alloc == b.length - exportOverheadSize;
        if (alloc != b.length - exportOverheadSize) throw new SpaceExceededException((int) alloc, "importRowSet: alloc != b.length - exportOverheadSize");
MemoryControl.request((int) alloc, true);
final byte[] chunkcache;
try {
chunkcache = new byte[(int) alloc];
} catch (final OutOfMemoryError e) {
throw new SpaceExceededException((int) alloc, "importRowSet: OutOfMemoryError");
}
        if (b.length - exportOverheadSize != alloc) {
ConcurrentLog.severe("RowSet", "exportOverheadSize wrong: b.length = " + b.length + ", size * rowdef.objectsize = " + size * rowdef.objectsize);
return new RowSet(rowdef, 0);
}
System.arraycopy(b, (int) exportOverheadSize, chunkcache, 0, chunkcache.length);
return new RowSet(rowdef, size, chunkcache, orderbound);
}
public final static int importRowCount(final long blength, final Row rowdef) {
assert blength >= exportOverheadSize : "blength = " + blength;
        if (blength < exportOverheadSize) return 0;
final int c = (int) ((blength - exportOverheadSize) / rowdef.objectsize);
assert c >= 0;
return c;
}
private RowSet(final Row rowdef, final byte[] chunkcache, final int chunkcount, final int sortBound, final long lastTimeWrote) {
super(rowdef, chunkcache, chunkcount, sortBound, lastTimeWrote);
}
@Override
public RowSet clone() {
return new RowSet(super.rowdef, super.chunkcache, super.chunkcount, super.sortBound, super.lastTimeWrote);
}
	@Override
public void reset() {
		super.reset();
	}
@Override
public final synchronized boolean has(final byte[] key) {
assert key.length == this.rowdef.primaryKeyLength;
final int index = find(key, 0);
return index >= 0;
}
@Override
public final synchronized Row.Entry get(final byte[] key, final boolean forcecopy) {
assert key.length == this.rowdef.primaryKeyLength;
final int index = find(key, 0);
        if (index < 0) return null;
return get(index, forcecopy);
}
@Override
public Map<byte[], Row.Entry> get(final Collection<byte[]> keys, final boolean forcecopy) throws IOException, InterruptedException {
final Map<byte[], Row.Entry> map = new TreeMap<byte[], Row.Entry>(row().objectOrder);
Row.Entry entry;
for (final byte[] key: keys) {
entry = get(key, forcecopy);
if (entry != null) map.put(key, entry);
}
return map;
}
/**
* Adds the row to the index. The row is identified by the primary key of the row.
* @param row a index row
* @return true if this set did _not_ already contain the given row.
* @throws IOException
* @throws SpaceExceededException
*/
@Override
public final boolean put(final Row.Entry entry) throws SpaceExceededException {
assert (entry != null);
final byte[] key = entry.getPrimaryKeyBytes();
assert (key != null);
final byte[] entrybytes = entry.bytes();
assert entrybytes.length >= this.rowdef.primaryKeyLength;
synchronized (this) {
final int index = find(key, 0);
if (index < 0) {
super.addUnique(entry);
return true;
}
final int sb = this.sortBound;
set(index, entry);     
this.sortBound = sb;   
return false;
}
}
private final int collectionReSortLimit() {
return Math.min(3000, Math.max(100, this.chunkcount / 3));
}
@Override
public final Row.Entry replace(final Row.Entry entry) throws SpaceExceededException {
assert (entry != null);
final byte[] key = entry.getPrimaryKeyBytes();
assert (key != null);
final byte[] entrybytes = entry.bytes();
assert entrybytes.length >= this.rowdef.primaryKeyLength;
synchronized (this) {
int index = -1;
Row.Entry oldentry = null;
if ((this.chunkcount - this.sortBound) > collectionReSortLimit()) {
sort();
}
index = find(key, 0);
if (index < 0) {
super.addUnique(entry);
} else {
oldentry = get(index, true);
final int sb = this.sortBound;
set(index, entry);     
this.sortBound = sb;   
}
return oldentry;
}
}
public final synchronized long inc(final byte[] key, final int col, final long add, final Row.Entry initrow) throws SpaceExceededException {
assert key.length == this.rowdef.primaryKeyLength;
final int index = find(key, 0);
        if (index >= 0) {
final Row.Entry entry = get(index, false);
final long l = entry.incCol(col, add);
set(index, entry);
return l;
} else if (initrow != null) {
super.addUnique(initrow);
return initrow.getColLong(col);
} else {
return Long.MIN_VALUE;
}
}
/**
* remove a byte[] from the set.
* if the entry was found, return the entry, but delete the entry from the set
* if the entry was not found, return null.
*/
@Override
public final synchronized boolean delete(final byte[] a) {
boolean exists = false;
int index;
assert a.length == this.rowdef.primaryKeyLength;
while (true) {
index = find(a, 0);
if (index < 0) {
return exists;
}
exists = true;
super.removeRow(index, true);
}
}
public final synchronized void delete(final List<byte[]> keys) {
final int[] indexes = new int[keys.size()];
for (int i = 0; i < keys.size(); i++) {
indexes[i] = find(keys.get(i), 0);
}
Arrays.sort(indexes);
for (int i = indexes.length - 1; i >= 0; i--) {
if (indexes[i] < 0) break;
super.removeRow(indexes[i], false);
}
}
@Override
public final synchronized Row.Entry remove(final byte[] a) {
Row.Entry entry = null;
int index;
assert a.length == this.rowdef.primaryKeyLength;
while (true) {
index = find(a, 0);
if (index < 0) {
return entry;
}
entry = super.get(index, true);
super.removeRow(index, true);
}
}
private final int find(final byte[] a, final int astart) {
        if (this.rowdef.objectOrder == null) return iterativeSearch(a, astart, 0, this.chunkcount);
        if ((this.chunkcount - this.sortBound) > collectionReSortLimit()) {
sort();
}
        if (this.rowdef.objectOrder != null && this.rowdef.objectOrder instanceof Base64Order) {
assert this.rowdef.objectOrder.wellformed(a, astart, this.rowdef.primaryKeyLength) : "not wellformed: " + ASCII.String(a, astart, this.rowdef.primaryKeyLength);
}
final int p = binarySearch(a, astart);
        if (p >= 0) return p;
return iterativeSearch(a, astart, this.sortBound, this.chunkcount);
}
private final int iterativeSearch(final byte[] key, final int astart, final int leftBorder, final int rightBound) {
for (int i = leftBorder; i < rightBound; i++) {
assert key.length - astart >= this.rowdef.primaryKeyLength;
if (match(key, astart, i)) return i;
}
return -1;
}
private final int binarySearch(final byte[] key, final int astart) {
assert (this.rowdef.objectOrder != null);
int l = 0;
int rbound = this.sortBound;
int p = 0;
int d;
while (l < rbound) {
p = (l + rbound) >> 1;
assert key.length - astart >= this.rowdef.primaryKeyLength;
d = compare(key, astart, p);
if (d == 0) return p;
if (d < 0) rbound = p; else l = p + 1;
}
return -1;
}
protected final int binaryPosition(final byte[] key, final int astart) {
assert (this.rowdef.objectOrder != null);
int l = 0;
int rbound = this.sortBound;
int p = 0;
int d;
while (l < rbound) {
p = (l + rbound) >> 1;
assert key.length - astart >= this.rowdef.primaryKeyLength;
d = compare(key, astart, p);
if (d == 0) return p;
if (d < 0) rbound = p; else l = p + 1;
}
return l;
}
public final synchronized Iterator<byte[]> keys() {
sort();
return super.keys(true);
}
@Override
public final synchronized CloneableIterator<byte[]> keys(final boolean up, final byte[] firstKey) {
this.sort();
return new keyIterator(up, firstKey);
}
public final class keyIterator implements CloneableIterator<byte[]> {
private final boolean up;
private final byte[] first;
private int p;
final int bound;
public keyIterator(final boolean up, byte[] firstKey) {
sort();
this.up = up;
if (firstKey != null && firstKey.length == 0) firstKey = null;
this.first = firstKey;
this.bound = RowSet.this.sortBound;
if (this.first == null) {
this.p = up ? 0 : this.bound - 1;
} else {
assert this.first.length == RowSet.this.rowdef.primaryKeyLength : "first.length = " + this.first.length + ", rowdef.primaryKeyLength = " + RowSet.this.rowdef.primaryKeyLength;
this.p = up ? binaryPosition(this.first, 0) : this.bound - 1;
}
}
		@Override
public final keyIterator clone(final Object second) {
return new keyIterator(this.up, (byte[]) second);
}
@Override
public final boolean hasNext() {
	if (this.p < 0) return false;
	if (this.p >= size()) return false;
return (this.up) ? this.p < this.bound : this.p >= 0;
}
@Override
public final byte[] next() {
final byte[] key = getKey(this.p);
if (this.up) this.p++; else this.p--;
return key;
}
@Override
public final void remove() {
throw new UnsupportedOperationException();
}
@Override
public void close() {
}
}
@Override
public final synchronized Iterator<Row.Entry> iterator() {
sort();
return super.iterator();
}
@Override
public final synchronized CloneableIterator<Row.Entry> rows(final boolean up, final byte[] firstKey) {
return new rowIterator(up, firstKey);
}
@Override
public final synchronized CloneableIterator<Row.Entry> rows() {
return new rowIterator(true, null);
}
public final class rowIterator implements CloneableIterator<Row.Entry> {
private final boolean up;
private final byte[] first;
private int p;
final int bound;
public rowIterator(final boolean up, final byte[] firstKey) {
sort();
this.up = up;
this.first = firstKey;
this.bound = RowSet.this.sortBound;
if (this.first == null) {
this.p = 0;
} else {
assert this.first.length == RowSet.this.rowdef.primaryKeyLength;
this.p = binaryPosition(this.first, 0);
}
}
		@Override
public final rowIterator clone(final Object second) {
return new rowIterator(this.up, (byte[]) second);
}
@Override
public final boolean hasNext() {
	if (this.p < 0) return false;
	if (this.p >= size()) return false;
return (this.up) ? this.p < this.bound : this.p >= 0;
}
@Override
public final Row.Entry next() {
final Row.Entry entry = get(this.p, true);
if (this.up) this.p++; else this.p--;
return entry;
}
@Override
public final void remove() {
throw new UnsupportedOperationException();
}
@Override
public void close() {
}
}
/**
* merge this row collection with another row collection.
* The resulting collection is sorted and does not contain any doubles, which are also removed during the merge.
* The new collection may be a copy of one of the old one, or can be an alteration of one of the input collections
* After this merge, none of the input collections should be used, because they can be altered
* @param c
* @return
* @throws SpaceExceededException
*/
public final RowSet merge(final RowSet c) throws SpaceExceededException {
assert c != null;
return mergeEnum(this, c);
}
/**
* merge this row collection with another row collection using an simultanous iteration of the input collections
* the current collection is not altered in any way, the returned collection is a new collection with copied content.
* @param c
* @return
* @throws SpaceExceededException
*/
protected final static RowSet mergeEnum(final RowCollection c0, final RowCollection c1) throws SpaceExceededException {
assert c0.rowdef == c1.rowdef : c0.rowdef.toString() + " != " + c1.rowdef.toString();
final RowSet r = new RowSet(c0.rowdef, c0.size() + c1.size());
try {
	c0.sort();
} catch (final Throwable e) {
	ConcurrentLog.severe("RowSet", "collection corrupted. cleaned. " + e.getMessage(), e);
	c0.clear();
}
try {
	c1.sort();
} catch (final Throwable e) {
	ConcurrentLog.severe("RowSet", "collection corrupted. cleaned. " + e.getMessage(), e);
	c1.clear();
}
int c0i = 0, c1i = 0;
int c0p, c1p;
int o;
final int objectsize = c0.rowdef.objectsize;
final int c0s = c0.size();
final int c1s = c1.size();
while (c0i < c0s && c1i < c1s) {
c0p = c0i * objectsize;
c1p = c1i * objectsize;
o = c0.rowdef.objectOrder.compare(
c0.chunkcache, c0p,
c1.chunkcache, c1p, c0.rowdef.primaryKeyLength);
if (o == 0) {
r.addSorted(c0.chunkcache, c0p, objectsize);
c0i++;
c1i++;
continue;
}
if (o < 0) {
r.addSorted(c0.chunkcache, c0p, objectsize);
c0i++;
continue;
}
if (o > 0) {
r.addSorted(c1.chunkcache, c1p, objectsize);
c1i++;
continue;
}
}
while (c0i < c0.size()) {
r.addSorted(c0.chunkcache, c0i * objectsize, objectsize);
c0i++;
}
while (c1i < c1.size()) {
r.addSorted(c1.chunkcache, c1i * objectsize, objectsize);
c1i++;
}
return r;
}
public static void main(final String[] args) {
/*
	kelondroRow rowdef = new kelondroRow("Cardinal key-4 {b256}, byte[] payload-1", kelondroNaturalOrder.naturalOrder, 0);
	kelondroRowSet rs = new kelondroRowSet(rowdef, 0);
Random random = new Random(0);
kelondroRow.Entry entry;
for (int i = 0; i < 10000000; i++) {
	entry = rowdef.newEntry();
	entry.setCol(0, Math.abs(random.nextLong() % 1000000));
	entry.setCol(1, "a".getBytes());
	rs.addUnique(entry);
}
System.out.println("before sort, size = " + rs.size());
rs.sort();
System.out.println("after sort, before uniq, size = " + rs.size());
rs.uniq(10000);
System.out.println("after uniq, size = " + rs.size());
*/
final String[] test = {
		"eins......xxxx",
		"zwei......xxxx",
		"drei......xxxx",
		"vier......xxxx",
		"fuenf.....xxxx",
		"sechs.....xxxx",
		"sieben....xxxx",
		"acht......xxxx",
		"neun......xxxx",
		"zehn......xxxx" };
final RowSet d = new RowSet(new Row("byte[] key-10, Cardinal x-4 {b256}", NaturalOrder.naturalOrder));
for (final String element : test)
try {
d.add(element.getBytes());
} catch (final SpaceExceededException e) {
e.printStackTrace();
}
for (final String element : test)
try {
d.add(element.getBytes());
} catch (final SpaceExceededException e) {
e.printStackTrace();
}
d.sort();
d.delete("fuenf".getBytes());
final Iterator<Row.Entry> ii = d.iterator();
String s;
System.out.print("INPUT-ITERATOR: ");
Row.Entry entry;
while (ii.hasNext()) {
entry = ii.next();
s = entry.getPrimaryKeyASCII().trim();
System.out.print(s + ", ");
if (s.equals("drei")) ii.remove();
}
System.out.println("");
System.out.println("INPUT-TOSTRING: " + d.toString());
d.sort();
System.out.println("SORTED        : " + d.toString());
d.uniq();
System.out.println("UNIQ          : " + d.toString());
d.trim();
System.out.println("TRIM          : " + d.toString());
final Row row = new Row("byte[] key-10, Cardinal x-3 {b256}", NaturalOrder.naturalOrder);
RowSet c = new RowSet(row);
final Random rand = new Random(0);
        long start = System.currentTimeMillis();
        long t;
String w;
for (long k = 1; k <= 60000; k++) {
t = System.currentTimeMillis();
w = "a" + Long.toString(rand.nextLong());
try {
c.put(row.newEntry(new byte[][]{w.getBytes(), "000".getBytes()}));
} catch (final SpaceExceededException e) {
e.printStackTrace();
}
if (k % 10000 == 0)
System.out.println("added " + k + " entries in " +
((t - start) / 1000) + " seconds, " +
(((t - start) > 1000) ? (k / ((t - start) / 1000)) : k) +
" entries/second, size = " + c.size());
}
System.out.println("bevore sort: " + (System.currentTimeMillis() - start) + " milliseconds, size: " + c.size());
c.sort();
System.out.println("after sort: " + (System.currentTimeMillis() - start) + " milliseconds, size: " + c.size());
c.uniq();
System.out.println("after uniq: " + (System.currentTimeMillis() - start) + " milliseconds, size: " + c.size());
System.out.println();
start = System.currentTimeMillis();
c = new RowSet(new Row("byte[] a-12, byte[] b-12", Base64Order.enhancedCoder));
byte[] key;
final int testsize = 5000;
final byte[][] delkeys = new byte[testsize / 5][];
Random random = new Random(0);
for (int i = 0; i < testsize; i++) {
key = randomHash(random);
if (i % 5 != 0) continue;
delkeys[i / 5] = key;
}
random = new Random(0);
for (int i = 0; i < testsize; i++) {
key = randomHash(random);
try {
c.put(c.rowdef.newEntry(new byte[][]{key, key}));
} catch (final SpaceExceededException e) {
e.printStackTrace();
}
if (i % 1000 == 0) {
for (final byte[] delkey : delkeys)
c.delete(delkey);
c.sort();
}
}
for (final byte[] delkey : delkeys)
c.delete(delkey);
c.sort();
random = new Random(0);
for (int i = 0; i < testsize; i++) {
key = randomHash(random);
if (i % 5 == 0) continue;
if (c.get(key, true) == null) System.out.println("missing entry " + UTF8.String(key));
}
c.sort();
System.out.println("RESULT SIZE: " + c.size());
System.out.println("Time: " + ((System.currentTimeMillis() - start) / 1000) + " seconds");
System.exit(0);
}
public static byte[] randomHash(final long r0, final long r1) {
return ASCII.getBytes(
Base64Order.enhancedCoder.encodeLongSB(Math.abs(r0), 11).substring(5) +
Base64Order.enhancedCoder.encodeLongSB(Math.abs(r1), 11).substring(5));
}
public static byte[] randomHash(final Random r) {
return randomHash(r.nextLong(), r.nextLong());
}
@Override
public String filename() {
return null;
}
@Override
public void deleteOnExit() {
}
}
