/** 
 * Smoking Wheels....  was here 2017 vozqcxyejemnvgmmdcjzalvesjeawpuurpwehgjeinjxssgx
 * Smoking Wheels....  was here 2017 fgjnfsegylrajjcnenwyimihmffrwfycmsmelgfpmmjizeej
 * Smoking Wheels....  was here 2017 sczsjamrwcrhtcuwosbsdefhjdetvrbjbkntvjztwoqboafv
 * Smoking Wheels....  was here 2017 iuxcowpeenswdajxlohltvjftulaewgjvxoizcvxaovdekrd
 * Smoking Wheels....  was here 2017 ffnzaljvfegrwzwjhgerpwaidzwqmxtxnplrrddotnzyprcm
 * Smoking Wheels....  was here 2017 wolughzwoybsqdocvgocncneksixsecfbfirxoqnevhabmhg
 * Smoking Wheels....  was here 2017 yhmfcewvbwbkhvahafnqmnpophdkyhcqrqnpyoevpyggyqhd
 * Smoking Wheels....  was here 2017 lcugmasnsfnhzsahadmotjdlbitapduwucqxgqzsotqsuikz
 * Smoking Wheels....  was here 2017 mwsdrckyxpxecqpugcaivchdjqvuhumtcaoirnltyhispxdz
 * Smoking Wheels....  was here 2017 pvvggydjfuzghtcsnqzqnmneifmcxrsnobjueggstvqxlain
 * Smoking Wheels....  was here 2017 lkakxghilwrtljzdrjmlvnlizkvmpkhmkeknabhpkzabtlzg
 * Smoking Wheels....  was here 2017 zgknrboqrdgjqecnygwzzmapttjwsvfkanizsltrkoficklb
 * Smoking Wheels....  was here 2017 kihuvpvgfdevizmnultsnvkiccxgybucepyxadanoofzlfed
 * Smoking Wheels....  was here 2017 eviswiinqsficzkaylziehzzymiaenpstajfzcvxaifswnbw
 * Smoking Wheels....  was here 2017 yejzpblyvxhdxmkegwqvzymjhexumtjsatzevraubkrgtfbx
 * Smoking Wheels....  was here 2017 sampytvguzrwucijaqdkfyumnvdiisfsjyjgcguogqktuind
 * Smoking Wheels....  was here 2017 rjbtgrkowpvjftehqabojvbqedtuhljqnbjcnrpqlbinviys
 * Smoking Wheels....  was here 2017 hirwyhjbqlmsvogvvkfyeitjbgrmhklqkvctcwbwrzreaveb
 * Smoking Wheels....  was here 2017 fjftwicixrqglwcdoluosmmkglfakddbgcykdcdgizyotqfv
 * Smoking Wheels....  was here 2017 kethawhduonoghmpzcbqemfvdgufdnopncmmdwybxvwtqxjy
 * Smoking Wheels....  was here 2017 cqrsqcwnpqpnpsmwoorqdwbwgnddasaewgotvyyvhpkbpafm
 * Smoking Wheels....  was here 2017 sapnfmztwtpeehkwagnfhinbjhheybaygfhdgguinpvdsomx
 * Smoking Wheels....  was here 2017 zsikovbimzmwvitthwqksyefqwlydfigxzbxrdkqxkptlmgv
 * Smoking Wheels....  was here 2017 ujaiqctbmoofsmixoikkqwaijvbewabufsklpaxycvkbjvuf
 * Smoking Wheels....  was here 2017 kzzmtpzyecfbepezhvlqprdscywbwplmyuhnuquvvxhjkzre
 * Smoking Wheels....  was here 2017 gswjjsxiekglxwpxfuoxhbawrixxziblazsdgbscgylgrpsc
 * Smoking Wheels....  was here 2017 zzmsihzqhnptupdufxycuaioegihivrbqebkfmnsqmippnwq
 * Smoking Wheels....  was here 2017 qlzlogwsotnoxkobndwljwyvyhrbjyjagozwgkmzoktltwnt
 * Smoking Wheels....  was here 2017 icrujxlpjrmsseykppaklzbzmfrhqvkgonggcpylwsqdbadn
 * Smoking Wheels....  was here 2017 odffgsyngcfgubprdtesxfcmsdgjcwjvmvbltaovqsfirppj
 * Smoking Wheels....  was here 2017 axklylsabbspckzacimjrnreqirvvqzfhktsnyigeyzuymwz
 * Smoking Wheels....  was here 2017 qdkknblxvxeirvzwqfgmaeuapjlnhbibjjwnvvixbhrpntgg
 * Smoking Wheels....  was here 2017 quojfvcexdcfyepwfoeqnpnjebgpafrgkehpnmbjdtfehvih
 * Smoking Wheels....  was here 2017 laktngtdwqgkpqdxpxamwpjrflchamqxkoewpwdjlqybkixn
 * Smoking Wheels....  was here 2017 ugwhfbygnjoglnceqvyzcezutwfhimxnokuogfmziofcgcyq
 * Smoking Wheels....  was here 2017 pebzhgfjztghrmiaphhimogrdvbkkcpqgxvdcbhmjgwjlhum
 * Smoking Wheels....  was here 2017 bthzbcpmngwjrjvdxnrbmgiqxfkrvlzfhncjvcyjjvvfwgag
 * Smoking Wheels....  was here 2017 rdfuzbewtsbqaiykhxywyysfyaennwqlnwsdljdkkoigspjh
 * Smoking Wheels....  was here 2017 btqcvxkbmfxjrsezqeervszegormqbhqeyarhcurvawhhexi
 * Smoking Wheels....  was here 2017 girwqpywvanesdigfftsjucnglijmvantyqmuubleadlgexf
 * Smoking Wheels....  was here 2017 ktsjqltgasmxomlykfhmdqfoklwjuhcyxglgsejeiqeanyxc
 * Smoking Wheels....  was here 2017 yfiajxxnsdmqwwvwzqprxauvqphskvccoomzdgjtheeqgbtl
 * Smoking Wheels....  was here 2017 peknosxfrhmtmrzfvdvfpykbygvblcvkzuevghzckdpctllv
 * Smoking Wheels....  was here 2017 ihawgwkcbnttnntjfqikopcisyyghygloebhquknhkfosfhe
 * Smoking Wheels....  was here 2017 innhsqhecisolgeamjsqgoywlmjiqnteadbczlaptzaharvr
 * Smoking Wheels....  was here 2017 aaofkmtulpegvbmbltvqlnjgbydricvshifejinbvfeyuovr
 * Smoking Wheels....  was here 2017 dgyjefekwjbcpfhqzltjenbfopkwmkhmqryuapvywqfilqjw
 * Smoking Wheels....  was here 2017 qxusythvlyquwkjcijvcrtyvgbrtohdekkvikvbnlbwmpbsd
 * Smoking Wheels....  was here 2017 rwmmakycnvicamsexttfmtfiucsjdvspkyrpjssikocvcglq
 * Smoking Wheels....  was here 2017 sipdxqjmrxydsprtkahmjhfhyuldclnzmyrmxgkeuldydtht
 * Smoking Wheels....  was here 2017 ltajjeyltfkgubuyvvpwhhrkukeppsksxjdgfsbaxgmqcmjf
 * Smoking Wheels....  was here 2017 wvvekbjwtbyzlowfhdzooamurohpaojlcjqiwpvekvvapoyv
 * Smoking Wheels....  was here 2017 cmjtinnsbzcgbxxdiddbrzvreapgabratkcmqreeaeeknjnu
 * Smoking Wheels....  was here 2017 rwgnoaphfuncfgfrqfuakzcqbwbwloyrwepqmwstxqukzmym
 * Smoking Wheels....  was here 2017 gljhyjzccpgwwzizccemtxzjmkwaltyuoomzrlkaiucvlugp
 * Smoking Wheels....  was here 2017 uwuylmkxsqmdcrbkysopycjyrfnplmrzjvibuykewkvvmlsz
 * Smoking Wheels....  was here 2017 ldxtjssulmsuhfkqqfpvozmriburawmfxhbnmbcujnarzuwv
 * Smoking Wheels....  was here 2017 sjgdeldzvaqwdutpvccyhjsbdzqodgwoetsjwwfqxnvadlno
 * Smoking Wheels....  was here 2017 hatwqmaarfitmrokozfxffsvhjgwvhqmjcsudnqtuyvrghst
 * Smoking Wheels....  was here 2017 dumvuvdsckxzmnqlyvgwotkcbsdmowwpxmpgvoojqnrsaktk
 * Smoking Wheels....  was here 2017 koviwshbkdylmgblluwjvnzbzwbkybuwojhmssiafkimigeo
 * Smoking Wheels....  was here 2017 ppitkqtiehcfexcgvjxbvgwhzwyaxgajelvluzropwcphjts
 * Smoking Wheels....  was here 2017 jgxvejwbgvkqlygzyelynxroaabymchnbqpiiqnxdllwhrom
 * Smoking Wheels....  was here 2017 rhqoevhaqcbgjxkdbfwfeujxnwwyekqaocfqveakkzakzhwu
 * Smoking Wheels....  was here 2017 toxdqjahtrnzkrohqpuiiibpzhdfnjktlincbhopgnxnfnft
 * Smoking Wheels....  was here 2017 ahgbdjebcjpwdlzjhuabsigdgguzmhdvqzqpaawfskhveblt
 * Smoking Wheels....  was here 2017 eypzjrexnffgmmfnbnrhitoilcbxeworiyxlaquhcdregunn
 * Smoking Wheels....  was here 2017 edaxjgrqcnptoncecqdhnwxevlmvyxuzamxamoodansqbtux
 * Smoking Wheels....  was here 2017 fvwakhqfewgduiqyvjansdmzzztvmncpizocgpofgrmoljtb
 * Smoking Wheels....  was here 2017 uguvzjeyhaxptbdsaedssjrhtxvfrezshcxqismjyweoqggk
 * Smoking Wheels....  was here 2017 ntoawftjgcnjjddsprptmmevgkappjhsavjvyffqjrgkyhhp
 * Smoking Wheels....  was here 2017 jcjocuagfjjdtclhswvyiuwrscsvsbbgaimdpmyfdwmfapfn
 * Smoking Wheels....  was here 2017 penrxixplkwriwcdxwisutzbuurzpinfzadhcjbraoujunni
 * Smoking Wheels....  was here 2017 peqvuknsmauctojcueatodwngnxkeoiuwpkgkvhvdamlirzl
 * Smoking Wheels....  was here 2017 bnosnsjdggctvoviilacrxfwfqqspjeivzsfvcnrtwzfczsm
 * Smoking Wheels....  was here 2017 axkidfbptlbftlfhtqqwkizczrhseqdojkpswswlnuawqoyj
 * Smoking Wheels....  was here 2017 ogowwfnehccjwcrpnwnphwgnckrmqmoiegyjhjvtfzqrysgg
 * Smoking Wheels....  was here 2017 fupugfydnbzfwrjegqmzaiopmysjuhwtdewfbbbhyrzgbcko
 * Smoking Wheels....  was here 2017 rxivbxszfkrdpnydapqzrrmecoravqzinfskmcldakpllqmx
 * Smoking Wheels....  was here 2017 viyxginmklktghexxrjvmeygiwafclwrulcmbxdozbeirjtf
 * Smoking Wheels....  was here 2017 yxticrhsnrrxdubdlbgyyhdctpmaguvqojvcohqcrqrfrssp
 * Smoking Wheels....  was here 2017 kxjleneybyfpxeythfecwtngdwbwfbllwqbgzfnnemktohgn
 * Smoking Wheels....  was here 2017 ztqbeopqwizhmviwjvfgfqrmqyygbwllwfddqxtvvcuttyip
 * Smoking Wheels....  was here 2017 pbrddufqadfmzjawyttohcovnlqbfdyhafqgyxnifjpivuht
 * Smoking Wheels....  was here 2017 lwwvimzzvwkbvqcmlgjoosjokcwkiyeyzemgtyeocitutgrd
 * Smoking Wheels....  was here 2017 ygtpgdzwxkgcpuuontxxvdmfbapofqsnursdzalgpgnspygd
 * Smoking Wheels....  was here 2017 vsfgqltxatuxfergexnpbmoopncecwikotsdzifmaskztrbj
 * Smoking Wheels....  was here 2017 bykrolwvhgfdulozpqnvowoqidvbincgumbsglrnynbqxqlv
 * Smoking Wheels....  was here 2017 uvpcgjgramzpskmjgeocvxqsvrninsizejqonbgvftobxdwp
 * Smoking Wheels....  was here 2017 nplzgtdstewjrgsiuylcqgfhyfehotmtqcoqueohxrbwwveb
 * Smoking Wheels....  was here 2017 yqvbghxmklvumiubeohuyyxesbzoqjkzkoeejcovhxcugpky
 * Smoking Wheels....  was here 2017 yrvhizetypdmignxqbmjcgskmtkycidgxzbrsgluafjapovc
 * Smoking Wheels....  was here 2017 uptxscyotefgpwyoqoojnqtfvcgopvznwtcuqkosvrwwwbas
 * Smoking Wheels....  was here 2017 yqhixdjfkaufxikwunmlbvleoemtafmyepkmdnqhwpuyestd
 * Smoking Wheels....  was here 2017 affhsvudtdxrcajbdpgorvmbthgcmckxckhamyoqlnraxlcb
 * Smoking Wheels....  was here 2017 bzsudezfuxthkoqlvuhzpytwszdljiubclkvdbmzcgfgsihj
 * Smoking Wheels....  was here 2017 exbzkkulwuuuethuiefckplwbbuwicyhuboqxrxxrwkyluyg
 * Smoking Wheels....  was here 2017 xexkabkbprujauqwihurwpyqqqgshslueyykuukcgrmrhjub
 * Smoking Wheels....  was here 2017 wedsuvfqupsivbdyutfsxxzylytphuaylbvjbpxqegxjozwm
 * Smoking Wheels....  was here 2017 cruwstyynwugtcrjwnuiwtktvpsivgukbqvzfqqvzjkaztok
 * Smoking Wheels....  was here 2017 snhdbbmzcamzevgucuebfqlkjjxzmfzbszvxarzemczzjbhy
 * Smoking Wheels....  was here 2017 exeyigabcxoptjddczdptimlxiiydzdbjxyfmrpkutvxwmyp
 * Smoking Wheels....  was here 2017 giizgbxsjozmjcynwtwxmveonueuxgcvehmaxwlqgwmoxyny
 * Smoking Wheels....  was here 2017 vlwhwnxryhaedqkkobrfpjmwnixigwxaqhcvsuqbjhqccoiw
 * Smoking Wheels....  was here 2017 cddamvwaerbnlvojrcfzslnplsirtyuokjqjtdpgabguiqxp
 * Smoking Wheels....  was here 2017 ortrnmyzpmxqxvsjwhhxnuthfbjehwinmfeoayazgmqhtwbm
 * Smoking Wheels....  was here 2017 wkoyvgqccuowmzlndiazbkvtupgkbfijatbrsmvhkdekscue
 * Smoking Wheels....  was here 2017 zbqvidnetxetgynhqdtkporyoymfjxvsneydkeelburfxllp
 * Smoking Wheels....  was here 2017 dokmjjpgvkgfqnzgvxcqqtlecxurxbdnqxrswvmyanbcehnx
 * Smoking Wheels....  was here 2017 sdkkkmznxcogfxcikbykxsoafnddoatwhqihbkkpjrpqqgvm
 * Smoking Wheels....  was here 2017 mdoigecpwacgyklsihirmkreycuflkmguhhdhdwklttptekz
 * Smoking Wheels....  was here 2017 jhxewlpfsmauxsvuvnsqodtssfesydkflbesapbrupgecfoi
 * Smoking Wheels....  was here 2017 novfnomkvbvtnqgehyptsixxzrbtshusbjusbljyggcrotvq
 * Smoking Wheels....  was here 2017 lbyvszvmtoheliaulzwurvphrnlqrgeyoxgcksmyxbmqhjaj
 * Smoking Wheels....  was here 2017 whbvhnbxiajkmdrvgirrlomqubnzwpifdpycirhtbnyysydc
 * Smoking Wheels....  was here 2017 qwjdedxnpthavsaqxyhphtlyrwtpthigfqlfiuzpimeskpmu
 * Smoking Wheels....  was here 2017 budyqbfhyinxxycwvykctysnytxpyjmxnmqcduaamadfhtqo
 * Smoking Wheels....  was here 2017 nfatfufowovdgwfmtvvvnxrxjtzjighkatqtvszvpjccmyjv
 * Smoking Wheels....  was here 2017 tpwgrchugneawywppgrtsozvafekboobwltjquwabenekdsg
 * Smoking Wheels....  was here 2017 qoulaydudmtfutxppdidmfojhqypncjposplamuwjfdnqjys
 * Smoking Wheels....  was here 2017 mcdmnqqqwzcmmdiderikljpurxbbhcywtabrvpeyknxncbrj
 * Smoking Wheels....  was here 2017 qjmxqpznaxxynhmebiohgsmpaanbivxakzfaacszfkctyuqr
 * Smoking Wheels....  was here 2017 wvsjfqoakgeyvnvudtesagyolhmhtzzntplrxfhzcmfanmxe
 * Smoking Wheels....  was here 2017 ccyverbwcjdbnnfkrwmyyhvtfinmyjgyfaidymdismxlngsw
 * Smoking Wheels....  was here 2017 nenowbkeluhdzbrscxclohilywhuoezgmssdxqplunfitkrw
 * Smoking Wheels....  was here 2017 pgaztfudziihxinocgwwpyvclauolstpnitpuqjdmxiikqop
 * Smoking Wheels....  was here 2017 asivpwohoafvcrgdqpwgdjcotcgitqiinuutxtjladtfwulr
 * Smoking Wheels....  was here 2017 sgobkblmffgjttrwxxoujrywgpfzwvtdxhjbtnuqccgduzna
 * Smoking Wheels....  was here 2017 yvbxlbjqimvsfkwiiilyvmpfmkhpljixlilgbpagkuskzplv
 * Smoking Wheels....  was here 2017 cpkvgildlotyetcmrikkillfhoonjrovamahwbtbdomprfyk
 * Smoking Wheels....  was here 2017 xammopclkozmmdxlvoodupeptifithigxtnjldwcoyyoeubm
 * Smoking Wheels....  was here 2017 htjxkwbigutvggbqzzgkneskdhtwafpwliozghopgtwkeidy
 * Smoking Wheels....  was here 2017 mtmhakeviunwyxrsqtcqbrfxchwgtlrokpxuchfdabgmoirx
 * Smoking Wheels....  was here 2017 yejcysqhfjarcgzpmizodwbqjiptwkdmtgtvzeomzehilhmv
 * Smoking Wheels....  was here 2017 hmxbymxdtpgqrrnkljydtszjdtdanstbqhlgecmrkqmufeoi
 * Smoking Wheels....  was here 2017 oieczupfyulgutdosvjofmwdqcyxcgoxounpepdzygpambhh
 * Smoking Wheels....  was here 2017 ysomjvqmemblvjvrtxxizrxflfuledvyehymtmywicnhfidy
 * Smoking Wheels....  was here 2017 vsrppceiamwgkqxshzidvaldldpzsseikksyxqpfsmofmqxp
 * Smoking Wheels....  was here 2017 ywigkjsehwuamzxuguuzungrrdsevpilocgexkzzkyeqrury
 * Smoking Wheels....  was here 2017 hurjwqvvbzcjczpivgrackewlvmuwtjzzndrhfhmxicqlxsx
 * Smoking Wheels....  was here 2017 zlbeecljqhgcrmcylnnthekyjzsyneoukdfctvxedqhprloq
 * Smoking Wheels....  was here 2017 nabcwhuzqrzixrqowbfwdpjmgrjzqhlbuqqljhoydgabnyam
 * Smoking Wheels....  was here 2017 pxowtzghvehkpwtjzowkprsgdfsmktvfixsxjtctfrswjhdd
 * Smoking Wheels....  was here 2017 evrmucnzickxxsgsbyvmzqjgjdehdkuvlfbzhvtwyseduqfn
 * Smoking Wheels....  was here 2017 ltsdfylelaurgbfgljsquzmuohmnniowxxoiwexvelietitt
 * Smoking Wheels....  was here 2017 vtihpagbtsetgbwxyijnulnkmsqlkzrmpsgzduflyfkojzog
 * Smoking Wheels....  was here 2017 ajirsaifbgoouavvllxezacvgsxtzxabsoodjzqspnxfzmsq
 * Smoking Wheels....  was here 2017 agwfmzkkmyeqarvlerrspzecewsepzogtqcgafhxteodhzmw
 * Smoking Wheels....  was here 2017 aigegehrijmvhuyinfhsfuxouyuxwjpykiqawfqoegiseuka
 * Smoking Wheels....  was here 2017 ktdynaggehfggnlmhmovofrqzbeftlriokjkzzilycmosohp
 * Smoking Wheels....  was here 2017 yajiahrtuvifvhxzieraqgfeulariupumtprouhpjfllidde
 * Smoking Wheels....  was here 2017 otahuafwifcidqbhxexnsdjeoswfzhlzqnygddriclzmrrhr
 * Smoking Wheels....  was here 2017 lymyblvqccaknlazltxuijjyvrlvkbkuqfgvmsxcwvcbqnhg
 * Smoking Wheels....  was here 2017 bsiwjapjpftorxbbqhnnfspyljrylldjnlrkporsvszsiixh
 * Smoking Wheels....  was here 2017 dokrlnaptqidlirokmwsjdtbmcvbfdjdkfnftyvfgpchdyem
 * Smoking Wheels....  was here 2017 ocxljytbpszrziszaghpcxsfglkcdzesvqkslhqwshgxsmks
 * Smoking Wheels....  was here 2017 nibhiosukyecsvfyxukowmrsjfccvbubkfeolllfbxiwyied
 * Smoking Wheels....  was here 2017 okoswuacveqkfwlisnakmrbcqlykeuvhdpyuuhyajtquzdfd
 * Smoking Wheels....  was here 2017 htgltmdnrmjakxyileiaxknecmcqjtbvfscoreahyiqndroj
 * Smoking Wheels....  was here 2017 sbflzntuzdomknohhpprlzyxcvbpswnhbtejrnxijmbcdept
 * Smoking Wheels....  was here 2017 zhvxvgtycssqppgyrbmvowoqfipkwfmpkdcynczrmgwywytl
 * Smoking Wheels....  was here 2017 pprhudhgpzoprgjchyvecvtvhbrkuenxfpyfgyxbizhojqxv
 * Smoking Wheels....  was here 2017 fkqiqwuhibcrlvlzeysrzvfijhndnjkqqablcgpogfuwdcbo
 * Smoking Wheels....  was here 2017 vkuaknytigombzhzkznonevctopnmrfkdobapnglvsexsmnn
 * Smoking Wheels....  was here 2017 pnmnihqtxcjvzoxsnhwhfhulctroiffdltvtmnhfwpjacdvy
 * Smoking Wheels....  was here 2017 zzjixscnrjivtspdegppvymxexrqyjxymeknufiqlepuhrud
 * Smoking Wheels....  was here 2017 reheymrplejvhuyiiovkjeqgahxjlsehlvfptxiuxyicuzlu
 * Smoking Wheels....  was here 2017 quhykqbthvskuksueewzcecmbmtngeauuwukyalyvujzfeau
 * Smoking Wheels....  was here 2017 buvyolfbovxknlxbegktnmbxthagywsjftbrbjcozspvkpei
 * Smoking Wheels....  was here 2017 kjkpyigstbpxgaxdagflkuzbatrwlcverdckdxymmbifnypu
 * Smoking Wheels....  was here 2017 jwyqibphuowgtoecrvkzudmrwfyzxodpjyftkwxtrjzyyaku
 * Smoking Wheels....  was here 2017 wbozrrxorpvagpnkixkrxumvrghkscrgskcglueoclidiyvh
 * Smoking Wheels....  was here 2017 ewnxhkdnutbcbaaskstxgeetyplglwtdmyoozkenoijdndlk
 * Smoking Wheels....  was here 2017 rlnvrslnqvfnwzywqqhkqczapjlwbeyhoesqasnjejgosebo
 * Smoking Wheels....  was here 2017 bgknojgacxiqowwbykfeannjqwlvqrzfedxtuyedhdnehzsj
 * Smoking Wheels....  was here 2017 iygwajfvghqbfgnrpxuksstwjqyypfyntythxpgckjxcvpru
 * Smoking Wheels....  was here 2017 qmkdgyfzjnoqhazkyjroeewtlmsipzccaadbalgujfisgmmx
 * Smoking Wheels....  was here 2017 manuupmsbkxlkioctfsifpfoqmrjmhacxcczeluzhxcpseye
 * Smoking Wheels....  was here 2017 nakolclpdbpukmuxyczsvbncaycoktnzpcagrwusmarnpqdg
 * Smoking Wheels....  was here 2017 seejdlrjsswimelhtzwxgtriylmvtgoipeniafkgmktqmxhz
 * Smoking Wheels....  was here 2017 gjekfvfcbyfvzfpwoaykaewqzsmgdynboulzxecdecihijzp
 * Smoking Wheels....  was here 2017 pvbfdudbtpjlotmodrcwxcnlxxecmewilpxdlvndojqbgrak
 * Smoking Wheels....  was here 2017 mzqmrbwtrrilcesljqlixmgowgsaxolplpgaujogavetpskd
 * Smoking Wheels....  was here 2017 unbevrdyvohmtbaanviyhpabdjpwvzhkawccohkvdgrmbomr
 * Smoking Wheels....  was here 2017 tipmxuuspttkwinxzkifoyydhaprvostvyhbljmirtbqmose
 * Smoking Wheels....  was here 2017 vqywjabhnbkgdblzmvhvmhnkehqvvqetxmyxmplntoqsalza
 * Smoking Wheels....  was here 2017 rwycazifkpijkrjkzukubokovmzxyxoujjkvxffnrgvpbyhw
 * Smoking Wheels....  was here 2017 hrqcvughjpqjusaqreyhoblsqedtpdxosvhhhrynarkkghyq
 * Smoking Wheels....  was here 2017 wblbcqunsrwctdofzgntmgwbddtlknlyqhlbiucbqwhllvll
 * Smoking Wheels....  was here 2017 vdymhzceaqupwzeeqjazqycedlwigltbblyabnhzpeuiveqs
 * Smoking Wheels....  was here 2017 xjacfqoudmhhasmoohowzatvtksaglpjfefltdmfebiwtdnd
 * Smoking Wheels....  was here 2017 amsvwowdbprrjwfvzwlqvwubgpthvmcnntutxcvczlrdvylo
 * Smoking Wheels....  was here 2017 jilynayhfmkrhjlphiiuqwjcguthqqljsoprietewhunaxxd
 * Smoking Wheels....  was here 2017 lduvqmylczehlhmvhcazeuxoocpimggbrgrfyjwevzxpkqsh
 * Smoking Wheels....  was here 2017 wipgbtheoeaysbvpvwrgmrbchuqapaibrukocxedgamfjawr
 * Smoking Wheels....  was here 2017 rpzestqgrhdefghjdoquvstwskhehtqzdkkeghuisghlpetf
 * Smoking Wheels....  was here 2017 awivxtytuyawityurkmarlebkvgygpnttlntegdiasgpxnva
 * Smoking Wheels....  was here 2017 iifqehjwlykbssbsetbrvpsggapoixnmmrwhxvxwgsrimpym
 * Smoking Wheels....  was here 2017 jlmigbhdmigcgleininthebegjmsshlqnztzrgzzsvzlsich
 * Smoking Wheels....  was here 2017 avgxcbjkykupbqbbycflhldwujkfsrhuinwhzzozzwyafvpj
 * Smoking Wheels....  was here 2017 nmwnbopqfunkocvnxesfkvbqjxcdaekxouzyrubiyxmlxlzu
 * Smoking Wheels....  was here 2017 hoyrqccdvfepjzrpbbwuidhaxyovnchcflgxqsdvoexgwuca
 * Smoking Wheels....  was here 2017 cmjbnihlptsnjrgmkkvcdjnsjwawicsumkakgyrogiqhnuxs
 * Smoking Wheels....  was here 2017 uyfrvhviqtktstgpddykasqvefxdvbuqvwxxyzxsocksmots
 * Smoking Wheels....  was here 2017 qwvssgqtftrctcunrltdotuqwuarrcunwhtbmofxhoftskdg
 * Smoking Wheels....  was here 2017 cmvrtrxczohtewcfstfamdkpgqhvtpgpriqxyshvochcgaxr
 * Smoking Wheels....  was here 2017 vdbfshbvsffyvluvgujauyeokczffdyhixyqnsaoqedonfbq
 * Smoking Wheels....  was here 2017 uqqioessmarhvjpsllojtjanrroqkqygjfhsuzpkeqleeeyc
 * Smoking Wheels....  was here 2017 euxfpmvvpperqopptylnxxbtqgsgzemjlsnvlhkuxnejcfad
 * Smoking Wheels....  was here 2017 lwnjitolrskewdbiwqveyjtucvniwdfunbszoqepyeqqkyde
 * Smoking Wheels....  was here 2017 iggmmtiankkcimobthvizrukdtdmdevyvegkihtuqdgxmiix
 * Smoking Wheels....  was here 2017 srhoclukfajbgfwfqvwdfcaqboboecklthtmitjroftfzjxe
 * Smoking Wheels....  was here 2017 vaxtmbxqccuwzfalxkldddrtlbzqscgfaubagsjummdyvnje
 * Smoking Wheels....  was here 2017 dmuobduxrljreoirhlmzondhehzbnmxkpjgxffmwnfrqbkoi
 * Smoking Wheels....  was here 2017 hntsqkwvvcdtsqizsrbsmhcagpfluydlrztljnqzzatdevmf
 * Smoking Wheels....  was here 2017 ivxdfwvdqlhtsbvvlznldqlzaoepyhzysubahbyjlqeoszlu
 * Smoking Wheels....  was here 2017 jhpbbtpwkyhlotvwwpnsccjkbxppoquujgdjsqvptewgqeze
 * Smoking Wheels....  was here 2017 wckzsoihsmxzxuqzsxxfakhwftlvnkbfqbalqfakzycuacwu
 * Smoking Wheels....  was here 2017 osgoxalyjccrrovixqsxaovenkzvafpnrccnjajwkmjahofh
 */
package net.yacy.kelondro.io;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Writer;
import java.util.Properties;
import net.yacy.cora.document.encoding.UTF8;
public final class CharBuffer extends Writer {
public static final char singlequote = '\'';
public static final char doublequote = '"';
public static final char equal       = '=';
private char[] buffer;
private int offset;
private int length;
private final int maximumLength;
/** Set to true when write attempts beyond the maximumLength have been tried */
private boolean overflow;
public CharBuffer(final int maximumLength) {
this.buffer = new char[10];
this.length = 0;
this.offset = 0;
this.maximumLength = maximumLength;
this.overflow = false;
}
public CharBuffer(final int maximumLength, final int initLength) {
this.buffer = new char[initLength];
this.length = 0;
this.offset = 0;
this.maximumLength = maximumLength;
this.overflow = false;
}
public CharBuffer(final int maximumLength, final char[] bb) {
this.buffer = bb;
this.length = bb.length;
this.offset = 0;
this.maximumLength = maximumLength;
this.overflow = false;
}
public CharBuffer(final int maximumLength, final char[] bb, final int initLength) {
this.buffer = new char[initLength];
System.arraycopy(bb, 0, this.buffer, 0, bb.length);
this.length = bb.length;
this.offset = 0;
this.maximumLength = maximumLength;
this.overflow = false;
}
public CharBuffer(final File f) throws IOException {
        if (f.length() > Integer.MAX_VALUE) throw new IOException("file is too large for buffering");
this.maximumLength = Integer.MAX_VALUE;
this.length = 0;
this.buffer = new char[(int) f.length()*2];
this.offset = 0;
this.overflow = false;
FileReader fr = null;
try {
			fr = new FileReader(f);
final char[] temp = new char[256];
int c;
while ((c = fr.read(temp)) > 0) {
this.append(temp,0,c);
}
} catch (final FileNotFoundException e) {
throw new IOException("File not found: " + f.toString() + "; " + e.getMessage());
} finally {
	if(fr != null)
		fr.close();
}
}
public void clear() {
this.buffer = new char[0];
this.length = 0;
this.offset = 0;
this.overflow = false;
}
public int length() {
return this.length;
}
public boolean isEmpty() {
return this.length == 0;
}
/**
* @return true when write attempts beyond the maximumLength have been tried
*/
public boolean isOverflow() {
		return this.overflow;
	}
private void grow(int minSize) {
int newsize = 12 * Math.max(this.buffer.length, minSize) / 10;
char[] tmp = new char[newsize];
System.arraycopy(this.buffer, this.offset, tmp, 0, this.length);
this.buffer = tmp;
this.offset = 0;
}
@Override
public void write(final int b) {
write((char)b);
}
public void write(final char b) {
        if (this.buffer.length > this.maximumLength) {
	this.overflow = true;
	return;
}
        if (this.offset + this.length + 1 > this.buffer.length) grow(this.offset + this.length + 1);
this.buffer[this.offset + this.length++] = b;
}
@Override
public void write(final char[] bb) {
write(bb, 0, bb.length);
}
@Override
public void write(final char[] bb, final int of, final int le) {
        if (this.buffer.length > this.maximumLength) {
	this.overflow = true;
	return;
}
        if (this.offset + this.length + le > this.buffer.length) grow(this.offset + this.length + le);
System.arraycopy(bb, of, this.buffer, this.offset + this.length, le);
this.length += le;
}
private static final char SPACE = ' ';
private static final char CR = (char) 13;
private static final char LF = (char) 10;
public CharBuffer appendSpace() {
write(SPACE);
return this;
}
public CharBuffer appendCR() {
write(CR);
return this;
}
public CharBuffer appendLF() {
write(LF);
return this;
}
public CharBuffer append(final int i) {
write((char) i);
return this;
}
public CharBuffer append(final char[] bb) {
write(bb, 0, bb.length);
return this;
}
public CharBuffer append(final char[] bb, final int of, final int le) {
write(bb, of, le);
return this;
}
@Override
public CharBuffer append(final char c) {
write(c);
return this;
}
public CharBuffer append(final String s) {
final char[] temp = new char[s.length()];
s.getChars(0, temp.length, temp, 0);
write(temp, 0, temp.length);
return this;
}
public CharBuffer append(final String s, final int off, final int len) {
final char[] temp = new char[len];
s.getChars(off, (off + len), temp, 0);
write(temp, 0, len);
return this;
}
public CharBuffer append(final CharBuffer bb) {
write(bb.buffer, bb.offset, bb.length);
return this;
}
public char charAt(final int pos) {
        if (pos < 0) throw new IndexOutOfBoundsException();
        if (pos > this.length) throw new IndexOutOfBoundsException();
return this.buffer[this.offset + pos];
}
public void deleteCharAt(final int pos) {
        if (pos < 0) return;
        if (pos >= this.length) return;
        if (pos == this.length - 1) {
this.length--;
} else {
System.arraycopy(this.buffer, this.offset + pos + 1, this.buffer, this.offset + pos, this.length - pos - 1);
}
}
public int indexOf(final char b) {
return indexOf(b, 0);
}
public int indexOf(final char[] bs) {
return indexOf(bs, 0);
}
public int indexOf(final char b, final int start) {
        if (start >= this.length) return -1;
for (int i = start; i < this.length; i++) if (this.buffer[this.offset + i] == b) return i;
return -1;
}
public int indexOf(final char[] bs, final int start) {
        if (start + bs.length > this.length) return -1;
loop: for (int i = start; i <= this.length - bs.length; i++) {
if (this.buffer[this.offset + i] != bs[0]) continue loop;
for (int j = 1; j < bs.length; j++) {
if (this.buffer[this.offset + i + j] != bs[j]) continue loop;
}
return i;
}
return -1;
}
public static int indexOf(final char[] b, final char c) {
return indexOf(b, 0, c);
}
public static int indexOf(final char[] b, final int offset, final char c) {
for (int i = offset; i < b.length; i++) if (b[i] == c) return i;
return -1;
}
public static int indexOf(final char[] b, final char[] s) {
return indexOf(b, 0, s);
}
public static int indexOf(final char[] b, final int start, final char[] bs) {
        if (start + bs.length > b.length) return -1;
loop: for (int i = start; i <= b.length - bs.length; i++) {
if (b[i] != bs[0]) continue loop;
for (int j = 1; j < bs.length; j++) {
if (b[i + j] != bs[j]) continue loop;
}
return i;
}
return -1;
}
public int lastIndexOf(final char b) {
for (int i = this.length - 1; i >= 0; i--) if (this.buffer[this.offset + i] == b) return i;
return -1;
}
public boolean startsWith(final char[] bs) {
        if (this.length < bs.length) return false;
for (int i = 0; i < bs.length; i++) {
if (this.buffer[this.offset + i] != bs[i]) return false;
}
return true;
}
public char[] getChars() {
return getChars(0);
}
public char[] getChars(final int start) {
return getChars(start, this.length);
}
public char[] getChars(final int start, final int end) {
        if (end > this.length) throw new IndexOutOfBoundsException("getBytes: end > length");
        if (start > this.length) throw new IndexOutOfBoundsException("getBytes: start > length");
final char[] tmp = new char[end - start];
System.arraycopy(this.buffer, this.offset + start, tmp, 0, end - start);
return tmp;
}
public byte[] getBytes() {
return UTF8.getBytes(this.toString());
}
public CharBuffer trim(final int start) {
        if (start > this.length) throw new IndexOutOfBoundsException("trim: start > length");
this.offset = this.offset + start;
this.length = this.length - start;
return this;
}
public CharBuffer trim(final int start, final int end) {
        if (start > this.length) throw new IndexOutOfBoundsException("trim: start > length");
        if (end > this.length) throw new IndexOutOfBoundsException("trim: end > length");
        if (start > end) throw new IndexOutOfBoundsException("trim: start > end");
this.offset = this.offset + start;
this.length = end - start;
return this;
}
public CharBuffer trim() {
int l = 0;
while ((l < this.length) && (this.buffer[this.offset + l] <= ' ')) l++;
int r = this.length;
while ((r > 0) && (this.buffer[this.offset + r - 1] <= ' ')) r--;
        if (l > r) r = l;
return trim(l, r);
}
public boolean isWhitespace(final boolean includeNonLetterBytes) {
        if (includeNonLetterBytes) {
char b;
for (int i = 0; i < this.length; i++) {
b = this.buffer[this.offset + i];
if (((b >= '0') && (b <= '9')) || ((b >= 'A') && (b <= 'Z')) || ((b >= 'a') && (b <= 'z'))) return false;
}
} else {
for (int i = 0; i < this.length; i++) if (this.buffer[this.offset + i] > 32) return false;
}
return true;
}
public int whitespaceStart(final boolean includeNonLetterBytes) {
        if (includeNonLetterBytes) {
char b;
for (int i = 0; i < this.length; i++) {
b = this.buffer[this.offset + i];
if (((b >= '0') && (b <= '9')) || ((b >= 'A') && (b <= 'Z')) || ((b >= 'a') && (b <= 'z'))) return i;
}
} else {
for (int i = 0; i < this.length; i++) if (this.buffer[this.offset + i] > 32) return i;
}
return this.length;
}
public int whitespaceEnd(final boolean includeNonLetterBytes) {
        if (includeNonLetterBytes) {
char b;
for (int i = this.length - 1; i >= 0; i--) {
b = this.buffer[this.offset + i];
if (((b >= '0') && (b <= '9')) || ((b >= 'A') && (b <= 'Z')) || ((b >= 'a') && (b <= 'z'))) return i + 1;
}
} else {
for (int i = this.length - 1; i >= 0; i--) if (this.buffer[this.offset + i] > 32) return i + 1;
}
return 0;
}
@Override
public String toString() {
return new String(this.buffer, this.offset, this.length);
}
public String toString(final int left, final int rightbound) {
return new String(this.buffer, this.offset + left, rightbound - left);
}
/**
* Parses tag properties for key=value pairs.
* Single attributes w/o value (e.g. itemscope) are added as key with value empty String.
*
* @return
*/
public Properties propParser() {
int pos = this.offset;
int start;
String key;
final Properties p = new Properties();
while ((pos < this.length) && (this.buffer[pos] <= 32)) pos++;
while (pos < this.length) {
start = pos;
while ((pos < this.length) && (this.buffer[pos] != equal && this.buffer[pos] > 32) ) pos++;
key = new String(this.buffer, start, pos - start).trim().toLowerCase();
while ((pos < this.length) && (this.buffer[pos] != equal && this.buffer[pos] <= 32)) pos++;
if (pos >= this.length || this.buffer[pos] != equal) {
p.setProperty(key, "");
continue;
}
pos++;
while ((pos < this.length) && (this.buffer[pos] <= 32)) pos++;
if (pos >= this.length) {
break;
} else if (this.buffer[pos] == doublequote) {
pos++;
start = pos;
while ((pos < this.length) && (this.buffer[pos] != doublequote)) pos++;
if (pos >= this.length) break;
p.setProperty(key, new String(this.buffer, start, pos - start).trim());
pos++;
} else if (this.buffer[pos] == singlequote) {
pos++;
start = pos;
while ((pos < this.length) && (this.buffer[pos] != singlequote)) pos++;
if (pos >= this.length) break;
p.setProperty(key, new String(this.buffer, start, pos - start).trim());
pos++;
} else {
start = pos;
while ((pos < this.length) && (this.buffer[pos] > 32)) pos++;
p.setProperty(key, new String(this.buffer, start, pos - start).trim());
}
while ((pos < this.length) && (this.buffer[pos] <= 32)) pos++;
}
return p;
}
public static boolean equals(final char[] buffer, final char[] pattern) {
return equals(buffer, 0, pattern);
}
public static boolean equals(final char[] buffer, final int offset, final char[] pattern) {
        if (buffer.length < offset + pattern.length) return false;
for (int i = 0; i < pattern.length; i++) if (buffer[offset + i] != pattern[i]) return false;
return true;
}
public void reset() {
this.length = 0;
this.offset = 0;
}
/**
* call trimToSize() whenever a CharBuffer is not extended any more and is kept to store the content permanently
*/
public void trimToSize() {
final char[] v = new char[this.length];
System.arraycopy(this.buffer, this.offset, v, 0, this.length);
this.buffer = v;
}
public char toCharArray()[] {
final char[] newbuf = new char[this.length];
System.arraycopy(this.buffer, 0, newbuf, 0, this.length);
return newbuf;
}
@Override
public synchronized void close() {
this.length = 0;
this.offset = 0;
	this.buffer = null;
}
@Override
public void flush() {
trimToSize();
}
}
