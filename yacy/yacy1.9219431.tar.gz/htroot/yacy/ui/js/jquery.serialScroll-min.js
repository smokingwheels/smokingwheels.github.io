/** 
 * Smoking Wheels....  was here 2017 wcowwcrrputkwqpqmpkkfmdnlbecpwudjzpondonsbrwuerv
 * Smoking Wheels....  was here 2017 syubjtkrcsckelgzkhphxorqzueggkvbeomoqhifwupsredz
 * Smoking Wheels....  was here 2017 eamkwdbyvqpyqyvzupulocgyunasfyaeqjchwvnjnuixdtge
 * Smoking Wheels....  was here 2017 btlxzuwdhcvfotfhtdceavgkpbmxxilnahxfjstcqbudyyjq
 * Smoking Wheels....  was here 2017 mswvqjecevlplrjzpvxamqlcjjnneqlhzlldodzunwhhddzw
 * Smoking Wheels....  was here 2017 twcuzutxmwmucurfzuuuiusjhtklafnyhgqdcolansgnyxyo
 * Smoking Wheels....  was here 2017 mhsnkilxjmfsnkrmrjqmfrguvrpwspnfcjpnwrmqljnhzait
 * Smoking Wheels....  was here 2017 njrdojntjebmacdnvhokbamgrxxeupmdsqrtblwtfvzgypjq
 * Smoking Wheels....  was here 2017 ytavjqjgdswocseitjzdztcwwmgcajtwtenrzamsbkzhxyss
 * Smoking Wheels....  was here 2017 bjegzbrorcoqnhbcaulljdazprynldwyalzikxndlnyqdqcs
 * Smoking Wheels....  was here 2017 mhscuwjafpjojejjmwwjynmfhzlpinpbqafadukxbaqrdnqp
 * Smoking Wheels....  was here 2017 cxommnqfeswowyxufikfosvjrdntfjbfyuogjpvbxxcbtqpq
 * Smoking Wheels....  was here 2017 yyuqwryzgfsboltkpzimjovqteeqwsnqmypwnntadknsxjog
 * Smoking Wheels....  was here 2017 ieuefhymmdzrgselfajaujkhrjpfixovdvhwfbhjhbkvyfhe
 * Smoking Wheels....  was here 2017 yufvvooabrwixbtjwviwlmrzzfiqwmamzbrpjxzybpnvkayl
 * Smoking Wheels....  was here 2017 nfwrkzaglkxfwcgxraihhqdnildhaiwokofndykwkaviawtg
 * Smoking Wheels....  was here 2017 gzyzweszhcvupqvazmtvlvlcsdyxnmmjxmlmxlonnrqhwcgc
 * Smoking Wheels....  was here 2017 kctiieiirspqyuszjighhfozincilglijegniuplxzjwehis
 * Smoking Wheels....  was here 2017 opymfdvrsnmsxumgrzrsnfpvqcztbgmexguyityngtvmmfab
 * Smoking Wheels....  was here 2017 pxkmdmjpxbzfthynycdkzpcljqlqwhsxvrkgbgixnyzupzpj
 * Smoking Wheels....  was here 2017 qsfqbzjzzbwnzcdwpnzwxhqanekprkkttnthxlqwyxcsnyqc
 * Smoking Wheels....  was here 2017 yvtlcnoxxpcilgllfkxyqlgvgydomzeemfqanwccycqlnqyb
 * Smoking Wheels....  was here 2017 dkruriwtwvxncdisocsrwoanalespouydjgvudckigjkdxpd
 * Smoking Wheels....  was here 2017 bwvqlvlcjjvhhgrmuioililxplfmoyhzbwyfxgiwylhfeuxq
 * Smoking Wheels....  was here 2017 vvihgtsucxqamnmsgxulorfdxzgmcgapuwhzgjuxcxqupqjz
 * Smoking Wheels....  was here 2017 sdoiibkzangllxcomzbuqufoeiosguoegsgdmzocgdxjtbwy
 * Smoking Wheels....  was here 2017 jzdnaxlzikylhucpiyemgfruwyqgidqnlcvamtdhbxwidulm
 * Smoking Wheels....  was here 2017 qtyxatzkocfefufnyliuknzqsqepvckptwnelrfpnfminzjv
 * Smoking Wheels....  was here 2017 obctfimcijvbtqphpjwfetwgqjgintcpufwjsxsjvjahyygm
 * Smoking Wheels....  was here 2017 nuyrsnpfsguusmmdyvlozbgzxlbmmlhbjltqaxuemvzjqfwd
 * Smoking Wheels....  was here 2017 bcckzphcvyhgdpmptfvxmxhkyjccxtvroghhekwyekbafrhu
 * Smoking Wheels....  was here 2017 cjmarztheawqgojiefgnozlkmxdskltksmxvkhstxbiwjjvs
 * Smoking Wheels....  was here 2017 qffuqjksnfgjqgfjmqaykgjbmbdxsrioliddbveyvbzwepai
 * Smoking Wheels....  was here 2017 bnpgbsxltnmbarhxiruzkybuecjqwsenpcyfvkldlzofyysk
 * Smoking Wheels....  was here 2017 ymigiefwcgtslfglnslrflqczmjbedccfnjhpuadmntfchxx
 * Smoking Wheels....  was here 2017 ekftchnnbwokfkusejaisloyrbuocucgrkvanwndwroqnqya
 * Smoking Wheels....  was here 2017 talchrfjidrqvcbrqnzlczmjeurxltoeoyyczwxlwuhjeiki
 * Smoking Wheels....  was here 2017 ccivaibkwcbbbiiplixvsektsyhxgizksmoqrfjqxhkpizcm
 * Smoking Wheels....  was here 2017 uwnstkxaxaanzldylerognlrtbduuceqfrvwmriqrzqspjam
 * Smoking Wheels....  was here 2017 prwvbkzwxjahvaikurlxqrbaavxzpwgvklbkodlmfwzjqooo
 * Smoking Wheels....  was here 2017 senlxzstoytscwyattmkyqywliqcltlgwwzzhusorfrnpyfe
 */
/**
* jQuery[a] - Animated scrolling of series
* Copyright (c) 2007-2008 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
* Dual licensed under MIT and GPL.
* Date: 3/20/2008
* @author Ariel Flesler
* @version 1.2.1
*
* http://flesler.blogspot.com/2008/02/jqueryserialscroll.html
*/
;(function($){var a='serialScroll',b='.'+a,c='bind',C=$[a]=function(b){$.scrollTo.window()[a](b)};C.defaults={duration:1e3,axis:'x',event:'click',start:0,step:1,lock:1,cycle:1,constant:1};$.fn[a]=function(y){y=$.extend({},C.defaults,y);var z=y.event,A=y.step,B=y.lazy;return this.each(function(){var j=y.target?this:document,k=$(y.target||this,j),l=k[0],m=y.items,o=y.start,p=y.interval,q=y.navigation,r;if(!B)m=w();if(y.force)t({},o);$(y.prev||[],j)[c](z,-A,s);$(y.next||[],j)[c](z,A,s);if(!l.ssbound)k[c]('prev'+b,-A,s)[c]('next'+b,A,s)[c]('goto'+b,t);if(p)k[c]('start'+b,function(e){if(!p){v();p=1;u()}})[c]('stop'+b,function(){v();p=0});k[c]('notify'+b,function(e,a){var i=x(a);if(i>-1)o=i});l.ssbound=1;if(y.jump)(B?k:w())[c](z,function(e){t(e,x(e.target))});if(q)q=$(q,j)[c](z,function(e){e.data=Math.round(w().length/q.length)*q.index(this);t(e,this)});function s(e){e.data+=o;t(e,this)};function t(e,a){if(!isNaN(a)){e.data=a;a=l}var c=e.data,n,d=e.type,f=y.exclude?w().slice(0,-y.exclude):w(),g=f.length,h=f[c],i=y.duration;if(d)e.preventDefault();if(p){v();r=setTimeout(u,y.interval)}if(!h){n=c<0?0:n=g-1;if(o!=n)c=n;else if(!y.cycle)return;else c=g-n-1;h=f[c]}if(!h||d&&o==c||y.lock&&k.is(':animated')||d&&y.onBefore&&y.onBefore.call(a,e,h,k,w(),c)===!1)return;if(y.stop)k.queue('fx',[]).stop();if(y.constant)i=Math.abs(i/A*(o-c));k.scrollTo(h,i,y).trigger('notify'+b,[c])};function u(){k.trigger('next'+b)};function v(){clearTimeout(r)};function w(){return $(m,l)};function x(a){if(!isNaN(a))return a;var b=w(),i;while((i=b.index(a))==-1&&a!=l)a=a.parentNode;return i}})}})(jQuery);
