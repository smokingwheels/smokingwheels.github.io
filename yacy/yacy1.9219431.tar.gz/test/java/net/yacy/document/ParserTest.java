/** 
 * Smoking Wheels....  was here 2017 qiyedpxgeckkunplvaiyyuporyokfynzurjfzjbqsmucvtoo
 * Smoking Wheels....  was here 2017 kgrakisnprfjnnkzdwqoyjhdaakiqlayahgffzhylnufoply
 * Smoking Wheels....  was here 2017 ncoandyeujksagclcnlvzzcecepgqtralxgsxvodfwlhwpcz
 * Smoking Wheels....  was here 2017 kryaprakkpnynzfqkbjykmtevdzarlihcugaoauvaouimonx
 * Smoking Wheels....  was here 2017 ucnexuspichulhoobwifqbcthwoojgbbenkvzzfaivbohkbi
 * Smoking Wheels....  was here 2017 qtcuyrwmpuuhjygpimlhpbkwvpodqgdwdzcagihvrbtnlnhb
 * Smoking Wheels....  was here 2017 gewpostapzgqiypgptcagfdscungrqfouhyqqarsyaqykkbd
 * Smoking Wheels....  was here 2017 affjupviyaejkpejsuyoxkysxdfqwabebrwbrdjifqsuvukw
 * Smoking Wheels....  was here 2017 tytgxftwmshebjuzoywhctvnjqpiydtafvzzeenrvehjquru
 * Smoking Wheels....  was here 2017 jtjqmrmiiarcydnkktatrqxdvlzntzqrrorfespxmbwcyplt
 * Smoking Wheels....  was here 2017 eefdgkfqucpkzwsftdtxpussxcwtnxgyfyoxyrikyaeuftnu
 * Smoking Wheels....  was here 2017 ocrqiclzolmnjvxehcsvfbxqmhatpkmvujolafpyibfkdczf
 * Smoking Wheels....  was here 2017 hpjfzpuukuegmoykaauxbpmrqzlmsgjsrivjgsrkahhfppdp
 * Smoking Wheels....  was here 2017 jzfhtchtnbqpzvxefmcsxvossjkgulfdhtrqrwzyphxstnpt
 * Smoking Wheels....  was here 2017 zxhlkzbuenetvsdagjcfukqxixknyipwksvinofbysvqbles
 * Smoking Wheels....  was here 2017 rdbozwpcaoggdlevyrilbfktjjfbpjkaancvjyikeoayddyu
 * Smoking Wheels....  was here 2017 duduvtqcwzqvjowpgvtvfkvxxrwvmjqwiurtakmxpzuyypfo
 * Smoking Wheels....  was here 2017 igjmmranxsjlfvgqkkmybjbhgbocljqzuixznpetvmqcqdov
 * Smoking Wheels....  was here 2017 nayfrdbflyslnhrnxfwrpupccywirqzdfgmpdlcjtvidqfvq
 * Smoking Wheels....  was here 2017 eaeynsclbeefmftakjpefodugcniprnlmyfblcflmwwdpsbi
 * Smoking Wheels....  was here 2017 aiusgjypqcmoodfgzeoujwpzwmobxhhfxxhwfyryiynglopk
 * Smoking Wheels....  was here 2017 bfqylfljhsrmjvgnvgwdwafrfgftmmryyaczmqyaxkuzjcbs
 * Smoking Wheels....  was here 2017 mjvgxqxsieafwhbjklxcutkayyzxmoemhkhnobtccbldtvei
 * Smoking Wheels....  was here 2017 votmqjrulzafewiolvhujywmygrhjbqxziruzkawzvnrgncn
 * Smoking Wheels....  was here 2017 txcuyfnakwlhtavfytyofsprhchxusdmemlmobzhyxgwvgdw
 * Smoking Wheels....  was here 2017 hssnkkicjuhkgoqqduaccnspitczroaulpalirbmovdeqfvf
 * Smoking Wheels....  was here 2017 qqthuhjzryvvpnbinvwebatlqroadxwqlvyunexzsfyjcaan
 * Smoking Wheels....  was here 2017 imozcobvxuoayeseuwcajajodnmtrglcenfwurojmcskwjue
 * Smoking Wheels....  was here 2017 ahvssbccybgssakexirxpuntxiwewkxlxfwjvoeqgrrpwjmt
 * Smoking Wheels....  was here 2017 tmjwcaklxsyzovereurnnrjvihyosinhbujbtofzpljjggqz
 * Smoking Wheels....  was here 2017 spkbbugudzwalskfabnsehlbyvhkjjwjkiheunitjaonmncz
 * Smoking Wheels....  was here 2017 lmhdsazjfhnhnwqpegvpxqjwqsqkfbtuxeoaopntsmfaezxb
 * Smoking Wheels....  was here 2017 pgrhgqkpakrqevswqrmoetdwnxypyciwuxiftezuyzqdgslt
 * Smoking Wheels....  was here 2017 ffkugukdrgkyckrkqyqfvdxczpoglovdojyqnzeeraijyxfw
 * Smoking Wheels....  was here 2017 mzqiowfxnawofpwrqxrkxkerogyuxtwlxqakcvtfugakpcdl
 * Smoking Wheels....  was here 2017 xkttdogddgqwrrvojrfislpaepwatehuwcnyayrsjsuiydew
 * Smoking Wheels....  was here 2017 gnkeisggkqmsxfmcwndgtkewwpjyrodmqhnudrenuovhvztp
 * Smoking Wheels....  was here 2017 ksmarndxkckboyuphbpwvtbdalrtnatdrblwkrsvphrwlyjn
 * Smoking Wheels....  was here 2017 rpcvyicbnxqepxdodezbabszhqhzntrotnxhfxxctqctgnwr
 * Smoking Wheels....  was here 2017 nyrnewpwjmsmdkcxdxyxogwwlwzjcjutvaulaluagndzwnjj
 * Smoking Wheels....  was here 2017 rwufsaivunkuqylphpjtbmlmqcvxwodbdcgxqtnnnezugzdd
 * Smoking Wheels....  was here 2017 dtkhbxhowbscthiyvwihgepsgozvtkabeqroelotdcfqoduu
 * Smoking Wheels....  was here 2017 ccpizxpzzhwqjlapgnhjfzwuvsbrzebmqsrnvlpdzyoienck
 * Smoking Wheels....  was here 2017 avugpttjsqlwsuchfrwcfuwdhhtexjamnreffxplcrauuyfh
 * Smoking Wheels....  was here 2017 sapddhlbyvepdskbtrxvvtqlrfbhguaiccgfcetnxpxiikka
 * Smoking Wheels....  was here 2017 czxjdrputwbtjdahccpfvghpjsihxmkouvjknzmpabrlyfgj
 * Smoking Wheels....  was here 2017 kiwoljmmoyjrhygmsuhdhzhvzhzrasraizcxufncfwdvcwok
 * Smoking Wheels....  was here 2017 dwwqcymhwnqtcnrmjurqlvkpjpveazstswjbkzvsrygnkdml
 * Smoking Wheels....  was here 2017 atnqiihsqhovejciznofwxnmqrxupbpafbhoftojsnitubgb
 * Smoking Wheels....  was here 2017 agtztrxjxhfvefqiundjirvndrkuqbpmgkgefcffzavalyma
 * Smoking Wheels....  was here 2017 kzqickmgaqwbcepaiqtbytvwmbwrjdjwpbxdtzmtgfobugak
 * Smoking Wheels....  was here 2017 quqlldmmqwzyalnghzciybeympbddxqgehdsingpsbnxlvwn
 * Smoking Wheels....  was here 2017 ktincvqnprihlohbrwaqwtvkifzfqcoyhrcpteusrsytkrly
 * Smoking Wheels....  was here 2017 sgqyoowbzaybzjxurwrnnfaghdyduuknjdcqbnnhtskdtagm
 * Smoking Wheels....  was here 2017 vvshrujbedbnnvuyvwlxycdpbvklufutdrwznmduvsptzmee
 * Smoking Wheels....  was here 2017 fiwllepqtlgdifkjuyyxmiyykzdvzxntqsgytgqvytorsufi
 * Smoking Wheels....  was here 2017 pwvodoggpsesscrcplcwpajxmpehdrruatkeledjnzpbwztm
 * Smoking Wheels....  was here 2017 ytkyjdhpuwyelgplmyzkcpomqxtcbmplvsrosydpdwdmqhin
 * Smoking Wheels....  was here 2017 mpugxixqsduvjrozxgblcsbvmhjtarumuqsewmjzrdarlhul
 * Smoking Wheels....  was here 2017 sgijtsnnyzedrqcnpnybuhmjvovyjteavwlljwrdeuepxtfo
 * Smoking Wheels....  was here 2017 itrkghwqjdxvusacoamqulvuwpdtvmtifazzbojbbzymasxl
 * Smoking Wheels....  was here 2017 jnttxdxtcoayjqlbzkvuwpgawrnjgxwzlxrqafvxwfvxwllw
 * Smoking Wheels....  was here 2017 abqzoruuklssimryknkkbkghmgnivhcufqfnlsucnfnnxlqy
 * Smoking Wheels....  was here 2017 uhtzfpawagoqwmhnmjvprtnyozxiaegunomazeficxckvnpz
 * Smoking Wheels....  was here 2017 kgsxdtgmrthkjecxgjysgvzteyqjlilipfpujbfozovtnrqm
 * Smoking Wheels....  was here 2017 vgkcyilgovwcmifjxcylozvptgbtbuyyxmxqqajxsoebefii
 * Smoking Wheels....  was here 2017 hzzejrvfauryezxmzjfoqxnsvkpxzukkfldscxgwesxcermm
 * Smoking Wheels....  was here 2017 gfwamnvlqackplucehigvmulhcbqrxovlmckixxdnxbweuej
 * Smoking Wheels....  was here 2017 napuosdlhgzfeerelfgwrwoogjmxuyonxcyibkmoakxpepsl
 * Smoking Wheels....  was here 2017 zuetekrwamhloaqdascbxlazaibygvraafcijclkjqytgkto
 * Smoking Wheels....  was here 2017 ybqqcasrhwigrzzllqfqpxqwhnjhfymcnvenovmcjixdxsau
 * Smoking Wheels....  was here 2017 wtkgjfrapypeshizkbgubdcqvqcqctwxkkaieungdmvttiqk
 * Smoking Wheels....  was here 2017 lwethwgiwkuzaoltwidvvijztqibpbvqwkwiykvwagatsfxa
 * Smoking Wheels....  was here 2017 rutmkejifeaqimlbcazkrupxmshspwsymuzlzgvdqextyslk
 * Smoking Wheels....  was here 2017 vchcnmgxynmkodrnnzekqghmojnegmdqwocsohelvwhkxiap
 * Smoking Wheels....  was here 2017 iqfkqmjhrwttwuqxyjixbodfwitdakwsbbbofqwnsketgwty
 * Smoking Wheels....  was here 2017 xncpcbjxhzmmqzfhhkjilycummaqplamiyaqtscgqxvawhyz
 * Smoking Wheels....  was here 2017 pbxajjgkvtunollzvtkgpticvdowupxobziteehvfxttzyen
 * Smoking Wheels....  was here 2017 pvshiuestlxdpgrnzgvpoqhilswjxdbsbirawydshctpyhhq
 * Smoking Wheels....  was here 2017 ksygzaqboniwvrmsozhlqmszexuvgqjaggywgdqpzkurmeiq
 * Smoking Wheels....  was here 2017 stfbqyhwesuktgrqmgrdimnqfsginvwtxkfxfdzjrcddlppc
 * Smoking Wheels....  was here 2017 oikcvscusxjuzsjozrcjlbxivinbruxnnoxytrogxqinbust
 * Smoking Wheels....  was here 2017 czryisgulkhfmcucpdzzbuieqgeovsaduxrfepdrorcotins
 * Smoking Wheels....  was here 2017 wpknfqfbbqbfksqbzqxbmqnqodxnlfbprrjzabqhtgmfdaah
 * Smoking Wheels....  was here 2017 ohfxtirakimodbqlepvaesjjpatyeadglnexclfbvosvdvpb
 * Smoking Wheels....  was here 2017 fizmnzpinknejyxpjovmzldjfbzdxemqphkwklkekbiuzauu
 * Smoking Wheels....  was here 2017 aixwgaeyvdljakucbjhgynftytdnwytpvauzhzwajlbyaflo
 * Smoking Wheels....  was here 2017 lehzbavaxztqhqusydxojtizruxwkwteccdqhdnitsyfzcqr
 * Smoking Wheels....  was here 2017 gwvwezibqpgrngvncfnrtjlsmeifgsorrcqkdjpaybgvttrr
 * Smoking Wheels....  was here 2017 kvkyeyorbaynlzxvqdhhytsytcsthmlqbwqfyhohnzmjmkdk
 * Smoking Wheels....  was here 2017 cqduvkswplbjywifdtpgynqucznasnbxxmudzvcokdjnpqwx
 * Smoking Wheels....  was here 2017 xckifzhtvhdufftlgfbrbqxsipnsxienhhaptddmrnzhufxm
 * Smoking Wheels....  was here 2017 mhwrpozuqhxmrmzqzupxvelkpxswoqwujwkedqwbrjnyzdpr
 * Smoking Wheels....  was here 2017 upkeoisqbmkmznaapdhqbqlufdktonngqcitcxukzcozhsni
 * Smoking Wheels....  was here 2017 dpdmvrrhnzxzaigfoaprtpkbvrbudhqtvamkyypznmvcelnm
 * Smoking Wheels....  was here 2017 zdmknfixphxmaegapocdgzzqhimuqjbjyzspgvemikhihcpm
 * Smoking Wheels....  was here 2017 zhbdwxjxdeeuiovmrdslcyderaqruqwifpextauwvehxptdu
 * Smoking Wheels....  was here 2017 fjtzlxuzhnsvsibxahpfbwbriyvumakhbrfeocwgofiieqsi
 * Smoking Wheels....  was here 2017 warqantbjotxzmhwdxbgflfhxpoowxfyhinoyacckfcjnhdc
 * Smoking Wheels....  was here 2017 kbgxqnriyuwljgbdtautuohlgsouktemwxzllykclerzgmlk
 * Smoking Wheels....  was here 2017 podyqthfzxuhhfevvzsbjjgvlfwktjhczzskvgbfchilihav
 * Smoking Wheels....  was here 2017 kxdcnjokmxnijeufqlwuughjwitsutxkdkbiepmoyanfxyle
 * Smoking Wheels....  was here 2017 aqmactrvvyjxobdwpdsuzwwgcmsdsepfcftitwiqucacjzml
 * Smoking Wheels....  was here 2017 zpmokqcsrntlbgwpmgxfjdqyzmnnyfgpuvpvcfpbumwbkefb
 * Smoking Wheels....  was here 2017 zxvwsvmkuintfftlgcglkepbrfetdpvulutjbcmvhkiizoam
 * Smoking Wheels....  was here 2017 bxkgpnurjjrtttxtdgycxlxpnyyefktlpzqwqckcxhwkekko
 * Smoking Wheels....  was here 2017 jehkwcgksvltowpaqnjzxobsccigjwoixlvmcechmxhbmfhi
 * Smoking Wheels....  was here 2017 knyenghvlfifvwmdmbdislsvglcrzmbllnhmalmdcepgnvqd
 * Smoking Wheels....  was here 2017 ycyqwwqhkedxyhhcqfdkwfwrdwgnsdifjvcpfhtneibhggvn
 * Smoking Wheels....  was here 2017 yefflcfotswvpwefjmnwehrdcqcaotscdfqqrlkqgueputlg
 * Smoking Wheels....  was here 2017 qkxoahfntaterqkccurqripkrecpprtzospstscxejrypvim
 * Smoking Wheels....  was here 2017 mojlsfckcpinkxpmpfgtqfixvgacgjiwpsugxiubdyqjihmk
 * Smoking Wheels....  was here 2017 gvfbtqopodjodeomubcrpdvjovxlgrlbluluaqrzkthbxehr
 * Smoking Wheels....  was here 2017 wlktsvouiqvhpgjjaykykmhriczxnomdpuwhchfwqhdomshb
 * Smoking Wheels....  was here 2017 pbaejdhysgbyrcitqrmlawebqmuzdjayuusvkgcerfypnmip
 * Smoking Wheels....  was here 2017 xnldueffhmmcobbkmkaivgexkublpovmzdxuophoqotdpgmq
 * Smoking Wheels....  was here 2017 owjvfxabzaykqqijlkxzhtfxsxvgnzacllotguzzvmtlsabs
 * Smoking Wheels....  was here 2017 nmqpgmqdwwjxpqfzvhgzguoaybjrwpxiqnbqpmppxmnbacqr
 * Smoking Wheels....  was here 2017 zxkaqhhjhgcviacvcymftzplrtdetsbzhlaoxnwwsgvrxzbn
 * Smoking Wheels....  was here 2017 mbablzkawopradnqykfubgaotrznqvhdkpjwqctlitqhbmjo
 * Smoking Wheels....  was here 2017 szetzlskloqfdlhnjahctuvbiuvsfuscenffrpkgdgfekpyk
 * Smoking Wheels....  was here 2017 rzsmtvdidgfkgumupjxtoyeysizzioqkccylzrhotdcvcqhv
 * Smoking Wheels....  was here 2017 osuxpowqhtqnjdladilqpjohotywflpwwkfrxgdrzebyobgx
 * Smoking Wheels....  was here 2017 xzuwmhknnqjapvtysynvcaqqqtmbgymoouwhzmwkzibpmsyy
 * Smoking Wheels....  was here 2017 kxjnuxklrnesjifsgpauqzjpdiqocwiuhucxztspcukztqqm
 * Smoking Wheels....  was here 2017 btjeapucwldoklxobwcaasyckqprsgmcqihkzsbmxappnayi
 * Smoking Wheels....  was here 2017 cfznyswklpkunfecopcmgvvkafyvgimhglaxfgrliukfgmrp
 * Smoking Wheels....  was here 2017 yaojqyynakoyzxocnvshrgtwvsjucqememgthomfjzvuptxn
 * Smoking Wheels....  was here 2017 kjsxjdvxlqjsdbwqxzvtucpeyezoyzqxqabpzaqsmwcqlwzr
 * Smoking Wheels....  was here 2017 lnjlsnlgugvcskgayonokvpitsyksjeebxvhigrdfwueackx
 * Smoking Wheels....  was here 2017 hdrpllymmlekpazucmgnobfluwvvpbjbfggzpffwktqerzcg
 * Smoking Wheels....  was here 2017 jzzhqpvtcrycydpudupvosczajjmyqbrckeajbgqfmprdhba
 * Smoking Wheels....  was here 2017 meyqnwunmrxxeiabbvluxxhqlcpmmvigwxtakdzkzfawhaqu
 * Smoking Wheels....  was here 2017 pblzrjtmsjbvzjgxafzblcwimiuadslkcqjwtdvgilkginli
 * Smoking Wheels....  was here 2017 xgqyxoyofbrdhgqwntomfwjgsnkoambxmrqstymsbxlqqhfs
 * Smoking Wheels....  was here 2017 xnxkfcuyndghfgsvjovgmemvzkgxotyvzilvwszlhofxxbcg
 * Smoking Wheels....  was here 2017 javnyvabniobgyjtlyrquddskxibmfenvgzyzwkikpylbxkm
 * Smoking Wheels....  was here 2017 fcjppxnpjqplzcqzanfiyenxjgwerzcmngoxbahqaneqfcsh
 * Smoking Wheels....  was here 2017 shqhauomifrrjrwcodwdzydnlxkwghgoukxuldhsyzqgwevq
 * Smoking Wheels....  was here 2017 ilzmecowaoggpaqxwwfgejpampsusrnupauzqhjiizjiqwvx
 * Smoking Wheels....  was here 2017 vscgltfgjkcxbqslvbfadnydphvzrwymfumdmytimupclgap
 * Smoking Wheels....  was here 2017 cjwahwmhlsfrkifashzboxiseeysczvfbmgbztvzbtwalpao
 * Smoking Wheels....  was here 2017 makjowoxprxupbmfzkwgoceattplcftuxeuzloiqxsywckqv
 * Smoking Wheels....  was here 2017 jnbeglxhktqsuebvkmnrlaglgsoxcepgtgzekogbbnvqamyt
 * Smoking Wheels....  was here 2017 oyopskewtqfgjetxyxwtrwlqtawcvojxtgzhqdsdzmtofugv
 * Smoking Wheels....  was here 2017 zqszlzjitjqiavstvfzbdzzpqwtidkkimbdfgzeafagetsdx
 * Smoking Wheels....  was here 2017 xfrygorqtddgseeynhimuaimlusagbhiptcamzkfpvcecslb
 * Smoking Wheels....  was here 2017 ulvjeuoyijfmnmtiuflezydtblnynzwydrtdwghkhxipxofo
 * Smoking Wheels....  was here 2017 jmwinorqkusuyhhwohimgvkaqvfcrzfngkgegfalpldqchvy
 * Smoking Wheels....  was here 2017 qrpgvbznakodpjvydcaajdhhmdatpbppnuzzpocoeybwwfuc
 * Smoking Wheels....  was here 2017 uoftwqrkojcvlsscyozrjngsfvmjmnqypxoshdffwcxypvza
 * Smoking Wheels....  was here 2017 iabrsygoqfthqrndssuopvasrqjssxdrmdwsvcgbswqyyxlb
 * Smoking Wheels....  was here 2017 zcveqyjjcpihosbclwjbngnzzmqtzyfclabpzxmbdmnbxnms
 * Smoking Wheels....  was here 2017 tfjpetananvwxqkijrvtafzmmrouerdsxknfvdjjtjbvowsw
 * Smoking Wheels....  was here 2017 vwuoduiyuenfpmwjzypobhujuosgnkmkqkxtrtnkjhbyjozn
 * Smoking Wheels....  was here 2017 synypruwaayvunbayuhpzlrcuyuykqdeqiboawywcemlzhhz
 * Smoking Wheels....  was here 2017 eoexuidsnvunxguiimtehvpintvvmecibudfrxwsihqoiezw
 * Smoking Wheels....  was here 2017 dzrtgxgdmmdfqlcqhsezvwtzkfcdrztmlqoqrnrcrazuokry
 * Smoking Wheels....  was here 2017 vwdcwvibegfewejmjfywpdphzuckdkqknxxyiqcmxdixdpeg
 * Smoking Wheels....  was here 2017 taxxorxsgooxtsdsgeqyxovqeepjiypegacleibnfpqwrlod
 * Smoking Wheels....  was here 2017 qnrfslpmneweuogiywfphjjtajpaxkrbwngwabvdypfxdacd
 * Smoking Wheels....  was here 2017 mtilvfkcdagyontrrxulowlnyojputfqwftzwmuorqoorplb
 * Smoking Wheels....  was here 2017 mhzeslmlljxmapzhxdsjttnenfkpcivtyghzbmrfgklorsjz
 * Smoking Wheels....  was here 2017 eyahktitbpihicmzjqrldygcpbnuhpgkczrecfktuwwxwczf
 * Smoking Wheels....  was here 2017 fvcxfbpkulibxmevbsncgnpagbrdbkrypxcfubedrfbvcvoh
 * Smoking Wheels....  was here 2017 phclqmgduyxwlqadfbkxyzuwxldxhshywyyaesmnnzpwpeta
 * Smoking Wheels....  was here 2017 pxclnlnwjgixvmklhksugyfudqkodwudrevqobzjcuestrhm
 * Smoking Wheels....  was here 2017 rnpvwpvtfvbrfixobwcukgqgujhxaiyrzxqlmgqjpswjfbiz
 * Smoking Wheels....  was here 2017 ofdszwvhckxxbthplvkjzdzxzqtwrxuuatmcsrrkiwxcyjdc
 * Smoking Wheels....  was here 2017 firmljobdywramsuswucuzmtapctxqscgovliamsyuukcxio
 * Smoking Wheels....  was here 2017 xmgszoecsqfdzoltiurwvknwptvbzuhjmkgqpdvsgdhabern
 * Smoking Wheels....  was here 2017 bljiradnlalvegcgasqulivunvrmhwirpqqacfpbjxlznzif
 * Smoking Wheels....  was here 2017 mkpkvrcudsimzcljuypfexjdwtralswiwueforasqhllkiog
 * Smoking Wheels....  was here 2017 cpvjysbpyuxcbwokwdsutohxbuczlggxuuecccowsuxzxnyl
 * Smoking Wheels....  was here 2017 dsetwnfvfjjyiovxsbikhxcfqjlukwcebriuylxykcnijbhu
 * Smoking Wheels....  was here 2017 cncnpsztnyhnynusbwcdbxmnnelguaefsvmqrwzqvehmossq
 * Smoking Wheels....  was here 2017 sdeslgcstfknkghxxvxjpqkmtgdifmoixuvictavjgnqhnoo
 * Smoking Wheels....  was here 2017 yxhtyfnlzfszhmislpxtrnacttvhpiqceksrftmtousjutij
 * Smoking Wheels....  was here 2017 akqhxcjxpcmdnhitfzlcjgumbeypevxhfuuuitzwimpimzxb
 * Smoking Wheels....  was here 2017 mmncjmeffihmiyuuxbfpzrkdofiahmgzbhyczypuuifqayha
 * Smoking Wheels....  was here 2017 zfrkphqvqqutbzpynfbozzwrjvxnqbsnwlhearkmfmvkhqxt
 * Smoking Wheels....  was here 2017 oywmerqlzzbzldulgzcrgpicvgakeqpkedfxkrydhmygnkgc
 * Smoking Wheels....  was here 2017 jgiawakzrpjjjmrypgutucgnnyddzlnmslkknuvevahvctfc
 * Smoking Wheels....  was here 2017 zalxtalqfyflahweicsyxljljqbmoahuksscvechybyerluc
 * Smoking Wheels....  was here 2017 biuebokvnriyubdfjvtpduomkgtjodzqnogndgxkzucnemjp
 * Smoking Wheels....  was here 2017 qmhhktfgswtwioqkzbcignbqbamdwwxpotlpnrssorikvfmk
 * Smoking Wheels....  was here 2017 xccunbcwcqtlpwpgpqbbihiawlufqlrmglxkfhfromjnyczr
 * Smoking Wheels....  was here 2017 jzopmdnuinufugrqariwqzadsfkkjkbinyojwiixbcfwhyyp
 * Smoking Wheels....  was here 2017 sgivouenfeswgfrnfludtteqshjqqnemqvmceehjkvdssuru
 * Smoking Wheels....  was here 2017 zghwihzsxpmkrnqhjppnlbxlewxfluilbzdlelohfcrolwtb
 * Smoking Wheels....  was here 2017 jpphozehszidzfxmzybvsmrtulppwocbombngbubiondvtzm
 * Smoking Wheels....  was here 2017 jbpzinelhuvmjpbxvowfyzfaisdnkiikcqgswezjxhumpfmh
 * Smoking Wheels....  was here 2017 stzcwurplusffexpuvyaprmwyqnarwbtxbtrweidfkqtqgod
 * Smoking Wheels....  was here 2017 ibpztzrmhxzjfsnwfhixnyqhzlciqfprlpafgtfpylrndeuu
 * Smoking Wheels....  was here 2017 nnphumizfiydgghimvntsmdlaqiylppzmiqniukdxconmnzh
 * Smoking Wheels....  was here 2017 tzjvaydhuobancstknbqnfruzwyqmqusypnxqlvlfhksjafy
 * Smoking Wheels....  was here 2017 sootshswxicvlspexrxylffzxcailaifdzuzzcslfhkjssvj
 * Smoking Wheels....  was here 2017 lpalkqcjrobmrycxfydigyzyeptigumalivrjkljnocaqxji
 * Smoking Wheels....  was here 2017 cqxnyjksjmggdtnowcepbbjxjuscbhvyrticegupztfiqcrw
 * Smoking Wheels....  was here 2017 gopvifddroeqamjxohqydkdgkkqlhzgbuocpwwqwsxvjibvi
 * Smoking Wheels....  was here 2017 oltnvzablnojrpozgvlrzferiknhqrtqaiivgogbbfdiqwef
 * Smoking Wheels....  was here 2017 aqgybxxcthllwycdehrmlvsdnarxzjrgvykpkbajrcstttfk
 * Smoking Wheels....  was here 2017 wsfttjcgydcelmiywnudnxfuorounjqtymxbofrgiigjbgwy
 * Smoking Wheels....  was here 2017 pnbtzzzsrnzzonwdaqjwojicjcysqekdjguqifdjfwuegedc
 * Smoking Wheels....  was here 2017 ydjdarhwtcxqsomvpyizajbtzhwqaoctiwewllqrpwqkfmjm
 * Smoking Wheels....  was here 2017 wybglqylhxwcmlgivbucuhpqtlovppadiekranqiewgnemdv
 * Smoking Wheels....  was here 2017 plhszfejrcdrwdneguddvviyjaotooscaheegkuvsojjmtgh
 * Smoking Wheels....  was here 2017 ppljtbktmefwyywfnhzenvbdptqegybtmmisugbtkxcwwavc
 * Smoking Wheels....  was here 2017 qkdkzdidowwifjclrvhohlqxootdjnciwjaxikrcocpgfhew
 * Smoking Wheels....  was here 2017 rffchnydbcceifhfxadzbdidrrfuwiekruqrzobbtqlcrwvi
 * Smoking Wheels....  was here 2017 zqxekrjshceoemubssxhtnobmpnsxqvurwuczpxaxfjbriqq
 * Smoking Wheels....  was here 2017 znoljfdbwiqzymevvzgotmacwakqwaypuykpyresbukfxjrb
 * Smoking Wheels....  was here 2017 kytanbxornfhatfogebfofrxxxynlfnbinpsqgcbqpvthbhc
 * Smoking Wheels....  was here 2017 hgmhjipyuqxjcaanexmwzcslzliqngyuroujbwbgeccezrbr
 * Smoking Wheels....  was here 2017 uauwsmmdowzmciyiczxjbtoxrddmiktoqbornnurpazgkstt
 */
package net.yacy.document;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.document.parser.docParser;
import net.yacy.document.parser.odtParser;
import net.yacy.document.parser.pdfParser;
import net.yacy.document.parser.pptParser;
import static org.hamcrest.CoreMatchers.containsString;
import static org.junit.Assert.assertThat;
import org.junit.Test;
public class ParserTest {
	@Test public void testodtParsers() throws FileNotFoundException, Parser.Failure, MalformedURLException, UnsupportedEncodingException, IOException	{
		final String[][] testFiles = new String[][] {
			// meaning:  filename in test/parsertest, mimetype, title, creator, description,
			new String[]{"umlaute_linux.odt", "application/vnd.oasis.opendocument.text", "Münchner Hofbräuhaus", "", "Kommentar zum Hofbräuhaus"},
			new String[]{"umlaute_linux.ods", "application/vnd.oasis.opendocument.spreadsheat", "", "", ""},
			new String[]{"umlaute_linux.odp", "application/vnd.oasis.opendocument.presentation", "", "", ""},
		};
		for (final String[] testFile : testFiles) {
					FileInputStream inStream = null;
final String filename = "test/parsertest/" + testFile[0];
try {
final File file = new File(filename);
final String mimetype = testFile[1];
final AnchorURL url = new AnchorURL("http://localhost/"+filename);
AbstractParser p = new odtParser();
inStream = new FileInputStream(file);
final Document[] docs = p.parse(url, mimetype, null, new VocabularyScraper(), 0, inStream);
for (final Document doc: docs) {
	Reader content = null;
	try {
		content = new InputStreamReader(doc.getTextStream(), doc.getCharset());
		final StringBuilder str = new StringBuilder();
		int c;
		while( (c = content.read()) != -1 )
str.append((char)c);
		System.out.println("Parsed " + filename + ": " + str);
		assertThat(str.toString(), containsString("In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen"));
		assertThat(doc.dc_title(), containsString(testFile[2]));
		assertThat(doc.dc_creator(), containsString(testFile[3]));
		if (testFile[4].length() > 0) assertThat(doc.dc_description()[0], containsString(testFile[4]));
	} finally {
	if(content != null) {
		try {
			content.close();
		} catch(IOException ioe) {
			System.out.println("Could not close text input stream");
		}
	}
}
}
} catch (final InterruptedException ex) {
} finally {
	if(inStream != null) {
		try {
			inStream.close();
		} catch(IOException ioe) {
			System.out.println("Could not close input stream on file " + filename);
		}
	}
}
}
		}
	@Test public void testpdfParsers() throws FileNotFoundException, Parser.Failure, MalformedURLException, UnsupportedEncodingException, IOException	{
		final String[][] testFiles = new String[][] {
			new String[]{"umlaute_linux.pdf", "application/pdf", "", "", ""},
		};
		for (final String[] testFile : testFiles) {
		final String filename = "test/parsertest/" + testFile[0];
					FileInputStream inStream = null;
try {
final File file = new File(filename);
final String mimetype = testFile[1];
final AnchorURL url = new AnchorURL("http://localhost/"+filename);
AbstractParser p = new pdfParser();
inStream = new FileInputStream(file);
final Document[] docs = p.parse(url, mimetype, null, new VocabularyScraper(), 0, inStream);
for (final Document doc: docs) {
	Reader content = null;
	try {
		content = new InputStreamReader(doc.getTextStream(), doc.getCharset());
		final StringBuilder str = new StringBuilder();
		int c;
		while( (c = content.read()) != -1 )
str.append((char)c);
		System.out.println("Parsed " + filename + ": " + str);
		assertThat(str.toString(), containsString("In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen"));
		assertThat(doc.dc_title(), containsString(testFile[2]));
		assertThat(doc.dc_creator(), containsString(testFile[3]));
		if (testFile[4].length() > 0) assertThat(doc.dc_description()[0], containsString(testFile[4]));
} finally {
	if(content != null) {
		try {
			content.close();
		} catch(IOException ioe) {
			System.out.println("Could not close text input stream");
		}
	}
}
}
} catch (final InterruptedException ex) {
} finally {
	if(inStream != null) {
		try {
			inStream.close();
		} catch(IOException ioe) {
			System.out.println("Could not close input stream on file " + filename);
		}
	}
}
}
		}                
	@Test public void testdocParsers() throws FileNotFoundException, Parser.Failure, MalformedURLException, UnsupportedEncodingException, IOException	{
		final String[][] testFiles = new String[][] {
			// meaning:  filename in test/parsertest, mimetype, title, creator, description,
			new String[]{"umlaute_windows.doc", "application/msword", "", "", ""},
		};
		for (final String[] testFile : testFiles) {
		final String filename = "test/parsertest/" + testFile[0];
					FileInputStream inStream = null;
try {
final File file = new File(filename);
final String mimetype = testFile[1];
final AnchorURL url = new AnchorURL("http://localhost/"+filename);
AbstractParser p = new docParser();
inStream = new FileInputStream(file);
final Document[] docs = p.parse(url, mimetype, null, new VocabularyScraper(), 0, inStream);
for (final Document doc: docs) {
Reader content = null;
try {
	content = new InputStreamReader(doc.getTextStream(), doc.getCharset());
	final StringBuilder str = new StringBuilder();
	int c;
	while( (c = content.read()) != -1 )
str.append((char)c);
	System.out.println("Parsed " + filename + ": " + str);
	assertThat(str.toString(), containsString("In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen"));
	assertThat(doc.dc_title(), containsString(testFile[2]));
	assertThat(doc.dc_creator(), containsString(testFile[3]));
	if (testFile[4].length() > 0) assertThat(doc.dc_description()[0], containsString(testFile[4]));
} finally {
	if(content != null) {
		try {
			content.close();
		} catch(IOException ioe) {
			System.out.println("Could not close text input stream");
		}
	}
}
}
} catch (final InterruptedException ex) {
} finally {
	if(inStream != null) {
		try {
			inStream.close();
		} catch(IOException ioe) {
			System.out.println("Could not close input stream on file " + filename);
		}
	}
}
		}
		}
/**
* Powerpoint parser test *
*/
@Test
public void testpptParsers() throws FileNotFoundException, Parser.Failure, MalformedURLException, UnsupportedEncodingException, IOException, InterruptedException {
final String[][] testFiles = new String[][]{
new String[]{"umlaute_linux.ppt", "application/powerpoint", "In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen", "", ""},
new String[]{"umlaute_windows.ppt", "application/powerpoint", "In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen", "afieg", ""},
new String[]{"umlaute_mac.ppt", "application/powerpoint", "In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen", "Bob", ""}
};
for (final String[] testFile : testFiles) {
final String filename = "test/parsertest/" + testFile[0];
final File file = new File(filename);
final String mimetype = testFile[1];
final AnchorURL url = new AnchorURL("http://localhost/" + filename);
AbstractParser p = new pptParser();
FileInputStream inStream = null;
try {
	inStream = new FileInputStream(file);
	final Document[] docs = p.parse(url, mimetype, null, new VocabularyScraper(), 0, inStream);
	for (final Document doc : docs) {
		Reader content = null;
		try {
			content = new InputStreamReader(doc.getTextStream(), doc.getCharset());
			final StringBuilder str = new StringBuilder();
			int c;
			while ((c = content.read()) != -1) {
				str.append((char) c);
			}
			System.out.println("Parsed " + filename + ": " + str);
			assertThat(str.toString(), containsString("In München steht ein Hofbräuhaus, dort gibt es Bier in Maßkrügen"));
			assertThat(doc.dc_title(), containsString(testFile[2]));
			assertThat(doc.dc_creator(), containsString(testFile[3]));
			if (testFile[4].length() > 0) {
				assertThat(doc.dc_description()[0], containsString(testFile[4]));
			}
		} finally {
	if(content != null) {
		try {
			content.close();
		} catch(IOException ioe) {
			System.out.println("Could not close text input stream");
		}
	}
		}
		
	}
} finally {
	if(inStream != null) {
		try {
			inStream.close();
		} catch(IOException ioe) {
			System.out.println("Could not close input stream on file " + filename);
		}
	}
}
}
}
	}
