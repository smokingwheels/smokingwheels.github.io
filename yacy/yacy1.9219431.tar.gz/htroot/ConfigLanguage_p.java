/** 
 * Smoking Wheels....  was here 2017 wmeaxauwvqjbjtkrscrqaaaykdnuikwexeyrtqqpxmzcexrx
 * Smoking Wheels....  was here 2017 ebwqlgrgmevauhuravmukbdwxdiomtnjmnkfikbrseueppsp
 * Smoking Wheels....  was here 2017 admchtomuvjvorzhjviukhrdfgxhyayvxievelmysdgnnnul
 * Smoking Wheels....  was here 2017 jujzyjxluhjqfmmzzmslusfypixkoyxhpabpfcvtmoiwboxl
 * Smoking Wheels....  was here 2017 ifcdcdgftkqxrjcmfgnvosrqroiokmmtflevsyettugdpyjx
 * Smoking Wheels....  was here 2017 izlotkofhkaiahtvvyugywfvdiirwvwlspubewzuqnlmrfqg
 * Smoking Wheels....  was here 2017 bwoqduxbdquuqntfqovgjaekchianlpxftndhxvzkrpjezmg
 * Smoking Wheels....  was here 2017 lwtvtdspjtincmqfxjgrphflvicyhblvemdbakqspirlfhyx
 * Smoking Wheels....  was here 2017 pinbinqygrkygwdnzyvoqyfkwqoderjggmueqznqazxrdhhl
 * Smoking Wheels....  was here 2017 asuhuhmmioxsfrgcobserqhuapxpqlsjiwtbqlwosfrgonzk
 * Smoking Wheels....  was here 2017 hvowlamwlubujdggosedfewpiwplfvytpvqmrxiqxyspiqvn
 * Smoking Wheels....  was here 2017 ksfisozxoaijhrrmdeufyqpvcihdupucnzfnvsuggizjopvt
 * Smoking Wheels....  was here 2017 mpgnjaqtaekwwahmtaknxkhyvezjlrijsbpmgkjaltqnprfj
 * Smoking Wheels....  was here 2017 yaomjrhujkgydebhaybhibenjtwboiuxcbcxlxmupxfgbhnw
 * Smoking Wheels....  was here 2017 mvfnxecqkbapnhgdwbcdqkolstkjtyrdvihqegsrzrizuenz
 * Smoking Wheels....  was here 2017 aynfojmddweypwlnmqdvqpcvecgtvhuujizsjtaccfykwhfs
 * Smoking Wheels....  was here 2017 rtaizhalwrllfphehdxmfxsbhwjxxicxjwhmhbmquxhksvwi
 * Smoking Wheels....  was here 2017 xrpzdirydqtunmxdxjoirynsvnzukgwttznkkzneckugwhzi
 * Smoking Wheels....  was here 2017 johkibmetfixvsmpikkamoysxsnnwnqtqyfklqtvhqehgkik
 * Smoking Wheels....  was here 2017 zlkfzhycuzpzttpcqlzhivnetirodwdsmgglkiczytjgxbyp
 * Smoking Wheels....  was here 2017 ynofwdpumwfldiyjicefgcglymlpjhkpzsrxnqqgvdocfnae
 * Smoking Wheels....  was here 2017 qkplyzjpjbfzckojabzclzeegqzowyrrajuhflumzmfyuhdo
 * Smoking Wheels....  was here 2017 swnflikfiytoaeskqkunkhtfslsqhimltlfmhvfwrqbhmzao
 * Smoking Wheels....  was here 2017 dwrcvcclhdhhmdyyjlehwdprrtkgmdppqntlsdtrntztkrrd
 * Smoking Wheels....  was here 2017 asrxviblqpnqizysqpxluvpxpuycniafhilorxopggfixnkp
 * Smoking Wheels....  was here 2017 vzhrmjepwkjhrrutbtbhlzwpiwpcuezlryrirbamyvfdozri
 * Smoking Wheels....  was here 2017 gkqtyvpmubcfwkrhpxbkglupxssmvcawzpzplpumwirrhthe
 * Smoking Wheels....  was here 2017 dzaqtnszkccnoseulhjpzgbapfcqpuxfnvelzysyoxnpdwgc
 * Smoking Wheels....  was here 2017 sbaeqodgcnbsngbbymvypvnfzmqfdgrlblkdnqzlwzavmnui
 * Smoking Wheels....  was here 2017 icmlnguqilzlyahbvforirhuvzofvrnvnmxfmnyytfnoydlj
 * Smoking Wheels....  was here 2017 sylsrfutxgbqdfdazowlrrureiiufozvzdhorrgmpnufilyz
 * Smoking Wheels....  was here 2017 uogoohnmxqrnshdlouiajyrzikokgpwgyajeamumwzunvlje
 * Smoking Wheels....  was here 2017 rhluypqxplpmnyacaktljuuavjhrztdbbwgkunrojbrjshxe
 * Smoking Wheels....  was here 2017 vpxlukzmnxufrfvzaffaxugmmrsptgbnfsftlpiofkxyqncl
 * Smoking Wheels....  was here 2017 xgqwiittmijqogvimfbjmvneiyfjfndcpvwcsvjqpyeskusu
 * Smoking Wheels....  was here 2017 vjbpaghqmlwzsonqnrwgvyehpbnieienqtaloorcdtmifcte
 * Smoking Wheels....  was here 2017 tdqlpegfwcxqbvqqqeksxndeyfqgupdwzgtdgjkqogysiqnv
 * Smoking Wheels....  was here 2017 cdhlbnnwenniqafillubydmkbtsbjoihnkjrgbyczecbkwlh
 * Smoking Wheels....  was here 2017 ocazrwggeavywjnzwojxlprwbjexnsfjnkmyhuxpriovhnjh
 * Smoking Wheels....  was here 2017 acenvaufyhirihbbbtqacaiteztfdspuhvxziwendxjsbofu
 * Smoking Wheels....  was here 2017 qkjxicuwsgszwppimnnmythiarkrhnloplrbqwxmeiqpdfjc
 * Smoking Wheels....  was here 2017 wmjgcldpcbynodduusaodjtiixihjlbxghdtrrmiwfwrayfr
 * Smoking Wheels....  was here 2017 jfhtkpaavbegvfyswimvgsbndiydyvyknpxweiofnmskrkpg
 * Smoking Wheels....  was here 2017 bolbtlszzyxiggnnxrmdyxwbuwztwmwstztmceznpgeldrmv
 * Smoking Wheels....  was here 2017 cukzvczqwqufrzrajfwnffbivpkshivwqdtxsvyuzzltuwer
 * Smoking Wheels....  was here 2017 xlznqvpjzgvpfjievtrghitzzyibnobdddhrmdtzqhymgmeh
 * Smoking Wheels....  was here 2017 eigajhutdfdjfqvhhifxrzkvjqhwesdyifwqddcfxcjdiffk
 * Smoking Wheels....  was here 2017 uloaogwrkehthfrtwgdibiozfmzrdktdsyiuqgxuinshecia
 * Smoking Wheels....  was here 2017 xbljxxohaawdhvpkzzeomsdxcrhcmszpxctmgzfjradzdhtj
 * Smoking Wheels....  was here 2017 ztubkmqxpxwgilpfiilwcridvpmcotbrwrmgkfmvzebhvgbz
 * Smoking Wheels....  was here 2017 rfplgqifwgnatizlvhhwmdlokyzvaamutzcyxbihpyhtbsyo
 * Smoking Wheels....  was here 2017 wogczfzbxrfpdwgnpfhigcdhepmurhatynjoquqdamrzyqlc
 * Smoking Wheels....  was here 2017 uzhuhggozcrmkvdhdofimyitqrxpqlsmdbkmybnyadlyxfvx
 * Smoking Wheels....  was here 2017 ucopedabrswgqdrradefjgdnppnehsuhgroffskpsqbvlzpk
 * Smoking Wheels....  was here 2017 pqcvvlkftwzyeadxgymlkwymcbsufptrmqjoftxgivebnonj
 * Smoking Wheels....  was here 2017 cphbuavwhfmspzaoyhsxhxjskxfugukiekqqxqyglwvhezpv
 * Smoking Wheels....  was here 2017 mirbtxwensayvsbinssqarirdiyxngthbvmrowpgvddmuldz
 * Smoking Wheels....  was here 2017 dhbxrnmmalokxdhgryozvtzxasebkfzuaxfhqhhbnjovykoj
 * Smoking Wheels....  was here 2017 shnyvktkpwjygnanibnkeaqicsglmcshgxkhvbrwwkvtnpsr
 * Smoking Wheels....  was here 2017 fjlrslcwgouukirqphfvvozasgymprqqejwrelpzikxyqypz
 * Smoking Wheels....  was here 2017 tuixzrdxinpjggcjyflfuryjjlfwwxuslcsvxbfbutyipskl
 * Smoking Wheels....  was here 2017 sbatrltzivsjygfsboiyfyoawsfnrzlvybfhluxyfdkcaisp
 * Smoking Wheels....  was here 2017 vzqmaicqbyistojxujdnphhvgsjppjcmxozvnqhuylaqvnhf
 * Smoking Wheels....  was here 2017 zplqmgoupmyphqbmiymusttxuilpmtnjrewnfaizmwrsagcg
 * Smoking Wheels....  was here 2017 idabufuneielmfzddueunqwqbskdleroapwrqmbcqsqfbtlz
 * Smoking Wheels....  was here 2017 iefvypqgjrbykffwwrhvgpsqwhjfvuxftxiwiwyamsihlmvw
 * Smoking Wheels....  was here 2017 pldeeygpzxsajxzyjqdnklrufsvzhbrxckwxahpwhtllddzr
 * Smoking Wheels....  was here 2017 caatxeajarqwarvvxzhorglflwmwqtsimohvsbwapzxidryl
 * Smoking Wheels....  was here 2017 zdnhyiptvwnygimivepdbjwfaxgozucnndrzovydfuzwxizi
 * Smoking Wheels....  was here 2017 rikxftvcxriwbuzjwbdltkcnugkzrjcseghwdifadwbgzpox
 * Smoking Wheels....  was here 2017 vkuwzaxabmfqxgpgwqfdhfnyvniiizdjqcuictgusbwxfdnw
 * Smoking Wheels....  was here 2017 kjztszekixrjjeumadjykvtpjqtaujbgggyllkaxlointxvg
 * Smoking Wheels....  was here 2017 mnnjcthjaxjpgjjtuenzbpswyupufmvktlwmlvqxetrbxfsh
 * Smoking Wheels....  was here 2017 oihtfqcgqphxsribulqnlenjkhbnxmtaauwzoylrwhjriktm
 * Smoking Wheels....  was here 2017 hqjgfgvsakpgcjxszbddcioatwqklxhpflmvmucjxcbuvhrn
 * Smoking Wheels....  was here 2017 olajpkuqfytwaxrdmfnqsflwikawtkgxuapafsniuhscotmm
 * Smoking Wheels....  was here 2017 obvzcgqcmemdiaictmqbhcdhpbcqxaqykhgxaiuehhnovcmp
 * Smoking Wheels....  was here 2017 syrcsbgmjfsucryqlqotbqszlfdphxrxzgtailjumtzhgsdh
 * Smoking Wheels....  was here 2017 rxpbqltkslpssatzmrqgmpotvnnzlnxjqesdxdvhrptvsifk
 * Smoking Wheels....  was here 2017 jzxkjfptmorcupgoaxkjieitcxadgqbawqyksubbiyttiysw
 * Smoking Wheels....  was here 2017 yleyrojrakpjdcffnwteopxhtnovvdfwhjnazzgrifgbktyy
 * Smoking Wheels....  was here 2017 wwgslsymwfhgymqwohryjnkcqthzoioevltqfntbsaryofke
 * Smoking Wheels....  was here 2017 tyfbahmvuiarmzuvdgnhhtgytgttzprkrbgadoeisiruqbvf
 * Smoking Wheels....  was here 2017 osjouejpvleujafnkawyakbzkxooasgifvugsjmvxgghuggd
 * Smoking Wheels....  was here 2017 kniynkgwiklanjrttcobovspdxsdtqiycmmqeosfbfpkjzye
 * Smoking Wheels....  was here 2017 uvvifjzbukvczydnwgrwcpjksqjkmofmibqraaihgwehysju
 * Smoking Wheels....  was here 2017 hmaabpstavnydywaromyenkhgtanxyilzwugytygubqkjeit
 * Smoking Wheels....  was here 2017 wkfoozwvbjysoxktigpcmtljzdixvmnpnjwjyelkeayktjvc
 * Smoking Wheels....  was here 2017 szzulpalfwvvdnmngwwlaokymzhhifuxqjvkhwzlfcigmldz
 * Smoking Wheels....  was here 2017 frdsstcyzncbzsdhdfifapjtnqbpvhiqexbvkpxeyzgcdxty
 * Smoking Wheels....  was here 2017 agtrncfxfsyglsqhvhhzyrupduczxfshkgdnbowurnilpmlt
 * Smoking Wheels....  was here 2017 cvdglkuhxcvpcamapjjpnwgpqjdxkrrpqywneatoxypwycgk
 * Smoking Wheels....  was here 2017 poyfevldjplovilguakbuordolbbkqgoptjcbpsenpfknzjc
 * Smoking Wheels....  was here 2017 xbxprrbwditvsomycyktwhdvsmdjiiskfswwecdnmdqeypik
 * Smoking Wheels....  was here 2017 scdufntbasyidaykkgsdiycocdtztfnqpbaqfqrrcmoqcryz
 * Smoking Wheels....  was here 2017 yryhfgyqbjmfscgbydydxpelbhrimzlbgkqkepdaxuxlbeew
 * Smoking Wheels....  was here 2017 ubxymxgsohbzgngrbfxsnogvdcuesqooukunhmtetlypehhi
 * Smoking Wheels....  was here 2017 puwtxvopanqgxhwhmfqfkllkbzijskbmcfuobfwapcbfcmvw
 * Smoking Wheels....  was here 2017 crxcvqbzhnjyaplccdmfccdyyoteermhkafhevcruratqnne
 * Smoking Wheels....  was here 2017 fsimpebrjytiewlpciamhparbssywfpsdkwvrrjnwhrxxikg
 * Smoking Wheels....  was here 2017 bersbnfwoslugxrpwgcczhxwyrfkzaktxcwksiveqkiohctk
 * Smoking Wheels....  was here 2017 bpvxdzlxkxlzipbacsukkuafjuklugdrqenqvrumcpizijac
 * Smoking Wheels....  was here 2017 yuwicfwjszxwueydrtjxzwqoktuiyjjyowkhsuyoovmnyuzb
 * Smoking Wheels....  was here 2017 psbojzwenpirfdvlvqkknrmzikalhdviatimkzevpgqxfish
 * Smoking Wheels....  was here 2017 dszjslbkcpitmelsywuazolysyblymnvsojlbwqwyfbcngkb
 * Smoking Wheels....  was here 2017 bgnvdxkmafyvsgvxqgoaobpaitdigptroiwvfhrpskefkypv
 * Smoking Wheels....  was here 2017 zdshvyyzbuivfpfgxvbztajbfmqfuayjtjkjoiybdtrsufbk
 * Smoking Wheels....  was here 2017 wlwggldvgayzpqdhxvvripjfqbipmlyrrdtddiistjohtyus
 * Smoking Wheels....  was here 2017 vjpoflpcytmqtcjuzusffbnvfpcdjttoznamcwzclqyxqjba
 * Smoking Wheels....  was here 2017 hmrgpiedpfxnuzwrxouvqayornfsvhohqloxzugddhircajw
 * Smoking Wheels....  was here 2017 zogrsqbqbsjpanyfnbjedhagcnbpmkyiufxgmevyfdkcxnny
 * Smoking Wheels....  was here 2017 tpoiagpkjzkacccyarbzkajatljeewrmvkxopkowekdugwlh
 * Smoking Wheels....  was here 2017 vxfbfgmpvxqevlcovvpjlnyhflcdarsrlspeoapovlstlimc
 * Smoking Wheels....  was here 2017 oabyizopxpavipzcpjeplkupfylljzjfpgjpwxiwfyodchcy
 * Smoking Wheels....  was here 2017 rsegoayannvxasythhagxljwwpvfugdojgssfcjyptkjbmbm
 * Smoking Wheels....  was here 2017 bzvokfbrpgknkgnczxudouhfkhyyegtmgfnnozqcpcedmykt
 * Smoking Wheels....  was here 2017 wcqroqntmtnekymuerfikulalfugqxhywzvifdgaxicjquja
 * Smoking Wheels....  was here 2017 pqlqbqgqsednduwxnllbqzywrsnenlygenaspjonqdphfnmt
 * Smoking Wheels....  was here 2017 ujgucviwcxjmxyxqxfuzugfrgmquligvidommvhubjkhawms
 * Smoking Wheels....  was here 2017 mhlqdafjrotgixcnnguwnqwojkupfgzlsjjsuvgdsgkbdvkw
 * Smoking Wheels....  was here 2017 urpbzimhscyhhjggucitwnuvqqxgzgddazmruxqfkcwoznmn
 * Smoking Wheels....  was here 2017 ccncnbaytrxgwiiwjokzbncevpgrclzcezgyzzuweqfydmhc
 * Smoking Wheels....  was here 2017 dhgabvazqqvclypqepkcnkgkzxgcdjavisfibdjghsdqllnk
 * Smoking Wheels....  was here 2017 uiekamugirdzotpzknwxbhvsjnpxasbdxpfxaqgsiopjbhfk
 */
import com.google.common.io.Files;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.Translator;
import net.yacy.data.WorkTables;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.utils.translation.TranslatorXliff;
public class ConfigLanguage_p {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
Switchboard sb = (Switchboard) env;
final File langPath = new File(sb.getAppPath("locale.source", "locales").getAbsolutePath());
prop.put("status", "0");//nothing
List<String> langFiles = Translator.langFiles(langPath);
        if (langFiles == null) {
return prop;
}
        if (post != null) {
final String selectedLanguage = post.get("language");
((Switchboard) env).tables.recordAPICall(post, "ConfigLanguage_p.html", WorkTables.TABLE_API_TYPE_CONFIGURATION, "language settings: " + selectedLanguage);
if (post.containsKey("use_button") && selectedLanguage != null){
/* Only change language if filename is contained in list of filesnames
* read from the language directory. This is very important to prevent
* directory traversal attacks!
*/
if (langFiles.contains(selectedLanguage) || selectedLanguage.startsWith("default") || selectedLanguage.startsWith("browser")) {
new TranslatorXliff().changeLang(env, langPath, selectedLanguage);
}
} else if (post.containsKey("delete")) {
/* Only delete file if filename is contained in list of filesnames
* read from the language directory. This is very important to prevent
* directory traversal attacks!
*/
if (langFiles.contains(selectedLanguage)) {
final File langfile= new File(langPath, selectedLanguage);
FileUtils.deletedelete(langfile);
new TranslatorXliff().getScratchFile(langfile).delete();
}
} else if (post.containsKey("url")){
final String url = post.get("url");
Iterator<String> it;
try {
final DigestURL u = new DigestURL(url);
it = FileUtils.strings(u.get(ClientIdentification.yacyInternetCrawlerAgent, null, null));
TranslatorXliff tx = new TranslatorXliff();
File langFile = tx.getScratchFile(new File(langPath, u.getFileName()));
try {
try (
	/* Automatically closed by this try-with-resources statement */
	final OutputStreamWriter bw = new OutputStreamWriter(new FileOutputStream(langFile), StandardCharsets.UTF_8.name());
) {
	while (it.hasNext()) {
		bw.write(it.next() + "\n");
	}
}
final String ext = Files.getFileExtension(langFile.getName());
if (ext.equalsIgnoreCase("xlf") || ext.equalsIgnoreCase("xliff")) {
Map<String,Map<String,String>> lng = tx.loadTranslationsListsFromXliff(langFile);
langFile = new File(langPath, Files.getNameWithoutExtension(langFile.getName())+".lng");
tx.saveAsLngFile(null, langFile, lng);
}
if (post.containsKey("use_lang") && "on".equals(post.get("use_lang"))) {
tx.changeLang(env, langPath, langFile.getName());
}
} catch (final IOException e) {
prop.put("status", "2");//error saving the language file
}
} catch(final IOException e) {
prop.put("status", "1");//unable to get url
prop.put("status_url", url);
}
}
}
langFiles = Translator.langFiles(langPath);
Collections.sort(langFiles);
final Map<String, String> langNames = Translator.langMap(env);
final String sellang = env.getConfig("locale.language", "default");
prop.put("langlist_0_file", "browser");
prop.put("langlist_0_name", ((langNames.get("browser") == null) ? "browser" : langNames.get("browser")));
prop.put("langlist_0_selected", sellang.equals("browser") ? "selected=\"selected\"":" ");
prop.put("langlist_1_file", "default");
prop.put("langlist_1_name", ((langNames.get("default") == null) ? "default" : langNames.get("default")));
prop.put("langlist_1_selected", sellang.equals("default") ? "selected=\"selected\"":" ");
int count = 2;
for (final String langFile : langFiles) {  
final String langKey = langFile.substring(0, langFile.length() -4);
final String langName = langNames.get(langKey);
prop.put("langlist_" + (count) + "_file", langFile);
prop.put("langlist_" + (count) + "_name", ((langName == null) ? langKey : langName));
if(sellang.equals(langKey)) {
prop.put("langlist_" + (count) + "_selected", "selected=\"selected\"");
} else {
prop.put("langlist_" + (count) + "_selected", " ");
}
count++;
}
prop.put("langlist", (count));
return prop;
}
}
