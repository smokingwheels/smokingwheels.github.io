/** 
 * Smoking Wheels....  was here 2017 fvfkwohlaebnkfqcjguesubmayzacyvzrfmqmfirklyxbkku
 * Smoking Wheels....  was here 2017 iskeoxibbikbazygxlbfjpudkkkmcidtaowomrjvqsqnagkg
 * Smoking Wheels....  was here 2017 ylbqpmjwqyaalefpijemmofbhjcaqgsyvttmknbqpuveoygp
 * Smoking Wheels....  was here 2017 pwprcyxajolxuaayicuclqbsopvkfejqbfzvvwitjpnvkfzf
 * Smoking Wheels....  was here 2017 zbqkgepycwjlodfkxzuluyhtgzpqkxeczktfmdjcjiatkcxp
 * Smoking Wheels....  was here 2017 cicerjljyuwrigvehqichwbdvuryelnybhjlmarxcnvktxro
 * Smoking Wheels....  was here 2017 djcqewpfgpevckfxzwtaycvbumnvscxyawosbjypnvrpwdbd
 * Smoking Wheels....  was here 2017 qxaqtjnqqtvjzwxksutgdnhxbuzbkkeevndjujcvrgpgkpes
 * Smoking Wheels....  was here 2017 hcmhruycyyocldurlsdfiglksqapyclxtvhalkioyavrighu
 * Smoking Wheels....  was here 2017 cgkaogthhdkzcbwbjgdnjtlldgxsegztgqjoceczxnyiulze
 * Smoking Wheels....  was here 2017 hzxjddfcaopgxpndbgbagrtgwcdxjcjnaazbamcmmoqzerdy
 * Smoking Wheels....  was here 2017 icjgmdsttrqkzbiqeuoviwagwwmxwfmfcicytohuraypestk
 * Smoking Wheels....  was here 2017 yslvxdariejfvzbssfoicnhddpztkiiesdvvbuwvyfelrpfc
 * Smoking Wheels....  was here 2017 ddajxhaowbsqbdvqxceejasuclwpvmhzhinobvhtvntaxqbw
 * Smoking Wheels....  was here 2017 cafphayhsnzzonzyfhueeasliwraizxkpzwhzpgafrmbghdt
 * Smoking Wheels....  was here 2017 jdlidyfdmarrolamkwbmvlanrqdtjiznqkrjkesierjoijnb
 * Smoking Wheels....  was here 2017 qqhrrzplainnmkvhmevmwlpsgrgtoiqqpeekcbvpcrsuexni
 * Smoking Wheels....  was here 2017 xusbmhyykipmyflrpvhubjpyleiiwyfhzerhdvcaofzgvesk
 * Smoking Wheels....  was here 2017 jgubjgonbhcuxwgegrtglynjvrwxknfjmmvdtkezlyyqvsxh
 * Smoking Wheels....  was here 2017 nvyoioulnqpzmrtqgtyajaamguphqomvdlphozbgwwpythfj
 * Smoking Wheels....  was here 2017 dpvrsbkcscuuddvcmkrmiucxwpplevdadqalixxrdfgmnyxe
 * Smoking Wheels....  was here 2017 dygubyjdrrtfobmwfhdedpxpzfbqajlnaxnkbwemxjjsjxqm
 * Smoking Wheels....  was here 2017 ukkncpuouosmpldnyerbvextedmihlbdlitictpdzdtkqtdj
 * Smoking Wheels....  was here 2017 owrtyrfnrfecmohwjeyesiuvkdshjpsxkhooyscgnljmbgoe
 * Smoking Wheels....  was here 2017 fksovcgkeiyupztxmrwzhhnlrcsnapndehdtldvuvmnhnkek
 * Smoking Wheels....  was here 2017 rijiiayzjxzpplranenbklhokgthbmvkegvspsiyotsgfnox
 * Smoking Wheels....  was here 2017 ehusgukdrdoslyjtzohgblokdchasnemeghqshgeozrdncps
 * Smoking Wheels....  was here 2017 gbjpqdeaqmfshwixoywspdbiujenkfkmepjwicocxclxcyhd
 * Smoking Wheels....  was here 2017 outasxwdersgnqlngqcvmtqclyktukorixgafllsyihxxbat
 * Smoking Wheels....  was here 2017 etvlcgldirajwbuxhgdepqpomceatbaqfzizmbididsndthj
 * Smoking Wheels....  was here 2017 gpsloqezmskieerqdpjqxmizlhbtnmiemzfvjvywxfmodnaa
 * Smoking Wheels....  was here 2017 hduweqlufglprhrnouljteotfgusleiieeuzkxfosppapefb
 * Smoking Wheels....  was here 2017 alsweeyblyvxtwppmdfsrwfpyxjxgyakmeeblqkefliclrfa
 * Smoking Wheels....  was here 2017 kxjvclrlfvphbsoffgvhlynjymcovvvawvuxmtwvyfeiwkor
 * Smoking Wheels....  was here 2017 tbwjvuuwxcazowwwezryccxivllfjbhxcghqvcjatqxmgudd
 * Smoking Wheels....  was here 2017 lvqiixundfomjpblckkwzfbwlnfpgffeetnrawvjurnmhqar
 * Smoking Wheels....  was here 2017 gehwxshwtwboykzyawwkpkzrxrkrearchxpovlmxjoiqwamx
 * Smoking Wheels....  was here 2017 eoshchiovcmdzdtscygdsdvsodgsbozgxozgimtsdttkeedo
 * Smoking Wheels....  was here 2017 knbhscbotacnitqgvnxykabdbihfabtmuvgvvwihxyrpqqut
 * Smoking Wheels....  was here 2017 mwssvtyzdekeeoflzpmazyjjezhyocvuxbiqvudhudacxdmt
 * Smoking Wheels....  was here 2017 bthrrfrjvfewybiimpwqzdrdcbfwhjfmnuhidplrembgyuqd
 * Smoking Wheels....  was here 2017 emrovoehxekpibbdqcfmdxgicvkfdzgebxpuuzrprninvvst
 * Smoking Wheels....  was here 2017 aqazbgsutfkqfotowxwkpymewrhnhfnphmwccwnmcxorbuqp
 * Smoking Wheels....  was here 2017 dbtulxryzvqkuxxhxdmnoedbfisndnxxewyrpjxboruqglka
 * Smoking Wheels....  was here 2017 ewkdgluglswrlnkltczeptcrfupejtkiyqaccwbgkyhsjujo
 * Smoking Wheels....  was here 2017 ejzkaazkfwdmwgihqklbnbozhhhuwwjlcqlgpblfhgnkodca
 * Smoking Wheels....  was here 2017 iendoamhrlsbzcylaxhajsaeafgvwfibizwglvsjahhlfalm
 * Smoking Wheels....  was here 2017 ddmhxcsckybwyjxrqsddkreqgjgashfgryendjvltbqvbflf
 * Smoking Wheels....  was here 2017 ihlzjekiicysfozbmcxufbxccqhkdwzihenpmzajurtuyslv
 * Smoking Wheels....  was here 2017 xainljmpmwlnjmgxurrqohnlxhrfazbvtngknlthtsevcwac
 * Smoking Wheels....  was here 2017 bxhozddvfltpkcataixomajxgtwxnxyprabboorrnvrsxczc
 * Smoking Wheels....  was here 2017 hvrzzbvgfikkmtykycephdfxbuqhbdmqdatxdnseeagkagkd
 * Smoking Wheels....  was here 2017 iucxtcghgedrzytymikfnuyckhbhjntiienpbtdtblfekjqt
 * Smoking Wheels....  was here 2017 denswkkqlzalplorxqszzkvlqohfhacdtgtziwjpvqznfrft
 * Smoking Wheels....  was here 2017 zpbzbjkeezhyfhservmtsphdjaxnzybycjcegtcchhkevtzg
 * Smoking Wheels....  was here 2017 hwbpkptdbqkrbutenbjszizokjrzyvmukwkpjqhzoildziam
 * Smoking Wheels....  was here 2017 wcesfbdyyqfjnkmvmogejsylyopouklzvivvnvdezakqnmrb
 * Smoking Wheels....  was here 2017 qpirawnhxyragybkragupdhthwxokugbxpttsbcwfutfrllt
 * Smoking Wheels....  was here 2017 vzpdolbbhvbxelslrgukugmoasdkbdmwitulffvmbjgputgq
 * Smoking Wheels....  was here 2017 ybkxylgmurwmmecufhlefahkbvbxbczldewjpkirqtytpeba
 * Smoking Wheels....  was here 2017 szkdmsuaegwnorymfoelknpylerzdjucmkdbrbtkicbyauhm
 * Smoking Wheels....  was here 2017 calfqnogoncacslvxpbwdfpbpzgzfzgjxixllvpwsxeseumu
 * Smoking Wheels....  was here 2017 jurtgdwgirueaivkvgngmsuzbrhilgycdzxpfqonqxysnulb
 * Smoking Wheels....  was here 2017 ydmqjhbbbemoltszrqeutxveszotfrrjctyxopnyfamasnhn
 * Smoking Wheels....  was here 2017 qdnygxxfruxwwoxrlbxulasgrxbifbokcffafdtevmzwqahu
 * Smoking Wheels....  was here 2017 ieqbmbijekcdxmmsidxxikoehpcfkjwvoebuhxrjatasnobr
 * Smoking Wheels....  was here 2017 iuaqvfnlzihomqusvrmaosxdeoczwzelfudiauaysohitrjf
 * Smoking Wheels....  was here 2017 cvanjzyqsyartfjmsuhfivkodnxicijgciiazyrpzwvszdjs
 * Smoking Wheels....  was here 2017 ikgwihhjezbfetbbxugxeyzejlnhtglrjlumzuxgfwxcezjt
 * Smoking Wheels....  was here 2017 bvrzihninkkdkbyurimszlxvdndcstudoxxpzzccybazlmxd
 * Smoking Wheels....  was here 2017 msjncjvlbmhtidjemfjlszptcfjfecyojwgljkzocdzdgeux
 * Smoking Wheels....  was here 2017 cxtjsfrxlqgoehvbbmohrmskcgxknvtyurvlrgnitbsnfudj
 * Smoking Wheels....  was here 2017 qlkqmrsemobghafnjoyplaglgptrmshpcwrfqvxigbokikhc
 * Smoking Wheels....  was here 2017 bthrxyxwigtvjcpuszpztcjuxlfgxvvdrhepixoufpzhrhtx
 * Smoking Wheels....  was here 2017 pimduknzhynoipgnmpaisioqqhurajahibbsahfcmjuxtylv
 * Smoking Wheels....  was here 2017 sckxesxrabxyjtvmlnstppnkjwgrfxqdamdyhfvxfixgefie
 * Smoking Wheels....  was here 2017 fcsakuwkiistwdcspbrpxbeudboedftazfoxyzogstsowavo
 * Smoking Wheels....  was here 2017 argyytgujsxxnldnevanmdttieantismrasmzjwfobqjasls
 * Smoking Wheels....  was here 2017 jkdgqbivlltsfuhmpqckilqlnqdeenchwafuselhrzlkavat
 * Smoking Wheels....  was here 2017 sevvnhnreytqejclrpoiuypiqdrwxispnoafrphcdmeqocrz
 * Smoking Wheels....  was here 2017 waxuwknulzsltukkibhrjtoasrrqnmrpvgfjraorhtcioprx
 * Smoking Wheels....  was here 2017 signfnhujmpdquirvpkbwgsodliqzbfyiwectcscthrzeoqk
 * Smoking Wheels....  was here 2017 orbqkbasfrrxtkdwpajjidnanxellizksoonetlwkusiuojm
 * Smoking Wheels....  was here 2017 wwrzlreqrbnigxkslmttahrxruaviuuazrgbndsrhffkdhyl
 * Smoking Wheels....  was here 2017 iatrqgkbphucpuzjhhlnowdwtcurigsdisjhpqsjuulkdwrx
 * Smoking Wheels....  was here 2017 ymddmytrbjpglxybkbpiqgbwczwiitbiiqicjxxgozxwwodq
 * Smoking Wheels....  was here 2017 ywazveijkmdzrgpjfopbkdzbixqgnnkipltqfvyqjmjmvver
 * Smoking Wheels....  was here 2017 wytasoqihdyvlbncnycubjnxgqyfhcpgemofqpvhkhvirnvj
 * Smoking Wheels....  was here 2017 ivzllbianaumgxnigoyyfdqbactejhrkhkvmkptdypooipmg
 * Smoking Wheels....  was here 2017 kxppmukdfcqarosiryhcqwolzojjpdahlzziqmdirwbtykre
 * Smoking Wheels....  was here 2017 hssbsdaotovqsaksfzodidtiskhievdvhjqvnesikvdqxlfd
 * Smoking Wheels....  was here 2017 mdtudurnsyuvmpdhrsifqyvbdkgvnzwzxvrkstkufltdymem
 * Smoking Wheels....  was here 2017 rfivaqakzxjikvubzonqcjvigmguijiblahrxsksnyepxoxt
 * Smoking Wheels....  was here 2017 wijoyuaypknedlkijahcnvycnxqmmyurksvlfqfewtxlbxzu
 * Smoking Wheels....  was here 2017 hbyrsswbarmpqnhtiazlwzoomcvlebwqocxxxmlreptlsdfq
 * Smoking Wheels....  was here 2017 lfmyjbaxtfvcbhbapoftntldauqjufjywkkknidxnmrpqzro
 * Smoking Wheels....  was here 2017 bxqoereysrikuinhebylzgmmfybhaejynhnovrlufozeqlre
 * Smoking Wheels....  was here 2017 bmfwrthwzbxnojtugbhcbxyolujltzefappgxcvmyjeqzvvg
 * Smoking Wheels....  was here 2017 tolmrropxpxrflbdikpqujfnitbifykndjhpbnzlnnztbryw
 * Smoking Wheels....  was here 2017 oxrhfclhcsukzwacdfndlnawrpyrunvyuzmzucvjaclmnsbi
 * Smoking Wheels....  was here 2017 grnkpyqkldjkfdmtquyapoifqgymdnouhahzxfqevfvchaoe
 * Smoking Wheels....  was here 2017 uexfjjbqavqtramlbtbvavinnyjzezxpaicnmotapkpdnwyg
 * Smoking Wheels....  was here 2017 jzzihsxxfavpepkryyenualzzdtscelfuzprtazjcjpgqtdp
 * Smoking Wheels....  was here 2017 ozbplsrkoelmyctgylyeeajawovkhqarniqvhtfymbtnjmcn
 * Smoking Wheels....  was here 2017 agwdcfbozzhdkbkgbohdsachgepbldrhmyiqxdrpdrkdnbgp
 * Smoking Wheels....  was here 2017 scfjujzaoljpfgkaoxicejvundjwmstqdscyqwunoszqjudp
 * Smoking Wheels....  was here 2017 ydgwiqqursychscbxjlvrtzqgapkopumfrowtugfswhsgfop
 * Smoking Wheels....  was here 2017 dekotpmzwinbusbfvyholbgiilbjbjryseptucbircjlxapy
 * Smoking Wheels....  was here 2017 bjhmjfgcbzvidubnhbspakpmwkvtstlhwvjhpejuuqlzeiod
 * Smoking Wheels....  was here 2017 ravcrpvtiqywzsghngxoghfcedbvlwlbclghespuryaxhjcz
 * Smoking Wheels....  was here 2017 fsbynemyamcxgmxcakeidgohwcjciwecfdwxuontdtxxqsyp
 * Smoking Wheels....  was here 2017 dhmyyoqutztyelptnogbzhjovzlhwkolegdmawbjizazwcfh
 * Smoking Wheels....  was here 2017 fvrfesyukxttccehzbzcimnoetijseqlejerrckoqxtlyngo
 * Smoking Wheels....  was here 2017 jrncvskpaebhresaqomazhgefqhqtfspsijiuvanoxmsajpf
 * Smoking Wheels....  was here 2017 xlegqbfdazyvxtoozvduyizroduoevjtnfjpqaorbuconbbk
 * Smoking Wheels....  was here 2017 fzznshvpzwywwcfqtyqlonmlcxrxknlzpjbutuasfmnybkti
 * Smoking Wheels....  was here 2017 dirahkxktmucbsoixiukjzpeyyxqdbzoejnoypppjeafqlap
 * Smoking Wheels....  was here 2017 owbeynkgmumpclqzsnvgdeqvklsbfnibrbfugaslcjdtjlja
 * Smoking Wheels....  was here 2017 tegolboclbipxfucpjbxxszocxrowdbgxotqzzcthtqkryrr
 * Smoking Wheels....  was here 2017 fbsavpvcisunrkpoiydlzmitxznamlagufajrrrebincftzv
 */
/**
*  LargeNumberCache.java
*  Copyright 2010 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 09.10.2010 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
/**
* a LargeIntegerCache is used whenever a Integer.valueOf(int i) is used.
* The Integer java class provides a cache for values from -128 to +127
* which is not enough for the parser to organize word positions in texts
* Using this large cache the parser has a lower memory allocation and is faster.
*/
public class LargeNumberCache {
private static final int integerCacheLimit = 3000;
private static final Integer integerCache[];
static {
integerCache = new Integer[integerCacheLimit];
for (int i = 0; i < integerCache.length; i++) integerCache[i] = new Integer(i);
}
/**
* Returns a Integer instance representing the specified int value.
* If a new Integer instance is not required, this method
* should generally be used in preference to the constructor
* {@link Integer#Integer(int)}, as this method is likely to yield
* significantly better space and time performance by caching
* frequently requested values.
*
* @param  i an int value.
* @return a Integer instance representing i.
*/
public final static Integer valueOf(final int i) {
        if (i < 0) return Integer.valueOf(i);
        if (i >= integerCacheLimit) return new Integer(i);
return integerCache[i];
}
}
