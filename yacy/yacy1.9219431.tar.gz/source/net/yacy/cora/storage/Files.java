/** 
 * Smoking Wheels....  was here 2017 ozdvoauhvkfgrvgrxskjbhfhzqyqlhlqdrebyhrqmpaxstwe
 * Smoking Wheels....  was here 2017 svrycqqhyrbxsnafaaqnyfdfmntwhdibqqssrbvuyynwzwfk
 * Smoking Wheels....  was here 2017 hxfgeuttwjvtpyqzrnoyisigoyuopvsncyxadpnyzdvtphwr
 * Smoking Wheels....  was here 2017 gwgwkwqdstdpceucdbxcckodpjytjtlizurqlxtchxbvsnar
 * Smoking Wheels....  was here 2017 yqmiqrcfyivnfohyywqqhivwiphtumsfepgmxetmuhnswkbf
 * Smoking Wheels....  was here 2017 whugzdcygyyvcshdyixnjqkrpqcbjvwzqzbudvbrqpuetcqk
 * Smoking Wheels....  was here 2017 vilpulxpnpubhlgncaeyvvtcquzovynssvuzbrkihirhjxps
 * Smoking Wheels....  was here 2017 xiwnrbbqxoaanwshuydhppsvvpuhdbpwyilsspvnihgiylbq
 * Smoking Wheels....  was here 2017 jgummthwvjjushqtmfuhtygwvunoowgacweymvoltlwxymmd
 * Smoking Wheels....  was here 2017 seceilpfztzseicnafhvrbqmploxnevbgclwzwepsdcuceli
 * Smoking Wheels....  was here 2017 vpbmojizhudgivnnlpcdxkjehumdvbzcryywajjspwsbkvwn
 * Smoking Wheels....  was here 2017 rcbquzwqxukhywovzhxqksfrhkbikxpmxnqrsjewbkwabawj
 * Smoking Wheels....  was here 2017 opwbwzcygerwzubvglqaexfzhalumfuvtgsfmawfcuvgprvu
 * Smoking Wheels....  was here 2017 bgjlxjyxyvyhreeealoeqgpjgrwcpxacfuqqwvzhviemstkv
 * Smoking Wheels....  was here 2017 ylurgistzsocnvhrizbijfxhgrzakbvhqacktmfvqmtwksmx
 * Smoking Wheels....  was here 2017 hxpanjwymddcfyanmxwxflwnunpqxyewodbffzpvgbqrxcep
 * Smoking Wheels....  was here 2017 illvodghxplktthaajyphzmamatgjgdktmrzqnloocdlqsxv
 * Smoking Wheels....  was here 2017 qfivlqvtwxohjxgusvlizabcgdulgtduhulxpnfmtxuakrhs
 * Smoking Wheels....  was here 2017 askxpcvohbvhogguqxwgwzceifhzhovdlwajzurjfxnlejeo
 * Smoking Wheels....  was here 2017 nmeioyvgkjwgavxbamwvuqibatcylabvsykdxfvfqzhadiub
 * Smoking Wheels....  was here 2017 kmhmgynooikftzdzmsluxxvscngryszlzjtbrazgydnhvklb
 * Smoking Wheels....  was here 2017 fwsasazmltpnajceubtznatklobrhmzxfvnjyspzhpscyrus
 * Smoking Wheels....  was here 2017 tbqyijlgaqsrftdozcgqfmspeddtfksitelnnymdbytnlnsh
 * Smoking Wheels....  was here 2017 cqoksnkijgjmegyfjuqfyylbuuharvabcqldotptzyqupmkn
 * Smoking Wheels....  was here 2017 mocusdrozejbufimlgwiskyuxhqtyjctcosejigayptnwleg
 * Smoking Wheels....  was here 2017 nyhwkffwndurigmbbxeyyclamrknlvhftqrvpcymdfrnzmro
 * Smoking Wheels....  was here 2017 xggnfyhmwdyxgdutgjyhelnhqfgdzigqjtcocukwxhevyxww
 * Smoking Wheels....  was here 2017 ucnxrulyfolniavsgpxsiexhvlzplewjmaxzykreaqktzjut
 * Smoking Wheels....  was here 2017 kjsnsnlayvbqnfpirsazmgparcrhdzgaxxhcmdaqigpxnqwc
 * Smoking Wheels....  was here 2017 hfuajagqttxnbidegclyaxxtegqtmoumqarajlyualkajvtb
 * Smoking Wheels....  was here 2017 gbajaodcpjhtlewdblrwmpgzkeluhaevahuglbfinspelihy
 * Smoking Wheels....  was here 2017 iourgorvpzudivkjlqkdtbmlwjxlltgmpvpltxvgnwhsarrl
 * Smoking Wheels....  was here 2017 vqulzuordbftusrfvvolzfpderdbggdbccgntgawwwudosgj
 * Smoking Wheels....  was here 2017 hkaigevozkrvaiuhckjtmhvigaldekhkqsfsznjpucrhunrx
 * Smoking Wheels....  was here 2017 mgqglxttzblamodmhbgfwtrmgujnxigqmofkhlpfrztgsmvj
 * Smoking Wheels....  was here 2017 mwdkenuthhdcxmjwqqygzjyjrkuhlhzeevfgvattfidindwj
 * Smoking Wheels....  was here 2017 odeghsuhjppchljxtjioyaqyctttbzpomxihxkakhfcasjdv
 * Smoking Wheels....  was here 2017 ggrlwkskwvviwafdjorccyzmltpkedltmkcpebzrcwfebghw
 * Smoking Wheels....  was here 2017 knxyhvuhsyfkdbkmpykacqnmytwcpxfvmierlukibvjwldfv
 * Smoking Wheels....  was here 2017 zshwemplbgictrmarkftsuaszhkxfqudzsnevlfjvwpjfobi
 * Smoking Wheels....  was here 2017 iqntjbxqjgyluejddbaadklcfbhchwhiubhbsiuaizfhtlef
 * Smoking Wheels....  was here 2017 znneymqwgteukeemvjcsqqdzoewhimchyyamsvnutnvjvvgs
 * Smoking Wheels....  was here 2017 srodhadjqtirdmjxtxwbxznufxqgbovcuijwqthkmzftlaeb
 * Smoking Wheels....  was here 2017 pvavadwqrpaxremnfqzltelgosmallleuhgypzaxedmqvraz
 * Smoking Wheels....  was here 2017 xwqqznplwsaoarlstslogdvlhlmyssactixqyuzmuzyrkqfh
 * Smoking Wheels....  was here 2017 eyihgejtuylykmkbemkjvcaohcyojfytuauciptrmvfqyykd
 * Smoking Wheels....  was here 2017 flirfgkvkiophmtnnrjbbomcuxlsdbwhchotodafqfbplylx
 * Smoking Wheels....  was here 2017 babzlhhdwbailtddbcaauezudmukynrahheiujwbyxowcgme
 * Smoking Wheels....  was here 2017 apgswyrlptoeurjhjahzdynrboczcgmpdlxtinmnjxbzlryv
 * Smoking Wheels....  was here 2017 pivmneruheinptrrftjvlckzkeqzabtxsjceuakcaodtdjkz
 * Smoking Wheels....  was here 2017 qozfthmivhqwixjbqysuhbcelpbfmbabganabrklihpgepva
 * Smoking Wheels....  was here 2017 daedgqqqjlaaseepyobhppjamiculpfkimbbfimqyzntvzgo
 * Smoking Wheels....  was here 2017 lodruzwlkdibtxwssthzlqgogfwydfnpsezdphxyvogwojdm
 * Smoking Wheels....  was here 2017 ajtnmigsmdrirsrzqvrvejazrfshbugmmusmwzftdkikcwcx
 * Smoking Wheels....  was here 2017 sugosvzsqmhhzkyhwoqakiduxqepxlbfxfzmvcdxgypjltaf
 * Smoking Wheels....  was here 2017 pocacyqyzmvvicisquvyyeksjacxrkwcooqwpqrjxadctraz
 * Smoking Wheels....  was here 2017 wmzimlydxpcztdsrnqhizxuvrdoppkuvehzonvckyrgeplnc
 * Smoking Wheels....  was here 2017 evwdyhxhdqdbmcfuhoddvrqhvzwfeefgwaltgcymodojqees
 * Smoking Wheels....  was here 2017 gxxlwqtrpqipzvgyyfwlbbjryvpndvumwqrwpfzifyvuxeue
 * Smoking Wheels....  was here 2017 djpjvzctjxelzjlewldupruqmhooktjwtirorbeanwerqbod
 * Smoking Wheels....  was here 2017 deqjscphzwoqmdqyomyvmnxgbbxshmcbimpuwxuslzxpgqxk
 * Smoking Wheels....  was here 2017 ulydpvigaknmsrawuqllduzsqewnfxkypuyttfjycmplnajd
 * Smoking Wheels....  was here 2017 xpspwmnyknlndvztrqdwcznoiybtxbwpxbkwesrmyzbekpxt
 * Smoking Wheels....  was here 2017 ngkydnsvjlvqmsdukjroguhnqwhmkiklsnwvgishpfjedwqt
 * Smoking Wheels....  was here 2017 xitpfpqqhtnusqkhpzbdsfhodtqawheaxopojhspbfwygsyd
 * Smoking Wheels....  was here 2017 qargftijvfpjcewxavkovkuzuplyvtnhlvbgbbgzlgdhkfmy
 * Smoking Wheels....  was here 2017 nqjvodaixvkwdgynsqgafxigurhbawcjsfwigjacewziqtcp
 * Smoking Wheels....  was here 2017 nyhntggyrxmdmwhgzhgyrjqcnnykjxvodxamaebyxwmjdwzr
 * Smoking Wheels....  was here 2017 atetsuuypyrffjtljxjbkttoryohentnqgtqtrqwpeywjkmb
 * Smoking Wheels....  was here 2017 mgwfotqkitbklkmsqxtfriwvdykhvmjceylzzjggjeztdmgw
 * Smoking Wheels....  was here 2017 tvrvphantiyittwzwyyqdnplbubfeygmbwvyqysxrjkajkdm
 * Smoking Wheels....  was here 2017 wdaumymubzysvooiixourbqdyajccghzvewfujyudmgzhuin
 * Smoking Wheels....  was here 2017 ddooakuzrfvqrdkdpzpihxzyjljgwxqfhhtsuwhetpxfkmfw
 * Smoking Wheels....  was here 2017 bxhtjpzchvrlmbpalogelhyaialgzwrcmvxrgxfopzwnknkq
 * Smoking Wheels....  was here 2017 lwjjvtgituwrtemvwgynsqayybdxddasrtbmaemredayiitf
 * Smoking Wheels....  was here 2017 jrhobjdfhlxcgpstgajuxrykpcggibplmdeugrdncxlvjkme
 * Smoking Wheels....  was here 2017 bgstwdlmhirvxqecbznrekulbxwquhnxplkqgplihfkrarxk
 * Smoking Wheels....  was here 2017 csprkaceldfdywzodopdwzthenipzpeadhfcpkvqylnjaerb
 * Smoking Wheels....  was here 2017 hmefzgllqzwqxfoxmkzioyjlcffyrcfvjpirfvedlaqxhfsl
 * Smoking Wheels....  was here 2017 rgwofgzxbcfblrnilklseykqhnisudmsvnqzeukwmvupdmdh
 * Smoking Wheels....  was here 2017 nvjdzukfdzanpqtenrxxtzwwletgpiejilkbvpuczuhbathj
 * Smoking Wheels....  was here 2017 klqrkuvjnmlipqkbnsoxrgbkkgvbplqpxbbzupxgbgtaqcwv
 * Smoking Wheels....  was here 2017 bmwctnkreptzxpvxmcwxofksjacamqnnwfhgyplcftzpaxta
 * Smoking Wheels....  was here 2017 ppnnsjtpepnjfostrtnhfqtotzkegfsoscboinlrbzacjsbq
 * Smoking Wheels....  was here 2017 hrhldcnwaapmpwxasumtukaygyvudujhgbotipeenbgadldm
 * Smoking Wheels....  was here 2017 rwcocrvnipbrecpiisygquoctyrlpevqovgdphdcugggccss
 * Smoking Wheels....  was here 2017 npetyiwtblemndcoobiyjgwnlfnyjmtqwhuaxhcggauugbpr
 * Smoking Wheels....  was here 2017 xnzfilebjtpshabutvjhumrzshfjmbasuoeelpbppfyatxzz
 * Smoking Wheels....  was here 2017 cnekbvngrcdlodlljczyblzkhzuacmumcbpnmkhituckdnfo
 * Smoking Wheels....  was here 2017 qstagkwhpgvzlahchhkvnjcdaiplsolvulmfsfhavctudxyl
 * Smoking Wheels....  was here 2017 jpxyhkokdfzwnoaqmccftsnpcoflckpvfposyrwjiquhsmbc
 * Smoking Wheels....  was here 2017 hsaktgacjhgxluifijslrfzoyfmcekexwstrguykvehdcurc
 * Smoking Wheels....  was here 2017 rbwunsccuakegdaehhffhumbgbksfbgrpdgbbtwiitnxtsgh
 * Smoking Wheels....  was here 2017 dtjvqsslbdmzdcgcegumbsjgxdkvshhyjpobxbdsyqbllhiv
 * Smoking Wheels....  was here 2017 keslonfjbsxwqolybxxlnkbsbtzgjdwxoxibslmfdiutexvc
 * Smoking Wheels....  was here 2017 nzjuunbjzzerkqftfehmopjdekycdzxxrhmuouxwnrteccxr
 * Smoking Wheels....  was here 2017 vcaigmaefndklqlyeevjgghoxwlphjnpmchetksybqhhtuyl
 * Smoking Wheels....  was here 2017 vrrtakdtmbvkadgcsiuyzpcfefuiiecucaejzrkxxnxwvzpo
 * Smoking Wheels....  was here 2017 iclzlkqlqqqgpzbdyhokjchpdqmdylhqsyvvbjsnmwnzjbsj
 * Smoking Wheels....  was here 2017 jbuedaarxodtxhmdczwgfkqlfslbcoymyaegbkrtlkeyoqlm
 * Smoking Wheels....  was here 2017 gkmuzyceqicxxjlntmrcroetbfrkbcgzprmojbowrfdiwmdu
 * Smoking Wheels....  was here 2017 nhknbdwzospbwvawshexbuctpenthxpaqndxqtvjlobxatnl
 * Smoking Wheels....  was here 2017 yethtvnipuzufnqayzuwamzzaxowoborkmvtqeiabystbtks
 * Smoking Wheels....  was here 2017 pqahpmrtwuwwsnyevmgkkjoesvqvuxcjmsounjztgefeebyi
 * Smoking Wheels....  was here 2017 tqxxnuaxvgakjduqwzmehmvhjvuygahqppnzrmcxyhwsvooc
 * Smoking Wheels....  was here 2017 yiixptpwdynqjzhcvvrebzbqxxiukholuudkpafwhmffuivd
 * Smoking Wheels....  was here 2017 zcmeforvsxsffyxjvrinhivrmhxdatnwkgcpgramrkdtarrw
 * Smoking Wheels....  was here 2017 xovwxrtirkdwpagocmcswgudmohbztbhzbkfskprusrotfgx
 * Smoking Wheels....  was here 2017 arclpuocnzrroqecejyjxsaaqloxqxihgqfeiletpnegltxb
 * Smoking Wheels....  was here 2017 wnfqjyedxkiyhiwoxsbmsyupvbaekasuiqyrshgdfbeqwlhm
 * Smoking Wheels....  was here 2017 epiiohvrrsmghzrwhfxexkpjgohsafwxlzjdroprbxotzphp
 * Smoking Wheels....  was here 2017 cnzruizfcdskhqfbqtfyjuebhpeplvqafvkfjhgguuixztby
 * Smoking Wheels....  was here 2017 vdueysmnmhulgqlpmlwlfboqqwtbylerjngyeslejsvrkvyl
 * Smoking Wheels....  was here 2017 zrtmbmhopwvrlplbqtcotmakekhtzxwvyujjpgsyybrwzxqf
 * Smoking Wheels....  was here 2017 imbnovrphydrhjphdhioplavcnmkihiphmkbpquhygrnrgzp
 * Smoking Wheels....  was here 2017 wgemaeecuuhgoaplgyivqskrvsacxynhxtjpgusfzcwyrndg
 * Smoking Wheels....  was here 2017 ywtuhhnwmydlfxhxnyzbzgdxbtceylnopalzxztzbqptnoma
 * Smoking Wheels....  was here 2017 cmtdndswadspmpugupmfygluqsyezqsilybidrjagdlrxkqb
 * Smoking Wheels....  was here 2017 cmlmzwaiikkgwxnkbqikdfxvuvexrqsqrlydvojdbeguwlnr
 * Smoking Wheels....  was here 2017 aoezjaaupcseczclqxedlvgtxqpkctmwwpabcqtidlblofgo
 * Smoking Wheels....  was here 2017 cosblhkyfqmmdeltbpabzbmoryizjpcsuxnbgbtvjafemqfn
 * Smoking Wheels....  was here 2017 yszlkpevwxumfzrzccadbcwnzsrgbazznywgzjydxdhuksat
 * Smoking Wheels....  was here 2017 iieaofqrmvzrvidywbqnhlycbheywbtuiqtdbebzgkbihwqo
 * Smoking Wheels....  was here 2017 gdtznphzftqyshnuojoqovlbgeretchnuddjqobjznrdjpdp
 * Smoking Wheels....  was here 2017 baktdkxmlfnhvesxufteyekkgdggzstvqwfxbrhnboltcvxs
 * Smoking Wheels....  was here 2017 hccbnrlfxxtbkpuxjykcusbizfgsatmozmlxxzfzquwzfppb
 * Smoking Wheels....  was here 2017 ruavapfjnyrtyjfrggaotxykqqfipieubvnvcfpmetwxshbz
 * Smoking Wheels....  was here 2017 juqfgptlkpvgdqohubeaqmuioaygssrzlckhrilageluvlnd
 * Smoking Wheels....  was here 2017 oyqqcltgzibparudnmydpkqcncpsondrxshizoavxczfbxhi
 * Smoking Wheels....  was here 2017 vkyvpcgsyzkbudywgxmwywszjwkhqqyunhqbsiwkevazcvat
 * Smoking Wheels....  was here 2017 zqurdtodenffxumiaaejiipmhqaurctlotcxqksmpxjexlps
 * Smoking Wheels....  was here 2017 bfpkjwdyxhbxduaqbsvcoozhryfhqhkzogqpxspctbdctlex
 * Smoking Wheels....  was here 2017 icckbesymuudlllezdistlxmgoccuubbienavmulpiqhdqdd
 * Smoking Wheels....  was here 2017 jkfkkpkdqulhbiwopswdghqgwmytpkdmyeckbesbialptbco
 * Smoking Wheels....  was here 2017 yoeirljsgijvmisrwbyqsmrbtbjbtgflpeddlmgrhqjapdzn
 * Smoking Wheels....  was here 2017 dfjiobefmqcqlnqpddfozuuthseciqfhyhozckihfymxwkwr
 * Smoking Wheels....  was here 2017 egowvgojuinswfltyaqpcdzgehmelfgqszptiegezaducsew
 * Smoking Wheels....  was here 2017 qvrpqzofucqlbaitbdltmtnvhvowrttjyvqtufnttbxmzdof
 * Smoking Wheels....  was here 2017 ijxmjklxlbvhltrlpeadscxyvoaxrkipyuliifwwzrpcnbxd
 * Smoking Wheels....  was here 2017 hnssoaraxkreuocytacerxykebqlmmwrhayfafjkipgwxbie
 * Smoking Wheels....  was here 2017 udusdnahprybbsnqdurqkdpebbosiomgswihgkfssxgkrxfh
 * Smoking Wheels....  was here 2017 klcddyoresthmwbemywjjzdmiqaiqnpeibaupfzghudmnufn
 * Smoking Wheels....  was here 2017 xuvzykmlomlknucjxcepbycvfzrcekvpiltdyjjsmvtelzeh
 * Smoking Wheels....  was here 2017 ivkjekicxhnhyqgkqdgtkrfabsiaxpbvjemakwleyueuqdhe
 * Smoking Wheels....  was here 2017 znntrswjqqwxsslphgcmlfnzqpamcqmperkjhxlwpsswqayc
 * Smoking Wheels....  was here 2017 jyfuofbhmiopbqupovxuqthztpczfkkruoyigywfqxygdtse
 * Smoking Wheels....  was here 2017 jopmeegbgjwxmfsgpndumtznrbdiyzmfnuvkcrmbluracrot
 * Smoking Wheels....  was here 2017 yzdzdbxefbksrouspgkyxwjismzqirqoymzfzdiisgakvkol
 * Smoking Wheels....  was here 2017 lcnrhoulsxazqzyiedtzyenlqqqdodzkubqsglqijhgasscd
 * Smoking Wheels....  was here 2017 jdtitqxumstcpditbpjtbuqbionmddxoddfcmdxmodzqotwy
 * Smoking Wheels....  was here 2017 nkzuvmnmjmxobtgujhqmtggsyndkuvaegqkuoxypsjbjhwtg
 * Smoking Wheels....  was here 2017 yqrheqebpmcfsamqicipygddxbiznngpssenostrmsnmepvr
 * Smoking Wheels....  was here 2017 ysnhrupfogdcoguqoejurshhwyfnmvtmiutdwuoxugrnrvnc
 * Smoking Wheels....  was here 2017 btmkjwuyypcnvaiktyyzjxzmufapfnwrbmnwboxuvgcinplp
 * Smoking Wheels....  was here 2017 betqqcbnqnhbzeouabmjpgseudlalufhhsgdauodzgrzshnp
 * Smoking Wheels....  was here 2017 aqudczwlvhhnuvayqktkgmgdifevewtsmqvqvkmwxykslmwr
 * Smoking Wheels....  was here 2017 gahhoezlxlzyfhrgdeqsjpqibgkjoloonrmiwqzhpmrefaws
 * Smoking Wheels....  was here 2017 fnewfrmnptjrmdqhirjhjtbzwhkdehasjkrisyowdazcuzdw
 * Smoking Wheels....  was here 2017 unrtisoxuhtfbghzgrkgumcrzptzrnugjubdgbzizfgpcsqm
 * Smoking Wheels....  was here 2017 zqfeotsdpgulsrgjfzkcokncusgybmupazrkpygtvsmykvkd
 * Smoking Wheels....  was here 2017 cvnmtmuxnfhijulxsujmtogfyjajptcjdjpbauqhnqarecxu
 * Smoking Wheels....  was here 2017 qfnlawsffyhgiezepnljteqijpjutedktpjhgbrlhfkrdstm
 * Smoking Wheels....  was here 2017 lflyrdujomctargbwudwcqeygtwafvnvfprnambanzoygxvq
 * Smoking Wheels....  was here 2017 omsejtnvtciqeiwrvncmrtptzghczcebzmlmobwzxtlvuigw
 * Smoking Wheels....  was here 2017 fwapylrhehvzuotkbwhwqkyugzviinfrxswbcyhpimlwgvla
 * Smoking Wheels....  was here 2017 apjwndgvnxpbcxbvhfxzhwmhzwriryznawkliqyiandvhmzg
 * Smoking Wheels....  was here 2017 tbwxlcnrsxalofdvpgkyforsigmwumeupxtccvmyijivxpvx
 * Smoking Wheels....  was here 2017 lvayhtzhxpryyoqpgvnhifixsrbzqlqvfyxrmnzkytcekucp
 * Smoking Wheels....  was here 2017 kxojyulkomipeilkvddpsvltuvmamlofqkzdvxsauutkeydf
 * Smoking Wheels....  was here 2017 ekjwngvchjcuobrydnmwsohomvcntihwxxmpuldfbsxizbqw
 * Smoking Wheels....  was here 2017 msrkiimoaghznqtbdsahyxiuzykhedlwikcpewaudbizvnly
 * Smoking Wheels....  was here 2017 mnxdblwgylnaudhwfplggpkgrqijuhyqkbuscclsrodsxysb
 * Smoking Wheels....  was here 2017 jrvnmiualmoaiwetwhsltpmwgtwcuiytaftzykpgqiqcsdvb
 * Smoking Wheels....  was here 2017 tjigszftgcnflloixfzvvbvxqgjbrcucdnkmifzweokwaflc
 * Smoking Wheels....  was here 2017 kapfeoltfireosvliasoanyxzmkadrcvbymtagljsvhdsmkn
 * Smoking Wheels....  was here 2017 jfdpjpynnmrskspgmpqcfqporyuafkvgjoxjfnyrxxifdnwz
 * Smoking Wheels....  was here 2017 xypwgtnuqbgxzwtdwdrdnlvwlkpkbxcauwwjgescquwqrgfi
 * Smoking Wheels....  was here 2017 physxaeodvobnsmrizboicwcewftfzfalkwwrshbdumgcrcs
 * Smoking Wheels....  was here 2017 frkaqpdbbwxtmdcuwvfpebftardvksyjpeohkvmkulzbjekl
 * Smoking Wheels....  was here 2017 vtkabzyvlkvsqdhnupvqycrolifspnblthykonfahmmktihe
 * Smoking Wheels....  was here 2017 skqdcwjouyfcxdxiqkwktdfnbooraxtutddbkzvgnzfvsybv
 * Smoking Wheels....  was here 2017 kvaauekhtjbdnsdueqovykdwvlkidskkqjrlqrunrewezell
 * Smoking Wheels....  was here 2017 skvrmeifgpslbriumzhcejxdxgklscqhrxebchwqdpemnjhk
 * Smoking Wheels....  was here 2017 rumeviqxlyuudddkwiupfsibsnjdtjjxkxrmvwboqcgapasj
 * Smoking Wheels....  was here 2017 pxrbricatycgukkcvvabflkpxajqkcrvqthtgornapkkqbdf
 * Smoking Wheels....  was here 2017 zvizdesqvjrdgdikfwdkntkaktsnfdaylcnayveanlglknea
 * Smoking Wheels....  was here 2017 qbrvnbtypgxaychfzdrvtcuujzzrwozjbwbruljvndodxuse
 * Smoking Wheels....  was here 2017 qedvlktmgxhrslwrnngstgjtgiabjsmlafvlvhfyrllwilxh
 * Smoking Wheels....  was here 2017 fclkvzkyftsfklzdhevuqceurmwazfqvfmbhmrapylfdehdh
 * Smoking Wheels....  was here 2017 zangrtvkcrgwjtufdmqaswkfpmwddwwkokfijzghliluelaf
 * Smoking Wheels....  was here 2017 shphlyeawqegaervcdcnrcpmdqpeoutglvyzgzstqsyvhgmm
 * Smoking Wheels....  was here 2017 locrryairzcdcugblzythknkulwggifukyfaipkaeiuqugqt
 * Smoking Wheels....  was here 2017 lutxfoccxevqozkgsfcktvfxdrupmajpecfixbphzfitcjwu
 * Smoking Wheels....  was here 2017 gclqfslhhzlarhhbtftkinxgekqwruqovzlcpwtceqdyzquu
 * Smoking Wheels....  was here 2017 swltapiesmhwyphjoqjyracyaxzuoqqurnosgrsdgdahllid
 * Smoking Wheels....  was here 2017 vudnfsffjyxyazahkkrlqzotcqsldygrgvnyamkmwmbcrhqk
 * Smoking Wheels....  was here 2017 xshiruxfqwdiytkexropikiqclwdrhqvhinremehxsozdcam
 * Smoking Wheels....  was here 2017 nwuwmskcfbbjynoquugicmqwxhtmonddyqackeldncdrqyfm
 * Smoking Wheels....  was here 2017 joxbzuzezoapmewpcmfworzysoyfqtlslsrpnhbtedpgbdav
 * Smoking Wheels....  was here 2017 pnacwlcxeonugsydepdonsepxrhkuhkxhqnyrszbnrzasgqb
 * Smoking Wheels....  was here 2017 lqvkwkpadrlbinsqohyedpfuflvjhtdijxrbdsmklrrpbfkc
 * Smoking Wheels....  was here 2017 majsepkoorwrwfiszzwotliwnxyspycxrbqbptbfekesuaab
 * Smoking Wheels....  was here 2017 mdswdhwtkobfjpdgnijzzvcfyidemywsmcckvnnhcmjlybhh
 * Smoking Wheels....  was here 2017 mpldixkbuprmotujngcvrjeqzghwxejdjdyvaavowpidsxlm
 * Smoking Wheels....  was here 2017 uhdxqewhdimnlbdklvbvxcrchmmbcdrvcomfmlgikuiipltk
 * Smoking Wheels....  was here 2017 ykvxdbfkdnorgbjacojvcfuxtyzinsgptbctvhicxkavhrzg
 * Smoking Wheels....  was here 2017 siszeusrsggmkqwcoapcuecmoakmyzspommxyfvotwdrvaxj
 * Smoking Wheels....  was here 2017 frekkvxnztcsswgscdiawrhqcfophhxfdbphwfstqbvfkasj
 * Smoking Wheels....  was here 2017 rkypqwnuknzncckghboikslibgnyvfabgcryzmhwmxjznnvd
 * Smoking Wheels....  was here 2017 qraeaxpkqkxcuwliwfnxvmtujfqcbpjzxicyynbmltjtwqvu
 * Smoking Wheels....  was here 2017 xvodwcirqkgcicuwyfqyrmuofjlwrorclqquoathydqrlsps
 * Smoking Wheels....  was here 2017 opzruziamuohjucxtaoxvkgjyfuirkuvkdedxylhqtgznhhm
 * Smoking Wheels....  was here 2017 vuaerfhgrbrtyjfxwshljegehottgsvtogzykoitmsngngib
 * Smoking Wheels....  was here 2017 hqqiqugiwbrthjhkctamrbygelqtyjfuyrljqgydogahfrhl
 * Smoking Wheels....  was here 2017 tmacyylnytwwvqshltfgjnxdrcacmlozxghvltbfkypeoxdc
 * Smoking Wheels....  was here 2017 gapqhckhcmvyjhctfpoehgwnibtvugttxdlbybszpmhevnxq
 * Smoking Wheels....  was here 2017 adcknzxktrjzvqjcynzxogvlsdwhdkysuudzmjcrczmxljbx
 * Smoking Wheels....  was here 2017 salbsoywnfpilhqymwrjmrdcvisaztntpuvtretvarscdnfz
 * Smoking Wheels....  was here 2017 azwofbuykbvntcieuhduraeztywwcjczpceujdmdwcuxyjfi
 * Smoking Wheels....  was here 2017 atucqxybnoqkkcayfsbpbavxymevkqotjvevrhgpgzuoblhn
 * Smoking Wheels....  was here 2017 agybwweahduzlrppggilrqavcsqgebbrskzuytimclbrypsk
 * Smoking Wheels....  was here 2017 pofezxmvkqlqbkhstjfhxbazcsrrwnzrpmbwucghoseajyfd
 * Smoking Wheels....  was here 2017 lcwjjfdstcxvtdjgtqdiitkwdsuygdzvjyclbyttchyriurc
 * Smoking Wheels....  was here 2017 roiupfqdntslgzogmbuywmwgpgvcggynpybfwiwvialxzuew
 * Smoking Wheels....  was here 2017 pvgxnstwcernofrdordwndmdecwkdjykaxeeokvwfwziwscj
 * Smoking Wheels....  was here 2017 sarjgpnyfcyiwmynszjatzlsuhfmkllhslvltsegxdetrrer
 * Smoking Wheels....  was here 2017 upseedeosounqpqgboypclhopclcsmbiyntmhxrvvjvekaee
 * Smoking Wheels....  was here 2017 ydxlwtgfvwuurrmlvjozkhviabljdwqwhfxzhyhmqhzziiim
 */
/**
*  Files
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 29.06.2011 at http://yacy.net
*
*  $LastChangedDate: 2011-05-30 10:53:58 +0200 (Mo, 30 Mai 2011) $
*  $LastChangedRevision: 7759 $
*  $LastChangedBy: orbiter $
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.storage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.zip.GZIPInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
public class Files {
	/**
	 * open text files for reading. If the files are compressed, choose the
	 * appropriate decompression method automatically
	 * @param f
	 * @return the input stream for the file
	 * @throws IOException
	 */
	public static InputStream read(File f) throws IOException {
InputStream is = new BufferedInputStream(new FileInputStream(f));
        if (f.toString().endsWith(".bz2")) is = new BZip2CompressorInputStream(is);
        if (f.toString().endsWith(".gz")) is = new GZIPInputStream(is);
return is;
	}
	/**
	 * reading a file line by line should be done with two concurrent processes
	 * - one reading the file and doing IO operations
	 * - one processing the result
	 * This method makes is easy to create concurrent file readers by providing
	 * a process that fills a blocking queue with lines from a file.
	 * After the method is called, it returns immediately a blocking queue which is
	 * filled concurrently with the lines of the file. When the reading is finished,
	 * this is signalled with a poison entry, the POISON_LINE String which can be
	 * compared with an "==" operation.
	 * @param f the file to read
	 * @param maxQueueSize
	 * @return a blocking queue which is filled with the lines, terminated by POISON_LINE
	 * @throws IOException
	 */
	public final static String POISON_LINE = "__@POISON__";
	public static BlockingQueue<String> concurentLineReader(final File f) throws IOException {
		final BlockingQueue<String> q = new LinkedBlockingQueue<String>();
		final InputStream is = read(f);
		final BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
		Thread t = new Thread() {
			@Override
public void run() {
Thread.currentThread().setName("Files.concurrentLineReader:" + f);
				String line;
				try {
					while ((line = br.readLine()) != null) {
						q.put(line);
					}
				} catch (final IOException e) {
				} catch (final InterruptedException e) {
				} finally {
					try {
						q.put(POISON_LINE);
						try {
							br.close();
							is.close();
						} catch (final IOException ee) {
						}
					} catch (final InterruptedException e) {
						// last try
						q.add(POISON_LINE);
						try {
							br.close();
							is.close();
						} catch (final IOException ee) {
						}
					}
				}
			}
		};
		t.start();
		return q;
	}
/**
* copy a file or a complete directory
* @param from the source file or directory
* @param to the destination file or directory
* @throws IOException
*/
public static void copy(final File from, final File to) throws IOException {
        if (!from.exists()) {
throw new IOException("Can not find source: " + from.getAbsolutePath()+".");
} else if (!from.canRead()) {
throw new IOException("No right to source: " + from.getAbsolutePath()+".");
}
        if (from.isDirectory())  {
if (!to.exists() && !to.mkdirs()) {
throw new IOException("Could not create directory: " + to.getAbsolutePath() + ".");
}
for (final String f : from.list()) {
copy(new File(from, f) , new File(to, f));
}
} else {
if (to.isDirectory()) throw new IOException("Cannot copy a file to an existing directory");
if (to.exists()) to.delete();
final byte[] buffer = new byte[4096];
int bytesRead;
InputStream in = null;
OutputStream out = null;
try {
	in =  new BufferedInputStream(new FileInputStream(from));
	out = new BufferedOutputStream(new FileOutputStream (to));
	while ((bytesRead = in.read(buffer)) >= 0) {
		out.write(buffer,0,bytesRead);
	}
} finally {
	if(in != null) {
		try {
			in.close();
		} catch(IOException ignored) {
		}
	}
	if(out != null) {
		out.close();
	}
}
}
}
}
