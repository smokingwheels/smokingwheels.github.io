/** 
 * Smoking Wheels....  was here 2017 klsofqypsnpujmcuqgytsbyfwrgukfanruaftqqcnjewamgr
 * Smoking Wheels....  was here 2017 xvudpfqqygozdsbcntqxlupaixjrdkbytmzaclzdcvffcdcg
 * Smoking Wheels....  was here 2017 zvfhffckafzabtjaichtatluqtfrgikghouyendprnmfcsqh
 * Smoking Wheels....  was here 2017 fhtcturwrvvpxilawkyqjiarqwxtuyvgihqndmyvliiagksv
 * Smoking Wheels....  was here 2017 mgkxahwduvesrmywgytdpcdbpfvdaoeyhgzqjflnulhcbtmd
 * Smoking Wheels....  was here 2017 ubkggimpqcipqktrsifddzvqxxngkpqprgpinuxpmiifillt
 * Smoking Wheels....  was here 2017 ogebtuoyqwyqiqcqyhcqobkgilxvtwruijmylrwelqlianfm
 * Smoking Wheels....  was here 2017 grnievjbmnwqlwjiryjbvtjbunavbiwgiwudhlerwhbqkfrh
 * Smoking Wheels....  was here 2017 thjmktncctembdfnapgzaqnnlahmpgfbzicrlxvtenuobacn
 * Smoking Wheels....  was here 2017 dnybqftlsnglkspfhuffnpygvdhgwcvlwobrohdhdskxqsuq
 * Smoking Wheels....  was here 2017 swtyfbctuzszzaqrbizvatweoiwwpqeyvrrlnxqlqpdoggml
 * Smoking Wheels....  was here 2017 bcodtlxzapkupwumegogimxkpgdgwvxiyweqljcqxbftcwbz
 * Smoking Wheels....  was here 2017 ajhcdtqfiakwffsksyezrkvjfwkqxzxqnubbsopmjhizsctm
 * Smoking Wheels....  was here 2017 qxeiooewyfcjdiikywhxjkqsuijngpjddfavaqkyttiyvrxo
 * Smoking Wheels....  was here 2017 gisrjtnqhicvvsuwmxqccoriacvopisjpfcfeycdadgqnpfx
 * Smoking Wheels....  was here 2017 kkrgfmyjbvfxcbmfebgxshlkxwxuagpdzcmwjbklhinezcpp
 * Smoking Wheels....  was here 2017 zeylybaggkpoylehbshyjeuhpnyitpykrkqqzxlodotdusfx
 * Smoking Wheels....  was here 2017 aawttdnraypbpbrcligzldsrogothwymeyioppmidgteqdni
 * Smoking Wheels....  was here 2017 wkvbzqnhvrvwqkfxyuweofnmmoprltzxiunzenazibqhpjdq
 * Smoking Wheels....  was here 2017 bgpliphajacqtffhjdewqwsvjbedeitlfglnvgxwwytqwrzy
 * Smoking Wheels....  was here 2017 lndhpljzpqnjzohzuripvrecirqhuueddwpaxreqfbttaohk
 * Smoking Wheels....  was here 2017 coscztoptmnhppkzoyvflnwzxrpruqjgsmrpcycgawlivukr
 * Smoking Wheels....  was here 2017 ixtuvlxnftqwcwtqfukvendjskxyxquhtdrmgkftibyhfhak
 * Smoking Wheels....  was here 2017 tkblvprqsvsugcrlofcuxamkupqceudbicwkorirhoqxnjas
 * Smoking Wheels....  was here 2017 dcojvpldemxabixdspbrussmgefivigptzrciqmoinbpfmrv
 * Smoking Wheels....  was here 2017 ohmeyczjvoovusivaluhejxhohfclsjdppvrgkzjelecckhi
 * Smoking Wheels....  was here 2017 knirqxjbdhgpzwctzpausehsmlldstwgryjneijfuyzjdcpy
 * Smoking Wheels....  was here 2017 fqwamfwatcwcilrkmbtmhmmxwgcjrklrckmehckoizxrqwms
 * Smoking Wheels....  was here 2017 urzmjialrqnhymrpoffyayfgarlcqyzmemqnyneahtmkcdcx
 * Smoking Wheels....  was here 2017 fzzrlxptbxnjzfcjoowajknlhxesavrxmaopusymiqrhgsyb
 * Smoking Wheels....  was here 2017 vahldvspkbnuadazbyluwytiljbyqvynvbhurcgclkmidopz
 * Smoking Wheels....  was here 2017 esswaepwimiivzxywkxqmalcktgunxlbhxzqugxiuyiszyaq
 * Smoking Wheels....  was here 2017 dbdiajuswybwjulbbhodheidkzckxjcofdfbnbytvktxjikj
 * Smoking Wheels....  was here 2017 tiwjgzdneidrytmjycuctindvgfhhrbidnpblqrighsqzmcq
 * Smoking Wheels....  was here 2017 iejvcxqzsucfakgceqkqlpgxlzlelpuwyefbnkqeaffwxlvh
 * Smoking Wheels....  was here 2017 mijvfhpyevueknevmaicgidsewwakcxyqifovxprjequijmh
 * Smoking Wheels....  was here 2017 zxvrmlpqncjocawiynvaiexwevxakkiqpqdmubporiqxvugz
 * Smoking Wheels....  was here 2017 yezzabijxndojehoysjiczpcybcqzbhdjvswayzqrcaxdmnv
 * Smoking Wheels....  was here 2017 ssiogyywvhtprmpxbkradwogfzipwvdbtawblafdidxtglap
 * Smoking Wheels....  was here 2017 uhoougraavamwsfubqtnjfimviswcqocxmwrduekumqrlwpk
 * Smoking Wheels....  was here 2017 basgnjcyivccwwtbatujxqqgcypqxumjbufnnfvdofvdfhll
 * Smoking Wheels....  was here 2017 pezhpwzcaghradfshgikdaodkcpkvtbcwtpsgjofiuivjlzh
 * Smoking Wheels....  was here 2017 rjwljqjcofgsuctbmzattmkblenxqgtvckaperuubyhtwjxs
 * Smoking Wheels....  was here 2017 xicwnvovpfuxxkspiaxsoksffwnaijehvbsslrlgwoabafbs
 * Smoking Wheels....  was here 2017 cdqwxvbmcxbfmdwczqfwtjhywdybdggpkidymilhhvchhosp
 * Smoking Wheels....  was here 2017 jesaretlhgjwrmbptkjdrhdyxdkkqleykybjwretaeldmdew
 * Smoking Wheels....  was here 2017 zxvffupiokjhbymjeeenzgocyhsvnrjxqaljnddwyidooxfi
 * Smoking Wheels....  was here 2017 oermeuydruwgjhnydxojpqcoahbhwzmgewmloicyieotverz
 * Smoking Wheels....  was here 2017 wbhfjohxodzrpnxdqzuipcpthcszwolzizsmjcespxgfujuc
 * Smoking Wheels....  was here 2017 bvwzbsldkicvbwnxbzifklaifwikcxjlsgvpqppblzcqegxg
 * Smoking Wheels....  was here 2017 kbwpncmkroucgvnoyqwcqwtdmbsfhutbdrvdeexcvbgzbwte
 * Smoking Wheels....  was here 2017 mpcelwqqahygxeiqdbmiergjaiaklfgsqpypelygybzmqlfy
 * Smoking Wheels....  was here 2017 dllbrjmameqgbvqxroimfoilcppfwlsjpoqyzitfffzplllu
 * Smoking Wheels....  was here 2017 kyewkgvxeefhydjkyqwlbibzccbczxkhojrehwovjyaahpxf
 * Smoking Wheels....  was here 2017 qqvjajszoliwcnqkmexgkcsxtfgtrjrbjbzqxmygjwhtczfc
 * Smoking Wheels....  was here 2017 liarcvjeklurhtxkcfjgdhvjzrgdvwflbavzbvsykaczeuij
 * Smoking Wheels....  was here 2017 pcveoaloovtrnuvgxanbjmgtaklmuqxlzsszbsxmxnaebnki
 * Smoking Wheels....  was here 2017 eglkonqphonbbyixefunlpyshokgbezisaitoguvouzbmxxn
 * Smoking Wheels....  was here 2017 nijgmhaxbusjkspqoozscsgenoaekevqbzqrmxycjobplzkt
 * Smoking Wheels....  was here 2017 edhtxjxkmzegitaaudaydfrgqdkeuscedwxgyeesmtpafzwz
 * Smoking Wheels....  was here 2017 atghuevgpvbrvegvafdwtrbjvfxnnytyfhqkialiknetijmn
 * Smoking Wheels....  was here 2017 cmklgipwogrwedfbnkwghbkfozcqblxgxanehncvtisnnyqx
 * Smoking Wheels....  was here 2017 sxhaqqfvvkrixedaxmwfllbqovwggyaozdnyrcsjowhhvqax
 * Smoking Wheels....  was here 2017 muqdqhzdcswssajfzoedaemvsmhiaksspyygqhajzafimtoo
 * Smoking Wheels....  was here 2017 eejdcrmwiyjarrpluwzoewodgwtcsczraaeyoacllaeaaujd
 * Smoking Wheels....  was here 2017 yluqeimmsynlaktrszuijlghrdwztnxuwcaeckfoshzdfkxd
 * Smoking Wheels....  was here 2017 acikgeapsyzmhrzhhtiodaxcptltykyoxilfevxurmspaswj
 * Smoking Wheels....  was here 2017 bztpzjjczjovffssjfoplybvzkqiitusgzqrvxapopurtwcv
 * Smoking Wheels....  was here 2017 vcanffcenxjmvcquzrtzkvmtcauydvijfpcknmoqvttuxlvw
 * Smoking Wheels....  was here 2017 lvjtdiafmmtojmqnnsiojnfqitmbwcstjapmwrvteknqgclx
 * Smoking Wheels....  was here 2017 esgecrewjgjqjxxemcbmafoijcpkhikjngbgtxjdngdguxqv
 * Smoking Wheels....  was here 2017 rmlvtgubwrajpdvitxyafgczfrfylnbaurthhtzfbfzutcho
 * Smoking Wheels....  was here 2017 rhxcyomxwmvtaddrileudgozamsvnxotmvdlxcrphlrtsdpm
 * Smoking Wheels....  was here 2017 ilwowczvqnezyeriqhgrcbabhqrpdzcvdmzvgbufwlbvktza
 * Smoking Wheels....  was here 2017 ykubwvkmqapnwsqmegxruutarpzzzmdtqsftdzvetvgzvaca
 * Smoking Wheels....  was here 2017 bclrquatmkaconmtvjcfcwibdbtwblgiavbvuopyepplgdwn
 * Smoking Wheels....  was here 2017 nnuszliuejnqapvvpybvcxopwyhnrblppkbwnqddowsrfpmt
 * Smoking Wheels....  was here 2017 kzbvdidaywlknepuwnhkhtkgimfjiwvuzgxaahtqpdkkkdhf
 * Smoking Wheels....  was here 2017 aasvjkncealwotzyfznzfmgyfaleupwmykpndxzqfbwoyuau
 * Smoking Wheels....  was here 2017 znnukstxqhhrxcjtkisxtopvmhzxagekqeibadpnrnjkztpk
 * Smoking Wheels....  was here 2017 bmlcdqjqekewpfmanwdudofhiggsibsqidplcwsykuoicoek
 * Smoking Wheels....  was here 2017 jfrhqvfpcgkqvhetydfmrjeaeawcfnqkpcetydnubghdbzdg
 * Smoking Wheels....  was here 2017 ghtfiegovzpkewqggasbabuwtcqvlkihgdzimkqgqprtvyeu
 * Smoking Wheels....  was here 2017 fnkzwsuiacpyjrhbenpwbboaadstarnakmgtvfvshtajssfa
 */
package net.yacy.crawler;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.NaturalOrder;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.crawler.data.CrawlProfile;
import net.yacy.crawler.data.CrawlQueues;
import net.yacy.crawler.data.NoticedURL.StackType;
import net.yacy.crawler.retrieval.Request;
import net.yacy.kelondro.blob.MapHeap;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.index.RowHandleSet;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.kelondroException;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
public final class CrawlSwitchboard {
	
public static final String CRAWL_PROFILE_AUTOCRAWL_DEEP = "autocrawlDeep";
public static final String CRAWL_PROFILE_AUTOCRAWL_SHALLOW = "autocrawlShallow";
public static final String CRAWL_PROFILE_PROXY = "proxy";
public static final String CRAWL_PROFILE_REMOTE = "remote";
public static final String CRAWL_PROFILE_SNIPPET_LOCAL_TEXT = "snippetLocalText";
public static final String CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT = "snippetGlobalText";
public static final String CRAWL_PROFILE_GREEDY_LEARNING_TEXT = "snippetGreedyLearningText";
public static final String CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA = "snippetLocalMedia";
public static final String CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA = "snippetGlobalMedia";
public static final String CRAWL_PROFILE_SURROGATE = "surrogates";
public static Set<String> DEFAULT_PROFILES = new HashSet<String>();
static {
	DEFAULT_PROFILES.add(CRAWL_PROFILE_AUTOCRAWL_DEEP);
DEFAULT_PROFILES.add(CRAWL_PROFILE_AUTOCRAWL_SHALLOW);
DEFAULT_PROFILES.add(CRAWL_PROFILE_PROXY);
DEFAULT_PROFILES.add(CRAWL_PROFILE_REMOTE);
DEFAULT_PROFILES.add(CRAWL_PROFILE_SNIPPET_LOCAL_TEXT);
DEFAULT_PROFILES.add(CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT);
DEFAULT_PROFILES.add(CRAWL_PROFILE_GREEDY_LEARNING_TEXT);
DEFAULT_PROFILES.add(CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA);
DEFAULT_PROFILES.add(CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA);
DEFAULT_PROFILES.add(CRAWL_PROFILE_SURROGATE);
}
public static final String DBFILE_ACTIVE_CRAWL_PROFILES = "crawlProfilesActive1.heap";
public static final String DBFILE_PASSIVE_CRAWL_PROFILES = "crawlProfilesPassive1.heap";
public static final long CRAWL_PROFILE_PROXY_RECRAWL_CYCLE = 60L * 24L;
public static final long CRAWL_PROFILE_SNIPPET_LOCAL_TEXT_RECRAWL_CYCLE = 60L * 24L * 30L;
public static final long CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT_RECRAWL_CYCLE = 60L * 24L * 30L;
public static final long CRAWL_PROFILE_GREEDY_LEARNING_TEXT_RECRAWL_CYCLE = 60L * 24L * 30L;
public static final long CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA_RECRAWL_CYCLE = 60L * 24L * 30L;
public static final long CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA_RECRAWL_CYCLE = 60L * 24L * 30L;
public static final long CRAWL_PROFILE_SURROGATE_RECRAWL_CYCLE = 60L * 24L * 30L;
private final ConcurrentLog log;
private MapHeap profilesActiveCrawls;
private final MapHeap profilesPassiveCrawls;
private final Map<byte[], CrawlProfile> profilesActiveCrawlsCache;
private final Map<String, RowHandleSet> profilesActiveCrawlsCounter;
public CrawlProfile defaultProxyProfile, defaultRemoteProfile, defaultTextSnippetLocalProfile, defaultTextSnippetGlobalProfile;
public CrawlProfile defaultTextGreedyLearningProfile, defaultMediaSnippetLocalProfile, defaultMediaSnippetGlobalProfile, defaultSurrogateProfile;
public CrawlProfile defaultAutocrawlDeepProfile, defaultAutocrawlShallowProfile;
private Map<String, CrawlProfile> defaultPushProfiles;
private final File queuesRoot;
private Switchboard switchboard;
public CrawlSwitchboard(Switchboard switchboard) {
this.switchboard = switchboard;
this.log = this.switchboard.log;
this.queuesRoot = this.switchboard.queuesRoot;
this.defaultPushProfiles = new ConcurrentHashMap<>();
this.profilesActiveCrawlsCache = Collections.synchronizedMap(new TreeMap<byte[], CrawlProfile>(Base64Order.enhancedCoder));
this.profilesActiveCrawlsCounter = new ConcurrentHashMap<String, RowHandleSet>();
this.queuesRoot.mkdirs();
this.log.config("Initializing Crawl Profiles");
final File profilesActiveFile = new File(queuesRoot, DBFILE_ACTIVE_CRAWL_PROFILES);
this.profilesActiveCrawls = loadFromDB(profilesActiveFile);
for ( final byte[] handle : this.profilesActiveCrawls.keySet() ) {
CrawlProfile p;
try {
p = new CrawlProfile(this.profilesActiveCrawls.get(handle));
} catch (final IOException e ) {
p = null;
} catch (final SpaceExceededException e ) {
p = null;
}
if ( p == null ) {
continue;
}
}
initActiveCrawlProfiles();
log.info("Loaded active crawl profiles from file "
+ profilesActiveFile.getName()
+ ", "
+ this.profilesActiveCrawls.size()
+ " entries");
final File profilesPassiveFile = new File(queuesRoot, DBFILE_PASSIVE_CRAWL_PROFILES);
this.profilesPassiveCrawls = loadFromDB(profilesPassiveFile);
for ( final byte[] handle : this.profilesPassiveCrawls.keySet() ) {
CrawlProfile p;
try {
p = new CrawlProfile(this.profilesPassiveCrawls.get(handle));
ConcurrentLog.info("CrawlProfiles", "loaded Profile " + p.handle() + ": " + p.collectionName());
} catch (final IOException e ) {
continue;
} catch (final SpaceExceededException e ) {
continue;
}
}
log.info("Loaded passive crawl profiles from file "
+ profilesPassiveFile.getName()
+ ", "
+ this.profilesPassiveCrawls.size()
+ " entries"
+ ", "
+ profilesPassiveFile.length()
/ 1024);
}
/**
* Get a profile from active or passive stack. Should be used to be sure not to miss old, cleaned profiles.
* A profile that was discovered from the passive stack is automatically shifted back to the active stack.
* @param profileKey
* @return
*/
public CrawlProfile get(final byte[] profileKey) {
CrawlProfile profile = getActive(profileKey);
        if (profile != null) return profile;
profile = getPassive(profileKey);
        if (profile == null) return null;
this.putActive(profileKey, profile);
this.removePassive(profileKey);
return profile;
}
public CrawlProfile getActive(final byte[] profileKey) {
        if ( profileKey == null ) {
return null;
}
CrawlProfile p = this.profilesActiveCrawlsCache.get(profileKey);
        if ( p != null ) {
return p;
}
Map<String, String> m;
try {
m = this.profilesActiveCrawls.get(profileKey);
} catch (final IOException e ) {
m = null;
} catch (final SpaceExceededException e ) {
m = null;
}
        if ( m == null ) {
return null;
}
p = new CrawlProfile(m);
this.profilesActiveCrawlsCache.put(profileKey, p);
return p;
}
public CrawlProfile getPassive(final byte[] profileKey) {
        if ( profileKey == null ) {
return null;
}
Map<String, String> m;
try {
m = this.profilesPassiveCrawls.get(profileKey);
} catch (final IOException e ) {
m = null;
} catch (final SpaceExceededException e ) {
m = null;
}
        if ( m == null ) {
return null;
}
return new CrawlProfile(m);
}
public Set<byte[]> getActive() {
return this.profilesActiveCrawls.keySet();
}
public Set<byte[]> getPassive() {
return this.profilesPassiveCrawls.keySet();
}
public void removeActive(final byte[] profileKey) {
        if ( profileKey == null ) {
return;
}
this.profilesActiveCrawlsCache.remove(profileKey);
this.profilesActiveCrawls.remove(profileKey);
}
public void removePassive(final byte[] profileKey) {
        if ( profileKey == null ) {
return;
}
this.profilesPassiveCrawls.remove(profileKey);
}
public void putActive(final byte[] profileKey, final CrawlProfile profile) {
this.profilesActiveCrawls.put(profileKey, profile);
this.profilesActiveCrawlsCache.put(profileKey, profile);
this.removePassive(profileKey);
}
public void putPassive(final byte[] profileKey, final CrawlProfile profile) {
this.profilesPassiveCrawls.put(profileKey, profile);
this.removeActive(profileKey);
}
public RowHandleSet getURLHashes(final byte[] profileKey) {
return this.profilesActiveCrawlsCounter.get(ASCII.String(profileKey));
}
private void initActiveCrawlProfiles() {
	final Switchboard sb = Switchboard.getSwitchboard();
	
	this.defaultAutocrawlDeepProfile =
	    new CrawlProfile(
	        CRAWL_PROFILE_AUTOCRAWL_DEEP,
	        CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
Integer.parseInt(sb.getConfig(SwitchboardConstants.AUTOCRAWL_DEEP_DEPTH, "3")),
true,
CrawlProfile.getRecrawlDate(Integer.parseInt(sb.getConfig(SwitchboardConstants.AUTOCRAWL_DAYS, "1"))*1440),
-1,
true, true, true, false,
sb.getConfigBool(SwitchboardConstants.AUTOCRAWL_INDEX_TEXT, true),
sb.getConfigBool(SwitchboardConstants.AUTOCRAWL_INDEX_MEDIA, true),
false,
false,
-1,
false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.NOCACHE,
"robot_" + CRAWL_PROFILE_AUTOCRAWL_DEEP,
ClientIdentification.yacyInternetCrawlerAgentName,
null,
0);
	this.profilesActiveCrawls.put(
	    UTF8.getBytes(this.defaultAutocrawlDeepProfile.handle()),
	    this.defaultAutocrawlDeepProfile);
this.defaultAutocrawlShallowProfile =
new CrawlProfile(
CRAWL_PROFILE_AUTOCRAWL_SHALLOW,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
Integer.parseInt(sb.getConfig(SwitchboardConstants.AUTOCRAWL_SHALLOW_DEPTH, "1")),
true,
CrawlProfile.getRecrawlDate(Integer.parseInt(sb.getConfig(SwitchboardConstants.AUTOCRAWL_DAYS, "1"))*1440),
-1,
true, true, true, false,
sb.getConfigBool(SwitchboardConstants.AUTOCRAWL_INDEX_TEXT, true),
sb.getConfigBool(SwitchboardConstants.AUTOCRAWL_INDEX_MEDIA, true),
false,
false,
-1,
false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.NOCACHE,
"robot_" + CRAWL_PROFILE_AUTOCRAWL_SHALLOW,
ClientIdentification.yacyInternetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultAutocrawlShallowProfile.handle()),
this.defaultAutocrawlShallowProfile);
this.defaultProxyProfile =
new CrawlProfile(
CRAWL_PROFILE_PROXY,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
Integer.parseInt(sb.getConfig(SwitchboardConstants.PROXY_PREFETCH_DEPTH, "0")),
true,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_PROXY_RECRAWL_CYCLE),
-1,
				false, true, true, false,
sb.getConfigBool(SwitchboardConstants.PROXY_INDEXING_LOCAL_TEXT, true),
sb.getConfigBool(SwitchboardConstants.PROXY_INDEXING_LOCAL_MEDIA, true),
true,
sb.getConfigBool(SwitchboardConstants.PROXY_INDEXING_REMOTE, false),
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFFRESH,
"robot_" + CRAWL_PROFILE_PROXY,
ClientIdentification.yacyProxyAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultProxyProfile.handle()),
this.defaultProxyProfile);
this.defaultRemoteProfile =
new CrawlProfile(
CRAWL_PROFILE_REMOTE,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
null,
-1,
true, true, true, false,
true,
true,
false,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFFRESH,
"robot_" + CRAWL_PROFILE_REMOTE,
ClientIdentification.yacyInternetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultRemoteProfile.handle()),
this.defaultRemoteProfile);
this.defaultTextSnippetLocalProfile =
new CrawlProfile(
CRAWL_PROFILE_SNIPPET_LOCAL_TEXT,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_SNIPPET_LOCAL_TEXT_RECRAWL_CYCLE),
-1,
true, true, true, false,
false,
false,
true,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFEXIST,
"robot_" + CRAWL_PROFILE_SNIPPET_LOCAL_TEXT,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultTextSnippetLocalProfile.handle()),
this.defaultTextSnippetLocalProfile);
this.defaultTextSnippetGlobalProfile =
new CrawlProfile(
CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT_RECRAWL_CYCLE),
-1,
true, true, true, false,
true,
true,
true,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFEXIST,
"robot_" + CRAWL_PROFILE_SNIPPET_GLOBAL_TEXT,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultTextSnippetGlobalProfile.handle()),
this.defaultTextSnippetGlobalProfile);
this.defaultTextSnippetGlobalProfile.setCacheStrategy(CacheStrategy.IFEXIST);
this.defaultTextGreedyLearningProfile =
new CrawlProfile(
CRAWL_PROFILE_GREEDY_LEARNING_TEXT,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_GREEDY_LEARNING_TEXT_RECRAWL_CYCLE),
-1,
true, true, true, false,
false,
false,
true,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFEXIST,
"robot_" + CRAWL_PROFILE_GREEDY_LEARNING_TEXT,
ClientIdentification.browserAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultTextSnippetGlobalProfile.handle()),
this.defaultTextSnippetGlobalProfile);
this.defaultMediaSnippetLocalProfile =
new CrawlProfile(
CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA_RECRAWL_CYCLE),
-1,
true, true, true, false,
false,
false,
true,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFEXIST,
"robot_" + CRAWL_PROFILE_SNIPPET_LOCAL_MEDIA,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultMediaSnippetLocalProfile.handle()),
this.defaultMediaSnippetLocalProfile);
this.defaultMediaSnippetGlobalProfile =
new CrawlProfile(
CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA_RECRAWL_CYCLE),
-1,
true, true, true, false,
false,
true,
true,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.IFEXIST,
"robot_" + CRAWL_PROFILE_SNIPPET_GLOBAL_MEDIA,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultMediaSnippetGlobalProfile.handle()),
this.defaultMediaSnippetGlobalProfile);
this.defaultSurrogateProfile =
new CrawlProfile(
CRAWL_PROFILE_SURROGATE,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
CrawlProfile.getRecrawlDate(CRAWL_PROFILE_SURROGATE_RECRAWL_CYCLE),
-1,
true, true, false, false,
true,
false,
false,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.NOCACHE,
"robot_" + CRAWL_PROFILE_SURROGATE,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(
UTF8.getBytes(this.defaultSurrogateProfile.handle()),
this.defaultSurrogateProfile);
}
public CrawlProfile getPushCrawlProfile(String collection) {
CrawlProfile genericPushProfile = this.defaultPushProfiles.get(collection);
        if (genericPushProfile != null) return genericPushProfile;
genericPushProfile = new CrawlProfile(
CrawlProfile.CRAWL_PROFILE_PUSH_STUB + collection,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
CrawlProfile.MATCH_ALL_STRING, 
CrawlProfile.MATCH_NEVER_STRING,
0,
false,
null,
-1,
true, true, false, false,
true,
true,
false,
false,
-1, false, true, CrawlProfile.MATCH_NEVER_STRING,
CacheStrategy.NOCACHE,
collection,
ClientIdentification.yacyIntranetCrawlerAgentName,
null,
0);
this.profilesActiveCrawls.put(UTF8.getBytes(genericPushProfile.handle()), genericPushProfile);
this.defaultPushProfiles.put(collection, genericPushProfile);
return genericPushProfile;
}
private void resetProfiles() {
this.profilesActiveCrawlsCache.clear();
final File pdb = new File(this.queuesRoot, DBFILE_ACTIVE_CRAWL_PROFILES);
        if ( pdb.exists() ) {
FileUtils.deletedelete(pdb);
}
try {
this.profilesActiveCrawls =
new MapHeap(pdb, Word.commonHashLength, NaturalOrder.naturalOrder, 1024 * 64, 500, ' ');
} catch (final IOException e1 ) {
ConcurrentLog.logException(e1);
this.profilesActiveCrawls = null;
}
initActiveCrawlProfiles();
}
public boolean clear() throws InterruptedException {
this.profilesActiveCrawlsCache.clear();
CrawlProfile entry;
boolean hasDoneSomething = false;
try {
for ( final byte[] handle : this.profilesActiveCrawls.keySet() ) {
if ( Thread.currentThread().isInterrupted() ) {
throw new InterruptedException("Shutdown in progress");
}
try {
entry = new CrawlProfile(this.profilesActiveCrawls.get(handle));
} catch (final IOException e ) {
continue;
} catch (final SpaceExceededException e ) {
continue;
}
if (!DEFAULT_PROFILES.contains(entry.name())) {
final CrawlProfile p = new CrawlProfile(entry);
this.profilesPassiveCrawls.put(UTF8.getBytes(p.handle()), p);
this.profilesActiveCrawls.remove(handle);
hasDoneSomething = true;
}
}
} catch (final kelondroException e ) {
resetProfiles();
hasDoneSomething = true;
}
return hasDoneSomething;
}
public Set<String> getActiveProfiles() {
Set<String> profileKeys = new HashSet<String>();
for (final byte[] handle: this.getActive()) {
CrawlProfile entry;
entry = new CrawlProfile(this.getActive(handle));
if (!CrawlSwitchboard.DEFAULT_PROFILES.contains(entry.name())) {
profileKeys.add(ASCII.String(handle));
}
}
return profileKeys;
}
public Set<String> getFinishedProfiles(CrawlQueues crawlQueues) {
this.profilesActiveCrawlsCounter.clear();        
Set<String> deletionCandidate = getActiveProfiles();
        if (deletionCandidate.size() == 0) return new HashSet<String>(0);
        long timeout = System.currentTimeMillis() + 60000L; // one minute time
try {
for (StackType stack: StackType.values()) {
Iterator<Request> sei = crawlQueues.noticeURL.iterator(stack);
if (sei == null) continue;
Request r;
while (sei.hasNext()) {
r = sei.next();
if (r == null) continue;
String handle = r.profileHandle();
RowHandleSet us = this.profilesActiveCrawlsCounter.get(handle);
if (us == null) {us =  new RowHandleSet(Word.commonHashLength, Word.commonHashOrder, 0); this.profilesActiveCrawlsCounter.put(handle, us);}
if (us.size() < 100) us.put(r.url().hash());
deletionCandidate.remove(handle);
if (deletionCandidate.size() == 0) return new HashSet<String>(0);
if (System.currentTimeMillis() > timeout) return new HashSet<String>(0);
}
if (deletionCandidate.size() == 0) return new HashSet<String>(0);
}
Map<DigestURL, Request> map = switchboard.crawlQueues.activeWorkerEntries();
for (Request request: map.values()) {
deletionCandidate.remove(request.profileHandle());
}
} catch (final Throwable e) {
ConcurrentLog.logException(e);
return new HashSet<String>(0);
}
return deletionCandidate;
}
public boolean allCrawlsFinished(CrawlQueues crawlQueues) {
        if (!crawlQueues.noticeURL.isEmpty()) return false;
        if (switchboard.crawlQueues.activeWorkerEntries().size() > 0) return false;
return true;
}
public void cleanProfiles(Set<String> deletionCandidate) {
for (String h: deletionCandidate) {
byte[] handle = ASCII.getBytes(h);
final CrawlProfile p = this.getActive(handle);
if (p != null) {
this.putPassive(handle, p);
this.removeActive(handle);
}
}
}
public synchronized void close() {
this.profilesActiveCrawlsCache.clear();
this.profilesActiveCrawls.close();
this.profilesPassiveCrawls.close();
}
/**
* Loads crawl profiles from a DB file.
*
* @param file DB file
* @return crawl profile data
*/
private static MapHeap loadFromDB(final File file) {
MapHeap ret;
try {
ret = new MapHeap(file, Word.commonHashLength, NaturalOrder.naturalOrder, 1024 * 64, 500, ' ');
} catch (final IOException e ) {
ConcurrentLog.logException(e);
FileUtils.deletedelete(file);
try {
ret = new MapHeap(file, Word.commonHashLength, NaturalOrder.naturalOrder, 1024 * 64, 500, ' ');
} catch (final IOException e1 ) {
ConcurrentLog.logException(e1);
ret = null;
}
}
return ret;
}
}
