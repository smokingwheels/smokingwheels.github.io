/** 
 * Smoking Wheels....  was here 2017 wqjsansperpvtqelbxblxircvezqhljzfhxcvvoxtacmewwj
 * Smoking Wheels....  was here 2017 kbrrdginlrcejnzgnkuudatbbfxryigzxkwnidefuvwconpy
 * Smoking Wheels....  was here 2017 hibkvjwqxhlzrmkqzmrffrvvfgweqmctndhpchfevgdipxut
 * Smoking Wheels....  was here 2017 zpvkyqimpsnachghgpgmfihfruazbzuhbdajnlhxlchifkqd
 * Smoking Wheels....  was here 2017 hglpozdayomdidmhfjhsjeskbqtkdfqytjzcdfetojzqqnpp
 * Smoking Wheels....  was here 2017 datzxrwjnotqhhgweuufisxugvswbubedaoltfzlfkcwffkw
 * Smoking Wheels....  was here 2017 vttxqfixfuyyflboqybovrzyipvagnusxlefkmbuwsvasoaz
 * Smoking Wheels....  was here 2017 vrrynhpgeozsmkpbjiqozahvspgwlntqbirlkfazccnhawre
 * Smoking Wheels....  was here 2017 wedyoybhtkaxthwlhnhibzknanjoneedxpbmixrjtpxciuuz
 * Smoking Wheels....  was here 2017 axvyeihfocmtbmbzrnaeqbelcmvprbouwlpxzicoanvebede
 * Smoking Wheels....  was here 2017 lvwgvydjmrzrmnqdbmcrnzsfbtoqibqitgwokkrnfkllydqt
 * Smoking Wheels....  was here 2017 rblnjorjqmlkmiiseudqtshsiwrrfghtmsplykyizadcwamy
 * Smoking Wheels....  was here 2017 lbdnwcgejaawuycrzduermodmppweauijsvzdtukelqqakfi
 * Smoking Wheels....  was here 2017 unrhpwlvjbcgiudiulenvujukazqmyopxlvrughjxytsvemp
 * Smoking Wheels....  was here 2017 xgefdhcukriaflyeawojajtjelttoxjhuidjyvtcpcshalhv
 * Smoking Wheels....  was here 2017 hovwicirseqwytfymukliebsgjaebzdkbandytusvqwomnvf
 * Smoking Wheels....  was here 2017 stfbehkjocetevxscyowakxaepfaxndgylbhimhrmqxzkcpi
 * Smoking Wheels....  was here 2017 eobvzcazqehwwagrffbzrqdqweyuietiyuylytgnrksggygx
 * Smoking Wheels....  was here 2017 ywlnjayyunsreysjgucicnvekkedstujuktjtncfumkirfvy
 * Smoking Wheels....  was here 2017 lvptcsgwdkivolaozbhsjciofvactkdjnbgfebjwlqljqfms
 * Smoking Wheels....  was here 2017 mychfgjqbkgirqchjsjgunfywgxuklarjpmfrvxwnymxhqst
 * Smoking Wheels....  was here 2017 ausgbuukegwjmwetsqjgwjiqgrlswmysteradovwcrjocgfu
 * Smoking Wheels....  was here 2017 hikyfvkoizxjdusmmboimhtjnlpnnkphnhlkoflsojhhseyw
 * Smoking Wheels....  was here 2017 wsoykdhsryfbcelhlinfrhvzzbmfbhykqnmlhbjoovricvdf
 * Smoking Wheels....  was here 2017 kjpburutprzjaeidoeybtpepiimzlmfiivvmxnkuyccdktgj
 * Smoking Wheels....  was here 2017 zzjjpqmvryomwepibmxefrpqjhgfwqvockvcekrbvmnjcvab
 * Smoking Wheels....  was here 2017 tlwflofjvuqxvsrhnkrcyifsggtrtoovsqyddqngqmczvdki
 * Smoking Wheels....  was here 2017 hxjdbdcycodhhrixpjurzlisitbhskjfefzpdmnmxyfeobpl
 * Smoking Wheels....  was here 2017 ivkapillysdpzflbjcaaqipugoqgumkyraywtjneownlmfbx
 * Smoking Wheels....  was here 2017 vwuwilwbycdaupidakkklkuiwtdbckfotfcmtbqxspykzknl
 * Smoking Wheels....  was here 2017 bymbuwedzsrzzmjnboekgkzziqkidaltdhaifodqtppcvuyc
 * Smoking Wheels....  was here 2017 nevdukmhdxtgxsicgyxwbjpoyrpbmmcpvvmklbrlgswqwsoe
 * Smoking Wheels....  was here 2017 ybhyladmwfmthleuoejwgmehkteleckibumczbatdzmohtvc
 * Smoking Wheels....  was here 2017 jfsozxsuskhqaybxhgotifomovtyimumjjhxrhjemshmpulr
 * Smoking Wheels....  was here 2017 yobgapapomukjwnywhvaciwwnhgfkmzumxltotzprlmkkyjy
 * Smoking Wheels....  was here 2017 hhrrjtfoovwtrbgrctporujfrpvgcgyhkdtqypmeixkmrnvd
 * Smoking Wheels....  was here 2017 buapalopbytprqfcygtkhvsupovgicyfizfxjkrhjftfpeht
 * Smoking Wheels....  was here 2017 gtxdjvsuspuehxplqtfxoytwfgzqhqicuocdrvrpvqkhosmo
 * Smoking Wheels....  was here 2017 ecjoxkmniwrxsoxhsjirhvndpzddktysoiydxxvxdtoqihjo
 * Smoking Wheels....  was here 2017 hzrmmyzmcbgmjkvjxoqlnmjmdflrinrapyoajvslxhomufdb
 * Smoking Wheels....  was here 2017 iuitdjnnirrxynjrfawjodyamvilbhsiehxbqceoaibgcdgo
 * Smoking Wheels....  was here 2017 igdjexrurnliiirmwpbsygaenumxsrqdtphwmlhwodaqtxlu
 * Smoking Wheels....  was here 2017 mgcseciraqceujghinncoptohmsuunafcghhzvkhyhopjpst
 * Smoking Wheels....  was here 2017 izoixqoumhofsnvxlethjdkbfjgzxzyofxpimmdztobiypft
 * Smoking Wheels....  was here 2017 puycmnrbkcbjuxihdfnltcpvxgltbjolinhinyhgwaehpmkh
 * Smoking Wheels....  was here 2017 hldaeyiplvxvywatqpwvfyffgfanjhjjzfqxwvzvkxwfvdcc
 * Smoking Wheels....  was here 2017 qublolhtkmvbjzitmmbbqlhwinuyipbcvkewpgnnuufzgqdg
 * Smoking Wheels....  was here 2017 dabzlrsgmjqsmezbkgrxzoesoszapkpqzvrhbinnonrvwjvy
 * Smoking Wheels....  was here 2017 oprkwrwxaapvzmyslqllqmmwopyyccegpidluqueqbvevxos
 * Smoking Wheels....  was here 2017 xcqvdrkxrhamvhkztmjbdtasefjeafimfdxzovmddsruodci
 * Smoking Wheels....  was here 2017 jmzovddofepgdfwjxauhgcwwnvcjursbopkrmxwikbhotdku
 * Smoking Wheels....  was here 2017 myzettdpwyftkcapqqeycllfzajncoiaqlnqvdpvdwdrjgsi
 * Smoking Wheels....  was here 2017 awfmzpuwzfbyhbwsxzjdzcgyfpnuxfipsofeeylbcfuqneko
 * Smoking Wheels....  was here 2017 xykouvrmdrmatkozzaidklekaogqjgghfduvicoqmifdsqhd
 * Smoking Wheels....  was here 2017 lbpttypvfmemxuqxjwjpfhhfofkuxouyzotmjoflquobpvhc
 * Smoking Wheels....  was here 2017 ckbqrrrpjvazgbtguaagmpyhfceegewlynweopcrekfrdcqt
 * Smoking Wheels....  was here 2017 rkizqzgqyiemmiwagbbfnptupazzhnuejyffmqyqzfuklato
 * Smoking Wheels....  was here 2017 bseyxewbptbflxglaymvvtmboalrfdxotzbgylxaemhzalkh
 * Smoking Wheels....  was here 2017 pgqubqliddhoklidovpqgvhsfjlzlyakwbwazzirduthonnz
 * Smoking Wheels....  was here 2017 tfzdxdaztuuguuwtqdynwtmszqeusabsrvmpzmuumwqoyoix
 * Smoking Wheels....  was here 2017 gzttnqyztfsggbtigogmzvqdlqaiysgskfykklcrbvpgjfhn
 * Smoking Wheels....  was here 2017 dfstelulugmtsogeqzpwdlrknirbgqazpklxcojbayobhhdp
 * Smoking Wheels....  was here 2017 pwxlmykttxsekyuthpggdkodgczreqefyupzdwytsspyjxve
 * Smoking Wheels....  was here 2017 ecpkfxxnsnhhsbdwzurmartfblcchvomnbdsvokxtzfbnlon
 * Smoking Wheels....  was here 2017 phhmkhprcolyjafmrhtqeltuodloqomanccksdpybuyxzmvd
 * Smoking Wheels....  was here 2017 veusljdinxnlgdgxqylzbglfqgsmiljildtqphplskveexht
 * Smoking Wheels....  was here 2017 epdlupgwunedpbspiyadouyekcspuiyeanqfoaujbkxuttzl
 * Smoking Wheels....  was here 2017 cuogisdycuiuvqhjnsayrbnofervtiephzofwosuuopyrmck
 * Smoking Wheels....  was here 2017 jdqxcsbltecjpyaefygluhulrizkcuguljmadkgdswpdcpbe
 * Smoking Wheels....  was here 2017 yidpjuqmlmxzvjairnsyjyqgsohtciribysdehlaasuamaqn
 * Smoking Wheels....  was here 2017 cfbntksmauleumvijprchtcqkdmobudzuaukzeqizoionvtm
 * Smoking Wheels....  was here 2017 ibsiajkaoiopvedyaqrqpsoldrsuuhqsrimxxhmfigqzckqg
 * Smoking Wheels....  was here 2017 jgpvgpzbmskeqoxerhnrpbowoyjqdeivzuuzmctbvvhrlitk
 * Smoking Wheels....  was here 2017 fkmcticrkslefzjhomenvgygmyeoibsueobeojomrnhkzlwr
 * Smoking Wheels....  was here 2017 cmlmbcohdjgzrayteizudavfbzyguvnkabtidbgkfzsbjwvb
 * Smoking Wheels....  was here 2017 orsmaomnxytjmokkgikhnjosqqxqemrrmyrmpkkxcxawozzw
 * Smoking Wheels....  was here 2017 iivzrtegzadfirrfuchbjmsvxsjzlmlvwcvalxwldjuhtjso
 * Smoking Wheels....  was here 2017 jfpbiwgqbjutdtzlboplexdyrecrukflpunmmgtpmraajxsx
 * Smoking Wheels....  was here 2017 ydaankobzbjkbjuqnxrbuixsbjxlqcufmihsvljhniuzcqbz
 * Smoking Wheels....  was here 2017 pijkcbddwjsxpkumyozrftialwzfrrbellwttshqwfmkvzvy
 * Smoking Wheels....  was here 2017 zfecdwjububejzzbhdijvjbamktfvlhpvbiyuokajgvsunpk
 * Smoking Wheels....  was here 2017 elgewbwcgfulikpqwotmdsycaavwgcyzahxvtstcdvsqlcaa
 * Smoking Wheels....  was here 2017 kyoxxbkngpndribqdbnpzmzwebcxlkscwqditcstplgckwcx
 * Smoking Wheels....  was here 2017 dvlwaqcqeheyvpcyvadnkqpfibuganozirvkbzwcjxwiqdzh
 * Smoking Wheels....  was here 2017 dpjyitijlvxvmgrmyckitljgbtfcyvsvpkalgwaoggesinfq
 * Smoking Wheels....  was here 2017 jxdebrqwrydaotanufiimjcligcxlwqfgxxzclitludaxwmt
 * Smoking Wheels....  was here 2017 dpuwwvwlrumxgqpptngenexjeuhjwnawzrcxsscogbxebhsr
 * Smoking Wheels....  was here 2017 yxqqmaduqowgatbmrmppwtdyzyzlzwxvvjifjywcjuvjseep
 * Smoking Wheels....  was here 2017 lgcgadtvxvkymgmentfrvljhknoiqikizwqhpnoupdoabchb
 * Smoking Wheels....  was here 2017 thbwtmipbjofpmzxnfdvzrkthormclbwzjirhgfhchbxoxvw
 * Smoking Wheels....  was here 2017 axnsgnspbhznpabgebpndekbtifptdngogwfkcelfwlxvsrz
 * Smoking Wheels....  was here 2017 tiskhyzjyvnovtlxgseqixrafjjphlvmsgcyihbjppdgwwdr
 * Smoking Wheels....  was here 2017 txeuzulvdnjgbscxswofwduufmmsqtdusfzgpisncptkuzpl
 * Smoking Wheels....  was here 2017 zjtypgtdffxvejfowjwqjipusshjzryszjwqawemwcfacyvb
 * Smoking Wheels....  was here 2017 sqkdtusrcxusjgghdljkoffqtjphuaxajcgzqzudfrsclvto
 * Smoking Wheels....  was here 2017 julzeejbwxxpcfzyhmnkouyetzqlrzcrubwiuwfrvcovuzqf
 * Smoking Wheels....  was here 2017 ujjiykdfytlmakimieerqgkphiuzqvqznfuazzfkokmpgawm
 * Smoking Wheels....  was here 2017 xyyekrpfwfvnbemenkiojckhhmsjvfamasiqcbxbmyjeiugd
 * Smoking Wheels....  was here 2017 zlgydlompkqekbyoijgpoccvvtghsyzwcyxzdcrlafjmrkrf
 * Smoking Wheels....  was here 2017 ncocwmcrenuenzkinmmqhdseipqsyfletpkdkjasuzwtgfkz
 * Smoking Wheels....  was here 2017 ghiorupqaemkbbwpclvuvoykjwfwlhrsdpvlmgwhrjnjewwy
 * Smoking Wheels....  was here 2017 frkjynqntdcdypnngcghttpzuqrdlvcxvcklfogutpgcydvv
 * Smoking Wheels....  was here 2017 pevudfatgmgtkfvsoqbvwntludwgirlpoorzpgnbkffvgffr
 * Smoking Wheels....  was here 2017 yzundpxxplxzvunwsnudguttsyafuxrtiomcznhihbtuzkft
 * Smoking Wheels....  was here 2017 ymxgyqoxepeuyknztkfhfufadvmduxzqjdtexxjwfdplihjo
 * Smoking Wheels....  was here 2017 rjxewppwqtmjqlckwejrhbxpawxmnhwueiwtecwkjtqmtuhw
 * Smoking Wheels....  was here 2017 hovnnwwfvxmddmsoozmvhgzfjigaixbynrhrvcducmyvyzbs
 * Smoking Wheels....  was here 2017 jeyyshmowkavvjagqieogkurrtppavmcituzgdtezaatufuh
 * Smoking Wheels....  was here 2017 psufltttdtijlgalbudzoswdlyjnllioynlayrnxynmpmcad
 * Smoking Wheels....  was here 2017 atekaogzgttywlzmajkjrrczqzgeujdvuemjrmprcgfdmmlb
 * Smoking Wheels....  was here 2017 vhbwbewqcmybiohvceijmbowibcgnkpqqblvpmgivrkhllaa
 * Smoking Wheels....  was here 2017 oltejgqiuewkgmrfaqjsatoqxvcsisqamxdnzydasrkhjkyh
 * Smoking Wheels....  was here 2017 zrucywyyrkpwhhdstkhopbtnzapucqmfpoosiibeqhxoiyrk
 * Smoking Wheels....  was here 2017 apyudgjqkypskiwooleeslxulrixbtqukhzankcistuuwxzc
 * Smoking Wheels....  was here 2017 yefnmusuvwmitgigxxhehqedkcetqytltlygpcqmjqgzpkuj
 * Smoking Wheels....  was here 2017 hoyxvidablemvwgppfdjhqwmfwghmiwfosgmwrfrdtqgmuin
 * Smoking Wheels....  was here 2017 ueptftxfmgvbghpnpznvbqoxnszspfdjbawaxpsjzdqcrrbb
 * Smoking Wheels....  was here 2017 krycyiqotbvizxojdekwdccveszlbgblvndllqedybdfrxss
 * Smoking Wheels....  was here 2017 kzcioofjswvrehpqtzdbjvpvieggkhjdopnpqszylchocofn
 * Smoking Wheels....  was here 2017 iggywerilbtuihmbduggutkxiqvagkymgzwotcswcamixbut
 * Smoking Wheels....  was here 2017 vxzwzcjijcssbadqjgmmscbbuvezpzcudpdqigfhtwkygzxx
 * Smoking Wheels....  was here 2017 zrabeqwmcveoiwtrphvcsjlupxypopgntorkexowoyydqdht
 * Smoking Wheels....  was here 2017 zjkyzfbengsuikvrjdrsohprwbanpdclvhyskbcmwtfwrsyg
 * Smoking Wheels....  was here 2017 igmagoabsrhdmmcjkdlbivyqzwpskrqojmtphylhheshizzt
 * Smoking Wheels....  was here 2017 vrreasbabrbolfnvtyyhjgztodakwpceobdkjajqsezwupzr
 * Smoking Wheels....  was here 2017 kjvlpwuefajefzggpofsdaqmlxyagnwtzdjrmaafgbzimlow
 * Smoking Wheels....  was here 2017 jeyeombyasxnyiudmcowovxkumigygtcifyhsxswhkwpcoth
 * Smoking Wheels....  was here 2017 diixrhxxpdpgafxidzlqqsflzjgcqyrepxrhhzbtlzawoitf
 */
package SevenZip.Compression.LZ;
import java.io.IOException;
public class InWindow
{
	public byte[] _bufferBase;
	java.io.InputStream _stream;
	int _posLimit;  // offset (from _buffer) of first byte when new block reading must be done
	boolean _streamEndWasReached;
	
	int _pointerToLastSafePosition;
	
	public int _bufferOffset;
	
	public int _blockSize;  // Size of Allocated memory block
	public int _pos;           
	int _keepSizeBefore;  // how many BYTEs must be kept in buffer before _pos
	int _keepSizeAfter; 
	public int _streamPos; 
	
	public void MoveBlock()
	{
		int offset = _bufferOffset + _pos - _keepSizeBefore;
		// we need one additional byte, since MovePos moves on 1 byte.
		if (offset > 0)
			offset--;
		int numBytes = _bufferOffset + _streamPos - offset;
		
		// check negative offset ????
		for (int i = 0; i < numBytes; i++)
			_bufferBase[i] = _bufferBase[offset + i];
		_bufferOffset -= offset;
	}
	
	public void ReadBlock() throws IOException
	{
		if (_streamEndWasReached)
			return;
		while (true)
		{
			int size = (0 - _bufferOffset) + _blockSize - _streamPos;
			if (size == 0)
				return;
			int numReadBytes = _stream.read(_bufferBase, _bufferOffset + _streamPos, size);
			if (numReadBytes == -1)
			{
				_posLimit = _streamPos;
				int pointerToPostion = _bufferOffset + _posLimit;
				if (pointerToPostion > _pointerToLastSafePosition)
					_posLimit = _pointerToLastSafePosition - _bufferOffset;
				
				_streamEndWasReached = true;
				return;
			}
			_streamPos += numReadBytes;
			if (_streamPos >= _pos + _keepSizeAfter)
				_posLimit = _streamPos - _keepSizeAfter;
		}
	}
	
	void Free() { _bufferBase = null; }
	
	public void Create(int keepSizeBefore, int keepSizeAfter, int keepSizeReserv)
	{
		_keepSizeBefore = keepSizeBefore;
		_keepSizeAfter = keepSizeAfter;
		int blockSize = keepSizeBefore + keepSizeAfter + keepSizeReserv;
		if (_bufferBase == null || _blockSize != blockSize)
		{
			Free();
			_blockSize = blockSize;
			_bufferBase = new byte[_blockSize];
		}
		_pointerToLastSafePosition = _blockSize - keepSizeAfter;
	}
	
	public void SetStream(java.io.InputStream stream) { _stream = stream; 	}
	public void ReleaseStream() { _stream = null; }
	public void Init() throws IOException
	{
		_bufferOffset = 0;
		_pos = 0;
		_streamPos = 0;
		_streamEndWasReached = false;
		ReadBlock();
	}
	
	public void MovePos() throws IOException
	{
		_pos++;
		if (_pos > _posLimit)
		{
			int pointerToPostion = _bufferOffset + _pos;
			if (pointerToPostion > _pointerToLastSafePosition)
				MoveBlock();
			ReadBlock();
		}
	}
	
	public byte GetIndexByte(int index)	{ return _bufferBase[_bufferOffset + _pos + index]; }
	
	public int GetMatchLen(int index, int distance, int limit)
	{
		if (_streamEndWasReached)
			if ((_pos + index) + limit > _streamPos)
				limit = _streamPos - (_pos + index);
		distance++;
		// Byte *pby = _buffer + (size_t)_pos + index;
		int pby = _bufferOffset + _pos + index;
		
		int i;
		for (i = 0; i < limit && _bufferBase[pby + i] == _bufferBase[pby + i - distance]; i++);
		return i;
	}
	
	public int GetNumAvailableBytes()	{ return _streamPos - _pos; }
	
	public void ReduceOffsets(int subValue)
	{
		_bufferOffset += subValue;
		_posLimit -= subValue;
		_pos -= subValue;
		_streamPos -= subValue;
	}
}
