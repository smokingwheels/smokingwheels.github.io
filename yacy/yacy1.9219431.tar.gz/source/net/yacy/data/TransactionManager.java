/** 
 * Smoking Wheels....  was here 2017 wxmsmcfkvcpirqxpukuuqounufcfdlocsechmsemripnzbpo
 * Smoking Wheels....  was here 2017 ipeqvltgixggwhuvwcuhwlkryrlpzbjaifoqwbwhbwnthsaq
 * Smoking Wheels....  was here 2017 czvvkdqorefrytgdyxotdlvwuqdunxhfxayyhobxegajneij
 * Smoking Wheels....  was here 2017 pgjqlmfgyhdbsldorgjwwboepszoyomwhjrclwmrpidkxjyg
 * Smoking Wheels....  was here 2017 kvaslxxnitudgyqkywplubicxtbwnxhqscleibeicefadjmd
 * Smoking Wheels....  was here 2017 mkewcgntllfxxebfxryoxkfgmuqxwcignmfmdjitrbtuaoua
 * Smoking Wheels....  was here 2017 zzngjlapbksohhbtzxipjkjpiehfuomtjzdsiildqpqjrqae
 * Smoking Wheels....  was here 2017 gszemvqbdyxpgrmcvzzesoigumumlwwmfgqrprgwnpwtjlnf
 * Smoking Wheels....  was here 2017 abuhwxwfzrntwxmniphcprvrinhsdywxdglmzlvqbdtftewx
 * Smoking Wheels....  was here 2017 dsikhjnnelralykoqsynarxotjzdlybxoekmqxiihpxeqdag
 * Smoking Wheels....  was here 2017 trhqrinqkgrppwwbeoxvewtscingfejlemviboienlbkdzbo
 * Smoking Wheels....  was here 2017 hbqjgydmulaaectzoninntxlqartnjxwvxauydmogpjxoqjk
 * Smoking Wheels....  was here 2017 kjnenvwfnqpyhhersiqoudbbwgnptizrsitbgrwchbavnfno
 * Smoking Wheels....  was here 2017 zhkydqlhfqkkfgnruyozzzggobiclghsfzxkflsvpfrswdlb
 * Smoking Wheels....  was here 2017 fuytcmxionuppfkteozegotavvrqmnrzzisnhymunpchrzgf
 * Smoking Wheels....  was here 2017 laczpomhqoiagnszopdtbjzkvckaxtguyboeeyymobingrgp
 * Smoking Wheels....  was here 2017 jmaedkqisktlhunpvvkoeftxfsnfcukrfceowlconqsqgiex
 * Smoking Wheels....  was here 2017 vwdhkudvivetaxggccnrncafqsilqwtlfrlzoseyjrvdmjug
 * Smoking Wheels....  was here 2017 bceiirzmfyxgabmqvsjmifbefllejhedqfpasgrtluksajgy
 * Smoking Wheels....  was here 2017 lkbsfkkglamlepcvqaeobeizflrdjttahlbpbvilfspjfhzm
 * Smoking Wheels....  was here 2017 peyalkxghsszpefckvjvlrqbdqaizcxrkhluomesnqqjrfnr
 * Smoking Wheels....  was here 2017 lfhdungwhtrwnrgbizphltxctzuzumfwjzuyllllitcdfnvo
 * Smoking Wheels....  was here 2017 djudfskwehrjqftkvsukfqlycwqoqhpquyfrdgquztvlxxxl
 * Smoking Wheels....  was here 2017 bwijwfrczpgyteqgmnfshxswlwgvqechqwevjqleykvgefgw
 * Smoking Wheels....  was here 2017 wfdlgpmsahgiyfaxgbfcjgmfjttsczejasimcpyhatmunpkp
 * Smoking Wheels....  was here 2017 naqgdqpfudrmoghvghmrkssrprmmpwkrirrbplibgehoukgs
 * Smoking Wheels....  was here 2017 cimwkgaechxrfjawxkatqordexxpagrggfidgrcqxgbgdiym
 * Smoking Wheels....  was here 2017 agrrhuaoyalisydbwvyznhwvjbxulscjsasnvaakmuwwwfvm
 * Smoking Wheels....  was here 2017 zhhghtboqxcgdrssbisesrbcsxnbffaoubpkgnccvvaqognl
 * Smoking Wheels....  was here 2017 vdwlcvxnrtzjwkdjpuamgserzncqwucrynvculnpwscbatxm
 * Smoking Wheels....  was here 2017 tsbjrdnevrixlhbtwkugisnmehczixfsuvqevgwbzbwvlkcv
 * Smoking Wheels....  was here 2017 cgtjgwfldatjtrizpsebkcopqtkvpelygsloeuvxqqkzbclb
 * Smoking Wheels....  was here 2017 peechnklwhamwgaipiqufsbnwtbebmezmcxhtzkwpnarnxqz
 * Smoking Wheels....  was here 2017 dfujmyxqpjgfdxojcfxnsoaxphjgizbpxfattdvtycglqhlp
 * Smoking Wheels....  was here 2017 uhfhubrqbgsudspulpvqbvrrxuxmfaxucmyoruqvywzanwcf
 * Smoking Wheels....  was here 2017 bqkgmezlgjytsdxtixqsvcnzbtmruhxwbqbpfqolcseinnxk
 * Smoking Wheels....  was here 2017 oqouzthenfutytsnqvtqqdhfpbculqjkwpcwitpherfqejmx
 * Smoking Wheels....  was here 2017 dbcvaqjgjrhvemhpniwnmxacgtdasezeyoavgjzigbpljvsv
 * Smoking Wheels....  was here 2017 bvslntfiottdaliukqxrpsxncdcwmjofzzyblzfqomemfmsk
 * Smoking Wheels....  was here 2017 qdiatlcicvtghasdxdbtkamrkvwcvuguvojkqkasqtzrzhwf
 * Smoking Wheels....  was here 2017 nkdceellilcwbwmzxptorrnxrpkqbiknrgxytolfgyiihiva
 * Smoking Wheels....  was here 2017 rkpplrbcslvxswbuqxsgjpxzrpctueqewgobavrzmjuvzajx
 * Smoking Wheels....  was here 2017 faiopaxybxhrveckliudqbatmblxxqwsdaljyphhoqeaeasd
 * Smoking Wheels....  was here 2017 nnilvmhwkdzqfdkwzffvzqgkjqhukleoigbtftynannuedeg
 * Smoking Wheels....  was here 2017 hgstomqczstnzkdmejlgdbkjvdsmrkydqwbftfrhqdekopkb
 * Smoking Wheels....  was here 2017 kazjowszjlqgnwrterdkbhmiqpzdirvikcjfwgtokuqjfsgp
 * Smoking Wheels....  was here 2017 bsukupngilzdirpmijftyrrdvjrgeqqdjkehxkqnrbtifevd
 * Smoking Wheels....  was here 2017 onbgkziuxaiqheusjwwuhrnasaophznvilyjrlcoyupjwvng
 * Smoking Wheels....  was here 2017 qyamympuitlmmbktexnlubujujucbnvznehmdjcizalruvzt
 * Smoking Wheels....  was here 2017 eqbxcxbqdllpheuewkxvjvkvvmozalfkivfzllxuvbwsvpaq
 * Smoking Wheels....  was here 2017 howsuguadeqhgrpswoxgigrkwtntbcocjvxocdacsorgbsvf
 * Smoking Wheels....  was here 2017 lxjfhtyvihoagyqkvvsibwcefqkegdykoxszvheqggxfvcsa
 * Smoking Wheels....  was here 2017 geuaaybhaizmiqbpqyuyikjpibieymtvcyklpvkcdhxxswhw
 * Smoking Wheels....  was here 2017 qznatoxusdasvpgvmuuebxnibbparfqeiewepcwkkyfsplmu
 * Smoking Wheels....  was here 2017 sjhgkrkzfuzxjzvvtqrkmpuhkztdjtkmxcixhoeskuqlmkkb
 * Smoking Wheels....  was here 2017 ylzcemxumqknueqsbwofbarrpipiasgauielkzzlpsfbuskg
 * Smoking Wheels....  was here 2017 ysuepnvkwecievvtjfzlnxxvfaenbamkcxcwxjihusiuckcd
 * Smoking Wheels....  was here 2017 pwejipxfwidhwvtluqnguhnnbbvyauuieybnzaldzdlcezku
 * Smoking Wheels....  was here 2017 cvusiqfxhcurlhbrsifzdkspcucdtjyyuxgcekwemplsfajm
 * Smoking Wheels....  was here 2017 uwpqwzyjcvqxtqojwsdeavafqvvujleltobjchguuwirmjls
 * Smoking Wheels....  was here 2017 kiurjbpvpcnswllxbnvtcgeweyawexulguemusrrrbldqgej
 * Smoking Wheels....  was here 2017 uzttosxqjsmderbvmrwvksedofapuwkrruoulxjtfmiplzmk
 * Smoking Wheels....  was here 2017 cueykxxnduujfkaxokhrcmgatzjnbsygrbjwnkufrruuagme
 * Smoking Wheels....  was here 2017 uxaocyvixqawvaedydfzrbxpbvwhabmkegbpsytkonxtsxne
 * Smoking Wheels....  was here 2017 ktmhdhdiauakdfsxmobpwfxjzoqybwjsijicapeaqbzqccff
 * Smoking Wheels....  was here 2017 zdzxfsqvycvzlvxrkqoopyfzigxrtfhynnbrrojayqoybfmj
 * Smoking Wheels....  was here 2017 oxephggomqstkzmhapqhcncicggzymcejgmzciuouumlqwkx
 * Smoking Wheels....  was here 2017 phzrpdhlrthgudgubvmkvmbopdnpsiwqwfawateaqkubezkj
 * Smoking Wheels....  was here 2017 turspyfquaieswikkcmrnnvejrsnlraycjikjtocimtchsan
 * Smoking Wheels....  was here 2017 wapqziuoifyonbctfijhdsktdzfyroewlxjzlrerwkzyujel
 * Smoking Wheels....  was here 2017 ezmmtkavcljouwepwrbpwibgyknjgmelqhifqynznsgkurzl
 * Smoking Wheels....  was here 2017 avgqdjcldaesjrlzaqsdevgwbllngadynfqxrkikvfqkqlva
 * Smoking Wheels....  was here 2017 ccctntonsngtidbfoxvvvzszbacjbamygpyfozqpoblfxvhz
 * Smoking Wheels....  was here 2017 hkkpsieniuoqbdivslattvngrcsdgsufgrglmapmsmghkghj
 * Smoking Wheels....  was here 2017 ssxipbxbtwloctwpukggepvpycxiqlyvewrgxzugqdvkhiyn
 * Smoking Wheels....  was here 2017 vhohlhzcbcmcilqpmgsznvefeomsivbbxxrmnryhvugmvyox
 * Smoking Wheels....  was here 2017 gmmcrmytnblwuvqcssvsohinvimertmkptxfiabhaovurgvj
 * Smoking Wheels....  was here 2017 xbdpbknmpolywuiqpsgqgygetkeahjxtrojvojjdhsduqppx
 * Smoking Wheels....  was here 2017 yyfxnbszessncliaomzctcebyefsycdbuufxqfjbxwzfvqzw
 * Smoking Wheels....  was here 2017 tiqihssceuxbkelhgleqphrkqfiytnirudwihhulkvkbohju
 * Smoking Wheels....  was here 2017 zrpovxcbyksiurwsphfelekpliptbovcxpzemqrynrrolrjk
 * Smoking Wheels....  was here 2017 osnjvjogaiihquyxrzwuhxkhcpjimigemiovkmfmitldhdvv
 * Smoking Wheels....  was here 2017 picxhcdicsydoqgpzsavjpxlpjdevfnxettxojyfcqlpejxh
 * Smoking Wheels....  was here 2017 ntgokkbghvekiqsvcywxcxkehetafwspxqyfrappicuwnfzj
 * Smoking Wheels....  was here 2017 zlewrtueugvvcklxyjvxgmryqvgvyeeuvxxwrndhugtfwwqw
 * Smoking Wheels....  was here 2017 xcirtycmfvyifvvksxowsjrklmyvqgphjsngubxeokwdaqtv
 * Smoking Wheels....  was here 2017 krieryzxhqwfeclctvcftwrltjlndnvccozzmehlxezhdflm
 * Smoking Wheels....  was here 2017 xieqobshbzcxxnezsnnnwlegudmqmpyoadtwmqcnhiesmmdm
 * Smoking Wheels....  was here 2017 boatzuswukndmuekorhqrwxhdoddcjjffjlatlhcpzspsokn
 * Smoking Wheels....  was here 2017 tahhpwvaaudxgttxjhdrfeweottgmzrvcmbvmwdatkemqwcr
 * Smoking Wheels....  was here 2017 drrjjizknfgltopgpoyzspivcawmovuljxswdlencgjajzjg
 * Smoking Wheels....  was here 2017 qudknllzhylgwqomxxxfortlzxhoimviwjxalwbzdhigfvpu
 * Smoking Wheels....  was here 2017 xsvynssxrpnarotydameodwkthblfxcctuikkfvcqpkktokb
 * Smoking Wheels....  was here 2017 veexcxnodznsogndmwhypaskfenkufhnmkvherttqndyxnqd
 * Smoking Wheels....  was here 2017 oewieawqmfuqavnviriyxonjjzevvufpqprkgwhdlqhprkkh
 * Smoking Wheels....  was here 2017 mvwoziabtnwfyrqcjvutaiuknfxomhbqedhmilgrnsaikadc
 * Smoking Wheels....  was here 2017 hrihajlzeppelmyglcafoahaessncodffxhskmnasxnktojh
 * Smoking Wheels....  was here 2017 wjshzvxwieynvbvvtkvlnryvcnyygtcdeerlrglczmlhnkby
 * Smoking Wheels....  was here 2017 jvrsvukhzjimspyprxauenctjaditgvjsjqgpfmcraosuehj
 * Smoking Wheels....  was here 2017 fhextmegdmfoxlcpwcwwxddzfucjsskgsdozwdjkgjyqxulc
 * Smoking Wheels....  was here 2017 afilgksxccmknhmdgrunmgxxepxbmagijmdumcdrnpwiljdy
 * Smoking Wheels....  was here 2017 rhrfajurjbdcxyltyplxvwjfaovrqhykapizrhzwnaxgggfw
 * Smoking Wheels....  was here 2017 jlvibijetknupqpgjathfgsvvymqbxjmjxhewgldnfxdldvg
 * Smoking Wheels....  was here 2017 nwscoprjgneanrurelyiaxnwukqstnqxhdmgvsfwbawyjxiq
 * Smoking Wheels....  was here 2017 tboeyqgkdxymrtehhnlxbpmvnsiwdbdeygohltjuwmdyoqjt
 * Smoking Wheels....  was here 2017 ysukzgwszkvdlrcrvgxbfjqhsyyjtpmcsjmrzoctbygpxuur
 * Smoking Wheels....  was here 2017 itbxqklzndehlrfpeuhftlfgmmyplnoshblyxrxzuybplzss
 * Smoking Wheels....  was here 2017 fiizdlgcujnjlckcbptxdirvavfkjnmioxvbxxnwsjozpbnj
 * Smoking Wheels....  was here 2017 hzuhwuvgctsbqpsnhktaavumyvurtkpmryjazeacngczwfvm
 * Smoking Wheels....  was here 2017 mkvqqgxvxaulgapicczslxpvyozshkozahygivoogxgbdunb
 * Smoking Wheels....  was here 2017 xmeeivlnbhasynqjwxigpwgvciiytvfvgmuikiqkfztxnlsk
 * Smoking Wheels....  was here 2017 zltgfusfowahomrqfiahyeiqqtqdgjriieicxlbdxetohctc
 * Smoking Wheels....  was here 2017 ktsltqedrjozdpxnbzmseqoreqzgdwjbiigsweuidrnfcuhw
 * Smoking Wheels....  was here 2017 zcoqqdqryostbrqlowkohgxokasmanvtrclmlvcyxtpjuafu
 * Smoking Wheels....  was here 2017 ykxywhbmdovuxwmhderfmhrhkhhkrqanbadacwkenavtjipe
 * Smoking Wheels....  was here 2017 qxsrpjsmgsjqnpkbkjnhffhzkzqrgxapistfpcoklgfjhrvo
 * Smoking Wheels....  was here 2017 ubdmjwbwqngzzmkbickqfvoczxshbeepqdzdvmmhnndjbenr
 * Smoking Wheels....  was here 2017 fnrevpwauwlupkyvzjxjlekgxewmrqdflotdciltufcineor
 * Smoking Wheels....  was here 2017 dhyxzncqluiibmqduibvdldkecrszpuojifvudyalwyxvjbt
 * Smoking Wheels....  was here 2017 xnyaaybqrqkccehblmaqsegrbgytaufyhgwcqqtlcgrdgpkm
 * Smoking Wheels....  was here 2017 fruclifetymtwabxumfpydmodlroebuvkeiarwvrlorfkbfr
 * Smoking Wheels....  was here 2017 ymyaxlhqfprirzjdahhxsjuqdtgkaneccjoyabkspamqdbjj
 * Smoking Wheels....  was here 2017 gwcwlihtuqgbddtqocgvicmxdnerkoftzgumeuarufwdohyv
 * Smoking Wheels....  was here 2017 nafzfgmkokukbxclzkfbfvaljhhejwabanjnwtkznaxrzqiq
 * Smoking Wheels....  was here 2017 ljkbtrjuulbcoypugvrjbidtjyrwigzpidacbaohqmynzeep
 * Smoking Wheels....  was here 2017 xrdvrkrhypedzdofnkhxvqvmxmozvxsdihsqzusodxmckkir
 * Smoking Wheels....  was here 2017 bwdnaljpxxjsxoppdgzauzknbhozrfbtrlosbqjxgwjejwxg
 * Smoking Wheels....  was here 2017 hcgkzbtpquhjdqqxvwxikwhbbxnqbufsfhaeaghuogqsfmhu
 * Smoking Wheels....  was here 2017 gxtczsimksstvatllyoqidgmldkxfomoeuvevslvvbqzmjce
 * Smoking Wheels....  was here 2017 wxamvgtruoqxhphuelpdorhnzcpaupmcydwzsgcacqwkbyfj
 * Smoking Wheels....  was here 2017 gbtqkpdvnjmbcmyrjozchwqardplpidjdtihdktlpoftzvtr
 * Smoking Wheels....  was here 2017 wpwyzcqxrmsrdcoftrvebdvfwthxuknrrjqxuwdpyrqarxbr
 * Smoking Wheels....  was here 2017 izpzzeuamnemkagrdpqfmgombvqlpransxmyrsgcubnjrhud
 * Smoking Wheels....  was here 2017 nwhpdriplfxljejotfbhphwmakbfshgtqputzfiwhzkjulud
 * Smoking Wheels....  was here 2017 qfszkogilsgvmsoszsavpmzeuvatxqcjdwuyfvxcqbcrexfx
 * Smoking Wheels....  was here 2017 bfujacvckitcszrelosjyhjsprjtijrrckwkajrejcqhdrkb
 * Smoking Wheels....  was here 2017 ljqllvncqpezbqwebmpuinvmatefgjjfqetejuruhfjmhtzi
 * Smoking Wheels....  was here 2017 sitbjmctsjrmxomiakiftfjevdsjittufkhrokdwkrvrlqvt
 * Smoking Wheels....  was here 2017 ybugtcotismuvxdkrmwykodsbdoriytllntlzsooabvqrybs
 * Smoking Wheels....  was here 2017 qtsmwwcypzekrbslrgjqudshyjnxknlmgfokjlrhqgkijmaq
 * Smoking Wheels....  was here 2017 jvrgckhnssocnqjtzjgdorvgbqraxkgktliqrqnsagxzcmkk
 * Smoking Wheels....  was here 2017 cbcmgkvyhtrtsokvrtgotemiezhfjttakjcmdphtglwcsiaa
 * Smoking Wheels....  was here 2017 yishfxswadwswxmnfrggnxxkhuzaqxvkvnyoftmpojdkgozt
 */
package net.yacy.data;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import org.apache.commons.codec.digest.HmacUtils;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.http.servlets.DisallowedMethodException;
import net.yacy.http.servlets.TemplateMissingParameterException;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
/**
* This class provides transaction tokens generation and checking for protected operations.
* These tokens should be designed to be hard to forge by an unauthenticated user.
*/
public class TransactionManager {
	
	/** Parameter name of the transaction token */
	public static final String TRANSACTION_TOKEN_PARAM = "transactionToken";
	/** Secret signing key valid until next server restart */
private static final String SIGNING_KEY = UUID.randomUUID().toString();
/** Random token seed valid until next server restart */
private static final String TOKEN_SEED = UUID.randomUUID().toString();
	/**
	 * @param header
	 *            current request header. Must not be null.
	 * @return the name of the currently authenticated user (administrator user
	 *         name when the request comes from local host and unauthenticated local
	 *         access as administrator is enabled), or null when no authenticated.
	 * @throws NullPointerException
	 *             when header parameter is null.
	 */
private static String getCurrentUserName(final RequestHeader header) {
String userName = header.getRemoteUser();
		if (userName == null && header.accessFromLocalhost() && Switchboard.getSwitchboard() != null) {
	 	final String adminAccountUserName = Switchboard.getSwitchboard().getConfig(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, "admin");
	 	final String adminAccountBase64MD5 = Switchboard.getSwitchboard().getConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "");
	 	
			if(Switchboard.getSwitchboard()
				.getConfigBool(SwitchboardConstants.ADMIN_ACCOUNT_FOR_LOCALHOST, false)) {
				/* Unauthenticated local access as administrator can be enabled */
				userName = adminAccountUserName;
			} else {
		        /* authorization by encoded password, only for localhost access (used by bash scripts)*/
		        String pass = Base64Order.standardCoder.encodeString(adminAccountUserName + ":" + adminAccountBase64MD5);
		        
		        /* get the authorization string from the header */
		        final String realmProp = (header.get(RequestHeader.AUTHORIZATION, "")).trim();
		        final String realmValue = realmProp.isEmpty() ? null : realmProp.substring(6);
		        
		        if (pass.equals(realmValue)) {
		            userName = adminAccountUserName;
		        }
			}
		}
		
		return userName;
}
	/**
	 * Get a transaction token to be used later on a protected HTTP post method
	 * call on the same path with the currently authenticated user.
	 * 
	 * @param header
	 *            current request header
	 * @return a transaction token
	 * @throws IllegalArgumentException
	 *             when header parameter is null or when the user is not authenticated.
	 */
public static String getTransactionToken(final RequestHeader header) {
        if (header == null) {
	throw new IllegalArgumentException("Missing required header parameter");
}
return getTransactionToken(header, header.getPathInfo());
}
	/**
	 * Get a transaction token to be used later on a protected HTTP post method
	 * call on the specified path with the currently authenticated user.
	 * 
	 * @param header
	 *            current request header
	 * @param path the relative path for which the token will be valid
	 * @return a transaction token for the specified path
	 * @throws IllegalArgumentException
	 *             when a parameter is null or when the user is not authenticated.
	 */
public static String getTransactionToken(final RequestHeader header, final String path) {
        if (header == null) {
	throw new IllegalArgumentException("Missing required header parameter");
}
/* Check this comes from an authenticated user */
final String userName = getCurrentUserName(header);
		if (userName == null) {
			throw new IllegalArgumentException("User is not authenticated");
		}
		/* Produce a token by signing a message with the server secret key : 
		 * The token is not unique per request and thus keeps the service stateless 
		 * (no need to store tokens until they are consumed).
		 * On the other hand, it is supposed to remain hard enough to forge because the secret key and token seed 
		 * are initialized with a random value at each server startup */
		final String token = HmacUtils.hmacSha1Hex(SIGNING_KEY, TOKEN_SEED + userName + path);
		
return token;
}
/**
* Check the current request is a valid HTTP POST transaction : the current user is authenticated, 
* and the request post parameters contain a valid transaction token.
* @param header current request header
* @param post request parameters
* @throws IllegalArgumentException when a parameter is null.
* @throws DisallowedMethodException when the HTTP method is something else than post
* @throws TemplateMissingParameterException when the transaction token is missing
* @throws BadTransactionException when a condition for valid transaction is not met.
*/
	public static void checkPostTransaction(final RequestHeader header, final serverObjects post) {
        if (header == null || post == null) {
	throw new IllegalArgumentException("Missing required parameters.");
}
		if(!HeaderFramework.METHOD_POST.equals(header.getMethod())) {
			throw new DisallowedMethodException("HTTP POST method is the only one authorized.");
		}
		
String userName = getCurrentUserName(header);
		if (userName == null) {
			throw new BadTransactionException("User is not authenticated.");
		}
		
		final String transactionToken = post.get(TRANSACTION_TOKEN_PARAM);
		if(transactionToken == null) {
			throw new TemplateMissingParameterException("Missing transaction token.");
		}
		
		final String token = HmacUtils.hmacSha1Hex(SIGNING_KEY, TOKEN_SEED + userName + header.getPathInfo());
		
		/* Compare the server generated token with the one received in the post parameters, 
		 * using a time constant function */
		if(!MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), transactionToken.getBytes(StandardCharsets.UTF_8))) {
			throw new BadTransactionException("Invalid transaction token.");
		}
	}
}
