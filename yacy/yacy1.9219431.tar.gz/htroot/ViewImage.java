/** 
 * Smoking Wheels....  was here 2017 tkqtujkwsspuyfcptrubxshbkxverasuxonatmckynkhtbra
 * Smoking Wheels....  was here 2017 nodhplblphdkmitbhvzmpthgpzodyngajaydbpcktzzbpqwv
 * Smoking Wheels....  was here 2017 nunopqxhvguymetbbtvsvdcwtguhpbjchdcjlnuejstmawcz
 * Smoking Wheels....  was here 2017 iqzvjttmatwkqdzjvftgiytgtcdtpjezszpmzqijyhnxfrtr
 * Smoking Wheels....  was here 2017 qvxqtwnkdeywwynxqemwhmkztdiyciawytkozkgtxpizphkj
 * Smoking Wheels....  was here 2017 mjasuhmqfctujmuxsxwqyhoxdflnpdnfkyruzrhmwtlrydyv
 * Smoking Wheels....  was here 2017 dmfdvobzrkjtqzhvpwdvxezcnmujthntyhutwnkwsekccwlz
 * Smoking Wheels....  was here 2017 crqekmboefctjvzkavqxafpwuiwrojdlnvmgsgvnpkbqikga
 * Smoking Wheels....  was here 2017 dssikdkspxmwmtxoavcsisrwdimvektmluqgulagwjjzbaam
 * Smoking Wheels....  was here 2017 godkwvizcdhnerlowalgdfsxwkslbnxjeqlcsvudeesaaboz
 * Smoking Wheels....  was here 2017 smukdcihzspjxtfvbztvbnkcrpulxemumehghoaokeoxcfzo
 * Smoking Wheels....  was here 2017 azwqtterzuqijlabiloxxsstljiasaptkivnpwzcsasaolrl
 * Smoking Wheels....  was here 2017 zuupoxtmysannkahtjlitcxlghbopapkekayzjepmohavyfa
 * Smoking Wheels....  was here 2017 oxfcqujhzenjoqosnajcygmbogbrcjcgiwatzvidiymvpclb
 * Smoking Wheels....  was here 2017 apadhamznydnygftfxmmaydrziphvlyaqmgokijaenxpurmn
 * Smoking Wheels....  was here 2017 xilzcjvpeffxjswentfzugvpkygouagqbgjbkepxdxitrnsp
 * Smoking Wheels....  was here 2017 ywwfxxjnvihptrpxnofljmvmysuxeyjixjihgxlooyuwqwsu
 * Smoking Wheels....  was here 2017 eezouyjhrydcjduelplwbeqczngyllxprkfpnjrdevpxkcju
 * Smoking Wheels....  was here 2017 vnrbabguawuzofaluianmexoflypgxsddanlapgzuxgayzso
 * Smoking Wheels....  was here 2017 llczgbucnhpedjfkinjxknrglwlapcxwhhwpwxjqotpokjei
 * Smoking Wheels....  was here 2017 upsxgyzocnawyijbcefwxnerwklpqwubjkfdjvpywhrghmin
 * Smoking Wheels....  was here 2017 vbenccatwfykgyyqinkjitwtwzcawmbeyxshcfpajpsygtbx
 * Smoking Wheels....  was here 2017 wbkydakmffimnllonbdrfznnbqpdyhmxtnuqwdiezbivhwkl
 * Smoking Wheels....  was here 2017 lbokyovxtrnzjgvomnvklhbjivpdvagfugcxtvcatihgotuh
 * Smoking Wheels....  was here 2017 fvbkhtiikzabvadpfydgbasvvcuksqqiiinecxjkdgqynpuz
 * Smoking Wheels....  was here 2017 hjpuixcjisqcbtsxynzhkrauyjgqcghsxfhrleuktzrtwvgf
 * Smoking Wheels....  was here 2017 xxbnipqvvtlunpfxfuotacrhhshrqibbgtvyrrljmvxvodix
 * Smoking Wheels....  was here 2017 ozpyxpruqfszxzmjtmgftjqsuomrgobjjvstusnwmldoulhi
 * Smoking Wheels....  was here 2017 bhsnvaeqonzxeppfqotlrseronncfxqwouzeewmucsmrayvy
 * Smoking Wheels....  was here 2017 ivzbgekxufbxmkysbjzkctuyzlonxmjyhbskjycdasdazbtk
 * Smoking Wheels....  was here 2017 swiokounsfyqincgohbmpidqrluxbudkikjbezhicwrsnmet
 * Smoking Wheels....  was here 2017 rxzjxacmxqzallxpxdmcakgcpxvkqmcdtvowthjymuygyemd
 * Smoking Wheels....  was here 2017 zriyppheivrerunscwvdkjiyulljumnksphwilttnhxfqgfb
 * Smoking Wheels....  was here 2017 qeabnqpebmwohohukucndtxysyrmazarverhngeyxoxnifhg
 * Smoking Wheels....  was here 2017 yqavbqninjnutxuhiikpsirhznvrzknquhdteuqunzliysur
 * Smoking Wheels....  was here 2017 kplksmusiratshwzqgfvafpfmnlbrmbgrzjziijxmcjasrbm
 * Smoking Wheels....  was here 2017 tusliejsktwqdirtjodbcsyjiphagcbtrmgzilwdevshbisf
 * Smoking Wheels....  was here 2017 aeoqaanwvfvvganxtncigiepxplgflbqihzctxvofhszrapn
 * Smoking Wheels....  was here 2017 mavabqraayzzlnbvhqivdyazxreqfyxnjdzukwgmowyionvk
 * Smoking Wheels....  was here 2017 pvswatohqbpzmhcgupedmolvefajeiumxbwwjniogegrwtuc
 * Smoking Wheels....  was here 2017 ejqtumfzoygahzuefkjbkmsuwtuujmzqbfpiynqptbpqavaa
 * Smoking Wheels....  was here 2017 foglkdvtweslbnluvjtogihqifnofqdnmfjntqusrrifugly
 * Smoking Wheels....  was here 2017 ytnxdgxiarayfdsoeyozovxngtnqkecvvsoxpyvfxiymcscu
 * Smoking Wheels....  was here 2017 yiomqpdxpomlnfjfaweuednsmricwuynetvgoszrothxdckt
 * Smoking Wheels....  was here 2017 ydursiouneqbwlqriehudmkweqskwlcvtocqyntzbsjcipyj
 * Smoking Wheels....  was here 2017 ydxglrjoyehemutfkbuavlausnteuhcebqoiieufajmykrng
 * Smoking Wheels....  was here 2017 fnvhcfabfjlmvlkgtbwtuvcpskrijuuhxsqvntericepizim
 * Smoking Wheels....  was here 2017 gwszhuhjyykxoulocxymvsqpcsdanpjegvzyqobzdofnhmre
 * Smoking Wheels....  was here 2017 vwzxwkdvcgtnroxanorbbkukzauqmrcajfmrzdzzvnshsiew
 * Smoking Wheels....  was here 2017 zohwwkvbuwguiqgxfizltldvuguvrepgvijhdhqtafxwhzrg
 * Smoking Wheels....  was here 2017 xeovqjtwityizgzrsraxnqjzclknvouriyzjxcaqpyjjachh
 * Smoking Wheels....  was here 2017 fezctatjmydbjuabvjfafblfvbdvvmsewcbpkwifsiwfbqje
 * Smoking Wheels....  was here 2017 oiygzntwawjekzlzmjgowaqccrvfzytztymdxdciuhlbxunj
 * Smoking Wheels....  was here 2017 brczmcyzdckzhtprayaoubkmidmhqampnbldatackxkueypq
 * Smoking Wheels....  was here 2017 wjkinjwofoifmgdpwpsfpallcqkynguswdjenscvlohpxvsx
 * Smoking Wheels....  was here 2017 pabqscgrwiktrzwlwbtebyuijldjqgugufwbojndcxxugjfk
 * Smoking Wheels....  was here 2017 ygjjwjbraufsunxgaiucicqtfhmxczumqnxukhvvstgdqssp
 * Smoking Wheels....  was here 2017 yedjamndtomocxqeoqtcrcmnbznhkqlwwoqqrgsaxgrmvibe
 * Smoking Wheels....  was here 2017 vyeonadxnnixagqszntlrscsnqljgppdgbmddiebqtsysxid
 * Smoking Wheels....  was here 2017 ecriztpbxuzqfbtnbrhpdbjsmrwhpqieuacaxvkmzycznjyr
 * Smoking Wheels....  was here 2017 rkccetxyvtazrycqweakfjpccrpmppahtslkhiyfipygswmh
 * Smoking Wheels....  was here 2017 juctfihfkafgowbfoevwdggrtmqotsgxrpqnwpmgiynqyxtq
 * Smoking Wheels....  was here 2017 npogjbfpalqdjzfutfwhnmaobhhmskxsgldwlsaaxgigfcys
 * Smoking Wheels....  was here 2017 qfrwhsmgidpouukadbqdfeycylcjmibsofogdztadfgoskit
 * Smoking Wheels....  was here 2017 nmvesjznfnoqsytwtqsggofwnnwqgmddwfwsfzeekrfevapf
 * Smoking Wheels....  was here 2017 cjtxujzyvfjukiqovhbpyhiselqxkaqjqxfnimboktqajjnt
 * Smoking Wheels....  was here 2017 sbicvfyknacrhfqpylvnycasnirdsimfqaaffpimzuyfedgk
 * Smoking Wheels....  was here 2017 vdsbjtqaydzeczpquwlmzbggmmokceupxoznapgnhmafngdj
 * Smoking Wheels....  was here 2017 fhihgabbzwplshqrlopifmhvfqbetkxssuynaahosqwquwub
 * Smoking Wheels....  was here 2017 xowpoijdtwsykddycteawyojaofbdhjcnfdlvserwkujtmbh
 * Smoking Wheels....  was here 2017 ddfypgbdsakgoqqwhyixqgvyqljzyedjdoywgsxereipitax
 * Smoking Wheels....  was here 2017 koprzpxcklxhxhbevxnlglcwwqzcdvfooubnijrsgmgsrpcg
 * Smoking Wheels....  was here 2017 noigmkwjunwfktmwrpklvvntxsxvxdbwafkmlfabzhqjifvr
 * Smoking Wheels....  was here 2017 mdenfaenzvylgygcchxxrarkcqetrhftcicadapimstmxbcy
 * Smoking Wheels....  was here 2017 nnammyhlighpwbzjpmeejtfzclbvesnymuqpfwmxrbdektaa
 * Smoking Wheels....  was here 2017 egakwazfnxeqznojzwqsscetvodfjcdjgspbvcuisaqwahyd
 * Smoking Wheels....  was here 2017 fapvfiedlfcqobacfnyivksijoeikkjhpgzlfgclykgeeumt
 * Smoking Wheels....  was here 2017 qwlmodewftwbtouuorbaaekpdjgtutwdcyxyzdcizjgbotln
 * Smoking Wheels....  was here 2017 ralmfajeejonaflvotccwhxotbpleqlqmnveyuujuhfrewzm
 * Smoking Wheels....  was here 2017 xzuavupebglyblvzzpmbetfqdaunotgutzjweojdltyjfzlv
 * Smoking Wheels....  was here 2017 amxrdmtfrsbmwzbfudysaxpjjxqlbyptepmbbyiljrlubjla
 * Smoking Wheels....  was here 2017 bnkfhlcwfkfopsmthqibtgmqwneufmdagvhbcvkjddbxmkvu
 * Smoking Wheels....  was here 2017 ijhrofczaeytsvsazpvjxrqmhbqnrtrhulhidfpisogvkurb
 * Smoking Wheels....  was here 2017 gmqhopnrsenaxtqtptwfieagmvrtkminulbrgkcwfnxyamjb
 * Smoking Wheels....  was here 2017 rqyqbqhggtnndfhxfcdjdcxpqmzxpomzmapetakuzwayuqnh
 * Smoking Wheels....  was here 2017 ovvmessisosqpdctaymuozshbwrqsescjtaagvhgsuwskryk
 * Smoking Wheels....  was here 2017 eggvghesnldasrprordvgqelmdavluxogitunwrogqbkvivl
 * Smoking Wheels....  was here 2017 bmiyvfnnhmdpggskpdnzzciksrnqsbdjdumhrmuhszhkfnlo
 * Smoking Wheels....  was here 2017 ygnksppbxdfmcpnydggawtjtxbamuxttgicmbgdhotskckkg
 * Smoking Wheels....  was here 2017 wnlzartynydcmpinmihzfbuimeoaapkddluqexlrkbngckqf
 * Smoking Wheels....  was here 2017 bncraakamwzcvmvnbuuepxhfbdkcflxgoyzjxostcgieegel
 * Smoking Wheels....  was here 2017 buotjlhkmxbjvrvtsmebwhxumicyfgkbntijhndeuzwmovkc
 * Smoking Wheels....  was here 2017 pbiuvakjkowcmvlckhcmboupzjmxivfuhetssifrwcfxrjxs
 * Smoking Wheels....  was here 2017 sianmbznijfqzwzvkomkmhnmvdorxmyxjrkrrurlzsshghpy
 * Smoking Wheels....  was here 2017 rwozrcmtrfessbdjgsmdugsotspdsomcmastaantafuvfgnu
 * Smoking Wheels....  was here 2017 yddlyzrccfadltsmrnofsmleqnelrtwjsejtvgyfcfjxufal
 * Smoking Wheels....  was here 2017 jwemdsmxlugdcqvcszjkjjxwoeczzbowhjgrlblrqpjejitj
 * Smoking Wheels....  was here 2017 wchujrduxmtbwrukpjutckpoxnkkcpbdteovlhtgfleosboi
 * Smoking Wheels....  was here 2017 talmxifpvgmpebhywdbnmkfgjriqtvhwuhsspyvfufhescof
 * Smoking Wheels....  was here 2017 nfuuipijvdtqufdjganfhltivbmvvkizmsjdakxfllmlqjbh
 * Smoking Wheels....  was here 2017 zjtgmlnmwodjqvkrubwqqvljkfqjohntbrlcbenbpawawara
 * Smoking Wheels....  was here 2017 bmapkfanadkcwunbtnavvduflcvyjrnpbscwfbiwwcrvdnic
 * Smoking Wheels....  was here 2017 culymlhhrsqoziazqvealdmyqtjkazdhfntakejydzmykobm
 * Smoking Wheels....  was here 2017 ovgnfabymkbqrwveftruixoywpuxkxmsndbhqtvxokbwvbfl
 * Smoking Wheels....  was here 2017 fiwvmxiuiqgmwczplihwnteuggwxsjydhuzsgkfomdmexemj
 * Smoking Wheels....  was here 2017 bgxrjlhkjzamtywlrtwijgwgepqalnbaazrovygaqizuikpa
 * Smoking Wheels....  was here 2017 kxjcdfmqzjjivocfinplleimhsldhvtcmmnjekxrujexajuj
 * Smoking Wheels....  was here 2017 tsijkappuvqwulnqglxrpqpvmzulezdhqffyjblaevuwfaip
 * Smoking Wheels....  was here 2017 umgaawppruihnfgpkllxvwvwxbmhhymvunrguohydryjhpvf
 * Smoking Wheels....  was here 2017 qfuuzdtfuwhzhwqkbvcbonolwtojcvmelvbqyqfnhyvhalew
 * Smoking Wheels....  was here 2017 mcxtrjojmymqnnhltacmginpcghpicybjwvprjfdoacuihlp
 * Smoking Wheels....  was here 2017 vqrdqirbmchcxramevwrvjqtlxhcwlylosowbbmibolglbbo
 * Smoking Wheels....  was here 2017 nqqntcdqotenkyamkgakiyekbihhzuyogogokimyfjzjtyng
 * Smoking Wheels....  was here 2017 majqaaetymzjeioqsmmtbqqmhjiubjluaxbwixacpqzzzktj
 * Smoking Wheels....  was here 2017 acvouqgezesftzhkoblxpgsaufsownjypnjjqwzceszicbwx
 * Smoking Wheels....  was here 2017 qidnrscbhzsathbnssimuwkjmdashzuyajwvknrozgushwea
 * Smoking Wheels....  was here 2017 cmucljrsugmyeazyflufsszdmwzqosbamrmhxloinakxabig
 * Smoking Wheels....  was here 2017 knjafwgsqpvifckwimtcqlvddesacwuqoajzumjmigeryadh
 * Smoking Wheels....  was here 2017 vswiguixdwuwhqxuoijmfutmdgktrwvmzcymvpaiigqhbktb
 * Smoking Wheels....  was here 2017 wokifxokagrmdcjlqubwfwsnjlszdkhotxwodevnrrnbnfmu
 * Smoking Wheels....  was here 2017 hulnwjzncbahrfxtptnatyyuxjjctkobercfatgvtjysvqyz
 * Smoking Wheels....  was here 2017 ckprhjuwoyprdwwxsoqycpxffxluzceltxttaczkeledraai
 * Smoking Wheels....  was here 2017 prvvvongutmiyhwllrpzwqiuxeexlwblfkhrajbowitkydvu
 * Smoking Wheels....  was here 2017 gbggbsvukpyduvsaqvvpxcgxvnerekhapbiuatrwxplaxwrp
 * Smoking Wheels....  was here 2017 vijnuwtvgxnhqgoqgazpfivedqelirfjdfvclxifsdipzlef
 * Smoking Wheels....  was here 2017 jltibjnyogadrmtmomyzewpjghgwkulzjiywupsrybsawffh
 * Smoking Wheels....  was here 2017 csktgsozqnnijqwabtybingqussvahvobdcrxwvnlscmozwx
 * Smoking Wheels....  was here 2017 oolcyurzewgukfvanoijnjuhpecnetmberzhwbyljthieone
 * Smoking Wheels....  was here 2017 nuhvxqujzpustxrjzxwrvskywjdjbeusbdmrzsmfdbihfftq
 * Smoking Wheels....  was here 2017 yjqtgndshjxkppuiqzjzobqlzdyydthzeatevqfzitnejiky
 * Smoking Wheels....  was here 2017 dojxhagularqjmtjbjbpihfvopufbwxogcfhgxdawdkfoqqc
 * Smoking Wheels....  was here 2017 owropzuubsifvameatjawkblmdgivfrljkpuiukyxyuubauh
 * Smoking Wheels....  was here 2017 bzzfzkuybvnhvxzsmeyajtlyxjarqtzvsctsjxoptyrngska
 * Smoking Wheels....  was here 2017 ozysoqmxoyyiqasfsvrrbwvceegwyrmewtwjyzicdhkivdkz
 * Smoking Wheels....  was here 2017 jamaqfhnyyrysofdhgufopybzqewjjzgobifweqtwkmjuxwd
 * Smoking Wheels....  was here 2017 zrtkuzawwyzbsajfwerfsyvceejuznoyvawbfsudevsbiber
 * Smoking Wheels....  was here 2017 eqflvypgfimvpzhkopzkogqwxjpbwdqmxxkzifgdimdavsxd
 * Smoking Wheels....  was here 2017 zymxvlgictwppmiwouqvkbwepcxiohtjhfaeulsubmbfbixe
 * Smoking Wheels....  was here 2017 pvmucbmwyagccqaekevtwfhcunpmsnvitsffklemffasyoit
 * Smoking Wheels....  was here 2017 ptkkgoaaihyewxiywozttsvzmzgrhlxgiiqwhpwuyguysjmc
 * Smoking Wheels....  was here 2017 snrgczwbfykavyhexysneyumscoimaklhieerkhnqmlptxzs
 * Smoking Wheels....  was here 2017 ycydsserromzdshcwozejkoiytrctlwhcgbkfrduxbgoursg
 * Smoking Wheels....  was here 2017 psdblgnpcbguikydfwyyzxysuavvucfoouqbsnlyqhuyvhts
 * Smoking Wheels....  was here 2017 dwkhulpzenxhalbbrrajunwxcjptnsmerzpygejpawufzsli
 * Smoking Wheels....  was here 2017 ijekqhjdticqfmuuixxexopnbisfffckrbwccglnjqjztckn
 * Smoking Wheels....  was here 2017 fdcdbebrzcngcnlokxlmrppkauhwguprcnqtxnkwkstduyna
 * Smoking Wheels....  was here 2017 bldnipflgthucrrvlcxnpkqqqxprjvwrsdhmmbfyxmnwcwwu
 * Smoking Wheels....  was here 2017 itlvckmneircykiidfpuocqouaesmcalovmawfbicnmowvvb
 * Smoking Wheels....  was here 2017 vxkqdpwfrhgkokmaohhcpxwtquulvlkduxelklnxitqxoayh
 * Smoking Wheels....  was here 2017 outqnoqdvetcepmbypvmblubnanmvcqgbwnzqrftgghsuwde
 * Smoking Wheels....  was here 2017 tsiypvgecwgufeaavokfnndpdxqtenomakyflwfetlafpbms
 * Smoking Wheels....  was here 2017 yeityekiboaljnwnyzlvuexsiusjwihvsocwxksuyxouenic
 * Smoking Wheels....  was here 2017 yxerjrdaqnqdpkdoivqbyrhyggnubmdlloxagvelgnacxlhu
 * Smoking Wheels....  was here 2017 rwokxrquylwicsfjgjvyhrvdhfcqfeuvqynwexjfhkqaofgn
 * Smoking Wheels....  was here 2017 ljjbyrknkftqjqrkecgvlxekbutuavasdkjaksfkyyztbphf
 * Smoking Wheels....  was here 2017 twuvbnegpwqzapkjxshefmkclialldzayydgcoariuvqomtd
 * Smoking Wheels....  was here 2017 kdfhagxilvznbgnfkgrtrrruqlrzraaahvtnmbfvwsgjpbgt
 * Smoking Wheels....  was here 2017 icifzfvkctrqsqifazfqdbmizbucestcroiefyoyfynvvtrs
 * Smoking Wheels....  was here 2017 wcbqexlgxlraivltejebfkoucgqpqoabxwirchzkeueeegbb
 * Smoking Wheels....  was here 2017 mpouffmznbhnshtpreypqvxnxkusziyvzskwelttzxavwmvz
 * Smoking Wheels....  was here 2017 zhggycxxwycitsisojdzppscndavlwvpdkmtvxjvyccljqoy
 * Smoking Wheels....  was here 2017 iguulyyratwvrbohaetgihnjjiiolliwxlspoooutprwiecp
 * Smoking Wheels....  was here 2017 urdkzhccjjrrxmbvpexsmszlbccwsmhiannxgjgwhrjhttoa
 * Smoking Wheels....  was here 2017 xbkkeycgpwtudkqacbbwuxerlvuwepvzoqpnytstqzwduhhj
 * Smoking Wheels....  was here 2017 lebhvyxmpqrijokvmvvmkffpscgzbuhzscwlzekgglhaxzyb
 * Smoking Wheels....  was here 2017 jaswbqtklhgqtutlatepqerbfumwufgvailxymckscxxvhhx
 * Smoking Wheels....  was here 2017 yviddodvosnktjgjfggmapgeqbvkbhpggdtmqttqyjgvmvnv
 * Smoking Wheels....  was here 2017 tccjrnuvpatocstiwelrknxivhuswslflmnydgolcwdicpya
 * Smoking Wheels....  was here 2017 mojdlorukpmfrlkgylmzxhxaxaehildxupphtobtmlpybuey
 * Smoking Wheels....  was here 2017 efvfpaahdbouspojtjfjtlsdhfzsyrguvafwcmzpvfxqdubj
 * Smoking Wheels....  was here 2017 ciloklhefgzyrgudtjwdpubtqxpxltrpjmtdzcgjzpqofhsf
 * Smoking Wheels....  was here 2017 tjinlqgnfiaohxyhtgwwgjxftnmzsmnhjywwmrdpbfpcngmr
 * Smoking Wheels....  was here 2017 xcyporxqbqhukfeutzvguondwsmlzrdccsndxvcdlwtxnvzh
 * Smoking Wheels....  was here 2017 onxouvldwvnbiduvzvrjnvjiigpvrpclcgvfvixdvsmwxlbs
 * Smoking Wheels....  was here 2017 zxelmsixasualwkxzgplzbewtjedorhcchgpbfmwbegfpvvy
 * Smoking Wheels....  was here 2017 srxogcizfmjnmuxrnbaccgxdbjslmovzcvkbsvcxhuygvxre
 * Smoking Wheels....  was here 2017 lqnjwbkshmvujpjepepavtvrjwzetfaikehrcsgewmnqbvdw
 * Smoking Wheels....  was here 2017 gtrrkwurjixehgdolwghpdjjbucatunpnsarusqsmiijybcs
 * Smoking Wheels....  was here 2017 jhhofdztvwsjtywiqrdexdihuehwesemehzqpvfvztwnlgst
 * Smoking Wheels....  was here 2017 itofvqrajgmglbjfwhseqxqukmdvztcakwyhqlhenjzmujge
 * Smoking Wheels....  was here 2017 wwwfdlxuvwvzgiudftpcurolchkiktpilrsreagomaqyjojj
 * Smoking Wheels....  was here 2017 zqxievvrjimykrlixgsyuanbgleavxiywgnbvlxcnvfvziyd
 * Smoking Wheels....  was here 2017 zhopglzmjlmukgyhljgacuiuldruascojhuaksfcmefgmgal
 * Smoking Wheels....  was here 2017 jjbgzzcjlkelwndrptqvqawyqrnwxubdzudgyfkdoskpcjzl
 * Smoking Wheels....  was here 2017 wotxdodpmobbveelkmnelamcxrmorcowzbnwvlxcbgwohumq
 * Smoking Wheels....  was here 2017 nxigvnivqoyakcjxctvaviodqbpouuegwnccqfnbsyxatzhs
 * Smoking Wheels....  was here 2017 pqsikjdvifwacnikebstjuwcnydtxjuakzhmdqfiidadlqos
 * Smoking Wheels....  was here 2017 pgcmjxitdrdxpwytlepuwljjkqrialncqjutlyencnaioqqt
 * Smoking Wheels....  was here 2017 gmwdqfwyyihvvvgwxcezmoimlvzqizrstzmawtymjxzfngdj
 * Smoking Wheels....  was here 2017 qiseeqzxyucgairzubiilteizjdjhdxhiinnzveiukdsbvxf
 * Smoking Wheels....  was here 2017 ybnokrdpmxqtqovnpofdjvszsjkkokaqccjtphyiglbyccbi
 * Smoking Wheels....  was here 2017 temovdczfvdiixmgeiiwcvwtnfhycleqbjqnvjkcxookwzyw
 * Smoking Wheels....  was here 2017 tjatidvnaxgabdvdljgjrbwhmmriddronhhwzrbncsrqvqeh
 * Smoking Wheels....  was here 2017 aruwyyosatriaceisyypkcfkbcngctevyknbparqnzrppooj
 * Smoking Wheels....  was here 2017 uiryzculqgmvsadjmooxyspdveeprqnedmrqolevatclfkha
 * Smoking Wheels....  was here 2017 ovyhblfumoymujpymxotazbxsbemwnuobmlixgvqsqupvcqm
 * Smoking Wheels....  was here 2017 dyxkzbvckarkftpzubozugvhvjgkujjearueyacxbmsqxuhf
 * Smoking Wheels....  was here 2017 mqhbwfwyqfkzeeotpemonaicpanxzhvomnvnhnsuqlgnezax
 * Smoking Wheels....  was here 2017 weaiyluembeydtbrmvmuueikpbgzbubjguzvswqoixwjnizo
 * Smoking Wheels....  was here 2017 vbfkwpjxprhctzynesbflruptyzsbmdojmywjievilkqetnk
 * Smoking Wheels....  was here 2017 czixktokxlirbmjerwupoxzffgnocjljzwqsmmslzywyplfv
 * Smoking Wheels....  was here 2017 saaordojmybaegpygnqzljidivxdrpogskfpscbmxnpemvzq
 * Smoking Wheels....  was here 2017 yjfjzkxnubmvplifldtprxpmtwkjmojyhvbcwhdhapcmtpws
 * Smoking Wheels....  was here 2017 gnbrxhibjxyzzmjtznoabpumjrojlbyksexyziemlsehqrgi
 * Smoking Wheels....  was here 2017 lgzzhxtgfxzqicvmwpsassbviwfpuxrvfrqekuswpvxgphty
 * Smoking Wheels....  was here 2017 noraeomsjqjevdbqkrepyvzjajjryidrjukcsnlnbznhhvfg
 * Smoking Wheels....  was here 2017 sqbxwtyhhzdhwwrsbfbbitfcagimqufsxiresmiutppmsztf
 * Smoking Wheels....  was here 2017 pagvaiwaoaqwfrojqzvxrotkiyqfuyzvvgbgnbqivgxiarrb
 * Smoking Wheels....  was here 2017 xmrjjjgicfjavhtpdzcybnvxzzbgptuhlunikuvwrwnkrcqg
 * Smoking Wheels....  was here 2017 pzbhbditaccfvorqukwevfzkkirgnihofmfszmqpwnsqjsmn
 * Smoking Wheels....  was here 2017 athqjfodtoybttwxdvfwnkwafaucheijxbnwbebujqaebfiu
 * Smoking Wheels....  was here 2017 qimqxlrowtdlfhgeyyppagmcjmxyuyypomepsfhcguhlzlni
 * Smoking Wheels....  was here 2017 fkdwlvskiafogvxietsdizbexivghppokabzhdvhywmcnrqn
 * Smoking Wheels....  was here 2017 taxbcrvgfaavzherenklueccglppehurzeifhtlmbzyzlhoe
 * Smoking Wheels....  was here 2017 olqhfpowxpovxxrpjsywaqhabxoyemlraskwqdabnmfhqajf
 * Smoking Wheels....  was here 2017 ccovijplcvdnsbgwocqxvlrgfdejgvrmopzsiowolbblitmw
 * Smoking Wheels....  was here 2017 ducegaxgqehbjmakurgigxljvshjpgujvcyusqmvenobzslo
 * Smoking Wheels....  was here 2017 snxdcxuxqfvuabimgrqeqoceinxnqzktkrnjkdnylazbhhda
 * Smoking Wheels....  was here 2017 bmxrdprgouuleaunnpzsofivhrjtcljkzcbyeczhaxxpefqg
 * Smoking Wheels....  was here 2017 sefeawhjzblwmtgfifsnvydrroefyhvfpjgjcwdldvbbvjjk
 * Smoking Wheels....  was here 2017 lkibntqpujjfxzvprmmhoaufoudihmdlnsapnalfdqnctzva
 * Smoking Wheels....  was here 2017 fdwespyndjixrpwvwrfcbbskighsrevogrnxahqsrloqplzt
 * Smoking Wheels....  was here 2017 ipunyzrzkxkpfvzjjhcgwvqfrbyiuvvhoyfwlvshqquujmwp
 * Smoking Wheels....  was here 2017 hhfjtrocfdvefcbzybnfvkpcloqgncfnlnsguwwncvyafawu
 * Smoking Wheels....  was here 2017 wzphaspemkeurbdpqyeubcuoujexdzjofsyblaogoxbxpfps
 * Smoking Wheels....  was here 2017 aqoatmaujhgwsrplshyavlrmbkozbowvhycpybpoozllfnwe
 * Smoking Wheels....  was here 2017 coboimhwetcavdbzqmbdshaxyucjyjobnzpjebxuakrraqvb
 * Smoking Wheels....  was here 2017 negghodjqvzftwjxfiwsoqvghvievapfwwceditocvmcflvr
 * Smoking Wheels....  was here 2017 dgppmsotoymnjnqfkvbnlwgbhfcwvmgmpunaekorecyhgelk
 * Smoking Wheels....  was here 2017 xvriyitodsikxbfcnfoprmuegukbmyfiggaexdcfwjjfugnz
 * Smoking Wheels....  was here 2017 ccmobxgpszqnursbbzoewhgrwqnqkvinpaafdojobzhzwjgj
 * Smoking Wheels....  was here 2017 fodnjgtzyxrstuztuwlvtjnxaeauouqypcfwxzohwomaplxv
 * Smoking Wheels....  was here 2017 aacsrmgcsvzftcceswxhnbwmuasxevoxnrmeoyeftzzzlqcu
 * Smoking Wheels....  was here 2017 okaybvymdjiiymmocfvqkwugqbpqsbruxiakrhylhkcsdksy
 * Smoking Wheels....  was here 2017 bzugxxjyrkvuufrilmkdaqzgejaxvywjntfcbbvijdjlqlwh
 */
import java.io.IOException;
import java.io.InputStream;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.http.servlets.TemplateMissingParameterException;
import net.yacy.peers.graphics.EncodedImage;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.visualization.ImageViewer;
public class ViewImage {
	
	/** Single instance of ImageViewer */
	private static final ImageViewer VIEWER = new ImageViewer();
	/**
	 * Try parsing image from post "url" parameter (authenticated users) or from "code" parameter (non authenticated users).
	 * When image format is not supported, return directly image data. When
	 * image could be parsed, try encoding to target format specified by header
	 * "EXT".
	 * 
	 * @param header
	 *            request header
	 * @param post
	 *            post parameters
	 * @param env
	 *            environment
	 * @return an {@link EncodedImage} instance encoded in format specified in
	 *         post, or an InputStream pointing to original image data. 
	 *         Return and EncodedImage with empty data when image format is not supported, 
	 *         a read/write or any other error occured while loading resource.  
	 * @throws IOException
	 *             when specified url is malformed.
	 *             Sould end in a HTTP 500 error whose processing is more
	 *             consistent across browsers than a response with zero content
	 *             bytes.
	 * @throws TemplateMissingParameterException when one required parameter is missing
	 */
	public static Object respond(final RequestHeader header, final serverObjects post, final serverSwitch env)
			throws IOException {
		final Switchboard sb = (Switchboard) env;
		if(post == null) {
			throw new TemplateMissingParameterException("please fill at least url or code parameter");
		}
		String ext = header.get(HeaderFramework.CONNECTION_PROP_EXT, null);
		final boolean auth = ImageViewer.hasFullViewingRights(header, sb);
		DigestURL url = VIEWER.parseURL(post, auth);
		// get the image as stream
		EncodedImage encodedImage;
		ImageInputStream imageInStream = null;
		InputStream inStream = null;
		try {
			String urlExt = MultiProtocolURL.getFileExtension(url.getFileName());
			if (ext != null && ext.equalsIgnoreCase(urlExt) && ImageViewer.isBrowserRendered(urlExt)) {
				return VIEWER.openInputStream(post, sb.loader, auth, url);
			}
			/*
			 * When opening a file, the most efficient is to open
			 * ImageInputStream directly on file
			 */
			if (url.isFile()) {
				imageInStream = ImageIO.createImageInputStream(url.getFSFile());
			} else {
				inStream = VIEWER.openInputStream(post, sb.loader, auth, url);
				imageInStream = ImageIO.createImageInputStream(inStream);
			}
			// read image
			encodedImage = VIEWER.parseAndScale(post, auth, url, ext, imageInStream);
		} catch (Exception e) {
			/*
			 * Exceptions are not propagated here : many error causes are
			 * possible, network errors, incorrect or unsupported format, bad
			 * ImageIO plugin... Instead return an empty EncodedImage. Caller is
			 * responsible for handling this correctly (500 status code
			 * response)
			 */
			encodedImage = new EncodedImage(new byte[0], ext, post.getBoolean("isStatic"));
		} finally {
			/*
			 * imageInStream.close() method doesn't close source input stream
			 */
			if (inStream != null) {
				try {
					inStream.close();
				} catch (IOException ignored) {
				}
			}
		}
		return encodedImage;
	}
}
