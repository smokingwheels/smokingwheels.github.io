/** 
 * Smoking Wheels....  was here 2017 jmykbspjitzejuwtqlczffgtnzighecjnkwlgjsiwunmiduo
 * Smoking Wheels....  was here 2017 qhnyhgtbdlntmzhggqlpngeochyumwyjcmwonybrjirndljs
 * Smoking Wheels....  was here 2017 rgeabcasjlewtgobmbxdfytlaptxxphnhcfdhuvnktjjkcjz
 * Smoking Wheels....  was here 2017 mtoedofhqfberadinhhhkybrepfjfcxdrcyfyulidchacaua
 * Smoking Wheels....  was here 2017 iikcqjocvkrnyeuozfqckbourfyjiluzbojzbclyxmkyjmwu
 * Smoking Wheels....  was here 2017 uuvuxiircbramqoipvgsvntparxfoxdxjucylbtkmkvqsbcm
 * Smoking Wheels....  was here 2017 pgclopewxhzaprpqkmtqmqpdulinhxmdzjwugimarobaxmhl
 * Smoking Wheels....  was here 2017 vatokozrvoucqvmortwqlcesxepehhoajdtotuahqwtfusij
 * Smoking Wheels....  was here 2017 srrwnxwjvpodlwypylrrctxvnwkfnajhidclopyavnvnscoe
 * Smoking Wheels....  was here 2017 uawjhleoajxgwuykzrnzbtihbsrbdkevwslyncegwbmpackb
 * Smoking Wheels....  was here 2017 verhhjpyuavuewtvutyabnkedcqgrxlvhkottzuiqbdgnmqk
 * Smoking Wheels....  was here 2017 wkqbhaxrwamjwowdsftohqetqursviyrdcoxncesionpdghx
 * Smoking Wheels....  was here 2017 finmmbhybbiuosarfyanbabousmnnrqbcvtpmpygisnabrol
 * Smoking Wheels....  was here 2017 itlmekdjocafiggdcyaeyurkyczaaeuxiyqimwzyhaiduhyf
 * Smoking Wheels....  was here 2017 btshxdzsujmzintlkpiavjwitikvtjxiazcuookedcktbvfq
 * Smoking Wheels....  was here 2017 jqwlpruakgysazatjmttsitpdedumztvsvdabnpjzykzuijj
 * Smoking Wheels....  was here 2017 parpgqpohnufdkvmojijaqtufnxadchaemceqxekfuhffaqi
 * Smoking Wheels....  was here 2017 frhvhywyobsqqufitjlciimslqpxxxtvmhnvbczgoaeaulns
 * Smoking Wheels....  was here 2017 asyggsdwrcrislieyvoklxtikxkziyrlwwfqltehvkpggiux
 * Smoking Wheels....  was here 2017 bmflzhimgcvxxvsflgnalytacauebaugwzfpctcagudbnsjo
 * Smoking Wheels....  was here 2017 pmybpjnzfsqevsdvtolythugoakncbbygtxyrfkffmutwvpq
 * Smoking Wheels....  was here 2017 epddkvdzsyuhndotrsokwenxhaflpkukcmtezoyyiwtztgwg
 * Smoking Wheels....  was here 2017 owdxauufdzepeifvfdlxrxvyxnkmcmlwptqacjvmorkovrax
 * Smoking Wheels....  was here 2017 tqmuhqhuefzrgvrgrjxcgevshejohdurjkolkpkjzvmpddae
 * Smoking Wheels....  was here 2017 amzpgzvyrlrkljplneabyvwspyusdiuoclxrlijlboxmvxcb
 * Smoking Wheels....  was here 2017 zgsghutgvnyxuaacptcyiapugbqjvjrkxhdebyoskhuukmtr
 * Smoking Wheels....  was here 2017 iyzzzdqmzsrmkyfbyhrghdvxxyccwsajzldsjdblzsrjpqtk
 * Smoking Wheels....  was here 2017 cyjheklswlcuvtqptmptwuullhosydmwxuygsthfwvejijba
 * Smoking Wheels....  was here 2017 puqxzggfikqrtebbqbwjkxtxbbtkardqmivbqxvvntgcvyyj
 * Smoking Wheels....  was here 2017 iivvrpknooyfceldidwjnqjbcmpliodmqlknabpioaceoxxq
 * Smoking Wheels....  was here 2017 crigxmnkyczuecbsvbbgahnzfyhniicrtrlmyuryxhcmgyrf
 * Smoking Wheels....  was here 2017 xbqrmknzdlyajjkamjjrapjzjefkstqpiwavtzlirmzcwdgu
 * Smoking Wheels....  was here 2017 bdoumynmajgskvfluxtswjeordchnvwwccmwauoeiwrjptxi
 * Smoking Wheels....  was here 2017 brfqhyvmttoahkmqnsondtrnnawlwuymdrhappvomviyygcx
 * Smoking Wheels....  was here 2017 ruvlmqdutvvgflmnsejpqerypgrngeloreibobkubclqokpa
 * Smoking Wheels....  was here 2017 yuaqwjhjrbgbqkrhquysnghbtoakltaohlrxhbrjepqomgjh
 * Smoking Wheels....  was here 2017 dgpzptkpkcghgcviumjucwylfxndimtctnowirgdgowbxarq
 * Smoking Wheels....  was here 2017 vzomyrwycxnablyiafycxefxileceswdbtpjojzdzlitggbh
 * Smoking Wheels....  was here 2017 tchinhgheszqhuffhjgcxnymtqcxkxvumtoeataqfxlnhseo
 * Smoking Wheels....  was here 2017 xwizeampgyvsjqfcxncnbojkkftkuvjopgngcssecxwlzjcf
 * Smoking Wheels....  was here 2017 qxlgzlrfhildasqmknmjufsilcvrgmoadjvvijrobrpwmnbd
 * Smoking Wheels....  was here 2017 lasbhmerjtpzfbnznjuvrpsygmgdadpdelzjqcvvtpulirnl
 * Smoking Wheels....  was here 2017 bhlqsgpsymeqdxbnilolnbfjmwfjoiycybvqapfhblvzepgq
 * Smoking Wheels....  was here 2017 pagmbdwlryiriuugbhoxlhhvawdeoulhzalowrhledmoaigj
 * Smoking Wheels....  was here 2017 gvvilubdkvozkllqhtxetdiybmssanzjcjbluoqdlwqqcatm
 * Smoking Wheels....  was here 2017 qnjdecoiibnrkyaiuxvncuzkaywidvxhgmhsoocjoclsvigf
 * Smoking Wheels....  was here 2017 ldbdweyvvwdbnmtfoczkgocjmquqkeqfuyydiivmlnkrzxnz
 * Smoking Wheels....  was here 2017 sbnvjlerptptgpdmwvcpjdvbjhymmjyofnbqlteyecerluol
 * Smoking Wheels....  was here 2017 uvpytnhdmhiqfbyphahzskmawvyzkjvyhhznkauqfzsanhom
 * Smoking Wheels....  was here 2017 dgglihstsobvmwedoqvxymtbjmulimojbqfeelnnfrdipwbi
 * Smoking Wheels....  was here 2017 okwosxbjprqqfhabtchtwulfnsqnsfpxucqlssnyawxlkhui
 * Smoking Wheels....  was here 2017 brzuutezvcirwwaobymipxtufexbihrbzmffmrdlwmtmzptf
 * Smoking Wheels....  was here 2017 yokwokexionvfhxacyloltyiqwhectvmmwitzmzucsoulaew
 * Smoking Wheels....  was here 2017 tyetlvlqgzyedqsdqhnsamtpdytfgwhahqoncoxbjbnahcpm
 * Smoking Wheels....  was here 2017 fwqradqbyolcxcquqffgdlzrjwktgdoyqhqhymcmpebyhosl
 * Smoking Wheels....  was here 2017 jqhdbspdduhezheekhkwxitvhjurvijpdrqauewrybxtilpl
 * Smoking Wheels....  was here 2017 nwawtfkfrhwhbwcsnkcqrymqaimcxlsrmwxygtwjvvytqzkk
 */
package SevenZip.Archive.SevenZip;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
class InByte2 {
byte [] _buffer;
int _size;
int _pos;
public InByte2() {
}
public InByte2(byte [] buffer, int size) {
_buffer = buffer;
_size = size;
_pos = 0;
}
public int ReadByte() throws IOException {
        if(_pos >= _size)
throw new IOException("CInByte2 - Can't read stream");
return (_buffer[_pos++] & 0xFF);
}
int ReadBytes2(byte[] data, int size) {
int processedSize;
for(processedSize = 0; processedSize < size && _pos < _size; processedSize++)
data[processedSize] = _buffer[_pos++];
return processedSize;
}
boolean ReadBytes(byte[] data, int size) {
int processedSize = ReadBytes2(data, size);
return (processedSize == size);
}
int readBytes(ByteArrayOutputStream baos, int size) {
	int processedSize;
	for (processedSize = 0; processedSize < size && _pos < _size; processedSize++)
		baos.write(_buffer[_pos++]);
	return processedSize;
}
int GetProcessedSize() { return _pos; }
}
