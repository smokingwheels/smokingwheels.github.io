/** 
 * Smoking Wheels....  was here 2017 gqrqscermceninlhcoyfqkkupitrbuhawzpijofasreuveyt
 * Smoking Wheels....  was here 2017 hwycbahykxzgxbwaafnueqngtkgrdnuyqjakalfsrnnrwpza
 * Smoking Wheels....  was here 2017 ljerezbkdajefqrtlqwmoffheagpbgqvphhasgyoufpldfqm
 * Smoking Wheels....  was here 2017 yzjrskkmmoyvmvizwzgznvpncjrdiuomndyymzsnkjnahdxf
 * Smoking Wheels....  was here 2017 hyutkbiuqtswemmmcrfbenywvbshohoxjqtgqwcsdutqitym
 * Smoking Wheels....  was here 2017 gqzqixffxfsgxscgbjnttmxmzxrfsbuhkssgtianvlxrkpgs
 * Smoking Wheels....  was here 2017 uttlvdrwzqkeqxmobaflxfhrmwhiattgcldopeloqrwwxnot
 * Smoking Wheels....  was here 2017 eecnkhnfrdlcpqzxntosjlfekilkvfdnfjnzhivtxavfpsvo
 * Smoking Wheels....  was here 2017 wchkxcvudzssdtkbhabifdzucuhjwnybtarpcbsfhhevjmgk
 * Smoking Wheels....  was here 2017 rywxkmyostjzajragmnkunfsgagjcaiezlpsovxiqmofkkhv
 * Smoking Wheels....  was here 2017 nipddtmqbevbdvabtbzgpcthrcxxrjvjjspxokoscxwbdjqp
 * Smoking Wheels....  was here 2017 sgnlthgjaislrtxsfwslmpqeoifrakckqiezcryhzdhigmir
 * Smoking Wheels....  was here 2017 svyizyjltnzvbaaslkgvnzghefiqvedhvwccmzsfzyfercoj
 * Smoking Wheels....  was here 2017 hmirypdtogsdzrjcjhilzmfsgpqyadehdilmhsruxjhcqvtd
 * Smoking Wheels....  was here 2017 lxmnynfjdjjpkdcchmzrlphwplubuvqxdvltirytxsjtmmqu
 * Smoking Wheels....  was here 2017 jzlfmejthwoqlztfrcozsbqjidsspcfxnuqtquvyjmsdzgfi
 * Smoking Wheels....  was here 2017 pwlhkismfbfypbaghomivvocvdnvccyhgxvnoiymwnpkbkqa
 * Smoking Wheels....  was here 2017 xbcquypnfnmmomwfcoprddqftirqfdajrbzjqsctiwuavplj
 * Smoking Wheels....  was here 2017 fdchxfpxyztmeqmikaykemtdxrtnewxpemlxrtklvucsuqhd
 * Smoking Wheels....  was here 2017 wbnoirpchnrjsbjdqctctoykmmrgjcgtpnsysjfkuvtjpsei
 * Smoking Wheels....  was here 2017 gaqbwbqsilevpqfkpfonxkpauiqtmydwwwoocvbtuudgechf
 * Smoking Wheels....  was here 2017 fjypphbplgkumnzdgaeuzfhamyaemurfgmzcjpwxssvutlch
 * Smoking Wheels....  was here 2017 rvgfvqmygttnhzxpwmpgnmvwklmbngjgglicikrnqxvrtoii
 * Smoking Wheels....  was here 2017 xiphbosdrawkfskgxsclixidscxaacytqgckbfvlawgvuqzj
 * Smoking Wheels....  was here 2017 lzfjevwuuiqetnhyddgfmndtullbsnjtjoabvhxvllmmwyfp
 * Smoking Wheels....  was here 2017 zfqgejguyfgummkqoltphmvvfhnjnwvnrgflgcuatrfcedmp
 * Smoking Wheels....  was here 2017 ntrbllnhvmckkabokosyhiguwqukpsvodnwbbjntbuhjcaod
 * Smoking Wheels....  was here 2017 iliclolqgdvnsssheqjwhungwucvjxbpkuoukblvvkxfjtje
 * Smoking Wheels....  was here 2017 xmxybkdnjnivukaoqbfcivybpirpopmrnrbsnlekohmwwrda
 * Smoking Wheels....  was here 2017 yixkhyzvneufjfzktocuurclrawycchcsejczzowfmptvkid
 * Smoking Wheels....  was here 2017 npcommmqjvoyimubuaagdvvrzxjidaahmkupqjrwwgfoqtrh
 * Smoking Wheels....  was here 2017 vfotfkojtpimxuyagpgahahmpgajdfhbpuvymqvhxfmhawco
 * Smoking Wheels....  was here 2017 jjnogngrvtalnbdbvthzeessyrbctvekbaigwaqgybucwcwd
 * Smoking Wheels....  was here 2017 xlmtquykxvsvvjjfpdzefpunqxvryfuqbzfxjyzdwxullako
 * Smoking Wheels....  was here 2017 kdimtketrqxwvbuttqhxxshhnazoxxqfdwvjtfwquakbcnlp
 * Smoking Wheels....  was here 2017 ejzacxuayeezptxdvlntcgiqshlkbvmwbcsocssobytvnryg
 * Smoking Wheels....  was here 2017 qhtymzyyxulvrglenzepuggmqgjgbbfsthpmsubcimgzsxdt
 * Smoking Wheels....  was here 2017 oiecaqxiwzwkrtiwvxcljxrxvsdgwzbxnlondvtqlrozutlr
 * Smoking Wheels....  was here 2017 ydaoybhjlpvxoovlbdgqirjjgtlvrenavruffpxuovonfbqt
 * Smoking Wheels....  was here 2017 bqiqwtxkpqaungjmrvytmimlypcswmhvlkxjzbvlallnqzqz
 * Smoking Wheels....  was here 2017 kajxomxdijisztqrklrrxvibivjwfaihihrdsmdtliogbwrq
 * Smoking Wheels....  was here 2017 rsredfpjckxrpcrbgpgjykmhafolodwruhbtbhrcsopbphff
 * Smoking Wheels....  was here 2017 xiaovdohmmdvjrqxlgrfcovqxvkydmjohnkvshmcykltsdzn
 * Smoking Wheels....  was here 2017 ivkihtrgjrrrkdasoogvfzkqbytbjwnqolfevkyrnkhecmxn
 * Smoking Wheels....  was here 2017 ljddfuzyxgmwegnggxmyhrpfwcurylhxpsgxrwrxbjmqrsgm
 * Smoking Wheels....  was here 2017 ajtstgvfktpjkecnnadsswzmzdwbumysrgnivelgkhsmqlly
 * Smoking Wheels....  was here 2017 amafejvfnaokygzvruhkaakwgarqcrxmgfjzbakhsovmkmfq
 * Smoking Wheels....  was here 2017 rqyxbpuhcbxjabqqejeqzxyyucdchvxbcahsmlvyipboryop
 * Smoking Wheels....  was here 2017 navjfrveidpacnusuejfrmxryxjkbbwjgjbpjrjjxhtxjgpb
 * Smoking Wheels....  was here 2017 haemqphqmwtgusjbmxpflzyekftuisbswdszgdwwhqpyrxxp
 * Smoking Wheels....  was here 2017 ziugsotxhzvibyqznlwyuwwuabaqhlypnmnkzpjdpzllavdw
 * Smoking Wheels....  was here 2017 wwrbzcainokqdwzzjznapxtewuzrjaevxwzsqafcfunicdgz
 * Smoking Wheels....  was here 2017 jtdlgwgnjwlxjifuuybfvbygjxwwgqujayyzlrautxduvdme
 * Smoking Wheels....  was here 2017 hlrfoxtkelbcnlgkvyhqwobdcfakxpzleqjnbzqrcjaglmix
 * Smoking Wheels....  was here 2017 qqbmflccodskmohdrzepgwyeysdslnerubnxfsdkjlblhzlz
 * Smoking Wheels....  was here 2017 qfjouyeajxzglgvmveartsqbbucnjhdsqsayawwuxsjiduvl
 * Smoking Wheels....  was here 2017 tivacczuucuivkofayjrmdnruxbtiyuqsfottpjajykbwfrm
 * Smoking Wheels....  was here 2017 ukzrfzzgdhhqjdlhizzsthdctwkqgxkshneqzlompeucrxmq
 * Smoking Wheels....  was here 2017 rdppktrpbeyiyusbxexcbskuvtupiskkvtfendmusskfzrxs
 * Smoking Wheels....  was here 2017 sltegxxfkwixtzwyhskjgciidueiahmmcicdlrmvdclgnrzr
 * Smoking Wheels....  was here 2017 klrwoeurhrjzfnntfzzjklhqbpqvzsrzbyrrafetldgldfwu
 * Smoking Wheels....  was here 2017 lpwpjnrydbfpbptnsrmfuzxweyqgdideanzcvhjzmvohdxbp
 * Smoking Wheels....  was here 2017 wpekagdcoxhxemslztveaezikwuastinkfgyrqdblnflvqhu
 * Smoking Wheels....  was here 2017 xhppbtaojffjuuwbohkvvtptvqzxcwawzlabpfwyrskwzmmm
 * Smoking Wheels....  was here 2017 bxkuiukzsgyrhlyedurbitczwvkvzscduxcoyhdutgmtmvwv
 * Smoking Wheels....  was here 2017 cvctujqfzpoujmxttwlwvicdcfmzirwqblmrghtxpcdoogxl
 * Smoking Wheels....  was here 2017 ztnpwrijubmwzhybqltpvalpkvuuhktwghlajywziqhypqia
 * Smoking Wheels....  was here 2017 yoqrafhxzqkkhlpqisvwfnebxzhairlpdvnmhhtxgiaxibbo
 * Smoking Wheels....  was here 2017 nltmdspksqfctwmfmcflaurjzgdocrxvsunbinbvcavrqwjj
 * Smoking Wheels....  was here 2017 lukxgequjpbwapquefskndmrgjrporkvezlcccobqthpsssy
 * Smoking Wheels....  was here 2017 sijzquyenjiybagrqbidhzniokpqwjjddrnejvkiatilaktb
 * Smoking Wheels....  was here 2017 oyqbwbkybxrtasujjsjdebuacrvjmonlfgjcfpxlrrcegbns
 * Smoking Wheels....  was here 2017 munsusctcoaajoypbrihfjspdrmsciuvmjszyrqqdfayhbee
 * Smoking Wheels....  was here 2017 ghotlsimbwmrtrskuozqrcvfjfzwpclneypccomeimsgjzfx
 * Smoking Wheels....  was here 2017 vdmgcitgmpnxejiathkneuzgrjzhekybtdgbmzmujscswrjt
 * Smoking Wheels....  was here 2017 nfjojaelhusfshfalbvmlegjdjjsiezeakhrexaiqmijnhor
 * Smoking Wheels....  was here 2017 tslfamqtpuafxhbcpgujqeakdvhaqmnwykkbmoryspvjgday
 * Smoking Wheels....  was here 2017 hbgbdtozucpxjlxhhobhaavohmemdqultarmykgambeegvfb
 * Smoking Wheels....  was here 2017 dxqeabmilmunbdywrxrmdgoelkqnzigkyljnjfxecfjmxgwu
 * Smoking Wheels....  was here 2017 odnxfvhembhlezpihlxpvphwuwpvoiqmhcaawyxhwnmgymye
 * Smoking Wheels....  was here 2017 azgtovadzbakcupmwphlcyioqlgipvwttqkbsvxomwzrgwql
 * Smoking Wheels....  was here 2017 gviqcbaciacjosygkapbiqhkqxygzcejqznyljrhuglfcblc
 * Smoking Wheels....  was here 2017 iinodsyfeuymnbvyerwvacatrhibzvbyjhqgwgjexzwnvway
 * Smoking Wheels....  was here 2017 klwvfhnvikfgcmrcqrjgzbpgvxjkyueetaiucmhcfoipekkz
 * Smoking Wheels....  was here 2017 bircenyqzctisvhlolqfinjvmhdhpdndtvjsjibehvgpbaul
 * Smoking Wheels....  was here 2017 zjldbjnnlmusdeoaysluhrynhgcxwfiaqoughemubvharjpv
 * Smoking Wheels....  was here 2017 egybebupjhspgxsaahugnbcvbuwryqbkwmuarwrppuiokgpz
 * Smoking Wheels....  was here 2017 wxfdccrfqpdjfpgbhmzftizhzgihggjafzzvohyliiodausv
 * Smoking Wheels....  was here 2017 qmnzpffbiszundwumoomboywjdssmehvqsdtgsxovfjyjifr
 * Smoking Wheels....  was here 2017 dkkkuktawdkuuqniqihdtxnrxgieotaelogdhqkfzmklsnna
 * Smoking Wheels....  was here 2017 kiqmyvwfvsvoaklvypenkwockrxcroaoctpootndxkoikdip
 * Smoking Wheels....  was here 2017 rffnpbkbckwoibbxypneueftzqhdgnzrirsvabpeapapfjqm
 * Smoking Wheels....  was here 2017 mfmdqtndvplnfmdgjsvzavtncsrizrxpeakzbvflwtdjanrx
 * Smoking Wheels....  was here 2017 nsxdayljiushiupxfqxyjbupgslvukaowsrkflfjjzodzgwi
 * Smoking Wheels....  was here 2017 ukiodvwxgubephrdtgtkkieikqgbwiscwwuqgsrpppgqpizp
 * Smoking Wheels....  was here 2017 oestnwocnpepepvlkuqyyiziqvauqhtzyxhnhpzyzbjtnyxr
 * Smoking Wheels....  was here 2017 igjiywqpeoxfppupzpdkadoniuvxukdedoydpirqdffsrkxw
 * Smoking Wheels....  was here 2017 vaubnslhpelalkmpmkawyxmachephzaypsutskqzxdoygimp
 * Smoking Wheels....  was here 2017 bdubnsoilgeeriercchqidqgvmrjhrwwxncannxrkaferogs
 */
/**
*  snapshot
*  Copyright 2014 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 02.12.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
import java.awt.Container;
import java.awt.Image;
import java.awt.MediaTracker;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrInputDocument;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.feed.RSSFeed;
import net.yacy.cora.document.feed.RSSMessage;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.Html2Image;
import net.yacy.cora.util.JSONException;
import net.yacy.cora.util.JSONObject;
import net.yacy.crawler.data.Snapshots;
import net.yacy.crawler.data.Transactions;
import net.yacy.crawler.data.Snapshots.Revisions;
import net.yacy.document.ImageParser;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.peers.graphics.EncodedImage;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class snapshot {
private final static int DEFAULT_WIDTH = 1024;
private final static int DEFAULT_HEIGHT = 1024;
private final static int DEFAULT_DENSITY = 300;
private final static int DEFAULT_QUALITY = 75;
private final static String DEFAULT_EXT = "jpg";
public static Object respond(final RequestHeader header, serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final boolean authenticated = sb.adminAuthenticated(header) >= 2;
final String ext = header.get(HeaderFramework.CONNECTION_PROP_EXT, "");
        if (ext.equals("rss")) {
if (!authenticated) return null;
int maxcount = post == null ? 10 : post.getInt("maxcount", 10);
int depthx = post == null ? -1 : post.getInt("depth", -1);
Integer depth = depthx == -1 ? null : depthx;
String orderx = post == null ? "ANY" : post.get("order", "ANY");
Snapshots.Order order = Snapshots.Order.valueOf(orderx);
String statex = post == null ? Transactions.State.INVENTORY.name() : post.get("state", Transactions.State.INVENTORY.name());
Transactions.State state = Transactions.State.valueOf(statex);
String host = post == null ? null : post.get("host");
Map<String, Revisions> iddate = Transactions.select(host, depth, order, maxcount, state);
RSSFeed rssfeed = new RSSFeed(Integer.MAX_VALUE);
rssfeed.setChannel(new RSSMessage("Snapshot list for host = " + host + ", depth = " + depth + ", order = " + order + ", maxcount = " + maxcount, "", ""));
for (Map.Entry<String, Revisions> e: iddate.entrySet()) {
try {
DigestURL u = e.getValue().url == null ? sb.index.fulltext().getURL(e.getKey()) : new DigestURL(e.getValue().url);
if (u == null) continue;
RSSMessage message = new RSSMessage(u.toNormalform(true), "", u, e.getKey());
message.setPubDate(e.getValue().dates[0]);
rssfeed.addMessage(message);
} catch (IOException ee) {
ConcurrentLog.logException(ee);
}
}
byte[] rssBinary = UTF8.getBytes(rssfeed.toString());
return new ByteArrayInputStream(rssBinary);
}
        if (post == null) post = new serverObjects();
final boolean xml = ext.equals("xml");
final boolean pdf = ext.equals("pdf");
        if (pdf && !authenticated) return null;
final boolean pngjpg = ext.equals("png") || ext.equals(DEFAULT_EXT);
String urlhash = post.get("urlhash", "");
String url = post.get("url", "");
DigestURL durl = null;
        if (urlhash.length() == 0 && url.length() > 0) {
try {
durl = new DigestURL(url);
urlhash = ASCII.String(durl.hash());
} catch (MalformedURLException e) {
}
}
        if (durl == null && urlhash.length() > 0) {
try {
durl = sb.index.fulltext().getURL(urlhash);
} catch (IOException e) {
ConcurrentLog.logException(e);
}
}
        if (url.length() == 0 && durl != null) url = durl.toNormalform(true);
        if (ext.equals("json")) {
String command = post.get("command", "metadata");
String statename = post.get("state");
JSONObject result = new JSONObject();
try {
if (command.equals("status")) {
JSONObject sizes = new JSONObject();
for (Map.Entry<String, Integer> state: Transactions.sizes().entrySet()) sizes.put(state.getKey(), state.getValue());
result.put("size", sizes);
} else if (command.equals("list")) {
if (!authenticated) return null;
String host = post.get("host");
String depth = post.get("depth");
int depthi = depth == null ? -1 : Integer.parseInt(depth);
for (Transactions.State state: statename == null ?
new Transactions.State[]{Transactions.State.INVENTORY, Transactions.State.ARCHIVE} :
new Transactions.State[]{Transactions.State.valueOf(statename)}) {
if (host == null) {
JSONObject hostCountInventory = new JSONObject();
for (String h: Transactions.listHosts(state)) {
int size = Transactions.listIDsSize(h, depthi, state);
if (size > 0) hostCountInventory.put(h, size);
}
result.put("count." + state.name(), hostCountInventory);
} else {
TreeMap<Integer, Collection<Revisions>> ids = Transactions.listIDs(host, depthi, state);
if (ids == null) {
result.put("result", "fail");
result.put("comment", "no entries for host " + host + " found");
} else {
for (Map.Entry<Integer, Collection<Revisions>> entry: ids.entrySet()) {
for (Revisions r: entry.getValue()) {
try {
JSONObject metadata = new JSONObject();
DigestURL u = r.url != null ? new DigestURL(r.url) : sb.index.fulltext().getURL(r.urlhash);
metadata.put("url", u == null ? "unknown" : u.toNormalform(true));
metadata.put("dates", r.dates);
assert r.depth == entry.getKey().intValue();
metadata.put("depth", entry.getKey().intValue());
result.put(r.urlhash, metadata);
} catch (IOException e) {}
}
}
}
}
}
} else if (command.equals("commit")) {
if (!authenticated) return null;
Revisions r = Transactions.commit(urlhash);
if (r != null) {
result.put("result", "success");
result.put("depth", r.depth);
result.put("url", r.url);
result.put("dates", r.dates);
} else {
result.put("result", "fail");
}
result.put("urlhash", urlhash);
} else if (command.equals("rollback")) {
if (!authenticated) return null;
Revisions r = Transactions.rollback(urlhash);
if (r != null) {
result.put("result", "success");
result.put("depth", r.depth);
result.put("url", r.url);
result.put("dates", r.dates);
} else {
result.put("result", "fail");
}
result.put("urlhash", urlhash);
} else if (command.equals("metadata")) {
try {
Revisions r;
Transactions.State state = statename == null || statename.length() == 0 ? null : Transactions.State.valueOf(statename);
if (state == null) {
r = Transactions.getRevisions(Transactions.State.INVENTORY, urlhash);
if (r != null) state = Transactions.State.INVENTORY;
r = Transactions.getRevisions(Transactions.State.ARCHIVE, urlhash);
if (r != null) state = Transactions.State.ARCHIVE;
} else {
r = Transactions.getRevisions(state, urlhash);
}
if (r != null) {
JSONObject metadata = new JSONObject();
DigestURL u;
u = r.url != null ? new DigestURL(r.url) : sb.index.fulltext().getURL(r.urlhash);
metadata.put("url", u == null ? "unknown" : u.toNormalform(true));
metadata.put("dates", r.dates);
metadata.put("depth", r.depth);
metadata.put("state", state.name());
result.put(r.urlhash, metadata);
}
} catch (IOException |IllegalArgumentException e) {}
}
} catch (JSONException e) {
ConcurrentLog.logException(e);
}
String json = result.toString();
if (post.containsKey("callback")) json = post.get("callback") + "([" + json + "]);";
return new ByteArrayInputStream(UTF8.getBytes(json));
}
        if (durl == null) return null;
        if (xml) {
Collection<File> xmlSnapshots = Transactions.findPaths(durl, "xml", Transactions.State.ANY);
File xmlFile = null;
if (xmlSnapshots.size() == 0) {
return null;
}
xmlFile = xmlSnapshots.iterator().next();
try {
byte[] xmlBinary = FileUtils.read(xmlFile);
return new ByteArrayInputStream(xmlBinary);
} catch (IOException e) {
ConcurrentLog.logException(e);
return null;
}
}
        if (pdf || pngjpg) {
Collection<File> pdfSnapshots = Transactions.findPaths(durl, "pdf", Transactions.State.INVENTORY);
File pdfFile = null;
if (pdfSnapshots.size() == 0) {
if (!authenticated) return null;
SolrDocument sd = sb.index.fulltext().getMetadata(durl.hash());
boolean success = false;
if (sd == null) {
success = Transactions.store(durl, new Date(), 99, false, true, sb.getConfigBool(SwitchboardConstants.PROXY_TRANSPARENT_PROXY, false) ? "http://127.0.0.1:" + sb.getConfigInt(SwitchboardConstants.SERVER_PORT, 8090) : null, sb.getConfig("crawler.http.acceptLanguage", null));
} else {
SolrInputDocument sid = sb.index.fulltext().getDefaultConfiguration().toSolrInputDocument(sd);
success = Transactions.store(sid, false, true, true, sb.getConfigBool(SwitchboardConstants.PROXY_TRANSPARENT_PROXY, false) ? "http://127.0.0.1:" + sb.getConfigInt(SwitchboardConstants.SERVER_PORT, 8090) : null, sb.getConfig("crawler.http.acceptLanguage", null));
}
if (success) {
pdfSnapshots = Transactions.findPaths(durl, "pdf", Transactions.State.ANY);
if (pdfSnapshots.size() != 0) pdfFile = pdfSnapshots.iterator().next();
}
} else {
pdfFile = pdfSnapshots.iterator().next();
}
if (pdfFile == null) return null;
if (pdf) {
try {
byte[] pdfBinary = FileUtils.read(pdfFile);
return new ByteArrayInputStream(pdfBinary);
} catch (IOException e) {
ConcurrentLog.logException(e);
return null;
}
}
if (pngjpg) {
int width = Math.min(post.getInt("width", DEFAULT_WIDTH), DEFAULT_WIDTH);
int height = Math.min(post.getInt("height", DEFAULT_HEIGHT), DEFAULT_HEIGHT);
String imageFileStub = pdfFile.getAbsolutePath(); imageFileStub = imageFileStub.substring(0, imageFileStub.length() - 3);
File imageFile = new File(imageFileStub + DEFAULT_WIDTH + "." + DEFAULT_HEIGHT + "." + ext);
if (!imageFile.exists() && authenticated) {
Html2Image.pdf2image(pdfFile, imageFile, DEFAULT_WIDTH, DEFAULT_HEIGHT, DEFAULT_DENSITY, DEFAULT_QUALITY);
}
if (!imageFile.exists()) return null;
if (width == DEFAULT_WIDTH && height == DEFAULT_HEIGHT) {
try {
byte[] imageBinary = FileUtils.read(imageFile);
return new ByteArrayInputStream(imageBinary);
} catch (IOException e) {
ConcurrentLog.logException(e);
return null;
}
}
Image image;
try {
image = ImageParser.parse(imageFile.getAbsolutePath(), FileUtils.read(imageFile));
if(image == null) {
	/* Should not happen. If so, ImageParser.parse() should already have logged about the error */
	return null;
}
final Image scaled = image.getScaledInstance(width, height, Image.SCALE_AREA_AVERAGING);
final MediaTracker mediaTracker = new MediaTracker(new Container());
mediaTracker.addImage(scaled, 0);
try {mediaTracker.waitForID(0);} catch (final InterruptedException e) {}
return new EncodedImage(scaled, ext, true);
} catch (IOException e) {
ConcurrentLog.logException(e);
return null;
}
}
}
return null;
}
}
