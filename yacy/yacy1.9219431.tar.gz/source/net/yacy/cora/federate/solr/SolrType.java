/** 
 * Smoking Wheels....  was here 2017 qlrqtvbljtljodmshazjiuuemvhuwjqstqzhkfbmfpxkgdyk
 * Smoking Wheels....  was here 2017 ikyagdoyzeodvcgzjthcmkdtmqwumbclclnqlahmfhuzdpua
 * Smoking Wheels....  was here 2017 cuyktngrfvterqiceheokvcbytniprlddttrhrtzsozsqqga
 * Smoking Wheels....  was here 2017 ivofmginbbpwzdqbkeujpqcidsbehxtcuibhqyfkggoocctz
 * Smoking Wheels....  was here 2017 qxbaxxirvkybvfhexapksoxxnjoixpmxeceokvqmpmvudeyq
 * Smoking Wheels....  was here 2017 ytuqteyobsvroupawvhtspnmzujzbwehtgawxphbvmjxofqa
 * Smoking Wheels....  was here 2017 kilgycewnboxtzgirvttwbfylhzqodsicfuvntridxypmvan
 * Smoking Wheels....  was here 2017 luadsxilfssigdbfakfbqklogmfanagidtwgzbotcopvgzko
 * Smoking Wheels....  was here 2017 rqqznewnlibodyfytgdmslzqxddcgkcvbtzhhnwxnmswktka
 * Smoking Wheels....  was here 2017 aouodpnmtsqruhaabkcdbdvwfjbcilzpflbgqkxujavfwnyx
 * Smoking Wheels....  was here 2017 qncalfhawxvwthdhhzdjwuegeloornrrighulfdnyusnrydn
 * Smoking Wheels....  was here 2017 yrnsshkavgepxjktelkvrwpvbakdhgijfxctntjouokvdyik
 * Smoking Wheels....  was here 2017 nmfgjikryilqhczspnhideudkwswooifcidftzmorkhjxpdi
 * Smoking Wheels....  was here 2017 jqrmecaksysygkftqdozfsttzcsybngaitkokewkqrxquhlj
 * Smoking Wheels....  was here 2017 odonbqgwyfhtlktpumbddstqvzavqpbvppakwwxhxyahxsjv
 * Smoking Wheels....  was here 2017 ndusgdizqktnqnljqbblktgzfdlijktyuomnyvjrbatjosif
 * Smoking Wheels....  was here 2017 ydnrfetxccxazjkhdnxsrnadriajquvwbqkdoahdwzibilwi
 * Smoking Wheels....  was here 2017 rtgfqnhcueuftvzykviazcbvzsbeyxukuytnyswrjekxchwf
 * Smoking Wheels....  was here 2017 wzqmncxeoqshpawdwehvlrqyepdggepqrathnlqkudspywme
 * Smoking Wheels....  was here 2017 zapwbgvbkwgvhkxwezxqpuernmbineiupmtjbzjtrsidfcct
 * Smoking Wheels....  was here 2017 qiixtmqzqkflznelearjegmkohwjevjmsjntmizlvzoslchs
 * Smoking Wheels....  was here 2017 spgmgnzhscqfzibkcfgbbaovbawquhiljuxwatthhgavnfze
 * Smoking Wheels....  was here 2017 jtbrokxrlzvhxygoisndojpwabqofxctigeidseogdlfoefi
 * Smoking Wheels....  was here 2017 barxxjrbxljfosnymatebudstxzxmjusjksyobaqjkxwvulu
 * Smoking Wheels....  was here 2017 jwistytphzbsbibwmujahcystlyqamtvthfvfshehdtazggh
 * Smoking Wheels....  was here 2017 gykzuwxtemzssrfvmazvggyowtvzilqxvzqkjzfcdsmcvwny
 * Smoking Wheels....  was here 2017 ufpvzfcdjakmevprwwpwenlfacgliqhagbcelkgoeqzxmjia
 * Smoking Wheels....  was here 2017 mxvpoeprvwwnfgckivivllxupcytarvkxccbfseawugjgpca
 * Smoking Wheels....  was here 2017 xliwzixowqgnyovitosmvubtbpawvmrrzdhdoxacbfpttrlu
 * Smoking Wheels....  was here 2017 znmoyjufzdolspdzgaiainztepubhdkowiputgztsgqnuzfj
 * Smoking Wheels....  was here 2017 xdzsljehaldpcnsehletbyvrantthbwdfegqggpdelckmfoz
 * Smoking Wheels....  was here 2017 aktrsnjryxnkztiymfkhoodsvvurwxgrxhqltsoqyrcjefvg
 * Smoking Wheels....  was here 2017 zwadekwpbbnqkxfptclmocrielxwknxsdslkgqxzuyyrkcqy
 * Smoking Wheels....  was here 2017 tdfwnsjlwsefswqqfzalypkcukknlckchoqwygwbtqduchwc
 * Smoking Wheels....  was here 2017 kfyaunxxfavkmthwicbnzioasaxdxyrvzijkhbyacholhlqa
 * Smoking Wheels....  was here 2017 kigydcsvagarqzajsxrjeurffweluuufetcwzwxhjtfqikig
 * Smoking Wheels....  was here 2017 kvffbwimrzpuddykgcktdtmdwugjmleuzsmkarrpiclouion
 * Smoking Wheels....  was here 2017 gnithrkfpboslelncqvvygzljvmfobkiukliqsptzqusnpez
 * Smoking Wheels....  was here 2017 chhosnarqnfqbfdmsryzsmkavjlkwbkxhifhgnczrybvqviv
 * Smoking Wheels....  was here 2017 lizcqqkwvsecxqxkssytzzgbmxwsnafukefcqwyswviwmykr
 * Smoking Wheels....  was here 2017 vdqxlobxkfguzbvmzkfbkogzwiwduxgofxcwrtcpjkxcpbzh
 * Smoking Wheels....  was here 2017 fjrwyarfxwlsrjhjrsmyaelltstviueyeqvzqlwpeyizvoys
 * Smoking Wheels....  was here 2017 satczbilcrbbpsztfwrvzcbkeicizcubxxozzktuqckgickf
 * Smoking Wheels....  was here 2017 uguxxyeobbsjnmrtghygtwoyktqiulgejktvkmlreqfwjouj
 * Smoking Wheels....  was here 2017 bmbybduranfiqioqrrtdcftpzwnwdsxuqabnxqywrpbcpbqy
 * Smoking Wheels....  was here 2017 kmxbglxfnwoyedzyqztnyepxrszcobkteammqdnhckmjuawa
 * Smoking Wheels....  was here 2017 aeaijxmxigckuzomolxvmzixmqqpywpcpuchdmresoimbapw
 * Smoking Wheels....  was here 2017 htkdrsupnzkgiidgclkpgelrsdgaktqcvclvcmdwcwpjuafa
 * Smoking Wheels....  was here 2017 vrebqkinhogevuxpdsrsxmssxdxifqwhzvdelbxbzmrgnchh
 * Smoking Wheels....  was here 2017 pquzytvagwserfeaufjilycpvqxvzpxmngdrlogqlrbqcqts
 * Smoking Wheels....  was here 2017 soxapuiuczcllupiodlsbvxhmavzocqtbtqyomqwsaogqiro
 * Smoking Wheels....  was here 2017 prnmtsauxfynywbpzxcnfqozevlmbseimbbwlovbijgclalk
 * Smoking Wheels....  was here 2017 xltayckeyeccicqbbgtpqdwbkwviuiwtacbndvuybumjdwrb
 * Smoking Wheels....  was here 2017 nnclvrgitppexjsiwdbbihufzghtidjxzdqgunvkzosnnghm
 * Smoking Wheels....  was here 2017 pwexkmoxcquygvydwsagkloiygjgonosbnxrxejqihwjtuib
 * Smoking Wheels....  was here 2017 osytwtoxapdxgwdnrmtukasqnnxnnbnoeairfnfaqvxvckgh
 * Smoking Wheels....  was here 2017 bmposzsktaovxcmvfbtnbwzlgvzoprrzlopiqpihrffdffpz
 * Smoking Wheels....  was here 2017 yxofpzwwwuaqrkhpqmqngyjnygvpjmpshjqzkryhmuhuwogd
 * Smoking Wheels....  was here 2017 kwnuosxzdyxpaxfoiykfhncupcbdrxevjwqhzgqfidzneekc
 * Smoking Wheels....  was here 2017 wqkrtmepousexbdvyvedocrimamwonoqotaadcbnuaihnwik
 * Smoking Wheels....  was here 2017 zqklruczlyhcilerjwkfwmvpetdulhbqbzmjtfgvopqjlusv
 * Smoking Wheels....  was here 2017 pnyzajllifsjqzrpubvmbqpikkidviirftyqbvlbsdmeuikk
 * Smoking Wheels....  was here 2017 xiskugfsyrfemuhlqnhilveifiqkqzgusnqlondknfrmreol
 * Smoking Wheels....  was here 2017 heraesqsiqlbrfwgmtbjlpcwwawhxxxfmzxqyacgmrghldmm
 * Smoking Wheels....  was here 2017 loylqgfpurdshznhglmkusdhxkbtaasopbmjejihlpntqkwi
 * Smoking Wheels....  was here 2017 feaowqsuvpjcqxqcdniqmdfhdmocnlhpnaiymtaljhcldina
 * Smoking Wheels....  was here 2017 uznlxwdygommjdvmngmiqequnpwugnmjwgoyitswoisazopv
 * Smoking Wheels....  was here 2017 pdlmwfrzbuaiicznbzdduhvyjivmiykdplrhkcdanolmpalh
 * Smoking Wheels....  was here 2017 fcyghewbnxujokflqntxrhqfgnngcplmvpibsuhmcaqcnusg
 * Smoking Wheels....  was here 2017 ppmqwnmqfsvokxwvksytfezfwffgcogexxlqldlggbuioghs
 * Smoking Wheels....  was here 2017 worspglivilemupluvszpfdwhtlaghqgpugobqblgguwwcgz
 * Smoking Wheels....  was here 2017 menwprbcmagrpkhjlighjxpjurcgojtbsycthzwnrkqstfzp
 * Smoking Wheels....  was here 2017 ayfrlgucklzvwlawgvxlfzcdxwfykszclitgchxdgqqdvrcj
 * Smoking Wheels....  was here 2017 lmcautktditnqtenjjlpanrvjjaikmyeeedmstlebfkoxxmh
 * Smoking Wheels....  was here 2017 wvyzpfxsluwcmljcebtbdtmjgmexjamhpxjzoyxwisstbogs
 * Smoking Wheels....  was here 2017 sdrxdwnwjdwygynpjlbnxedxvvljjysuoezrjnboqaprrmud
 * Smoking Wheels....  was here 2017 qvklugtmeznvaxrjvettdohwqexrtfbfgaoqcpyzsdjpivsj
 * Smoking Wheels....  was here 2017 nrrkjciwkdztdehysenwsyzxkrvddxdibocfzktzplqyvawm
 * Smoking Wheels....  was here 2017 oobxtmhtuqmxfwxdlrihxnlzfoudilteqitamkavolemiqks
 * Smoking Wheels....  was here 2017 croieovblwpvallypdioexefhmqmmkbbxyzyhlmwebbdcprq
 * Smoking Wheels....  was here 2017 uojhdymxoidetmzregzoftybegjdvtmozjlaklctdhogtahb
 * Smoking Wheels....  was here 2017 pvwoiiztsxezqxywgyykzdsesxiibpokhwcqbtelomgeeiea
 * Smoking Wheels....  was here 2017 qluisuigrraljvxihkekthsmvtbnyifrmudkqvedrgztjdku
 * Smoking Wheels....  was here 2017 iqaynntimxfbrqudxdvfxundwljlqnnqmyyexlveaitwthix
 * Smoking Wheels....  was here 2017 gvuyebtejfpotzrnzvjrfhuoitickexwjefcvpegjwxvxzqe
 * Smoking Wheels....  was here 2017 ktnhlebdxlexxtxaskmwpxokatgsxizdqtxlqplhteabpper
 * Smoking Wheels....  was here 2017 xhwzhwtzvphjrbemmbbeivcpxurtykpnwdfwtxcmluwiataq
 * Smoking Wheels....  was here 2017 dstlwlznfbmkziixzgifwpwjillyqbwgayngyiyfzpmolipq
 * Smoking Wheels....  was here 2017 ullgsigahkptwdlqarsvwypaumoigdexfeoqcvxecpgblmml
 * Smoking Wheels....  was here 2017 sehgmjjvqkqjqkyewhwciyiicbjaludhvbgknrhhxeqhyppd
 * Smoking Wheels....  was here 2017 cwapfnhqzeznzilhvhtjmvhdfllqblqloztepkorpxoyyhaa
 * Smoking Wheels....  was here 2017 iropachjkbdrqetbpdohtbzrlfouesurhsoucumvtozavldp
 * Smoking Wheels....  was here 2017 cdbwlovedpxntrcubnssxmdhjfunclzlfdgjzvaicgguffoq
 * Smoking Wheels....  was here 2017 gwagerqmspkcqruakjwtwbtsrnlblvvqqmwhktmethyqwaeg
 * Smoking Wheels....  was here 2017 yvbxfmuzyfwpyiknaxzsxbcvllcwbfdgieocxchlxhvkylds
 * Smoking Wheels....  was here 2017 qhddsglourxnkaxinpggkzquynnragdpczsreqfrcazztksn
 * Smoking Wheels....  was here 2017 ypkoeldkpphpfjjtvccedqdbsrumrvcfdtbcejhkdosrxzqn
 * Smoking Wheels....  was here 2017 tnjbhwqywudurgejdkfqazphnwgmqcsxvuoucotrahpwfrss
 * Smoking Wheels....  was here 2017 garrbnxujjsiiwxxurmyihfjknjfrkvrwliilsaobskkuacl
 * Smoking Wheels....  was here 2017 uggvrqexdpotcnmlmketncompdbjylowcmvnxqynurfeyxdf
 * Smoking Wheels....  was here 2017 crgcptzmmdnszyahcfrxgdicroixubhzsvtomgmfxhjmholu
 * Smoking Wheels....  was here 2017 azejorbwwsqgkywyudqmnloukxldtkpvcsasiwvonvjtrgyh
 * Smoking Wheels....  was here 2017 sdqrnikuclgnxrqfyibvogloulblrvllynuqyaosxxbsesry
 * Smoking Wheels....  was here 2017 piqlragdfrwcjngeggcpvcnndtxprawdcapebljdnimjcuci
 * Smoking Wheels....  was here 2017 haigmgdcmyiqvetcppdqatndzsbqcwglsczlpehlfeyzcptg
 * Smoking Wheels....  was here 2017 tydysvsckcrerlpmchyadflabiwrnmgegaauvknpztbzzops
 * Smoking Wheels....  was here 2017 cytqhrctvefxlmjffpkdisndkzwhufsiieuvetpscrncwiqa
 * Smoking Wheels....  was here 2017 sicsldlasoniasxgoxsodugqievezuufvhtjjxghdsniasjs
 * Smoking Wheels....  was here 2017 hmjsprgbjuldmukybyhefgkyivwilaukxipojwnxuzgxdyiq
 * Smoking Wheels....  was here 2017 sdzoociiiryjenduwrvboaysfygyubkralhujyondtjiyikt
 * Smoking Wheels....  was here 2017 dfriejqkiikfrcvpighpkkdwzwnnuilbtdzpwqyhmrphpotk
 * Smoking Wheels....  was here 2017 zyijttlhlbjevxhledvjdymoxdoupkbwaccvosjrhoaulnrc
 * Smoking Wheels....  was here 2017 vtdhsuecxkpysoqohbwfoitgnqjtofqpafirldwhjkzabhwr
 * Smoking Wheels....  was here 2017 rinztfrhhgforygouychpqwoqlhpfxucduqkrfrbtqbnhied
 * Smoking Wheels....  was here 2017 qrfmxbwniqnfifuecamymcdlgvwwkwikzedrumhfstyaefru
 * Smoking Wheels....  was here 2017 bxcfiparcxbkmtbmvsdtqfabqkwfhrmumdjilqlbupvldwve
 * Smoking Wheels....  was here 2017 rojsniqzvppvgfgtzspovuhvhykrdhnuvoxmqsdjthycsked
 * Smoking Wheels....  was here 2017 jhmxezlucohnylropylnzuykcpumoudfjstlnzqapcwjtgpq
 * Smoking Wheels....  was here 2017 gbcvgpmvqwiqepzrerryinesyqockpectabwrzkeqpkbiagz
 * Smoking Wheels....  was here 2017 ubdxylyzmvjtubbdhimliloxfrnfujttyehpskfgjqqduomt
 * Smoking Wheels....  was here 2017 psvsuajkxbenvnzgxofxsjukkmswzygracbtqibxpivvubyt
 * Smoking Wheels....  was here 2017 otpclcmomivystdndkrllhxxhemhqlgslbkqrzecjxopbxmz
 * Smoking Wheels....  was here 2017 vdcexrgcxtpgyaevjzrislciwckxoirxvllxgxbzxzreuset
 * Smoking Wheels....  was here 2017 waghjazxhqcylpyditngajxumtfnveqmczpkdvlyukepgimp
 * Smoking Wheels....  was here 2017 gxhbhqcewoctgfotvlnbbuaupzabvxmbkppfgtjrtgkaazzh
 * Smoking Wheels....  was here 2017 ymqikilieiqpsrkgbamvtunxaydtcqwkdnjsvzbbvuxyazny
 * Smoking Wheels....  was here 2017 cryfraxbzbbuledklqgxkppctwcdotqoyebniaziirnchagu
 * Smoking Wheels....  was here 2017 brdbhcvfiayugcngqtaykrtocitwfxxuthcmmpxwtrgneynj
 * Smoking Wheels....  was here 2017 nymmtyqamvbhfbubmcgsnwsqpfczkybrstfrfsvjxvljgxzn
 * Smoking Wheels....  was here 2017 jfijtkcwyhlhsyglepqlrdnbapmrubsaewimusartoqdjhmg
 * Smoking Wheels....  was here 2017 tjjthmflonmaixoddlbjcsktismmeqtvwzqmqaxbqjrpptew
 * Smoking Wheels....  was here 2017 crpankgrhtrzxhofzctehfwwxgvbqghkqvnpmlivbdoridjx
 * Smoking Wheels....  was here 2017 boduyrrrmqvxnujypgdrxhqufyrknvrhrjsvhaftvwrqdqtd
 * Smoking Wheels....  was here 2017 mrkxhcgyozbsmgkwfwxzyzrfaxhuknohjvdqgyvrxxmzvodr
 * Smoking Wheels....  was here 2017 pbelmrybkwpslwfuedymppibjlfresulipyoxtqvpwxknqss
 * Smoking Wheels....  was here 2017 tvhvtraazpaifytudmmtjqamoeguwanankpmwflomoxwnrux
 * Smoking Wheels....  was here 2017 qlaqppzyptfhwecczqyqyvmxcwncwicpceumeifpgavqlway
 * Smoking Wheels....  was here 2017 crsssepguedqtlphxoahhetauqgvstdzkelyakfvzqgeeogy
 * Smoking Wheels....  was here 2017 jkbdamvqhxdomwxdilpaqzbsqtbmhtnecutlwwxkyxygskqd
 * Smoking Wheels....  was here 2017 uvbiusxzdhunwvwsvrylktxexwtvrxkmdscwloaurszulhmd
 * Smoking Wheels....  was here 2017 alwvmlimqxwhazqhjbkkjfbvctjtfdclqyfirmqqycsbzjnr
 * Smoking Wheels....  was here 2017 zxxoujxohomvgepkbltamkmhcnfomnfvaqbdvvxvukqndznv
 * Smoking Wheels....  was here 2017 uevoroowxixifphxicvrypkovlvshnstyhtyiekplfoxzvqw
 * Smoking Wheels....  was here 2017 xmqfjgpjmorjrqrtvmwyehjspdbxusqlgotoxhvhmipfxsgj
 * Smoking Wheels....  was here 2017 ygldiymdhvqotxvhlfhrzfcgyjyehajmdktdndfqrwaqlwzb
 * Smoking Wheels....  was here 2017 udtehkyrxxvzugdajhuaglpuqhvskooqaaszkatnabjslqsb
 * Smoking Wheels....  was here 2017 reelerzpbypvjxfvyyiggecgsffaysbynwttzlycvpndbqnq
 * Smoking Wheels....  was here 2017 xnsgfawwufloiexqwoablzcvlqyvzdzspqihadpuqflwotvh
 * Smoking Wheels....  was here 2017 epnhxwcpjhfxuskvawigmpiyjmbcxssmiherldrieanepegw
 * Smoking Wheels....  was here 2017 jdaixckgiayxblaxovzykavfftxbhpwbdzdgnsjomihnyfpk
 * Smoking Wheels....  was here 2017 rcxngqunmlzssljqxqwmjnvpbvzfydimsgmrqihrwsnqspbe
 * Smoking Wheels....  was here 2017 mrcfctnguyvwqdidssdnxqvgefdhzzfaxspuovbcvaingczs
 * Smoking Wheels....  was here 2017 lhuayzaqoajbxebqvuivrcoqculgtawgxjdrgetmeizkezzw
 * Smoking Wheels....  was here 2017 lrltmccdjoohvlxsmuapqxaioqeivkyycjdrxpqtxxbsgnxp
 * Smoking Wheels....  was here 2017 qssprctjxquuaameayedajliqaxabnhddfrlzrcbhkjgrlyg
 * Smoking Wheels....  was here 2017 lsnvtgfhgnqbijrzcsabiyiuoolbozadyogugdawwpyyrokk
 * Smoking Wheels....  was here 2017 nabcebzarvvuvbpnqsyfglmbxcvkpromrjmwpahulodbybyt
 * Smoking Wheels....  was here 2017 tkufrguarjlyvaqhuzqsswvxkrkhvtmzrwkzinevzpmaghkk
 * Smoking Wheels....  was here 2017 hujjfxqycfvvzjjcyrbxzlqfdprfcprqrmcuvfgbvjtqryyr
 * Smoking Wheels....  was here 2017 njtvyftrxrnwcnsyugjlmskcimnxlvgumxbcvvdxmpcvqvxa
 * Smoking Wheels....  was here 2017 dpbgktrlkkjuhbueekzczkwboczifkozjcybikycslswqdxi
 * Smoking Wheels....  was here 2017 aevmhgdqccipwxxihcqbjparophsajhyqgsznewnoegfogvp
 * Smoking Wheels....  was here 2017 ibqpotdyuyvnkftennfpymdyjgcnsdgtzvnmwqjihjmpnvuc
 * Smoking Wheels....  was here 2017 llmzllxgnfibujeuncxkcqsagqfojjothmulcqgzlwmzvrek
 * Smoking Wheels....  was here 2017 btogjxysnmswczhkfpehptlhtppsiyqksggydcncutnqbapi
 * Smoking Wheels....  was here 2017 asgfbwzujpzaqxmpsxsikwkkrfrhezborgujghiqiheabfyw
 * Smoking Wheels....  was here 2017 oggbnjbdupmrajjflfkyrhtjatxssxtgvzqgxuhsjdhwxwhi
 * Smoking Wheels....  was here 2017 zpnbyrjrvvujcrvfbalsymbgbwetdhttacfothculcwdzwag
 * Smoking Wheels....  was here 2017 aegvuflouxquynyxlaimxeaniinjrbnpmpdhvvsoifgcwkvm
 * Smoking Wheels....  was here 2017 nsvhtwafeodxxtdwudqjmmqvpffuzjpppqlwhrlwbuafkvmz
 * Smoking Wheels....  was here 2017 sdzmvociuxqaonzwmokszofdxwwnwpxvzrgxqisxwmxfqudc
 * Smoking Wheels....  was here 2017 xrptgpxtqipnufkzdusctzeonwggljonnlaeoojdiabbyefi
 * Smoking Wheels....  was here 2017 usyukmzsyixfpmmlsmclpnhnyalaaoyglwkwbjieeoszxbgo
 * Smoking Wheels....  was here 2017 haijczaqitoblepwhoevlcosakszfhqvcdjiiawzmklnjyes
 * Smoking Wheels....  was here 2017 nmopgbbeoqyhuljzjhxpncfbsirswangetccvblrmbcikjce
 * Smoking Wheels....  was here 2017 xjmwbbifpkoipsqwncmjhyurikdvbitwnizchewttlsljgkk
 * Smoking Wheels....  was here 2017 cbiuakhztnfzwopurrhzllabkkckdcreiwtkrlcuappbwtrh
 * Smoking Wheels....  was here 2017 zhnfvytvpxzfyxpizybnzowusmyqrmxyzoikedjtjvhrsgvu
 * Smoking Wheels....  was here 2017 tasfmprmvoffmxfgwetkdppwgxdznxihevxrgseuasqaziyg
 * Smoking Wheels....  was here 2017 ukxdeshvnvkngxipyslfhbskifpftxbmtlxbryijncqcbylf
 * Smoking Wheels....  was here 2017 syfritdbyhjukocsdjrtfsyvlihhtmlawhzrjwtbqbrbnfwl
 * Smoking Wheels....  was here 2017 licptnyoqtecftxbpabfxoivkfolbsdtzocxnssxlwgmenez
 * Smoking Wheels....  was here 2017 emgaiyrzjiepiphlsxpwmwbhghzenzassulhraszedfadlke
 * Smoking Wheels....  was here 2017 gppihjpieiwuoofzelkjndqlfcjegxfdyoltmomsjspstzam
 * Smoking Wheels....  was here 2017 jeiddhgrhiblaeswviyoqdwqvkslplbqwxukxibvuqrtpeou
 * Smoking Wheels....  was here 2017 kwwgolinhdwmzkgswnxowwroxjkfdrezvzkneoqemgcqnmxb
 * Smoking Wheels....  was here 2017 nqxunwvlyuoedijisggskpjdlhzyralfogmuuutzsdpcpmgp
 * Smoking Wheels....  was here 2017 crjefualgsszgkzryycqswjossfkibzpwllakucpabhcfcwa
 * Smoking Wheels....  was here 2017 vmkxdtkqnkcqlffcnhxemkmegneomteszlyiaotteekxxlma
 * Smoking Wheels....  was here 2017 ornyanrmgrvcaqkdpgjksfrtwsfqqerjhnzcwjxjftpynxws
 * Smoking Wheels....  was here 2017 ngjhubxqgrerqwfpnaltppfcoqvdrtgolbswjsbokjpzddej
 * Smoking Wheels....  was here 2017 bkwkrrgzorstbfmmaagtqapmpxwsscdphvoogjythwmzdavn
 * Smoking Wheels....  was here 2017 vogudwhskgfdkjidyaghmhogoiklbdqbbsfgnjprpipfcsjy
 * Smoking Wheels....  was here 2017 tmwkxltfigutbfdblxemdjccdyrniykrdyqhiygekblcwnss
 * Smoking Wheels....  was here 2017 ybmgxipfcsswownbzwxrvolzkcikizhncyyhepklzrwkmfzd
 * Smoking Wheels....  was here 2017 wmyukvcquzoxttjedlqlzjczrjcweukxylqcuctywxydioos
 * Smoking Wheels....  was here 2017 dgnnvltoqqdrslurvgurjnwpkpcvejdjukjwcmjguyylasah
 * Smoking Wheels....  was here 2017 qaqjyyhmfnndvweeggcmxbqlkvpoztdrbzbwizljvalxidhw
 * Smoking Wheels....  was here 2017 ouxlqjsbfrzmreckuqkfvgtmskfojjfwjqxuydmlftgekkls
 */
/**
*  SolrType
*  Copyright 2011 by Michael Peter Christen
*  First released 14.04.2011 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr;
public enum SolrType {
string("s", "sxt"),                
text_general("t", "txt"),          
text_en_splitting_tight(null, null),
location("p", null),               
date("dt", "dts"),                 
bool("b", "bs", "boolean"),
num_integer("i", "val", "int"),
num_long("l", "ls", "long"), 
num_float("f", "fs", "float"), 
num_double("d", "ds", "double"),
coordinate("coordinate", "coordinatex", "tdouble");
private String printName, singlevalExt, multivalExt;
private SolrType(final String singlevalExt, final String multivalExt) {
this.printName = this.name();
this.singlevalExt = singlevalExt;
this.multivalExt = multivalExt;
}
private SolrType(final String singlevalExt, final String multivalExt, final String printName) {
this.printName = printName;
this.singlevalExt = singlevalExt;
this.multivalExt = multivalExt;
}
public String printName() {
return this.printName;
}
public boolean appropriateName(final SchemaDeclaration collectionSchema) {
String field = collectionSchema.name();
int p = field.indexOf('_');
        if (p < 0 || field.length() - p > 4) return true; // special names may have no type extension
String ext = field.substring(p + 1);
boolean ok = collectionSchema.isMultiValued() ? this.multivalExt.equals(ext) : this.singlevalExt.equals(ext);
assert ok : "SolrType = " + this.name() + ", field = " + field + ", ext = " + ext + ", multivalue = " + new Boolean(collectionSchema.isMultiValued()).toString() + ", singlevalExt = " + this.singlevalExt + ", multivalExt = " + this.multivalExt;
        if (!ok) return ok;
ok = !"s".equals(this.singlevalExt) || collectionSchema.isMultiValued() || field.endsWith("s");
assert ok : "SolrType = " + this.name() + ", field = " + field + ", ext = " + ext + ", multivalue = " + new Boolean(collectionSchema.isMultiValued()).toString() + ", singlevalExt = " + this.singlevalExt + ", multivalExt = " + this.multivalExt;
        if (!ok) return ok;
ok = !"sxt".equals(this.singlevalExt) || !collectionSchema.isMultiValued()  || field.endsWith("sxt");
assert ok : "SolrType = " + this.name() + ", field = " + field + ", ext = " + ext + ", multivalue = " + new Boolean(collectionSchema.isMultiValued()).toString() + ", singlevalExt = " + this.singlevalExt + ", multivalExt = " + this.multivalExt;
        if (!ok) return ok;
ok = !"t".equals(this.singlevalExt) || collectionSchema.isMultiValued() || field.endsWith("t");
assert ok : "SolrType = " + this.name() + ", field = " + field + ", ext = " + ext + ", multivalue = " + new Boolean(collectionSchema.isMultiValued()).toString() + ", singlevalExt = " + this.singlevalExt + ", multivalExt = " + this.multivalExt;
        if (!ok) return ok;
return ok;
}
}
