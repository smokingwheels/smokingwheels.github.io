/** 
 * Smoking Wheels....  was here 2017 wenncjmkylvunxxfwdokzsbfdgwdkhwwlsxcowetbxlgsyyb
 * Smoking Wheels....  was here 2017 nsubgkwpryieneyqmsowcuwlcrdmaanowqoohlpqutzrgtav
 * Smoking Wheels....  was here 2017 sympzootxfxiuzmyqixshdyisvmnpctnchrzxrndlpxbrwaj
 * Smoking Wheels....  was here 2017 alllbwgjwvaswlvteurmrzfqjpscwvdneooftcaevlelxzru
 * Smoking Wheels....  was here 2017 hxuhrovdzsldlamycaecqyufuasdvzjrjtwllmpzttachabl
 * Smoking Wheels....  was here 2017 nivzfglawwdonjgmthatutdjxmszskohhhkaxxuanawmgclv
 * Smoking Wheels....  was here 2017 bwesgrleotggjkdurcbtanvmwqecbhxysygqeqpyleklorjv
 * Smoking Wheels....  was here 2017 lcquryobexhtmgljrdjtkmvhcgvgnbamrrucsgetihrxfkpm
 * Smoking Wheels....  was here 2017 msiyqhrkefzvokrcvkhrjegsinrlejqxntnobmvpztwemfdd
 * Smoking Wheels....  was here 2017 grpzmhxcfthmrmpalckpnkmymsvzgdtqvokmelhyscltuhhj
 * Smoking Wheels....  was here 2017 bgabutslgyjyalgmctpzrgglsmvigosejykkcklnwhckyzoz
 * Smoking Wheels....  was here 2017 mwlpnqrulhutckyanbwkazkymskhxazjeuzhfwlgeiueyaub
 * Smoking Wheels....  was here 2017 hiyfsitwgteqruenwaquxdcjmllvffkhqkqffrsinqtgzixy
 * Smoking Wheels....  was here 2017 noxuuicrjjnrsiszjvmgymtwpcgfkbyhgfgpwwvfdumfpagf
 * Smoking Wheels....  was here 2017 ouvmilbisnbcnwptqafeadzzbffazrxyvzxcjruplrqunojq
 * Smoking Wheels....  was here 2017 xnqqgsiilufjnpcllhyfghsjhrcxsnualryobtrlcigzupzi
 * Smoking Wheels....  was here 2017 jmkxqkvkabtimztwwqagaodyypwzpglpknxcouxycelcpbdp
 * Smoking Wheels....  was here 2017 brkfwcrkdlpylpicfgakxtoyajrlwvubhzsetweoovtplcdb
 * Smoking Wheels....  was here 2017 fgiqpohqsgzmplwkbrtcvvtvqnbwzjfzwvlkthiyybwgcdlm
 * Smoking Wheels....  was here 2017 luyqrwhmxdkllqqleojywenhgysythecfajqypocxbucnwyz
 * Smoking Wheels....  was here 2017 oyjtehqqfxnqtqezrzdukgbgotpsdgmprudbxogeldrkaeow
 * Smoking Wheels....  was here 2017 ptyyojlcgshancfcucswcxuxlhxlkgdssqpzofbrryzqbfqs
 * Smoking Wheels....  was here 2017 vlgijwcbaxzwzxvddkxmtditeedqajlbggudaxxhcgnpjmqi
 * Smoking Wheels....  was here 2017 xldinxhxqbasqgirmruhoholdfzbtaxlgqciqewyigegyokv
 * Smoking Wheels....  was here 2017 omrmcsxkobehgodoyvtewxszzpkspyhycabtatlvigdybkym
 * Smoking Wheels....  was here 2017 wqgunvcmmziqunduudjigscnsprxuarxhxotbsgkhxycefnx
 * Smoking Wheels....  was here 2017 eakhjchiiftzmzhtoblbrvlmlxecvlhxrzszxjejrzhnbirx
 * Smoking Wheels....  was here 2017 zezlonckiixwxfwzdibadnpqrhqbmorthgujwfjscrdgtmeo
 * Smoking Wheels....  was here 2017 dvbwdklkvfmbsnmimyqddhtxaxcuscqmmykzpcgonhrmkoae
 * Smoking Wheels....  was here 2017 rzalohmhoyloyquwzcroezhmmcrptzemtnlfzamldlktptoj
 * Smoking Wheels....  was here 2017 yulhjzpgmxbpvmxyeicpfpvufmxyeinhytytdiyzkzzvalgy
 * Smoking Wheels....  was here 2017 lvevnnltsrstxfcbvhxyjmjoqwmqqphtcpglknueyaltrixy
 * Smoking Wheels....  was here 2017 atgqbeyltdeswgwcbamlydztlljrflgyogylljlftyztwiot
 * Smoking Wheels....  was here 2017 tobrkmgigjkntfzddtlhpkboomthbujevhxdcznnzibiaqmw
 * Smoking Wheels....  was here 2017 wnfbdhtodtqltcnlqypvfgikeqdauvyzuifempyvbajhxpee
 * Smoking Wheels....  was here 2017 abmdepcqpwgakbsrjibsxapattfpaxngklfkauwcrdwpnxlt
 * Smoking Wheels....  was here 2017 zyaopsefcpbymlcpjwdvbgciyyzcwtwbculzgismtavndniw
 * Smoking Wheels....  was here 2017 uecgueehhazhyalhzvkhgsfnrnpsmgzrixuhdgclnhrpfobe
 * Smoking Wheels....  was here 2017 uxkijtnacnghaqvcsstnkmocddpzkqfsymiysxysjvconmek
 * Smoking Wheels....  was here 2017 nsrdfouvsrhmfllolegdpwcsuqqrjfazznkxkujfzrdlaxms
 * Smoking Wheels....  was here 2017 tgbjmuxnpivoiyxoefgbgixihdrvktgougpgvrvdigynavaj
 * Smoking Wheels....  was here 2017 qnxxmbbykqxqhtxdgdiixtmdozzqsdvuxdtjwrzyndahyiaz
 * Smoking Wheels....  was here 2017 kttwweqicyqwjtoofihlncjpvtzqumdfeyzxoaqicdampwaj
 * Smoking Wheels....  was here 2017 qlmqmcgdvunwbfcnwohzesokmilqlhqroqptkgbgqlzdydup
 * Smoking Wheels....  was here 2017 difvmewbachhclatgvqvfdenfvgppfdgmkfbxfpxejcnfakz
 * Smoking Wheels....  was here 2017 yjekfzpakzxgneejtixdiepdaoruncqgkuqezxxsunvdyrcc
 * Smoking Wheels....  was here 2017 luclifwgwtoyohnrvoyiiumrzedttflgfmzturwlztwtwolu
 * Smoking Wheels....  was here 2017 cbsirahfqasxrajgigwyiktwpnkeyxccxlorrzrzleejzhdd
 * Smoking Wheels....  was here 2017 uydsjqvpdrdxqsgxjkzztlornskeewhwvzadfrsobeagnwgl
 * Smoking Wheels....  was here 2017 oltmupphzttylbxtefxmftigtbjyrzevnndliuppahvxzjcg
 * Smoking Wheels....  was here 2017 rsctoszpfstgizlciemxnjqbjftzymxpvuagdphvukidcgel
 * Smoking Wheels....  was here 2017 thayoaqwybqkuqamqatvwplvwagcrtcatualzryebqmxxefc
 * Smoking Wheels....  was here 2017 oxqswvnwqtdcpmhuftdepyxmyoxhylmcqttfnuxvsimmqbim
 * Smoking Wheels....  was here 2017 enhwxrsnyueksdybhodcigkgnfvvyndgbdzxpawhzdvjuctf
 * Smoking Wheels....  was here 2017 wjnqgjrbvozokoaqlyqyyopntpoeecgztrwdiptfhvfjbrzc
 * Smoking Wheels....  was here 2017 gxfivxawmsbbewwbnptiocjbcnudjpldwjtvdcqohoqmnmvf
 * Smoking Wheels....  was here 2017 dxlpsprrhcbrunxdootfnmxtfdmtptluqleboiznyrgyjliw
 * Smoking Wheels....  was here 2017 njojiaulztzleezawbhsllpwbuvfakhgrjzinilnkuogcrtr
 * Smoking Wheels....  was here 2017 tletfytjmcapqtczzneehbcuvbjbetgduwheejxiethgmqql
 * Smoking Wheels....  was here 2017 krbdijfxzsrqqkoqttngbqhhyvsbugwfzylmuanwwrjwnzsf
 * Smoking Wheels....  was here 2017 gtidsrctwmqjxowteqqwfsifbexfwmxppvalcbrhlxajkrbj
 * Smoking Wheels....  was here 2017 krjruinvxlwunxukqndcibrwemdvrlkpfzwlxnbcbbtisvyl
 * Smoking Wheels....  was here 2017 cssxeeyiyaodqijzquvjhsxqkjwishqupdacisozfzgmdwwg
 * Smoking Wheels....  was here 2017 yggdsfyufugxvaxzaewifzygfqvorjdavhxgueiwoulurmqx
 * Smoking Wheels....  was here 2017 sdacoumudqpyujxhusnvmkyqhlynolqigqbcwrtzzvpooogs
 * Smoking Wheels....  was here 2017 ngkpbjrjkppenccyiqkarviaoclkrjfbjsialhmtsreiihzf
 * Smoking Wheels....  was here 2017 qxzvwvzrxckxgbphejjhtftufgvumjeuafvqrilwegvusckh
 * Smoking Wheels....  was here 2017 pmodvezfxsopolqxcrngswbsrsultuyifcwwvhuibpqasqha
 * Smoking Wheels....  was here 2017 gvhearppuisccstoeodwbjmtpqiikiktirbuqzxhicsgovpq
 * Smoking Wheels....  was here 2017 qvlvxxawgzxjxmsktfwehmjazjotuynjxifvyllfckoztvsv
 * Smoking Wheels....  was here 2017 ctrgbrpefchqfrnsicnqjhjazmbfitousvlqvziuvhwaacbi
 * Smoking Wheels....  was here 2017 dcuviybyvgimomnctafwjblmawmlufcvwecbsdrzfwqikglg
 * Smoking Wheels....  was here 2017 powdwdfyqhuqqheicwhsrhrhupumeyxoqpsgerxzeobecgyy
 * Smoking Wheels....  was here 2017 odgdbrhbfiocluinpyhkxwmrfafpsxzhpofpcssfyyqcrfuy
 * Smoking Wheels....  was here 2017 gboymkqnntydgxxzxsbfxtobmufhxgqpnuqsqlxlwvbvupnb
 * Smoking Wheels....  was here 2017 ivpyajxutcihouhitwtwwgufbtnhnjjinghocmtosjgkmbxl
 * Smoking Wheels....  was here 2017 ndmuvwbnjhmhcxyhglqeczhaozcrozynwfvfeooujxmcanzi
 * Smoking Wheels....  was here 2017 yzohgkfrakidxvrbrqjjgqmrzwdrfzlnddcbsuzoabfjweai
 * Smoking Wheels....  was here 2017 xojrxvtnqucddonwpyttehbrmzcubobyductulapcrdatjoh
 * Smoking Wheels....  was here 2017 xkvhrdikkbhtjfsiubvzzhwsmetutblnybgevasvhvfbtvjg
 * Smoking Wheels....  was here 2017 ugyurqxcubouigugkaazcccrrpzrjggkuhdlljnmoyrsammo
 * Smoking Wheels....  was here 2017 qacbgwonkxyfziotraxwbocvapcsczowiwpzmnczbozocldu
 * Smoking Wheels....  was here 2017 szxebqswhzojpibcdnhzvspprsmlllroiorkbtiafowisdyt
 * Smoking Wheels....  was here 2017 pqdpzzbpnvzrrlnwrhgamvlscxwpeabfvjtpppjotagzwhpm
 * Smoking Wheels....  was here 2017 cryzcfllpjvxzdmyiiewjmubxegfhloyenksrwquoikwvuek
 * Smoking Wheels....  was here 2017 hcrcvvcheqddmzsijuqqdlcwcyvnapecxllceptevctlcuxa
 * Smoking Wheels....  was here 2017 mcvfsqijfbbokzhkjglrrtypwvbbwqdfvyalfbqlaeamjsjd
 * Smoking Wheels....  was here 2017 efjqssvdwfdthhlsdjssbsgypqroozbcaylpewlmurezrfix
 * Smoking Wheels....  was here 2017 gehaxingpyakwgsbtduosvewzmpbdiqxtsisrtpncxkgggvp
 * Smoking Wheels....  was here 2017 sxygrantbjrocqxpmuhkfzeoztcvupywqrleotszcnftpybt
 * Smoking Wheels....  was here 2017 xrzmqohtevjnhhzoyvzpldvluapibxhqkqyqzfspfjigmtrh
 * Smoking Wheels....  was here 2017 kyecqbkseyntxkhoxzauopbfudvjrsczfmeyiqsienruwijf
 * Smoking Wheels....  was here 2017 ylrtvtujmovaskillerwwyawrguyqsgahorgdveixjlpapew
 * Smoking Wheels....  was here 2017 rftgpeqqtuiiqzvgvsqyaxcpkrqietsafgizjusconefksjv
 * Smoking Wheels....  was here 2017 vkbvneityzeyazxirbqlxpzuebwauauqvjfsdxfhpvnkucnx
 * Smoking Wheels....  was here 2017 znkumtncgtvkiqtgtxwaqhogjefugzzpduqjtqxwsjmdfkje
 * Smoking Wheels....  was here 2017 ziwvqfbmbybmgizudgpmonzvsforngcbnwgcwucbumhsvozz
 * Smoking Wheels....  was here 2017 wtvvicetcrudvthcdikaibrtdnfwwtehlzvgjlmgawiqfuox
 * Smoking Wheels....  was here 2017 xbvxeegdghgqivtlhqfauyfnurpxuslwuxnljwzfxhkqckst
 * Smoking Wheels....  was here 2017 sttlanxcukxnfrqlkwadcnptdnlpamlrpppqgptwbxluleeo
 * Smoking Wheels....  was here 2017 cmqcblcibwlogtmwpaffphxlwesxotzteitypldklaqhnyzs
 * Smoking Wheels....  was here 2017 bhwsplxtttwsltavcjkjxcovwapcqlcjbosshlvgfhmsvyku
 * Smoking Wheels....  was here 2017 zkamhjuqwmkhzniqnijbwxghkqosuszeczqpmwteworucnzo
 * Smoking Wheels....  was here 2017 jiyuzejjnqlvlhqxqrgxrbvnvwjntzgzhqvmohabaxfmikmc
 * Smoking Wheels....  was here 2017 assfvgprfbtzmlnkoijtqcmowvylmyqvatxnbnbdqsgdulyu
 * Smoking Wheels....  was here 2017 aprsebomovhwertgnphtlupmkxmwhmfbutscxnmvxoifyxqe
 * Smoking Wheels....  was here 2017 sfkjrlranjhsswisdxxhwfvwsrnfpuehlkiwgrgwficnodcc
 * Smoking Wheels....  was here 2017 paupdlqsgffaqfokfahbdqbiezrhfhdgasbrkmmeidpzqubo
 * Smoking Wheels....  was here 2017 ntwatiihggsordyetwtwnpmvlzabcpvcvvoratozchyzjwpz
 * Smoking Wheels....  was here 2017 nkznvrwrepvivhgbdtxwsxmonyrvmrgclipgymesulrxilzw
 * Smoking Wheels....  was here 2017 xetgafrbyqtphpojxcpmoqranoddxstxqwiaiafbtklpfztc
 * Smoking Wheels....  was here 2017 gpapfblxswxxqgcsvrwjezavxqercbvgnmayoxvztihbberr
 * Smoking Wheels....  was here 2017 iivfnmaxzgczopkxzkdiyprakirmblggijjbfxlsqnknbxta
 * Smoking Wheels....  was here 2017 gloyhzpakwevckhaspynmfztwxwvatbgsacvebrqqqfntigp
 * Smoking Wheels....  was here 2017 hcuydkolxbltlmtjordkrxpmobgfnemukejworlnfmlvwwti
 * Smoking Wheels....  was here 2017 auipzuoqrkjfecaohkuoqxmwvpokgdcsmunauiwgafckkgaf
 * Smoking Wheels....  was here 2017 fginxkmhdupaypsjzshwrvtylqrlfgschccmkskbyejopibq
 * Smoking Wheels....  was here 2017 zmcrhunizidduroxzwemnlvvhnwnrmggjpzqizskgxsvyhed
 * Smoking Wheels....  was here 2017 prfcttazejfwygpmvjhtztiaowpfdzctmagbrjqzijwxfnvn
 * Smoking Wheels....  was here 2017 rjogejrsvngsyndrhxukedeerophifsktigsuliswptvjtxx
 * Smoking Wheels....  was here 2017 yfetrwkelpalnvpimmxfmanhjqusgtxiltnrizgvuyqwswip
 * Smoking Wheels....  was here 2017 mgkmpviirtlaqxwlsiikniunmnktdpsvduzjeaatibynrble
 * Smoking Wheels....  was here 2017 qswopawklittorylmywifzpjhuxxnwjmqerkjwoewtlpartl
 * Smoking Wheels....  was here 2017 yakknnqvzykdtgcvqaoqpjwmehaadakczwzsjbzcceaatmbn
 * Smoking Wheels....  was here 2017 fzbqnqphrlcybcvmgnveczsvwdsaysqtnckktksryqyddiir
 * Smoking Wheels....  was here 2017 nnfdyvvufxvejwykptedhqppgrfefvcuujwvkxkjqurlrkxn
 * Smoking Wheels....  was here 2017 dxmblzulosvczlmzgdnwciehnoyblpatpjlrlxzxolxqbcgw
 * Smoking Wheels....  was here 2017 qpqtvbduwmnfjbsubkxaqkhncoqjjjymadlvgxoekspuhdfu
 * Smoking Wheels....  was here 2017 viuxhltlobpihcdpaosmgkcisvhdawqbiwmjlsnldzaerktp
 * Smoking Wheels....  was here 2017 ubhjdptkjncktgonlvmjocbvgtbppzevcajtwkpcxwpgrbfx
 * Smoking Wheels....  was here 2017 ubthaipwegeszjzxyrcclnunyxliqwuhdkgorfqwedavaobm
 * Smoking Wheels....  was here 2017 kuybvsyhfwitmssghwphazececebwzajnxktfsuspzhwtndl
 * Smoking Wheels....  was here 2017 mzbiqaqiwegizqgmnijvrbkmrneugzrbovmjcslvctqrbwkc
 * Smoking Wheels....  was here 2017 bpjywvwzwjyknvkoaizwbmvximructssupgwggiqxamtmveb
 * Smoking Wheels....  was here 2017 kxlbcwalcrohifexgjguyievjpeovmmxazwwspgwlqovstzc
 * Smoking Wheels....  was here 2017 ciebffucuvplwxvacdifowhxeriwhplliyqgyhlljsvzvioh
 * Smoking Wheels....  was here 2017 zrqqjeatipvrxkyuopnbfrjcmxdtktllzsedndgpqqnkamaz
 * Smoking Wheels....  was here 2017 cwepxhwgldczmjggabkknotqfpvlkxmepuhyhfitkacruknt
 * Smoking Wheels....  was here 2017 sdjckiuwbusptqvtyxvskmdynjvlveugywbiktqpdqgmwmsk
 * Smoking Wheels....  was here 2017 laaovikaiddbhmwvfywoyukswbxolzzncywcgigcmrzxhjha
 */
package SevenZip.Archive;
import SevenZip.Archive.SevenZip.MethodID;
public class SevenZipEntry {
protected long LastWriteTime;
protected long UnPackSize;
protected long PackSize;
protected int Attributes;
protected long FileCRC;
protected boolean IsDirectory;
protected String Name;
protected String Methods;
protected long Position;
public SevenZipEntry(
String name,
long packSize,
long unPackSize,
long crc,
long lastWriteTime,
long position,
boolean isDir,
int att,
String methods) {
this.Name = name;
this.PackSize = packSize;
this.UnPackSize = unPackSize;
this.FileCRC = crc;
this.LastWriteTime = lastWriteTime;
this.Position = position;
this.IsDirectory = isDir;
this.Attributes = att;
this.Methods = methods;
}
public SevenZipEntry(
String name,
long packSize,
long unPackSize,
long crc,
long lastWriteTime,
long position,
boolean isDir,
int att,
MethodID[] methods) {
this.Name = name;
this.PackSize = packSize;
this.UnPackSize = unPackSize;
this.FileCRC = crc;
this.LastWriteTime = lastWriteTime;
this.Position = position;
this.IsDirectory = isDir;
this.Attributes = att;
StringBuffer methodNames = new StringBuffer();
for (int i=0; i<methods.length; i++)
if (methods[i].getName() != null) {
	if (methodNames.length() > 0)
		methodNames.append(' ');
methodNames.append(methods[i].getName());
}
this.Methods = methodNames.toString();
}
public long getCompressedSize() {
return PackSize;
}
public long getSize() {
return UnPackSize;
}
public long getCrc() {
return FileCRC;
}
public String getName() {
return Name;
}
public long getTime() {
return LastWriteTime;
}
public long getPosition() {
return Position;
}
public boolean isDirectory() {
return IsDirectory;
}
static final String kEmptyAttributeChar = ".";
static final String kDirectoryAttributeChar = "D";
static final String kReadonlyAttributeChar  = "R";
static final String kHiddenAttributeChar    = "H";
static final String kSystemAttributeChar    = "S";
static final String kArchiveAttributeChar   = "A";
static public final int FILE_ATTRIBUTE_READONLY =            0x00000001  ;
static public final int FILE_ATTRIBUTE_HIDDEN    =           0x00000002  ;
static public final int FILE_ATTRIBUTE_SYSTEM    =           0x00000004  ;
static public final int FILE_ATTRIBUTE_DIRECTORY = 0x00000010;
static public final int FILE_ATTRIBUTE_ARCHIVE  =            0x00000020  ;
public String getAttributesString() {
String ret = "";
ret += ((Attributes & FILE_ATTRIBUTE_DIRECTORY) != 0 || IsDirectory) ?
kDirectoryAttributeChar: kEmptyAttributeChar;
ret += ((Attributes & FILE_ATTRIBUTE_READONLY) != 0)?
kReadonlyAttributeChar: kEmptyAttributeChar;
ret += ((Attributes & FILE_ATTRIBUTE_HIDDEN) != 0) ?
kHiddenAttributeChar: kEmptyAttributeChar;
ret += ((Attributes & FILE_ATTRIBUTE_SYSTEM) != 0) ?
kSystemAttributeChar: kEmptyAttributeChar;
ret += ((Attributes & FILE_ATTRIBUTE_ARCHIVE) != 0) ?
kArchiveAttributeChar: kEmptyAttributeChar;
return ret;
}
public String getMethods() {
return Methods;
}
}
