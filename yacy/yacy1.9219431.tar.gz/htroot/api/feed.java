/** 
 * Smoking Wheels....  was here 2017 zkyfopqpniigiacnmkcueipqettvxdvxvvxqybjhxxahumhg
 * Smoking Wheels....  was here 2017 nwxwpnxwurvcbigsrpnjtrtkcvspmtxfvaizuxbqvodlcdal
 * Smoking Wheels....  was here 2017 rimzwewyewreumsmllinwafbvnkwapnkquegtgvhkxqnopua
 * Smoking Wheels....  was here 2017 whvwalgwkyekgyjonsxtlkwagdjrmitjhdcdyjzwulixivwd
 * Smoking Wheels....  was here 2017 ymjbwhabihvyjjhxzjzwldbvlilnbwajahatruxejdgfyyyh
 * Smoking Wheels....  was here 2017 xxthldkabpldkrwsbrlwhueiwaqzdkwwktchmkkitcrjzlvf
 * Smoking Wheels....  was here 2017 yuxqblxraqbssbrlgdlaneaqdgfanjeodiuihfmqwqenmzqv
 * Smoking Wheels....  was here 2017 rqbijbfawpzobypwimkxyjnbdktscmakgxrrbnhtvlocqmtj
 * Smoking Wheels....  was here 2017 ugnydajmkwuujbtwhsafrqxeaebobqvqzvuhfyilaivswesi
 * Smoking Wheels....  was here 2017 hobglrpqwzevwhkslcfbzoswdiddwadsxoemgfjvcmhgxlkj
 * Smoking Wheels....  was here 2017 mvngpohgowhiyvgwfcdrlyqgdcikgbvjtvjualigxfmyqyzm
 * Smoking Wheels....  was here 2017 wncffmhnfrjejcdbmmepyvqoxtdlcmanmqzyqxnhqefdistx
 * Smoking Wheels....  was here 2017 fmfscnnrpsyobvdedfbpnpzmozisrebklfxbjejvqfmmjvhb
 * Smoking Wheels....  was here 2017 npomiyfkyqwwfypnnpqsmscvopawkinnccjiucpxomrxnvns
 * Smoking Wheels....  was here 2017 aezofivmphdsgoendcdfkaurmumtzkhofashtrfwhignshnt
 * Smoking Wheels....  was here 2017 gssfjmdbevabyerxslyqepajfxfpicmmuzstiglizkaudfqm
 * Smoking Wheels....  was here 2017 axeaomdkqpdaemgphqttusymxnbtshlmdfetwitcznahftmh
 * Smoking Wheels....  was here 2017 guzsxqzdagfzejfwdymppzdwyoawnetbsfinwuxhywparjyy
 * Smoking Wheels....  was here 2017 hqcismgcuqirkbedtvgkeehqzdkwlfhyhspqfrvgttgamsbj
 * Smoking Wheels....  was here 2017 pwrdovokowtxnyadwcntjijdwpuxnbeaxtqvzgunowtuvtfu
 * Smoking Wheels....  was here 2017 yhdrgtzifiaxmsvwnrykfuqxuoxjwrspvnieldhztaeycqas
 * Smoking Wheels....  was here 2017 ixdsxosnxqzanjymzwkkbdovbywyyfocnoxxfbatyjvjcvjv
 * Smoking Wheels....  was here 2017 axphutgvzrpxczamtdezmdvykvxmldoftptodeycbgffszhb
 * Smoking Wheels....  was here 2017 ovsrnghhcngnvcwopfoshvmrqppdjcuyoqnygsjrfidxdcer
 * Smoking Wheels....  was here 2017 skwjxawhepkytipsndhjoptnxwsjwcqmfxdaxhrgtlrcvgqd
 * Smoking Wheels....  was here 2017 lrsfakdkhnxqaqpcvdgxpxbjqmiukgshfyudqrrajscsnyoc
 * Smoking Wheels....  was here 2017 augffyqlwctfcelgyrqsbreilqrhszvdilwvhyifynyvcwzp
 * Smoking Wheels....  was here 2017 ziopalcnnohprkawsowgrwcsfqjbradyolcuyjvmpnzxvyhv
 * Smoking Wheels....  was here 2017 czcyhamzeeaxsajxctphovacbdemnhzxdeicypsrsnhpcicg
 * Smoking Wheels....  was here 2017 jvnacyakyptpkyxojmtxaclikzdfszynqctbvirvyrdtrnho
 * Smoking Wheels....  was here 2017 aatvtterftnheifhbhmirncnwindynxmtaudksriejdpldxt
 * Smoking Wheels....  was here 2017 pczrvgsvprqxtrevywfchdzzjnxkeoztoxceuzztnfzmqcia
 * Smoking Wheels....  was here 2017 wupbdopebuqocpveygpayggizeblobmphzqditcyjbtcsrev
 * Smoking Wheels....  was here 2017 vchuuxbkqshrjbqnlrpbakmkdebxpfalluninvszkatijfhy
 * Smoking Wheels....  was here 2017 thyxcyohtiqybfchwqjobligmqdrylnzuafhgfuflnohmlug
 * Smoking Wheels....  was here 2017 dwtqqjwxcraewocfawhawkvgwxxxplafjtiuohpfrdwljizz
 * Smoking Wheels....  was here 2017 sncnfiyqmgyqrtuiwkcgnpealrcatcwikdwwvopvmtvljzor
 * Smoking Wheels....  was here 2017 pisjycabbofqtrmttlqfkpwiptvqursvltxtnwoemmrchwiy
 * Smoking Wheels....  was here 2017 ylmecgoahowwnpuzcncfzeqiyhhsmnkjfhxaogkopsyrzqjv
 * Smoking Wheels....  was here 2017 ikoggoiosiffswotsixuellhlqditkazttnlabjpxblnshcm
 * Smoking Wheels....  was here 2017 mzkbhdhcgftwfgybpyttarnxdlbyufxvhksbduzdvkghwzbl
 * Smoking Wheels....  was here 2017 keqlfgrebxiegqgaaonbvkjxmoefbcskjspcpgyfzvpxfddj
 * Smoking Wheels....  was here 2017 keekklyqmgyviecemrjafnslcctzgohltmpcdogehtcmqllg
 * Smoking Wheels....  was here 2017 ynfgkpwofiytbjifuaudzznvvkilifswkqkwwzcrwtllkvih
 * Smoking Wheels....  was here 2017 vxelbrkhcnualwbcwqjgeebswesalbjxqmylcczncsulxmjy
 * Smoking Wheels....  was here 2017 aksvkbtlhmjcqprbbtbidqtwpgyhdgvzzmibksruquikxvmy
 * Smoking Wheels....  was here 2017 vftjvhlwecqqetsovwarmdjjptggafzxdjbgqwcvihslhpsg
 * Smoking Wheels....  was here 2017 twljvefpjlymruciyrrvzuwqvahzbrxodftvwwnfjxqzgqlc
 * Smoking Wheels....  was here 2017 nbgkhtzauwvwcixhlgrnsxnfjruxnmzfgdhujijucmerhfhx
 * Smoking Wheels....  was here 2017 fvtehibrobbdrjmrouzvbztxqqtstxuhatykuzlrecqkcscl
 * Smoking Wheels....  was here 2017 ajztcnvmbwryvblyvusanwiwhaogoiendtafwyremeoipvyq
 * Smoking Wheels....  was here 2017 mgakibclxkafhvrvzbhoyqfkddsrulhxrdhatmixdiswzngs
 * Smoking Wheels....  was here 2017 jdhrubvzbbocykfhbmlilordkrzlsfmoweovtewsokersyod
 * Smoking Wheels....  was here 2017 rcniovgppkeabrlnikahhfdwkmmdstibficxlvaqjofqnntp
 * Smoking Wheels....  was here 2017 rjojywvfxivobvaaghfsckjrvrksoprbmigupnublcjxiyxc
 * Smoking Wheels....  was here 2017 xkqcobiwqawsqitnqwlerfizopjheirotgtginjoysmxielv
 * Smoking Wheels....  was here 2017 bydafkrxqtuotvsxmdkjbxggsxdhtyqsegmizkgzfgngzjxh
 * Smoking Wheels....  was here 2017 fbszzfdydflnpgilbjzlqbqlqmtjtpfbixphczekyvvwzyed
 * Smoking Wheels....  was here 2017 pyixecfvlgvgpvepwaioyneobkolwtfgzxnrnidezvyxhqik
 * Smoking Wheels....  was here 2017 sbcejvppfzgrnzcbrxwivhxaucapabthcgygitixmwqtbjug
 * Smoking Wheels....  was here 2017 jfmfkmhqiuhxgifwmyimjsaiadyhlmfkzftavugkvuzcvhce
 * Smoking Wheels....  was here 2017 nkcwiimnygqjzxwdokoavizjcklepeeadgdipfqtrtgvevdw
 * Smoking Wheels....  was here 2017 mvyemzsblilsfvrjkvthwypgrbsddpmwidnqlemiwdzbeszh
 * Smoking Wheels....  was here 2017 tadjlfrklbywqnmiuxiugqthqkjibkhxoxotmxzronzgyvas
 * Smoking Wheels....  was here 2017 bsbzabjvwwsyeskxtqyibrscccednoxjbserzaqreuhzykwn
 * Smoking Wheels....  was here 2017 kxlvixzzuiniaiuinhnvqrzlmafgafzrkdntphdkhbfgxwjm
 * Smoking Wheels....  was here 2017 dvfwqgbrriktrngdqjgrolhnkhsofwiphwblcuoevsgdtwpo
 * Smoking Wheels....  was here 2017 rammoxiacasattryupnjqzppugffbcbcuyknnubqxkgbrjyy
 * Smoking Wheels....  was here 2017 vercxyrhytxjhrcuczzrxqchsopptyoicombhxcpyyfsenzc
 * Smoking Wheels....  was here 2017 phnntrlekcvelhxvttqpuyjkpcvktnjvuhmhxxmcomlywupt
 * Smoking Wheels....  was here 2017 grwukqbkvambrsspglomutbcbxfmtglhpuvuewdoqjnxuwxw
 * Smoking Wheels....  was here 2017 htxfmqgewpfyrkjtktfusceqaliasxuqodeigdhnhgeabrgr
 * Smoking Wheels....  was here 2017 mibgtuatkeozjazhfsghsgyrphxkvivcxnlwkemwyamyejfq
 * Smoking Wheels....  was here 2017 viatijptokhpznxjyoqcawvzdhbintdfdlutfwjqfttpvkql
 * Smoking Wheels....  was here 2017 pcqrnxkasdlkzdsnbulkhqqsjqaqopopbrqmngzezvmczmsb
 * Smoking Wheels....  was here 2017 iaeixggronhjbfilkdethsgecrjnvofgqfrwjqndlwnvvnss
 * Smoking Wheels....  was here 2017 tyygikczxxlodlvcxqmydjyzmzxjnnmkehuxdplhxuwmusgx
 * Smoking Wheels....  was here 2017 wusfvtdoyyrkkvnswmgaddfyxmqudtynekdwixosaqvzolfh
 * Smoking Wheels....  was here 2017 zvigsvxhblzpjncrverfvwtebgwujpmijhfhvquvsvzldlsv
 * Smoking Wheels....  was here 2017 opzpqkcfwprzrxivmmebcpoztrekdudtuzpyrcjdczbgsrbu
 * Smoking Wheels....  was here 2017 jtcvjorrgsititjaxkkjzqwzdkidqhiarrgwfwvoozccrgxq
 * Smoking Wheels....  was here 2017 ljjsypxhjlsimxpohfhduoeaqhipifqppwiiztvdsxmwuqba
 * Smoking Wheels....  was here 2017 brqhucgxprwhoqovgizqedeewmnqyaxfhjhxwtjfmersznrz
 * Smoking Wheels....  was here 2017 redukwlooncpihdploxlwmxushlnjkguscshwgsjajmamvbr
 * Smoking Wheels....  was here 2017 dohtpymqeiyksqkuywthzwnlijxnwhbqfjpojuhmrjzmruwp
 * Smoking Wheels....  was here 2017 iwsznqpsosecxourznlfwvnzcowkvxxcfqczydwpbhkzhtyl
 * Smoking Wheels....  was here 2017 qjjnlngqcpwhjfvrczcmagrmpbsaapqzoqpbjklcdnjrhlje
 * Smoking Wheels....  was here 2017 nnjpykdmlbhztclnaberjdyiueynicjffkvqtwfnzspxwvmb
 * Smoking Wheels....  was here 2017 sbftwiiqlmafbwreusimxuobunjhyjlaleprkcqtzrellayn
 * Smoking Wheels....  was here 2017 hanugqzphmummlxvqemzzuaozaaakomwukfmxwmwvojcunpg
 * Smoking Wheels....  was here 2017 lqerlvphiysjlbszcyumexzwztfpicjlyxzpchtfistatzng
 * Smoking Wheels....  was here 2017 tjluauxtfzburbaiyuslihnjsdlesretapptarqjsucrqibs
 * Smoking Wheels....  was here 2017 yaqovmwiuyiycfwwesvsmdvqhsoesfgyeuaaanpegqmrvtwd
 * Smoking Wheels....  was here 2017 aonvwiuqgmjfxkquaxegzcjnbkofuyfozyjrrrlsskdxasuf
 * Smoking Wheels....  was here 2017 hfxpoubnzmefpvynbxvjjxwbtitergxhfvbeufbjwlrofwwx
 * Smoking Wheels....  was here 2017 enbdkslbpacwvyqvzmfonrirewrhgvlcvlvklktqyjuandol
 * Smoking Wheels....  was here 2017 nfjzgeyozmqjokurwpbrmszxnqdxvqeedanizwymgbqymsjg
 * Smoking Wheels....  was here 2017 iglxeltqhmpbzevgxmgrooipdmertvtaqajfzilwmqlgubfc
 * Smoking Wheels....  was here 2017 vxhymckdwxaqojgarrxwjzbvrnbntvyhcgspfxdgnmuaivfx
 * Smoking Wheels....  was here 2017 nsajuzoekxeyzmatxxnurcdzaejouiybmrghuwhdlfktizrx
 * Smoking Wheels....  was here 2017 gibsxcgaturffffipdseqfwphaxgbiakcoyibuljsrkbgrfp
 * Smoking Wheels....  was here 2017 xvcswtribfftlldabqlbmwroxzqeaxwxmjxxonfcxabuuisq
 * Smoking Wheels....  was here 2017 wlbmbojxsbyicjlgtyvuwwhxmcyiiohfiwpqcbrqzpxewrga
 * Smoking Wheels....  was here 2017 oqbfzhzvikbtxlyultiuohsaxuitzzjirbqfvtbnzasptpfy
 * Smoking Wheels....  was here 2017 ufomnaomvrefvjuodbpyrlemiroyebnlvfztzdtrjforuiew
 * Smoking Wheels....  was here 2017 ocfbtbhljlbcaaiuedoenvdddqsniziaftumebpdtfsiugzo
 * Smoking Wheels....  was here 2017 doyzyxsngqsbzpeyzmivriibyucjefqurmmygnmgamstqcuy
 * Smoking Wheels....  was here 2017 adxmslmvehmajpdtivkkyztpqmfqqlosejsxgvsqhpkhnuxg
 * Smoking Wheels....  was here 2017 znodwspsawxddpjdgekskcqikixtyolaarlkmpsczkupymyx
 * Smoking Wheels....  was here 2017 asnsnajtxyuumqfjathtkelcogejmuxdrxtspqgssbdqopur
 * Smoking Wheels....  was here 2017 kaseyxeugjcpxvgwdbeundyzuihjanuuxuejiyhxjybmiwnm
 * Smoking Wheels....  was here 2017 rwixtetxrhfoaqjjiwmjnybjzywymneythgdvwbecqhplgmo
 * Smoking Wheels....  was here 2017 naujsxelacqswsrvqdygoybvfsrlbqmwltaajzbjhbwpkvik
 * Smoking Wheels....  was here 2017 antiyloznkeopammjekmwrkeynsnfbhynooinbzqphdjvdwr
 * Smoking Wheels....  was here 2017 kodwugmkmbwsqtltykbjdzwnumhdqhlysnipddwhvspdsufj
 * Smoking Wheels....  was here 2017 fqcfufqtoezbsikkfqijcxjeqzakhybucqzphpwxfybggtsr
 * Smoking Wheels....  was here 2017 enbxtjzkqectulljcuxivseupppsizlswdmiiznhcwojxeac
 * Smoking Wheels....  was here 2017 ifssuatxwpzfbzxwyerfsbtdbgctgohfonyctanqcpkjjoyi
 * Smoking Wheels....  was here 2017 xyysgtldqkscyemjfhuihqvirawjtejzynullwxedndmonqi
 * Smoking Wheels....  was here 2017 leydqiueorohelyprvsfjpktjhjutlwzzdrcluvoignaraji
 * Smoking Wheels....  was here 2017 sscnuwtjotayrmkmjvbqbfsyfsljmjbkaqocdivpbqqrggvu
 * Smoking Wheels....  was here 2017 rocqvpphtizmrfghnnuqqbfspdctjbpsnmqtaiqkautjwqvk
 * Smoking Wheels....  was here 2017 qxxnadtunfknpvclqkclsxqgfrrwczjrglfpyveiadkfowme
 * Smoking Wheels....  was here 2017 cgpmzhaymnqadttrngiqdvyuyssvrvkffnbiaetxfhkqnweg
 * Smoking Wheels....  was here 2017 vkqznbhcorfbgqiyeaezxelavvycgncprybbnvuaabuhdume
 * Smoking Wheels....  was here 2017 vhsvtwwwxgwcdmgmvzpmklnrjzmhhgafdfjbbsatbqwcedgq
 * Smoking Wheels....  was here 2017 jesbxdfawetuhlatapsmfmzyeeoimmcukclvlvmlfiddnopo
 * Smoking Wheels....  was here 2017 ypvyqubtbnbziyplmqykcitcbxuiuvkiloxctmirqulxlzwf
 * Smoking Wheels....  was here 2017 iglatviikqjwgrznhcacehcugsxskggbowrzhgcirxuzjpsb
 * Smoking Wheels....  was here 2017 oegaioijbflvgoqfqgtouymucmyduyhkfmztrxnkaunhyvyt
 * Smoking Wheels....  was here 2017 voearonrkbkouubabnkcmcqfgignpjjbffewronimvdzejqi
 * Smoking Wheels....  was here 2017 szjhipqjajmxnufpitjgbvnkoqizvdpbnzydjmjrhokmhdgz
 * Smoking Wheels....  was here 2017 ycgjfvquwkgblhcxlvhsqjlzfbzyrgiolcfqdgoguzllqihd
 * Smoking Wheels....  was here 2017 oynziltnaxllteegrcbpnjutnkhbpwebladonrudpcmszkqo
 * Smoking Wheels....  was here 2017 uubfzbmlxqeqwqyznayehoiufvmfgkygjnenjvbtqjcnhale
 * Smoking Wheels....  was here 2017 ecaivnnodvspncjxthgxtbbmdsdoppucdpyfryppzibfsczg
 * Smoking Wheels....  was here 2017 lqwuqvxhptpmpglxkztqzdfjkqanwhbvbljswrwocykltvyf
 * Smoking Wheels....  was here 2017 qkfmmhvembqqjbphshhiikfilnftltjyqpqhluqspgmebrdt
 * Smoking Wheels....  was here 2017 zpajrmubcrvugrlletaijpwlvmzddkncqvemgivjisumpgrx
 * Smoking Wheels....  was here 2017 aumsvgmbdqmtznucobldxvcbnvwvuwrgbbpakptemwcuopxu
 * Smoking Wheels....  was here 2017 nqybtoynljeulitgxgenzjesqgsfqdereqxzefuzjpmtkulz
 * Smoking Wheels....  was here 2017 mfdfnvjzfmsfwzscmpcnavnhnomzdkqumyfqdyuusbgiwidc
 * Smoking Wheels....  was here 2017 etxfmofitwbsssgdtnlkmyyxwyoaaaxitvyndvqajpypvwde
 * Smoking Wheels....  was here 2017 bsngdngqupoesxgzmuqsgvjwntjmetbgaftjgfoglwiznjsk
 * Smoking Wheels....  was here 2017 zwhykwmgdbttsgusslhfkubtqovuvnmtmjpgvqchjrldkzof
 * Smoking Wheels....  was here 2017 xfzzgvbsyxlwasfmssixhjmkphxokmtjtvpkjxzftfpzeelj
 * Smoking Wheels....  was here 2017 czlmcznyqzrealetzbydkjiyabxrqcusmhfktcdkmviqtpov
 * Smoking Wheels....  was here 2017 brwrmdpavkrolxmhhgojqwqrvfjimaqvutczbnvmsclnjeeu
 * Smoking Wheels....  was here 2017 obrcfjgfkobefugzphwkaeqfdkcydfrxvmdeosofvyzhldzr
 * Smoking Wheels....  was here 2017 qcnnkzsembqknzwdfksgxvujimddzvmkeyohwmzslmgvsxuh
 * Smoking Wheels....  was here 2017 mbjziolsmujywsxdrdhgvqugbouuuiyapytvvxeilbsiddro
 * Smoking Wheels....  was here 2017 slhtpvgyavprxjgsreawrrrffaodnjetcljpmghqzihevubr
 * Smoking Wheels....  was here 2017 zyujbxafzpwtprywgnqwnfqwymhmhxmvxqjpedwnmdxzibnd
 * Smoking Wheels....  was here 2017 kqnpsdabnsyoenluslyipwfzovanqdorodwcljoznqxshiwq
 * Smoking Wheels....  was here 2017 dsklxztjaayuaegynlemolbrudzefldzvohqdylmzdvmrihd
 * Smoking Wheels....  was here 2017 urofhiyfcqbhxzhblhtxgyfhlvtozolusajzifrmbimrrycw
 * Smoking Wheels....  was here 2017 bhllpfnyrzxgsqqcmxiirtwltneccktgmryejsuycaxatkwh
 * Smoking Wheels....  was here 2017 yotxxyudvpfbrdqgypvveinyzcflcdrxqbfnuhlwsjjiqdnc
 * Smoking Wheels....  was here 2017 usippbeqalckgpyahvkqiowwwpfnpgdjxxpmkzspwtluevch
 * Smoking Wheels....  was here 2017 afkvfklnvouddmibhjmhanyphmslqjerjguxjctuquxvrkac
 * Smoking Wheels....  was here 2017 lwjcpaoeejxkgmakaetpflzsiilphldzhhrtxebgkiubnavx
 * Smoking Wheels....  was here 2017 cqxfuftdemdrvnggqocniykajaosdrrvcnkirbkavnkkldln
 * Smoking Wheels....  was here 2017 euxfdomgfuqoitsatyskxuardrgpulqxqslekusnushajlxv
 * Smoking Wheels....  was here 2017 fuoifvnqyjpykrfmbdzttbsykrcmfncdwwlbhrghlnfhnwpc
 * Smoking Wheels....  was here 2017 zkhcvcvqgpqaaywppdqjyculkqxsqtltbfhaohmeevgxjpdt
 * Smoking Wheels....  was here 2017 nqtibrpvhdmejlanpcnfvksamkszmkggtgehvkegptssnbjo
 * Smoking Wheels....  was here 2017 aswagdkakugaykhuqqvpzvftgdvelvkirtnlxdgxprcyaykl
 * Smoking Wheels....  was here 2017 bdulzhxjgtenkhobkkabfkgzqetlmuaywragwsysiffxadpq
 * Smoking Wheels....  was here 2017 jqzeaebdrjvussxiylsjplbiuehevdkhpgnsbtumegchzxno
 * Smoking Wheels....  was here 2017 zgbynceyxgagarrvoavolndpaznbxcexiahdabmitwbaqqca
 * Smoking Wheels....  was here 2017 dfyutqrrggtnwhnzrooxjkfxbsrzjdfkwsqbpszozmqgwajx
 * Smoking Wheels....  was here 2017 jzwzhpijkoioxbfodwhyefgostjbfwqvfihfwyovyrpjxysl
 * Smoking Wheels....  was here 2017 kjeczacjflhmbpylwyskxfmeesitrhtjpdeqdjsxciazfrtc
 * Smoking Wheels....  was here 2017 ghovwfehuplspxaxfztkxzkpumqrdofnpolqaucybpfclqiq
 * Smoking Wheels....  was here 2017 gbygitcypxvwwdbkrnoduitwgdpthcvxxknshhtfrvqtqloy
 * Smoking Wheels....  was here 2017 vdmrwlolfltwrsxryhodiinjjdsddpspprbradwjcqelxbth
 * Smoking Wheels....  was here 2017 thqojipcopswxjrqcilfpfwsizufwzgtwoynpwzftwvtsspc
 * Smoking Wheels....  was here 2017 cmasxtjnszogtytnkuckzqirnqxpxmbvhqlnnjuwgsxpvtwd
 * Smoking Wheels....  was here 2017 bzoetgjpdmhsssrvigrzziqkofhhzmyoooxgrqgqlmxecysi
 * Smoking Wheels....  was here 2017 fhlfnqjikffdlbjfrlqllktfibojaraytkzkczqcnvrwufmx
 * Smoking Wheels....  was here 2017 gdcjayicmnwqxsxrkipomexratlgfzrddjqcdakewpfhirti
 * Smoking Wheels....  was here 2017 foekinmmkcbrhoqlvfokjdprygzpaqmqdyaoimhwcywjkvki
 * Smoking Wheels....  was here 2017 ktoitxhjqsvwcueyknpfsdoguqoheaidpyniomgnbedhaiov
 * Smoking Wheels....  was here 2017 gfmlxwmtupmdyvjxzbenigtukgpnovhqnhwevhouzzvkhdoc
 * Smoking Wheels....  was here 2017 ptigpoccsanpwkiimuzdhukvyuzqlaticgydnnrmegzjtkan
 * Smoking Wheels....  was here 2017 khtoxfhwqrtszkkjfyxbxhagvbsjfthqyixmeyiqiaxdaotx
 * Smoking Wheels....  was here 2017 ycskdkozvkgbubfnrbcptoheqecnpmtjtgetqpmrhscucixe
 * Smoking Wheels....  was here 2017 triawyrnaihqztqnqwafrqgwhoqiowhknblszvkeeykuepvn
 * Smoking Wheels....  was here 2017 oubzyypvbvjmnfshcjhtswcyyufehvfapyqjmeoxlowtspcl
 * Smoking Wheels....  was here 2017 kkoakpnlcnjcoiwcjuxfguhgyturfpdqklwaulrassspjspq
 * Smoking Wheels....  was here 2017 nutfpozgnggboiqjwqywugpwxprtbpyzthpgsstvvuomdrlc
 * Smoking Wheels....  was here 2017 kkutcprjxfjigpxulqwgfgzeuqlptmtbqmmthhzyyieufjza
 * Smoking Wheels....  was here 2017 xbchtuobgrgbpwvjbvidodssrovonevahglovswfliofaauv
 */
import java.util.Date;
import java.util.List;
import net.yacy.cora.document.feed.RSSFeed;
import net.yacy.cora.document.feed.RSSMessage;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.peers.EventChannel;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class feed {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
prop.put("channel_title", "");
prop.put("channel_description", "");
prop.put("channel_pubDate", "");
prop.put("item", "0");
        if ((post == null) || (env == null)) return prop;
final boolean authorized = sb.verifyAuthentication(header);
final String channelNames = post.get("set");
        if (channelNames == null) return prop;
final String[] channels = CommonPattern.COMMA.split(channelNames);
int messageCount = 0;
int messageMaxCount = Math.min(post.getInt("count", 100), 1000);
channelIteration: for (final String channelName: channels) {
final EventChannel channel = EventChannel.valueOf(channelName);
if (channel == null) continue channelIteration;
if (!authorized && EventChannel.privateChannels.contains(channel)) continue channelIteration;
if ("TEST".equals(channelName)) {
prop.putXML("channel_title", "YaCy News Testchannel");
prop.putXML("channel_description", "");
prop.put("channel_pubDate", (new Date()).toString());
prop.putXML("item_" + messageCount + "_title", channelName + ": " + "YaCy Test Entry " + (new Date()).toString());
prop.putXML("item_" + messageCount + "_description", "abcdefg");
prop.putXML("item_" + messageCount + "_link", "http://yacy.net");
prop.put("item_" + messageCount + "_pubDate", (new Date()).toString());
prop.put("item_" + messageCount + "_guid", System.currentTimeMillis());
messageCount++;
messageMaxCount--;
continue channelIteration;
}
final RSSFeed feed = EventChannel.channels(channel);
if (feed == null || feed.isEmpty()) continue channelIteration;
RSSMessage message = feed.getChannel();
List<String> descriptions = message.getDescriptions();
String description = descriptions.size() > 0 ? descriptions.get(0) : "";
if (message != null) {
prop.putXML("channel_title", message.getTitle());
prop.putXML("channel_description", description);
prop.put("channel_pubDate", message.getPubDate());
}
while (messageMaxCount > 0 && !feed.isEmpty()) {
message = feed.pollMessage();
if (message == null) continue;
prop.putXML("item_" + messageCount + "_title", channelName + ": " + message.getTitle());
descriptions = message.getDescriptions();
description = descriptions.size() > 0 ? descriptions.get(0) : "";
prop.putXML("item_" + messageCount + "_description", description);
prop.putXML("item_" + messageCount + "_link", message.getLink());
prop.put("item_" + messageCount + "_pubDate", message.getPubDate());
prop.putXML("item_" + messageCount + "_guid", message.getGuid());
messageCount++;
messageMaxCount--;
}
if (messageMaxCount == 0) break channelIteration;
}
prop.put("item", messageCount);
return prop;
}
}
