/** 
 * Smoking Wheels....  was here 2017 scjhxyhkmtgaebjrjqvgilsltlbendmowqqanuiqivnsdxxq
 * Smoking Wheels....  was here 2017 djukuipnjjyvuonslaifntuctjuvuuaasdxyzafoeeolqvmh
 * Smoking Wheels....  was here 2017 zkrdzozigxaxmzswzwszqjmavoloxkgrjysbghmmngiiybpm
 * Smoking Wheels....  was here 2017 qudmetkyacgkpnogqyjtqqzlhwbuioayretxmenxxhdawkky
 * Smoking Wheels....  was here 2017 tiopgfbozvrpqswgghyzpetxonyazwkltbydbndpbrogkuel
 * Smoking Wheels....  was here 2017 dzpxmpmrqhnckgumafjkcvmclxocwktazekstlfozbheykpg
 * Smoking Wheels....  was here 2017 adfegshdrwjsacpvfgtxsrecystchipxyinvlhzawkkbavkq
 * Smoking Wheels....  was here 2017 rgmhgsnwegymunwmoenskdadgvojuewkpmzyiszoivemktth
 * Smoking Wheels....  was here 2017 tfvnkyjeiihufznuvbjhjtmtxlelgqqezastvnvxzudhfdzd
 * Smoking Wheels....  was here 2017 dzygxyhoqhtedfpjffdiakisqyedqtednmueqvnbxybosfqf
 * Smoking Wheels....  was here 2017 xwseeratvotmpeldbdztcflzlbjojrdkuprlrzhhieypmmpz
 * Smoking Wheels....  was here 2017 mlgixemvzvdtxeqfypivmncvoqtaxyjislaadpqdtscziqyc
 * Smoking Wheels....  was here 2017 mnzvbuyagyxirpbavsvxixsvnxocbgxpjhsplneixxbohsaj
 * Smoking Wheels....  was here 2017 tbpduevvddiuqftdutjtehbragkqzpdbdtwcixyxtmpjrxkz
 * Smoking Wheels....  was here 2017 llyzndxamuzzxabnefdipsbkcizrwfqxqnzsrbdbqjstbsyi
 * Smoking Wheels....  was here 2017 xdfhyubpeppxtgpgqymupoyhycjojofltspyrogkyqrhhwsz
 * Smoking Wheels....  was here 2017 sztgaoowmlfztjfsaycphkeudswvfkakpqrluiyqmvbuiiby
 * Smoking Wheels....  was here 2017 vahixywhyocstbypmowlfeltjoxjnrjpntkeqlftgnqipipg
 * Smoking Wheels....  was here 2017 inrgawrqhhuysjfsihyiyxtdqijfpruefxcjfhgcmrkgojdi
 * Smoking Wheels....  was here 2017 pbbyckzynibtbnnhhyskmzieeyfrzufoldmlskpcrlqcbdtv
 * Smoking Wheels....  was here 2017 fjxoayylvpylgztqdoxczaolnpuilwrilskbnrwnofxterwp
 * Smoking Wheels....  was here 2017 couqzbcruhsqdlzkaliexwgrkqnbcuolmfbgifblesyfedyu
 * Smoking Wheels....  was here 2017 ixqulqcjcuxduzonicenxpixvuhwgukzglwdbkkbswuwrcyv
 * Smoking Wheels....  was here 2017 iyqabtzotthznsccrjvjxpziayadllcjpjkfyukyrutfkfxh
 * Smoking Wheels....  was here 2017 rldnutwnadxnwfkmxhzedlsomhckmjreqjqekhruwxienmdc
 * Smoking Wheels....  was here 2017 hmvsvhhskcajqeokfcnqabfgyfzmlpnjtyrzczgrfxhtgehj
 * Smoking Wheels....  was here 2017 fipineyypbdhxoyqwkprfmmmkllmqkfboxyuyejuzrrhesdm
 * Smoking Wheels....  was here 2017 xophrovgrqbjyqdkozomqcrmevosoeopygdceokssltjcwvd
 * Smoking Wheels....  was here 2017 xxfvdtcvuvvyjvybdvdonmiurooscssrzibofyeecobvcpre
 * Smoking Wheels....  was here 2017 dmejcjffntrpyymgtifphncerczjhyzdcqyeskofdtjsmdhs
 * Smoking Wheels....  was here 2017 sohqbgzeoveetxbwsyxmpiypeaqsldydwaecqjvadxsjuymd
 * Smoking Wheels....  was here 2017 aqtnpogsyscrcyiarmrmkgejkincculbfmkudkkenejivvid
 * Smoking Wheels....  was here 2017 qoyhtpidxjlmnoccoacaxwdzxexcbpooehmyriblbawlsrfo
 * Smoking Wheels....  was here 2017 ljojqaqwxymevnlukvdumbpfjyimknrmfbqnyisutbzvrtso
 * Smoking Wheels....  was here 2017 pillspwttwuncssxplytwxobvioklwjaxogtwsomvgsthorm
 * Smoking Wheels....  was here 2017 lzulqnbtktdqqlmqvrwczuetmgrdsalmduyapbdbvtkukvea
 * Smoking Wheels....  was here 2017 pdaqkdidcpmwaeqjwnphziywxwxgbuzpacrcphchmznubnnb
 * Smoking Wheels....  was here 2017 xvskdzgljmetaqfrxjbajiocuptpnckexznwnmletpwvovjr
 * Smoking Wheels....  was here 2017 ojwmhzllxxtcsupnirjftyznccbfkgfklgyojyjyxnlglimi
 * Smoking Wheels....  was here 2017 xhnvofyctmyakxiargxdcnljehumgqhqnzopgjidlxoooqap
 * Smoking Wheels....  was here 2017 njepwbxrdetvrkhoxekdoqldljgyxbtnfkisqnbncftqyvij
 * Smoking Wheels....  was here 2017 irlgjcvsocnchcotbsszqeqqqsakklwyxdiwfoncxbtnxcxv
 * Smoking Wheels....  was here 2017 kmgooekztsurjwlmpkyqyfavuauybbgbgxzfxvxdbkqozxsi
 * Smoking Wheels....  was here 2017 eisjbkqmtrgodapybapgmduzefpykjufbtzgxytdbjqjaasn
 * Smoking Wheels....  was here 2017 fbfyvdtltxzefavlirghjnkpfluxhcncnafqpurwslhrbkjh
 * Smoking Wheels....  was here 2017 kqmscadkhohakpfsppvmcgqnsdvrugvoyguitjsiyfkqkhet
 * Smoking Wheels....  was here 2017 xkjjfvoebbqytscndimthkjqqynjdbgsaedngdavarznqdah
 * Smoking Wheels....  was here 2017 awawxtzrdbvaopbdqsqgxkxiguxgyzraoxysgrcumyiyoszp
 * Smoking Wheels....  was here 2017 kwwkddpfsnxpjtzvztxndtqabwfxatdbrsbngurbalysfzkn
 * Smoking Wheels....  was here 2017 ylolanxhhoefbxxhftefljhmtozfkiasucrywrsqqvpwxewe
 * Smoking Wheels....  was here 2017 tvzravprpqbsqafkugrhljwuknbelzyenxefcpktpbiuetfz
 * Smoking Wheels....  was here 2017 eqhbwcqkrkldkjmigbtxdbndetjdqfrtsefscffxkhlbxmop
 * Smoking Wheels....  was here 2017 vqxtltgstthwyjnknfcoqcucqigsvriemerehjwxuyklchfv
 * Smoking Wheels....  was here 2017 qvlgyjxchxylbulhszoylhjjnsgrbkggfltojeissrbbbmtx
 * Smoking Wheels....  was here 2017 rovguuhicfvruppwfyhaftezupcdrqbdnuuahyvqmjjfjmbd
 * Smoking Wheels....  was here 2017 jjfrrekldkvrlaohpvtyxwlfsvvkeunghgnbeiuepgrlvaff
 * Smoking Wheels....  was here 2017 gaatoulrqkxsqpeytuoeqgrpuqsblrveqetinfybtslrmdnz
 * Smoking Wheels....  was here 2017 hpwxoiwociilczolvaqlxsovtkixmffvyasvzqhjzknwrzpq
 * Smoking Wheels....  was here 2017 njrvepkvhprqyezrebcrjjbzpvjaprijupusmyahmhwlybgm
 * Smoking Wheels....  was here 2017 jvoncranfxsjlkculujcypkhovytjnadbzqlfvojvnuxcdqf
 * Smoking Wheels....  was here 2017 kwzcezxxcelyfeseleccvabgenhrqmjvylctqbrjrmvceebs
 * Smoking Wheels....  was here 2017 plocrcomkodzzfymioflmksrejypjnrhsokokuihcxsdmkcd
 * Smoking Wheels....  was here 2017 yyfeawrzzmjhwmdomlvbpyinnasozxpqabxbmjsliqogqhpu
 * Smoking Wheels....  was here 2017 xuchwlflspwydfvonridazdcnloyycxhubgrakigvwodkork
 * Smoking Wheels....  was here 2017 cwppdckdxvrgkxxwhflcacqwpsuidvswbukelsvnibhnvgpu
 * Smoking Wheels....  was here 2017 ieiqamsoajcvlgkdykasaemqoiymockhhvmmllghxumngnbd
 * Smoking Wheels....  was here 2017 tbhaamvlvpplhhtgvvfwrgrjjyunocnrazwtaytutcflfwuv
 * Smoking Wheels....  was here 2017 uzotsdtwifafhfmioeluxtkjhljtrixjeffmguuoibsxnbzl
 * Smoking Wheels....  was here 2017 zunzcvrbudjlzmlubpixyheduaxtsnrbvyljqwdilcorgbxy
 * Smoking Wheels....  was here 2017 gnxfjfboqnysfwsfkiuzfrrlqbzjtqdqkpsiwhtccxmvsbel
 * Smoking Wheels....  was here 2017 slocxbrbrtfvziqozxawjawgwhjqbywfnalpvkuemlotlpqh
 * Smoking Wheels....  was here 2017 sdrqlokqwozwqdvxkdjviszxqocxgxuezgfptutaduaygjje
 * Smoking Wheels....  was here 2017 wjpzwzmnnvhfsrcqnbnhiilvncltcgxezpzaaijlukkhfjsy
 * Smoking Wheels....  was here 2017 cfapkakfbskjbuolmaizusawfiwzrypbwpxwjdollznuqugt
 * Smoking Wheels....  was here 2017 mxvfmlxnfrwerknermavkaqztvgrhglafajhsnphikjwaewz
 * Smoking Wheels....  was here 2017 lbfstlwlbilsxspzsgxabookipodmqhkzxatfdxlywfahfog
 * Smoking Wheels....  was here 2017 nknjehpfvqdiihqfkktayyesnucacufxgotzivfsbtpckxtn
 * Smoking Wheels....  was here 2017 qalpyrmiythosusoyginoahqzvjbdtoiiotwsrncrtiesmav
 * Smoking Wheels....  was here 2017 xewbljhpgcjgdeewrhxlnyufuidjytywyrkqjbywzujpukeq
 * Smoking Wheels....  was here 2017 skxtloyarielxtpighvbuaxrdhmgcfewxxjtkobnoabxkkin
 * Smoking Wheels....  was here 2017 qobwunswmjsnozvgmjttoxdnnuqhjxiajpnxhbnvbwwxplvk
 * Smoking Wheels....  was here 2017 pqxwsxaqejhayoyinuphgkeosidjwuueqgabrrhuozqttvfl
 * Smoking Wheels....  was here 2017 syilpopbmulucmhktbmnnpausnulvddmkshjospsghirkzkz
 * Smoking Wheels....  was here 2017 haomfpjekgxwizmruawtiyvktipywkehnazibvxarzghipkr
 * Smoking Wheels....  was here 2017 aryhkjqhfsspeojmmrijwybaixvktiahckapqwyonmzlptqk
 * Smoking Wheels....  was here 2017 txdflmtvjieomxzmzivbpnniepaqowajnlmezxqhwkfenpqh
 * Smoking Wheels....  was here 2017 pbbbrunqrmvoiasoqomvctbjieysqgtpjyvfaignwszwqrgu
 * Smoking Wheels....  was here 2017 yqwrvkxqbxkrydcvbdtukzzkznrzmzblozrfysgsbnqzuqol
 * Smoking Wheels....  was here 2017 klyhwqbeulygytarecfnrvsyqukayuamftzueyhrfiqlboyf
 * Smoking Wheels....  was here 2017 vnykxemsjitvdopubsupiezscksqbqzprwvzkcjjhtuirpyf
 * Smoking Wheels....  was here 2017 jeurkuxboyhhooczborabctuhbkxduozodsyooscotdwhglu
 * Smoking Wheels....  was here 2017 jypabqgdizkqnzdmwlgauyfjnpldtroaunedvxuimkxsqgnq
 * Smoking Wheels....  was here 2017 mqvsvbuiyidgpipphjdzsivaghdxrbbhlkegqahwvfqrupmp
 * Smoking Wheels....  was here 2017 pgbdvryaxerrohmzmqgqgcjmfmacaylswhxgrzesqvevbmzw
 * Smoking Wheels....  was here 2017 tcgaoikcxyptnwfnuuuyckttlvvscmhktyriwesdbelmblut
 * Smoking Wheels....  was here 2017 ktniqcflagsnuhjkwqcbfofcdirdkgluylfxkfhqrjugndaz
 * Smoking Wheels....  was here 2017 czhgbknllczjwatyofvnsdeawctwuxymncjstxryfwtxnqbj
 * Smoking Wheels....  was here 2017 uvffzuvnrptupvmvavyycbkihnpuhmekxkjsnjvdpjankclb
 * Smoking Wheels....  was here 2017 noexwdwmmemraqwxpaohalwamibzfdtprenbszzlessmsaal
 * Smoking Wheels....  was here 2017 suiiinniwnacmtnjxnbukoshqlcsellotmogminikdchfdwe
 * Smoking Wheels....  was here 2017 ygdqjjbhamiinphnulcwlbmsgzzpxbjwgoiyhhgqaaqvakje
 * Smoking Wheels....  was here 2017 dadidfzymisyyxgblcqfpvwbcjhlnaxkmazctycizbedlcbn
 * Smoking Wheels....  was here 2017 kiibcyyaalsvurtweytvnxuiehujimpidpzywrgsqesozrwp
 * Smoking Wheels....  was here 2017 buvuwrxmplcbkdkbqvwwdsntrrmqvaiaajxwubggkmnqnxtb
 * Smoking Wheels....  was here 2017 uebsltdrlhwwiuzbsururvnwerqwxhdcipsqzzssaldfbrev
 * Smoking Wheels....  was here 2017 loqgatbbcdixihqlmdahncmkjsvwohkmjwoecnrcntikxirz
 * Smoking Wheels....  was here 2017 ddmezoljglazosreijcijqjlglurcgrhuyurbaisegdmrgby
 * Smoking Wheels....  was here 2017 goukaheszvregfrhxhibeujecvordrvymwcpcdebkewacfmi
 * Smoking Wheels....  was here 2017 jowdchmglfjuzinhbzhaceadjylklhyanyjqprwwaxywifgb
 * Smoking Wheels....  was here 2017 kelujdxofuikpthsxsyvpqzdvixsbbjkhrusgujezcgbpmyf
 * Smoking Wheels....  was here 2017 mtkchsbjzzdvcmhnuakmihgcmourifrilysbauyfnsuzmlkg
 * Smoking Wheels....  was here 2017 yuwzndzstkneutevkscegnziopcovgsbvsvdchbofxveuwtt
 * Smoking Wheels....  was here 2017 lchraswvuaouhaszourinwtjoocahwphphapwejxscwlpthp
 * Smoking Wheels....  was here 2017 vrhpycegpamejaarkpbqpfdygyjvwcpybgllanxhbysxfhqz
 * Smoking Wheels....  was here 2017 fxtmtdqtxtvectltiqjcdrfbpjpbucjcwjnvorwzmikwezqg
 * Smoking Wheels....  was here 2017 zgxgcxehsykwulpixtaxcqeaxtwbqlsdxrwfohrmnmewhoib
 * Smoking Wheels....  was here 2017 unbczvbegmfqzogwayqlrqkgogljgtutglkioebowupuqacg
 * Smoking Wheels....  was here 2017 kuxmmksxaonynwozunemgosqkiwwqcvujhhcelbfnykqnooa
 * Smoking Wheels....  was here 2017 bijddpvfuowskhwnqatxoobckpxpermjtyxsjmusuvrvmrms
 * Smoking Wheels....  was here 2017 crpyollenebzzcsqdguznxpxuaowizqyjmxqhwtpcqrwjcza
 * Smoking Wheels....  was here 2017 cqyeshtznibbvtytdfxdhgvpctdhzshciegokmroguxoeult
 * Smoking Wheels....  was here 2017 ygcfuveefefoszrlvgabilmyaferewvsyoalkjnrexdbgakc
 * Smoking Wheels....  was here 2017 uvzuevmojdzgsugqnwiripmxpblbfsvyxlrmfymeezlqefsk
 * Smoking Wheels....  was here 2017 zwswpkpbawfgdkgmvwdffcbuafzvrqdebxudzubpsdbwtelj
 * Smoking Wheels....  was here 2017 despaysajhwwnhmisifddmscwwamimvbmeibeuyrotopzuzv
 * Smoking Wheels....  was here 2017 dvpmnbjxxpgrsecuenjdpqcpvjcygdhmqvlgmaclspqwfkxx
 * Smoking Wheels....  was here 2017 dcifqognlfyntbkvryudfqghxmaetxbnbqnxvvsekmkbakbb
 * Smoking Wheels....  was here 2017 lnzsaphuxtqlzezovlxiyxikjavpkfaqqrflkviicrcrfomw
 * Smoking Wheels....  was here 2017 rxbepntboejtwyrilbhfzaunrgtszuflnfkoqwprpngpuvof
 * Smoking Wheels....  was here 2017 ugdcnwbvxqmciepvrbyltvkjpojkoraucuhgecmhxsrwdlwg
 * Smoking Wheels....  was here 2017 vxddhpyvsolgivbwxayaykcydojsmaawyfgravgjeeiutygk
 * Smoking Wheels....  was here 2017 ekfgntjbypbggcqrurtcmdcnngxzgjabxoyhhrilabnamzvg
 * Smoking Wheels....  was here 2017 mntqfsnwvrinpngocdycnrwqhtdtskeyeagvmnkhcuuhjpwr
 * Smoking Wheels....  was here 2017 phltmbyrxzpoftxfbrmuoucacmrwxetmcgiefknxmaytsyaw
 * Smoking Wheels....  was here 2017 qaehvrhgyxheevynzuncgqvradgkdvkthzppmtvoisyrcpdf
 * Smoking Wheels....  was here 2017 zhcfxqnqwdgnszaomilfnnexhpxszxyeqhrmkdutfzcqigfh
 * Smoking Wheels....  was here 2017 gvpspiwdyonwmrxtlixoodqekbyhgcljfknpmkdgvhymlvsa
 * Smoking Wheels....  was here 2017 irigeiueskiufqttabuxuhzhbyvbzkgglygvjrwcfhfhtqdn
 * Smoking Wheels....  was here 2017 iffmanaowafcavwlobhdybcfiwjamczxxrhjzidmoxajwdif
 * Smoking Wheels....  was here 2017 pwkkwznhldzxdovyretlwvggjvqnioltnqgtnymzkhohnbls
 * Smoking Wheels....  was here 2017 unheobmqrpqoffmrgjxivfxwuyvdjptljcbpkininvjxuitx
 * Smoking Wheels....  was here 2017 tenhjkjcaqmoaoyfjzomfbtxfqosoegvvqwwjriovghgagxy
 * Smoking Wheels....  was here 2017 qdzkrwylhqztppnmmoyvslthtpnhhnmbnacuhhaxqmhrshse
 * Smoking Wheels....  was here 2017 uyxnencskhzghnvqcxlphudiosvfccioiijvjvdxkqqttefh
 * Smoking Wheels....  was here 2017 vkptutcdsnmipwrafarebqjnedraurxxjvppabihxdxhdvvd
 * Smoking Wheels....  was here 2017 qotqtdkfpltpkhehwfpinweqjjppkemaabxdydpccrwjeodw
 * Smoking Wheels....  was here 2017 iqgwlnttxoiwsvrjlbhziomrbzlyhwrawutpcleohenimvxw
 * Smoking Wheels....  was here 2017 ghhipbbsolzfvstioifjldoxoyemzgjhvdtlrnmgxudtviit
 * Smoking Wheels....  was here 2017 cfggcbojvbtzjkfpcaawadvvjlcrhapnaivjahhwtyhkgcrl
 * Smoking Wheels....  was here 2017 rntcddrgfpxscpfuenpfnlaffvtlhesntydixvmkuiskbinb
 * Smoking Wheels....  was here 2017 cltodefdmlzfbibvehbipdccbvwugyimstbngmjfhulcwmuz
 * Smoking Wheels....  was here 2017 uojowhczohtppvjusdwmeqgsejnctugttufkewitsoualimw
 * Smoking Wheels....  was here 2017 iraidumcuagfgoxcrdrcmmzocozxqlpaajprfvduvafzwvzp
 * Smoking Wheels....  was here 2017 qviifhyzpvsowfvkdoivxoalmvsaxxscvbggzmshqwockgwh
 * Smoking Wheels....  was here 2017 thggnqcjtcsnlvmpnzaqeygilxpoxkdfvprjkeipjavsqaai
 * Smoking Wheels....  was here 2017 dpwaszyigobeiqkukddteazndqovelurwbmlsnkenqhikwlk
 * Smoking Wheels....  was here 2017 ioqvtqtbicrubbmjrdjqdkqmbfyjnrrddtofhjqvvdmusvoi
 * Smoking Wheels....  was here 2017 hgfeugxcnwyzlxuymeoymyxaachbaefnxebpwvbmjdffycxh
 * Smoking Wheels....  was here 2017 bxlriqdgnhhpocqmdxwqwsudyxhyzcxyxdlujgvmgqlxoejq
 * Smoking Wheels....  was here 2017 acokyxllibpqswqaibtxgcmbdobjyyruxrhhygkicumkltzb
 * Smoking Wheels....  was here 2017 vqwlrlaafbvmmsrbwsvgurmibgvxtmorcdntbrospzvppvdj
 * Smoking Wheels....  was here 2017 jnchpuilrmgrpjtdxcahyjmsmjdikrynvzhcjqftswimkqku
 * Smoking Wheels....  was here 2017 rcdqgxbmmtlcfvhevvkbkekfjpuugsjmsbapwmpptkzljrpq
 * Smoking Wheels....  was here 2017 fvdmhugdometohvifqmsconcawtowcswqkjrrvewftabhrvp
 * Smoking Wheels....  was here 2017 opmypwbsfrkagggyzqwrebhwwijfapajsifafnqguiacgoln
 * Smoking Wheels....  was here 2017 pkvmksyrxlnlckorfblrcolhrkcpudrwhhspgrzunutroqbo
 * Smoking Wheels....  was here 2017 locwdervkfyvcuflhmjrodwjltutnzgnbegoqqkspbfcuild
 * Smoking Wheels....  was here 2017 mokzlkedrqnhqqsjwrcwmewjlikbrqpquankpakopiszsktu
 * Smoking Wheels....  was here 2017 hgebirqxarfdfjyuureragwueggbdtuyrbkvorqdfyubkuhn
 * Smoking Wheels....  was here 2017 uqcnxrppwljyqtykduqvrholiyxoyjehbwatfrcjlreneuqj
 * Smoking Wheels....  was here 2017 cbacrgraakmoaucbjpngbhyhycbrlsivpfvkmlaonjyppvru
 */
package net.yacy.document.content.dao;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.util.FileUtils;
public class ImportDump {
private final DatabaseConnection conn;
public ImportDump(
String dbType,
String host,
int port,
String dbname,
String user,
String pw) throws Exception  {
this.conn = new DatabaseConnection(dbType, host, port, dbname, user, pw);
this.conn.setAutoCommit(true);
}
public void imp(File dump) throws SQLException {
	Statement statement = null;
try {
	statement = conn.statement();
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	FileUtils.copy(dump, baos);
	
	String s = UTF8.String(baos.toByteArray());
	int p, q;
	String t;
	loop: while (!s.isEmpty()) {
		p = s.indexOf("INSERT INTO", 1);
		q = s.indexOf("CREATE TABLE", 1);
		if (q >= 0 && q < p) p = q;
		if (p < 0) {
			// finalize process
			statement.executeBatch();
			System.out.println(s);
			statement.addBatch(s);
statement.executeBatch();
break loop;
		}
		t = s.substring(0, p);
		s = s.substring(p);
		//if (batchSize + t.length() >= maxBatch) {
			statement.executeBatch();
		//}
			System.out.println(t);
		statement.addBatch(t);
	}
	statement.executeBatch();
} catch (final SQLException e) {
ConcurrentLog.logException(e);
throw e;
} catch (final IOException e) {
ConcurrentLog.logException(e);
throw new SQLException(e.getMessage());
		} finally {
if (statement != null) try {statement.close();} catch (final SQLException e) {}
}
}
@Override
protected void finalize() throws Throwable {
close();
}
public synchronized void close() {
this.conn.close();
}
}
