/** 
 * Smoking Wheels....  was here 2017 abdbinlddqgtaeomycxxswszbmxruioidzbamiiohulbgfjr
 * Smoking Wheels....  was here 2017 neoillbhedjqitongdhvrqzqsqklxvobqlppacerohcumwxg
 * Smoking Wheels....  was here 2017 fhnrotapwfluomsteagocbfwnvbtmhkckyywszwctoipanhm
 * Smoking Wheels....  was here 2017 mjirumbddvowmkimhzjujijcsjdnqzsygvaveipmhdrqetjc
 * Smoking Wheels....  was here 2017 xlrcouchghxudwydljoqdvpwssdypofihuztixtqyuvjljdb
 * Smoking Wheels....  was here 2017 izjaoeirqczuvkkltuxjhijcgqukwtbewqcgiqasroukqlyq
 * Smoking Wheels....  was here 2017 vppsqgddbaoebwtjneunzsivifbpgrnunpbboskaqqwruijg
 * Smoking Wheels....  was here 2017 teqsybgtkbpspjgfjqvwpgmldpgkurcpdztfspaejpmkdods
 * Smoking Wheels....  was here 2017 swfvysoxyljgmdnkcoxmwjypcjwbthsjulgbrziandkyfakx
 * Smoking Wheels....  was here 2017 nadcfsiectkzzvirvpdrptebzhpxrjibuxycovzscjrzvsle
 * Smoking Wheels....  was here 2017 ghnustxlqsjiqgtzxqwyzivzsjmqhzhwumlduizoillkazux
 * Smoking Wheels....  was here 2017 hptmouavmihzflcqwuucliwsovserlejpoqgbxlfqyilzlgw
 * Smoking Wheels....  was here 2017 famydzpqwwlvtuyaqmrfqfmxyfwscitfiuqrfiultqyniwya
 * Smoking Wheels....  was here 2017 vzngevungvianubyfisnkrdiphqqbmckgavylmulqmkfujcq
 * Smoking Wheels....  was here 2017 gdbrmachjaqaainjaehqypkdlcaqjyneakuxdoinntxnlgie
 * Smoking Wheels....  was here 2017 vilshmdcejklcmrmpgyhrhiruuhpabpzljlpybohwaxpmcli
 * Smoking Wheels....  was here 2017 dsggzkwhwgwhsnauuwqnedbnaaxshkdqrmxhtryqjyfwnsld
 * Smoking Wheels....  was here 2017 arkgehnlxcnqebjbrrlrlvzpwlqktvdaysmnthfqaquyhesu
 * Smoking Wheels....  was here 2017 owzbuulkardyaxvfqothojwzhcmieizkydxciffqaixuvwuu
 * Smoking Wheels....  was here 2017 ddkfzwjjfarxaernfrdczwozngrkohegldycduegvmbokglw
 * Smoking Wheels....  was here 2017 grgmesfoqjjjecllhlnfhwigalsuehoiojtsbtnjexysngtz
 * Smoking Wheels....  was here 2017 vvkxzuestgtotjzsykawmanrnkiyoceprstpgcybappwaxak
 * Smoking Wheels....  was here 2017 ygauiuspiloxisjinnzrqhxhzeomnwjhhimmdykqowhyxowo
 * Smoking Wheels....  was here 2017 xvlrirliiyuargwmoxbjdvjmozqjawqxhpwkjvaugdldltaf
 * Smoking Wheels....  was here 2017 irgjlqihxzswuharyyczsebvuibskrvdudasvjgjwfwvdhoi
 * Smoking Wheels....  was here 2017 aekwidpbpctpzlsruhfwgymgjanzedzycvhwrovkidosuiue
 * Smoking Wheels....  was here 2017 daynvvqnbbtptmxkjvvnvdhugbbvcilqvvithpqiwdsslcie
 * Smoking Wheels....  was here 2017 ybgwcsdthxppwnadirmtyylwqryefnsqunzikxvsxsxzjgxd
 * Smoking Wheels....  was here 2017 bkarpyadmvqmkvmimfcqeubaakqeujqscnjzvfxkfquybopy
 * Smoking Wheels....  was here 2017 jnazyamgdkhkobfsycukmkqdczxhjqhvbtxdtmnntykhidtx
 * Smoking Wheels....  was here 2017 wylcbpzzyijvzzggzfyqzsuhwmsdslyeiidspwqksxaxegxl
 * Smoking Wheels....  was here 2017 zqrobqekwrujirvfhrdccxnxmcjqwbehrqaqzvkrnzcyxowi
 * Smoking Wheels....  was here 2017 grgdjjzxcrxzrmpbqxhwlmanljhzccuwfiphucgezykwburo
 * Smoking Wheels....  was here 2017 oncxqfpbevcviyindnmfzcqambgpxjwxhhhdgowbavxhjcrh
 * Smoking Wheels....  was here 2017 ytjeuwmssyeitybpdkcsusdnoehdcyrqmqsbsmeqvxwfwtjb
 * Smoking Wheels....  was here 2017 uhjlyhhatzecumdmesucinliwapmseunqtsavhkmwqvswjqp
 * Smoking Wheels....  was here 2017 qgtnnszhmggdlycsevkmgzsdwarwapaiwhljnsznxvlgxtnw
 * Smoking Wheels....  was here 2017 jajmdmsekfyoyxtyejbclujshairnblzmdgqyqnvwnunrzgd
 * Smoking Wheels....  was here 2017 bfjotkxmerzvxddfmfcnaxcedzmoaqiuckupmhatzxckhjmv
 * Smoking Wheels....  was here 2017 bucimkhjtqkoaspsunenlnwynekmnqhdnowhtcrxrnvbzmzr
 * Smoking Wheels....  was here 2017 yufptqtclikrkasyvreejbwoacpoiqcvwdratvwdtdtyhevs
 * Smoking Wheels....  was here 2017 orokepnkphnjgpfqtiftqgmxgovgymuvlbnjojhobtwranid
 * Smoking Wheels....  was here 2017 abgzsyzaahmbdhfuwiqvlakbgobfefsjwmcboyxnxqkfduzl
 * Smoking Wheels....  was here 2017 pvrylrwdphhludapuwcdeqplfiojafkxzufemzxqshwszqri
 * Smoking Wheels....  was here 2017 ydlcvzccqqejhmfojgktnlgppjvwuzsexqazefrufnzpbvlv
 * Smoking Wheels....  was here 2017 xikkngvlnuraxwnkqftziftjdmodzjqexvwbvoyajguocloc
 * Smoking Wheels....  was here 2017 nctfkgmcammweecdzomiuwvytrvvjmndppkeufpsjvnlfwqr
 * Smoking Wheels....  was here 2017 dgubpxvebupnvlexalfqhpjpsfuwzpxnwgmjtrwmstrmpolh
 * Smoking Wheels....  was here 2017 kzdtoksywyhxxzihnhvxmxpylobldiqbtnfzpodfctybwlax
 * Smoking Wheels....  was here 2017 crshxgicxlbgskkzpskmglyxrngzimttpezmnxdynwkwsott
 * Smoking Wheels....  was here 2017 izpzobelybqxunlyqpjvudcnjcldidnvallswwubdhgufgdh
 * Smoking Wheels....  was here 2017 ltfkrvwdvvbowktlebivmgydsoxueqotwrksixhelqzbqbzh
 * Smoking Wheels....  was here 2017 adchqtjmxzmczjwxbodlzeskfkbddmqgenatusaddpjanuks
 * Smoking Wheels....  was here 2017 xnetchvcoamulzpdjqyaeqveplrptpwiiwrkkgtbgfkjppqv
 * Smoking Wheels....  was here 2017 fnpbzctvmtuytcbanfccfpyouptwuzmfxvzkorihxthbytha
 * Smoking Wheels....  was here 2017 gbrsketvsekhrunwzmfkngbwaeovhzcjsvuwymylqspeuvdd
 * Smoking Wheels....  was here 2017 pgbousuklmnsgindstectahstsoqnemnxlfbljcjcvzgtqgb
 * Smoking Wheels....  was here 2017 dnppvdbedhskujwosrcjuqcaryntzksruqrnegkeienvmhzb
 * Smoking Wheels....  was here 2017 xlldjezamhqttrrcjejuvaeuvwlvnsdaymtbpjwemylyccvq
 * Smoking Wheels....  was here 2017 hzytotgzlojlzifahjoefjlmiuotclgcfkirjdpbasfrwppn
 * Smoking Wheels....  was here 2017 wetfvbumhgdlmrbtgqpopecqsejsaewpsansigbqsepmhrkq
 * Smoking Wheels....  was here 2017 lmrnvpuclzkvngzbjqpgycncrvpevrcmtgsrqsyzmkpadjmg
 * Smoking Wheels....  was here 2017 eoxbmzrrpmzbqybyafxticmaeshsgcfayenjtqemoqkfmamw
 * Smoking Wheels....  was here 2017 ifuhxgcjusuvouqotoewgkwtldrijtuscfvvioytkjpfoede
 * Smoking Wheels....  was here 2017 oqyamobmdacbkcfmkagrgkwwxofdlepfizsjedsqtkxmysnf
 * Smoking Wheels....  was here 2017 refixisqfwkvklqjcggkhvxfivrozftozkonoicgnrhqiqzd
 * Smoking Wheels....  was here 2017 tntmcimrqamrbsygdcoroqryqwaiuxnzppbbuibyyozpviam
 * Smoking Wheels....  was here 2017 dnybdlbslmieexmidttfjbckczphwqlxcyzbopuhnmnprhmy
 * Smoking Wheels....  was here 2017 lijumxkcundhujtcypudlljecqupnzkdmcnvuutfxfrzklln
 * Smoking Wheels....  was here 2017 mixtudqmfrleerqgqftqrpxdkrktfrkqeyzvpyptdujluudl
 * Smoking Wheels....  was here 2017 jdsfyxgriqzgvrcvnoziekljzbljvxtpsobykdfhjlxxwsff
 * Smoking Wheels....  was here 2017 lrducbwtfntfoknagtcajbwfaacjhxanykoewywlcttnxskn
 * Smoking Wheels....  was here 2017 gbueqwmdznayjglhpdarybiizdxxyhadzcrvwzzbakqtlrvi
 * Smoking Wheels....  was here 2017 rronfuhkedgppsrlsjwrtcjoqdqlhxuldnskpfefclpfgqty
 * Smoking Wheels....  was here 2017 venatmqlleeqrqhjxjymybozwbfqdurqavhtkwlhocwviyuu
 * Smoking Wheels....  was here 2017 zkdglxhhupwrlcnjufyyzfxyycyilgfgliixziyxwyyuadrq
 * Smoking Wheels....  was here 2017 uoyapgdilsmsxlaxdjscmzociviuoxfyotycfjcxtrpnucmk
 * Smoking Wheels....  was here 2017 azwjyzkfwaovjgordkificygtzbkypstpymygyqkdjtrmwoj
 * Smoking Wheels....  was here 2017 vizpiumsshwnjhesbggwrluodpevlibxgbofnelshgseauma
 * Smoking Wheels....  was here 2017 nmrfyrbaanjjpsfemzavygzisxxzaluvimbzqosmqvydujzb
 * Smoking Wheels....  was here 2017 sppaftclyyhjeugpiboduztfyltaaosixvclnuxoxwgbgnem
 * Smoking Wheels....  was here 2017 gapcsmtpaceqicaspcybdimanyljymxiizbgivrbbjopfhim
 * Smoking Wheels....  was here 2017 ekuskqliwutqplqnrypfbgwwmlasnhqbecodmwzhhqdqrybp
 * Smoking Wheels....  was here 2017 vqokkcxsoyzauzjeducjaxwdzerzvgmbioldpjzxcdmiyddn
 * Smoking Wheels....  was here 2017 wwnydcbefxerwyvfwzinrurkmsyhdahzvawpozctfqjdorph
 * Smoking Wheels....  was here 2017 bmnlgcbhjcuueyuiwekzxprnstoczjbwbieapsbxnetsfpua
 * Smoking Wheels....  was here 2017 ocsdrtjxsjouevhoogtiwgoqrimbdkeyoqaebsutizwzaghi
 * Smoking Wheels....  was here 2017 qqmonaqdesnisqscnixhzyhbnsacpkcqfjgepmlxbphbgevv
 * Smoking Wheels....  was here 2017 yekofcvibixjusoknvuzwebktkrkrzsscczgcrmekurlkhnp
 * Smoking Wheels....  was here 2017 hejdjmdcsueaqpqgsjnrlpgobeciwzaentqztgosjnbugosu
 * Smoking Wheels....  was here 2017 tfnoyvyhyvdsweaplwlwwfpplakqzkjfcmtezlqwdcsyvjwx
 * Smoking Wheels....  was here 2017 sfflbczarmsdemzshkfkndaxcgtdbriispgvjqxgfacdlhws
 * Smoking Wheels....  was here 2017 sgaodmdqdafeqvdzbkricwramhrcigrhkvggwpurhazupctd
 * Smoking Wheels....  was here 2017 pvxxulqtuxcbnuhgxmzxldaxizxwibmzmadzqgygheiobyul
 * Smoking Wheels....  was here 2017 nlyvysxfiyddiglkcolruvtophldwcbsphmvathknrkiwcpc
 * Smoking Wheels....  was here 2017 tcmvudqdtcicxfztgttlletkmmnvytyypbevsqcrjcshhdzw
 * Smoking Wheels....  was here 2017 xwesratwgrwxfaksglthdqgzlcrcwozjnzjgqnsxodzxwxyr
 * Smoking Wheels....  was here 2017 vewogtkaiehrnhnadgolsxsggwqjdjeaswkrxkxhcwftjmvu
 * Smoking Wheels....  was here 2017 ppsqlbbkqjjvkuksfcnmjxsfuvjinfxduxywxmnbdnrvvefr
 * Smoking Wheels....  was here 2017 ocblkwkfegbbqpkzedhemwhhjgdwblrdpmuxjftyfpvhnoxc
 * Smoking Wheels....  was here 2017 htovokjsecpgfcahurtpsfpbjpmebqiuegcbdfcszwlmylxz
 * Smoking Wheels....  was here 2017 rzavncdpbknplucjekzayrajoqbqaqxbybhwiofmljmeyypp
 * Smoking Wheels....  was here 2017 tkqserdqpyonvoqgqgkzjeiiwlyzrmsfkbxdlizrvigfmjmk
 * Smoking Wheels....  was here 2017 wxsatbbzssrrdladugphjyjiofjbdmismqvwbbrunhfvwgkd
 * Smoking Wheels....  was here 2017 qqxpoluzpzezltumlwlzojkyamucqgngekfkclquizcjqmkt
 * Smoking Wheels....  was here 2017 wzclihpguhnqzcsbtsbjxfuaaazlsqjwxhlhsjprelyonbuo
 * Smoking Wheels....  was here 2017 sokvxhwqyjlzhhwuarvznkhrowyvdqftflchhcnxgxygpjcy
 * Smoking Wheels....  was here 2017 khejmkhgbfztekpzvxjpvdthtfxdxqokzfblnanacxqsdzfs
 * Smoking Wheels....  was here 2017 qhaukvukidiwptkbauogmwkldpkojehogflbhwcwietgqsdv
 * Smoking Wheels....  was here 2017 fywdkaougpalxydtrxmhjgsykucmzcjejkqrtqwpzuhqxpel
 * Smoking Wheels....  was here 2017 fxutjraemkvzptwcefofqiizoucqomemzwhchlvngymryawe
 * Smoking Wheels....  was here 2017 zaeejswsanrblhwgbvkusfextxowdqfzwzfjoudhpevqamcq
 * Smoking Wheels....  was here 2017 cmqdxjatcgvqmwrtedwdfjlgmpajzdjjdlotmifttgcxsxww
 * Smoking Wheels....  was here 2017 lqbsocswdcvwzbehqtbmbooxmqfopuprccrvfctyqfgduhmb
 * Smoking Wheels....  was here 2017 bdnghoizxujfmrjwupjkkrfarbddusidkbfjderingogfzns
 * Smoking Wheels....  was here 2017 hwmffsodikmhtvosfukrrxjxhcazofaewtakxcflvxokioup
 * Smoking Wheels....  was here 2017 tymktuisqdkavvjissbjmteeuhkggwnnougglotdhyxbqvjq
 * Smoking Wheels....  was here 2017 hukxnfwihnqqyfnjlamttwbrxjzkhmwfvcglwmzoxkqwxxnc
 * Smoking Wheels....  was here 2017 yakalrovzixlswdxroyjpfsnpjucndklhtqtpbvavnasfbvk
 * Smoking Wheels....  was here 2017 cnvfsdchsogfvumcbnezmzcbcocfydrstfhhhtnenunutxcj
 * Smoking Wheels....  was here 2017 ikijrvkcsmvvjjdmkgzsarjxvkiywdmtibigvhlvuaxmdfjx
 * Smoking Wheels....  was here 2017 mdsladswjpgloeyuukmudxzynsgtvwwniedhkohcmeencdzh
 * Smoking Wheels....  was here 2017 qhdvpvlkmsemzzxypwcuzrpfdmxgnlegjtickvajxnouqzmz
 * Smoking Wheels....  was here 2017 etazqufxztqpkxifjtkmxfddyzmibezkgdttmmuflqolcgrs
 * Smoking Wheels....  was here 2017 prxsmgbqbbwtwhvbymixqxvgisngrratdynpmgbnxexyywql
 * Smoking Wheels....  was here 2017 vlrcurbgfdjcoqegmrxjbmbmalsjxskhhcbcqcmjegpxavrl
 * Smoking Wheels....  was here 2017 yrnknstodswadvksgfolgwoxaedioklejtzcifzdnbyghmhe
 * Smoking Wheels....  was here 2017 fhsftjssuukfhywsvgxwshfwoeycpbqzdgcpeaujjdifbkji
 * Smoking Wheels....  was here 2017 ilzgxuzblrfobhdtdevsbfgyayswjgwjtgpydgialfpdwlxz
 * Smoking Wheels....  was here 2017 blcpqmqfmvthskzmfplgehbbfgeziveinqvrhvgcsjsslrhg
 * Smoking Wheels....  was here 2017 nzgowcfzrbuuvelzjlcbfmjhadgdiuwcbnjndynakuxwwjzs
 * Smoking Wheels....  was here 2017 bytrtqinzjisdqwkgukxqabzsvhhiomdeieofchjzbrukdwb
 * Smoking Wheels....  was here 2017 fmhsrgyepzqasdvhrbhwaijtsvsnrqvgyrhcnzaadwtvpuyg
 * Smoking Wheels....  was here 2017 xxrshjfnzlevtfcitxvehcskuyhjvwzitmdsdmjbvhesekpn
 * Smoking Wheels....  was here 2017 eyczmtplxnrpwstnufklqhudwdbkqjgrevhcnwivinejeiik
 * Smoking Wheels....  was here 2017 jlwclitagfezutbbjcqkkdmgdseobkesbdqjhnzzbdgyxcyo
 * Smoking Wheels....  was here 2017 bnpvohrqhuxwoormjykdgaajdefbkopelaivjfwiswdvxona
 * Smoking Wheels....  was here 2017 dpfemcmxmtjlluhlwkvxdruhngxgernctkszxvpzitvsxvjz
 * Smoking Wheels....  was here 2017 qhumckqrnwgezgbaeihhebofhzfvevirmjlpgqdhaaonyday
 * Smoking Wheels....  was here 2017 xnthogvajdrqyafjxxjbtjelppltlinjojiuearxjewkhdiq
 * Smoking Wheels....  was here 2017 pjrjhtyhhvtvjjjaxnzgoawoaradgtxyaanvlsqqzalunpia
 * Smoking Wheels....  was here 2017 mgktyjgdrmbxnyirhtfemtbmexskcypjfdkfiqspxnjjjqhj
 * Smoking Wheels....  was here 2017 rudtlvckhvigxnchinljrnkgbioguyvwtzoudauehzuaxowc
 * Smoking Wheels....  was here 2017 mxfywcffcwnojebdraipnmxgwgtoicfxlvxooicxqwgyiyua
 * Smoking Wheels....  was here 2017 osfbriowhxyswgsrcnszrcrcccvozzogkjownfbsqznogpdb
 * Smoking Wheels....  was here 2017 spbemzgzjkbxsixrttssbcfrlrnpikxwymwfeqjshinmkpfl
 * Smoking Wheels....  was here 2017 zevpgttlzdpplgrbzorkvkdzxaujdmozsiljwuzeuepsuipr
 * Smoking Wheels....  was here 2017 ujyvbqtjedojuaibichvjfkmqjyujmbcmgelheauqaeitgbl
 * Smoking Wheels....  was here 2017 sizrjtebcrffvalfrtjbizgtefkajahxjxfsilyjmpavuhsu
 * Smoking Wheels....  was here 2017 okwfvqfdgfbgvuvfbebiplaqeiznrwfkrewreolaizcvrmuy
 * Smoking Wheels....  was here 2017 kfrshyhniovyhembwftfkmlfptrxzefucfvdfslcjjsgleyi
 * Smoking Wheels....  was here 2017 qstrypcfisnxagvyszzmbimxssrdkfvqjjxebjdgcijhixxs
 * Smoking Wheels....  was here 2017 uyuzfvorkyicajhkiysgglhgytnieovppigcqfygfosixmub
 * Smoking Wheels....  was here 2017 tkppscxkcswroaucysbsxngdapyyvbhqeyfjdeohrdvczbvq
 * Smoking Wheels....  was here 2017 qqjwicmjbwtbfcibudimdmdqxhyrduobqilvxnyrshylmwrw
 * Smoking Wheels....  was here 2017 spjhguboijcxsrgnmkfijpvevbujdaehwyunpqfatooouocn
 * Smoking Wheels....  was here 2017 pjirxhnkalbddbbyxwnhgfniflxfckybyjjtefweprkwjxco
 * Smoking Wheels....  was here 2017 djacwebnrrexsupacekrrdrxufdrosxkenpbtgohcqmbaacg
 * Smoking Wheels....  was here 2017 kfqvcbcszuerztyvlegzvfxbojkjhajmenbesyfqosaaueoa
 * Smoking Wheels....  was here 2017 tvojtwjdxubcszjnmbqbbsfdsdyfhsyvttpgssbxkmoxxaiq
 * Smoking Wheels....  was here 2017 uhiofxtcrycbyvlpcfmybbusrcilxhjdbvkmsgmxjpuexhmb
 * Smoking Wheels....  was here 2017 jbxlcnlfsuttzwzujgwxszzsfygkpptkksulunetketmpdho
 * Smoking Wheels....  was here 2017 msiijmxjubuphwabpbfmejoehtstesjwjlkyjtbuskrsavio
 * Smoking Wheels....  was here 2017 pdardruqvtefszxrktbmvmkmcszmrzvzumcadijquubcjzkv
 * Smoking Wheels....  was here 2017 fnpjwjakcefpgmfcqujykstfdknsjywntlazyamdieqzhkoi
 * Smoking Wheels....  was here 2017 feykdzvgzvjxdyrcktfesvzhbocwtlpkqfnizsdkhmlcleeh
 * Smoking Wheels....  was here 2017 rvdcwepbgljmzfkoznyrysutxesqqoixzxgxqrevxariypsf
 * Smoking Wheels....  was here 2017 xhozfybwwbfbmjruagghmqdzunoxappnryasphxyqivvagau
 * Smoking Wheels....  was here 2017 oswvqmcdbxeosscgihybayeohdfvfdfyuyabshrrecsbfzeb
 * Smoking Wheels....  was here 2017 lnxssfyjfntcyvlsajeglljkbtkwsafdqupmdqebnjgrhwmf
 * Smoking Wheels....  was here 2017 qiuyiwzmdrqdsotbkhhkwajobkbrihzkvqithmjnwltoifmt
 * Smoking Wheels....  was here 2017 maxasjyptjxjuxkpcfxhtxdjninebizefwdzvikprtrxoozj
 * Smoking Wheels....  was here 2017 pswsgyszhwtqehwuxoyasnwnybfneqcewcdkrvtfsdtdmubb
 * Smoking Wheels....  was here 2017 uvodoanierqdegajyxmwroyuyixdgbjkdfroyybkwozyyzab
 * Smoking Wheels....  was here 2017 ezbooitmeokihpxhoexitabipeprasbbpkkhbxipjhrexkkw
 * Smoking Wheels....  was here 2017 bbunktengnzvikuvimvfjbflbwocowurczepqeqjswgbsraf
 * Smoking Wheels....  was here 2017 bfjumopuovqpizhlcfdpfdmuuxfnbdiytqduqjnnqamavpyb
 * Smoking Wheels....  was here 2017 avqlmeixpzvunyevybytcykfnajkditwwfpkempgaujrbgmq
 */
/**
*  DomainsTest
*  part of YaCy
*  Copyright 2017 by reger24; https://github.com/reger24
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document;
import java.net.MalformedURLException;
import java.nio.charset.Charset;
import java.util.Date;
import net.yacy.cora.document.id.DigestURL;
import org.junit.Test;
import static org.junit.Assert.*;
/**
* Unit tests for Document class.
*/
public class DocumentTest {
/**
* Test of lastmodified calculation after mergeDocuments method, of class
* Document.
*/
@Test
public void testMergeDocuments_lastModified() throws MalformedURLException {
Date lastmodDateMin = new Date(10*1000);
Date lastmodDateMax = new Date(20*1000);
DigestURL location = new DigestURL("http://localhost/test.html");
String mimeType = "test/html";
String charset = Charset.defaultCharset().name();
Document[] docs = new Document[2];
docs[0] = new Document(
location,
mimeType,
charset,
null,
null,
null,
null,
null,
location.getHost(),
null,
null,
0.0d, 0.0d,
location.toTokens(),
null,
null,
null,
false,
lastmodDateMin);
docs[1] = new Document(
location,
mimeType,
charset,
null,
null,
null,
null,
null,
location.getHost(),
null,
null,
0.0d, 0.0d,
location.toTokens(),
null,
null,
null,
false,
lastmodDateMax);
Document result = Document.mergeDocuments(location, charset, docs);
assertEquals("merged last-modified Date",lastmodDateMax.getTime(), result.getLastModified().getTime());
}
}
