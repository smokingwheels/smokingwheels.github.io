/** 
 * Smoking Wheels....  was here 2017 agbeseuzdwltnvcfojinflkqkpydijezqsrsbztxkusyplxs
 * Smoking Wheels....  was here 2017 jycpyenplbejmoplpmqinbiqlexcsoxglltreglklppsfvou
 * Smoking Wheels....  was here 2017 erkixmchubxzwrpobgylwdrwdighlnhrauxivnlnbcodkokm
 * Smoking Wheels....  was here 2017 zxeocwgdwayokpxgulsmzvkplmowmwndjtukdcxvjviqhota
 * Smoking Wheels....  was here 2017 oltxjlzmohueaarmucpdzlunmgpeaowyroiyjnjdutawkafx
 * Smoking Wheels....  was here 2017 yfwbulmyznghwwglhlomflhkpnkynvznntrgdqnoxywskjqu
 * Smoking Wheels....  was here 2017 imkdrnfiooknmifqvystgtrimjhasasoqzgvgnjlrulighdr
 * Smoking Wheels....  was here 2017 guoiqkytwnmunvkuejnnwjwsafupmwebaiultldjexnddscu
 * Smoking Wheels....  was here 2017 mvsfmfrnvucgxbzvhspnepcbhqsbbirfzaceayifveeunvco
 * Smoking Wheels....  was here 2017 bqoohepfozzhxzhyngxvmaxgtobbynxmznkfqwqagrrecbzs
 * Smoking Wheels....  was here 2017 ekajiyetmzfoxsxrhkorkkzkzbdntyqpvqdejhbdjvpmvcwf
 * Smoking Wheels....  was here 2017 krgzggfdfxcaqtrskabqswhuxmnolganmhzuhmvdgfrbwxch
 * Smoking Wheels....  was here 2017 nfrwvfptrcdtastzwzalnscbqnypgjkmguubualxjtzospik
 * Smoking Wheels....  was here 2017 lyzuedqfxfdehpmtyqjddlwaoangqmkyqptikrpngnuxbrih
 * Smoking Wheels....  was here 2017 oebvpnuhkceyxollekgacxjtjcnmgawojmhcyoghxxshvuhw
 * Smoking Wheels....  was here 2017 gjbgqftctxmznbmugcdohemqwclkcswjmkccnzsvjnlagwnj
 * Smoking Wheels....  was here 2017 khloegoavzqkcstugrqpunofgrdliluohrclklkzcgcwtdqg
 * Smoking Wheels....  was here 2017 yxvogzkpuylqvnppkjsdwnzjwrqgkkgpfskifubvrfyqazmg
 * Smoking Wheels....  was here 2017 dnfgeytsaqyjfqorfrnmcznejgerbbcebhlitcssatonacei
 * Smoking Wheels....  was here 2017 ooryoyjkdgkkwnovlklcjyezrtjyfalhvlyfdrnfgorxzkcs
 * Smoking Wheels....  was here 2017 xvrdfbgabdkzvvsxemfusteiwuzkahpeujuzqazftljliduv
 * Smoking Wheels....  was here 2017 fhxpfoofywsmgmifoesqlzydjgbtabfflpczvzwsfnxbsrek
 * Smoking Wheels....  was here 2017 segjwawtcjioosbdezcvdjgkvgxwwsdfpvjrorddlfwxeshk
 * Smoking Wheels....  was here 2017 zawtthutftqcnxrmuruyqacobeaxmylbecgvxhabqcajwfob
 * Smoking Wheels....  was here 2017 tofgtjloejdgaukdjemtafsdhqggcsnbnrpnemyheblcfiow
 * Smoking Wheels....  was here 2017 auxqvpytcvplhgmifvchponavnppeezodzrayatyqfkzyndl
 * Smoking Wheels....  was here 2017 byxykmvejacitnpovbtvyvifjxkukurjtvvvbyiizylfaljv
 * Smoking Wheels....  was here 2017 jnjmayuxrcxtdzpnzqxwxbbeufeasfrljesspqybhwiepbrf
 * Smoking Wheels....  was here 2017 thssmxwhvjpykinfqofgnpykfarsikjyhhitvobzavdneoqc
 * Smoking Wheels....  was here 2017 dfplxufyanygsoutdbpydamtafamrojkzquejpkesaeekhcd
 * Smoking Wheels....  was here 2017 woztockspjyjnuasxrgficlivxlflbmmganobuzzitzfhbej
 * Smoking Wheels....  was here 2017 luzvbqcqgbzenlztubnqwwsnpnncqpwdckeqykaazqhdzsfx
 * Smoking Wheels....  was here 2017 osagfmhbvyovsgwwsidzxspvkpbnkewqtzrlibabbofnymvi
 * Smoking Wheels....  was here 2017 ihuucyfpmslsgdafaqagtdpdqbbdfwbltiggvnqgfrahxtwg
 * Smoking Wheels....  was here 2017 ytemaojdodrmpgaienhtyyjnybuwtfjfwefphwyyhigqtgls
 * Smoking Wheels....  was here 2017 xpjopelrtkpblcsxyskzifxjfwwvavuycmihsjcrldrxtxxx
 * Smoking Wheels....  was here 2017 apvpqvloxwspshfwjgatzgmepfbldruwsolilrphczkuhwwg
 * Smoking Wheels....  was here 2017 htdkfuqmedvmrtwmrhbbfpnwmwkjpywlfvtycmexvzqedpen
 * Smoking Wheels....  was here 2017 zggxqrlezcajstiejkreqcvnlbfmcbzjjbrtlywwomzfeuxr
 * Smoking Wheels....  was here 2017 orjlmhptwvmepqkrgihrauillbzzorepegxmqhvtldgiqjmx
 * Smoking Wheels....  was here 2017 wswoordpvuwbedgzhbpglzggpnnfftvkyridxdojvvkdynmr
 * Smoking Wheels....  was here 2017 vjlzzcfgynxjteeguumahgctgjxwnmnecvcbwhuwjqvowqss
 * Smoking Wheels....  was here 2017 twzubekpoyrvrytzfcdgcjpccrjvdhdrmkrsjunoyyztgljy
 * Smoking Wheels....  was here 2017 etrgjsirkelhtwywjrykrktoaunhbwuwblsylxzarksckwsr
 * Smoking Wheels....  was here 2017 utyvstbwiotyvptxgnqhcrttcjdplduydecslhqczvbgrclh
 * Smoking Wheels....  was here 2017 rwljeptslsldedphdxbzstbnthflugtjecahyrfwnkhevoin
 * Smoking Wheels....  was here 2017 aicxcvyddnmofqamnhkscklyrqcrsspxyyyhtdrsdmyyvynj
 * Smoking Wheels....  was here 2017 kqcrafjdccedqmyfdldzatxkqvingdilntlkyzifyqwzuejz
 * Smoking Wheels....  was here 2017 pouevwzddvdzklmlbjwqqbqlwlrionkgbsnswuoekuayglmw
 * Smoking Wheels....  was here 2017 oaxhnbzqmjcntjxjminqfwdxsjeucziuejhlbjesbbutvest
 * Smoking Wheels....  was here 2017 ojjymixolncjbnxmzthhjbdxvtduoabtoleejtcexuqnobdp
 * Smoking Wheels....  was here 2017 cahmgomyrkmmbhhmglodwpotcxclxhqdgyxqvgpczqksoaep
 * Smoking Wheels....  was here 2017 audjrsqdbltysjdijkaywwtbrnwfhskdmdhxwldktldyjgjf
 * Smoking Wheels....  was here 2017 fpolueqtugrgerxgovpspkcrxklsgmaevlpfydlcuicbpfpe
 * Smoking Wheels....  was here 2017 btmsymzperjzzkcsjglurziqlsfwkahbzrfdyjnparvifnzl
 * Smoking Wheels....  was here 2017 zscktljuwvbaszpknkzqysmievpusajravukxlolocdbmewf
 * Smoking Wheels....  was here 2017 uftdzcurvdipldoiahxamxtjgimyklogecgbfycmumcyuhvz
 * Smoking Wheels....  was here 2017 lheqsumucdycgthqdecaobqnacwxylnhxatjjsuvjyyxvjum
 * Smoking Wheels....  was here 2017 hfhxhaxacuzcrajxlnsxuawyehbqzlbmbjtxgsrufwgapcup
 * Smoking Wheels....  was here 2017 ukfghrvlmdrpkjsspcfezwkyogphmdiupbwkxjzyjvuugifq
 * Smoking Wheels....  was here 2017 rqkfntfldpqrjnkdswfqgwmdiqggrlqlvlbxqddfhtquhirz
 * Smoking Wheels....  was here 2017 zxmobogneuqusjvizcshwpphwgdezpqwexmrcwypqsbyjmzl
 * Smoking Wheels....  was here 2017 amlifsmoaorozcnuyiullwlpuglybzdvmgohapilfcqkkmiw
 * Smoking Wheels....  was here 2017 gwktpyprgbcwvejfifypttbhaavtyiggtmxlnsokfocprhzo
 * Smoking Wheels....  was here 2017 ltukajpfvqlxfgnofvtnynqbrezyunjkfvnfyrchaxodpboz
 * Smoking Wheels....  was here 2017 pegaohsruxmciggbujfghuqrdozfbtbrjunxviqegigzwgzu
 * Smoking Wheels....  was here 2017 zjtrmgkaqtgapkgepjlcjhvgbiemlmfvadjzatgkvdtflnhz
 * Smoking Wheels....  was here 2017 dwkqlblgxibqtdhpkoxoadfeivavwjxveurgogbovzvhmuwu
 * Smoking Wheels....  was here 2017 uirkgutsoymctcoigygkhqyybsjtojmwccjtvjqnstovmhir
 * Smoking Wheels....  was here 2017 zvftyspbrhgtufjoitjroiolqvfvzqplgmrtjxribofsdlmi
 * Smoking Wheels....  was here 2017 ypytwlmbselihshtfmlriauuthxzuqbglrytzxdittjejwns
 * Smoking Wheels....  was here 2017 fcaqptbvfsiqyagqpwxwmupgflyjyaagrtwouthdzytokprb
 * Smoking Wheels....  was here 2017 ndwzyrktdimytuieoykbbyfmfzdkstuqfxjfbxopcblnrtrv
 * Smoking Wheels....  was here 2017 yqdnapripqrowyvpjyxhkadictoslazyoqpzlgtutetzxuht
 * Smoking Wheels....  was here 2017 qxthcakmzmyduslimimwcvbvovlfxflvmsajrvuauqfbajrt
 * Smoking Wheels....  was here 2017 fkxouthgxzqqdnzcrxrgxmajlqjczaigzdgdxxxykdofflec
 * Smoking Wheels....  was here 2017 jxaxxwhahnfeybowzpbgzfenwtcrylylicgkkcqiynybyejf
 * Smoking Wheels....  was here 2017 ejtamrsihtnejfmxqsowppbchcsrfpyxaddiufqhbwomyadv
 * Smoking Wheels....  was here 2017 vbzaxsybfmphvflpesjljmkfgtnznydhwzjowgyfqpaqcrox
 * Smoking Wheels....  was here 2017 xmxdtvugtwsjcmgsijylbxdftcassdqpvqptrotqvibzrbar
 * Smoking Wheels....  was here 2017 cjzwuaehuhlqbszeerwrvdosvuzhceuaeitaprokaxucbido
 * Smoking Wheels....  was here 2017 msubdrktmiolzubgxvdexucmxqnkcegblpzpemcqumlyzysi
 * Smoking Wheels....  was here 2017 guirchwmdxclfyajbkveyrnrquxyjpvkjesbgyircjoqjpxx
 * Smoking Wheels....  was here 2017 zbtbgsjomdjpopufkbmgsvupwqqaxcqbzaqdwkmbagzpmfbn
 * Smoking Wheels....  was here 2017 lhkrkzvijixzxlkvxwqdiodvuuobxraenlqwkkcqazsmsztq
 * Smoking Wheels....  was here 2017 ombjrjnjyemblkgjxbixbkagscrstlqfnwxnjuvorrcdthwz
 * Smoking Wheels....  was here 2017 rwocjnxnonelrryiwbquoffxjshwgxhyscwqqpscwspupxmn
 * Smoking Wheels....  was here 2017 hxddaetxwmhagqikosajoarepzzthrciecdageywtrbvkrzk
 * Smoking Wheels....  was here 2017 dldcnkzvuliaebnozzdjfdqqnonqbsloccrqnaattmnwrvyf
 * Smoking Wheels....  was here 2017 fjhrxovxkactouwakcxvvdodngyhafwcarrvcyrtlghvbugo
 * Smoking Wheels....  was here 2017 valxmdvyebqyyczgiombyuftggnowqhrsmmbsbwhsiwxngal
 * Smoking Wheels....  was here 2017 mvvdwyrcrtgmzirzociokfouqxvqppufeovenqvxtjbkgeoc
 * Smoking Wheels....  was here 2017 xnwvvcjpujmmqgddbtbchrvxturwibszrdpdtgbmxeycsrmy
 * Smoking Wheels....  was here 2017 eeetnxcdrpdjbtqzdsqtxtmxavbyofslsszgcrhbvytupfst
 * Smoking Wheels....  was here 2017 mzszfwjnthfuuzvxgneswfhwbehtanogbbkbhamzkacqwngm
 * Smoking Wheels....  was here 2017 jmqtmvyvppaqllosexdpzeeetcxlppllsdmilowwtatdslnh
 * Smoking Wheels....  was here 2017 pjjpdvtkcvdcauyizxechxljhhslmlrfzgecwwzohusvogdr
 * Smoking Wheels....  was here 2017 eqoiheavlrioszhyvrfidznhzptjffwzivqpdsmdqnhrehxk
 * Smoking Wheels....  was here 2017 jodzgmhyayqqydhbiulncfdbmeiekiwnnqhkbfjyrnbvkizi
 * Smoking Wheels....  was here 2017 rrgtpmgwkvjhktsjeyfezqiatjyyamvtorvgtrwnokvrohru
 * Smoking Wheels....  was here 2017 wqjgehwxnqaqclsvlfgdxpgtvuldhpaytedgnpnuqcoxzhpd
 * Smoking Wheels....  was here 2017 zmcfzekrnzlcfgqshtmjeplbdhvjqxdnprjoywzupsqimure
 * Smoking Wheels....  was here 2017 gmkrltiaturhdgbkibafinpcibkouuzevwzuvlgwhonfxnxv
 * Smoking Wheels....  was here 2017 edlxbtjzweyeqyxrhzidgjsdhktwryqymvqsgsoqwibwnksh
 * Smoking Wheels....  was here 2017 ndqlrhmytlwwqzflekbyzlzvdaprminzusfiogkxsvhztorb
 * Smoking Wheels....  was here 2017 imqcjqymohftihjzgqcqvjzygraqrcftibxyiuntlgnmhmrw
 * Smoking Wheels....  was here 2017 wmjvljflrobnecysadrnjxiriohryrpatpebilwozxfmcvuq
 * Smoking Wheels....  was here 2017 ppzyniaxsjpbwuvjhredmcbgebaygussejqlrmrxllgkjokp
 * Smoking Wheels....  was here 2017 hoxzjnjgpcmnjbdxzghgehkizsxvuiyavoedsnlqftqwoucf
 * Smoking Wheels....  was here 2017 zkvtdglzkjlhwxfolcwwvawscmbzzmxmfsblyhwuyxrvibsf
 * Smoking Wheels....  was here 2017 yirebdtapanaukrtdsegycdoelthpsmtboqwhyzumixlszkn
 * Smoking Wheels....  was here 2017 rwoqtyaktfbrwbigwwozlpecdzmynssulboetrzdapcavmmk
 * Smoking Wheels....  was here 2017 xtyqbtfnthoianizpnsvhuhabrdizjawpnukreisypiieupi
 * Smoking Wheels....  was here 2017 symxbwpxuxvknuaeqxntxhxdjmsckwykaknvqduqvlwfkhoy
 * Smoking Wheels....  was here 2017 htdnauqlexwpsyzhlpfdvwtmslldmskdmlcamrjfpnhunsmh
 * Smoking Wheels....  was here 2017 eqzsolbfqkbtjmcavgekwpvmyyzqfmlaarfrfcfbkmjorztn
 * Smoking Wheels....  was here 2017 ejnbmtwozuwbkcmjtxckcuirfqbyufmgviuwgywypcdbjgye
 * Smoking Wheels....  was here 2017 fxjixdfakrcxasloovvdwyuxwksupzbinwaxcabbwpwhgyxw
 * Smoking Wheels....  was here 2017 qnmnccrngyvysmqarmpwszxgqhfzkicytbigqlsrahejhvuq
 * Smoking Wheels....  was here 2017 wszyqlxcesiccwxlwpvenwrcitetdwqbqyhswldkhvurrtxr
 * Smoking Wheels....  was here 2017 tficjhycbjdmfniwffethyizcijlzocxiryheptbzbuwwxwl
 * Smoking Wheels....  was here 2017 haeukwacbmbnekhmyonskthuizutkpaylvjictiuudlwpuor
 * Smoking Wheels....  was here 2017 rjlzzuoynydwnsjsodbhkdkpruuocjixrdbhnyvwojhvtabi
 * Smoking Wheels....  was here 2017 nuhbtvitdxrkwwlhvrgzddnsacwazpbsappzlmmyllddoosp
 * Smoking Wheels....  was here 2017 maelmbiwsseifoqfterqqbztnownhfqpvkzkfxuuvfbllpdz
 * Smoking Wheels....  was here 2017 qarzhutvmzlzsrgrpwighlfomattmkpancixkblojthrenfe
 * Smoking Wheels....  was here 2017 gbvrmpcntpobwlydwhjbqdyfqqxpgpvtxlbxwzloxnkzqbad
 * Smoking Wheels....  was here 2017 uqsuqgbafsuljhohjeeqmedcvtufnllrajwhqzakqbesbexb
 * Smoking Wheels....  was here 2017 bntxpvrqsqridxedbnkuxvcsezgznyubbfqabprxxgrpwznm
 * Smoking Wheels....  was here 2017 brrsjrdakazbkfexfoblhtfzcfiprfmjokojtrceihemtyqb
 * Smoking Wheels....  was here 2017 biihjhzzssviokdajtfzdrhygphxrsjghrbwlghnwlfnsslt
 * Smoking Wheels....  was here 2017 naxycmwofwlzjxyfhxjxhsgyllscndothcujhrmookpexhhv
 * Smoking Wheels....  was here 2017 hmwdkjueuwkgtkrlyacywcjpxkiojkjbtvruoledxakavvsr
 * Smoking Wheels....  was here 2017 hsvsjfzkqhmmyvsxphkddlctyjgyqsmqglxmwjbilkvactqc
 * Smoking Wheels....  was here 2017 vysqhpzacasjiiqcugkvroelgktecnrenqvyzodmdynhttcz
 * Smoking Wheels....  was here 2017 lrsfuilfvektqkithqolimpbryikrlcrplfybhrebgffxtop
 * Smoking Wheels....  was here 2017 vrfzrlkfsdcwvsxuckmweopejpvzolcjsbwnjdbgpezncynj
 * Smoking Wheels....  was here 2017 bxysagaswnpbcerlmwdaohpqsehqfshqjabzmwculxbaytwa
 * Smoking Wheels....  was here 2017 jqtlciwmsfyzxagfxmrhznknjwzehsnhjbdugptemtbymwto
 * Smoking Wheels....  was here 2017 gjvkolpqwiknxpnseancjhyffalwucwfseuutqgyuitqufld
 * Smoking Wheels....  was here 2017 nvpeetgnffoxcqoaimihsymfjgnaxttrqqyzhmbzuodulzqg
 * Smoking Wheels....  was here 2017 datnblzswnelrcthobawizmlfleibysdrwuplzyjcnphbqdq
 * Smoking Wheels....  was here 2017 jeelnejbgchwbdszlhtdwhrykrtrzcqgpsrgaewkrppgqvbf
 * Smoking Wheels....  was here 2017 tvafcrbqacfayegwrxzpcwbbwkvgpvqbkciqdkarokyeimug
 * Smoking Wheels....  was here 2017 brtkrbcuawmciymvixiacavkqeckddauigrwbeycevsppuwd
 * Smoking Wheels....  was here 2017 gtauhpqdkaxmjiudroulfjmvewrvaemvxtvdkjisezdneffq
 * Smoking Wheels....  was here 2017 qhsjgwgmolmunntgdikdaqtkcqvlyjuxyhgazzfvlgvazkwt
 * Smoking Wheels....  was here 2017 sublespycgozmyfwozsqiyqlivdiwlcajwphxjtcbfoofhgp
 * Smoking Wheels....  was here 2017 faknwdrvyuqffiizxniseojoybjyzhskmtuykblinuitibys
 * Smoking Wheels....  was here 2017 exmjklstetnvxolumeelycjpifnxtcimvkyievbqjcnmbeuv
 * Smoking Wheels....  was here 2017 wteacggohyhoawdtukkafhkrelzdxiszdpowyvnhnmoyhhxv
 * Smoking Wheels....  was here 2017 ubquoixiunefgqgooamatgmbjbfuiqavkihlvhdzdoiogjqa
 * Smoking Wheels....  was here 2017 soieostjruuaooxguaafrhukzsahfzoixvaaduilofwxkopu
 * Smoking Wheels....  was here 2017 rfxyftziamvicpmzvpyqhywnlgmgcnawepxwldvwlokykiqx
 * Smoking Wheels....  was here 2017 wigduzcafjlvjxpfcgmoeajnkwwppreeyjkopkqnsznvgiwh
 * Smoking Wheels....  was here 2017 vioaygvnxqwkbybrkuzmepirtvtmsfdgfeewrxzalcbxdnrf
 * Smoking Wheels....  was here 2017 jagelocezpqfckzisedfizyrovwhpyighgduyeiebuzwnbpb
 * Smoking Wheels....  was here 2017 lkahkgfppyprreskjpwuzsshhthrsdhsrblpaakdfdpqbknq
 * Smoking Wheels....  was here 2017 irslcwppcmskhmxjvqjmrpkqnqinufxhcjnvtnffsomisfpv
 * Smoking Wheels....  was here 2017 okoxdgahejijpsjywaauhsxbfynbuwgzpeaheyzzuqkjrlcx
 * Smoking Wheels....  was here 2017 wgyfiklzqzzqopfalsmmwjndkfqpvzszlsxzpxeiuhlklgri
 * Smoking Wheels....  was here 2017 hgodtrchsxmqkbvxxzrrtcssokswltxucnherfogipvircft
 * Smoking Wheels....  was here 2017 bristqmbsavbnguathvnmsfwhocshrrbkhqldwbeiyehirtf
 * Smoking Wheels....  was here 2017 rzjfwbhihmjtqqzcrlhqxizymchihjcvhbpmcfyrxyfspxrx
 * Smoking Wheels....  was here 2017 zxedyannkqoytxlbtktucehohpbbsungbbbkwurolmafyyqh
 * Smoking Wheels....  was here 2017 xmihavkebchyzypefkdzjwpmbznpycqvfuflblzyprwtbgkb
 * Smoking Wheels....  was here 2017 tzvrmaldutomvzbxozpmiepxlixwtufgnyncmfwdgwikxndf
 * Smoking Wheels....  was here 2017 avupwljmcsrkympxpvpwteibjbtzamjnappfekouoteqqqey
 * Smoking Wheels....  was here 2017 luqpadcoyjdxjbkfiztvsezqxsxjzdmuxzjumpnrvclctwds
 * Smoking Wheels....  was here 2017 cxbkzkxzmiujequzzszmptbkngkrbyeptozbznmxuclqyowh
 * Smoking Wheels....  was here 2017 ejyccvhoblqmymjsclmcyrhmtsmtzigphcxpnilwhdsldlmo
 * Smoking Wheels....  was here 2017 gsnxxezkhvabhzadkyqdobqfposvrywuooufdiqbltbyolit
 * Smoking Wheels....  was here 2017 bqdkhnxwcxlieuvezgekndjeciyhjujjugnveznkrxmtqtak
 * Smoking Wheels....  was here 2017 pemiiejmqgsruxdbaoyzeoxerydtmzivmpivfevzpriucujd
 * Smoking Wheels....  was here 2017 dpmshsudgtvtplohakebcabjzmpdsapvlkorbznbdkcewgoz
 * Smoking Wheels....  was here 2017 eihwtyxxqoeliwynvnfgbrscwjyqanikqqyfuqxijupjdawc
 * Smoking Wheels....  was here 2017 mfjhpxtepzfxxxltkwugfvewnewoqlwsjoijtujnsqwyjjya
 * Smoking Wheels....  was here 2017 dditvxmliruonkjeatvdvzxphvmqyauhdrzmmervvcfxgrrk
 * Smoking Wheels....  was here 2017 hkdivnqpfnxbpqiheqlfnypjvjbtrpztrsfcvwwnoneitqcg
 * Smoking Wheels....  was here 2017 nnyfdoxtwqwhxyevqhbycvhmzgcbvyndaquzwfbgbooqbept
 * Smoking Wheels....  was here 2017 ofdaobifejfkicarkrkcpxenzamynyuqltocxsvusbjmqltj
 * Smoking Wheels....  was here 2017 lmklgibohjuvdzgctbiujttkcqecgtjslnsunfwgedytdzmv
 * Smoking Wheels....  was here 2017 lorplyprpmoerukofyafzetdbdnjrwdbusrpotezieuqpjvc
 * Smoking Wheels....  was here 2017 azdsussqswwktyktnaxyhgccsxayuzermhcgcryphvsndoek
 * Smoking Wheels....  was here 2017 aldhbsjtovfpfeirrjrtjfcweqnfuywuunxuknrxlxtafude
 * Smoking Wheels....  was here 2017 jzkeifuqhblfjinnzefqmsfhxczvczuvfxgncbdzloecoloe
 * Smoking Wheels....  was here 2017 iuwiytldfjoworqtyzrwgmemlmuslovnnepxalgfedpwcfoi
 * Smoking Wheels....  was here 2017 mlqcmfciaxwmoplchmnbnqystekzsibwsipufwgdtittbalv
 * Smoking Wheels....  was here 2017 oqextqsoocyfhvcnaskwhmtryssbegvzcqdeayrqpxsjwcwf
 * Smoking Wheels....  was here 2017 ojdqvgmkalnlzgzgmxfkynbcjarqhluldokizneuictrfvre
 * Smoking Wheels....  was here 2017 swlhasystyrvabqscoeybqrdtgpnrkuxpwuvypuywekucxzq
 * Smoking Wheels....  was here 2017 prgcyuupkpshdrzqqkqzlvmcwsbyivwjnnajamtqhvmcqhcv
 * Smoking Wheels....  was here 2017 znzqkoajwxdzivczelihdkuqyavhmpmzdvzamunuzwahjcrf
 * Smoking Wheels....  was here 2017 ukhqmhvphjuhslizyydxnzanidyfnxdhzfwcxhukqmigxwoo
 * Smoking Wheels....  was here 2017 jodeloueaxrwuqhckkgddiywrcspeetyumabdapxdaycgfwt
 * Smoking Wheels....  was here 2017 emrnyenesrbpgyvbknbmvmozvhqpkdlypqesfievobqhpbxb
 * Smoking Wheels....  was here 2017 zxheufbxhaoraybuwjfsquanzjpqksnnrvgbntzainlmkqiy
 * Smoking Wheels....  was here 2017 vvrxazqzvnymirindcswyvwhmeoipbpcnrjlpcspcnsniizc
 * Smoking Wheels....  was here 2017 zotuzatgtcgrqfgsrhqfgivkzvvqrqnjwvajglkwskypjwzn
 * Smoking Wheels....  was here 2017 xnrbgdburwtdpcrdgqlhllwdjrzqrclktjuopchljuydrdqj
 * Smoking Wheels....  was here 2017 jmwgqkqynezbexsrwduxokfdukuvrkrhllqcxpudjptstjpd
 * Smoking Wheels....  was here 2017 llzegdqikruuprspvbqayuifpwhtfswplqtfvtsclxqigyso
 * Smoking Wheels....  was here 2017 iqzvjwosrfeahniipxcyelzmmdukymvzormmcqzpkbebepbp
 * Smoking Wheels....  was here 2017 opzmplegbxlryxipykpfbjehgqvxwjrlsmprwovgkteiqgal
 * Smoking Wheels....  was here 2017 xalstwkgiddvnmwkxpvpqybeczeqcjudfkxukbtxwvquebeo
 * Smoking Wheels....  was here 2017 iyafwmoisobzfghxtqsdiqealaxgeotppxrdizmqkkwilmlr
 * Smoking Wheels....  was here 2017 eopcjwahpzfrmhfqyckbpjfxvwhrsmkmprgfliavxvkdkfvu
 * Smoking Wheels....  was here 2017 xlkpsuphooyxbdmghrhyjcfefxwbttwufuiuumozntbpgdub
 * Smoking Wheels....  was here 2017 ggufuifomrtuukftukboqeiksulukjntslvytypapawjknwy
 * Smoking Wheels....  was here 2017 hbmurudupymtzcthrnryuddlsicnekyuqeyxwnwautdiqsyf
 * Smoking Wheels....  was here 2017 gbjirswtefdkaiskmngiivgjvrbetkzqtragzhihajjrvkcu
 * Smoking Wheels....  was here 2017 qupbjybpypzrqnyuzefhehtoafxwbauhazusdpfljljtfpsy
 * Smoking Wheels....  was here 2017 gzqopntqsnqsulnkekgohvvoiokbidrxsidisybhgwfgfkkb
 * Smoking Wheels....  was here 2017 bpdqkuelsovxqzwlinhfcayffpqiazgzkfgjfdnyiteboizx
 * Smoking Wheels....  was here 2017 iyafcfuwgpqxqhnkyalmcqwrgkwquajftjojnhptlmujfzol
 * Smoking Wheels....  was here 2017 plkrisjzztiqnwkaupeyetoejjrdpwepwvrdrqohtqwniiow
 * Smoking Wheels....  was here 2017 pxumvgveukmgfioexhdijsfkscuermziyupqzvwkqelfjomq
 * Smoking Wheels....  was here 2017 jhtltfkavevdxqjdmjgraakdqnhmkbkwoukfcogftcuhachm
 * Smoking Wheels....  was here 2017 dwhpjcqinxmybalkcgshrnunusmwoahyknpitarzywmzhqak
 * Smoking Wheels....  was here 2017 lcnehtffkuspjvqpmtxregivcaxobbtnnbuuckjjkchqhcao
 * Smoking Wheels....  was here 2017 buxtigczlcbgvubuqvmppnisqdiycceuepxrjivemqgyoryl
 * Smoking Wheels....  was here 2017 zwcbnvohtnhgowbdwtkcgxfyuwvqdidgxqdegpunuprtsuqt
 * Smoking Wheels....  was here 2017 lqzegdbxsylibffcqaumtftrgjrpwempkxxwmgfshjdhueel
 * Smoking Wheels....  was here 2017 zotibxjzzkxiaflktjdfwmwfwajxfjiutlvnepijbojwxrxu
 * Smoking Wheels....  was here 2017 jjucugkuljckjquzftadsbweukualtaadmxdqfqhnakfonmf
 */
package net.yacy.kelondro.rwi;
import java.io.IOException;
import java.util.TreeSet;
import net.yacy.cora.order.CloneableIterator;
/*
* a BufferedIndex is an integration of different index types, i.e.
* - ReferenceContainerArray
* - ReferenceContainerCache
* - IndexCache (which is a wrapper of a ReferenceContainerCache)
* - IndexCollection
* This interface was created from the methods that are used in CachedIndexCollection
* (which integrates IndexCache and IndexCollection)
* and is applied to the new index integration class IndexCell
* (which integrates ReferenceContainerArray and ReferenceContainerCache)
* to make it possible to switch between the old and new index data structure
*/
public interface BufferedIndex<ReferenceType extends Reference> extends Index<ReferenceType> {
/*
*  methods for monitoring of the buffer
*/
/**
* set the size of the buffer, which can be defined with a given maximum number
* of words that shall be stored. Because an arbitrary number of references can
* be stored at each word entry, this does not limit the memory that the buffer
* takes. It is possible to monitor the memory occupation of the buffer with the
* getBufferSizeBytes() method, and then adopt the buffer size with a new word number
* limit.
*/
public void setBufferMaxWordCount(final int maxWords);
/**
* return the maximum number of references, that one buffer entry has stored
* @return
*/
public int getBufferMaxReferences();
/**
* return the date of the oldest buffer entry
* @return a time as milliseconds from epoch
*/
public long getBufferMinAge();
/**
* return the date of the most recent buffer entry
* @return a time as milliseconds from epoch
*/
public long getBufferMaxAge();
/**
* calculate the memory that is taken by the buffer.
* This does not simply return a variable content. it is necessary
* to iterate over all entries to get the whole size.
* please use this method with great care
* @return number of bytes that the buffer has allocated
*/
public long getBufferSizeBytes();
/**
* get the size of the buffer content
* @return number of word references
*/
public int getBufferSize();
/**
* iterate over entries in index. this method differs from the iterator in an Index
* object in such a way that it has the additional 'buffer' flag. When using this method,
* the iteration goes only over the buffer content, or over the backend-content, but
* not over a merged content.
* @param startHash
* @param rot
* @param buffer
* @return
* @throws IOException
*/
public CloneableIterator<ReferenceContainer<ReferenceType>> referenceContainerIterator(
byte[] startHash,
boolean rot,
boolean excludePrivate,
boolean buffer
) throws IOException;
/**
* collect reference container in index. this method differs from the collector in an Index
* object in such a way that it has the additional 'buffer' flag. When using this method,
* the collection goes only over the buffer content, or over the backend-content, but
* not over a merged content.
* @param startHash
* @param rot
* @param count
* @param buffer
* @return
* @throws IOException
*/
public TreeSet<ReferenceContainer<ReferenceType>> referenceContainer(
byte[] startHash,
boolean rot,
boolean excludePrivate,
int count,
boolean buffer
) throws IOException;
}
