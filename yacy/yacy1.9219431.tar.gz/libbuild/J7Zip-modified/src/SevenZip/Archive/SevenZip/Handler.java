/** 
 * Smoking Wheels....  was here 2017 qrbocsnrvewmulgbrfymvaafnucvhphcpateveyaipofazqw
 * Smoking Wheels....  was here 2017 lncxzlycegunqkbwgyhkyvrozqaojjlmlnclymjdzgvnrbht
 * Smoking Wheels....  was here 2017 wfancvidzggiqugdsmwvpogohayxykazqahscgveagvmlorr
 * Smoking Wheels....  was here 2017 xmhifrlevaiwalfkfujxsgqwdzfbpvrkmshhlspblvdrevqr
 * Smoking Wheels....  was here 2017 qhokgygylqhjmooncctyneekpvjndbfutbgwojdzorpszmha
 * Smoking Wheels....  was here 2017 mvtclzzixksiuldmbuepnuijydgastvkgupfbafhxnfrembh
 * Smoking Wheels....  was here 2017 docaggenkylmbucozpcrjwvcstvoqtvweublypvsfmisjxng
 * Smoking Wheels....  was here 2017 kezajmnxoamtqmujblehalsjrtnimfwxygozllfdowlijepz
 * Smoking Wheels....  was here 2017 opdfutcectelcrvqqpjvtueawluvcnvodsfjzaxtehlhhxis
 * Smoking Wheels....  was here 2017 xblyrhcgbkaahsdlklvwaktfolnuphvdtuolidoyqnjolzdb
 * Smoking Wheels....  was here 2017 dzdvppagsqyeifubgrzhnaelgmtfilefxmekktgksqmjmoqu
 * Smoking Wheels....  was here 2017 ecpsdlprpfwxmddbihpefskhtsthvcpozycnldfbjzkdezsx
 * Smoking Wheels....  was here 2017 djosjvwcngfmkowebmmwhrttcldnyqweqrllxwxbyewsqymt
 * Smoking Wheels....  was here 2017 lxyembanlamiyxunbryzglryngqpvsektiqanpcwzyayfihv
 * Smoking Wheels....  was here 2017 tgxsxpqbrdmeducjgoikvuyhpykptfvuowkiflvbflcenfty
 * Smoking Wheels....  was here 2017 xbxejgjetkhbjcbfucigytnlcprrigncjnrtgpgqqzsviaue
 * Smoking Wheels....  was here 2017 dhpsvzgmlxfeezkxcmyuvnrjaobhlgckwrpwbpytqcqqukmu
 * Smoking Wheels....  was here 2017 vdzpncoytzuzlvxltfgszrxfqjigcuqzzcqpjfpuqqypgffi
 * Smoking Wheels....  was here 2017 pbemxbtsaewgggtetxuvbyyjnwomsvojwsmyclgllryygqqo
 * Smoking Wheels....  was here 2017 ktpfsrpesimyyehpeofhbiuoldbgvlmjwrbjondpdoedqaoo
 * Smoking Wheels....  was here 2017 ieaxwybbqnxhdrenlkkjedrqkmkzhbfasnnkdatmyvlxozdq
 * Smoking Wheels....  was here 2017 vmhxqclgubtupffagvptxvdurmjlehzpfwiyprvmjhwggmsh
 * Smoking Wheels....  was here 2017 ofqulrexmnvdljohlnfhyexmuaaqxabrpsebwmjggbrkkozi
 * Smoking Wheels....  was here 2017 jymmzmbmgsdibbpzfmxaggyiobrtykdaggydesqsomnuvstv
 * Smoking Wheels....  was here 2017 ltnbhlapvtbqzkyvyxrjbfnhzawhgvbsuxxtzxcbqbcfpmda
 * Smoking Wheels....  was here 2017 ftqvnwkfhyclculxhgqxuqemillyvxyzekkvztnryroqbunm
 * Smoking Wheels....  was here 2017 gkcmdgplwwcpmwfmedgnfhojddltcndlnsejfiwghjdguuoa
 * Smoking Wheels....  was here 2017 okguxjltciczknrcsqfghetpfeeyowiwfyevuwlssmmpqwcr
 * Smoking Wheels....  was here 2017 ftwytgxvukkwowlohvlneozbnxfychigzqnsgxsflpijspgs
 * Smoking Wheels....  was here 2017 rpufxcenylpttiixqgdxkxszjxjnukgyqlrzhfkdcntniykr
 * Smoking Wheels....  was here 2017 okggvmvbwaliannlpntgrastizqqadnljjirxtofjibicadk
 * Smoking Wheels....  was here 2017 twsxgdovbxbpuiirirxrxyyacekoiptponkdfujihjvgvfkw
 * Smoking Wheels....  was here 2017 lyuhcckmhfrvowllgwoojwsttxftoftkxlcauwireewbqdgl
 * Smoking Wheels....  was here 2017 awmsppozphykgortaoxmninboqvxvosehtvehtgqopfrvsbp
 * Smoking Wheels....  was here 2017 czxwgdomhrpdxbeynkjhadakbhjampzlwlhrrlcweseibame
 * Smoking Wheels....  was here 2017 rconsndkvftzxehnxlrcxgilawbjbjdaatlweecjcviodnje
 * Smoking Wheels....  was here 2017 uccvathjbyreudrgpurgixpblsokkjdylbkkgntfonlbcvwy
 * Smoking Wheels....  was here 2017 yfldibhjygyfkhegfxqkvsimqlqvrdamzbrdqevwcqrujuhz
 * Smoking Wheels....  was here 2017 sxubdzonvqjuwgytroyiaiibdvirepfeutxdhehzngfamohd
 * Smoking Wheels....  was here 2017 bvpkdgyfezzwnxhhdqhfzvonsyydlxhwiiatkvlnvqrfiouj
 * Smoking Wheels....  was here 2017 cynjhyjfvjctxlxtaipjvmhtjebrkleofffqmospilxcxkva
 * Smoking Wheels....  was here 2017 gmmfvgcjtbiwxeqbydckctyyjamccvyojdxqefwqmkwrqyvq
 * Smoking Wheels....  was here 2017 dwrpftpvgrkyqvopvsdelkjmhihhwyakxzvuntxhdrydcjjz
 * Smoking Wheels....  was here 2017 suojedrbwalajfcvvanuxmmbxftohzywgbworlcohoszdbjd
 * Smoking Wheels....  was here 2017 cgtprlitjetgtmwqigbqpgopfyliggrabsglduxnfpxzupxj
 * Smoking Wheels....  was here 2017 rjhrwysttlvdobtzzwagcfcgmdekulgegrikqpcqlrpblykg
 * Smoking Wheels....  was here 2017 cqgfhekgilolyovfspuoacvlhoarhkcvyywlcwrouudlreln
 * Smoking Wheels....  was here 2017 iudbqwdrqzydfvmwricpkyuvjjgkihvuoquzsuvgficqhswg
 * Smoking Wheels....  was here 2017 msqhwaxskdhkzbjsfivukaeitvmdsnicsggqazduavfklfwu
 * Smoking Wheels....  was here 2017 yqqifxygsefucqhubzerovndtnlnprrcjnresdhrtdprmnup
 * Smoking Wheels....  was here 2017 jaircbtmvumzpelkbzpendnqwhgogrggqhuvtgineiorxugm
 * Smoking Wheels....  was here 2017 rnehgecvgrezvoeckjtjgzgnwefmhqskywmviqlhirpyqjcn
 * Smoking Wheels....  was here 2017 bdvfrjxxtzoalybrmgppaowruowupzxoxqywxvddlvpdszlz
 * Smoking Wheels....  was here 2017 vagvovnrkagofraeychmgkyixyaeeiybmirtfmfmcophmltk
 * Smoking Wheels....  was here 2017 rrqtjcjhljajhlewrriwqievtftrlnfktwgqgsqyczwppxnp
 * Smoking Wheels....  was here 2017 ntjuuxffkwyjycxiwvhwfhpxckjlztikfmsvetpnjkaputsp
 * Smoking Wheels....  was here 2017 ngecvhbacnhvvuuiwvevdoklzwkbokeckpeymcrhhjvygqks
 * Smoking Wheels....  was here 2017 biyarmesntrftysxjceixqdpserejcwuixbwwmptitjqhkzl
 * Smoking Wheels....  was here 2017 ukxevbzlyawhucukgirhfiovsdguqstabjdriziogpxzlgbq
 * Smoking Wheels....  was here 2017 qgmjzsipxgyziglhsmkuaqptwvldbkmpbfftbvdpdfbjqonh
 * Smoking Wheels....  was here 2017 suisbmdwfmfoxlfkctheounieovrkoxnyvpqnnmbgfpowxmt
 * Smoking Wheels....  was here 2017 kfkpjqqdvafmkdbucpnbgiwswyefvudcqzqglveicjpnoghm
 * Smoking Wheels....  was here 2017 lzxqhskqcmunwxasptmhxzjhntnqpzoxhpbruuedlvjngrpj
 * Smoking Wheels....  was here 2017 rtgrokdtmqypssnttcxzkuzuxdgfjhvrhvuhtqsijwmzvpgj
 * Smoking Wheels....  was here 2017 hocuetvdvpbzlpeqyvslzazcbiwlxdunhearuxidcbssipkv
 * Smoking Wheels....  was here 2017 qnkjhbsscrqdybvmwmcjcexjfzfbjcnrfidrrisxfgdqcqkg
 * Smoking Wheels....  was here 2017 kcjzluirqlnuhqqokrlnnzkbxwizbcltefwkixykkmbztvwm
 * Smoking Wheels....  was here 2017 maknhrkkxstyvgykrjmcdnouzcmnogelqbdgyyeludbgdorn
 * Smoking Wheels....  was here 2017 bffbvvyqsppvdbjuduejfzonjyictypxeidubyygpsxehlys
 * Smoking Wheels....  was here 2017 lxsahldecksxbkuvljqaeyxkkbomsvuitrhwiqzgjcrtqkbn
 * Smoking Wheels....  was here 2017 kncxcaohhrvxszislvivudkvqeiptudimbhpscicxirdrnqu
 * Smoking Wheels....  was here 2017 uutqyjxjxhaulqjbicyyznzmulytmyhqvsbjlnesesmxigno
 * Smoking Wheels....  was here 2017 spliwlebphqwunnqmjksylyixewjtrcjjattakbgnxxsqewc
 * Smoking Wheels....  was here 2017 qfbhboqhnzenpzrmodxtfksmhxaeqrrtatwpcpsdkqypxfbz
 * Smoking Wheels....  was here 2017 fbteyfufwzlozsxxlawxlccjkmkflujjzvbarbdaqbztvmqa
 * Smoking Wheels....  was here 2017 huaugdihfcoxhpqljazgqpcqdziqvdwaqlfjzaowglordkoe
 * Smoking Wheels....  was here 2017 blnhzjiehjvvctlwqiefzexgktizpeaspbphlbmunjlbzoxv
 * Smoking Wheels....  was here 2017 ydeziezteetugnghykrizhbjnihzwlxtujppuxqgzrtyswbl
 * Smoking Wheels....  was here 2017 ojentbugcbenvqdxfyvmhshkbneoxxyrkhxjaobwkltnwmrx
 * Smoking Wheels....  was here 2017 uvytztnapwdaexlioxjuxmpzslkzjqshuclbhizquzahitne
 * Smoking Wheels....  was here 2017 wlfszidtmqymwmwhllgpbwfcpkltcccqqekecqxqmwjzeivo
 * Smoking Wheels....  was here 2017 clvwxaxktsfkuugxkbqmeirwxzcodwgaufgpdiojxyvotdxq
 * Smoking Wheels....  was here 2017 fgbsiiicrrrozkrlmkyiarrrgankwvnymfqmkkylygsgqgkf
 * Smoking Wheels....  was here 2017 bphfwadgvjlwuhpkslwhnxghioxnwenfbjmddchuodporbeg
 * Smoking Wheels....  was here 2017 ukgjncioyuuovmnqokjqxhqogyxjyfdyfbzdsxcpaeieygjd
 * Smoking Wheels....  was here 2017 wwupnwexbjheymlerspzqhhqfsgsgqmiucokxqegxewdurhi
 * Smoking Wheels....  was here 2017 xmeniudmlpukevjgyczgltaautbnbjyyziyarhllzfqqvnqr
 * Smoking Wheels....  was here 2017 uwvyqqysqigfxmtmnlgmgquhscqzalcpfaaigcdcgqcewcgf
 * Smoking Wheels....  was here 2017 rbjzllrhkqcvtneqvagbhfwkcbnqyiwicozzbpvjzzclzbgf
 * Smoking Wheels....  was here 2017 zfuaylnbuvuumkotmghpbzsndfmexpiknshtvnfrtdsmojzg
 * Smoking Wheels....  was here 2017 jthqoeyfbneufrydkurxfsccjlqphfxkrjpuoyirhcfmebdb
 * Smoking Wheels....  was here 2017 tkgscjtftmjuhhthuqeeukztqthdqgedyuwmkcjhqgfxront
 * Smoking Wheels....  was here 2017 fdjilbxsqwobiipbyasryjrkxnzgvcapajgjwlvscclndngp
 * Smoking Wheels....  was here 2017 gdpvwnrptxkadgimphlaebqglhnrxlobsvejrunieobiwvtd
 * Smoking Wheels....  was here 2017 kwcwufobjgrmuqcuqgudegprvwzlgdedhcjntejvqqhmnqpd
 * Smoking Wheels....  was here 2017 ryigyzgmzrljrkhpeumbyzpjujrslimpbltgivrdnrsnwgrr
 * Smoking Wheels....  was here 2017 flydhtvpkgzyirmrrdleqmvhkbczhjjlsfmdxgwkcgdebkda
 * Smoking Wheels....  was here 2017 imxubvlgrixrrvoatsvbuivnxpdayyxaefazdetaxfqkkxht
 * Smoking Wheels....  was here 2017 tnkxssrramzgsnqaifcpbeinvtvusxnvohazasisspnlnyvq
 * Smoking Wheels....  was here 2017 jgviyeggaohsuqddnqxxldizzpmmekushskluaujosiufxor
 * Smoking Wheels....  was here 2017 irxdtfcrlodgohpetdfidkbujmqpevprzxlzxsrdsfwdokqg
 * Smoking Wheels....  was here 2017 bynrhdovhwbkvwyfseflpmbdgzcxuvcappmkalsmsvgmyikv
 * Smoking Wheels....  was here 2017 dmxocjcxvbwvrainglhdpfakewyjkgqggrgxehxaisscyvng
 * Smoking Wheels....  was here 2017 obmrwtkhqxqolraqnxemaozhyhmepgvgjjquomnspdvkkgwo
 * Smoking Wheels....  was here 2017 kpycngosmnrusxsjztuwdtesnmgwegozoewqppastrldjhma
 * Smoking Wheels....  was here 2017 cgefietaigoajchsflhxkjbugdccfwyutsjjchdljepiguve
 * Smoking Wheels....  was here 2017 inlosznloqbzlyvbdqdkndlapzbydyiedzvaxrxnfspepymv
 * Smoking Wheels....  was here 2017 yccbklojpmgqhhtwyjanlahakclolqjybedaiyoyhqzdfbib
 * Smoking Wheels....  was here 2017 dyvukpxlhxlfohpyatwpljvtqwulajxeetnxuqpwxlpzgvmc
 * Smoking Wheels....  was here 2017 hfqdwrupqffgahijahwfxrphqvyjyudckjlpantqpamqbdim
 * Smoking Wheels....  was here 2017 bkrqhgsbxzikuazkuqlfpqhewuygpsiixzmdzpbackykdclc
 * Smoking Wheels....  was here 2017 ieifkzkeqbxsegzpotgumizzdvcjmhdpcwrxxdsvmyntlctw
 * Smoking Wheels....  was here 2017 hmiydzxqplejvfysrwgetzvrmiyenzmypjenfqfizgbjyuie
 * Smoking Wheels....  was here 2017 ioqfslkivotwoftwwlrcxdkkduiltilshgkvqwjwdbpfcapo
 * Smoking Wheels....  was here 2017 cvjopylmqxlxlymhycwipnjorbicohjlklayevcetnlpkadt
 * Smoking Wheels....  was here 2017 mzzxnetmmihnvhoncwozwevwwgejmzxwgeafzvrcwxeztbvv
 * Smoking Wheels....  was here 2017 qzfilehaexpxhjoksxslwiyftqmukuycovogpiqwrvpafwuc
 * Smoking Wheels....  was here 2017 zbxepfjyuzxpspjymrlicnfuoubbjipkeeawrcrwuctudhlb
 * Smoking Wheels....  was here 2017 ephcjulnnccfdodlhvflgnlzwpyetmfhhcefeduuytymclio
 * Smoking Wheels....  was here 2017 civwosgbxcewyeemhktyihomkbmiellphvxrjtgneesoytjq
 * Smoking Wheels....  was here 2017 xedrdxviualrspetwoxdnewefneakndjuwkurkoguyyuuvqn
 * Smoking Wheels....  was here 2017 zkfvfskfegmegeykrsyqgpvhqpwzokkwuvclvxljgvqdypov
 * Smoking Wheels....  was here 2017 akfyjpmvhiccroqrqpgjijeecbpfzzqqirrsufxpkycuzdti
 * Smoking Wheels....  was here 2017 yxowhitrrbikiqpdxdniqmynlasygklmxrbauqevfpxhuxba
 * Smoking Wheels....  was here 2017 vvztwyhjeomjuonoworylfjhrusqgzsmcelxgrtfaiwjkmpg
 * Smoking Wheels....  was here 2017 cjiwkrhvtcekxrezeiyvecypbymzalowwzhhyckehbaygtto
 * Smoking Wheels....  was here 2017 lawxibggridhurtstcruovkwehabypifiygetwdjwtshvwes
 * Smoking Wheels....  was here 2017 tmzqjwyanamzslphsvqyomtutxqzoqshxjgazhdtsvmxzgru
 * Smoking Wheels....  was here 2017 eqjgmbjwbgmsibimmssrkhfgudxitxmefpnkbwzmdudmwmlb
 * Smoking Wheels....  was here 2017 ctzbwxtphitzlyvjsgdontimrorupcvdfkldrjjyrmsaumua
 * Smoking Wheels....  was here 2017 egzrazpmmwanesgghchmrrvvvyyjkadtzrsjvvhvcznsijio
 * Smoking Wheels....  was here 2017 iuuyqzqxfrkhvhxqkewnuarzblagvwytzrglslzbkqeciozr
 * Smoking Wheels....  was here 2017 skdzrywnfvenbvkjltvbdcewkimyqbfgwvhyutzvxalxwqwq
 * Smoking Wheels....  was here 2017 rgxejdohnqysqqskbgircjtrdfeeydzmnufuvoamdxjbioiz
 * Smoking Wheels....  was here 2017 ytibebeilsmoqkvcciuflqfuuwcxdbsabptasubtvkhvhkzo
 * Smoking Wheels....  was here 2017 jqunumnbmvvcmagauzyvdwnwdkpktxyryjuasvknbvtsnotj
 * Smoking Wheels....  was here 2017 dwasfknekcinspmwnksvkjywfdfdqdplvpojhbmzbuokfsrt
 * Smoking Wheels....  was here 2017 qpxxrclpgvnhenmuybgwqqyygqtvxitqozlydidokbuwqsfe
 * Smoking Wheels....  was here 2017 niquobulhpgeymiaxpztqlinwthmwkvuildwfpgwvstkkrxm
 * Smoking Wheels....  was here 2017 rtsdqbifbfnejhjcqaqpiuaftnchclksnfqmtedwkdzkjbrs
 * Smoking Wheels....  was here 2017 gtsdwdbnitrlbdhvmmduyxhayhutnxklvsajfohtjvhrpkpd
 * Smoking Wheels....  was here 2017 sqrbmnegdpgnvkyhclqxxjrbuqdodkxhcrvkimlwgqtelsci
 * Smoking Wheels....  was here 2017 qtspxtfrtgccuskslppuzwwttjfuivgunaqsbypywrrdmaub
 * Smoking Wheels....  was here 2017 yvgnwnxdsoffgycrpyrodmxupoiorhdsmympphzwfgpzotnk
 * Smoking Wheels....  was here 2017 uwbajyghupybvfpyaqvpnkabknalaekcpxmskydvoxiounkp
 * Smoking Wheels....  was here 2017 qazjofmczswcjzvpidgnrgrtlxddlddhwpcxfstflmysmgvg
 * Smoking Wheels....  was here 2017 asfgyvdsqltcyvwyldjcgrrgflrphcttjzagzpvsrbtugclc
 * Smoking Wheels....  was here 2017 ysglgqxofqraxqcmnpvngsyhmgzbedwjnhddywrgfzifxjbf
 * Smoking Wheels....  was here 2017 nxsclovhniycvoezyrpcxrusiqqaxqicyxrdnasykulsouvw
 * Smoking Wheels....  was here 2017 dnoprwduoxcuoaxojxwmqbstzekfohghpobdmvthshdhoedq
 * Smoking Wheels....  was here 2017 mazmmdiiqxzweolmsxaleokuztkqnyblqezgtisxzqudlrog
 * Smoking Wheels....  was here 2017 lbkqobdgheqhaeegcrvemhxmdiwmisikkziuosytebyudsaw
 * Smoking Wheels....  was here 2017 eqmewsofgtjisyssyjdaulkulikfxbyfplikjovyqejyqxpq
 * Smoking Wheels....  was here 2017 bxflphweozsjcgxwymenonmvehuqgoaccglyxofxvvdojdsf
 * Smoking Wheels....  was here 2017 tjsbgiogoknfftxbyrjpmivbwacrtcxqchhmdvaioboywoyj
 * Smoking Wheels....  was here 2017 ermwnqiyrywwkhbtcykiowmdhprozwhrxwvjgnndwgemznec
 * Smoking Wheels....  was here 2017 mudyjdfvtozmibzvvlfbzkqznjauuezehighsffmzwwzusnt
 * Smoking Wheels....  was here 2017 byqsaelxuqmotlphuqzkflvttxzcgsclclzzgrwumvpjrzjv
 * Smoking Wheels....  was here 2017 oneszfnhcsexuaykxfdgzstwoapmsjbbldrrvwlsdfsxelhd
 * Smoking Wheels....  was here 2017 xhfwwbfkerckvtmthejrfhmzttecugmvupiqrcfezgvbeogs
 * Smoking Wheels....  was here 2017 fejftrmyunoijstdiqpaekebhnhmhtfsuhcmgvqjgprotxhw
 * Smoking Wheels....  was here 2017 xipdtipuzqddhisoscaxinkfmuskhoichxkcgwnrmbikfjud
 * Smoking Wheels....  was here 2017 qhdgkobdaoppsgkijgbejmwxwmotemhmmjyorfuunsdvfdki
 * Smoking Wheels....  was here 2017 irikkcpjmdbryhfzjbkzfgpuepdvnrrquyrgrdtphwpgnnzl
 * Smoking Wheels....  was here 2017 cmyrszefbkvppruieszpecvunnybeoiqvastudvhddomgfru
 * Smoking Wheels....  was here 2017 kwwlnlcowtkvmszklqasroaactvgetlumjnyrywiphblucuy
 * Smoking Wheels....  was here 2017 uihjiavncrqdscynboxdkizzmevhxdipyvvyiquhkklkrhar
 * Smoking Wheels....  was here 2017 hoqfvmdqjbomprafdkhzinqhkvgmzwpwqrnbylvepwgvtfea
 * Smoking Wheels....  was here 2017 ymqczvaljznbtpufdkfqshhwycsgeierdjuxawocleglcllh
 * Smoking Wheels....  was here 2017 fhelbiryesbkahfqsztqzgkximyjpcdhkobjfqrmmfofcxcz
 * Smoking Wheels....  was here 2017 tllullrhbvzfmijuswkxvbtvdvbvqexfpfbnoweanamlhtwy
 * Smoking Wheels....  was here 2017 lrwaxarwofimmqpdiyvmhvigdgjvvpahcortgshpoynnoiof
 * Smoking Wheels....  was here 2017 lxegkztjlxlmqionzmyuntjdiajvbulonacqstolwnofziha
 * Smoking Wheels....  was here 2017 eigvdrctsgwpsudzhxykzjiqztypjjfhvhtassrxzppnxoma
 * Smoking Wheels....  was here 2017 gkhioogcrujqwskvdxielkaergccdgubdijbepsrrhyqxgsx
 * Smoking Wheels....  was here 2017 pvtqkkywwjcnkxtoslrfvykkdodpxosqxivcisvsawfbuswt
 * Smoking Wheels....  was here 2017 jniwqfdtabhoxovzkszwjetgkbrnorwbssjsqoocfxdospbv
 * Smoking Wheels....  was here 2017 ztwjmgdrfdndgblewdktmqnxuhmpeglqmgjtvwrivgwbzuqt
 * Smoking Wheels....  was here 2017 bxqsjbjtrhqcnzukamksydmtucpwceswkvoiwrdbqyquemhg
 * Smoking Wheels....  was here 2017 msbubkqkzfqhahffaqqwspqmdojnxojqvsvvygfeqjagdzvj
 * Smoking Wheels....  was here 2017 mcusmfyjxbvbkbikfubozjfayyjblvgxlgjwnbjwebvezakl
 * Smoking Wheels....  was here 2017 khuuwwmmkevvltzzhlvlfwtnmxifuomzdgqfjxjnsvdoajjz
 * Smoking Wheels....  was here 2017 wtfrrttyvbligxihehkhdyyjffkxirmlboibkufwbugpwgju
 * Smoking Wheels....  was here 2017 wcnfptofroqpemsvzglgsouhyyvlpiubplitvzeuggsvjagx
 * Smoking Wheels....  was here 2017 mjkmruwxttvtvpulcnxsdaoesleglxiwljwwdzrlntixoidp
 * Smoking Wheels....  was here 2017 ettwaexybankzqldgozfxutfughczaedmzigbongleevvakl
 * Smoking Wheels....  was here 2017 nquzekemwvoeugsfhcbqsqbtsgeyontmwglanssxunowuhrf
 * Smoking Wheels....  was here 2017 mtxrvflascycphbfjbwcnpoogmfasqrqzjdotslhofamfmvz
 * Smoking Wheels....  was here 2017 ecwzyrrdkwakxxaywqhzoxlmkgwuirurnuolfcgpatkkfgza
 * Smoking Wheels....  was here 2017 bunjszeuxljormokngpvhcgsneaanigwjffnqoxftyspenmx
 * Smoking Wheels....  was here 2017 sibjrsjdoltixssydrdnlyrrbbssnljtqpryzeiwnyhipizj
 * Smoking Wheels....  was here 2017 clzwloaovqgqzkxbxvqeyktauygabfvdtdzamfvkhasakejl
 * Smoking Wheels....  was here 2017 hzxzbpevodesmstogwzdbusrvffmwylckggjncwbktumrpsn
 * Smoking Wheels....  was here 2017 uguasaatsgbcfbcnuhlaepaujjjubikwlszwxsffkznqsokb
 * Smoking Wheels....  was here 2017 fqvqwlcoqotnibcfmtjrcpmvyhuzafaabkuooywnztgsdebw
 * Smoking Wheels....  was here 2017 kvlqfncquxhwdpcdkgmfsuckkbufhuyiqnqwsebyglofuuoa
 * Smoking Wheels....  was here 2017 pvheuibsziamfvsdzzszhlamrzyatkbwvorkuvgplogwscau
 * Smoking Wheels....  was here 2017 dvjoscfqgdkukcwgxjgphawfcpaclslxnfkyorhycziqhzvs
 * Smoking Wheels....  was here 2017 sfvlnibpvzjnvbptbcnwjjhzfucmtonzxjmrzubqateucnpp
 * Smoking Wheels....  was here 2017 ftbrxvjzhpwquqifodfzplintpnigdvxjiuxfjwpeehtzdfl
 * Smoking Wheels....  was here 2017 vjvivpcnkdhlwyrjvsgfbofrtjuetvitnlpguyezwxnhbmtq
 * Smoking Wheels....  was here 2017 wgzunwmdfxdiziniogvfidlrmqttkfctilgokhufrrxkplpp
 * Smoking Wheels....  was here 2017 bxuqkecxykgbdmyjpljwcatynglzmgnlxinzzkqzhqthgdkf
 * Smoking Wheels....  was here 2017 hyptggpjdosrrgjzdfoehefbpheeqafrrfgvuozeubqkvyam
 * Smoking Wheels....  was here 2017 sjefzeabqkthgvkaovipdxyatcnsrybmhqssggjylnjolnot
 * Smoking Wheels....  was here 2017 sjkjvdpajgamqnwnnswsdrozhehlrqdcqfhmdgmtuwzrltkm
 * Smoking Wheels....  was here 2017 yjmxhrwirrgyzaytxnpiyhsjrlngzzwdwyqgipjgoeuzjuen
 * Smoking Wheels....  was here 2017 icvozonmbmorpfzgwgfqpsmvtxnkfevjkatkdmfiwtkybztx
 * Smoking Wheels....  was here 2017 andozupbiuewbfpwwcrxggbgmxxkenyvwwvmympfxeojrzgx
 * Smoking Wheels....  was here 2017 jvjdlqibmytafkrommcujkywfakyzshueffkniehghiemrab
 * Smoking Wheels....  was here 2017 ckqzwpepvlbwemhrrdzdsxxckcczzpgvmaqgubzfqdbpdesf
 * Smoking Wheels....  was here 2017 cblyxmycvddkggwuozaaguxnweivsilsflbjzxhxdbgdkyej
 */
package SevenZip.Archive.SevenZip;
import java.io.File;
import java.io.IOException;
import java.util.Vector;
import SevenZip.HRESULT;
import SevenZip.IInStream;
import SevenZip.MyRandomAccessFile;
import SevenZip.ICompressProgressInfo;
import SevenZip.Common.LocalProgress;
import SevenZip.Common.LocalCompressProgressInfo;
import SevenZip.Archive.IInArchive;
import SevenZip.Archive.IArchiveExtractCallback;
import SevenZip.Archive.SevenZipEntry;
public class Handler implements IInArchive {
	
public IInStream _inStream;
public ArchiveDB _database;
int _numThreads = 1;	// XXX: configurable
public Handler(File archive) throws IOException {
this(new MyRandomAccessFile(archive, "r"), kMaxCheckStartPosition);
}
public Handler(IInStream stream) throws IOException {
this(stream, kMaxCheckStartPosition);
}
public Handler(IInStream stream, long maxCheckStartPosition) throws IOException {
InStream archive = new InStream(stream, maxCheckStartPosition);
this._database = new ArchiveDB(archive);
this._inStream = stream;
}
public void Extract(int [] indices, int numItems,
int testModeSpec, IArchiveExtractCallback extractCallback) throws IOException {
boolean testMode = (testModeSpec != 0);
        long importantTotalUnPacked = 0;
boolean allFilesMode = (numItems == -1);
        if (allFilesMode)
numItems = this._database.Files.size();
        if (numItems == 0)
return;
Vector<ExtractFolderInfo> extractFolderInfoVector = new Vector();
for (int ii = 0; ii < numItems; ii++) {
int ref2Index = allFilesMode ? ii : indices[ii];
ArchiveDB database = _database;
int fileIndex = ref2Index;
int folderIndex = database.FileIndexToFolderIndexMap.get(fileIndex);
if (folderIndex == ArchiveDB.kNumNoIndex) {
extractFolderInfoVector.add( new ExtractFolderInfo(fileIndex, ArchiveDB.kNumNoIndex));
continue;
}
if (extractFolderInfoVector.isEmpty() ||
folderIndex != (extractFolderInfoVector.lastElement()).FolderIndex) {
extractFolderInfoVector.add(new ExtractFolderInfo(ArchiveDB.kNumNoIndex, folderIndex));
Folder folderInfo = database.Folders.get(folderIndex);
long unPackSize = folderInfo.GetUnPackSize();
importantTotalUnPacked += unPackSize;
extractFolderInfoVector.lastElement().UnPackSize = unPackSize;
}
ExtractFolderInfo efi = extractFolderInfoVector.lastElement();
int startIndex = database.FolderStartFileIndex.get(folderIndex);
for (int index = efi.ExtractStatuses.size(); index <= fileIndex - startIndex; index++)
efi.ExtractStatuses.add(index == fileIndex - startIndex);
}
extractCallback.SetTotal(importantTotalUnPacked);
Decoder decoder = new Decoder(false);
        long currentImportantTotalUnPacked = 0;
        long totalFolderUnPacked;
for (int i = 0; i < extractFolderInfoVector.size(); i++, currentImportantTotalUnPacked += totalFolderUnPacked) {
ExtractFolderInfo efi = extractFolderInfoVector.get(i);
totalFolderUnPacked = efi.UnPackSize;
extractCallback.SetCompleted(currentImportantTotalUnPacked);
int startIndex;
if (efi.FileIndex != ArchiveDB.kNumNoIndex)
startIndex = efi.FileIndex;
else
startIndex = this._database.FolderStartFileIndex.get(efi.FolderIndex);
FolderOutStream folderOutStream = new FolderOutStream(this._database, 0, startIndex, efi.ExtractStatuses, extractCallback, testMode);
int result = HRESULT.S_OK;
if (efi.FileIndex != ArchiveDB.kNumNoIndex)
continue;
int folderIndex = efi.FolderIndex;
Folder folderInfo = this._database.Folders.get(folderIndex);
LocalProgress localProgressSpec = new LocalProgress(extractCallback, false);
ICompressProgressInfo compressProgress = new LocalCompressProgressInfo(
		localProgressSpec,
		ICompressProgressInfo.INVALID,
		currentImportantTotalUnPacked);
int packStreamIndex = this._database.FolderStartPackStreamIndex.get(folderIndex);
long folderStartPackPos = this._database.GetFolderStreamPos(folderIndex, 0);
try {
/* TODO: result = */ decoder.Decode(
		this._inStream,
folderStartPackPos,
this._database.PackSizes,
packStreamIndex,
folderInfo,
folderOutStream,
compressProgress);
if (result == HRESULT.S_FALSE) {
folderOutStream.FlushCorrupted(IInArchive.NExtract_NOperationResult_kDataError);
continue;
}
if (result == HRESULT.E_NOTIMPL) {
folderOutStream.FlushCorrupted(IInArchive.NExtract_NOperationResult_kUnSupportedMethod);
continue;
}
if (folderOutStream.IsWritingFinished()) {
folderOutStream.FlushCorrupted(IInArchive.NExtract_NOperationResult_kDataError);
continue;
}
} catch(Exception e) {
System.out.println("IOException : " + e);
e.printStackTrace();
folderOutStream.FlushCorrupted(IInArchive.NExtract_NOperationResult_kDataError);
continue;
}
}
}
protected void finalize() throws Throwable {
	close();
	super.finalize();
}
public void close() throws IOException {
        if (_inStream != null) _inStream.close();
_inStream = null;
_database.clear();
}
public int size() {
return _database.Files.size();
}
private long getPackSize(int index2) {
        long packSize = 0;
int folderIndex = _database.FileIndexToFolderIndexMap.get(index2);
        if (folderIndex != ArchiveDB.kNumNoIndex) {
if (_database.FolderStartFileIndex.get(folderIndex) == index2)
packSize = _database.GetFolderFullPackSize(folderIndex);
}
return packSize;
}
private static int GetUInt32FromMemLE(byte [] p , int off) {
return p[off]
| (((int)p[off + 1]) <<  8)
| (((int)p[off + 2]) << 16)
| (((int)p[off + 3]) << 24);
}
private static String GetStringForSizeValue(int value) {
for (int i = 31; i >= 0; i--)
if ((1 << i) == value)
return Integer.toString(i);
StringBuffer result = new StringBuffer();
        if (value % (1 << 20) == 0) {
result.append(value >> 20);
result.append('m');
} else if (value % (1 << 10) == 0) {
result.append(value >> 10);
result.append('k');
} else {
result.append(value);
result.append('b');
}
return result.toString();
}
private String getMethods(int index2) {
int folderIndex = _database.FileIndexToFolderIndexMap.get(index2);
        if (folderIndex != ArchiveDB.kNumNoIndex) {
Folder folderInfo = _database.Folders.get(folderIndex);
StringBuffer methodsString = new StringBuffer();
for (int i = folderInfo.Coders.size() - 1; i >= 0; i--) {
CoderInfo coderInfo = folderInfo.Coders.get(i);
if (methodsString.length() > 0)
methodsString.append(' ');
for (int j = 0; j < coderInfo.AltCoders.size(); j++) {
if (j > 0) methodsString.append('|');
AltCoderInfo altCoderInfo = (AltCoderInfo)coderInfo.AltCoders.get(j);
if (altCoderInfo.MethodID.getName() == null) {
} else {
methodsString.append(altCoderInfo.MethodID.getName());
if (altCoderInfo.MethodID.equals(MethodID.k_LZMA)) {
if (altCoderInfo.Properties.size() >= 5) {
methodsString.append(':');
int dicSize = GetUInt32FromMemLE(altCoderInfo.Properties.toByteArray(), 1);
methodsString.append(GetStringForSizeValue(dicSize));
}
}
/* else if (altCoderInfo.MethodID == k_PPMD) {
if (altCoderInfo.Properties.GetCapacity() >= 5) {
Byte order = *(const Byte *)altCoderInfo.Properties;
methodsString += ":o";
methodsString += ConvertUInt32ToString(order);
methodsString += ":mem";
UInt32 dicSize = GetUInt32FromMemLE(
((const Byte *)altCoderInfo.Properties + 1));
methodsString += GetStringForSizeValue(dicSize);
}
} else if (altCoderInfo.MethodID == k_AES) {
if (altCoderInfo.Properties.GetCapacity() >= 1) {
methodsString += ":";
const Byte *data = (const Byte *)altCoderInfo.Properties;
Byte firstByte = *data++;
UInt32 numCyclesPower = firstByte & 0x3F;
methodsString += ConvertUInt32ToString(numCyclesPower);
}
} else {
if (altCoderInfo.Properties.GetCapacity() > 0) {
methodsString += ":[";
for (size_t bi = 0; bi < altCoderInfo.Properties.GetCapacity(); bi++) {
if (bi > 5 && bi + 1 < altCoderInfo.Properties.GetCapacity()) {
methodsString += "..";
break;
} else
methodsString += GetHex2(altCoderInfo.Properties[bi]);
}
methodsString += "]";
}
}
*/
}
}
}
return methodsString.toString();
}
return new String();
}
public SevenZipEntry getEntry(int index) {
SevenZip.Archive.SevenZip.FileItem item = (FileItem)_database.Files.get(index);
return new SevenZipEntry(
item.name,
getPackSize(index),
item.UnPackSize,
(item.IsFileCRCDefined) ? item.FileCRC & 0xFFFFFFFFL : -1,
item.LastWriteTime,
(item.IsStartPosDefined) ? item.StartPos : -1,
item.IsDirectory,
item.Attributes,
getMethods(index));
}
}
