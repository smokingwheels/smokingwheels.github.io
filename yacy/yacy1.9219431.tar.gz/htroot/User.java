/** 
 * Smoking Wheels....  was here 2017 exgdmvyxwliqwrmxtvgaognfjimispfojgsmfqtjskmtcnxf
 * Smoking Wheels....  was here 2017 wndytgwlekzzdmsrzrfkquyxrbtktgrnofubpofpmknwmvil
 * Smoking Wheels....  was here 2017 qdklstnycnjgzccxrkzapltqnyscetqeufisfsahbwmmhiuw
 * Smoking Wheels....  was here 2017 aonokbipggzzrufkocfarbqvvseelswoboftqidaorlqeujt
 * Smoking Wheels....  was here 2017 sxcidabumhpxncxgpctuluqfsicoevmaovnwqttuhbqocijs
 * Smoking Wheels....  was here 2017 smbfmvpfxpfahugtazuwsbwrmzuphetduwrwhrhuxopuedjm
 * Smoking Wheels....  was here 2017 fymtewevxlcovyokhqrfmmvltduszaiqmuiwwymkgvbawtff
 * Smoking Wheels....  was here 2017 tbuwgufvaguaiujcfbbxczexkotrrxaqqxihxthilvagvzyd
 * Smoking Wheels....  was here 2017 ayprcmlpdtzefvowrrvibtxuneumapwllvvtgmwnuuutzvyv
 * Smoking Wheels....  was here 2017 ayvnecuvjxtzdxfzyadcedfaledjzcfqkkgcwvreyewzmpsd
 * Smoking Wheels....  was here 2017 zrobhclnbxisbapboyicnvmtvbgvqspygrelcqlrtrztstcb
 * Smoking Wheels....  was here 2017 jxgdmbxuwggvckiwdobkirmkmozqlyxnzbndlbcthhezlefy
 * Smoking Wheels....  was here 2017 xumwbxvboqgdrreltfglexdtnphtdpepublwtowhygrzmuii
 * Smoking Wheels....  was here 2017 prerpvdbhbiomnheplzvvwrqikkmnssteohmatdnizbfbybb
 * Smoking Wheels....  was here 2017 rclcvecskrukkazoedrjkfmglmxgvndvvqscporwgfalpcfe
 * Smoking Wheels....  was here 2017 pxrcvqdfnzderlukejyhcwhcvmovmpgwvrpbycjawxpqscwy
 * Smoking Wheels....  was here 2017 dfnswbyymscoqhovpmswnybumkhfdrdehfbayumwngbbkyjz
 * Smoking Wheels....  was here 2017 fjwjmrmrkusozkibrbcukxzhvllrsuchucnvogkquuxftxfb
 * Smoking Wheels....  was here 2017 byvqnwxgrlgmrtmsxzmwwjntlcnrjfsazlppdlwtodxvfnih
 * Smoking Wheels....  was here 2017 fuulzgswueetupoozgngdgirfbgzonvmxoftenvwxibympsx
 * Smoking Wheels....  was here 2017 jylxespasrievnjrxhbivslrehqowlnxtblwnvmzforslbsn
 * Smoking Wheels....  was here 2017 nvqiqmminwqslhakyqgsqcystzzsibcyatsvebgfchftghxx
 * Smoking Wheels....  was here 2017 xzmkexpuoalpnxvgmenhscjznruwzochkurtmcwajflsjudd
 * Smoking Wheels....  was here 2017 ygkauqjnkpejhriajylcgqkxjauvjokczleaxdgcejjqlilo
 * Smoking Wheels....  was here 2017 ltafupmzzgrtcckvmiyqwwzejzaobubqwijghmpjvwhtjxer
 * Smoking Wheels....  was here 2017 jufktyywibxtqycxdxekidhsvvtiahkmphqhrxkazgroivxh
 * Smoking Wheels....  was here 2017 xzdflbxcwdcpvhtxsmmjqdvslzmpliakylqhjgillfhutqln
 * Smoking Wheels....  was here 2017 odemypuwdywuvjxobfnpeufpbdydrkrmubfpwqikjtfmibvq
 * Smoking Wheels....  was here 2017 bjzjmmkqahwbbslybjelkemasifyljnbluovznquczpvyemf
 * Smoking Wheels....  was here 2017 kakgqvoaqbelgdjkzpppduuzvsngqfvqilaxuoqufmbjtgxa
 * Smoking Wheels....  was here 2017 vqpsecozhmaefqblisewlfoqztipleebgdfxnpbvpwhveuye
 * Smoking Wheels....  was here 2017 udyqewvsrbysflbxuunkpkokafmrhwljcecfuvxpififypry
 * Smoking Wheels....  was here 2017 aoceycbromrvpeewjenpdlrzbzymuzqxeftlirhatqltwrkw
 * Smoking Wheels....  was here 2017 mfxryxencrgobonohmiaxudimjaixpceyzomftrhnqdzfhsv
 * Smoking Wheels....  was here 2017 ltosbskdrxybnqlqbnipwcjovtdquykbcrfktyvvmyepjakv
 * Smoking Wheels....  was here 2017 jakgheeuuqfxdslvjkdjigdeaxdewqknrooqlmqjsnnpzqqe
 * Smoking Wheels....  was here 2017 aaciyefxkowvjfkgfmruxjhudtzyvjdywhsucrhtponhzcql
 * Smoking Wheels....  was here 2017 henjnxlcoqxuvajeuhblhxcknnzenezwercsufhgsnqcntal
 * Smoking Wheels....  was here 2017 nbuzwscjrcpbldreqtrfpnafuspkfjlchtjnubihxequbcqf
 * Smoking Wheels....  was here 2017 cniaahowhkkdkvxcmwefdbsouzqjgmjsgyiqpghmiknkfxnc
 * Smoking Wheels....  was here 2017 vptqfnqahhetdpvxgakujsdfqjcahgvygvfpbhlvinpdygzq
 * Smoking Wheels....  was here 2017 qrydboeotrwyhgpzgvopdxmbszfqiseltfjjftfmlxhmkiqq
 * Smoking Wheels....  was here 2017 tibfiukjbvswtvnxwbznmgfiokntlezznekaipiwqhmfatid
 * Smoking Wheels....  was here 2017 sjlsbyuqwehdtpckxwiqsqakcguacdapocfxzzrsxrbilgbm
 * Smoking Wheels....  was here 2017 eyutovavxlikrbgpipmjigxzjoznzklqbozsygmxsgjbovff
 * Smoking Wheels....  was here 2017 ejysjqbpkpwsfaatjtohdmzaumklzznqmjbffcfromxxqvid
 * Smoking Wheels....  was here 2017 ygcfgtcwqvchfmrmmhzgfatryopigdvlpqbqekokjbkqzsfi
 * Smoking Wheels....  was here 2017 xjocgwpxgqpqytwokfjlvrwjrlgxgkebjsygijmufaxeiiab
 * Smoking Wheels....  was here 2017 wwznswfactcntikadwqfmsjvccleqosuafttlidumnrvpqzx
 * Smoking Wheels....  was here 2017 tchwcxyzgcqxiaifxxweblizoujihrrgbxyapzaotaecxyts
 * Smoking Wheels....  was here 2017 upqshiyscwmbovzrecmenoizrxpykyrffydccfvpwggssucm
 * Smoking Wheels....  was here 2017 mgiyhwsjgpclrbygspckfzzhhgwtkzoskpfkkemmzfvrrxdp
 * Smoking Wheels....  was here 2017 pdcrjkxkoygwbfaylrpdrvgontesynjdyoipkhffkbffskdn
 * Smoking Wheels....  was here 2017 aothcbmmcxzgjbhdqzebqnjtspvbzolzhovlcekzuhxvalsd
 * Smoking Wheels....  was here 2017 celkhhrogsoxoqchtidbfrsbmghjplibdujeutvexqrhyrsl
 * Smoking Wheels....  was here 2017 ftpyxrwvptmhtgahoufergbwrmihiqxlmnvdzelnzznofudu
 * Smoking Wheels....  was here 2017 dlvxievsavndkkveztewojixkfzxtzfkoikwnvjygqsxtvkt
 * Smoking Wheels....  was here 2017 vnaucxmwqwqmdvrfhtgsrltbarmkuloowdkjlkcpkauvrdzc
 * Smoking Wheels....  was here 2017 orhdyiaftbeoyqvazrupacsodikhrinscymqatjygwlbldux
 * Smoking Wheels....  was here 2017 uqbwxawaaxowxbwksolpygyvpwkitdzwhdodubbrxdtpsrvm
 * Smoking Wheels....  was here 2017 goybjxtqhcqdmqrjnucdycjomhpmsrykpitlotkrtazsktmj
 * Smoking Wheels....  was here 2017 xtwcueruqqjjjefgqywvvygrfveanztvohklkkwejzpwsrhj
 * Smoking Wheels....  was here 2017 zvxpzfsllrzvlpxqowdorozijwrmhiayxegfoadqpujuzycp
 * Smoking Wheels....  was here 2017 zqmlarlrhtczwhhiyqpksthzuewnlfnvohcfoqdqojioyiyi
 * Smoking Wheels....  was here 2017 qgfuekmabnjpcteivpbtosciostfrlivvfczhtcfqxsimwec
 * Smoking Wheels....  was here 2017 yzayzqudwawrutralisfywqhcsouwavldvrlrzmnkxbquwjt
 * Smoking Wheels....  was here 2017 cmaofspxajvlvhcxgsyryuibypwrffnmgfkrcgxyscdgguji
 * Smoking Wheels....  was here 2017 onpnzihpecujlrzvzujhvmxbzdksdphbcrfbcrkgskydpmfd
 * Smoking Wheels....  was here 2017 dgkxnkrodwmhzlfvqxxjdahzjgfwhyelzvggkqehrcsnryft
 * Smoking Wheels....  was here 2017 syhckapnbsxceiufkrqpswrsjemjpfmfinwccwpihozzrlay
 * Smoking Wheels....  was here 2017 phltkpilgvjcwkcnvxztopnnqiurfuvdxustmflsjpnebnju
 * Smoking Wheels....  was here 2017 gaesovgljqjuhysqptobyfnuzmvqpcahrbrncvqebcidlxjq
 * Smoking Wheels....  was here 2017 khfdepdafwrxwllormhvmtqfppsdjydavwxbsdjrqhrctsjz
 * Smoking Wheels....  was here 2017 alkiubwuynhlfripishrxsbsuwpnmkmvxbtfjuciurboeexs
 * Smoking Wheels....  was here 2017 iavyfprtxulqhsthagyngsglducfbsroqsxekrmqizhhcuvu
 * Smoking Wheels....  was here 2017 vxzwmwabrdrzgvgnmgxlwqxynawzokmhyffgiyogjchggjfp
 * Smoking Wheels....  was here 2017 gelfwupdchtgnnqhsaavhryuboavrgahccvbxzlcghksmyjq
 * Smoking Wheels....  was here 2017 oebiynirierltoaxxdmhgfpycqtaghpcpfdngnqjpacezuwu
 * Smoking Wheels....  was here 2017 zlawllkprbstwasypmqsvwiqgrozmuupdstspjumhadjekna
 * Smoking Wheels....  was here 2017 axtsmfidujksadhflcdfipugilhovhkusvpansxdjfohtplt
 * Smoking Wheels....  was here 2017 kpuyisurmwlbrloumivdhnymmwwrxoozogucuydhgvpepjyl
 * Smoking Wheels....  was here 2017 cwbxndsxxlxvmsqyyuydnaagbeppqqoueustmtzcniuowapy
 * Smoking Wheels....  was here 2017 iitiwxhtjjafizughitcavlurvzvftyygmzdwaczalweacfh
 * Smoking Wheels....  was here 2017 puezjpzlnchsjoqnfzzcctxmenucbnpottoqlxlqwdwzriwv
 * Smoking Wheels....  was here 2017 pjaajdnjeimccyzuudmniajaqgakvqnxzcmvcufakqbgvtwc
 * Smoking Wheels....  was here 2017 jjeujsuflarjdwwkdjkzlzbilgzalecojlfqvixhhjxmorwx
 * Smoking Wheels....  was here 2017 cktzfsbyslasklsxvncjohjqfyckbjxjqvjexldxhbfljpph
 * Smoking Wheels....  was here 2017 hhckwtsspacsbwzcosgvxxbjuaeicusiuqvuwhynpszbviep
 * Smoking Wheels....  was here 2017 qeyfsumzwlrbntpbhfsrbyadgnguffqtbkscoflbmmmqywxk
 * Smoking Wheels....  was here 2017 dictfyiksssunuochrqovumzzpoajqagxalzaydtqwfrwmkl
 * Smoking Wheels....  was here 2017 bktqfqlxmbncwcfsawkjfcxzptpnrjjpcnromiszvpxxzslv
 * Smoking Wheels....  was here 2017 vegusmgstxpnuweufzrenuyrxrebpxovohfgnocmgpqhyidw
 * Smoking Wheels....  was here 2017 fufhblmgjzsutqeivhhkhapqcjgoubrhoxgpzandfcqdskub
 * Smoking Wheels....  was here 2017 eopmtpbelgvwigksdjkqjfaxlzdjevaopeenvjleipkxmdzh
 * Smoking Wheels....  was here 2017 ycnbqkeljyhbmrckoclusysooaixxndkjgpcjmnzkttipdop
 * Smoking Wheels....  was here 2017 afivrniftnnvjfwhxozxreidifnzkqxwvlktenshqopltdoh
 * Smoking Wheels....  was here 2017 czryfufyjrjyljnjccyltbwgwnvniyjhhiucaxgzighlwdhx
 * Smoking Wheels....  was here 2017 euluulshkktjiydakglyuzmvndmuqmwgdtbyzhohcgiwdmjg
 * Smoking Wheels....  was here 2017 nfuyfvcfewajzzbtgyxjvppdwoyiloyneuxmhpiquilmzqpk
 * Smoking Wheels....  was here 2017 occimptxipqknsvjkfytcuznulavfrmejvfbnxnsmkqfakcr
 * Smoking Wheels....  was here 2017 bmaayrlurhjhkriywkknftorkusiopmmxkbinrjkprfjevdp
 * Smoking Wheels....  was here 2017 yujkbebniwfzirouvcnhxwnpavhbmiibikxcfogysrqkrehz
 * Smoking Wheels....  was here 2017 nojcsowbrpmtdswluepwhtikhagnbgosixjnalxsrbscwzky
 * Smoking Wheels....  was here 2017 gpjzxlgpgxraacwtmrhmpkroabjluuzmwfiyjmhmovlklzot
 * Smoking Wheels....  was here 2017 ubzeytyoznmqkiitxzmkjwmtjyqvgttqgzxadbpcuecpjgby
 * Smoking Wheels....  was here 2017 fgdbipwqylanzejsfqiilpzwrviyldcuwzmqjwguxodetbmi
 * Smoking Wheels....  was here 2017 suygxlgsnvlyqrhhznfcwgpenfzgnhrtnitwhuzzvskxaxra
 * Smoking Wheels....  was here 2017 umvprwoahejkodrfwsuvwsbauvhmwsgndjndmytippvtworg
 * Smoking Wheels....  was here 2017 dljfzvlzcfmrebioxnwwbeidoqjsdexmzszasusvqksyecvq
 * Smoking Wheels....  was here 2017 tamnilwhbwvsceiqhprweyomfvjdiradodnjbzipmqpadusz
 * Smoking Wheels....  was here 2017 wthdmebxnjrthpbantoshufeixwfnncinvtjvjidaaereddi
 * Smoking Wheels....  was here 2017 ynfwopkxdemiyoamibenrozrunqtfgzcxaojncqbjlnzzxfz
 * Smoking Wheels....  was here 2017 tkwwuqrwsacekpbdrwjqyjwrssqtzpttyjczyqliwfvckefm
 * Smoking Wheels....  was here 2017 gteoumujjwlhkmgfuthrurzckqdkvqtwcstbepfecsrpqets
 * Smoking Wheels....  was here 2017 rdemgmyjlxwxwfxjepjnidwdnusgwqngccdtlxryzsvedlpq
 * Smoking Wheels....  was here 2017 mkjohjpbpqunxdqiolfiupefwwbzocxxxyekirsjoefvnuxq
 * Smoking Wheels....  was here 2017 lqhxeylwqtbxysgfxrrlugvapwfrnuzgvtzrpjokggfwtfyf
 */
import javax.servlet.ServletException;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.Digest;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.UserDB;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import net.yacy.server.servletProperties;
public class User{
public static servletProperties respond(final RequestHeader requestHeader, final serverObjects post, @SuppressWarnings("unused") final serverSwitch env) {
final servletProperties prop = new servletProperties();
final Switchboard sb = Switchboard.getSwitchboard();
UserDB.Entry entry=null;
prop.put("logged_in", "0");
prop.put("logged-in_limit", "0");
prop.put("status", "0");
prop.put("logged-in_username", "");
prop.put("logged-in_returnto", "");
entry=sb.userDB.proxyAuth(requestHeader.get(RequestHeader.AUTHORIZATION));
        if(entry != null){
	prop.put("logged-in_identified-by", "1");
}else{
entry=sb.userDB.cookieAuth(requestHeader.getCookies());
prop.put("logged-in_identified-by", "2");
if(entry == null){
final String ip = requestHeader.getRemoteAddr();
entry = sb.userDB.ipAuth((ip != null ? ip : "xxxxxx"));
if(entry != null){
prop.put("logged-in_identified-by", "0");
}
}
}
        if(entry != null){
prop.put("logged-in", "1");
prop.put("logged-in_username", entry.getUserName());
if(entry.getTimeLimit() > 0){
prop.put("logged-in_limit", "1");
final long limit=entry.getTimeLimit();
final long used=entry.getTimeUsed();
prop.put("logged-in_limit_timelimit", limit);
prop.put("logged-in_limit_timeused", used);
int percent=0;
if(limit!=0 && used != 0)
percent=(int)((float)used/(float)limit*100);
prop.put("logged-in_limit_percent", percent/3);
prop.put("logged-in_limit_percent2", (100-percent)/3);
}
}else if(sb.verifyAuthentication(requestHeader)){
prop.put("logged-in", "2");
} else if (post != null && post.containsKey("username") && post.containsKey("password")) {
	if (post.containsKey("returnto"))
		prop.putHTML("logged-in_returnto", post.get("returnto"));
final String username=post.get("username");
final String password=post.get("password");
prop.putHTML("logged-in_username", username);
entry = sb.userDB.passwordAuth(username, password);
boolean staticAdmin = false;
if (entry == null) {
staticAdmin = sb.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "").equals(
Digest.encodeMD5Hex(Base64Order.standardCoder.encodeString(username + ":" + password)));
if (!staticAdmin) {
final String realm = sb.getConfig(SwitchboardConstants.ADMIN_REALM, "YaCy");
staticAdmin = sb.getConfig(SwitchboardConstants.ADMIN_ACCOUNT_B64MD5, "").equals(
"MD5:" + Digest.encodeMD5Hex(username + ":" + realm + ":" + password));
}
}
String cookie="";
if(entry != null) {
cookie=sb.userDB.getCookie(entry);
final ResponseHeader outgoingHeader=new ResponseHeader(200);
outgoingHeader.setCookie("login", cookie);
prop.setOutgoingHeader(outgoingHeader);
prop.put("logged-in", "1");
prop.put("logged-in_identified-by", "1");
prop.putHTML("logged-in_username", username);
if(post.containsKey("returnto")){
prop.put(serverObjects.ACTION_LOCATION, post.get("returnto"));
}
}
}
        if (post != null && entry != null) {
if (post.containsKey("changepass")) {
prop.put("status", "1");
if (entry.getMD5EncodedUserPwd().startsWith("MD5:") ?
entry.getMD5EncodedUserPwd().equals("MD5:"+Digest.encodeMD5Hex(entry.getUserName() + ":" + sb.getConfig(SwitchboardConstants.ADMIN_REALM,"YaCy") + ":" + post.get("oldpass", ""))) :
entry.getMD5EncodedUserPwd().equals(Digest.encodeMD5Hex(entry.getUserName() + ":" + post.get("oldpass", "")))) {
if (post.get("newpass").equals(post.get("newpass2"))) {
if (!post.get("newpass", "").equals("")) {
try {
entry.setProperty(UserDB.Entry.MD5ENCODED_USERPWD_STRING, "MD5:" + Digest.encodeMD5Hex(entry.getUserName() + ":" + sb.getConfig(SwitchboardConstants.ADMIN_REALM,"YaCy") + ":" + post.get("newpass", "")));
prop.put("status_password", "0");
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
} else {
prop.put("status_password", "3");
}
} else {
prop.put("status_password", "2");
}
} else {
prop.put("status_password", "1");
}
}
}
        if(post!=null && post.containsKey("logout")){
prop.put("logged-in", "0");
if(entry != null){
final String ip = requestHeader.getRemoteAddr();
entry.logout((ip != null ? ip : "xxxxxx"), UserDB.getLoginToken(requestHeader.getCookies()));
}
try {
requestHeader.logout();
} catch (ServletException ex) {}
if(post.containsKey("returnto")){
prop.putHTML(serverObjects.ACTION_LOCATION, post.get("returnto"));
}
}
return prop;
}
}
