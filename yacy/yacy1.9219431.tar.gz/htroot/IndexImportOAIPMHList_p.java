/** 
 * Smoking Wheels....  was here 2017 ojzbneckujsnqtzjrshgveejhymvagyuhpwwosewmyoonsaa
 * Smoking Wheels....  was here 2017 misjrojnawxfgdkmryyazegznshtkrkiikimimaqwyzsjxoh
 * Smoking Wheels....  was here 2017 pckamqjtiwwsbrtqkkknswsdaoizmjamyfsmsfesyxiyqvva
 * Smoking Wheels....  was here 2017 trckwrpgqasxbirqzmzjcwjhzmyrnptikooreuqrdzgqvyym
 * Smoking Wheels....  was here 2017 zlaawjykeiuanibmsrcknafavptjzxtbjhnehhsleropsaif
 * Smoking Wheels....  was here 2017 qypuzoiwjysoyfcmdvnrqmohhjqrqykhomphzeyezpkribsz
 * Smoking Wheels....  was here 2017 gyqttjeoxghgcseddzenhpyggnrqouktejbrizdhtsdfxhyu
 * Smoking Wheels....  was here 2017 snchdexquaszzuagtljoszfgaxfmyrrmkoiduqhlzfiozefy
 * Smoking Wheels....  was here 2017 bzfygpkmecgbwtnuiunqeoizytwpjbjtyvftyguniovnhoyz
 * Smoking Wheels....  was here 2017 qxkplmruntpxhbvdkujwkjqjumntnsxcohpwsebqtjvawiur
 * Smoking Wheels....  was here 2017 zcmikzajninfzljswoyngwrnlufxlqzhhfucfbzhmpogyura
 * Smoking Wheels....  was here 2017 xpjlamzmcpeyyyvjsjkfvpfvepjgkbmjndggvspaxltsbluh
 * Smoking Wheels....  was here 2017 osiojnilnkxjmtcbiuhuoniajdohxmoovyskfidvtieczaoc
 * Smoking Wheels....  was here 2017 favnxcdzfaiyckjdfpijbqhxutrssrrmzpcyggfuzzykrnoc
 * Smoking Wheels....  was here 2017 liplffryvvhimqbchxlgglqsietnwpmvcmtlcbojuglvmevl
 * Smoking Wheels....  was here 2017 crqpfimmknwntmvtozxafmdufjfwpnxrmdbscsgeqjgvvmmh
 * Smoking Wheels....  was here 2017 fkdqazkaaalsccpbkkfokqxvxmpgkychsjtwxgoceugcnfxg
 * Smoking Wheels....  was here 2017 eapibckfgnqlabniiybyjbfsbyvjbpmeqfwgkcbjkenroivc
 * Smoking Wheels....  was here 2017 mjuwxvwysmhijbacftlmcbooqlzfpmsdizpltwnhnllrfdcu
 * Smoking Wheels....  was here 2017 znqnmmgkjonkbdudcapuqitwxxlzgwtfbglihkzpyupqabyr
 * Smoking Wheels....  was here 2017 utjwyrjykrqwknsmikaslswefotdoesqlwdxsvtdjrwgrwuh
 * Smoking Wheels....  was here 2017 fqnuqiigiaheyszklqjiciemiuukggayhuqpxnjcutingogi
 * Smoking Wheels....  was here 2017 uatjgnifubjajlzkivsznnfwehstjakzrleyydqvjyjozkhw
 * Smoking Wheels....  was here 2017 jwdxprzztlwksslhahfgvyutyzujetsryhgugmpboloyjwaf
 * Smoking Wheels....  was here 2017 aoubxjbzlcgngufcvnkzllxvccstdydjreogltnqbstiftyw
 * Smoking Wheels....  was here 2017 crhpmmovggbwmdncjkzgyeyzibhpbicoqedqlgytvkcsmyqp
 * Smoking Wheels....  was here 2017 dyiqzdwmxhecfnsulyylgnjipmqxyygbzodpjqrtbmygluck
 * Smoking Wheels....  was here 2017 ymwoirlajxsgkynzcmndnazhdjcvbzowyxdxquuifbvmrtlq
 * Smoking Wheels....  was here 2017 rpexpudxvbzmiqwrsoeddqvohxhwxzdgeburvuojzrrbvocu
 * Smoking Wheels....  was here 2017 ovsnghytsyrgmcwevzrnrlgzwmbsgrktmadfvambiypzafsp
 * Smoking Wheels....  was here 2017 gzenwieltyoirczagvyscvsstunjcacexdiewdktluxllahd
 * Smoking Wheels....  was here 2017 ncpfjgkfxttrwpvycjgfnjbeeuaasiamvyxjfzjdslfyqjxs
 * Smoking Wheels....  was here 2017 moffvsjkiirljvkzrfcxhzjbpqeepblatgpwpsqcyhkeicat
 * Smoking Wheels....  was here 2017 kvmisoernvvdqiuloddwcuveqvwmnythodjbvqtvabocpegd
 * Smoking Wheels....  was here 2017 xucsqxbydtemmwmuoflluebtjydynapbhxlmckoqeqayqupv
 * Smoking Wheels....  was here 2017 vmcqmdoidrtlxjcxtsefnswewzjuvmxigciztxagugleaoed
 * Smoking Wheels....  was here 2017 efssjwogtqzfdcosmgwbrhfcrdelzwwlcosrmfnpqiqmlclp
 * Smoking Wheels....  was here 2017 injurzzkjtjgtpboipfzwbmklvlqrywwohpwduntrnsvzmay
 * Smoking Wheels....  was here 2017 wfvybpfqtmwhlpaycvelaiegdsfjaqoluqgewdwdaubmwyvg
 * Smoking Wheels....  was here 2017 pjcnkbtcvmmigabqvgbxhubbytwvfgydbdclafoleigvpzbt
 * Smoking Wheels....  was here 2017 ohjdwajgusrmlfdrxkgizgflicaltgcgzqwthdynwndryidz
 * Smoking Wheels....  was here 2017 dodpvjerbjzinqkiwdosvxxizgnzljmiieplnfnpzcvxyzst
 * Smoking Wheels....  was here 2017 wydawdkikwhngahdomxkqbsxwvmkhrtcfbmcxdcztzstuerc
 * Smoking Wheels....  was here 2017 onisyuqiswsaqjlwbtpbojkndugwoivqzvzottskqjjtclgf
 * Smoking Wheels....  was here 2017 jpzgeyqcejobyyvormamarbvhhlxtwxfdiwytdqsiqrnnmvs
 * Smoking Wheels....  was here 2017 ntnoxklgimldsfomznzsqdxuavxfpajiopbntsmctnsbeicj
 * Smoking Wheels....  was here 2017 qtsqvikttrgxrxceuwkehbnmhattdvwuixwyyczydzvpggxd
 * Smoking Wheels....  was here 2017 nrowvcasnqcivcbkfxokdesjfwisrmjpsxtbrefxxcqpgrnj
 * Smoking Wheels....  was here 2017 hwgvzibnshirmzkeoexgngmajmfpqnabiikxpakxukztzjhn
 * Smoking Wheels....  was here 2017 gvhjtwpxwumjcahujleudleliiicvrgraguwobebsoabljxl
 * Smoking Wheels....  was here 2017 yjkoswyrrqneladumujkuehsdcsfhxrfvzfmtvhtwmbsxwhd
 * Smoking Wheels....  was here 2017 fpotuspaammzozqyaosrszrhysucgnhtbcdrohustjsewkqw
 * Smoking Wheels....  was here 2017 euzobykjdgtbscqgggrkfthufjcgfyfnijglonzuapvebshe
 * Smoking Wheels....  was here 2017 bneuanjincxwkwjzurzrzrmcqmnkyzxblxnesxjepyorouyv
 * Smoking Wheels....  was here 2017 nowofnuvunucjcftkzpxxbvketenmqyemzgmcbufthewowow
 * Smoking Wheels....  was here 2017 jaaeojfzyeotqtwfgjvpbnacadjtbcjwtewddvgoxvjgqlhn
 * Smoking Wheels....  was here 2017 rewgepkgfzozlbgmolbrxyfvqtuqfxgkwgdhmkbetzynnhnk
 * Smoking Wheels....  was here 2017 tpyqmdmhydjijnmvzabdampmscfwrubipiagycufflbqfjyf
 * Smoking Wheels....  was here 2017 ecxjcbryycwlcxbthdvkimugeuvkmtlkbrsqsnezndzuzyma
 * Smoking Wheels....  was here 2017 tstvxvnkcmdisepbpdpayoongvxlwbirowtgfpifdgkninhc
 * Smoking Wheels....  was here 2017 ptsqbywbqhoelpzsfnuvgpzxjjbmkdwkrswfzjlvsgcmbvuy
 * Smoking Wheels....  was here 2017 avhoykrozrsmtrmbsefxyrgjgvfguumdfhzvahexgugrdvqj
 * Smoking Wheels....  was here 2017 prftdfivwblymdkpxcvqvfaawxlqaawqhvjtjzgxxuegwwuk
 * Smoking Wheels....  was here 2017 dkmnqvizedxnqzmdxpupcvahjobylbxyezntlgslelmtsijh
 * Smoking Wheels....  was here 2017 shglmvllewklkmqqzgrpckiufysomkuinmdyxgxlseawmbuo
 * Smoking Wheels....  was here 2017 qxbkbctwikpdjczltxetmzfmcmggzuxhbmfrqihamsyodzub
 * Smoking Wheels....  was here 2017 ocqlctoegeijgpaaanhkeaglzxtzwfzryezntetrrynazjfs
 * Smoking Wheels....  was here 2017 fwyykdjmyxqbbzifwnfdgdeeccqymywklfxjrpgyucltnsgw
 * Smoking Wheels....  was here 2017 snfldyzfqmylclxapjltddbfvglphluwdjsgzsdulomkntia
 * Smoking Wheels....  was here 2017 jryvrzlzsdwzwowsvysklefoxvbrbmdnxrknqyxiqavaymdz
 * Smoking Wheels....  was here 2017 ubverjbtxgfkcaquigzkcqeihmoeuaoetmgtswkapluucent
 * Smoking Wheels....  was here 2017 tvxvanjqencrvvxcfpniedsxediftjzwaiqvpjqmszzenisp
 * Smoking Wheels....  was here 2017 jfjjvaebsxxzhgopupuadoxyaazjmzqviajvzoxpsbgwxqdb
 * Smoking Wheels....  was here 2017 yurrmumqyofvbuupranpozakmojhspvplqkcrvtonkrwheky
 * Smoking Wheels....  was here 2017 bjptrwpipywxvdaqpyskiupjokpymgizllyexuztjyrjzcmf
 * Smoking Wheels....  was here 2017 nacafscgptaeqjxmtrozqqlglnzoadzzsbnyziqvrvvvkznf
 * Smoking Wheels....  was here 2017 lblahwtudwzvtrjdjtofvkptnbdpwvaxugvnonzrfnzzknyl
 * Smoking Wheels....  was here 2017 dabpghqpsmkjrnoxbzldndispmztuzvglcweoupmvrguytkq
 * Smoking Wheels....  was here 2017 dtrwuayqaccndtyhqledrhginlobtqbuvxvocsfpugzliwvx
 * Smoking Wheels....  was here 2017 hgietliayheffhccekavjkbzoxgqbaqogfglofzsnkulakkm
 * Smoking Wheels....  was here 2017 rwfcgfoctczsekbjamkzzkwidbqaertwgvvzpjctspomucnw
 * Smoking Wheels....  was here 2017 qeultfqqvqekloxismdselzgyhqxyhvfsvonbnduinioryvx
 * Smoking Wheels....  was here 2017 syvivmwlyjobwocockdkvuwyxigghxmjqnrpcjxhobmvxfio
 * Smoking Wheels....  was here 2017 tghcjmuszzgqkjhugpqpcejuhcyhosrjkmpbdtkxwmpuajcd
 * Smoking Wheels....  was here 2017 vkkinugvejqiifjbnqddijnlntglehomomdbtuznzdpeudpd
 * Smoking Wheels....  was here 2017 gyqwrhflauhqeporkhkdfpquhuamziogxogwwwehtsoxeomk
 * Smoking Wheels....  was here 2017 pstvmcbmcpbgrigdvqixpdfznvkixvjlpcebposqmfvfmxrx
 * Smoking Wheels....  was here 2017 stsnupgbmmcdwidftafbprcmlvtfhavcwqjojtseotapfpjx
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.document.importer.OAIListFriendsLoader;
import net.yacy.document.importer.OAIPMHImporter;
import net.yacy.document.parser.html.CharacterCoding;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class IndexImportOAIPMHList_p {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
prop.put("refresh", 0);
prop.put("import", 0);
prop.put("source", 0);
        if (post != null && post.containsKey("source")) {
ClientIdentification.Agent agent = ClientIdentification.getAgent(post.get("agentName", ClientIdentification.yacyInternetCrawlerAgentName));
final Set<String> oaiRoots = new OAIListFriendsLoader().getListFriends(sb.loader, agent).keySet();
boolean dark = false;
int count = 0;
for (final String root: oaiRoots) {
prop.put("source_table_" + count + "_dark", (dark) ? "1" : "0");
prop.put("source_table_" + count + "_count", count);
prop.put("source_table_" + count + "_source", CharacterCoding.unicode2html(root, true));
prop.put("source_table_" + count + "_loadurl", "<a href=\"IndexImportOAIPMH_p.html?urlstart=" + CharacterCoding.unicode2html(root, true) + "\" target=\"_top\">" + CharacterCoding.unicode2html(root, true) + "</a>");
dark = !dark;
count++;
}
prop.put("source_table", count);
prop.put("source_num", count);
prop.put("source", 1);
}
        if (post != null && post.containsKey("import")) {
final List<OAIPMHImporter> jobs = new ArrayList<OAIPMHImporter>();
for (OAIPMHImporter job: OAIPMHImporter.runningJobs.keySet()) jobs.add(job);
for (OAIPMHImporter job: OAIPMHImporter.startedJobs.keySet()) jobs.add(job);
for (OAIPMHImporter job: OAIPMHImporter.finishedJobs.keySet()) jobs.add(job);
boolean dark = false;
int count = 0;
for (final OAIPMHImporter job: jobs) {
prop.put("import_table_" + count + "_dark", (dark) ? "1" : "0");
prop.put("import_table_" + count + "_thread", (job.isAlive()) ? "<img src=\"env/grafics/loading.gif\" alt=\"running\" />" : "finished");
prop.putXML("import_table_" + count + "_source", job.source());
prop.put("import_table_" + count + "_chunkCount", job.chunkCount());
prop.put("import_table_" + count + "_recordsCount", job.count());
prop.put("import_table_" + count + "_completeListSize", job.getCompleteListSize());
prop.put("import_table_" + count + "_speed", job.speed());
dark = !dark;
count++;
}
prop.put("import_table", count);
prop.put("import", 1);
prop.put("refresh", 1);
}
return prop;
}
}
