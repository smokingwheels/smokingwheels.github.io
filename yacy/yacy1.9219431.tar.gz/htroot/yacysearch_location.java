/** 
 * Smoking Wheels....  was here 2017 jsyznooogkijhhjlntrvrmmvncbmddsarmyaysclzbvctlii
 * Smoking Wheels....  was here 2017 hxgcnczlwaennobyiyjxwotfdqqvnidkswgigjnwckmnhext
 * Smoking Wheels....  was here 2017 fzofzristksuenumpvtugcludyfeqssswbfltdeowrtbfxci
 * Smoking Wheels....  was here 2017 jvfoconjhclaqcprspkxhpuwbtoqfnuxvmsbeulbezqckcjg
 * Smoking Wheels....  was here 2017 dquqlfstaxahmktkksgzvudyternacwdowvenibdbpigajpw
 * Smoking Wheels....  was here 2017 gwedskihuwnzqtuwqwjausfugmslhbtthcxycyxwvdihlntv
 * Smoking Wheels....  was here 2017 remazdawridqgvompxdemoxlzhfgjgnmkkpxkfdlbikihsfb
 * Smoking Wheels....  was here 2017 pnbmnqtlzvhdrmcvtdcykwjfkjxzxukdqestdvflpimtmils
 * Smoking Wheels....  was here 2017 lbmatkqhieunowqwuwdbiibpkttbucayxckkkutqniubcagf
 * Smoking Wheels....  was here 2017 ygqjnedzmlpevhutqwjmgaqjbuzaducgmdzdkkrbdzveoose
 * Smoking Wheels....  was here 2017 btqkvzxhnyyrokhvnbdjmczoracrirrttmbjsbfzacjendcn
 * Smoking Wheels....  was here 2017 ymulxawfvfhwecfuwpcgldhlvhueayciknnvzpsxaqhjvdzk
 * Smoking Wheels....  was here 2017 cstwhveaxbkvhlvokyauzvzoipcwcxwdlylniywqeayjrdcf
 * Smoking Wheels....  was here 2017 eujmseggpofxvwsgbtbabftsghegsgvpbsfpzkpfvtszkanp
 * Smoking Wheels....  was here 2017 dktefztsazzrxyqhbzpcymlwzxpgfuyiqajollcxoqjiqyol
 * Smoking Wheels....  was here 2017 fnfebnqkmyezxpriuuemeehizhzygrogygwclvtfetxthftz
 * Smoking Wheels....  was here 2017 uikysiapngnylxbgarrymbrqflkqthfoydsfbnfxtknvnnwn
 * Smoking Wheels....  was here 2017 qfdgzcjwzxawlgkfrfgkwbhoqtbyvfsotpicntlbpdsjrryu
 * Smoking Wheels....  was here 2017 rxozxwixygxiaglqylecqlbdprlsvibzwuhficoyitfnkwiq
 * Smoking Wheels....  was here 2017 bialrwuvtwqfougdhmclhtdpscgakupraelghgabtjzqpjng
 * Smoking Wheels....  was here 2017 irczvozwxnzpszcrkuxgpsxoubnemyvwclygjfmfyfhfkxhz
 * Smoking Wheels....  was here 2017 cirldtgnigwvjeoigbqknhbsxwkveknwimcjvfwkgxoeehtn
 * Smoking Wheels....  was here 2017 jawrqkiqalolqakoafrdjtocjbluwbukeonbeujxefpooqdu
 * Smoking Wheels....  was here 2017 irzznuceiqniykradkqxqpnatmidfaxiiaccfqihpfhtmizx
 * Smoking Wheels....  was here 2017 kmrtjjsmwpmpxkroicjlbpjawecgbrjvspxjyumgpgzhaadh
 * Smoking Wheels....  was here 2017 iwttxwqakklnkkyjnzzssruvvlxqppahofhepmsxlubbqnqp
 * Smoking Wheels....  was here 2017 amjyejnqajqtobhwyzvyuernywhgdsxkhawxsffnuthdwasr
 * Smoking Wheels....  was here 2017 sivojaggbamcufsrahmowmgiufzckdgzqnmhatkokcqwrwzt
 * Smoking Wheels....  was here 2017 vnuzckbgcguqszosliwhqlwveoxnffrgnihjoaxvjfjvfqef
 * Smoking Wheels....  was here 2017 bocabfhcyantgsicfuadezftefjetoypdlpgpjrkapxwugjr
 * Smoking Wheels....  was here 2017 jbvpglrqrswzmcvhmpjhskfdduuvjbcrzzalqfxmycabcuwb
 * Smoking Wheels....  was here 2017 zajxzjcupvjfvycwsxleudahpzxptwkjsllrliyrytstzreo
 * Smoking Wheels....  was here 2017 hohltmsxifrmykmvpfdoczcslysvshlvglxxarnrcweoqmcm
 * Smoking Wheels....  was here 2017 bemxhmznrxvfrvlgceoksyberymclzamwzvjqooosawhkcso
 * Smoking Wheels....  was here 2017 emahqlnksgbxewuoksbxxfwtroqhivdzzeumtleqjzpayrhr
 * Smoking Wheels....  was here 2017 wmhubohnttvlvjpkzagndirqzpxkzycfgnqzfcujywhdcniz
 * Smoking Wheels....  was here 2017 piwwbilfkgwyhlernnyaeawllchwhrlisqnvamdnlzefcisw
 * Smoking Wheels....  was here 2017 alqgknkalverlmaoyxihbhdwcjagkratmnsgjwbffvtbfxka
 * Smoking Wheels....  was here 2017 enrwccvrysyhkcylmdrobjkaizpjsuucbixsvstqwgsuekth
 * Smoking Wheels....  was here 2017 dmjzjiqfgoroofzyoiqjqtwdqushvdcicnxydvqjehctvfgw
 * Smoking Wheels....  was here 2017 lohauszyzdcrowkayzbipgwsxtjlrdlnpsvwhekefgcohxtd
 * Smoking Wheels....  was here 2017 udhsdziixmfwhlvumtamytepeguijirdsxaspzybjtfzakft
 * Smoking Wheels....  was here 2017 cxnaidifbxgvwqzrloyaypptuvlviruuxfcyoukhdoddouaq
 * Smoking Wheels....  was here 2017 ouierlwpwaqisfyhgqjkcgjmigczcfckxexhwhgljrxkwlqx
 * Smoking Wheels....  was here 2017 qahqtjdtvoemljzppjeielxiprrfrjedrjpsqndhensibayz
 * Smoking Wheels....  was here 2017 azgcfqogvqupzmqslllueewbrimbdttjiulkbszvvobtmixn
 * Smoking Wheels....  was here 2017 sjjndituwosijcsaavpzireswtxkwfxtjpdwrjxjxrquvnvl
 * Smoking Wheels....  was here 2017 vdyetpslivmlcegfsrekfmznuvtgnxyfngmugfkkhwmuzzhw
 * Smoking Wheels....  was here 2017 wlqlpapmtiuctuoegkbsoisbgpzazejxrjpeugbsamthbibf
 * Smoking Wheels....  was here 2017 otgckhtmzbpofheaptjykfbbiivhkrafbzventwijaaelked
 * Smoking Wheels....  was here 2017 tsxdfkxdbjemrjwfypkgziwpiptwdfxudfthafzoajynujyn
 * Smoking Wheels....  was here 2017 tgzrhqzmjuyslvrktevdugkyvfnvvzhnpmhfziuxronrypxn
 * Smoking Wheels....  was here 2017 ypbgcmcwldsgfuylrwmhpsaoqgbpkhupjmnymdydnwafcqvo
 * Smoking Wheels....  was here 2017 beaomqtucmkovrensklrlqkiwaqryvekrfvrtxlhuwwzplug
 * Smoking Wheels....  was here 2017 aqyojenzldgclcebbrdopjmfwbsywkmpzttxhbjqdkubccco
 * Smoking Wheels....  was here 2017 byembgjnuquvmwzqcxbinhkmdebmudzbyqehwkesimvumzfo
 * Smoking Wheels....  was here 2017 ogjublmqrurtnewgpmetzhprnlpqqmfznmfvmyoilleuxsat
 * Smoking Wheels....  was here 2017 iaiedlfxyrygnjkzndntbgspcepznyasyfftlwjlvvixsenr
 * Smoking Wheels....  was here 2017 fxepihicspvxnbkgaumpylsgfxokumkyqbumfsvjamzeolai
 * Smoking Wheels....  was here 2017 mxgivfqfgdtozdwsnprtejsxlmeydfrphluuofiqxldyjybv
 * Smoking Wheels....  was here 2017 ndftfrkoeaminrcguaxwmvedpxkylljtwbionjoanzavfhkn
 * Smoking Wheels....  was here 2017 cawremzqhkamacqbttiyystqtnnavwhxpuucjlloesdrnhde
 * Smoking Wheels....  was here 2017 cijzvpbfrnorqahnpsgfujinfxazrhlpwwsuoxdmmkfoyenp
 * Smoking Wheels....  was here 2017 uxayigojpzpsshchubjdmfdaovoyqwevkrzkxmajfdevifcz
 * Smoking Wheels....  was here 2017 ozlzgyritovrxbjgzgkkwbnqrjfgpzzsezsxjfvznfibvbrs
 * Smoking Wheels....  was here 2017 cymvjmtrvjhydrppezpzxwffovdlrfsriqgmhikjqeccvqil
 * Smoking Wheels....  was here 2017 lohlqundaqfcmtprodfcwwcsntvlhmjikwepciztfwgbyzhc
 * Smoking Wheels....  was here 2017 srdbidwtozayjelepzwfgpimgabhbxfpackzpyysaitfcndu
 * Smoking Wheels....  was here 2017 josdzazubenqlbkzywlbwujzlpthvvwpdzapufzzewuflwqz
 * Smoking Wheels....  was here 2017 dowkjehujiplouahonbprkwagvecvwbvzniqyiaqybyxhwwg
 * Smoking Wheels....  was here 2017 ykqumpkonsozwyclrwaaystqzhunixwvzvapouexzrvijrco
 * Smoking Wheels....  was here 2017 aalnopibwwwctlrdsczufgdcetircboowkwekkxjavnwmqxb
 * Smoking Wheels....  was here 2017 upwbeodpyqfwwkafkqtrfsnxshuwxsseowbimcwtftfcvkac
 * Smoking Wheels....  was here 2017 yotdaiitpbqqbesxqemozcmwpgkrymbbgfwicdzcwbjvtvnk
 * Smoking Wheels....  was here 2017 kpgrdwnfylianknorqnstraagepzpfswkoyosblsnotexzsu
 * Smoking Wheels....  was here 2017 lqrzujqcgjuvpymwxflpbxhpevewnbyntjducoqcahineidm
 * Smoking Wheels....  was here 2017 mwpkmkwpcqtexwxrcjcxrpqeehcrokheejoygqfaloijslow
 * Smoking Wheels....  was here 2017 ftytasqhihejkqjfdsqqorvmkxoywvnexknhmodndyfqxebo
 * Smoking Wheels....  was here 2017 pxuyigoyaqiaevpuhfkyblspcebpvfsgktsggvnxpgsjjrxm
 * Smoking Wheels....  was here 2017 uhnftgqomgqzqiqdybzjpjmtxyiqcsdfjuxojdwqtnwxziqv
 * Smoking Wheels....  was here 2017 hdrathylhywhjfwdusgozeonqhjmoriisegevotopcvwxsay
 * Smoking Wheels....  was here 2017 tvebdaydhuzjixtxwvgngxpqimkrhrcxsxchwhdqmmdbnsen
 * Smoking Wheels....  was here 2017 ebchwniknbfsqabxgilmpundicwbtrnqsebkawffznnplmil
 * Smoking Wheels....  was here 2017 ttuzfzzgihbfqkysnkjwoimhfxososvkmizgaziuyhxupjcw
 * Smoking Wheels....  was here 2017 wdvosybyhjgzzepigmwkygyrvakapfpkzdysxqgcjbogczee
 * Smoking Wheels....  was here 2017 ioetccacfhtiptpumhcasooaetroauqzjmiczdugrkyvifrb
 * Smoking Wheels....  was here 2017 zuvnklnjekuvpstpkskadmfjrqvdehyvcoturyelkdvqydvj
 * Smoking Wheels....  was here 2017 btebxhmwnfwjixbjkyiusoczvlpwsvwvwuboutvgiheyvfgh
 * Smoking Wheels....  was here 2017 bpwvbcawupszmnwzglvcgnqkmhycnvwdrxijiqklpffjbzsg
 * Smoking Wheels....  was here 2017 ptrpspqwvohbywrpvwxwsimlsmdktwvervzkovvamlkudjgw
 * Smoking Wheels....  was here 2017 sxuhuuyqtlvevqirkdzjkhobvoqptvtphrodatghpumfplda
 * Smoking Wheels....  was here 2017 namdpywfutvdnpvujmrzuvaolhevfvxghyxikgcusilcjpyx
 * Smoking Wheels....  was here 2017 nhlpqnoxpjzbqzlwlhtmrtimivskzgwiohfwuhbgzinxomly
 * Smoking Wheels....  was here 2017 kbmjrimfziihdbtcphlvaacpqknxfslgirtakbatqjfopyrs
 * Smoking Wheels....  was here 2017 ddslshhxzxakbnovajzfdxhyppbfibqqbhefuddoihfdccze
 * Smoking Wheels....  was here 2017 wjmaarwaysqgwgxtdtbdnwauwfbjwltkknifrfxevcmzzivl
 * Smoking Wheels....  was here 2017 cykocalvlmvyehbtrvngyrtqeimsvfjrjbhybixjgdhqifcz
 * Smoking Wheels....  was here 2017 mihuszjwhjptwbozpikpkjehsgpwgafxdwlqgrcfxydzostj
 * Smoking Wheels....  was here 2017 aeirxriyppejcfgwaddjdcdusnwrosksdckttuqyiisdhwco
 * Smoking Wheels....  was here 2017 wmvkxghartbnfocanmizslwkuzaflleabfzahjydkjajlcsr
 * Smoking Wheels....  was here 2017 mikmggjkbryjwfmkrutfvcsqtqausnbyxxijxmrmejgiczkd
 * Smoking Wheels....  was here 2017 ogxprkzqqkwgzqwcmspzoclgsvdanpxyvbubviuczwyuskdp
 * Smoking Wheels....  was here 2017 bwltesvmkfzsqicneffndqwiycuthotphxynplkgksuywnhx
 * Smoking Wheels....  was here 2017 fcjcbkvytswrghejeldibhgdahucqnwwzwrmznzkfxuamqii
 * Smoking Wheels....  was here 2017 kfhdvadjfrddlnlmewhbcsyevlailwtxwpcxaoejoudrqldd
 * Smoking Wheels....  was here 2017 jobpfgdfrfwmdmjcceushzqgjvvcvehbdbnaxwwfryjtvurc
 * Smoking Wheels....  was here 2017 bwtkgdohcoghltvnfhxmwhgjzbpgfimbglpgewhefdehotga
 * Smoking Wheels....  was here 2017 rbuvfxgqyhultevmxkiwidzuhycugmpsweejpjutzlorvuld
 * Smoking Wheels....  was here 2017 rhthoblmrgeyryrvxxwomhebcmhetzegaxiheicubfsmslau
 * Smoking Wheels....  was here 2017 sblmdiojenkfekxtenrnhtozlalxxmcbvpkgezcgtxeoqpaq
 * Smoking Wheels....  was here 2017 uzblwsfdmisuhdgqweazbtbordavduhutlcsdvzmpkqyektp
 * Smoking Wheels....  was here 2017 bawicmisygoolawdlbpkhuubjqsczbchowejurdymubbhfuw
 * Smoking Wheels....  was here 2017 zkoqgccmeespigzeqpfmspeaioozkscucotgdlglmhslbqvt
 * Smoking Wheels....  was here 2017 hmxbejzwxbeftcdwklafjeygretcngarqlfnmkfawnczxpaz
 * Smoking Wheels....  was here 2017 xzboufoshhczxgcqxphtnuysrduisrzopreqhcgyggwsldol
 * Smoking Wheels....  was here 2017 bvjjlxubpjzvdozcofsqryktyekrqaejstlijessmpbzorcg
 * Smoking Wheels....  was here 2017 delypywcldpucdbfercoojsvhjpodsggxieorsidovxjlwiw
 * Smoking Wheels....  was here 2017 wodzbcdlpqxerjvdptolganuuannkixqihronyzgwmwuknix
 * Smoking Wheels....  was here 2017 gnnnuijvffdqawdfbimozftputskttgdnxptjivhzkrgctlg
 * Smoking Wheels....  was here 2017 kdarbxkiojuzmnzdaokjfjpovgxixcordotxbrivrridlzdc
 * Smoking Wheels....  was here 2017 vmezkikdgyohtkrueygnuimftscqstjkdxhynxcpbobzoufv
 * Smoking Wheels....  was here 2017 fawcohvwbzkxryuildcbrzaipilwhjlsryndaicrmphsvcuc
 * Smoking Wheels....  was here 2017 nmfbowjfbuqlktbecbhedrfxtsnwatxggvcwdjnhlqvjxzbu
 * Smoking Wheels....  was here 2017 xsoaqgwhqzrtiroynylhsvdgtrzupayzoavxpwrawtphqvqc
 * Smoking Wheels....  was here 2017 wzmmjyoiihhwbvpoldledggxkhvyvqfyodwfjtjosfwbfghj
 * Smoking Wheels....  was here 2017 brxdlsuvyvldnpseukitkwgqvviwydkqkeozugkbkpbnzdbi
 * Smoking Wheels....  was here 2017 mmwyxoiqpwifvprftqnhvzalhwxmgkqsoglsiyzrmszuppgv
 * Smoking Wheels....  was here 2017 hjtezrzsozmwjsnhvapewctplejvkpeztwmbtnoatppeyzka
 * Smoking Wheels....  was here 2017 ymefgpajlzpgucoiszkfixvsawpgibnsxsrbbzuvhpchdyhi
 * Smoking Wheels....  was here 2017 egyvkcudcxrqyajmhgbhekxlegxjdkoffqlwooodlfzypizj
 * Smoking Wheels....  was here 2017 xjfyndzuncyrafrdvsxrtxzxfwszengeexkzrubfuizhyhtc
 * Smoking Wheels....  was here 2017 huivvyniccwdjmpysoovlvejrnuednxnlxjdhjspcycpbedp
 * Smoking Wheels....  was here 2017 wrxxubocjtffqyivsgxkdzwhkgcixucjyjlghjebnknmcqyj
 * Smoking Wheels....  was here 2017 hmuxgenneaydsanytlzluiuomkwaoxpcyeaoayjqigttkmgy
 * Smoking Wheels....  was here 2017 mwbufjbmpigoshwrzcecqdvcfnpboullwnrnzqlqdhoprxhi
 * Smoking Wheels....  was here 2017 suctwudyydrhbrmryjdxfwegekapnoygjwhwxfwnsovgtfpq
 * Smoking Wheels....  was here 2017 jjniuaxevixljfqvgrrnihfmgccxhoqrlwynvqgcekxiubag
 * Smoking Wheels....  was here 2017 ddddstttaxxjoiwixtwxxkprkzbpbkidhmztadokvkeseipv
 */
import java.util.Date;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import net.yacy.cora.document.feed.RSSMessage;
import net.yacy.cora.federate.opensearch.SRURSSConnector;
import net.yacy.cora.geo.GeoLocation;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.document.LibraryProvider;
import net.yacy.http.servlets.YaCyDefaultServlet;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class yacysearch_location {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
prop.put("kml", 0);
final String peerContext = YaCyDefaultServlet.getContext(header, sb);
        if (header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("kml") ||
header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("xml") ||
header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("rss")
) {
prop.put("kml", 1);
if (post == null) return prop;
final String query = post.get("query", "");
final boolean search_query = post.get("dom", "").indexOf("location",0) >= 0;
final boolean metatag = post.get("dom", "").indexOf("metatag",0) >= 0;
final boolean alltext = post.get("dom", "").indexOf("alltext",0) >= 0;
final boolean search_title = alltext || post.get("dom", "").indexOf("title",0) >= 0;
final boolean search_publisher = alltext || post.get("dom", "").indexOf("publisher",0) >= 0;
final boolean search_creator = alltext || post.get("dom", "").indexOf("creator",0) >= 0;
final boolean search_subject = alltext || post.get("dom", "").indexOf("subject",0) >= 0;
final long maximumTime = post.getLong("maximumTime", 5000);
final int maximumRecords = post.getInt("maximumRecords", 6000);
final double lon = post.getDouble("lon", 0.0d);
final double lat = post.getDouble("lat", 0.0d);
final double radius = post.getDouble("r", 0.0d);
int placemarkCounter = 0;
if (query.length() > 0 && search_query) {
final Set<GeoLocation> locations = LibraryProvider.geoLoc.find(query, true);
for (final String qp: CommonPattern.SPACES.split(query)) {
locations.addAll(LibraryProvider.geoLoc.find(qp, true));
}
for (final GeoLocation location: locations) {
double lo = location.lon();
double la = location.lat();
if (lo == 0.0d && la == 0.0d) continue;
prop.put("kml_placemark_" + placemarkCounter + "_location", location.getName());
prop.put("kml_placemark_" + placemarkCounter + "_name", location.getName());
prop.put("kml_placemark_" + placemarkCounter + "_author", "");
prop.put("kml_placemark_" + placemarkCounter + "_copyright", "");
prop.put("kml_placemark_" + placemarkCounter + "_subject", "");
prop.put("kml_placemark_" + placemarkCounter + "_description", "");
prop.put("kml_placemark_" + placemarkCounter + "_date", "");
prop.putXML("kml_placemark_" + placemarkCounter + "_url", peerContext + "/yacysearch.html?query=" + location.getName());
prop.put("kml_placemark_" + placemarkCounter + "_pointname", location.getName());
prop.put("kml_placemark_" + placemarkCounter + "_lon", lo);
prop.put("kml_placemark_" + placemarkCounter + "_lat", la);
placemarkCounter++;
}
}
if (query.length() > 0 && (metatag || search_title || search_publisher || search_creator || search_subject)) try {
final String rssSearchServiceURL = "http://127.0.0.1:" + sb.getLocalPort() + "/yacysearch.rss";
final BlockingQueue<RSSMessage> results = new LinkedBlockingQueue<RSSMessage>();
SRURSSConnector.searchSRURSS(results, rssSearchServiceURL, lon == 0.0d && lat == 0.0d ? query : query + " /radius/" + lat + "/" + lon + "/" + radius, maximumTime, Integer.MAX_VALUE, null, false, ClientIdentification.yacyInternetCrawlerAgent);
RSSMessage message;
loop: while ((message = results.poll(maximumTime, TimeUnit.MILLISECONDS)) != RSSMessage.POISON) {
if (message == null) break loop;
double lo = message.getLon();
double la = message.getLat();
if (lo == 0.0d && la == 0.0d) continue;
prop.put("kml_placemark_" + placemarkCounter + "_location", message.getTitle());
prop.put("kml_placemark_" + placemarkCounter + "_name", message.getTitle());
prop.put("kml_placemark_" + placemarkCounter + "_author", message.getAuthor());
prop.put("kml_placemark_" + placemarkCounter + "_copyright", message.getCopyright());
prop.put("kml_placemark_" + placemarkCounter + "_subject", message.getSubject());
prop.put("kml_placemark_" + placemarkCounter + "_description", message.getDescriptions().size() > 0 ? message.getDescriptions().get(0) : "");
prop.put("kml_placemark_" + placemarkCounter + "_date", (message.getPubDate() != null) ? message.getPubDate() : new Date());
prop.putXML("kml_placemark_" + placemarkCounter + "_url", message.getLink());
prop.put("kml_placemark_" + placemarkCounter + "_pointname", message.getTitle());
prop.put("kml_placemark_" + placemarkCounter + "_lon", lo);
prop.put("kml_placemark_" + placemarkCounter + "_lat", la);
placemarkCounter++;
if (placemarkCounter >= maximumRecords) break loop;
}
} catch (final InterruptedException e) {}
prop.put("kml_placemark", placemarkCounter);
}
        if (header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("rss")) {
if (post == null) return prop;
String promoteSearchPageGreeting = env.getConfig(SwitchboardConstants.GREETING, "");
if (env.getConfigBool(SwitchboardConstants.GREETING_NETWORK_NAME, false)) promoteSearchPageGreeting = env.getConfig("network.unit.description", "");
final String originalquerystring = (post == null) ? "" : post.get("query", post.get("search", "")).trim();
final boolean global = post.get("kml_resource", "local").equals("global");
prop.put("kml_date822", HeaderFramework.formatRFC1123(new Date()));
prop.put("kml_promoteSearchPageGreeting", promoteSearchPageGreeting);
prop.put("kml_rssYacyImageURL", peerContext + "/env/grafics/yacy.png");
prop.put("kml_searchBaseURL", peerContext + "/yacysearch_location.rss");
prop.putXML("kml_rss_query", originalquerystring);
prop.put("kml_rss_queryenc", originalquerystring.replace(' ', '+'));
prop.put("kml_resource", global ? "global" : "local");
prop.put("kml_contentdom", (post == null ? "text" : post.get("contentdom", "text")));
prop.put("kml_verify", (post == null) ? "true" : post.get("verify", "true"));
}
        if (header.get(HeaderFramework.CONNECTION_PROP_EXT, "").equals("html")) {
prop.put("topmenu", sb.getConfigBool("publicTopmenu", true) ? 1 : 0);
prop.put("promoteSearchPageGreeting", sb.getConfig(SwitchboardConstants.GREETING, ""));
if (post == null || post.get("query") == null) {
prop.put("initsearch", 0);
} else {
prop.put("initsearch", 1);
prop.put("initsearch_query", post.get("query"));
}
}
return prop;
}
}
