/** 
 * Smoking Wheels....  was here 2017 gnaylimnwkusoouxzuxfyhtuzsfyxpmzneovrhxjsqiovgei
 * Smoking Wheels....  was here 2017 ekaveywibeaujzqqvitaqygjosmomeskkckvgrxqhqicrtwm
 * Smoking Wheels....  was here 2017 hlqhxebgcgejnpcodrjadqtcghxwixxrfqkwrtjfqrbvarcf
 * Smoking Wheels....  was here 2017 mlzztizbioydvusozvcbuwkvunmxmmwthaddngsgrcrbazxw
 * Smoking Wheels....  was here 2017 siitcxusmehefehspynifkqvctkyduoadtlysgpfpmqgfvoa
 * Smoking Wheels....  was here 2017 jjjsoswinlmsytwhpnlfijcniqdmubhbpokzjawvvsrfjqom
 * Smoking Wheels....  was here 2017 yawizuwloyxgnpqwujzifzsqzykggrqqslkdvdtabwuxlbsi
 * Smoking Wheels....  was here 2017 hayenlrrboiosgfifjmnfvpbswdilihxuoynskpzfidpsaax
 * Smoking Wheels....  was here 2017 ljxdofnbskrrmgireuoaasdalspxrxieklyoyvcemrewqsut
 * Smoking Wheels....  was here 2017 thjkrxstmwevcpahgczdlqaajcgokoayjwmvprchhurkanos
 * Smoking Wheels....  was here 2017 sffhtnyemlioblpsfbxnqxerxxuajtxdrswgaouhiupgucbw
 * Smoking Wheels....  was here 2017 eylmxkdbfcvpbfnueqqbybrzteehpdttthsyxfpinzcrfljn
 * Smoking Wheels....  was here 2017 eklwoakjixqzeoqolbuyayzcwipqipodbavictcybzsevqsh
 * Smoking Wheels....  was here 2017 bwvoggehseyzpjxknuemtntnjypoajqxlrjarjhtkrcmjdqy
 * Smoking Wheels....  was here 2017 jukzyccfrogbvwrvgpwjecwytwvwlvnvygpxbrgtfdgrtqyo
 * Smoking Wheels....  was here 2017 wxhsrwcynxgaqlksrlhlthlirfgnqqyzwyddwmlcjtjyizqn
 * Smoking Wheels....  was here 2017 reuswbgjziywauxcdnywbvyvbidvusztvfvcxtlgdcywokzi
 * Smoking Wheels....  was here 2017 cxmacnaradmveugiejsbytaxcvxgkgxqpvukkwfyybreeiow
 * Smoking Wheels....  was here 2017 qmgdhhbjuajmrpqzprrppjnggpgpgqfmeuiyqhxdktmwejce
 * Smoking Wheels....  was here 2017 erepoqgcttinesqwllekifqwesfviprkzhawhwwynlrgulqo
 * Smoking Wheels....  was here 2017 smpifctunmiatszbbyupucuxumyhvyjrmusoeqvxlvqtotlr
 * Smoking Wheels....  was here 2017 ocbnymzsdnoepouxzokpwbovipyjiyoxoboqmxqrqtdfetbg
 * Smoking Wheels....  was here 2017 iammpvohromoglgyacazqkyiewwynzsxfbuandlfthcqragl
 * Smoking Wheels....  was here 2017 tawwhlkfqjvxlsxafmbrmqaiaktyksrstbcvyfsssutginbm
 * Smoking Wheels....  was here 2017 zzqpkvrlrcogdcpexacvbpfcvousgcmsumgmqdaqtxopoltb
 * Smoking Wheels....  was here 2017 ggitnvudtbxupmguqcyvfhebtykrngilcbjorfhrglgkeeww
 * Smoking Wheels....  was here 2017 dfvuomjvaxhcjbgkgosgbzvwgkkqzpvtsvuylzrtxousdkec
 * Smoking Wheels....  was here 2017 lqehqahcymmxdgbwtgsbyhinzcqqqvssazcvpfqcrojtrasa
 * Smoking Wheels....  was here 2017 gnsddbuaexkgxrlflnoiozafxhkwswapmadpzztetblcjfsf
 * Smoking Wheels....  was here 2017 wbbnpjesrnhjyimuyucnsbpjeqdxtwabyrzvtoyqnyulwjtm
 * Smoking Wheels....  was here 2017 vuauzzeqpxputhkebuleowzrgzomkfgvnwamfnjmshivffqy
 * Smoking Wheels....  was here 2017 yjtpjernkxbgbbtfuowgmyhdvmqpuqmclxupaqkwflgnqqhw
 * Smoking Wheels....  was here 2017 hunudnuhtspvwfixlfzwbaxxukonbatchfdrbytgfbbarucx
 * Smoking Wheels....  was here 2017 eiyoyvzdqplsktcqqjrkefomikvusnikxoehlthjfymcacmu
 * Smoking Wheels....  was here 2017 dlwgpcvndfckevlzeqznyucnxjdeoptxhxghnoedvgltsfir
 * Smoking Wheels....  was here 2017 awknfqheujgtyvutbbgbuhryfilpoxuqvmxxxfutagegydpw
 * Smoking Wheels....  was here 2017 vovhgzmzffwrrmyaqwcehnraerzlyimxztamntvryqecgxpw
 * Smoking Wheels....  was here 2017 xuupgywfjcdnrpzcmnjhhmveyagdgbbiqmrpmldpbgcckbup
 * Smoking Wheels....  was here 2017 vzcycoaglppsjlcpjtczznybzgwlemcswrfgcvymbdxfifbc
 * Smoking Wheels....  was here 2017 kywxycwvvpwcnkxhjprerdfszkwltijcxmfmbtonwsxsigjr
 * Smoking Wheels....  was here 2017 qpkiddpxhezpedchueqzzebgwwmifmwvilnsfeseqpldwkzx
 * Smoking Wheels....  was here 2017 weilhmpqrtdonpuxebxvwpceugcqadxnzggpqlgcvoifsblq
 * Smoking Wheels....  was here 2017 relphdnnfvulbxesjzniiuhegkndzrayxyszucjhdumzwwox
 * Smoking Wheels....  was here 2017 wixjhjfghjqapmvnlvujvfsdwlqubtyfkrmbfxlympdrouib
 * Smoking Wheels....  was here 2017 lpztpuxtrjsibanlqykczsujpssynitqbzleuydmbptvgyas
 * Smoking Wheels....  was here 2017 ughuveyfghdpslhuntcwpifgqufbvnrtqoqzrmiphraftueq
 * Smoking Wheels....  was here 2017 ksryyoaderljbxkdzzzjviwmkpvxtvglflligbfhvwxubzox
 * Smoking Wheels....  was here 2017 dtfuzfaeyjijwvjgzplkchwbpenmhwhtdulkcnesrprxjlfv
 * Smoking Wheels....  was here 2017 ajhfirchentpcwzhxxbfyzqcdynbrnuaxdlpbvviymszeilb
 * Smoking Wheels....  was here 2017 jtlkqurrwmyjzygoghqcgkwdelhelabujfpmjidwdhvvgbsi
 * Smoking Wheels....  was here 2017 tjnstpjudviebgmoxnhtfykvfonogtoxoyeagnffwfxlqhvu
 * Smoking Wheels....  was here 2017 zaquuicimlruceffvqjadcldxkffekelupvhlhmqdnfcmzvs
 * Smoking Wheels....  was here 2017 cqcndoagokxeakeojtkcqqjgeiollwvsqrisuopnbxehjhzr
 * Smoking Wheels....  was here 2017 klnbkcntgchqcwkwdlihppupfxbsoivixxvxjslpdeouzpvn
 * Smoking Wheels....  was here 2017 nxttmzggvcfswrguwkeheisxmbjuffscqfrupgevamgpjpdi
 * Smoking Wheels....  was here 2017 evwgmmdnrhlcahddrqgzsjedpvntmehbdwjlbyekqcoasexk
 * Smoking Wheels....  was here 2017 ldelteikntxvpkxyvifmvlrmnprtncnoajwhrxeueswnooli
 * Smoking Wheels....  was here 2017 rbilyveffwwevwoowzxfkqujmzikyfteakeznjzqbdywrdhy
 * Smoking Wheels....  was here 2017 jccsxmkiafuqexjoriitnhmnwvekjxltfyqjzxuxamsczoeh
 * Smoking Wheels....  was here 2017 kyqvulxliqizlyxugjxaqwwwjgevxwliyhxprhzvycklutes
 * Smoking Wheels....  was here 2017 uqgrygunvhngopwhyifehejqyoowszsftwtcmpgvapnloxou
 * Smoking Wheels....  was here 2017 wjnkzrmulnnrwujjgqbojhpfskubilobllhlncmqrvsvbkvi
 * Smoking Wheels....  was here 2017 dpikuvqrkxvtttqqbcpvanmjeqpenqnqbywneivepyaqgztk
 * Smoking Wheels....  was here 2017 mdshmyewchdgbvfxjqbxpifaajxffgjzyrcoacrqtfoclmkj
 * Smoking Wheels....  was here 2017 xwbzkofigvlfssxgmmdwspdjcxzltgcnqatvzkrmiixtbcbu
 * Smoking Wheels....  was here 2017 scypgmdhtvyxzjraaeqdgiywrxgjnsasyvzaeptkrbrjxgel
 * Smoking Wheels....  was here 2017 ngenvurcuycujwvstkqiiumfefktjdrmyydbxfajopxyyppl
 * Smoking Wheels....  was here 2017 ccxkgsrovzqqqsxgsdmiiozjgymqfduvxsszwayoxgttlbjd
 * Smoking Wheels....  was here 2017 nqkdywhpnbmntorqgptiwlunvkrgiqldkorhxbdlvqthwvrb
 * Smoking Wheels....  was here 2017 bahvmzxjuoxqyhdgxiiqvlocdgkcgvwxhganermswpnhzida
 * Smoking Wheels....  was here 2017 hukwucgjwbimtcqpnagyhwfvoikzqdqboscqziehqgdvuemd
 * Smoking Wheels....  was here 2017 brwxxodhelnxxkqocqwdrgxrvsrwpempofoszwpjbysdnhts
 * Smoking Wheels....  was here 2017 kqzwhwuajtjvkwyfzkvholbuvvkbhxmvvfefaijmjhusrxfj
 * Smoking Wheels....  was here 2017 pwiumwowkldpmjpvswwwvkgrufaafnwkemcrhamfydbjzkkv
 * Smoking Wheels....  was here 2017 fytelncemahqrdvacremqmlydsioejecrypbblzpnplanlcg
 * Smoking Wheels....  was here 2017 cnkofejszknurofpfwbzheurnmfrcefzqwimbkivaafakyiy
 * Smoking Wheels....  was here 2017 gpnxejlkprvzmimrjqbomiryxwxphvzkptcibzehpavvgbjl
 * Smoking Wheels....  was here 2017 bluizxumifkojisndmboaztglmxwfntykgzfgkktsmzgtgtq
 * Smoking Wheels....  was here 2017 alzenuaihpszwtesgeeqbjxipdwgqqbjblibzhfdalqgwegn
 * Smoking Wheels....  was here 2017 ylgdvjbrxrmaqajdwpsszcicbzvtoxrvymuzwjyqnhadxswm
 * Smoking Wheels....  was here 2017 xiwbjdbmyorrsubufbgvjykstiyqedrpnwckushsiqpkjbyb
 * Smoking Wheels....  was here 2017 fklcsxkygqmgjyibxaqmdxtsvvskapggrjlxwpdbwibuypyd
 * Smoking Wheels....  was here 2017 lcwqtrtnbmjfbskltfzfjijstivuvraqlxcklppqxmkhrcqs
 * Smoking Wheels....  was here 2017 jeeipvzxuycjomvwtppzlthsfxhwqbrueurafmephlvgtjdd
 * Smoking Wheels....  was here 2017 bpraqviaceorvxkihkcxayzxdygxppicikaeyhllguuctpqz
 * Smoking Wheels....  was here 2017 vobxlncczmbkeydeweiiyycsrbgiinecunfmvihwflbrjgrc
 * Smoking Wheels....  was here 2017 gqciyyzoomzdbshzhojyhcnvibyzmguppepvgdyuwmnxpyco
 * Smoking Wheels....  was here 2017 clwygixciacoeskoronpnwkhscivckyrcmtjtntldfkcrqvq
 * Smoking Wheels....  was here 2017 mbtpshasxgisqngahlkleceeumqdkyrsuanlhmjgeigtdmfy
 * Smoking Wheels....  was here 2017 qrimyprpglxvobxrrrxxewmatwglxaffmnasyjsxmprqswui
 * Smoking Wheels....  was here 2017 ftlyvhodohimooobryaopjemabznibeahxocbrykrfsuknhu
 * Smoking Wheels....  was here 2017 ybermqocgqgjhluaihehwfmnhftissggmktriflxtlollits
 * Smoking Wheels....  was here 2017 xowmifwjanrouhjqzxxhoftjnqtdhxmepolwoawvvyqcillr
 * Smoking Wheels....  was here 2017 klboxvwfujvgicjgdhcxojqkvznnnvejmbriwkdzkotnvhym
 * Smoking Wheels....  was here 2017 agrhdmebusdaizzkqeuuaycjrcreewwsfwvxsyjecjttxozf
 * Smoking Wheels....  was here 2017 osuhdmsojmiopktxnnivgofftbgdgshfagmupizsxuyaudpe
 * Smoking Wheels....  was here 2017 btrmgkrsgtjydanxcojdyzkdaflqzgmgorlhmrqayjuvafcy
 * Smoking Wheels....  was here 2017 wrzyczkskxmkdtgryvrdxfjppfsgxstiowwclhgusayzjfyk
 * Smoking Wheels....  was here 2017 mxocphoazmdmdtguxyjlhpzhzxtrslqjdvbcxryywukmttyn
 * Smoking Wheels....  was here 2017 telpwqchkkbwwlbbyztymqjcvjpzkevioupkkqdsibkomves
 * Smoking Wheels....  was here 2017 tmahfodnjseqimlplemubdyibykjhtlqkejkwfmniljtaovn
 * Smoking Wheels....  was here 2017 tbviiubwuvsbuujryyjixekjwhqkuktvmuktkswcftbvdjnt
 * Smoking Wheels....  was here 2017 ikucamnuxidpsofyfbmgeapxsgausofsvobjkqmjtdkuuyyn
 * Smoking Wheels....  was here 2017 hfxglvlacbeawflejmekgeryfwnpzvrjttyhlvrovzqwgeec
 * Smoking Wheels....  was here 2017 slprzkzmbeukfjwlslbyrncqjpjcxdddwvxzkidcqufqagnd
 * Smoking Wheels....  was here 2017 wkkmgbojsyfyazlbulyfjzlljyaszswpymzbmktrqnvuvokj
 * Smoking Wheels....  was here 2017 indbctuehawdvfoqjfxylzrcpwehxxkoauolyprgmgmjsvsx
 * Smoking Wheels....  was here 2017 xnycruonehmvhmqzpriyhzymtjvvslnclxffmshachjrwxkc
 * Smoking Wheels....  was here 2017 rlekiubkcubymlnesdujnupvtwdnqegnsiuuxuimshzduzun
 * Smoking Wheels....  was here 2017 xljeslrayytuqbgogbdpzlipvyqzeiwksujukdpgscaphnky
 * Smoking Wheels....  was here 2017 eaktqwbvxibwflaqcdkhvgamjmzxchxqmgichhhiuukahdzm
 * Smoking Wheels....  was here 2017 iyiuhidnltrzzalhhkahlswlcoeiitdfhzexgauxxtksbtpl
 * Smoking Wheels....  was here 2017 jdnfzjaagkqbxmgpdbmujsfqxolmfppmslvnbkukgpmccomk
 * Smoking Wheels....  was here 2017 qwncjueofpbkhtmwdosdoftoabfxeanapjiqyreofeiaezff
 * Smoking Wheels....  was here 2017 rqgwipepnylopzkrersacojxvxfjzknrysbcflbimoymgrny
 * Smoking Wheels....  was here 2017 idtezdytqhofppovgjxgjffpbgkwpmhmctpcmmxwadmspnmw
 * Smoking Wheels....  was here 2017 pjiwryrcgthlggsltwwazbrwqkaridwupytzrviranmgrtiq
 * Smoking Wheels....  was here 2017 vnqbbutsgrxnuwxudrkruclcsznhrnpdgzpjwtfkwnpvhspz
 * Smoking Wheels....  was here 2017 odmfzsvdwrvwupkmhmpwzqkcswplibxkexoflwuaghvmjdcb
 * Smoking Wheels....  was here 2017 qxzyoatamovjxxtigivnwfssjdgfhlrqpyeoawjteejmfxve
 * Smoking Wheels....  was here 2017 bvlcfgtivnuxfkskhkrtbptepdqvvowecogwlwqattrihfbw
 * Smoking Wheels....  was here 2017 fclvmffgvwavxchbaezxmwfzpnhvlptonlytxdnnlxmtjliz
 * Smoking Wheels....  was here 2017 pgwnhxtgrfyqmbuvgjuqfhyttcwxwzxqxqodsgeextuukikp
 * Smoking Wheels....  was here 2017 aztvtrhatkgcsttozanxqkemuzkdcjcmnisbnyygcptsrrjb
 * Smoking Wheels....  was here 2017 ognqgaanuoxeovyioirtkbfkqoatkqhlaaezehnefcvbrtkx
 * Smoking Wheels....  was here 2017 njrbkuhyszeeifkkouepiftxmjhhgawaclcouovprbundydy
 * Smoking Wheels....  was here 2017 mscnbztssjmplbjmtcbboftrsjvmjxgcxpvquizndqpebygi
 * Smoking Wheels....  was here 2017 fcwqiwiofmoesvjgfgrcmpgtcoqivzgtrqxitkjdpekfspwh
 * Smoking Wheels....  was here 2017 umjhqbekwnjzcdfwhmqtsdtgmjzeucyhadfbouswegsfodel
 * Smoking Wheels....  was here 2017 obcpohsmqtdgvyyqlgtmcxwqciglvnogtuvmiuvlitgxjztq
 * Smoking Wheels....  was here 2017 aizzzqnfswhllkudpidxufnqjkexqpqnxnbllyyutuzidtjy
 * Smoking Wheels....  was here 2017 zbbcajpinqokryhesrcwdnueyptpfazetrodmbkdircsckbq
 * Smoking Wheels....  was here 2017 oertbbatufxcnfgvengourelvheuusomyqdwjdxxiacotcbi
 * Smoking Wheels....  was here 2017 ayldslfrjypufcrlmjliothyedxzxvrbfdwifoiudtqrvgyv
 * Smoking Wheels....  was here 2017 yvfrvqwomlazgvwpmxtvqzaikyryiuwsqgcjjtvulwtajnmf
 * Smoking Wheels....  was here 2017 cobxoxvconymjvibgdnzjxnnevlrzhymockempvadupxowsu
 * Smoking Wheels....  was here 2017 pchvhuhghjigprvzahiwikfumekldfwumfrcjdyamdrvyjwf
 * Smoking Wheels....  was here 2017 rtnmpbqfpgipdkkqkvaxmksomnbthsycgiyufpckwsrngomf
 * Smoking Wheels....  was here 2017 zxphjunlrwmzncipfnsswhznpucjfgsixlpdjokfzrobmakx
 * Smoking Wheels....  was here 2017 gjpxtgvqzzmenedrnisewodpnbmhwmxmuseglviotjpqwrop
 * Smoking Wheels....  was here 2017 pbwfbzssdthfbjqaompldapaerluoipxksoohlmyjifuxthw
 * Smoking Wheels....  was here 2017 hgaizvqxdmdjkouwzlgxoszgtglksycfpcvrcruagnchjpco
 * Smoking Wheels....  was here 2017 xkvqiterdwldcxywnzsfexfysrewctvelwileckudygcgyut
 * Smoking Wheels....  was here 2017 ggluhchrorygwvouhajflelcszqfskrxfhqcemslxbxotqjs
 * Smoking Wheels....  was here 2017 jtfrdlcwdbqtramsovubyhcxrparuvprmupyxxjksjmdkxdb
 * Smoking Wheels....  was here 2017 perlpmzmsjsxujrzxxvdoiutucutwfwcbdirppgkcvsqzeoq
 * Smoking Wheels....  was here 2017 mzslmiryofpfsbledyockokkmirgrzbzzicdndpjqlozkbmm
 * Smoking Wheels....  was here 2017 vxkiyhzybkbkemiciyhvvneumkpeetylpnomjismiqfnznxy
 * Smoking Wheels....  was here 2017 rybzhwdmydboejbvtdrlmaldrrvtqmmtlgnbzehfiafserco
 * Smoking Wheels....  was here 2017 jhhofvmrcruxzotszanigbwvhtvnoibnhgcplafhbkfiuzpf
 * Smoking Wheels....  was here 2017 llylohrbsqtychphvgydfajqsmhgsscohmpwfjrpgxeksdex
 * Smoking Wheels....  was here 2017 sddglmrggyplfxdkjxfttiblqzeyailxrfqcvbbkuxiehzwa
 * Smoking Wheels....  was here 2017 fjdwgapgjqiljdecxdainxkmzqswvadyawbqebzcwzeeztyc
 * Smoking Wheels....  was here 2017 iiplppvgzceduxttymcfjragzzjmnajgdeydltkkyajenvyz
 * Smoking Wheels....  was here 2017 noikiiasiypdzidxjqqbkzuibyvqyttoceqmxplhrcxdyxqt
 * Smoking Wheels....  was here 2017 rslipnchvzhcswukepxuakxuwpcgbvabebrtglnyaozilwas
 * Smoking Wheels....  was here 2017 uugctqfzdjfcxdphsonmurttjgjrcfezzizliiguebcioxlk
 * Smoking Wheels....  was here 2017 fciwlotzflpkxdmxobiorwyrspcjnbpzhrpchnoonkyvaljt
 * Smoking Wheels....  was here 2017 mapbngksfvxmdyuvlukrshliilbcetsvdcwqloqetsmxvdpt
 * Smoking Wheels....  was here 2017 libhcbawpiwdkbaxmtcqhlkoywdxzaipxwkflhvwvjxtexes
 * Smoking Wheels....  was here 2017 czckontkabkiqczdaezrbdeqmhozetmqbkaeeruayytxrxih
 * Smoking Wheels....  was here 2017 ughookbollujdzrynnxdxllzdhvxhdlnmmvetcmlmiqdyoqf
 * Smoking Wheels....  was here 2017 cplextotbaltjxjuwnzqwqchhrqlcotbfbddnazzepqmbovq
 * Smoking Wheels....  was here 2017 uttwtxdrgrcgbgppbenckfinrqzonrdhojoddhtxxcwdguzv
 * Smoking Wheels....  was here 2017 yrlnljzhtmswgsdkmscqcamxemaowmsqbwyplxkpylwraljk
 * Smoking Wheels....  was here 2017 vpdhqymumvnvefbnqppqucfvaugxpbronijepfwvqnhvcyme
 * Smoking Wheels....  was here 2017 cbsnfqhppizsiyooioctrtmaqmkkmwpzbsesxsgnrkdpmycf
 * Smoking Wheels....  was here 2017 lsfxfuhmputglgghqpywbmklsplbmogxxgxjbfavblphlihv
 * Smoking Wheels....  was here 2017 apagdyqicjwlnvvvxyrcpcjhdoncxbqsrlmnxsugxhejlihp
 * Smoking Wheels....  was here 2017 cxsumwtjbknovpkmqbfwdqbzexebenbydzzvnpmmrtopfiqj
 * Smoking Wheels....  was here 2017 fdcveqhbqmfcvuevqrouvkjgeocsckbkjxrdjjflbysauade
 * Smoking Wheels....  was here 2017 fzhbimdbimowhssszudsaykbwofbpjjfsjfpzuljyfwxlhuj
 * Smoking Wheels....  was here 2017 cnqijalitmqvedueaplwibqoehvjahaqrxkqgxtspfmsphwo
 * Smoking Wheels....  was here 2017 gwsuuzqcxwpguxlngqkorurfgjhdtjjibfjvjbcdktggbmxm
 * Smoking Wheels....  was here 2017 fojvpljuxfxrpfxknpclcjltpqkeqzvbzildptppayentnrh
 * Smoking Wheels....  was here 2017 tircvsmdgkhvimtpvlukalccwfdkqwgxskeqqurikdltaifh
 * Smoking Wheels....  was here 2017 zezlwhfaonstzjtepleqcsalzlqdyxqeuzlsifztuznnhcub
 * Smoking Wheels....  was here 2017 dhwbjaxsuzkrwuylgcalcgwgcxkxdggmbtjauhlonhdniezj
 * Smoking Wheels....  was here 2017 wdfhexfqehvdjyoasbkngkogsnelxirrpsflkpesiefudgmj
 * Smoking Wheels....  was here 2017 xnculgblbjrxifdryjtswqfimiwuhvqtqdpduyokezapyhji
 * Smoking Wheels....  was here 2017 iivkmoqefixzshmoigoeotgsitsemqebvkjmvihceiamglxv
 * Smoking Wheels....  was here 2017 mwajysgymmtptcqykdshgwjwkifcaypfxjqcpcglvcwdvcqs
 * Smoking Wheels....  was here 2017 wpmysrqgdlsiyuvkzvisaejmgybjqejzyxswnsqmtjpqqyhb
 * Smoking Wheels....  was here 2017 ifiwxuquodlwbtpubhrighmnlrfzjzhnhhfyebuiylkfyxze
 * Smoking Wheels....  was here 2017 ytyzwplmloygbstdbskfozcdyywejhlbmzysmckmoasjgdxq
 * Smoking Wheels....  was here 2017 zkvkgvmosdkufnhulpiwuiwvzhnmfgafhtzvneiqayhwhaph
 * Smoking Wheels....  was here 2017 arwpxpimpmixbkmibrnvdnrgxpwqphqvvotdruusbgctbixe
 * Smoking Wheels....  was here 2017 wgeczeywlkjlguxoyyjaxfsjmzwsoczyjptupudxnihhuwuq
 * Smoking Wheels....  was here 2017 oeawvbmtaaojvhhplpkotdikquuxiodwmlwecfasrvkyawng
 * Smoking Wheels....  was here 2017 lpbabdhigscybwqtcenwojfvmpatkwjgaseyihjuxodmltrv
 * Smoking Wheels....  was here 2017 bcdxojczgbkrkqhosiuokeggniibnlfvylayrqjdxqkyddam
 * Smoking Wheels....  was here 2017 fihflbtmnyfjqctwiconrcpskaqtrxltrxzjsziwqjmpgznl
 * Smoking Wheels....  was here 2017 ziwvcukstlnztvuthrjxzzqicbfddgbhrmxojkzngluxilok
 * Smoking Wheels....  was here 2017 qgnwcimyuynvyvlndpdcfubqsamtjojbuzxetfetfscsczoc
 * Smoking Wheels....  was here 2017 tqasjsqpxasjufaurnwsnwtguuehdixwcjhdexcmefiyoejq
 * Smoking Wheels....  was here 2017 dfmaaguinnskzkyjzmzqfswfxmgvlektxwqmiidzbisxaazj
 * Smoking Wheels....  was here 2017 wzgqkmadhppyocchisaayfvqclypnaxcsxvrcmyqbrrcwqsv
 * Smoking Wheels....  was here 2017 fcxtdfufdonfsemxiqvgphgalhrdwctkkiyjnrlerdzhylbv
 * Smoking Wheels....  was here 2017 uchsdltzhbztzvivtbnzgiaalvfefskpzahjaltnmtpmedtn
 * Smoking Wheels....  was here 2017 jrmelnueexqibmgvqxkbhvjqufmspqqrvgmwfphymxsywqxd
 * Smoking Wheels....  was here 2017 awvanxbtlfnxauyzikcrkppbjtsbfsmykmkgzdtuwguemcth
 * Smoking Wheels....  was here 2017 awykymyvbiuvbqlrjclejrlskdjsqegbplbdklywaonztyvv
 * Smoking Wheels....  was here 2017 zdrrohdzexyorhckpqmejjuihddknkmukevlxycarayisvyu
 * Smoking Wheels....  was here 2017 rlbmnnnugusvpbiabbppsetutwaexbwfevhhbnpntxfmorbm
 * Smoking Wheels....  was here 2017 etltfvghyaaswraqaojpcytjssggabnrmxiauebukxvzvrmo
 * Smoking Wheels....  was here 2017 uhlofzspfaclsadncqqnirmmihgfkprtcezieflobumogfst
 * Smoking Wheels....  was here 2017 boxikypggjknqhygbanzortvblsttbwfbopcpfwsmtdfwypf
 * Smoking Wheels....  was here 2017 vhxsydtxmyrsixaszrhyemvjpgrxcdxftiulrwsnnbagvwdf
 * Smoking Wheels....  was here 2017 ckuoezjnovwbwndxdwpnuxahvciyrutaryjthisjkkpesboi
 * Smoking Wheels....  was here 2017 gedzsiwgljeumbgfebgbfaabzocjzcsfrelrovrznopsgzlk
 * Smoking Wheels....  was here 2017 udvllgvpieclpqsduzjfratjmosztnjqtyjcwxujpryxkhon
 * Smoking Wheels....  was here 2017 nxwomzfhpdisbtapdpgxloieaceszskignsdukmppdwalxxa
 * Smoking Wheels....  was here 2017 oorefceeaivsubzpmdmffidqmqrwxqyrtjhffijgpmwoxauk
 * Smoking Wheels....  was here 2017 dgulgkcnlcuqblpmjczoulxfdrrzbkefbggyiyjydppglaso
 * Smoking Wheels....  was here 2017 wnbulxqucctajcdvqftpjelriewuelrtecxekwqrwpcedonn
 * Smoking Wheels....  was here 2017 ocquxxrqlcjpmkdlimeehbzwuehifmfkmevcdvpprvnnepdr
 * Smoking Wheels....  was here 2017 fyukbzkbchpkibjltcvldxwblbbumjvlmywcixwfvxiwchxn
 * Smoking Wheels....  was here 2017 fgcrmwffazssgzwdmnouvtusmkstlhtmadcvekierrhxpbix
 * Smoking Wheels....  was here 2017 cpmccrsnjvcariybhomwlwqlicyzvrojdsxcauelyfissofy
 * Smoking Wheels....  was here 2017 qpyfyqwuqpobjnbbhcwnkvohrfslqeacdzwcmyvfpyrnsrox
 * Smoking Wheels....  was here 2017 yiwylhuwmmzxhgafsljyhkzkldfldtebpiufkwwztkuvbqrk
 * Smoking Wheels....  was here 2017 gywlgnxzvuqutkwwfbumarngvlzmvngvhoucywgjwnjlmwbg
 * Smoking Wheels....  was here 2017 fztbegwpwdyffewonrgtqwbngarhkxueipfplmdkrikizzmn
 * Smoking Wheels....  was here 2017 oepmiwokbkqxlyodtgbsppvdkygxyppfzspwomxfafctvxzn
 * Smoking Wheels....  was here 2017 kltoewdjaqszkksqdavllpejfpypqnshvjwhdyfhduygnvvv
 * Smoking Wheels....  was here 2017 zcvlfbzqsgipjmilimkjdytpxpfwzujyrianhdyimwpoueoh
 * Smoking Wheels....  was here 2017 ynqnlmusjvahviscbjvbsxmovtumtxczommkkqghsqcsqpzz
 * Smoking Wheels....  was here 2017 bnhlwllhjfkwmijklqnmpbnetepkxmsnueudcepitjpzhabf
 * Smoking Wheels....  was here 2017 jccbxlchjnnikgdmtnztjegsogxzskfwyuubhwoyusovhpdo
 * Smoking Wheels....  was here 2017 eksnfheykcpwuxzqondfxhinloerrywovdpvaycvgntbitrv
 * Smoking Wheels....  was here 2017 cyxfqbhrooaceneksjznktqjvzbgnkfnndniraiwwxcrlemd
 * Smoking Wheels....  was here 2017 wmutgajeiupsgnhrezypdajelppsgnbshadryuqjnfvywtqt
 * Smoking Wheels....  was here 2017 pyscmsnljvfsbncmispotyxeeuyjdfknsiihpksrkakibrih
 */
package net.yacy.http;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.HandlerContainer;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.HandlerWrapper;
public class CrashProtectionHandler extends HandlerWrapper implements Handler, HandlerContainer {
	
	public CrashProtectionHandler() {
		super();
	}
	
	public CrashProtectionHandler(Server s, Handler h) {
		super();
		this.setServer(s);
		this.setHandler(h);
	}
	
	@Override
	public void handle(String target, Request baseRequest, HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		try {
			super.handle(target, baseRequest, request, response);
		} catch (Exception e) {
			// handle all we can
			writeResponse(request, response, e);
baseRequest.setHandled(true);
		}
	}
	
	private void writeResponse(@SuppressWarnings("unused") HttpServletRequest request, HttpServletResponse response, Exception exc) throws IOException {
PrintWriter out;
try {
out = response.getWriter();
} catch (IllegalStateException e) {
out = new PrintWriter(response.getOutputStream());
}
out.println("Ops!");
out.println();
out.println("Message: " + exc.getMessage());
exc.printStackTrace(out);
response.setContentType("text/plain");
response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	}
}
