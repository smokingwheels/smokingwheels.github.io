/** 
 * Smoking Wheels....  was here 2017 oyhmjhyrbupuhammnjgdswmfbtzlemnnazqxbgzbirnqfrne
 * Smoking Wheels....  was here 2017 ffjnldmwexqctpnyeqtfbzkvagzhbgpeprmbhblrndzeufls
 * Smoking Wheels....  was here 2017 hhweejpzfificluugaphpqubyboamczmubtvnvowcchwwwzn
 * Smoking Wheels....  was here 2017 ipqwlzxmhrxyvupooivzlcpogallflfhreuddbomqqksjizp
 * Smoking Wheels....  was here 2017 dyteijibwuhurambdlufyyzisepngzcqoffbrpuvedpzqmkh
 * Smoking Wheels....  was here 2017 vhoafaaqqtluruekgqbctziofygovpqxzqwablzhwfgfbmoe
 * Smoking Wheels....  was here 2017 rvrpssjkmzogabswoknbtfhrxxwblmcpugvqlxyocrddmuzb
 * Smoking Wheels....  was here 2017 fcwetnbwrabsfzlculgraytjgxetvaapbzkvdnxqqqftvalb
 * Smoking Wheels....  was here 2017 huimjtzspurwazuwatpwztxqzccraxeyabgsucfsinrjjdzm
 * Smoking Wheels....  was here 2017 zwhkaxgvxijulspgopcufjcqyuwbfbpzhaergroekvzlqivx
 * Smoking Wheels....  was here 2017 npkaguhmpakrtcwoyjqupxbvjoymxrogqnfjsovuhnwthyoc
 * Smoking Wheels....  was here 2017 nlntzlucumedjhwkbwgngpqyrjbrxcppeouqlgemrqiikryf
 * Smoking Wheels....  was here 2017 uerfhepjzolvcteqxcjwoazwofepdbndekmqdoamnnnlfmzo
 * Smoking Wheels....  was here 2017 jrgipmwfujdvxcngufnzdynwznmpxlhdfmbuqnzeyvyofmaq
 * Smoking Wheels....  was here 2017 ohvfngbxffnjbgypgsofwlwibvmcrlfebosscmyhkjhmccmj
 * Smoking Wheels....  was here 2017 ylggwluwkuazakshejpgvuzagbvyeludvqrgvxduphnfxafu
 * Smoking Wheels....  was here 2017 ivpbvjyttwjkpzjcndxylnzvhhocldwauxqpmrxwmyxaxegf
 * Smoking Wheels....  was here 2017 tnfptpsoapnrtqsergelilhzaxwvslkenvjdytxzexwkosvf
 * Smoking Wheels....  was here 2017 orsxhwlmdirashstefdcipnxslfqlnseufzlilbueaccpamp
 * Smoking Wheels....  was here 2017 guwlfhvyfrizzcslvszpohpitvhiluiwsyvmainhdlpebvzm
 * Smoking Wheels....  was here 2017 rpvvtdurtlfiinecrszvkarfvccwqxzhpimipeqqznoveakf
 * Smoking Wheels....  was here 2017 xbyygxlpjvfbtextbntxmqdsxruoivtuyvukybdixvmqktah
 * Smoking Wheels....  was here 2017 fmtxhlexbcqklzzsnocfsdrhcdxwzrwypdviffxajfbiomho
 * Smoking Wheels....  was here 2017 fgddttrcaxwyydpqvoekdverxidpjxxoqgyatfbsavgxpvbd
 * Smoking Wheels....  was here 2017 qddguewvpbrjabhhcnhiegtuzjlsmdqsiltoewaouzhrttih
 * Smoking Wheels....  was here 2017 oddctfvbotatqjxsqrzekfwvhqanojbtgdbkjflawipbokjq
 * Smoking Wheels....  was here 2017 jltxhrazvgchabkiynegttdgzrjnbrlfgdzdlnfusryxterz
 * Smoking Wheels....  was here 2017 nptafocbnfjosgcpxtyhidmtmkemunizhivqujnvzegfhudl
 * Smoking Wheels....  was here 2017 xggargxaemphlinlniodmybhnwkjspnbuzfczmsiqdtflcrg
 * Smoking Wheels....  was here 2017 nlqwcfrsjdrmebkwdosyvyfbzmhmctavfqzvyzntveyktipb
 * Smoking Wheels....  was here 2017 rkkrahtlcowlegughwdagfrnbugjkgdvlxfouduuzemqwxkr
 * Smoking Wheels....  was here 2017 zomvinuqojppzeaduzacwahifscskkjwmwfcwlrjvfjuwlyd
 * Smoking Wheels....  was here 2017 fryzfdsydkqvhenisxqbcwgndiroczlbrtqqvuotgqugzwfu
 * Smoking Wheels....  was here 2017 ltczztrintxacxeyiwpzmqxeszhftvmtoyhmmcdimcglrjlg
 * Smoking Wheels....  was here 2017 yznzgcbaruqorjxhgitgyhzwdhjcudslyhgjauiuxlketjfh
 * Smoking Wheels....  was here 2017 ixdjxhomudivnrbygadooeiewcrbairzxrwduhfdgshldnhz
 * Smoking Wheels....  was here 2017 jeyvcoajgppsjfdskyeutucdpmbbkbdmtksxjmgnlicnctss
 * Smoking Wheels....  was here 2017 dviedmpquindftyrzikadztyfwwkfgdgaxrcsjclqxgxefsz
 * Smoking Wheels....  was here 2017 ybvosvtmhrfkhcleprrsnsvayvmoycyvoyvjwfpohfnjbjwq
 * Smoking Wheels....  was here 2017 hjjkrrckzffacmataqclcjjaffqhizccjmmnfqyvblvxtvxu
 * Smoking Wheels....  was here 2017 cmzhchnbhvfskichjgzcflkzrdiqipjbutgtliolxykuonxs
 * Smoking Wheels....  was here 2017 ijaekffjwpenegmuvtywnskbhysvhvtckgzlilbxzgtnxrdz
 * Smoking Wheels....  was here 2017 ihcdegopsyitsffqcpucvhasfghkpwouyrtfbfjvuhnxoqcm
 * Smoking Wheels....  was here 2017 rrapiledykcvljpjxoqlhjcqywucbdixobwzzepfydsxocof
 * Smoking Wheels....  was here 2017 diwezbatzvgpeecvhoutgowuczdzrivonozvtdfgkenucyoo
 * Smoking Wheels....  was here 2017 ueatlrfipjszvfocqwwfkrriqxpgrhbbjsxfedvkizlcrkkb
 * Smoking Wheels....  was here 2017 ylankbfbqjsismymlytenrfttfologiayfsskmjjfkeobxqn
 * Smoking Wheels....  was here 2017 eqttsholikscicononlivxjtvvvhbpefhcugvsybrorfgayb
 */
package net.yacy.contentcontrol;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.concurrent.ArrayBlockingQueue;
import net.yacy.cora.util.ConcurrentLog;
import org.json.simple.parser.ContentHandler;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
public class SMWListImporter implements Runnable, ContentHandler{
	private final ArrayBlockingQueue<SMWListRow> listEntries;
private final Reader importFile;
private SMWListRow row;
private final JSONParser parser;
	private final StringBuilder value;
	private final StringBuilder key;
	private final HashMap<String,String> obj;
	private Boolean isElement;
	public SMWListImporter(final Reader importFile, final int queueSize) {
this.listEntries = new ArrayBlockingQueue<SMWListRow>(queueSize);
this.importFile = importFile;
this.row = new SMWListRow();
this.parser = new JSONParser();
	    this.value = new StringBuilder(128);
	    this.key = new StringBuilder(16);
	    this.obj = new HashMap<String,String>();
		this.isElement = false;
	}
	@Override
public void startJSON() throws ParseException, IOException {
	}
	@Override
public void endJSON() throws ParseException, IOException {
	}
	@Override
public boolean startArray() throws ParseException, IOException {
		final String key = this.key.toString();
		if (key.equals("items")) {
			this.isElement = true;
		}
		return true;
	}
	@Override
public boolean endArray() throws ParseException, IOException {
		return true;
	}
	@Override
public boolean startObject() throws ParseException, IOException {
		return true;
	}
	@Override
public boolean endObject() throws ParseException, IOException {
		if(this.isElement) {
			for (Entry<String, String> e: this.obj.entrySet()) {
				this.row.add (e.getKey(), e.getValue());
			}
			try {
				this.listEntries.put(this.row);
				//this.count++;
			} catch (final InterruptedException e) {
				ConcurrentLog.logException(e);
			}
			this.obj.clear();
			this.row = new SMWListRow();
		}
		return true;
	}
	@Override
public boolean startObjectEntry(String key) throws ParseException, IOException {
			this.key.setLength(0);
			this.key.append(key);
		return true;
	}
	@Override
public boolean primitive(Object value) throws ParseException, IOException {
			this.value.setLength(0);
			if(value instanceof java.lang.String) {
				this.value.append((String)value);
			} else if(value instanceof java.lang.Boolean) {
				this.value.append(value);
			} else if(value instanceof java.lang.Number) {
				this.value.append(value);
			}
		return true;
	}
	@Override
public boolean endObjectEntry() throws ParseException, IOException {
			final String key = this.key.toString();
			final String value = this.value.toString();
			this.obj.put(key, value);
		return true;
	}
	@Override
public void run() {
		try {
			ConcurrentLog.info("SMWLISTSYNC", "Importer run()");
			this.parser.parse(this.importFile, this, true);
		} catch (final IOException e) {
			ConcurrentLog.logException(e);
		} catch (final ParseException e) {
			ConcurrentLog.logException(e);
		} finally {
			try {
				ConcurrentLog.info("SMWLISTSYNC", "Importer inserted poison pill in queue");
				this.listEntries.put(SMWListRow.POISON);
			} catch (final InterruptedException e) {
				ConcurrentLog.logException(e);
			}
		}
	}
public SMWListRow take() {
try {
return this.listEntries.take();
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
return null;
}
}
}
