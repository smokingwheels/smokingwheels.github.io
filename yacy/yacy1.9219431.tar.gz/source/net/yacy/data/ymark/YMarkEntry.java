/** 
 * Smoking Wheels....  was here 2017 yjvenumrtuqivkceqnxdutgeusjnwmpjlkwsmzmlpdttnuns
 * Smoking Wheels....  was here 2017 gkrhxnkcvxrzwctcnbruxgamdtvfuxtzrvlybrghsqfqrmbs
 * Smoking Wheels....  was here 2017 ntlnldjygwtagpdwhgfytuuyapkhuwttbnyicvgerczeuusm
 * Smoking Wheels....  was here 2017 fwyhzrbqgfkzncoctusgkqmdubunowdnqjtrzzqaercjwjia
 * Smoking Wheels....  was here 2017 gmhfrmiyhviqlznozrkofkfdegzyeopirrlfixtbdsumeewr
 * Smoking Wheels....  was here 2017 powdwakszwmzzxvjieyavvkbbndvuvgovxvgarhstulaeira
 * Smoking Wheels....  was here 2017 qkehfcqfhpbhjvnvhsdbdytjsnsqyvisuualfndsltuuqgfw
 * Smoking Wheels....  was here 2017 wldznvrwjrobdxvmracgfccumbmekbjrshjtfblawuwtorhi
 * Smoking Wheels....  was here 2017 cjvwyllksyrcaohfpceomuphdgkldcdmwrlfraquadvedlxs
 * Smoking Wheels....  was here 2017 lgnvxmctznjizksbifxbmvrznlrrjxsmvjcglmimandpytko
 * Smoking Wheels....  was here 2017 egxbytacbtwbilcjktfdegzkwhtlqqhfjdknrtmuisntragt
 * Smoking Wheels....  was here 2017 wwtwziwyffqvmutrroclqikfqpjlrsloozswtiesrvyrjxgi
 * Smoking Wheels....  was here 2017 hwdyclnxvvkjhwevfnywgrdjlllsmvzntbqmgbwkxgqpfikp
 * Smoking Wheels....  was here 2017 oemdsrfzpqcsqjdxgxioqzobhhgnhvwmlyzsbyfhgpbbtmae
 * Smoking Wheels....  was here 2017 yahplvgkkaycwfrgkfdxrkhthqgkqzkamhvfhhbderxvruqw
 * Smoking Wheels....  was here 2017 aylscxionplaknbjndjnldgdykcbeqcxydoviqpvhpdxbwzs
 * Smoking Wheels....  was here 2017 oqbdwgjeifhhatveorlhjtqdwqvoamugbrtuutgqpuancqdc
 * Smoking Wheels....  was here 2017 rbkscjmenzlxsnurxbyjbcuabtqdilljmkfjotpygtyghiio
 * Smoking Wheels....  was here 2017 qmdqkbcubfccsvxfburdidjeriyhprjvyachtvqmrkrukhcy
 * Smoking Wheels....  was here 2017 bkbgrjwmbptkounjxosgkfihdfnuqpcmoorktqleoweelggh
 * Smoking Wheels....  was here 2017 rmggzprxaxcoywczljmoowtjdoirkwjjpfovdwlgvlqspcuy
 * Smoking Wheels....  was here 2017 otckugrbphcqxqmczkmflvcpqqnfekgvqlpauqidrtovkzzm
 * Smoking Wheels....  was here 2017 bkdzqehcscavrcqbcfppygakudqwjlalmbxnwfyoorpjpijt
 * Smoking Wheels....  was here 2017 syghkkempxgrtkwkpnxjeijmavjkvheaeythrdlldiuhevtu
 * Smoking Wheels....  was here 2017 idnzgffxqpoywzsaogtjnriuaxqwmrmqbkulxehzjaiwkkdx
 * Smoking Wheels....  was here 2017 yxhyndojnhwralxygrsuoaiotrsnpoaqrxwikkbrjjqptfus
 * Smoking Wheels....  was here 2017 xmcivaqaeilbmuomhhqzflyejtbvraaovdaqhcsdqglhzqga
 * Smoking Wheels....  was here 2017 tkwncvbhvisrscwgkuqppgekiziqlnbhocpgyvkkvttxcjhx
 * Smoking Wheels....  was here 2017 hipdjxtyxckfmwjaseanbycegmowyswvfbghzjmqxgutijys
 * Smoking Wheels....  was here 2017 phsbbuwwaumtuswymqjxfjdqeqyvjomojltdgtqgaiyhetmy
 * Smoking Wheels....  was here 2017 yntluguhftenwpkgisocynyhezxagefztafkwhtzqvzijyln
 * Smoking Wheels....  was here 2017 ylorljfrooxbfqfpacrtjslvukffhznamtzbgnaukxvwxqpl
 * Smoking Wheels....  was here 2017 iwgkcjasodlcogwtpvauwmtfpbvkosgrvxqeaguwgwtdbszc
 * Smoking Wheels....  was here 2017 gsdmewiixmsqyecvkaghbqhppfywffkhkwadzmtrkifrijvz
 * Smoking Wheels....  was here 2017 yfvcgqptmbyzphzdahdrvfsmzoacvqglzmfpiotwhewglasz
 * Smoking Wheels....  was here 2017 zwepfslknkpqzstgeguohmyndwtxcmizqroljzakontvjike
 * Smoking Wheels....  was here 2017 flfpfktzkkjiwyyzayowtzcsuhegbjkyqqrvuoyndqatkfyv
 * Smoking Wheels....  was here 2017 qviaoftmwegcgpjkuqasyoofvflkxfnrpykckidqhfemavoo
 * Smoking Wheels....  was here 2017 qjcayztbvamekpawcsblqgbmmfbxffyshguxjpnmibytypvf
 * Smoking Wheels....  was here 2017 rlkyeslelpmdtdexsystahlfecslqtfxuoeebwgybigqffmu
 * Smoking Wheels....  was here 2017 qvgklstnetzrdpjkrjinlgvkpajdfncjkcfzbashiiijbopr
 * Smoking Wheels....  was here 2017 omajanubsoxvmsjjjdnwoyseqjhefkpjrjrthapyjrqlzwll
 * Smoking Wheels....  was here 2017 triyqzazykowaifehtceejrbmrwccpbmlbrduetoogxqslnw
 * Smoking Wheels....  was here 2017 uwzmcbatcwihiqfjgzeckwqrqwvqpnxpsfnyaajerdczgbpb
 * Smoking Wheels....  was here 2017 ktcqnbsbpvyxcbvujtcnszuaszevuvaswzxkpkvyorksvptj
 * Smoking Wheels....  was here 2017 tjzihphvdkkqigxnwiloqlmhrkdyvlkejxowihvhlmijzffi
 * Smoking Wheels....  was here 2017 cyfqbjdhpxxugekwjeaqcjjxsucmgohodspzjafysloqkint
 * Smoking Wheels....  was here 2017 zxszrmwxgzxxkyrjrbzjeajqgxweuofsdikpbeewdqbqdpmt
 * Smoking Wheels....  was here 2017 gamafflilmcsnaeyuxqpgxqizxicmczstbnwclcfokaokzbq
 * Smoking Wheels....  was here 2017 ygxpddzoxmnfpasocyonzxohudtlndqvmivfhypmfjzytqpa
 * Smoking Wheels....  was here 2017 jwowzzwtoihsvxhqcspnfzvwyfoulvkrexjftyrinkpnvypq
 * Smoking Wheels....  was here 2017 cihfruujpsyruvgrqxvfblivuynvypvcvsnvxaksepvispwq
 * Smoking Wheels....  was here 2017 xifhhyqdljexefbntnqnwwecbnoqccscvbvcjxewchyqpnjh
 * Smoking Wheels....  was here 2017 xxpygwoyunyjztnhtupnizuxsgxlbgbcsjfmyssfmciyawkf
 * Smoking Wheels....  was here 2017 igcjemybokmjmhqgfdnqgxwqwsatkfeogkrqurwltxuzscnf
 * Smoking Wheels....  was here 2017 vwnxwsmxytfkebszxjnnuxgbzupjvknkodpjijunpufvrunk
 * Smoking Wheels....  was here 2017 dmzenxbejixfulhjykyahndbtqqginyrwtpwcoxqycwsdyja
 * Smoking Wheels....  was here 2017 iaudlqvvngmvhdckpnihknwxdnirfllrvummaivhzledpsjs
 * Smoking Wheels....  was here 2017 tvowiqeaixenzbellepszzezgbeexjiaezixfyncdrxvumah
 * Smoking Wheels....  was here 2017 yhduzztgawluijvchctydexapevmesbmzgmzaycadyywtyev
 * Smoking Wheels....  was here 2017 rdomoymfyaajclpddhfvgrgzvyiqzdlepwowcczivoonsaup
 * Smoking Wheels....  was here 2017 bkgxlcmwwmvigaerkynozfoawrvxroojoijyhnukmcgfeweg
 * Smoking Wheels....  was here 2017 jisefffjrodxbzraopnmdxoqxautqdpsriawsmlzlmquwxwp
 * Smoking Wheels....  was here 2017 eiwqujheowkpamjtlxigwzbmjvzzsieazwvmumczmutguupq
 * Smoking Wheels....  was here 2017 hdtyguqayhhewysrdxgtobhozfipuszhuelybidqnkvuellu
 * Smoking Wheels....  was here 2017 uurazbjwoxvqpbowxvwcuvqaqmbwficyrtqqmcgjrwgancrp
 * Smoking Wheels....  was here 2017 ymizpzxvhcehmtxsidcsmlsinirglfummgnecbiwlcvqqbuv
 * Smoking Wheels....  was here 2017 isleapxlilvpzearfnyfsclfbnupfxptetlnitncmdlqlcoq
 * Smoking Wheels....  was here 2017 tffhhdgjcumiwslrpbtmwkapzelwnahwelatuzfhskjiebbi
 * Smoking Wheels....  was here 2017 gxxfvgdnihdmccytvwerpdureswhplwcytagjubwjmafkdnl
 * Smoking Wheels....  was here 2017 fccbgqyeyhzkzeoflnaetilwwrmlzkqajnprdlznvfdbwtnv
 * Smoking Wheels....  was here 2017 cgrelkhtbimmzeoqhsjpkgvylzabkgcmlqbxmnceusswmpuo
 * Smoking Wheels....  was here 2017 tbthmvdxfiipvmmxikovanevpqkewtcomjabauwcfixwonjy
 * Smoking Wheels....  was here 2017 gopftkprzkornucazweadvvrhcyzpsoocehoriwrgrfqptop
 * Smoking Wheels....  was here 2017 xxvdxzbejwhziakisocorhlzrxabcjwcbvzbmkcrjpjwhsvh
 * Smoking Wheels....  was here 2017 gqhktpgwoibcshtkkfjctfylfyjdcdlykgljxnpyffipraad
 * Smoking Wheels....  was here 2017 cmcrmnzmyrpsmbpccuimsbmzoizgqreensfrmowutwgdaqdl
 * Smoking Wheels....  was here 2017 nknvlilzgzuwoztlbopwfslvrjarxwzewsejdmnpderytslu
 * Smoking Wheels....  was here 2017 uqgagtbnjpxvgyfuxyarbdnkssawlyflixlbzplbvagurrmz
 * Smoking Wheels....  was here 2017 nrapuxmonekcafisjtrmlsoldfqpzhjwyjhrjnuenlarueac
 * Smoking Wheels....  was here 2017 mfzfdaovcnzlpcnapxwfswsvqywynogmzgjhyyzccvdxhdcn
 * Smoking Wheels....  was here 2017 thmtssnfvuqwairuvqfamnlwcixchrwpacljozrhtvbystzt
 * Smoking Wheels....  was here 2017 qbckdsrzqgornutirmpgqpjxtwgovvmwxpsmiwtmzfooukfq
 * Smoking Wheels....  was here 2017 sbqmgbtorpfhorahxcangmjrznpevkqarskorfkpkdouotog
 * Smoking Wheels....  was here 2017 safqecqqlrioykbkpnxuurqdoiwxidceqterdtzuyzhweuay
 * Smoking Wheels....  was here 2017 uxeuhimennvlqqqubyuetzoniqizowyricwirpepwhfjfpxg
 * Smoking Wheels....  was here 2017 exdbgorjyozfwhstwwnadktfmdlzzujaponaiyvqnyayjqta
 */
package net.yacy.data.ymark;
import java.net.MalformedURLException;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.data.CrawlProfile;
import net.yacy.document.content.DCEntry;
import net.yacy.kelondro.blob.Tables;
import net.yacy.search.Switchboard;
public class YMarkEntry extends TreeMap<String, String> {
private static final long serialVersionUID = 2179622977348536148L;
public static final YMarkEntry POISON = new YMarkEntry();
public static final YMarkEntry EMPTY = new YMarkEntry();
public static final String BOOKMARKS_ID = "id";
public static final String BOOKMARKS_REF = "ref";
public static final String FOLDERS_IMPORTED = "/imported";
public static enum BOOKMARK {
	URL            ("url",             "dc:identifier",    "",             "href",             "href",         "uri",          "link",		false,	YMarkUtil.EMPTY_STRING),
	TITLE          ("title",           "dc:title",         "",             "",                 "",             "title",        "meta",		false,	YMarkUtil.EMPTY_STRING),
	DESC           ("desc",            "dc:description",   "",             "",                 "",             "",             "comment",	false,	YMarkUtil.EMPTY_STRING),
	DATE_ADDED     ("date_added",      "",                 "",             "add_date",         "added",        "dateAdded",    "date",		false,	YMarkUtil.EMPTY_STRING),
	DATE_MODIFIED  ("date_modified",   "",                 "",             "last_modified",    "modified",     "lastModified", "date",		false,	YMarkUtil.EMPTY_STRING),
	DATE_VISITED   ("date_visited",    "",                 "",             "last_visited",     "visited",      "",             "date",		false,	YMarkUtil.EMPTY_STRING),
	PUBLIC         ("public",          "",                 "false",        "private",          "yacy:public",  "",             "lock",		false,	YMarkUtil.EMPTY_STRING),
	TAGS           ("tags",            "dc:subject",       "unsorted",     "shortcuturl",      "yacy:tags",    "keyword",      "tag",		true,	YMarkUtil.TAGS_SEPARATOR),
	VISITS         ("visits",          "",                 "0",            "",                 "yacy:visits",  "",             "stat",		false,	YMarkUtil.EMPTY_STRING),
	FOLDERS        ("folders",         "",                 "/unsorted",    "",                 "",             "",             "folder",	true,	YMarkUtil.TAGS_SEPARATOR),
	FILTER         ("filter",          "",                 "",             "",                 "yacy:filter",  "",             "filter",    false,  YMarkUtil.EMPTY_STRING),
	OAI            ("oai",             "",                 "",             "",                 "yacy:oai",     "",             "oai",       false,  YMarkUtil.EMPTY_STRING),
	URLHASH        ("urlhash",         "",                 "",             "",                 "yacy:urlhash", "",             "urlhash",   false,  YMarkUtil.EMPTY_STRING),
	STARRATING     ("starrating",      "",                 "",             "",                 "yacy:starrating", "",          "stat",      false,  YMarkUtil.EMPTY_STRING);
	private String key;
	private String dc_attrb;
	private String dflt;
	private String html_attrb;
	private String xbel_attrb;
	private String json_attrb;
	private String type;
	private boolean index;
	private String seperator;
private static final Map<String,BOOKMARK> lookup = new HashMap<String,BOOKMARK>();
private static final Map<String,String> indexColumns = new HashMap<String,String>();
static {
	for(BOOKMARK b : EnumSet.allOf(BOOKMARK.class)) {
		lookup.put(b.key, b);
		if(b.index) {
			indexColumns.put(b.key, b.seperator);
		}
	}
}
private static StringBuilder buffer = new StringBuilder(25);
	private BOOKMARK(final String k, final String d, final String s, final String a, final String x, final String j, final String t, final boolean index, final String separator) {
		this.key = k;
		this.dc_attrb = d;
		this.dflt = s;
		this.html_attrb = a;
		this.xbel_attrb = x;
		this.json_attrb = j;
		this.type = t;
		this.index = index;
		this.seperator = separator;
	}
	public static Map<String,String> indexColumns() {
		return Collections.unmodifiableMap(indexColumns);
	}
	public static BOOKMARK get(String key) {
return lookup.get(key);
	}
	public static boolean contains(String key) {
		return lookup.containsKey(key);
	}
	public String key() {
		return this.key;
	}
	public String deflt() {
		return  this.dflt;
	}
	public String html_attrb() {
		return this.html_attrb;
	}
	public String xbel_attrb() {
		return this.xbel_attrb;
	}
public String json_attrb() {
return this.json_attrb;
}
public String dc_attrb() {
return this.dc_attrb;
}
	public String xbel() {
		buffer.setLength(0);
		buffer.append('"');
		buffer.append('\n');
		buffer.append(' ');
		buffer.append(this.xbel_attrb);
		buffer.append('=');
		buffer.append('"');
		return buffer.toString();
	}
	public String type() {
		return this.type;
	}
	public boolean index() {
		return this.index;
	}
	public String seperator() {
		return this.seperator;
	}
}
public YMarkEntry() {
	this(true);
}
public YMarkEntry(final boolean setDefaults) {
super();
        if(setDefaults) {
setCurrentTimeMillis(BOOKMARK.DATE_ADDED);
setCurrentTimeMillis(BOOKMARK.DATE_MODIFIED);
setDefaults();
}
}
public YMarkEntry(final DCEntry dc) {
super();
	for (BOOKMARK b : BOOKMARK.values()) {
if (dc.getMap().containsKey(b.dc_attrb)) {
this.put(b.key(), dc.get(b.dc_attrb));
}
}
setCurrentTimeMillis(BOOKMARK.DATE_ADDED);
setCurrentTimeMillis(BOOKMARK.DATE_MODIFIED);
setDefaults();
}
public YMarkEntry(final Tables.Row bmk_row) {
super();
	for (BOOKMARK b : BOOKMARK.values()) {
if(bmk_row.containsKey(b.key())) {
this.put(b.key(), bmk_row.get(b.key(), b.deflt()));
}
}
}
private void setCurrentTimeMillis(BOOKMARK b) {
switch(b) {
	case DATE_ADDED:
	case DATE_MODIFIED:
	case DATE_VISITED:
		this.put(b.key(), String.valueOf(System.currentTimeMillis()));
		    break;
default:
			break;
}
}
public void setDefaults() {
for (BOOKMARK b : BOOKMARK.values()) {
if(!b.deflt().isEmpty() && !this.containsKey(b.key())) {
this.put(b.key(), b.deflt());
}
}
}
public byte[] getUrlHash() {
	if(this.containsKey(YMarkEntry.BOOKMARK.URL.key()))
			try {
				return YMarkUtil.getBookmarkId(this.get(YMarkEntry.BOOKMARK.URL.key()));
			} catch (final MalformedURLException e) {
				ConcurrentLog.warn(YMarkTables.BOOKMARKS_LOG, "getUrlHash - MalformedURLException for YMarkEntry: "+this.get(YMarkEntry.BOOKMARK.URL.key()));
			}
	return null;
}
public DCEntry getDCEntry() {
final DCEntry dc = new DCEntry();
for (BOOKMARK b : BOOKMARK.values()) {
if(!b.dc_attrb.isEmpty() && this.containsKey(b.key())) {
dc.getMap().put(b.dc_attrb, new String[]{this.get(b.key())});
}
}
return dc;
}
public Tables.Data getData() {
final Tables.Data data = new Tables.Data();
for (BOOKMARK b : BOOKMARK.values()) {
if(this.containsKey(b.key()) && this.get(b.key()) != null) {
data.put(b.key(), this.get(b.key()));
} else {
data.put(b.key(), b.deflt());
}
}
return data;
}
public void crawl(final YMarkCrawlStart.CRAWLSTART type, final boolean medialink, final Switchboard sb) throws MalformedURLException {
		final DigestURL url = new DigestURL(this.get(BOOKMARK.URL.key()));
		switch(type) {
			case SINGLE:
				YMarkCrawlStart.crawlStart(sb, url, CrawlProfile.MATCH_ALL_STRING, CrawlProfile.MATCH_NEVER_STRING, 0, true, medialink);
				break;
			case ONE_LINK:
				YMarkCrawlStart.crawlStart(sb, url, CrawlProfile.MATCH_ALL_STRING, CrawlProfile.MATCH_NEVER_STRING, 1, true, medialink);
				break;
			case FULL_DOMAIN:
				YMarkCrawlStart.crawlStart(sb, url, CrawlProfile.mustMatchFilterFullDomain(url), CrawlProfile.MATCH_NEVER_STRING, 99, false, medialink);
				break;
			default:
				break;
		}
}
}
