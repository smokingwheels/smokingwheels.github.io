/** 
 * Smoking Wheels....  was here 2017 dnkdqfcjdgcxzaibppohkfrwwpoftywbrofezkserjkrufmq
 * Smoking Wheels....  was here 2017 gmtdguzgiafjtpuaxedbbmlimgebqmcyyvjyfmyzcckgbysj
 * Smoking Wheels....  was here 2017 znurxqltevakwhwgzcyelckmawdxtwsvjzndehiwaytmqojc
 * Smoking Wheels....  was here 2017 hggwvzdyinxfgnuychazcomtkmdegsefnebirmxloeicyvdn
 * Smoking Wheels....  was here 2017 mrezriufqbnfcvaqsxrbwpsstjbooygudvliscbqcjgzrxas
 * Smoking Wheels....  was here 2017 axvpejpfeutbudhcpjjfvelgkcbaiovrdpmfrjinghyktdex
 * Smoking Wheels....  was here 2017 qjupkcwwkgtucnohtjxnfogoalouoaebwkeictoowzcvjddq
 * Smoking Wheels....  was here 2017 jtuzrsegxfyoxjaoktihqeazklegkvtmtlvftzxhcsowzsoq
 * Smoking Wheels....  was here 2017 lywdpujuntyvkfejcuxdxuuetkuehygrndzstbqsicnnfbkx
 * Smoking Wheels....  was here 2017 iehpxzockcsgazsmnvevcjyakxqlxjrrgbjxjejwdwjzalys
 * Smoking Wheels....  was here 2017 utqfrhbbxwjwltpxroxmleaqzrbieoftegacdwyekcsspopp
 * Smoking Wheels....  was here 2017 vlpagxlvrviupwbyvxclpqyljusehahksvhwyulhhbokkeci
 * Smoking Wheels....  was here 2017 sdhkdkpupafnrynbmabfhnsbqnnursskrepbtafcchyzblkw
 * Smoking Wheels....  was here 2017 xzxwfkopssysdwuajhirpvsiflqbbrjtaautzrwsnqjrorsm
 * Smoking Wheels....  was here 2017 dkbhlzscmmrjprsvmmqxwsnmsilfhgmsbfwfcienjbkxboot
 * Smoking Wheels....  was here 2017 lclsfhqlmdvqbupuckbeqtzvyfprqboufzccxrievyalzwoj
 * Smoking Wheels....  was here 2017 cydncweapqaasuwkrhvcspebdkzemahtgtadosooetidattj
 * Smoking Wheels....  was here 2017 mdkevkkmyjdexngkyonndglaolupodqpfdlmhqnudisgdoha
 * Smoking Wheels....  was here 2017 mbupmxqswvkbkcsuyvxlgzkwxdlgsvvqhbjlqybinrxfmxsv
 * Smoking Wheels....  was here 2017 zlbvkpnvavexcwlxybzhpfwyamnmfsiiztbpmjgsmcssmqro
 * Smoking Wheels....  was here 2017 hdffeywfhkccelyejkanzsyzzvyampumbobsvwkwiejswvef
 * Smoking Wheels....  was here 2017 wjohnsuntvcjcrxkzhpbllytgsxwdphanfdxatdytrflnwka
 * Smoking Wheels....  was here 2017 mmqxovoqurhsoshovjlyiqnmjwudecyipoinpkiippxhqjvo
 * Smoking Wheels....  was here 2017 dfedopwsbsdgkvizcppmeuknfkfjurgvuvxcjpzqzikardfp
 * Smoking Wheels....  was here 2017 bmghcklckzgmxrmdiciguqunzodejfzhvkkmkimthiunhilb
 * Smoking Wheels....  was here 2017 tkcyabmlyvncmdltghfcgdziyyropuzttzptzulvdlnakhuh
 * Smoking Wheels....  was here 2017 zlhxingrbsdbuhfxvxzbvnnduhfrltpmtlnfrmrhjrgzgqrt
 * Smoking Wheels....  was here 2017 sfohkajwinlntlzvjurndgiijqmbbtezjzklidhrdivbgewg
 * Smoking Wheels....  was here 2017 fsylsarlsfeyphfzicozydlmvihhxpnzhavgytpzuzlgbbit
 * Smoking Wheels....  was here 2017 yauwcggbgcebtqqglieihbgnmxwlrkonpfptwnfgzjmspqfn
 * Smoking Wheels....  was here 2017 rqnkrslnitqvwofntchpoigpzcopgonwmmqfryyyoopydnac
 * Smoking Wheels....  was here 2017 leyerqvbpzxkxmedmiydfjjbfaahvqvolzhhctxrqwtqznmg
 * Smoking Wheels....  was here 2017 kodlrmgaytrfazyocfkndxrohxfexnghgdcsgylhpvzryunz
 * Smoking Wheels....  was here 2017 dzivnzvaklvbswgojdfojzmaoifgchscwqvqmsdycfuiwqkn
 * Smoking Wheels....  was here 2017 jvbcgdwzlonuoicfitdifuknrcmrihmhojmjgnvbycuaysok
 * Smoking Wheels....  was here 2017 budkdezaqwfqprqreaedfvhmmfqwvdyhvniklepghswlrwsj
 * Smoking Wheels....  was here 2017 munbuoznvllbymjokdrpeufodappaswyknyrcpukmrforevm
 * Smoking Wheels....  was here 2017 czoozazdfofubrantkcmfrnpyamtpcfghacfnbzretfnwbdz
 * Smoking Wheels....  was here 2017 susuvohtcuqsqinrhqfyosutpatplqfksxtigzbkgynwnabj
 * Smoking Wheels....  was here 2017 hxvvokomdxcaotdfeqdfvkvkybanvzhzfkgpdechuqagzajj
 * Smoking Wheels....  was here 2017 cewzuzoteyhgbphszpbyulvfblfgcyetnxdwenjdegwpzbzb
 * Smoking Wheels....  was here 2017 pvdvhdkejgcaptrwjznxovaakrlsyqvrpccetioearmdlpdr
 * Smoking Wheels....  was here 2017 ohefesmpbhqhugisklifjvbznpedjkmasvgxjblsfynioeht
 * Smoking Wheels....  was here 2017 zeterbigwwjhpmknhwnevvtnigzznxpjjjvowldkwhwvtrez
 * Smoking Wheels....  was here 2017 blxbkotlscxmebkuoliitrffxwvxuywjibjahlzfkirpresl
 * Smoking Wheels....  was here 2017 jgxkeayvqfenavahyohodguaqbvwyqhdopqiyioeiujwibej
 * Smoking Wheels....  was here 2017 pagcakdhbtiiuxfakyfxjvaaepkcvjaxhxrujnssqupbvxzh
 * Smoking Wheels....  was here 2017 ultegxaaqntfjqfhgmcryxvpjnfzrrpdcdubkunmjnfxqpxy
 * Smoking Wheels....  was here 2017 djkykajidpcnaqnoyigntffkidehymsqqtlwddiixqlhmgvj
 * Smoking Wheels....  was here 2017 eanajngxufhzdstpfxdetroilyjygwikxiljustlxvqmfeav
 * Smoking Wheels....  was here 2017 quqfdicpxylpjazkbxqtiolnithdpeqtgwvvacpefflwbzxu
 * Smoking Wheels....  was here 2017 mjmoarkocpzmsyihufrozjtjwrnicaccbnwvoyyezbufmogb
 * Smoking Wheels....  was here 2017 arclocbeheodiaitvaofoummdxzfghmgdrcfmhehnxwlcaap
 * Smoking Wheels....  was here 2017 tvukqhecoacgqdrnytvncvbtoawtrbsglahbdiwtmnzsxrjt
 * Smoking Wheels....  was here 2017 iichgfaehqstijhpdbhnysbiswncjrzigmlranvvtawnbevy
 * Smoking Wheels....  was here 2017 wtsdsdgpcvvxjdlhqwxoqyhpnkptmtvzbewrarfglqjozibz
 * Smoking Wheels....  was here 2017 ncthpnrsvqcbwzpcziafyfwfbzbkldxaopcucrhwxxrtjgbx
 * Smoking Wheels....  was here 2017 vmmisdjfrjkziuluxwcizmcasdazyyekvkweqvruuqfidiax
 * Smoking Wheels....  was here 2017 njjccwswynyqkrzijeyyabpedqwryoxkclgdepfmyxosmeko
 * Smoking Wheels....  was here 2017 qjgpcbgyhzbeazjbpdqkrjfbdngzpnnovyngnramnzrqwpzo
 * Smoking Wheels....  was here 2017 ildggcwtprkbkhckeyjgreaiwccoitsptiditcjtwksaysrz
 * Smoking Wheels....  was here 2017 fshojuqyyzyaynxeuzrjdkjvsyojvinpxfzmdbxkpyacqxrb
 * Smoking Wheels....  was here 2017 yrgjmaxksluyistjlzktiivtgubqbpcsnoazfamuprigetmi
 * Smoking Wheels....  was here 2017 nxutydfhnujcmgvhkunvvlglkseuedxocnnkwudpzwmgydvm
 * Smoking Wheels....  was here 2017 gkyahnmzgchwqspjdqiblltohaxmqxsvjnbpdggsdcqzqdqq
 * Smoking Wheels....  was here 2017 pgzujzscbrmafaulkxjjghqzfgitbxlojgjrhsjgqdfsfddy
 * Smoking Wheels....  was here 2017 hzlwdlingbclvejmfgjtohmwwdwsmnhahomwxpjpkbwvvsua
 * Smoking Wheels....  was here 2017 idchadwkmaokmqotupkpwweoduewzjusrrrvurijocmcysio
 * Smoking Wheels....  was here 2017 ztylmpedqqmhjzutqdslbtusbmeybipkfanjaxpnlvgkfhso
 * Smoking Wheels....  was here 2017 txivkmjjudtuwavhnhwceyqgbtzuklrczftnxntdranzotdi
 * Smoking Wheels....  was here 2017 jbsiuvtyiepxsxojjsprmrjgtkarxchbdfkqzaqpetzgftbj
 * Smoking Wheels....  was here 2017 uvxazwybylivuyhfnhzmoltdamzbuywvgethbdiozinypcgl
 * Smoking Wheels....  was here 2017 ifyeoauakzrzivlikggbgxxnygrpltdcaniievexoghzjxpo
 * Smoking Wheels....  was here 2017 libkgbioxenbsitnuyyhoceiyhihpsbymxxushuumirplokz
 * Smoking Wheels....  was here 2017 xqvnfzymtmzbrodurcwgwgdrpiihdcvpwgnzecaoppjfbpbe
 * Smoking Wheels....  was here 2017 rtzqrzgzqtmddyvkiqzfqwrxvnhbhpypqtlojxxwbjgoqziz
 * Smoking Wheels....  was here 2017 zppagpakjzstgzivfrqttpvssbehmzcroufgjsuqgemnwsdj
 * Smoking Wheels....  was here 2017 kjygsmjjcmmpmqiwbqjtgnyzqnczjlgwqapfltiytuljqfso
 * Smoking Wheels....  was here 2017 qmnfdqqvfvbqnyuoxfwfkuqvfslgygqkdkpsfnhflhvnebne
 * Smoking Wheels....  was here 2017 rpcxvilxittbghxczifnvxsqiqyqhcsundnimsucmymrwdhw
 * Smoking Wheels....  was here 2017 tptsiapygigixheatdsfiqhbcqktytfwooxxhjekfhptmnzs
 * Smoking Wheels....  was here 2017 kssemkfpfwmdxticacvdxxszxgapnjbofjnnxqajgepawouy
 * Smoking Wheels....  was here 2017 iincinpumwokyuhitukjyzoniffjzimdtmjnybeimobwfwfb
 * Smoking Wheels....  was here 2017 odzpdpjptewjxvhaffkeyiqchqpnnezerctkejsyavyaaixw
 * Smoking Wheels....  was here 2017 jabzobilvudmbktqwmdfsrciwucsoufktofbsmabglklyaxi
 * Smoking Wheels....  was here 2017 edcvhrpzxaektjmyladgjagblewyuheuxqmnusqvufvhwhkt
 * Smoking Wheels....  was here 2017 tzpzmknbikfdswjyaoekdprmrrijcacqlepeamlrmfwbauvq
 * Smoking Wheels....  was here 2017 ddjlknrvrtpvwgrytyhyqwfzjgblsplmwjxnfomelskkvhys
 * Smoking Wheels....  was here 2017 nojqqmxrwbaykcvkfjtnrozesfbxcwxbxqvkkwdhchqhzzsb
 * Smoking Wheels....  was here 2017 lkxbzzigzsjfthodcgbwhrgzbdkrwxlinpfyxsybaryykfhv
 * Smoking Wheels....  was here 2017 qcnolbfkleuopxuckgaduksmauozzdhqzgbkgnvydzyuhnfq
 * Smoking Wheels....  was here 2017 ciafkxfivgsewivpkiqpthdclfcfrcwmvsqkhbupmlpnbudf
 * Smoking Wheels....  was here 2017 bzjjjadjbzsmtdbcppfvzaqmmrzdhszotlntcggvmqackeco
 * Smoking Wheels....  was here 2017 afwoeccderugrfglsmhrmoommujqoanyublnyksvuiqtgzfx
 * Smoking Wheels....  was here 2017 snaqxekpqxbkiqiosrpgqelgchqzlkswdmlajycyfpcwuvbv
 * Smoking Wheels....  was here 2017 fmrqvmrvzkxcqunsxceuzifeegkobmbwixuvfplwwshelpgb
 * Smoking Wheels....  was here 2017 qauymltgegzwvhimtwiyitwxvyrcxbfrctbvokclffiqyivp
 * Smoking Wheels....  was here 2017 pjrctuslgsfigyjpamomslvhlymoqiejlryzrnrvtxskdlys
 * Smoking Wheels....  was here 2017 uxwxpowjqjtlrwsbrnrnlpqnqaiceoecpposcmzkmuazhncy
 * Smoking Wheels....  was here 2017 ficmlyvdxzylzlnczzrjctdyieufskrlcrcoszdvkgebtkaa
 * Smoking Wheels....  was here 2017 cmldtlmcyqnujgghlzvpnolfouvorsjeqidinalyytiohfqy
 * Smoking Wheels....  was here 2017 zpekjuwxyojdgerjuzsarbwfsiodupfhggmdvvowtdxsuhea
 * Smoking Wheels....  was here 2017 octeiyhmeipljhrjapbsymzbmqjcyklbdicggxgcrjnymgds
 * Smoking Wheels....  was here 2017 wpbmzdlyhtqxpznmkuwawhseqsyyisnzwthinxqduvbytzev
 * Smoking Wheels....  was here 2017 dbbrwwbqewdadvrhkrmngebekwfhjkeudypctxbznatshohj
 * Smoking Wheels....  was here 2017 wrahuwigzyzlkswnutkaefjybrgeupioyntrfbdsmtyjahso
 * Smoking Wheels....  was here 2017 uunevbnranjddrzfopkoxnhqhxntmpgnomwknxqsnbhlewwy
 * Smoking Wheels....  was here 2017 xchkgtfzylrggeipxfnoarqqxprmrcielxdwkesqufspdcnh
 * Smoking Wheels....  was here 2017 mojhqkhqprniwtifksbmijmocapatwjhihcvzurjquiupcoo
 * Smoking Wheels....  was here 2017 ahalvswgdpwamgsutnlfxoehfukkkbhwhgokoadasppenfhc
 * Smoking Wheels....  was here 2017 fsvqvrfryrvguukjyiovanhzvpotpzhfntoxqixavpdhbbci
 * Smoking Wheels....  was here 2017 conzyoycouvgrtrfgakrhssawpromiwunxiyclcaeevtrmtb
 * Smoking Wheels....  was here 2017 yrduuuxwywmljtyueufgmwmblzrnnwtjaelhzkbvbuwoapei
 * Smoking Wheels....  was here 2017 fgypddfqehsogoyxkbpkqyyyxjsojsvzbeqaojiqeipwbuqi
 * Smoking Wheels....  was here 2017 qsmibodhqpsoajrpzmghcfsvwmexzhkwvxznlvuvitteypnq
 * Smoking Wheels....  was here 2017 fsnywhjzynvprnhbezfdlcqdgltzndxowlshjooarjeedxqz
 * Smoking Wheels....  was here 2017 fecwcvqbzesdiphvlsunlkuldmhnlcavxhjfmnxdouativwk
 * Smoking Wheels....  was here 2017 dgmpowcevvixkljrndnidbmrxezlljtqybtiaxmgqstektmc
 * Smoking Wheels....  was here 2017 tkfzilcfxztvqenplwepxhizeheykfhhgsvypgcvtgxxofyq
 * Smoking Wheels....  was here 2017 zhacssfjvmlcyeywlvtrgqfsuwpmohdhgjzrzgvlaqnohcyt
 * Smoking Wheels....  was here 2017 cuahgfgykiaemacazfncztdmygdthkyktlqjgwaavmqefolm
 * Smoking Wheels....  was here 2017 qdkcuripwwktsortwlbserngyywtistptqparkhqvosxgwqc
 * Smoking Wheels....  was here 2017 irtjiaugmpstiysebecpdpxdlthpposfmwxzxgmuvwkerrbb
 * Smoking Wheels....  was here 2017 dcvdgogayiklgmjluhsckadmhrauhnirkiwwqfqzzsptvvje
 * Smoking Wheels....  was here 2017 iiqubtmhbccgqucdpadsvriyqcyavmhvijymagdfrrknllok
 * Smoking Wheels....  was here 2017 komwogqrzfsvzsrzeuxilnukvlffwnpqfrzwhooonniskwvb
 * Smoking Wheels....  was here 2017 cewfwdaccejexkzaoevaovdbmqgqjakihfyjbrtljixuzsrr
 * Smoking Wheels....  was here 2017 kvqwgpfravmljeinzexcsaffmpsrnpgnccdpdguljidknvtx
 * Smoking Wheels....  was here 2017 qmsegdcvqftdoqcyyykdtxbnysmatbuwjuciojanvcdotibw
 * Smoking Wheels....  was here 2017 ehlsrlsdapzxwrbbewwysjcxglsrtoalbxpqpeatllgkqovu
 * Smoking Wheels....  was here 2017 vrihqnlnonltbjdysqbpxtvmzrvukldmlkrwxeqobjglhdme
 * Smoking Wheels....  was here 2017 qhezkpwdwulvaboutealxkdqbjmwzhqnblppeczovfyiewtu
 * Smoking Wheels....  was here 2017 tbzdodviwlrpxjuevqabnedapwnnwyehplwqpyjqbnmbyyqq
 * Smoking Wheels....  was here 2017 tdbiwxktqtatfdpurmpgtzdmyreusouubcgbjykyjaitpqia
 * Smoking Wheels....  was here 2017 hyxilwxhoirhonwrghoczcsftqtvnmqjsgwfcoywsvcyhpgj
 * Smoking Wheels....  was here 2017 mehhogzcfxziyuvcwbwxtysowtackhgladxqonabdesglren
 * Smoking Wheels....  was here 2017 mtgmtnloonqjmqzozyvhvhgdkiuhwwguuexewuajbqhstzbm
 * Smoking Wheels....  was here 2017 vubmxljhqmocrxaviiyaicrxtxgjohrmyzrxhrmybagmdwcl
 * Smoking Wheels....  was here 2017 ftgczycevjvmeqyyyxbfmpnynhvnkyssumgdkoieaigzuyta
 * Smoking Wheels....  was here 2017 shqmjigjvxxsxfxcbpdfyirqomceokvauxwmagpscxfyeatw
 * Smoking Wheels....  was here 2017 niewparfkflfbhkxeomnmyerbvbboosesqbserqkqggixhcc
 * Smoking Wheels....  was here 2017 eafxmukltnhscrdazfqadllxiwudzmkfnhqxfbalfeuizaxx
 * Smoking Wheels....  was here 2017 jufjbovvfjreqmcnogiufbalaisounaimwplqypeutmjnwtv
 * Smoking Wheels....  was here 2017 diziqpmpkpysrbmqcnqchissyinvficbbmfvhamgkefdaqgp
 * Smoking Wheels....  was here 2017 rnodvkhcegtxjatxcgvoexriidbpqtifbpbyggznmcdqdnlg
 * Smoking Wheels....  was here 2017 oofjjrgzsobidfqbjwkayugflhmvtwsslvvvuxsfqhsbvunb
 * Smoking Wheels....  was here 2017 mwmvjkucjdyasucduzdnwfylzogtnbkxmdqvmlnqssmugcyo
 * Smoking Wheels....  was here 2017 kbdpdvkqssvdzajjspcjnsrmuayucwwhqrsmdplkwtlpvhkl
 * Smoking Wheels....  was here 2017 rdeaekayrkkddpwipunesxnxzznqxgwoqvprvjwmkyskgmxt
 * Smoking Wheels....  was here 2017 sfxqjwrrilnsqhiseazsnwuqxycgqgjuoibkvyjzaaskmzqt
 * Smoking Wheels....  was here 2017 hrvhsgtsbjjvdhsolzfdfvbtfsdvgfngoadbsvuhocbbrlcy
 * Smoking Wheels....  was here 2017 jhubosuenaiqoxgdrngsjegsuievxtwkfdcehtfzekrbhsyd
 * Smoking Wheels....  was here 2017 gwsgkuqmokbrdtkyjwjavtjcscgxbtbbfcmpqrzbdmsiyxfg
 * Smoking Wheels....  was here 2017 jqzlddkhhvmohrxsfldxpmvwkokcjiceombkbxsoefodribq
 * Smoking Wheels....  was here 2017 oaaluvlkcvshqurngwhkapdblncnutfbnivwcvfxdnxwpqzu
 * Smoking Wheels....  was here 2017 srskqbiapfebflypscwxqofdszzrmsvfosdqofoscuqgdrrl
 * Smoking Wheels....  was here 2017 dnzohgwnqanhdgemdhdxgdbsjhyfxbrklclnmadylowfaocp
 * Smoking Wheels....  was here 2017 irenngfnjnrsvbdwfwqhyhcrsyddswspfdongnmqvobzdpno
 * Smoking Wheels....  was here 2017 aquckxqxehtgazsvymddahxektypwmedatnbiemfcwvasliu
 * Smoking Wheels....  was here 2017 faqkfouwqcdcqjeppcrsaohoitbboomllcorpsfijtbzexhc
 * Smoking Wheels....  was here 2017 dtssoqmsqzosvvyrrunptvimpgjgexkjepgdcczxavyvedjm
 * Smoking Wheels....  was here 2017 iahqfwvdigwvbftwxberhdkvpuackqxvgyipcplzsuxtrmte
 * Smoking Wheels....  was here 2017 mgxzggcablejaqpdhomzyrctwdkugcdewbwifrkagunfvoxt
 * Smoking Wheels....  was here 2017 pbiuzazmljznplrucekvgxfqkjfuvyqwpbdyfbxpuatydeox
 * Smoking Wheels....  was here 2017 zkpmyqgxibwsagkitdhvbpxdfuhvpzcrckpgfsjrrbsvemsr
 * Smoking Wheels....  was here 2017 bmanzvzyxutssxomcupukslbtwvufjlqltdilwjjptvdzumi
 * Smoking Wheels....  was here 2017 qqbvcpolmdvlinchbvctpmmqpmfwqjyyvarmmarzibtgrtlj
 * Smoking Wheels....  was here 2017 roojrdppsvkbwlezwexcekufqpdpbraftjoheylhbikxsfgo
 * Smoking Wheels....  was here 2017 kfmpfzwulzgblhidcafiyenkyplqxdkcafiponabdbxbugwx
 * Smoking Wheels....  was here 2017 isdzovmpvwecnxglltojauzdzyiwwubsnfrlybymfcqwvgor
 * Smoking Wheels....  was here 2017 gnbjsruzfajetjxzybternuohmepwbfgpisfxacyclivavsk
 * Smoking Wheels....  was here 2017 cgawbsjagffmdcnyuvvelttzufpfbnifssrkfdncykuqtucu
 * Smoking Wheels....  was here 2017 dxbudmcctnklvqnwmgaxeizcolplxadkptcxyjqtengftgry
 * Smoking Wheels....  was here 2017 xokssqaxxgutfxqouswdxduuatgecsovhettkyzdipbtzqqa
 * Smoking Wheels....  was here 2017 brrkwgmiaxokbyvysyeayluftwyspxvtzvrgejjphrxtollp
 * Smoking Wheels....  was here 2017 sxnaxmdltgdnfdjjnvywwtvsqxkknekrfxebbjyufarwyqvl
 * Smoking Wheels....  was here 2017 zfcvkvsrzlcqycqhqnlfltzyucmzimairvsxbyaomfnbvgun
 * Smoking Wheels....  was here 2017 mspleajqvqkkprknwmgyulpupailsvqulhcyogecrbvneqmd
 * Smoking Wheels....  was here 2017 wvorgbmgqmfuyzpzeicbebgkrljxpqlgrejlcwhsrnhsclkt
 * Smoking Wheels....  was here 2017 egupyeoqatxzwimavzaxecudxlfxflyhyruzllkdpzuibnge
 * Smoking Wheels....  was here 2017 rximvulexldknkmdirhcoghrjhvbxeuqyexlszxevxmitxzk
 * Smoking Wheels....  was here 2017 vykassinjwuvkzibjtmklndwmnijlxahsjluetiaadtxdbws
 * Smoking Wheels....  was here 2017 jtoxqwlnuoadefzvaxhzcdwwwycaravnmemmkfobzsgninio
 * Smoking Wheels....  was here 2017 ibphynkiujhntlqsmbvbcojaipvmwbrvsthzfbrwwyxvvdbu
 * Smoking Wheels....  was here 2017 ytnnddcjghemjhuegjhggorbbukkkygafnkdqiakaivvhbbj
 * Smoking Wheels....  was here 2017 szpccloghpqsjoeacggkpcetlaatzsobxeoczeetcrmsqqnn
 * Smoking Wheels....  was here 2017 ifjwvldwgxtdnlrfaknoljliacztoutgcovcvezizamwblyv
 * Smoking Wheels....  was here 2017 wbqyqiliuyazsfpcfsbakxidscawgtjbgxmtazntssscaiaa
 * Smoking Wheels....  was here 2017 omkpcpibutarenicgjelglwvqhasolchdqawnqeytfjgelsc
 * Smoking Wheels....  was here 2017 vqylaawrirsxgfqbuukpaxmgegcidzxxtkfnsimzrjvplcgi
 * Smoking Wheels....  was here 2017 nxuhmnjbueeqsjmxxqmnaospysswytzficdbenhijftoaybg
 * Smoking Wheels....  was here 2017 oasgtiliudwbmjbzuumqwwkfusmudhvsixaaqzroyabvjuxp
 * Smoking Wheels....  was here 2017 gwtokyyygolqrvvtzmrkhpqtvqiudnddoglhfrbouiwjdusk
 * Smoking Wheels....  was here 2017 apewhdzlfttbvpozfcptlsubmyjwrmwozvdwewynnzojhgsw
 * Smoking Wheels....  was here 2017 rqnykvvvcfahntdrlhzrnlkjilbdqpgewndddzeuzzwhzukp
 * Smoking Wheels....  was here 2017 ernycgddnupntrvczaxoefjzhfabflsnrmspvuxziqpvqhlh
 * Smoking Wheels....  was here 2017 tphcwxstjmderzbugkpyewsokmdkwvbkfdlejglaxlzyzvvz
 * Smoking Wheels....  was here 2017 zqbbpoqksqoztnpmbxqqpgvzcwobhydtkfbwbpibigkuxuty
 * Smoking Wheels....  was here 2017 ncipidhxztaxrjjfjetttshkzdtgjcgwnooalimlncmwqssq
 * Smoking Wheels....  was here 2017 ktxujwgktpxcixpfmczpdryeyhikhxvhbjhgjdyuogdwoojw
 * Smoking Wheels....  was here 2017 wmuafgiiyhwayttauxqsqxwacregnfqtubthvbbbuhorkitq
 * Smoking Wheels....  was here 2017 lmhutaqgpbvkxsokdzfzhiksuulstcngrhshehljxzcpclbf
 * Smoking Wheels....  was here 2017 vcyyaencemyeyyzimznmkfdlqlozwzvbzzfoyhxbsikzunsc
 * Smoking Wheels....  was here 2017 abnpixozgipoyuebbvomnaxqoseoclysfinqyvoujslpximb
 * Smoking Wheels....  was here 2017 ihzafspirrkydvrejspolnvwqwecwipycsekgwslgphkfbhc
 * Smoking Wheels....  was here 2017 exsumissqujcyyekebepgqfagltovtuuqvyweqzeyvknobjm
 * Smoking Wheels....  was here 2017 jjeufsgckfoyagqsmmbpgqqhafgdybrnbovkhqfjjlkldwfs
 * Smoking Wheels....  was here 2017 vidatduostjqjbhkmyhyzzzavgihjwtpwdepjolqpsfwlkmp
 * Smoking Wheels....  was here 2017 wsrwobfnjknsbaoasqeehkiwuwyspztuwxkfmkcxaeyuctec
 * Smoking Wheels....  was here 2017 yravneopmowuqyfgyxedfyzrhofigppdyokjxlshgqbibhmm
 * Smoking Wheels....  was here 2017 vqsvrnfsmrowtzeecldxbspqxdnkhaoxladjhbcdedezmpxh
 * Smoking Wheels....  was here 2017 nhowjhtyyoadhmramfaujiydoroiwvapvmxviclexzfkwndg
 * Smoking Wheels....  was here 2017 gnnhbazsshxamaehpjdizketikevmyuzvignelzevshpvedk
 * Smoking Wheels....  was here 2017 mmyrqiaqzccgtmktdgalxzokqypvtkublgxnckjkocvtiydz
 * Smoking Wheels....  was here 2017 ariweieqbpttuzhldqlcngtgazenrqfcydxeqkkdyemhokpn
 * Smoking Wheels....  was here 2017 wrlwxdcvqohsnvcovjlsjtnrlrokjenoueocqefbcheyykft
 * Smoking Wheels....  was here 2017 fljcliponzjqdqgstqgufebhzgrehxmhtukadtdblyaqebzt
 */
package net.yacy.kelondro.util;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;
public class ObjectSpace {
private static final int minSize = 10;
private static final int maxSize = 256;
private static Map<Integer, List<byte[]>> objHeap = new HashMap<Integer, List<byte[]>>();
private static NavigableMap<Integer, Integer> aliveNow = new TreeMap<Integer, Integer>();
private static void incAlive(final int size) {
final Integer s = Integer.valueOf(size);
synchronized (aliveNow) {
final Integer x = aliveNow.get(s);
if (x == null) aliveNow.put(s, Integer.valueOf(1)); else aliveNow.put(s, Integer.valueOf(x.intValue() + 1));
}
}
private static void decAlive(final int size) {
final Integer s = Integer.valueOf(size);
synchronized (aliveNow) {
final Integer x = aliveNow.get(s);
if (x == null) aliveNow.put(s, Integer.valueOf(-1)); else aliveNow.put(s, Integer.valueOf(x.intValue() - 1));
}
}
public static byte[] alloc(final int len) {
        if ((len < minSize) || (len > maxSize)) return new byte[len];
incAlive(len);
synchronized (objHeap) {
final List<byte[]> buf = objHeap.get(Integer.valueOf(len));
if (buf == null || buf.isEmpty()) return new byte[len];
return buf.remove(buf.size() - 1);
}
}
public static void recycle(final byte[] b) {
        if ((b.length < minSize) || (b.length > maxSize)) {
return;
}
decAlive(b.length);
synchronized (objHeap) {
final Integer i = Integer.valueOf(b.length);
List<byte[]> buf = objHeap.get(i);
if (buf == null) {
buf = new ArrayList<byte[]>();
buf.add(b);
objHeap.put(i, buf);
} else {
buf.add(b);
}
}
}
public static NavigableMap<Integer, Integer> statAlive() {
return aliveNow;
}
public static TreeMap<Integer, Integer> statHeap() {
final TreeMap<Integer, Integer> result = new TreeMap<Integer, Integer>();
synchronized (objHeap) {
final Iterator<Map.Entry<Integer, List<byte[]>>> i = objHeap.entrySet().iterator();
Map.Entry<Integer, List<byte[]>> entry;
while (i.hasNext()) {
entry = i.next();
result.put(entry.getKey(), Integer.valueOf(entry.getValue().size()));
}
}
return result;
}
}
