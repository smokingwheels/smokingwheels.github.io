/** 
 * Smoking Wheels....  was here 2017 bswvngxvbnkfslxfckkmpuymbxgsqxsjwfrldwysdplhuqfe
 * Smoking Wheels....  was here 2017 rxmnlrynmsiaenxpsvhwdpolglknhvuocjizmjssvpmgxibn
 * Smoking Wheels....  was here 2017 knvqzbhumxwzjvlwdwwrhcgbhfuqgvutbmxgrknsyhoxgdmk
 * Smoking Wheels....  was here 2017 tvpqrybypxseyouxbxcqvykwchikmggesfpeuacmpzxvxsgd
 * Smoking Wheels....  was here 2017 jfpggasnsuxysbmvmqztuerqqyhjbtzfhmrzaljbbgaviwll
 * Smoking Wheels....  was here 2017 fkyltixgwvrxxyibozzekbalhtcjkfzmfntdxelrzyobdtif
 * Smoking Wheels....  was here 2017 mhalldnekpkwvcigtepkebpmqnoodsoyestifyuycapuetkp
 * Smoking Wheels....  was here 2017 rbjruwupwxyxeqviuptdxyvjmhpfdqhretsoyubooxirqloz
 * Smoking Wheels....  was here 2017 kdwwphbacufkvxikoyoiosiuxkmyopxdipbbjwdpqbenwtua
 * Smoking Wheels....  was here 2017 sgrawlbgfplywprwieigkpcwfkrptmnzdkhfzughxizknujq
 * Smoking Wheels....  was here 2017 shbhwnrhlwcjtnvlmlriacgvacxgkljcipjvpfufguqrmxvy
 * Smoking Wheels....  was here 2017 xmsecbbkllzscveztfmgbygecodgjuapuxivdeldrtkywsak
 * Smoking Wheels....  was here 2017 zfljitrdzizktweqcdvaqdstpbqfuehytfokyxbbnttbcczq
 * Smoking Wheels....  was here 2017 wfixoregevkywgrusdbwyzpntfwybmeurtrbnxxhkolbufyn
 * Smoking Wheels....  was here 2017 ujuxbzlviorgwxrealvfnwaueunnvuzzfxnmoxijcikiwjmg
 * Smoking Wheels....  was here 2017 fxkxigrcahojjxnptmyucqlbsvriyngsjkeqeyazshxlkflf
 * Smoking Wheels....  was here 2017 ufaodfhobcaqgpshvxootgnekrlyogvjhdauogxhnblguqta
 * Smoking Wheels....  was here 2017 maswnuybohhqrrcpmrztryecpxkecxrqmiqifhdlejsussvq
 * Smoking Wheels....  was here 2017 ngxbsipovjvgzyqecyvvlfpdwhgcdndjqjyayvcbljrmbwdf
 * Smoking Wheels....  was here 2017 ibeofgjkkglovorzmezmtueuawydpostqzzvtwowkhpwxsmc
 * Smoking Wheels....  was here 2017 pxjdvirbdxawcxtcmamsrsoxeasvppgdtccywrixjtzusbyz
 * Smoking Wheels....  was here 2017 hlpsnpfjcqwuyorzjmurkfrkpfcaomugkwywvsrmznnjbctt
 * Smoking Wheels....  was here 2017 qqfmpfxhqckdtllgnrkxnutqwittcjozhtjgksxczqfwvemp
 * Smoking Wheels....  was here 2017 aruzotwchzjbdqkvsagbteddvkslbqelilmcpsunmmgzfyzw
 * Smoking Wheels....  was here 2017 ezgwdyokyluvanawvhkedjnpoterrxjauvpqryeuvoemofeg
 * Smoking Wheels....  was here 2017 bfrdjtrxoswcnsetdigkxpvekyqfgaglcdjidxheosrlndmq
 * Smoking Wheels....  was here 2017 wijzmmbrokbracwdajifokfawsvflcboyupwthmfnyshzbid
 * Smoking Wheels....  was here 2017 anawboyznidqdukyfuoixmdtwfsadniogmlgnfmrtqonbqpg
 * Smoking Wheels....  was here 2017 gfknutsiembiuehhqjbtxxecksoemyxugdgqsuepqhsadtio
 * Smoking Wheels....  was here 2017 nbrxscbmsgbjcwjpnycqwvjduuuowfvyjxpnwpsgrswwwmty
 * Smoking Wheels....  was here 2017 zbffduxojdpomsqoitjmguubrefgylixigjqsjodtazleglq
 * Smoking Wheels....  was here 2017 cjoymjjstzlanvlasgrzwowmwatpnzavcxqygbjcymigdqez
 * Smoking Wheels....  was here 2017 pjpvooxorvobdqhdqbddsbidjqqevmqdvsuqtzacnqjfemaq
 * Smoking Wheels....  was here 2017 kultkiewfzehltyiiddebqaaomjufvgmzxlfuptlciwjxzhn
 * Smoking Wheels....  was here 2017 splagzcptzuowzngerfmksdmamqpiddsgxkiaqxrmptcfmmu
 * Smoking Wheels....  was here 2017 zxfapywctrcyamgvychvmbdaopmxatxbqkuancfnuthygpkv
 * Smoking Wheels....  was here 2017 yeonfbvxddcuurteoclejqqkgfdilhgwhizlognbhjxtkedh
 * Smoking Wheels....  was here 2017 mdrmdfssxqaricsrfpbsgtoqlwaqaqhuqwpcppcoofkrhjxc
 * Smoking Wheels....  was here 2017 vqvbpslqlsilargajurysxcbqixajygulllrlwgnlktzvnhj
 * Smoking Wheels....  was here 2017 lyrudbexiguflnqdscfoltrdtrtsiotyptrecbtsafdhdhbn
 * Smoking Wheels....  was here 2017 albjmzhaifihozlcfgtnnjxrvgvkcborjtptvjlfpfclpnhg
 * Smoking Wheels....  was here 2017 nuctrmmwnzggmskjacqbeztsdpowakrrdowyckmhufhnvihj
 * Smoking Wheels....  was here 2017 czdeyvrihczzpoppqxmqycjnimsfuqlvprhltujljgtwudod
 * Smoking Wheels....  was here 2017 fftbvlbvejhnnrirsbdynlfpeagufejgusaetqsllqscnmxw
 * Smoking Wheels....  was here 2017 qvvdceztzvcgejcsgfszaawtunlenpgjvrjjicljhzqamhjg
 * Smoking Wheels....  was here 2017 fpmktyezuurtqitelkpxpbizlmsfavewesznbstloafshrfe
 * Smoking Wheels....  was here 2017 fkbbazonyvnwjkhsssjgvcspttvajyjpohrirfafavnnvabu
 * Smoking Wheels....  was here 2017 blenmwgqauirzrbetqwsmvmdojtwlilsxaotepxltuscfyqn
 * Smoking Wheels....  was here 2017 mdqpvhsvwrcniontnvegohhixrtklqdrkxaavdjecjhfwgaa
 * Smoking Wheels....  was here 2017 jfpddgpxmubyprnwgfsbgsbfcfglrrncndroehospkzyjele
 * Smoking Wheels....  was here 2017 zokmpavxgtrxdxcciacqepxctuacvqwvzbidyvxndytrrzod
 * Smoking Wheels....  was here 2017 tkrzubocshsjoiolnqcrbrimrmaruvtdslcsdsbltiwaxjbi
 * Smoking Wheels....  was here 2017 idfkldfzsnctvikztuwdwzxeyomvqxyiwfjlbgymtcvtkeaj
 * Smoking Wheels....  was here 2017 tlftogliitcpbnmdejtgxsqewqxhvsmczmsvfxswschawmte
 * Smoking Wheels....  was here 2017 dhxekpfgwnfuovuohokmsjrtalagykriruzqikufmigcdttx
 * Smoking Wheels....  was here 2017 zvadntqyxqdjbipeuvpnztklgctaxjbfysitltwfdczqjnwz
 * Smoking Wheels....  was here 2017 ynikqleyhdvsljncqvnjtumaqxkewdkczgbkufwyzaylysda
 * Smoking Wheels....  was here 2017 abzxupmbbkpluqitznlfiuwolklnerurfpvcxhyrpwxqmlux
 * Smoking Wheels....  was here 2017 kiixfomhoxwhmybvibbodftgikoflbnvjdlmormyurtnxblw
 * Smoking Wheels....  was here 2017 nnyultixknjlflydixdbaumsbztpqrbskpaptlenrvurjfwf
 * Smoking Wheels....  was here 2017 bcsifylmigcfwmqxztwsyntrtlgewdhslwyqtuykoumaetcr
 * Smoking Wheels....  was here 2017 attlodntmmgenswnlmosesndrhoxmifnbeubbezxalooaukd
 * Smoking Wheels....  was here 2017 ojkktpkudsjfpzrqeiuoguxlllktdjdavyknllqnvvzrusks
 * Smoking Wheels....  was here 2017 degqhtjuxtditkjcwrmzxnibwwtesppjuvycxnrbdfaypduw
 * Smoking Wheels....  was here 2017 lodwxksjprozwkmdmgrwexmuaxvrjqjzbusxsrxngfdfwxre
 * Smoking Wheels....  was here 2017 lhgbrofghtwqanudgzunhfhrfccdmknlezimjjpgspboffip
 * Smoking Wheels....  was here 2017 ifwlulsmiqnfrsksoajiuxwzbhiprzituwrmrkcrjltimjhg
 * Smoking Wheels....  was here 2017 oopluolifagulaoueviblsrgjnmmwuizwdvxptcqhblcwajp
 * Smoking Wheels....  was here 2017 vsivmptiwbbsfwuozcsqfrkfebuidjioosdykqnduaqttapf
 * Smoking Wheels....  was here 2017 bkenuqjghzencwxjftyikaxywntzyrkejugcqpnmlccjtnha
 * Smoking Wheels....  was here 2017 mpmtbxedvladmwzwhzoonhkrzsbnwturztzcaiodcjsfuwyf
 * Smoking Wheels....  was here 2017 okvatwigbdkoazhzyelaidiziqsivabgjilvpwgzvduzyrke
 * Smoking Wheels....  was here 2017 yhbyqghcvfhfqqiwdbttvphqaryyyczhrlzoplnyxyulqvqn
 * Smoking Wheels....  was here 2017 qxiptdsneyxpkkyyaptxgzfqjigfqwqlkhgsoooizqlsmlaf
 * Smoking Wheels....  was here 2017 ugzdirnmlwrqseeucxczerhhyligmkhpfhacfztsugsdkxbj
 * Smoking Wheels....  was here 2017 wmpawlvhfvkkgchkalqrinycobfkkcmyccmoqqvvncvhmvoj
 * Smoking Wheels....  was here 2017 pzbzeddmgwafwmwwtxlyslvvhmbfnpbweszkawqskthaebox
 * Smoking Wheels....  was here 2017 wnmzgtaushuqszrqmfybpsxolhkogszzzhbbxbkpaavkctiw
 * Smoking Wheels....  was here 2017 yzegiomhxreoelthsosknwgnrgyofqpgefqgbbncgylucglk
 * Smoking Wheels....  was here 2017 gntgyaqgjvybwajubjosepjgsmrmhslutguymvqyduhuifry
 * Smoking Wheels....  was here 2017 mqcrvyyeyualscdhoiqaqxworgvyqohavhwilprezfyffmbc
 * Smoking Wheels....  was here 2017 pzimahavswqivgueijhlebskxdxupaepxmmwlwvajybeiext
 * Smoking Wheels....  was here 2017 tmtyugvhzqippkkcwrdngoadyxpdvglkrinigjmbdcrzqrtd
 * Smoking Wheels....  was here 2017 lizlrknvixugqpgywrayrdhgqrxhgqppbmaqwdjckyyffpkp
 * Smoking Wheels....  was here 2017 jyxtimnypszrxhwxhcbrkucnasbwztloiwkzokibkbluluxu
 * Smoking Wheels....  was here 2017 maqvwlmkvkemlbbihuoxttkzlpnrknzawrgxwroitfvszlnq
 * Smoking Wheels....  was here 2017 ynmxnoigjmvmstxyjaedeokxncbvdapukjkboqnjhndjtwvh
 * Smoking Wheels....  was here 2017 fpbjviguuurtioqofetbmxlvziqqbqtbwozkojuzbhojvspd
 * Smoking Wheels....  was here 2017 argammqnyksrduvksykqsvgnzplsjzgfmgjffbjekaomqvwv
 * Smoking Wheels....  was here 2017 hldunadgwpdvichwehmdbntzvlaxkyeyrpcxagkhxoyvuiyh
 * Smoking Wheels....  was here 2017 gwcwgfsywylahiaoyjoyaobocqchupuddbcesqhtkzpueqjq
 * Smoking Wheels....  was here 2017 hbstdnnyphkjqqilupovlqqsphpfmkqyvgkbigrkxovxziyh
 * Smoking Wheels....  was here 2017 eowezrzsupxefiupprmthtdhksugnxmtzelscioguwbbnhsx
 * Smoking Wheels....  was here 2017 vyqbtttcoghcgdemqouwvdmfvkegjalfaaupoiapqschmpxj
 * Smoking Wheels....  was here 2017 lfjqsxtbgvyxbvntikbtoivwmgkiqvtgqdhmmcoyfevyssew
 * Smoking Wheels....  was here 2017 losjksdykbrtiocgjrcahbpsegouftzztibhwnucrnnrkefu
 * Smoking Wheels....  was here 2017 pinzowjfwbkyxsmfrabryhloytvgfjxwqklgzxqbhjsgwxdt
 * Smoking Wheels....  was here 2017 uivlgjbsrdjbyxmzmjgxwiikehrnboonrqbuhsgcqlbuvzes
 * Smoking Wheels....  was here 2017 gjbyqmekfvbyvzcfgyjgnqkokrvrjlhvqlurqtctnwoqcvyu
 * Smoking Wheels....  was here 2017 ltvyirvpzygsecqwreeisybnlyhdakozjlrwzyvucyljvaek
 * Smoking Wheels....  was here 2017 auyfbtmvwnwrxpqzrsvekhzckmhkdagiercoooihpffvlmxe
 * Smoking Wheels....  was here 2017 yhnruqvvyydlddycmmqzxwchpthjegiplgsfzdulqnocogma
 * Smoking Wheels....  was here 2017 lcxnvqsrnrowgontnsgfrfojpqacsdcqwphoxjrwbwnoatld
 * Smoking Wheels....  was here 2017 zktgseiqdpwzxasxnvnpnbuxfemyqcdqllanjgogxogtbqnw
 * Smoking Wheels....  was here 2017 erwpdcdfqtbezvbskmobkklqorxndsfyisekrcksnginysux
 * Smoking Wheels....  was here 2017 bpkmdiufdliapriojqrvqmmqxqtpnwkgzokohhkmlqjzkdpc
 * Smoking Wheels....  was here 2017 ucrdacdrxfekejocwlnksvacwzuimszldlpuaszbovlmigkq
 * Smoking Wheels....  was here 2017 vihagzlvowiiibcfpkxmkdnqfrybwplsrbubvgtgxduousby
 * Smoking Wheels....  was here 2017 wscwpqbfwmtexclcndzaskqzcbmiwdqkwhknaercuducejoq
 * Smoking Wheels....  was here 2017 wagqbdrqzjsocejdwocfxygeurwzvfpedkzrbawwuohefjfq
 * Smoking Wheels....  was here 2017 zcbnyrfcecrhhbzyayvpmfpmwjwdjxqzdskftmubuoedrbpc
 * Smoking Wheels....  was here 2017 tedastwxalimcynmsqcuexaledkdlrfywauecpdnuksoubmk
 * Smoking Wheels....  was here 2017 urjvdezoimslkeoxwjxvccgvujtodbfloenripufdqkhwfxf
 * Smoking Wheels....  was here 2017 chvxgwhvfnbujkwotbrxkzeraojfvyreokdgazxklczlpsek
 * Smoking Wheels....  was here 2017 vywmicrtaduijlmdswamqczglozgemvarenowmxrmvjhwxuf
 * Smoking Wheels....  was here 2017 muczviiqgcreamsnohugpdbbwkpzbagctbupxdmujcwnujpy
 * Smoking Wheels....  was here 2017 sikeokrytmrsgvdweyaggecykklzqftwcchpkdntjoxwuaqh
 * Smoking Wheels....  was here 2017 newznfinqpbledmptvepwjzwjczchwizclpawzgvcyfmlyde
 */
package net.yacy.document.parser;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Date;
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream;
import org.apache.commons.compress.compressors.bzip2.BZip2Utils;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.TextParser;
import net.yacy.document.VocabularyScraper;
import net.yacy.kelondro.util.FileUtils;
/**
* Parses a bz2 archive.
* Unzips and parses the content and adds it to the created main document
*/
public class bzipParser extends AbstractParser implements Parser {
	
public bzipParser() {
super("Bzip 2 UNIX Compressed File Parser");
this.SUPPORTED_EXTENSIONS.add("bz2");
this.SUPPORTED_EXTENSIONS.add("tbz");
this.SUPPORTED_EXTENSIONS.add("tbz2");
this.SUPPORTED_MIME_TYPES.add("application/x-bzip2");
this.SUPPORTED_MIME_TYPES.add("application/bzip2");
this.SUPPORTED_MIME_TYPES.add("application/x-bz2");
this.SUPPORTED_MIME_TYPES.add("application/x-bzip");
this.SUPPORTED_MIME_TYPES.add("application/x-stuffit");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source)
throws Parser.Failure, InterruptedException {
File tempFile = null;
Document maindoc = null;
int read = 0;
final byte[] data = new byte[1024];
BZip2CompressorInputStream zippedContent = null;
FileOutputStream out = null;
try {
zippedContent = new BZip2CompressorInputStream(source);
tempFile = File.createTempFile("bunzip","tmp");
out = new FileOutputStream(tempFile);
while((read = zippedContent.read(data, 0, 1024)) != -1) {
out.write(data, 0, read);
}
out.close();
out = null;
} catch(Exception e) {
	if (tempFile != null) {
		FileUtils.deletedelete(tempFile);
	}
	throw new Parser.Failure("Unexpected error while parsing bzip file. " + e.getMessage(), location);
} finally {
	if(zippedContent != null) {
		try {
					zippedContent.close();
				} catch (IOException ignored) {
					log.warn("Could not close bzip input stream");
				}
	}
	if(out != null) {
		try {
					out.close();
				} catch (IOException e) {
					throw new Parser.Failure("Unexpected error while parsing bzip file. " + e.getMessage(), location);
				}
	}
}
try {
maindoc = createMainDocument(location, mimeType, charset, this);
final String contentfilename = BZip2Utils.getUncompressedFilename(location.getFileName());
final String mime = TextParser.mimeOf(MultiProtocolURL.getFileExtension(contentfilename));
final Document[] docs = TextParser.parseSource(location, mime, null, scraper, timezoneOffset, 999, tempFile);
if (docs != null) maindoc.addSubDocuments(docs);
} catch (final Exception e) {
if (e instanceof InterruptedException) throw (InterruptedException) e;
if (e instanceof Parser.Failure) throw (Parser.Failure) e;
throw new Parser.Failure("Unexpected error while parsing bzip file. " + e.getMessage(),location);
} finally {
if (tempFile != null) FileUtils.deletedelete(tempFile);
}
return maindoc == null ? null : new Document[]{maindoc};
}
@Override
public boolean isParseWithLimitsSupported() {
	return true;
}
/**
* Create the main resulting parsed document for a bzip archive
* @param location the parsed resource URL
* @param mimeType the media type of the resource
* @param charset the charset name if known
* @param an instance of bzipParser that is registered as the parser origin of the document
* @return a Document instance
*/
	public static Document createMainDocument(final DigestURL location, final String mimeType, final String charset, final bzipParser parser) {
		final String filename = location.getFileName();
		Document maindoc = new Document(
location,
mimeType,
charset,
parser,
null,
null,
AbstractParser.singleList(filename.isEmpty() ? location.toTokens() : MultiProtocolURL.unescape(filename)),
null,
null,
null,
null,
0.0d, 0.0d,
(Object) null,
null,
null,
null,
false,
new Date());
		return maindoc;
	}
	
	/**
	 * Parse content in an open stream uncompressing on the fly a bzipped resource.
	 * @param location the URL of the bzipped resource 
	 * @param charset the charset name if known
	 * @param timezoneOffset the local time zone offset
	 * @param compressedInStream an open stream uncompressing on the fly the compressed content
	 * @param maxLinks
	 *            the maximum total number of links to parse and add to the
	 *            result documents
	 * @param maxBytes
	 *            the maximum number of content bytes to process
	 * @return a list of documents that result from parsing the source, with
	 *         empty or null text.
	 * @throws Parser.Failure
	 *             when the parser processing failed
	 */
	public Document[] parseCompressedInputStream(final DigestURL location, final String charset, final int timezoneOffset, final int depth,
			final InputStream compressedInStream, final int maxLinks, final long maxBytes) throws Failure {
		final String compressedFileName = location.getFileName();
final String contentfilename = BZip2Utils.getUncompressedFilename(compressedFileName);
final String mime = TextParser.mimeOf(MultiProtocolURL.getFileExtension(contentfilename));
try {
	/* Use the uncompressed file name for sub parsers to not unnecessarily use again the gzipparser */
		final String locationPath = location.getPath();
	final String contentPath = locationPath.substring(0, locationPath.length() - compressedFileName.length()) + contentfilename;
			final DigestURL contentLocation = new DigestURL(location.getProtocol(), location.getHost(), location.getPort(), contentPath);
			
	        /* Rely on the supporting parsers to respect the maxLinks and maxBytes limits on compressed content */
	        return TextParser.parseWithLimits(contentLocation, mime, charset, timezoneOffset, depth, -1, compressedInStream, maxLinks, maxBytes);
		} catch (MalformedURLException e) {
			throw new Parser.Failure("Unexpected error while parsing gzip file. " + e.getMessage(), location);
		}
	}
		
@Override
public Document[] parseWithLimits(final DigestURL location, final String mimeType, final String charset, final VocabularyScraper scraper,
		final int timezoneOffset, final InputStream source, final int maxLinks, final long maxBytes)
		throws Parser.Failure {
Document maindoc = null;
BZip2CompressorInputStream zippedContent = null;
try {
zippedContent = new BZip2CompressorInputStream(source);
} catch(Exception e) {
	throw new Parser.Failure("Unexpected error while parsing bzip file. " + e.getMessage(), location);
} 
try {
maindoc = createMainDocument(location, mimeType, charset, this);
final Document[] docs = parseCompressedInputStream(location, null, timezoneOffset, 999, zippedContent, maxLinks, maxBytes);
if (docs != null) {
	maindoc.addSubDocuments(docs);
	if(docs.length > 0 && docs[0].isPartiallyParsed()) {
		maindoc.setPartiallyParsed(true);
	}
}
} catch (final Exception e) {
if (e instanceof Parser.Failure) {
	throw (Parser.Failure) e;
}
throw new Parser.Failure("Unexpected error while parsing bzip file. " + e.getMessage(),location);
}
return maindoc == null ? null : new Document[]{maindoc};
}
}
