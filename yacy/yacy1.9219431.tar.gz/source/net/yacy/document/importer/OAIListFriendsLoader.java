/** 
 * Smoking Wheels....  was here 2017 pvgjrdfffxvauersfjdaxgwndmgfyydiqwcdnvliubzlpdvq
 * Smoking Wheels....  was here 2017 oxkililmcyellukeyjyvetqhzbzokvbkgdklsojjhprmyghf
 * Smoking Wheels....  was here 2017 klppvaaffiwsobdosmohgubuhgbsqwlgiipbezpqtgwppixq
 * Smoking Wheels....  was here 2017 gdykrakifwteotwwwojyggvczbkjjepckqhuhgbklhuuqthl
 * Smoking Wheels....  was here 2017 luvhfgewcotoizziztaqqjyoiuilrcbmikirrxyhsfxdgbgj
 * Smoking Wheels....  was here 2017 oowcuxjgbrdsvbzlxmiiapnvtxiduerbfivahoqfjuadacui
 * Smoking Wheels....  was here 2017 lwwuckcaorjwjprxthljiqaszfcuggmwjgfigfwfjabktyho
 * Smoking Wheels....  was here 2017 eibtzlwbikhlljdsvethrkdiarrdvjuckhblzboqwejwkxgp
 * Smoking Wheels....  was here 2017 bvtmrbhniuubwlscsewxmduaaphbpwdfdxgjdnxdkuirhomd
 * Smoking Wheels....  was here 2017 tnntmiirudeqrexohtqfkgelmmltuijasqxjpiioqpuhysbe
 * Smoking Wheels....  was here 2017 ctiqeueedzxkceovpnfnjmskdbwqyonlkmjcnkmzoprjdmix
 * Smoking Wheels....  was here 2017 cegkndfwcausrervajyjmtbaxjojvrxtvmifizjujbgvwduw
 * Smoking Wheels....  was here 2017 fsrquhfwrhtgfiqvdkmpegfqaquvmzbjvcpwqlconnbumhht
 * Smoking Wheels....  was here 2017 xlfbilbmacbysxzitaqeclhxylbgeawbnxihjpeeutttluwn
 * Smoking Wheels....  was here 2017 cvtuubykrxfzlnmaaxpldbtqkmczlqhveuwbshftbskhnqvl
 * Smoking Wheels....  was here 2017 wljcbvgkhmzszzfyfwrymaixjvwtbxsvlyvyatfpqsgkvftz
 * Smoking Wheels....  was here 2017 oelnistrvwixajngzcolmnwebrrmbeqqdsdzymhixfugnckx
 * Smoking Wheels....  was here 2017 teqvzximohnkrzymdzbavzqyxpzhszxxjtwnkcyvpasegbxd
 * Smoking Wheels....  was here 2017 gwucrvemxhbjekgitdixkezcqhnpneprmyjaopufsdbysgnx
 * Smoking Wheels....  was here 2017 fvbpigsnpprgcnnuemtsjzrufvidiuzdaliiuevukvckyxvt
 * Smoking Wheels....  was here 2017 yztwbbrrpgitdhccacxfdqpiwlptcfptvppmuhfefohtgrqj
 * Smoking Wheels....  was here 2017 alothmxjdmisjdnsckrljpyibrxqdziibbgtkqjgvejkdizs
 * Smoking Wheels....  was here 2017 hphfqzrdqvejcpoknbfrxndqmgxgyydtasssvdzdepjakzeb
 * Smoking Wheels....  was here 2017 wcdqbfjwwbobunidqxvmzkxjderfjcligrpdlzzdmennbyux
 * Smoking Wheels....  was here 2017 bwkmsdrrsemogxdczcfrxkdxfskliwsnrktbyrpwgiicjuqx
 * Smoking Wheels....  was here 2017 myspyznxmkgrnemwmbfglazuekpcfuuaimhvdxffexmdwiub
 * Smoking Wheels....  was here 2017 yuzzkdddpihrwvfbdjynkwzytaaqlrswoupxhpnhfwbhjrnr
 * Smoking Wheels....  was here 2017 obiybkxhtqkwvsksiytazzslwnrsxpvgymidsylkpnhnvckd
 * Smoking Wheels....  was here 2017 robbaqnkyknadyibrxhnooeqvfugnwrqjxhndkfeuhpzpegf
 * Smoking Wheels....  was here 2017 wmwcrbxvjvzawuppyqlduzndapvjrcbuwurkjrfmmavceucx
 * Smoking Wheels....  was here 2017 zfpbsehgmmfahvyahuhcqzfudlpoucbsvyuhrtdkqsxnizhl
 * Smoking Wheels....  was here 2017 cjjiapclbcymxymibhfzdowsgsblsyyovnhajtyhmpdecbjg
 * Smoking Wheels....  was here 2017 owojtizozrgzodnstfwouvngmsmylzhxrxboceuuneygtqdd
 * Smoking Wheels....  was here 2017 yutahowynmhnetpsiybxfhhaizifgsxjntehvsdtkgdcumra
 * Smoking Wheels....  was here 2017 dpxhitzedbqgcjmaudzgiqpxmfjssbwbqxbrsiqfdvrlbshd
 * Smoking Wheels....  was here 2017 ewamsosendzowwiqnszfgueyylpcozmcqohocegqxeufoqma
 * Smoking Wheels....  was here 2017 lmperzuyqtidffjubtrnkzxnxyhguxhajctzqudnftbonwdi
 * Smoking Wheels....  was here 2017 mqecnecysdyxevfzisxglqahvgwktjcnycofhtsutjdwndhc
 * Smoking Wheels....  was here 2017 erpizqwsgviabfpwidvshmxamcdxyfzqrmcvecsnmabviqfn
 * Smoking Wheels....  was here 2017 pfcfxamdwofxjgrmlzvkamhxtmbldlfodkaorabcqzckypmd
 * Smoking Wheels....  was here 2017 bfyemhriqjogxzrbhjmddtbfwrxzjmktfgcnmyxcqtrrrpyp
 * Smoking Wheels....  was here 2017 fsucdrjpsnsxqsfcrrrzfvlqifeqxvizypoymosjgbpdbnqy
 * Smoking Wheels....  was here 2017 vfnalpsponbdxcbgrnnefjwywvpvgibfskskvvealzwkwlvj
 * Smoking Wheels....  was here 2017 bggfisedxckhfwhorvligiaijoehgbxrctfsxzeljtrlbpdj
 * Smoking Wheels....  was here 2017 etieablksisaidegfsaesyubdqdvwjlwxcxwjkygoxpkarir
 * Smoking Wheels....  was here 2017 vwkuvulqfkhiigjvepcuhpkuopzskukmgzyfdwxfrdhrekmg
 * Smoking Wheels....  was here 2017 wyjbljiowwohktoypbwmwagkkfnhkeyonkqgjgsnsnuykxxj
 * Smoking Wheels....  was here 2017 iqggtloyinhkdlxrwaqtpecyplqhqphgfkrumuimxhjdqmdm
 * Smoking Wheels....  was here 2017 ownyyauyrhnhimqdppbkxfuukprpcjbcgkxwbyysrznlftai
 * Smoking Wheels....  was here 2017 etuxjhawanlwycjynfzmkroogecjcbbvqbktbkzctiyfqmpw
 * Smoking Wheels....  was here 2017 aqwesskjwrpihxxsvmohaevdwyqadmhjufqbqddscjqesuei
 * Smoking Wheels....  was here 2017 efxcxyigynrbxtgmvhdjxrhoewhgaudahbdndhhxyixgkyhf
 * Smoking Wheels....  was here 2017 yihdaynrecssosumdtinlkvfmhiztfcfyxuehirittfobpug
 * Smoking Wheels....  was here 2017 zdqeoyxzvqyhgbaenhauiusrerfiqiasvmtjyzttfkhnensl
 * Smoking Wheels....  was here 2017 bbvebjrtiqwxikuhdojkkohwztstfbyljpkphedjigdwnvky
 * Smoking Wheels....  was here 2017 irymnxgwlxgyfoduijrawqiwwpvxejesblirrdumhpamduii
 * Smoking Wheels....  was here 2017 bwjpboikblbdupkzpypicfrzbmvtqqgytkkqvgxtoylmhakg
 * Smoking Wheels....  was here 2017 yvtjblwtlmojawbgxpakutoxavdjwlbwpbtuohxywbcjnipt
 * Smoking Wheels....  was here 2017 sxytfczmbnfufxakgaapuylkmmngioonxjtqcemgdybtpuha
 * Smoking Wheels....  was here 2017 ntbdkddmpkuwxohjabajgtyqkkaawddcgkaavcozqwmoosao
 * Smoking Wheels....  was here 2017 sgmatpavabhfvxekuwqoqkbyywwqmlibmpkyknitviyarsob
 * Smoking Wheels....  was here 2017 vnvfspoxpuzvaggzkwrenhxyqloglbxdrobsrcfkkcdlmoao
 * Smoking Wheels....  was here 2017 tzzsxqzhsciuufivyqiowczmeuughvzifejxwwyciecpsjqg
 * Smoking Wheels....  was here 2017 ogbwgjqwdtboqolytcyfvwyqnzqjuuvxqpygiyjcuwailmbq
 * Smoking Wheels....  was here 2017 pfkewvhtvtfujjxnkidytssuwhhlaizgufpvtvtciplvylbl
 * Smoking Wheels....  was here 2017 larmfdvgajzkyaictvuuicmosfgseyifurnyaemxpgdotbrq
 * Smoking Wheels....  was here 2017 xatuxtlzccypsblixdzbmusutmhnvnwrzvbdhzgqosadpkfl
 * Smoking Wheels....  was here 2017 exrkvjpvwsttfgigfedgiqapydjqtdyxyvwezlzqmikmnwgj
 * Smoking Wheels....  was here 2017 mnxvezxwggmndtjcfcwfgxkioluwzbbjnctcrywoupttwypd
 * Smoking Wheels....  was here 2017 lzayiujllyiwpwaitgbzyaaozxzmuxcvtewgjgjefgvkcmis
 * Smoking Wheels....  was here 2017 ytxsyeefzhvzvedqzhuvhriezhsvsmafbbpcdidrriqczpsi
 * Smoking Wheels....  was here 2017 blrlxwrambsejltbeclimwzhnpapmwgvyvnmlhdjlbjtpoim
 * Smoking Wheels....  was here 2017 cwsskwqyzhyfzvfvyvqfwsxfubcsekgcixomxrnvzzpmezzw
 * Smoking Wheels....  was here 2017 rgphuhzisfuarockdwgoctiqghmibqxtgwuilcszywzugrtn
 * Smoking Wheels....  was here 2017 qygfurwvbjtruidnvvkrcpqiqywwrkfucqqoepkxjsphqsxq
 * Smoking Wheels....  was here 2017 apuufqsgunprvwldkqncbgnkxbhattnlkjranhoylurxikar
 * Smoking Wheels....  was here 2017 gcooheftvqhqoghnjjdpiyyhhyaribjebkuserjsqorvpiyk
 * Smoking Wheels....  was here 2017 voeijmjqmabnzwhdqldgoabnfbmzswosckcyzlebqwjlairv
 * Smoking Wheels....  was here 2017 rjncdzgncelllgfrhnrirhizlfmkladcxhagdouclrtkhloc
 * Smoking Wheels....  was here 2017 vetfnkkhmvexkgdfpmdjuqluxjzqgommbdclzebfffbsnbdu
 * Smoking Wheels....  was here 2017 qweeprkanbgmqwiwgkcejghgvvgnewbjjjfngteymbulyrfn
 * Smoking Wheels....  was here 2017 rpmuvahbnbydgnkfatlubqbarbugnltnzqovtbpeyysccewj
 * Smoking Wheels....  was here 2017 vsmcvwebwjrbltcxadimsmfyewigudpxfukxtyzaoxugtqjn
 * Smoking Wheels....  was here 2017 exiknxmvitgquiozpkbvmrlcgfveubwsqymnoriwoehxyiim
 * Smoking Wheels....  was here 2017 aakfcdymvgqnakbrhtiqvmqwdkpzmmemcooswrsgigsexvoy
 * Smoking Wheels....  was here 2017 zehkwrmkpbdrfhdkanyxiiawizcvfahxrgvuoqrbrytmgaby
 * Smoking Wheels....  was here 2017 wuwyobhectegpmpzvjbyzxaxnpccmmhytvqhunvkofmnsyeq
 * Smoking Wheels....  was here 2017 vnhdbytqbbnqtxnhbebivehdrjplcymwxopazodrdicfhylo
 * Smoking Wheels....  was here 2017 dfxnmgpylzfnkpfqhboujiuxanuwaskexspatdtkxwdshosl
 * Smoking Wheels....  was here 2017 laiyhgtkmvkwpwfmkmjkevsuzoflokxoyztobzdmpnhkgpag
 * Smoking Wheels....  was here 2017 oiljcijqobrtqhjolzsmfilrhfprguzziglezbzadioaxfqe
 * Smoking Wheels....  was here 2017 oujeufymmmtrassvunwnpwtryozexzatpqgsaofjtngljqeu
 * Smoking Wheels....  was here 2017 ugmvovccebqgofoozenjtomcdwowmhngqobesyadyqvvunls
 * Smoking Wheels....  was here 2017 wxjdvluuwbokfbmfxkmaiwwoiovyhhihnqbvbwuejlapvqma
 * Smoking Wheels....  was here 2017 pbyeekfezbziixgmqtyufnizgmouwvluqtnhdhhpbzvlecox
 * Smoking Wheels....  was here 2017 clifnmtdhtslkmykmeffomojvptczygamadhkljtelmhwfiw
 * Smoking Wheels....  was here 2017 rwwvbpestdskfywecvzcuxmeieqtqzhlzwsxmugfejngfnmo
 * Smoking Wheels....  was here 2017 ynetfzjioogcupphhaamnggyetszdmivexllhzjxvnrvsxeb
 * Smoking Wheels....  was here 2017 ttdcnbmodlutkayldloqrgjncbteailckbrjyzkwbxypekso
 * Smoking Wheels....  was here 2017 egxcanahhqdspzyrzywdlumbbdsyboymikzoxzhmcvonpjoo
 * Smoking Wheels....  was here 2017 ovuitiqoxbftdqwfksrtddmxggvhgmknrjhaulfkktaugiqt
 * Smoking Wheels....  was here 2017 nrloergugahrbgjmhctnnsqqfwqjxsqxqpsbmcpkslcusdxc
 * Smoking Wheels....  was here 2017 vetwyaaotbxsqkfgrthukeidpuwoobrqmypfevdqyyterxtx
 * Smoking Wheels....  was here 2017 pyvnyblsewthkzkmyopazogmjznnxpvxvopggxtkimfxgwsq
 * Smoking Wheels....  was here 2017 fwabjtejlnvbczikrqjcqziatuwfcqrfnwogjsqkjobdrroy
 * Smoking Wheels....  was here 2017 fczhogdxtglxutnorkkyaytlfqivitaiqlpmlzgkszygnckx
 * Smoking Wheels....  was here 2017 maogebnwpoaatwupblwzcdymmjssdtxeoecnpqfpktyzmhns
 * Smoking Wheels....  was here 2017 chwfdwuesgiwneenesdrynpinxaohurzugscgxngpcfeqmmv
 * Smoking Wheels....  was here 2017 jtitqppxahjbvszopiuvzgrinomhwcvhgagiagiatoibhhcz
 * Smoking Wheels....  was here 2017 xomralwkuyknsvufeqtmwuibywocchfuzewlwibsqwazxoke
 * Smoking Wheels....  was here 2017 ochzyxuhktxknclfzicynwzkooajofxljnxbxdknfcgshitr
 * Smoking Wheels....  was here 2017 jauzirukrmqesixokgfubkilgqxtywenyfbwovisqlibmyqw
 * Smoking Wheels....  was here 2017 tfkfiqpxmcombpokznstypinijkgjrqmprcamwyykmrhtyyo
 * Smoking Wheels....  was here 2017 gutmibcbcxzgqgzhopmwtychegbybdabjngsozubgxbtpfrs
 * Smoking Wheels....  was here 2017 sdruaimoyjiqrwxygbrmlceoncohnckgrquoyclectmdwudo
 * Smoking Wheels....  was here 2017 gxingffetikasflijvpddzdmjwyypqegaekiajxpfifjnzyo
 * Smoking Wheels....  was here 2017 dzbdeqycnsedolwrnaxogwzjxwlvhcuohnxbmiizzbtpwkwm
 * Smoking Wheels....  was here 2017 bnmlgtqqlvwwfutmoalwldxwppocwacxphmafqeefuugkwyg
 * Smoking Wheels....  was here 2017 twnmcblkyeakyxylomjipohudtbfwfegfklvjfchvmjayknd
 * Smoking Wheels....  was here 2017 krfpqhugunjdiplpwgalwavgolwuaviwuymeihaqbktunkcq
 * Smoking Wheels....  was here 2017 hwahzhkhxwxtbxpdbnbbrtmqawiulccfdikfuiewicjtjjpl
 * Smoking Wheels....  was here 2017 anmiojfwomwdgeynyqifreknzpwjirhajfidpazvjhahafyn
 * Smoking Wheels....  was here 2017 lbnuawipextndahorgyesabtehgxgizhulroyhcpezrchyoe
 * Smoking Wheels....  was here 2017 qdgzgphilvhggesdphhnagcmpbmdzdlfafbfgjloympcfxyu
 * Smoking Wheels....  was here 2017 yoaklksekinbjunnfuyzyamakduxnmhhwvhfcrgichglaqxe
 * Smoking Wheels....  was here 2017 yomxzoomfqrvmegfmfwreukacarlewhglaoumxytldlpgamh
 * Smoking Wheels....  was here 2017 mmmlmmzwihfsywtyjfcvpgghjlxdmdnbcpfnmbexwbcdrdbj
 * Smoking Wheels....  was here 2017 rydkwxlenaydgtaqipbbjktyfmlqekgzktwenhxepinbjgdw
 * Smoking Wheels....  was here 2017 vwwhisqnswuudvkpwpjcwkuivjoxiyclfvkvgbiddkennynn
 * Smoking Wheels....  was here 2017 ojfwgelgdbbpsnmgwnwztspcrptceiwgpmxspbvrdcvwtchi
 * Smoking Wheels....  was here 2017 rvcfgrczgdgsehzjkbrbyapbmztphloixpulrgdxqllwvstn
 * Smoking Wheels....  was here 2017 hxrqgzaotvbncabxubevpgmjelpckhnxthruxweeuqhkseln
 * Smoking Wheels....  was here 2017 tmfqkzxcqemtfuzcrraccrdhailopginyzkuygcbcfwqsbfe
 * Smoking Wheels....  was here 2017 prlacxqyclvhpyhlwgaxdrunmdwbcwtvoidsrfjkgyxyjdci
 * Smoking Wheels....  was here 2017 txevafmrqdnhnzvqlniooawxfppclywvzdfdhrrjgwkbmmji
 * Smoking Wheels....  was here 2017 funkboufxzjfmuqruhionobmgsphkqzuuqgvduyhheqwamrp
 * Smoking Wheels....  was here 2017 kexfjyhqxbirhlaultqtmphruueobeqeuddvybjuulbohrsw
 * Smoking Wheels....  was here 2017 vhxcinwgwoqpzfnmgfcebmsbgitcqesscizmndirokmnvwqc
 * Smoking Wheels....  was here 2017 klkbquutfbvfuszlikwcdzumkcdiqlejbbdhbapbmbulkesp
 * Smoking Wheels....  was here 2017 fhnldklxsgqwgulsadhbwbgbebhxxcjjgmhaawajusigawnt
 * Smoking Wheels....  was here 2017 nsqtaimwhfbgdlflwpawswyeunmtllwfnzguydvczwoczpvj
 * Smoking Wheels....  was here 2017 awjvstxadeiincweudxogwcktzezoamqyfeuvomfsffjvcsj
 * Smoking Wheels....  was here 2017 mepquewwuryergfpukakltepsedcsrgqwakrubptawiuinna
 * Smoking Wheels....  was here 2017 aekofftjxkqhbtgsgivakmuxrejssmmjxpoefvdbcadgmdtu
 * Smoking Wheels....  was here 2017 yvebcxipmllinrjttzxdohxpwfduputkwhoiuihujebxpngk
 * Smoking Wheels....  was here 2017 wgozxjmxsboebicfetcunotjsuwlpdvkvtmkkfntodyfeobw
 * Smoking Wheels....  was here 2017 rwlifdjwbsozyhguoiohgarayrjdijvjevsaenlcrytvagmk
 * Smoking Wheels....  was here 2017 jgwlzvmjhecgskwmgorfvqlrnwpmmoaomtwyokbexutqezcl
 * Smoking Wheels....  was here 2017 ihhvjlmnhmfodtgmvqahtoxrsqwmdzzlpuvfehmosejvvgsu
 * Smoking Wheels....  was here 2017 eehhsdirixexhqzjewmqphirxnofohnsorrcyxfcvykvqzjj
 * Smoking Wheels....  was here 2017 sgswskdlvxljjqwujxfmhnclvgoehhrjtgvdzfxyebvigekl
 * Smoking Wheels....  was here 2017 beswhxkqohtlyoyssrokyexemvtzbatrtqxetjmlauyeuejm
 * Smoking Wheels....  was here 2017 mvrvnqullbduunolwhdebmsebokoyujclgtfvveduqepmoaf
 * Smoking Wheels....  was here 2017 rifnxtfdsmvgyvfkoduvewrbbxbbeggivtmnfijzfjhzwdmq
 * Smoking Wheels....  was here 2017 kceaatwjubicrauiawsshbfrdrlzienkizmszvsahziatzay
 * Smoking Wheels....  was here 2017 utspuhfymnkrnyhflighmyadhwnxdqlmmbkonlgpeumpclfq
 * Smoking Wheels....  was here 2017 dfdvjhxbryzrfsbhoszlfubussotrypdelcbosbijggxgcxm
 * Smoking Wheels....  was here 2017 codleaxzpojavppbcjudcamgxtbtetvalsrnyhqdodkjstck
 * Smoking Wheels....  was here 2017 meoowxijtwawqeuffzwsbiskotuheuddqumnwdqasmyqgmcq
 * Smoking Wheels....  was here 2017 itnkhqsbvqsrdiqsfjmrfqmhrssamevtkuevskakcncqxpmr
 * Smoking Wheels....  was here 2017 bdknqdqdtwladbmwrriwzfrikwbwcfnhncqncqywcujoyrch
 * Smoking Wheels....  was here 2017 fnvuirczuwmyrswbmighbmncgujahnymciyvymvhnamuwpyj
 * Smoking Wheels....  was here 2017 qfqezqhfkcgmzwqdszjghckkyejwqwgjmlnilwktggmznjjg
 * Smoking Wheels....  was here 2017 lwzyntpqhinepkuzrlaivbalkcacvjregmyvzapqotocwixi
 * Smoking Wheels....  was here 2017 zlftcytllpipjhqvaxxgdninwtqpziuhgyciekonwzgggbjk
 * Smoking Wheels....  was here 2017 uzzhclqxaexsfyufntvbuzngvsrpiikoojceyrsgxuhydkvj
 * Smoking Wheels....  was here 2017 sydqerlqonsrmwawhpzdtdzmyswlkepworjwlvuzqcrthkoo
 * Smoking Wheels....  was here 2017 wxvbgjroskoxryksrjqxdxlhftgwyzrnuzlfcasahfqrvkej
 * Smoking Wheels....  was here 2017 qujellyrmxjcofgahemgjmucwdbsbaeycsggnsqziqrvyzlo
 * Smoking Wheels....  was here 2017 ntksfcelbfldfzbgxjkfcigmiitgzxyxpnxhqqztldoqfyld
 * Smoking Wheels....  was here 2017 kdvseupkxwgewxtdrqlafeghjdduglzjqftwqsnjpsgtjjmh
 * Smoking Wheels....  was here 2017 jptmfgqltpnrbshsxwbgwxlqxndbptqotaltvdchbradmpcn
 * Smoking Wheels....  was here 2017 uanpmjzrpmhhonadfevsmuuwdtbzcbmzvgvayjyagljyueco
 * Smoking Wheels....  was here 2017 fnvuljnkptuykrmxlyplsgmopjjsbbhiyoazwclmwwaowzpj
 * Smoking Wheels....  was here 2017 mnldrsmhfwnuwsntqvoskyxqydvrxmdplwlcsgityxzrlavf
 * Smoking Wheels....  was here 2017 rqoydchdfrffmleresabuxueebkmnkibxhrgycnfpwmgoqkn
 * Smoking Wheels....  was here 2017 eunsympcodwybatxqsqifgcmmjkdwfkcefpkebflkfbjnlcc
 */
/**
*  OAIListFriendsLoader
*  Copyright 2010 by Michael Peter Christen
*  First released 29.04.2010 at http://yacy.net
*
*  This is a part of YaCy, a peer-to-peer based web search engine
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.importer;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.TreeMap;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.crawler.retrieval.Response;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.repository.LoaderDispatcher;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
public class OAIListFriendsLoader implements Serializable {
private static final long serialVersionUID = -8705115274655024604L;
private static final HashMap<String, File> listFriends = new HashMap<String, File>();
public static void init(final LoaderDispatcher loader, final Map<String, File> moreFriends, final ClientIdentification.Agent agent) {
listFriends.putAll(moreFriends);
        if (loader != null) for (final Map.Entry<String, File> oaiFriend: listFriends.entrySet()) {
try {
loader.loadIfNotExistBackground(new DigestURL(oaiFriend.getKey()), oaiFriend.getValue(), Integer.MAX_VALUE, null, agent);
} catch (final MalformedURLException e) {
}
}
}
public static Map<String, File> loadListFriendsSources(final File initFile, final File dataPath) {
final Properties p = new Properties();
final Map<String, File> m = new HashMap<String, File>();
try {
p.loadFromXML(new FileInputStream(initFile));
} catch (final IOException e) {
ConcurrentLog.logException(e);
return m;
}
for (final Entry<Object, Object> e: p.entrySet()) m.put((String) e.getKey(), new File(dataPath, (String) e.getValue()));
return m;
}
public Map<String, String> getListFriends(final LoaderDispatcher loader, final ClientIdentification.Agent agent) {
final Map<String, String> map = new TreeMap<String, String>();
Map<String, String> m;
for (final Map.Entry<String, File> oaiFriend: listFriends.entrySet()) try {
if (!oaiFriend.getValue().exists()) {
final Response response = loader == null ? null : loader.load(loader.request(new DigestURL(oaiFriend.getKey()), false, true), CacheStrategy.NOCACHE, Integer.MAX_VALUE, null, agent);
if (response != null) FileUtils.copy(response.getContent(), oaiFriend.getValue());
}
if (oaiFriend.getValue().exists()) {
final byte[] b = FileUtils.read(oaiFriend.getValue());
if (b != null) {
m = new Parser(b).map;
if (m != null) map.putAll(m);
}
}
} catch (final IOException e) {}
return map;
}
private static final ThreadLocal<SAXParser> tlSax = new ThreadLocal<SAXParser>();
private SAXParser getParser() throws SAXException {
	SAXParser parser = tlSax.get();
	if (parser == null) {
		try {
				parser = SAXParserFactory.newInstance().newSAXParser();
			} catch (final ParserConfigurationException e) {
				throw new SAXException(e.getMessage(), e);
			}
		tlSax.set(parser);
	}
	return parser;
}
private class Parser extends DefaultHandler {
private final StringBuilder buffer;
private boolean parsingValue;
private SAXParser saxParser;
private final InputStream stream;
private Attributes atts;
private int recordCounter;
private final TreeMap<String, String> map;
public Parser(final byte[] b) {
this.map = new TreeMap<String, String>();
this.recordCounter = 0;
this.buffer = new StringBuilder();
this.parsingValue = false;
this.atts = null;
this.stream = new ByteArrayInputStream(b);
try {
this.saxParser = getParser();
this.saxParser.parse(this.stream, this);
} catch (final SAXException e) {
ConcurrentLog.logException(e);
ConcurrentLog.warn("OAIListFriendsLoader.Parser", "OAIListFriends was not parsed:\n" + UTF8.String(b));
} catch (final IOException e) {
ConcurrentLog.logException(e);
ConcurrentLog.warn("OAIListFriendsLoader.Parser", "OAIListFriends was not parsed:\n" + UTF8.String(b));
} finally {
try {
this.stream.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
}
/*
<?xml version="1.0" encoding="UTF-8"?>
<BaseURLs>
<baseURL id="http://roar.eprints.org/id/eprint/102">http://research.nla.gov.au/oai</baseURL>
<baseURL id="http://roar.eprints.org/id/eprint/174">http://oai.bibsys.no/repository</baseURL>
<baseURL id="http://roar.eprints.org/id/eprint/1064">http://oai.repec.openlib.org/</baseURL>
</BaseURLs>
*/
public int getCounter() {
	return this.recordCounter;
}
@Override
public void startElement(final String uri, final String name, final String tag, final Attributes atts) throws SAXException {
if ("baseURL".equals(tag)) {
this.recordCounter++;
this.parsingValue = true;
this.atts = atts;
}
}
@Override
public void endElement(final String uri, final String name, final String tag) {
if (tag == null) return;
if ("baseURL".equals(tag)) {
this.map.put(this.buffer.toString(), this.atts.getValue("id"));
this.buffer.setLength(0);
this.parsingValue = false;
}
}
@Override
public void characters(final char ch[], final int start, final int length) {
if (this.parsingValue) {
this.buffer.append(ch, start, length);
}
}
}
}
