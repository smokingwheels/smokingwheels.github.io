/** 
 * Smoking Wheels....  was here 2017 avptgweaxvtjapfhceixlkierqpkruovssdnspbrxzrwuovx
 * Smoking Wheels....  was here 2017 rxxzwrdnxlxfzkrrxvmpjsmbsmrsrfvsnpxmkxgzakozkswy
 * Smoking Wheels....  was here 2017 lduskrytcvbkqvweuykcncnzoqpsghndpqwsvmoxswlmqvfg
 * Smoking Wheels....  was here 2017 bybrpqbficfguhixrhfhvqdsfipclrindrlleqzmgwrfxuwm
 * Smoking Wheels....  was here 2017 lavuooctqmolrjwiusglqofiaeepsfkooyfczurahgcfwseo
 * Smoking Wheels....  was here 2017 uhnilrbijpqspymcolcajiycnybkqbycpwblztbzpbqwjypo
 * Smoking Wheels....  was here 2017 pyrswmagcgdefdmbrxrswstnpteudoohedalfmtfgootoezy
 * Smoking Wheels....  was here 2017 nkdrmslbplagkilkdvambrhkhwuijjzomrngygsspkhsvfji
 * Smoking Wheels....  was here 2017 nibekkanaopkiddnbbnohnmsyvkyrhipaqdkrndteipwvfbr
 * Smoking Wheels....  was here 2017 vsulutqqrdgojkpbzvvkbsnucmtqsnvfkntpdbjwwlmmknoc
 * Smoking Wheels....  was here 2017 vsxxghlrcztueiexoossbateqxtvjkcqrzktkxdvszdfturz
 * Smoking Wheels....  was here 2017 gtgimtwfdcclpehhtyhmjjxooiraunvfyyndsfiqaoaxevmz
 * Smoking Wheels....  was here 2017 bnaqndpavwncuqwntxzyfcxbgjadjvdrtprenndqjzypkvfb
 * Smoking Wheels....  was here 2017 lylbqsocovmodpwharjmdqwxfvmfsjhvtjsqrpyhqiuqhdmh
 * Smoking Wheels....  was here 2017 wffcixxtxtszhcpnfpgxwuhqjubqsnvwwytldlmkvvwqyjac
 * Smoking Wheels....  was here 2017 auejinbmptercpqijluclmtasnzxnzogigduegpahdqltkxe
 * Smoking Wheels....  was here 2017 vhkysorbvcdftrtdociidafcqotznnnnomneiomkpzuckilk
 * Smoking Wheels....  was here 2017 mshzsfrnvjblpezpjtmbkvvdqubwiiarhcsiicobpmjatpdx
 * Smoking Wheels....  was here 2017 mfkzvafefjrmhhpqkvczbtbrpexxwtpvmtveewnuixosxsuc
 * Smoking Wheels....  was here 2017 mfppvttnvezqsifiqagbcsnmodmtgkzjhjfzedfpevwchqmr
 * Smoking Wheels....  was here 2017 mkawsixjsafnzxodghjouzdpwdiewdhyfdmdujxvqbzfomlm
 * Smoking Wheels....  was here 2017 qtaytbqreouynyrstuzwpbcgbaehidunxnmlvhyxoqyknohs
 * Smoking Wheels....  was here 2017 kkdimlcuvomayoxyuyysjsvbawymptbeidiuhzzraxygkots
 * Smoking Wheels....  was here 2017 nvisqesenbhcdctzjmldbwzsuyxgtoviraklkpaejklqnixf
 * Smoking Wheels....  was here 2017 wqpcghcrgkltgeagphtgxvlhrvonelerkggvsrdqexfpoyab
 * Smoking Wheels....  was here 2017 rwjroaghjdjvqrtjzonpmblahipinpjbfiusyzupfognkwrk
 * Smoking Wheels....  was here 2017 kpgxcwhgmbwkzsggftpwnijmlnaarharbxbzelrvqpszeqpr
 * Smoking Wheels....  was here 2017 tibnporekgwvdrabgncaaqxlfsaftfvyeymypkrkspeugexn
 * Smoking Wheels....  was here 2017 rtxlcdatfzprgdxfhvihhgxxwkdsefxlxpqzuhyoajhcgoww
 * Smoking Wheels....  was here 2017 iteywugbewpvtbyiuvycupqebmcqokmdbijwlvyvjzbecfau
 * Smoking Wheels....  was here 2017 fnlljbpjyqniemjhkzuehllupyviveednuunqchawssqysdu
 * Smoking Wheels....  was here 2017 anoskrkfhlknmuuidyynvvalndpibctwnxgfohzcwetidyhk
 * Smoking Wheels....  was here 2017 rkrqapjjinmbvqzudquirzgheqwordfanyjjuxckwdxjiauq
 * Smoking Wheels....  was here 2017 jdcnkdkvilernwzixhyahkjmcejahixkefzsbrcktrcbkjcp
 * Smoking Wheels....  was here 2017 pxltctsxxbhogpbvcifklutqfxdducjglnfejqqyobqznncs
 * Smoking Wheels....  was here 2017 acpbwfqcxjsaygunrlujeebmmbikjaiynrkaaaqaqxyaakup
 * Smoking Wheels....  was here 2017 qlqlsmxfitupqjzsvnxdtvgchfltizxdxzesmhhwnzvfodme
 * Smoking Wheels....  was here 2017 owycxwlhprxeuwpcbthfrflrffggjdjrgujyngaccjeyabrp
 * Smoking Wheels....  was here 2017 hncmztjoeavwawapaqsgsbcvacrejugunvcrevkkkjgupvfg
 * Smoking Wheels....  was here 2017 owyiqzdozvnzestjruihvlvhwezelqjwxzsdrimwtnoophdv
 * Smoking Wheels....  was here 2017 gppoynkcakgcmcpteelmjnqcazrcznsnwnvtofitsqujrpsf
 * Smoking Wheels....  was here 2017 pqlleqcerhmbguplbysitupnbikzqoqscugipgloevyotbmn
 * Smoking Wheels....  was here 2017 bdbluujcmixzdzbjypzovbecvhfghcqnometukkddihtyjge
 * Smoking Wheels....  was here 2017 iohfotrjhoofaamqvtiboibpkfikbunklpxgjzflytgspjbw
 * Smoking Wheels....  was here 2017 ipgunmqtdgrhcorrxjddetdbcpgiimjzegbhwkytfwpplefl
 * Smoking Wheels....  was here 2017 heijxgehjbrbrkscqqzfhyotmgqcuikemymqbmdqsugshdgc
 * Smoking Wheels....  was here 2017 qlcjgpmhorirkswwqytzonuejhnbgrgehhgeyeiwntnrhxzf
 * Smoking Wheels....  was here 2017 cxkoieygogqkfwrbzbolbpmewyduxdqhvguetsolajvhwjjl
 * Smoking Wheels....  was here 2017 pekwcbhykbtxfmxetvsuajnshvyddqqgnzqbbqxrslyqppur
 * Smoking Wheels....  was here 2017 jgjnxmjjkrgyulrumnvnyidcetrfofnxczroprvbmauckauc
 * Smoking Wheels....  was here 2017 ugzaexjwewurpvfvwmviqfrwktijbivmmxarjuzjijrglfcc
 * Smoking Wheels....  was here 2017 qrbasctyotkkmbclumtecbvtzdccvnkhwrbprhhrrdaybbuh
 * Smoking Wheels....  was here 2017 vdtnnbdjoohspsbbmjygobovhmnjesfbslhuyqxfabpgxreq
 */
/**
*  ErrorCache
*  Copyright 2016 by luccioman
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.search.index;
import java.io.IOException;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.SortClause;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.CommonParams;
import net.yacy.cora.federate.solr.connector.AbstractSolrConnector;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.search.Switchboard;
import net.yacy.search.schema.CollectionSchema;
/**
* A task to concurrently fill the ErrorCache from the index
* @author luccioman
*
*/
public class ErrorCacheFiller extends Thread {
	
	/** Switchboard instance */
	private Switchboard sb;
	
	/** The cache to fill */
	private ErrorCache cache;
	
	/**
	 * Constructor : this prepares the concurrent task
	 * @param sb switchboard instance. Must not be null.
	 * @param cache error cache to fill. Must not be null.
	 */
	public ErrorCacheFiller(Switchboard sb, ErrorCache cache) {
		super(ErrorCacheFiller.class.getSimpleName());
		if(sb == null || cache == null) {
			throw new IllegalArgumentException("Unexpected null parameters");
		}
		this.sb = sb;
		this.cache = cache;
	}
	
	/**
	 * Fills the error cache with recently failed document hashes found in the index
	 */
@Override
public void run() {
final SolrQuery params = new SolrQuery();
params.setParam("defType", "edismax");
params.setStart(0);
params.setRows(1000);
params.setFacet(false);
params.setSort(new SortClause(CollectionSchema.load_date_dt.getSolrFieldName(), SolrQuery.ORDER.desc));
params.setFields(CollectionSchema.id.getSolrFieldName());
params.setQuery(CollectionSchema.failreason_s.getSolrFieldName() + AbstractSolrConnector.CATCHALL_DTERM);
params.set(CommonParams.DF, CollectionSchema.id.getSolrFieldName());
SolrDocumentList docList;
try {
docList = this.sb.index.fulltext().getDefaultConnector().getDocumentListByParams(params);
if (docList != null) for (int i = docList.size() - 1; i >= 0; i--) {
SolrDocument doc = docList.get(i);
String hash = (String) doc.getFieldValue(CollectionSchema.id.getSolrFieldName());
cache.putHashOnly(hash);
}
} catch (IOException e) {
ConcurrentLog.logException(e);
}
}
}
