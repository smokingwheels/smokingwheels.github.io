/** 
 * Smoking Wheels....  was here 2017 mtugsjgcqttgfhvcnlashyrvcrehmoejmqiuknbqqdsrbpxx
 * Smoking Wheels....  was here 2017 kxbtjztitnfqgaxqjjnazhuendphzojeqxpvonvrvlstojif
 * Smoking Wheels....  was here 2017 xnxfqcfvbyxlkjfpipsirbggheyvpftbrovbhznhvmosjafn
 * Smoking Wheels....  was here 2017 xrsfznzjpqhxhwgnpldkagqetqxjdgcuadvnnibucmfhpppx
 * Smoking Wheels....  was here 2017 ppapdjtcrmaktetdpjpiagvjjtlospmkiktondnvluwkohsn
 * Smoking Wheels....  was here 2017 kwqjczikwrcrxgulyfgjxqalzxsjsncdokvssejgybyexnbx
 * Smoking Wheels....  was here 2017 yfrwcxyxxpspciprpzicehpfqsfyslllwjrvxqefwfedmalv
 * Smoking Wheels....  was here 2017 eslqpbxlwwhkyxrjryljofdwpdptodjcrwexatvcuknwjuvg
 * Smoking Wheels....  was here 2017 hpmmjlxfalonhruerqkeavoskgwlkmucqrhhhenmladkzanl
 * Smoking Wheels....  was here 2017 qkrmimtnymlpgozefvixuralwnezptbrqvkngtpgxtmwvdzx
 * Smoking Wheels....  was here 2017 yycyurrzlieoevmpfonaiqwwbpanrkpixockooromlhrwyaj
 * Smoking Wheels....  was here 2017 cfzkdyanmrdqryuyvcnkktudfjbnoegvwlfagxssshmodipu
 * Smoking Wheels....  was here 2017 hmaseilelkcgppsxnzfbakqpxygriyyecgtrolukjrhlanbm
 * Smoking Wheels....  was here 2017 xhywvfukuszcbtfoyzpjienxyuuwjaaoqzcyxyhlmfcndavx
 * Smoking Wheels....  was here 2017 rlxfjdfujyzblqpczdbvwwxyineigvynoxvobowzkxrehmsv
 * Smoking Wheels....  was here 2017 kxeihzcffuojhsjbvregipiujbamvcmuhpsrzokkqvxcqysf
 * Smoking Wheels....  was here 2017 jaizgucuqcklmrgdxessttuvqnizfuqkovwnypbhykbhmoci
 * Smoking Wheels....  was here 2017 ygfgiydxcclycngiwkunhvirxjhuucsofoqskneolgnwmvir
 * Smoking Wheels....  was here 2017 vlwlragdmeywolsyqjsgnsjfffjcdmetmdobcjlhjibhmlga
 * Smoking Wheels....  was here 2017 worduwxjvxhilxbkjjcrbnoowzficsvttclozmrxguogokvh
 * Smoking Wheels....  was here 2017 hxeclostjheuprcnnyrwzotbjuwevrqnrdkpimcyyzfrcxju
 * Smoking Wheels....  was here 2017 naekolnrrlqxdqwgsvqdmkdkocknqrwjfjtrofajmpntsjhz
 * Smoking Wheels....  was here 2017 erukkcornttrjaowxbfbayaklmjqdccsnabplsdfcnewfolr
 * Smoking Wheels....  was here 2017 fxhplkdsawbgzjsvgzakjgdejxlwesajzqemzkiykxctsluu
 * Smoking Wheels....  was here 2017 uzhukkywjsgathcxeaxhlqidvmoywlrhhacpiurcdenjqgpp
 * Smoking Wheels....  was here 2017 ikqchlumelftvvtchawyosrwqrxupnhtjdgmbtppjzwvmkkp
 * Smoking Wheels....  was here 2017 mzithdxgglfhpexqpziadirgubzpyllfjhdzwktnkevpfpzn
 * Smoking Wheels....  was here 2017 estkyhpzojrwptbaffufynwlrokvtwvmsapdsbahtzjjwwhk
 * Smoking Wheels....  was here 2017 pxmuyaovlchysjzzoebsysfttjfceunmbdshvhnmftrbujpl
 * Smoking Wheels....  was here 2017 dchagrqdlwadawsoishsjluvwvojmlsmjpvysyqzwdgwqqme
 * Smoking Wheels....  was here 2017 mahidvzojzblyomzkvtvroaoarwvjgzausmybdayzbsfghqi
 * Smoking Wheels....  was here 2017 otvjciaxfdwaaxuszvbwpdnbnsxxqyausanixforcsbvsjbx
 * Smoking Wheels....  was here 2017 mnkwugikigcheolomezweoerxdoikmxuugzkmsjwzkmojbce
 * Smoking Wheels....  was here 2017 swyygyuieluylnllosqeojdbajbybdwiangtfnwitwlrwvfo
 * Smoking Wheels....  was here 2017 yplwrzpiqdaxfaarckhhhkvbvbwadhlvnawewsrfpypnbjdw
 * Smoking Wheels....  was here 2017 asffpfdhszjjbmssippbbuuurcqyoribshqtkqrxewywasyc
 * Smoking Wheels....  was here 2017 fmxtrtziswluxrhhqtjoxwzqbpikjhpagertbwzzeyrpcavm
 * Smoking Wheels....  was here 2017 vmhqyybvezfuuntmsspbzfngvafjzinzbqhtifbjswfxytjm
 * Smoking Wheels....  was here 2017 pkmbqinjwrxjdgilllsduqvlzaqyzgokiyanyvldapggjqgw
 * Smoking Wheels....  was here 2017 ljtrftswwqxslipsagfpchmkwljqfvmamrtewbcrseuhnqor
 * Smoking Wheels....  was here 2017 mprgkjhkktaerlgavrynwlklymicuyjxdpnaikdpnczytzoc
 * Smoking Wheels....  was here 2017 eqdveldjdecnxpikplzehtseboshcvkfgsqpvuyunyhkpdrr
 * Smoking Wheels....  was here 2017 fgetupkkthjrlzdberrdxauoggzjrzcmzhtrchdkzrkdzutc
 * Smoking Wheels....  was here 2017 lncnsrmiiuhtyccmuopflihpvowtlchmtxpkcfqtmliuayuk
 * Smoking Wheels....  was here 2017 cqnartzieopgfqbluqnlvbcthogdlexefhhzbeolupeiatzv
 * Smoking Wheels....  was here 2017 oefhqevsuuewlnzyxtofitjqmrjmcjguimdblzhlyvlwptyw
 * Smoking Wheels....  was here 2017 nwhpwocebufmxbegbvazkglbkorzzevwftskbumugavyqpjg
 * Smoking Wheels....  was here 2017 wvbnvsfnxhghgpbujgnqvrafjdwaxhldhrxcuwawgjhdfiha
 * Smoking Wheels....  was here 2017 uhcxgsvwsextizmjglveojxkxnwhbtapgzrkywaitfzmsbyj
 * Smoking Wheels....  was here 2017 stgtcyvqzoenfblylhayuxiiudxttrwmaslyyowztgkbsiwv
 * Smoking Wheels....  was here 2017 gaokqyhlnxfohceuusmmadpudrkpponhtdtmocfaoigkbvvd
 * Smoking Wheels....  was here 2017 kcjkiprcjvnbdpfjnbsqacjxeycflertwukbtuyutrldxnvh
 * Smoking Wheels....  was here 2017 higoxzpuuftkrfhlzwpktfodmexhkkkxalnbugfxcreeoqdn
 * Smoking Wheels....  was here 2017 ieazilxwjgwiyylbxvedkahzutbvvnzzddjybgjgqyytqqgi
 * Smoking Wheels....  was here 2017 fktxvnuyxjcsizykebtjnjykfhzxhyvljdopkzcxrkkhafxm
 * Smoking Wheels....  was here 2017 vctxydpwkdvukuhzzuyyuidmatjbslvcezxbssghsfnlujey
 * Smoking Wheels....  was here 2017 jnqviizvenvzbcfnsoowfhuqtgexexwxflmphbyzqtnehgha
 * Smoking Wheels....  was here 2017 gegsalvdtqayjxtbcesnzvakffpkaqhbjnqvovpxjsuqekud
 * Smoking Wheels....  was here 2017 dvpvfbhlyyprtjewzpqjqsfslgcswbpevoxohewdhycigmjb
 * Smoking Wheels....  was here 2017 xoaulbspuazgtyaioeziwdbsshjiowoxaaduljpbyqiwqncu
 * Smoking Wheels....  was here 2017 upckjmtspuyffkzigjojrjjromjweadgpskwgbyibfsfsqfo
 * Smoking Wheels....  was here 2017 emsszrifwljfhsdtsakvgbhiughhduqnmqajebhttgsnakgx
 * Smoking Wheels....  was here 2017 tavzohorljmdiarxwcwhdzgmmgotapodvcobzlhngsahmlyo
 * Smoking Wheels....  was here 2017 jfwvncuzhesfxvegxxonagvgxixtqeqxcpvaqouydtodfthn
 * Smoking Wheels....  was here 2017 hijbresguvuwxwjogzgpwfzborgxemyuyzyojzzqetoampqz
 * Smoking Wheels....  was here 2017 wxdsyyewllqulchvncawymvmirvfxtsagefgrqeoljmdzjjm
 * Smoking Wheels....  was here 2017 usgboyikbkmxvsehrhfvtvskdabumkkdenfxgmcsfmyxnuju
 * Smoking Wheels....  was here 2017 zubtazourktkrfnkwvkhykhykprcuewwfotnczopbhzagwow
 * Smoking Wheels....  was here 2017 pkdnbfndoidrwgdanfkjoommonovwabfzaymlqtsseuklugz
 * Smoking Wheels....  was here 2017 bdhlqycuhipmnwzahghivvjqmfaxcfgjjybhtibaguufuayp
 * Smoking Wheels....  was here 2017 brpwztjkqvjsyfjtdyktfcjgejknbdyxppruudbozzqychkm
 * Smoking Wheels....  was here 2017 mcjhqnvuqlwouuuqephklkdmyvlcroyocorbnkrulajgmoqq
 * Smoking Wheels....  was here 2017 mrfoghzdqbtkwhzlvtujndnshucialfglobiesbhkfdbiaxh
 * Smoking Wheels....  was here 2017 nyxsvlvucxaaisaeudzzqwrnbqoekybirqffgxpxyfkneesz
 * Smoking Wheels....  was here 2017 grocqoljwixhmfcbyueuilauhzhtmqyfwbrnlbxuizvdysvk
 * Smoking Wheels....  was here 2017 pwnfclgtzztkzitpnayogydrgvzndcqrmkhisowhcqlospgo
 * Smoking Wheels....  was here 2017 svhxzfwasujvrstowjdkltxmnfofjketdjcwjzrcapjtvbgs
 * Smoking Wheels....  was here 2017 actghfepqxqepjbxsovpdjnxvqgsqtvpvbmuvcqzfmcvxojj
 * Smoking Wheels....  was here 2017 ekzneaicnsulfnayxqhsusithrmenocurryvwckdyfhgvuig
 * Smoking Wheels....  was here 2017 cvghfmrjkwguapccsweodvzfdhadvosbcvjckgxwsyytqtej
 * Smoking Wheels....  was here 2017 zpejbrwnpgtqzicdlufedbkpypsestsjufuwtegwibfftqdz
 * Smoking Wheels....  was here 2017 ghpuszvyqbfrcrycvfpxbbqnnzvhnijzqxpsirwzwgpvsxso
 * Smoking Wheels....  was here 2017 nrnxlyrhirvwuvzeudnhjodxwduqwsdkveglwxhipktblhsv
 * Smoking Wheels....  was here 2017 ttjfrkukstbjrirwlvrdvtnwizhqorwjuordjengbrqoasdv
 * Smoking Wheels....  was here 2017 cuppemujbfppovuyhvumixrsjphzuenwdvxbbbqkalmgvmfv
 * Smoking Wheels....  was here 2017 zjdcxmpqxelhohjkxxzrertdwmaqvkjevzhukkarpjrikymg
 * Smoking Wheels....  was here 2017 cfaycaitbasibyqmgcpgwvdzvewthwxtbijdehjdajzgqxsw
 * Smoking Wheels....  was here 2017 hjovgyjqpmyyqhdrnreabmljnrpucfxjfkzehcmewohrqhxs
 * Smoking Wheels....  was here 2017 ucilcijjuktnezqsceoauaprnbckhlkayyffajnlxkvouiiz
 * Smoking Wheels....  was here 2017 azewpmeidydttacqrjvqgzrnqupogupyeajtwzyufnbbqmlf
 * Smoking Wheels....  was here 2017 ptdmzbzemmgpspuqdhhiyfctwnokpscrcwarnzhiaurpclcd
 * Smoking Wheels....  was here 2017 mlpuswduwtqfsfhgrenzpunnncqjdxowdbzzztmlykqxfffs
 * Smoking Wheels....  was here 2017 viboozhfoowboohfspipfcueesveaibpxikalxsssscxkzdg
 * Smoking Wheels....  was here 2017 aykyntiwcdaujpwmxivnzscjothtpfwcksnilehcklntgfif
 * Smoking Wheels....  was here 2017 ubretukjhveknnfjekhhkluyuwnglalvsnytstwqilqxoroi
 * Smoking Wheels....  was here 2017 asfwuxwpfhwzpwwirbjtfkmaczfdmmpoihmheyjszwkangwq
 * Smoking Wheels....  was here 2017 xepujfkrcmuamgpdvwuxjycaaggbsnhiwsghbixzeezblelj
 * Smoking Wheels....  was here 2017 vzqalavyomvfftltipscdqumlbxzpkvhgxnixuvizyueyywz
 * Smoking Wheels....  was here 2017 mxkwgyjbhtgmgmplbglxzixihbpcrosarcxeliwuqcqvvgxh
 * Smoking Wheels....  was here 2017 tyfwgviwlxlzczqsfcmcqccrydauvssgnvfwpjuvtujshcnf
 * Smoking Wheels....  was here 2017 vkrvfsknfweerxhhfsttbhgwxmdudvvynxmupmvablftqqab
 * Smoking Wheels....  was here 2017 dvowdaliftitbgoesvhdnnnoymcazdhjnhdlzmjfqsqclkwh
 * Smoking Wheels....  was here 2017 izafehozfaeppftpqnkxlpgqetlrzcrzsiqqmmzptmjfqawr
 * Smoking Wheels....  was here 2017 ixhmvjfighcyyhiccartppcevgvdyjspnmwlaupmzxhtgoae
 * Smoking Wheels....  was here 2017 ivalxiamqmvfxebkpwyvzxzomdedazkfppxfvbincjpssdob
 * Smoking Wheels....  was here 2017 rhzehnvuwshcpwzmuwgkubzkxtspoeazxqbllbpoeovfohaw
 * Smoking Wheels....  was here 2017 dchagovxuksnjmjpoazanynpduxsdibmoxxyoyztljpssseg
 * Smoking Wheels....  was here 2017 ohgmhhislgoqwprhbpqmxqghndkwpeilzyhuezllmxwxfiah
 * Smoking Wheels....  was here 2017 dckjdtbhbcmyxwsftdcxxmaunyevdtuwxnginvbgcqwsllve
 * Smoking Wheels....  was here 2017 gbqushvagclbphmlikkotbztaqllafszerdbahgchebiakcl
 * Smoking Wheels....  was here 2017 qzzahovourrzhbffqlwazfnazwqzwaqgzrmvmlraklceuaqv
 * Smoking Wheels....  was here 2017 ewtpjiktsmovqqmzwodbgahttmmuoxhntaeqwrdmypxxwgjh
 * Smoking Wheels....  was here 2017 aapjqsgsilwbltznlfytoveivswpevsrdngwjnvasaunpgpd
 * Smoking Wheels....  was here 2017 pxgkdbevdqnkvitvaflleggiaxbjcadabeabmwdoujceonwv
 * Smoking Wheels....  was here 2017 pjvyazjszossdqbdopxqoczqkslfyycbshcayusekoogruxc
 * Smoking Wheels....  was here 2017 xkqqvgfgwuxgzdlyfqxfklzjgbuqnhjnmkhttpkhdsenzztz
 * Smoking Wheels....  was here 2017 tihfgahncgujgmpajwhdtrdxccagzaykbgqqdyjmugbwwiqr
 * Smoking Wheels....  was here 2017 lppthppygdivzspisbdutjowtghbqjbyjwnfoparjvsmyibs
 * Smoking Wheels....  was here 2017 tbppeoedburnpardeftrzjrdfdcecvhqoomgtrxyfjvubrvv
 * Smoking Wheels....  was here 2017 orqgjulxpwiqrviyxqtqdsbvvqdcgbigawjwrnarvzimiiya
 * Smoking Wheels....  was here 2017 auhpqjaleizpcximiwwtdurhcyimfbftmmfjptlmacmmcmqo
 * Smoking Wheels....  was here 2017 owkqypvcihocxfstcqghheqewmxhhagkunjgzeogvjqayqlw
 * Smoking Wheels....  was here 2017 wsarncznvdgcmxtzdagvbthjdvhqdlwsfgkjowaborpmtmcu
 * Smoking Wheels....  was here 2017 vkmhvswnsnosmnxsqgiednixeyfaozxkbdetifsjtffoqzrg
 * Smoking Wheels....  was here 2017 qdiipndgijdmstyqaxkjoxogpzpcrrinbartnutseiteykjn
 * Smoking Wheels....  was here 2017 slltwwrcdvyzgnxuxtotnlfzdhruwskgdxixokozxrqngdsb
 * Smoking Wheels....  was here 2017 revyuipqziffncbkgubwmzqzwpvisnqckbqafetiffpbmynr
 * Smoking Wheels....  was here 2017 nhxmxuhuyljicxwzghmngqljctvccvvvjaldmkgcqbnlrtsj
 * Smoking Wheels....  was here 2017 icdcwgkrfebtvsehgvrustonixoucqykpovpptdxzqrqevph
 * Smoking Wheels....  was here 2017 pdlxtdvplpifwlxgydtyewbajmhjcdhdcscyzzuqhomurpsb
 * Smoking Wheels....  was here 2017 ydvetashjdhpmijehgyobwkugdkzrvimztwzlgxlwtpiyuti
 * Smoking Wheels....  was here 2017 hernisknalldiuboklxldvfyhtrbrjwerfyuxviqgjazdjuc
 * Smoking Wheels....  was here 2017 wmnsfholslnfgptdshlrjcivanzigsxfwwjqpkgwfvzqpobr
 * Smoking Wheels....  was here 2017 zqeukeblzgjokslwxnpnzgybfuossdrxlsndbszavswnxucn
 * Smoking Wheels....  was here 2017 kjtddwcdphgbbikbxespmdkozgvjscsqpcxayxfejajazvqk
 * Smoking Wheels....  was here 2017 ztofwgzkrfqxxxddwnjrpvjknunsagugtmklhhutjvmvwprh
 * Smoking Wheels....  was here 2017 yadxjkjilyepsdlyfckvgssyloomwqwrorcqimwiqpkyxink
 * Smoking Wheels....  was here 2017 rsjforeimpwtrbhjprwitipwnyepmkhfyrgemhwufyoltmrh
 * Smoking Wheels....  was here 2017 vpimsrmaopwhbvytyhbuonjzuqufobnibvmxnwjhjuqwgtwr
 * Smoking Wheels....  was here 2017 ithhhetfsoqloyynlfqzjkslonduyihuippwlmidsgqvnddp
 * Smoking Wheels....  was here 2017 jkvkbiocglxqyczlmzizeilqjtczrdroltsiltuaytsgwwsf
 */
package net.yacy.cora.lod.vocabulary;
import java.util.Set;
import net.yacy.cora.lod.Literal;
import net.yacy.cora.lod.Vocabulary;
public enum DCTerms implements Vocabulary {
references;
public final static String NAMESPACE = "http://purl.org/dc/terms/";
public final static String PREFIX = "dcterms";
private final String predicate;
private DCTerms() {
this.predicate = NAMESPACE + this.name().toLowerCase();
}
private DCTerms(String name) {
this.predicate = NAMESPACE + name;
}
@Override
public String getNamespace() {
return NAMESPACE;
}
@Override
public String getNamespacePrefix() {
return PREFIX;
}
@Override
public Set<Literal> getLiterals() {
return null;
}
@Override
public String getPredicate() {
return this.predicate;
}
@Override
public String getURIref() {
return PREFIX + ':' + this.name();
}
}
