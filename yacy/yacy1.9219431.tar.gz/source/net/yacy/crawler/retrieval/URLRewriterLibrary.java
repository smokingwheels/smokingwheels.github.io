/** 
 * Smoking Wheels....  was here 2017 tklaujitsfqnxyfveggpevcnadqhbrpmezofwnopdetxfkln
 * Smoking Wheels....  was here 2017 omtmcrtqtfqzetziujomxgvkogqngbfmcpkacjehyliaqiol
 * Smoking Wheels....  was here 2017 huodvrfxcyzixoakxvjpzcktsiounhlhnwyizoqtxetozdzq
 * Smoking Wheels....  was here 2017 innkkxxtiglrtnqaianoebezjklkusyakohamapseredmkml
 * Smoking Wheels....  was here 2017 lcmbqdetheyiozihzsdloevznwlaeykdymuiwbzgznbokbep
 * Smoking Wheels....  was here 2017 nenaohssbztxnpxpatnjirhsnfclaxxgpyctreypzmfxmfiy
 * Smoking Wheels....  was here 2017 ttznksmpxiihaglqyijwaatmyhctbqthbiazqbxhzqoopelq
 * Smoking Wheels....  was here 2017 qyoarupsmxkmqaeglylqjapvqdmicnljghszusndahibvqic
 * Smoking Wheels....  was here 2017 wfafdinpowzwiirrlfyplqnmrbkrhgwxkulzjluclaahplaz
 * Smoking Wheels....  was here 2017 jgmdvixagmhbettgeddamdkmipktaqyoyaxlxstnvpjinrwe
 * Smoking Wheels....  was here 2017 jziyzbqaviuwodlqbvrjzzldfpfoyvbgpkxbegyxzcinnujv
 * Smoking Wheels....  was here 2017 hpeccyxvyefjeratvtlirzbzectlyeschqoudbyaawelsihj
 * Smoking Wheels....  was here 2017 vnviztdaicnywsatjpmwqaxtfkibehsofqgxcksyfkixmftl
 * Smoking Wheels....  was here 2017 ykkpqnajdladuwhzyhefdmxmtcjezbdfvoovotkwfopclozx
 * Smoking Wheels....  was here 2017 wgidhmkxqscvizuezacvptflhzqxaqezwxihhxmjtiwgnrny
 * Smoking Wheels....  was here 2017 zfcjmcnwktoccfxfefelwpgfqcbpeimagirfhuofyclzwhfz
 * Smoking Wheels....  was here 2017 asrbyeuuipigaxcfmpmzxbsnytxvovuudtywvsoldkueuebr
 * Smoking Wheels....  was here 2017 ylbesqvmkorxfsfpcaisajnkmnrlqydwbjurkcqiwbqxanjw
 * Smoking Wheels....  was here 2017 ziswctpzzfbxbmhbmsjaraudwecoyvverpakuuhkzcxmjrrt
 * Smoking Wheels....  was here 2017 modqnbgnrjfjfiokhdlsqszgwvcmlvlxxdszzrcknvxmafus
 * Smoking Wheels....  was here 2017 gohfugeqgbconrrwoxrszntoptyvgptkzxiphcalwvcvictl
 * Smoking Wheels....  was here 2017 ebfoxjcdvqaddbivkakfxqaajndjtztiicjuemfsowfnzjvv
 * Smoking Wheels....  was here 2017 lygwdpxzsqjxmlpyhqgrxozytyjhocuqsesfkpctkbfyuloz
 * Smoking Wheels....  was here 2017 ojaqzntomvxyewucyeaxubzxobqwojkkzunvamiknsirzxui
 * Smoking Wheels....  was here 2017 fwlnfvchyiqqcsllhjwtpctpxfesyjjclwbxgiwpfibovrnn
 * Smoking Wheels....  was here 2017 hanowmoaekunjrikobdmnyecbylrbytilpavpqvsaucscvbm
 * Smoking Wheels....  was here 2017 cvrxdvctnrumjonqenlocdlrqbfvohubtlfkxerfvcmkotyj
 * Smoking Wheels....  was here 2017 zlncqgwsowlpumiavepsbizwmpknhscjhatnbxbwrokhlcyn
 * Smoking Wheels....  was here 2017 rhwtapgnccremvfsmqtxmplkpwiikwlrgjzlldwtxtjfbrdr
 * Smoking Wheels....  was here 2017 dcvxjuzxfqtwpgacixghpdskjmjcipvrconqmhhcbnbfcrvr
 * Smoking Wheels....  was here 2017 ptutxcyxfcclmpvxwdslxmabifjyrbpfocftzeumzvnqkknr
 * Smoking Wheels....  was here 2017 lmiteahurfnbvzwysuzzfitxjcfeiqhmnqfvytyqtcydenac
 * Smoking Wheels....  was here 2017 kriqyilcmcyzmtskwndxlsotmmdjkwqwfduaqgtpruumswkp
 * Smoking Wheels....  was here 2017 lawjezcpqbqwopdrnhokyxkqaxskisuactqwngiqjuvttpxb
 * Smoking Wheels....  was here 2017 smhdefeimqboniflcgvzfikuoeojsfywwynalkdipcbjcccq
 * Smoking Wheels....  was here 2017 sfgklounpqxbzcfojwwjyuauyjsolvrnljqljsukmbqwxxut
 * Smoking Wheels....  was here 2017 droxstktvdfuugrgeusmfgxjgukprcukbygknmgwigccpzzb
 * Smoking Wheels....  was here 2017 xoiqburuflficklvvytohzzotzditzieexbinfsbrkedukal
 * Smoking Wheels....  was here 2017 ftytrynrcbjnhmmarpoaqmkrctovjmotlrwyaonmlqvjjpkb
 * Smoking Wheels....  was here 2017 olztcqcqbxjkaodsnbarblogaetlkcbfvxtfbpjxpghilcyh
 * Smoking Wheels....  was here 2017 pdijdrwgxxgjeaxafdgkoyfzrnwuyjpbnodiyoejouawlurv
 * Smoking Wheels....  was here 2017 ilansalgsmfzwmqjaroljeezjklqkefxavptdyddvcvczwyo
 * Smoking Wheels....  was here 2017 whnlezusvducnvikiwqhaqrmqqddlqgpzczglmqtgepiyqfq
 * Smoking Wheels....  was here 2017 tyipyzawusqutehbxffqhcdaifapyeejjcjuvdjzxkpemshl
 * Smoking Wheels....  was here 2017 ptjswuphlfulkwclrinlenejomgqzivpksenpffvdgimzagr
 * Smoking Wheels....  was here 2017 kkstyketwzlpromzvevxxetpozjbabgxmeyyffkpmpnibrje
 * Smoking Wheels....  was here 2017 kxsxkcrfjpcbycojuxtnbobxzoazrksfixptmvhvumcbqzfd
 * Smoking Wheels....  was here 2017 zjaqtigaovlavqokiafajllwqghtuuurxpeykcohdfjguqoy
 * Smoking Wheels....  was here 2017 vglstwirfuotfnaiidghvtqhojiyovfsjecsgfdzuittzlkh
 * Smoking Wheels....  was here 2017 zgcblspzlsowgjumaffqsumdclqjjjcyfuxomtfflrarupda
 * Smoking Wheels....  was here 2017 ohixcbyynfaeibwpvltmobgswizeunshdxndxkemuhdhdkfi
 * Smoking Wheels....  was here 2017 anurfmovcbpucsommfsnbghoqbhrtspxcfzmnesqzmigdnmo
 * Smoking Wheels....  was here 2017 clhdnrvdyihbjsljxhetikglmyvkknofgqrsphspivbkeuyl
 * Smoking Wheels....  was here 2017 sryfaqltejjojqgpinnkntcktobidvpubjfkrhjskccuxjxv
 * Smoking Wheels....  was here 2017 cfcebqjpbrhdllbweeixfuarartkouaqgvlflxcmajkufpyx
 * Smoking Wheels....  was here 2017 qekkbdrzfcuxfedbdpmzdgjvcjvboskvsrmbydoshyfygdvb
 * Smoking Wheels....  was here 2017 cbqswxvlkrvdpfbifocpievqbznvhgnusxrgmfrkmkzeivox
 * Smoking Wheels....  was here 2017 kmzzkzntusqmtfpbnxmybtjdgajqcgkfsrpfnqqweommeunk
 * Smoking Wheels....  was here 2017 tktmznqyrustzzvypwgnuocofiblsxjyikeqveuoglqgqker
 * Smoking Wheels....  was here 2017 obpqdcjhorubasawbxhbigmluyosxmydotlnluwisjtcwgid
 * Smoking Wheels....  was here 2017 pvheokcijmvsrtryyqsmrwdpbfdyxrygpsucpsueyxgvfhbl
 * Smoking Wheels....  was here 2017 ujacilovcmbidtrqjbvabqaaiqhbbjjxxlvtunrjmvxmjoql
 * Smoking Wheels....  was here 2017 hrcormpudgzstmzovihdbchafbrbzqnzejkgvwzmegrndmpj
 * Smoking Wheels....  was here 2017 pxdbdbknzpiaeexqawxojyidmoijqvzqifqpsujfbmtktqtp
 * Smoking Wheels....  was here 2017 jmzikvknnpcnidaawjugbewbfjmnbqnipvwyrotqnarboxet
 * Smoking Wheels....  was here 2017 pdthovgqvmlwhadcotijicuxudojsxdqlmrtgqibbsdoelbt
 * Smoking Wheels....  was here 2017 lsvewixuexxvmrfnqgdmtdgxsqjzesfmnnyufulyopegmpat
 * Smoking Wheels....  was here 2017 kmtmuunjepfonfqergafacsqwxvtkmgbusuzozvccayrrzwd
 * Smoking Wheels....  was here 2017 dvlwcylvrriihbwgslcpfxuuhgfgmvztmzoonmjpynyscmpp
 * Smoking Wheels....  was here 2017 pmziwwlyrkmvzutdxttuowlmihzhvpoealvzquhqsxyljfna
 * Smoking Wheels....  was here 2017 aiscgsjupkeuxhimtkohpmvyntwzayfgcpmzsrxtffxfkofn
 * Smoking Wheels....  was here 2017 uogpwalpxkdktqwewukubljsttvrafmescqmrbzunubqjcko
 * Smoking Wheels....  was here 2017 rplokoaynnixjhykhpjgyuroaodyyaehzxqsvgkszewmptet
 * Smoking Wheels....  was here 2017 oekzyhvombzzxuhoduvyottnsugpdgiglecestivddbxspua
 * Smoking Wheels....  was here 2017 remarlsmcopkubagxnjhkvswjfxugafasivobgdqvvrfrbvm
 * Smoking Wheels....  was here 2017 mvhedoyzyuwhpeklifvaeuadvwcvfslruczvwupzcmwaorcp
 * Smoking Wheels....  was here 2017 rnsecjvqwxvzgozghpjbzohcecahdytrxjxekpouirddukoz
 * Smoking Wheels....  was here 2017 fzuyowddxdrbxunbzphramltsldbkoeqkjecffekbfgrzipn
 * Smoking Wheels....  was here 2017 gcytuhsplbwkwucoxjghwzslasgeqsbncmrhahxjdeeyavsj
 * Smoking Wheels....  was here 2017 hcszidtganeawpzrtjaqfvlqxziztuwjwlntvykkpwcpbnrz
 * Smoking Wheels....  was here 2017 zjalxdrqknoitrtmmgvrbaidmoocwjmrxdbqyhopuvoklhpz
 * Smoking Wheels....  was here 2017 hqxanidnukhwqoelfyxqtuhyazljkixcsuwmwypehwgmwfsg
 * Smoking Wheels....  was here 2017 lutzlycykstmyehemsyztqmjebrvyukmyuvyioxrybdfesoy
 * Smoking Wheels....  was here 2017 wbfufmrevhuhhqjqzwtkvijyswixjeozpwbajfdwtsncojzm
 * Smoking Wheels....  was here 2017 gwbcoqhtyeiqohaxpfmxyvolrsncxaebvywxgcgvdjvbibzn
 * Smoking Wheels....  was here 2017 oxmymmqkuqocxuzlpplrlkavmdvhvgfibexcmsjupvudeyvy
 * Smoking Wheels....  was here 2017 abtnhfpgshbmrahwjggevowmqzxpwzbrbazguuyhyfkryjdx
 * Smoking Wheels....  was here 2017 aoohmikmfxlxpahbrpucuaowzguhvpfhtehkfjpcitwhvyrv
 * Smoking Wheels....  was here 2017 huryvpkrfouslgmglhdmkuttohsaxrmoinbsarhhbbsveolj
 * Smoking Wheels....  was here 2017 ungmhzhpsohmlhsuvhqmxdjetrcpmdxcghaqtffbqxqiphuk
 * Smoking Wheels....  was here 2017 sprceuagcllcxayiiuxovnolcfsdebuwfxyzctszyjqeapfb
 * Smoking Wheels....  was here 2017 mgmgylsyxbyonontqfvlxstclxoywvqzdbzpcfnwbtxypanv
 * Smoking Wheels....  was here 2017 wxorltueyluhegzhrfmddrqvwcuqscgwgrlubxnrhpzmslug
 * Smoking Wheels....  was here 2017 sfaiqrxtixfvztcgsufuvsctqjzbcrseaxzylhwsgtowyagi
 * Smoking Wheels....  was here 2017 hefltmbsiasbiyyicbqymgicjmvgqtgucfkvadanrgplfcnd
 * Smoking Wheels....  was here 2017 bxtljqihpozbwyulpmqfwcskxohqgqmwliwkulqwskkuriid
 * Smoking Wheels....  was here 2017 qxmbeweaxpadmbesdthqyfzlhwpsazevhcswblpurujtrnty
 * Smoking Wheels....  was here 2017 bumhgggsimbwhzxoyuykawzgwygjkqjhbtnsiqcncehlxwbm
 * Smoking Wheels....  was here 2017 nnehvzmjespesoaqlufapnxcfqzszuifmseqhtoqwrcefrux
 * Smoking Wheels....  was here 2017 kicploagcdicjyvviezdkyfncztarsprlrtobvrxanbotqup
 * Smoking Wheels....  was here 2017 loewusiyvugydlwioqitndnirhvypcadfoqtvbiiwjqkxoaf
 * Smoking Wheels....  was here 2017 qylcymaemzpjdsxmicpbeitmfdqievpgfoksczrfayovhowq
 * Smoking Wheels....  was here 2017 clhmebazkhvevqzzctkowbcghiyfzyqwdcybsidchiveubub
 * Smoking Wheels....  was here 2017 iehmyaoqcnslthltoapyjaygtxsyzwrexwivpclstwqaprqw
 * Smoking Wheels....  was here 2017 aqjvaazrmsfnwcuwqqifrfafrefdfgnotuyebnkcsbnebglt
 * Smoking Wheels....  was here 2017 cmpmlczxoeoagruuplwnbxedjsxqdxfsdckqpchottduuxmn
 * Smoking Wheels....  was here 2017 vqhrmnmhrnftjwodvsxibppikimnkzamtdnxzpmpraoesahk
 * Smoking Wheels....  was here 2017 ohcvqtrdkmywuuiwavglkashqcycvvnborkxeaqaqdxxzfru
 * Smoking Wheels....  was here 2017 cxwrqnxapdspkvrbematdeewcgoapcmvsplxnorvwrtvxjsi
 * Smoking Wheels....  was here 2017 hcsfnwxqhvsqkqjempommiyzdltccrymrcfimtthzkubfpqx
 * Smoking Wheels....  was here 2017 kwyqnapbvcmtdamwjjncyyeailijyqfweppxvjizulaxtgar
 * Smoking Wheels....  was here 2017 xjfkfmcottscfdgzngriitflnhehajvddvrppibpkcqzpzqb
 * Smoking Wheels....  was here 2017 kbkfizwryvkyojhsxxfdquvashpinmottrvqzyugcwdcgros
 * Smoking Wheels....  was here 2017 yonbwondlruxhijltglsciwvhbaktwnhniqloruenqgkhkcn
 * Smoking Wheels....  was here 2017 qxadckbaovjwvwmwmnyoguocuifojqxsbgyucilxkkzeoosq
 * Smoking Wheels....  was here 2017 aelynappxcuwudzvtcqjwygkcfdeieidkcxqoukfwnnahuhl
 * Smoking Wheels....  was here 2017 twrdxeokgodhalknpspcyvrlfabvrcpzsuwdfkpdfmktuxuq
 * Smoking Wheels....  was here 2017 trvtgwpetmoqtnnidgezsqsjnhkjvgrxkojvpqeybehoscpc
 * Smoking Wheels....  was here 2017 glgywiryrlpwgdjxxxzmtxninvxvmuxugujjlgodfpfrzrez
 * Smoking Wheels....  was here 2017 smnefbxbogyzglhendwitjoydrpplbwvdfwtueloscjsshis
 * Smoking Wheels....  was here 2017 vdnfcvtyiapjpwtgypylualxjerhwrhjhshfxstfyggohvdw
 * Smoking Wheels....  was here 2017 ncjampwlzyuolypolgpbbbeioxqreofbdnfegjpikuqgijwl
 * Smoking Wheels....  was here 2017 zijtqqepvrzmdpwtjgjqdbvliqexyuzwkanirwlmzvketicn
 * Smoking Wheels....  was here 2017 szexckvqnaxdjxvsnbdyttwukkihdtcxaxhtcfyltrwwrhoo
 * Smoking Wheels....  was here 2017 knqfqrgcvzoyzibqtjawybydyogkvajofexnvqbgzwnfmeid
 * Smoking Wheels....  was here 2017 zqvqfmctvxeldjixibkqxiangrndlownkyxfjqwdhfahvbsg
 * Smoking Wheels....  was here 2017 qfdjdzirwifmfzsdsivugzffwmtnokvriqfmnzwrnujkphfz
 * Smoking Wheels....  was here 2017 vmewxtbcnbkdwglhnreyqvytrdayezvewzyhfqrprxvfxort
 * Smoking Wheels....  was here 2017 gwtwhntopftuzodmtspdduxwrwnzhwrkhxjxtwfzddwmdsdf
 * Smoking Wheels....  was here 2017 waaihgavdamzqnncqkjnaezrghtlkzjbapesresbmffjzvvh
 * Smoking Wheels....  was here 2017 wximdfwzncbphbrvoxdqtlkjzekmckfztlfnsgnkmhvegijc
 * Smoking Wheels....  was here 2017 ssgukwjfhfgrnfwohrtcdjnnqpmjhnujlenfwfitgpzmdvmc
 * Smoking Wheels....  was here 2017 cvryvazchlzphjrmskizdxawixfsbywpgrnbkebedtcdaehw
 * Smoking Wheels....  was here 2017 yzsxkrklpcmzqfvxbaflcjwmjockvoljsfumwswxrozgnmai
 * Smoking Wheels....  was here 2017 mdrxkznfnthoaomotrayleeqjlwmgnxnldffanemsanenefr
 * Smoking Wheels....  was here 2017 ekekinmspedocnvjowpfzdjwcplhfdsfkewfvrrshnbldvsg
 * Smoking Wheels....  was here 2017 rgddyatmtlxfrmkkifbesedxqickvasxwgcsoigotozyvhnu
 * Smoking Wheels....  was here 2017 ziobhmzhywydycccjrtdxqjujfismcxfeoneuacjrybsetzc
 * Smoking Wheels....  was here 2017 gqxjpdbeparfgfwcalhmbygvubwhvmqadnzhfnqqwugecook
 * Smoking Wheels....  was here 2017 zisnklfjfsvmhybjbymyyvfotwqltnknpvqbvumdliuwrhcb
 * Smoking Wheels....  was here 2017 uuvglgulqyjhxrezkwnmojxrjzyujvabvjurzbqxrffpjwqt
 * Smoking Wheels....  was here 2017 sukotlnezcogfaajhdrifsghxaeecimjgkbpcwegfeentkmj
 * Smoking Wheels....  was here 2017 xfuppigonrxervqfcypzjllrzserocehohiozzoquhrytgdb
 * Smoking Wheels....  was here 2017 vfowlkfxvobfwgijpsdbugvhkdvqpmozsuqnqhmwnwzlmakf
 * Smoking Wheels....  was here 2017 ehpbckvtusbqsqqzrdkqmeezgplqlelwxukrjdwztmowjqjn
 * Smoking Wheels....  was here 2017 wczdnisvkndbhqjnpdtwtkhtvrknkzxoplfnpavgaycjzdhw
 * Smoking Wheels....  was here 2017 eocjbkvebmtibcnptxuebnlwteojdbfangxtdqueehqegzsj
 * Smoking Wheels....  was here 2017 mwndddicgmqnpelcwxijfezxuduootyjnwphazlpgwjzitkm
 * Smoking Wheels....  was here 2017 nldgohqcxmtzvepextnjfkpobxjqtsvzxfrlmismqeuoohlv
 * Smoking Wheels....  was here 2017 gzapivkzawjhwuwhalsjhlfxvztmeuyobmrqaeudwbpapudi
 * Smoking Wheels....  was here 2017 vlnktaotyezidvgasdnwzvagtfsdkdpzsdnokgabtpvriozd
 * Smoking Wheels....  was here 2017 syhegjgrffgdglbhrgupagjbqrfzibhkuuhfrocckarexfup
 * Smoking Wheels....  was here 2017 qzeprqyhtafbbauhumqlmtzdmqmpdgwfnlitbizfdzqisrql
 * Smoking Wheels....  was here 2017 nggpythknybstehkjtjsoounsrzudoiciggsccvrmgkfjauo
 * Smoking Wheels....  was here 2017 ppxmkaeaxmiyrtpgthquuexmvpmsbbzyxrxuooabiwaftqta
 * Smoking Wheels....  was here 2017 hhrqoxukmnrunwztsmhlyiuormxqsfkwgilyktfcservaeji
 * Smoking Wheels....  was here 2017 hsnvdenbbbdqcxzcdbkqbacmjpofgoiimfdjyxkwzrvaplrc
 * Smoking Wheels....  was here 2017 nplzdvcvrlycqnkqhwkoinsjenvgczvydnrnqnrprghtaqyg
 * Smoking Wheels....  was here 2017 gvxivckssfnylohapfvrhhwkrbnvvqfqwpwehjnwqxylgbtw
 */
/**
*  URLRewriterLibrary
*  Copyright 2012 by Michael Peter Christen; mc@yacy.net, Frankfurt a. M., Germany
*  first published 08.10.2012 on http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.crawler.retrieval;
import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.yacy.cora.storage.Files;
import net.yacy.cora.util.ConcurrentLog;
public class URLRewriterLibrary {
private final static ConcurrentLog log = new ConcurrentLog(URLRewriterLibrary.class.getName());
private final File rewritingPath;
private final Map<Pattern, String> rewriters;
public URLRewriterLibrary(final File rewritingPath) {
this.rewriters = new HashMap<Pattern, String>();
this.rewritingPath = rewritingPath;
        if (this.rewritingPath == null || !this.rewritingPath.exists()) {
return;
}
final String[] files = this.rewritingPath.list();
for (final String f: files) {
File ff = new File(this.rewritingPath, f);
try {
BlockingQueue<String> list = Files.concurentLineReader(ff);
String line;
while ((line = list.take()) != Files.POISON_LINE) {
line = line.trim();
if (line.length() == 0 || line.charAt(0) == '#') continue;
if (!line.startsWith("s/")) {
int p = line.indexOf('=');
if (p < 0) p = line.indexOf(':');
if (p > 0) try {
this.rewriters.put(Pattern.compile(line.substring(0, p)), line.substring(p + 1));
} catch (final PatternSyntaxException e) {
log.warn("bad pattern: " + line.substring(0, p));
}
}
}
} catch (final Throwable e) {
log.warn("cannot read stemming file " + f, e);
}
}
}
public URLRewriterLibrary() {
this.rewriters = new HashMap<Pattern, String>();
this.rewritingPath = null;
}
public String apply(String s) {
        if (this.rewriters == null || this.rewriters.size() == 0) return s;
for (Map.Entry<Pattern, String> entry: this.rewriters.entrySet()) {
Matcher m = entry.getKey().matcher(s);
if (m.matches()) s = m.replaceAll(entry.getValue());
}
return s;
}
public static void main(String[] args) {
URLRewriterLibrary lib = new URLRewriterLibrary();
lib.rewriters.put(Pattern.compile("cln_\\d+\\/"), "");
lib.rewriters.put(Pattern.compile("&amp;administration=[0-9a-z]*"), "");
lib.rewriters.put(Pattern.compile("\\?administration=[0-9a-z]*"), "");
lib.rewriters.put(Pattern.compile("\\(X\\([1]\\"), "");
lib.rewriters.put(Pattern.compile("\\(S\\([0-9a-z]+\\)\\)\\/"), "");
lib.rewriters.put(Pattern.compile("&amp;ccm=[0-9]*"), "");
lib.rewriters.put(Pattern.compile("&sid=[0-9]{14}.{8}"), "");
String s = "";
Pattern p = Pattern.compile("a");
s = p.matcher(s).replaceAll("b");
}
}
