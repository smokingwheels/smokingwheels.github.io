/** 
 * Smoking Wheels....  was here 2017 gzerqhzyohflpmxjxycyljegcowihbgildgekydievlxvezu
 * Smoking Wheels....  was here 2017 sjnqnjyzokowekazagazixwitwihjxxiuuxowsgndmijckbz
 * Smoking Wheels....  was here 2017 prrmjmryvcwmypdcpktpznpoixjhbfmguoplbxziwgqvqnfp
 * Smoking Wheels....  was here 2017 phdujxsqdmrlfzzemdantufztbuqwezsomjvsikdntmafasr
 * Smoking Wheels....  was here 2017 mysfxeydlwydnrlwslxujluygvtaqfoqkrlztywkptfswnzi
 * Smoking Wheels....  was here 2017 lpkuqbjszxtdqeuesnqqsoraicrgjxrhzrkihcyawkncxwta
 * Smoking Wheels....  was here 2017 tmlunojagjnjqalebwsozklzsyenjfaadeystikagahnwhxk
 * Smoking Wheels....  was here 2017 cbjrtzntyjwxufckqdxhpmwxjtdcegonydcbvikrafqqoesl
 * Smoking Wheels....  was here 2017 gaxerwpbcgscrvsmnhgvfoccoassplmuutdplefpquygadoi
 * Smoking Wheels....  was here 2017 jkcjzzsewperahljbqzkssjctrgermgygnoxtekpwxwmncem
 * Smoking Wheels....  was here 2017 vifkpiesugqkyhugwnpoieitrukpseolfedrfuvrquhupgno
 * Smoking Wheels....  was here 2017 ehtvsfplphtlrrlovtxzlmuchrcjftiyuqxxkwnffdiscxun
 * Smoking Wheels....  was here 2017 hbljretmgcjduqjyagxstlukvykdapvlhcbvijwsbtkeavlo
 * Smoking Wheels....  was here 2017 hnjbgysbyfqecnskugvzdariukttdikbjcezcpkzyrcgqvdc
 * Smoking Wheels....  was here 2017 nyschovufnzjpbzbuefitoapxeuhwxwgwizcdcyduijiocwu
 * Smoking Wheels....  was here 2017 puaazismubzwpdvjuuukcoqhepjftkbtwsmeeqpkwghbnauq
 * Smoking Wheels....  was here 2017 jscntuceqfpzrvgazaphtvqsthqbpigktmzkbgqkphhhphkt
 * Smoking Wheels....  was here 2017 xtxrfrdeyowloqjyrdxerihkfaztlgxlcdyjzfryvozdctjp
 * Smoking Wheels....  was here 2017 qcsqjacagxgaiesinofpajggfxbjocqhtjetjaobkjhymqqx
 * Smoking Wheels....  was here 2017 cfazicpphjkwiizphzghfmgfuisinampxdqowmhbrhhkqgkn
 * Smoking Wheels....  was here 2017 fvpkomlwaidkzgblekcgylkrdudgckpjvrqblpgnafkioier
 * Smoking Wheels....  was here 2017 awmxrxsfqhqefjeumbzscibdtgryjyltdkrtfraggfhwosov
 * Smoking Wheels....  was here 2017 xoyupksdregcyhuvvjjevitmjryponrfscmjpgjhhqujeopp
 * Smoking Wheels....  was here 2017 mjlmngamwarhozpzcccjqzhrynxnggijqrcwhbkykbbmeiky
 * Smoking Wheels....  was here 2017 obttwamidetcoooyiddicdvcshqkhpoehjuofdmtbhmbqqmc
 * Smoking Wheels....  was here 2017 inxphkeytgqetlvryuuhdtqgevobqfuvgqbxmudpzmsfvjnl
 * Smoking Wheels....  was here 2017 badgsnkxfbsjegxhnlmtzdhabhgqpytukfqrpnemexpiismq
 * Smoking Wheels....  was here 2017 kaafhotzfsqucxmhxwblavpkiyrntyjrwbpvddsswfibwanr
 * Smoking Wheels....  was here 2017 ffghlcahtofwdomifznjyorsflxhwrwmyjeqcqbxmfgfoads
 * Smoking Wheels....  was here 2017 powjwyidbdrdzpdiuabtpkvnfokwztsjgpwpphtuuaayqnaf
 * Smoking Wheels....  was here 2017 whculbyaqijotswmgmhcfqpqalsikbourmllcrrlvynqrtbu
 * Smoking Wheels....  was here 2017 swnajtmuefyesujgmaxffswcrkubsujjhaxefnxfspwwmcol
 * Smoking Wheels....  was here 2017 xzwubounqdhkkzqhnqxafnrgjassqijcmjobxvsqaumobewi
 * Smoking Wheels....  was here 2017 prccdfwmisnwqqvouopueaiqpeycfiydvavohysnlqzutxtx
 * Smoking Wheels....  was here 2017 cboepvchrsallnjewfmzhmlbcxbjuswyerplwjryymgybmcv
 * Smoking Wheels....  was here 2017 crsonparkhlfckaqpiilxmwpvpzxxpberitrfwteuwlrugea
 * Smoking Wheels....  was here 2017 jfizkbntntroeosqcxdbstonzuuihjstreqoimfuksyvywkr
 * Smoking Wheels....  was here 2017 aqklwapvgsvclhqbscddrizkdkynbtgxsrtoinrppbimxhmg
 * Smoking Wheels....  was here 2017 mdgewnpkbzitzifcblwexmpcylbolplatnwkqkxrigpcdqik
 * Smoking Wheels....  was here 2017 hfirnucjsruoanefzodwwuhplhzvbaevutycyaahtwufmgec
 * Smoking Wheels....  was here 2017 iokrhkytdddzebmbpnwgezdfunxzqnrfgngxdjibluityxmm
 * Smoking Wheels....  was here 2017 senfucfvpxloeihpglkpuclonzevgrjjshjhkrktcbwvvkya
 * Smoking Wheels....  was here 2017 tgymayefpxdfcyczpwfiwkukjulpelatbuzbeockragusymj
 * Smoking Wheels....  was here 2017 cfdacemrvdvbgwprkmbgvlzvhgpnyxmbjzddcslklhqhjxim
 * Smoking Wheels....  was here 2017 pwwokiwggzlldgrivfyjizddnytiknaeadcvceufvslduyxo
 * Smoking Wheels....  was here 2017 jcfcrfmhdbbaplqxgidwhbnwosjwoybiopjpigssqjgnizyz
 * Smoking Wheels....  was here 2017 sdiwvuqjzedqpdvpfhfhwytvcszgraiyxfsegmaxuozunejl
 * Smoking Wheels....  was here 2017 glvkzlwgmkgknfzuptvjneqceenuiytrevdpmqueoyuodxjx
 * Smoking Wheels....  was here 2017 xulkopaaqchtwwcfntbdxmhzyuefidnlrtycysjajhasgvko
 * Smoking Wheels....  was here 2017 sbexgbezqxlfkliujmdtxzyayigisfcnakodvzhgzshidvfv
 * Smoking Wheels....  was here 2017 aogdzwrraobtfpcrrkputwgbxxkgscegbnvnoakykpowicrj
 * Smoking Wheels....  was here 2017 nrgoyibxlgukpheiiffyusacuxojyysjybsfuoukvmyvpaad
 * Smoking Wheels....  was here 2017 zdwzmxduzgnpbqlllxzgshinvvviedwuzemlkrtetfufbfsi
 * Smoking Wheels....  was here 2017 nxejhlboudjxkadyjrdzlpmvmopylierulrtqpxcxxtayqli
 * Smoking Wheels....  was here 2017 ngkyixbvkvtgrdsaszfoeybvnfmkbkgmfmbvxwafgwssvlex
 * Smoking Wheels....  was here 2017 pobgspukmjgtewvbiozthvxqxckaoocxkipsuhfvbswwmzbx
 * Smoking Wheels....  was here 2017 oqxzxbziccvtmimuiklolcbnwumlsfwwrdoqhwumuhnjzypo
 * Smoking Wheels....  was here 2017 ojzfnbvwkpowhzwdbqwgprwawednpyboqlmcowhadriioflh
 * Smoking Wheels....  was here 2017 xzncnqorxtwztljhcvtixxwzriyklsikewdvzvpmdefdvypt
 * Smoking Wheels....  was here 2017 gzbfbbumjpjfcqtrjpwmuhzkgovlwqrbilmwgnuezkhknofy
 * Smoking Wheels....  was here 2017 laigpvijsmyywszzyzfuxqervlyhqdgnnkwkhzdregyztrua
 * Smoking Wheels....  was here 2017 odjfssgqeatuxbedddbkeyviwxqtuwnyidszgmguksvatgzj
 * Smoking Wheels....  was here 2017 zmkjjvxwhaepeiwippywtnmddzoaqtfsqkvhpoxntfuwbjst
 * Smoking Wheels....  was here 2017 hozetjvvtpwoakszeapybwafpzplrwfpmefkxaggihadnmha
 * Smoking Wheels....  was here 2017 jcwlhwwqocryanquzkaqutlvmoxqtstlhrdnevpnruvtdfal
 * Smoking Wheels....  was here 2017 haacpdcoxctlxzxrjyndwfdngnwlwwhnqicdohlcnvyufntk
 * Smoking Wheels....  was here 2017 knulpfvehkmysmxvycozknqerycajgofjwxzlxscvtfqhmho
 * Smoking Wheels....  was here 2017 kdpyniqhmenmuykrnpywwfutsfmtsblfqgmcnnktwctxdnyx
 * Smoking Wheels....  was here 2017 aogitajykssnqmgygkqwxcrqowdfuqdlssesscwsbtymwicp
 * Smoking Wheels....  was here 2017 lstrxccmipgqbntmntyeldojttnhoqechslieysteumlstnb
 * Smoking Wheels....  was here 2017 awjczockrsmrcrhovbjiqrctazgdjadpezbqipsxeneffzbz
 * Smoking Wheels....  was here 2017 ilqfcraogbbvbypodcqaxebvhxdctwcrllbswuzmipgkflai
 * Smoking Wheels....  was here 2017 gegssaqazcvkmjoenuvhylnywckumqefoirtqpubbvawsstg
 * Smoking Wheels....  was here 2017 wahplhabdiaadkmjhjdiqnvpdjkcpzvkaclgwhtldhdsztae
 * Smoking Wheels....  was here 2017 nfzdgpmgepxpcssgcgcseroqxwudlttrsmczzissninjqsuu
 * Smoking Wheels....  was here 2017 wfvuherkvafgqeaiugmczlnddwkgndyttlryqprdmngklyea
 * Smoking Wheels....  was here 2017 tsqhyoipcyuihyihmghospukbalcpnonneljsbahlturkesc
 * Smoking Wheels....  was here 2017 fsjsynpceyulxkvammuigdsydcgotpbeoewtkzizecsjvgbk
 * Smoking Wheels....  was here 2017 sjhfdcsmowpmlgzsllnwvjvqdgmshfddudtvdykhqwxuhier
 * Smoking Wheels....  was here 2017 tfyjtojpzuuogjmufuexuuzmzvaztotdhbcpprimbroqovgu
 * Smoking Wheels....  was here 2017 gxcwflhklcjbwxhzxovnxgfvyjzxwacckceiqfkdyiarskty
 * Smoking Wheels....  was here 2017 hltscnoidhjpbhoevxsxzrxensulthpettmmmvfczzxdzyjp
 * Smoking Wheels....  was here 2017 gbdeluowohfaxdupqiinglpkkzcrseauesuwocpjfxehyqak
 * Smoking Wheels....  was here 2017 setsipvvldnmrirrenmedzdoonszfxgrtzckmtphvswwkvyi
 * Smoking Wheels....  was here 2017 onlcfkeguffixceanldwheoyhxvzcxmsyurjfvpkhhlqjepn
 * Smoking Wheels....  was here 2017 wbejtasnublfktlrcipuqyfbayvnjtfdgnahxpcnkrntdqql
 * Smoking Wheels....  was here 2017 zaerwmtcxonzfaytkrjmhqrumuiukjdjoyxwzpzsbfzpiibt
 * Smoking Wheels....  was here 2017 nvapsavwyuduqukskderttuertfbqyebzbjccphhnmzvqrak
 * Smoking Wheels....  was here 2017 jgkvtfvwwceyeetfdrajqcomukraywnewzqgfqjuhjwgdhao
 * Smoking Wheels....  was here 2017 pgkkouujwaucrpefzoguwrkijoaojtrwvhgvkzuacxhadcrr
 * Smoking Wheels....  was here 2017 pzfnevazkmiddsdwoghmqtumckysdogpspxoedjbwmdmefal
 * Smoking Wheels....  was here 2017 yzktrpdnhnkewljqrkydjwqazfiyvkhaqysleyefxrohadft
 * Smoking Wheels....  was here 2017 mxstnoyzlmzplxtfmaftruzggohvgrydymwshjnbrhyhtktv
 * Smoking Wheels....  was here 2017 iuepjpmscydzpoonhijqnodsjifglcrbgtwxttaiwmyqqagc
 * Smoking Wheels....  was here 2017 wtamdqdguthfkzestuxfcmsgboshrmdfkknsxolemnjqgbsg
 * Smoking Wheels....  was here 2017 ritxzamleaclecigscphtamwirtjmajjnkveloywtblziyie
 * Smoking Wheels....  was here 2017 pgeqihgigcjblczvgflueaoykekcsdmjyabnhwtydwnnzinc
 * Smoking Wheels....  was here 2017 ukgrvdqfhnhpyjhjtjsbilgzsycjjlzlhrrgqrnfkcfjlebl
 * Smoking Wheels....  was here 2017 obhglrwrtegzuntaubymipdvbbkgtwnakcncwnauoclwhnvx
 * Smoking Wheels....  was here 2017 nruwidpmjdxjhnbhhywxqabnkwhdjocujgncrfjytjiriwaj
 * Smoking Wheels....  was here 2017 nzmgwboscsbbxldugzmgxmbiyzvqcyxrpizlyuwfnvhrovdb
 * Smoking Wheels....  was here 2017 swklufxreoysmuemclcuaamxfekrxpjvqvlqwmblooxyihwl
 * Smoking Wheels....  was here 2017 jqvqyqyydlxebdrpluebewwzxpshcnetkmplwvvrwwcxcldd
 * Smoking Wheels....  was here 2017 etfinqgiqnpqxjhmdrmsuqcqzpqyguibyenwoqffrjadtrdc
 * Smoking Wheels....  was here 2017 zwkiyrpwrcwjpszwfcbvnzfessgedvztqekeyxoqmxangpin
 * Smoking Wheels....  was here 2017 vyioxodvntxbxoyrdieqibneouzxuioyczwuexkszoteyelw
 * Smoking Wheels....  was here 2017 chiihidwpjaoxnqclshqibqlgzlfndvdegonpfpoercmjnjt
 * Smoking Wheels....  was here 2017 lgvchgetrzyavnupzcgnynjauoonwlszzyoiyoflivfbibjd
 * Smoking Wheels....  was here 2017 rqrphwcmtzmthrhuxizixgtfkdllppkjvicmczpyvwluvlvf
 * Smoking Wheels....  was here 2017 xjvwzxzlaxvkaljqostiahepnomuuiiokvslhthvmxmtdnml
 * Smoking Wheels....  was here 2017 nrodhldeyrjwclljnqdzowezyxhtsmgymedawlcfgfejxnhl
 * Smoking Wheels....  was here 2017 bakwjtdmhhrgupgjqxvaxnplqnvrygbffikentdjjlrgvvlf
 * Smoking Wheels....  was here 2017 lcbwqjvkbcsxrbtibkxmrbmftzdfgzzhymtdeuswiligzbkx
 * Smoking Wheels....  was here 2017 swqbuaggltonofdedjppwmeyxerdqjljhdskztlnuhwmqdvy
 * Smoking Wheels....  was here 2017 hphtrutpxbqwkrvclhjvpbgjsdbrmidxbzbtjfbjvgbijfra
 * Smoking Wheels....  was here 2017 tspknyxhgdodolnovwbziiopefeegzcolaueazstqadkzreb
 * Smoking Wheels....  was here 2017 yyiutznhjggrppeelbqarcdxobdfuskgskdwvaserklqmfuh
 * Smoking Wheels....  was here 2017 zglxarsaobucgoazpckepjhwjkjrcgpenrrjzqqnrmqbesdc
 * Smoking Wheels....  was here 2017 gvgzfctygjqhozmbykuzgkqhglmsnkiurmclxiguqoocpige
 * Smoking Wheels....  was here 2017 hdgmnmfxfhjjwtgxhtqeatzggljrokotjvmbgyshuhkiokhl
 * Smoking Wheels....  was here 2017 ayffjkyzldwssbhetbysqekaoadfapmzwxalxlhqqmnrcssd
 * Smoking Wheels....  was here 2017 mecdlpblcnixwhvusoywzsgfsbgdyqosvehdcdpowgngmagr
 * Smoking Wheels....  was here 2017 cbgnqcuxshbwibgzuteefqbojogppmmicjawfolflwjkhpur
 * Smoking Wheels....  was here 2017 kbcvceucamusmigeuhjhtmqeoxcapffotmfpxlwurzetitod
 * Smoking Wheels....  was here 2017 iwlvhkwdzniuvfwzvdnhhzdjmsxyrhyherepdwgyzlheofzg
 * Smoking Wheels....  was here 2017 ymhnvnbivywtdcflgpzksgurrubgwicszkjkabcmchjujvvk
 * Smoking Wheels....  was here 2017 pcyernsfbotkmsursaecgmgxugfdmgkhalosapijayhaguzh
 * Smoking Wheels....  was here 2017 wevfztkqknpydwhcbfxeghhcwkfxcfvsjsunufyazwfkzmrw
 * Smoking Wheels....  was here 2017 rluleszpudjsrtqliceokjzqcvfempnwklhcfygylamwqnii
 * Smoking Wheels....  was here 2017 cwuvxemlnaehvuapywgnqtraakqvqcyyscpyncxydlumnwrb
 * Smoking Wheels....  was here 2017 mrdqcefsazjqsqyumbqpctybhfbayovkfklucerbbmarerqt
 * Smoking Wheels....  was here 2017 lhhjyzvfbdpuodblvicmfxquxpkbvddyyhwqpzqrlsgbihlk
 * Smoking Wheels....  was here 2017 vlatvdbaputdzmifbqqerztpdduqfhzmgadsyndhtzylckmd
 * Smoking Wheels....  was here 2017 tcjtlkbmwozjscybnfnzkyrzlrqpaqxevatnibtstkratxnj
 * Smoking Wheels....  was here 2017 onosrucbjhrgupjewohineztohnaqbnllalvedgajhiduymv
 * Smoking Wheels....  was here 2017 vcdatqtqublzoxiyxiqzmdlamikiotwbfzhpcnunwfclcyol
 * Smoking Wheels....  was here 2017 mpvmajxgdefxnesctnqzypfajjjcpcbwodmdcgqtsbitqofk
 * Smoking Wheels....  was here 2017 pyscewofrhbrmttouinnvqniuhvgusqczxowgqjorxrftrdc
 * Smoking Wheels....  was here 2017 njzcdcbbvflcnjxnpgvchmaulekxkofelbioadvzrczeykgg
 * Smoking Wheels....  was here 2017 vjezcjzqiayivxvjazhmtrnmghajauutznsgcpcizeliagvu
 * Smoking Wheels....  was here 2017 lqbmlfeyfbmtbmnwemyrxabqoitiktovznbdizldbaklatgx
 * Smoking Wheels....  was here 2017 kcppwjsjqyfyyoewlzaxqmzvtbaqqdynanvtzpngqtoshxga
 * Smoking Wheels....  was here 2017 dadpgwwkdmlvosfpjybqckwxppljzvrhzguujzcssqsnhutu
 * Smoking Wheels....  was here 2017 ewdyuagxluwnexjmxbvruhnybhyzzzrvyqzhgxhuniblwwze
 * Smoking Wheels....  was here 2017 kijkxjsymfjjigofbhhahxbekrpakaebhyqmmkjdnqzjbtjk
 * Smoking Wheels....  was here 2017 yjvzgpgtohczvezsfxtwohtfbrwkiooeqpgwgszmlqcjdjpv
 * Smoking Wheels....  was here 2017 dfuxtwhycxkgsiddaissutgwvijgbnpouiqfakwxgshxqwre
 * Smoking Wheels....  was here 2017 pitroiihvexihprzhhyjithepzyxdcgzxcumjgetgksojqtj
 * Smoking Wheels....  was here 2017 elnbdpexujonbenxdsltxczlrgtziqqihdyyhhenvptekihp
 * Smoking Wheels....  was here 2017 ymbackzbdcmnwkyvywmdkvrgnyfjrugupxqbxtlbuiaxzvzh
 * Smoking Wheels....  was here 2017 isrvjuaikfbdtziygfobafxjvdyfmmvuqbppqewkbalcsjud
 * Smoking Wheels....  was here 2017 wnvydaxmivwnyvlrzklfdunxqfuwhxgaorxoejlwxedkigxc
 * Smoking Wheels....  was here 2017 lsievqkqvgwabaesfmeqlhoddtyxxjtkrwtfljnaurmrweth
 * Smoking Wheels....  was here 2017 efdldlqcebehvatzhqynwvkqvothipudqdrzpksrlpcbrbcf
 * Smoking Wheels....  was here 2017 jfobxkxjwddejmqrvhiloppfluxbxlaqgflsaauxviywgavm
 * Smoking Wheels....  was here 2017 sfbmivugpomvxgmgsfbbydyxysfqeclqrbbhlzwyfjbtkmec
 * Smoking Wheels....  was here 2017 zxmmvhcxjqzoaohjzieksgoaoywpwygzfwubtjglcqxqfbof
 * Smoking Wheels....  was here 2017 igtbcmyokzwbmtfybxxtszteuigwcrwynddmclnddfcoxssg
 * Smoking Wheels....  was here 2017 cmekbmptelmdimtemjuofpbciyznddzxkowgyrmdjjmxbppx
 * Smoking Wheels....  was here 2017 xcgbvorjlclzxrnmekopnpjxfezynmppabalxxftaugjlbid
 * Smoking Wheels....  was here 2017 pstuvgakdhsxsmopfagwktswqoiubewxryvgycbmngutdulc
 * Smoking Wheels....  was here 2017 gkrnuhqfopionibkylcosdlocymwtugazpuffppervsekqpf
 * Smoking Wheels....  was here 2017 gihopuxhcwtulukdadqgqzcvhlajyhmjvtradxqxkyxavvuf
 * Smoking Wheels....  was here 2017 eyckjyjnofptsvieftqpqwnrgkvpdulriknsiugyzcmydtdz
 * Smoking Wheels....  was here 2017 yzwuphxxxytvwpvfricrhnukejbfdsjvttpouhtxvfxulads
 * Smoking Wheels....  was here 2017 pkqryqnujqiotmafubhspzfqnfdbzssaugjzqrsnthsrzomw
 * Smoking Wheels....  was here 2017 nkqigaosketxjdkicjsernkcbaqhzreshqpthmayrtwyinec
 * Smoking Wheels....  was here 2017 injhurpnuqqxamqznacvzsdyudnhsuspiwixlmrjwdmhghhj
 * Smoking Wheels....  was here 2017 vjpgwemfliwahqtxcznregnkwdvqwknogdvrasaluhynvokv
 * Smoking Wheels....  was here 2017 ezkfgghcqwpvxbwagkfydgwbvwaepfausxpndkqydixuifdy
 * Smoking Wheels....  was here 2017 soylvyhuwceexilmnvrdbysskksddcxtnykfgdjyyoflhjmj
 * Smoking Wheels....  was here 2017 aouktodbuchfrjftvyrajwzmoctuaeedvdftargtlpacnmpa
 * Smoking Wheels....  was here 2017 arsxlqozmfvhrjcmgsgosuqpnojubyavxtijjbqxcgsrbdzd
 * Smoking Wheels....  was here 2017 sxsxowswcawbssiqdipaatcqtqvzhzwalhhpmncfprygfihd
 * Smoking Wheels....  was here 2017 omapajxgekvjvaijbhiwmawkbiwoafkfhjudsqltzdpfndms
 * Smoking Wheels....  was here 2017 cuepajryjkjiigueyhcxmduaicjvutpanawzudtvlgueszut
 * Smoking Wheels....  was here 2017 fqynzkwatjjjunrqwhacswysvlklkcrjmlvkqcjznwyayoql
 * Smoking Wheels....  was here 2017 zyimngpumxxayfeudngrbfrbbgkfwuamucdxjtvawbqwkrsh
 * Smoking Wheels....  was here 2017 uxpqqzcvcvlgvattllkdtmnxtpzjmukuisoglrzamevbspyx
 * Smoking Wheels....  was here 2017 gagnkuaxggpcvvczotegdfihvvaevhszegcjnpxirvpgpqpg
 * Smoking Wheels....  was here 2017 eaawhgebanfzjveerloaxeenpnsiqpezrxbonpxkuvjhdmcm
 * Smoking Wheels....  was here 2017 svzszeprofmniiefbtxrajiemnkqakgymexhpxperhtiqacc
 * Smoking Wheels....  was here 2017 fqkgjnqhjdtosbnjkbqrocmagxshfqqiksliebtpgnqsqlps
 * Smoking Wheels....  was here 2017 gzszppxrflsfvyyzmdovbwicwbopvlgvooqqywmaucebxduh
 * Smoking Wheels....  was here 2017 rotrdyewakexfbjulzscbmauonbfofijhxtnuhbasytgmsdz
 * Smoking Wheels....  was here 2017 qhmipingbrifqvasrthtozwquepzopicgejkxrdjvbzkrdhh
 * Smoking Wheels....  was here 2017 mkeezuhjuboaeyiysxvgtplkibvbamwngdecrnmeavuxamfw
 * Smoking Wheels....  was here 2017 vkjsjobzzrlmdgaxlfcjywoedoqvobagksfpvqfrpvhjigdp
 * Smoking Wheels....  was here 2017 mzusffqfnvyxayagypdcxpigkfdvxrwhbesbfzpmaxwqqzmt
 * Smoking Wheels....  was here 2017 ocmdfnchtceyqknzqgdrnuafsytaebytwygcawgkaddwgryr
 * Smoking Wheels....  was here 2017 lysffmuwcjnlaizgcsrpztfwstcmpbwcqsnjrvymoxakrlmc
 * Smoking Wheels....  was here 2017 tbymlkgrhsppmocmdrmpqyugjabptvrbmmoxwqvawtqxssiz
 * Smoking Wheels....  was here 2017 hbzriviuhmirohviybpsfftrzjuylunmtmrzmifplnkelcwl
 * Smoking Wheels....  was here 2017 ezvummcnjfvkawkuucgeqomszoqmrowqbdhasepaahxlcmwz
 * Smoking Wheels....  was here 2017 uascwkwmavmoyaeaigzlagnedtggtckwhegvzsxiolczhcff
 * Smoking Wheels....  was here 2017 tqfaqxgkxixiqpylkhnivwsckgorfnbympnkxrdvhoalthdd
 * Smoking Wheels....  was here 2017 woajenajbdaapuqtccwtsccuzrriwfbtboiylercsmeroscx
 * Smoking Wheels....  was here 2017 htfdfygsrtzipykxvyjapabvkvzctwwmpohztkayohcwahuy
 * Smoking Wheels....  was here 2017 ikznqhiyhddcttsadglprycajvcdejeozibggxbkuhsiqddy
 * Smoking Wheels....  was here 2017 pzxcputypgckidhpxuwghiclxzxuqwwrgutuqnwurcfsfsjv
 * Smoking Wheels....  was here 2017 zfsnoaksonvrvfchgmsyezdjeyprzuguuenttessqpwwvqxv
 * Smoking Wheels....  was here 2017 pckweriolnkncjhbnoeygymirmnrftrbgzyswgfxlulxsumh
 * Smoking Wheels....  was here 2017 sugihwwcsbfuehiahmvtqntfeshxqqyxlwukhffmbcsgmjaz
 * Smoking Wheels....  was here 2017 butkevobcgyqhxxrmzjcudtaqzvturxblvauuvstsbwmwtsv
 * Smoking Wheels....  was here 2017 kusxfchoollkbhzrdzvairochwhumfujrcyefedfxoimypay
 * Smoking Wheels....  was here 2017 wudtblbxjevsgxuzqsnsgcnzpgzytxccscazumytjqqizvrv
 * Smoking Wheels....  was here 2017 uyffpxgpzjolxkstorwrrsemheqhxqlrkocawibjbrumnnoe
 * Smoking Wheels....  was here 2017 vuouctkndbesiqnkuossaajqkzcglqwtwmcgeknjfgvmkeyw
 * Smoking Wheels....  was here 2017 vawfwnjrupqxavcrliatywduchmjefmgmaixowqjiefgqjfc
 * Smoking Wheels....  was here 2017 vodnqzfkfobqvirlwebbkewmwxfpecukurhnhwzdconxnbch
 * Smoking Wheels....  was here 2017 grsxhdggwuvtuusyrpjdnhcomyxbsdmpretvsaksotrtpjoe
 * Smoking Wheels....  was here 2017 suaxbibamkolddworhrtttrawslainmohlsvmaylxiumqsur
 * Smoking Wheels....  was here 2017 aqwghalubtezmndaagawthqeiwzfupaextmsozzxpdhzssfy
 * Smoking Wheels....  was here 2017 hegyranwujubpisfaqqtlziqhewmfcoremmccdbvkhuhchok
 * Smoking Wheels....  was here 2017 xqkfdipuedunnfzjizawybifmtuxuwtlzlopnayihbdwjptu
 * Smoking Wheels....  was here 2017 lmxovgfjxcvmnctwuyaatbmxwypxebpfjnrhnkvsmcoggbaa
 * Smoking Wheels....  was here 2017 tlmtfigrbqujedwlnnodntuatjlbbcfwtzckyiyomgijwiug
 * Smoking Wheels....  was here 2017 ykduxisatjusgspavxxncfreovtgoqdqrhjkabwpaoeimgty
 * Smoking Wheels....  was here 2017 krdwwfayobglvljtjpqqsrqeakcqyobybcfcddmzakzmpaxu
 * Smoking Wheels....  was here 2017 trznfjrhdvtreiwczglgurmadljotbwlylrkzhvyuiumbbjr
 * Smoking Wheels....  was here 2017 tdlmkgnbnbguvkbttxjiyzjbcotqumudtnzqlqgctfcfxzrv
 * Smoking Wheels....  was here 2017 pzotcqpqyhvjpedpbssderpwlpotbmicauqhtjgfremsksmr
 * Smoking Wheels....  was here 2017 pmopfohnvjxingowmexeoyrfwpnzxacwrymagbtjnmwlcjsw
 * Smoking Wheels....  was here 2017 jbzmxidnykctwnzzxzteojmejyluvfcbtzlyqmtwntizukpj
 * Smoking Wheels....  was here 2017 umodpmzsgshafdlqlchdwtcbdfnsqlnrqcvgwqqhevifolqj
 */
package net.yacy.peers;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.yacy.Distribution;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.Domains;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.cora.protocol.http.HTTPClient;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.blob.MapDataMining;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.kelondroException;
import net.yacy.peers.operation.yacySeedUploader;
import net.yacy.search.Switchboard;
import net.yacy.server.serverCore;
import net.yacy.server.serverSwitch;
import net.yacy.server.http.AlternativeDomainNames;
public final class SeedDB implements AlternativeDomainNames {
private static final int dhtActivityMagic = 32;
/**
* <p><code>public static final String <strong>DBFILE_OWN_SEED</strong> = "mySeed.txt"</code></p>
* <p>Name of the file containing the database holding this peer's seed</p>
*/
public static final String DBFILE_OWN_SEED = "mySeed.txt";
public static final String[]      sortFields = new String[] {Seed.LCOUNT, Seed.RCOUNT, Seed.ICOUNT, Seed.UPTIME, Seed.VERSION, Seed.LASTSEEN};
public static final String[]   longaccFields = new String[] {Seed.LCOUNT, Seed.ICOUNT, Seed.ISPEED};
public static final String[] doubleaccFields = new String[] {Seed.RSPEED};
private File seedActiveDBFile, seedPassiveDBFile, seedPotentialDBFile;
private File myOwnSeedFile;
private MapDataMining seedActiveDB, seedPassiveDB, seedPotentialDB;
protected int lastSeedUpload_seedDBSize = 0;
public long lastSeedUpload_timeStamp = System.currentTimeMillis();
protected String lastSeedUpload_myIP = "";
public  PeerActions peerActions;
public  NewsPool newsPool;
private int netRedundancy;
public  Distribution scheme;
private Seed mySeed;
public SeedDB(
final File networkRoot,
final String seedActiveDBFileName,
final String seedPassiveDBFileName,
final String seedPotentialDBFileName,
final File myOwnSeedFile,
final int redundancy,
final int partitionExponent,
final boolean useTailCache,
final boolean exceed134217727) {
this.seedActiveDBFile = new File(networkRoot, seedActiveDBFileName);
this.seedPassiveDBFile = new File(networkRoot, seedPassiveDBFileName);
this.seedPotentialDBFile = new File(networkRoot, seedPotentialDBFileName);
this.mySeed = null;
this.myOwnSeedFile = myOwnSeedFile;
this.netRedundancy = redundancy;
this.scheme = new Distribution(partitionExponent);
this.seedActiveDB = openSeedTable(this.seedActiveDBFile);
this.seedPassiveDB = openSeedTable(this.seedPassiveDBFile);
this.seedPotentialDB = openSeedTable(this.seedPotentialDBFile);
removeMySeed();
this.lastSeedUpload_seedDBSize = sizeConnected();
this.newsPool = new NewsPool(networkRoot, useTailCache, exceed134217727);
this.peerActions = new PeerActions(this, this.newsPool);
}
public void relocate(
final File newNetworkRoot,
final int redundancy,
final int partitionExponent,
final boolean useTailCache,
final boolean exceed134217727) {
this.seedActiveDB.close();
this.seedPassiveDB.close();
this.seedPotentialDB.close();
this.newsPool.close();
this.peerActions.close();
this.seedActiveDBFile = new File(newNetworkRoot, this.seedActiveDBFile.getName());
this.seedPassiveDBFile = new File(newNetworkRoot, this.seedPassiveDBFile.getName());
this.seedPotentialDBFile = new File(newNetworkRoot, this.seedPotentialDBFile.getName());
final String peername = myName();
this.mySeed = null;
this.myOwnSeedFile = new File(newNetworkRoot, SeedDB.DBFILE_OWN_SEED);
this.netRedundancy = redundancy;
this.scheme = new Distribution(partitionExponent);
this.seedActiveDB = openSeedTable(this.seedActiveDBFile);
this.seedPassiveDB = openSeedTable(this.seedPassiveDBFile);
this.seedPotentialDB = openSeedTable(this.seedPotentialDBFile);
initMySeed();
this.mySeed.setName(peername);
removeMySeed();
this.lastSeedUpload_seedDBSize = sizeConnected();
this.newsPool = new NewsPool(newNetworkRoot, useTailCache, exceed134217727);
this.peerActions = new PeerActions(this, this.newsPool);
}
private synchronized void initMySeed() {
        if (this.mySeed != null) return;
        if (this.myOwnSeedFile.length() > 0) try {
this.mySeed = Seed.load(this.myOwnSeedFile);
if (this.mySeed == null) throw new IOException("current seed is null");
} catch (final IOException e) {
ConcurrentLog.severe("SEEDDB", "could not load stored mySeed.txt from " + this.myOwnSeedFile.toString() + ": " + e.getMessage() + ". creating new seed.", e);
this.mySeed = Seed.genLocalSeed(this);
try {
this.mySeed.save(this.myOwnSeedFile);
} catch (final IOException ee) {
ConcurrentLog.severe("SEEDDB", "error saving mySeed.txt (1) to " + this.myOwnSeedFile.toString() + ": " + ee.getMessage(), ee);
ConcurrentLog.logException(ee);
System.exit(-1);
}
} else {
ConcurrentLog.info("SEEDDB", "could not find stored mySeed.txt at " + this.myOwnSeedFile.toString() + ": " + ". creating new seed.");
this.mySeed = Seed.genLocalSeed(this);
try {
this.mySeed.save(this.myOwnSeedFile);
} catch (final IOException ee) {
ConcurrentLog.severe("SEEDDB", "error saving mySeed.txt (2) to " + this.myOwnSeedFile.toString() + ": " + ee.getMessage(), ee);
ConcurrentLog.logException(ee);
System.exit(-1);
}
}
this.mySeed.setIPs(Switchboard.getSwitchboard().myPublicIPs());
this.mySeed.put(Seed.PEERTYPE, Seed.PEERTYPE_VIRGIN);
}
public int redundancy() {
        if (this.mySeed.isVirgin()) return 1;
return this.netRedundancy;
}
public boolean mySeedIsDefined() {
return this.mySeed != null;
}
public Seed mySeed() {
        if (this.mySeed == null) {
if (sizeConnected() == 0) try {Thread.sleep(5000);} catch (final InterruptedException e) {} // wait for init
initMySeed();
}
return this.mySeed;
}
public void setMyName(final String name) {
this.mySeed.setName(name);
}
@Override
public String myAlternativeAddress() {
return mySeed().getName() + ".yacy";
}
@Deprecated
public String myIP() {
return mySeed().getIP();
}
@Override
public Set<String> myIPs() {
return mySeed().getIPs();
}
@Override
public int myPort() {
return mySeed().getPort();
}
@Override
public String myName() {
return this.mySeed.getName();
}
@Override
public String myID() {
return this.mySeed.hash;
}
public synchronized void removeMySeed() {
        if (this.seedActiveDB.isEmpty() && this.seedPassiveDB.isEmpty() && this.seedPotentialDB.isEmpty()) return; // avoid that the own seed is initialized too early
        if (this.mySeed == null) initMySeed();
try {
final byte[] mySeedHash = ASCII.getBytes(this.mySeed.hash);
this.seedActiveDB.delete(mySeedHash);
this.seedPassiveDB.delete(mySeedHash);
this.seedPotentialDB.delete(mySeedHash);
} catch (final IOException e) { ConcurrentLog.warn("yacySeedDB", "could not remove hash ("+ e.getClass() +"): "+ e.getMessage()); }
}
public void saveMySeed() {
try {
mySeed().save(this.myOwnSeedFile);
} catch (final IOException e) { ConcurrentLog.warn("yacySeedDB", "could not save mySeed '"+ this.myOwnSeedFile +"': "+ e.getMessage()); }
}
public boolean noDHTActivity() {
return sizeConnected() <= dhtActivityMagic;
}
private synchronized static MapDataMining openSeedTable(final File seedDBFile) {
final File parentDir = new File(seedDBFile.getParent());
        if (!parentDir.exists()) {
			if(!parentDir.mkdirs())
				ConcurrentLog.warn("yacySeedDB", "could not create directories for "+ seedDBFile.getParent());
		}
try {
return new MapDataMining(seedDBFile, Word.commonHashLength, Base64Order.enhancedCoder, 1024 * 512, 500, sortFields, longaccFields, doubleaccFields);
} catch (final Exception e) {
FileUtils.deletedelete(seedDBFile);
try {
return new MapDataMining(seedDBFile, Word.commonHashLength, Base64Order.enhancedCoder, 1024 * 512, 500, sortFields, longaccFields, doubleaccFields);
} catch (final IOException e1) {
ConcurrentLog.logException(e1);
System.exit(-1);
return null;
}
}
}
private synchronized MapDataMining resetSeedTable(MapDataMining seedDB, final File seedDBFile) {
Network.log.warn("seed-db " + seedDBFile.toString() + " reset (on-the-fly)");
seedDB.close();
FileUtils.deletedelete(seedDBFile);
        if (seedDBFile.exists())
	ConcurrentLog.warn("yacySeedDB", "could not delete file "+ seedDBFile);
seedDB = openSeedTable(seedDBFile);
return seedDB;
}
public synchronized void resetActiveTable() { this.seedActiveDB = resetSeedTable(this.seedActiveDB, this.seedActiveDBFile); }
private synchronized void resetPassiveTable() { this.seedPassiveDB = resetSeedTable(this.seedPassiveDB, this.seedPassiveDBFile); }
private synchronized void resetPotentialTable() { this.seedPotentialDB = resetSeedTable(this.seedPotentialDB, this.seedPotentialDBFile); }
public void close() {
        if (this.seedActiveDB != null) this.seedActiveDB.close();
        if (this.seedPassiveDB != null) this.seedPassiveDB.close();
        if (this.seedPotentialDB != null) this.seedPotentialDB.close();
this.newsPool.close();
this.peerActions.close();
}
public Iterator<Seed> seedsSortedConnected(final boolean up, final String field) {
return new seedEnum(up, field, this.seedActiveDB);
}
public Iterator<Seed> seedsSortedDisconnected(final boolean up, final String field) {
return new seedEnum(up, field, this.seedPassiveDB);
}
public Iterator<Seed> seedsSortedPotential(final boolean up, final String field) {
return new seedEnum(up, field, this.seedPotentialDB);
}
public TreeSet<byte[]> /* peer-b64-hashes/ipport */ clusterHashes(final String clusterdefinition) {
	final String[] addresses = (clusterdefinition.isEmpty()) ? new String[0] : CommonPattern.COMMA.split(clusterdefinition);
	final TreeSet<byte[]> clustermap = new TreeSet<>(Base64Order.enhancedCoder);
	Seed seed;
	String hash, yacydom;
	int p;
	for (final String addresse : addresses) {
		p = addresse.indexOf('=');
		if (p >= 0) {
			yacydom = addresse.substring(0, p);
		} else {
			yacydom = addresse;
		}
		if (yacydom.endsWith(".yacyh")) {
			// find a peer with its hexhash
			hash = Seed.hexHash2b64Hash(yacydom.substring(0, yacydom.length() - 6));
			seed = get(hash);
			if (seed == null) {
				Network.log.warn("cluster peer '" + yacydom + "' was not found.");
			} else {
				clustermap.add(ASCII.getBytes(hash));
			}
		} else if (yacydom.endsWith(".yacy")) {
			// find a peer with its name
			seed = lookupByName(yacydom.substring(0, yacydom.length() - 5));
			if (seed == null) {
				Network.log.warn("cluster peer '" + yacydom + "' was not found.");
			} else {
				clustermap.add(ASCII.getBytes(seed.hash));
			}
		} else {
			Network.log.warn("cluster peer '" + addresse + "' has wrong syntax. the name must end with .yacy or .yacyh");
		}
	}
	return clustermap;
}
public Iterator<Seed> seedsConnected(final boolean up, final boolean rot, final byte[] firstHash, final double minVersion) {
return new seedEnum(up, rot, (firstHash == null) ? null : firstHash, null, this.seedActiveDB, minVersion);
}
public Iterator<Seed> seedsDisconnected(final boolean up, final boolean rot, final byte[] firstHash, final double minVersion) {
return new seedEnum(up, rot, (firstHash == null) ? null : firstHash, null, this.seedPassiveDB, minVersion);
}
public Seed anySeedVersion(final double minVersion) {
final Iterator<Seed> e = seedsConnected(true, true, Seed.randomHash(), minVersion);
return e.next();
}
private final Map<Long, Integer> sizeActiveSince_result = new ConcurrentHashMap<>();
private final Map<Long, Long> sizeActiveSince_time = new ConcurrentHashMap<>();
/**
* count the number of peers that had been seen within the given time limit
* @param limitMinutes the time limit in minutes. 1440 minutes is a day
* @return the number of peers seen in the given time
*/
public int sizeActiveSince(final long limitMinutes) {
        long now = System.currentTimeMillis();
Integer s0 = sizeActiveSince_result.get(limitMinutes);
Long t0    = sizeActiveSince_time.get(limitMinutes);
        if (s0 == null || t0 == null || now - t0 > 60000) {
int s1 = sizeActiveSinceInt(limitMinutes);
sizeActiveSince_result.put(limitMinutes, s1);
sizeActiveSince_time.put(limitMinutes, now);
return s1;
}
return s0;        
}
private int sizeActiveSinceInt(final long limitMinutes) {
int c = this.seedActiveDB.size();
Seed seed;
Iterator<Seed> i = seedsSortedDisconnected(false, Seed.LASTSEEN);
while (i.hasNext()) {
seed = i.next();
if (seed != null) {
if (Math.abs((System.currentTimeMillis() - seed.getLastSeenUTC()) / 1000 / 60) > limitMinutes) break;
c++;
}
}
i = seedsSortedPotential(false, Seed.LASTSEEN);
while (i.hasNext()) {
seed = i.next();
if (seed != null) {
if (Math.abs((System.currentTimeMillis() - seed.getLastSeenUTC()) / 1000 / 60) > limitMinutes) break;
c++;
}
}
return c;
}
public int sizeConnected() {
return this.seedActiveDB.size();
}
public int sizeDisconnected() {
return this.seedPassiveDB.size();
}
public int sizePotential() {
return this.seedPotentialDB.size();
}
public long countActiveURL() { return this.seedActiveDB.getLongAcc(Seed.LCOUNT); }
public long countActiveRWI() { return this.seedActiveDB.getLongAcc(Seed.ICOUNT); }
public long countActivePPM() { return this.seedActiveDB.getLongAcc(Seed.ISPEED); }
public float countActiveQPM() { return this.seedActiveDB.getFloatAcc(Seed.RSPEED); }
public long countPassiveURL() { return this.seedPassiveDB.getLongAcc(Seed.LCOUNT); }
public long countPassiveRWI() { return this.seedPassiveDB.getLongAcc(Seed.ICOUNT); }
public long countPotentialURL() { return this.seedPotentialDB.getLongAcc(Seed.LCOUNT); }
public long countPotentialRWI() { return this.seedPotentialDB.getLongAcc(Seed.ICOUNT); }
public void addConnected(final Seed seed) {
        if (seed.isProper(false) != null) return;
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
synchronized (this) {
try {
this.seedActiveDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
this.seedPassiveDB.delete(ASCII.getBytes(seed.hash));
this.seedPotentialDB.delete(ASCII.getBytes(seed.hash));
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetActiveTable();
}
}
}
protected void addDisconnected(final Seed seed) {
        if (seed.isProper(false) != null) return;
synchronized (this) {
try {
this.seedActiveDB.delete(ASCII.getBytes(seed.hash));
this.seedPotentialDB.delete(ASCII.getBytes(seed.hash));
} catch (final Exception e) { ConcurrentLog.warn("yacySeedDB", "could not remove hash ("+ e.getClass() +"): "+ e.getMessage()); }
try {
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
this.seedPassiveDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetPassiveTable();
}
}
}
protected void addPotential(final Seed seed) {
        if (seed.isProper(false) != null) return;
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
synchronized (this) {
try {
this.seedActiveDB.delete(ASCII.getBytes(seed.hash));
this.seedPassiveDB.delete(ASCII.getBytes(seed.hash));
} catch (final Exception e) { ConcurrentLog.warn("yacySeedDB", "could not remove hash ("+ e.getClass() +"): "+ e.getMessage()); }
try {
this.seedPotentialDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetPotentialTable();
}
}
}
public synchronized void removeDisconnected(final String peerHash) {
	if (peerHash == null) return;
	try {
			this.seedPassiveDB.delete(ASCII.getBytes(peerHash));
		} catch (final IOException e) { ConcurrentLog.warn("yacySeedDB", "could not remove hash ("+ e.getClass() +"): "+ e.getMessage()); }
}
public synchronized void removePotential(final String peerHash) {
	if (peerHash == null) return;
	try {
			this.seedPotentialDB.delete(ASCII.getBytes(peerHash));
		} catch (final IOException e) { ConcurrentLog.warn("yacySeedDB", "could not remove hash ("+ e.getClass() +"): "+ e.getMessage()); }
}
public boolean hasConnected(final byte[] hash) {
return this.seedActiveDB.containsKey(hash);
}
public boolean hasDisconnected(final byte[] hash) {
return this.seedPassiveDB.containsKey(hash);
}
public boolean hasPotential(final byte[] hash) {
return this.seedPotentialDB.containsKey(hash);
}
private Seed get(final String hash, final MapDataMining database) {
        if (hash == null || hash.isEmpty()) return null;
        if ((this.mySeed != null) && (hash.equals(this.mySeed.hash))) return this.mySeed;
final ConcurrentHashMap<String, String> entry = new ConcurrentHashMap<String, String>();
try {
final Map<String, String> map = database.get(ASCII.getBytes(hash));
if (map == null) return null;
entry.putAll(map);
} catch (final IOException e) {
ConcurrentLog.logException(e);
return null;
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
return null;
}
return new Seed(hash, entry);
}
/**
* Get seed denoted by hash from the given database.
* If hash equals own peers hash, the own seed is returned
* !(regardless if included in given database)
* @param hash
* @param database
* @return seed with hash or null
*/
private Seed get(final byte[] hash, final MapDataMining database) {
        if (hash == null || hash.length == 0) return null;
        if ((this.mySeed != null) && (ASCII.String(hash).equals(this.mySeed.hash))) return this.mySeed;
final ConcurrentHashMap<String, String> entry = new ConcurrentHashMap<String, String>();
try {
final Map<String, String> map = database.get(hash);
if (map == null) return null;
entry.putAll(map);
} catch (final IOException e) {
ConcurrentLog.logException(e);
return null;
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
return null;
}
return new Seed(ASCII.String(hash), entry);
}
public Seed getConnected(final String hash) {
return get(hash, this.seedActiveDB);
}
public Seed getConnected(final byte[] hash) {
return get(hash, this.seedActiveDB);
}
public Seed getDisconnected(final String hash) {
return get(hash, this.seedPassiveDB);
}
public Seed getDisconnected(final byte[] hash) {
return get(hash, this.seedPassiveDB);
}
public Seed getPotential(final String hash) {
return get(hash, this.seedPotentialDB);
}
public Seed getPotential(final byte[] hash) {
return get(hash, this.seedPotentialDB);
}
public Seed get(final String hash) {
Seed seed = getConnected(hash);
        if (seed == null) seed = getDisconnected(hash);
        if (seed == null) seed = getPotential(hash);
return seed;
}
public void updateConnected(final Seed seed) {
        if (seed.isProper(false) != null) return;
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
synchronized (this) {
if (this.seedActiveDB.containsKey(ASCII.getBytes(seed.hash))) try {
this.seedActiveDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetActiveTable();
}
}
}
public void updateDisconnected(final Seed seed) {
        if (seed.isProper(false) != null) return;
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
synchronized (this) {
if (this.seedPassiveDB.containsKey(ASCII.getBytes(seed.hash))) try {
this.seedPassiveDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetActiveTable();
}
}
}
public void updatePotential(final Seed seed) {
        if (seed.isProper(false) != null) return;
final ConcurrentMap<String, String> seedPropMap = seed.getMap();
synchronized (this) {
if (this.seedPotentialDB.containsKey(ASCII.getBytes(seed.hash))) try {
this.seedPotentialDB.insert(ASCII.getBytes(seed.hash), seedPropMap);
} catch (final Exception e) {
Network.log.severe("ERROR add: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
resetActiveTable();
}
}
}
public Seed lookupByName(String peerName) {
        if (peerName.endsWith(".yacy")) peerName = peerName.substring(0, peerName.length() - 5);
        if (peerName.equals("localpeer")) {
if (this.mySeed == null) initMySeed();
return this.mySeed;
}
peerName = peerName.toLowerCase();
Seed seed;
String name = Seed.checkPeerName(peerName);
synchronized (this) { try {
Collection<byte[]> idx = this.seedActiveDB.select(Seed.NAME, name);
for (byte[] pk: idx) {
seed = this.getConnected(pk);
if (seed == null) continue;
return seed;
}
} catch (final  IOException e ) {
}}
synchronized (this) { try {
Collection<byte[]> idx = this.seedPassiveDB.select(Seed.NAME, name);
for (byte[] pk: idx) {
seed = this.getDisconnected(pk);
if (seed == null) continue;
return seed;
}
} catch (final  IOException e ) {
}}
        if (this.mySeed == null) initMySeed();
name = this.mySeed.getName().toLowerCase();
        if (name.equals(peerName)) return this.mySeed;
return null;
}
public Seed lookupByIPs(
final Set<String> peerIPs,
final int port,                 /* port may be -1 if not significant */
final boolean lookupConnected,
final boolean lookupDisconnected,
final boolean lookupPotential
) {
for (String i: peerIPs) {
Seed s = lookupByIP(Domains.dnsResolve(i), port, lookupConnected, lookupDisconnected, lookupPotential);
if (s != null) return s;
}
return null;
}
public Seed lookupByIP(
final InetAddress peerIP,
final int port,                 /* port may be -1 if not significant */
final boolean lookupConnected,
final boolean lookupDisconnected,
final boolean lookupPotential
) {
        if (peerIP == null) return null;
        if (Domains.isThisHostIP(peerIP)) {
if (this.mySeed == null) initMySeed();
if (port > 0 && this.mySeed.getPort() == port) return this.mySeed;
}
Seed seed = null;
String ipString = peerIP.getHostAddress();
        if (lookupConnected) {
try {
Collection<byte[]> idx = this.seedActiveDB.select(Seed.IP, ipString);
for (byte[] pk: idx) {
seed = this.getConnected(pk);
if (seed == null) continue;
if (port > 0 && seed.getPort() != port) continue;
return seed;
}
} catch (final IOException e ) {
ConcurrentLog.logException(e);
}
}
        if (lookupDisconnected) {
try {
Collection<byte[]> idx = this.seedPassiveDB.select(Seed.IP, ipString);
for (byte[] pk: idx) {
seed = this.getDisconnected(pk);
if (seed == null) continue;
if (port > 0 && seed.getPort() != port) continue;
return seed;
}
} catch (final IOException e ) {
ConcurrentLog.logException(e);
}
}
        if (lookupPotential) {
try {
Collection<byte[]> idx = this.seedPotentialDB.select(Seed.IP, ipString);
for (byte[] pk: idx) {
seed = this.getPotential(pk);
if (seed == null) continue;
if (port > 0 && seed.getPort() != port) continue;
return seed;
}
} catch (final IOException e ) {
ConcurrentLog.logException(e);
}
}
        if (this.mySeed == null || !this.mySeed.getIPs().contains(ipString)) return null;
int p = this.mySeed.getPort();
        if (port > 0 && p != port) return null;
return this.mySeed;
}
private ArrayList<String> storeSeedList(final File seedFile, final boolean addMySeed) throws IOException {
PrintWriter pw = null;
final ArrayList<String> v = new ArrayList<String>(this.seedActiveDB.size() + 1);
try {
pw = new PrintWriter(new BufferedWriter(new FileWriter(seedFile)));
List<Seed> seedlist = getSeedlist(Integer.MAX_VALUE, addMySeed, false, 0.0f);
String line;
for (Seed seed: seedlist) {
line = seed.genSeedStr(null);
v.add(line);
pw.print(line + serverCore.CRLF_STRING);
}
pw.flush();
} finally {
if (pw != null) try { pw.close(); } catch (final Exception e) {}
}
return v;
}
public ArrayList<Seed> getSeedlist(int maxcount, boolean addMySeed, boolean nodeonly, float minversion) {
final ArrayList<Seed> v = new ArrayList<Seed>(this.seedActiveDB.size() + 1000);
        if (addMySeed) v.add(this.mySeed);
Seed ys;
Iterator<Seed> se = this.seedsConnected(true, false, null, minversion);
while (se.hasNext() && v.size() < maxcount) {
ys = se.next();
if (ys != null && (!nodeonly || ys.getFlagRootNode())) v.add(ys);
}
se = this.seedsDisconnected(true, false, null, (float) 0.0);
final long timeout = System.currentTimeMillis() - (1000L * 60L * 60L * 24L);
while (se.hasNext() && v.size() < maxcount) {
ys = se.next();
if (ys != null && ys.getLastSeenUTC() >= timeout && (!nodeonly || ys.getFlagRootNode())) v.add(ys);
}
final StringBuilder encoded = new StringBuilder(1024);
for (Seed seed: v) {
encoded.append(seed.genSeedStr(null)).append(serverCore.CRLF_STRING);
}
return v;
}
protected String uploadSeedList(final yacySeedUploader uploader,
final serverSwitch sb,
final SeedDB seedDB,
final DigestURL seedURL) throws Exception {
        if (seedURL == null) throw new NullPointerException("UPLOAD - Error: URL not given");
String log = null;
File seedFile = null;
try {
seedFile = File.createTempFile("seedFile",".txt", seedDB.myOwnSeedFile.getParentFile());
if (Network.log.isFine()) Network.log.fine("SaveSeedList: Storing seedlist into tempfile " + seedFile.toString());
final ArrayList<String> uv = storeSeedList(seedFile, true);
if (Network.log.isFine()) Network.log.fine("SaveSeedList: Trying to upload seed-file, " + seedFile.length() + " bytes, " + uv.size() + " entries.");
log = uploader.uploadSeedFile(sb, seedFile);
if (Network.log.isFine()) Network.log.fine("SaveSeedList: Trying to download seed-file '" + seedURL + "'.");
final Iterator<String> check = downloadSeedFile(seedURL);
final String errorMsg = checkCache(uv, check);
if (errorMsg == null)
log = log + "UPLOAD CHECK - Success: the result vectors are equal" + serverCore.CRLF_STRING;
else {
throw new Exception("UPLOAD CHECK - Error: the result vector is different. " + errorMsg + serverCore.CRLF_STRING);
}
} finally {
if (seedFile != null)
				try {
				    FileUtils.deletedelete(seedFile);
				} catch (final Exception e) {
					/* ignore this */
				}
}
return log;
}
private static Iterator<String> downloadSeedFile(final DigestURL seedURL) throws IOException {
final RequestHeader reqHeader = new RequestHeader();
reqHeader.put(HeaderFramework.PRAGMA, "no-cache");
reqHeader.put(HeaderFramework.CACHE_CONTROL, "no-cache, no-store");
reqHeader.put(HeaderFramework.USER_AGENT, ClientIdentification.yacyInternetCrawlerAgent.userAgent);
final HTTPClient client = new HTTPClient(ClientIdentification.yacyInternetCrawlerAgent);
client.setHeader(reqHeader.entrySet());
byte[] content = null;
try {
	content = client.GETbytes(seedURL, null, null, false);
} catch (final Exception e) {
	throw new IOException("Unable to download seed file '" + seedURL + "'. " + e.getMessage());
}
        if (client.getHttpResponse().getStatusLine().getStatusCode() != 200) {
	throw new IOException("Server returned status: " + client.getHttpResponse().getStatusLine());
}
try {
content = FileUtils.uncompressGZipArray(content);
return FileUtils.strings(content);
} catch (final Exception e) {
	throw new IOException("Unable to uncompress seed file '" + seedURL + "'. " + e.getMessage());
}
}
private static String checkCache(final ArrayList<String> uv, final Iterator<String> check) {
        if ((check == null) || (uv == null)) {
if (Network.log.isFine()) Network.log.fine("SaveSeedList: Local and uploades seed-list are different");
return "Entry count is different: uv.size() = " + ((uv == null) ? "null" : Integer.toString(uv.size()));
}
        if (Network.log.isFine()) Network.log.fine("SaveSeedList: Comparing local and uploades seed-list entries ...");
int i = 0;
while (check.hasNext() && i < uv.size()) {
	if (!((uv.get(i)).equals(check.next()))) return "Element at position " + i + " is different.";
	i++;
}
return null;
}
/**
* resolve a yacy address
* http://PEERHASH.yacyh or http://PEERNAME.yacy
* or deprecated  http://subdom.PEERNAME.yacy resolved to http://host:port/subdom (no matching target servlets)
* to the actual host:port
*/
@Override
public String resolve(String host) {
Seed seed;
int p;
String subdom = null;
        if (host.endsWith(".yacyh")) {
p = host.indexOf('.');
if ((p > 0) && (p != (host.length() - 6))) {
subdom = host.substring(0, p);
host = host.substring(p + 1);
}
String hash = host.substring(0, host.length() - 6);
if (hash.length() > Word.commonHashLength) {
hash = Seed.hexHash2b64Hash(hash);
}
seed = getConnected(hash);
if (seed == null) {
if (this.mySeed == null) initMySeed();
if (hash.equals(this.mySeed.hash))
seed = this.mySeed;
else return null;
}
return seed.getPublicAddress(seed.getIP()) + ((subdom == null) ? "" : ("/" + subdom));
} else if (host.endsWith(".yacy")) {
p = host.indexOf('.');
if ((p > 0) && (p != (host.length() - 5))) {
subdom = host.substring(0, p);
host = host.substring(p + 1);
}
final String domain = host.substring(0, host.length() - 5).toLowerCase();
seed = lookupByName(domain);
if (seed == null) return null;
if (this.mySeed == null) initMySeed();
if (seed == this.mySeed && !(seed.isOnline())) {
return Switchboard.getSwitchboard().myPublicIP() + ":" + Switchboard.getSwitchboard().getLocalPort() + ((subdom == null) ? "" : ("/" + subdom));
}
return seed.getPublicAddress(seed.getIP()) + ((subdom == null) ? "" : ("/" + subdom));
} else {
return null;
}
}
private class seedEnum implements Iterator<Seed> {
private Iterator<Map.Entry<byte[], Map<String, String>>> it;
private Seed nextSeed;
private final MapDataMining database;
private double minVersion;
private seedEnum(final boolean up, final boolean rot, final byte[] firstKey, final byte[] secondKey, final MapDataMining database, final double minVersion) {
this.database = database;
this.minVersion = minVersion;
try {
this.it = (firstKey == null) ? database.entries(up, rot) : database.entries(up, rot, firstKey, secondKey);
double version;
while (true) {
this.nextSeed = internalNext();
if (this.nextSeed == null) break;
version = this.nextSeed.getVersion();
if (version >= this.minVersion || version == 0.0) break;
}
} catch (final IOException e) {
ConcurrentLog.logException(e);
Network.log.severe("ERROR seedLinEnum: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
if (database == SeedDB.this.seedActiveDB) SeedDB.this.seedActiveDB = resetSeedTable(SeedDB.this.seedActiveDB, SeedDB.this.seedActiveDBFile);
if (database == SeedDB.this.seedPassiveDB) SeedDB.this.seedPassiveDB = resetSeedTable(SeedDB.this.seedPassiveDB, SeedDB.this.seedPassiveDBFile);
this.it = null;
} catch (final kelondroException e) {
ConcurrentLog.logException(e);
Network.log.severe("ERROR seedLinEnum: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
if (database == SeedDB.this.seedActiveDB) SeedDB.this.seedActiveDB = resetSeedTable(SeedDB.this.seedActiveDB, SeedDB.this.seedActiveDBFile);
if (database == SeedDB.this.seedPassiveDB) SeedDB.this.seedPassiveDB = resetSeedTable(SeedDB.this.seedPassiveDB, SeedDB.this.seedPassiveDBFile);
this.it = null;
}
}
private seedEnum(final boolean up, final String field, final MapDataMining database) {
this.database = database;
try {
this.it = database.entries(up, field);
this.nextSeed = internalNext();
} catch (final kelondroException e) {
ConcurrentLog.logException(e);
Network.log.severe("ERROR seedLinEnum: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
if (database == SeedDB.this.seedActiveDB) SeedDB.this.seedActiveDB = resetSeedTable(SeedDB.this.seedActiveDB, SeedDB.this.seedActiveDBFile);
if (database == SeedDB.this.seedPassiveDB) SeedDB.this.seedPassiveDB = resetSeedTable(SeedDB.this.seedPassiveDB, SeedDB.this.seedPassiveDBFile);
if (database == SeedDB.this.seedPotentialDB) SeedDB.this.seedPotentialDB = resetSeedTable(SeedDB.this.seedPotentialDB, SeedDB.this.seedPotentialDBFile);
this.it = null;
}
}
@Override
public boolean hasNext() {
return (this.nextSeed != null);
}
private Seed internalNext() {
if (this.it == null || !(this.it.hasNext())) return null;
try {
Map.Entry<byte[], Map<String, String>> dna;
while (this.it.hasNext()) {
try {
dna = this.it.next();
} catch (final OutOfMemoryError e) {
ConcurrentLog.logException(e);
dna = null;
}
assert dna != null;
if (dna == null) continue;
if (dna.getKey() == null) continue;
return new Seed(dna);
}
return null;
} catch (final Exception e) {
ConcurrentLog.logException(e);
Network.log.severe("ERROR internalNext: seed.db corrupt (" + e.getMessage() + "); resetting seed.db", e);
if (this.database == SeedDB.this.seedActiveDB) SeedDB.this.seedActiveDB = resetSeedTable(SeedDB.this.seedActiveDB, SeedDB.this.seedActiveDBFile);
if (this.database == SeedDB.this.seedPassiveDB) SeedDB.this.seedPassiveDB = resetSeedTable(SeedDB.this.seedPassiveDB, SeedDB.this.seedPassiveDBFile);
if (this.database == SeedDB.this.seedPotentialDB) SeedDB.this.seedPotentialDB = resetSeedTable(SeedDB.this.seedPotentialDB, SeedDB.this.seedPotentialDBFile);
return null;
}
}
@Override
public Seed next() {
final Seed seed = this.nextSeed;
double version;
try {while (true) {
this.nextSeed = internalNext();
if (this.nextSeed == null) break;
version = this.nextSeed.getVersion();
if (version >= this.minVersion || version == 0.0) break;
}} catch (final kelondroException e) {
ConcurrentLog.logException(e);
	Network.log.severe("seed-db emergency reset", e);
	this.database.clear();
				this.nextSeed = null;
				return null;
}
return seed;
}
@Override
public void remove() {
throw new UnsupportedOperationException();
}
}
public void loadSeedListConcurrently(final String seedListFileURL, final AtomicInteger scc, final int timeout, final boolean checkAge) {
Thread seedLoader = new Thread("SeedDB.loadSeedListConcurrently") {
@Override
public void run() {
try {
DigestURL url = new DigestURL(seedListFileURL);
final RequestHeader reqHeader = new RequestHeader();
reqHeader.put(HeaderFramework.PRAGMA, "no-cache");
reqHeader.put(HeaderFramework.CACHE_CONTROL, "no-cache, no-store");
final HTTPClient client = new HTTPClient(ClientIdentification.yacyInternetCrawlerAgent, timeout);
client.setHeader(reqHeader.entrySet());
client.HEADResponse(url.toNormalform(false), false);
int statusCode = client.getHttpResponse().getStatusLine().getStatusCode();
ResponseHeader header = new ResponseHeader(statusCode, client.getHttpResponse().getAllHeaders());
if (checkAge) {
if (header.lastModified() == null) {
Network.log.warn("BOOTSTRAP: seed-list URL " + seedListFileURL + " not usable, last-modified is missing");
return;
} else if ((header.age() > 86400000) && (scc.get() > 0)) {
Network.log.info("BOOTSTRAP: seed-list URL " + seedListFileURL + " too old (" + (header.age() / 86400000) + " days)");
return;
}
}
scc.incrementAndGet();
final byte[] content = client.GETbytes(url, null, null, false);
Iterator<String> enu = FileUtils.strings(content);
int lc = 0;
int uptodatec = 0, outdatedc = 0;
while (enu.hasNext()) {
try {
Seed ys = Seed.genRemoteSeed(enu.next(), false, null);
if ((ys != null) && (!mySeedIsDefined() || !mySeed().hash.equals(ys.hash))) {
final long lastseen = Math.abs((System.currentTimeMillis() - ys.getLastSeenUTC()) / 1000 / 60);
if (lastseen < 240) uptodatec++; else outdatedc++;
if ( lastseen < 240 || lc < 10 ) {
if (peerActions.connectPeer(ys, false) ) lc++;
}
}
} catch (final Throwable e ) {
Network.log.info("BOOTSTRAP: bad seed from " + seedListFileURL + ": " + e.getMessage());
}
}
Network.log.info("BOOTSTRAP: " + lc + " seeds from seed-list URL " + seedListFileURL + ", AGE=" + (header.age() / 3600000) + "h" + ", uptodatec = " + uptodatec + ", outdatedc = " + outdatedc);
} catch (final IOException e ) {
Network.log.info("BOOTSTRAP: failed (1) to load seeds from seed-list URL " + seedListFileURL + ": " + e.getMessage());
} catch (final Exception e ) {
Network.log.severe("BOOTSTRAP: failed (2) to load seeds from seed-list URL " + seedListFileURL + ": " + e.getMessage(), e);
}
}
};
seedLoader.start();
}
}
