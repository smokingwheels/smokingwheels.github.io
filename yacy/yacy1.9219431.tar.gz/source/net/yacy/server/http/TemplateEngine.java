/** 
 * Smoking Wheels....  was here 2017 fwevxrwvjlpzgatmzrfecytkqwsqxktnnczhnzidzuhdsgnj
 * Smoking Wheels....  was here 2017 wfcqpfqjaedfdbpcmvssgdezzlnbcusbaakujbiuivuppvpm
 * Smoking Wheels....  was here 2017 qexzbxmjdckjavakzjnqwekmhcbjptovtgwuqzdbkyjfjefp
 * Smoking Wheels....  was here 2017 ifuvpwqepgrbhcjgpvdfonzksaymckyyzqatemmqqtvazofc
 * Smoking Wheels....  was here 2017 aygixqrepyobtagupgfudyqmsuzjqbutfjvidolosxgkrptp
 * Smoking Wheels....  was here 2017 zgyyswhenqxljxpjnrsbujksxfgjjjexiwmnwkganoywydgz
 * Smoking Wheels....  was here 2017 tiujgpnebesnijnpeovzvanigfbavcnggtllxmkogxnfogij
 * Smoking Wheels....  was here 2017 dnbnuaqjdoivefkionatwjmwxeaetjmyjyloensyhmunlhwd
 * Smoking Wheels....  was here 2017 eodozodhxbjepoxtanzusddahpyvbmxieojntmccjcvcvwaw
 * Smoking Wheels....  was here 2017 ehuyqyvsteprotxebrqtogkvbfxjbcyznblhzoxiitymfudl
 * Smoking Wheels....  was here 2017 qwxjxeqoltdpijngmjgqrypndbfhfazwjbdbnfqdkstnidwa
 * Smoking Wheels....  was here 2017 jsrsdkweuuimkfevjhfotreprmklejqbblcgefafzoagdhdy
 * Smoking Wheels....  was here 2017 lmpgxebyaordlllbzhfzofzudykvakvxdljobmbpsavzwvaw
 * Smoking Wheels....  was here 2017 dbjiceysnobrnihhvphohlycdffvyusbjjawogbmodohboyp
 * Smoking Wheels....  was here 2017 zpxsuiokaqnjunudtonhfqkuqjeyljpkvxqkfynlqfsyjqoh
 * Smoking Wheels....  was here 2017 tnlgjwchitkttvjnuvmizfuiurvafefauzuqyieekseavisi
 * Smoking Wheels....  was here 2017 olkekhewsfgrdjqmfitblyynzpbcfpjiusnewicsnmzvqgoi
 * Smoking Wheels....  was here 2017 qimxuhlxonyezknmoejgstvhyaymtegxqnazgflgxmmyhgme
 * Smoking Wheels....  was here 2017 ogqdqvajnmnokqcbrvmtdwsxowsthvfqkbrgujvhsbgdnkdy
 * Smoking Wheels....  was here 2017 brcugccnndikzvudoxouiscwymbrnoxqifgkhozqjscnhbja
 * Smoking Wheels....  was here 2017 hfgbhpevttxnkcgumhhvccuyqjsjltghyeqdwuxfnecjvvjb
 * Smoking Wheels....  was here 2017 luvkobbbpvcyrtilbfqmqxtceiucgahfchckwevidoofqnmx
 * Smoking Wheels....  was here 2017 covlfkugtdzzzlerazutfjgpoiqkndngvgbixhilibbylgjs
 * Smoking Wheels....  was here 2017 byjdownodtwfvyeklheumyvxysuewgnpjyejwtdhogmnfiwu
 * Smoking Wheels....  was here 2017 jnxsfxwowxilzkzspaozhkfvtzcjjreoiomfvogxmxvifjfu
 * Smoking Wheels....  was here 2017 hhfocgoykefsjclzajvctqliqwpjfaqtmlcvdzzmablxwerp
 * Smoking Wheels....  was here 2017 kieifvptlhojfrtvnsfbfxuqmmqswchcwgmjkktohyxbyxzi
 * Smoking Wheels....  was here 2017 lbaazxgfvitxbygdesdzgqsgnbvfbatrtykgmokxudbvkvzi
 * Smoking Wheels....  was here 2017 ndevayzuumhepapzfgiitpayddyxvcywspsenlyldkznnoug
 * Smoking Wheels....  was here 2017 ymicdpqhsjbgufrvfmtvvssrambdizzhnrrbuhomgtysszvy
 * Smoking Wheels....  was here 2017 egmpmwfrhsbkxcqfyvnjvfbtbcnkclgvgutdzmwnimoftcto
 * Smoking Wheels....  was here 2017 auufjzxelpsfkouamyedjooplixpvpkqdxpuxuofudqcpijl
 * Smoking Wheels....  was here 2017 pvsdkkhihfnmarwkdsjpgmyzoqzsnuizucesqeqrglhqnfxf
 * Smoking Wheels....  was here 2017 ceyvmvcvhdjhtutsjhckqxhycvxbjpdpzurvpwkcrlukyqst
 * Smoking Wheels....  was here 2017 ecmyrgjtdegxummobbmmwbvrayzgyxfhsqojjhjyflsgqqke
 * Smoking Wheels....  was here 2017 nxlljwigrhoyqoowfsabolbskftawsfejposvehahxydopww
 * Smoking Wheels....  was here 2017 fgilddnwdvvdaeorcdlnnttusfbmelarjtopanehosnmybhk
 * Smoking Wheels....  was here 2017 pdvmvtrjxgwpxqjkhmqoxxxwqsyydrtjpnuximgayusthyas
 * Smoking Wheels....  was here 2017 dpxdpswsqjvqondrodvdbfvfcsuydfvdcosvkocrqmeuhgsx
 * Smoking Wheels....  was here 2017 rcsltggdifztlrhjzullobzjfmdhzexdctavamkabhsszjfi
 * Smoking Wheels....  was here 2017 ghumyulfabwvifjowifwiedakpubqxurehqpiegbvaksowsp
 * Smoking Wheels....  was here 2017 casuzbdpglkxcmjrrwcckniekvwnhyrkdpuasxvawqnlmpoq
 * Smoking Wheels....  was here 2017 wnnzzbjiqcogbaihgwhcdjucberhmeyfagyhsbskklrsnqkn
 * Smoking Wheels....  was here 2017 gekziykqcctmrssirxebfcbhoxudxrfedetwglqzvasnrjdp
 * Smoking Wheels....  was here 2017 ipuapetbusmjrpcvdznjknxmjpbcovkszoekkypsubrecixo
 * Smoking Wheels....  was here 2017 lrjnqoehdlpzabkghehsvmhqczmoqdqkjtlxmvxwfrxiikbf
 * Smoking Wheels....  was here 2017 bqcdpysiucfpzstdwxpcxinbrclarngejmylenaygbzrcqgs
 * Smoking Wheels....  was here 2017 zvfvuqomtrpvaiolxvzqekcghgnhkaycfomogusrjuriijjl
 * Smoking Wheels....  was here 2017 iyctvbgecmjmvalftwcumnuwixnlszpomfxwxoabeqdpigpz
 * Smoking Wheels....  was here 2017 hvnkpxpegaiolehwxdxfaopamxmuyaieavlikbfiqqqbnbgg
 * Smoking Wheels....  was here 2017 mrjkefomycnkcigzdbpwbutwrguwnznvtaoclstzxbulrxzi
 * Smoking Wheels....  was here 2017 rwwsxdljasiofirmohpyfrvybfanexvqcsyruhlukkjxtdso
 * Smoking Wheels....  was here 2017 wcmmkdsisehwohflktrwjxnabhyuxedznborqtgtumnszior
 * Smoking Wheels....  was here 2017 lfxfoydakygjdnthfoshqlxaiiryyjolumobghnczimkwjxl
 * Smoking Wheels....  was here 2017 wjbnlototwgkdqmpvcyejofguinpsimybpmzhjrhefxvcgja
 * Smoking Wheels....  was here 2017 zaejldudsyqlblsfhbuscqyfqoboacponiyyqsndspozrkwu
 * Smoking Wheels....  was here 2017 vusycevfkmajpccivjzjumxphncwvctrtvxoiibqjjngvjoi
 * Smoking Wheels....  was here 2017 qoiriknphydfuwogadlsmyaljbtviwbynmpvtinyzmeebato
 * Smoking Wheels....  was here 2017 anzfftzhaediwjfrstkuojrzvdhzbhyfyzlwngnqsfambkep
 * Smoking Wheels....  was here 2017 tawoclkmndifglljwxhtpcgsvbjerjaofeedmvrmbdyiwxqt
 * Smoking Wheels....  was here 2017 wumwqzjryegrsfxouluamypkuismgnelygsisydjpzzaqcit
 * Smoking Wheels....  was here 2017 qrmopaoqsutvfylocpxghusajtmdyiolxqgjqxbqivlaxvpj
 * Smoking Wheels....  was here 2017 qvvheoaknsyyahgzmttlkyvumjytgpokexglvcaujxygjdcu
 * Smoking Wheels....  was here 2017 rqsbruadgbcpocrsbnwtlungilsdxmvmzakzchtmdthsalsi
 * Smoking Wheels....  was here 2017 tvoasfbkbauopkixbuxpfbldhlpixffaxdrrplguidoschpq
 * Smoking Wheels....  was here 2017 egdpenxxkewydoexcuurvtsmbgqqmmwrtphlrtvyvdcucmcp
 * Smoking Wheels....  was here 2017 mbimcrpqyhkajehhywtxranlnvfqbcehndpnyrykvykvsexi
 * Smoking Wheels....  was here 2017 nqkpxxjxpksjtccaprgmjkkpxlwdlcuznpkggykztekvyswe
 * Smoking Wheels....  was here 2017 grsdersdmtjubkedkdzvspdqorkeoxodidqksnfpgoccaqdu
 * Smoking Wheels....  was here 2017 abbotrkccyeihkmawjwqvntofgycrbrksflvqqpofdvfkuca
 * Smoking Wheels....  was here 2017 iyintxmvbqghqtcjuvdwcllrsfulgkmpskhursbiweezwhja
 * Smoking Wheels....  was here 2017 assyooemizxhoflygdfrcutkhwnzabqwqrxrrmlrpeylimwc
 * Smoking Wheels....  was here 2017 cbsascaqzdsbwyezmevmshmoiszvziapzcgftyroczgycxsy
 * Smoking Wheels....  was here 2017 wwzedgtaotmslgdtcdwzaxocnnegivtjpemgghbhgpkzpmhj
 * Smoking Wheels....  was here 2017 xgmdwzkqqnhnptlxvkqdkwiguinvokgcnmbbtzchggylofgo
 * Smoking Wheels....  was here 2017 yrluimgremmbtgojtqmclphohlmklcdwayrbdsoimntiamlv
 * Smoking Wheels....  was here 2017 btgjcgtsiypdrvbedsehawdskizyxhhbqthwnmmlrevydxbv
 * Smoking Wheels....  was here 2017 okrfaztknjmvjwvtovplfpztvubweowiegdmgmbvrgoxkglk
 * Smoking Wheels....  was here 2017 ytpdfqevkqglzybsuizlkbzxnxbqtsfnrcqbxfvzrznzprgs
 * Smoking Wheels....  was here 2017 bggyamifyrdmbwcxwyvndqsrowmckxatlglbjipsdymfrnjc
 */
package net.yacy.server.http;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PushbackInputStream;
import java.nio.charset.StandardCharsets;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.util.ByteBuffer;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.server.serverObjects;
/**
* A template engine, which substitutes patterns in strings<br>
*
* The template engine supports four types of templates:<br>
* <ol>
* <li>Normal templates: the template will be replaced by a string.</li>
* <li>Multi templates: the template will be used more than one time.<br>
* i.e. for lists</li>
* <li>3. Alternatives: the program chooses one of multiple alternatives.</li>
* <li>Includes: another file with templates will be included.</li>
* </ol>
*
* All these templates can be used recursivly.<p>
* <b>HTML-Example</b><br>
* <pre>
* &lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;
* #{times}#
* Good #(daytime)#morning::evening#(/daytime)#, #[name]#!(#[num]#. Greeting)&lt;br&gt;
* #{/times}#
* &lt;/body&gt;&lt;/html&gt;
* </pre>
* <p>
* The corresponding HashMap to use this Template:<br>
* <b>Java Example</b><br>
* <pre>
* HashMap pattern;
* pattern.put("times", 10);
* for(int i=0;i<=9;i++){
* 	pattern.put("times_"+i+"_daytime", 1);
* 	pattern.put("times_"+i+"_name", "John Connor");
* 	pattern.put("times_"+i+"_num", (i+1));
* }
* </pre>
* <p>
* <b>Recursion</b><br>
* If you use recursive templates, the templates will be used from
* the external to the internal templates.
* In our Example, the Template in #{times}##{/times}# will be repeated ten times.<br>
* Then the inner Templates will be applied.
* <p>
* The inner templates have a prefix, so they may have the same name as a template on another level,
* or templates which are in another recursive template.<br>
* <b>The Prefixes:</b>
* <ul>
* <li>Multi templates: multitemplatename_index_</li>
* <li>Alterantives: alternativename_</li>
* </ul>
* So the Names in the HashMap are:
* <ul>
* <li>Multi templates: multitemplatename_index_templatename</li>
* <li>Alterantives: alternativename_templatename</li>
* </ul>
* <i>#(alternative)#::#{repeat}##[test]##{/repeat}##(/alternative)#</i><br>
* would be adressed as "alternative_repeat_"+number+"_test"
*/
public final class TemplateEngine {
private final static byte hashChar = (byte)'#';
private final static byte[] slashChar = {(byte)'/'};
private final static byte pcChar  = (byte)'%';
private final static byte[] dpdpa = "::".getBytes();
private final static byte lbr  = (byte)'[';
private final static byte rbr  = (byte)']';
private final static byte[] pClose = {rbr, hashChar};
private final static byte lcbr  = (byte)'{';
private final static byte rcbr  = (byte)'}';
private final static byte[] mOpen  = {hashChar, lcbr};
private final static byte[] mClose = {rcbr, hashChar};
private final static byte lrbr  = (byte)'(';
private final static byte rrbr  = (byte)')';
private final static byte[] aOpen  = {hashChar, lrbr};
private final static byte[] aClose = {rrbr, hashChar};
private final static byte[] iClose = {pcChar, hashChar};
private final static byte[] ul = "_".getBytes();
private final static byte[] alternative_which = " type=\"alternative\" which=\"".getBytes();
private final static byte[] multi_num = " type=\"multi\" num=\"".getBytes();
private final static byte[] open_endtag = "</".getBytes();
private final static byte[] close_quotetagn = "\">\n".getBytes();
private final static byte[] close_tagn = ">\n".getBytes();
private final static byte[] PP = "%%".getBytes();
private final static byte[] hash_brackopen_slash = "#(/".getBytes();
private final static byte[] brackclose_hash = ")#".getBytes();
private final static byte[] UNRESOLVED_PATTERN = "-UNRESOLVED_PATTERN-".getBytes();
/**
* transfer until a specified pattern is found; everything but the pattern is transfered so far
* the function returns true, if the pattern is found
*/
private final static boolean transferUntil(final PushbackInputStream i, final OutputStream o, final byte[] pattern) throws IOException {
int b, bb;
boolean equal;
while ((b = i.read()) > 0) {
if ((b & 0xFF) == pattern[0]) {
equal = true;
lo: for (int n = 1; n < pattern.length; n++) {
if (((bb = i.read()) & 0xFF) != pattern[n]) {
i.unread(bb);
equal = false;
for (int nn = n - 1; nn > 0; nn--) i.unread(pattern[nn]);
break lo;
}
}
if (equal) return true;
}
o.write(b);
}
return false;
}
private final static boolean transferUntil(final PushbackInputStream i, final OutputStream o, final byte p) throws IOException {
int b;
while ((b = i.read()) > 0) {
if ((b & 0xFF) == p) return true;
o.write(b);
}
return false;
}
public final static void writeTemplate(final String servletname, final InputStream in, final OutputStream out, final serverObjects pattern) throws IOException {
        if (pattern == null) {
FileUtils.copy(in, out);
} else {
writeTemplate(servletname, in, out, pattern, new byte[0]);
}
}
/**
* Reads a input stream, and writes the data with replaced templates on a output stream
*/
private final static byte[] writeTemplate(final String servletname, final InputStream in, final OutputStream out, final serverObjects pattern, final byte[] prefix) throws IOException {
final PushbackInputStream pis = new PushbackInputStream(in, 100);
final ByteArrayOutputStream keyStream = new ByteArrayOutputStream(4048);
byte[] key;
byte[] multi_key;
byte[] replacement;
int bb;
final ByteBuffer structure = new ByteBuffer();
final String clientbrowserlang = pattern.get("clientlanguage");
while (transferUntil(pis, out, hashChar)) {
bb = pis.read();
keyStream.reset();
if ((bb & 0xFF) == lcbr) {
if (transferUntil(pis, keyStream, mClose)) {
bb = pis.read();
if ((bb & 0xFF) != 10){
pis.unread(bb);
}
multi_key = keyStream.toByteArray();
keyStream.reset();
if (transferUntil(pis, keyStream, appendBytes(mOpen, slashChar, multi_key, mClose))){
bb = pis.read();
if((bb & 0xFF) != 10){
pis.unread(bb);
}
final byte[] text=keyStream.toByteArray();
int num=0;
final String patternKey = getPatternKey(prefix, multi_key);
if(pattern.containsKey(patternKey) && !pattern.get(patternKey).isEmpty()){
try{
num=Integer.parseInt(pattern.get(patternKey));
}catch(final NumberFormatException e){
ConcurrentLog.logException(e);
num=0;
}
}
structure.append('<')
.append(multi_key)
.append(multi_num)
.append(ASCII.getBytes(Integer.toString(num)))
.append(close_quotetagn);
for(int i=0;i < num;i++) {
final PushbackInputStream pis2 = new PushbackInputStream(new ByteArrayInputStream(text));
structure.append(writeTemplate(servletname, pis2, out, pattern, newPrefix(prefix,multi_key,i)));
}//for
structure.append(open_endtag).append(multi_key).append(close_tagn);
} else {//transferUntil
ConcurrentLog.severe("TEMPLATE", "No Close Key found for #{"+UTF8.String(multi_key)+"}#" + " in " + servletname);
}
}
} else if ((bb & 0xFF) == lrbr) {
int others=0;
final ByteBuffer text = new ByteBuffer();
transferUntil(pis, keyStream, aClose);
key = keyStream.toByteArray();
keyStream.reset();
boolean byName=false;
int whichPattern=0;
byte[] patternName = new byte[0];
final String patternKey = getPatternKey(prefix, key);
final String patternId = pattern.get(patternKey);
if (patternId == null) {
whichPattern = 0;
} else {
if ("true".equals(patternId)) {
whichPattern = 1;
} else if ("false".equals(patternId)) {
whichPattern = 0;
} else try {
whichPattern = Integer.parseInt(patternId);
} catch(final NumberFormatException e){
whichPattern = 0;
byName = true;
patternName = UTF8.getBytes(patternId);
}
}
int currentPattern=0;
boolean found=false;
keyStream.reset();
PushbackInputStream pis2;
if (byName) {
transferUntil(pis, keyStream, appendBytes(PP, patternName, null, null));
if(pis.available()==0){
ConcurrentLog.severe("TEMPLATE", "Bad Key-Value pair in #()# construct: key=\"" + patternKey + "\", value=\"" + UTF8.String(patternName) + "\" in " + servletname);
final byte[] sb = structure.getBytes();
structure.close();
text.close();
return sb;
}
keyStream.reset();
transferUntil(pis, keyStream, dpdpa);
pis2 = new PushbackInputStream(new ByteArrayInputStream(keyStream.toByteArray()));
structure.append(writeTemplate(servletname, pis2, out, pattern, newPrefix(prefix,key)));
transferUntil(pis, keyStream, appendBytes(hash_brackopen_slash, key, brackclose_hash, null));
if(pis.available()==0){
ConcurrentLog.severe("TEMPLATE", "No Close Key found for #("+UTF8.String(key)+")# (by Name) in " + servletname);
}
} else {
while(!found){
bb=pis.read();
if ((bb & 0xFF) == hashChar){
bb=pis.read();
if ((bb & 0xFF) == lrbr){
transferUntil(pis, keyStream, aClose);
if (java.util.Arrays.equals(keyStream.toByteArray(),appendBytes(slashChar, key, null,null))) {
pis2 = new PushbackInputStream(new ByteArrayInputStream(text.getBytes()));
structure.append('<').append(key).append(alternative_which).append(ASCII.getBytes(Integer.toString(whichPattern))).append(ASCII.getBytes("\" found=\"0\">\n"));
structure.append(writeTemplate(servletname, pis2, out, pattern, newPrefix(prefix,key)));
structure.append(open_endtag).append(key).append(close_tagn);
found=true;
}else if(others >0 && keyStream.toString().startsWith("/")){
others--;
text.append(aOpen).append(keyStream.toByteArray()).append(brackclose_hash);
} else {
others++;
text.append(aOpen).append(keyStream.toByteArray()).append(brackclose_hash);
}
keyStream.reset();
continue;
} //is not #(
pis.unread(bb);//is processed in next loop
bb = (hashChar);//will be added to text this loop
}else if ((bb & 0xFF) == ':' && others==0){//ignore :: in nested Expressions
bb=pis.read();
if ((bb & 0xFF) == ':'){
if(currentPattern == whichPattern){
pis2 = new PushbackInputStream(new ByteArrayInputStream(text.getBytes()));
structure.append('<').append(key).append(alternative_which).append(ASCII.getBytes(Integer.toString(whichPattern))).append(ASCII.getBytes("\" found=\"0\">\n"));
structure.append(writeTemplate(servletname, pis2, out, pattern, newPrefix(prefix,key)));
structure.append(open_endtag).append(key).append(close_tagn);
transferUntil(pis, keyStream, appendBytes(hash_brackopen_slash, key, brackclose_hash,null));//to #(/key)#.
found=true;
}
currentPattern++;
text.clear();
continue;
}
text.append(':');
}
if(!found){
text.append((byte)bb);/*
if(pis.available()==0){
serverLog.logSevere("TEMPLATE", "No Close Key found for #("+UTF8.String(key)+")# (by Index)");
found=true;
}*/
}
}//while
}//if(byName) (else branch)
text.close();
} else if ((bb & 0xFF) == lbr) {
if (transferUntil(pis, keyStream, pClose)) {
key = keyStream.toByteArray();
final String patternKey = getPatternKey(prefix, key);
replacement = replacePattern(patternKey, pattern);
structure.append('<').append(key)
.append(ASCII.getBytes(" type=\"normal\">\n"));
structure.append(replacement);
structure.append(ASCII.getBytes("</")).append(key)
.append(close_tagn);
FileUtils.copy(replacement, out);
} else {
FileUtils.copy(pis, out);
pis.close();
final byte[] sb = structure.getBytes();
structure.close();
keyStream.close();
return sb;
}
} else if ((bb & 0xFF) == pcChar) {
keyStream.reset();
if(transferUntil(pis, keyStream, iClose)){
byte[] filename = keyStream.toByteArray();
if((filename[0] == lbr) && (filename[filename.length-1] == rbr)){
final byte[] newFilename = new byte[filename.length-2];
System.arraycopy(filename, 1, newFilename, 0, newFilename.length);
final String patternkey = getPatternKey(prefix, newFilename);
filename= replacePattern(patternkey, pattern);
}
if (filename.length > 0 && !java.util.Arrays.equals(filename, UNRESOLVED_PATTERN)) {
final ByteBuffer include = new ByteBuffer();
BufferedReader br = null;
try{
br = new BufferedReader( new InputStreamReader(new FileInputStream( HTTPDFileHandler.getLocalizedFile(UTF8.String(filename), clientbrowserlang)), StandardCharsets.UTF_8) );
String line = "";
while ((line = br.readLine()) != null) {
include.append(UTF8.getBytes(line)).append(ASCII.getBytes(net.yacy.server.serverCore.CRLF_STRING));
}
} catch (final IOException e) {
ConcurrentLog.severe("FILEHANDLER","Include Error with file " + UTF8.String(filename) + ": " + e.getMessage());
} finally {
if (br != null) try { br.close(); br=null; } catch (final Exception e) {
	ConcurrentLog.warn("FILEHANDLER","Could not close buffered reader on file " + UTF8.String(filename));
}
}
final PushbackInputStream pis2 = new PushbackInputStream(new ByteArrayInputStream(include.getBytes()));
structure.append(ASCII.getBytes("<fileinclude file=\"")).append(filename).append(close_tagn);
structure.append(writeTemplate(servletname, pis2, out, pattern, new byte[0]));
structure.append(ASCII.getBytes("</fileinclude>\n"));
include.close();
}
}
} else {
out.write(hashChar);
out.write(bb);
}
}
final byte[] sb = structure.getBytes();
structure.close();
return sb;
}
private final static byte[] replacePattern(final String key, final serverObjects pattern) {
byte[] replacement;
Object value;
        if (pattern.containsKey(key)) {
value = pattern.get(key);
if (value instanceof byte[]) {
replacement = (byte[]) value;
} else if (value instanceof String) {
replacement = UTF8.getBytes(((String) value));
} else {
replacement = UTF8.getBytes(value.toString());
}
} else {
replacement = UNRESOLVED_PATTERN;
}
return replacement;
}
private final static byte[] newPrefix(final byte[] oldPrefix, final byte[] key) {
final ByteBuffer newPrefix = new ByteBuffer(oldPrefix.length + key.length + 1);
newPrefix.append(oldPrefix).append(key).append(ul);
final byte[] result = newPrefix.getBytes();
try {
newPrefix.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
return result;
}
private final static byte[] newPrefix(final byte[] oldPrefix, final byte[] multi_key, final int i) {
final ByteBuffer newPrefix = new ByteBuffer(oldPrefix.length + multi_key.length + 8);
newPrefix.append(oldPrefix).append(multi_key).append(ul).append(ASCII.getBytes(Integer.toString(i))).append(ul);
try {
newPrefix.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
return newPrefix.getBytes();
}
private final static String getPatternKey(final byte[] prefix, final byte[] key) {
final ByteBuffer patternKey = new ByteBuffer(prefix.length + key.length);
patternKey.append(prefix).append(key);
try {
return UTF8.String(patternKey.getBytes());
} finally {
try {
patternKey.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
}
private final static byte[] appendBytes(final byte[] b1, final byte[] b2, final byte[] b3, final byte[] b4) {
final ByteBuffer byteArray = new ByteBuffer(b1.length + b2.length + (b3 == null ? 0 : b3.length) + (b4 == null ? 0 : b4.length));
byteArray.append(b1).append(b2);
        if (b3 != null) byteArray.append(b3);
        if (b4 != null) byteArray.append(b4);
final byte[] result = byteArray.getBytes();
try {
byteArray.close();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
return result;
}
public static void main(final String[] args) {
try {
final InputStream i = new ByteArrayInputStream(UTF8.getBytes(args[0]));
final serverObjects h = new serverObjects();
h.put("test", args[1]);
writeTemplate("test", new PushbackInputStream(i, 100), System.out, h, UTF8.getBytes(args[2]));
System.out.flush();
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
}
}
