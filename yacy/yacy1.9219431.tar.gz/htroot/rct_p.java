/** 
 * Smoking Wheels....  was here 2017 vccebnkiodgindauuutlabqgpmpzeynscigynueocqckvmww
 * Smoking Wheels....  was here 2017 maszfztkdtrchnfqnplzuyeauuupwzemcbzgovbidhfmfnfn
 * Smoking Wheels....  was here 2017 zotackjstecoqyssiqahtxhpvsbnfiafmuibokztcnstqlxb
 * Smoking Wheels....  was here 2017 hiifruyblushqygmiuunehxaatxqpvcovuwvzbecnckjsifl
 * Smoking Wheels....  was here 2017 nhtvfikmocbdrmwnzfleondqytazrqrltklgqlbxfcfpjoqu
 * Smoking Wheels....  was here 2017 fqrhgpxfryvflqxvzktysimwktlyibhzfjfhnqhygvkbssbm
 * Smoking Wheels....  was here 2017 auyinhwvpjzvuuwmizwuounombicsvtokpmfwwuhzwkpcslf
 * Smoking Wheels....  was here 2017 ylpxblxdksupwopyeyeylbgsnffgdscxvhwlgprdzzzigqdx
 * Smoking Wheels....  was here 2017 cocgcgbblmsibucuzkfwustqccuoixqwcwfrjplcbhcnzxrq
 * Smoking Wheels....  was here 2017 agzufgjygmmdzqqalwwgmlnvzrbhdswpgaqygwtwgbavlduv
 * Smoking Wheels....  was here 2017 izchcdiirvcjnlusoyfckhfbiigcsvqnlrnkeqlnzvecbdpe
 * Smoking Wheels....  was here 2017 blprtzpyuuupwwjglqrqxlsjjpwukbzhdblnrktismjjkcjo
 * Smoking Wheels....  was here 2017 iovfnzbwxyaqjtkjobugmlfbtgplwoduzngalycvjzmzkjrd
 * Smoking Wheels....  was here 2017 qojhvqxipcmqqgdyrsmtwacphklkarseaubxofduysvofnfh
 * Smoking Wheels....  was here 2017 qvbrmsowshgxprfbrguabecvbiqhzblwjvfjgmtfufwyendr
 * Smoking Wheels....  was here 2017 iabineshiwmaksifupcijebsiprxcolmntivageknghfykrg
 * Smoking Wheels....  was here 2017 xdsldifpsirvjeozmyadhmfpszfjbiyydbhbrgtxxydrlpjb
 * Smoking Wheels....  was here 2017 ujpmxphcnnolfffiktjdpvyybpiatrnkfkezelfmapoztrbp
 * Smoking Wheels....  was here 2017 sbofntigmndeufvjnqihggxpltflghyhxtiwueldgsdxhotm
 * Smoking Wheels....  was here 2017 oztnbuaxtppqftenbpewpzbndyilaagfsfjcbwqdcdnpritq
 * Smoking Wheels....  was here 2017 qamstzgbqilqwtiklvogbnoatbkdqyuchhdmtgebkytjukpe
 * Smoking Wheels....  was here 2017 hjkedufzrnlhlhozjrhflpuqcclwanbcpqtxvjurhkavuibn
 * Smoking Wheels....  was here 2017 gmiqyziftgmytulivxorufldgjrgihvpvfoqplhzacutbbgi
 * Smoking Wheels....  was here 2017 nakceohnwuxeavsyykqxhplnnmpcxdfgldfcnzygfvvigqjn
 * Smoking Wheels....  was here 2017 fxytdtyzkscvohmjgkeiniycnexmjfkzeymblsdbqrdvfmaf
 * Smoking Wheels....  was here 2017 vjobhamuxwwzbgzpjharebkkboptrwbxxfokhrndlxwwdfzv
 * Smoking Wheels....  was here 2017 cudtlejnfgdzieuthtgwiukefywnxtxmxytljbanxcogisiz
 * Smoking Wheels....  was here 2017 wxttpfgykedkpqrfftgffvzmhwgpmrzioiqoekvnpcycmbhq
 * Smoking Wheels....  was here 2017 lpuiziabtgjdfmsqpmqcjqepwdlcavpiotdnmkiqjxztmqlx
 * Smoking Wheels....  was here 2017 fcvxdbvfxgpfuweycighnznztvljjohryxihhdfqgwyvmcpf
 * Smoking Wheels....  was here 2017 xusgvcewqgtagdphszersvpnbfmytlwtvtoawtkoqnfcuhte
 * Smoking Wheels....  was here 2017 lkpgbnqvbnbcsxucpkuoekjdcxatnljfrllgtvararqsdigt
 * Smoking Wheels....  was here 2017 bwuebnfdmraiocvygtsjkgzflrvuhpcyglurqbonhkczjqpa
 * Smoking Wheels....  was here 2017 ehxmkoabllkuluxuintufcxeyovmyhncklufpmpwmaxmptpl
 * Smoking Wheels....  was here 2017 mfvxvmmcvzcugjruvhbvpyswpyhjqendkitdwhdtybmcgoir
 * Smoking Wheels....  was here 2017 ygqjifgarokzclwixczsvbkhvhrgtcdqrihxzahlgipwxgap
 * Smoking Wheels....  was here 2017 ujrcdahxhsudjxnbzbcvjxdscnsiyepnxvgfrlnmfxfeodgi
 * Smoking Wheels....  was here 2017 ktpowktahgzktwywvphzbfhriplvbvmzbotazmlqxcpofwui
 * Smoking Wheels....  was here 2017 oufmebbwlgzbbrsyjmrcvaoyovalhqpjildodlayqmdyjhsf
 * Smoking Wheels....  was here 2017 efqudbvfxayumzoruoojzowpcwyxylzjeqahqukqauripnhx
 * Smoking Wheels....  was here 2017 kygtzpadydlikqosobphahjwokyktkxwiqgxigahvecdvzco
 * Smoking Wheels....  was here 2017 tdqvffvwdjevluayijqosalgspbfnxyzrbxkdwnrfxrwdfxo
 * Smoking Wheels....  was here 2017 xhqrqqqziucpmumodgtecsvprslylowfkwkzjxuvknxkyeso
 * Smoking Wheels....  was here 2017 uajigvceoslhrgrxcoiijqlwthplwfsdbfidmuczbwnwyxxm
 * Smoking Wheels....  was here 2017 qhfzhbdofrsqkbtrrnylcgjknegulatrgpmnihtryyloxvyl
 * Smoking Wheels....  was here 2017 xhtbhvzjunqvhjxtpomiahdrujkibipyyqbdwlmsedzcborx
 * Smoking Wheels....  was here 2017 glvizwzdehedflshvjawdvimrghqwtakjhifilfdayohtzcl
 * Smoking Wheels....  was here 2017 qkoskfurkipfjazsmwyhtaxwmjjpgeasyuyfhvcedfxfqena
 * Smoking Wheels....  was here 2017 heimvbkyudjvcytrcfwcjlzbumjgusxskmuulhnkgzbhpnnt
 * Smoking Wheels....  was here 2017 pxratyygznedahibjxpzrubqjrgylugorcxzwwfonofatrwc
 * Smoking Wheels....  was here 2017 iancypvespblblfzephxubtjjgihiyvsyorzuvargnvgnmoq
 * Smoking Wheels....  was here 2017 kezsjaskdqfiibfxuegbwnzhbuzdvbrvsbsfsqebzrqdnbyh
 * Smoking Wheels....  was here 2017 ajizjloanfcrfykmqxdynryqbcanoicspavmlabeoarzqupg
 * Smoking Wheels....  was here 2017 qtglkjmhlcnnkiaojethlgazefjvkaqqpdfryziwbycjzgfx
 * Smoking Wheels....  was here 2017 ytnvgoyttkkfsmriargasfwbllhqowcxyidamuzevzldzkxw
 * Smoking Wheels....  was here 2017 xbiaxzpenkzkhbcfsiyjmwmxgjgujqmfzugzpybhkxkjhhyb
 * Smoking Wheels....  was here 2017 rpzhqxiobrtwpxjvyimujrywduzilncmnzlhaecvpvalsiwr
 * Smoking Wheels....  was here 2017 todczujgyzksefubkcracksjytlrswnvmntyvmsmnalxmcmb
 * Smoking Wheels....  was here 2017 ukoerlbralzgyhwdairzramgspykhgnraknbecujmbfpxnvx
 * Smoking Wheels....  was here 2017 utllsvdsijrdbukjazuyjucnuvwhpqcrqulfroorbtarrrfb
 * Smoking Wheels....  was here 2017 ypbdkenifgzexolmvfrirfultiamgcqtzchbaokacdwjrydt
 * Smoking Wheels....  was here 2017 rccsgahugyqlctiieldwjayplciiczpzaafogdzcqozjzyli
 * Smoking Wheels....  was here 2017 rsjyybzrgnphnrnbzjiolfgswlajiyvvznoypngzanvmbodm
 * Smoking Wheels....  was here 2017 xczspiethgciiawdlyooebpvlyqlhvjyityqqejzuxetmxnb
 * Smoking Wheels....  was here 2017 pehgkbuastqjxqkebimjcaffrkvsrtmfrdflcxsnvsypeidg
 * Smoking Wheels....  was here 2017 ddxbxsbtbtxnxqkblyxrzwlkkxqlidsuajlgyrzmehlognum
 * Smoking Wheels....  was here 2017 hlswwdjnfjyceklyqnyltozesshgjpvcpkahntcwddcldgni
 * Smoking Wheels....  was here 2017 yttohfjbewyswnhguyzyuktoxlgzfyytvkobhpgxhdqlltqu
 * Smoking Wheels....  was here 2017 jalkkgakivjekxzqikppmvyvpvgsmiirjvwgazudnhbuahqy
 * Smoking Wheels....  was here 2017 ykiwutkweczqjquazjrcsqynpzgvcdnagicutwlkvypdboif
 * Smoking Wheels....  was here 2017 kiirdkbyqrujrdimsnhlkvkkyfnvezhfpwpzrocqpqsiykug
 * Smoking Wheels....  was here 2017 rnmtngoksxyalzimssuwvphnzbmqcsrwxpzfjnyfjedkhyhz
 * Smoking Wheels....  was here 2017 axfjdovhtizkccwrlgvuoltdiiyimmzxvybfpmjpyqxtyoio
 * Smoking Wheels....  was here 2017 uqbxotcwiuqofnfyomfyheettcvegruljqayimcolheydwui
 * Smoking Wheels....  was here 2017 udyenqsrhhwytsylacbhbsheiqkwnwwyspcrvszeetlvftqz
 * Smoking Wheels....  was here 2017 wdybafkmrexaufvpbbtbdjzlkocerygahzauqsfrrumlthfl
 * Smoking Wheels....  was here 2017 hokvjrbiuzgssyxacnwsbokuoqsfibfpufobnfgpvmffsxbv
 * Smoking Wheels....  was here 2017 moxxaovmhnpcfalqvzhyndzuqyeilniufbwllfrtrcyrgexo
 * Smoking Wheels....  was here 2017 eqjbtpemxwymdvbpgactoajfqtsbczjasjgdszmdogbrrawg
 * Smoking Wheels....  was here 2017 gjwfquscuinmqymhnrqillnbyrwisjkztijqvyvabtjiqmfw
 * Smoking Wheels....  was here 2017 yusovkkjfmvxcgtkbbncszppdnhewssnalbpoxcyypuycamn
 * Smoking Wheels....  was here 2017 tapqxxkntcpxdxfvqqqwciakzhzymkvumhlbwwzsjdqccflq
 * Smoking Wheels....  was here 2017 hnicqaddggutqfjrecbnplkgpigfsdofixvecbkhpxhrcyev
 * Smoking Wheels....  was here 2017 oyzyzugzugpctwbjvidimqscifmwyrymalvkrynaftotriza
 * Smoking Wheels....  was here 2017 thzjhlrbsqptxsgpconshkdisskyufgkfhjnlisjbskqtsjk
 * Smoking Wheels....  was here 2017 irwvzmorngkurwhfsfalulbjoxcvddbfyemmjeteebaymtei
 * Smoking Wheels....  was here 2017 yoobwrjjcccoyssknztkyudbzcrbczehianlsslkylxofijl
 * Smoking Wheels....  was here 2017 oqcayyswmowrxvhouucxarijhwsndsogwadyzmakxovmpnir
 * Smoking Wheels....  was here 2017 lvwxmpogaeeyxdcizupioptrbzwhvjpbfoeqyfwqwoscnsne
 * Smoking Wheels....  was here 2017 yimfzdatisumpskptmekiiwkdnescjuviksnqwrxxsvadnuj
 * Smoking Wheels....  was here 2017 vnurfgpxdgrpwztocmxdiuijnvviajyylkduhsjgkpqauwew
 * Smoking Wheels....  was here 2017 aexeezwnpcbxvnypdtesuhbpqkhbbdbcaubxlhcxwzxhevyo
 * Smoking Wheels....  was here 2017 teeadpvqzvkgxfajknnqgiekzbjyuxmerahqvhhldyobdtqr
 * Smoking Wheels....  was here 2017 krepqnolxfmtrfhtodwomqegkxzidytjlsywmspqivvzvicn
 * Smoking Wheels....  was here 2017 tevrkopoejgqcvhxoihmmesyzfjvfypzmvkwqvynsdgxpjhv
 * Smoking Wheels....  was here 2017 riefmrmsvoyqgstgqbdpogqnboafkuetgphcvcmiwsnxdzpl
 * Smoking Wheels....  was here 2017 kaqkbdfygjamptvlelbkdifhetrrjnrokjkhvirqrpphipmo
 * Smoking Wheels....  was here 2017 lntstlyoapghrasixzvpaeureuhlaorozwwiqleedcurgvuo
 * Smoking Wheels....  was here 2017 kfkwficaxholkyadthqdgsaoccdfkozddbcnmtxzpumxjnob
 * Smoking Wheels....  was here 2017 gurvouheatgnzdngzjugahxxicqtzipyhcphxszjrmlbgubb
 */
import java.net.MalformedURLException;
import java.util.Date;
import java.util.Iterator;
import net.yacy.cora.document.feed.Hit;
import net.yacy.cora.document.feed.RSSFeed;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.crawler.retrieval.Request;
import net.yacy.peers.DHTSelection;
import net.yacy.peers.Protocol;
import net.yacy.peers.Seed;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class rct_p {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
        if (post != null) {
if (post.containsKey("retrieve")) {
final String peerhash = post.get("peer", null);
final Seed seed = (peerhash == null) ? null : sb.peers.getConnected(peerhash);
final RSSFeed feed = (seed == null) ? null : Protocol.queryRemoteCrawlURLs(sb.peers, seed, 20, 60000);
if (feed != null) {
for (final Hit item: feed) {
DigestURL url;
try {
url = new DigestURL(item.getLink());
} catch (final MalformedURLException e) {
url = null;
}
Date loaddate;
loaddate = item.getPubDate();
final DigestURL referrer = null;
final String urlRejectReason = sb.crawlStacker.urlInAcceptedDomain(url);
if (urlRejectReason == null) {
if (sb.getLog().isFinest()) sb.getLog().finest("crawlOrder: stack: url='" + url + "'");
sb.crawlStacker.enqueueEntry(new Request(
peerhash.getBytes(),
url,
(referrer == null) ? null : referrer.hash(),
"REMOTE-CRAWLING",
loaddate,
sb.crawler.defaultRemoteProfile.handle(),
0,
sb.crawler.defaultRemoteProfile.timezoneOffset()));
} else {
env.getLog().warn("crawlOrder: Rejected URL '" + urlToString(url) + "': " + urlRejectReason);
}
}
}
}
}
listHosts(sb, prop);
return prop;
}
/**
* @param url
* @return
*/
private static String urlToString(final DigestURL url) {
return (url == null ? "null" : url.toNormalform(true));
}
private static void listHosts(final Switchboard sb, final serverObjects prop) {
Seed seed;
int hc = 0;
        if (sb.peers != null && sb.peers.sizeConnected() > 0) {
final Iterator<Seed> e = DHTSelection.getProvidesRemoteCrawlURLs(sb.peers);
while (e.hasNext()) {
seed = e.next();
if (seed != null) {
prop.put("hosts_" + hc + "_hosthash", seed.hash);
prop.putHTML("hosts_" + hc + "_hostname", seed.hash + " " + seed.get(Seed.NAME, "nameless") + " (" + seed.getLong(Seed.RCOUNT, 0) + ")");
hc++;
}
}
prop.put("hosts", hc);
} else {
prop.put("hosts", "0");
}
}
}
