/** 
 * Smoking Wheels....  was here 2017 wnkpeslcgrfakqezeuwbygcswqpngmtwqgpvtjgphpjrbpxy
 * Smoking Wheels....  was here 2017 ovmtmdoenjporexxsiuhrsvywykyzsntqvuiwgugflpivaog
 * Smoking Wheels....  was here 2017 cpwksaswpglxjaaprmiwzcknkebszirvxkdjmthftfjbxcvh
 * Smoking Wheels....  was here 2017 zbgidqvnsnaxmmepxrkynwbzavdymvbtpqufmnfhpqkiwqua
 * Smoking Wheels....  was here 2017 bnmonjcsituvjdbomndrdsfgkribbcrmakdmbofpstusluts
 * Smoking Wheels....  was here 2017 mrrksxxiesnamvvotxvsaoojnrptlfxituuwpahmiurgruhu
 * Smoking Wheels....  was here 2017 nkflwgaleifdrptthyevppasoehxsmgtrgpntkopxhpzvgeb
 * Smoking Wheels....  was here 2017 vurkjohlpycewtjqycaamiuxzqvsclolwksqlkntdzillamk
 * Smoking Wheels....  was here 2017 egzjyiyxwbrflynyvxmqpkguovzpezwjqcmvuxubayvfidnd
 * Smoking Wheels....  was here 2017 slgpkfksskrsxxhrgiyebuemgtsfrdmvpnowfeixtjjhlyws
 * Smoking Wheels....  was here 2017 sgvsyekzdzdjzuxbvlaliskifrimqfzhobttjrivtuktdziw
 * Smoking Wheels....  was here 2017 vujkzkuagcgbswzokromapfyychojvelrhgwdagtvzsbwcyo
 * Smoking Wheels....  was here 2017 xlrudjulqgoyltixarspadydevixjubhfejrrfstxyhxmkaa
 * Smoking Wheels....  was here 2017 zwycitveyfulpgzbbhwingjcvvmdkeaavuuzkmreeyjfyect
 * Smoking Wheels....  was here 2017 kynysnqfdyyhbkghbspmxfjcdkyfnipfioiwzfircmmbozbm
 * Smoking Wheels....  was here 2017 vuabrwbzmtghupscygubvlcupaggaupmucdphedalihzwrwe
 * Smoking Wheels....  was here 2017 zvhnxfjcjdfsbjedtppjepbaxmeskjaxphptngskdmxoqixc
 * Smoking Wheels....  was here 2017 brnqghyjowpykorlvqizdrxxztqgkehrhhhbzqbdjgmtxgsr
 * Smoking Wheels....  was here 2017 jfaxxblyayjqqfogtmrrcvptddxvdnwgsmcplwivrcosxacr
 * Smoking Wheels....  was here 2017 mpkegrxdyqvstrjzjnlmsoggtcnnvzojznersoyisuwxfmcb
 * Smoking Wheels....  was here 2017 fepkyqkovlkibnwlulvrvojeolfuzknalgwuzrpulikxorac
 * Smoking Wheels....  was here 2017 sqrzxplcjdwyboeojbcwstornfyjlvymrvturlfmdaksaymf
 * Smoking Wheels....  was here 2017 hvbjgoqwmtgfnxopqnzuqjwcwpzbeomdmrurkhacejklwwfe
 * Smoking Wheels....  was here 2017 owikkraemntamvpalghmjujacdvcngwuajbtcykljcdopgiy
 * Smoking Wheels....  was here 2017 ifidbjrqtywnfycoxxdhtuojwofxyqfkovxoxibppgosaecu
 * Smoking Wheels....  was here 2017 rmgvalcdaujfgbdfjhysxhcedyddgwvftezyfqyzdbyudzcd
 * Smoking Wheels....  was here 2017 amkbntythcgskgzekphoimxvenwrlfgrkuewsifelcuagfes
 * Smoking Wheels....  was here 2017 vllpynewudtyqvgywfbwovfxkuwtvhgnpioqgchbebwtwsho
 * Smoking Wheels....  was here 2017 btgmyexbxjjbgkrgwtjypakhooxtywzurrnvzxxrjycstowx
 * Smoking Wheels....  was here 2017 syxakmrekovmuujbrcpioaecptzjocqqgzsgjyykfcvuycjd
 * Smoking Wheels....  was here 2017 favsmjcjftdxaaqqxliuvanrtsimqfwoeqzxaqpwezldtwrc
 * Smoking Wheels....  was here 2017 bbplpzcypfpgzlallcnjclnqlxmgowmimflbwtiyyiufrrus
 * Smoking Wheels....  was here 2017 elcejvxoalpqyrifitfkfaruldcduvlxorliaevrmfvqmqbe
 * Smoking Wheels....  was here 2017 ovlftoxadezokmqyyhukjrrhqjgucfemycrmxczmbwtkfbab
 * Smoking Wheels....  was here 2017 qdadwevlzmspfyfvvuxdzqkmixedoiepoxyndbzxcudpdnna
 * Smoking Wheels....  was here 2017 zklscvpfsoashkrjwsksqjbyyfiilsgylslusqiwitsrvwob
 * Smoking Wheels....  was here 2017 kdpzdajxvykbaluhdrkjincofcmufglnxllvrwpkrukhzdlk
 * Smoking Wheels....  was here 2017 zwpfvkojblpcwxqoznhrdbflbnqeszdopfqjnyvyldokrqvo
 * Smoking Wheels....  was here 2017 couakyytizqlqunlzlrlmeixsvbkygvmikwnvgcazhpdeakg
 * Smoking Wheels....  was here 2017 iivdfvjjwxtbimzjyulraipprlfseqideqhonoyocbixaahl
 * Smoking Wheels....  was here 2017 mnoqxnavdrlbgnvdafsrqgmjqevkzxsjnvgauuzptkrkzuui
 * Smoking Wheels....  was here 2017 svdtkskawblxxudrnpvznwqhozygbehnyciszdeocpyncomm
 * Smoking Wheels....  was here 2017 hcwdwjdaabtgbhffaclkbiatqfucnuqafwmqubszqfpmqado
 * Smoking Wheels....  was here 2017 wmlmrreeuzqaukqhkblzxdvijiweohnpnstdcfzubykqcxvo
 * Smoking Wheels....  was here 2017 fjswncscrhnkjqeosdxzzamxmcxvunzgdoosbqsajvirhiws
 * Smoking Wheels....  was here 2017 mjtpfidritgtgxxahgfzjvrpxnxuyokernneclvcucqofpum
 * Smoking Wheels....  was here 2017 zlafahezuktuhfdytnzunwhsvwdyarhxzanpvdnoshvkfhlq
 * Smoking Wheels....  was here 2017 iqbnheujgnhkmxluyhckdnoxuqbljnmderpgekfhyerqsgvd
 * Smoking Wheels....  was here 2017 iktmqmcmdokucophygscanxamqltlwawnjfqheokjudypoig
 * Smoking Wheels....  was here 2017 cjgmaxocfitirzskcgdmjuadvvgncvfhqfzporoggilfummj
 * Smoking Wheels....  was here 2017 yjybpjwklvktahajylaipnvqbmuqgrqykqseqiilaidqrqbi
 * Smoking Wheels....  was here 2017 mpkysbxtzipxctdrkffrjfncrdnhhabmwgoqlvivloxqrvda
 * Smoking Wheels....  was here 2017 oknfblyrjhuagzwbnfwuonnkjoeysroyjzyodegnlbvwqeas
 * Smoking Wheels....  was here 2017 gmkeogjcgotlyugmqiifiknqcstegtmooxkrcmavgachpyhx
 * Smoking Wheels....  was here 2017 xqljikwbrblxagpfirgubclecwnzynivemwcahvliaezutth
 * Smoking Wheels....  was here 2017 cbgoubjztcehlsmrmqmokzlpupzmdoykjgkctgddjuwlskkw
 * Smoking Wheels....  was here 2017 rdruotbmbflunsrrdwetiuauyowdgtjinfleliobjjehgyrw
 * Smoking Wheels....  was here 2017 tmxkpcjifcxvuchcqfqyxmvwmweoecxudkoeosbonzhlitzu
 * Smoking Wheels....  was here 2017 pzfxzczsgvraaxpgqxnypgudqtdsvydicgrdrwvgietdhkgi
 * Smoking Wheels....  was here 2017 xuiceyvxiqxigneoxfsuaodfwrgtpxwpmkwitlizlqhsprmm
 * Smoking Wheels....  was here 2017 kibzvccpyacxslvvowitcbfzxmhcxterqtnhxlfvxmywcrzl
 * Smoking Wheels....  was here 2017 hdnxvfgpvubfzppyysskyttnscfkpphsdkgwobjfwxwntriu
 * Smoking Wheels....  was here 2017 veckihyaxxtvuyvfqxnmavsfmvhprtwfwtxaksbrulqwxiid
 * Smoking Wheels....  was here 2017 qokhsmcgkqltgxabmupdxsgrrfavltqxwlrcgdsclwygbkao
 * Smoking Wheels....  was here 2017 nsinrgxvvnocnaahobcoocusazdojmstmjwqhgyptevlyatg
 * Smoking Wheels....  was here 2017 qezmbivrviyifbxugojidyblndrlhakajrdlzhtmypngrlbr
 * Smoking Wheels....  was here 2017 hytrcqnvkanccezwbkafamygiyujfqffgsjnxrhlmrnxlhto
 * Smoking Wheels....  was here 2017 acfxcjxsuxohertyybyiwdqsyxcnlxzzidpezczgcfovvkwx
 * Smoking Wheels....  was here 2017 taheuzexkmodtcbuwcgwoqorbvfhlsujwvhzjnobsdqrpusy
 * Smoking Wheels....  was here 2017 okcvbeugzmgzihzkhlhmgwlhrsgkacyomybrmdxeptzjtvxe
 * Smoking Wheels....  was here 2017 sbykaylwnyqorivysftwkbexztktgjybbwsjykfhdpebqbfg
 * Smoking Wheels....  was here 2017 xdnrckzcedatvncyzuldprzcloemicrqpfkhsayedkwerirg
 * Smoking Wheels....  was here 2017 wcsrzarompusclrdgvmntkgstvhbvddfmwoawytznebjtsqi
 * Smoking Wheels....  was here 2017 umotnoycbauxzyomvehpbfrwxotcnoraiasjwjpamebpvnqa
 * Smoking Wheels....  was here 2017 ygmjwxlvzlyzgcdfgamewgfydcvolrvoyztiitqznyiaejna
 * Smoking Wheels....  was here 2017 ymcjlhddjdovyfwvltwhxaaowwaowbkpllvfdthqjfqajahi
 * Smoking Wheels....  was here 2017 qphuyeeotpcqiwpalyqfzfpnwraohomadgipniicxzxheoge
 * Smoking Wheels....  was here 2017 cfdyfeazuqhwywkvpncmhtnyanxfnfieppvfvtoulomsojaa
 * Smoking Wheels....  was here 2017 qgbikjionfdcphpknqyxgvuepqwmpjolsufdsjggklunxyjp
 * Smoking Wheels....  was here 2017 xvqtyvbocpyhgntiaqzomypwbpklupyppoqrcyvjmjpcqdjy
 * Smoking Wheels....  was here 2017 thuhlcjqzidqfapffejrxtivcdgppsoqmsljclzfrjxdpbie
 * Smoking Wheels....  was here 2017 ejpewvtrydmoathdkemvrfsesglouustblfzezpeeszmuaux
 * Smoking Wheels....  was here 2017 pwlzizusxbzrlrbhfsxveorhcffhldyldcwoxcwwmwgkmoot
 * Smoking Wheels....  was here 2017 pyyogtndcixxndmemgnrcejtsnbxvjckuiolgkhdgrofgnst
 * Smoking Wheels....  was here 2017 zzzvhpbpzmsmmtkmgimriuglgyrwlhesjaocjymbnbvruzod
 * Smoking Wheels....  was here 2017 wqrfhfwwggetyiwfyxdkzkaktndvcznmmhpkpwkzlihqfhrj
 * Smoking Wheels....  was here 2017 oujemoqcxrglpyeqcccqndobjmqsuushxpmirpfpnznityvf
 * Smoking Wheels....  was here 2017 sosnfuhqdafkmxxeohgkomdaojssufnuvmiflxkrlvfcxwcp
 * Smoking Wheels....  was here 2017 cjphdkzckuowxuvokdszzccbcxceqdbanxnpbrpieujrnbuu
 * Smoking Wheels....  was here 2017 vvcueceilsafkkauzmwzzzejwctvdqofoysgxctyzffyowlg
 * Smoking Wheels....  was here 2017 huqonuolfwqdswudxmhdyiggegyohzquvatfssbdgnhbjxxs
 * Smoking Wheels....  was here 2017 amtjmsbuylpoxmrazoxmnppikweokvbnkusvidysuoimkyfe
 * Smoking Wheels....  was here 2017 vfkiuhwzbalpfvneiivjqkpmiregyyxjqcboxibvmihwmbrv
 * Smoking Wheels....  was here 2017 xqrqigkviiwsfsjqhqkhkuxuwtzgsknoccigvmkvobmcqpwf
 * Smoking Wheels....  was here 2017 mqxxfnjnqjyoqfookrgafynpghuouokqqelzvcchngikddoa
 * Smoking Wheels....  was here 2017 gkuyxhqihkvbnrpmougrugonyvdgjzkgizmyswqbasqdmmvg
 * Smoking Wheels....  was here 2017 zgdsaamxsyckeqidwqonzmmksctvbmolnkwtrrqhckkansac
 * Smoking Wheels....  was here 2017 twcolkhdpulyczulpdmbzoakleqxodekuoefdtbixqvyedqb
 * Smoking Wheels....  was here 2017 ycaajktbxxwkbshsjjrcdravjhakygvpavhispdtyxkbujnx
 * Smoking Wheels....  was here 2017 ecoxefuaxoqscfkjasasdgthzyknnkivhvjjivflyyyvxfto
 * Smoking Wheels....  was here 2017 fgofnhpsbhganaxdrwqfwbpqzxnqsmsaxntydlbmuukwgtoh
 * Smoking Wheels....  was here 2017 efdhhhpyavlsvzxaqswbmzfziekmkmhklzavnroguszdxhoo
 * Smoking Wheels....  was here 2017 lwrprgmuugfmtdsgmijckgpshahxptqlvqcadwwijfhuclpc
 * Smoking Wheels....  was here 2017 nhvabheqpsugkwvicdzjgixjfzrcnxoybcdwxvmpgbygkzqw
 * Smoking Wheels....  was here 2017 izkobwxcwvsfarcyotveywowyuhntscvngkwzlcdjgaeozbe
 * Smoking Wheels....  was here 2017 xmonqsbaihrtclocecibrwhhjlctbgpiufqvtyoizbtmpujk
 * Smoking Wheels....  was here 2017 qsqlxtinzdsnmfoaohautmyzsglulxoytkpvwtctnzqivali
 * Smoking Wheels....  was here 2017 cuichfqxapbldiqeoswkxfuolssueewjkmmdgoehsukeslhy
 * Smoking Wheels....  was here 2017 cdknlnfvxgesjjpigaxfasgxhoscvxnqehqgajlanmbrccgm
 * Smoking Wheels....  was here 2017 sjbbfjldivwtsdmkzcougyybfulmefvypysaqiwhejwszkvj
 * Smoking Wheels....  was here 2017 jjrfvtayhicfysqriblwzcwlktdvfjkunxnmrxotdxhmqwwk
 * Smoking Wheels....  was here 2017 ohvvquxozadackpqdhknxrepjwhggyzwbtfycvbgcwckqjln
 * Smoking Wheels....  was here 2017 fnjwizfqxklikveznlpbwhhluxqguvrfokewazyvahgdrxwy
 * Smoking Wheels....  was here 2017 irmrubmatguoluksukjzazybryflpbuzozadvqfyekbovwqf
 * Smoking Wheels....  was here 2017 iqmtexivlodkyjqbnijcvwbueffssxwtywqtgeacytzyjuqa
 * Smoking Wheels....  was here 2017 tobywtrjgquszwkmpokmxltguedilbreurcadiufdbtpwnwi
 * Smoking Wheels....  was here 2017 lwahnathqyftvwosctrkdkohfruqhfjgljumqbhkqjjgacrj
 * Smoking Wheels....  was here 2017 ncmbcmylhgdwyecuivmksrbalqchaoegmajyenizrycvwxpr
 * Smoking Wheels....  was here 2017 hgwurazyepptfyjwxwnhamhuskihrirptaqkkgeothkmtmmy
 * Smoking Wheels....  was here 2017 jjugrvtcoguipkxlrhpbsgifklasnesaiaueevgzodcpeqid
 * Smoking Wheels....  was here 2017 pxboukmovrgtjenhtswbrtsdhnwacwhooxevshfkbncwwmlm
 * Smoking Wheels....  was here 2017 alwzwkoetrslbbhikbrvcvbrjqwxfmtkbvkdjvadmssfwiln
 * Smoking Wheels....  was here 2017 axoacusahfebmdnvgkrdjthetcifvjrbqdjdvwvvhgkvnsdx
 * Smoking Wheels....  was here 2017 eltmwuwmqpwoqtthdfracxqhzjregbufkmddycchevxchmnr
 * Smoking Wheels....  was here 2017 ikilvvedgiibumujebxufcnuufrfalgwsudqynmqcmgrztyb
 * Smoking Wheels....  was here 2017 oljexpcxwegandsdswqzxepvcsiyxohgcdzmegzgimqnpuym
 * Smoking Wheels....  was here 2017 gligfbiulcrcnuwtgtojnjwtcawhysnwlymshvrsgjqtlfjs
 * Smoking Wheels....  was here 2017 xnskektgfluextsttcmbtdkeisvmjnslvwwpfwcwrwyvavft
 * Smoking Wheels....  was here 2017 lcmskbqvqremxpdufoohmetyloywttyxptksckwvmznkcsvu
 * Smoking Wheels....  was here 2017 yvtlxuikknnjafeyzaepwlnekoeewonoittuiozzyzrktduh
 * Smoking Wheels....  was here 2017 snwfsmnbmbuocpdjspyvhdsfmyugteavwfvxovnxmkxafuxb
 * Smoking Wheels....  was here 2017 jklsijfecniyccpofsrylrlrcghiqgfmhwrksxalvaxpbjea
 * Smoking Wheels....  was here 2017 sujbiwnitkosjhihnypifudkzgkvcoemznstysdtyuswabyl
 * Smoking Wheels....  was here 2017 witnqsylcnfgjzkmbgaltlomcydiwffamjotpmtdczosdcut
 * Smoking Wheels....  was here 2017 eyzqkwcncvifxhdkjsoelupiqptwamwrrsbmkrcfreyircns
 * Smoking Wheels....  was here 2017 fuqfbmyaapepancnhtcmyhkmcstnuaabphjffyqvkapdexdi
 * Smoking Wheels....  was here 2017 veqggarlijemzfboxztrfrmwebvttoqgqxwmegzdhqoukoau
 * Smoking Wheels....  was here 2017 dtcdwestrwdjhgdnpixhiwlnwrafqgblitcdtuclnfaelkrp
 * Smoking Wheels....  was here 2017 kmjhaxtzbdawtqpqyweesbgvitpwmkxcpeadnbejoinnmzyl
 * Smoking Wheels....  was here 2017 hkcpflsmtkcwkuzitakiasdkbwzupowzlvsvlsqtdrueddwj
 * Smoking Wheels....  was here 2017 pzdczfuxcfwqmfdkdltbenlcutzmmodbgpntpsesfhuwczto
 * Smoking Wheels....  was here 2017 lvpaiwkcyiamoscvkzpwhmxamkooxmxnqqdrmgsqzlvnmuen
 * Smoking Wheels....  was here 2017 dvvyilhddtqejlfufunpvsmnhdzzxruyjijrrulcyrjgmdyz
 * Smoking Wheels....  was here 2017 hcnrlbhjzswozrzuigkhjsietltxuqpyphjzdauytrdmrwcx
 * Smoking Wheels....  was here 2017 sanghfqlwthvqyhoxakfwevxoapsahjpqknfzwmhlneyubzn
 * Smoking Wheels....  was here 2017 ohyytpufpqqkxeccfywylattrznclqkbcvkdpojmfksmyacj
 * Smoking Wheels....  was here 2017 ctdibdktbkwynjuqxfjfnmzchntzaahwuyxurosenyfhiihb
 * Smoking Wheels....  was here 2017 znsenbkkmggjnwxpuewdtasnyeuocawsvjelboxdbumunvps
 * Smoking Wheels....  was here 2017 zbpnwuzvjsgwegguzmkybhkygrkfemcqoaorzmqovamrhojl
 * Smoking Wheels....  was here 2017 gxxrybowkprubjwduakfngskfcppzkjunargunvtzwlvqwdu
 * Smoking Wheels....  was here 2017 cayfyuwpowmxxfbxvxmtqdoicqpqqffrptkgeeribwwlvirm
 * Smoking Wheels....  was here 2017 cmkvfeujauybtfloxomozkdfhvwoillbwwvyzcqdttnxltcm
 * Smoking Wheels....  was here 2017 dtcrmrnviwnlwwtudpnymrwaplfsqwcxrfkwlgjhapkwgfsa
 */
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import org.xml.sax.SAXException;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.BookmarksDB.Bookmark;
import net.yacy.data.UserDB;
import net.yacy.data.WorkTables;
import net.yacy.data.ymark.MonitoredReader;
import net.yacy.data.ymark.YMarkAutoTagger;
import net.yacy.data.ymark.YMarkCrawlStart;
import net.yacy.data.ymark.YMarkDMOZImporter;
import net.yacy.data.ymark.YMarkEntry;
import net.yacy.data.ymark.YMarkHTMLImporter;
import net.yacy.data.ymark.YMarkJSONImporter;
import net.yacy.data.ymark.YMarkTables;
import net.yacy.data.ymark.YMarkUtil;
import net.yacy.data.ymark.YMarkXBELImporter;
import net.yacy.document.Parser.Failure;
import net.yacy.kelondro.blob.Tables;
import net.yacy.kelondro.workflow.OneTimeBusyThread;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class import_ymark {
	public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final UserDB.Entry user = sb.userDB.getUser(header);
final boolean isAdmin = (sb.verifyAuthentication(header));
final boolean isAuthUser = user!= null && user.hasRight(UserDB.AccessRight.BOOKMARK_RIGHT);
final int queueSize = 200;
YMarkEntry bmk;
String root = "";
ByteArrayInputStream stream = null;
        if(isAdmin || isAuthUser) {
	String bmk_user = (isAuthUser ? user.getUserName() : YMarkTables.USER_ADMIN);
	final ArrayBlockingQueue<String> autoTaggingQueue = new ArrayBlockingQueue<String>(10*queueSize);
boolean autotag = false;
	boolean merge = false;
	boolean empty = false;
	final String indexing = post.get("indexing", "off");
	final boolean medialink = post.getBoolean("medialink");
	if(post.containsKey("autotag") && !post.get("autotag", "off").equals("off")) {
		autotag = true;
		if(post.get("autotag").equals("merge")) {
	merge = true;
}
if(post.get("autotag").equals("empty")) {
	empty = true;
}
YMarkAutoTagger autoTagger = new YMarkAutoTagger(autoTaggingQueue, sb.loader, sb.tables.bookmarks, bmk_user, merge);
OneTimeBusyThread.startFromRunnable(autoTagger, 0);
	}
if(isAdmin && post.containsKey("table") && post.get("table").length() > 0) {
		bmk_user = post.get("table").substring(0, post.get("table").indexOf('_',0));
	}
if(post.containsKey("redirect") && post.get("redirect").length() > 0) {
prop.put("redirect_url", post.get("redirect"));
prop.put("redirect", "1");
}
if(post.containsKey("root") && post.get("root").length() > 0) {
root = post.get("root");
}
ClientIdentification.Agent agent = ClientIdentification.getAgent(post.get("agentName", ClientIdentification.yacyInternetCrawlerAgentName));
	if(post.containsKey("bmkfile") && !post.get("bmkfile").isEmpty() && post.containsKey("importer")){
		final byte[] bytes = UTF8.getBytes(post.get("bmkfile$file"));
		stream = new ByteArrayInputStream(bytes);
		if(post.get("importer").equals("surro") && stream != null) {
		    /**
SurrogateReader surrogateReader;
try {
surrogateReader = new SurrogateReader(stream, queueSize, sb.crawlStacker, sb.index.fulltext().getDefaultConfiguration());
} catch (final IOException e) {
ConcurrentLog.logException(e);
prop.put("status", "0");
return prop;
}
InstantBusyThread.oneTimeJob(surrogateReader, 0);
while ((bmk = new YMarkEntry(surrogateReader.take())) != YMarkEntry.POISON) {
putBookmark(sb, bmk_user, bmk, autoTaggingQueue, autotag, empty, indexing, medialink);
}
prop.put("status", "1");
*/
} else {
MonitoredReader reader = new MonitoredReader(new InputStreamReader(stream, StandardCharsets.UTF_8), 1024*16, bytes.length);
if(post.get("importer").equals("html") && reader != null) {
final YMarkHTMLImporter htmlImporter = new YMarkHTMLImporter(reader, queueSize, root);
OneTimeBusyThread.startFromRunnable(htmlImporter, 0);
OneTimeBusyThread.startFromRunnable(htmlImporter.getConsumer(sb, bmk_user, autoTaggingQueue, autotag, empty, indexing, medialink), 0);
prop.put("status", "1");
} else if(post.get("importer").equals("xbel") && reader != null) {
final YMarkXBELImporter xbelImporter;
try {
xbelImporter = new YMarkXBELImporter(reader, queueSize, root);
} catch (final SAXException e) {
ConcurrentLog.logException(e);
prop.put("status", "0");
return prop;
}
OneTimeBusyThread.startFromRunnable(xbelImporter, 0);
OneTimeBusyThread.startFromRunnable(xbelImporter.getConsumer(sb, bmk_user, autoTaggingQueue, autotag, empty, indexing, medialink), 0);
prop.put("status", "1");
} else if(post.get("importer").equals("json") && reader != null) {
YMarkJSONImporter jsonImporter;
jsonImporter = new YMarkJSONImporter(reader, queueSize, root);
OneTimeBusyThread.startFromRunnable(jsonImporter, 0);
while ((bmk = jsonImporter.take()) != YMarkEntry.POISON) {
	putBookmark(sb, bmk_user, bmk, autoTaggingQueue, autotag, empty, indexing, medialink);
}
prop.put("status", "1");
}
}
	} else if(post.containsKey("importer") && post.get("importer").equals("crawls")) {
		if(!isAdmin) {
			prop.authenticationRequired();
			return prop;
		}
		try {
	    			final Pattern pattern = Pattern.compile("^crawl start for.*");
					final Iterator<Tables.Row> APIcalls = sb.tables.iterator(WorkTables.TABLE_API_NAME, WorkTables.TABLE_API_COL_COMMENT, pattern);
	    			Tables.Row row = null;
	    			while(APIcalls.hasNext()) {
	    				row = APIcalls.next();
	    				if(row.get(WorkTables.TABLE_API_COL_TYPE, "").equals("crawler")) {
	    					final String url = row.get(WorkTables.TABLE_API_COL_COMMENT, "").substring(16);
	    					sb.tables.bookmarks.createBookmark(sb.loader, url, agent, bmk_user, autotag, "crawlStart", "/Crawl Start");
	    				}
	    			}
	    			prop.put("status", "1");
				} catch (final IOException e) {
					ConcurrentLog.logException(e);
				} catch (final Failure e) {
					ConcurrentLog.logException(e);
				}
	} else if(post.containsKey("importer") && post.get("importer").equals("bmks")) {
		if(!isAdmin) {
			prop.authenticationRequired();
			return prop;
		}
		final Iterator<String> bit=sb.bookmarksDB.getBookmarksIterator(isAdmin);
	while(bit.hasNext()){
Bookmark bookmark=sb.bookmarksDB.getBookmark(bit.next());
if (bookmark != null) {
final YMarkEntry bmk_entry = new YMarkEntry(false);
bmk_entry.put(YMarkEntry.BOOKMARK.URL.key(), bookmark.getUrl());
try {
if(!sb.tables.has(YMarkTables.TABLES.BOOKMARKS.tablename(bmk_user), YMarkUtil.getBookmarkId(bookmark.getUrl()))) {
bmk_entry.put(YMarkEntry.BOOKMARK.PUBLIC.key(), bookmark.getPublic() ? "true" : "false");
bmk_entry.put(YMarkEntry.BOOKMARK.TITLE.key(), bookmark.getTitle());
bmk_entry.put(YMarkEntry.BOOKMARK.DESC.key(), bookmark.getDescription());
bmk_entry.put(YMarkEntry.BOOKMARK.TAGS.key(), bookmark.getTagsString());
bmk_entry.put(YMarkEntry.BOOKMARK.FOLDERS.key(), root+bookmark.getFoldersString().replaceAll(".*"+YMarkUtil.TAGS_SEPARATOR+YMarkUtil.FOLDERS_SEPARATOR, root+YMarkUtil.FOLDERS_SEPARATOR));
}
if(autotag) {
bmk_entry.put(YMarkEntry.BOOKMARK.TAGS.key(), YMarkAutoTagger.autoTag(bookmark.getUrl(), sb.loader, agent, 3, sb.tables.bookmarks.getTags(bmk_user)));
}
sb.tables.bookmarks.addBookmark(bmk_user, bmk_entry, merge, true);
prop.put("status", "1");
} catch (final MalformedURLException e) {
ConcurrentLog.logException(e);
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
	}
} else if(post.containsKey("importer") && post.get("importer").equals("dmoz")) {
		if(!isAdmin) {
			prop.authenticationRequired();
			return prop;
		}
		try {
			final File in = new File(sb.workPath, "content.rdf.u8.gz");
			final InputStream gzip = new FileInputStream(in);
			final InputStream content = new GZIPInputStream(gzip);
			final InputStreamReader reader = new InputStreamReader(content, StandardCharsets.UTF_8);
			final BufferedReader breader = new BufferedReader(reader);
			final MonitoredReader mreader = new MonitoredReader(breader, 1024*1024, in.length());
			final String source = post.get("source", "");
			final YMarkDMOZImporter DMOZImporter = new YMarkDMOZImporter(mreader, queueSize, root, source);
			mreader.addChangeListener(sb.tables.bookmarks.getProgressListener("DMOZImporter"));
			DMOZImporter.setDepth(6);
			OneTimeBusyThread.startFromRunnable(DMOZImporter, 0);
			OneTimeBusyThread.startFromRunnable(DMOZImporter.getConsumer(sb, bmk_user, autoTaggingQueue, autotag, empty, indexing, medialink), 0);
			prop.put("status", "1");
				} catch (final Exception e) {
					ConcurrentLog.logException(e);
				}
}
}  else {
	prop.put(serverObjects.ACTION_AUTHENTICATE, YMarkTables.USER_AUTHENTICATE_MSG);
}
return prop;
	}
	public static void putBookmark(final Switchboard sb, final String bmk_user, final YMarkEntry bmk,
			final ArrayBlockingQueue<String> autoTaggingQueue, final boolean autotag, final boolean empty, final String indexing, final boolean medialink) {
		try {
			final String url = bmk.get(YMarkEntry.BOOKMARK.URL.key());
			// other protocols could cause problems
			if(url != null && url.startsWith("http")) {
			    sb.tables.bookmarks.addBookmark(bmk_user, bmk, true, true);
				if(autotag) {
					if(!empty) {
						autoTaggingQueue.put(url);
					} else if(!bmk.containsKey(YMarkEntry.BOOKMARK.TAGS.key()) || bmk.get(YMarkEntry.BOOKMARK.TAGS.key()).equals(YMarkEntry.BOOKMARK.TAGS.deflt())) {
						autoTaggingQueue.put(url);
					}
				}
				// fill crawler
				if (indexing.equals("single")) {
					bmk.crawl(YMarkCrawlStart.CRAWLSTART.SINGLE, medialink, sb);
				} else if (indexing.equals("onelink")) {
					bmk.crawl(YMarkCrawlStart.CRAWLSTART.ONE_LINK, medialink, sb);
} else if (indexing.equals("fulldomain")) {
	bmk.crawl(YMarkCrawlStart.CRAWLSTART.FULL_DOMAIN, medialink, sb);
}
			}
		} catch (final IOException e) {
			ConcurrentLog.logException(e);
		} catch (final InterruptedException e) {
			ConcurrentLog.logException(e);
		}
	}
}
