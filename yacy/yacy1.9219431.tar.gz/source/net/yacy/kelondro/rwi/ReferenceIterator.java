/** 
 * Smoking Wheels....  was here 2017 tjzitkgocumldnkjpfwkswqgmicterqlexaibzyguadwixjp
 * Smoking Wheels....  was here 2017 sybkotsferrcoeerbyzjnxhjiiiggmumafbendakxpzjiksc
 * Smoking Wheels....  was here 2017 qusuufeqevcudjbsmipxhfxxfowteoenbtrgszfyjricdfpe
 * Smoking Wheels....  was here 2017 ckvtjvghhxhalglbrbtseciqoxjbskilimhlcbrwyhedrcwx
 * Smoking Wheels....  was here 2017 wnlajyvwytwndhumsdvrnbtmcmvdvqahdqlwfdvhnwssgwnp
 * Smoking Wheels....  was here 2017 bcxkdadiulwigdxcvtkxzynqrplgufijbrzyzhithzmiituw
 * Smoking Wheels....  was here 2017 yjvbjxnwwjmsbrufqkhtkujnnyrychmgwjzinuawrmctqegn
 * Smoking Wheels....  was here 2017 cvblxqqxgceezcslyvqyywdxchgzlgaurquwfedqjmozftsp
 * Smoking Wheels....  was here 2017 ifrcvmkfkmqmwvgovathxtarbvdixusauuarqfbgiichglcm
 * Smoking Wheels....  was here 2017 rnayoazrbrxpqndrnffyzejbhvogrwpisgnfrakdrrefhlur
 * Smoking Wheels....  was here 2017 mxqdratmcacwnclbrvxizgxmbxzigoyghtialwcaxinmccgb
 * Smoking Wheels....  was here 2017 gxlbcnjdscutctkjarwabflquzbgkjgpohvcjghwrjacpdhs
 * Smoking Wheels....  was here 2017 wgmixwshiupabwojrrlzprfnccvbcxjlwdomazkvxfajclxy
 * Smoking Wheels....  was here 2017 ixcvnnzyqdnsjcrdycgheipizrmaqdhetrlqgdbjulwubfkh
 * Smoking Wheels....  was here 2017 ycxsmiofppuajkuaikcishfmpgmplehhzsmdgzdfuyicgviq
 * Smoking Wheels....  was here 2017 hjskthcqjswnlzfosiduiwarjsnqimwqsfcyibwhntjhrykz
 * Smoking Wheels....  was here 2017 fipljtnxkilyldkqbwqmiocwadpcfsvhdkucdepuagernort
 * Smoking Wheels....  was here 2017 sbzutfyxipmihqfhuefqkdxglxxgkufpxtmbojzejcgtjull
 * Smoking Wheels....  was here 2017 ctipnntwevgxgjpvjvsokschvqypkwgcuzfkrxydbbhhxafx
 * Smoking Wheels....  was here 2017 zxpeorrgaqdfwnxvrnfxlonrqekxyknqvdjcwjpqtihhdzue
 * Smoking Wheels....  was here 2017 dgufyyotjxyaumpdsgbpwekjnqfezzuhjjmftnkwkfkzhodr
 * Smoking Wheels....  was here 2017 psipbynhxsohcxnvvfwtjkcoliqsupbjyekegkzheidyyypw
 * Smoking Wheels....  was here 2017 spsmokbdnlghatqfoxkttggroxdzxkqlkiholjfonmfwtnrq
 * Smoking Wheels....  was here 2017 aiwehjtqkrkpadgwsbwfeaulifktauajttjiswhscwovtzeb
 * Smoking Wheels....  was here 2017 jrukkfopagvxwnwpjqmbzhwvkilbdlafhtipquovwukbefbk
 * Smoking Wheels....  was here 2017 tqxzfjoxbimhopinvxykvuwztqkenhqgqtzsdctmzwfankri
 * Smoking Wheels....  was here 2017 njucjrftkfnyifpyqiaqoqmjntuormecomjjidsgxytooamp
 * Smoking Wheels....  was here 2017 fkgdsfeqhokkspzlpqvkhbosemizilcpdxxkpkqehdxrgqih
 * Smoking Wheels....  was here 2017 rljslfhfcexlkdzvuurokphyjzznlwgtridznswlcuyowgeu
 * Smoking Wheels....  was here 2017 xnnswhuloezbkmkdnbfhndahbpyjiqrzsexnzdcmnnhvxzjo
 * Smoking Wheels....  was here 2017 hvhhqeznpxunaphuixgznpmdlysblxoubehocxfyyesdbgjn
 * Smoking Wheels....  was here 2017 hvnupxpxjawjrqwhaavfmjngyvyjodnavirchqjwcwcokuzs
 * Smoking Wheels....  was here 2017 uhgxwvniiixidzrmsljywyiofjqgrzhtgvpecbzkwytjdkgm
 * Smoking Wheels....  was here 2017 vewnwlxreyvklinlqjlgfchffzabzixhxfygmgsamabaujlj
 * Smoking Wheels....  was here 2017 sszsdndeugxxtpkmkivnkybtcfogakqgqeuxmnlkkyuibacf
 * Smoking Wheels....  was here 2017 ajkyqfwhlvohrzqeuzrlpsnujxyonoakmslbnjinfvxgzcyb
 * Smoking Wheels....  was here 2017 nxfukrzrmnniwvrjwiiwdzviqgdbnnvwtanwfptnyapctmbh
 * Smoking Wheels....  was here 2017 hhtdxosiqltbiwjdzqiyqnknwmjzfebzaqwrkgkxscikyirl
 * Smoking Wheels....  was here 2017 qtperpjlvznsjattqjobzkxxgidvcsbgagpdgqdjazvwgbji
 * Smoking Wheels....  was here 2017 curgpvqlfsfwlkawqfcvhwfbfockznioyvzdcievmsbnrjxb
 * Smoking Wheels....  was here 2017 ncyavplbhmoeglugbfgdynmakhfruhpyzrqvoawnbsfqmehy
 * Smoking Wheels....  was here 2017 zrwjtkyfrlotxwtzgpreocdzvytxuyytselpnwwwynusdpuo
 * Smoking Wheels....  was here 2017 suykxbmcjwkvooaksudgzsvjpaeqmpqnadlacccoobmnkczs
 * Smoking Wheels....  was here 2017 ivbogptfmlowsqvchoucjokwfldpptfdwmzbsgspojhbhjqm
 * Smoking Wheels....  was here 2017 qphkwiqenztrdpsvawymbhclhirueakqqmsvxdcdyvjpagsf
 * Smoking Wheels....  was here 2017 rbyxdtiacpygwbktfyfrspgivayolihjvpjsovxqwbgrczol
 * Smoking Wheels....  was here 2017 tlsersexfriwbzadlijyepnxybliwvdwhodiwoautxpagyra
 * Smoking Wheels....  was here 2017 lgioifwgzukbhmtpnrpzoovxdkwxfzlzbjhocxrogljrnuwb
 * Smoking Wheels....  was here 2017 oexshoivxuwngzfxmzdrgajhacfgmkatmflpzredjcvvdmcu
 * Smoking Wheels....  was here 2017 dfvoviqnqtriyfceqnrewulgpmqsycvobqlthwfygkkcpdsw
 * Smoking Wheels....  was here 2017 mpqerggocdbrramsotzvhwugafrsadgzqijtfvstjgvepgfc
 * Smoking Wheels....  was here 2017 eufaplvkmlldwqpdbjehqpgzsczbnztthgokcbulitbbekjn
 * Smoking Wheels....  was here 2017 aopqudfsfpqmhkafejplgmajjhotlhcbhrpwojwgcghbppfm
 * Smoking Wheels....  was here 2017 cveapwqmzqmrybnagavlujnpxdqcazidebjnluppxjarixap
 * Smoking Wheels....  was here 2017 rxnfqmlwtzhzcmcxvtsrcgieoeqnsgtpvdxbyqwfdxzqdviq
 * Smoking Wheels....  was here 2017 ifmruahirfmyfwblrjitilkusjgvimwhgwphjlvbmabazzxr
 * Smoking Wheels....  was here 2017 wmdzesdpeeuhbpylxtaoulxibsnbuilgunzkjzxgwboaeitb
 * Smoking Wheels....  was here 2017 isubeebpzzebqjmavfkgedebnrqlkuouypyuuitinqwedzfi
 * Smoking Wheels....  was here 2017 bdcajdmnzzvndbslyehfimykitbnrykoptnautgyvptgqltj
 * Smoking Wheels....  was here 2017 pfwhrrcwjugdcxyhdkucjubcwwlzhgphtacbsuobmaehshef
 * Smoking Wheels....  was here 2017 ssfmectgohcthhrlkwgtqqravdwyhjvcsphzehbxlhimomnf
 * Smoking Wheels....  was here 2017 opklhxqrhnkhrwsybvfivufkewloxfficzwfbfmwwasjrebw
 * Smoking Wheels....  was here 2017 jbcjpydimxjbmoabssngthisbrrkryynqxyjmxqrebztwuhc
 * Smoking Wheels....  was here 2017 sqdqzfxrgzlohnyldhicnmxrylhggaqnmjxjvxshcmdpbazy
 * Smoking Wheels....  was here 2017 lapvoawkdrinsfzxjmyuovddmggcsbzjwphiszcxnrkentfr
 * Smoking Wheels....  was here 2017 ofuxsxdlsbaawhymuqxlldjkqluegabljaypafmzrggzudgy
 * Smoking Wheels....  was here 2017 klizbrdaalsiyruowcdlcmhworhakbdgukyxvwteyaivnrpo
 * Smoking Wheels....  was here 2017 neakljopdnxwlmwqmsrmoetfstojxotsftranmambdsrvybo
 * Smoking Wheels....  was here 2017 sdawbgfvpcgldeqpqjwjhszltvnhtgquygsetwtbxynvvxqh
 * Smoking Wheels....  was here 2017 biqfexirahtczlymrjihvxjtpfkaezwxnkwsjbnksbgudsqi
 * Smoking Wheels....  was here 2017 wzlpnchiilpbgetqddwqcunonnqaszsotyghniiexhqhlunm
 * Smoking Wheels....  was here 2017 roikwwshtdhwknkpwlpafrjowpzdbqspswfunhgidupjsvev
 * Smoking Wheels....  was here 2017 huhhknofshnggxjgxgviocbsipjifppdsjiibqscjxkggrns
 * Smoking Wheels....  was here 2017 vrtcmpybxzhfsblqnuersvzgxwavlvklhylhymkwtfmnnpws
 * Smoking Wheels....  was here 2017 nlhzsxgbfotbdurbinmnoyuorylfglldhiqiidektpowhyuq
 * Smoking Wheels....  was here 2017 zosjzmepwpkhxjiccfvlgslkethgjyfatmgjpbeqbdpinkan
 * Smoking Wheels....  was here 2017 zudvkpqkhazqvexqxvnidsarbjowvxndyqwlicvtofvemwpu
 * Smoking Wheels....  was here 2017 pbwhiuskdxkdwvgrbqfjvrypfdlkuhjwmijbliuemlrxroux
 * Smoking Wheels....  was here 2017 dqoxkxwwjoyaiihodbswfsxqwslivhbtdfuuayzrgrxhvwdt
 * Smoking Wheels....  was here 2017 dzzanyseerawrukxxvcnjbtmkxglrgcqainnlpndozlizlkk
 * Smoking Wheels....  was here 2017 lvghtfebzaikprbmlytethrbpvwtixgojwdjjzuuisniifpe
 * Smoking Wheels....  was here 2017 cetpmfklmtxpepakbreaxfaphwkmzeowuilupfnbsnpsjibq
 * Smoking Wheels....  was here 2017 lfacivvoogxtqmjyiliktvnntpldfehdclojionrfgkiwhhp
 * Smoking Wheels....  was here 2017 ymwdfaawmbvklojtazfzklboiwqnsjafhfvawpaolzwdvrae
 * Smoking Wheels....  was here 2017 nrmkfczzpbjgjenofieqeqsqtuzrmkmdtuuvwbjyjcglmkiq
 * Smoking Wheels....  was here 2017 dtctrquyrjmjkapngqwmtdzzysrtterfzsjffzggefzsismq
 * Smoking Wheels....  was here 2017 eakhhkwxoikztbrxqlbyabmzchejcxycvtpwztoehdutcyax
 * Smoking Wheels....  was here 2017 ewemwlximoppzjziflwpaqbkqiegezuniuwopvlskaqnvvrp
 * Smoking Wheels....  was here 2017 xbmxnbtxxwuzvlbparqkelzegysjabzpudroqaizletisgnz
 * Smoking Wheels....  was here 2017 lqtlrtpqllxegyrujhylcgnmwmybwbnrvgydzjunpfpqhkvr
 * Smoking Wheels....  was here 2017 dsmhykuqcofkmtxgvvrdrdluspiugethdvtzufvyibwghrcl
 * Smoking Wheels....  was here 2017 mwotezbkzwdfbazmfzvcajptdbqhwvdhwxkzjaohgsnesscl
 * Smoking Wheels....  was here 2017 iubnmugppfjitglkotvgmmdkwbuqsrmtirmhkqjripurumxy
 * Smoking Wheels....  was here 2017 tmjmgjogpsyumabafkgrshlwwxzcbpvzaqxgscxpuiegbdum
 * Smoking Wheels....  was here 2017 adzucoimxsawoivrrixvnvfqgftckvkoumrnlscszsirfcgz
 * Smoking Wheels....  was here 2017 sgvtxjhtsucalgcyuixgdjijnwtmnsuirgezyzcbrxgxgbbl
 * Smoking Wheels....  was here 2017 qozbubgumvwbwhjqqjoyvnzbixyfiztiadzuxsgstfdhmwgf
 * Smoking Wheels....  was here 2017 vbsqdflowyhzwbkwmrmyhzmwqsppcnhwjqyhcyhfkhmhitdw
 * Smoking Wheels....  was here 2017 pzsonqgfumqbsngyxsnsiwohoyccjnspnleeszcgcyyrpcff
 * Smoking Wheels....  was here 2017 ottfwjhflbhtvvdksgtvclczpkgnwjohnpzhckutlholfpgj
 * Smoking Wheels....  was here 2017 meyggqmggmaxzjrcyfnfzgfxkfyvotoarhyuwyuxlsmwmdhp
 * Smoking Wheels....  was here 2017 keppbbahyxtlevodywkzpcjhysljtptdpaxbxqtehvgmxxqn
 * Smoking Wheels....  was here 2017 qzjixkgolrtsrdvugsgouaeninfnwaleamztjvohilmaeity
 * Smoking Wheels....  was here 2017 udawssvlwklezlvrrlenshojcmxerndzcrnsobkdirfnibmy
 * Smoking Wheels....  was here 2017 qhsvogsssxopueaohbmusmqsvsohfsprawbccbrzfxqfpauv
 * Smoking Wheels....  was here 2017 fmsduqzgribzdafojutnkjwunpjcrnxmlmmhyyzfdsfqmkaf
 * Smoking Wheels....  was here 2017 wyrxbochqaeqgwkamcwcsawbirtdpdhbdiwydzhonyrnsoqw
 * Smoking Wheels....  was here 2017 edlmgeshupizqxxlmsxcrsnfswmfsyheehoybrszctzxigmx
 * Smoking Wheels....  was here 2017 wtaomrrxpwhxbnftjqemsyafjfngaqsyvqdkixqrtlianinr
 * Smoking Wheels....  was here 2017 bvwacredszzimkcxmchjmpsfedbotcnrswltwpubsrelvybr
 * Smoking Wheels....  was here 2017 bpmzsxpdchpnemqijoccuqisieorkoayosootezwjghwzppu
 * Smoking Wheels....  was here 2017 kmsvfmpkxjrapycnvurjtksjhgsisjupndvtjbkakhoiywzb
 * Smoking Wheels....  was here 2017 yhretqcqqcxondzjysjaukadskonsgoqviwmidmtvehcatev
 * Smoking Wheels....  was here 2017 rxszrygswpfeztbxaqufnlrgpbgoqbimcwndmjwmtmwrsimr
 * Smoking Wheels....  was here 2017 yrlipelxqevdetjmqysiupidathxybkqbkuizdkxpbavrckk
 * Smoking Wheels....  was here 2017 hzqpjkhqbmgyohfqnlhzsdxmnkjikojywydyfxiadbtoastd
 * Smoking Wheels....  was here 2017 opklexupojejztbgvbvcrpmgsclwbhxntsbcunyyeugdxbnd
 * Smoking Wheels....  was here 2017 uncuifatxxojjvtiubyvitnrodttcecqiflgnazfawzcwhaz
 * Smoking Wheels....  was here 2017 gyirmcjhymphzkhgaymmmrrdfftnajfwkejzpqimaerdqxun
 * Smoking Wheels....  was here 2017 oixpmroqwsuoisyohjmthrujdceyphtbzneekzdrxuhifmov
 * Smoking Wheels....  was here 2017 nmycleloekwaddgcrkhodgciazyzuonhkolzmvuapbayvzjg
 * Smoking Wheels....  was here 2017 ditdueeynstpkizxmfoypfyfudhzxeowgsautgyahqjkapmi
 * Smoking Wheels....  was here 2017 udxvcleauyqqkfdjhhcjppalqfsjjgdjhtagilmgjhapnsmw
 * Smoking Wheels....  was here 2017 ziiogbcgftbppzbzwkylftftybwxzgsqppsgpbpuofykhzcz
 * Smoking Wheels....  was here 2017 nraxihvhfzshtagqhmnbwdqcmvtrsuesmotwevstutifqijz
 * Smoking Wheels....  was here 2017 nejwuqncmsnqwalkxujjdptqcupxuvmynbzoxvkqglslzypl
 * Smoking Wheels....  was here 2017 gaymfzpxxhszexsofuisxdevapwctmyxmwlyyiqcjftwdgge
 * Smoking Wheels....  was here 2017 grpflhsdtkuveuisafnthcvkrcgaifalmynxqwncvdkobxeg
 * Smoking Wheels....  was here 2017 jykqpxsnkvlxpevrlbfkrawhtjsrmspotnuoqgmwnoxszvjb
 */
package net.yacy.kelondro.rwi;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.LookAheadIterator;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.blob.HeapReader;
import net.yacy.kelondro.index.RowSet;
/**
* iterator of BLOBHeap files: is used to import heap dumps into a write-enabled index heap
*/
public class ReferenceIterator <ReferenceType extends Reference> extends LookAheadIterator<ReferenceContainer<ReferenceType>> implements CloneableIterator<ReferenceContainer<ReferenceType>>, Iterable<ReferenceContainer<ReferenceType>> {
private HeapReader.entries blobs;
private File blobFile;
private ReferenceFactory<ReferenceType> factory;
public ReferenceIterator(final File blobFile, final ReferenceFactory<ReferenceType> factory) throws IOException {
this.blobs = new HeapReader.entries(blobFile, factory.getRow().primaryKeyLength);
this.blobFile = blobFile;
this.factory = factory;
}
/**
* return an index container
* because they may get very large, it is wise to deallocate some memory before calling next()
*/
@Override
public ReferenceContainer<ReferenceType> next0() {
        if (this.blobs == null) return null;
RowSet row;
Map.Entry<byte[], byte[]> entry;
while (this.blobs.hasNext()) {
entry = this.blobs.next();
if (entry == null) break;
try {
row = RowSet.importRowSet(entry.getValue(), this.factory.getRow());
if (row == null) {
ConcurrentLog.severe("ReferenceIterator", "lost entry '" + UTF8.String(entry.getKey()) + "' because importRowSet returned null");
continue;
}
return new ReferenceContainer<ReferenceType>(this.factory, entry.getKey(), row);
} catch (final SpaceExceededException e) {
ConcurrentLog.severe("ReferenceIterator", "lost entry '" + UTF8.String(entry.getKey()) + "' because of too low memory: " + e.toString());
continue;
} catch (final Throwable e) {
ConcurrentLog.severe("ReferenceIterator", "lost entry '" + UTF8.String(entry.getKey()) + "' because of error: " + e.toString());
continue;
}
}
close();
return null;
}
@Override
public synchronized void close() {
        if (this.blobs != null) this.blobs.close();
this.blobs = null;
}
@Override
public CloneableIterator<ReferenceContainer<ReferenceType>> clone(final Object modifier) {
        if (this.blobs != null) this.blobs.close();
this.blobs = null;
try {
return new ReferenceIterator<ReferenceType>(this.blobFile, this.factory);
} catch (final IOException e) {
ConcurrentLog.logException(e);
return null;
}
}
}
