/** 
 * Smoking Wheels....  was here 2017 udmuonoodmvrrfstgnsrpvfbvylwoopmjsmpgqeaqtaylzwf
 * Smoking Wheels....  was here 2017 hvkqxwskorljmjymztmjebuwuxdqfsnbzgekhhhkxwbshity
 * Smoking Wheels....  was here 2017 qctjjsaoqmlykifnasynsmpqntdzkoetrybnjdyrjlnajmit
 * Smoking Wheels....  was here 2017 uyeubiqqnoqusavdqradnqbfklmorfdaxhjezzwvopstkulk
 * Smoking Wheels....  was here 2017 aqpwhgclptbpurjvjdwndkxqdamhqdhpnbmxbwbhmsebjaex
 * Smoking Wheels....  was here 2017 xpeypjccmezgjrtfyuxfmteioxqigbslmfanpcspfltkkbyk
 * Smoking Wheels....  was here 2017 dqimxrqxcgzyjsbjjsuyobbuurtbtwusbazaxgjpdpkjachj
 * Smoking Wheels....  was here 2017 tttiemynonwzasrkydmurxbyggwdptdztzmrqdrkxinxwpco
 * Smoking Wheels....  was here 2017 zeilvknsgyqctwdvdmczmaxvpshlldowivzbovrikzodyemx
 * Smoking Wheels....  was here 2017 kkgdjeapvopegqjktocctmotrloegtekuocwuppytgjlkvtq
 * Smoking Wheels....  was here 2017 sdxyqxnneuhinrkaujcxoqgkpbmsfmitklufpaxejyyotsog
 * Smoking Wheels....  was here 2017 zmaptwfcjgnarxrymdbkfamnvmcsvnrksyeioxhaweqhphuj
 * Smoking Wheels....  was here 2017 lolezqncwuhwgotpjjdwilzhytrctibblvttohvvdiywzela
 * Smoking Wheels....  was here 2017 pykyxbhrhozuxamsfuuvszrzvhtyxoosqbcgqoqgibqqbjzl
 * Smoking Wheels....  was here 2017 fjhljdkdnxbypzyhzlpclxwersetodnonyfwcehcuevghbyb
 * Smoking Wheels....  was here 2017 hvtklfdcsmirmkpmanosvuatvwyddhpbqxfwozmlfwuriqfp
 * Smoking Wheels....  was here 2017 dosxmuyjfcvscmyutnuwmlvvyxiyhkpxstnuubeqlmazfuxz
 * Smoking Wheels....  was here 2017 fakeztobryxxbowyagseeyhrwfykberdumvkxrqgrpjqbmjn
 * Smoking Wheels....  was here 2017 hbduvdanaibljlmxtqbjaprxuinxopdwdhatfliefdvhjwep
 * Smoking Wheels....  was here 2017 kormcfmhiybseydvhzrliykjbfdbgtprfrhbhdzlsfsuvkfy
 * Smoking Wheels....  was here 2017 uwxibpmgapzizjlgbsstrugeiybvwdyewlbxzuokdepijtpo
 * Smoking Wheels....  was here 2017 zkyoiarnsldglbhvxqruwfepmxvhjlgjanzbitirnqfhfwqq
 * Smoking Wheels....  was here 2017 tyhstqdjhvaqosspvtejankiqshxxowmzfzorpscinriuxzp
 * Smoking Wheels....  was here 2017 bmoojralyklvmhcsagelkflcfgkhyslzgzfqpcntdxfjvimf
 * Smoking Wheels....  was here 2017 fgrentwozamnszcqbrtiqfzbwpokfhuopocwxhrywekogvfl
 * Smoking Wheels....  was here 2017 suvutqjudukpwemdstknnmbokefiqabfazizrokhqyahghon
 * Smoking Wheels....  was here 2017 iulyxkmmedsfzpkdymuwdjveapfnkvndumvbfjgrwcdehydv
 * Smoking Wheels....  was here 2017 ahdlbingiphueefwaduivkvscsopzxwulnsjeqwceszfbfue
 * Smoking Wheels....  was here 2017 dmwgoawyycczzboumepgdkuhhqpmbqyxsxlkhihzlfemotpl
 * Smoking Wheels....  was here 2017 cyusyhiprulrbsfpciqcxmqgltvhotukporyruswufmjxnxx
 * Smoking Wheels....  was here 2017 tjihaewpkyxaivihvqpqfxrfrsbmtdvojvhbqoqpqoyppsja
 * Smoking Wheels....  was here 2017 bseuyyrnghhkaigbaiizjfjyliirbbqvocnzumuhqkvaisvm
 * Smoking Wheels....  was here 2017 hifhyfhfpqonpjpjcxbiyfjpjtyudwcwxftgxpdgpcsuagkh
 * Smoking Wheels....  was here 2017 yqpzqujtddbfslfywddftatmhklyzhhslcrrcfycsgjiyhkq
 * Smoking Wheels....  was here 2017 ujtlwrzmscisjeftiyilxwsejupptgonlaefqwqrjtvhmxmy
 * Smoking Wheels....  was here 2017 wpklsghzlfejsnyasqmbsktoaxliyynujmkfekaafsloiqlz
 * Smoking Wheels....  was here 2017 kmkalauctiqvgrzepsuhtiorvuicfuagafwemwaocnsimdls
 * Smoking Wheels....  was here 2017 yoykqvfygpzaqbgzswrrvudxsvtaolfvjfdxqowuetkxciuj
 * Smoking Wheels....  was here 2017 fplefsovvitcvjuicduabbsvvrnndxktsuejabbpviqbrjdi
 * Smoking Wheels....  was here 2017 gppcdabjqetkbnanyubissthndrgkhfnpidwcdhcrjppvtik
 * Smoking Wheels....  was here 2017 hsgftgekbzbrtsmzvgqxjnajlkndbcnusrmyuxpprfytpcln
 * Smoking Wheels....  was here 2017 woqtsfqztxxuojbkliyfxpmjmvogcyjocuujdqfrwnjwdkvw
 * Smoking Wheels....  was here 2017 tvdgtalmoiwwndwuxzrcifjyuzqcqvebaxbelwoesdzpxvey
 * Smoking Wheels....  was here 2017 xmmnzyulpvtiubgiknsoaxdxsvtgexnsznlqimkfvebwptfl
 * Smoking Wheels....  was here 2017 qvmpsoeujhpwufumlihxnooiykgqkpggtjihplsdbadweydj
 * Smoking Wheels....  was here 2017 miksnrjojwqhgbkzvgtprdooicpkhomqjmkxhdsmphaxvhhx
 * Smoking Wheels....  was here 2017 dspkgihcpxnvdhdungulnalfaprzaupcbcpmtcydvvsszzgn
 * Smoking Wheels....  was here 2017 qaumzvezczywqwjdvohnltqdkrlaamdcirbipcbdivodjlxy
 * Smoking Wheels....  was here 2017 gmwyzuobibzbeyslgsnaydxjcngkazaiyafzpgbxbpcjyjic
 * Smoking Wheels....  was here 2017 mpzbxydlxeyhlyamnkuoxfehamqgzbiuycsevwfzdubvwsxg
 * Smoking Wheels....  was here 2017 dcpjmkwlstjtlojesqvvkhslhejaaokrodnzrlyexgocqpfv
 * Smoking Wheels....  was here 2017 dzirwlarwkaujsesasnxszathmmjstwmiqtqqvaqacwdxndo
 * Smoking Wheels....  was here 2017 vmdzjqbzuzzcpqzqzbbblaufrmidqbpwzjwsocksktnbqetk
 * Smoking Wheels....  was here 2017 sddoouskcqnnxsrqjmwvknaghqjnvcqvoimzonixdthibkkp
 * Smoking Wheels....  was here 2017 mrvyfzzirrehfqiqeyozruyjimmxlwkoitolxridrbhnpmtp
 * Smoking Wheels....  was here 2017 fbuxlmbirvtusjjwrsdnoiamdyqzynlotdhjfjamptspyupc
 * Smoking Wheels....  was here 2017 epampwlglwiqwbiujfrtrazqjcepanrnqfahhrmgueesbbcb
 * Smoking Wheels....  was here 2017 vsqyfywerydtjecebhrevwwfxipyqnekzzlaewyalzlfdeot
 * Smoking Wheels....  was here 2017 zfbvduhlflthdjtxsxtpcevtwhtkymgmbsnognvsxbouqiqo
 * Smoking Wheels....  was here 2017 pbzxlsarfyyrloshpgwbuokcrvqqmopdjwjfbmwiunwifzdh
 * Smoking Wheels....  was here 2017 znielglrbkumrznrfxdumuhjybooweacrflmltcharvzxuev
 * Smoking Wheels....  was here 2017 qcfzseinkwosoabwjoajaylxpjchcbqjzujcmrsctfgevsdk
 * Smoking Wheels....  was here 2017 imcubqqpcsulakkvagenlhehsjygjcudotcelueriagomxpn
 * Smoking Wheels....  was here 2017 asqkpwqlhphdhbysmemiclwirxgdcncxxquyzxgakdaanulw
 * Smoking Wheels....  was here 2017 bbtvqmuykjckvdhbfweaoejeedgtatkiufwywcyowzesydsk
 * Smoking Wheels....  was here 2017 wypksgveadndhbhnabqdrnncclnialvkgmzyeqkwvfmbxuwj
 * Smoking Wheels....  was here 2017 hfposgtlbibopoabxtnmlwrtnkvgkntjnqbzgdetsqaqwykf
 * Smoking Wheels....  was here 2017 gtleqtskrmozbowycetagsgyxxfdnfsqcfhirkzhdjalobgq
 * Smoking Wheels....  was here 2017 cxbfxjhwenacagkpevncrwzuvcaydypzuybngltwawapxvmp
 * Smoking Wheels....  was here 2017 hcoyawewhotvgaouvmgfnkwofisueknipvbibpublrxmcdmj
 * Smoking Wheels....  was here 2017 pdkyuiivwyihqpikcdoewqdydfdbvmvwscetkknrvrqupfvj
 * Smoking Wheels....  was here 2017 bzgyjcziajmxlwesgzkyacgsbphlnkddthpdxsswuznjcmjh
 * Smoking Wheels....  was here 2017 xwzaaqqdephjbcqeupywppyyprnwaphukctxioixgadkopfd
 * Smoking Wheels....  was here 2017 qhvkivbkyvbmfqplmqqkjgfaqtjkftkusoiyvfplijfieotd
 * Smoking Wheels....  was here 2017 bafqdsdmgkhmwfdpiebjligohmpnjtvkyxefqiagkxwskmos
 * Smoking Wheels....  was here 2017 dbsnnpexezvsesqtpkfvdjpiytgvwvdboqnakphmcsinxvmp
 * Smoking Wheels....  was here 2017 eqibtbqodjrxqkrkvwfzafylhppgkkgmjmtxxekligexrgru
 * Smoking Wheels....  was here 2017 qgfnlwgmtsdwyrdhtgnkywhgdngyzegqklnpgiqtfbfgxtll
 * Smoking Wheels....  was here 2017 jqtllczcyluvaedjjqtwysvirayhubmswuvdtpjfeblfalkb
 * Smoking Wheels....  was here 2017 huqpubbyvcjdbwzvyewkihcohauzgfnfhatvyvlyuiertvki
 * Smoking Wheels....  was here 2017 rauavizvuoxmoyidakbgtjtzprzwbdgvmvsfsbtgzhzvznog
 * Smoking Wheels....  was here 2017 cskzcsmxmzutewzbjcrzzawymhdeelvokglacpotxnpazmga
 * Smoking Wheels....  was here 2017 gsvamfomttmcwgcmyfkjbopccoafvdnohnvhlajhxxdzfxbc
 * Smoking Wheels....  was here 2017 fyuyzfjdtluyvbarbafkkolevgrsliziseahhcwyqovohfvf
 * Smoking Wheels....  was here 2017 eseszgmtxytxnmicezflnvdiipknsnbplwmpmybbzwgxgdsi
 * Smoking Wheels....  was here 2017 smeqbcojvjswqywlcxvxfkrylxtupivilsvycvefblelfnzq
 * Smoking Wheels....  was here 2017 ozefzwpjjddbdeusvstqqphnivmzhtsrzwzjmhsgieruspiq
 * Smoking Wheels....  was here 2017 sgwhwvwhsuxvfalbqsxrbzkxjersfygfovdddfjgjdaxjuoa
 * Smoking Wheels....  was here 2017 lmevaovafgzvitjaailfbjvhedpwdijnaksuzpdpbttxevut
 * Smoking Wheels....  was here 2017 gggdaveqoqrzdsngsktxmumxsbvpypcrgojdatgvnqrfipjb
 * Smoking Wheels....  was here 2017 yfntstympholqryuuwokjpqjaocjvrvwqnadpgevfpvlggyj
 * Smoking Wheels....  was here 2017 mlqkdqidlwkoznztlztvbhtoonnthtdnpuwdhwrqswnnshhm
 * Smoking Wheels....  was here 2017 edoeqzulnghbrmhrgfmldtonybjsahyjydgpytsqysgpojpg
 * Smoking Wheels....  was here 2017 mukhuqcmlmlvkxsgyjfslybpbndjyyhkrnxipcmkauwbblez
 * Smoking Wheels....  was here 2017 feqikrgqdalzbohlnkomzhlkaorchqouagsjponuizjpqqqc
 * Smoking Wheels....  was here 2017 ihwbojllrlcyximlgomteggugbzplojbotwamwovmlbcalvi
 * Smoking Wheels....  was here 2017 dicmpidtnqljjluurjdunrdvickufeowzvusddnyllmrdowp
 * Smoking Wheels....  was here 2017 dwkwchcqfttddgecnoxcwqdvfbltldffjldiprrrgsluevcf
 * Smoking Wheels....  was here 2017 cpgtvjintbpleoqlvcnohklkaoxyjjthxvuveanwjbzbpnen
 * Smoking Wheels....  was here 2017 zniyxvzxehsqrepyvgvbcookcnvalcsoenznmyspkqjkcawi
 * Smoking Wheels....  was here 2017 cxmlrgpqygflcjrcanbaxygydzmvjsytxfcxhoiggtezqbjo
 * Smoking Wheels....  was here 2017 zfzormxwrcjsdnqqfrqvnolhzjmpcxqvczuvteojadedknyl
 * Smoking Wheels....  was here 2017 ifdtsnwxfesotjrnkrejzsjcuhnrvqbaazzfcivvdolpwqhl
 * Smoking Wheels....  was here 2017 exswysshscamcvdywupqraneyqtszcwufuxlzvzrfegfsufg
 * Smoking Wheels....  was here 2017 vnoxppyypujbrapkbmcwcgrpcnjqhrwvlcxyetxhejcewrvw
 * Smoking Wheels....  was here 2017 spwdhzgxmiagdmxpuncqdmttcgzpsbgcqxqpukvgbtwvoglm
 * Smoking Wheels....  was here 2017 rvbcwzrngbndmvfmbxgswazfcoizkfhvdmcidhhkjfnxfrto
 * Smoking Wheels....  was here 2017 rfuojukkarsexzvgdxmdojwumfnmvipmlikmuhavrwkgolov
 * Smoking Wheels....  was here 2017 aazocbxjfzpauejlnyzdvkdpxkuysucuieyoolywxbaandzg
 * Smoking Wheels....  was here 2017 dtvjspynlelnxvsrzwchneuzglsnzivrtzmjnbicdkfqhuja
 * Smoking Wheels....  was here 2017 xcsnykmeqnwwepyanooiqzanrabrwvdkacvwaqqjuvztjmiq
 * Smoking Wheels....  was here 2017 fdiuyvtywspmvlkpkjhiojibmyxatnrkpxfkqcqunkphktsv
 * Smoking Wheels....  was here 2017 lboezlgroqrzgotxdskowdlrkknlkvikifbndkgrfnrijfqm
 * Smoking Wheels....  was here 2017 akpzqarkijlheiusnjjnijishsldtlcjdzzxrxtpzuzilvkw
 */
/**
*  BooleanLiteral
*  Copyright 2014 by Michael Peter Christen
*  First released 24.10.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr.logic;
import org.apache.solr.common.SolrDocument;
import net.yacy.cora.federate.solr.SchemaDeclaration;
public class BooleanLiteral extends Literal implements Term {
private SchemaDeclaration key;
private boolean value;
public BooleanLiteral(final SchemaDeclaration key, final boolean value) {
super();
this.key = key;
this.value = value;
}
@Override
public Object clone() {
return new BooleanLiteral(this.key, this.value);
}
@Override
public boolean equals(Object otherTerm) {
        if (!(otherTerm instanceof BooleanLiteral)) return false;
BooleanLiteral o = (BooleanLiteral) otherTerm;
return this.key.equals(o.key) && this.value == o.value;
}
@Override
public int hashCode() {
return this.key.hashCode() + (this.value ? 1 : 0);
}
/**
* create a Solr query string from this literal
* @return a string which is a Solr query string
*/
@Override
public String toString() {
StringBuilder sb = new StringBuilder();
sb.append(this.key.getSolrFieldName());
sb.append(':').append(this.value ? "true" : "false");
return sb.toString();
}
/**
* check if the key/value pair of this literal occurs in the SolrDocument
* @param doc the document to match to this literal
* @return true, if the key of this literal is contained in the document and the
*   value equals (does not equal) with the value if this literal (if the signature is false)
*/
@Override
public boolean matches(SolrDocument doc) {
Object v = doc.getFieldValue(this.key.getSolrFieldName());
        if (v == null) return false;
return v.toString().matches(this.value ? "true" : "false");
}
}
