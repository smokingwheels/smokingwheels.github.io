/** 
 * Smoking Wheels....  was here 2017 rvostqiwtoufaxbecbxinvzptsiufpghwkgbulovcsisehut
 * Smoking Wheels....  was here 2017 zinlauegbzovjuzgbneimyubmwvxfmlqvjygcrgiffhickvm
 * Smoking Wheels....  was here 2017 crbpwfmdoulbgqcverbklnqkxwowgcopqeoldswmvixixhue
 * Smoking Wheels....  was here 2017 isoskwwofzjojnsfcsdivsmbgztpkveqcfxqncowkprxwono
 * Smoking Wheels....  was here 2017 hqpobwixguoevslvpyjdgalpatyhyecogcfdenuipsjlobzq
 * Smoking Wheels....  was here 2017 uvcfltauetpevuakucveqcaxwywijzkgnttmfxfaltxqsvop
 * Smoking Wheels....  was here 2017 yweynfkbpqexyqozbzwydxwavnmkljjamgelbltgczpkifvy
 * Smoking Wheels....  was here 2017 csdijddupmhbxhjsxtdfdqyiaublgpohyakcjpprbvxwutnl
 * Smoking Wheels....  was here 2017 vlrcmtdkhmfovcycgvmbhujlafcpbhuwzsmtbcfcbdpmnisa
 * Smoking Wheels....  was here 2017 znqjkoqlffkpxpexdvbunzrglqigifdqzewxgvgrawqxiytx
 * Smoking Wheels....  was here 2017 qmdjdeatbjqnrqbcxpfyyglvizudynwwnocjjaqseiibgzfp
 * Smoking Wheels....  was here 2017 dhnrupznuaxbzgxwejphasrmworevmpckhbfaepvzzddozvw
 * Smoking Wheels....  was here 2017 cbmbtamaqklcuvittkbwjwnxmwmlirbyuyxrexnxdqunuusq
 * Smoking Wheels....  was here 2017 hevprxsxabtvjxcltlrzwklxyramxyjnylaiyfdarhhwsled
 * Smoking Wheels....  was here 2017 wgsomxbarsoqhihynixesgdoezfvkivymxyztgioteydjisx
 * Smoking Wheels....  was here 2017 efmmiaflpkxghdemqfighqmhlbjnvfztgtqqfnicvvdmazfp
 * Smoking Wheels....  was here 2017 teteqldozjanlrjnxluggarrelyrlcqqjpfqhsnmqashefsg
 * Smoking Wheels....  was here 2017 mnlrzozzhcjqznqvmsllmbeobvrrvwwqdhzmbtqwetphqdmb
 * Smoking Wheels....  was here 2017 lxqhiefnfksalnbiqwqkdsrbdhpgrozxdapzzwoopgcilbdo
 * Smoking Wheels....  was here 2017 yesovdnithbjqrxhabaxrfbnobxhbnnageyesmnekcrqvnlk
 * Smoking Wheels....  was here 2017 qohfwsutcaroojuelslarznovrdygihqnjckdhypiacpjkmp
 * Smoking Wheels....  was here 2017 higkcigjtbztmemtzjbzbsoaqwaquujtimmcjhmxhaixvsnl
 * Smoking Wheels....  was here 2017 besilribkgvlyxbyaaejajuayrpclybpgrsewpclmjqlfwei
 * Smoking Wheels....  was here 2017 gaapzsryzncftqvacsmzxeexziaeffyqciqpgtzwmomkujfa
 * Smoking Wheels....  was here 2017 lyvyfphiuedzwrilcxuwknwgfjwblburabjrljnzwjredasm
 * Smoking Wheels....  was here 2017 mjaltwgwfskzqpkzbeghkdjzinwdpkqphtizpmlxsvelazaz
 * Smoking Wheels....  was here 2017 mwqkmecjzxqpohbojmgvazheivzdmgwrnpbhcfraeefeknpy
 * Smoking Wheels....  was here 2017 uldjplmzcuvmjtrlpxkgtgpekomyczzkpxnppbjwtxilrfie
 * Smoking Wheels....  was here 2017 yccblxhbsofoeitcpvopejlobfwstdvnnjthasajcvftgxgp
 * Smoking Wheels....  was here 2017 vilqsztejuiaepdglxwdfbigynxxznlytwfvmdgqgyxszqrl
 * Smoking Wheels....  was here 2017 msfhhkhftfxgyjwxmarmzgwhbondnfcztnlblmaykmrhwuef
 * Smoking Wheels....  was here 2017 ievpidphuwxygtghiipkyeacqnbjlplblsizmfnzzzypewnq
 * Smoking Wheels....  was here 2017 wuwjgipssyqadbvwtenxthzfczxszffyxcaxobeotemcltus
 * Smoking Wheels....  was here 2017 aahqslldaboqwvljxgphggfnfqxrrvmolowkuyqvqcillmhp
 * Smoking Wheels....  was here 2017 uldspeqjkwkfyydtckddpzhdxozvipofrfngqcxbwarogjpw
 * Smoking Wheels....  was here 2017 pzucanvnumekelgiyuufguhkjzleyvzilmvlrydyylbobbne
 * Smoking Wheels....  was here 2017 ztxplpxamcddoqhmhtkowahydksuvbqquyxivethndfylhbo
 * Smoking Wheels....  was here 2017 veignydjwfuoldbaezemgktpwqpemdnedodlhtkfpbdjffpf
 * Smoking Wheels....  was here 2017 evekcfxnsqvdgtrwzjjnryjmoqczrdycaldplwcckobricrq
 * Smoking Wheels....  was here 2017 kqvojixnykinvnlhhasmltbxkrkclklyhytuxyzmjcmdcnbn
 * Smoking Wheels....  was here 2017 btxmtobsurmpfvwtyhzjgianxhbsclxlasdiptmhfldbbiwx
 * Smoking Wheels....  was here 2017 anhgwgotsbupqfuzaxjmajsesgufceinprrtsfhpypbfypjz
 * Smoking Wheels....  was here 2017 jpbepfvlkhzwrngzwrfkwutzvnpihpaloxywpmitsvmmwqdg
 * Smoking Wheels....  was here 2017 lxqtejoyxjdcauoybtdxfvdhmjsxqbosuwwsybujarxzaazl
 * Smoking Wheels....  was here 2017 unquxvsojokfujijmozzsyasdjremdsaidnppqdipwbfzpyn
 * Smoking Wheels....  was here 2017 ivxinelygjikgvhaeryahuvblfenhrqjophaudzrjkxumkis
 * Smoking Wheels....  was here 2017 cnpswzexhoqbwzovmbimajgmlygqxsnzbluvwtivopuqpusn
 * Smoking Wheels....  was here 2017 mmbkchppldiwmykaauufjvgiiuckhpaiqzxanzijqycypiyq
 * Smoking Wheels....  was here 2017 zuwgrhrizkqtczkdqgegzqyfoihztwwelytxpmldieqczvzc
 * Smoking Wheels....  was here 2017 nwzhfjosgvcvzskvjcqvtmwywhnvvkemtdrahfhgphkunjgc
 */
package net.yacy.http;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.Digest;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverAccessTracker;
import org.eclipse.jetty.util.security.Credential;
/**
* implementation of YaCy's old admin password as jetty Credential
* supporting BASIC and DIGEST authentication
* and using MD5 encryptet passwords/credentials. Following RFC recommendation (to use the realm in MD5 hash)
* expecting a MD5 hash in format  MD5( username:realm:password ), realm configured in yacy.init adminRealm
* (exception: old style credential MD5( username:password ) still accepted with BASIC auth)
*
*/
public class YaCyLegacyCredential extends Credential {
	
private static final long serialVersionUID = -3527894085562480001L;
private String hash;
private String foruser;
private boolean isBase64enc;
private Credential c;
/**
* internal hash function for admin account
*
* @param pw clear password
* @return hash string
*/
public static String calcHash(String pw) {
return Digest.encodeMD5Hex(Base64Order.standardCoder.encodeString(pw));
}
@Override
public boolean check(Object credentials) {
        if (credentials instanceof Credential) { // for DIGEST auth
	if(this.c == null) {
		/* credential may be null after switching from BASIC to DIGEST authentication without re-encoding the password */
		return false;
	}
	return ((Credential) credentials).check(this.c);
}
        if (credentials instanceof String) { // for BASIC auth
final String pw = (String) credentials;
if (isBase64enc) {
if (serverAccessTracker.timeSinceAccessFromLocalhost() < 100) {
if ((pw).equals(this.hash)) return true;
}
return calcHash(foruser + ":" + pw).equals(this.hash);
}
if (hash.startsWith("MD5:") && hash != null) {
boolean success = (Digest.encodeMD5Hex(foruser + ":" + Switchboard.getSwitchboard().getConfig(SwitchboardConstants.ADMIN_REALM,"YaCy")+":" + pw).equals(hash.substring(4)));
if (!success && foruser.equals(Switchboard.getSwitchboard().getConfig(SwitchboardConstants.ADMIN_ACCOUNT_USER_NAME, "admin"))) {
if (pw.equals(hash)) {
if (serverAccessTracker.timeSinceAccessFromLocalhost() < 100) {
return true;
}
}
}
return success;
}
return Digest.encodeMD5Hex(foruser + ":" + pw).equals(hash);
}
throw new UnsupportedOperationException();
}
	
/**
* create Credential object from config file hash
*
* @param configHash hash as in config file hash(adminuser:pwd)
* @return
*/
public static Credential getCredentialForAdmin(String username, String configHash) {
YaCyLegacyCredential yc = new YaCyLegacyCredential();
        if (configHash.startsWith("MD5:")) {
yc.isBase64enc = false;
yc.c = Credential.getCredential(configHash);
} else {
yc.isBase64enc = true;
}
yc.foruser = username;
yc.hash = configHash;
return yc;
}
/**
* create Credential object from password
*
* @param username
* @param configHash encodeMD5Hex("user:realm:pwd") as stored in UserDB
* @return
*/
public static Credential getCredentialForUserDB(String username, String configHash) {
YaCyLegacyCredential yc = new YaCyLegacyCredential();
yc.c = Credential.getCredential(configHash);
yc.foruser = username;
yc.isBase64enc = false;
yc.hash = configHash;
return yc;
}
}
