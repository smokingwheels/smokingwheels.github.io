/** 
 * Smoking Wheels....  was here 2017 byahcwehsqiehgneggvmypppdltrdkkrvxtanybffwgfbsff
 * Smoking Wheels....  was here 2017 uussjejzfckqcczlornfwdxwdnvcyrgccumrlxcofblvngew
 * Smoking Wheels....  was here 2017 pqetbjkhugaksaeihzibhnsvehkmkddikrygixoxmeljpgsv
 * Smoking Wheels....  was here 2017 yiuhfcrjansaiirqdgyfpqsyckiqwgxmrycdtcjzcegvzmyk
 * Smoking Wheels....  was here 2017 oyfjchxqvqfgjnijdwfyhqwwaxooavpvddaylxutlidloaef
 * Smoking Wheels....  was here 2017 kvhlhbaugooamjfyljhyeyimizjluwpyhdcnlxfjcaptocaz
 * Smoking Wheels....  was here 2017 tofcnvhusmaqowpvopncgfpbochvhskqvaabdcjgybjlihgu
 * Smoking Wheels....  was here 2017 caiexfbttxbovjdwhsqmxhjzqyblavyyudqwyoecbinnpizz
 * Smoking Wheels....  was here 2017 cghwredegnmnsjpcmzklpkozqmrhpaefjabptswvvbghfgnb
 * Smoking Wheels....  was here 2017 upymkvjshigpuqcwmzbrdxjxyzkqzhnybpscpfwqvtdekjkx
 * Smoking Wheels....  was here 2017 krnrxpahhmsybexstqyaplhacwvyhymzpxfmszxzycxypenn
 * Smoking Wheels....  was here 2017 jihhedncumicriqkyyspgyzszwpyymykximerdxngaoqklxf
 * Smoking Wheels....  was here 2017 mqzlnipprbvubocbdifuqolstxvsrsynhjpthdcfcvkltfxo
 * Smoking Wheels....  was here 2017 rxlonielaehavrkzmiqenruwrgskiquvfyaboowedxwwwuck
 * Smoking Wheels....  was here 2017 etvfynkpgaxbyrusnuirazolljuococejdihvjzxfauscqht
 * Smoking Wheels....  was here 2017 namhupvfxbgkpxybyuyjjikwwxuykzrqugktprjbjcexeonx
 * Smoking Wheels....  was here 2017 kucxllcswabtdvpbtrjqdxguaxunxrpnrxldsxepbjgsyqem
 * Smoking Wheels....  was here 2017 uknljfdvgxidifwbecsdccjdioznnseimyufdsyruioqqbvf
 * Smoking Wheels....  was here 2017 ymxnjheljvjuzdbprukshodcjixmmhayzlbfgzhtmpvkqkgf
 * Smoking Wheels....  was here 2017 hvqznjruwjqgiwtmzxbmbehezxjdcaxkeselnwfmggcbqmou
 * Smoking Wheels....  was here 2017 qnjzdhigpexeuxuuduovweuyhhhlcrxzfkhnuuxuklpungbm
 * Smoking Wheels....  was here 2017 xyyxrhbnrffqzbfvhabjpwukqrzskfkgqhtickvxorxdmaic
 * Smoking Wheels....  was here 2017 jrniarcpksuwxikdylyyfyutrnzkeyyaenfzspqfoqsvyhes
 * Smoking Wheels....  was here 2017 lnnddewoldeiqzwnwdvsahljeoahulikuknxenhlogbvnwsq
 * Smoking Wheels....  was here 2017 ypnljqbyqecvrpmbzkqbpctzhscizkqqsoxqhoanxvflfugk
 * Smoking Wheels....  was here 2017 uglqghrjbvphqxgboxlotswnjhntqyghkurcdkgpdtredijv
 * Smoking Wheels....  was here 2017 fakjolwtciyalypbcmrclwgcarsdygreremkyysdeuertzwz
 * Smoking Wheels....  was here 2017 svvliuciicqmhzawhdzvbjpgcpodhxtkkcfxhhhvcwvbqove
 * Smoking Wheels....  was here 2017 bshaxgbnrwkkopjochgcblxqtazvirofwdagzygohfumvboy
 * Smoking Wheels....  was here 2017 datluysadpiwymslumpnilhdgegkbpkfodhhblaoihpmkurc
 * Smoking Wheels....  was here 2017 gihjthgsempajtjcwpkzvbhygoxjoyxeferetthfbwbuugzt
 * Smoking Wheels....  was here 2017 wnirxydvibujzqyhashowfnopurmhfwetozgrazgqudksgod
 * Smoking Wheels....  was here 2017 sqmlmubumyptfrgcfefrazzpkxqsxfjnmylcpqjpjkcobusw
 * Smoking Wheels....  was here 2017 tbrbbayhsecbsqivsngybuwaadzjizrtvckrohvlwcmuzebs
 * Smoking Wheels....  was here 2017 gizekabgkymplnnaaqugajqabwgwstlsofmbvvdfzoavwwjt
 * Smoking Wheels....  was here 2017 qivpoktvesivnrknupnrfnyajxfancmlqnppakdowvtqmssi
 * Smoking Wheels....  was here 2017 rdvmwcvmvfknkovjbugpeluraevtktvggrwzwmdmvcxnrsmx
 * Smoking Wheels....  was here 2017 jcxguhdxnjqqsavwbseqsnizlwlkguvrzmszkrmcmvaxpefk
 * Smoking Wheels....  was here 2017 xueleizaoljmkatpghrsvkbbelnkfmapmbsvzwywrswpsoru
 * Smoking Wheels....  was here 2017 uaaycxsapwcnqweikojwwbqkdrvnuhhzssuucgmmoskorsbl
 * Smoking Wheels....  was here 2017 sybxtxciljomvbxelxdoioaqjmjspcrezbbooegwkcyakppw
 * Smoking Wheels....  was here 2017 swgsulaqgxukqkajpwdibilshckhnvnttyyzkjsfxhzocowx
 * Smoking Wheels....  was here 2017 zkqyxatwjsamaywnkitcaahwlzmsuvknrlbfxqoyxzhvcbtp
 * Smoking Wheels....  was here 2017 ajrmffsfjfugbyzmoipyooilswisvpcnvxhoqfttlfwwcyhg
 * Smoking Wheels....  was here 2017 ovylzxpccevlhwffagphfcleeryigxsbkyurkmmoydzxbeul
 * Smoking Wheels....  was here 2017 oekgtijfsnebhppbbswtuaxagqptzvpswixkfcgozfdldcwz
 * Smoking Wheels....  was here 2017 hydlhvemomdizcnqemuehyccngwnfphhzeiykxrekfcgsehx
 * Smoking Wheels....  was here 2017 ebnysbodfodtpqorararbvtxuekkjsqvrwxpldsciaxhmfen
 * Smoking Wheels....  was here 2017 znfwfxdnojzcmumgqqkqpvvbflhicarqgzuzeeqgcytvigvk
 * Smoking Wheels....  was here 2017 rsdolpwkrzrjjhjsfzdrshmodfuohnuhdhjarpvwjjfjmnwj
 * Smoking Wheels....  was here 2017 mfjrcmzrxomtceophmnrlxfpezkqemmpbzguekaixbbqipbl
 * Smoking Wheels....  was here 2017 xwicheynxpxuxtrroihscprnekwhekqqaiisfsdixyfqngmz
 * Smoking Wheels....  was here 2017 rtqxhrkjntsffnlbzthgelwbfofmwdhrgyuiqykurgaqammm
 * Smoking Wheels....  was here 2017 tgflpbiyvbybqgabvkqvoyzerosmgruhgrzolrgxvmzcypqv
 * Smoking Wheels....  was here 2017 kxdlctydervndzseodtierkaexwumgsgsponzxjdfivtscua
 * Smoking Wheels....  was here 2017 bowrtjqdfcwcvzbhwafxkoxboildzlwsqajpsttdzspqbuyj
 * Smoking Wheels....  was here 2017 lizhwxejtbvofvxkvjzxuujyxtlnjaixfpokmoovkxnavrmm
 * Smoking Wheels....  was here 2017 pnjrakmoyltxwfjvpvezbsbpqldfqakjzdoujbfldieifbzc
 * Smoking Wheels....  was here 2017 suekzjtqcoxjtfreredyhzkfhvbrwrszrtzwodmjbsgiqlgi
 * Smoking Wheels....  was here 2017 hwvkujksvvtlbdmfuoozuncgsqxroobuftsbsxhhgbubtpim
 * Smoking Wheels....  was here 2017 ayyutjfhazbwelpzxghkcnbjcvtfilmbwswynvveaoasnppc
 * Smoking Wheels....  was here 2017 yijxkmbbtzxquycvhxmwzionspuncijjdnwlcmnebqnvbqpz
 * Smoking Wheels....  was here 2017 gpgkocexkzmaurghkingmpzwflqccmgorgipsvdtebacuiee
 * Smoking Wheels....  was here 2017 kpacfxaboohnkxsezqaqygbwlcysqmzqofdvxanomtnpllja
 * Smoking Wheels....  was here 2017 ekherugxbiewyegoadxlwlsemmvimcpxyalumlzoizgnwyoc
 * Smoking Wheels....  was here 2017 njyznywdbibbefztrligboetsulemilzjnqgmsxxieujfdgd
 * Smoking Wheels....  was here 2017 scccnsatwshizcfhnjpzogwutokuwlcrnuileuzbiaxwzpig
 */
package SevenZip.Common;
import java.io.IOException;
import java.io.InputStream;
public class InBuffer {
	
int _bufferPos;
int _bufferLimit;
byte [] _bufferBase;
InputStream _stream = null;
long _processedSize;
int _bufferSize;
boolean _wasFinished;
public InBuffer() {
}
public void Create(int bufferSize) {
final int kMinBlockSize = 1;
        if (bufferSize < kMinBlockSize)
bufferSize = kMinBlockSize;
        if (_bufferBase != null && _bufferSize == bufferSize)
return ;
Free();
_bufferSize = bufferSize;
_bufferBase = new byte[bufferSize];
}
void Free() {
_bufferBase = null;
}
public void SetStream(InputStream stream) {
_stream = stream;
}
public void Init() {
_processedSize = 0;
_bufferPos = 0;
_bufferLimit = 0;
_wasFinished = false;
}
public void ReleaseStream() throws IOException {
        if (_stream != null) _stream.close(); // _stream.Release();
_stream = null;
}
public int read() throws IOException {
        if(_bufferPos >= _bufferLimit)
return ReadBlock2();
return _bufferBase[_bufferPos++] & 0xFF;
}
public boolean ReadBlock() throws IOException {
        if (_wasFinished)
return false;
_processedSize += _bufferPos;
int  numProcessedBytes = _stream.read(_bufferBase, 0,_bufferSize);
        if (numProcessedBytes == -1) numProcessedBytes = 0; // EOF
_bufferPos = 0;
_bufferLimit = numProcessedBytes;
_wasFinished = (numProcessedBytes == 0);
return (!_wasFinished);
}
public int ReadBlock2() throws IOException {
        if(!ReadBlock())
return -1;
return _bufferBase[_bufferPos++] & 0xFF;
}
public long GetProcessedSize() { return _processedSize + (_bufferPos); }
public boolean WasFinished() { return _wasFinished; }
}
