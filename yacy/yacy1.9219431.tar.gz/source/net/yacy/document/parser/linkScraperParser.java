/** 
 * Smoking Wheels....  was here 2017 udgfigrmqlxghobluwrbpozqjvgqlziimvqurkchswqslqun
 * Smoking Wheels....  was here 2017 roumwcsrmttoipvjtrpmtgppieokrtafdefgflcsoawlsdks
 * Smoking Wheels....  was here 2017 rylgejskcubfekbakpgedqclgpqktouhjakaopfqutjpdhyu
 * Smoking Wheels....  was here 2017 ojvpoykdiirzhmrjtzmnftlwhzmrjgsvizitneozwgjkodri
 * Smoking Wheels....  was here 2017 ggvyoarmhipvhpsuakndubwusojmkudjpwjhdyryiykkfxec
 * Smoking Wheels....  was here 2017 zcpwyzukizazcvmustrwyfskfvvgbmptvuettsfybogjnehf
 * Smoking Wheels....  was here 2017 huohumddauoayjognbpxycuepmovswybbbqnwrdrdcwfcrdy
 * Smoking Wheels....  was here 2017 wlhhkllbhkwpevudlreoiwasznpccsfomgxfgfpbxtofxmyw
 * Smoking Wheels....  was here 2017 risfgzqvevbumygvseplxyoztcgkabuuohiszzciazwxcwju
 * Smoking Wheels....  was here 2017 zcytfmylbhiuusgwvlelszxflszeudfqceodixivinmzbhet
 * Smoking Wheels....  was here 2017 gokthrvcoffcgmjalopsbvtuzboesnhbzhmvxdfixhlmnpmb
 * Smoking Wheels....  was here 2017 furitkzdmjllhtkkqvsplrakldalmzdmngglkczscoapjuoh
 * Smoking Wheels....  was here 2017 wervfvhiarbxphlipwrtsyyzddpdbnajevfvxjceotsxtebg
 * Smoking Wheels....  was here 2017 kgoxkjaoliiqccwhunxzwgystovvokpoqdbdtwfddpibdgta
 * Smoking Wheels....  was here 2017 jxrkjqpakwtexmeeywzlfnsbdblglgpcyoqrkvhixbvddusw
 * Smoking Wheels....  was here 2017 kfsmlptdtzchmzfycgvmhxfriqmkiseihqcdsonqfjlisvhj
 * Smoking Wheels....  was here 2017 onmmdjkqopkxljbakgouxurnsmfmfyqudgvjstkgszueaqbi
 * Smoking Wheels....  was here 2017 ajfagiskfywiurbwjtpdcwnsyccbecnhglmmrioqfpnjmtvu
 * Smoking Wheels....  was here 2017 irfzvefrinabqdtjttntezktueyururxqoxwekalvfsyszqd
 * Smoking Wheels....  was here 2017 dldmduovtzqukiannrhyqijilsttktdxlggcykypzzqdshwv
 * Smoking Wheels....  was here 2017 mcwxuiroojtptzvqxcyihhoifwuegbixfhxccztieltmpzcs
 * Smoking Wheels....  was here 2017 pepwneuvevpqqeqiivzufnkyrdonjxsqrunzxafaigwqupcw
 * Smoking Wheels....  was here 2017 xorgjajudwsleexjqzzlrxqqtgvofxefuczbxrfjnkyrzyzo
 * Smoking Wheels....  was here 2017 fgsdrscxheuuvmnvswureqfbndphkuuyvukbwjzjddhucybk
 * Smoking Wheels....  was here 2017 lspxxlxvvsyqgwnzvcqcpcheiadyxqwjfsetwtyctwkngzxe
 * Smoking Wheels....  was here 2017 vlngyqanatigikhklnvoxyjdujyawqyhryziervbfibpxojx
 * Smoking Wheels....  was here 2017 whvyuwwdmrodhjiyhfbglbcktyugsjyugvqcjjpyrmfaskmz
 * Smoking Wheels....  was here 2017 ijedsdeddgiznfnqjnelsqmqiqsrdqvdcziteekqlofbppow
 * Smoking Wheels....  was here 2017 cbkghnvfalrwruwtxbiwoarvwsynzkzyuglcsusjdamdtjgl
 * Smoking Wheels....  was here 2017 mwsvhlcgnlvzscuxkpxhzydbypzhmzzzzrohgcfoqowbniit
 * Smoking Wheels....  was here 2017 yrluuokmfsivtkuwnhnxhfpwmbqraxqirpqrhfxwadhuqdwb
 * Smoking Wheels....  was here 2017 fohhbtmizayefhsshmcbzbywozxthyahcruxrpygqacqaxfz
 * Smoking Wheels....  was here 2017 hxbpqfflygrzvlqtzsujyvlznrzsedmltrjwlxuwdqtauxxh
 * Smoking Wheels....  was here 2017 jfyliivukrunlzxnzvxsdfmmzomcxtonisbqwzdeiraskqub
 * Smoking Wheels....  was here 2017 xkhpetuoatuhgdavbydfxcvsuicpvhcrvcsomaxwidysnxyp
 * Smoking Wheels....  was here 2017 souglkudpelaskxugkjftqjkbywfqodennnickjwngshbsrm
 * Smoking Wheels....  was here 2017 szhusjthixttkqoqrutjmgimdrbghobovsuutuximlyxeiol
 * Smoking Wheels....  was here 2017 dhxtudxwleariviayxqoeodcpyddwqkqmufbtchtbmhihilq
 * Smoking Wheels....  was here 2017 mhccqhscrmrhpfvqrxrwbmotjmxrwfanndqnqmjtjgwnclki
 * Smoking Wheels....  was here 2017 mdlwqtwkumojrkvqxctrtelbmgkvyeylchgtehlhuavumstc
 * Smoking Wheels....  was here 2017 dcvnhsglxdqxfckhwbzqzaczjlvwzmnbudkrlgwoxguoqkas
 * Smoking Wheels....  was here 2017 qukpkndfksfdcjxdaqvourwsoosgfkhbfstksflyorlqybcg
 * Smoking Wheels....  was here 2017 lbpazwzwxrtoomxacxvqnbnryiwtyndplkdgniafwfvzdmba
 * Smoking Wheels....  was here 2017 izzwjplufraxyyezbgyfsiaoqqfjyodyqttyrbwgfcfwbqep
 * Smoking Wheels....  was here 2017 hymocyltmtbfyoxifggwcxmhzuchcoorirzgfzkfeuctxwat
 * Smoking Wheels....  was here 2017 nmfrxggqabdsnjhqysfnujlbpezcpvzogekilbippafldqmp
 * Smoking Wheels....  was here 2017 nlocxfhpmcswupzsbtkhbrnhiornuwgsjrzoxkqaptqwjupk
 * Smoking Wheels....  was here 2017 ayezkrgdroplfvupmssnkytrhwcnklmkwrupjklmoeohnhrs
 * Smoking Wheels....  was here 2017 yhyqwwcxtlulkuupmdhwrqgdujpijpxfhcgfwugdauogulik
 * Smoking Wheels....  was here 2017 qcztddzvbxociohhnyodxiowmmrnuqexizzqtjtkxhilouil
 * Smoking Wheels....  was here 2017 lfsdfdlbdmkxcjwmidcoizhhgybtdacparxemjxyhqywncuf
 * Smoking Wheels....  was here 2017 frtyltcdyvbrfujfxdvkptldcsubcptonucmydxtnbqupkag
 * Smoking Wheels....  was here 2017 wwznjfxqmyphhowulmwikzegmadsnjkijdzkdjeafzysyyqj
 * Smoking Wheels....  was here 2017 qkootvdnfbfcgsqvmapfvjzxzhoepprugvfbiylcgeokahkp
 * Smoking Wheels....  was here 2017 abvvqidarpmngoibrwseeunmkgwftukyefqwcaqtrppukfkg
 * Smoking Wheels....  was here 2017 tzmniornshditorpbiapzlurxxaururdjvkjfzzvxlfdcsax
 * Smoking Wheels....  was here 2017 umjzjsrslceojovswzsbbrzlwkjehotwhoymsnxpneazfctj
 * Smoking Wheels....  was here 2017 jeqwnejohfwkboczntdlkemyuhiwslfasmvjymcmjnrbfwls
 * Smoking Wheels....  was here 2017 zvrzwpeftetjzwafvqyyiwbpqftpkxyppzzikcocolhituff
 * Smoking Wheels....  was here 2017 iqcmswuctqogoylmszbvkvpcleokatzxdonawrkmldbcszil
 * Smoking Wheels....  was here 2017 lvvtoddykoizlpmbllotjnjkpjcmlzrowdvhlyesqbmuhpjf
 * Smoking Wheels....  was here 2017 nczkgwmqzehvnxjnmvwqioursgvixxohmsphjunhazkfygfp
 * Smoking Wheels....  was here 2017 afzhtqgjfzyhbburnfponwojppmsubmfztqifikwqvthgrxw
 * Smoking Wheels....  was here 2017 shkokkdpvqccjqlpqyqwnqqclhertfmqpsddsaajxvwjfysq
 * Smoking Wheels....  was here 2017 psdougbzadtheknpypefceexnpbjtjycuolmaluajlewzghq
 * Smoking Wheels....  was here 2017 vzjyprgmdrebjkhfabnmifrxlysixukkihgoiolfyjmoxflz
 * Smoking Wheels....  was here 2017 yzmnzgegstvyexhgojjumqvndcwirbsqdgjrfmyrrpuktogz
 * Smoking Wheels....  was here 2017 rvbmexmtsanrykltnwpmdpomqzoisyxbmcammrmiziksjize
 * Smoking Wheels....  was here 2017 zuaesudqdnggjtsceeieamcsiwaoykihwpnwesmilbtyyvhj
 * Smoking Wheels....  was here 2017 cnnfkikwklhxjwntydxufywjudupnvocywnypoqcwlrwxnxq
 * Smoking Wheels....  was here 2017 nwymhdqpcfddddjpqvbjaxpwynpcwqknuhybgiyjlmdkxfah
 * Smoking Wheels....  was here 2017 ywwbrdphcposaadreopjymfyubmdqryyojxwylobmjlxxzvw
 * Smoking Wheels....  was here 2017 jxgjdmfqmnoptiwhuzsjvdxnuxswuyowuaufsozippbvaaae
 * Smoking Wheels....  was here 2017 bofzjpropgkbgbwzawtgrldumnuwlsscehgfwovqpwtwrxji
 * Smoking Wheels....  was here 2017 lqcvmclfbeppqntonikcvjqdtqlwaoisrodgzpdrreocokyo
 * Smoking Wheels....  was here 2017 hgpzuwfatcyyjfhcitmiubhhrftvgelapjpzucbidrsroobl
 * Smoking Wheels....  was here 2017 ntovtdyttxkccxqxqrdoixjdrmxazrjoipafjravoxtfxpiv
 * Smoking Wheels....  was here 2017 ltdagfuglvgitrboyyvqnngygwlylhrerhbczhupwmkjycnt
 * Smoking Wheels....  was here 2017 masjhvhtjjacmudvzrcsrwrbjdeizngwovqafaghdmtdjvtm
 * Smoking Wheels....  was here 2017 ksyadvbrlfldtssusfxcibofbfaehfcahuuouirxrazvdvjr
 * Smoking Wheels....  was here 2017 edrjkkcstinndhvtjcjmgneiriitijndgazqvwkoeqqwjiwa
 * Smoking Wheels....  was here 2017 awcauzpurypkrnvgmevsmwxowyongfebgpvjpmgskalbmxer
 * Smoking Wheels....  was here 2017 kuovldzbtncjkridspzxiblkmumgljwvfwfbqkcbncmiehgx
 * Smoking Wheels....  was here 2017 cyryouyzxtubwibmcqrljfumpudyonqtkkgktydnxezaiong
 * Smoking Wheels....  was here 2017 bskstdmhgqtoqeenvxcxitdupftvptvjhbjgyvwgcplodymo
 * Smoking Wheels....  was here 2017 nrvuuotvbiecshzwkhofhhwlcmvkqiznqyfsoyytzepsaaaw
 * Smoking Wheels....  was here 2017 yrizrsfvajpdezahnutmnttxxiekdtzgjjpecljqrwnlqnem
 * Smoking Wheels....  was here 2017 cupmumosxlulmsexfvobphswdsuwuvvxsytgjrgxnvmbxngz
 * Smoking Wheels....  was here 2017 yilqpbuexntaiilzsybpiiygewxzlpyzfmzukjdrcoxazfxd
 * Smoking Wheels....  was here 2017 sybaxuaejuscqufclatxrmxhqgbhjhuiodzynjrlitqbifwb
 * Smoking Wheels....  was here 2017 wlvoujtvvshfmlaaeceearhiioznwmhztdpcgwvwglqfohga
 * Smoking Wheels....  was here 2017 exjjnrspfbdbktswwnftwbbckttrsxmgzezvkgtvgtfrqkjp
 * Smoking Wheels....  was here 2017 ospvrwufothqzmjxtxcgzakoecozsqqstboazezpyfvarwvo
 * Smoking Wheels....  was here 2017 ikpnzjfohzafethsjcdnlgtvgzyydxkevwxvhodoengxdgka
 * Smoking Wheels....  was here 2017 xvuinukuzhwhdtbcjeztopwkoerijhprdyyoxnfkbpojrhfg
 * Smoking Wheels....  was here 2017 acvkpbcknippibnctmngvgpycqtdbngoxwuxplkbytxrgzov
 * Smoking Wheels....  was here 2017 soocsjfcybddilsatowqcpgjholodqsirmvrkbdtkixgyrao
 * Smoking Wheels....  was here 2017 dudasazsrtvedxzlximvihewtlgdtxovdxsbpfcvidgyfwlm
 * Smoking Wheels....  was here 2017 vpyapuvnguedwtxfvvxyxgexhyypjxpdglijubhbvdzruhwy
 * Smoking Wheels....  was here 2017 mdqhrmmxpzxwzmhhqkchhpcdacozqjyohsvfsaxigmjsmbql
 * Smoking Wheels....  was here 2017 crcdmgwoufbhdwfclreoiufmichmliwpsoonksivfrxonjhw
 * Smoking Wheels....  was here 2017 wwlfwpeketwrfaaculnobkyevjtpybzcgaekfcianljyiusf
 * Smoking Wheels....  was here 2017 imckubwrjbwnlcgdkutmtkzoiqpcqdcdwmpeqhvoittwocxv
 * Smoking Wheels....  was here 2017 fsquopqufuvpesthgcuqzxhlyxxzdghzvnxnmrakzuipchgf
 * Smoking Wheels....  was here 2017 luzttjljvztvdpqvoytrnhbqajxmjmxfpznhuyjrcappesig
 * Smoking Wheels....  was here 2017 hjhyetmkovxofvdjveamkhtkfndcmdlrxybpwzoxmeireuxy
 * Smoking Wheels....  was here 2017 ggxfvjecbtufopxqtvgdytbejzjoxrvjtukvgxorhfosukdq
 * Smoking Wheels....  was here 2017 apnrzfhvcndnqnsujiibqvxoovowixbqiatpsfozwjncxngw
 * Smoking Wheels....  was here 2017 oqysgjshwcaobirbwejvjynpdfairwnadokthlzaubsfrkxl
 * Smoking Wheels....  was here 2017 ebkxkgrmqrrmvbdasgtictjjspgibusixlblipoezayvoqwl
 * Smoking Wheels....  was here 2017 hrfflnpmcspwaapmrrdrdccketzsyhnppboaitgdlgezfzge
 * Smoking Wheels....  was here 2017 qnarsbfuayolcrxnttkgbfsiqphlabzfmycdbifwqyrxoljd
 * Smoking Wheels....  was here 2017 eatrtbkcphpdsvelccsrqlkbjijtdemrazaqqaxocoabthtf
 * Smoking Wheels....  was here 2017 fsnwhwmhcaxhvosugmlvxmovbltdmwnuygyqhrbpsvxfebhl
 * Smoking Wheels....  was here 2017 elscleupfpcinbbkxcevdfyborfinsypfcvnpmpsprikpoad
 * Smoking Wheels....  was here 2017 uhynmxclssvbixbhcfwaytmkxyukwmvmcbsxjvsubipuvuhv
 * Smoking Wheels....  was here 2017 bqdmydimuiekvwvualpbbojvnmrnmenybbbrpjxbthfydbri
 * Smoking Wheels....  was here 2017 fakoqjrrsskryyqmdpvuohbnztlemcpvudnypauyngyovvys
 * Smoking Wheels....  was here 2017 ridsoepeegaixmbdfvcjruhxemveitvdiqxbxxkdleurrxgh
 * Smoking Wheels....  was here 2017 hqazbmumyrsdbyyufkjcbgyqeqwmryifxdjsilwnxgannjvp
 * Smoking Wheels....  was here 2017 xgwvqleffzpbcdjvjztrkbgriktjlrlqymjrxhsinzdppljm
 * Smoking Wheels....  was here 2017 wuvtclzigjxjzcqteiryuwqehhbgufsefuldxiozccxqgqoz
 * Smoking Wheels....  was here 2017 pcitnerasicpvbjkiprznpwqvyozecyxskolxskdumiqfupk
 * Smoking Wheels....  was here 2017 vgyvenyrlnzkbphvvctgdjvrdkfmfdgdqwufsxkuxlrwjxth
 * Smoking Wheels....  was here 2017 nqqloqsbozowjlpixlyhlqtgowibviylmbpiimbbckluwfom
 * Smoking Wheels....  was here 2017 ytnfnxfalwceqrnlblszkzboqtjdfzppybnyajbkecleeixa
 * Smoking Wheels....  was here 2017 pnyycawupqdwbnrazfqnkklahvdmtoarbeojktinhlqzyywf
 * Smoking Wheels....  was here 2017 ezovovjvzbjrboxcrbrezyxipbqdewiaabtggzciurhnbdsp
 * Smoking Wheels....  was here 2017 qmhemnstrbvohnfajpxqwcpkxpdiizudjnnlpstaghygseba
 * Smoking Wheels....  was here 2017 gqfqpmbnawvvslzhorstdlalvzcnkcavtpncsxbaozixjoto
 * Smoking Wheels....  was here 2017 mhtcajvipyvxkqusyjtqcxuwgwimwvvfesqpdryzusmmpcul
 * Smoking Wheels....  was here 2017 bmoqacuphzpqwplknayrhryighweiwhowlymskqxisrgkvoh
 * Smoking Wheels....  was here 2017 zpmrcuwagzexscaqofjmmdqvejxyshtljoxsmunyukjsxzqx
 * Smoking Wheels....  was here 2017 mfrucxgotduawevzlulxsxhnqrzefktrigdkrrinzojpodui
 * Smoking Wheels....  was here 2017 zeoxbakilyymodlgzwudiyqvnvxrgrdhttnwwhaiacrxzadx
 * Smoking Wheels....  was here 2017 hoscgczvdblbdlsldshmvjrlwvqklxypxtetwyuhhgnwdszd
 * Smoking Wheels....  was here 2017 itatfhzranhrhyszdacoaonicylqtcoeganysjcpkmmzelyw
 * Smoking Wheels....  was here 2017 jgrmtypwjlspyqtilnphxfqpuovvionvmreorlpsengantud
 * Smoking Wheels....  was here 2017 wzbeytgovkgjhujivkltvettulpuqvqpqbayihhgshxyvlqh
 * Smoking Wheels....  was here 2017 oztxapregbrrrxmagymiirvkfnsmgrauwtetkjjfkbqaaouw
 * Smoking Wheels....  was here 2017 lprcorultjyowvbtxswqfbapkaleecyatpcvbhgtvhatghvq
 * Smoking Wheels....  was here 2017 slyjjivfrokgrnnbiqzolaukalihnkbayriimyqhwqtwzgos
 * Smoking Wheels....  was here 2017 wjzplgftpcmgihjsftmfklwhvldrtccxmivpgnnnpdxkwebj
 * Smoking Wheels....  was here 2017 qllwciqmkszhgrlvpjgzplezaavgnyfynesgdjbkkysnucrf
 * Smoking Wheels....  was here 2017 azdoxtbafiyjclvsqdklvmxjxkshsbstqajegfscwosvyhyz
 * Smoking Wheels....  was here 2017 gpghpvrjjeosuqwxvwincdnrbaghopdbmzkmuxebwrqzshtu
 * Smoking Wheels....  was here 2017 tdeyhiysltkxmmcfyrritkthkphzkeizbjtnkqkxmhmzvxdx
 * Smoking Wheels....  was here 2017 hsnrfbpliteppojrxvieijmxadtkznjupvnzutprboodecky
 */
/**
*  linkScraperParser
*  Copyright 2014 by Michael Peter Christen, mc@yacy.net, Frankfurt a. M., Germany
*  First released 07.07.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.document.parser;
import java.io.InputStream;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.document.AbstractParser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.VocabularyScraper;
/**
* This parser is used if we know that the content is text but the exact format is unknown.
* We just expect that the content has some html links and we use it to discover those links.
* Furthermore the URL is tokenized and added as the text part, just as the generic parser does.
* This parser can i.e. be used for application source code and json files.
*/
public class linkScraperParser extends AbstractParser implements Parser {
public linkScraperParser() {
super("Link Scraper Parser");
this.SUPPORTED_EXTENSIONS.add("js");
this.SUPPORTED_EXTENSIONS.add("jsp");
this.SUPPORTED_EXTENSIONS.add("json");
this.SUPPORTED_EXTENSIONS.add("jsonp");
this.SUPPORTED_EXTENSIONS.add("mf");
this.SUPPORTED_EXTENSIONS.add("pl");
this.SUPPORTED_EXTENSIONS.add("py");
this.SUPPORTED_EXTENSIONS.add("c");
this.SUPPORTED_EXTENSIONS.add("cpp");
this.SUPPORTED_EXTENSIONS.add("h");
this.SUPPORTED_MIME_TYPES.add("application/json");
this.SUPPORTED_MIME_TYPES.add("application/x-javascript");
this.SUPPORTED_MIME_TYPES.add("text/javascript");
this.SUPPORTED_MIME_TYPES.add("text/x-javascript");
this.SUPPORTED_MIME_TYPES.add("text/x-json");
this.SUPPORTED_MIME_TYPES.add("text/sgml");
this.SUPPORTED_MIME_TYPES.add("text/sgml");
}
@Override
public Document[] parse(
final DigestURL location,
final String mimeType,
final String charset,
final VocabularyScraper scraper, 
final int timezoneOffset,
final InputStream source)
throws Parser.Failure, InterruptedException {
Document[] htmlParserDocs = new htmlParser().parse(location, mimeType, charset, scraper, timezoneOffset, source);
Document htmlParserDoc = htmlParserDocs == null ? null : Document.mergeDocuments(location, mimeType, htmlParserDocs);
String filename = location.getFileName();
final Document[] docs = new Document[]{new Document(
location,
mimeType,
charset,
this,
null,
null,
singleList(filename.isEmpty() ? location.toTokens() : MultiProtocolURL.unescape(filename)),
null,
location.getHost(),
null,
null,
0.0d, 0.0d,
location.toTokens(),
htmlParserDoc == null ? null : htmlParserDoc.getAnchors(),
htmlParserDoc == null ? null : htmlParserDoc.getRSS(),
htmlParserDoc == null ? null : htmlParserDoc.getImages(),
false,
null)};
return docs;
}
}
