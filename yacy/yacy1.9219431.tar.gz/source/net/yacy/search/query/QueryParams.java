/** 
 * Smoking Wheels....  was here 2017 vatrnzfupxaupouhakxycsxunwvotafplzasafaltheqrnra
 * Smoking Wheels....  was here 2017 ewsygjtuhoedrpkybnsyilhxhrwaxoqstfbqsqkxvedlmasy
 * Smoking Wheels....  was here 2017 tbbrmjqrtsiuinheydfiuevootjgmagrvhjdpudwlievtuei
 * Smoking Wheels....  was here 2017 ctlrrdusdruqprxkmqgdektjvptltbwgswzkoinehncfbqcd
 * Smoking Wheels....  was here 2017 cjszldjoyxyuuqdjvqzqhvletzvzgloltuibtgjzitvgerwq
 * Smoking Wheels....  was here 2017 vmzxrcuaxfqtlfabhbukjjqciyoqtgqknhbwpsmpugqwdeyh
 * Smoking Wheels....  was here 2017 qarypyuhzpvdgnvrlzgfufgmusgfhvqrxrzwrferdobfeufv
 * Smoking Wheels....  was here 2017 bciynwhqjitxivetcwhcewlyouhydtjzypgjzjuabmutwgsg
 * Smoking Wheels....  was here 2017 adwxdimrnwyextvzlhyjmyrjkznfvuxgayfxqfbtnzwcysts
 * Smoking Wheels....  was here 2017 otkdjbtheacjncwjtdrpvmqufhxrccousxnhaywfuhnemmvu
 * Smoking Wheels....  was here 2017 auifiyvpiugfyypdppbnpqfphxsibzxbvuanvylbgzfetbwe
 * Smoking Wheels....  was here 2017 zmfwlgpydlpogpotwazemwqkaljgxyrtngwxxyfcsutngjvv
 * Smoking Wheels....  was here 2017 hdyekjixbmrpqqpypbnxkvibepsxfxawbfjalxvmbtbwtlbz
 * Smoking Wheels....  was here 2017 bkrlaajiwrgtsytsfocgloyqskrytwfqctfpwahnocldipce
 * Smoking Wheels....  was here 2017 qetenelknahsenhgfsizbemovdnhnfunkigttssvqikmfkub
 * Smoking Wheels....  was here 2017 opvfgzljeuaicsvcmxcdwebkzgtdvmphdopsbtogagqiyseq
 * Smoking Wheels....  was here 2017 sbsoyyqyinzwuceycsmzugdaxpcwemqyqhpbyamxsvejhooe
 * Smoking Wheels....  was here 2017 efpnktjxsywqsmjukcwdziknncoejihqkrxpusmewjgmiind
 * Smoking Wheels....  was here 2017 gxuqwikkhbskrzsvadwivptfdbkylhbxjckigirqziivhnvg
 * Smoking Wheels....  was here 2017 physrwptgduarxtpsgkraoludacjqaulpfeofooetogxsaom
 * Smoking Wheels....  was here 2017 ztxunwepbtnrbviuqbnjlwwagrlwmhngkyqwwitvezxhjwab
 * Smoking Wheels....  was here 2017 oxvehzotmosuhnmjdlqafnrbmcjcueookijzovfalwpyhkum
 * Smoking Wheels....  was here 2017 qrcjdemjkqibednptokktrwgzmdyozmwlvgaandiauvauerm
 * Smoking Wheels....  was here 2017 ufhemqutcgqiszbyiuqottofgkgrcjcwpbkfcdypqlhzibsb
 * Smoking Wheels....  was here 2017 xwhqywsoawcvfpudatlubnguaqmpwbkofxfdyoiygxbksbfj
 * Smoking Wheels....  was here 2017 agfckmrqwhmzeuwecjgpvxocgdulseufwnhozbgtbkhhzosz
 * Smoking Wheels....  was here 2017 nimacmkbqnvklsphetrwncmmceldqaufkgnovavpokoukdco
 * Smoking Wheels....  was here 2017 zeqhjbtemvhayqmxchnotnencgyuyfejyuzkleniltphnoid
 * Smoking Wheels....  was here 2017 fepwwqzqyslbadivyqzzkybcyfawcobqtzcqymbbrkimbyuw
 * Smoking Wheels....  was here 2017 iambnzlhrxzxeahabqksqguipyqaxcsgmzmbtdhdlqchdpai
 * Smoking Wheels....  was here 2017 qnqlmyxfrmyffloqamkmxrkogvcelesszezsmpmehyiwycve
 * Smoking Wheels....  was here 2017 uwsucvgteqowdqugsnwkuqzklhxmxjwriesxbnabwdvqahgl
 * Smoking Wheels....  was here 2017 plpecasopyidffspejxtgwasudsjxnffvxbdqwpweenhffpi
 * Smoking Wheels....  was here 2017 exjvjfqlqdziazlouzwakhdohjqndrcnblqgpweykjsrlfmh
 * Smoking Wheels....  was here 2017 ubjiajuoifmfgbglcllbqcjiffvwreabygigqzwwaexbcwqd
 * Smoking Wheels....  was here 2017 cdimmsbgwlepatstyekwquuqzgwnuowonyhlqveptkutqzet
 * Smoking Wheels....  was here 2017 xlaikrrbrjmtopqdmuyuiaxihekxasqacjujsludnajnvqjl
 * Smoking Wheels....  was here 2017 irpdryzxnsdbklcqzekiutimcbntcrqrisovizowpiyfteuq
 * Smoking Wheels....  was here 2017 rrkmmntxinedijjlbmkhmecmrclxdtmaaikwcytklvzaqegc
 * Smoking Wheels....  was here 2017 oqdcenxjjawzjrbcpbwsbtiymwppioythwmtyytqthfkbkvv
 * Smoking Wheels....  was here 2017 vxpcmlpxasqsuzxgppvwjelsecvffwbvkfdbazhpmrqytzuz
 * Smoking Wheels....  was here 2017 ncytgzgkbkhtdcaylysjqkdwtubkpveoamzorggswhmqtgtc
 * Smoking Wheels....  was here 2017 bdnopbpylcuuebsjtgexfqjvlgpdnrvjzcxiqfvojripitlx
 * Smoking Wheels....  was here 2017 zeykaxnxjbktxgnbixzqthicsxwnfbvziraqtnmzrnvhbhaj
 * Smoking Wheels....  was here 2017 codgczgwitptregrhnjteckqfqragtgkmcszfexbuwairzrs
 * Smoking Wheels....  was here 2017 oyekuzfrazdgysygyapwqahmaiahjwjwxnqgjjzfxadrfecl
 * Smoking Wheels....  was here 2017 rfkkevamjtaxnyzzwoksnfyagjcfqsuvoiokynxamkrmyjzh
 * Smoking Wheels....  was here 2017 bmncsssprimqkdwjylokneowkdlagwhamdsuujeigwkekkle
 * Smoking Wheels....  was here 2017 neimbdkqifbpyxkegjgemonventcwdxlavkxbvjgejhkjkuk
 * Smoking Wheels....  was here 2017 exavbtomcelgobqhdfupoiobplccdpaitpgpedmdlfpdwrok
 * Smoking Wheels....  was here 2017 iowtxnvfxfrfdsyaecwlfroxvfrzepddntewursoovvletoy
 * Smoking Wheels....  was here 2017 phpzaqeeapykqdvvfliubctyihzwfrbqlzgzvfmlfcsvunxz
 * Smoking Wheels....  was here 2017 vmzoaouavvuaixcliwgxzfobvnueuswtvewojrlwkygyozvt
 * Smoking Wheels....  was here 2017 ctfvvabocszmuxwwwfbiebrjhvcqrswtgkqiwgoehqrsmoxt
 * Smoking Wheels....  was here 2017 saqhoxsxuflltdjglsiwauzexoccybpcpdmkzkzzjsnguszr
 * Smoking Wheels....  was here 2017 ikwtrlrkdpmvhzfevqzodvsdfdituixoyzkzovfdjxmabicn
 * Smoking Wheels....  was here 2017 thvgucdsokouqzeiftdrmxgbvkoavhvbquxrvlwsfhpramoo
 * Smoking Wheels....  was here 2017 bhocvnmqujmtiyiqvvcuezjcuhsptarwftnhdnxdebbeunxf
 * Smoking Wheels....  was here 2017 pilvxtlhundkezzljborrgxphddiqxzlogeuelnzrtlpoyzf
 * Smoking Wheels....  was here 2017 zneflwzbucwqdkrdpvikndcdukfmumpnuwynvycbkcllwqup
 * Smoking Wheels....  was here 2017 agoidkfnfqdqouhmqtpfsjkpawtkrooceogbfykokebjnqsn
 * Smoking Wheels....  was here 2017 vetlubonvxruyzulvtsskwlcxottcgekjkrdurhtvfogoihn
 * Smoking Wheels....  was here 2017 teccrtuepwmucanhsygrxwdyssmmbvzxeubueozheskhffhi
 * Smoking Wheels....  was here 2017 ikfccruwsvvozfblfsdcztttwvjuxxvhrkpjhhxbdkkxaduw
 * Smoking Wheels....  was here 2017 lfzmtiteqhehxefsjrmilirlcseaciuqgcqkhwucrkltufcl
 * Smoking Wheels....  was here 2017 fgoonjcybaiiksazntpxnlpakjywlccclauqolmuawxtnsum
 * Smoking Wheels....  was here 2017 xkgvpsmhaafkgyuohcfooilxxaxhypjfdoxetmfsqiebmgqs
 * Smoking Wheels....  was here 2017 dutdiqxorodkmccxmackfljsefnkxkkqjjdgtrkugpadgqte
 * Smoking Wheels....  was here 2017 twwmkonkmdnnjvsseglsknwgwroqvhglogvmtztcuqmpoyka
 * Smoking Wheels....  was here 2017 wetfsdtpfnfdlytatppbhlprymbrnjfuflqoepeymtujlmeu
 * Smoking Wheels....  was here 2017 urtvljhiutcymnmaugddhlmirvelazxdfhkqpzxzvklrevwf
 * Smoking Wheels....  was here 2017 cmncylcxkanwmvmfcpaczzstlgmcorbiqlgyyuhbnkdwhwmf
 * Smoking Wheels....  was here 2017 rzxdwvhzpxxbtnoivfhejstxanrbrgtfwtpakachmsyqpolb
 * Smoking Wheels....  was here 2017 puaeeeiizdayuktigajxnqfujquyevickjzrjwfazqbxbifg
 * Smoking Wheels....  was here 2017 evhtymycqtxflnjlzfvdwycwrwatbshmesiymuvvmqzvasqm
 * Smoking Wheels....  was here 2017 aehtqxarrztsreaewcpwbboqlsyqplnagkueqkjqromvyntt
 * Smoking Wheels....  was here 2017 zhwcxytqqjbstalfzitkarabiygyiyztxiquaunmoinpqwxh
 * Smoking Wheels....  was here 2017 dufepgpvfqpogvtpsurhxuedjpxlbecxvppszagthgjbdbpo
 * Smoking Wheels....  was here 2017 vnqlxufjiuixxrfnprahbozhswgyunixupmxeqsajvoisqsi
 * Smoking Wheels....  was here 2017 qquuftnpgeosuwlmmhpnflpdwjrsuonowakrohifnutwxlgn
 * Smoking Wheels....  was here 2017 konefptdkfsedaeemipefemmotadpctumstogzvjrfahmpol
 * Smoking Wheels....  was here 2017 gxzytagvospqnynqyqiwfqglscfwzeiwdvekrvcwcioplidm
 * Smoking Wheels....  was here 2017 monqaavvqrevrstbkklkqbykoqnuzetftsneliiifrxxciwl
 * Smoking Wheels....  was here 2017 rquakshkvjrpqrmxtyutdxqyoxldwrxqibxfmfzotytpyiuh
 * Smoking Wheels....  was here 2017 soqdopxgrgrfrimybzngpwvylrtidlubhsrbyjstrfdluldg
 * Smoking Wheels....  was here 2017 rydhkjcdvevzjouerialfxeldxkzqpttevnnfamefrigrzpu
 * Smoking Wheels....  was here 2017 wrtabynggcdrllttedvdifqxxxqajlhevtgpzplluythvowr
 * Smoking Wheels....  was here 2017 xxadyodwfhxdyhxfkvxipfkvfezqopiajfapcvamerfxvybv
 * Smoking Wheels....  was here 2017 qaxrsqcrdgqodrchlaijzpwesleguuuicaeburyihyrtkfln
 * Smoking Wheels....  was here 2017 dqkxhxwmttzjokiyqpmtpjsylufnvfciqiiujhdiiakvqtqg
 * Smoking Wheels....  was here 2017 tqakuhcjzuafzpykpraiwsxookjjsctlunkvoetevjxgtbkr
 * Smoking Wheels....  was here 2017 behypattcrzaknmdersbkbqpovbzraomsgmmgzgqmuwlhavw
 * Smoking Wheels....  was here 2017 yrcplnzfoxjzeutxjfuhcchxewcshwpjrkygoshwfhjbarfz
 * Smoking Wheels....  was here 2017 lropdmgobexmufwsqeooeupqillhhreihckzxmvegcpaajcn
 * Smoking Wheels....  was here 2017 xecnxwgzooofaxbsmsqqzjmcgxkqtuvxkttryvbfctbnnqhg
 * Smoking Wheels....  was here 2017 yggedwxuhiqcwcylufypffcykskwytjtczcrpkjvlanzbiwd
 * Smoking Wheels....  was here 2017 jgzplyjoszqgrlhqqhptscxznqflikxwsqulzdmdfxyblndj
 * Smoking Wheels....  was here 2017 hxibtucfofgdwtefjwxorxpinrvauwrnwxmwohilsrpqqorm
 * Smoking Wheels....  was here 2017 bbsdfjuutdnkicwmoaoxnwbisdnngjhejeaxxhcjiuzxyzgd
 * Smoking Wheels....  was here 2017 guspgwisnzqaauawbfjuvlnplmtcbnnoiboxyuevucwhypyk
 * Smoking Wheels....  was here 2017 rphmmsynjfecgkjdyanmoilanmhetflqblljwuhvcoemioal
 * Smoking Wheels....  was here 2017 malcvqcdyqvbouzgpjiowlkrwfdlakjrdmhdbmjvllfjecdt
 * Smoking Wheels....  was here 2017 yzqylokpggporzdkojlvdalyrvmuznwcmozfdipjhhlcuvac
 * Smoking Wheels....  was here 2017 sqlxtsvhnjspqimeskshznsjmyxkwcssciqyazkiivrdqptk
 * Smoking Wheels....  was here 2017 pjtyinnvfksgtktfcdhhkopwygcrfyakjpquxkluobvcnmqy
 * Smoking Wheels....  was here 2017 suskeszbzeizoaanclnilfwnatbiudamwpopdvsdfgezltfe
 */
package net.yacy.search.query;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import org.apache.lucene.util.automaton.Automata;
import org.apache.lucene.util.automaton.Automaton;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrQuery.SortClause;
import org.apache.solr.common.params.DisMaxParams;
import org.apache.solr.common.params.FacetParams;
import net.yacy.cora.document.analysis.Classification;
import net.yacy.cora.document.analysis.Classification.ContentDomain;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.AnchorURL;
import net.yacy.cora.federate.solr.Ranking;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.geo.GeoLocation;
import net.yacy.cora.lod.vocabulary.Tagging;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.document.LibraryProvider;
import net.yacy.document.ProbabilisticClassifier;
import net.yacy.document.Tokenizer;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.data.word.WordReferenceRow;
import net.yacy.kelondro.index.RowHandleSet;
import net.yacy.kelondro.util.Bitfield;
import net.yacy.kelondro.util.SetTools;
import net.yacy.peers.Seed;
import net.yacy.search.index.Segment;
import net.yacy.search.ranking.RankingProfile;
import net.yacy.search.schema.CollectionConfiguration;
import net.yacy.search.schema.CollectionSchema;
public final class QueryParams {
	/** The default max count of item lines in navigator */
public static final int FACETS_STANDARD_MAXCOUNT_DEFAULT = 100;
/** The default maximum number of date elements in the date navigator */
public static final int FACETS_DATE_MAXCOUNT_DEFAULT = 640;
public enum Searchdom {
LOCAL, CLUSTER, GLOBAL;
@Override
public String toString() {
if (this == LOCAL) return "local";
else if (this == CLUSTER) return "global";
else if (this == GLOBAL) return "global";
return "local";
}
}
private static final Map<String, CollectionSchema> defaultfacetfields = new HashMap<String, CollectionSchema>();
static {
defaultfacetfields.put("hosts", CollectionSchema.host_s);
defaultfacetfields.put("protocol", CollectionSchema.url_protocol_s);
defaultfacetfields.put("filetype", CollectionSchema.url_file_ext_s);
defaultfacetfields.put("date", CollectionSchema.dates_in_content_dts);
defaultfacetfields.put("authors", CollectionSchema.author_sxt);
defaultfacetfields.put("collections", CollectionSchema.collection_sxt);
defaultfacetfields.put("language", CollectionSchema.language_s);
}
public static final Bitfield empty_constraint    = new Bitfield(4, "AAAAAA");
public static final Pattern catchall_pattern = Pattern.compile(".*");
private final QueryGoal queryGoal;
public int itemsPerPage;
public int offset;
public Pattern urlMaskPattern;
public Automaton urlMaskAutomaton;
public String urlMaskString;
public final Pattern prefer;
public final String tld, inlink;
boolean urlMask_isCatchall;
public final Classification.ContentDomain contentdom;
public final String targetlang;
protected final Collection<Tagging.Metatag> metatags;
public final Searchdom domType;
private final int zonecode;
public final int maxDistance;
public final Bitfield constraint;
public final boolean allofconstraint;
protected CacheStrategy snippetCacheStrategy;
public final RankingProfile ranking;
private final Segment indexSegment;
public final String clienthost;
protected final Set<String> siteexcludes;
public final QueryModifier modifier;
public Seed remotepeer;
public final long starttime;
protected final long maxtime;
public int transmitcount;
public long searchtime, urlretrievaltime, snippetcomputationtime;
public final String userAgent;
protected double lat, lon, radius;
public LinkedHashSet<String> facetfields;
private SolrQuery cachedQuery;
private CollectionConfiguration solrSchema;
public final int timezoneOffset;
/** The max count of item lines in navigator */
private int standardFacetsMaxCount;
/** The maximum number of date elements in the date navigator */
private int dateFacetMaxCount;
public QueryParams(
final QueryGoal queryGoal,
final QueryModifier modifier,
final int maxDistance,
final String prefer,
final ContentDomain contentdom,
final String language,
final int timezoneOffset,
final Collection<Tagging.Metatag> metatags,
final CacheStrategy snippetCacheStrategy,
final int itemsPerPage,
final int offset,
final String urlMask,
final String tld,
final String inlink,
final Searchdom domType,
final Bitfield constraint,
final boolean allofconstraint,
final Set<String> siteexcludes,
final int domainzone,
final String host,
final boolean specialRights,
final Segment indexSegment,
final RankingProfile ranking,
final String userAgent,
final double lat,
final double lon,
final double radius,
final String[] search_navigation
) {
this.queryGoal = queryGoal;
this.modifier = modifier;
this.ranking = ranking;
this.maxDistance = maxDistance;
this.contentdom = contentdom;
this.timezoneOffset = timezoneOffset;
this.itemsPerPage = Math.min((specialRights) ? 10000 : 1000, itemsPerPage);
        if(domType == Searchdom.LOCAL) {
	/* No offset restriction on local index only requests, as only itemsPerPage will be loaded */
	this.offset = Math.max(0, offset);
} else {
	/* Offset has to be limited on requests mixing local and remote results, because all results before offset are loaded */
	this.offset = Math.max(0, Math.min((specialRights) ? 10000 - this.itemsPerPage : 1000 - this.itemsPerPage, offset));
}
try {
this.urlMaskString = urlMask;
int p;
while ((p = this.urlMaskString.indexOf(':')) >= 0) this.urlMaskString = this.urlMaskString.substring(0, p) + "." + this.urlMaskString.substring(p + 1);
while ((p = this.urlMaskString.indexOf('/')) >= 0) this.urlMaskString = this.urlMaskString.substring(0, p) + "." + this.urlMaskString.substring(p + 1);
while ((p = this.urlMaskString.indexOf('\\')) >= 0) this.urlMaskString = this.urlMaskString.substring(0, p) + "." + this.urlMaskString.substring(p + 2);
this.urlMaskAutomaton = Automata.makeString(this.urlMaskString);
this.urlMaskPattern = Pattern.compile(this.urlMaskString);
} catch (final Throwable ex) {
throw new IllegalArgumentException("Not a valid regular expression: " + urlMask, ex);
}
this.urlMask_isCatchall = this.urlMaskString.equals(catchall_pattern.toString());
        if (this.urlMask_isCatchall) {
String protocolfilter = modifier.protocol == null ? ".*" : modifier.protocol;
String defaulthostprefix = modifier.protocol == null ? "www" : modifier.protocol;
String hostfilter = modifier.sitehost == null && tld == null ? ".*" : modifier.sitehost == null ? ".*\\." + tld : modifier.sitehost.startsWith(defaulthostprefix + ".") ? "(" + defaulthostprefix + "\\.)?" + modifier.sitehost.substring(4) : "(" + defaulthostprefix + "\\.)?" + modifier.sitehost;
String filefilter = modifier.filetype == null ? ".*" : ".*" + modifier.filetype + ".*";
String filter = protocolfilter + "..." + hostfilter + "." + filefilter;
if (!filter.equals(".*....*..*")) {
Pattern r = Pattern.compile("(\\.|(\\.\\*))\\.\\*");
Matcher m;
while ((m = r.matcher(filter)).find()) filter = m.replaceAll(".*");
this.urlMaskString = filter;
this.urlMaskAutomaton = Automata.makeString(filter);
this.urlMask_isCatchall = false;
this.urlMaskPattern = Pattern.compile(filter);
}
}
this.tld = tld;
this.inlink = inlink;
try {
this.prefer = Pattern.compile(prefer);
} catch (final PatternSyntaxException ex) {
throw new IllegalArgumentException("Not a valid regular expression: " + prefer, ex);
}
assert language != null;
this.targetlang = language;
this.metatags = metatags;
this.domType = domType;
this.zonecode = domainzone;
this.constraint = constraint;
this.allofconstraint = allofconstraint;
this.siteexcludes = siteexcludes != null && siteexcludes.isEmpty() ? null: siteexcludes;
this.snippetCacheStrategy = snippetCacheStrategy;
this.clienthost = host;
this.remotepeer = null;
this.starttime = Long.valueOf(System.currentTimeMillis());
this.maxtime = 10000;
this.indexSegment = indexSegment;
this.userAgent = userAgent;
this.transmitcount = 0;
this.lat = Math.floor(lat * this.kmNormal) / this.kmNormal;
this.lon = Math.floor(lon * this.kmNormal) / this.kmNormal;
this.radius = Math.floor(radius * this.kmNormal + 1) / this.kmNormal;
this.facetfields = new LinkedHashSet<String>();
this.solrSchema = indexSegment.fulltext().getDefaultConfiguration();
for (String navkey: search_navigation) {
CollectionSchema f = defaultfacetfields.get(navkey);
if (f != null && (solrSchema.contains(f) || f.name().equals("author_sxt") || f.name().equals("coordinate_p_0_coordinate") ))
this.facetfields.add(f.getSolrFieldName());
}
        if (LibraryProvider.autotagging != null) for (Tagging v: LibraryProvider.autotagging.getVocabularies()) {
if (v.isFacet()) {
this.facetfields.add(CollectionSchema.VOCABULARY_PREFIX + v.getName() + CollectionSchema.VOCABULARY_TERMS_SUFFIX);
}
}
for (String context: ProbabilisticClassifier.getContextNames()) {
this.facetfields.add(CollectionSchema.VOCABULARY_PREFIX + context + CollectionSchema.VOCABULARY_TERMS_SUFFIX);
}
this.cachedQuery = null;
this.standardFacetsMaxCount = FACETS_STANDARD_MAXCOUNT_DEFAULT;
this.dateFacetMaxCount = FACETS_DATE_MAXCOUNT_DEFAULT;
}
private double kmNormal = 100.d;
public Segment getSegment() {
return this.indexSegment;
}
public int neededResults() {
return this.offset + this.itemsPerPage;
}
public int itemsPerPage() {
return this.itemsPerPage;
}
public void setOffset(final int newOffset) {
this.offset = newOffset;
}
public boolean isLocal() {
return this.domType == Searchdom.LOCAL;
}
/**
* @return the max count of item lines in standard navigators
*/
public int getStandardFacetsMaxCount() {
		return this.standardFacetsMaxCount;
	}
/**
* @param standardFacetsMaxCount the max count of item lines in standard navigators
*/
public void setStandardFacetsMaxCount(final int standardFacetsMaxCount) {
		this.standardFacetsMaxCount = standardFacetsMaxCount;
	}
/**
* @return the maximum number of date elements in the date navigator
*/
public int getDateFacetMaxCount() {
		return this.dateFacetMaxCount;
	}
/**
* @param dateFacetMaxCount the maximum number of date elements in the date navigator
*/
public void setDateFacetMaxCount(final int dateFacetMaxCount) {
		this.dateFacetMaxCount = dateFacetMaxCount;
	}
public static HandleSet hashes2Set(final String query) {
final HandleSet keyhashes = new RowHandleSet(WordReferenceRow.urlEntryRow.primaryKeyLength, WordReferenceRow.urlEntryRow.objectOrder, 0);
        if (query != null) {
for (int i = 0; i < (query.length() / Word.commonHashLength); i++) try {
keyhashes.put(ASCII.getBytes(query.substring(i * Word.commonHashLength, (i + 1) * Word.commonHashLength)));
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
}
return keyhashes;
}
public static String hashSet2hashString(final HandleSet hashes) {
final byte[] bb = new byte[hashes.size() * Word.commonHashLength];
int p = 0;
for (final byte[] b : hashes) {
assert b.length == Word.commonHashLength : "hash = " + ASCII.String(b);
System.arraycopy(b, 0, bb, p, Word.commonHashLength);
p += Word.commonHashLength;
}
return ASCII.String(bb);
}
public static String hashSet2hashString(final Set<String> hashes) {
final byte[] bb = new byte[hashes.size() * Word.commonHashLength];
int p = 0;
for (final String s : hashes) {
assert s.length() == Word.commonHashLength : "hash = " + s;
System.arraycopy(ASCII.getBytes(s), 0, bb, p, Word.commonHashLength);
p += Word.commonHashLength;
}
return ASCII.String(bb);
}
public static String anonymizedQueryHashes(final HandleSet hashes) {
final Iterator<byte[]> i = hashes.iterator();
final StringBuilder sb = new StringBuilder(hashes.size() * (Word.commonHashLength + 2) + 2);
sb.append("[");
byte[] hash;
        if (i.hasNext()) {
hash = i.next();
sb.append(ASCII.String(hash).substring(0, 3)).append(".........");
}
while (i.hasNext()) {
hash = i.next();
sb.append(", ").append(ASCII.String(hash).substring(0, 3)).append(".........");
}
sb.append("]");
return sb.toString();
}
/**
* check if the given text matches with the query
* this checks inclusion and exclusion words
* @param text
* @return true if the query matches with the given text
*/
private final boolean matchesText(final String text) {
boolean ret = false;
QueryGoal.NormalizedWords words = new QueryGoal.NormalizedWords(Tokenizer.getWords(text, null).keySet());
        if (!SetTools.anymatchByTest(this.queryGoal.getExcludeWords(), words)) {
ret = SetTools.totalInclusion(this.queryGoal.getIncludeWords(), words);
}
return ret;
}
protected static final boolean anymatch(final String text, final Iterator<String> keywords) {
        if (keywords == null || !keywords.hasNext()) return false;
final SortedSet<String> textwords = (SortedSet<String>) Tokenizer.getWords(text, null).keySet();
return SetTools.anymatchByTest(keywords, textwords);
}
public SolrQuery solrQuery(final ContentDomain cd, final boolean getFacets, final boolean excludeintext_image) {
        if (cd == ContentDomain.IMAGE) {
	return solrImageQuery(getFacets);
}
final List<String> filterQueries;
		switch (cd) {
		case AUDIO:
			filterQueries = this.queryGoal.collectionAudioFilterQuery();
			break;
		case VIDEO:
			filterQueries = this.queryGoal.collectionVideoFilterQuery();
			break;
		case APP:
			filterQueries = this.queryGoal.collectionApplicationFilterQuery();
			break;
		default:
			filterQueries = this.queryGoal.collectionTextFilterQuery(excludeintext_image);
			break;
		}
return solrQuery(getFacets, filterQueries);
}
/**
* @param getFacets when true, generate facets for fiels given in this.facetfields
* @param filterQueries a mutable list of filter queries, initialized with filters related to content domain. Must not be null.
* @return a Solr query instance ready to use
*/
private SolrQuery solrQuery(final boolean getFacets, final List<String> filterQueries) {
        if (this.cachedQuery != null) {
this.cachedQuery.setStart(this.offset);
if (!getFacets) this.cachedQuery.setFacet(false);
return this.cachedQuery;
}
final SolrQuery params = getBasicParams(getFacets, filterQueries);
int rankingProfile = this.ranking.coeff_date == RankingProfile.COEFF_MAX ? 1 : (this.modifier.sitehash != null || this.modifier.sitehost != null) ? 2 : 0;
params.setQuery(this.queryGoal.collectionTextQuery().toString());
Ranking actRanking = indexSegment.fulltext().getDefaultConfiguration().getRanking(rankingProfile);
String fq = actRanking.getFilterQuery();
String bq = actRanking.getBoostQuery();
String bf = actRanking.getBoostFunction();
final String qf = actRanking.getQueryFields();
        if (!qf.isEmpty()) params.setParam(DisMaxParams.QF, qf);
        if (this.queryGoal.getIncludeSize() > 1) {
if (bq.length() > 0) bq += "\n";
bq += CollectionSchema.text_t.getSolrFieldName() + ":\"" + this.queryGoal.getIncludeString() + "\"^10";
}
        if (fq.length() > 0) {
String[] oldfq = params.getFilterQueries();
ArrayList<String> newfq = new ArrayList<>(oldfq.length + 1);
for (String x: oldfq) newfq.add(x);
newfq.add(fq);
params.setFilterQueries(newfq.toArray(new String[newfq.size()]));
}
        if (bq.length() > 0) params.setParam(DisMaxParams.BQ, bq.split("[\\r\\n]+")); // split on any sequence consisting of CR and/or LF
        if (bf.length() > 0) params.setParam("boost", bf); // a boost function extension, see http://wiki.apache.org/solr/ExtendedDisMax#bf_.28Boost_Function.2C_additive.29
ConcurrentLog.info("Protocol", "SOLR QUERY: " + params.toString());
this.cachedQuery = params;
return params;
}
private SolrQuery solrImageQuery(boolean getFacets) {
        if (this.cachedQuery != null) {
this.cachedQuery.setStart(this.offset);
if (!getFacets) this.cachedQuery.setFacet(false);
return this.cachedQuery;
}
final SolrQuery params = getBasicParams(getFacets, this.queryGoal.collectionImageFilterQuery());
params.setQuery(this.queryGoal.collectionImageQuery(this.modifier).toString());
StringBuilder bq = new StringBuilder();
bq.append(CollectionSchema.url_file_ext_s.getSolrFieldName()).append(":\"jpg\"");
bq.append(" OR ").append(CollectionSchema.url_file_ext_s.getSolrFieldName()).append(":\"tif\"");
bq.append(" OR ").append(CollectionSchema.url_file_ext_s.getSolrFieldName()).append(":\"tiff\"");
bq.append(" OR ").append(CollectionSchema.url_file_ext_s.getSolrFieldName()).append(":\"png\"");
params.setParam(DisMaxParams.BQ, bq.toString());
ConcurrentLog.info("Protocol", "SOLR QUERY: " + params.toString());
this.cachedQuery = params;
return params;
}
private SolrQuery getBasicParams(final boolean getFacets, final List<String> fqs) {
final SolrQuery params = new SolrQuery();
params.setParam("defType", "edismax");
params.setParam(DisMaxParams.QF, CollectionSchema.text_t.getSolrFieldName() + "^1.0");
params.setStart(this.offset);
params.setRows(this.itemsPerPage);
params.setFacet(false);
        if (this.ranking.coeff_date == RankingProfile.COEFF_MAX) {
params.setSort(new SortClause(CollectionSchema.last_modified.getSolrFieldName(), SolrQuery.ORDER.desc));
}
fqs.addAll(getFacetsFilterQueries());
        if (fqs.size() > 0) {
params.setFilterQueries(fqs.toArray(new String[fqs.size()]));
}
        if (getFacets && this.facetfields.size() > 0) {
params.setFacet(true);
params.setFacetMinCount(1);
params.setFacetLimit(this.standardFacetsMaxCount);
params.setFacetSort(FacetParams.FACET_SORT_COUNT);
params.setParam(FacetParams.FACET_METHOD, FacetParams.FACET_METHOD_enum);
for (String field: this.facetfields) params.addFacetField("{!ex=" + field + "}" + field);
if (this.facetfields.contains(CollectionSchema.dates_in_content_dts.name())) {
	params.setParam(FacetParams.FACET_RANGE, CollectionSchema.dates_in_content_dts.name());
String start = new Date(System.currentTimeMillis() - 1000L * 60L * 60L * 24L * 3).toInstant().toString();
String end = new Date(System.currentTimeMillis() + 1000L * 60L * 60L * 24L * 3).toInstant().toString();
params.setParam("f." + CollectionSchema.dates_in_content_dts.getSolrFieldName() + ".facet.range.start", start);
params.setParam("f." + CollectionSchema.dates_in_content_dts.getSolrFieldName() + ".facet.range.end", end);
params.setParam("f." + CollectionSchema.dates_in_content_dts.getSolrFieldName() + ".facet.range.gap", "+1DAY");
params.setParam("f." + CollectionSchema.dates_in_content_dts.getSolrFieldName() + ".facet.sort", "index");
params.setParam("f." + CollectionSchema.dates_in_content_dts.getSolrFieldName() + ".facet.limit", Integer.toString(this.dateFacetMaxCount));
}
} else {
params.setFacet(false);
}
params.setFields("*", "score");
return params;
}
long year = 1000L * 60L * 60L * 24L * 365L;
private List<String> getFacetsFilterQueries() {
ArrayList<String> fqs = new ArrayList<>();
        if (this.modifier.sitehash == null && this.modifier.sitehost == null) {
if (this.siteexcludes != null) {
for (String ex: this.siteexcludes) {
fqs.add("-" + CollectionSchema.host_id_s.getSolrFieldName() + ':' + ex);
}
}
} else {
if (this.modifier.sitehost != null) {
if (this.modifier.sitehost.startsWith("www.")) {
fqs.add(CollectionSchema.host_s.getSolrFieldName() + ":\"" + this.modifier.sitehost.substring(4) + "\" OR " + CollectionSchema.host_s.getSolrFieldName() + ":\"" + this.modifier.sitehost + "\"");
} else {
fqs.add(CollectionSchema.host_s.getSolrFieldName() + ":\"" + this.modifier.sitehost + "\" OR " + CollectionSchema.host_s.getSolrFieldName() + ":\"www." + this.modifier.sitehost + "\"");
}
} else
fqs.add(CollectionSchema.host_id_s.getSolrFieldName() + ":\"" + this.modifier.sitehash + '\"');
}
        if (this.metatags != null) {
for (Tagging.Metatag tag : this.metatags) {
fqs.add(CollectionSchema.VOCABULARY_PREFIX + tag.getVocabularyName() + CollectionSchema.VOCABULARY_TERMS_SUFFIX + ":\"" + tag.getObject() + '\"');
}
}
        if (this.modifier.language != null && this.modifier.language.length() > 0 && this.solrSchema.contains((CollectionSchema.language_s))) {
fqs.add(CollectionSchema.language_s.getSolrFieldName() + ":\"" + this.modifier.language + '\"');
}
        if (this.modifier.author != null && this.modifier.author.length() > 0 && this.solrSchema.contains(CollectionSchema.author)) {
fqs.add(CollectionSchema.author_sxt.getSolrFieldName() + ":\"" + this.modifier.author + '\"');
}
        if (this.modifier.keyword != null && this.modifier.keyword.length() > 0 && this.solrSchema.contains(CollectionSchema.keywords)) {
fqs.add(CollectionSchema.keywords.getSolrFieldName() + ":\"" + this.modifier.keyword + '\"');
}
        if (this.modifier.collection != null && this.modifier.collection.length() > 0 && this.solrSchema.contains(CollectionSchema.collection_sxt)) {
fqs.add(QueryModifier.parseCollectionExpression(this.modifier.collection));
}
        if (this.solrSchema.contains(CollectionSchema.dates_in_content_dts)) {
if (this.modifier.on != null && this.modifier.on.length() > 0) {
fqs.add(QueryModifier.parseOnExpression(this.modifier.on, this.timezoneOffset));
}
if (this.modifier.from != null && this.modifier.from.length() > 0 && (this.modifier.to == null || this.modifier.to.equals("*"))) {
fqs.add(QueryModifier.parseFromToExpression(this.modifier.from, null, this.timezoneOffset));
}
if ((this.modifier.from == null || this.modifier.from.equals("*")) && this.modifier.to != null && this.modifier.to.length() > 0) {
fqs.add(QueryModifier.parseFromToExpression(null, this.modifier.to, this.timezoneOffset));
}
if (this.modifier.from != null && this.modifier.from.length() > 0 && this.modifier.to != null && this.modifier.to.length() > 0) {
fqs.add(QueryModifier.parseFromToExpression(this.modifier.from, this.modifier.to, this.timezoneOffset));
}
}
        if (this.modifier.protocol != null) {
fqs.add("{!tag=" + CollectionSchema.url_protocol_s.getSolrFieldName() + "}" + CollectionSchema.url_protocol_s.getSolrFieldName() + ':' + this.modifier.protocol);
}
        if (this.tld != null) {
fqs.add(CollectionSchema.host_dnc_s.getSolrFieldName() + ":\"" + this.tld + '\"');
}
        if (this.modifier.filetype != null) {
fqs.add(CollectionSchema.url_file_ext_s.getSolrFieldName() + ":\"" + this.modifier.filetype + '\"');
}
        if (this.inlink != null) {
fqs.add(CollectionSchema.outboundlinks_urlstub_sxt.getSolrFieldName() + ":\"" + this.inlink + '\"');
}
        if (!this.urlMask_isCatchall) {
fqs.add(CollectionSchema.sku.getSolrFieldName() + ":/" + this.urlMaskString + "/");
}
        if (this.radius > 0.0d && this.lat != 0.0d && this.lon != 0.0d) {
fqs.add("{!bbox sfield=" + CollectionSchema.coordinate_p.getSolrFieldName() + " pt=" + Double.toString(this.lat) + "," + Double.toString(this.lon) + " d=" + GeoLocation.degreeToKm(this.radius) + "}");
}
return fqs;
}
public QueryGoal getQueryGoal() {
return this.queryGoal;
}
public final Map<AnchorURL, String> separateMatches(final Map<AnchorURL, String> links) {
final Map<AnchorURL, String> matcher = new HashMap<>();
final Iterator <Map.Entry<AnchorURL, String>> i = links.entrySet().iterator();
Map.Entry<AnchorURL, String> entry;
AnchorURL url;
String anchorText;
while (i.hasNext()) {
entry = i.next();
url = entry.getKey();
anchorText = entry.getValue();
if (matchesText(anchorText)) {
matcher.put(url, anchorText);
i.remove();
}
}
return matcher;
}
private volatile String idCacheAnon = null, idCache = null;
final static private char asterisk = '*';
public String id(final boolean anonymized) {
        if (anonymized) {
if (this.idCacheAnon != null) return this.idCacheAnon;
} else {
if (this.idCache != null) return this.idCache;
}
synchronized (this) {
if (anonymized) {
if (this.idCacheAnon != null) return this.idCacheAnon;
} else {
if (this.idCache != null) return this.idCache;
}
final StringBuilder context = new StringBuilder(180);
if (anonymized) {
context.append(anonymizedQueryHashes(this.queryGoal.getIncludeHashes()));
context.append('-');
context.append(anonymizedQueryHashes(this.queryGoal.getExcludeHashes()));
} else {
context.append(hashSet2hashString(this.queryGoal.getIncludeHashes()));
context.append('-');
context.append(hashSet2hashString(this.queryGoal.getExcludeHashes()));
}
context.append(asterisk);
context.append(this.contentdom).append(asterisk);
context.append(this.zonecode).append(asterisk);
context.append(ASCII.String(Word.word2hash(this.ranking.toExternalString()))).append(asterisk);
context.append(Base64Order.enhancedCoder.encodeString(this.prefer.toString())).append(asterisk);
context.append(Base64Order.enhancedCoder.encodeString(this.urlMaskString)).append(asterisk);
context.append(this.modifier.sitehash).append(asterisk);
context.append(this.modifier.author).append(asterisk);
context.append(this.modifier.protocol).append(asterisk);
context.append(this.modifier.filetype).append(asterisk);
context.append(this.modifier.collection).append(asterisk);
context.append(this.modifier.toString()).append(asterisk);
context.append(this.siteexcludes).append(asterisk);
context.append(this.targetlang).append(asterisk);
context.append(this.domType).append(asterisk);
context.append(this.constraint).append(asterisk);
context.append(this.maxDistance).append(asterisk);
context.append(this.tld).append(asterisk);
context.append(this.inlink).append(asterisk);
context.append(this.lat).append(asterisk).append(this.lon).append(asterisk).append(this.radius).append(asterisk);
context.append(this.snippetCacheStrategy == null ? "null" : this.snippetCacheStrategy.name());
String result = context.toString();
if (anonymized) {
this.idCacheAnon = result;
} else {
this.idCache = result;
}
return result;
}
}
/**
	 * make a query anchor tag
	 * 
	 * @param authenticatedFeatures
	 *            when true, access to authentication protected search features is
	 *            wanted
	 * @return the anchor url builder
	 */
	public static StringBuilder navurl(final RequestHeader.FileType ext, final int page, final QueryParams theQuery,
			final String newQueryString, boolean newModifierReplacesOld, final boolean authenticatedFeatures) {
		final StringBuilder sb = navurlBase(ext, theQuery, newQueryString, newModifierReplacesOld,
				authenticatedFeatures);
sb.append("&startRecord=");
sb.append(page * theQuery.itemsPerPage());
return sb;
}
/**
	 * construct navigator url
	 *
	 * @param ext
	 *            extension of servlet (e.g. html, rss)
	 * @param theQuery
	 *            search query
	 * @param newModifier
	 *            optional new modifier. - if null existing modifier of theQuery is
	 *            appended - if not null this new modifier is appended in addition
	 *            to existing modifier - if isEmpty overwrites (clears) existing
	 *            modifier
	 * @param authenticatedFeatures
	 *            when true, access to authentication protected search features is
	 *            wanted
	 * @return url to new search result page
	 */
	public static StringBuilder navurlBase(final RequestHeader.FileType ext, final QueryParams theQuery,
			final String newModifier, final boolean newModifierReplacesOld, final boolean authenticatedFeatures) {
StringBuilder sb = new StringBuilder(120);
sb.append("yacysearch.");
sb.append(ext.name().toLowerCase(Locale.ROOT));
sb.append("?query=");
sb.append(theQuery.getQueryGoal().getQueryString(true));
        if (newModifier == null) {
if (!theQuery.modifier.isEmpty()) sb.append("+" + theQuery.modifier.toString());
} else {
if (!newModifier.isEmpty()) {
if (!theQuery.modifier.isEmpty()) sb.append("+" + theQuery.modifier.toString());
if (newModifierReplacesOld) {
int nmpi = newModifier.indexOf(":");
if (nmpi > 0) {
String nmp = newModifier.substring(0, nmpi) + ":";
int i = sb.indexOf(nmp);
if (i > 0) sb = new StringBuilder(sb.substring(0, i).trim());
if (sb.charAt(sb.length() - 1) == '+') sb.setLength(sb.length() - 1);
}
}
try {
	sb.append("+" + URLEncoder.encode(newModifier, StandardCharsets.UTF_8.name()));
} catch (final UnsupportedEncodingException e) {
	sb.append("+" + newModifier);
}
}
}
sb.append("&maximumRecords=");
sb.append(theQuery.itemsPerPage());
sb.append("&resource=");
sb.append((theQuery.isLocal()) ? "local" : "global");
sb.append("&verify=");
sb.append(theQuery.snippetCacheStrategy == null ? "false" : theQuery.snippetCacheStrategy.toName());
sb.append("&prefermaskfilter=");
sb.append(theQuery.prefer);
sb.append("&cat=href");
sb.append("&constraint=");
sb.append((theQuery.constraint == null) ? "" : theQuery.constraint.exportB64());
sb.append("&contentdom=");
sb.append(theQuery.contentdom.toString());
sb.append("&former=");
sb.append(theQuery.getQueryGoal().getQueryString(true));
        if(authenticatedFeatures) {
	sb.append("&auth");
}
return sb;
}
}
