/** 
 * Smoking Wheels....  was here 2017 kafasrmwlwyebhltxsgglhddnwxwxefgjmjincuyjahgvkyz
 * Smoking Wheels....  was here 2017 mudldmaqiwpkyoerzdzvqkojtafhgfrkfwczwukxwiomccod
 * Smoking Wheels....  was here 2017 vsgmtbxzcbvuwzlulxvtnebzqvptslbowfdyofafazruuern
 * Smoking Wheels....  was here 2017 oilnvimcbtmjeesxqzwpmtgistflvpaxwqtaivooqqbrrrfk
 * Smoking Wheels....  was here 2017 bnrftnjmrktllwudhlkhhpygsnlzlupsdlnlbhbzqjiyxyml
 * Smoking Wheels....  was here 2017 zmhmhalwutcnleoufqyawjgpqeacqiapvieoanxpikmqunwl
 * Smoking Wheels....  was here 2017 fmvljntdiuckikimnfhekzoruzvuttskidubqsrygeqawfem
 * Smoking Wheels....  was here 2017 xfaoezroputcicobsbmkirlxqjakivmfgzsvpihrdnepybjy
 * Smoking Wheels....  was here 2017 kmaldowqcfewcbyohgwokvtzzdakfsgkmgjzvbuvzjweekrj
 * Smoking Wheels....  was here 2017 kmazzsczpvvglimkgfxwneqxvgnqlqhmforzouoobantuvoq
 * Smoking Wheels....  was here 2017 sopjrcnrdqibkgkcrnksxpkxkzkbkeajttpmgsejxykqlbtu
 * Smoking Wheels....  was here 2017 oiozjrnvxwqgjkfoybmtzhskguwzpdgduzkiphozgwviyfhf
 * Smoking Wheels....  was here 2017 gqymoqrzlbxevnqvsyivmsjddliyxpxceptsnethduoqipim
 * Smoking Wheels....  was here 2017 lqatxiuuoxohrtqgwooejomcbzlskwgvcgibgidpuzmpytjl
 * Smoking Wheels....  was here 2017 bsjzkobgfkglyillonzdusllhodhjmsfxufyfxhhsyskjmed
 * Smoking Wheels....  was here 2017 fltnfeuprvyqyvnfdsokfkvqitpzlgcifisidjcdtktrkwrz
 * Smoking Wheels....  was here 2017 gsfbukohmrscicqqhgqvjbnmxgehjghnzgijxkrcvjfddfdn
 * Smoking Wheels....  was here 2017 xrbmwqhzjrblwducwmtqdiovcbpahuqjgfxlvxijfbbwxbbp
 * Smoking Wheels....  was here 2017 zqvzipasjuqjpidezbrduejzdmufmlnrmalfgcslmzkbhgci
 * Smoking Wheels....  was here 2017 qhixlfersjiyxefsbvmcttojoywcoysphugoxjrzixribuia
 * Smoking Wheels....  was here 2017 gmpyqqhiyujljmsutylisnxrbghghlflozxrtmhauvpkjaxg
 * Smoking Wheels....  was here 2017 mhxzoihjuxcktirsxsdzqepysiskvefvlddyzhyseyaimnix
 * Smoking Wheels....  was here 2017 fdvefzfthpfoeagdrvinsqzitmapktfnhdaabzgnxudjzbjb
 * Smoking Wheels....  was here 2017 oqcxunmtsfqzzdawldapjbphseldrzxsudwurbafudjbssza
 * Smoking Wheels....  was here 2017 yqvwtcqvofoyrlpzwspaiyjoiekmlwiqtmfludktwxketujl
 * Smoking Wheels....  was here 2017 zhhytfpqpijydabvuanboxjdpmmnttszkvuioeshildtkwac
 * Smoking Wheels....  was here 2017 oyahumkeuotulepajppafxyevireyfmnbzsdmjpjtdsbgsrc
 * Smoking Wheels....  was here 2017 uguhbwlqmepmwlrjajyquctenfdupbkjkchtfdxqwupqckju
 * Smoking Wheels....  was here 2017 caspyoindrchbsbzjkttyzpwlwgvohmvhozitescslkgbggu
 * Smoking Wheels....  was here 2017 ckzdfzxomtrutysegcqnrfpeohtdwhxowzqhgkkyngcxkvvx
 * Smoking Wheels....  was here 2017 svfbvvgqplztcnvpwcijdrcietmsvoejnghhfzorutwxuxvf
 * Smoking Wheels....  was here 2017 avetxaubszyejyzaogyzuqtuutqvcyzixlffgkbyisbuypgc
 * Smoking Wheels....  was here 2017 lixwztcfjwsiebuoarseimihezqakmjuxyzekhzuccjhaehc
 * Smoking Wheels....  was here 2017 qksirlzwgwstixiobtfetwauhnebwnnipkjqvqsjkdtmhemc
 * Smoking Wheels....  was here 2017 lmdgaupzlyqgxuupwcfieudnmndyvoyvlrlgzpwetkiqjlnd
 * Smoking Wheels....  was here 2017 adybesitfjkughqnvpujcjixfosavljjbwlwoogxwongabjp
 * Smoking Wheels....  was here 2017 uhflokrqapdswfploifcfcjrgihtsftfijzsnhzouqadkghb
 * Smoking Wheels....  was here 2017 iafgxhpjqlhnqpsqysatmqlupwpzoeibjvucbrliuxthtrtk
 * Smoking Wheels....  was here 2017 nsnqecexcvnzqududiarcxwmojlqrxprpbytpxgqjuwasbnq
 * Smoking Wheels....  was here 2017 ozxanrsmrbtdehkrncgnmcffokdcqfheqetowkfhhduucnnd
 * Smoking Wheels....  was here 2017 uskblhxnvqehvygjtcagjrlrlqzvgejxjqsqvwleovdmyizn
 * Smoking Wheels....  was here 2017 wzhqqintkfdxlvpgrsvzrgowfcrqqbcmxzqkqgiolfxaoblo
 * Smoking Wheels....  was here 2017 rgdyamseixjuafsxloncqvyzcbeockxrrcpourmwltgtpmol
 * Smoking Wheels....  was here 2017 jatiusuzwwtyzrbelnchrogmpzpvfcopidvyyqsvidnewtjk
 * Smoking Wheels....  was here 2017 hhemldlppqmsvakditwknwgcnqkatdaqskxtbvdkcllcjbcd
 * Smoking Wheels....  was here 2017 ccqhphlvgzzolhsdynjqbmduwafwxwnizpqijcdvbwymmbfj
 * Smoking Wheels....  was here 2017 rvtxhtyovwxivvftmokkohftwjzkwuonmobkgshnryerumlh
 * Smoking Wheels....  was here 2017 echtrnhapndyjejvhrahlmcmbdxyhuwiyklvmbmgskodcltf
 * Smoking Wheels....  was here 2017 zuhlftbrbmxuqdxlbzmhknqrfdizawjbdnjtzwuzffssmgkr
 * Smoking Wheels....  was here 2017 sbbxpwdhzlpikuvzpxjmkbyhiizibjjihnoqyapwkqqkglwo
 * Smoking Wheels....  was here 2017 gfchupqtjlwjukjabamhqbjoqzsztviztgdbvsllvelmavwz
 * Smoking Wheels....  was here 2017 uxgaywxintrxdpaixfujnqnysoufsbzcevjyikhjgpololjf
 * Smoking Wheels....  was here 2017 qznsovnmxudgyclcrprquihdhvnoscgakrumjtdqqwrczqqx
 * Smoking Wheels....  was here 2017 mqggixjxijsycasphpqgktsdiuruwiliqkeaesklhfsnqzdw
 * Smoking Wheels....  was here 2017 edywevootlbsrrzlytloovederczmfzvfvpgflshrfuxafpf
 * Smoking Wheels....  was here 2017 wfjximlrlhbpzpumyyfgruiqhzzjdqqsudibdkwwqnjvalag
 * Smoking Wheels....  was here 2017 zqqagcptykywoqvuyjdgmbyhlmtlqpjfhqxpygzdcecarzop
 * Smoking Wheels....  was here 2017 dozcocxkancchucswiwrwgecqdbbcmkztaeguykijkxoijub
 * Smoking Wheels....  was here 2017 ekzjhdlsqpeafkuwulcydkkhefvfvtgvqcdtdquwysysolku
 * Smoking Wheels....  was here 2017 gtkdqeqvcydsralaeqyrqqehnegdjhqwpabxsuznpwraefjb
 * Smoking Wheels....  was here 2017 ulidzjzfxbcjfmtipzrvdkkvmvslodmkleoxlcafjwsfgaym
 * Smoking Wheels....  was here 2017 kqafbflpvpmprusczwvnnkdxadxvmocbkdjdnliflxzidkow
 * Smoking Wheels....  was here 2017 zsanwhbywradehnylxeebnurkisjmexruunhkbmxknssjfak
 * Smoking Wheels....  was here 2017 rgdmnqfmhloayosrjzukezxrfyjictrighjfujjczmguvmgi
 * Smoking Wheels....  was here 2017 vekunjmrolhnqjzkkfzeofjncrfgekjjszkcqbareshknmmh
 * Smoking Wheels....  was here 2017 cocgoztfnlqebvhllygodxhhenywujfjhmmjdawwgnsouvfb
 * Smoking Wheels....  was here 2017 kvucpbdbdjhtheylpvladybdqunggfrejroptmnftjuogiev
 * Smoking Wheels....  was here 2017 vogsvqylrndhpziehtneaofmbyaqdvnwprzudwtilavxrziw
 * Smoking Wheels....  was here 2017 uposrwvvqjibqdguduvzmeqddsyqhesvvwgahwtfhmojeeyt
 * Smoking Wheels....  was here 2017 ydzbvdpyvsipeproziynlmlaxcyxtpmpfwgsjjvcoywzbkmk
 * Smoking Wheels....  was here 2017 dmbwhfktfmurhsudbapfckziqixoxriaenxnwqqlvzxbxmqv
 * Smoking Wheels....  was here 2017 nhonfypkbyphibcirsvtycvovzawfeyfiypimayyuhecnnlk
 * Smoking Wheels....  was here 2017 mlpscotmxpytwljgmnzaqbxkgssiqfinnovidgyplwgwzucs
 * Smoking Wheels....  was here 2017 rbkjpmtpmegpswnfjupdexhwxnqtdasmyylxahypdzcjrvcp
 * Smoking Wheels....  was here 2017 zmnorlrtvsfozsvunfknrqhccssccgoayzkrpgokhcxycmed
 * Smoking Wheels....  was here 2017 miusnhxeelrsyntwgpnwrjppgudscqqdevapoprtsaaccvhr
 * Smoking Wheels....  was here 2017 qmfnpgaibvwiebanfceavpzcfkgdygxfnuxvxajokreptcsv
 * Smoking Wheels....  was here 2017 bccwptxxgqfxnlqbibzeczpnzqubrkpwdoustlzcrigmjxwk
 * Smoking Wheels....  was here 2017 qmzxmnqxtwigbxudsdrsqkudusrprrfwkysxqcdvynlzobnn
 * Smoking Wheels....  was here 2017 miralkpmutejccanuehhzdejdcazmwljybajeirlaydscprm
 * Smoking Wheels....  was here 2017 zlfwyrjexvxngtzicheutooxvphtybhrqjefjxsxyqajdwmx
 * Smoking Wheels....  was here 2017 vzwjqrvqxuxhhzsyqwvkyjduwddrdmykqjbwkrqkyuaaxjnp
 * Smoking Wheels....  was here 2017 wiernebwsrxliblxmocmtmefmamujuzjiarysxamnyhxbylr
 * Smoking Wheels....  was here 2017 fbzetblbqruyqoqbaeytpcipfsmjesarilhjazsulvhqjrgn
 * Smoking Wheels....  was here 2017 ichnvoosfjtdwhamxwsbfrlruzpyljdqoymihpvitmpwyvfq
 * Smoking Wheels....  was here 2017 tnkqkahmdkdnuhooazyonwpkhulhgamwdfadrssgsbftbztx
 * Smoking Wheels....  was here 2017 lswqmfskmwsxmxnwmfkqspfbxkylwgpfmbynqlzcudgmjxql
 * Smoking Wheels....  was here 2017 nilyeafrmyhghrjfsieahbvaeihqxwetdrpjxhnotleqptwo
 * Smoking Wheels....  was here 2017 iegfarjsredxtjwsionnxsibwixmeyfvcjmvjxjoqzpyxspv
 * Smoking Wheels....  was here 2017 okmjroahtgqitdxrfeajnfvdailrttyblujhigyjsynloljc
 * Smoking Wheels....  was here 2017 cktndjiivfljheutnwkximqlvquhzwvfoujkdmullwalesxn
 * Smoking Wheels....  was here 2017 buwbnapbbhlztdasqluvutllvteokcqlcnscnavmrnoloofi
 * Smoking Wheels....  was here 2017 vlusitmybzwnsugseckzpkawvjzcwnibyiymlpdliwvguilf
 * Smoking Wheels....  was here 2017 alwifzusmbdmyfnbaevpsemrunxolkcqgvxaccbnsesweody
 * Smoking Wheels....  was here 2017 peqbfirilmwporaiigvaiygczmucljmbjypixsfgixjohbaq
 * Smoking Wheels....  was here 2017 phxhlvlzdmzyvtgkmgmxwxwoxrxxldekytihqxlhyugwzxaq
 * Smoking Wheels....  was here 2017 npstkpsecpsukhyhdhbfbnfvjxpnhvdawprcejwqoxzoijln
 * Smoking Wheels....  was here 2017 xhhgubiocokrchcldsdawmkvjdntatrlhdjdtzvmllnsqbtd
 * Smoking Wheels....  was here 2017 rshamyledjtjycxjrdltlrtudqrpamfopgmbuyzhcxboltqo
 * Smoking Wheels....  was here 2017 ymkkudkflgrwhgwxbmbbghxeewejutmllbhtatcuibypqmde
 * Smoking Wheels....  was here 2017 dmscbwtcpsimrpsfavhxavsshqlnermmqxjjjziycwwrhqkn
 * Smoking Wheels....  was here 2017 xunybokohneszdlojoqirwgimwdyhpleklmjaqayrpttrrzl
 * Smoking Wheels....  was here 2017 bvjeswmqprvjgfgoghyvllxgaweokzvlbnrimxuhosuekmpb
 * Smoking Wheels....  was here 2017 ufbcgtgltjfmukpbcwfasrhzjcusdsjiihhekfnroajkhcfs
 * Smoking Wheels....  was here 2017 nupmbkkmgdohfmhenmuvgaffiihwhubezbucsfgbrlehkvby
 * Smoking Wheels....  was here 2017 urhdwfumwsfiimgekldjydvxxnlwypdpgmalrwjrdhcubfpr
 * Smoking Wheels....  was here 2017 ogsfqylkqcwkfutsxkdabalhjycslqbkmmawsjmzlbjfwbpx
 * Smoking Wheels....  was here 2017 yeqeokuluoloexfpjftnzttugclrhsoticbinclsllibqlaa
 * Smoking Wheels....  was here 2017 igbqcxkcvoczvrlylaislwmegsyhkxqwrtsybujublreksdp
 * Smoking Wheels....  was here 2017 iqjnyvebowghxdibadkukawikveiunnlqatdmjpmojjnoiim
 * Smoking Wheels....  was here 2017 wsayavdhzlpfpoeohgscbceozqdvudrhqvfmhatenqnjqflu
 * Smoking Wheels....  was here 2017 ccwjnwsaipaveolhofkiviahnqybzovmghkzeerrqbohliju
 * Smoking Wheels....  was here 2017 irxjydmrctsieywhmdrjleigtpbofuzjltvtbmmwzpdbcaje
 * Smoking Wheels....  was here 2017 hnlxzbiadsbimtkyzkcjvfcjrndcneinhvjeexnatngrxwyr
 * Smoking Wheels....  was here 2017 uabdoihajluodhiveqmtemuxpqbrghkufkzxyrjpnhzlkrvm
 * Smoking Wheels....  was here 2017 zunkwwuwcftbmcbumrwezdyhzlbpzyxhvpawbdyhzruwmlyw
 * Smoking Wheels....  was here 2017 itwkkwkzumdbcajylronxpkgqrmkneuibuzfnahbfqiseook
 * Smoking Wheels....  was here 2017 jzjbusaehaketdgobzbxyoitnjavyhimzprimgudlmnbvnea
 * Smoking Wheels....  was here 2017 awplberiovddprxhjgeufybaysqyovaqawdwjabzerndafns
 * Smoking Wheels....  was here 2017 lzibjdusvejzxhuzvhzvfxemkglazrnwutrtztzhfyumnpnx
 * Smoking Wheels....  was here 2017 zhqmduytrmdyhsrrbhtwqynxqsxoauwnfqvcddobniyxlalc
 * Smoking Wheels....  was here 2017 ivuqdozfvozqnaosxpzcmsgfrcqjtohekcjjddgnjbxjdcuf
 * Smoking Wheels....  was here 2017 izjsgdaahjmtsoqsovoywdsquqplmngqubjdkwqbhpxfdogh
 * Smoking Wheels....  was here 2017 dkcbslkjifpjevknkwlagkmrlwybullbxodjqvnmashygmvs
 * Smoking Wheels....  was here 2017 dzbjysutmnmsmroebuyfkzlzmmbunlyttbeetqbrpltipftz
 * Smoking Wheels....  was here 2017 yuomshzxmbokmedcjaqsfmrnwmrjsuxhkcgzzhpygyfkngnb
 * Smoking Wheels....  was here 2017 mecqwybtivndgpiuoeiywxoowerwscvngqmltytqouvlnmvy
 * Smoking Wheels....  was here 2017 wvneroloicgybnqeyczmwkroyzgnccloysdluajofsbzmxqz
 * Smoking Wheels....  was here 2017 mpvupissyhxdntthexzhxkweyrtwswtsitseagnqgrnulvgv
 * Smoking Wheels....  was here 2017 zpiihstazgyglismeaunwqhlwhyrptzpqjbzrmqdxydxtvcg
 * Smoking Wheels....  was here 2017 geozsjpjkxaaxpribagoaygnxarabhoaekfodzgltadpzsyj
 * Smoking Wheels....  was here 2017 jaiebfqanoamgcfsetkaupkxqjcctggcpalufefhnqvjxoso
 * Smoking Wheels....  was here 2017 uxrmulnkvqdybqzrfknwxapiudsnkubeunhvtrssevzarqri
 * Smoking Wheels....  was here 2017 daxxpnbhcxvxcgapbheggwwrkfdzddfvwpobzmavbumppnip
 * Smoking Wheels....  was here 2017 htnnmdioikrenhmbucdnbbqgsyhphwdxhchfjuueqamjebjk
 * Smoking Wheels....  was here 2017 kritodtntjrtphywwpljuunmguipkuqmqetcqywlrhkvifuc
 * Smoking Wheels....  was here 2017 vrkgiuxoxfzxxbbexakrdnictnrmhyqxucoxqsjpepxuckuh
 * Smoking Wheels....  was here 2017 fwaylnqlpuyegrvgtqnqbyeagbaccsjtxplarapwleygtcxu
 * Smoking Wheels....  was here 2017 lpszyzbctbiiulmsperpsylnzthkbojxjnldeafryoqnyews
 * Smoking Wheels....  was here 2017 rogsydnusgzltwnkukvgpssbnapsvjhkvyxduebtlklcmrpk
 * Smoking Wheels....  was here 2017 hptvxdpyywcstvqlzmhmksvhopkoedepdgidndfczuaukwjk
 * Smoking Wheels....  was here 2017 xulgolgheqctqjwdbuqlbqyfdojrffgdlcmpnwbxuyhpbiqq
 * Smoking Wheels....  was here 2017 lnwcvsltnprhlukbdzpoujjcncldfeyteimdhnfpkikvaxdc
 * Smoking Wheels....  was here 2017 zlwtyxrpdzrinpscqwhlzcsifssfutaqxbormomzpttycpxf
 * Smoking Wheels....  was here 2017 zllyhelhpgifkrohfozakiwqzerlucmcoriibqayidcvjtcm
 * Smoking Wheels....  was here 2017 aoxnqzqnreakzbyarnelarxavlyoglnrhvmngsesxugkeyfv
 * Smoking Wheels....  was here 2017 agtqxajgiulthbawfhscybfrbulpmkrhkidylzouvemacyai
 * Smoking Wheels....  was here 2017 ccwrifzsvhmfqfiqftqrssjbcskwbspyqiolkvzvvacdyulg
 * Smoking Wheels....  was here 2017 qzfjhsbisejbpjoliafaycfxuyexwnhbvehebzpwzjwptwtg
 * Smoking Wheels....  was here 2017 hzdnnznxtflxbnsrjnziquwdcmllxcaecndppjsbmlqkxrke
 * Smoking Wheels....  was here 2017 xodiyslixjklaabvovuaavsahpdnozgdwgdhlezxxtpvyaeb
 * Smoking Wheels....  was here 2017 rfbfvuevmyftvlaugvprliiaxtkljarbuloejugdyafktazi
 * Smoking Wheels....  was here 2017 zywvomiwzjzccpirbpthstourrrsegihrmzlgypqrgbxhxcm
 * Smoking Wheels....  was here 2017 kuyawdsfeldzpmauxpuxsunjqlqcazljszfmhoksisdjzhzk
 * Smoking Wheels....  was here 2017 xdtzrmntbcjfkmhtyjmarjpybfeqgtldhwfxavgukwpbjyke
 * Smoking Wheels....  was here 2017 opddflatxrouxcpjmvxgbqjyknmqlkctbejrbeaosmvngzhd
 * Smoking Wheels....  was here 2017 ucdbxfxqfpxzpdssfbinmcrdmdzolzkmwiexjgvaeomntqxw
 * Smoking Wheels....  was here 2017 fratmfydtpvjjsoebmhxzkrlgahghunzwylzebzjdiobensf
 * Smoking Wheels....  was here 2017 stjhwchgntzsgclibrpxtlqcaljshjaalxepxsccchdlbllh
 * Smoking Wheels....  was here 2017 lzxdgwheughzovuarnhdflgpiwkfcpotfhsqgscxuerfhlcl
 * Smoking Wheels....  was here 2017 uetwcrojcoynxtjindrmawipwbtgllemdmpherztgzwcwvwe
 * Smoking Wheels....  was here 2017 kldlcyynenhwcyconxhcfizcradrlhbugdpwxofvsapeeehl
 * Smoking Wheels....  was here 2017 dfrafioqaacsfrhjslxkyvpiazlmlqsnactcvpiqsrasuhag
 * Smoking Wheels....  was here 2017 ccczqvsxykeeomjoppobrmtsklwyziwvbnjwsdexauofnedz
 * Smoking Wheels....  was here 2017 uxmzvpcukcumtfbgtopybuhzpevoxlmyfszilyxopiylkfuf
 * Smoking Wheels....  was here 2017 svcxmbmafwheoyksbqnfdjicqdydhfunrikwgxvvtnamvymu
 * Smoking Wheels....  was here 2017 wfmynxapisjacxopqldgaffispeslhhkvgrdpepeaxypieyu
 * Smoking Wheels....  was here 2017 hrllecbqbxybrtbtyxltfmobkbroyksrgpbbegbhcdfhsyeo
 * Smoking Wheels....  was here 2017 lcbdxtesxxeowgpfocuqjqgamgweprarxtduxuhfailicojr
 * Smoking Wheels....  was here 2017 ypowjjhmplnbmlejkkszmhifweljnjlzwhrsztqbbqouupaz
 * Smoking Wheels....  was here 2017 rnntnplxfopiqqaupmafslfvychdabmlocsmygtksptxjwxp
 * Smoking Wheels....  was here 2017 tnshpkaeymjjqkqhndraofmjclourowdpiozjulwuyjfqlyw
 * Smoking Wheels....  was here 2017 pmfbaxqvisynapravnbhrdzmfbswhynkxitkhawlfsemspki
 * Smoking Wheels....  was here 2017 vmiampdodzugrefgjareauvefwkcymuwpsbdwxijicatwwsv
 * Smoking Wheels....  was here 2017 ixnhzdphjhnkpolqighbuejqjdnnytaiajpwoomcppcisdrn
 * Smoking Wheels....  was here 2017 fjrgqmkghxdxefvzbbapmlgjfjhlyobwwkpkcmdivzurblfr
 * Smoking Wheels....  was here 2017 yutoyueykhtdzzcjfocssbgcnibjryvwzfpzjjkbzgvqybpx
 * Smoking Wheels....  was here 2017 cfdeqmtbnfuouygdrecnnqnshyocggoxojkzqbrljqcfuohb
 * Smoking Wheels....  was here 2017 obhfphfnprxzsknxomumaflmuorpzasvyucahwnalptqbtaf
 * Smoking Wheels....  was here 2017 myabbcypxxbkcwjnhjffswpwnoogmccrtpxbbcvlzzgnrsts
 */
package net.yacy.kelondro.rwi;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import net.yacy.cora.order.ByteOrder;
import net.yacy.cora.order.CloneableIterator;
import net.yacy.cora.order.Order;
import net.yacy.cora.sorting.Rating;
import net.yacy.cora.storage.ComparableARC;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ByteArray;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.index.RowHandleSet;
import net.yacy.kelondro.util.MemoryControl;
import net.yacy.kelondro.util.MergeIterator;
import net.yacy.search.EventTracker;
import net.yacy.search.Switchboard;
/*
* an index cell is a part of the horizontal index in the new segment-oriented index
* data structure of YaCy. If there is no filter in front of a cell, it might also be
* the organization for a complete segment index. Each cell consists of a number of BLOB files, that
* must be merged to represent a single index. In fact these index files are only merged on demand
* if there are too many of them. An index merge can be done with a stream read and stream write operation.
* in normal operation, there are only a number of read-only BLOB files and a single RAM cache that is
* kept in the RAM as long as a given limit of entries is reached. Then the cache is flushed and becomes
* another BLOB file in the index array.
*/
public final class IndexCell<ReferenceType extends Reference> extends AbstractBufferedIndex<ReferenceType> implements BufferedIndex<ReferenceType>, Iterable<ReferenceContainer<ReferenceType>> {
private static final long cleanupCycle =  60000;
private static final long dumpCycle    = 600000;
private final ReferenceContainerArray<ReferenceType> array;
private       ReferenceContainerCache<ReferenceType> ram;
private final ComparableARC<byte[], Integer>         countCache;
private       int                                    maxRamEntries;
private       IODispatcher                           merger;
private       long                                   lastCleanup;
private long  lastDump;
private final long                                   targetFileSize, maxFileSize;
private final int                                    writeBufferSize;
private final Map<byte[], HandleSet>                 removeDelayedURLs;
private       boolean                                flushShallRun;
private final Thread                                 flushThread;
public IndexCell(
final File cellPath,
final String prefix,
final ReferenceFactory<ReferenceType> factory,
final ByteOrder termOrder,
final int termSize,
final int maxRamEntries,
final long targetFileSize,
final long maxFileSize,
final int writeBufferSize,
final IODispatcher merger
) throws IOException {
super(factory);
this.merger = merger;
this.array = new ReferenceContainerArray<ReferenceType>(cellPath, prefix, factory, termOrder, termSize);
this.ram = new ReferenceContainerCache<ReferenceType>(factory, termOrder, termSize);
this.countCache = new ComparableARC<byte[], Integer>(1000, termOrder);
this.maxRamEntries = maxRamEntries;
this.lastCleanup = System.currentTimeMillis();
this.lastDump = System.currentTimeMillis();
this.targetFileSize = targetFileSize;
this.maxFileSize = maxFileSize;
this.writeBufferSize = writeBufferSize;
this.removeDelayedURLs = new TreeMap<byte[], HandleSet>(Word.commonHashOrder);
this.flushShallRun = true;
this.flushThread = new FlushThread(cellPath.toString());
this.flushThread.start();
}
private class FlushThread extends Thread {
public FlushThread(String name) {
this.setName("IndexCell.FlushThread(" + name + ")");
}
@Override
public void run() {
while (IndexCell.this.flushShallRun) {
try {
flushBuffer();
} catch (final Throwable e) {
ConcurrentLog.logException(e);
}
try { Thread.sleep(3000); } catch (final InterruptedException e) {}
}
}
private void flushBuffer() {
final long t = System.currentTimeMillis();
if ((IndexCell.this.ram.size() >= IndexCell.this.maxRamEntries ||
(IndexCell.this.ram.size() > 3000 && !MemoryControl.request(80L * 1024L * 1024L, false)) ||
(!IndexCell.this.ram.isEmpty() && IndexCell.this.lastDump + dumpCycle < t))) {
synchronized (IndexCell.this.merger) {
if (IndexCell.this.ram.size() >= IndexCell.this.maxRamEntries ||
(IndexCell.this.ram.size() > 3000 && !MemoryControl.request(80L * 1024L * 1024L, false)) ||
(!IndexCell.this.ram.isEmpty() && IndexCell.this.lastDump + dumpCycle < t)) try {
IndexCell.this.lastDump = System.currentTimeMillis();
try {removeDelayed();} catch (final IOException e) {}
final File dumpFile = IndexCell.this.array.newContainerBLOBFile();
ReferenceContainerCache<ReferenceType> ramdump;
final ByteOrder termOrder = IndexCell.this.ram.termKeyOrdering();
final int termSize = IndexCell.this.ram.termKeyLength();
synchronized (this) {
ramdump = IndexCell.this.ram;
IndexCell.this.ram = new ReferenceContainerCache<ReferenceType>(IndexCell.this.factory, termOrder, termSize);
}
IndexCell.this.merger.dump(ramdump, dumpFile, IndexCell.this.array);
IndexCell.this.lastDump = System.currentTimeMillis();
} catch (final Throwable e) {
ConcurrentLog.logException(e);
}
}
}
if ((IndexCell.this.array.entries() > 50 ||
IndexCell.this.lastCleanup + cleanupCycle < t)) {
synchronized (IndexCell.this.array) {
if (IndexCell.this.array.entries() > 50 || (IndexCell.this.lastCleanup + cleanupCycle < System.currentTimeMillis())) try {
IndexCell.this.lastCleanup = System.currentTimeMillis();
IndexCell.this.shrink(IndexCell.this.targetFileSize, IndexCell.this.maxFileSize);
IndexCell.this.lastCleanup = System.currentTimeMillis();
} catch (final Throwable e) {
ConcurrentLog.logException(e);
}
}
}
}
}
private boolean shrink(final long targetFileSize, final long maxFileSize) {
        if (this.array.entries() < 2) return false;
boolean donesomething = false;
int term = 10;
while (term-- > 0 && (this.merger.queueLength() < 3 || this.array.entries() >= 50)) {
if (!this.array.shrinkBestSmallFiles(this.merger, targetFileSize)) break;
donesomething = true;
}
term = 10;
while (term-- > 0 && (this.merger.queueLength() < 2)) {
if (!this.array.shrinkAnySmallFiles(this.merger, targetFileSize)) break;
donesomething = true;
}
term = 10;
while (term-- > 0 && (this.merger.queueLength() < 1)) {
if (!this.array.shrinkUpToMaxSizeFiles(this.merger, maxFileSize)) break;
donesomething = true;
}
term = 10;
while (term-- > 0 && (this.merger.queueLength() < 1)) {
if (!this.array.shrinkOldFiles(this.merger)) break;
donesomething = true;
}
return donesomething;
}
public int deleteOld(int minsize, long maxtime) throws IOException {
        long timeout = System.currentTimeMillis() + maxtime;
Collection<byte[]> keys = keys4LargeReferences(minsize, maxtime / 3);
int c = 0;
int oldShrinkMaxsize = ReferenceContainer.maxReferences;
ReferenceContainer.maxReferences = minsize;
for (byte[] key: keys) {
ReferenceContainer<ReferenceType> container = this.get(key, null);
container.shrinkReferences();
try {this.add(container); c++;} catch (SpaceExceededException e) {}
if (System.currentTimeMillis() > timeout) break;
}
ReferenceContainer.maxReferences = oldShrinkMaxsize;
return c;
}
private Collection<byte[]> keys4LargeReferences(int minsize, long maxtime) throws IOException {
        long timeout = System.currentTimeMillis() + maxtime;
ArrayList<byte[]> keys = new ArrayList<byte[]>();
Iterator<ByteArray> ci = this.ram.keys();
while (ci.hasNext()) {
byte[] k = ci.next().asBytes();
if (this.ram.count(k) >= minsize) keys.add(k);
}
CloneableIterator<byte[]> ki = this.array.keys(true, false);
while (ki.hasNext()) {
byte[] k = ki.next();
if (this.array.count(k) >= minsize) keys.add(k);
if (System.currentTimeMillis() > timeout) break;
}
return keys;
}
/*
* methods to implement Index
*/
/**
* every index entry is made for a term which has a fixed size
* @return the size of the term
*/
@Override
public int termKeyLength() {
return this.ram.termKeyLength();
}
/**
* add entries to the cell: this adds the new entries always to the RAM part, never to BLOBs
* @throws IOException
* @throws SpaceExceededException
*/
@Override
public void add(final ReferenceContainer<ReferenceType> newEntries) throws IOException, SpaceExceededException {
try {
this.ram.add(newEntries);
final long t = System.currentTimeMillis();
if (this.ram.size() % 1000 == 0 || this.lastCleanup + cleanupCycle < t || this.lastDump + dumpCycle < t) {
EventTracker.update(EventTracker.EClass.WORDCACHE, Long.valueOf(this.ram.size()), true);
}
} catch (final SpaceExceededException e) {
EventTracker.update(EventTracker.EClass.WORDCACHE, Long.valueOf(this.ram.size()), true);
this.ram.add(newEntries);
}
}
@Override
public void add(final byte[] termHash, final ReferenceType entry) throws IOException, SpaceExceededException {
try {
this.ram.add(termHash, entry);
final long t = System.currentTimeMillis();
if (this.ram.size() % 1000 == 0 || this.lastCleanup + cleanupCycle < t || this.lastDump + dumpCycle < t) {
EventTracker.update(EventTracker.EClass.WORDCACHE, Long.valueOf(this.ram.size()), true);
}
} catch (final SpaceExceededException e) {
EventTracker.update(EventTracker.EClass.WORDCACHE, Long.valueOf(this.ram.size()), true);
this.ram.add(termHash, entry);
}
}
/**
* checks if there is any container for this termHash, either in RAM or any BLOB
*/
@Override
public boolean has(final byte[] termHash) {
        if (this.ram.has(termHash)) return true;
return this.array.has(termHash);
}
/**
* count number of references for a given term
* this method may cause strong IO load if called too frequently.
*/
@Override
public int count(final byte[] termHash) {
final Integer cachedCount = this.countCache.get(termHash);
        if (cachedCount != null) return cachedCount.intValue();
int countFile = 0;
try {
countFile = this.array.count(termHash);
} catch (final Throwable e) {
ConcurrentLog.logException(e);
}
assert countFile >= 0;
final ReferenceContainer<ReferenceType> countRam = this.ram.get(termHash, null);
assert countRam == null || countRam.size() >= 0;
int c = countRam == null ? countFile : countFile + countRam.size();
synchronized (this.removeDelayedURLs) {
final HandleSet s = this.removeDelayedURLs.get(termHash);
if (s != null) c -= s.size();
if (c < 0) c = 0;
}
        if (MemoryControl.shortStatus()) this.countCache.clear();
this.countCache.insert(termHash, c);
return c;
}
/**
* all containers in the BLOBs and the RAM are merged and returned.
* Please be aware that the returned values may be top-level cloned ReferenceContainers or direct links to containers
* If the containers are modified after they are returned, they MAY alter the stored index.
* @throws IOException
* @return a container with merged ReferenceContainer from RAM and the file array or null if there is no data to be returned
*/
@Override
public ReferenceContainer<ReferenceType> get(final byte[] termHash, final HandleSet urlselection) throws IOException {
final ReferenceContainer<ReferenceType> c0 = this.ram.get(termHash, null);
ReferenceContainer<ReferenceType> c1 = null;
try {
c1 = this.array.get(termHash);
} catch (final SpaceExceededException e2) {
ConcurrentLog.logException(e2);
}
ReferenceContainer<ReferenceType> result = null;
        if (c0 != null && c1 != null) {
try {
result = c1.merge(c0);
} catch (final SpaceExceededException e) {
try {
result = c1.merge(c0);
} catch (final SpaceExceededException e1) {
result = (c1.size() > c0.size()) ? c1: c0;
}
}
} else if (c0 != null) {
result = c0;
} else if (c1 != null) {
result = c1;
}
        if (result == null) return null;
synchronized (this.removeDelayedURLs) {
final HandleSet s = this.removeDelayedURLs.get(termHash);
if (s != null) result.removeEntries(s);
}
return result;
}
/**
* deleting a container affects the containers in RAM and all the BLOB files
* the deleted containers are merged and returned as result of the method
* @throws IOException
*/
@Override
public ReferenceContainer<ReferenceType> remove(final byte[] termHash) throws IOException {
removeDelayed();
ReferenceContainer<ReferenceType> c1 = null;
try {
c1 = this.array.get(termHash);
} catch (final SpaceExceededException e2) {
ConcurrentLog.logException(e2);
}
        if (c1 != null) {
this.array.delete(termHash);
}
final ReferenceContainer<ReferenceType> c0 = this.ram.remove(termHash);
        if (c1 == null) return c0;
        if (c0 == null) return c1;
try {
return c1.merge(c0);
} catch (final SpaceExceededException e) {
try {
return c1.merge(c0);
} catch (final SpaceExceededException e1) {
return (c1.size() > c0.size()) ? c1: c0;
}
}
}
@Override
public void delete(final byte[] termHash) throws IOException {
removeDelayed();
ReferenceContainer<ReferenceType> c1 = null;
try {
c1 = this.array.get(termHash);
} catch (final SpaceExceededException e2) {
ConcurrentLog.logException(e2);
}
        if (c1 != null) {
this.array.delete(termHash);
}
this.ram.delete(termHash);
return;
}
@Override
public void removeDelayed(final byte[] termHash, final byte[] urlHashBytes) {
HandleSet r;
synchronized (this.removeDelayedURLs) {
r = this.removeDelayedURLs.get(termHash);
}
        if (r == null) {
r = new RowHandleSet(Word.commonHashLength, Word.commonHashOrder, 0);
}
try {
r.put(urlHashBytes);
} catch (final SpaceExceededException e) {
try {remove(termHash, urlHashBytes);} catch (final IOException e1) {}
return;
}
synchronized (this.removeDelayedURLs) {
this.removeDelayedURLs.put(termHash, r);
}
}
@Override
public void removeDelayed() throws IOException {
final HandleSet words = new RowHandleSet(Word.commonHashLength, Word.commonHashOrder, 0);
synchronized (this.removeDelayedURLs) {
for (final byte[] b: this.removeDelayedURLs.keySet()) try {words.put(b);} catch (final SpaceExceededException e) {}
}
synchronized (this.removeDelayedURLs) {
for (final byte[] b: words) {
final HandleSet urls = this.removeDelayedURLs.remove(b);
if (urls != null) remove(b, urls);
}
}
this.countCache.clear();
}
/**
* remove url references from a selected word hash. this deletes also in the BLOB
* files, which means that there exists new gap entries after the deletion
* The gaps are never merged in place, but can be eliminated when BLOBs are merged into
* new BLOBs. This returns the sum of all url references that have been removed
* @throws IOException
*/
@Override
public int remove(final byte[] termHash, final HandleSet urlHashes) throws IOException {
this.countCache.remove(termHash);
final int removed = this.ram.remove(termHash, urlHashes);
int reduced;
try {
reduced = this.array.reduce(termHash, new RemoveReducer<ReferenceType>(urlHashes));
} catch (final SpaceExceededException e) {
reduced = 0;
ConcurrentLog.warn("IndexCell", "not possible to remove urlHashes from a RWI because of too low memory. Remove was not applied. Please increase RAM assignment");
}
return removed + (reduced / this.array.rowdef().objectsize);
}
@Override
public boolean remove(final byte[] termHash, final byte[] urlHashBytes) throws IOException {
this.countCache.remove(termHash);
final boolean removed = this.ram.remove(termHash, urlHashBytes);
int reduced;
try {
reduced = this.array.reduce(termHash, new RemoveReducer<ReferenceType>(urlHashBytes));
} catch (final SpaceExceededException e) {
reduced = 0;
ConcurrentLog.warn("IndexCell", "not possible to remove urlHashes from a RWI because of too low memory. Remove was not applied. Please increase RAM assignment");
}
return removed || (reduced > 0);
}
private static class RemoveReducer<ReferenceType extends Reference> implements ReferenceContainerArray.ContainerReducer<ReferenceType> {
HandleSet urlHashes;
public RemoveReducer(final HandleSet urlHashes) {
this.urlHashes = urlHashes;
}
public RemoveReducer(final byte[] urlHashBytes) {
this.urlHashes = new RowHandleSet(Word.commonHashLength, Word.commonHashOrder, 0);
try {
this.urlHashes.put(urlHashBytes);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
}
@Override
public ReferenceContainer<ReferenceType> reduce(final ReferenceContainer<ReferenceType> container) {
container.sort();
container.removeEntries(this.urlHashes);
return container;
}
}
@Override
public Iterator<ReferenceContainer<ReferenceType>> iterator() {
return referenceContainerIterator(null, false, false);
}
@Override
public CloneableIterator<Rating<byte[]>> referenceCountIterator(final byte[] starttermHash, final boolean rot, final boolean excludePrivate) {
return this.array.referenceCountIterator(starttermHash, false, excludePrivate);
}
@Override
public CloneableIterator<ReferenceContainer<ReferenceType>> referenceContainerIterator(final byte[] startTermHash, final boolean rot, final boolean excludePrivate) {
return referenceContainerIterator(startTermHash, rot, excludePrivate, false);
}
@Override
public CloneableIterator<ReferenceContainer<ReferenceType>> referenceContainerIterator(final byte[] startTermHash, final boolean rot, final boolean excludePrivate, final boolean ram) {
final Order<ReferenceContainer<ReferenceType>> containerOrder = new ReferenceContainerOrder<ReferenceType>(this.factory, this.ram.rowdef().getOrdering().clone());
containerOrder.rotate(new ReferenceContainer<ReferenceType>(this.factory, startTermHash));
        if (ram) {
return this.ram.referenceContainerIterator(startTermHash, rot, excludePrivate);
}
return new MergeIterator<ReferenceContainer<ReferenceType>>(
this.ram.referenceContainerIterator(startTermHash, rot, excludePrivate),
new MergeIterator<ReferenceContainer<ReferenceType>>(
this.ram.referenceContainerIterator(startTermHash, false, excludePrivate),
this.array.referenceContainerIterator(startTermHash, false, excludePrivate),
containerOrder,
ReferenceContainer.containerMergeMethod,
true),
containerOrder,
ReferenceContainer.containerMergeMethod,
true);
}
/**
* clear the RAM and BLOB part, deletes everything in the cell
* @throws IOException
*/
@Override
public synchronized void clear() throws IOException {
this.countCache.clear();
this.removeDelayedURLs.clear();
this.ram.clear();
this.array.clear();
        if (Switchboard.getSwitchboard() != null &&
Switchboard.getSwitchboard().peers != null &&
Switchboard.getSwitchboard().peers.mySeed() != null) Switchboard.getSwitchboard().peers.mySeed().resetCounters();
}
public synchronized void clearCache() {
this.countCache.clear();
}
/**
* when a cell is closed, the current RAM is dumped to a file which will be opened as
* BLOB file the next time a cell is opened. A name for the dump is automatically generated
* and is composed of the current date and the cell salt
*/
@Override
public synchronized void close() {
this.countCache.clear();
try {removeDelayed();} catch (final IOException e) {}
        if (!this.ram.isEmpty()) this.ram.dump(this.array.newContainerBLOBFile(), (int) Math.min(MemoryControl.available() / 3, this.writeBufferSize), true);
this.flushShallRun = false;
        if (this.flushThread != null) try { this.flushThread.join(); } catch (final InterruptedException e) {}
this.ram.close();
this.array.close();
}
public boolean isEmpty() {
        if (this.ram.size() > 0) return false;
for (int s: this.array.sizes()) if (s > 0) return false;
return true;
}
@Override
public int size() {
throw new UnsupportedOperationException("an accumulated size of index entries would not reflect the real number of words, which cannot be computed easily");
}
private int[] sizes() {
final int[] as = this.array.sizes();
final int[] asr = new int[as.length + 1];
System.arraycopy(as, 0, asr, 0, as.length);
asr[as.length] = this.ram.size();
return asr;
}
public int sizesMax() {
int m = 0;
final int[] s = sizes();
for (final int element : s)
if (element > m) m = element;
return m;
}
public int getSegmentCount() {
return this.array.entries();
}
@Override
public int minMem() {
return 10 * 1024 * 1024;
}
@Override
public ByteOrder termKeyOrdering() {
return this.array.ordering();
}
@Override
public long getBufferMaxAge() {
return System.currentTimeMillis();
}
@Override
public int getBufferMaxReferences() {
return this.ram.maxReferences();
}
@Override
public long getBufferMinAge() {
return System.currentTimeMillis();
}
@Override
public int getBufferSize() {
return this.ram.size();
}
@Override
public long getBufferSizeBytes() {
return this.ram.usedMemory();
}
@Override
public void setBufferMaxWordCount(final int maxWords) {
this.maxRamEntries = maxWords;
}
}
