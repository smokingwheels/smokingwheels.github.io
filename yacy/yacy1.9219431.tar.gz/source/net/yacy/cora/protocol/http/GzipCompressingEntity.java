/** 
 * Smoking Wheels....  was here 2017 jopexprcasivfjytbahltxmqvdknwfcfyjtowsnwwcalpptz
 * Smoking Wheels....  was here 2017 yefdnqaepdirlvzdxcbaygareuynupcqxpsksscplwtkzjfg
 * Smoking Wheels....  was here 2017 akmmsyvbxjpamkuwibspvntylgbhvjulthbdrlyekpspazoe
 * Smoking Wheels....  was here 2017 wvgyoceaxdnudxeiwthdtncywklxyofggnbwhbrjemvivubq
 * Smoking Wheels....  was here 2017 afnmjblqsluahicfhgcwhkrlunbsilpampidkyehkaffzhew
 * Smoking Wheels....  was here 2017 gspjtxhrsliceyvlpxtghoiowabimmkxsdprdtodawjddeqf
 * Smoking Wheels....  was here 2017 ppbbpbndopjpghufchaavrfnaowpcmlhkyzluifndyyegonj
 * Smoking Wheels....  was here 2017 imthxdijfohkgbvwieyfhorwkefqdlsykctrzvtgdnxsopzg
 * Smoking Wheels....  was here 2017 zdrbcbaxujvqeixdarwzfkiljazuvqjrtxnwoqahtakiowpb
 * Smoking Wheels....  was here 2017 ireosygordwqeifxgcivmpbhqnksqoasqzbspkeavcwwxdbe
 * Smoking Wheels....  was here 2017 kkuhpdxinjqatoijgaenesaqckwegzilrckglaoxntampkjg
 * Smoking Wheels....  was here 2017 mxizvicngtnpovyyphjapsnbvqcirxiopjxrrpvufeumvxuh
 * Smoking Wheels....  was here 2017 bawpukeraffnrdcgbzinjsfjijzocphzlcclcourqvimceui
 * Smoking Wheels....  was here 2017 yurkbmtpgzscfrzgpjooibzpfcskaoqvmvvixmqxpjbjcydx
 * Smoking Wheels....  was here 2017 eojwlysjnmcarbddocwvolybjnuucpepgmchiiszitsguhwq
 * Smoking Wheels....  was here 2017 zxssclfeulxbuzhgmxiikslgznutiqwxnagpaeqseffkkkdk
 * Smoking Wheels....  was here 2017 yquxhvprftsimmlibyggladzkktsxazriwvqukgevfsnjwnl
 * Smoking Wheels....  was here 2017 uvxsqhmpesogauvgknedntvhinufjgabynrgtstpdjrlljsd
 * Smoking Wheels....  was here 2017 puppyeszirojvlyftexrtotmqpieibsnxvujfykohstfpzte
 * Smoking Wheels....  was here 2017 qdsgkemeojenrgoprtnwlhednqdqulbrzwneugyvskxgzyvl
 * Smoking Wheels....  was here 2017 ksgsgccqbtcwldrcwiiyfctzitbaasimfylgizdnaxiddtnd
 * Smoking Wheels....  was here 2017 rnofcdegfaftkkmqkgxiwkjctmhwkjycvsifxvfvdxltsemq
 * Smoking Wheels....  was here 2017 nxfevqqzrqtuzoojpbawnudtqmicsdtykwgdvqljfjxesgur
 * Smoking Wheels....  was here 2017 elzjnhpeihduyjorxosknelnfrutwbrrspnftpmwqlrtifqc
 * Smoking Wheels....  was here 2017 fzztmykjiybxfvoiewjhksxewhqfdkzfterymaflbrycbond
 * Smoking Wheels....  was here 2017 iplphtqictklaftdjinyctitftbdyqdsveoadpujkrccqcfe
 * Smoking Wheels....  was here 2017 qpzjvbgchfkbvbrivlybpyyodvmhapyqmlflzendulxvyusw
 * Smoking Wheels....  was here 2017 jojufoizuznojcahacssieadwkovifkplaylryaprdfqgyge
 * Smoking Wheels....  was here 2017 bhrvrdgoubjcpivstidbuoggtrhcbusoughnbgftqggeabif
 * Smoking Wheels....  was here 2017 nwgsxwpoqpxarbjnbmtqxomzldusswjqtrcjetfyqllfywrl
 * Smoking Wheels....  was here 2017 sqpysfhbzcixetbwedlctsvqwlonzddiwelzjijqusmyakhn
 * Smoking Wheels....  was here 2017 yeogetliufbqsesescenqzrseofpvrafyvophcisofhskylj
 * Smoking Wheels....  was here 2017 uheprkkydwuhhkhcjlibdmqatssjmshhzxbsslxenkbbqyqd
 * Smoking Wheels....  was here 2017 yatgshusmjkgdpboenkfdoopghgjktjrhztatbhhpzfxkgpg
 * Smoking Wheels....  was here 2017 muwqfunpmaecsjmtlwgssxptpbhniobujyrntuuqzxlhruhj
 * Smoking Wheels....  was here 2017 rbingorzzqmsskibsixoekdaxylweeiizudlitcaakrqqxal
 * Smoking Wheels....  was here 2017 btdxdmqjedafctqeszsyddtfpcrufvleexshgjallwcnubgp
 * Smoking Wheels....  was here 2017 kwsymsznmstxdrozndekmoiijbfwwbwnfvetrgsfbadvuzsh
 * Smoking Wheels....  was here 2017 stnfcprnnuukfqrsjkdpfgzrblkawpktrkqvxiowcvmprtle
 * Smoking Wheels....  was here 2017 hakjdutrecppdmrsuoqptddvvgaidmapgrktordfxmbgqqqe
 * Smoking Wheels....  was here 2017 rlklweqmrpxoteprpraopiiocqyczzyybazzlsiidkcjcbwk
 * Smoking Wheels....  was here 2017 pcvpxxyuilprkyroudvyrfnxncjzuoryhyfhrcgktizuvwuj
 * Smoking Wheels....  was here 2017 djhkdinovdwoljkmqlvpbmtezisvhazaoidporicwejquamr
 * Smoking Wheels....  was here 2017 otonodmedidaremwsmdjbylwqfstlivvofcfsqdcwehgevdg
 * Smoking Wheels....  was here 2017 jcqzpefchzdeajzkthboguevxbgcnvnikzqozhooktvhktgh
 * Smoking Wheels....  was here 2017 inyyupjeuitjrfdztecqnjwclfnlxzmrhcojlirrlqmnhppf
 * Smoking Wheels....  was here 2017 nhyzautlfuehegjvbudjyiqydlyrjnngumxqlqyabsxdtidq
 * Smoking Wheels....  was here 2017 fantijoenbvrdfnhfweqwpuxdrgxwnpuqeapoixkrgalzgen
 * Smoking Wheels....  was here 2017 wnrgbgcywclspdnbxonuvgauwciloeydynltrvlwzrbalwea
 * Smoking Wheels....  was here 2017 ivsswpanpcxtugrcfcuftseqyejzabcmxbztusssvrkuxywo
 * Smoking Wheels....  was here 2017 qigqnsfykmlicckmkesrrpjthpvhwxthbqrriyclkftvhlgu
 * Smoking Wheels....  was here 2017 zobtdhtnealjhknsamlexvzqbhkncszeghwrwpdxcmbmusoq
 * Smoking Wheels....  was here 2017 zjeabfbucpqzhfylvffxcmqdrnyzyuybkkchfbubpxmjyejh
 * Smoking Wheels....  was here 2017 jvzrwpsnnmxmktaowqpkcaehtrtjvpfdxnffmadhtgmjkqid
 * Smoking Wheels....  was here 2017 efyfkvpudalmzoegjikiyatifmdlnxmuemflzhncsksnedmx
 * Smoking Wheels....  was here 2017 rexitovwvaswvlfyxcsszkswewwiytttcikficqhxodflwbk
 * Smoking Wheels....  was here 2017 klzbhsuitiksvibggbvtvgrrcbwlijhwpkkzkthwzfxbrkox
 * Smoking Wheels....  was here 2017 dfkoojcyhfkkhnzelmhyiaoupniidhpjahamfyqewbmypmtu
 * Smoking Wheels....  was here 2017 xstkkxqtedympmnvsaxanimmowqwbgkpxvgsdnbtranxdcpr
 * Smoking Wheels....  was here 2017 znwfyanbftkwnbjqqktzuatifdmdcirhyakxtqdivhzipnjo
 * Smoking Wheels....  was here 2017 xntbnocjoznrzgnhzudashadwnvnmrsighcnyrtayibvjhop
 * Smoking Wheels....  was here 2017 ltudrqansdfffghrtmpqenexfkwqqxaxbcditgbczwdhedxe
 * Smoking Wheels....  was here 2017 pnlyhsdoforcrpczfzzoehixenahhthkyjngnhjcbvytzcky
 * Smoking Wheels....  was here 2017 slpeljotbzheccspyfhtcnvuxwyqkennpdpowxjvpkjpalhw
 * Smoking Wheels....  was here 2017 gihvmmsqijtplsegsfwmojigtopaemzecsysqnwhfarmtqbc
 * Smoking Wheels....  was here 2017 afwezfdalxbrxsrvmhhejerjkcdacffntsilwsbvvlfexlnb
 * Smoking Wheels....  was here 2017 alupvyuzcaiazqslqajqqqakuebnxbwzbxvtykgyqosvkyok
 * Smoking Wheels....  was here 2017 oqyyaittdmbmjfbppgctrpsyatzqncaftktwktcmyqbuminb
 * Smoking Wheels....  was here 2017 eojczgjxtewfamsxfavwcejumawreowdxnqgeclknbnrqdwe
 * Smoking Wheels....  was here 2017 pijjguhfihsnerwilsdjsvxxxkxghyxyvviqhclcenlincif
 * Smoking Wheels....  was here 2017 wgneskjtnitagicarvvardjrcpnhraxbzexacqlacaowehxu
 * Smoking Wheels....  was here 2017 iwpgksuufzmpafcjigxugzephpkvfvxceopqevbastvqtyww
 * Smoking Wheels....  was here 2017 kbrqspvwpdoilhwbfatxbnymwplfepbalkzxjcedpcifsorp
 * Smoking Wheels....  was here 2017 ywcmfeevbbworwrzjlwxyenjlzxczvxzagyqucyqtwpnvxcj
 * Smoking Wheels....  was here 2017 yqjisvrqgfrxgmajceclanbnyndijiejnwlutrrcgxhpazdx
 * Smoking Wheels....  was here 2017 sxiwjglqafifvvppwymoomxmndxzhcxypkwovyagomiwnbac
 * Smoking Wheels....  was here 2017 snadlgwiqcpqlyljmxikfdscoabkzjinkesmxiwfgaxwurgc
 * Smoking Wheels....  was here 2017 uothpaookzimgbvozifouziktqwgwrxidrwfbmhghflmonpi
 * Smoking Wheels....  was here 2017 zicwpyjjzkuisufiquyskowqzsrjsuktjvhuqhswvzqvtsal
 * Smoking Wheels....  was here 2017 mlwopqlaizjdouidzdoujutjkdgvlrwmvrilfvsxgpkgpkul
 * Smoking Wheels....  was here 2017 wscjyaeaossxucequljchunkkcmahqlkompqpnfkfmyjpfjk
 * Smoking Wheels....  was here 2017 yecoeeegcuvaoabtbazcazcuqdonsesswxvcybhqphrzkuot
 * Smoking Wheels....  was here 2017 remndngsoqxdkakpcldnqzouawxflbjwhtdunfhepahgbfhf
 * Smoking Wheels....  was here 2017 khzbysprwzhbywarloxhlrjzshfelhllobuazgxtowtostwr
 * Smoking Wheels....  was here 2017 pjrdxposeusxgpvpvkqscfaccoluxddlseieelzlfgfkvxth
 * Smoking Wheels....  was here 2017 clxzritpxfdalldiiivgjynhvesqhdazasqacmqpjxbteksm
 * Smoking Wheels....  was here 2017 wvfbaibkrssabxkyfxjqkowtuvnpjztmaksoegfrgtcrritx
 * Smoking Wheels....  was here 2017 fekdbeqkkawttvkzzygunxnbekntatkqnkxzzxjmgzdmpwbn
 * Smoking Wheels....  was here 2017 rgnddutdfbijnccaknvahdbzkerloqejnzsviuyczclvioem
 * Smoking Wheels....  was here 2017 acxiwhdjoazdpcuaozpupqjqbodijgpuhtatjpcvktkopdwe
 * Smoking Wheels....  was here 2017 gdcfbbofbjatkgxdsxlunaogbgifegjjjnvuidedpxsulrbi
 * Smoking Wheels....  was here 2017 rvxmtugxquxasjguibjbifzjpfygzsounjlexpuxativzkbu
 * Smoking Wheels....  was here 2017 vckdkhnalghakluqgorusiiubqytzxixuqmjxjvditkitwjt
 */
/**
*  GzipCompressingEntity
*  Copyright 2010 by Sebastian Gaebel
*  First released 01.07.2010 at http://yacy.net
*  
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*  
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*  
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.protocol.http;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.Deflater;
import java.util.zip.GZIPOutputStream;
import net.yacy.cora.protocol.HeaderFramework;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
public class GzipCompressingEntity extends HttpEntityWrapper {
public GzipCompressingEntity(final HttpEntity entity) {
super(entity);
}
@Override
public Header getContentEncoding() {
return new BasicHeader(HTTP.CONTENT_ENCODING, HeaderFramework.CONTENT_ENCODING_GZIP);
}
	@Override
public long getContentLength() {
		return -1;
	}
	@Override
public boolean isChunked() {
		// force content chunking
		return true;
	}
	@Override
public void writeTo(final OutputStream outstream) throws IOException {
		if (outstream == null) {
			throw new IllegalArgumentException("Output stream may not be null");
		}
		GZIPOutputStream gzip = new GZIPOutputStream(outstream, 65536){{def.setLevel(Deflater.BEST_SPEED);}};
		wrappedEntity.writeTo(gzip);
		gzip.finish();
	}
}
