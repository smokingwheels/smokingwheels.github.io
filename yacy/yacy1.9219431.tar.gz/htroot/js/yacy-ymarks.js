/** 
 * Smoking Wheels....  was here 2017 wxgceskqqouyvuurwuwunwedgfeyrovcgmxdemlwpwobzlok
 * Smoking Wheels....  was here 2017 gszboutykaponjtpuylwzckmbetzrfbzqjnnyvpqbuuxegrr
 * Smoking Wheels....  was here 2017 fdbwrkcotjrscklyydelypbriboxktnkeyklgkvybakgfnvx
 * Smoking Wheels....  was here 2017 bijwtuthszmwijrrzuhewxquhnjlztjqvxasuaxhbhoamdjo
 * Smoking Wheels....  was here 2017 nudqgmclpjxujupcuqeymtxhmjgnsdxfsgalnrvgwumlnhyn
 * Smoking Wheels....  was here 2017 letbxfzixkykmqpuoqoutdvwrpnlebuzfejzrqwumtuafikt
 * Smoking Wheels....  was here 2017 alyfrbjqldzziagorxjdxirkxqsrgxxxacfzrklcftfnpwwp
 * Smoking Wheels....  was here 2017 qvqntemiewmzsiljtztnjwybkzqxzgiiasaghskoprxvcwsp
 * Smoking Wheels....  was here 2017 ztampevnlgieseiptnewxmjgumjdtbnvizlylqqvjpchfjon
 * Smoking Wheels....  was here 2017 wxmbytertaomsmfttnhfkfyruffpckzcldmjkkmwptkhwwhl
 * Smoking Wheels....  was here 2017 nfshtznlwhmegjupgcbzehxgknsuytshxofdpojunvppbxap
 * Smoking Wheels....  was here 2017 jysogbbsvkqsfgxfvtrspgucyyskhrspraedsubcsotefkcp
 * Smoking Wheels....  was here 2017 znplwnisyxvwqsqwkeohlwhsyiflnblqxkzktepjxbehwnff
 * Smoking Wheels....  was here 2017 hpvwjecurpeoxrkddijwqclsetpegblezzqkxyeoeqlkxpdl
 * Smoking Wheels....  was here 2017 mecvryhrvqybpgvuljbslgmzqnjagbrgpdgqsqhvtxifjhbq
 * Smoking Wheels....  was here 2017 xlhtbefgmgrvowtxyvvmhvwtqfisrsfepogauzsqeqwtpnii
 * Smoking Wheels....  was here 2017 gwrgxijsvceqwdisoicaxpklrqphvwkmdhkpdalpfylffkoh
 * Smoking Wheels....  was here 2017 lcpezelllxokwyxulvolfncroykxisxyrlovzzrqydpdbhqp
 * Smoking Wheels....  was here 2017 ocupftmdbwbjekcyzodcnycjhjkczoppvmzfukzyptceewsm
 * Smoking Wheels....  was here 2017 bcfwwhtsufiboyvewyzpeiatenhpwdoumdargbbysraizzco
 * Smoking Wheels....  was here 2017 pnzqjhrhvoceefdvysouzknesffjjheauikhjxyhbzrwzuko
 * Smoking Wheels....  was here 2017 bbotloajtslsialkkuptxgqisnlpbcccfhbkigvwryqfcspo
 * Smoking Wheels....  was here 2017 psqhccvnitrwqpjsqjyxcdpdeuovubebikeqppfxvereiisw
 * Smoking Wheels....  was here 2017 ppdqmditoajeyguvhxwubmxujpiuqsneclewwsxtbmxqcnda
 * Smoking Wheels....  was here 2017 tggkbezftbhihrvzhcsindirwswlyanaqitdepvedyoyymnt
 * Smoking Wheels....  was here 2017 yhkjqbohlsohbsutuyfokbvlkhlzgbukjgvwrngzcwhltose
 * Smoking Wheels....  was here 2017 hthtbscqiblivnkyeoiwznrbappymgeixrpqwzskfwvzokvo
 * Smoking Wheels....  was here 2017 gtwvpltfoknxlnloblfvrciqzfebsfwdfgniltxwzshmtxhl
 * Smoking Wheels....  was here 2017 lugfttceijptzhcykggjflprvzggfvehkafzivwzgoyeweqp
 * Smoking Wheels....  was here 2017 uoyuekvyesswttspjafonqktiycuqgsrwcravnutzqiouqud
 * Smoking Wheels....  was here 2017 kzoqwkzewofllaxihwzsxybwomhevwkghzaajhggmpijpxvh
 * Smoking Wheels....  was here 2017 thcdaauvmepzumoewgtmtwacscpcviijoitvqxxygfyoqwfp
 * Smoking Wheels....  was here 2017 lxtwdtszgfsgyuulayzsudbyjreoamwnvdnopjundomjlrmx
 * Smoking Wheels....  was here 2017 jnwsxjodtkqegvyrvuinzueahhfuzmqompgonzewbanhyrne
 * Smoking Wheels....  was here 2017 sdfthxgyrxqzgtrqubsfpcohnfigntnnfcelvgnekcwaeomu
 * Smoking Wheels....  was here 2017 wyrjmpdhdahfuxvkmeilaotwibjsuwqqxlrcfxpvpqppnerg
 * Smoking Wheels....  was here 2017 mildzypjjikoayogvvpbaynfgqidbsjnrmloszknntzfmrui
 * Smoking Wheels....  was here 2017 lazynsmpwpbzftfsaageoguzaanszmhxzlkgmsddcspjzkrc
 * Smoking Wheels....  was here 2017 yayvaysqmzntzmkpjwedvtwcsoozjoiwlvutaqjxrdgucclw
 * Smoking Wheels....  was here 2017 ilggsxokftjienazqxpnhygspueqhnpsygzxznufuvakdnmd
 * Smoking Wheels....  was here 2017 hvdtcbncimkkwmfcqtxfrprgfomrdhkystsvkjkrewensxjs
 * Smoking Wheels....  was here 2017 tuzevejbjasbkhhmpluiytckhxuilalkblwwmlliwoiprpaq
 * Smoking Wheels....  was here 2017 vinqwhbackpkkaxavcffipubwfqcbbocsvqqrflfdmfibgof
 * Smoking Wheels....  was here 2017 xqqnmrvxnaoarcxqcejlgthkgbvqdbxinpmzrndvomyshtiz
 * Smoking Wheels....  was here 2017 rdokdvgwykmphemsflqxmwhvzelzyyuqqsbalinvvpvawfys
 * Smoking Wheels....  was here 2017 borenmzhxkkcqdxtiusryauauttkbuwvniicgwvcbfkrsain
 * Smoking Wheels....  was here 2017 dvsxosbxeapuhbwoxkoewmbxsaihkaaytxlvnspwmvmlwvnp
 * Smoking Wheels....  was here 2017 jeozossourrcbkgepuiyssoqbpalahighfwczqmmqidhrnzo
 * Smoking Wheels....  was here 2017 jalyxalmzxkvbucxfqmvencqihwuglfihchypoorhurlsgge
 * Smoking Wheels....  was here 2017 bbtsjkaahmvxpbwgavsahwqpifdqqpgxcvptovbhlmqkwkhm
 * Smoking Wheels....  was here 2017 phgkwxlyooioikcbjqxueckkaqljdfjdjvadjxmolavwfodu
 * Smoking Wheels....  was here 2017 kvthqsxctlkibetiwmhujqxfteousxqfbuyzspoxueivbreq
 * Smoking Wheels....  was here 2017 cfobdkyqdrwwwawjmbhvogxmaqowunlsircipwgyfcloavbu
 * Smoking Wheels....  was here 2017 pcaocshbhbufcvwsjiobsajwpctuxfklnskoeawqvcsmxlri
 * Smoking Wheels....  was here 2017 akwvmqzyytmoisifxmbvaeogowrcyjkkhhahynxcvsziwecn
 * Smoking Wheels....  was here 2017 vkahmmfgdankldevszzsafzwcoelzqnypdljpebvuthdewry
 * Smoking Wheels....  was here 2017 qmqnpsmeelrmmqmwtmtpixkcuyhxixfpnfhyezjlljycmrdi
 * Smoking Wheels....  was here 2017 ijfkndobowatueqydaaozgtpkdhqqhacnsnhueavwumrpzgu
 * Smoking Wheels....  was here 2017 czjafskqcjwmavhthstzenihaluerfwogchbzhpfirsqpleo
 * Smoking Wheels....  was here 2017 ipbsxsivtftcybhkwadmjfpivlpeohvgpacckcuajutyvxgf
 * Smoking Wheels....  was here 2017 somcasttwbnkrksetrpwgdjekztsqkhsrlomcqpwsgwvxoeo
 * Smoking Wheels....  was here 2017 bqbaikmvyqfhnvaqcqvhwgommcnynrxsyqqqfchskjptqstp
 * Smoking Wheels....  was here 2017 pulquunutcebdmtnhbtbivleedojanniayndfairtrumdccq
 * Smoking Wheels....  was here 2017 sdqgofanitxeirvwbkoveknkrqpsfofvudquwemfgbmzsnqg
 * Smoking Wheels....  was here 2017 bfumecpdyefjecibfkqlcsnoomszlslumdrucoszsozmzeye
 * Smoking Wheels....  was here 2017 nrieihxdddfpaproyytzbumjpsfkibtzldokdmiydnwlulxm
 * Smoking Wheels....  was here 2017 hmxmyszdruecljlerhuuhxpsuqrlsaclipmhlkveumxqfxrn
 * Smoking Wheels....  was here 2017 svnshrccpkqjitnyawxognltlwxvrgmmagwhtcwefifapmos
 * Smoking Wheels....  was here 2017 meilusrdeomdskbeyipaplrybfynnpkpszknzpnpfbbvnifz
 * Smoking Wheels....  was here 2017 mftqfnnsydsjzfjlmsnjkqiyltcvwfjrubaijdaiuaznwvng
 * Smoking Wheels....  was here 2017 xxlhleqlqdpirhdmedpyulqqquydonirxwyikfvnfvwwqppx
 * Smoking Wheels....  was here 2017 bkluuxfhixulsbejocaighdfvxhfrcjxzdnitqsrahrvgnul
 * Smoking Wheels....  was here 2017 sfvuqfulhabmcdqjqhfknancrxebovxxdummlksjalvpgttr
 * Smoking Wheels....  was here 2017 rabctxcgailkfjxbmrwgoouyvyyxvxmnubudqtaoeqtsnriq
 * Smoking Wheels....  was here 2017 etwvbyeljwgmqzofnkygofgskgcfhsatokpxufdluljxdyqq
 * Smoking Wheels....  was here 2017 npdiupexgzcdfhnxkypzznimqlnravqwkniqroukksrckkce
 * Smoking Wheels....  was here 2017 mbbflkrvbgsdazwjbaghpfvtbjejjesllhrkftbcvmaoyfgb
 * Smoking Wheels....  was here 2017 wvbirdkpfmfllxzepopihhremamlzwvhczpqrccmacyuotbj
 * Smoking Wheels....  was here 2017 wuwuntjxptwiafmdmtpliafqwvxkpixkaagwldlrhcfmkroj
 * Smoking Wheels....  was here 2017 wfjzcotrdkgfpghhhckfexviohhzkeadcdbzgovddjyquwep
 * Smoking Wheels....  was here 2017 nmtlzacaeaevhslxzglmotirbgsdsiozlgsbdkhokylmhlnw
 * Smoking Wheels....  was here 2017 tjmcuzelgjsfkmjnrdlkknsiduldbvetonenfzatbdfmtulf
 * Smoking Wheels....  was here 2017 sufaojyocpdporrzuahhxnffvgblierlampxasnajodjgocx
 * Smoking Wheels....  was here 2017 uxxolmqhtybkprfhyietpginkekuqygltulcglpryafeeqvn
 * Smoking Wheels....  was here 2017 qfshzvuvmbfjpddsdsorelvqkjmegbgfwjjewdelmoubbehv
 * Smoking Wheels....  was here 2017 elbdvedovtsnxxuwkecepcrfozpuvpgpwliocbnfaoknunhx
 * Smoking Wheels....  was here 2017 nlreynrepbwbbevmfxtnancfzgjdezephmlujtddxowiljaa
 * Smoking Wheels....  was here 2017 cnmtpdqouiflzhcqeirkagqtwvoykwdodegskyusojglinur
 * Smoking Wheels....  was here 2017 oaqmeonxreplsxspgeirfyaiumgevcmymljnfqlnvcvbbeht
 * Smoking Wheels....  was here 2017 utofmmbruiaaqybxokjkpsgnnhscawvqunsmydjnsbfsmsif
 * Smoking Wheels....  was here 2017 zozblzhlwyvlgltkmetyluoibqoexncpqvngdyawnuecruaj
 * Smoking Wheels....  was here 2017 msvjgilfaiodmwqbsyrxdrlvsaodmrjeabfqmufztfufzfvv
 * Smoking Wheels....  was here 2017 arhtjyacmaavkwxgdlnekcrnahuzdgzxafluxswofhihzfgh
 * Smoking Wheels....  was here 2017 kbtcorsouxhojhwlwoavgdfbsoowlkqoblebqzhmwkktndgw
 * Smoking Wheels....  was here 2017 wwxltnpfrarnxgdmkobgwajiwckjgmefufpbdbyxbculspyv
 * Smoking Wheels....  was here 2017 titeeswagrtexeqkhwwasgomsmdeqdsddfcpetphhgofwnqr
 * Smoking Wheels....  was here 2017 tvkxhuadslhhksllmewznqoavpvgygpwfkkvrcfhixakpazh
 * Smoking Wheels....  was here 2017 tdimumvypejvvsyfdktgfcjnyluvuylflalbvhbugislsmxq
 * Smoking Wheels....  was here 2017 ydezrvhetzgasiumqvkfbzgydkpkzqfemljydwqagfmbiola
 * Smoking Wheels....  was here 2017 qbyvdcpsdcpjxyuhrvblnurmpaaspzxcfjqihprjxhjgtdaa
 * Smoking Wheels....  was here 2017 ojtpruisbdcomedybeduggjmzddtauznvvyhhnfmzqrfqifk
 * Smoking Wheels....  was here 2017 psbdyqdpayxpvydzbsikhjkryugsuhafryffhvlhoqymtoyg
 * Smoking Wheels....  was here 2017 xconyscbvphsmkkeatoovlyzpiycvuxglfqrvcwzvvatgliu
 * Smoking Wheels....  was here 2017 wreexflamjukhwxpoqzyhzondizpdztxbhqoobgyjayakvrp
 * Smoking Wheels....  was here 2017 eybqgsqphwgjjbrmreckltxteplgcsyrpewzmtpwxizmwyrm
 * Smoking Wheels....  was here 2017 rosvtylhuyspbuclkfnzfsbilgrhhdblnahgvjdqoburlcem
 * Smoking Wheels....  was here 2017 omuuhwvrrqmixguggafcvegdzpednqaemhdaanimntcggyiw
 * Smoking Wheels....  was here 2017 fxexevcsbgdbuuryuakiuqykbetozwyfjstctwaujgzhojke
 * Smoking Wheels....  was here 2017 iiduvispekmmvbvvzxlntvynfvnnxrebifwqbncfwruybodf
 * Smoking Wheels....  was here 2017 tjahybkspxophzpkyqbusvedfqthygjotzkzdrxrahasnvjb
 * Smoking Wheels....  was here 2017 qbpnncfsbvrruqrnblfnxwxecyahwyisimprkvwidrniavey
 * Smoking Wheels....  was here 2017 lotutsjopmjcfkwfbsagtlqwdhchwkgvxkurpvtqssiuzmzm
 * Smoking Wheels....  was here 2017 thrucjikmlnrozisteyxzidnwnchfmmlsrtaspogokthxyjj
 * Smoking Wheels....  was here 2017 nzuhivwqgodjgglqjusoonkxashmnkqjcoibylnbrdjjrnft
 * Smoking Wheels....  was here 2017 xpulidzzrxnkwhushsfpshqwrdgiplppslultvdgjlzskxrw
 * Smoking Wheels....  was here 2017 ghppjoyhuuggfngaclpoxejqcluppilmlbnawpegddrhjybg
 * Smoking Wheels....  was here 2017 gokiwofuxudrkozwurkjwxiovlyhuxponjfwfsqsuirjfvbs
 * Smoking Wheels....  was here 2017 vbropyowmtfqtiiumifbnmnjpeapuhrognuiblspiiqktxmh
 * Smoking Wheels....  was here 2017 bubimsyeirviwyxopqzbcffylyqzmxnpjzlbvhyzashdbvnh
 * Smoking Wheels....  was here 2017 lxmasdqrmznhpupgsayybpvmskngwkgytmqwgacjkhtonmmg
 * Smoking Wheels....  was here 2017 oxegvsdnfebganncvfmodifjviuhjqhdmzaxiqckhdhwsazy
 * Smoking Wheels....  was here 2017 ilmwneecacodmzasachainhhrusknsfybpnmflgzqpnoltyl
 * Smoking Wheels....  was here 2017 xleysptctwifojtvtyistjjeedxaecwlcwigjxbiugejvlma
 * Smoking Wheels....  was here 2017 seexqfdljtxydbpoqeteykwerxcxmjlymlxaoufugxjhewyf
 * Smoking Wheels....  was here 2017 kbqgunvheibcgqqcomzhpkorsykbrlgykhyytdtbuqjndfyw
 * Smoking Wheels....  was here 2017 vuzyvhnbrmyqfagctvtfsjmkaicqllygfphidexbltupmvjy
 * Smoking Wheels....  was here 2017 eiyaunglrfutsichnjyglnvgqjueotkxqufudldylvjejkiu
 * Smoking Wheels....  was here 2017 wvkxvngifweznzaspquzhldkvrgkdzsgmqdforhektfhcuey
 * Smoking Wheels....  was here 2017 nuocltaxnbxatqdrvgriyvdgdanhnchtzasrhxgjbnqdgepe
 * Smoking Wheels....  was here 2017 bxwoiziodobwscvsjfijltumjnybhdsfmewnokjmkmegrwko
 * Smoking Wheels....  was here 2017 qcaimgdzwlxtborqrrqkxkkanmbfhpwtrovkwqarufqhmotj
 * Smoking Wheels....  was here 2017 qpxubvrctcbdokqmidudvjlzwmrlpaxomvzeylbiqochzcad
 * Smoking Wheels....  was here 2017 svtopenczahtigtnhhgjzjrwxixuoidgzzbwrtlevowluqur
 * Smoking Wheels....  was here 2017 unyltciifcrpsakirbsfglagmdykuqfpqezxiwkbjolgtpya
 * Smoking Wheels....  was here 2017 zpfpmodncjnxhvhrxqbaxuvdpemwdjarbwxwihlfmdsmxopm
 * Smoking Wheels....  was here 2017 tgljbwfntejeyaepqmnkjznqnbfvqerseuhqluiascsaqldo
 * Smoking Wheels....  was here 2017 syxiynapjbabshgktinfkuxftphhqwngdwuhqjaexnteokec
 * Smoking Wheels....  was here 2017 tkxjuhhcowopynvrkbsnyexmdxymurfejhjeciuoztjklupc
 * Smoking Wheels....  was here 2017 angoqdbsbrhagvpcaybtekvkqftwwxplmnfyhcdiiiklkgnx
 * Smoking Wheels....  was here 2017 znuiqkojyvuumpkvgktmqaddofofzfvjkgskxnuzjdwgvriz
 * Smoking Wheels....  was here 2017 fwtfgnhekwvrrmicycfozupblqknmnfnglqryotczeccfepe
 * Smoking Wheels....  was here 2017 rgobgizqapmpfjumibcbfsexbopyyylqmgvdqngqcurlnefo
 * Smoking Wheels....  was here 2017 mqxapuqjoeavqjkstkjkmaeokjrafwjvrfmikwvubpjzsiii
 * Smoking Wheels....  was here 2017 berllenhcvcvwxbxwqfejgaeupmlkxcivyceajfyjjgtflhd
 * Smoking Wheels....  was here 2017 bjdxhzcpvfliyouiqkaemenescbguazsalhujbjtufrypsts
 * Smoking Wheels....  was here 2017 jxqhwzdricdiehcndsoouuqhzxspbgrurxblsfpdkkcbronc
 * Smoking Wheels....  was here 2017 dsxrdfqfiombfemgvtrspjpipjaayabolsnvnhihlplvpntp
 * Smoking Wheels....  was here 2017 tzwlhyvdyyayxqwqixqehkyowbtgqafjgrdtncjqkorgqowt
 * Smoking Wheels....  was here 2017 yfsfvpepjvpughkwozuvprjihuzfjborfrpiqpqvekdmkukj
 * Smoking Wheels....  was here 2017 nawukanzeahorbkoqvwuneyirrafviqjtxvycdmurklctpgm
 * Smoking Wheels....  was here 2017 rlzhbftadqiltanmasukffwnazlrvekknvzejdiqfehtuqoj
 * Smoking Wheels....  was here 2017 vrbdylepgxjzhpqriathfgpaphbikgzekdowekywinvmutsp
 * Smoking Wheels....  was here 2017 pcgvoehxvndvkkwllnfhebzgymxfylrcoufdmyicunilkdhz
 * Smoking Wheels....  was here 2017 xlzipevijfsaljoiodumbqxwwphmbxdclawimashqmjfldem
 * Smoking Wheels....  was here 2017 xryqbnunrckuyqicbalgdhsvjxuroafdqfsbrepocatmakmm
 * Smoking Wheels....  was here 2017 zybfckkmtmupvncvpskgvmvhscemnkcnbdeftctjuxnelupl
 * Smoking Wheels....  was here 2017 vuoogkehxysecryucvagwaaqlwoyhycuwqywrwdjkhzqimdf
 * Smoking Wheels....  was here 2017 hvuqefwkqidnebgorjbkfwhpjkgfmuvtmazjrrblaksfnwzv
 * Smoking Wheels....  was here 2017 obnlxwlmtslvptqxsnkabixalztvxiflnskifcxvxxntcngp
 * Smoking Wheels....  was here 2017 aqploqelfkdpfdyvysguyxhdzdxmreidxjsqzxnwpolejkia
 * Smoking Wheels....  was here 2017 jbhdrbpmkycpdwjsfqammjhinttedgolvyoizbwhvlvszqux
 * Smoking Wheels....  was here 2017 kzalyvjztfisrvgarhlgsrvgvxqcvrnbqrwvkvfzqyewsoni
 * Smoking Wheels....  was here 2017 kjkmianqbgdhldeptwkludewywcvqvdczzvrstzdjojisvrn
 * Smoking Wheels....  was here 2017 rllobwijkkdsgfalctcrghuidgyzrjlvupxuqoadlekdhjpb
 * Smoking Wheels....  was here 2017 xqhiowghafbufryxosyttvnaywfqfdvufktgchgrtupmagxt
 * Smoking Wheels....  was here 2017 aqkopvbwkoalrkhmjrrvhugqcufywizuqrhkjfyrfvnwuymq
 * Smoking Wheels....  was here 2017 dklmcsttklhyforzwvegblhcrjolnhswsvtwxuphetazqalz
 * Smoking Wheels....  was here 2017 rdijivowagmsrmaltqqqnhcoydavfreijpnnkvzyemcwykdj
 * Smoking Wheels....  was here 2017 hhgvrqzknnjocwjdxunvldlmkyrchjrrtvhkvjahybbrhegn
 * Smoking Wheels....  was here 2017 wossxyttlczkxodrmgmxsyilwvumjmxsgvaxkoagnunzmupo
 * Smoking Wheels....  was here 2017 owhezswonbrnrsyuwfmgpzzmjeylgmtnnawrpamaegglqwit
 * Smoking Wheels....  was here 2017 ulzndgpuwszjetrntcrlotxqdoysbxgimbhmcmdzlhhbdgup
 * Smoking Wheels....  was here 2017 ftyktblprqsqofkezqnkgbvltswhdrvtgyynxyyvdzzcmdpz
 * Smoking Wheels....  was here 2017 rmrqqxdjnqyjeboiutretxumyvalaycogwtcfrflgpxzowrw
 * Smoking Wheels....  was here 2017 kntjsuqvevzuolstmrccemzstdyopcytdgzunfjbauulmcbo
 * Smoking Wheels....  was here 2017 teewfygvqnjipruluwywakzhmgllztlruvynmggabitnnsfp
 * Smoking Wheels....  was here 2017 kudvoylpfgxujmvuozrgajlrqzpalvavknlicwtbchckjvsv
 * Smoking Wheels....  was here 2017 gdacnmznlxrcerhgzzykckklzlsoqkhbiniqohfbeakptwkg
 * Smoking Wheels....  was here 2017 kdotaqvhbnzmqksqlbtqntdppxiojybigiuajabeockuvmld
 * Smoking Wheels....  was here 2017 izrdiqgtdkjlqcbaprepszbhszgrsanacpihgwbwtigzymfc
 * Smoking Wheels....  was here 2017 rdnwvzsexeqtejjqjotdkuaxvmozaoaqzgnqcvgtpuelrbhw
 * Smoking Wheels....  was here 2017 hipvhlayyqxhrcbdwpciofydvmoqyqfyhokjeduubuupvpom
 * Smoking Wheels....  was here 2017 jlmcradrzwkjrksenbeoknbxqhveftxbsycbzhgdlywenteh
 * Smoking Wheels....  was here 2017 hsfafahibetlasgxzidlkfyiondgakgedcbqecjehbmfdjmu
 * Smoking Wheels....  was here 2017 soxgiyacmdsgvquodemufbhxdyoyqppxsyzdsocqieyweocu
 * Smoking Wheels....  was here 2017 otbptmbjtpktlcqselvtwbcgdrkkrkpbwtuzwytkqrurnuyi
 * Smoking Wheels....  was here 2017 zegeltjurqbfkemelldromqhqafdzgdpfxqsattqmcwjhrbs
 * Smoking Wheels....  was here 2017 ianiqyfhfnhbohdxqopduwjfvpvxqshwrcafzswukgfxubvm
 * Smoking Wheels....  was here 2017 ivasuoccsxwbbbuhrnqzeyakhdhqytmljioqrwdmcgdnqcyk
 * Smoking Wheels....  was here 2017 veecpluornxfekuvqgyjusrptuypplgbuufghntrsjfrpefo
 * Smoking Wheels....  was here 2017 acqsbnfiwnqsolshzykqumnpiwggifotmxesicgmlgfdwzuf
 * Smoking Wheels....  was here 2017 gtkujbskifrazomujchjqsarfydihrmwkjwwmlijvrfwsizx
 * Smoking Wheels....  was here 2017 gqpzzqsxievypkeorjylbfzfzuovuskyseyusmbaqsobtknl
 * Smoking Wheels....  was here 2017 vjsepzzgkedkrvfdbsdzaykwkoxzlmxsvmkxgophysthvoew
 * Smoking Wheels....  was here 2017 fzjlgbmcijyqxaejxishtemomorfcjxhitkuodnkafqfzlcm
 * Smoking Wheels....  was here 2017 upodcfnkdatdaizgxryzsmslnisiuanxerjgjantibguqysu
 * Smoking Wheels....  was here 2017 etkwpxohcsjqejrcxmeypoxzaschxhdemezmpeqasixiifoq
 * Smoking Wheels....  was here 2017 ibknnwjfsixcscsldqehjlavutbhziivsnetnwbcejegxpob
 * Smoking Wheels....  was here 2017 jnfeuexvuwrteprcxjvihkhwvvfvynyxlddsoqiezswiluvh
 * Smoking Wheels....  was here 2017 riteqblajreclgkcychstyfilmkqvmftqrhfkfeqreamiqsy
 * Smoking Wheels....  was here 2017 yyfcmbmasigwptbsdpcgnunodopszekwldiicqpfaxyachwu
 * Smoking Wheels....  was here 2017 baaxcxtejryayyamptvboahgrcehzqfbfsfmudvtbdfjpddv
 * Smoking Wheels....  was here 2017 doxplpgfbtpvdywgutlnbvridlrusilkqvbfzgkmcmrgyurk
 * Smoking Wheels....  was here 2017 rssorlfavxsszenaicegnufztfwafwgdpfjkjtaupuhrmeub
 * Smoking Wheels....  was here 2017 fyslixduaselogbcclkbqqqpbdxxvdzvhuueyqsijclwukeo
 * Smoking Wheels....  was here 2017 tzibcuvxbzzzfcwahuvbijywwjzsegigbuhwwesbltrirwqz
 */
/*    
* Copyright (C) 2011, 2012 Stefan Förster
*         
* This file is part of YaCy.
* 
* YaCy is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 2 of the License, or
* (at your option) any later version.
* 
* YaCy is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with YaCy.  If not, see <http://www.gnu.org/licenses/>.
*/
HTMLenc = function(s) {
	return $('<div/>').text(s).html();			
}
$(document).ready(function() {							
	height=document.documentElement.clientHeight - 200;    			
	qtag = "";
	
	/* Initialize Bookmark Dialog */
	bm_dialog();
		
	/* Initialize Flexigrid */
	$('#ymarks_flexigrid').flexigrid({
		url: '/api/ymarks/get_ymark.json',
		dataType: 'json',
		method: 'GET',
		colModel: [	
			{display: 'Hash', name : 'hash', width : 85, sortable : false, align: 'left', hide: true},
			{display: 'Public', name : 'public', width : 20, sortable : true, align: 'center'},
			{display: 'Crawl start', name : 'crawl_start', width : 20, sortable : false, align: 'center'},
			{display: 'Title', name : 'title', width : 400, sortable : true, align: 'left'},
			{display: 'Tags', name : 'tags', width : 160, sortable : false, align: 'left'},
			{display: 'Folders', name : 'folders', width : 160, sortable : true, align: 'left'},
			{display: 'Date added', name : 'date_added', width : 100, sortable : true, align: 'left'},
			{display: 'Date modified', name : 'date_modified', width : 100, sortable : true, align: 'left'},
			{display: 'Date visited', name : 'date_visited', width : 100, sortable : true, align: 'left', hide: true},			
			{display: 'API PK', name : 'apicall_pk', width : 85, sortable : true, align: 'left', hide: true},
			{display: 'Date recording', name : 'date_recording', width : 100, sortable : false, align: 'left', hide: true},
			{display: 'Date next exec', name : 'date_next_exec', width : 100, sortable : false, align: 'left', hide: true},
			{display: 'Date last exec', name : 'date_last_exec', width : 100, sortable : false, align: 'left', hide: true}
		],
		buttons: [				
			{name: '...', bclass: 'refresh', onpress: function() {
				$('#ymarks_flexigrid').flexOptions({
					sortname: "title",
					sortorder: "asc",	
					query: ".*",
				 	qtype: "title"								
				});
				$('#ymarks_flexigrid').flexReload();
				loadTreeView();
				
			}},
			{separator: true},
			{name: 'Add', bclass: 'bookmark', onpress: bm_action},
			{name: 'Edit', bclass: 'edit', onpress: bm_action},
			{name: 'Delete', bclass: 'delete', onpress: bm_action},
			{separator: true},
			{name: 'Crawl', bclass: 'crawl', onpress: bm_action},
			{name: 'Schedule', bclass: 'calendar', onpress: bm_action},
			{separator: true},
			{name: 'XBEL', bclass: 'xml', onpress: bm_action},
			{separator: true},
			{name: 'Help', bclass: 'help', onpress: bm_action}
		],
		searchitems : [
			{display: 'Full text (regexp)', name : ''},
			{display: 'Tags (comma seperated)', name : '_tags'},
			{display: 'Tags (regexp)', name : 'tags'},
			{display: 'Folders (comma seperated)', name : '_folder'},
			{display: 'Folders (regexp)', name : 'folders'},
			{display: 'Title (regexp)', name : 'title'},
			{display: 'Description (regexp)', name : 'desc'}
		],													
		useRp: true,
		rp: 15,
		sortname: "title",
		sortorder: "asc",
		usepager: true,					
		striped: true,
		nowrap: false,			 									    				
		height: height,
		query: ".*",
		qtype: "title"									    				
	});
	
	/* Initialize Sidebar */
	$('#ymarks_sidebar').height(height+90);
	$tabs = $('#ymarks_sidebar').tabs({
		// tabs options
	});
	$tabs.bind('tabsselect', function(event, ui) {
		/* 
	    Objects available in the function context:
		    ui.tab     - anchor element of the selected (clicked) tab
		    ui.panel   - element, that contains the selected/clicked tab contents
		    ui.index   - zero-based index of the selected (clicked) tab
	    */
	tabid = "#"+ui.panel.id;
		if (tabid == "#ymarks_tags_tab") {
			loadTagCloud();
		}
		return true;
	});
	loadTreeView();
	
	$('input[name=importer]').change(function() {
	     if ($("input[name=importer]:checked").val() == 'crawls') {
		    $("input[name='root']").setValue("/Crawl Start");
	    	$("input[name='bmkfile']").attr("disabled","disabled");
	    	$("input[name='root']").attr("disabled","disabled");
	     } else if ($("input[name=importer]:checked").val() == 'bmks') {             
		    	$("input[name='bmkfile']").attr("disabled","disabled");
	     } else if ($("input[name=importer]:checked").val() == 'dmoz') {             
		    	$("input[name='bmkfile']").attr("disabled","disabled");
		    	$("input[name='root']").setValue("/DMOZ");
		    	$("input[name='source']").removeAttr("disabled");
		    	$("input[name='source']").setValue("Top/");
		    	alert("The DMOZ RDF dump is exspected on your YaCy peer at DATA/WORK/content.rdf.u8.gz" +
		    			"\nYou can download the file from http://rdf.dmoz.org/rdf/content.rdf.u8.gz (ca. 320 MB)." +
		    			"\n\nPlease check http://www.dmoz.org/license.html before you import any DMOZ data into YaCy!" +
		    			"\n\nDue to the large number of links contained in the dmoz file it is recommended" +
		    			"\nto limit the import volume with an appropriate value for the source folder (e.g. Top/Games).")
	     } else {
	    	 $("input[name='bmkfile']").removeAttr("disabled");
	    	 $("input[name='root']").removeAttr("disabled");
	     	 $("input[name='root']").setValue("/Imported Bookmarks");
	     	 $("input[name='source']").attr("disabled","disabled");
	     	 $("input[name='source']").setValue("");
	     }
	  });
	$("#tag_include").multiselect({
		noneSelectedText: "Select (multiple) tags ...",
		height: height-50,
		minWidth: 200,
		maxWidth: 200,
		selectedList: 4,
		header: "",
		click: function(event, ui) {
			if(ui.checked) {						
				qtag = qtag + "," + ui.value;
			}
		},
		close: function() {
			$('#ymarks_flexigrid').flexOptions({
				query: qtag,
				qtype: "_tags",
				newp: 1
			});
			$('#ymarks_flexigrid').flexReload();
		},
		beforeopen: function() {
			loadTags("#tag_include", "alpha", "");
		},
		open: function() {
			qtag = "";
		}
	}).multiselectfilter();	
	
	$("#tag_select").multiselect({
		noneSelectedText: "Select tags to remove ...",
		minWidth: 200,
		maxWidth: 200,
		header: "",
		selectedList: 4,
		height: height - 540,
		beforeopen: function() {
			loadTags("#tag_select", "alpha", "");
		}
	}).multiselectfilter();
	$("#ymarks_qtype").multiselect({
		noneSelectedText: "Select query type ...",
		minWidth: 200,
		maxWidth: 200,
		header: "",
		multiple: false,
		selectedList: 1
	});
	
	$("#ymarks_importer").multiselect({
		noneSelectedText: "Select an Importer ...",
		minWidth: 200,
		maxWidth: 200,
		header: "",
		multiple: false,
		selectedList: 1
	});
	
	$("#ymarks_autotag").multiselect({
		noneSelectedText: "Select an option ...",
		minWidth: 200,
		maxWidth: 200,
		header: "",
		multiple: false,
		selectedList: 1
	});
	
	$("#ymarks_indexing").multiselect({
	   position: {
		      my: 'left bottom',
		      at: 'left top'
		   },
		noneSelectedText: "Select an option ...",
		minWidth: 200,
		maxWidth: 200,
		header: "",
		multiple: false,
		selectedList: 1
	});
	
	$('#ymarks_tagmanager').submit(function() {
		var param = [];
		$('#ymarks_tagmanager input[type="text"],#ymarks_tagmanager input[type="radio"]:checked').each(function(i){
			param[i] = { name : $(this).attr('name'), value : $(this).attr('value') };
		});		
		var tags = "";
		var ta = $("#tag_select").val();
		var i = 0;
		if(ta !== null) {			
			while (i<ta.length) {
				tags = tags + ta[i] + ",";
				i++;
			}
		}
		param[param.length] = { name : 'tags', value : tags };
		$.ajax({
			type: "POST",
			url: "/api/ymarks/manage_tags.xml",
			data: param,
			dataType: "xml",
			cache: false,
			success: function(xml) {			
				/*
				$(xml).find('status').each(function(){					
					var code = $(this).attr('code');								
					alert("Request returned status: "+code);
				});
				*/
				loadTagCloud()
				loadTags("#tag_select", "alpha", "");
				loadTags("#tag_include", "alpha", "");
				/*
				$('#ymarks_flexigrid').flexOptions({
					sortname: "title",
					sortorder: "asc",	
					query: query,
				 	qtype: "title"								
				});
				*/
				$('#ymarks_flexigrid').flexReload();
			}
		});
		return false;
	});
	
});
function loadTags(select, sortorder, tags) {
	$(select).empty();	
	$.ajax({
		type: "GET",
		url: "/api/ymarks/get_tags.xml?sort="+sortorder+"&tag="+tags,			
		dataType: "xml",
		cache: false,
		success: function(xml) {			
			$(xml).find('tag').each(function(){					
				var count = $(this).attr('count');
				var tag = $(this).attr('tag');									
				$('<option value="'+tag+'">'+HTMLenc(tag)+' ['+count+']</option>').appendTo(select);
			});
			$(select).multiselect('refresh');
		}
	});
}
function loadTagCloud() {		
	$("#ymarks_tagcloud *").remove();
	$.ajax({
		type: "GET",
		url: "/api/ymarks/get_tags.xml?top=25&sort=alpha",			
		dataType: "xml",
		cache: false,
		success: function(xml) {			
			$(xml).find('tag').each(function(){					
				var count = $(this).attr('count');
				var tag = $(this).attr('tag');										
				var size = ((count/20)+0.15);
				if (size < 1) {size = 1;}					
				$('<a style="font-size:'+size+'em"></a>')
					.html(HTMLenc(tag)+' ')						
					.appendTo('#ymarks_tagcloud')
					.bind('click', function() {
						var qtag = $(this).text().replace(/\s+$/g,"");								
						$('#ymarks_flexigrid').flexOptions({
							query: qtag,
							qtype: "_tags",
							newp: 1
						});
						$('#ymarks_flexigrid').flexReload();					
					});																									
			});
		}
	});
};
function loadTreeView() {
	$("#ymarks_treeview").empty();	
	$("#ymarks_treeview").treeview({
		url: "/api/ymarks/get_treeview.json?bmtype=href",
		unique: false,
		persist: "location"
	});
	$("#ymarks_treeview").bind("click", function(event) {
		if ($(event.target).is("li") || $(event.target).parents("li").length) {
			var folder = $(event.target).parents("li").filter(":first").attr("id");
			$('#ymarks_flexigrid').flexOptions({
				query: folder,
				qtype: "_folder",
				newp: 1
			});
			$('#ymarks_flexigrid').flexReload();
		}
		return false;
	});
	return false;
}
