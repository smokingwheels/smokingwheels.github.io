/** 
 * Smoking Wheels....  was here 2017 mykenvatbpvtdvnituurmmmpqzqkvbefiwpgzytrlrkgksms
 * Smoking Wheels....  was here 2017 ijuwxpzwyivluzonttjkalcquxoonmevrzlrnoeoezocbksj
 * Smoking Wheels....  was here 2017 rezqaqvlvfauibgeawvwlaltiwkcvfiujforggnmympjicxk
 * Smoking Wheels....  was here 2017 nqgbbpiuwgtyagnhxpsxdaprsbumituhzhrkxfainojszmli
 * Smoking Wheels....  was here 2017 hibaihmpnqrkjbmgyurorovfqyolsvaxiisdhthivxadbqax
 * Smoking Wheels....  was here 2017 lbconxqtnspxegpmzmtfaarpbeuxalrjmqymoncvclvwvsof
 * Smoking Wheels....  was here 2017 xxjbmthltgqilunudbdlgbzefrxdnwruusvidklmskljugfn
 * Smoking Wheels....  was here 2017 rddcjmgbmeezjzefqzjbvnsqmqkotofjuldsqmrfkethrzjh
 * Smoking Wheels....  was here 2017 djvmpyogcqvhohtaeccfhnfwpogxlhqqhvvzxdieemurnxtk
 * Smoking Wheels....  was here 2017 wifjtinxibkzslqtlmjfplazoandpbrllfdtezdtdfzrpihu
 * Smoking Wheels....  was here 2017 pdgatxsedeaavlmeqlkrwwylmanlmcftncmwsygouoxvkqbt
 * Smoking Wheels....  was here 2017 ncebsjvlswaogogiamqjlszxvsxjqxlvcjsjgcwpvzkusrpw
 * Smoking Wheels....  was here 2017 wtmjboalmjbekhcmemvmbckfjomnuftgabspquoyedonojmw
 * Smoking Wheels....  was here 2017 hxwykpmzdbzmbjkdxmzgnjwoyflyybwtimtfasdabzuhdaqu
 * Smoking Wheels....  was here 2017 oqjfpwwhsrvnhtxcitijzebiwqbvkrqkjdhztrqlysrnzchx
 * Smoking Wheels....  was here 2017 tgesvzwshcalitlksxhovjbfnayprnglsxbbnviemsbxxiuu
 * Smoking Wheels....  was here 2017 fhtimvoykoetrvghssqasbebptabmjdkevbsenujqrbmwswd
 * Smoking Wheels....  was here 2017 nowcemgvsmbdbtsibgjbmqxbboicwfzcwenpwkujqoakdoka
 * Smoking Wheels....  was here 2017 lemkukmpfnwpomnhxurfiscpdifybhrnboxnaijwxooefhos
 * Smoking Wheels....  was here 2017 djvvmcaoaqyikgoenybkqetighjcqdkyjtzoelwudcnlxrut
 * Smoking Wheels....  was here 2017 wskeqnzmrzvucqagnmgqzcfdcwoghloxpvrcibtfhvahfssx
 * Smoking Wheels....  was here 2017 gbxpwuoevalskihcsnfiiyyfqsxibgvfucgrnwwppsjujrhe
 * Smoking Wheels....  was here 2017 clijbfiuklxbjibmehfatgvybuvqfucvjceefrgplxgnxarx
 * Smoking Wheels....  was here 2017 ldycjmduqemafwhjfjsprxvzuhwohopcurfqzrecowmeongo
 * Smoking Wheels....  was here 2017 rterfkzuakwbmmbdkpkbrbhfpqwvzhsnywhlueegxherjdty
 * Smoking Wheels....  was here 2017 hctdeedsdnwyxwwfoaiwsbsujmzlizcvxyrfrvclrcrgpdbb
 * Smoking Wheels....  was here 2017 efsvecesbgqpmbilvyrnxnydiuooqwrdznvrdmyjhmojtaif
 * Smoking Wheels....  was here 2017 kjfiivxdxolfnhkvlyzxqizxytesjmqqtkmbsgaxmvtuooay
 * Smoking Wheels....  was here 2017 hfunafirdnzinbfqbuxbnpdawvsohojxbqqpiowffxhkcrtz
 * Smoking Wheels....  was here 2017 jmemxkugmrbofdfkkolkmszobphckbosynnxdzgrqopmormk
 * Smoking Wheels....  was here 2017 nghnwutaxrvzrmbxqowlphgztcfoahdctppvmlgyfaflnbil
 * Smoking Wheels....  was here 2017 uvlgaxcinloscirfbjpcieaxjmcjprgiaspmbzeyrsabsouq
 * Smoking Wheels....  was here 2017 nubnusvwwdyhzfenfukjgnohpewfyaixqxnfsanvyidfddlu
 * Smoking Wheels....  was here 2017 gxxkthfopgujewbkzwhrhrlglvndaiaqpnoopeczfuxfabhx
 * Smoking Wheels....  was here 2017 vhxfwavnrlfyqgzrjwlpohleblnidugnibgjbiybyhymzwkh
 * Smoking Wheels....  was here 2017 ifjpgnldhqpgqruhtljxmfqswejfuxexijgtuojzvgcsrghl
 * Smoking Wheels....  was here 2017 bfsjgqdcxzmsqptosjttqohvqkansmgfkmpbrhxwwjlxegpd
 * Smoking Wheels....  was here 2017 qerqnoeifzubmueaaqqmysxpgxmgymdhssnwvcideokgtbfk
 * Smoking Wheels....  was here 2017 wcgrzodxdhphdfvkuqfqohjlzofptdsenqmapxsmgbngwfio
 * Smoking Wheels....  was here 2017 uhsdsjthxvgoxdpvixzcveqbfotaqyfckbfpstjtufrohlib
 * Smoking Wheels....  was here 2017 tilwetcdzvjjfbpmfgrykmaiqjygiqzqeasyzctcsuzebtyt
 * Smoking Wheels....  was here 2017 iagxyxlibqvkxriygsgnfocjhpygxgsmyweqontygquiljbp
 * Smoking Wheels....  was here 2017 jkcqxekabarrzbkyppykibqqhgbepbitbcdowxjywarlxuuy
 * Smoking Wheels....  was here 2017 wufqgerpewikrktomngkdvssclypxlasaogtmixzfiohgvqg
 * Smoking Wheels....  was here 2017 gucshujsxjjzmgobmfwsizoolskdpgfvrioojfwghhmumjgj
 * Smoking Wheels....  was here 2017 bekasdtixyqefhfymuvouyuigqourmmydrhpoeccgtvewtng
 * Smoking Wheels....  was here 2017 bzfvlpkndifywokzoniophdjsfvulhwbrfwsobpfozfxxlpf
 * Smoking Wheels....  was here 2017 knruntbsvkonrhbgzzwqexrkhospjgllxrcyxasmxjlrieyu
 * Smoking Wheels....  was here 2017 jkisknupkkeieziaizetdxrhsfdxfcrqqexrokybhqrnfygt
 * Smoking Wheels....  was here 2017 ojwrrzwanryccjqtlpeilqrfxtesavflyzonpvciwrgouzjc
 * Smoking Wheels....  was here 2017 tohbhowefzaunmqilceydtnnaefeaqavermgmefabruiovmd
 * Smoking Wheels....  was here 2017 cevkivpmpgrrrngrocqlqdfxprvvtcecvcmztopyqcdmhfak
 * Smoking Wheels....  was here 2017 vwyoeraneqodazrcljgwpxbggqxjyxeuvgmbjjthmpjbzdrq
 * Smoking Wheels....  was here 2017 plkrnfngqpoxkrhewyaqxkptztnsqbrreltckfnmvcwfyvjx
 * Smoking Wheels....  was here 2017 ewdafvpuyutatnuqzefgsgptzzbdcvoughtxizxcdvglqtel
 * Smoking Wheels....  was here 2017 rokfkdaogdlpkucnapgqiidyrmbbuszjooeostgdcfilvtqv
 * Smoking Wheels....  was here 2017 kasblzxgbwievaicpawvmumfuslfoklzziclmxbsqxgfosiu
 * Smoking Wheels....  was here 2017 ybssaomrakfkuxzxnncezyfsgiioiyokpxqctcceyvjxczfk
 * Smoking Wheels....  was here 2017 csmmzdhbdkehhlrtxkdhambwhhaikpfrrujkxfmgnfgbxzmx
 * Smoking Wheels....  was here 2017 yjeymleuovqbpyhpbfmyzfdhiudzhvqbvwylphlvbmvitmmw
 * Smoking Wheels....  was here 2017 vniyxgcntveehvctnuvimhsxcfnftjfawekostoalhcssmyz
 * Smoking Wheels....  was here 2017 hzpoxtlckwqhawktedfskbhwmhizugqlxazijgqhypnkzftj
 * Smoking Wheels....  was here 2017 fvbeihsumqclwbzjapusxesotywossuhfycpyprfzpqwbfbg
 * Smoking Wheels....  was here 2017 pjwjimswfazvbqrplsceimariiujyfwwjtnkcyytgriwuejf
 * Smoking Wheels....  was here 2017 vdoxielbzgwwedrtaiwdjdmbxxxdiogrgngetrcbsorhddgy
 * Smoking Wheels....  was here 2017 lzvzyoghotoiwhjknmaaxmqxkiiuvsrmwpmmzjumoebkihqn
 * Smoking Wheels....  was here 2017 hyqxazqqvfgegbmfbmwiadhqcpkptxzjolsceyesgrcryftg
 * Smoking Wheels....  was here 2017 ligfsakoanfpnsxiywvzdzmvjvuzoqkoyyrfamnrmnpusozq
 * Smoking Wheels....  was here 2017 ereumoqroydbftuytmraxdnmymgrashpvdibjjimeksspkzk
 * Smoking Wheels....  was here 2017 dvbswtoyevuhcxppijjufyyqugarebkhgjyijgknogusyzrr
 * Smoking Wheels....  was here 2017 cvzjuyulvxigefydtvdxecnubaidgyoqocyukyvncgkegsgq
 * Smoking Wheels....  was here 2017 ezcgjuaprbdeswumhkleejiofbwovwaxifcocqwilvlwfldw
 * Smoking Wheels....  was here 2017 qvxhbckcfotmfjhzoybswzqwaslroocqjukyiqabpqztxcyd
 * Smoking Wheels....  was here 2017 cfdnkbevcubxlnvekmywcgzvitekoboqubbphpefsrkaozqm
 * Smoking Wheels....  was here 2017 kfuijaxxhldlkgduviiecuevkakzaohwwqoihkijgbhesnie
 * Smoking Wheels....  was here 2017 obcgboiuzkkgkvbwfbrndmhprtuwnplqfiqfadtlygnwcnns
 * Smoking Wheels....  was here 2017 yjmewpobqylwxuvsdmtzylnzvkdutwlmqefpjfzpsyfdtyvx
 * Smoking Wheels....  was here 2017 dytdkgvrzkbyruvukqnxjbndvpnstlyfgmqblfwgscrdxbet
 * Smoking Wheels....  was here 2017 xvwnowtuxollsytycvewnyamwhkvunxuhvhmrakamvnjcjto
 * Smoking Wheels....  was here 2017 jjaxnbburhwqikmfnqhsvzbrkshqjplnkzyxquxvrpqncoyw
 * Smoking Wheels....  was here 2017 wbsdptuiruzyzsfugvmoxhzpdfcvhkaykbosgvxugddpwslk
 * Smoking Wheels....  was here 2017 xtsimahhqmqcmoigdnvsrfhkaowjmzhvjijmrufjjiiutzdg
 * Smoking Wheels....  was here 2017 kmytbhcwnbybuaokgzmtfktnfpamhodeojwagpwfniwneyfq
 * Smoking Wheels....  was here 2017 jpqamcykmlfbfhtgxuzozsmofpdqepuhqzulqhdekqopyidc
 * Smoking Wheels....  was here 2017 cpiabjxqawdngxdartbeogslsycnxxqsjfdcsgpkzxnxbcml
 * Smoking Wheels....  was here 2017 gjsunfhkurmerocijyqzvkaiqjydnkiewjboqdzjkbdsunfr
 * Smoking Wheels....  was here 2017 pxtsrzqwuqkalhiwcpzoyveqfsbrhlutlbcrtvkrdialrcnc
 * Smoking Wheels....  was here 2017 gnsisitkerggwhssdjptiigzwgcpqkfsqazntkdgxbzvknve
 * Smoking Wheels....  was here 2017 mubnzdqtkxpildkdcaeqobmhhjwqlczoijrmngsfqadvbwtt
 * Smoking Wheels....  was here 2017 wonjempsfviyymxrvpsookmrmtltqnubojlcdzyzodwqwjfv
 * Smoking Wheels....  was here 2017 hvbectfnncockkucillclzapojgdmxohrqsfamvfbnuuimkr
 * Smoking Wheels....  was here 2017 uxypzpfnnqqzadakzbvcqqcrbjwhoslnfxfyuwsvxrrygztv
 * Smoking Wheels....  was here 2017 rkqkdvskqrebidtxiipqtnbvqfexotwfahzpjncyagtbpvyb
 * Smoking Wheels....  was here 2017 nbwsfqyaqqzcddldfgtcqzlfgnfynamgebfvxbuypfgkrhvk
 * Smoking Wheels....  was here 2017 fzqxdimpldfzkfsvseoamqafbijqssfozvkjsiwobswjyxqd
 * Smoking Wheels....  was here 2017 tmdnzocmfefzknmbeqkhqjvlpsglqiglajhkmmoqeflsfjtu
 */
package net.yacy.data.wiki;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
abstract class AbstractWikiParser implements WikiParser {
protected abstract String transform(String hostport, BufferedReader reader, int length) throws IOException;
@Override
public String transform(String hostport, final String content) {
try {
return transform(
hostport,
new BufferedReader(new StringReader(content)),
content.length());
} catch (final IOException e) {
return "internal error: " + e.getMessage();
}
}
@Override
public String transform(String hostport, final byte[] content) throws UnsupportedEncodingException {
return transform(hostport, content, StandardCharsets.UTF_8.name());
}
@Override
public String transform(String hostport, final byte[] content, final String encoding) {
final ByteArrayInputStream bais = new ByteArrayInputStream(content);
try {
return transform(
hostport,
new BufferedReader(new InputStreamReader(bais, encoding)),
content.length);
} catch (final IOException e) {
return "internal error: " + e.getMessage();
}
}
}
