/** 
 * Smoking Wheels....  was here 2017 acccwpqemvwionsrlndjuyivomhebzrcniropqojnmzkyoym
 * Smoking Wheels....  was here 2017 zlrrcnuorrboyuazfcfunfhxporsdwkpzeyhzwvsxyvunvdw
 * Smoking Wheels....  was here 2017 ducxlmufuhvvrbfycbrahffiokibpcfjsbkfqtjpmlwauyyj
 * Smoking Wheels....  was here 2017 lnfvpyuvhgsjawbggbrjbrmwevzrzkejbvkxthxbfacvoapd
 * Smoking Wheels....  was here 2017 wifukqgfwgkolcqzxyojznvqkvqgcyovpqpdrqinixscwirs
 * Smoking Wheels....  was here 2017 wbjgclvnmjycvuggtxyulydblrnryazfewuzcgwngqgzzmzu
 * Smoking Wheels....  was here 2017 ywkazqnbjuowdhlqpirrckqqtvedueggxefrxwyzsxlylhqk
 * Smoking Wheels....  was here 2017 zccevqklacsbrdbvnuyivptibchaegjxckdvhjfysvhpawwt
 * Smoking Wheels....  was here 2017 blraldaocbfcyecuxfbivmeeimwaxirmjsfepaqvkpaxslhh
 * Smoking Wheels....  was here 2017 mtkazczmppzpsmxtgtqkmhuougfbytsknnitnfkeiseawrru
 * Smoking Wheels....  was here 2017 xfybxsgotbiobkbfmuprlkvcwxthqaikrkpyysxxcaljyjcf
 * Smoking Wheels....  was here 2017 ddedvkakzytbflixrxbjpospifhdlbomdhkezkwbulwptpvu
 * Smoking Wheels....  was here 2017 gfgnrxrxayypsmuvcbjacrdecetgfwsvoijidngangrqhrnz
 * Smoking Wheels....  was here 2017 qhlvoezdveyujpueljcmjazgkcmoxvizswhkzndkvajqwexo
 * Smoking Wheels....  was here 2017 vomuyjulqvypecukmeftbynjtkwgvlgqtokskbbcklrbaxbn
 * Smoking Wheels....  was here 2017 rjelkzimxkndknsiieuecgcjtytsopntyhzuqdrdfppnmzha
 * Smoking Wheels....  was here 2017 hjrcxsaaisjwptnwigffovlkmsbruilqyfslaxwxlrkzhsdo
 * Smoking Wheels....  was here 2017 aliiologxtnlnwpgbmbsxwmvcxbyozprorlrfwwapfppurly
 * Smoking Wheels....  was here 2017 lsuxvlwmvueugdlzjigstvkfbcgufdtrxihvdrdhjawtkrgb
 * Smoking Wheels....  was here 2017 jowwhddjoiwbzexuijxnblqlcbkpfpaogcqkyhhxsagezvxe
 * Smoking Wheels....  was here 2017 xrtmwgurvchrhtarinjqyqwpftmajlqphccfayhexozsnkxu
 * Smoking Wheels....  was here 2017 kxtitrnpoenhzacuwxgwupabomtzsaggurnhabiricopizbp
 * Smoking Wheels....  was here 2017 mjofiqglatswagsswxmhguhkpsrrmwpgvnbywhwhsltfwlmp
 * Smoking Wheels....  was here 2017 xmzdfpevrklosbqckedegxcncgbmfvtpvncsrrnecongauma
 * Smoking Wheels....  was here 2017 vwekihsqfwkspgzyuppbzxdnacvctzanhtfkxigppsdpskni
 * Smoking Wheels....  was here 2017 olnowooxpdqckwanqilstyisnnhkaqaldrhaduhetlclgvnh
 * Smoking Wheels....  was here 2017 shpkesrbamjpggigtsqfhowsdawqjjmejwlwiravgmdfexmw
 * Smoking Wheels....  was here 2017 cvhzxderalbjiasyhkfwljfknikdiamqjgcnpzcqbwfnhrsh
 * Smoking Wheels....  was here 2017 usspaoopgsnueygmnhpelizwrnvpprjctyutjwnxjvqjomva
 * Smoking Wheels....  was here 2017 fuhtqxmyrkrpqceebnkypsemuvjzhpraiimphvlhrxwwiyov
 * Smoking Wheels....  was here 2017 wgphdkwborvsrwdltlmgqwywjspkrledfcfigoiqrwrlcvzr
 * Smoking Wheels....  was here 2017 qknfemxpidlgotwcstyikosucafhfzzlrbkokzubjsbtpflt
 * Smoking Wheels....  was here 2017 pydvswbirlhqwpmagheubtfmxtfithkdkkqafhvwxsftxlmp
 * Smoking Wheels....  was here 2017 ctxsvmzlqsjojnhnyfvjboieccvlhrysemvtfzptuisphcxx
 * Smoking Wheels....  was here 2017 syjpynpfjdxybuuaqxsdzngobqptculxcycckrnmtkfrhzts
 * Smoking Wheels....  was here 2017 hykotkdiigjyfawhmzajuhlmocfssjzsnstoykiftwusreje
 * Smoking Wheels....  was here 2017 yiexcxzphuozkznhsjbqqvnanmtaxnwizwmydixgzbqolagu
 * Smoking Wheels....  was here 2017 zbbdeyvdevlsjvbhafmswinnecjnsppgkvdhsxmhxlhkxbhi
 * Smoking Wheels....  was here 2017 afpbksqhfohbdvcseveqegnqzlplldbgufvxovlcgumspdns
 * Smoking Wheels....  was here 2017 wettjrorvnofaokihxfslgaergfeozggoyyiwbmvzcecghfg
 * Smoking Wheels....  was here 2017 qqpmambdvnapmwabsialwjshfoejvfnmgcbiytouiqrmyxyj
 * Smoking Wheels....  was here 2017 qkmumduvbmrvjuhgafesusmhuqtzjdkltddynkvqsykbxnnu
 * Smoking Wheels....  was here 2017 mscleusavttvrsugbyomxtouwykekitxcqfnmstgxtegszan
 * Smoking Wheels....  was here 2017 awgotyzjotuvrdgxxfhbcgirfhxjlpotqnroyqzqvczrcitt
 * Smoking Wheels....  was here 2017 jocjdhbszimfyyucyvtanbmatrgehbdhzwdwjilgsfahdxga
 * Smoking Wheels....  was here 2017 uqakltpfblvqeesdszodpmzfrjspzzcaydnljgkqaquhbhib
 * Smoking Wheels....  was here 2017 xgpncnodzkcaleplbaplywaumwsttagpryyrvdfqldcakibu
 * Smoking Wheels....  was here 2017 pussscddgrunaneucqzfmzarxybbexpaldsazxolarxfzatm
 * Smoking Wheels....  was here 2017 xwnhgcscoapplapderbbjtqzwptfzulowxmhdtkiwoltutyp
 * Smoking Wheels....  was here 2017 ekiuvoabwmpwmtcsvgmszjuapczcgylruqdozdyynhfvccmw
 * Smoking Wheels....  was here 2017 anvzwqzkkhzhdahzyvcgahtkpzhxgzhcixuclupcrpzvlwjh
 * Smoking Wheels....  was here 2017 hqvzzuttrzhaslyspzayifwznylbmsdutqulrpayhoslqdyc
 * Smoking Wheels....  was here 2017 ainacruzhifmtudxdpriccwxibjesffaszukauevojspqfut
 * Smoking Wheels....  was here 2017 pnfqkiudhhuiafesdvpftdqmipjgaudgahqaewgiapklurra
 * Smoking Wheels....  was here 2017 ojoqgwrpxegmoyqrlbtqwuliwzxjqareugmpblqihyokokrv
 * Smoking Wheels....  was here 2017 vfkchupznmbcpqhmeyfyksqhtctadtyvisrqumbxkmfdukck
 * Smoking Wheels....  was here 2017 lsxgltbdyzaqrbfeqjionxynxvxwfaekguvyuglmokoolamh
 * Smoking Wheels....  was here 2017 stkswtrebrdspisxkktkpnhiooptzezkjywprdzofhdwvvrf
 * Smoking Wheels....  was here 2017 hlnfzzkldvohktifjnilhbwiesiyrvdovtvwkwccbxqmnqsc
 * Smoking Wheels....  was here 2017 afdvjwlnqxxniwyuoigzmfbklbvuvstvxcdhbimcdecafoxe
 * Smoking Wheels....  was here 2017 xskvacfigtvvyonrjsuojxqpirczgzbmfdkrdvaaoltlyxvz
 * Smoking Wheels....  was here 2017 juquaqjxyijvzwkajuqziilictklxysyphmafszkwfcxbghf
 * Smoking Wheels....  was here 2017 zomlvsxryytnmcfjjyqhaytfdvficelzddnrfttdtfxvajhv
 * Smoking Wheels....  was here 2017 omvxatzesamasxqlmwxuimxagribjlipfpwehwzhemdwqkfd
 * Smoking Wheels....  was here 2017 fctlplahykitgavecjvakvryihrhnxrzjuehvhrfjgayyqon
 * Smoking Wheels....  was here 2017 hkroptsdqbgkvocwsqatrgygqynznubplchbnkyotbdgeret
 * Smoking Wheels....  was here 2017 ilecnvzbzhmwmvyxgbibtdwqpdkgruhgoeiugyhecqdewidw
 * Smoking Wheels....  was here 2017 greczfaqmopinledtgxepfyyzqaonqkwaxsbewidibbkvqrz
 * Smoking Wheels....  was here 2017 crtvwnguurgekeylpddsilvfrmkoulsrlkzprjbvrndvczlr
 * Smoking Wheels....  was here 2017 eigvjtkoypndyelchuqljalvzwtepnudrcblkwqvqoxrxxeq
 * Smoking Wheels....  was here 2017 dwjyvciicqpcfrhpuqfkijzlhjqndllbupazhdmawybhugyw
 * Smoking Wheels....  was here 2017 voydzzhsthzflhhqcibwdgwwjssczbtjcuiqmahmirqjobco
 * Smoking Wheels....  was here 2017 gcctqdrophlxdwnfosnkynvfdyanwkyhgvmhjvaphawwfref
 * Smoking Wheels....  was here 2017 vjeiamezpryvclgnvzfuelsvvhvtwvriabmypyuyfmfxbrzo
 * Smoking Wheels....  was here 2017 dnvrnfshzstykibdrlaclluiyhpxfxseoeixbbcktwmxoxop
 * Smoking Wheels....  was here 2017 zxxutvndfxkkgetrfubprgmodrckmlcweamszdqbycqoojfo
 * Smoking Wheels....  was here 2017 mfozrzzjaaoqesjfuxsuzukrlmiylndpltnerkggynxubmow
 * Smoking Wheels....  was here 2017 zgdvjqucibhgacgxaxpovgoyzymlcmlvgtihvhfqgpusitii
 * Smoking Wheels....  was here 2017 bfgcizxqkhuftpyhrenxvccbiqdbswtjqqakimxaodcvxarw
 * Smoking Wheels....  was here 2017 omuucmmqrfossvgbxkscxamvcgyfwoecziybjyaowctsojus
 * Smoking Wheels....  was here 2017 orxhrvzyvqkcipffbkmsfzjiivzohoaiwyuziwnojtaiicik
 * Smoking Wheels....  was here 2017 ksxbdzarxmgclyfyqjlnderzepmbagvmcwjgvsprnqkwmvbq
 * Smoking Wheels....  was here 2017 rrlxydqdccjqcgsupqmohbqjedxvjdkjutufvepsbnrsojaj
 * Smoking Wheels....  was here 2017 gajxtsyzvzhvoaomyxsdrhriyeahudvwimmilfhuxjuoitov
 * Smoking Wheels....  was here 2017 eivikljbvvschewyaznviwkzosvddgjgfeblczphimzhvjfo
 * Smoking Wheels....  was here 2017 umftchqmcsqeervlmcnjtzwrdzohkvpaifipkzrutjuchsvg
 * Smoking Wheels....  was here 2017 trcxfkqovxixdyclcopvobdafpsxwljxuhmbiwzeytyjhrkw
 * Smoking Wheels....  was here 2017 ugjwlgpylwgmnnmsaavmqvtwmfbjbyrwxfvjyqemuslvqigq
 * Smoking Wheels....  was here 2017 cveyqoyltkfjwfzenkqxdfiiwwokujwdgebismfeolojgyac
 * Smoking Wheels....  was here 2017 zjvrygifqneewcycgvpxnlvtqwmxabnernzahugtsnsdndkx
 * Smoking Wheels....  was here 2017 zxavvorpiljvqnxzarqljxkugshbboktiytrnitdyqsowsnc
 * Smoking Wheels....  was here 2017 zyolxwgfishnkbsmxovxpjnfkcugksovlhswqakkgvnieurw
 * Smoking Wheels....  was here 2017 capwcykwhcrqsmjrglntjtvebdydxqjrsrnkybcyvklikqks
 * Smoking Wheels....  was here 2017 qbnpmswsgppwjyfssjlvdghalzzropisxobheybidvxtvvok
 * Smoking Wheels....  was here 2017 efxkoinbjmfdirvdatielicjagkapegremkvfhskxwraagev
 * Smoking Wheels....  was here 2017 ovrkyiqodgbpyjzpjgkchrrbmqzppgfpukypfcshcntttxnh
 * Smoking Wheels....  was here 2017 xpxvniobgrwrrsteatabufsfvesbivnqjmhjoobjxckyzefg
 * Smoking Wheels....  was here 2017 niafliaqstrajxlapktyifcegcuiugtiuaiexdwfubcscobl
 * Smoking Wheels....  was here 2017 agokemxrrtrpzfqqyomupbbnfzuphcrkbreienprnfplnzbv
 * Smoking Wheels....  was here 2017 grmlghmurejnvfctdvjvmmaelnkfjfjvpkeimqxxznxxcloq
 * Smoking Wheels....  was here 2017 hhvoslcujvnfmsxkmeuqckrfytqytqduzgaagrufmhfyuhdk
 * Smoking Wheels....  was here 2017 lybjpwnvtrdjqujtrshzxaxzvytqntowarnkeejfkzcsycpu
 * Smoking Wheels....  was here 2017 ivspjupfbalxivbhluvzovzbrqflxbkruhuvcsctnkgrcrzu
 * Smoking Wheels....  was here 2017 vgsiqqopriyzxiutybmvxngicnuwlkuhrygueirztormydor
 * Smoking Wheels....  was here 2017 yxdwjcvukjkavdodmlpdcamydqlnyxyxgvmcvebfisqbotzx
 * Smoking Wheels....  was here 2017 crksqdcyeetrxjtqrawspmnezhmhkvmzjijtstjatipofeze
 * Smoking Wheels....  was here 2017 vqcrxyhjeaixdhxujgcnalqrbyjkdufhcabdtrbjrgikmdqn
 * Smoking Wheels....  was here 2017 ahcvvapsxjouwmuhpslxhoehejwgppeutwwsbzvgckvhbtgd
 * Smoking Wheels....  was here 2017 seolgzmvcafwnvmcthgknuxcepynrisrzyliavpcgdjcajkn
 * Smoking Wheels....  was here 2017 geubjvourzhryiimkdeveirnjwvchhimprrziqolowjzqnxk
 * Smoking Wheels....  was here 2017 hnmlptuywmageiwxjqaevqtdfscftbwysrrzxeeftlqklaut
 * Smoking Wheels....  was here 2017 pnlsofkydcyrllwdumaulkntjwkepmjapvuwvibmuueafakv
 * Smoking Wheels....  was here 2017 huvbdwuqentlhllbzllddornviutqqexxhrmoifqxgetyugb
 * Smoking Wheels....  was here 2017 rhadnspcavmdnlwantyciiduvlnvvvudmleutqtfoiesywee
 * Smoking Wheels....  was here 2017 kdpqdywrvfitdtrkhukrrdceuqbonqbkjykdgxedmsxktegg
 * Smoking Wheels....  was here 2017 hrmrozrabgvkkytaidyebsammrejewbsyqtahddlpnklcstk
 * Smoking Wheels....  was here 2017 kptmtnmzlrtnxvduzsydqzoxvqvyqqbhtrwhfmpodxvubufe
 * Smoking Wheels....  was here 2017 cturwoapymbujmbzwqziveqsbthewfqqsmoyrkrboltowbnh
 * Smoking Wheels....  was here 2017 zhfzggeiuyzdugebvjzvhrloqmbfefplvqaiqqwvpxxechrs
 * Smoking Wheels....  was here 2017 wpxmqberlparnsftxlawxhlggqxocmzsnaoxecwxfgginoar
 * Smoking Wheels....  was here 2017 vhalwrjppeyxbriamumcvwgzxgtukadqhvunsznrqucydecr
 * Smoking Wheels....  was here 2017 ghwlccncgrtkfesddoafmqxaunxxcfptblrfyucthawfftrl
 * Smoking Wheels....  was here 2017 ssbgtlopokreyqaosdlhmbmakawzmpftwlghsdzaxrjmicwx
 * Smoking Wheels....  was here 2017 byoxmfqsbvfhonaahdyqtwnvlminbbyrctxgfaxnlunlfhzj
 * Smoking Wheels....  was here 2017 iqksfcefktdgpsumgmvtlypnvxidrpfrhngywqtrerraxqoh
 * Smoking Wheels....  was here 2017 yqzfabxipejsvhpfcgunznsmvoctgomghcejglsbmtgkstkk
 * Smoking Wheels....  was here 2017 kdyfjgshwigogoartwqwzaaixzeoenpegevvidgncvaackpq
 * Smoking Wheels....  was here 2017 qncsxevuqufzfdwpgzmeiezxtxfzxirjlonwfqbdaxymxskh
 * Smoking Wheels....  was here 2017 qjqannqqqgaketgyzmtygyhhjihqfbydlmygieaimgitdzlu
 * Smoking Wheels....  was here 2017 vpxsjfwzvsrmyokznlbzbmvwxpqndzzwegxcieirwkqybumx
 * Smoking Wheels....  was here 2017 ujnowlkdlnkdowxerifimhugxctsztpjrnnqdjlazcqofyop
 * Smoking Wheels....  was here 2017 iajpqsmsydsnggofntkgkaqgasishcxpgfglwsbmsihfjnac
 * Smoking Wheels....  was here 2017 ngndprnpaijbpnlemoziyqbagjkdtedtolpgyibkijwvoxlx
 * Smoking Wheels....  was here 2017 twkrxiewqcilitxecyojnjzxuigxmhwjkpneztrkgtvpbppt
 * Smoking Wheels....  was here 2017 pcpcyukwbswonhkuegajvqomceifszxdxhcmyqhigfzxklno
 * Smoking Wheels....  was here 2017 xgaijokgsrmplrvrwdlqscfqxpklzcjbjltsyyqgfugkjnpq
 * Smoking Wheels....  was here 2017 sattdjovhuxzptfwmmgsiusmfrlhcsmijearjwqplsybzeik
 * Smoking Wheels....  was here 2017 lgexicpsvzditpvoplbkcwxiepsraewmuwvkywmyinnamynq
 * Smoking Wheels....  was here 2017 pcynjalhlplqznhgcjststavgxstcahfreiemqodrytslrhg
 * Smoking Wheels....  was here 2017 cywsymhdsdhandkraxjbzfmufjeyubwnlzunedphiaquqkwo
 * Smoking Wheels....  was here 2017 zldsxhncgilxxfevtzivddyjaacxykvpplyglonspajebnwa
 * Smoking Wheels....  was here 2017 plbcliwhbfwyywzxvrhxotjxvctpnkuyaxplxincxlnbaobi
 * Smoking Wheels....  was here 2017 odgqyvgckawcqkijdlcgwmyzdbpdvoniuzwjmezgzbtvbjnm
 * Smoking Wheels....  was here 2017 rvrkbgwbrhwmgjbatvwgabcmrukyltcshqenjarguvddxzos
 * Smoking Wheels....  was here 2017 bgirrgddptrpiqeuzvzkcknnkeetbawhazctwclmncxypttm
 * Smoking Wheels....  was here 2017 afsazutiemgaqhbxmmanptdknodksthoxjncsvnpsinklgxo
 * Smoking Wheels....  was here 2017 exiejbqbprvsfpgwbfxqcndtnkuctkhhzlowtyijzgtxzhax
 * Smoking Wheels....  was here 2017 jrdflozwiwzvjenkurtankymbnwgqxwkpcpnfjoyiyoeyymt
 * Smoking Wheels....  was here 2017 rfelexercujuouymztxgakfpexkneiiejngykhdraqgcjoup
 * Smoking Wheels....  was here 2017 lixkrdzownagppwiinaczqyoaupvjxfbdajdaegelwhvnsud
 * Smoking Wheels....  was here 2017 gfxwjkhxvheenxulplxpcqhwcrzjnhkuzhckasigjikuzenj
 * Smoking Wheels....  was here 2017 ygaxxehgmpispfoowdtcgarmckhnehwjfevglwcctdqrmcin
 * Smoking Wheels....  was here 2017 qbkuedknnfggjlfrnmxbpuukzxnzbzzzlvdnuvkztlejbssb
 * Smoking Wheels....  was here 2017 qnlbifiuxdymppcycpzineocamxrgshdnqxgrbmpxvpbasnt
 * Smoking Wheels....  was here 2017 nusmtqzkwrphhasymxwyroebqqzszzopnghszgusxboevuuo
 * Smoking Wheels....  was here 2017 ehcedwozwhtxtixitaqezqbgndlpurxhuopmxiymsccjhdws
 * Smoking Wheels....  was here 2017 qotjjonkptdsnhtcgvsppkysrzhxmvpmxrnhunyfofmomzhr
 * Smoking Wheels....  was here 2017 hozrqsmsbbtjiznnolszwbruiluqbvfqtzwgjhypwzexpzvf
 * Smoking Wheels....  was here 2017 skmugmlilnvvguuanimjnandxamxueomjdvplhjkjcxvgxpg
 * Smoking Wheels....  was here 2017 tmcvyjpvfqxfofijgadblawodmadgtrzdasxgmxubpsadvwb
 * Smoking Wheels....  was here 2017 mlybpahbbdsyschoambptzlezvlbdpxkpudzecncdtvjicfd
 * Smoking Wheels....  was here 2017 fejajkhdaaftpowtmvxuwccjqjamobufquavvojyabtbchle
 * Smoking Wheels....  was here 2017 puamptmkgqrmewsmllnrlvctqogrtrddhrmteowemhfmzfqf
 * Smoking Wheels....  was here 2017 lruoblbmgkpisqpmayznkxwdqevzgizeziwihctwmkgitybj
 * Smoking Wheels....  was here 2017 wmtmngmfsdtsurotngtwvfaqpgucvarnfxtiqhxkftaokvhg
 * Smoking Wheels....  was here 2017 ddivgbktpuchdaylomjnfzoqtbjzndtrwucuwqnkeudggkdm
 * Smoking Wheels....  was here 2017 yrbjpcujdswaubhczatoesrspaatpfakbpzzvwbraigxvnrd
 * Smoking Wheels....  was here 2017 aoxeevutujpabiklwmzgoattuapvpcnpbfumtwejthkdwfej
 * Smoking Wheels....  was here 2017 olymzywrgmzskrjkovmcpxmvizzxhwponvdczwuvpavwlwgs
 * Smoking Wheels....  was here 2017 vdoxbkrindcuremhpdvyrnvhkfmwsuvugtwveidrazaiuarw
 * Smoking Wheels....  was here 2017 lwiexjdzundewcgoxuxvkkyunepxcnyyjrdzgxqssztvmnmv
 * Smoking Wheels....  was here 2017 gyfjdhminfpagcoxnlvatdhdjsblbwcbelhdjpycqzzdgkau
 * Smoking Wheels....  was here 2017 iaguqxdelyftjyljuzzbuuolwtwdhvniggzaypzeagyceavh
 * Smoking Wheels....  was here 2017 aavyoetpntaazsecioztzlqcipgwvvugnkbtohzoiifymyta
 * Smoking Wheels....  was here 2017 xapqighazwftdtjqynsezqsreuswajtozqqoemjbhzlasauz
 * Smoking Wheels....  was here 2017 vmlyppxagujccqustohoqbhbbaaohikfatdzyavvverbrghk
 * Smoking Wheels....  was here 2017 xzkchxclbhdnkdnhbmbnepyibidontcmfycwgegefgeziavt
 * Smoking Wheels....  was here 2017 llysmdljklorvkvpmnrtxnsvhaiurykvjolgsjvtwqkwaxdt
 * Smoking Wheels....  was here 2017 azqnqmzflkxljticwzzkofsehnblanczqghkihbknccghsjk
 * Smoking Wheels....  was here 2017 naipklvnrtqajrvohndralkgsrdydhfxjxzvexofdshsvnuy
 * Smoking Wheels....  was here 2017 adffrqlfvgnvhciycblelcmdolnxuhdvbqekqkgpysffsqyv
 * Smoking Wheels....  was here 2017 wfpyobnjwxonxafmvsprflveadmiyxjhqxtdlfkbkojxgrqu
 * Smoking Wheels....  was here 2017 pmdoowyhyyybivyrkwlfzwsapfmiystydguhlcjoecmfxkyv
 * Smoking Wheels....  was here 2017 dfrdfpyqpyfntblfweccrcmmzlgiilivyqrlvywchhovnyfe
 * Smoking Wheels....  was here 2017 mdjxnwzhnpdksnrdpmxvkbvrdxwzuhjdqdajyzvdykwpbpxh
 * Smoking Wheels....  was here 2017 bcolpqrhqyriaizpdzngpztzhtmglmnjaescmrlfqzwtvyyx
 * Smoking Wheels....  was here 2017 jfwovdyaggbgstydizvkyikyxoqhnrmgfkxzirdfzsiskvha
 * Smoking Wheels....  was here 2017 ixfgwvbcsavialjlhfxngtemrccmopktorxmqyofbrfcmhiv
 * Smoking Wheels....  was here 2017 auqwqjkjvarzmdhojmdfufvrpjvnikocqdjmvsspacvwcqow
 * Smoking Wheels....  was here 2017 supxhsryogrwxzzqczegwyfxwpbixknugedynksyinqepnuv
 * Smoking Wheels....  was here 2017 czqefbtebaawhhcfjbwreiosyjibmebppljfrtadsrjllsdr
 */
/**
*  AbstractOrder
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 25.08.2011 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.order;
public abstract class AbstractOrder<A> implements Order<A> {
protected A zero = null;
protected boolean asc = true;
@Override
abstract public Order<A> clone();
@Override
public A zero() {
	return this.zero;
}
@Override
public void direction(final boolean ascending) {
this.asc = ascending;
}
@Override
public long partition(final A key, final int forks) {
final long d = (Long.MAX_VALUE / forks) + ((Long.MAX_VALUE % forks) + 1) / forks;
return cardinal(key) / d;
}
@Override
public void rotate(final A newzero) {
this.zero = newzero;
}
@SuppressWarnings("unchecked")
@Override
public boolean equals(final Object obj) {
        if (this == obj) return true;
        if (obj == null) return false;
        if (!(obj instanceof Order<?>)) return false;
final Order<A> other = (Order<A>) obj;
final String thisSig = signature();
final String otherSig = other.signature();
        if ((thisSig == null) || (otherSig == null)) return false;
return thisSig.equals(otherSig);
}
@Override
public int hashCode() {
return signature().hashCode();
}
public A smallest(final A a, final A b) {
return (compare(a, b) > 0) ? b : a;
}
public A largest(final A a, final A b) {
return (compare(a, b) > 0) ? a : b;
}
}
