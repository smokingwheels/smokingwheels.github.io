/** 
 * Smoking Wheels....  was here 2017 enyjiqgopopwobrpoeddauzjtaeovpkhmmjylvadifcmlweq
 * Smoking Wheels....  was here 2017 cjsqtxvpqtaomsjkncbzptvpsanwwhytxsbusahvwucnhsvr
 * Smoking Wheels....  was here 2017 eneofnbgsyokhkvdtijoebidobgplevyakbtevmsgtbklesl
 * Smoking Wheels....  was here 2017 lqsgixlbaltftgryorrhqlgrqtgtlpafirglaepvexbneuaq
 * Smoking Wheels....  was here 2017 dqcgzuttyslbuotenjawcwphpuoqddogszxxoixknhliylbc
 * Smoking Wheels....  was here 2017 xqgdgeaifpsfqzhlktogxnqflgmwaqxvezlfktwxncurleny
 * Smoking Wheels....  was here 2017 lajxmhmzsbxguhpqfntpqwwxhjqeufrezmowkchdnzxqrign
 * Smoking Wheels....  was here 2017 wnwtinrhqloaaqjwingjfqbdosvrketostenrkecgpvmxolm
 * Smoking Wheels....  was here 2017 kznbpqjyifnngilnfzcfqugwybdredgrddocowtzpbyuoqks
 * Smoking Wheels....  was here 2017 rofnlonynfvbsyzfrgkbjorkikvsnxpjhgcvryphtpukkrwi
 * Smoking Wheels....  was here 2017 kqeceolodkwgxijuvzrdyjvfwbopeoktncndwikvbtfikaqq
 * Smoking Wheels....  was here 2017 qyvykcqgicewppfkwcpwhzmaandkdnofhsuqhzgnhhgxugwj
 * Smoking Wheels....  was here 2017 shynavvvmvozsblljtcxkiswlppkqhejlpcjfejqhhgrbfzh
 * Smoking Wheels....  was here 2017 dxjmcucfhicwmiemeiketqrybhhfdtsbajwlhigshyvlxzpo
 * Smoking Wheels....  was here 2017 tdjuadqrrredkgukgnyxwjyuaxupjztlixuhkerlqwshjyop
 * Smoking Wheels....  was here 2017 nqjpjkztvdhofwyiyelnqfhdtxxqiiexwjwqprrvaubnpqcy
 * Smoking Wheels....  was here 2017 vjcjzfxedgifxonrumurdeszyespgkealfgkhamdkserexnn
 * Smoking Wheels....  was here 2017 dkmuzplwgthjrxqzouhiumlolqocqzbsdakuaspwxzqotwll
 * Smoking Wheels....  was here 2017 gfsuttuedroqausehvhqcoaknqaxdfnbesberlutybfhivwb
 * Smoking Wheels....  was here 2017 hkgnwennxisvrfjjimncadffnqxculkkelcgkeduftbcdlva
 * Smoking Wheels....  was here 2017 lxulfnjsagoyqolyewyipdazcmgzvfxlwquamdugqcloqmsf
 * Smoking Wheels....  was here 2017 iwgfwuiseddibldmpjugfwragelcsjjaiynpoujpjjznqbgr
 * Smoking Wheels....  was here 2017 sqxueestfdvnnrvxssldlsttbzbhfakgvgbknwoouclaanfw
 * Smoking Wheels....  was here 2017 qyekteziikejrjdhttqielzzalwpgnzmyshfkhjepayjblvj
 * Smoking Wheels....  was here 2017 krskmlygyoayovyahqhonyjrtiyiclejlslwphdrtfvcgrkb
 * Smoking Wheels....  was here 2017 nynmkaoktikmkrkscvqtuneberrafpjtkyzqsjhojxpaiiqb
 * Smoking Wheels....  was here 2017 vftqzccdrtroqsxhfxdbqpyrltpnidfubhowpfqowrdgfrks
 * Smoking Wheels....  was here 2017 jbxzscdxvdkaabbuyumzwxjfabovljpvzwehjtesyhnbfkvr
 * Smoking Wheels....  was here 2017 jlqamujmqzlynbuqwqodqjntoloiuwrnydaujgefntaztgiv
 * Smoking Wheels....  was here 2017 lmyjldvuvavokiflswrnhgrlywaovmvrbsmqfdeosjhwojmh
 * Smoking Wheels....  was here 2017 jqzzxhtdgjwmcqrcocegkygvkqlhhhrmoniftewnzqbtrcfj
 * Smoking Wheels....  was here 2017 emfbnusadgemkcxrshvuvgdrhhsperchzsnebhhczimyhaqt
 * Smoking Wheels....  was here 2017 dyibbikevfprfcsprnovtcgyiovurfgrdrenostornwawyeh
 * Smoking Wheels....  was here 2017 wfhpsvwoczdiveglhgoikswxknfmhsmobbvjuxsidltudald
 * Smoking Wheels....  was here 2017 bqiquokmtreaseycodhknnnbrlijuhnacudfqoyfwqzhdnip
 * Smoking Wheels....  was here 2017 vxvkxylkangopfjrualnvhzcpvcpchdmszasfrmemwqvacyi
 * Smoking Wheels....  was here 2017 myngxsvbiafykplpmczkoygbulnmmgoosbttwmomyfayinsf
 * Smoking Wheels....  was here 2017 mvjyxwmmhzdolyiknubxzspfgjznkcdcfrspfjrqkxsntyhi
 * Smoking Wheels....  was here 2017 raoihotxwliyebjawrfhscmabwaopwmfktqqcdqjgmpoisnc
 * Smoking Wheels....  was here 2017 denrqidugqjxicgowtbyqtsfqllqbwnhxkmoprlqesrjfjnd
 * Smoking Wheels....  was here 2017 bezjuuiyudbmwiukaconvqivtwjcztkymblhcgiucqhnytth
 * Smoking Wheels....  was here 2017 cdwcwakhfsnzakededzbrancfeclwimbejybfivffnavfzur
 * Smoking Wheels....  was here 2017 znkvfdqdkkbahcuqiorqtjwnfrfomsjthfrfupssxxriajnr
 * Smoking Wheels....  was here 2017 tzaslrmznlgijogbtfktyibvfwoktfajjuqnyaygvnjjpodx
 * Smoking Wheels....  was here 2017 tjlelhsnajxahcltbhdbiyeawodkxlnoelawzvwdxmklkizh
 * Smoking Wheels....  was here 2017 lwoxgzjtozcjgioizdzmgjmibsiamfgfuwfmomxujailfurw
 * Smoking Wheels....  was here 2017 rwqvhzszaieytaxrpmmfjckhzqscdqxklyztnswaoqzjyhdb
 * Smoking Wheels....  was here 2017 nbcecsgrqprpnjexfehsnvuqbxcsybinuvgjzltuedmoxlnl
 * Smoking Wheels....  was here 2017 ehqjpxsoullimpfkhjjquopiygodabqfnxfghywidocnmaez
 * Smoking Wheels....  was here 2017 htfawodqcnolykeusmxynmdqorkzylghswiqaqqepdldmesr
 * Smoking Wheels....  was here 2017 owaegvueoyjoiomxnejujbxcbngzkjvyrphxbfxbzlhkwfcz
 * Smoking Wheels....  was here 2017 cfnxjgfqiyjklfsxxilpdzpkxgwgjdfmyhaunsqyygtrwtkm
 * Smoking Wheels....  was here 2017 etjsbmcuubmcequdndbcyhiosrkccjoohguesicdloemypbc
 * Smoking Wheels....  was here 2017 ipohlmmqqbsyulwgdylfechulwcbavfbtfzghmvbqrbqwwrw
 * Smoking Wheels....  was here 2017 jegnwnqltaknvmgbtlbbkzbrfaoyyrxbraimcxooxdhfoxdf
 * Smoking Wheels....  was here 2017 hdzpyzbqiddoxwrtsnoenohwmrqvuglzoxtogpinyqynhhou
 * Smoking Wheels....  was here 2017 mkizoroavasecxzrmiyepvckyrjzvczkffmjbsjgrhibovkj
 * Smoking Wheels....  was here 2017 jcijtmcovjgrpehlygjzzasolzcamcxgrpzceueggjztaqge
 * Smoking Wheels....  was here 2017 vpdrxrynihapxnzxczhvipqtfxksohwpgywglmogcjuntczn
 * Smoking Wheels....  was here 2017 wqgaqsqklaqusctfgkldlhpupycdzcsullelyungxbuuxstb
 * Smoking Wheels....  was here 2017 ubhyuhxypbygadmtyrtolarrjxhpzarnbncpbyimnmibakyp
 * Smoking Wheels....  was here 2017 dahbmjudmfyicifcyekcszcqjvgqbzapftaykimlfyydtffi
 * Smoking Wheels....  was here 2017 sxkicenfanapjlleipwvvsjdtyobzzmfccrxutsxixncenlq
 * Smoking Wheels....  was here 2017 okcyedpsjgsvoqtbjuwhqxhyzubzqlwrhrbejcbwnfbglwsb
 * Smoking Wheels....  was here 2017 xlahpbwixxwbsebdqyhcgnuctevqixjppxhqlqunuwyecdmn
 * Smoking Wheels....  was here 2017 kcfdmvgcjiorarlawmifbtfuxcfqnfjxbmwnsvlkfdsqvjid
 * Smoking Wheels....  was here 2017 tvuierbgplcfyzjpeznuqbbnqwttymmszfngxkshhoerpyfh
 * Smoking Wheels....  was here 2017 bggbhbuhvqbkgfkaulmiwfbbkygboapiwicmggqcqxmrrleo
 * Smoking Wheels....  was here 2017 phhvrseymjhkwrlphxflucgkvfvwqlwlofxfarneefweossw
 * Smoking Wheels....  was here 2017 wcvgkphfelvmcyrylwxdvawuvputpprxbmiovbvxbtzxxvjh
 * Smoking Wheels....  was here 2017 tcbixyijvwbfkxmziyznojkspksmgoqvrcbzpfidtapatdbg
 * Smoking Wheels....  was here 2017 fwmetewwrxmjlqlvfadbwxsxofkdmqqoydceiaauxwuuifyi
 * Smoking Wheels....  was here 2017 oktgtbpmbdyahllvrhjluosjitybplwurcqbmsfdlgyudxjj
 * Smoking Wheels....  was here 2017 juwhcnpfrinmdyspldvptosjxastbwriwobvoujrmmouviao
 * Smoking Wheels....  was here 2017 jmzdbtchlloilznbqearikfkjjebpxrhxldxnxhencmwlutg
 * Smoking Wheels....  was here 2017 rbnahhqgovqjzppgmjoektzefhgzezucfxuzkcypevujexsb
 * Smoking Wheels....  was here 2017 omgjquxtjzoqsfuqowmtapzsbozyaqdjrigypnqfjtvuonhv
 * Smoking Wheels....  was here 2017 oxcwfgzwqsjlwjgtqzxipdohwesjqtdxikxbrswmgddzhrcs
 * Smoking Wheels....  was here 2017 lsgmjwdvfzljxxiotmjcswejtmzetjjxkamsmhjehmpzjtac
 * Smoking Wheels....  was here 2017 hodircvdgdjepxrbgfmmfnprdypjivtsmiypehehcofdzign
 * Smoking Wheels....  was here 2017 jinxarvmgrxzwsftqigefzvgtjsgptlxksmqcxocqliyqfdz
 * Smoking Wheels....  was here 2017 fehvooeyujdbayaesfwcbndhluokbzulcvnbvpabbkogbohm
 * Smoking Wheels....  was here 2017 roqcozdsvglzmlofnptmkpbjkluqlpljzpvfgbixuxrcgrql
 * Smoking Wheels....  was here 2017 tbcwqkehopjozgkzihqrbxidcyeztyhcndgwlimrmvtvldhn
 * Smoking Wheels....  was here 2017 sqgosmcljyswntlxsmmlclzqdyvudomfnxcwtntpccezcvrn
 * Smoking Wheels....  was here 2017 dkdxwgxexboejmwomolrylfdlpbodjkqantmvfqdsbmixukp
 * Smoking Wheels....  was here 2017 vtyukxwrdyhaxjzvqfzpehqdeckemkrlixxdnaxcvfmzyjid
 * Smoking Wheels....  was here 2017 ukckzxmmeykhyknumivortyhuzspdafbzenlxyolcigfieqt
 * Smoking Wheels....  was here 2017 jehelymjmntzlahwobximuesybcgjvcautvkifxkkmdqqash
 * Smoking Wheels....  was here 2017 ahmvwaygsmklqslrqtkuzpopojwppqthuhgelhknywrzobdw
 * Smoking Wheels....  was here 2017 qcwgricmuwsfzkkcveuevrqktcononvxgrmebwvmdctjcoww
 * Smoking Wheels....  was here 2017 fgxqkjllwyfcfdufjctwuseyaxzahweiscmdixfiqwjcldzy
 * Smoking Wheels....  was here 2017 ashlxvtzjftdjhlkvugobsdezlhkzgycaymyoruijhxrcqxy
 * Smoking Wheels....  was here 2017 rozijqbazlkrpkoizpmfyvwjovthdnncdvwvjocxmoyzudhz
 * Smoking Wheels....  was here 2017 wgdgbbowptmgkinuxdxzbouzxhzkmspmlsieqjwvlhgamzzl
 * Smoking Wheels....  was here 2017 slhjqovyjioroeyzvjeigqtumjtxygzqksxslzddweydlucx
 * Smoking Wheels....  was here 2017 nzbdyvqbusmaahsgjlhxpzruyvdavqvdwgsieqebshiwdich
 * Smoking Wheels....  was here 2017 tbkfbwyelrhpzgyegtlrnvxfftniounwwygfkvlbdxzahuos
 * Smoking Wheels....  was here 2017 hbpnjvaohijyzxcspybupqxokilrxstyrsfvaguxnosrxkkn
 * Smoking Wheels....  was here 2017 cqzimfksmvfwshswpxwsrelpzesbwvjtwtnwbxdpozqcdwtj
 * Smoking Wheels....  was here 2017 nsizftwjlurldvudwuucwinhqzkvpsmxekjfyxukfgbxoyzc
 * Smoking Wheels....  was here 2017 cloetkjmvywzobjbfabxnjlxfwwnqemhsigbhvgtoqoxwttv
 * Smoking Wheels....  was here 2017 pfxwijfjpicakvwnpgbhgsryzarzrhbzsmvxxihlcrxcapyy
 * Smoking Wheels....  was here 2017 crtgrcxnxgxjkfyqkjotxczdgbqftlbktybjxkymmcguhdrb
 * Smoking Wheels....  was here 2017 vswsojfpdedcoplvdomwpnkltrvobfqeqedjqfkbpyxqdeib
 * Smoking Wheels....  was here 2017 kndzdbdsyywnbnnroearrefekyppbledjunethfspnkigtpb
 * Smoking Wheels....  was here 2017 pmvzslxaiokflwpatxqhtmwvjdmcnehkhsydbieeyipzrhhk
 * Smoking Wheels....  was here 2017 lfixyzcbjhjyksgazpaerfecatidkuwkxbhzrggmieoypjpt
 * Smoking Wheels....  was here 2017 frkdrjkpornuyjlbvmdaoidacpeayxcsahupzitvpbpsotxy
 * Smoking Wheels....  was here 2017 maylzoxonmzbglftbxdttazvlskipiheraxfozdsyhhcfpud
 * Smoking Wheels....  was here 2017 apdrguvgetbhwubytonnvtgzijoudddzeehhgyexvjmeogfr
 * Smoking Wheels....  was here 2017 wcmabosestjimnnudizusgshbblonrnlawyleexjwbggwghe
 * Smoking Wheels....  was here 2017 jkrzhnganzqfcxnquilglmjsjoexannfbobpsypkzkwxpmkn
 * Smoking Wheels....  was here 2017 zrqfaqnvhhbgxofcnadvlqmndybkapqdivbalqsmjszymaev
 * Smoking Wheels....  was here 2017 pippretvxqvakjybibmsgfoepmqviwkjcqrcfzbilljjlenm
 * Smoking Wheels....  was here 2017 ezzktpmnpiqhjjkroheiuxjlcrugxushxcvmezqywlcovpnc
 * Smoking Wheels....  was here 2017 bpmzfolrsxgesxlgtwfjcsxiihpaawtmoqsepvrpnsnaabqn
 * Smoking Wheels....  was here 2017 tgbcbcrfzctxsqelqgttoumbgkhqbzxucxuhezstqmepuslx
 * Smoking Wheels....  was here 2017 ckxptjkmhzmdvhbchbgrurndygoyvfukuvuisenfpjyicwwq
 * Smoking Wheels....  was here 2017 csntuwexvuzpubrkbfknqzwixjdzhwhrgmqxjjdxbcwnfdag
 * Smoking Wheels....  was here 2017 banxdhtgyccjpfxrkvebeunpundbsqnfejnakttcyrgtohhs
 * Smoking Wheels....  was here 2017 nnxvvpdnkrwumjyneitevgseluxtmgxwsbwunvxillsvxnjc
 * Smoking Wheels....  was here 2017 gpwkfbozbnrjwjdvjkobdvyqdkzvkvbvbmlsnhjhzwaufbbv
 * Smoking Wheels....  was here 2017 jywuycobcxbyohctiwjdzgaqfxflltxjuvdknceafthytpnl
 * Smoking Wheels....  was here 2017 clonvkxpykwpmmtqoybdmmxgkbquvooftlewwmosadvwzxev
 * Smoking Wheels....  was here 2017 zfyeazqmgueoxnfcwawxzsxrowpmadjdxzzgewaxphgjpcre
 * Smoking Wheels....  was here 2017 wrfswbybzagmhhxzhtfsclnkxrsiunaipkiaibiikshmpnvu
 * Smoking Wheels....  was here 2017 smujxbjtflsdjvkmdavyqknevzskbcjdjubujxnabfdogtvi
 * Smoking Wheels....  was here 2017 xojncrsjlokocnrxyaqhtmwbzouzdlpezpmossvdmuacaqaq
 * Smoking Wheels....  was here 2017 ybywlyyvidjbuxtxmcwrvzwfileplkaimmymyxuhvtozpgcw
 * Smoking Wheels....  was here 2017 pjrikbimtfxgvwdivxyijhbezwldsbjsfhfzxfecopofzyyj
 * Smoking Wheels....  was here 2017 ycadmmjsxcqwzljigkoqiedrklmqyslsqfftspyriddcliqs
 * Smoking Wheels....  was here 2017 hfsrpwwjfgkagakghsrhtpdtgwiijakxqqdtsgjebkogkfpw
 * Smoking Wheels....  was here 2017 dvqqwhujinfavfistgngatiplehwluqfegldnraexpkkqslx
 * Smoking Wheels....  was here 2017 hjazpwlzewljfuopsqmqtdgtdszaycvspxwjanpigjorcecf
 * Smoking Wheels....  was here 2017 umiwkchsyqqyewtakuhzukpxtyfwviuvkuhcgvdsvjajbdsj
 * Smoking Wheels....  was here 2017 ycgtesdhahptpvsjjwxxfolczrarhasdliygquxonseaylph
 * Smoking Wheels....  was here 2017 hhthzrytbrmdvergmhnikvaosxuawbznschbswkinqolnglb
 * Smoking Wheels....  was here 2017 qnalefaiatorgwzorqpmzrwvdybsgnfcnaaxktkufrartwdc
 * Smoking Wheels....  was here 2017 zlmjkswmavjcqwgjixutttrpqhrwlshgkibnulxxhppbwvua
 * Smoking Wheels....  was here 2017 ryvmmzgzokunzpkcyecwxdowxtrrrgipeiquedezqlreibvq
 * Smoking Wheels....  was here 2017 febnoyeufixgmqoiixrsrysxwikukyuawseyghsnmnttypvc
 * Smoking Wheels....  was here 2017 knjkyuwgzoavqucynsanurqerhlajyfptkkkvrieeisyputv
 * Smoking Wheels....  was here 2017 hrehgbxtykrbeeqbvmurabdmufpjoootjmhuaeyalppzpgrj
 * Smoking Wheels....  was here 2017 eneqjkzcpjsacddctlyxnaftuvydfjybolydeaxhdltljuzq
 * Smoking Wheels....  was here 2017 pfidiuegpggapgrpdxsdqvchrevzuftkjxxowsslmbsernjt
 * Smoking Wheels....  was here 2017 idvrplsmubopejqmzomoyxjopovpafqyasvnaychxajemtrc
 * Smoking Wheels....  was here 2017 lzemrwcilcgpooswpiaoizsixltcxrlaccrrssbuadsvacbg
 * Smoking Wheels....  was here 2017 fpzzmsclxxcasesdoigvwaeojrqvrfjgklqahexeujeqtkwc
 * Smoking Wheels....  was here 2017 fehvcztwxfggxuvwpajjzganwgwguqsnyjerivdyjzfkltuu
 * Smoking Wheels....  was here 2017 edfzxwgwhbzuohkzuzuhectsolagabfybuzbtkmwdptfclsr
 * Smoking Wheels....  was here 2017 fbgqlwfxgswlmsdoldhbkidwvuwwhurwhwayqvzyvxujwdsj
 * Smoking Wheels....  was here 2017 oxcfqrisgtsholwzbrtjswfakbnkwmgykamehjxjizrkhqft
 * Smoking Wheels....  was here 2017 uvrkogpjxxrrcbtxmzkdlyejehhlfxjbkwuzklssubafbawy
 * Smoking Wheels....  was here 2017 sffcpviaefzcojddsrrngapkitstbeqhrjruttgrqspteroh
 * Smoking Wheels....  was here 2017 isdniwagezgjrmswbshzzvexgyskkrzaspbgnilfosnjxckm
 * Smoking Wheels....  was here 2017 yfedpbktiripltjkbeegthawqshslylxhzejziqrmbbprguh
 * Smoking Wheels....  was here 2017 dxgonknnjdgaaseknooewrhnkatgsuntmflhuggmnavifdiy
 * Smoking Wheels....  was here 2017 qdptlcqvejihzhptmlwzykpjretvxkttpdpkuudkeernoczt
 * Smoking Wheels....  was here 2017 oqpxapfdwqedznfnftucwfpdyralzacfcyolcxflahqnwuvi
 */
package net.yacy.search.index;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrInputDocument;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.federate.solr.connector.AbstractSolrConnector;
import net.yacy.cora.federate.solr.connector.SolrConnector;
import net.yacy.cora.federate.yacy.CacheStrategy;
import net.yacy.cora.order.Base64Order;
import net.yacy.cora.order.ByteOrder;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.ResponseHeader;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ByteBuffer;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.LookAheadIterator;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.crawler.data.CrawlProfile;
import net.yacy.crawler.data.Transactions;
import net.yacy.crawler.retrieval.Response;
import net.yacy.document.Condenser;
import net.yacy.document.Document;
import net.yacy.document.Parser;
import net.yacy.document.parser.htmlParser;
import net.yacy.kelondro.data.citation.CitationReference;
import net.yacy.kelondro.data.citation.CitationReferenceFactory;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.data.word.WordReference;
import net.yacy.kelondro.data.word.WordReferenceFactory;
import net.yacy.kelondro.data.word.WordReferenceRow;
import net.yacy.kelondro.index.RowHandleSet;
import net.yacy.kelondro.rwi.IODispatcher;
import net.yacy.kelondro.rwi.IndexCell;
import net.yacy.kelondro.rwi.ReferenceContainer;
import net.yacy.kelondro.rwi.ReferenceFactory;
import net.yacy.kelondro.table.IndexTable;
import net.yacy.kelondro.util.Bitfield;
import net.yacy.kelondro.util.ISO639;
import net.yacy.kelondro.util.MemoryControl;
import net.yacy.repository.LoaderDispatcher;
import net.yacy.search.query.SearchEvent;
import net.yacy.search.schema.CollectionConfiguration;
import net.yacy.search.schema.CollectionSchema;
import net.yacy.search.schema.WebgraphConfiguration;
import net.yacy.search.schema.WebgraphSchema;
public class Segment {
public final static String catchallString = "yacyall";
public final static byte[] catchallHash;
final static Word   catchallWord = new Word(0, 0, 0);
static {
catchallHash = Word.word2hash(catchallString);
catchallWord.flags = new Bitfield(4);
for (int i = 0; i < catchallWord.flags.length(); i++) catchallWord.flags.set(i, true);
}
public static final long wCacheMaxAge    = 1000 * 60 * 30;
public static final int  wCacheMaxChunk  =  800;         
public static final int  lowcachedivisor =  900;
public static final long targetFileSize  = 64 * 1024 * 1024;
public static final int  writeBufferSize = 4 * 1024 * 1024;
public static final String termIndexName = "text.index";
public static final String citationIndexName = "citation.index";
public static final String firstseenIndexName = "firstseen.index";
public static final ReferenceFactory<WordReference> wordReferenceFactory = new WordReferenceFactory();
public static final ReferenceFactory<CitationReference> citationReferenceFactory = new CitationReferenceFactory();
public static final ByteOrder wordOrder = Base64Order.enhancedCoder;
private   final ConcurrentLog                  log;
private   final File                           segmentPath;
protected final Fulltext                       fulltext;
protected       IndexCell<WordReference>       termIndex;
protected       IndexCell<CitationReference>   urlCitationIndex;
protected       IndexTable                     firstSeenIndex;
protected       IODispatcher                   merger = null;
/**
* create a new Segment
* @param log logger instance
* @param segmentPath that should be the path pointing to the directory "SEGMENT"
* @throws IOException when an error occurs
*/
public Segment(final ConcurrentLog log, final File segmentPath, final File archivePath,
final CollectionConfiguration collectionConfiguration, final WebgraphConfiguration webgraphConfiguration) throws IOException {
log.info("Initializing Segment '" + segmentPath + ".");
this.log = log;
this.segmentPath = segmentPath;
archivePath.mkdirs();
this.fulltext = new Fulltext(segmentPath, archivePath, collectionConfiguration, webgraphConfiguration);
this.termIndex = null;
this.urlCitationIndex = null;
this.firstSeenIndex = new IndexTable(new File(segmentPath, firstseenIndexName), 12, 8, false, false);
}
public boolean connectedRWI() {
return this.termIndex != null;
}
public void connectRWI(final int entityCacheMaxSize, final long maxFileSize) throws IOException {
        if (this.termIndex != null) return;
        if (this.merger == null) { // init shared iodispatcher if none running
this.merger = new IODispatcher(2, 2, writeBufferSize);
this.merger.start();
}
this.termIndex = new IndexCell<WordReference>(
new File(this.segmentPath, "default"),
termIndexName,
wordReferenceFactory,
wordOrder,
Word.commonHashLength,
entityCacheMaxSize,
targetFileSize,
maxFileSize,
writeBufferSize,
merger);
}
public void disconnectRWI() {
        if (this.termIndex == null) return;
this.termIndex.close();
this.termIndex = null;
}
public boolean connectedCitation() {
return this.urlCitationIndex != null;
}
public void connectCitation(final int entityCacheMaxSize, final long maxFileSize) throws IOException {
        if (this.urlCitationIndex != null) return;
        if (this.merger == null) { // init shared iodispatcher if none running
this.merger = new IODispatcher(2,2,writeBufferSize);
this.merger.start();
}
this.urlCitationIndex = new IndexCell<CitationReference>(
new File(this.segmentPath, "default"),
citationIndexName,
citationReferenceFactory,
wordOrder,
Word.commonHashLength,
entityCacheMaxSize,
targetFileSize,
maxFileSize,
writeBufferSize,
merger);
}
public void disconnectCitation() {
        if (this.urlCitationIndex == null) return;
this.urlCitationIndex.close();
this.urlCitationIndex = null;
}
public int citationCount() {
return this.urlCitationIndex == null ? 0 : this.urlCitationIndex.sizesMax();
}
public long citationSegmentCount() {
return this.urlCitationIndex == null ? 0 : this.urlCitationIndex.getSegmentCount();
}
public Fulltext fulltext() {
return this.fulltext;
}
public IndexCell<WordReference> termIndex() {
return this.termIndex;
}
public IndexCell<CitationReference> urlCitation() {
return this.urlCitationIndex;
}
public IndexTable firstSeen() {
return this.firstSeenIndex;
}
public ReferenceReportCache getReferenceReportCache()  {
return new ReferenceReportCache();
}
public class ReferenceReportCache {
private final Map<String, ReferenceReport> cache;
public ReferenceReportCache() {
this.cache = new ConcurrentHashMap<String, ReferenceReport>();
}
public ReferenceReport getReferenceReport(final String id, final boolean acceptSelfReference) throws IOException {
ReferenceReport rr = cache.get(id);
if (MemoryControl.shortStatus()) cache.clear();
if (rr != null) return rr;
try {
rr = new ReferenceReport(ASCII.getBytes(id), acceptSelfReference);
cache.put(id, rr);
return rr;
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
throw new IOException(e.getMessage());
}
}
}
/**
* A ReferenceReport object is a container for all references to a specific url.
* The class stores the number of links from domain-internal and domain-external backlinks,
* and the host hashes of all externally linking documents,
* all IDs from external hosts and all IDs from the same domain.
*/
public final class ReferenceReport {
private int internal, external;
private HandleSet externalHosts, externalIDs, internalIDs;
public ReferenceReport(final byte[] id, final boolean acceptSelfReference) throws IOException, SpaceExceededException {
this.internal = 0;
this.external = 0;
this.externalHosts = new RowHandleSet(6, Base64Order.enhancedCoder, 0);
this.internalIDs = new RowHandleSet(Word.commonHashLength, Base64Order.enhancedCoder, 0);
this.externalIDs = new RowHandleSet(Word.commonHashLength, Base64Order.enhancedCoder, 0);
if (connectedCitation()) try {
ReferenceContainer<CitationReference> references;
references = urlCitation().get(id, null);
if (references == null) return;
Iterator<CitationReference> ri = references.entries();
while (ri.hasNext()) {
CitationReference ref = ri.next();
byte[] hh = ref.hosthash();
if (ByteBuffer.equals(hh, 0, id, 6, 6)) {
internalIDs.put(ref.urlhash());
internal++;
} else {
externalHosts.put(hh);
externalIDs.put(ref.urlhash());
external++;
}
}
} catch (SpaceExceededException e) {
if (Segment.this.fulltext.useWebgraph()) internalIDs.clear();
}
if ((internalIDs.size() == 0 || !connectedCitation()) && Segment.this.fulltext.useWebgraph()) {
SolrConnector webgraph = Segment.this.fulltext.getWebgraphConnector();
BlockingQueue<SolrDocument> docs = webgraph.concurrentDocumentsByQuery("{!cache=false raw f=" + WebgraphSchema.target_id_s.getSolrFieldName() + "}" + ASCII.String(id), WebgraphSchema.source_chars_i.getSolrFieldName() + " asc", 0, 10000000, Long.MAX_VALUE, 100, 1, false, WebgraphSchema.source_id_s.getSolrFieldName());
SolrDocument doc;
try {
while ((doc = docs.take()) != AbstractSolrConnector.POISON_DOCUMENT) {
if (MemoryControl.shortStatus()) break;
String refid = (String) doc.getFieldValue(WebgraphSchema.source_id_s.getSolrFieldName());
if (refid == null) continue;
byte[] refidh = ASCII.getBytes(refid);
byte[] hh = new byte[6];
System.arraycopy(refidh, 6, hh, 0, 6);
if (ByteBuffer.equals(hh, 0, id, 6, 6)) {
if (acceptSelfReference || !ByteBuffer.equals(refidh, id)) {
internalIDs.put(refidh);
internal++;
}
} else {
externalHosts.put(hh);
externalIDs.put(refidh);
external++;
}
}
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
}
}
this.externalHosts.optimize();
this.internalIDs.optimize();
this.externalIDs.optimize();
}
public int getInternalCount() {
return this.internal;
}
public int getExternalCount() {
return this.external;
}
public HandleSet getExternalHostIDs() {
return this.externalHosts;
}
public HandleSet getExternalIDs() {
return this.externalIDs;
}
public HandleSet getInternallIDs() {
return this.internalIDs;
}
}
public long RWICount() {
        if (this.termIndex == null) return 0;
return this.termIndex.sizesMax();
}
public long RWISegmentCount() {
        if (this.termIndex == null) return 0;
return this.termIndex.getSegmentCount();
}
public int RWIBufferCount() {
        if (this.termIndex == null) return 0;
return this.termIndex.getBufferSize();
}
/**
* get a guess about the word count. This is only a guess because it uses the term index if present and this index may be
* influenced by index transmission processes in its statistic word distribution. However, it can be a hint for heuristics
* which use the word count. Please do NOT use this if the termIndex is not present because it otherwise uses the solr index
* which makes it painfully slow.
* @param word
* @return the number of references for this word.
*/
public int getWordCountGuess(String word) {
        if (word == null || word.indexOf(':') >= 0 || word.indexOf(' ') >= 0 || word.indexOf('/') >= 0 || word.indexOf('\"') >= 0) return 0;
        if (this.termIndex != null) {
int count = this.termIndex.count(Word.word2hash(word));
return count;
}
        if (this.fulltext.getDefaultConnector() == null) return 0;
try {
return (int) this.fulltext.getDefaultConnector().getCountByQuery(CollectionSchema.text_t.getSolrFieldName() + ":\"" + word + "\"");
} catch (final Throwable e) {
ConcurrentLog.warn("Segment", "problem with word guess for word: " + word);
ConcurrentLog.logException(e);
return 0;
}
}
public void setFirstSeenTime(final byte[] urlhash, long time) {
        if (urlhash == null || time <= 0) return;
try {
if (this.firstSeenIndex.has(urlhash)) return;
this.firstSeenIndex.put(urlhash, time);
} catch (IOException e) {
ConcurrentLog.logException(e);
}
}
public long getFirstSeenTime(final byte[] urlhash) {
        if (urlhash == null) return -1;
try {
return this.firstSeenIndex.get(urlhash);
} catch (IOException e) {
ConcurrentLog.logException(e);
return -1;
}
}
/**
* get the load time of a resource.
* @param urlhash the resource hash
* @return the time in milliseconds since epoch for the load time or -1 if the document does not exist
*/
public long getLoadTime(final String urlhash) throws IOException {
return this.fulltext.getLoadTime(urlhash);
}
/**
* discover all urls that start with a given url stub
* @param stub
* @return an iterator for all matching urls
*/
public Iterator<DigestURL> urlSelector(final MultiProtocolURL stub, final long maxtime, final int maxcount) {
final BlockingQueue<SolrDocument> docQueue;
final String urlstub;
        if (stub == null) {
docQueue = this.fulltext.getDefaultConnector().concurrentDocumentsByQuery(AbstractSolrConnector.CATCHALL_QUERY, CollectionSchema.url_chars_i.getSolrFieldName() + " asc", 0, Integer.MAX_VALUE, maxtime, maxcount, 1, false, CollectionSchema.id.getSolrFieldName(), CollectionSchema.sku.getSolrFieldName());
urlstub = null;
} else {
final String host = stub.getHost();
String hh = null;
try {
hh = DigestURL.hosthash(host, stub.getPort());
} catch (MalformedURLException e) {
ConcurrentLog.logException(e);
}
docQueue = hh == null ? new ArrayBlockingQueue<SolrDocument>(0) : this.fulltext.getDefaultConnector().concurrentDocumentsByQuery(CollectionSchema.host_id_s + ":\"" + hh + "\"", CollectionSchema.url_chars_i.getSolrFieldName() + " asc", 0, Integer.MAX_VALUE, maxtime, maxcount, 1, false, CollectionSchema.id.getSolrFieldName(), CollectionSchema.sku.getSolrFieldName());
urlstub = stub.toNormalform(true);
}
return new LookAheadIterator<DigestURL>() {
@Override
protected DigestURL next0() {
while (true) {
SolrDocument doc;
try {
doc = docQueue.take();
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
return null;
}
if (doc == null || doc == AbstractSolrConnector.POISON_DOCUMENT) return null;
String u = (String) doc.getFieldValue(CollectionSchema.sku.getSolrFieldName());
String id =  (String) doc.getFieldValue(CollectionSchema.id.getSolrFieldName());
DigestURL url;
try {
url = new DigestURL(u, ASCII.getBytes(id));
} catch (final MalformedURLException e) {
continue;
}
if (urlstub == null || u.startsWith(urlstub)) return url;
}
}
};
}
public void clear() {
try {
if (this.termIndex != null) this.termIndex.clear();
if (this.fulltext != null) this.fulltext.clearLocalSolr();
if (this.fulltext != null) this.fulltext.clearRemoteSolr();
if (this.urlCitationIndex != null) this.urlCitationIndex.clear();
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
public void clearCaches() {
        if (this.urlCitationIndex != null) this.urlCitationIndex.clearCache();
        if (this.termIndex != null) this.termIndex.clearCache();
this.fulltext.clearCaches();
}
public File getLocation() {
return this.segmentPath;
}
public synchronized void close() {
	if (this.termIndex != null) this.termIndex.close();
        if (this.fulltext != null) this.fulltext.close();
        if (this.urlCitationIndex != null) this.urlCitationIndex.close();
        if (this.firstSeenIndex != null) this.firstSeenIndex.close();
        if (this.merger != null) {
this.merger.terminate();
this.merger = null;
}
}
private static String votedLanguage(
final DigestURL url,
final String urlNormalform,
final Document document,
final Condenser condenser) {
String language = condenser.language();
final String bymetadata = document.dc_language();
        if (language == null) {
language = (bymetadata == null) ? url.language() : bymetadata;
} else {
if (bymetadata == null) {
if (condenser.languageProbability() < 0.9) {
if (!language.equals(url.language())) {
final String u = urlNormalform.toLowerCase(Locale.ROOT);
String ISO639_country = ISO639.country(language);
if (u.contains("/" + language + "/") ||
(ISO639_country != null && u.contains("/" + ISO639.country(language).toLowerCase(Locale.ROOT) + "/"))) {
} else {
language = url.language();
}
}
}
} else {
if (language.equals(bymetadata)) {
} else if (language.equals(url.language())) {
} else if (bymetadata.equals(url.language())) {
language = bymetadata;
} else {
language = bymetadata;
}
}
}
return language;
}
public void storeRWI(final ReferenceContainer<WordReference> wordContainer) throws IOException, SpaceExceededException {
        if (this.termIndex != null) this.termIndex.add(wordContainer);
}
public void storeRWI(final byte[] termHash, final WordReference entry) throws IOException, SpaceExceededException {
        if (this.termIndex != null) this.termIndex.add(termHash, entry);
}
/**
* putDocument should not be called directly; instead, put queueEntries to
* indexingPutDocumentProcessor
* (this must be public, otherwise the WorkflowProcessor - calling by reflection - does not work)
* ATTENTION: do not remove! profiling tools will show that this is not called, which is not true (using reflection)
* @param queueEntry
* @throws IOException
*/
public void putDocument(final SolrInputDocument queueEntry) {
try {
this.fulltext().putDocument(queueEntry);
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
public SolrInputDocument storeDocument(
final DigestURL url,
final DigestURL referrerURL,
final Map<String, Pattern> collections,
final CrawlProfile crawlProfile,
final ResponseHeader responseHeader,
final Document document,
final Condenser condenser,
final SearchEvent searchEvent,
final String sourceName,
final boolean storeToRWI,
final String proxy,
final String acceptLanguage
) {
final long startTime = System.currentTimeMillis();
final Date loadDate = new Date();
final String id = ASCII.String(url.hash());
final String dc_title = document.dc_title();
final String urlNormalform = url.toNormalform(true);
final String language = votedLanguage(url, urlNormalform, document, condenser);
Date modDate = responseHeader == null ? document.getLastModified() : responseHeader.lastModified();
        if (modDate == null) modDate = new Date();
        if (document.getLastModified().before(modDate)) modDate = document.getLastModified();
        if (modDate.getTime() > loadDate.getTime()) modDate = loadDate;
char docType = Response.docType(document.dc_format());
final CollectionConfiguration collectionConfig = this.fulltext.getDefaultConfiguration();
final CollectionConfiguration.SolrVector vector = collectionConfig.yacy2solr(this, collections, responseHeader, document, condenser, referrerURL, language, crawlProfile.isPushCrawlProfile(), this.fulltext().useWebgraph() ? this.fulltext.getWebgraphConfiguration() : null, sourceName);
this.fulltext.getDefaultConfiguration().postprocessing_references(this.getReferenceReportCache(), vector, url, null);
        if ((url.getProtocol().equals("http") || url.getProtocol().equals("https")) &&
crawlProfile != null && document.getDepth() <= crawlProfile.snapshotMaxdepth() &&
!crawlProfile.snapshotsMustnotmatch().matcher(urlNormalform).matches()) {
Parser p = document.getParserObject();
boolean mimesupported = false;
if (p instanceof htmlParser)
mimesupported = ((htmlParser)p).supportedMimeTypes().contains(document.dc_format());
if (mimesupported)
Transactions.store(vector, true, crawlProfile.snapshotLoadImage(), crawlProfile.snapshotReplaceold(), proxy, acceptLanguage);
}
this.putDocument(vector);
List<SolrInputDocument> webgraph = vector.getWebgraphDocuments();
String error = null;
        if (webgraph != null && webgraph.size() > 0) {
if (this.fulltext.useWebgraph()) {
tryloop: for (int i = 0; i < 20; i++) {
try {
error = null;
this.fulltext.putEdges(webgraph);
break tryloop;
} catch (final IOException e ) {
error = "failed to send " + urlNormalform + " to solr: " + e.getMessage();
ConcurrentLog.warn("SOLR", error);
if (i == 10) this.fulltext.commit(true);
try {Thread.sleep(1000);} catch (final InterruptedException e1) {}
continue tryloop;
}
}
}
}
setFirstSeenTime(url.hash(), Math.min(document.getLastModified().getTime(), System.currentTimeMillis()));
        if (this.connectedCitation()) try {
if (collectionConfig.contains(CollectionSchema.inboundlinks_protocol_sxt) || collectionConfig.contains(CollectionSchema.inboundlinks_urlstub_sxt)) {
Collection<Object> inboundlinks_urlstub = vector.getFieldValues(CollectionSchema.inboundlinks_urlstub_sxt.getSolrFieldName());
List<String> inboundlinks_protocol = inboundlinks_urlstub == null ? null : CollectionConfiguration.indexedList2protocolList(vector.getFieldValues(CollectionSchema.inboundlinks_protocol_sxt.getSolrFieldName()), inboundlinks_urlstub.size());
if (inboundlinks_protocol != null && inboundlinks_urlstub != null && inboundlinks_protocol.size() == inboundlinks_urlstub.size() && inboundlinks_urlstub instanceof List<?>) {
for (int i = 0; i < inboundlinks_protocol.size(); i++) try {
String targetURL = inboundlinks_protocol.get(i) + "://" + ((String) ((List<?>) inboundlinks_urlstub).get(i));
String referrerhash = id;
String anchorhash = ASCII.String(new DigestURL(targetURL).hash());
if (referrerhash != null && anchorhash != null) {
urlCitationIndex.add(ASCII.getBytes(anchorhash), new CitationReference(ASCII.getBytes(referrerhash), loadDate.getTime()));
}
} catch (Throwable e) {
ConcurrentLog.logException(e);
}
}
}
if (collectionConfig.contains(CollectionSchema.outboundlinks_protocol_sxt) || collectionConfig.contains(CollectionSchema.outboundlinks_urlstub_sxt)) {
Collection<Object> outboundlinks_urlstub = vector.getFieldValues(CollectionSchema.outboundlinks_urlstub_sxt.getSolrFieldName());
List<String> outboundlinks_protocol = outboundlinks_urlstub == null ? null : CollectionConfiguration.indexedList2protocolList(vector.getFieldValues(CollectionSchema.outboundlinks_protocol_sxt.getSolrFieldName()), outboundlinks_urlstub.size());
if (outboundlinks_protocol != null && outboundlinks_urlstub != null && outboundlinks_protocol.size() == outboundlinks_urlstub.size() && outboundlinks_urlstub instanceof List<?>) {
for (int i = 0; i < outboundlinks_protocol.size(); i++) try {
String targetURL = outboundlinks_protocol.get(i) + "://" + ((String) ((List<?>) outboundlinks_urlstub).get(i));
String referrerhash = id;
String anchorhash = ASCII.String(new DigestURL(targetURL).hash());
if (referrerhash != null && anchorhash != null) {
urlCitationIndex.add(ASCII.getBytes(anchorhash), new CitationReference(ASCII.getBytes(referrerhash), loadDate.getTime()));
}
} catch (Throwable e) {
ConcurrentLog.logException(e);
}
}
}
} catch (Throwable e) {
ConcurrentLog.logException(e);
}
        if (error != null) {
ConcurrentLog.severe("SOLR", error + ", PLEASE REPORT TO bugs.yacy.net");
}
final long storageEndTime = System.currentTimeMillis();
        if ((this.termIndex != null && storeToRWI) || searchEvent != null) {
final int outlinksSame = document.inboundLinks().size();
final int outlinksOther = document.outboundLinks().size();
final int urlLength = urlNormalform.length();
final int urlComps = MultiProtocolURL.urlComps(url.toNormalform(false)).length;
final int wordsintitle = CommonPattern.SPACES.split(dc_title).length;
final WordReferenceRow ientry = new WordReferenceRow(
url.hash(),
urlLength, urlComps, wordsintitle,
condenser.RESULT_NUMB_WORDS,
condenser.RESULT_NUMB_SENTENCES,
modDate.getTime(),
System.currentTimeMillis(),
UTF8.getBytes(language),
docType,
outlinksSame, outlinksOther);
Word wprop = null;
byte[] wordhash;
String word;
for (Map.Entry<String, Word> wentry: condenser.words().entrySet()) {
word = wentry.getKey();
wprop = wentry.getValue();
assert (wprop.flags != null);
ientry.setWord(wprop);
wordhash = Word.word2hash(word);
if (this.termIndex != null && storeToRWI) try {
this.termIndex.add(wordhash, ientry);
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
if (searchEvent != null && !searchEvent.query.getQueryGoal().getExcludeHashes().has(wordhash) && searchEvent.query.getQueryGoal().getIncludeHashes().has(wordhash)) {
ReferenceContainer<WordReference> container;
try {
container = ReferenceContainer.emptyContainer(Segment.wordReferenceFactory, wordhash, 1);
container.add(ientry);
searchEvent.addRWIs(container, true, sourceName, 1, 5000);
} catch (final SpaceExceededException e) {
continue;
}
}
}
if (searchEvent != null) searchEvent.addFinalize();
ientry.setWord(wprop == null ? catchallWord : wprop);
if (this.termIndex != null) try {this.termIndex.add(catchallHash, ientry);} catch (final Throwable e) {ConcurrentLog.logException(e);}
}
final long indexingEndTime = System.currentTimeMillis();
        if (this.log.isInfo()) {
this.log.info("*Indexed " + condenser.words().size() + " words in URL " + url.toNormalform(true) +
" [" + id + "]" +
"\n\tDescription:  " + dc_title +
"\n\tMimeType: "  + document.dc_format() + " | Charset: " + document.getCharset() + " | " +
"Size: " + document.getTextLength() + " bytes | " +
"\n\tLinkStorageTime: " + (storageEndTime - startTime) + " ms | " +
"indexStorageTime: " + (indexingEndTime - storageEndTime) + " ms");
}
return vector;
}
public void removeAllUrlReferences(final HandleSet urls, final LoaderDispatcher loader, final ClientIdentification.Agent agent, final CacheStrategy cacheStrategy) {
for (final byte[] urlhash: urls) removeAllUrlReferences(urlhash, loader, agent, cacheStrategy);
}
/**
* find all the words in a specific resource and remove the url reference from every word index
* finally, delete the url entry
* @param urlhash the hash of the url that shall be removed
* @param loader
* @param cacheStrategy
* @return number of removed words
*/
public int removeAllUrlReferences(final byte[] urlhash, final LoaderDispatcher loader, final ClientIdentification.Agent agent, final CacheStrategy cacheStrategy) {
        if (urlhash == null) return 0;
try {
final DigestURL url = fulltext().getURL(ASCII.String(urlhash));
if (url == null) return 0;
final Document document = Document.mergeDocuments(url, null, loader.loadDocuments(loader.request(url, true, false), cacheStrategy, Integer.MAX_VALUE, null, agent));
if (document == null) {
fulltext().remove(urlhash);
return 0;
}
Set<String> words = null;
words = new Condenser(document, null, true, true, null, false, false, 0).words().keySet();
int count = 0;
if (words != null && termIndex() != null) count = termIndex().remove(Word.words2hashesHandles(words), urlhash);
fulltext().remove(urlhash);
return count;
} catch (final Parser.Failure e) {
return 0;
} catch (final IOException e) {
ConcurrentLog.logException(e);
return 0;
}
}
}
