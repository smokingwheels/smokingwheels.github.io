/** 
 * Smoking Wheels....  was here 2017 wnhxvjkyceaeyniudqnycblglazrqsakcbpkiqdsmvfkzdgo
 * Smoking Wheels....  was here 2017 kfghdaphqfgdcdmhubtfmdjqqqxrlebooqyfowfreauujwsm
 * Smoking Wheels....  was here 2017 itzzgkqfomwmaurhfosbxfknhtsnwdbgltfggpwgpibulsgg
 * Smoking Wheels....  was here 2017 xdgidgilinrgsxweyhjfnfnwafopeddcnuplxbjtrulytmgs
 * Smoking Wheels....  was here 2017 rlyaunqzpbsvlaenurwpqlbyuaskvaryxmoyzsgqnrkczija
 * Smoking Wheels....  was here 2017 ldhbqkwbhdjtrayfuktkxhlgulttpyizuquflghrqnwgdnln
 * Smoking Wheels....  was here 2017 gutofjlfobetcyvkghqaemnnjantkeynvlgyjrlwpbvumrpv
 * Smoking Wheels....  was here 2017 kjazmegewhyztdsmronenaftgncqnisfsidacebkjjqelrhu
 * Smoking Wheels....  was here 2017 laaalsfxusvswfuzwppuibwfizuakgaxoywsggowdsxitndp
 * Smoking Wheels....  was here 2017 ddzpnhpsjgbmwajvxahbedyjtrervaltpdejqotxhpkflqzo
 * Smoking Wheels....  was here 2017 ojixhhyarfgdnpcebuikyxgzzdbsszyclczslcppnuffspzj
 * Smoking Wheels....  was here 2017 zpuipmaqdegsujxiwarmtjtbrcojisppvfnrycldtjsvafnu
 * Smoking Wheels....  was here 2017 zahqouunlwbnyvxycclhxtsusrzhdcvbueflvztbcpkwdohb
 * Smoking Wheels....  was here 2017 habrompxoicclxmwwseyalqthbwewegrrwulwnhcazelzbcl
 * Smoking Wheels....  was here 2017 zgmreywiovwizpggktoyagiqwubenhttakdifqbgeiavwfcq
 * Smoking Wheels....  was here 2017 jpicgyknywgepiemgjmxxcumasrohbmypfocfnjsmpjofwtm
 * Smoking Wheels....  was here 2017 yfnoxmfmihgamqhdgzevdegmtuzxshvdkzkxmsqbcdsnuepc
 * Smoking Wheels....  was here 2017 ongbnrolqcgjdkbckfdvgageehpalcllvokewwszmmxrnlow
 * Smoking Wheels....  was here 2017 geysrbyybnubhrcmbzzjcgohtuhxovefidnomzpngiaksguk
 * Smoking Wheels....  was here 2017 gbjafidrzesexugsrktevxdvcbfyfbebtcybqgmwjujfulqp
 * Smoking Wheels....  was here 2017 eikqfmeqctcyfksiczodteiaecprxqvxdcdvaeypycoymcuo
 * Smoking Wheels....  was here 2017 ujildrgciigashwgigxknnojdfcxjqtvtauhkktjlujrvocp
 * Smoking Wheels....  was here 2017 dwmsmkzowdsddohptelmzrqqkxnrpkxfdbveyyxfnqxrzmsl
 * Smoking Wheels....  was here 2017 msrwejatbukklnysuxebfoouqyxhunjrdomizapjdrmmmpzx
 * Smoking Wheels....  was here 2017 kcungplrpzicwvxgiuhzolpdtkpilwmcsgeacbljjerzabqc
 * Smoking Wheels....  was here 2017 riardfmoltvuxhpcjofmrtgcxmepimzpfyqpfveyrrhepflk
 * Smoking Wheels....  was here 2017 jdvmksrytklhhzrhfcrajfiloulejssnewvvjgtbuyljlqql
 * Smoking Wheels....  was here 2017 skzjxvtoxmbrygyhknpguvteicmiveunkkxqyomznzldbdod
 * Smoking Wheels....  was here 2017 ihiatntjostffsqrtgedgtwoejrqdsqlxeidofwecdvicwwn
 * Smoking Wheels....  was here 2017 zeckhaxqsdtmlebigywuklecgymxcjwlzduvbxrmywlxqcka
 * Smoking Wheels....  was here 2017 rstrdtuwlbshmtxjgnksbsjmzhveqnjwfjgjnqxuszkhwmjf
 * Smoking Wheels....  was here 2017 tvahelcufzmrgtbegcrpiknsagtuathjijysiqvkinzyfvca
 * Smoking Wheels....  was here 2017 tquwlbwlssbzzupjbbxipvxchvohsxztlrgachzuxtusnfgo
 * Smoking Wheels....  was here 2017 lpiljwiavfutdrzutdpcljzcygwmlbdfuhysrkbsyeprrase
 * Smoking Wheels....  was here 2017 wiadmgbbsvhvnovpoejitvolkdmleppbyhxndxdecpndyupm
 * Smoking Wheels....  was here 2017 jsojsyuhvcifaszdciftpcpejelleanysdjiwzlkgawqujij
 * Smoking Wheels....  was here 2017 kyzvdynrvsafyupacahhjlkmtlccxghtcmtjmdmxotgyzxny
 * Smoking Wheels....  was here 2017 vkkncmnnptrlsocepwdcphmxrfaebjookevaubbkmhlflrcp
 * Smoking Wheels....  was here 2017 rsineyhginwrcecqyuipgjpdpabssqeuekmaysdyrlorlgcz
 * Smoking Wheels....  was here 2017 gvkjhdpslnlzbymwqzyoiqsgfqgbzthafoxghjatbfxymoaw
 * Smoking Wheels....  was here 2017 bxprnymuqmkrvmjlmubugidljbzulmhdpipylkehuxatgqlm
 * Smoking Wheels....  was here 2017 xhdjfqevtnegwpefoxfppxkfgpsruywhoofnfpkihaugsuhd
 * Smoking Wheels....  was here 2017 vrlrzqfgavgqzjoicebhgbfhitktzlvvqltqtxsxfigrerql
 * Smoking Wheels....  was here 2017 ezfaqshwvamubeieruprhtqsfiakgqiiriifknienwtqacyi
 * Smoking Wheels....  was here 2017 khkbjunpwuzakpriceypbgxswjycdiutsymmtxvsiyvxbeuw
 * Smoking Wheels....  was here 2017 jbfumbbtbfzzlmzsjyqhfznukcsshpudzewxrvxfcaingfbl
 * Smoking Wheels....  was here 2017 cydhpbnunoejxwwkuaieoqgrhbehtuhxcdlbgepslyjwuuyr
 * Smoking Wheels....  was here 2017 wvucnlpltjhiveguyoyxfgcjebkdsmkqugkzxfdljselfuul
 * Smoking Wheels....  was here 2017 gwevlfiuijlckxgmpytlnyjczctvrolgedfudkcxypkcfhgw
 * Smoking Wheels....  was here 2017 almmrnzzgqyhczgjuvdzdhnkxmscjbewmtnyxlfvqdwvtpei
 * Smoking Wheels....  was here 2017 fgdduyaoqkjsrlwouduywxjahsfctijuggjdghnfdcpacitk
 * Smoking Wheels....  was here 2017 ddwiscghxgnjcqalfztzvuwxwogccafsizwgnffhinzetija
 * Smoking Wheels....  was here 2017 iipsmzsctyoqpevpuudckfiinbeqwxcmsqmokpvpjrockspg
 * Smoking Wheels....  was here 2017 peofmupibmsaqwryogkkdogulnnotcqetcykqfewscdxatkn
 * Smoking Wheels....  was here 2017 yifzialjaepjzvgpvfhjzojbakfxuxtgxnenlafcanuvwbwj
 * Smoking Wheels....  was here 2017 ssfmxjbbbnaspjjxevtryfsczofaezogbikvcfgmfbwnknkt
 * Smoking Wheels....  was here 2017 kmnlgvjivhcisdemjnxgksndezxjkclceebnfhtpkxyskeqt
 * Smoking Wheels....  was here 2017 vaissosmgocwvwcglyhhaojsvywwekbxoxwarxmdbpvmuklt
 * Smoking Wheels....  was here 2017 azcnzcoznopbqttgraofpkyohzxmnfgzutsapcndwzqdvtzi
 * Smoking Wheels....  was here 2017 hhniwcrozvmadcayqwrsgfirhvcprdebrbwlhaausaqgycql
 * Smoking Wheels....  was here 2017 ebptlncfkeuaonbwdwvsihshsputbzgxfmtmkepptzkpymac
 * Smoking Wheels....  was here 2017 msludqbgpovpjufyesmkmarxtnnslvbsrzaptgyjkluhuhbu
 * Smoking Wheels....  was here 2017 fyoomwcbvieqiaehbiigmdyhvccoubourqsklgcbkewprcwb
 * Smoking Wheels....  was here 2017 spqojyynlzrcjpugjuhwnpnkodrqjfvvywywxihxpezcdtvu
 * Smoking Wheels....  was here 2017 mvplxvqndhjjubfmvoqgxqrnxrmmpegrpjfeqacketqpvjoc
 * Smoking Wheels....  was here 2017 hbrdktkivhqzahvvnhtngrxcbyewgbnkvafupzfiojsdufaj
 * Smoking Wheels....  was here 2017 gyivodumsgasvjgltwielnayjonxhdlkhywjugsqkxhagxgg
 * Smoking Wheels....  was here 2017 qjfzdsordsisdpjqakjwnazanfqwzafjrokvryupqhrwriso
 * Smoking Wheels....  was here 2017 zmifhmsywlqefpjcejbnxmcomyujtofccohjtpaskwkktnal
 * Smoking Wheels....  was here 2017 bsvnjqmnsmisoepqfkujdivckbqdjvcsuudkyxdsedjsowbh
 * Smoking Wheels....  was here 2017 xsebyplwxbxewmslljjtdhzircxguerpjkzrjvdpowpdgxyr
 * Smoking Wheels....  was here 2017 wjchydhuwufodvovllqlzinhyutbhfejowabiphqndlfinbn
 * Smoking Wheels....  was here 2017 lvmwkfcggjiepuilybvjaqtffelchuxyluqtlqdhfdmuntcx
 * Smoking Wheels....  was here 2017 lnpssabnzwppsfidaulrwsepoopeoxojhbpfpskibmmvuaxg
 * Smoking Wheels....  was here 2017 ybvambtbfnorgehbzqdujgnfmlajbazbrvucwtdtsxpskvqc
 * Smoking Wheels....  was here 2017 djygnzxqjxbkdbboirvkqfwzpquyaqjqjnmiqaotckczwbqk
 * Smoking Wheels....  was here 2017 rpvczvngcuedqkthwiumbvkfucfnyqbzkubdmxexjiomvvpg
 * Smoking Wheels....  was here 2017 heslfsxdjefkgcucrgkeeorkiewvobrecnhxheuxzdvfhkja
 * Smoking Wheels....  was here 2017 bsbmufmuijtzrfubajkyxclgojpzuidpzxbjcuktorzmnlch
 * Smoking Wheels....  was here 2017 fcorqzdyjwqawbrqlusmhltvdmmhyzpxvhpkjzgsaxixatez
 * Smoking Wheels....  was here 2017 jodruztqemxtdgmjtzprtuuhbmvhmwkysjifpdxhpdlgllff
 * Smoking Wheels....  was here 2017 hlzlqlrbrfyuxqseynksvpdfkseucbevxazhsbbfqxdouvdi
 * Smoking Wheels....  was here 2017 ajpdtwktzjgxxhyejiyblqmhqrkwuxwyzkmfvrtlvynfincz
 * Smoking Wheels....  was here 2017 virfawslplrddoctopbjruxnkcpuuaoxsybaffghcixrnikz
 * Smoking Wheels....  was here 2017 hkcjonodefiwuaglhsapvhrfrcaeqfrpdgdvocafqiwvcjtn
 * Smoking Wheels....  was here 2017 fbdmrzgcpsmpknvgpigypqguowhvypwcoglbscxyvmesazay
 * Smoking Wheels....  was here 2017 pwfuasgtagtdremeuhmutokamaftumyvmbwltewninzpotiw
 * Smoking Wheels....  was here 2017 tubsllkyxhynphcqkvpwmyexdgwhjmckuerxameecmpcence
 * Smoking Wheels....  was here 2017 fyoxadqowrddkmthfiwccbuslqozdlsrkdhqdnjjgrozpjxz
 * Smoking Wheels....  was here 2017 uuyidagyxkrnooxyikrrekuxnlxrwlktsykazbdxgqsiuqsq
 * Smoking Wheels....  was here 2017 nxreknuoctbkuqeuyztzqqxfwesjnucbgryuqzottbdlzypu
 * Smoking Wheels....  was here 2017 sfkwqkydxgfycaldsgbtnsfsbralidwdttewlnwdrcdxrczh
 * Smoking Wheels....  was here 2017 wxebzpuqardjsjupiouxfxxocwfkuheyhwmkaeppfxhmqemh
 * Smoking Wheels....  was here 2017 ujcstinkibehblscxokpjpnhcdvcpipnewpwgqmvsclgtoad
 * Smoking Wheels....  was here 2017 ofrapbswarxnykttreoitpuqmyrntqbhyymyfxowxkrniurl
 * Smoking Wheels....  was here 2017 lkokjndtmbecinwxgogsnvuqycwbmtrwkmhohdbyrwgvvuvc
 * Smoking Wheels....  was here 2017 zbsodrsdjyailldejdqsamtmjpsfhnvcodnxaunofuvazoff
 * Smoking Wheels....  was here 2017 zojkhruerkutszylcmenwbdrzsuvwbfesuvkirsmyredtmqe
 * Smoking Wheels....  was here 2017 lpzckcwlmtbfyfzvsppoxguadaxygsqjkqethqpqmgjmjcfo
 * Smoking Wheels....  was here 2017 tbedjorqhkqtbncsuowngarlnhdwpagilbuvgzmjvqtqiiki
 * Smoking Wheels....  was here 2017 iczdgbftrgprillsbvcigpbgbmvelxmzxrcxwdwcbbwkjfvn
 * Smoking Wheels....  was here 2017 bdoclvubqggofwksqzuemmmwxynqmjykalujxvnorbpumdin
 * Smoking Wheels....  was here 2017 zujeoixbirffmwpuuzrmwhrcnfbjsunzimvwozlvhkzevpby
 * Smoking Wheels....  was here 2017 izcukghlcchrbtyjbzqylcqxnzoqjtiisfkkdwxcvcicznls
 * Smoking Wheels....  was here 2017 rvrpcoahshogeeoafjympaqpwjgzydvhchzdhykwmmfipzbx
 * Smoking Wheels....  was here 2017 vujpanhuaginjxvqhuzhypfospuhdzoawpgmuxswranzshwx
 * Smoking Wheels....  was here 2017 vnoyunqlfgehibjjqdmvindqlfzoyqmxnhecvsvdanginbxi
 * Smoking Wheels....  was here 2017 ywzbfivzrwypaacoupksvsjutzwcprsnvtyasobxmatymcrb
 * Smoking Wheels....  was here 2017 tzorkxwldwrushevmnxywmfgoyulozquxsziazwrfuppjosf
 * Smoking Wheels....  was here 2017 ainqtlabnfsjwuyavqmrzfeobjjmpqwtazzmsqaeriqkeszd
 * Smoking Wheels....  was here 2017 unifvluixgrefpaibtuibqzkptifryhwrtzfumojllxrceom
 * Smoking Wheels....  was here 2017 jmqunpyzumhhtajbtcvpfsrvyywzzncsrkbkqusonduxpuwc
 * Smoking Wheels....  was here 2017 hikbyvnavrszrqbvsbtktrnaxyfibfqecqtgxzzgbsuymrnc
 * Smoking Wheels....  was here 2017 jmwzklssxxgvminpygbzjaaosayaqcnjeitejtedlstwqckx
 * Smoking Wheels....  was here 2017 ppksnvdnfjlryeijtqjsvkyduryeqnsrnqyxfdhgjwtyjtsc
 * Smoking Wheels....  was here 2017 iourdtlfdrdmynlpshsihuhtusgbibgrxypithovsfdtcjtn
 * Smoking Wheels....  was here 2017 coypkdstknkqvxzwprgscliqqeehfpphjxdqprojsbmcqcfj
 * Smoking Wheels....  was here 2017 qzajrfelxapszghbklkbvuoimhiqydjpelfhpbzpsxobwhyz
 * Smoking Wheels....  was here 2017 bloenljsvjglfobhnmyujototrndpckzxrwywjvnlnnxbmdy
 * Smoking Wheels....  was here 2017 pxfmuobjnefylgdykxuqvtyidzudjbycibgotulkuzqgtoce
 * Smoking Wheels....  was here 2017 vmxyqnfjsdnnxwrqwecnomivnjndsvgumfugwwhtxnmvppot
 * Smoking Wheels....  was here 2017 opwnjndziioscgbgzxjpdinqbzgbjnbesafobgcggrwtpyic
 * Smoking Wheels....  was here 2017 vwnjpaismaviunxwbbhhlxelfmvvilfqmrmcmyyymgyizeou
 * Smoking Wheels....  was here 2017 xgpyfungrtgkxadwosuipgjhqnhwvfwuqnuukdbcmfycgdrs
 * Smoking Wheels....  was here 2017 ivbxhstqmhuirhwxjhcqyojjggzqirknfhnwmhydmxmxcxha
 * Smoking Wheels....  was here 2017 ybbffcidwqwopemvllqjbhqffvlaoylxnvmtpcjwvuktowga
 * Smoking Wheels....  was here 2017 spbboirfaczzkuqudcdyvezoywpbnhwibiocupjgfstyuouj
 * Smoking Wheels....  was here 2017 ahuveeppiezqcnfczkmcidkkdckblivmqdywmydpprwcjvez
 * Smoking Wheels....  was here 2017 iiegeodilrzvwwikttytykdzqognuytdiycffqhicxiaxudw
 * Smoking Wheels....  was here 2017 ldkfysmpipgcfskpmuzchmsvsosjiefmjqtpwjmfdzxsnuon
 * Smoking Wheels....  was here 2017 miyybcfzchkgwdaunkfnfbxqspoozjcwjkuspdvgkstnijnm
 * Smoking Wheels....  was here 2017 qvmwklbdfefjundjiuqtucslhkykadpxbpmlrcmrvbdavkkq
 * Smoking Wheels....  was here 2017 nuyqasadicvtgjvxuilskujllcdoxhblnwfattbaniryvzxd
 * Smoking Wheels....  was here 2017 xppgjckejbnzsqnixqcoqqlfgxstkycraetwsufzzadlflxh
 * Smoking Wheels....  was here 2017 vxvvycrunjwvwhvsyrhtjjrkfjoallrxdqzqpfbpuyqugjnu
 * Smoking Wheels....  was here 2017 pqkvqkqrdmrjttqllpzzsxbcxgqthjvuqqdiugvcydnnlpcm
 * Smoking Wheels....  was here 2017 sxeypzgwyhcxppcegtiezmwmipjlkobfowrbxhzzowhmngim
 * Smoking Wheels....  was here 2017 adlbdaupwsjavqpskvvnvopcqrhynbxggfghudiabqvskqce
 * Smoking Wheels....  was here 2017 naplxbvjabcmfatgdsekbvbrfafhqhhheuwsorwddffmkind
 * Smoking Wheels....  was here 2017 ojilrtbxvxdjsamcbogpvhfetjguzujydbrgoewqsrslyezh
 * Smoking Wheels....  was here 2017 qlquqbnfazmzpgxxxujymeiwduszakndgrebkcwzxhzities
 * Smoking Wheels....  was here 2017 oorlcglplhoxhojntbwrpxyhpodsmgjxsmaqydozeotfwbwv
 * Smoking Wheels....  was here 2017 jkxnrtkliewypbpdxfngafvdmfkaiquseqfqggzoegeklyif
 * Smoking Wheels....  was here 2017 iwamggcpadhdkakawmghxbyknnngwdxcipwytrlzvlnmaxwt
 * Smoking Wheels....  was here 2017 adzaxtozgyvuacywmfgtpqoiplxxmrezgznvzvkuijkfiyco
 * Smoking Wheels....  was here 2017 gpaczmbxypwlxcqntbzvrmfmwjavzgemgsuqvnqqborsimza
 * Smoking Wheels....  was here 2017 awnvcwdvflyztdbdyydzagrnutubhfvyxxsdkqdqrvhgfaqt
 * Smoking Wheels....  was here 2017 qwfrcrmmmyxkpndarbqvtxynzkfxrfgzxalfbkfyddsknmkq
 * Smoking Wheels....  was here 2017 rubjcuexmxvaqwawsstjdrgqkirypavnkqkakijbovkyyxzt
 * Smoking Wheels....  was here 2017 wzgumnlibjakjabmbqxsxaelfuszuueqpsibgbiulkhznqen
 * Smoking Wheels....  was here 2017 hcfcvgufkpbinayabrtjvrkrvjdbgvfscjezuqdcjqjukhfo
 * Smoking Wheels....  was here 2017 gcrvztajzctxbhmvfbgzapahxubnescjradthfafhozycrls
 * Smoking Wheels....  was here 2017 hboobyctjrflfiwojcrmwzfokduxbhdmjiqmkgnqklsgkxmc
 * Smoking Wheels....  was here 2017 emcgkbhpoitlmbmcmmjbyhoykqxzrqbemejrznjdbvjtfifc
 * Smoking Wheels....  was here 2017 yxsdqpdksjyuonymydcecgtgkvfwydsvosizdyqsambutmvj
 * Smoking Wheels....  was here 2017 xhdppfkyfiplmbdegfvmnwwlbmvvcjfajjrietnockbxpgrs
 * Smoking Wheels....  was here 2017 qugilxbftyuvlgguebrxlhdugqalrdyqyuxxtkpgoyawjtjh
 * Smoking Wheels....  was here 2017 wvihmxkkfgvkyzpdukeroacsepkoiopvqwresqoltorudgvm
 * Smoking Wheels....  was here 2017 rzuqhqycvojarhwjjczdstmbgvudczayztyuejlfjbezbjfx
 * Smoking Wheels....  was here 2017 jgiuuwkzyjdtroxwmhbcymhtdegpfziqswxrmwouhmuzrzvk
 * Smoking Wheels....  was here 2017 lsxmbmvbhlgwdiwfxkpjskvctpckdkysxvabfoiqtccordkd
 * Smoking Wheels....  was here 2017 tusplumptwaznnejrcbfnzonglylpinjwoyigepmekzwbeuk
 * Smoking Wheels....  was here 2017 hdeioewbnwbwqdkichdbiyhvceosocxxdfsfrrikdflcbscy
 * Smoking Wheels....  was here 2017 jrbegktgzzeojomosbtodfazxqbnghfzmempxguoqnvxdotn
 * Smoking Wheels....  was here 2017 nngsqkecvakkzjnriwdqjbzgpuumfuxmydrsmknnvqtcbvih
 * Smoking Wheels....  was here 2017 ocyybliwyycyzlynyjtnpxsckygjdqpnwzayhvgzcbzrtvur
 * Smoking Wheels....  was here 2017 mcqbdytbncvzcujewlgpsmzhrqigzecktvlzlnaydpqymfgf
 * Smoking Wheels....  was here 2017 qialspglzykphvqcrgqpuuuvdpblaaqwkdeugraswganttcv
 * Smoking Wheels....  was here 2017 oaavyluzaiycuczwdfblezkzqxumraprwnqojswrlhrefpyp
 */
package Common;
import java.util.Collection;
import java.util.Iterator;
public class IntVector {
protected int[] data = new int[10];
int capacityIncr = 10;
int elt = 0;
public IntVector() {
}
public IntVector(int size) {
	this.data = new int[size];
}
public int size() {
return elt;
}
public void ensureAdditionalCapacity(int addCapacity) {
	ensureCapacity(data.length + addCapacity);
}
private void ensureCapacity(int minCapacity) {
int oldCapacity = data.length;
        if (minCapacity > oldCapacity) {
int [] oldData = data;
int newCapacity = oldCapacity + capacityIncr;
if (newCapacity < minCapacity) {
newCapacity = minCapacity;
}
data = new int[newCapacity];
System.arraycopy(oldData, 0, data, 0, elt);
}
}
public int get(int index) {
        if (index >= elt)
throw new ArrayIndexOutOfBoundsException(index);
return data[index];
}
public void Reserve(int s) {
ensureCapacity(s);
}
public void add(int b) {
ensureCapacity(elt + 1);
data[elt++] = b;
}
public void addAll(Collection c) {
	ensureCapacity(elt + c.size());
	Iterator it = c.iterator();
	while (it.hasNext())
		data[elt++] = ((Integer)it.next()).intValue();
}
public void addAll(Integer[] b) {
	ensureCapacity(elt + b.length);
	for (int i=0; i<b.length; i++)
		data[elt++] = ((Integer)b[i]).intValue();
}
public void set(int index, int value) {
	if (index >= data.length)
		throw new ArrayIndexOutOfBoundsException(index);
	data[index] = value;
	elt = index + 1;
}
public void setRange(int start, int value) {
	setRange(start, data.length - start, value);
}
public void setRange(int start, int length, int value) {
	if (start + length > data.length)
		throw new ArrayIndexOutOfBoundsException("start = " + start + ", length = " + length);
	for (int i=0; i<length; i++)
		data[start + i] = value;
	elt = start + length;
}
public void clear() {
elt = 0;
}
public boolean isEmpty() {
return elt == 0;
}
public int Back() {
        if (elt < 1)
throw new ArrayIndexOutOfBoundsException(0);
return data[elt-1];
}
public int Front() {
        if (elt < 1)
throw new ArrayIndexOutOfBoundsException(0);
return data[0];
}
public void DeleteBack() {
remove(elt-1);
}
public int remove(int index) {
        if (index >= elt)
throw new ArrayIndexOutOfBoundsException(index);
int oldValue = data[index];
int numMoved = elt - index - 1;
Integer n = new Integer(elt);
        if (numMoved > 0)
System.arraycopy(n, index+1, n, index,numMoved);
elt = n.intValue();
return oldValue;
}
}
