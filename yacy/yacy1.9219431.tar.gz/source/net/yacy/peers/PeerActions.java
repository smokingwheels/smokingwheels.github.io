/** 
 * Smoking Wheels....  was here 2017 zexzgyrscmztdckpbaikjxxudopozxuxjgvsftaetfeqkyhu
 * Smoking Wheels....  was here 2017 jbptrjjqktlelbqcuvvccpgjnvvpstvaerwstndinjovrpup
 * Smoking Wheels....  was here 2017 liwuvlvcbvipzoaapeegmztzrswmrumsqehtdgykvgjynjqk
 * Smoking Wheels....  was here 2017 ruluoqqxcrywbdtgdghyosdtanhimuddscfaqxlqhjmlthlq
 * Smoking Wheels....  was here 2017 spfwtqnbwpycipeaiilkpukabsynbvmupzebtpyrrlyxmqdb
 * Smoking Wheels....  was here 2017 ncmesgnzyacsryatlcadahxhpzxtmfkirtxpevzhamcfdywn
 * Smoking Wheels....  was here 2017 gwqiytyfbrnjfndeujvyqrdkrjovdlctqnhsyeiorroohaah
 * Smoking Wheels....  was here 2017 jvlaenhojooxhwrfefttlqwmralyqixglpppipawfnehwxgv
 * Smoking Wheels....  was here 2017 nzwgkgiccxvmotbclbbxqadvcmklvxmfhphvuhhsjtzbywmu
 * Smoking Wheels....  was here 2017 rucjwvdewecmwfyfumextbfatmoawltkojbcbpsyhijswmwd
 * Smoking Wheels....  was here 2017 auquckyjkcnniofirhwlnepvszgndoxuzbwmeharfnyliotc
 * Smoking Wheels....  was here 2017 ywdiulhlwrlniiajurbqyzdkgebbgzgmmzzeifhetumpecwb
 * Smoking Wheels....  was here 2017 fcpzypyondkqniunbyyrgkuaaqucaunzftvtcntarwcvmkbu
 * Smoking Wheels....  was here 2017 qwgawtyzxygesoegqrbbzrxgsaofrgpaqgdydrzcbsebrane
 * Smoking Wheels....  was here 2017 nuoyzcphvvcvbjagzubpvdxzmishmypmlovuniskeogijtqm
 * Smoking Wheels....  was here 2017 frfnccjikuhmygomuiyhvnrfouvmcpzpnbenllairyedkqac
 * Smoking Wheels....  was here 2017 mrftejcewakhybdcysxkfsehoxtekhjvdhpqkcdkgnbayzqu
 * Smoking Wheels....  was here 2017 ecsxlvtdvbhpzulpsmkkmwsugjpaojqvqevyetplbifyhhpl
 * Smoking Wheels....  was here 2017 mpgnlqqtbpabdsirloecjkuoterwwhaptuwktceojogadkih
 * Smoking Wheels....  was here 2017 xamhwghyrqxovlagwzenwafrhpoxywvikmwijbybsszpiimt
 * Smoking Wheels....  was here 2017 clkitimrxkpfqsvoxdqwgpakmadmtetltxientdoymnjzjyo
 * Smoking Wheels....  was here 2017 ygfujufjkiymlpmatqzrajljdhlghmsrhwztypgucygfmbwq
 * Smoking Wheels....  was here 2017 sajgdtvnwfyxjjwjviytwrakhhwbbjvyqmtbriexmfrfkfre
 * Smoking Wheels....  was here 2017 tqqmwsuzlzalupdmvinavfonghzcoonmucwjxuvervrurvzr
 * Smoking Wheels....  was here 2017 vfxlnhwwkxteibrqqywvdxbdoupttdlrwjueefnflnipkgsu
 * Smoking Wheels....  was here 2017 ubmkjjdlimyovudgnwnqiyutbnwprkmhjcgfezuwxhanyabn
 * Smoking Wheels....  was here 2017 xutywfwiajsdlbkawxdfcshfvkbpuxvfxkfnztkdhhhryxiz
 * Smoking Wheels....  was here 2017 nhltudphnpkxomrxjdrplwjodsvvqkvsmqxktlkkgczlfzhr
 * Smoking Wheels....  was here 2017 krowexbldkpxtuicyykaqjafnyysezeffkthbgbfnjfmymti
 * Smoking Wheels....  was here 2017 kggnejhdkfcoxbabuytadinqvupwlxtjppmappwkedirmzxv
 * Smoking Wheels....  was here 2017 urbhjspxfvbodormizlitglsdgaevssfhgbokcraopwdlhdk
 * Smoking Wheels....  was here 2017 ytqwmjmoofurwvkhgelzlsmnsowvzemwfusessllffrhrldn
 * Smoking Wheels....  was here 2017 opaimztftowdqsqsnvzflrsjceydtksuouwkzqmfxuxtjstv
 * Smoking Wheels....  was here 2017 ppiwpmkekjdikfzegpmogilvewjuhrgttciyafhdtfwkvrei
 * Smoking Wheels....  was here 2017 ejcbkbsagjsvfpkkyjruqadsypmqymhpmwzwtesiauckrcuf
 * Smoking Wheels....  was here 2017 usaqpcfojoxomlbjgdoxpnpdspvviqgqsjalmkrchzndvbhx
 * Smoking Wheels....  was here 2017 ctbpegswcdirvogecjidiqwkciithfufphadsbozjmeejumd
 * Smoking Wheels....  was here 2017 bwlfjmehzpuncytjsqlbjqfbvnzbamtcokptdpuwiikmswqu
 * Smoking Wheels....  was here 2017 uqqaszykvsktkxkpmtpjmweyaeeqvzifhxsgtrgulsuekcbd
 * Smoking Wheels....  was here 2017 uyitybnasknheajwcwudqameyonpknxttcrywfwchcfqkmmq
 * Smoking Wheels....  was here 2017 twmlamrfxxsfzbahnifobzfaebujncdfcpviyiairhsmujsx
 * Smoking Wheels....  was here 2017 ouihfdlhztvyrbbjxsifhaqbomdnjbzfugzdsndiqerqxgzy
 * Smoking Wheels....  was here 2017 khjxafcvtpyclhjvrxxvblgdcuxzhymtmeclekbenarfkzrz
 * Smoking Wheels....  was here 2017 sfgzfbdshmkoqicooavkiywicepxyndbcsiloxuewjnqeolk
 * Smoking Wheels....  was here 2017 gszotlkywpunwzqulkjfkmnzeeerewonwmerlepynwjlhgey
 * Smoking Wheels....  was here 2017 vctwxexwcmzhzgryorzusflpcnqwcfrvejixmrbgmnmqdrbo
 * Smoking Wheels....  was here 2017 szbmdnwbtuaodlbuhqjwbnfbxdilcepatkuesbwfbomhjolk
 * Smoking Wheels....  was here 2017 igpcfvwjwohfrdaejlmmlcolzhxmtmtfmatrjfddwmfuvyzz
 * Smoking Wheels....  was here 2017 izitevrvuaijgbwkrkowbwnauldkzfuwptrzyjcprzuvreqz
 * Smoking Wheels....  was here 2017 romrejhucpajsiivlebokzklfiewyrqsmmhufwhkocnffuni
 * Smoking Wheels....  was here 2017 nomluqavobkyeeggcpshhwslgyhsxjjrwjpfelmrvazdcnag
 * Smoking Wheels....  was here 2017 ivcuscktfkxxadvnhumcrfgehndcocmzrrskaysrafbyfmvd
 * Smoking Wheels....  was here 2017 tnhsykeqlvalwclxyboguxzyuonjtyobbceygpgayluirxvu
 * Smoking Wheels....  was here 2017 uyfmukkvsvrxpzuuibkgdcghqsngqeopmksorvporrodvjeb
 * Smoking Wheels....  was here 2017 oskprjjwxdxyieryuqtvmgocwbnonhoopufhggphndymirge
 * Smoking Wheels....  was here 2017 mrnwjqnpbtamlejhawoavarjutblcdbdjnzjfufpaituavsq
 * Smoking Wheels....  was here 2017 izogxxscmvronteaadbdjhrlyhahfuquzhkicrtaaycsaemb
 * Smoking Wheels....  was here 2017 yytamdzstysrlauoxaspqhtyekluylfgwwgxphtknajctfsm
 * Smoking Wheels....  was here 2017 ofnspkoyquejjfcrdkefkjmrmdstssyjrkletgzuxsbcttua
 * Smoking Wheels....  was here 2017 oopbafzsfikpqxhgkkmapgrrgqkidjglkhgiuolorobdzvke
 * Smoking Wheels....  was here 2017 seycteaztualwwsnqiwgovhizkjybltwdbcxeilgqhmtntkq
 * Smoking Wheels....  was here 2017 wjubaftexrwjydbxzvskrhqdmerfqgjjkpsqtzmsxvqysayi
 * Smoking Wheels....  was here 2017 hupmhnkvksayabgdxsugtagzwyrzfjgxwaapkfjztmdtfmmm
 * Smoking Wheels....  was here 2017 ifbcjnntixubkcjeddauusxxkyzmkmuqlriakycksruqxeqo
 * Smoking Wheels....  was here 2017 svezgvwazkuwtdxdnlribgphqqjadtraheajihzoperfwihf
 * Smoking Wheels....  was here 2017 jydidlmayuxtxdkohfejzwqqktzglktuxivmvsngnxeimoqk
 * Smoking Wheels....  was here 2017 mfkrnlqfzsejalwdwihqjxouthdctzfvxisiyxnptexekqai
 * Smoking Wheels....  was here 2017 mksufiwnffxploktywxddcdvzllqshllgmxexszwwkpcmpem
 */
package net.yacy.peers;
import java.util.Map;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.feed.RSSMessage;
import net.yacy.cora.storage.ConcurrentARC;
import net.yacy.kelondro.util.MapTools;
public class PeerActions {
private final SeedDB seedDB;
private Map<String, String> userAgents;
private final NewsPool newsPool;
public PeerActions(final SeedDB seedDB, final NewsPool newsPool) {
this.seedDB = seedDB;
this.newsPool = newsPool;
this.userAgents = new ConcurrentARC<String, String>(10000, Runtime.getRuntime().availableProcessors() + 1);
}
public void close() {
        if (this.userAgents != null) this.userAgents.clear();
this.userAgents = null;
}
public boolean connectPeer(final Seed seed, final boolean direct) {
        if (seed == null) {
Network.log.severe("connect: WRONG seed (NULL)");
return false;
}
final String error = seed.isProper(false);
        if (error != null) {
Network.log.severe("connect: WRONG seed (" + seed.getName() + "/" + seed.hash + "): " + error);
return false;
}
        if ((this.seedDB.mySeedIsDefined()) && (seed.hash.equals(this.seedDB.mySeed().hash))) {
Network.log.info("connect: SELF reference " + seed.getIPs());
return false;
}
final String peerType = seed.get(Seed.PEERTYPE, Seed.PEERTYPE_VIRGIN);
        if ((peerType.equals(Seed.PEERTYPE_VIRGIN)) || (peerType.equals(Seed.PEERTYPE_JUNIOR))) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting NOT QUALIFIED " + peerType + " seed " + seed.getName());
return false;
}
        if (!(peerType.equals(Seed.PEERTYPE_SENIOR) || peerType.equals(Seed.PEERTYPE_PRINCIPAL))) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting NOT QUALIFIED " + peerType + " seed " + seed.getName());
return false;
}
final Seed doubleSeed = this.seedDB.lookupByIPs(seed.getIPs(), seed.getPort(), true, false, false);
        if ((doubleSeed != null) && (doubleSeed.getPort() == seed.getPort()) && (!(doubleSeed.hash.equals(seed.hash)))) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting FRAUD (double hashes " + doubleSeed.hash + "/" + seed.hash + " on same port " + seed.getPort() + ") peer " + seed.getName());
return false;
}
        if (seed.get(Seed.LASTSEEN, "").length() != 14) {
seed.setLastSeenUTC();
if (Network.log.isFine()) Network.log.fine("connect: reset wrong date (" + seed.getName() + "/" + seed.hash + ")");
}
final long nowUTC0Time = System.currentTimeMillis();
        long ctimeUTC0 = seed.getLastSeenUTC();
        if (ctimeUTC0 > nowUTC0Time) {
seed.setLastSeenUTC();
ctimeUTC0 = nowUTC0Time;
assert (seed.getLastSeenUTC() - ctimeUTC0 < 100);
}
        if (Math.abs(nowUTC0Time - ctimeUTC0) / 1000 / 60 > 1440 ) {
if (Network.log.isFine()) Network.log.info("connect: rejecting out-dated peer '" + seed.getName() + "' from " + seed.getIPs() + "; nowUTC0=" + nowUTC0Time + ", seedUTC0=" + ctimeUTC0 + ", TimeDiff=" + formatInterval(Math.abs(nowUTC0Time - ctimeUTC0)));
return false;
}
final Seed disconnectedSeed = this.seedDB.getDisconnected(seed.hash);
        if (direct) {
seed.setLastSeenUTC();
seed.setFlagDirectConnect(true);
} else {
if (Math.abs(nowUTC0Time - ctimeUTC0) > 120000) seed.setFlagDirectConnect(false);
}
        if (disconnectedSeed != null) {
/*
if (!direct) {
if (ctimeUTC0 < dtimeUTC0) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting disconnected peer '" + seed.getName() + "' from " + seed.getIPs());
return false;
}
}
*/
if (Network.log.isFine()) Network.log.fine("connect: returned KNOWN " + peerType + " peer '" + seed.getName() + "' from " + seed.getIPs());
this.seedDB.addConnected(seed);
return true;
}
final Seed connectedSeed = this.seedDB.getConnected(seed.hash);
        if (connectedSeed != null) {
try {
if ((ctimeUTC0 < (connectedSeed.getLastSeenUTC())) && (!direct)) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting old info about peer '" + seed.getName() + "'");
return false;
}
/*if (connectedSeed.getName() != seed.getName()) {
}*/
} catch (final NumberFormatException e) {
if (Network.log.isFine()) Network.log.fine("connect: rejecting wrong peer '" + seed.getName() + "' from " + seed.getIPs() + ". Cause: " + e.getMessage());
return false;
}
if (Network.log.isFine()) Network.log.fine("connect: updated KNOWN " + ((direct) ? "direct " : "") + peerType + " peer '" + seed.getName() + "' from " + seed.getIPs());
this.seedDB.addConnected(seed);
return true;
}
        if ((this.seedDB.mySeedIsDefined()) && (seed.clash(this.seedDB.mySeed().getIPs()))) {
if (Network.log.isFine()) Network.log.fine("connect: saved NEW seed (myself IP) " + seed.getIPs());
} else {
if (Network.log.isFine()) Network.log.fine("connect: saved NEW " + peerType + " peer '" + seed.getName() + "' from " + seed.getIPs());
}
this.seedDB.addConnected(seed);
return true;
}
public boolean peerArrival(final Seed peer, final boolean direct) {
        if (peer == null) return false;
final boolean res = connectPeer(peer, direct);
        if (res) {
processPeerArrival(peer);
EventChannel.channels(EventChannel.PEERNEWS).addMessage(new RSSMessage(peer.getName() + " joined the network", "", ""));
}
return res;
}
/**
* If any of the peer2peer communication attempts fail, then remove the tested IP from the peer by calling this method.
* if the given IP is the only one which is remaining, then the IP is NOT removed from the peer but the peer is removed from the
* active list of peers instead. That means when a peer arrives in the deactivated peer list, then it has at least one IP left
* which should be actually the latest IP where the peer was accessible.
* @param peer
* @param ip
*/
public void interfaceDeparture(final Seed peer, String ip) {
        if (peer == null) return;
        if (Network.log.isFine()) Network.log.fine("connect: no contact to a interface from " + peer.get(Seed.PEERTYPE, Seed.PEERTYPE_VIRGIN) + " peer '" + peer.getName() + "' at " + ip);
synchronized (this.seedDB) {
if (this.seedDB.hasConnected(ASCII.getBytes(peer.hash))) {
if (peer.countIPs() > 1) {
if (peer.removeIP(ip)) {
this.seedDB.updateConnected(peer);
} else {
this.seedDB.addDisconnected(peer);
}
} else {
peer.put(Seed.DCT, Long.toString(System.currentTimeMillis()));
this.seedDB.addDisconnected(peer);
}
}
}
EventChannel.channels(EventChannel.PEERNEWS).addMessage(new RSSMessage(peer.getName() + " interface not available: " + ip, "", ""));
}
/**
* PeerDeparture marks a peers as not available. Because with IPv6 we have more than one IP, we first mark single IPs as not available instead of marking the whole peer.
* Therefore this method is deprecated. Please use interfaceDeparture instead.
* @param peer
* @param cause
*/
@Deprecated
public void peerDeparture(final Seed peer, final String cause) {
        if (peer == null) return;
        if (Network.log.isFine()) Network.log.fine("connect: no contact to a " + peer.get(Seed.PEERTYPE, Seed.PEERTYPE_VIRGIN) + " peer '" + peer.getName() + "' at " + peer.getIPs() + ". Cause: " + cause);
synchronized (this.seedDB) {
peer.put(Seed.DCT, Long.toString(System.currentTimeMillis()));
this.seedDB.addDisconnected(peer);
}
EventChannel.channels(EventChannel.PEERNEWS).addMessage(new RSSMessage(peer.getName() + " left the network", "", ""));
}
public void peerPing(final Seed peer) {
        if (peer == null) return;
this.seedDB.addPotential(peer);
processPeerArrival(peer);
EventChannel.channels(EventChannel.PEERNEWS).addMessage(new RSSMessage(peer.getName() + " sent me a ping", "", ""));
}
private void processPeerArrival(final Seed peer) {
final String recordString = peer.get(Seed.NEWS, null);
        if ((recordString == null) || (recordString.isEmpty())) return;
final String decodedString = net.yacy.utils.crypt.simpleDecode(recordString);
final NewsDB.Record record = this.newsPool.parseExternal(decodedString);
        if (record != null) {
final String cre1 = MapTools.string2map(decodedString, ",").get("cre");
final String cre2 = MapTools.string2map(record.toString(), ",").get("cre");
if ((cre1 == null) || (cre2 == null) || (!(cre1.equals(cre2)))) {
Network.log.warn("processPeerArrival: ### ERROR - message creation date verification not equal: cre1=" + cre1 + ", cre2=" + cre2);
return;
}
try {
synchronized (this.newsPool) {this.newsPool.enqueueIncomingNews(record);}
} catch (final Exception e) {
Network.log.severe("processPeerArrival", e);
}
}
}
public int sizeConnected() {
return this.seedDB.sizeConnected();
}
public void setUserAgent(final String IP, final String userAgent) {
        if (this.userAgents == null) return; // case can happen during shutdown
this.userAgents.put(IP, userAgent);
}
public String getUserAgent(final String IP) {
final String userAgent = this.userAgents.get(IP);
return (userAgent == null) ? "" : userAgent;
}
/**
* Format a time inteval in milliseconds into a String of the form
* X 'day'['s'] HH':'mm
*/
public static String formatInterval(final long millis) {
try {
final long mins = millis / 60000;
final StringBuilder uptime = new StringBuilder(40);
final int uptimeDays  = (int) (Math.floor(mins/1440.0));
final int uptimeHours = (int) (Math.floor(mins/60.0)%24);
final int uptimeMins  = (int) mins%60;
uptime.append(uptimeDays)
.append(((uptimeDays == 1)?" day ":" days "))
.append((uptimeHours < 10)?"0":"")
.append(uptimeHours)
.append(':')
.append((uptimeMins < 10)?"0":"")
.append(uptimeMins);
return uptime.toString();
} catch (final Exception e) {
return "unknown";
}
}
}
