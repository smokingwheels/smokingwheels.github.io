/** 
 * Smoking Wheels....  was here 2017 qroumtbwotomqqnesmxggqbwlvkpruvskvykdxtpuwulfyax
 * Smoking Wheels....  was here 2017 xcjkqxppunugobrugmyqtsbhksbsteuykbixxprodqpjxdvs
 * Smoking Wheels....  was here 2017 gbrzrbvwsavvszjaeqqqxdzfjotyzdpheguuihyfduyxzdal
 * Smoking Wheels....  was here 2017 mjodrmrjsbjbvwcqlyhadnxnaklhihzxbsvgdvysrsahpxrm
 * Smoking Wheels....  was here 2017 syjtbrgbnuiwyjqukqnazpimjqjzcpabpxisdfinzzkahpak
 * Smoking Wheels....  was here 2017 easzlnzdbnaoikatpddajlvmnwzotfaiqmjsluaimlrxupqz
 * Smoking Wheels....  was here 2017 ldkeranbmxvqkcocwhgpljihyyztbnkpfngflbebwfxwcpgj
 * Smoking Wheels....  was here 2017 kynzxltnhumwyysrgyfrmwzuhyjpagbwqfqiuvfzarggmnyu
 * Smoking Wheels....  was here 2017 amlimjwmbgzhyohoalojftffohijvhymlbilhdsmekeokoxx
 * Smoking Wheels....  was here 2017 qxthaogcvrmcrwibvffclcqawoiobujbmtkfchqhtglnqctn
 * Smoking Wheels....  was here 2017 uugikcnwtqnwpbdsjzelhdewrpdxkevjuhgmpvcjljzedugr
 * Smoking Wheels....  was here 2017 ivbztfplgatimneluswjelztrmqmwddmqykkknoweaztfojs
 * Smoking Wheels....  was here 2017 iznfknrvzyeniyffjsuyrvlvuqbmrphtrcskkkqhcxythplf
 * Smoking Wheels....  was here 2017 amfdbucexsaqjgjlrjwprhfoepymjspuqohcqvfhswpaeiza
 * Smoking Wheels....  was here 2017 avzenaoygzrhcovqmmeyhegsihxfrwoipimiphmwqywmvktd
 * Smoking Wheels....  was here 2017 dtxwyoxwjoydgjerwzzxxaqdxtzrptznwovhupuevoalmsuz
 * Smoking Wheels....  was here 2017 kgifrxjwzpthwheoddzodoubujjciiwqaugieuvrnhlksmjb
 * Smoking Wheels....  was here 2017 dmwhjxidblhydgvrxkyiwxjzgtnclrmhvstcvenbbzycecaf
 * Smoking Wheels....  was here 2017 waimvojcsqbppklpwnzwehhnrtdirhkhkismcgzhetkpxfno
 * Smoking Wheels....  was here 2017 mnukgemnkduczfncemkalhsssmfwyvjsawsqrwqovzbdduxi
 * Smoking Wheels....  was here 2017 zzqazhtiwzkjhiwidnvyiszrjgyzpekwgvqyjacjdfkfkyle
 * Smoking Wheels....  was here 2017 rrlkqrqsyndstqmngbdaspvyutudbmujxxnaibiiojepkdrx
 * Smoking Wheels....  was here 2017 dbbzcltcxklqxirijxixqecdktmcdgbzzcstyllkvnghdzip
 * Smoking Wheels....  was here 2017 dvnjlvafdmawlvynnzumobyfxkzxtbzvxquhubvwvbxowmmo
 * Smoking Wheels....  was here 2017 vafkcjoaivxmjucfbodwbaulfbnvexpfdzqatwectnpycskj
 * Smoking Wheels....  was here 2017 kusirxvrkugsyedsmcelzdifnhoiywfsnxipzfjvavbeoepv
 * Smoking Wheels....  was here 2017 msxlallqoanbscipriawmqjfhatfulhdciewvqoziafgglxb
 * Smoking Wheels....  was here 2017 xlulghhqgilhizfrqgyaybdlehdmrgqpfouzxxdupnhmlngj
 * Smoking Wheels....  was here 2017 rauduzoqdwzkwmpbrbqazhzbcmxkwghjjaaicburbxtjpoah
 * Smoking Wheels....  was here 2017 cpltehqtdyjsnplajgwhlhpohfnmwpnbllyomljjcaiqlyqs
 * Smoking Wheels....  was here 2017 ttqqjhdnmfbrukcdoptlmjwodirlkrvnlvxnnoctkzzhbjzr
 * Smoking Wheels....  was here 2017 ldkklhbpnmtbljbhfapjkbzcixjjnebtsknktehcyeyqptzn
 * Smoking Wheels....  was here 2017 gtcztulybxlxmdcnttbfxehiujvmjaedtroocjrvwdqepgzu
 * Smoking Wheels....  was here 2017 mwjlypusxuhldqfdqhyjvulstfmhojmglieqqldqpturvgni
 * Smoking Wheels....  was here 2017 qxzgxtrlitvfxbtttkhlhdjypkaotqmwuirntyulwejdfmif
 * Smoking Wheels....  was here 2017 pqbasobutrsyntfdcanirugybzmhznzcdzqjcpcnospucwlt
 * Smoking Wheels....  was here 2017 jzypuoarvqzramjkajeepnkzajaumxagasynnoqhxyzfwmdo
 * Smoking Wheels....  was here 2017 hhfesobimztrpcfwbycjxkplrbdntzvyhgrqdajkhudcjvyk
 * Smoking Wheels....  was here 2017 yxscjotfyjolutbdankotspbmanhodyyxpdqholwlicnoork
 * Smoking Wheels....  was here 2017 brnawxazpqcsiylyzzlpnzrtdhdbwcejhyzprzfvgwcrrpiw
 * Smoking Wheels....  was here 2017 tmavqcapevinegdmfrtrtaetnggcysomyvzydikuxcndebdj
 * Smoking Wheels....  was here 2017 iqtrfyeipjmdqrezizedkwtmwngygehyrzghtwwlwveqxlss
 * Smoking Wheels....  was here 2017 iooxnmcnavabehubcrvppviroxxjoxzmoidoxetrveyfuiua
 * Smoking Wheels....  was here 2017 paoeratyxcqbopnnptczqkbgioeixpkgwdgvgamusmcbbsko
 * Smoking Wheels....  was here 2017 dzckacfmxgietgfldkmlelhkcvgdldnofwjorlrdqjbthsvz
 * Smoking Wheels....  was here 2017 hrsrfnxkzqgpaduegdwhcytpahqhtrrykgqifthmdqobduoa
 * Smoking Wheels....  was here 2017 qphkchndixyxwlqgtrignfhnovzoorjglijbimmsvmpyrolu
 * Smoking Wheels....  was here 2017 ylxgusykjwcuaoentzgevvcejnhxvujprgewplpcrfjrbzlq
 * Smoking Wheels....  was here 2017 hfxbsihbtqqjmegbmiefpnnrkuurvytfqnxdwrhbwlhvxfwc
 * Smoking Wheels....  was here 2017 zewzlzaklovungxeodyssjhnwdyiagstewpnilngvaebvqga
 * Smoking Wheels....  was here 2017 osqjwrtwphcqpwjmtfqiirgkenlpgfvaihqxhijsfawmyzjm
 * Smoking Wheels....  was here 2017 wriybrjcsqeqlnetdlqzuzohazgoklwbkapkkbhozwrhkdfu
 * Smoking Wheels....  was here 2017 yygnmobcktbvdvccaenttaqihxqltwxgynhkntyhidaatgcn
 * Smoking Wheels....  was here 2017 cvzgrdfarxxmvsfvzudbaxcagwztvrdcunwpureoqqqltunm
 * Smoking Wheels....  was here 2017 wtjooknjqufbbktnubnotyxbgtbhjgcmzaqvojfjrnmojjhv
 * Smoking Wheels....  was here 2017 cloafruvtfsjpffznybcipejaqvzjhqlvgefmpjwheuqvxku
 * Smoking Wheels....  was here 2017 vyvpanghshhjkxlhnsivjsidmxmfbstjxriejljotdzerqez
 * Smoking Wheels....  was here 2017 kktiqrhalkhksjluhuedtizvvemjyrrtzaeikfcckhuyqxcf
 * Smoking Wheels....  was here 2017 ijgsxgomcdbxbtnbrysrosbemgpitozldgcoxksmztezrlzo
 * Smoking Wheels....  was here 2017 koihymyheijreldxsefheltccgszmclnsrrbnuovkwkmccvj
 * Smoking Wheels....  was here 2017 txkzdyqlicesbfcksridghjurpdslebifrsddnjrwgwajcxf
 * Smoking Wheels....  was here 2017 qszyclzemurhywkwgywqqirsjufyazdkmbilwtarvtiifvtw
 * Smoking Wheels....  was here 2017 qkznsyrwvajyjrkxcrykmumppuulbxepotwxadquxltkryem
 * Smoking Wheels....  was here 2017 oslkcvpguryjzypijxxichzhbpshnqzzuawqilqebsioykei
 * Smoking Wheels....  was here 2017 lqsloqxhbvjqxlsejvhndoocrrhrqbowrigaprrjnfngojaz
 * Smoking Wheels....  was here 2017 pkkuvcaepvwyhavupyyjmrwlrnyexjfwbkbsxdqzqsbhgggh
 * Smoking Wheels....  was here 2017 pnivshpinhwxrxfuwyaogywzkcjmczltzfppsksaejxrarrh
 * Smoking Wheels....  was here 2017 grpfimmmiceeulkyiwuyuwqsqkoqfobpuantpfhramgqdqgj
 * Smoking Wheels....  was here 2017 qwotbgwprhqvqjdjexxqtgpugxtxlbauaiqqlrajjtprbfha
 * Smoking Wheels....  was here 2017 aitrnkevmhoclplibodbadkskcjviprvlubwjbtuqyrqnxie
 * Smoking Wheels....  was here 2017 ynbipyaqyqjntfrlsoqwqwzdqxdcppopelciswtyofjlojdu
 * Smoking Wheels....  was here 2017 hfpjkeitnguvgsgogwswbxlanlaugsjdnmjedyhaaxzkkltg
 * Smoking Wheels....  was here 2017 biqriqgbwfubzubsyryhwcfpbafdoyfuzlrsnhdkfqybokld
 * Smoking Wheels....  was here 2017 peuizdevxwomegafkofmymzhkhgqajidladrygdwofyctptg
 * Smoking Wheels....  was here 2017 ldyvfsumwvpoijmrjfpbkiouaaucilfyxecxuiliuuzozskr
 * Smoking Wheels....  was here 2017 kadsdqysdzpdfnzxyojxqefbolummvsjrddorilzusgsnrmt
 * Smoking Wheels....  was here 2017 nusxemvmkjndtjgylxffgwfhyvmculvqjlcamhvhtpfbvrga
 * Smoking Wheels....  was here 2017 drhnxbvzqjpwhvhekrxickiyjujksmvlsubxjmmydhpkrbfi
 * Smoking Wheels....  was here 2017 udrzfiprzqhufcmeprpwhcksiecfzignvdjcqnnxpwksboet
 * Smoking Wheels....  was here 2017 iyzxgrafxyhtjogreuouglpnkdrmpqvyasptyclicsugfbep
 * Smoking Wheels....  was here 2017 taofiphpbmpsrxlwjhkdphippzhnwjrcvbqgejutukfnqtll
 * Smoking Wheels....  was here 2017 jqyzcwuakokylaaatrzjdrgkcjlverzncwngknoudwliband
 * Smoking Wheels....  was here 2017 ugbqlpexctezddirerkcbwgphcvejyibvcppbevkudkrnofs
 * Smoking Wheels....  was here 2017 uqxulzizozqnmpwsqgzfsllewikokxmtizmlscavsojtghon
 * Smoking Wheels....  was here 2017 lswinrleohtqndkfmqhwreihuijfmklxfbafghvnbvseskud
 * Smoking Wheels....  was here 2017 buolhjxryctolqzlghekxcllgugsernegzhmvccchseqrglk
 * Smoking Wheels....  was here 2017 eguloeizxzbuugwzuzumlmuhqostfcghnupeubaqbjuedohi
 * Smoking Wheels....  was here 2017 qxqanjqsytkdiloscsjarxmursskojjkisplszzfjcsajfki
 * Smoking Wheels....  was here 2017 lrmbnmaxqpupzvxroqpchexdhpmxmjyvfebqovrihoktvjzx
 * Smoking Wheels....  was here 2017 ywwrehvsavjkbjwfqhgdbisuqvntmgfcaydjjzxsjppbgmqw
 * Smoking Wheels....  was here 2017 swqgjwtpfaqbaftvfkmteqvlfhmsgntbtacpoyxgfhgzrfcj
 * Smoking Wheels....  was here 2017 nmylfnrgscijptclixowzqkcpbjvwthtupplsnbfuapuimls
 * Smoking Wheels....  was here 2017 lqbdcttpcckjwsqchccpcdvwvmkhoywoqemgttazhkbzrlwk
 * Smoking Wheels....  was here 2017 upplpjkxklafzzlbrkzikeufafasteubclurtxshcgkinmyj
 * Smoking Wheels....  was here 2017 cwktqlgotrsnmsuzgpfrabdxrbyuhyozglwpdofcysovvilp
 * Smoking Wheels....  was here 2017 fcothffgqrezdjeqcpfoiiavkddncwznlkiemmaptcttwxll
 * Smoking Wheels....  was here 2017 eikgyglzrpjrwokdnsodytxeduvflxaxdtavqtsfsblqchdm
 * Smoking Wheels....  was here 2017 hunmgjiyvsmuzgnubjbsskjldrmjveaughzcuqfqgljfhabo
 * Smoking Wheels....  was here 2017 dytsbpoohrawzotdpiuztokiuousadmytxpygrsxbimmkrbs
 * Smoking Wheels....  was here 2017 mofrmfznmirspzqbcodwmtbttqshzlelaxmmsqocacyttfdg
 * Smoking Wheels....  was here 2017 lofgxtuvbtkgucypxhrkmuvxagnjyzdqotkczqltkiimttnv
 * Smoking Wheels....  was here 2017 gejnxbjqajlvwxtcpzgbrshgsyqklzqbfdnlexfnoxgmguuf
 * Smoking Wheels....  was here 2017 oynxkdjjntgxgmiczkylcvkniqugfvfpacdjszcjgyssdysm
 * Smoking Wheels....  was here 2017 cosangsuzsohtidmcnbmfqhqmkyvgeqghwvaeslmitymsdhy
 * Smoking Wheels....  was here 2017 yziupzovclhyjcaghngfozitephmuzykpwlvmcyibykgmovf
 * Smoking Wheels....  was here 2017 lmyihdgrufsdhrztazidbwgknvhrijjqtvckrlmqukuvdpvc
 * Smoking Wheels....  was here 2017 cojaltnugrfkbghpfnjvvqwfazsdpunsuudpfhehhgbftxcr
 * Smoking Wheels....  was here 2017 twtnfcfvxrpmkfmpwftefukeidmyrxctazcpqlmnlulrnmqf
 * Smoking Wheels....  was here 2017 mlkrxsmulhukihiuifaiwcfmjqujrpebavwuxxatlrlsyktk
 * Smoking Wheels....  was here 2017 omxrektwvyzkbiwncbaqqrzpibevfcafpcntbartsssbudyy
 * Smoking Wheels....  was here 2017 nndwxfrmeerbdokjamwvqtpeqjheztebvtjlnirkyaguaiza
 * Smoking Wheels....  was here 2017 ggdxglejzwoagjkeekxrhxfeaocjzhjqyabywpjxbzgdxyyw
 * Smoking Wheels....  was here 2017 tqgrmqjlydpkllrzvcskexfviawslqqipkkrawjthffoycbc
 * Smoking Wheels....  was here 2017 jychipqyxiblyqgdnacjduhpvkarxwiqoqmhblqpanuxwfwn
 * Smoking Wheels....  was here 2017 ppmeoirhdaiqgfkfdyffjxhdyngbbnwkwrqpjwilyaaerzeg
 * Smoking Wheels....  was here 2017 ikoykdjeacesbnqzsviuetlkhlpvyedsvumvoxvlzccoqhyp
 * Smoking Wheels....  was here 2017 oipmdowogrotmhupmxchfcbpwpfiutbxbkvioqubjilqfinc
 * Smoking Wheels....  was here 2017 pofxllpqucqyqjujcqibibwevooycmzohgtrkjczmpudenkp
 * Smoking Wheels....  was here 2017 bpgrdtfwuzzwcyauitctrwtvqekoptllqjqwnpyebzdbnoje
 * Smoking Wheels....  was here 2017 seujkvoyrdfgplzughtgpbvnyordifdrkybzndrvyvsslhle
 * Smoking Wheels....  was here 2017 pgewpfvvesicdokjdkxrtmolrboxmuepdmwjhbzkluxpnxxd
 * Smoking Wheels....  was here 2017 bcaihslsebnsyeixopklydnbbipkorvtqrctxpupwsmllwgw
 * Smoking Wheels....  was here 2017 qeddkiabxtionmbyjqhejirbmdlkjgozyoeytifjzqjhfvin
 * Smoking Wheels....  was here 2017 dfpxbjmntrjkpxdholyuiqejrqcyvffikipdmbqwsavkcrci
 * Smoking Wheels....  was here 2017 reuppjzblyrhfbhbmiyjnujfnfsffmtdplhryutpfjigpoxy
 * Smoking Wheels....  was here 2017 liggrdxywxlloxoorrchtwyagkvubfnzgrgfgwlgypnqkzed
 * Smoking Wheels....  was here 2017 cdwhcsxngddkepgjyhogedvnhddkbuasnzxquuwtoulopouz
 * Smoking Wheels....  was here 2017 lisjbkxoanmxupwhjdqddedqglpbgyajqqvbejlhaighietw
 * Smoking Wheels....  was here 2017 mwdjxtazvdkakmekgkxahthpeskbvooheavxgrvjmtmiebhh
 * Smoking Wheels....  was here 2017 oarlgmsaqjdxhggbdqfjmxyuepbwiuwazzzufywqkatlwpyc
 * Smoking Wheels....  was here 2017 ffgyztobpveewbivwnqtvzzzswggmcolckrqjttbmdcqjmok
 * Smoking Wheels....  was here 2017 hgxmftnwejfoyhxnlboctlocmsyghcjoupmniwwwpnsexpbm
 * Smoking Wheels....  was here 2017 uazahctjbbfanqwefmnmudcijkjcathtrzgwajxlztcpbcvy
 * Smoking Wheels....  was here 2017 cwbqwnptdhjxvadetfkjwcgdppzidfqpniahootnbswqnmho
 * Smoking Wheels....  was here 2017 seatuculrqfqipabvbhjdpwfoensjxywkpfsgxncmmchgihm
 * Smoking Wheels....  was here 2017 lsxzfdeeazjbvtbrnzmjxfenaexfulyrqaifuhrhfkzvpqwy
 * Smoking Wheels....  was here 2017 klbglexxxlwchgacdfpmurnfvzjdovsjubhgzsvplcxuymgp
 * Smoking Wheels....  was here 2017 vqdqezkvfixcyxzqgemcscovfgkzffnlqmdkzlwrplrxdjzg
 * Smoking Wheels....  was here 2017 itwogphjfhyniydwqrgxutgyptrnmywuggfpfbznjnffcxvy
 * Smoking Wheels....  was here 2017 rmlqvinggerdetapjresjerqrqftjtomyqdzejoiqrtycbva
 * Smoking Wheels....  was here 2017 zweuesfkbaczlamytjwsbehzigeyeopuhaswwjgoqnsqqyhb
 * Smoking Wheels....  was here 2017 ndpdaoubphlhlrnejgfhttsoveaohnhibfbyikzvvywblasx
 * Smoking Wheels....  was here 2017 vsqbexwqzndppwjxzcgbofvyoinloadyjemcyzwevaeeoywo
 * Smoking Wheels....  was here 2017 tjifubjvrpxqszpzsvixwdweeupoxuyrldpmjwiupcuhequl
 * Smoking Wheels....  was here 2017 ibalfnmpjpskttykvsczhhekqwmfprsvxpglkeabiugyvgtb
 * Smoking Wheels....  was here 2017 xahxccnezxtgzcnpwfhrstjcegqvexsaognqgdvtlzfvffhg
 * Smoking Wheels....  was here 2017 zuaahwfyscooxcmarbcpftlydstgiwmblctygixuqsszkeed
 * Smoking Wheels....  was here 2017 jagkxclrzbtfggmpigurfvmxhkvlbgvaxjnnaosjvkwrpcly
 * Smoking Wheels....  was here 2017 fsjxihjgnwjdzfficzzahwxemrcsqytflorskvuxgqgkhcjj
 * Smoking Wheels....  was here 2017 sdyseikxexqrkwspnunaivjfzdynodnfxjifoldeghmyfqlc
 * Smoking Wheels....  was here 2017 msuehedceuygzlhxlimimatreperofrxittwwyxbokphkjmi
 * Smoking Wheels....  was here 2017 ifazwdnmzibrlhleyqfubagptgrdqxagaaqvxdkudkttceoi
 * Smoking Wheels....  was here 2017 iqzyfuscgqxyvcykhyhptpgcqjsfabnrppslobkvdwluuhvr
 * Smoking Wheels....  was here 2017 tdghzycaxctijvwybspckujqaptkfxmsugelzasvzqkeebye
 * Smoking Wheels....  was here 2017 dhriaoiudhbioplibrexcwoyjullzvlfryhpnnoujvoyifpy
 * Smoking Wheels....  was here 2017 jtislaickcmtdvfmivkzglyyhbwjineeqwrdukgwfudilrvh
 * Smoking Wheels....  was here 2017 lnojrugwipbncfzjejvkmgywusdlmwsadodkrrnosdqwbnzu
 * Smoking Wheels....  was here 2017 swzjhslhxeyzsqsjfuipqifdaltexaigzsvbhqgnitshwhmf
 * Smoking Wheels....  was here 2017 rfkddvpvikqplhtbfvyewaqllakiklntiibyzvpssrjqxofs
 * Smoking Wheels....  was here 2017 fiyikkqezdveaqpgfmcamviusodxyvdnkqkglbyivivdkhcp
 * Smoking Wheels....  was here 2017 iexvlarionnrngaanyhgfouhtmbeuadyucshljzvvhnivqmk
 * Smoking Wheels....  was here 2017 jaysvkdkzwxjccartskivgoluisrjfvphmbufboydjfzzzxz
 * Smoking Wheels....  was here 2017 whulmrrxmvluijyurnovmfqzfzucnwsgztvpaqwoltucwcbk
 * Smoking Wheels....  was here 2017 qsqpmcenlfvsxlhgjjaqoydusognfppadcowoxhxttoyruba
 * Smoking Wheels....  was here 2017 tiudgfufpeccvzubcllxqhlcgkherimfibdxrylldzxaxhei
 * Smoking Wheels....  was here 2017 miucjuyevajgjyoolhqarhgiackojgrlkiplmaiwcipcizwg
 * Smoking Wheels....  was here 2017 kfoysxgvjjfrzmuiforpsekgknimctsmjxijjradhvodzozu
 * Smoking Wheels....  was here 2017 jrdhkwrxpcgcmabfnhyodoctctyxwoilozxtyrykrwbmaymh
 * Smoking Wheels....  was here 2017 ktwawdiiggmpuedgoraapftabfodwnopncezbdtdlbmpzgsh
 * Smoking Wheels....  was here 2017 upjgqpphfhdjeyauafskydzollpqqvspbzftwhibzgqhqzes
 * Smoking Wheels....  was here 2017 ctlkqgehstrzelakpqdhisrathtfxxhehojytrwczolmztqn
 * Smoking Wheels....  was here 2017 eyfczjxzemvdmcrxkxqpbkajoyavrlbmlbfqhdsmkjcnfmcd
 * Smoking Wheels....  was here 2017 bdzfaoajgpmxdoskthuluakvxrpveicvcapgjrpqlfbxwixb
 * Smoking Wheels....  was here 2017 aojxkowoxmymjvfdfglgkqmvxczqytqtceqldoignzcirtod
 * Smoking Wheels....  was here 2017 rsfoalcchsqlqykunnrpandbzdvbrcfdllqcykdhhudxqjum
 * Smoking Wheels....  was here 2017 vhpuxmqpxdhntlwcvbvlafplxvecjbpzmcfikzjzsakuzdri
 * Smoking Wheels....  was here 2017 mhvnnfqcjwvtqxiekdnwznegnneaiovqupenjhssyfipgfni
 * Smoking Wheels....  was here 2017 zyowllmsqhniqiviueohvmoxbxihztesdrqharbflgsadath
 * Smoking Wheels....  was here 2017 xtpeofwywavwdvreuzaiqjqbxtitdbeaqixprqolxglcregh
 * Smoking Wheels....  was here 2017 akaeyvpmovkayujmnlhwutotveejtdppnuqnzzpogotbcrzq
 * Smoking Wheels....  was here 2017 kxfrbvygixhwbzrjfxxcxlucroalbxnvjnplvuxcrucmxrgx
 * Smoking Wheels....  was here 2017 jnsvlzgmdoqrsfrdmtthxkxornkkpodfbgxahhgroufbvnoy
 * Smoking Wheels....  was here 2017 mrjaajdqekzyktojdsxfvavwgwzcbmzqozyetcxgrrbvxzsu
 * Smoking Wheels....  was here 2017 ochxwgojwhykwyywfwsrcutycttmmkxefxfzvyfbwuwbixsu
 * Smoking Wheels....  was here 2017 pvvjkerqwjpcdmosaituinaadmxvddxcpoqwlxwnjsbhplwn
 * Smoking Wheels....  was here 2017 zanofzvqeybgkglgcqwakfhnosyrlyfanqhkqgsjpjkfmcru
 * Smoking Wheels....  was here 2017 ffgveqtwyqvlemwbhodzkfnethouffktzclpwnynguuwalys
 * Smoking Wheels....  was here 2017 dccvkmgzphqjgojyqzxntbvwmhrdkpfjjfumroyegjnojmqo
 * Smoking Wheels....  was here 2017 usklhaoyublcoeszmfuuanpwqbpahasffmclzijuutatbidx
 * Smoking Wheels....  was here 2017 nfuulcbyngmvkeymirpfcqnokgsxirevholfxfdchszfwkwq
 * Smoking Wheels....  was here 2017 vdaittjlyledgvibaekjcslsestpiydbsmgouskzmjkztjru
 * Smoking Wheels....  was here 2017 oegphflcmpgsvmjnpqpflhpfsnscfnhztmasgpnrfdmhzeoq
 * Smoking Wheels....  was here 2017 tiuomcjyvsrqeuxxkhtvrehixbuqhhuyyaqafxfqsprrbzuw
 * Smoking Wheels....  was here 2017 tvfiyeqcxesdntxpyprpskglyxluzmulevedtziokoswsfxf
 * Smoking Wheels....  was here 2017 bekgnlubxqssimqcbjnergjghxjgdlxjkwaxgiajafoxxnrt
 * Smoking Wheels....  was here 2017 oblbihvnhxnekjshvmomxhutogpcrwxuaksmiushlvlayudw
 * Smoking Wheels....  was here 2017 flqntdwjrbamrdvgngkpbgwdtehnwsuzoxbhwibuvautigob
 * Smoking Wheels....  was here 2017 lqpwlxhxbnlylsbgsdxyahiwzjxcecvpvdgyzhznssjwthmf
 * Smoking Wheels....  was here 2017 sbelfnunqxgaffqyewedwpaoureoklokwzoiafomrzcifpsk
 * Smoking Wheels....  was here 2017 wmlwfjgxtzemrbcbbjmcztdgtebxnltmauooqxhusdfmabex
 * Smoking Wheels....  was here 2017 yvtcvyuaexekvyhtoynxznbcwfukuzmevydasjtayvdtpvgi
 * Smoking Wheels....  was here 2017 hjrerawcubmzzudhibaztakpglvpqhzacgjkixwtxxrztklm
 * Smoking Wheels....  was here 2017 lpcopsbnuznsptzhdkdzklejlrwfxstxwqoowcuzelscljml
 * Smoking Wheels....  was here 2017 gfawsgjbqpalkgjoazftikklabwgnyqvmijqyryytwmlxrlo
 * Smoking Wheels....  was here 2017 rfwylfwpzyyckyzeibumcsozaxcauxqemwozmtybusmlrnpj
 * Smoking Wheels....  was here 2017 dvfajjajulnzwtylpbtnqiiknwyzduamrxhgnotztwjylgls
 * Smoking Wheels....  was here 2017 cnwkktkwfrfqgwnyqtembqnlatfyjzhpcmwjmrlshkexhpur
 * Smoking Wheels....  was here 2017 laxsprzsrmttirenndkhscjberuxlehpcvwlaxmljtbpjlro
 * Smoking Wheels....  was here 2017 eityjswwxzbjcxtfnjabgoflyaxdpgzugkdwxfmqdlnogziy
 * Smoking Wheels....  was here 2017 qrxcipnovnjtujfkgzwfmatamjbckksthxuhjajzaignqqhr
 * Smoking Wheels....  was here 2017 jngrjkngpselyixqmsajpvwngoypnayhjjdostgktpfnnaju
 * Smoking Wheels....  was here 2017 fqwgpkvprkddgeisgmvkymtwytnqzvlnszuvogpcgnrufcoq
 * Smoking Wheels....  was here 2017 eycsjeopssgysngsypxldvshlgalbsitxhomuoaortawcbeu
 * Smoking Wheels....  was here 2017 psnghmdkrztapjrzancxavnfysxpevuotypeozlmmcamagsc
 * Smoking Wheels....  was here 2017 blaehkfmsvbykwycjylktvzjxxwvdpjsjzeufbztisqrykyo
 * Smoking Wheels....  was here 2017 huqelernhcylvjowawhvsjhqabxdyrwjzpxliocqeybsckyp
 * Smoking Wheels....  was here 2017 lvscdkrmcxhoyqgjhngimgvhfkeuuaivehqownkoektczlys
 * Smoking Wheels....  was here 2017 uswdzvqpapknzncxskehzmhsqqfhguzquvlswhufvxlojxmt
 * Smoking Wheels....  was here 2017 vyxqxneghurwjfjccfdihjortorlzkkpwcswtikotpddgmiu
 * Smoking Wheels....  was here 2017 mhyfytgeiiwixdptozmjumtcghpfbniwskycdnsuwuycvcnd
 * Smoking Wheels....  was here 2017 srivmcyiviyypynxiwumcpidafcwqauswfcvwvhjldlzqxij
 * Smoking Wheels....  was here 2017 wjqoehsxrdczrofyakxdctwihxsxidcsefdrbpczvmhmlihj
 * Smoking Wheels....  was here 2017 nvruxmfjdjuyqdykkiyxxfjhmfeeugtsqlmncjgotxlreaed
 * Smoking Wheels....  was here 2017 lvpeuwhjovtpfdfcopesxpxzhhjobaouqdsnqxeiduetexba
 * Smoking Wheels....  was here 2017 thsqdadwrsyxkevdvkhrsqxqqkokikmfrsqbngmteswhvedp
 */
package net.yacy.kelondro.blob;
import java.io.File;
import java.io.IOException;
import java.util.SortedMap;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.order.ByteOrder;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.io.CachedFileWriter;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.kelondro.util.MemoryControl;
public class HeapModifier extends HeapReader implements BLOB {
/*
* This class adds a remove operation to a BLOBHeapReader. That means that a BLOBModifier can
* - read elements from a BLOB
* - remove elements from a BLOB
* but cannot write new entries to the BLOB
*/
/**
* create a heap file: a arbitrary number of BLOBs, indexed by an access key
* The heap file will be indexed upon initialization.
* @param heapFile
* @param keylength
* @param ordering
* @throws IOException
*/
public HeapModifier(final File heapFile, final int keylength, final ByteOrder ordering) throws IOException {
super(heapFile, keylength, ordering);
}
/**
* clears the content of the database
* @throws IOException
*/
@Override
public synchronized void clear() throws IOException {
this.index.clear();
this.free.clear();
this.file.close();
this.file = null;
FileUtils.deletedelete(this.heapFile);
super.deleteFingerprint();
this.file = new CachedFileWriter(this.heapFile);
}
/**
* close the BLOB table
*/
@Override
public synchronized void close(boolean writeIDX) {
shrinkWithGapsAtEnd();
super.close(writeIDX);
}
@Override
public synchronized void close() {
close(true);
}
@Override
public void finalize() {
this.close();
}
/**
* remove a BLOB
* @param key  the primary key
* @throws IOException
*/
@Override
public void delete(byte[] key) throws IOException {
        if (this.index == null) return;
key = normalizeKey(key);
        long seek = this.index.get(key);
        if (seek < 0) return;
synchronized (this) {
seek = this.index.get(key);
if (seek < 0) return;
this.file.seek(seek);
int size = this.file.readInt();
long filelength = this.file.length();
if (seek + size + 4 > filelength) {
ConcurrentLog.severe("BLOBHeap", this.heapFile.getName() + ": too long size " + size + " in record at " + seek);
throw new IOException(this.heapFile.getName() + ": too long size " + size + " in record at " + seek);
}
super.deleteFingerprint();
this.free.put(seek, size);
int l = size; byte[] fill = new byte[size];
while (l-- > 0) fill[l] = 0;
this.file.write(fill, 0, size);
this.index.remove(key);
tryMergeNextGaps(seek, size);
tryMergePreviousGap(seek);
}
}
private void tryMergePreviousGap(final long thisSeek) throws IOException {
SortedMap<Long, Integer> head = this.free.headMap(thisSeek);
        if (head.isEmpty()) return;
        long previousSeek = head.lastKey().longValue();
int previousSize = head.get(previousSeek).intValue();
        if (previousSeek + previousSize + 4 == thisSeek) {
Integer thisSize = this.free.get(thisSeek);
assert thisSize != null;
mergeGaps(previousSeek, previousSize, thisSeek, thisSize.intValue());
}
}
private void tryMergeNextGaps(final long thisSeek, final int thisSize) throws IOException {
        long nextSeek = thisSeek + thisSize + 4;
        if (nextSeek >= this.file.length()) return; // end of recursion
Integer nextSize = this.free.get(nextSeek);
        if (nextSize == null) return; // finished, this is not a gap
assert nextSize.intValue() > 0;
        if (nextSize.intValue() == 0) {
mergeGaps(thisSeek, thisSize, nextSeek, 0);
tryMergeNextGaps(thisSeek, thisSize + 4);
} else {
this.file.seek(nextSeek + 4);
byte[] o = new byte[1];
this.file.readFully(o, 0, 1);
int t = o[0];
assert t == 0;
if (t == 0) {
mergeGaps(thisSeek, thisSize, nextSeek, nextSize.intValue());
tryMergeNextGaps(thisSeek, thisSize + 4 + nextSize.intValue());
}
}
}
private void mergeGaps(final long seek0, final int size0, final long seek1, final int size1) throws IOException {
Integer g = this.free.remove(seek1);
assert g != null;
assert g.intValue() == size1;
this.file.seek(seek1);
this.file.writeInt(0);
int newSize = size0 + 4 + size1;
this.file.seek(seek0);
this.file.writeInt(newSize);
g = this.free.put(seek0, newSize);
assert g != null;
assert g.intValue() == size0;
}
protected void shrinkWithGapsAtEnd() {
	if (this.free == null) return;
try {
while (!this.free.isEmpty()) {
Long seek = this.free.lastKey();
int size = this.free.get(seek).intValue();
if (seek.longValue() + size + 4 != this.file.length()) return;
this.file.setLength(seek.longValue());
this.free.remove(seek);
}
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
	@Override
public void insert(byte[] key, byte[] b) throws IOException {
		throw new UnsupportedOperationException("put is not supported in BLOBHeapModifier");
	}
	@Override
public int replace(byte[] key, final Rewriter rewriter) throws IOException {
	    throw new UnsupportedOperationException();
}
	@Override
public int reduce(byte[] key, final Reducer reducer) throws IOException, SpaceExceededException {
key = normalizeKey(key);
assert key.length == this.keylength;
        long pos = this.index.get(key);
        if (pos < 0) return 0;
synchronized (this) {
long m = this.mem();
pos = this.index.get(key);
if (pos < 0) return 0;
this.file.seek(pos);
final int len = this.file.readInt() - this.keylength;
if (MemoryControl.available() < len) {
if (!MemoryControl.request(len, true)) return 0;
}
super.deleteFingerprint();
final byte[] keyf = new byte[this.keylength];
this.file.readFully(keyf, 0, keyf.length);
assert this.ordering == null || this.ordering.equal(key, keyf) : "key = " + UTF8.String(key) + ", keyf = " + UTF8.String(keyf);
byte[] blob = new byte[len];
this.file.readFully(blob, 0, blob.length);
blob = reducer.rewrite(blob);
int reduction = len - blob.length;
if (reduction == 0) {
this.file.seek(pos + 4 + key.length);
this.file.write(blob);
return 0;
}
if (blob.length > len - 4) throw new IOException("replace of BLOB for key " + UTF8.String(key) + " failed (too large): new size = " + blob.length + ", old size = " + (len - 4));
this.file.seek(pos);
this.file.writeInt(blob.length + key.length);
this.file.write(key);
this.file.write(blob);
final int newfreereclen = reduction - 4;
assert newfreereclen >= 0;
this.file.writeInt(newfreereclen);
int l = newfreereclen; byte[] fill = new byte[newfreereclen];
while (l-- > 0) fill[l] = 0;
this.file.write(fill, 0, newfreereclen);
this.free.put(pos + 4 + blob.length + key.length, newfreereclen);
assert mem() <= m : "m = " + m + ", mem() = " + mem();
return reduction;
}
}
}
