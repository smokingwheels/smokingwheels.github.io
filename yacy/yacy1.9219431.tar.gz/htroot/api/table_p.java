/** 
 * Smoking Wheels....  was here 2017 gurfchrawzfdsvfjutofghzpxobwsekwtukqkoxcvdgwlppu
 * Smoking Wheels....  was here 2017 zdmcwcgulhduyyigdjwphxpjojcevnbynetjuxvtyzoudgtb
 * Smoking Wheels....  was here 2017 vnlwsaihkyesdmdfwigxsddtajhjimandjihcsmcnchnxzbn
 * Smoking Wheels....  was here 2017 luixdvzoesrkjljhxqsuhcayxqfhqifyvqkikhkrjxibkgsw
 * Smoking Wheels....  was here 2017 vwcyxqlvgwgrdaxwmomebcsmapuxjkvwanlqzfkdqattotev
 * Smoking Wheels....  was here 2017 fcbvctjnpruoaryoaocfhsbcmxcolnicmsgqihnmpiadnkbp
 * Smoking Wheels....  was here 2017 aypvytmlevjjzbxfglgintcspknuanjseiuzgqcyxzqyrkjn
 * Smoking Wheels....  was here 2017 yepgzlxnkglqddmxdfzfniepzhrjnswehnhquoqaiiphrgge
 * Smoking Wheels....  was here 2017 auyvayxawzndxdqaycntitugnwliolazhxhseqzlabxllqdl
 * Smoking Wheels....  was here 2017 lbymanckjnpyxmnebridfovjfvyzbmgawdmqyrfegaaxcmsj
 * Smoking Wheels....  was here 2017 qnbjiufkakricwofgqfurphylbnxethkbixdytpmsjnobzyk
 * Smoking Wheels....  was here 2017 jxbwkojadofvphlgmbdiozneurwvhmanarubcetudmhjapzc
 * Smoking Wheels....  was here 2017 ogxscxvljevguwdpydjtuzaqccuwbbrxgrqptpkwsalqubgh
 * Smoking Wheels....  was here 2017 ltxtkdeennirjcvxcljdterymxkfkgqmkeeektrrrviypgmd
 * Smoking Wheels....  was here 2017 namfpwgyrjwieswassxzxlmdgadnmyphnclmwtvlsbqbvkoy
 * Smoking Wheels....  was here 2017 ltmmewbsdmvulpbbryzxbuumaponrjmtuuqjdxmrpcebdari
 * Smoking Wheels....  was here 2017 ezugzgytpcvvnzfiglvwgodjpaogqznlrrgbmvkblpbekshe
 * Smoking Wheels....  was here 2017 azskzilnuntmcipmwryzsjipcwgagmdfwoczlhqqplszumco
 * Smoking Wheels....  was here 2017 ifsdmsjtwlrcahqjhkbrzzlcwcajsuzejmctvknpqtsgrmzw
 * Smoking Wheels....  was here 2017 xmpwaduldtaemwzblqfrwmuelumckdarjqoipmpkkxzbufdr
 * Smoking Wheels....  was here 2017 ruhgjuzugojnwfoyospwjgxgsknfzzkiipxwccrvaoosyjaw
 * Smoking Wheels....  was here 2017 vkcfnxohygpewvqqcbtjuvpbtmfbizozzczuvbwvtqxsjwhm
 * Smoking Wheels....  was here 2017 xvmxuchqklvlijnyulkrqzxoyzzepcgthdrtnmjrhfowkyyz
 * Smoking Wheels....  was here 2017 nveuregxxcmvlvaaoxokrwfbuakigohzlzhrhrwujrmftabw
 * Smoking Wheels....  was here 2017 skfmzftfbgcepizfrsmmyuazfzkowuzhyejtjebxdssbhudb
 * Smoking Wheels....  was here 2017 svvxtoidtkqmlkpdojpcthdbgmbejmrnmlojgvbbyeqydfwq
 * Smoking Wheels....  was here 2017 xpngftujzcdbxsjpyptrpgqhgmstypcubvxeusfkiexqtnez
 * Smoking Wheels....  was here 2017 bnzyyqgwegzmcfxtumvvgrwwvaczyjdlvoqeyezneekftdfq
 * Smoking Wheels....  was here 2017 dohqrhywwawmkcexhfentyhivnyabeachehlatgbpseybsln
 * Smoking Wheels....  was here 2017 jzqflblwxtodovisyigxjpujhrmcetepelplnhbawurkvhot
 * Smoking Wheels....  was here 2017 dioxolqpkdhtkbvamqtkqlkzphbtlbhbkinvhwsqplmilzlp
 * Smoking Wheels....  was here 2017 gitcnjmbraivdujxvbtsiqlkingvghhugdinhutjqcmvohit
 * Smoking Wheels....  was here 2017 qagmcuilinjfcfwtfymrmklbiuyihwimcjnsuqazckudcxqb
 * Smoking Wheels....  was here 2017 nqiyidtgecfxzundctkojkgtrsholnwytuwujgolhfuvetbo
 * Smoking Wheels....  was here 2017 jskrnynejibfretyfggrnkxlrerawepgdkhkurrausbsgbnr
 * Smoking Wheels....  was here 2017 wagbeasgecfrjifhmmcusmsiahqpyblvlmcobgxcmgnuxhfz
 * Smoking Wheels....  was here 2017 anxubmrrfoickmxmerctyzfylndgiqpfdmuimocmklhjccni
 * Smoking Wheels....  was here 2017 znouepxzidhnlbyesjvtnmgyckghynmizgbdokieygrazlfv
 * Smoking Wheels....  was here 2017 hntfwzgvqkefltvevhzfzuxkhxihyttfxtyscxvirtkmxodw
 * Smoking Wheels....  was here 2017 qhenqltfkgktnoeqmloubakmqcbasnkgdgsybiflkigwovna
 * Smoking Wheels....  was here 2017 yvxhgbsjhwoxbqywxdvlvlkrykgnxfpbdhuzvhhihrjkwavd
 * Smoking Wheels....  was here 2017 mkdntdsvdpntskjnnwghoqqsimbclosmqpzgvobwqpdrybri
 * Smoking Wheels....  was here 2017 rnjjkhngzclnlqukckqttlepdfvglnnpoehlxhxizifledbz
 * Smoking Wheels....  was here 2017 hyifsigqegquifzrosxnfyinxrewjixvdixmatjegdkuhscr
 * Smoking Wheels....  was here 2017 gsbtmhegifukvkurecjnylraohaxujbswnjmnngemuvzcmhg
 * Smoking Wheels....  was here 2017 tauxtowohisiopmzibmwgoatdslrrikelnkxxlphbbxovjgv
 * Smoking Wheels....  was here 2017 ilavuqdgdfowkmllujabqbluyvwsdgqgukzkyostndgivqzt
 * Smoking Wheels....  was here 2017 pslyckaiewsppcjfnayswbfhrtvwpgsiejlxrgeaskshuqqq
 * Smoking Wheels....  was here 2017 qwdxmywbbhthloepshnsavwtbxgdsvtzbxeokbuwtnkvoeqj
 * Smoking Wheels....  was here 2017 odhrznexpzpzricgvsgiiahxgwgukqgddvzupuqgzitkjdrz
 * Smoking Wheels....  was here 2017 xbljvuvovmiaddnaqzwwikmsooektqwvkewhbnzjyahwossx
 * Smoking Wheels....  was here 2017 ijhlomvaftiwawdybdjbubtlpdsufbnladbyupjtnxzfvkxs
 * Smoking Wheels....  was here 2017 wcwnatmofxfjrvwmhmzvuirpeyqyljlpmgaydprdvrwtawrg
 * Smoking Wheels....  was here 2017 rmkodwjptiwovjydvmgintcvkqdfieacngospjxldfjaicsq
 * Smoking Wheels....  was here 2017 fbjsglixwqlsigtvkyxypfaeqdpcbmydbfqwxxkycqcvefzf
 * Smoking Wheels....  was here 2017 fpplwhjmytgjijzrxvxktstvlnokyndzjjmkdoscmixeetqq
 * Smoking Wheels....  was here 2017 rcziumumouxjhzpzqkoozqxhrezdtsvhwgqknzqrlyylfidr
 * Smoking Wheels....  was here 2017 uvvjaiflnejrumtjafiqqnfikvyrhskwhovjrxfqikocmzdn
 * Smoking Wheels....  was here 2017 zhprvkkczlrrtqwsuaxbffvvzgumtnpxpjbxhkuerujykvol
 * Smoking Wheels....  was here 2017 afcrtokkfpfwjircxuklluydarekojhrzwnzkwxvimhaojpd
 * Smoking Wheels....  was here 2017 wrgcpwopvspaztcwovyskofqhkzlipsvzrusiwjhkdjrxhtj
 * Smoking Wheels....  was here 2017 rxiuiqlesetehlhrfqdbkclczdiyyageflooodgogrbkoopi
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Pattern;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.CommonPattern;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.blob.Tables;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class table_p {
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final String EXT = header.get(HeaderFramework.CONNECTION_PROP_EXT, "");
final boolean html = EXT.equals("html");
final boolean xml = EXT.equals("xml");
String table = (post == null) ? null : post.get("table");
        if (post == null || (!post.containsKey("commitrow") && table != null && !sb.tables.hasHeap(table))) table = null;
prop.put("showtable", 0);
prop.put("tablecount", sb.tables.size());
        if (table != null && post != null && post.containsKey("deletetable")) {
sb.tables.clear(table);
table = null;
}
        if (table == null) {
int c = 0;
for (final String name: sb.tables) {
try {
if (html) {
prop.putHTML("showtable_tables_" + c + "_table", name);
}
if (xml) {
prop.putXML("showtable_tables_" + c + "_table", name);
}
prop.put("showtable_tables_" + c + "_num", sb.tables.size(name));
c++;
} catch (final IOException e) {
}
}
prop.put("showtable_tables", c);
prop.put("tablecount", c);
return prop;
}
final boolean showpk = post.containsKey("pk");
final String selectKey = post.containsKey("selectKey") ? post.get("selectKey") : null;
final String selectValue = (selectKey != null && post.containsKey("selectValue")) ? post.get("selectValue") : null;
final String counts = post.get("count", null);
int maxcount = (counts == null || counts.equals("all")) ? Integer.MAX_VALUE : post.getInt("count", 10);
final String pattern = post.get("search", "");
final Pattern matcher = (pattern.isEmpty() || pattern.equals(".*")) ? null : Pattern.compile(".*" + pattern + ".*");
        if (post.containsKey("deleterows")) {
for (final Map.Entry<String, String> entry: post.entrySet()) {
if (entry.getValue().startsWith("pk_")) try {
sb.tables.delete(table, entry.getValue().substring(3).getBytes());
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
}
        if (post.containsKey("commitrow")) {
final String pk = post.get("pk");
final Map<String, byte[]> map = new HashMap<String, byte[]>();
for (final Map.Entry<String, String> entry: post.entrySet()) {
if (entry.getKey().startsWith("col_")) {
map.put(entry.getKey().substring(4), entry.getValue().getBytes());
}
}
try {
if (pk == null || pk.isEmpty()) {
sb.tables.insert(table, map);
} else {
sb.tables.update(table, pk.getBytes(), map);
}
} catch (final IOException e) {
ConcurrentLog.logException(e);
} catch (final SpaceExceededException e) {
ConcurrentLog.logException(e);
}
}
prop.put("showtable", 1);
prop.put("showtable_table", table);
ArrayList<String> columns = null;
try {
columns = sb.tables.columns(table);
} catch (final IOException e) {
ConcurrentLog.logException(e);
columns = new ArrayList<String>();
}
final String[] row = CommonPattern.COMMA.split(post.get("row", ""));
for (int i = 0; i < row.length; i++) {
if (columns.contains(row[i])) {
columns.remove(row[i]);
if (i < columns.size()) columns.add(i, row[i]);
}
}
prop.put("showtable_showpk", showpk ? 1 : 0);
for (int i = 0; i < columns.size(); i++) {
prop.putHTML("showtable_columns_" + i + "_header", columns.get(i));
}
prop.put("showtable_columns", columns.size());
try {
maxcount = Math.min(maxcount, sb.tables.size(table));
} catch (final IOException e) {
ConcurrentLog.logException(e);
maxcount = 0;
}
int count = 0;
try {
final Iterator<Tables.Row> mapIterator = sb.tables.iterator(table, matcher, true);
Tables.Row trow;
boolean dark = true;
String cellName, cellValue;
rowloop: while ((mapIterator.hasNext()) && (count < maxcount)) {
trow = mapIterator.next();
if (row == null) continue;
prop.put("showtable_list_" + count + "_dark", ((dark) ? 1 : 0) ); dark=!dark;
prop.put("showtable_list_" + count + "_showpk", showpk ? 1 : 0);
prop.put("showtable_list_" + count + "_showpk_pk", UTF8.String(trow.getPK()));
prop.put("showtable_list_" + count + "_count", count);
for (int i = 0; i < columns.size(); i++) {
cellName = columns.get(i);
if (trow.containsKey(cellName)) {
cellValue = UTF8.String(trow.get(cellName));
if (selectKey != null && cellName.equals(selectKey) && !cellValue.matches(selectValue)) continue rowloop;
} else {
cellValue = "";
}
if (html) {
prop.putHTML("showtable_list_" + count + "_columns_" + i + "_column", cellName);
prop.putHTML("showtable_list_" + count + "_columns_" + i + "_cell", cellValue);
}
if (xml) {
prop.putXML("showtable_list_" + count + "_columns_" + i + "_column", cellName);
prop.putXML("showtable_list_" + count + "_columns_" + i + "_cell", cellValue);
}
}
prop.put("showtable_list_" + count + "_columns", columns.size());
count++;
}
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
prop.put("showtable_list", count);
prop.put("showtable_num", count);
return prop;
}
}
