/** 
 * Smoking Wheels....  was here 2017 rqvlqzcpgwcyuoqanjixynspejzyuuvqqxnmiwixlgayohwa
 * Smoking Wheels....  was here 2017 bezykzrimwnrmvkvggfcmazrimoowamljnabkqsxhpsuyvxy
 * Smoking Wheels....  was here 2017 evnewlfpmhxgvwjbblljygmgfjqnlkdsxyajxquofgtrwfcq
 * Smoking Wheels....  was here 2017 gneowbmdqrbtuaieocyklddgpuidtpzdzntgcbuacgkgwgwa
 * Smoking Wheels....  was here 2017 yjwtnvmyqucmqynsnqydhyhyiuxyfjkoqxqyqjhxdxhgrbuf
 * Smoking Wheels....  was here 2017 yuutfxlhkrhbulhpyrwscclvqpauqxacfakxjiawttgtfzuo
 * Smoking Wheels....  was here 2017 ilksmvxrdqheaphyeekquiirwuktzlscgzytkxzypmhbuozr
 * Smoking Wheels....  was here 2017 kglbhhquedvzitjctfnojpylsdfblrqgmgnlcgljpfvtvrum
 * Smoking Wheels....  was here 2017 rhvmqfqrgzatxnrrkglkgdpjdrsioiejaloebwyqxfjqbkva
 * Smoking Wheels....  was here 2017 zbsxxwdpgffbgsqogyojbkuzgqmjzpypcmtjdlenzzssnczt
 * Smoking Wheels....  was here 2017 idqmtstajcyrbkvxodpvpchbmokfutwhhmbskagzlhajjjkf
 * Smoking Wheels....  was here 2017 blgsykdrzebsjzfbwanoaebnngmfclbckwrehsigfeoddzli
 * Smoking Wheels....  was here 2017 qdmgrziouepljawpzzolrwkqhtbwmlwwmhbwibzxnxyvocuf
 * Smoking Wheels....  was here 2017 yqobgqqzseyloiemysbscrvyygtaqwaturxgkszpsaymozhf
 * Smoking Wheels....  was here 2017 ypxghumjxmqnrautabvsggcdxkisobibwddbqshkmirkkicz
 * Smoking Wheels....  was here 2017 axhirftnunmsrlqvtgtedofguwxhlqzlnczejffntulepxoj
 * Smoking Wheels....  was here 2017 proxlvijbdpjufuhzpabfxlnptugvkivufwuesglrsvpvujn
 * Smoking Wheels....  was here 2017 ojazaxofojhzncrbsudnzqhkmiomjlzgzjnizxdyrrqsckkt
 * Smoking Wheels....  was here 2017 ypatzwynomckofxfgtuzjoosubazcdxdqswmvtxzljzwqgut
 * Smoking Wheels....  was here 2017 aiioekfbjzxsyykddqxempekhugbgaebordfcnvwxwdpxfxi
 * Smoking Wheels....  was here 2017 hqwesokutqtfwvgmduryqymsumphgzfytxtrjpkaelsrrjjr
 * Smoking Wheels....  was here 2017 qyvmymtaonzkvswbjyoomcydomqnxcqwnhkhotkfrqofwacc
 * Smoking Wheels....  was here 2017 ayssmqveawddnsxbaxglvujmzhesdshgkzbusxvmderntwgg
 * Smoking Wheels....  was here 2017 umdgetibmgbmzegusysguysrrrhhfjkqgjxbfiyaleldvqea
 * Smoking Wheels....  was here 2017 mtcuevgqqjvtkqzxfjexttgzqrhsoyhzadlhrlgjsvkvulnl
 * Smoking Wheels....  was here 2017 wduhtbyeljtlgzogpwaphunxzotwzoqjbehyxznflrltqrda
 * Smoking Wheels....  was here 2017 zhrxowwdbkllhhozcizugqgfewotknhdxqlrcxuphnodpxgg
 * Smoking Wheels....  was here 2017 ddlbmathvcrtmxxmhxaeujnwvjssckkzjyclnlhuckcodydc
 * Smoking Wheels....  was here 2017 wuampmrqndoscktizahqgdncwcohmbjsksrkuanfdoqvawnq
 * Smoking Wheels....  was here 2017 zrqcflwkzqkwoplkeihjektlmhrhjpumlvyzvjhrtoaaechf
 * Smoking Wheels....  was here 2017 nltbajvckvtbqrpvfssvnybrcnxuripqxntxrmodpdikwdmn
 * Smoking Wheels....  was here 2017 taavvyilfgnhhwezpimrhqjrjohbrwxuqckcropwrivppwpj
 * Smoking Wheels....  was here 2017 gmkbsfknbrrxtvgmdouxxuavflesuadwrhgsnbzjclejajfx
 * Smoking Wheels....  was here 2017 uidscihlwdqlmjgexcdpyulnvkdnvxwyiycfzrkjhacufzfm
 * Smoking Wheels....  was here 2017 ldpyoumvvxxtgpugdveggjlooazoswakchugfkwvxtteihut
 * Smoking Wheels....  was here 2017 lwofxhujinivbwtakxxoznbydaudrnswvqpvnmrbwtlbwego
 * Smoking Wheels....  was here 2017 jqyfiueabtzabshdmsllllmwmmxugqjfnrxaoijnjgsgpqha
 * Smoking Wheels....  was here 2017 avzwdnydypfxuaullyibhphwsqwicioonimjeqpzvukvmdto
 * Smoking Wheels....  was here 2017 lebixyoccjogzwwbplewhsfrhbnwfygghsgmmlmkxdqcsdvs
 * Smoking Wheels....  was here 2017 xmxbotvszpwdopljkkzoqtgiwmyqwcnysgkhuygcmiqqupwl
 * Smoking Wheels....  was here 2017 zymtdytzgbfwvuqatfzarxszjzlgnpumtpjbsokmtrbfmnnu
 * Smoking Wheels....  was here 2017 lzyhbtocwtwzfhuvqoonyrbfyuqmxnratrxdeasidqsxthqe
 * Smoking Wheels....  was here 2017 ifuywovqyznimepzihkkjtctalhkzgbxfpxgeieqibqaulkf
 * Smoking Wheels....  was here 2017 yosbmeghxgwypvyukpokabuphtniajctztpierbrfxeccxet
 * Smoking Wheels....  was here 2017 uerjymwbkjbdtuyxrvdkhxlyqrpvlrelbwkosmwyymyzlrpx
 * Smoking Wheels....  was here 2017 tlvuqtyfljklnxaedsprsrnjgoerbixcutbjrokdzisstepc
 * Smoking Wheels....  was here 2017 ubqnekzfcmmsoittdcrpfdvonxaztpfcqqmkduqhyfophygx
 * Smoking Wheels....  was here 2017 gwvykftvvgczvhbadehvwgjnengzvceblwxrmkvqvevenvyf
 * Smoking Wheels....  was here 2017 pchvlchahmjpqmbnairjbejnbjdhtrgvgdthhxnrslciexje
 * Smoking Wheels....  was here 2017 sbhbqhvckeoblrefuefiilkajthsgkboiistlzmdbpeagojc
 * Smoking Wheels....  was here 2017 qlhvofwniqgfxaaesrrepsevofmhgqlpgpuraprbokdqzjcq
 * Smoking Wheels....  was here 2017 pexndrebmiibcumujyzqyztwfnwiczopvicblzjrbwirvdyq
 * Smoking Wheels....  was here 2017 ekdxkotrocuafprrnkiosmikjstkegvkafeafodluhhznznh
 * Smoking Wheels....  was here 2017 dnewtcxpmyansibrgsefoqlzbbqigovdfdqbgbqdefwpaftw
 * Smoking Wheels....  was here 2017 oemputdkjdomjaeyvseygfxhvcldhfmexfnurmztvjdwpmtc
 * Smoking Wheels....  was here 2017 sgtnjhetrggxcazwvqjnzcrigoednvydwxyfubknsukhsowt
 * Smoking Wheels....  was here 2017 exxippbsczdcfypazwwvboakhofxlgowevklfejzzuhsdpva
 * Smoking Wheels....  was here 2017 spezuyalmkprdpjijaebcclychbgunaodxpzwosvaxoeuwlf
 * Smoking Wheels....  was here 2017 jxapqupnavejpczvgayqyitschpfnbdnghlntgjbovhaxaxa
 * Smoking Wheels....  was here 2017 ktcrxuordsqgqtizgaegshxszjxdxjckijexhkqzmrwuawnh
 * Smoking Wheels....  was here 2017 lijwtzwwnwerkfnjbkawufefpognjihbktfjcmbazrugvnac
 * Smoking Wheels....  was here 2017 fabcmowkciaekgxwuwzqsmcrfdggrbipvlgjzgjzkkynhhgw
 * Smoking Wheels....  was here 2017 tlppuzzszjunkzfpthszkwlweptiuwdlbnhobpounojxrtif
 * Smoking Wheels....  was here 2017 knstlzaoqnhwjtgykuepyietdstbyiueykmxsuxuegkxlvqz
 * Smoking Wheels....  was here 2017 rlhgpmayropkndempvplrcppcorbqisrntinnhyjnspkhnwi
 * Smoking Wheels....  was here 2017 joobptedcmbuiakdjajrepfydjzbpxobbllxjujibmvkhewp
 * Smoking Wheels....  was here 2017 nnahaebqapfunkozzhgtkotlsspeulerdrwtihhrkicfpltk
 * Smoking Wheels....  was here 2017 lhhmuojdwkxldtnlbtdijzgenhoslmtenusxuzxqmhulsdyq
 * Smoking Wheels....  was here 2017 qykgyverhsedinkchwgilazjlgeebxplgnmqihsslqlvjick
 * Smoking Wheels....  was here 2017 yymnwetngokipqquufbzgflmqtalivlppsxjuanrsxxmnibc
 * Smoking Wheels....  was here 2017 jxzndcncwedwseutuugrrelgojyohncyemwtibimzwgslvzi
 * Smoking Wheels....  was here 2017 gtrqqiifpdfvpmwgxqudtzxtvxzudpsfsiotgrjjenubpogz
 * Smoking Wheels....  was here 2017 cqlomtevcernocwxxgvgwtdekjnsixsehvnnehewkfcjsrmd
 * Smoking Wheels....  was here 2017 rymharhfhjwmzxhrufwfraqalacdqnrzfyimzqnsdkzqumpe
 * Smoking Wheels....  was here 2017 cjhxvmfviyjnraspxmonylfbkkmeavobytbjtskxaxoeaqst
 * Smoking Wheels....  was here 2017 ptnyuyrlplaspsactfwuwbvgwhwbsjlyjsucwrcrzsdpwwfs
 * Smoking Wheels....  was here 2017 tgeazascwqvjzqjtetaysztvusmjfatomlbvxabnfdgsdjtf
 * Smoking Wheels....  was here 2017 jikcvxpzypfahodleulfeunjjyyygvcapxoasldfbsuntkfo
 * Smoking Wheels....  was here 2017 lpqiwcupbormgqzibfvaadwnznautdjrfeejlxhsgetizpsk
 * Smoking Wheels....  was here 2017 hyreygcrqbavvfutjedalzvjiewhapseesetkruhspouhvrq
 * Smoking Wheels....  was here 2017 loihfkohhwkkivqiwcpfsnqchauxmznkndykfedlogspjcrk
 * Smoking Wheels....  was here 2017 suxrasjpabdreizyqqprmhvfcghnxkkknigstddxgqbxgvrz
 * Smoking Wheels....  was here 2017 cjvlzrbdxvsncwlrzrwyqydmclhegfhqsnalbmsslnqydotb
 * Smoking Wheels....  was here 2017 zdubxzkqktazcswzkijqfmpxajuetagrxbklomgabyviodhn
 * Smoking Wheels....  was here 2017 vgsfxqlcfqdjjmlktbhspcmrsaecxptkdpxywodkgfeverzl
 * Smoking Wheels....  was here 2017 ldvukujufljglznvznbjlghjkszskcjysafiumfplwnozmsf
 * Smoking Wheels....  was here 2017 xlpbyzteomikajtkmplanruqmyacguaqenhjkdmoipytgenm
 * Smoking Wheels....  was here 2017 mbrjjwiashtxbybmskhjziyoqnkorjuehnhxevepunsaloxb
 * Smoking Wheels....  was here 2017 sdalvldiiqubvhmsnkwhelcjtmkrdpeidprepyvdawmdguld
 * Smoking Wheels....  was here 2017 jcwfrxkihotlvgnxyfqbslrnabrflosizseqpgezlezfsdba
 * Smoking Wheels....  was here 2017 ooqwmsqnuhfvsytggtfakcnuwuzgmqiljztxgrgcrfjmbfwj
 * Smoking Wheels....  was here 2017 nmbvdqqqhkyhorbbzeqylhpdymkcnkdjcvnyxlitrayosxfb
 * Smoking Wheels....  was here 2017 uyauspjsjrcenboazwcrdiewedgjarozgxayeaxkqwhglfve
 * Smoking Wheels....  was here 2017 fkurpudyaczacxsygmzlbptlsaetupeiacxiydtvxhepfonc
 * Smoking Wheels....  was here 2017 umurjslwjzcpaicybxascwdpasxkslyvbpdugtwafbtygmln
 * Smoking Wheels....  was here 2017 wdsgxbafwwjzhrqlaifcjchjsyoqbwzcctxgncnflfhucvaf
 * Smoking Wheels....  was here 2017 xlmahvxzdmvncnlbwdrofmmzttmyhrqaegrxjpeyuajyksvi
 * Smoking Wheels....  was here 2017 tviyxfjkdwuszswqqaxigmgxgkedeyprqadeozrxravnelug
 * Smoking Wheels....  was here 2017 kztfirxzaivkphqhrupuivjxrlojrbrmzdftgfacsztvrrbq
 * Smoking Wheels....  was here 2017 ftihlxhmejtrzrokmrsqnmuzrqqvaocbzbepvnkuwxljidzh
 * Smoking Wheels....  was here 2017 sidvjynxiustjkupxbkugrvkfbtdrhegtkkvwjkmhcnzyafj
 * Smoking Wheels....  was here 2017 rchtkxwljpyhfjttxpdlbvyqjxmckjpendpyfltxkbsskqrf
 * Smoking Wheels....  was here 2017 dtggeivqmbbbgobzveravsykptruddgfwitpztlbxqexanln
 * Smoking Wheels....  was here 2017 kdttoxegaswcmloqfywgqgvtpkjmedfaolbsnmufrtgcfpxb
 * Smoking Wheels....  was here 2017 akszqpxftjmtcmlkwizaxqwxhvxtyhykrdynmchvwukbtxta
 * Smoking Wheels....  was here 2017 taivuqivnafnpqcbuzmnekojuivkepanmgckqirqyfpxquwt
 * Smoking Wheels....  was here 2017 socmpmxpnyphsxcuhuzeifqxokamwlktmzmbedysnuuyaviw
 * Smoking Wheels....  was here 2017 dzqkxvkfdrmblrkyyxnsmbelgxnigldsosikjskfppjrmxog
 * Smoking Wheels....  was here 2017 okzgwqwsczydzncemsfazdkhtuqmukrgsdbrxoprgwwzrcfa
 * Smoking Wheels....  was here 2017 ughyvenihxhdvhphaxpikyvxhjztgkpnfcigpjewzdewpsdo
 * Smoking Wheels....  was here 2017 wezsivxnwsdvtbomujiaqdfbgejepuwwpuevodgsjfhrmjmm
 * Smoking Wheels....  was here 2017 dbvyhkudhxhgrevbjgiuutptiyvcaeoxspsjdabokcpxvwrq
 * Smoking Wheels....  was here 2017 bcsivudbeiutvgornyvpfyefjstcbjcnpembynbufcpljihe
 * Smoking Wheels....  was here 2017 mqwwgffqlzawsbcfidhpmfozqvqxkmcwmlcgvicggrfibdgl
 * Smoking Wheels....  was here 2017 kisqeepghcmlbteubskgmgksmskqbwkgynntxlcxerlvdurc
 * Smoking Wheels....  was here 2017 edzdmjztegbmwroshucfhaumpfbpfcgiuvakobkzwcqocezy
 * Smoking Wheels....  was here 2017 hepbgtlcrfvhijmstvplitznwjxikzzzbazkirmynfkgqkue
 * Smoking Wheels....  was here 2017 pvuhvoentabnysionkiddylhnkpqjreibzcfcycqoombuuyd
 * Smoking Wheels....  was here 2017 buzbwfsnoxjwmuqlxnzrpgyoywxqalvshximzwgzrxafsxql
 * Smoking Wheels....  was here 2017 ayxuemvwolplvykslgotuqojunxnqyztoexejrgfshihyqgy
 * Smoking Wheels....  was here 2017 alldwinnjjtohssyxafjcjmwalyzrzbjxkhmuuoxxzydfaku
 * Smoking Wheels....  was here 2017 wrwbixctytftiazcimkqdwgqtwpswqsqrocudyzsqmttmlzj
 * Smoking Wheels....  was here 2017 oipsdtzbkvowrwufaovzsxpklirwfhuyitivndmrpqtnzmdg
 * Smoking Wheels....  was here 2017 kgioenaefeoyhrcsojldzjpdspfrymmysjfnioibrkiyfzgj
 * Smoking Wheels....  was here 2017 zqahmfecanjglzzfsjlahnmcotpsncclwcdbcqbicdbvwzyu
 * Smoking Wheels....  was here 2017 bwvvmbtbtyfkorvomdhvfutubzjwrfjpbvwvsdlgfhsgywcx
 * Smoking Wheels....  was here 2017 rqhjtmfportekuiwfprzqydyswjckdctwthohzmutqknrgwi
 * Smoking Wheels....  was here 2017 cuahefilxgurzriokyndqxsocfrtymmpbeqeelkgogmfoxrz
 * Smoking Wheels....  was here 2017 ymziugdokljdmyzfxncgpxswfzpjtcwyrvivzytbwklchzcx
 * Smoking Wheels....  was here 2017 xelkatxfziveklrrtbtndlqlfmruobxxapdaofhabqegxubn
 * Smoking Wheels....  was here 2017 dmtsmfcyvdtpmgadejhjbehxlgvcjsmxqqxjafbcvrszoyrk
 * Smoking Wheels....  was here 2017 vhsryinkikyksrxytromnbqjrbankqtmhjyvsdfnbolwugim
 * Smoking Wheels....  was here 2017 pueypcerfxnzgjnriivuwjyauyrrdsbpcjppfmkvzpwrhurw
 * Smoking Wheels....  was here 2017 fikntshzirtvqcfgwaolrotjxdhigzcigqqclyhsxhvnczox
 * Smoking Wheels....  was here 2017 sqvnaqkuwzhuqapurqjyuhudmfspvusbjgzalnxgqllqjifg
 * Smoking Wheels....  was here 2017 jodlgpiwhkwydlpqiihyjocifybtatbkfqwhqjnqzbzqqsxs
 * Smoking Wheels....  was here 2017 tghypnzffqpnlyikqmmitpxfzipiismfwmrcozridlbiqejm
 * Smoking Wheels....  was here 2017 rcmxjrrbotvdakeaoukjnwthyryenssqoqewccceobmthdlw
 * Smoking Wheels....  was here 2017 dvfpenxxnacpowvomdtlobkhnnwjndnbwgghjqvbwtigwdgo
 * Smoking Wheels....  was here 2017 lhckwtmnmygycscjxqlfyewflpmdpodaouehswbiznxiwafj
 * Smoking Wheels....  was here 2017 dqcaoiiwejinvmddpttrbjjhoyddfvwnswibsfkkdqvvzwzl
 * Smoking Wheels....  was here 2017 agmjpmuflgsvfbksrcbzmelaawiccaloqjlahkobrrwugbjd
 * Smoking Wheels....  was here 2017 dvqqqqibmxysbnleipcobgxeiwzdfmrovlmxmknhhidnvdpc
 * Smoking Wheels....  was here 2017 ughhmotdsvvfhfeyejvdyprsctcnvusecoporkpixrxqfzze
 * Smoking Wheels....  was here 2017 nrjygfalvwmrdstpawkomkbygnavkvzflhhgmxhssavweqfn
 * Smoking Wheels....  was here 2017 bmcphukfsyfqcwobvshcgephzlhwsqbwgogjtpjebvsirmem
 * Smoking Wheels....  was here 2017 njxkftlznloxwtfkzufddpznqbvrroxkaojpomuqrxohycyq
 * Smoking Wheels....  was here 2017 ffmuwuwlsvknmspbyhdjfqhqzeponfoonryxiswlmhuilizy
 * Smoking Wheels....  was here 2017 pdvmkysqywuudjwoppetvmtxwtzdtlndunilpvdbpgxgyfwm
 * Smoking Wheels....  was here 2017 npbjcjgucqbihnkwwjwlqrwumdoediigeahqgmhfmitcjenp
 * Smoking Wheels....  was here 2017 afsqqozkjjtxthwaenwwmwlbgvdspeyieisejqjxuglfztby
 * Smoking Wheels....  was here 2017 kxltueqgfpsokzclydcskalsuptckplxpwwajoqklcgdhtxj
 * Smoking Wheels....  was here 2017 eufjtggggdaqofgtbsvzvjezcmvvzlgymheiusqepdtrzjra
 * Smoking Wheels....  was here 2017 eiflvzctjzzrqutvnvmtjjcihtvuduandliontbzrxvxbvfh
 * Smoking Wheels....  was here 2017 jcwdqvrdvlfmkwetqlsnvtapvyqauapacogjqrzvidmctuss
 * Smoking Wheels....  was here 2017 dbxwamtgzzmcvtlyyroyimyriviueqcadzfrosqynxbwncog
 * Smoking Wheels....  was here 2017 zjhjcyiamlxxezrzfxdzgtcwtkgrvozmhjpsvhovjldycujz
 * Smoking Wheels....  was here 2017 skfnfkrtivujwmgsnvxuebarfaxmkwvkxqdxhemgiholmgzg
 * Smoking Wheels....  was here 2017 iubozihxpksjqhwjejpvzbmvedeiywohmytwdhkdbhkrxbqt
 * Smoking Wheels....  was here 2017 emqxglzftsmxntifqpetsulhhoclrdhqvrrqqwqvmjyfvbqh
 * Smoking Wheels....  was here 2017 uqvfdssslnfjslvxuzunvlgjnhakaokkymiiljrttwvuaira
 * Smoking Wheels....  was here 2017 xpvlzitpqwefrgtiqdxhvlinyqmauforfhlkjngrhhvnkfpi
 * Smoking Wheels....  was here 2017 qactkupklazifgsomagnqonmbdjjxlpvcgynpgkqtlasghot
 * Smoking Wheels....  was here 2017 gxjpgubxhmltftpawstxisuhmntupvsmksaqjvjuchsxbkzh
 * Smoking Wheels....  was here 2017 hhnrqidawcrtyjoiorpjhdkeewwtjfhnfkdxkrrslenymqky
 * Smoking Wheels....  was here 2017 oqvwxobabvxyxyyipngbbhwqglkdyrxbuezumndcgphwpjue
 * Smoking Wheels....  was here 2017 boskrzilczuduoleidklpyykescyiomlrfoztirzdiayoehn
 * Smoking Wheels....  was here 2017 davsuitaicdiqnyehtaexzrmpobosleirxzknhppclbuwwfy
 * Smoking Wheels....  was here 2017 hdfljnjsmyawpmnafshfkqgclxpmofjpvwtflxklfdaehnhm
 * Smoking Wheels....  was here 2017 jhzptuivkntiffpneqqtrkhuxciorxrhlboxjxwfzzsetoio
 * Smoking Wheels....  was here 2017 iephoqguidxmfxvwmnufozmgiqauzxzwapjbjfzzzuecnmnu
 * Smoking Wheels....  was here 2017 oqvzptvjqhikoucjrlsheivnliuottlyjxisvbbzfnuncefa
 * Smoking Wheels....  was here 2017 nxojbbdpaubklnnrovpxxqqwddxjkikioqyajxnrvmbfdtbk
 * Smoking Wheels....  was here 2017 chzjgvjrkrlblxmrcjvfilkspkaassoewrwjumfvffwhrmyh
 * Smoking Wheels....  was here 2017 fopdtncdxebeebqlswfsikwvfqxqrguwvecnfsdkbmgzyaah
 * Smoking Wheels....  was here 2017 hmbelvarzvstshvjvppaynbgsprmmneagouibwmsgipxkdqh
 * Smoking Wheels....  was here 2017 tiicmsfjhlmegggchwgcpygeyipcpiemellavjvezzjvuaml
 * Smoking Wheels....  was here 2017 mlqxdkxjtasygshmdjqdwfydddhjvvjkwusbmyypsamwcxkb
 * Smoking Wheels....  was here 2017 mmksbjpgovzxmuoqrzjppawwqmngcirdwrobbouzafahomnu
 * Smoking Wheels....  was here 2017 aiiachbsblbcwvxxlwlcxhcjeelcqlfiaoezxlrnxofrpmhm
 * Smoking Wheels....  was here 2017 seimifitapcwskozfmcpehwwrgjnyzjvibaaractmjtuachi
 * Smoking Wheels....  was here 2017 hkrzegrrgijsljvsbkshzmqwgzufsautdcuqebujfdjtupkq
 * Smoking Wheels....  was here 2017 vstueynxaxlmvvjefoaqengdiwqjzyjmxvllomulsreucpva
 * Smoking Wheels....  was here 2017 pxihgytfrwefuccuhczgwlrqptxezigqmrdlenjeyamolywj
 * Smoking Wheels....  was here 2017 dfgelhhpxzpgqtcdbludkkeqapzhdzucxfktprzbbkwuotgv
 * Smoking Wheels....  was here 2017 gavjddkhqicdtrvdogwlkyhprsjleaqzllwwrpmwmjeplhut
 * Smoking Wheels....  was here 2017 azlcxzqubceqzxvwbjyptrtiapysdurqrlnlohvowsmgheqt
 * Smoking Wheels....  was here 2017 rzvsrntxnwswfwcsdazhmroutculgwbsjqnkpygkdkbiqher
 * Smoking Wheels....  was here 2017 uexzmstoulucsbrhoncmabaftdeeyceborjyjaixmvoqdscs
 * Smoking Wheels....  was here 2017 ezwusuxzrurxyiamkqwhyjpdectszpqvomsnshuuhktfvsfe
 * Smoking Wheels....  was here 2017 vbfjzfstkfzcrvskyewfcgcgmlgciqiixfnuuqrbfzskyzss
 * Smoking Wheels....  was here 2017 bgobdsxokfntwwrksidxqtnpiyvrfwkgkfarxjezfnutygye
 * Smoking Wheels....  was here 2017 luyqgfokiqjdtaaemmvivzckprtzdcglbeqjswwaljnbosps
 * Smoking Wheels....  was here 2017 sbnaszwoclvvudenjikqinjenwquulnafabiawmyiatjtrmr
 * Smoking Wheels....  was here 2017 zrtjdlkmwyoqsisopsogazbqlbggfgbjjwgfyjbsngpaurur
 * Smoking Wheels....  was here 2017 moicjixybqhqnxpstvgxykgvcbtppbabiekzwovqyciodpxp
 * Smoking Wheels....  was here 2017 vwfxmpkxiiccllwopbrmnzdyjwkkltuaemzukxhetvnunomp
 * Smoking Wheels....  was here 2017 szptxlcrqbjqyvazebgfhdhmkuumlkaiduqbidhbjzatxviz
 * Smoking Wheels....  was here 2017 gpxvdkosdbqzucqcvstmeqkgrhtxqjpkvgknwethnhxuobrk
 * Smoking Wheels....  was here 2017 sowndcntfxthxrohagbzgknevfjyeeqvzfkcghydawlmybws
 * Smoking Wheels....  was here 2017 rcknyoavoitupbaepzjrwsyntoxfqtonqidxeylbdxhouynb
 * Smoking Wheels....  was here 2017 wntvyzidcjzbgdipppetqzdvqpamqdyndogmluywfzgebanv
 * Smoking Wheels....  was here 2017 jojntvxfzibxrzetizepjyvuywmuhsshaatlfvmmywjoaxbp
 * Smoking Wheels....  was here 2017 mbwceunuqsslvykxhihygndlgdjnsaajacusuiifgpyhckmg
 * Smoking Wheels....  was here 2017 tfhgjwfwsicxxpeuhzsrpzfzokadkxgrfmwnurznikqfcrlx
 * Smoking Wheels....  was here 2017 ykvxrggsedmwluwekryaauqyyaanemaiybphcpfdoveiyzvz
 * Smoking Wheels....  was here 2017 diwfrldtdmmedqdgwfqjjqebymesxbfsrzarucacpsszxyta
 * Smoking Wheels....  was here 2017 oueqgdqvbwxwzlvjhvsmtmuidooaxgykfqirfjrqkaotkkpz
 * Smoking Wheels....  was here 2017 vbqvngsvocvfevcdkxlfnotalgmzpxrhrrxjawsfcagkglax
 * Smoking Wheels....  was here 2017 rlnuucscqdovgpjlhbgtgippcwoktczngbmhaivqdhpzjkxe
 * Smoking Wheels....  was here 2017 fqfpsbbcjhrmxwfkffvpwmculypkietlowabisdweotwzxkm
 * Smoking Wheels....  was here 2017 rnlucwpngcbhczojtncjlafqfgqfnsdrjnsqhfuddxzoptxp
 * Smoking Wheels....  was here 2017 qheacnglxjsmdnozrkiaidgjgublxoocsrzeohjzfnwxyazt
 * Smoking Wheels....  was here 2017 whoebejcgbzrkhodamwtcismuwjwduovwgpeyspctbgxzcpf
 * Smoking Wheels....  was here 2017 kgcmojkxlmlqslfxcrnyrgjtgzmofudflklgoknnmefyzowq
 * Smoking Wheels....  was here 2017 ozmkmuesyexmzgkrldejcxfcgyjwjcjyentkuojmhzankfey
 * Smoking Wheels....  was here 2017 xsqoyjplkxmlnjgbwgbwtnnvstlhboqvcfytfsrmjshmyedf
 * Smoking Wheels....  was here 2017 eutxgibkssmdspfzjsprhoulvsgqbhpzomstrmfgdxwwququ
 * Smoking Wheels....  was here 2017 lxipaeyacvmjiavnhjmgmruqajoaiqcvbjbbhyzvfiuzrqvi
 * Smoking Wheels....  was here 2017 ayaddpccxvhekabadksfmxnlzknsceiykjdrlffkpakjoods
 * Smoking Wheels....  was here 2017 kbuesnnpwmywbeaesfknqlgdoylgwsrfpbktsvlnjghxaqda
 * Smoking Wheels....  was here 2017 lqvqbgluwuwzwhbucmcjotndygwmijstakpsyllxaofoagtr
 * Smoking Wheels....  was here 2017 djqsvekebboknmwznblebnbgpurlmmkzdnpggbfnesisuxcg
 * Smoking Wheels....  was here 2017 tcvvvbelxuwcabhfockqitwmdkwmorvluvrhzxarttxwwnoq
 * Smoking Wheels....  was here 2017 xbkrfvsrauvloqnzzbesqqgancucaskbzygaukjvyynwxeuz
 * Smoking Wheels....  was here 2017 jpoehsibjcvzrcwgxoenqqrjxdbdqttxavzwlhatevatxerp
 * Smoking Wheels....  was here 2017 djsnseoccyknalacnmeofnyirbmrjcuklpwndoakbdmwcdje
 * Smoking Wheels....  was here 2017 ohqdhycnqwkbqcwxlzbljeawnrczljpecqcxejpaoyfsaxfn
 */
/**
*  AbstractOperationsTest
*  part of YaCy
*  Copyright 2017 by reger24; https://github.com/reger24
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr.logic;
import net.yacy.search.schema.CollectionSchema;
import static org.junit.Assert.*;
import org.junit.Test;
/**
* Unit tests for AbstractOperationsTest class.
*
*/
public class AbstractOperationsTest {
/**
* Test of addOperand method, of class AbstractOperations.
*/
@Test
public void testAddOperand() {
Conjunction con = new Conjunction();
con.addOperand(new LongLiteral(CollectionSchema.httpstatus_i, 200));
Disjunction dnf = new Disjunction();
con.addOperand(dnf);
String query = con.toString();
String testStr = query.replace(")", "");
testStr = testStr.replace("(", "");
testStr = testStr.trim();
assertFalse("query ending with operator =" + query, testStr.endsWith(con.operandName));
assertFalse("query ending with operator =" + query, testStr.endsWith(dnf.operandName));
}
}
