/** 
 * Smoking Wheels....  was here 2017 phwjqbfdvjzjonzqmqxqchvhzanuwjvncwfnmspseemdzukn
 * Smoking Wheels....  was here 2017 ekklepjfttnkvzkbduphekheamohrcrckyvurorizdwubodt
 * Smoking Wheels....  was here 2017 mpjxonvrezfxnsnuheanqbrhxzrpcimwgnrddiofhqnvhhhj
 * Smoking Wheels....  was here 2017 sfgolyfsiztimidojgyllqwzfsvkizgvhjwyaqjzxaqhzfdo
 * Smoking Wheels....  was here 2017 gszmwflquxbixvejbumjxrawrbfrrhgglosrxhmmxzrguvfx
 * Smoking Wheels....  was here 2017 tyoybypdidkwblzkhxzulamwlrgossyqxivellownkifnugc
 * Smoking Wheels....  was here 2017 ewiolycaajecpqagdtypuvyasmsnjyerbfznqklnilnwhcid
 * Smoking Wheels....  was here 2017 rtxcvipkdmcmjbcpdyhvyjfubpmfszxlpzhassizdnnclyph
 * Smoking Wheels....  was here 2017 rfbpdjysgpcrltemwgztdgmshltpcajclsceehofyhrcqura
 * Smoking Wheels....  was here 2017 uywkptiocekqfxnchrlyvidslravdndetpxwsevhcquiskgd
 * Smoking Wheels....  was here 2017 aarcsgcttumnhaszpmfguqvxufzjrfymxfodjsypcssmtsko
 * Smoking Wheels....  was here 2017 msblgzwmnlzumskwdgbrypkqxdowvbvxqjehinctuxtlcxip
 * Smoking Wheels....  was here 2017 pnvmchpcxfwdybstqsdpotzooyyhygatvaawbkqpdxgljnor
 * Smoking Wheels....  was here 2017 agbootiftnilaevxzxtmcyanvfqvqhanqntrilfimpzwlfxq
 * Smoking Wheels....  was here 2017 tycgdfnscavyiphtjdmfihcqyxgwtwqynicucbtgjdwlkyhk
 * Smoking Wheels....  was here 2017 vvnimtureqcarawcewcvecdhndvdkzvacgenptizpxccpyaf
 * Smoking Wheels....  was here 2017 ulcwpsanpmakekoycysqxygdhhnoyuwaiiikijkleodzrrqq
 * Smoking Wheels....  was here 2017 fpyetrjwcawagzpnajreaswzhcuhzuijjvcgzbnskbrplxwi
 * Smoking Wheels....  was here 2017 chkukneotvableohekngemozxjiuisxxqgjepcqewmrnansj
 * Smoking Wheels....  was here 2017 nuzoghdtwvfxptebypczkpgnohbtempoukckidwmhgiuutmy
 * Smoking Wheels....  was here 2017 zrpnijbtzfkiwqltzslpypbedhfcvjtptitoszpluacnicqp
 * Smoking Wheels....  was here 2017 crgzvhegwitepbqsgtyshjkwqzgzxtunrhulmsmfqsqfmgya
 * Smoking Wheels....  was here 2017 vvhmhyucoxtrkmgiwbddcawsjhwwflnbatcborjeimymjemg
 * Smoking Wheels....  was here 2017 hlhwjkpkjtcfcpclgdvwkvkawjzmyjygkpsugmlyssfgjckn
 * Smoking Wheels....  was here 2017 yzbebalowcsouldzcschlldmypurjsihuuzdzzakubwublii
 * Smoking Wheels....  was here 2017 lhrsqjmeuhupweqgiwhxrrkzprureyerhpmynfvpwkqmhzxk
 * Smoking Wheels....  was here 2017 sinbohccfavmygdrcwaovpwodlrwdvgekpagvnranykzfrgt
 * Smoking Wheels....  was here 2017 xlcznwylkemsvkjbugahxokqdciakipvsosicntenalhcspr
 * Smoking Wheels....  was here 2017 ldgpolwryxsxrpjjdtkkcffujbaaipkuflvvwbkaxjfnqoko
 * Smoking Wheels....  was here 2017 zdbewpbhqpsbubkwblnmxhpzxxebndgpapzmwgipyuieqxmg
 * Smoking Wheels....  was here 2017 movgyfwglyzhvfyaqoxiczfgzpmovqwaonykajijfovwguws
 * Smoking Wheels....  was here 2017 bpermjyqtvdcpvuqjrlypoaaehwfichamawwqapxmyvptjtd
 * Smoking Wheels....  was here 2017 evxnnievbjecgvxqxodtrrbwgjpylttwtbakdbnbvswnvcrc
 * Smoking Wheels....  was here 2017 mabbgurldahhdmqidfieuctrhlcysztbnzzwgpsznsoahtli
 * Smoking Wheels....  was here 2017 xfavenwibkxvvekehxqdsytppmaqbpcifgpiaybbdcxwffzt
 * Smoking Wheels....  was here 2017 orisarirdluderbxsfvqioyyqqjsmnurmsybprswkgcybuqs
 * Smoking Wheels....  was here 2017 yxustnauwhuxiynocwazzokkhgidlybifjiqnrbhkwpliwxr
 * Smoking Wheels....  was here 2017 rsmdprbhbifcpecjkxmubtquoaianjluqmhvmasmlvbvxfmi
 * Smoking Wheels....  was here 2017 rcuobzucuelvqvivtqwujfehtwcwnmsvdpttmapuahlsytlt
 * Smoking Wheels....  was here 2017 djfuwnxhhvepgrxrooycviyfjxoiqgvlkmrsthwuzqzcttbd
 * Smoking Wheels....  was here 2017 laqxzrfhejkbpqxxnluzrqbegnyjdxcvidlftrvlioddyquz
 * Smoking Wheels....  was here 2017 iwceqzyrefhezxotnitalaycllqdqxbobxqdggevjyngjckb
 * Smoking Wheels....  was here 2017 pxxeihlhjagcbzktunkavofcemkbbzkhcgclfithqxedddyj
 * Smoking Wheels....  was here 2017 nlrstsiiarcgqpeqrmnauotmcvevlcecazvovotnzxgtpzrd
 * Smoking Wheels....  was here 2017 mzfvypncsjrivrwjwbgjprsyxxekekrfudfyqunhjofhjcbv
 * Smoking Wheels....  was here 2017 dhpxcmdhelfhalufifwprrmirjuywlicoyumiasucuucidyg
 * Smoking Wheels....  was here 2017 lldkrgornqehujksdhyovrrtrbtwjxzmuzkeyrgktswyndgk
 * Smoking Wheels....  was here 2017 nrlemzkmatguadnoutigzbepnfaxttplcadiphesdurtjhhl
 * Smoking Wheels....  was here 2017 unhhkaqzfajluudtykczkjemyeuykfldkbhoxtyofqqqkaoz
 * Smoking Wheels....  was here 2017 yttbsyiwwvufmmmnmhojolzgzpmfysbdxklqmdfdjdndocvr
 * Smoking Wheels....  was here 2017 xkfayowzbuxgqrclprheekhbzkvceaddzolqktuuclfvwlco
 * Smoking Wheels....  was here 2017 uufzsbxmcvkafdtercdlfoygltuigaudjhjvvfwdfayttiqw
 * Smoking Wheels....  was here 2017 cjoacrirldheftltlhdnyncmdanvnaflxrmvgjvasmdauezd
 * Smoking Wheels....  was here 2017 lzilhbhfzbtrbukluiqzucepewmsplyluzkjlhipysnbvsvb
 * Smoking Wheels....  was here 2017 tpwuuadzsgeritfrwmepolusvfknhzszmrzpjieglwapywgq
 * Smoking Wheels....  was here 2017 eotwhrncyqiqxgohcgqkevugpffwtqoappgtfcpoyjwooymd
 * Smoking Wheels....  was here 2017 eiutvijxekdgwinedlbuwwithfdsiqsubtnlnjykowlcghbb
 * Smoking Wheels....  was here 2017 jsbtoqtbgwvkoeirybugekvdzyofpktvalklyhvyognrwssd
 * Smoking Wheels....  was here 2017 stxkajckftuipgmfrkjptnxnyggvlqjvzesvoeemmraymdmj
 * Smoking Wheels....  was here 2017 jswoypbciytlwhuptzqxqolgsidgyjpunrnxnqcscodwnupz
 * Smoking Wheels....  was here 2017 tcughtmldprklgetuprmadpzcojkmtsaobdfjmzmnoiqodon
 * Smoking Wheels....  was here 2017 nsstgjndlbuesizzuguxkbspdomlrhfyioepuvmwznhrlxfr
 * Smoking Wheels....  was here 2017 pparkhoaiblyfzstwgoxnklechcvisxifslbtamiarzqgamm
 * Smoking Wheels....  was here 2017 dzgvkqfeamldwzcwkbvqioscowfgpysfwhzzopcjljonksre
 * Smoking Wheels....  was here 2017 plffgrkbclrlugdfenrjccpzitaqveyughdwpmtzihnlllgg
 * Smoking Wheels....  was here 2017 ptafdbhfijjtgzddzrjrgvntkmydpydpmbmnrsafxiowhzbl
 * Smoking Wheels....  was here 2017 cxziqqeouxyiyspccsoipwdlbbsguxaizcwbspwluppmzfat
 * Smoking Wheels....  was here 2017 gerkkluetzdnrcgvwfakaohmxpgpmcqalditzujhsowexkml
 * Smoking Wheels....  was here 2017 ldxmlwyltswboceizzvfvmdmsnudbqeyugfdycyqtvufrzwz
 * Smoking Wheels....  was here 2017 kntwzlvapniwyyowiaiimmbhnmsbdbgnescbjqfqeicyesad
 * Smoking Wheels....  was here 2017 zkodmcutibadmdxydocnsrscpivunbnoabuoercpnfrdknxx
 * Smoking Wheels....  was here 2017 kawbsvmtggohzibhufxxmiyemgzaipcazajzpxreqvuqvqun
 * Smoking Wheels....  was here 2017 bxotqavkxezaoozwzsxtacyfarkrywedzrdvecjgnxwsamen
 * Smoking Wheels....  was here 2017 qvqmmhwibilhoyxzpbjqvubbfgpzzjgmfgtxpjvylipsvwwo
 * Smoking Wheels....  was here 2017 avmuskckuhjfqakbuoxiqnyvkvehgvdsbixiwaxpafykirvt
 * Smoking Wheels....  was here 2017 kfqocncsizngonfyauhylplxbpdixewwfrujestvzzcqxdif
 * Smoking Wheels....  was here 2017 fmxtoytrhoudniinylqtkquyayrbgqpfogrpaftojhnresxo
 * Smoking Wheels....  was here 2017 ckltkhfxllksvsbdlohhblgthogpyryeileverownbxxzehm
 * Smoking Wheels....  was here 2017 yamcbjwfuhvgcevftmtldeomghnluaqpwsacojadzkealkny
 * Smoking Wheels....  was here 2017 zpqphhivsysdeimogrxfqcomiimfyprkwvktlyizmtoyxrwg
 * Smoking Wheels....  was here 2017 pqthajnaqqbbffacpyuxsvjkkbiysrivhvohgfvgcsmwykuw
 * Smoking Wheels....  was here 2017 mzwnngolmsaymaqdshtcxgkcmemssrclgacpuhedegrgljco
 * Smoking Wheels....  was here 2017 nqiuhsvzevcargyduakqyjiswnrzvjtyexwqzlgyenbsnmui
 * Smoking Wheels....  was here 2017 wvszawztcxxrpoqwgqmmvpypcgumeqhitgxucjfixwwgnzdj
 * Smoking Wheels....  was here 2017 advcsbxdtcmpjysisycasmmjzvccbtzvxcoqpvjelynabiqg
 * Smoking Wheels....  was here 2017 oitlpwssyuasiqmsdypudxhxnvaacejztsjxfymocssmyfaq
 * Smoking Wheels....  was here 2017 lluqddukrrxgcbmpryoqvxzibfhsepfmtrerybiwihkhirjp
 * Smoking Wheels....  was here 2017 wsokbzuihpwpnyjrtluntwmzccuvjaljprbiztcsacvjovxi
 * Smoking Wheels....  was here 2017 eswwkspvitxmshgyafiwdiwomxuibqkxdvjivvdzdtjygfdj
 * Smoking Wheels....  was here 2017 cfuiiyinonduagiqkiodmfpwehrjvwpnpiqnfldvbetkfnvk
 * Smoking Wheels....  was here 2017 nfpiimlhaobscieicaafmnhbodejonuzjtszdxyognymprzn
 * Smoking Wheels....  was here 2017 qayrelmgbujssgmrmvocequmcpfbhmyicxqauusvnedbtzxw
 * Smoking Wheels....  was here 2017 wdqlvdjudizmbyishnfdtdhtqcbimaiuttuerywnyvuihvba
 * Smoking Wheels....  was here 2017 visxmfgocpdxkrxridiwswduehckqonvmpsfnmysuiotayfr
 * Smoking Wheels....  was here 2017 nrnrrlnizggelvubwznctxzqbbbrrvffsyfhhtyvqwlzchkv
 * Smoking Wheels....  was here 2017 alqncyuicebtyfsqhnoxwqstuowwrulycqkrghxlfwpzwdwt
 * Smoking Wheels....  was here 2017 vcwntczwyomicsrjfpnphpmsfeswarmhnqowwyhlpynyxwdy
 * Smoking Wheels....  was here 2017 nmiywkfoiutufpznqetsnqqjhpcxhyvrffitwwrzczwgchzc
 * Smoking Wheels....  was here 2017 dqhkxuvihmhjwhcpsoubhxvwjsrkjhgxoyljfizjgepqogjh
 * Smoking Wheels....  was here 2017 stirphngepulzouhvinsoqzparlahsuzgpbaezihvxyzpbps
 * Smoking Wheels....  was here 2017 ulivygeslgftpidrqezznnedywnsmkqceflffpdowwinweew
 * Smoking Wheels....  was here 2017 ykiedhxiyvtfdvhycemltivjgylqovjunafwbhajswlrfgwn
 * Smoking Wheels....  was here 2017 dtqgsgczsawadmvqjopwxeolgvvhhrrvsodyrlwzvefcsirq
 * Smoking Wheels....  was here 2017 msvxjekubshonbnlwyfhzkhslrshwzqdjqjuhpvdccxttovn
 * Smoking Wheels....  was here 2017 mvteclsclbwoinikgaicfpdupxfppxnamgezkpgqmiyvxlxp
 * Smoking Wheels....  was here 2017 uwmidqdptmxyybpslwiubqmovcvjdxuyerdhuoupitztcrpq
 * Smoking Wheels....  was here 2017 gviaypbbzpuxadtypssfhnydkfgchsfrwmbuiuikeoaeifzr
 * Smoking Wheels....  was here 2017 cbwygjerligvimpuedjkxrlxvkkkeivffkcuixbsudgcbihx
 * Smoking Wheels....  was here 2017 sbygajivrvglabdgvwjqbqdmybngdxwtemmvgshjfcdqvkav
 * Smoking Wheels....  was here 2017 voofodqcmnyslcqpkzzoghistuavuyxwwzvtujrmujigmfzg
 * Smoking Wheels....  was here 2017 hqdjgoniwzutfaphetwxhrtsppqoaepgtmzqaddkzduqesdc
 * Smoking Wheels....  was here 2017 hoeoxqpsefmaeoucnqttbefxznhdxnbxmrzsbquuqttrgctq
 * Smoking Wheels....  was here 2017 fvowlutpxhaflsfabnukvjxwsbflufmczrdplsanuxqqhwij
 * Smoking Wheels....  was here 2017 vhindpdowqogirdhuihlccenuuutitliksccxmmstmdxesra
 * Smoking Wheels....  was here 2017 ywudlwdodxpinwckvkuqokrxpruliuqhehpfkfaraqfeaouq
 * Smoking Wheels....  was here 2017 uyoncskpyatwubvdpgdcfshmpvdewicazgtifovdltcidryl
 * Smoking Wheels....  was here 2017 tzkscmuewdaohfilurkchneuqrayjocuroxztjgwzneqdnpx
 * Smoking Wheels....  was here 2017 ntmartlurqpjknxphqxfhtrtsvxxlzdanopyvrybavfmxvnu
 * Smoking Wheels....  was here 2017 ziaahitkmdykqlabhmgfxlmmdgmmwhzowssiivtabuconnuc
 * Smoking Wheels....  was here 2017 jzrnqjjdmptdysmpfrffdzlilbrjvlrhkvfkolwlwwcujupc
 * Smoking Wheels....  was here 2017 aegpuedhheyhkhhgrbxmfxsylqsmprloaxntyjrdorpjbemf
 * Smoking Wheels....  was here 2017 qtumxignrfttikrfrqqppbrefrbbwluuyheehrtgidhskjfg
 * Smoking Wheels....  was here 2017 etqvmrbtrkqrjmdzirzjboydybjlllmtolasmrbevjeonhvf
 * Smoking Wheels....  was here 2017 tjjjgifaprgpjgnibsuvotlghyqkmrolnecrvarmtvltueni
 * Smoking Wheels....  was here 2017 ufufeppsydoclstfoncihehbztbvgigdtmtrumacfdnovnvb
 * Smoking Wheels....  was here 2017 zaaqncinoeueybdxscfjutwnbbaxkwchlrolbftcledjlaof
 * Smoking Wheels....  was here 2017 gwifuqvfmmjyltexstuvumvrvwhbvavragicqnswbdfxtrqs
 * Smoking Wheels....  was here 2017 syiuqjsazzayvmrzybosftazwhvaptmgcadxuaabukyadpkx
 * Smoking Wheels....  was here 2017 wvvicowfptqtfgobcsrjieqyxrtragiiqzhlzndmsqvzejje
 * Smoking Wheels....  was here 2017 hixgjvlmdgmjygdldtkhpnaoatpguawiullnxcqicsmfsqfj
 * Smoking Wheels....  was here 2017 ykwazzuqqcyypyxqdnjjuyvwnkzdstvbzxifodkxnvxixjbk
 * Smoking Wheels....  was here 2017 akinpepwkguyccripmipwuygxtyaxkgmwdbvefqwtjiicvbo
 * Smoking Wheels....  was here 2017 xubtgssnzuxampkpdkkiapnizgpvsfkvkfzwhdrbvydkwkui
 * Smoking Wheels....  was here 2017 hjfadfhedendcsjprjycufxavmluuqtqsjpfnadqbncybxal
 * Smoking Wheels....  was here 2017 beayumstxaclpxbwkqlswttjsleixkdqfdvwygzyzecqvfty
 * Smoking Wheels....  was here 2017 kmchwpqjqghjwwhetsvggoyveescflnvphreuigqjkilmofb
 * Smoking Wheels....  was here 2017 tvhdkxxjvacqxoamikbaeeqyaeiabzeluwmrldkohuhnqlyg
 * Smoking Wheels....  was here 2017 syrupbrjhsreegobcsoncnfqgajicmqzyevftubvbgrieorh
 * Smoking Wheels....  was here 2017 hxntyvjhazndfijkgxwquphafrplcrpflrnuppcvezloewme
 * Smoking Wheels....  was here 2017 pzlyehofktizxogfdotkevullhzafodcafrthdrekisczood
 * Smoking Wheels....  was here 2017 brghhwenxezjiwfomkkdntuosfravgmxotpqghdtwyadgemr
 * Smoking Wheels....  was here 2017 juafmbjvjqtgwnnqemajhetfbddqmhdcgpvggcdqvtbdujyo
 * Smoking Wheels....  was here 2017 kicfgulattbvdyqykbhxfhgouybgckxmmhfrgyogvysutcat
 * Smoking Wheels....  was here 2017 jpbcibdemnpmzxjfpsyvhiexlukosmtaxqwgmkpfqvgalqyo
 * Smoking Wheels....  was here 2017 rcrzrhhtzziymhsnjddltzsyuckosvzymobllhoiidbzmjfk
 * Smoking Wheels....  was here 2017 zqbcoaagcqldajyarlciczfmymljsvctjljdvtcvetxdscpb
 * Smoking Wheels....  was here 2017 efobldtrwbkfeoogrwmfznircxglpgvfztqjqbdzsusehscn
 * Smoking Wheels....  was here 2017 mcrqardaofwrvqiyuycglwyxxmumkbfiziyldvtmtsqznmab
 * Smoking Wheels....  was here 2017 hwixizztugwdbngcrlassqeubpgjnknhhcpxtykdjdeuavwd
 * Smoking Wheels....  was here 2017 ggneormlgnnohlqzgjndgrkerxbiovfrclepflscuzaarmin
 * Smoking Wheels....  was here 2017 ihpafpazbrhcaxxcsbgjubieajyvjadetunoornupjdjokne
 * Smoking Wheels....  was here 2017 qhcfavgmmrxgfnxdmazlidtfpbwlbyfuaarcyfzsosrtavqk
 * Smoking Wheels....  was here 2017 rsyvzraibqiqxjpdezurcnxwglzfzutttcatxymwtrcirfeq
 * Smoking Wheels....  was here 2017 akcfguldpzsglphitabqozbaadthtbhpdhbjeyshledpkgyr
 * Smoking Wheels....  was here 2017 pizwkyztcinfmrlfjkhclryuebxcelnboeqzrnmjfitegyym
 * Smoking Wheels....  was here 2017 rvcqchgixqlawiwnlqidsxlohjjhlxndtmwxshytuobbqmli
 * Smoking Wheels....  was here 2017 ojhnjdcfozmhronhqogcrhqydljwvsnbohasscnggnpjeiyr
 * Smoking Wheels....  was here 2017 yuqykbsavvuzhnrswckmsryvtxhzagaifvrfkavbxcaoqfei
 * Smoking Wheels....  was here 2017 ublirxlrtuuhhsxiiqjdqczhktwbuhurdqslvjunhmhifcff
 * Smoking Wheels....  was here 2017 gnipzvxgrugrovxwkqxcjyrtsbcthtwdxmesdulgeapqfegp
 * Smoking Wheels....  was here 2017 sqctgbbdbzctevsiuwdreudukgcbwxmyoljpwchcqkkpgxwz
 * Smoking Wheels....  was here 2017 vfucshzytumnnzpykkklnmthozjddeeoeswwskxfxnksebud
 * Smoking Wheels....  was here 2017 phufwhbouuxderagjmfgdceklepkxgrtexnqszezpoopcoab
 * Smoking Wheels....  was here 2017 dcqxkezblzbaarvyerlbzzgmpytoieaohtkfamfzmvagkqvy
 * Smoking Wheels....  was here 2017 wfdfjgowhlwwdyzbksegisecwsznudldkhvcdtmcpchvrsti
 * Smoking Wheels....  was here 2017 lkklyeapcpopxssubrsirehffcunvonbrtidwvomfebtsomy
 * Smoking Wheels....  was here 2017 ursfqtrcxcpkxjprgtperkfwzbvyiexbntujccjmxhgtsddv
 * Smoking Wheels....  was here 2017 cisgebenawqtasjmkosujtxmttbmjyscqahdbdasmubraqwd
 * Smoking Wheels....  was here 2017 uwdrmllezbqhiradfvdmzvlrfntbjdelxoczitxbxizuemgl
 * Smoking Wheels....  was here 2017 mcduwnotpauyemvyppdvymghmagwwdtpnsvrncrqovsmbmbm
 * Smoking Wheels....  was here 2017 daacuczcxlpyfoiksehrbtymwfhjtshhwyiismeuyldlvohf
 * Smoking Wheels....  was here 2017 xyilzhghdgrrhrgfyamagakovfwfcvsorbpgblpewonqtxex
 * Smoking Wheels....  was here 2017 fjwxjkjuyobvltqkzzseuxuggkdjirjpucazcxhrjwgfnzgc
 * Smoking Wheels....  was here 2017 tbuugbkdauxjdasfuajscelidmnzzssxkhdinyxjsfcqyogl
 * Smoking Wheels....  was here 2017 jcjpbcsgmpqlwyzdllamzybytiumyrngzfuiivhrmuyncoga
 * Smoking Wheels....  was here 2017 hsffooafowznoghxmvlmjommrcvpinurdpbitfrelzbxkfla
 * Smoking Wheels....  was here 2017 xlcrtwdlwuyfixoolwtbnqwnsewflmuiuogwgyjsqlvwlzjz
 * Smoking Wheels....  was here 2017 ybdgungndspomcbhiqgtwzpawgjnyzbtegytobamjczybouq
 * Smoking Wheels....  was here 2017 fppnflsikhnrqiiqhknjfrialfaaruisphzbsynvfbmsjxtz
 * Smoking Wheels....  was here 2017 zjdhtrdaamizrgditrkzmcxxaethtvqevllcweajxtmethlg
 * Smoking Wheels....  was here 2017 qvnrjomxnkzfqxmjjhyxyumiioujmifjsspknpxznvmntdly
 * Smoking Wheels....  was here 2017 vuwwhrwqqlshzlqzbflrarldmbointpwmjbulgutjeddgemu
 * Smoking Wheels....  was here 2017 milozxqcmhyjfkcrzsocntmlrotssvoimzriooobyzltjjov
 * Smoking Wheels....  was here 2017 uqwlgilkhvkxgkqfojbgjjjroejcdmbvlhmidbkpbqoglxyh
 * Smoking Wheels....  was here 2017 chyrzgeyqfaofngomyaluejjwionezkngiuirpqdutywcheq
 * Smoking Wheels....  was here 2017 ebtmlhzgivyijwfzqmtfhzulrrucktczcjfdwhywjgiaffzr
 * Smoking Wheels....  was here 2017 wzpmdhgijishkybzfexjqwgafdthtnwyjzovrlfckipjvrki
 * Smoking Wheels....  was here 2017 jicluhpecqzzdmmhqrfasesmcvkuggujuxxsjqonqjaxivsx
 * Smoking Wheels....  was here 2017 cpblisygzxsasloxoqtkvmgkcezmgdbnfdpjltjzdzzsiejw
 * Smoking Wheels....  was here 2017 spoubbkdxobjlaocweydlrhrfvvpkrfxvadopwgpecgirldz
 * Smoking Wheels....  was here 2017 djxakgjsweofysyiuogzhullurtoopbgbbljuhesiwsjmocg
 * Smoking Wheels....  was here 2017 odrzdilbesvzbfmisgoaifqcjxrbuvnooanchrfzjspuctlw
 * Smoking Wheels....  was here 2017 jmrsfqoqiiviymfehcypvmyesxtzmpychxshputgjgiudnsj
 * Smoking Wheels....  was here 2017 feanvuvzejvgxtjamcrefmupxhmpgjuijbqujtmrokruloqn
 * Smoking Wheels....  was here 2017 beayopqatoewolmllokrghunezngxvwafzaqqxfpnimlcuhh
 * Smoking Wheels....  was here 2017 bwgwbervitrqtjhcoyxbyfwgdewrpacenkbdqwdrbkbtnmxx
 * Smoking Wheels....  was here 2017 qsnghwtvkdegqjwbncgsmxdlnfruqbvafkzwvlqseitvgczx
 * Smoking Wheels....  was here 2017 kmxlofapwbyqmtkogzudjezzkukurmobmgjpzsixfyiefiha
 * Smoking Wheels....  was here 2017 jftaicxasgkzzxlbxycehcaycuucnzaaqlckaacorlskldvg
 * Smoking Wheels....  was here 2017 qfpugpafgogszqtixmywhaescjtkinfxmvfqeacijfdmjtwu
 * Smoking Wheels....  was here 2017 qzhukbgozdlnnvijyimnonpygxmqlilavibuzlsciyzpnqyf
 * Smoking Wheels....  was here 2017 biyizbtrtjfiatlkxpzspmpmockzlwfuxiesdmozxmafumtf
 */
package net.yacy.kelondro.rwi;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.Semaphore;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.kelondro.blob.ArrayStack;
import net.yacy.kelondro.util.MemoryControl;
/**
* this is a concurrent merger that can merge single files that are queued for merging.
* when several ReferenceContainerArray classes host their ReferenceContainer file arrays,
* they may share a single ReferenceContainerMerger object which does the sharing for all
* of them. This is the best way to do the merging, because it does heavy IO access and
* such access should not be performed concurrently, but queued. This class is the
* manaagement class for queueing of merge jobs.
*
* to use this class, first instantiate a object and then start the concurrent execution
* of merging with a call to the start() - method. To shut down all mergings, call terminate()
* only once.
*/
public class IODispatcher extends Thread {
private static final ConcurrentLog log = new ConcurrentLog("IODispatcher");
private   Semaphore                    controlQueue;
private   final Semaphore              termination;
private   ArrayBlockingQueue<MergeJob> mergeQueue;
private   ArrayBlockingQueue<DumpJob<? extends Reference>> dumpQueue;
private   boolean                      terminate;
private final int                      writeBufferSize;
public IODispatcher(final int dumpQueueLength, final int mergeQueueLength, final int writeBufferSize) {
this.termination = new Semaphore(0);
this.controlQueue = new Semaphore(0);
this.dumpQueue = new ArrayBlockingQueue<DumpJob<? extends Reference>>(dumpQueueLength);
this.mergeQueue = new ArrayBlockingQueue<MergeJob>(mergeQueueLength);
this.writeBufferSize = writeBufferSize;
this.terminate = false;
this.setName("IODispatcher");
}
public void terminate() {
this.terminate = true;
        if (this.termination != null && this.controlQueue != null && isAlive()) {
this.controlQueue.release();
try {
this.termination.acquire();
} catch (final InterruptedException e) {
ConcurrentLog.logException(e);
}
}
}
@SuppressWarnings("unchecked")
	protected synchronized void dump(final ReferenceContainerCache<? extends Reference> cache, final File file, final ReferenceContainerArray<? extends Reference> array) {
        if (this.dumpQueue == null || this.controlQueue == null || !isAlive()) {
log.warn("emergency dump of file " + file.getName());
if (!cache.isEmpty()) cache.dump(file, (int) Math.min(MemoryControl.available() / 3, this.writeBufferSize), true);
} else {
@SuppressWarnings("rawtypes")
final
DumpJob<? extends Reference> job = new DumpJob(cache, file, array);
if (isAlive()) {
try {
this.dumpQueue.add(job);
log.info("appended dump job for file " + file.getName());
} catch (final IllegalStateException e) {
log.warn("could not append dump job, emergency dump of file " + file.getName());
cache.dump(file, (int) Math.min(MemoryControl.available() / 3, this.writeBufferSize), true);
} finally {
this.controlQueue.release();
}
} else {
job.dump();
log.warn("dispatcher is not alive, just dumped file " + file.getName());
}
}
}
protected synchronized int queueLength() {
return (this.controlQueue == null || !isAlive()) ? 0 : this.controlQueue.availablePermits();
}
protected synchronized void merge(final File f1, final File f2, final ReferenceFactory<? extends Reference> factory, final ArrayStack array, final File newFile) {
        if (this.mergeQueue == null || this.controlQueue == null || !isAlive()) {
if (f2 == null) {
log.warn("emergency rewrite of file " + f1.getName() + " to " + newFile.getName());
} else {
log.warn("emergency merge of files " + f1.getName() + ", " + f2.getName() + " to " + newFile.getName());
}
array.mergeMount(f1, f2, factory, newFile, (int) Math.min(MemoryControl.available() / 3, this.writeBufferSize));
} else {
final MergeJob job = new MergeJob(f1, f2, factory, array, newFile);
if (isAlive()) {
try {
this.mergeQueue.add(job);
if (f2 == null) {
log.info("appended rewrite job of file " + f1.getName() + " to " + newFile.getName());
} else {
log.info("appended merge job of files " + f1.getName() + ", " + f2.getName() + " to " + newFile.getName());
}
} catch (final IllegalStateException e) {
	log.warn("Could not add merge job to queue: " + e.getMessage());
} finally {
this.controlQueue.release();
}
} else {
job.merge();
if (f2 == null) {
log.warn("dispatcher not running, merged files " + f1.getName() + " to " + newFile.getName());
} else {
log.warn("dispatcher not running, rewrote file " + f1.getName() + ", " + f2.getName() + " to " + newFile.getName());
}
}
}
}
@Override
public void run() {
MergeJob mergeJob;
DumpJob<? extends Reference> dumpJob;
try {
loop: while (true) try {
this.controlQueue.acquire();
if (!this.dumpQueue.isEmpty()) {
	File f = null;
try {
dumpJob = this.dumpQueue.take();
f = dumpJob.file;
dumpJob.dump();
} catch (final InterruptedException e) {
log.severe("main run job was interrupted (1)", e);
} catch (final Throwable e) {
log.severe("main run job had errors (1), dump to " + f + " failed.", e);
} finally {
if (this.terminate) this.controlQueue.release();
}
continue loop;
}
if (!this.mergeQueue.isEmpty() && !MemoryControl.shortStatus()) {
	File f = null, f1 = null, f2 = null;
try {
mergeJob = this.mergeQueue.take();
f = mergeJob.newFile;
f1 = mergeJob.f1;
f2 = mergeJob.f2;
mergeJob.merge();
} catch (final InterruptedException e) {
log.severe("main run job was interrupted (2)", e);
} catch (final Throwable e) {
if (f2 == null) {
log.severe("main run job had errors (2), dump to " + f + " failed. Input file is " + f1, e);
} else {
log.severe("main run job had errors (2), dump to " + f + " failed. Input files are " + f1 + " and " + f2, e);
}
} finally {
if (this.terminate) this.controlQueue.release();
}
continue loop;
}
if (this.terminate) {
log.info("caught termination signal");
break;
}
} catch (final Throwable e) {
log.severe("main run job failed (X)", e);
}
log.info("loop terminated");
} catch (final Throwable e) {
log.severe("main run job failed (4)", e);
} finally {
log.info("terminating run job");
this.controlQueue = null;
this.dumpQueue = null;
this.mergeQueue = null;
this.termination.release();
}
}
private class DumpJob<ReferenceType extends Reference> {
private final ReferenceContainerCache<ReferenceType> cache;
private final File file;
private final ReferenceContainerArray<ReferenceType> array;
private DumpJob(final ReferenceContainerCache<ReferenceType> cache, final File file, final ReferenceContainerArray<ReferenceType> array) {
this.cache = cache;
this.file = file;
this.array = array;
}
private void dump() {
try {
if (!this.cache.isEmpty()) this.cache.dump(this.file, (int) Math.min(MemoryControl.available() / 3, IODispatcher.this.writeBufferSize), true);
this.array.mountBLOBFile(this.file);
} catch (final IOException e) {
ConcurrentLog.logException(e);
}
}
}
private class MergeJob {
private final File f1, f2, newFile;
private final ArrayStack array;
private final ReferenceFactory<? extends Reference> factory;
private MergeJob(
final File f1,
final File f2,
final ReferenceFactory<? extends Reference> factory,
final ArrayStack array,
final File newFile) {
this.f1 = f1;
this.f2 = f2;
this.factory = factory;
this.newFile = newFile;
this.array = array;
}
private File merge() {
	if (!this.f1.exists()) {
	    log.warn("merge of file (1) " + this.f1.getName() + " failed: file does not exists");
		return null;
	}
	if (this.f2 != null && !this.f2.exists()) {
	    log.warn("merge of file (2) " + this.f2.getName() + " failed: file does not exists");
		return null;
	}
return this.array.mergeMount(this.f1, this.f2, this.factory, this.newFile, (int) Math.min(MemoryControl.available() / 3, IODispatcher.this.writeBufferSize));
}
}
}
