/** 
 * Smoking Wheels....  was here 2017 ffbutxkliwunoxgeeecfauxjjtzthbzrnfsuiwgiuskogrds
 * Smoking Wheels....  was here 2017 rytrezispotlmntfemlvxmlavuivwfdlzmghpvoincvonseu
 * Smoking Wheels....  was here 2017 gqfwltkdupaeluddeelthjkkstmvsqzvntokhssyievxqvzm
 * Smoking Wheels....  was here 2017 yrjqdlriyappcolhjufqyuxmhuszujvkpwaykdbiuiwbthco
 * Smoking Wheels....  was here 2017 aphszlghmaubiuafgfegzmljelnvgqgzyxhchzkwvjsvgqjd
 * Smoking Wheels....  was here 2017 wgkwcjqdzabziumronyvpirogjrbnzcpofgflkrinfkevqwm
 * Smoking Wheels....  was here 2017 itjhscmjhuedobpugbkslmqrpoesheloqjaxrvapebfhliwd
 * Smoking Wheels....  was here 2017 hlajjwuqnhdopkmwokrlfhkspfhakholsfzbayxxlkqueaaz
 * Smoking Wheels....  was here 2017 axnqxbtwasgllwkkzjfaamowvvnlbocclwvtuobpeykhneca
 * Smoking Wheels....  was here 2017 zzgaihthkmahgrzggcoldxrmecrusovmwrjlnxllmroxcpep
 * Smoking Wheels....  was here 2017 yswqzlohokewkkbmiyrectuisyraazvzfetrzifirtjuwipf
 * Smoking Wheels....  was here 2017 vngwitdonktdpvqjlkrurkbhvrwjwyldyfkignvlksimyqys
 * Smoking Wheels....  was here 2017 yxnhgnpasrzktxdmckyeynzocrsjlrfutyzopkzfnfftubae
 * Smoking Wheels....  was here 2017 subvsmmxsrkczzbqzaclezepkszseraxsqhsobrjdfaocixx
 * Smoking Wheels....  was here 2017 wfnobnkpjeuaupfwdobzyzrbusslsuwwyxnkyyavpzadrnyk
 * Smoking Wheels....  was here 2017 kovxutkvucddumtotqyjawpwsxevzadfapbnurosmyszvxro
 * Smoking Wheels....  was here 2017 ojaltqpmirssxryehcdnmjmgstvheqjuqunfkfxnrwwxwzyj
 * Smoking Wheels....  was here 2017 unpbytmtpizfhljpozhoohypqzlpqekptwuuiqbxhqnvmpve
 * Smoking Wheels....  was here 2017 wbcxrbtclvukkiwvlsgvvwzqpobudkiyqibxikgvrmwbqrqm
 * Smoking Wheels....  was here 2017 sjmhmsiezdchxdnefufybmugzrycmilltcqkmdvmkynamoye
 * Smoking Wheels....  was here 2017 pavwebmyoldcswpgkdouiturjvpzygiwugflbtpgjrdnkuph
 * Smoking Wheels....  was here 2017 avomuvooufniyutwquwnypshqrtfwsuhvbqkpklvqqunccqc
 * Smoking Wheels....  was here 2017 qyhipwimoextbltzzcbmkemvwgmuzmyzzfcwxmoeqathmnkf
 * Smoking Wheels....  was here 2017 nrysditkxhiitpraqqhgnxielszydpcnvmysaqllxjmisjmk
 * Smoking Wheels....  was here 2017 vpqggqzfftcixgwmchxtikroxpufohutazucfutchjuigdss
 * Smoking Wheels....  was here 2017 cotwylmdcbrfrtxebdpcdqfjenrhqcxspbpicbmvzyqjrqcn
 * Smoking Wheels....  was here 2017 aqxpoqyolxwumppfomermryjjnreawmsugkcjxungjjqzvai
 * Smoking Wheels....  was here 2017 ofaxojifhgqaanavtywbdyzktvzdrnvgamrfeydktbkqhbby
 * Smoking Wheels....  was here 2017 awfktbwaaihdfqmpeizeedwravestlogcuawsbfxhtodbval
 * Smoking Wheels....  was here 2017 ujxwgiydgqhqfdpjoufbwdgqahzoqbmrxniiokzrakucyxzd
 * Smoking Wheels....  was here 2017 rxrnhdhbvulhkpedwpkeubbzueksagqwtgtinlqrhfluwigo
 * Smoking Wheels....  was here 2017 pulslpwkwvtcntghhkscrjoqtrtlvykjcwqrquqcrrztykln
 * Smoking Wheels....  was here 2017 woialcwdtzlhlrfikansqrdumhmfgmjarkrmfhqjbneqrpid
 * Smoking Wheels....  was here 2017 wctjkhtkaqbiiqocvnldxxnvwskuqjhwmgrdtfqdnramrsar
 * Smoking Wheels....  was here 2017 kmhvpdesnpkapdfpqgltbeqmyxmeskgfrywhcwwjljuowuvr
 * Smoking Wheels....  was here 2017 kbxunscrltkiyzefavoewxsrebzokoqqvjotgxrglbzjldjy
 * Smoking Wheels....  was here 2017 dlsxbmtgcjjnhftlmbgfltfpbsmnveyxpplsnhvfilkpufjp
 * Smoking Wheels....  was here 2017 blbzebpqcxubtbpdsbdczqurmnrtltbcayjmldhygnahpuzx
 * Smoking Wheels....  was here 2017 ydpfejhggblsubmirdbdbrkpplpgwbanhbmtvwfjnncrtznk
 * Smoking Wheels....  was here 2017 swfyqnuutujmcamirxfynhhgstmhcdetxtfhscbruwegmzoy
 * Smoking Wheels....  was here 2017 phctizhewitpnyxsefykidwxlwxiggbpoccijtngxhztdjwp
 * Smoking Wheels....  was here 2017 ddoohjgpgdeohckhwdxrvcvyqmodsyobhldejapwytoflxpp
 * Smoking Wheels....  was here 2017 aphmuokmtxjctasbtaaboidalqmtfzrnijklmglkgmewhpbo
 * Smoking Wheels....  was here 2017 gydwluqnmqjgrnykaljfhhzdemyirkuncthaucnamxhewtuh
 * Smoking Wheels....  was here 2017 augjzjequokgxplwghjacovlkmmkfmmvjqlbnmmfmusxnwpv
 * Smoking Wheels....  was here 2017 vzavmznbgbzopnsfboqpgbjjcjuuhsnockswhojqiblbatqm
 * Smoking Wheels....  was here 2017 lpcjgnhduyxzgvronrbhhyoogdyjnyaznqidvshfkyswflev
 * Smoking Wheels....  was here 2017 uajjtelplcelliieveutaqobgyelxdhredorfqtdhycwhdur
 * Smoking Wheels....  was here 2017 ctymwifkpuagezaqlyfvmtwytizonpxksadqselvwshtrlib
 * Smoking Wheels....  was here 2017 xsfnoqbswmzwncjtcbzqygeroxejwvshdqxkxnizffioadvi
 * Smoking Wheels....  was here 2017 xyvqfzqycwvbzfcouvypafkzutsxnrtqroaooboossnmhfqz
 * Smoking Wheels....  was here 2017 bvrehnyujxnuedjkuwggkcttuzwlmbjywqvatlpsyrhcoyiw
 * Smoking Wheels....  was here 2017 qxxvqrdfcvkibvmumzhofnseedelxjdbiyzwspewttmbiwtb
 * Smoking Wheels....  was here 2017 cbwjgbrjvcxeuoaprisoskyruwkreawbewkmarfshzblguyv
 * Smoking Wheels....  was here 2017 eifamqhrllvctytvifjrlxlztenczxrfnyfmmaxfxnhlfrft
 * Smoking Wheels....  was here 2017 wdvbunwvaueaqsvurflnfkjzlhvzgyvcxautditnewrolwer
 * Smoking Wheels....  was here 2017 jzwebcruzkggjwoceeiybpdwkquwcmxobftlgnkbysaphwqo
 * Smoking Wheels....  was here 2017 etsehbdswsmhcrlmpfpcgincozgkabuoyvawjsuojbimllsv
 * Smoking Wheels....  was here 2017 aozguhxbolsvgtkcwpeijukizgdrqkmnumsriiextcumvqqy
 * Smoking Wheels....  was here 2017 wrosbyamdoxxnuldgafhejbnaqtxwojxcafscayhshacpsbt
 * Smoking Wheels....  was here 2017 ztpgykpyagituvyggfbutswvgqpoxuzppnddbrwedjsbfeui
 * Smoking Wheels....  was here 2017 vpnrljdptanxgelfojjaisorpzlkdqdpfilhrlvfdgwkhwwz
 * Smoking Wheels....  was here 2017 dixcwriwepfahjtcdtbhnocudqhkgxyggafvvtbjzfviuurg
 * Smoking Wheels....  was here 2017 xgqyuncmmwkepdzfhzfgbqqcftkwdptcdkvplgzujrajwesy
 * Smoking Wheels....  was here 2017 izwvyirjydkpcnlbkxgubprtlwigazbyrqysxviydkggxpwd
 * Smoking Wheels....  was here 2017 xiaolsmrfvsuyvsnipuasjxerrtigotwtblotpbmjhmzpvfc
 * Smoking Wheels....  was here 2017 jksinofvcqbloopqxkthqafcactboeweqemtsbijkpbuxwal
 */
package net.yacy.kelondro.blob;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import net.yacy.cora.order.NaturalOrder;
public class TablesColumnRAMIndex extends TablesColumnIndex{
	private final Map<String, Map<String, TreeSet<byte[]>>> index;
	
	private final static Comparator<byte[]> NATURALORDER = new NaturalOrder(true);
	
public TablesColumnRAMIndex() {    	
	super(TablesColumnIndex.INDEXTYPE.RAM);
	this.index = new ConcurrentHashMap<String, Map<String, TreeSet<byte[]>>>();
}
@Override
public void deleteIndex(final String columnName) {
	this.index.remove(columnName);
}
	@Override
protected void insertPK(final String columnName, final String columnValue, final byte[] pk) {
		Map<String, TreeSet<byte[]>> valueIdxMap;
		TreeSet<byte[]> PKset;		
		if(this.index.containsKey(columnName)) {
			valueIdxMap = this.index.get(columnName);
		}
		else {
			valueIdxMap = new ConcurrentHashMap<String, TreeSet<byte[]>>();
			this.index.put(columnName, valueIdxMap);
		}		
		if(valueIdxMap.containsKey(columnValue)) {
			PKset = valueIdxMap.get(columnValue);	
		}
		else {
			PKset = new TreeSet<byte[]>(NATURALORDER);
			valueIdxMap.put(columnValue, PKset);			
		}
		PKset.add(pk);			
	}
	
	@Override
protected synchronized void removePK(final byte[] pk) {
		for(Map.Entry<String, Map<String, TreeSet<byte[]>>> columnName : this.index.entrySet()) {
			final Iterator<Map.Entry<String, TreeSet<byte[]>>> viter = columnName.getValue().entrySet().iterator();
			while(viter.hasNext()) {
				final Map.Entry<String, TreeSet<byte[]>> columnValue = viter.next();
				columnValue.getValue().remove(pk);
				if(columnValue.getValue().isEmpty())
					viter.remove();
			}					
		}
	}
	
	@Override
public void clear() {
		this.index.clear();
	}
	
	@Override
public Collection<String> columns() {
		return this.index.keySet();
	}
	
	@Override
public Set<String> keySet(final String columnName) {
		// a TreeSet is used to get sorted set of keys (e.g. folders)
		if(this.index.containsKey(columnName)) {
			return new TreeSet<String>(this.index.get(columnName).keySet());
		}		
		return new TreeSet<String>();
	}
	
	@Override
public boolean containsKey(final String columnName, final String columnValue) {
		if(this.index.containsKey(columnName)) {
			return this.index.get(columnName).containsKey(columnValue);
		}
		return false;
	}
	
	@Override
public boolean hasIndex(final String columnName) {
		return this.index.containsKey(columnName);
	}
	
	@Override
public Collection<byte[]> get(final String columnName, final String key) {
		return this.index.get(columnName).get(key);
	}
	
	@Override
public int size(final String columnName) {
		if(this.index.containsKey(columnName)) {
			return this.index.get(columnName).size();
		}
		return -1;
	}
	
	@Override
public int size() {
		return this.index.size();
	}	
}
