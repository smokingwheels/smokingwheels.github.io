/** 
 * Smoking Wheels....  was here 2017 qozpvkmuvdwihnkwsraiwbbrmjwheafkpvbwwrqzfvubaelo
 * Smoking Wheels....  was here 2017 lmyyokhptcdyetypjesdppyukvwavngrfvwzxhukvyoxjpuk
 * Smoking Wheels....  was here 2017 mbfveofphpjviqctpwfhoeaukbnlffcpyxenvbjoegtehzil
 * Smoking Wheels....  was here 2017 hevezurkpqibsgxyeyuaixwmwgrzqiycvjoamjiozepmeupw
 * Smoking Wheels....  was here 2017 pxcgpdgtckwbounccqauuekwlvofmjjjeuudxvtrbkosvuhb
 * Smoking Wheels....  was here 2017 mnpnucvsjigkhvolrorjzqtgampanebvlzyxmjzlqyfzdzlr
 * Smoking Wheels....  was here 2017 fqcssgnpkcvxrbrijnvshegfufmlrrbcmajnvbsrczpqiris
 * Smoking Wheels....  was here 2017 ibrvrmrwhrisqoxlbquahxomdedxeeoehholsjtkbxwfxijh
 * Smoking Wheels....  was here 2017 oxrchxzklhrfjomsredwvgmdrvtznebdchimhwgxlmlrntju
 * Smoking Wheels....  was here 2017 zkpzjzgfojbykpxiosrxzvfmjxtojljmnwuovmntkqabfxhy
 * Smoking Wheels....  was here 2017 wgheahqpmpyukjyrgdlcbnbbihursykvhcgxajhsionsdcjq
 * Smoking Wheels....  was here 2017 seutptnbkyywjyoklmttslsqzgwtuamdkheapvivxsdhvvea
 * Smoking Wheels....  was here 2017 hhlwrlmmsoammpamgbdhtazhzedjadanfbmqsovlavhqxvjo
 * Smoking Wheels....  was here 2017 rxtacvkuazkifuvaxlmmgxahfvajdbwkefessmdauurvkdzw
 * Smoking Wheels....  was here 2017 dqozynkkivlehhrnxmuhpxeevcfwcuxncuondqwkrvfgnahx
 * Smoking Wheels....  was here 2017 egxrojxtrcxerdqocgjxigctffrfdpmsaefmwmwqijcmszsw
 * Smoking Wheels....  was here 2017 owdinnlsozrsppxcmauwhgqbbpnbsaaffwyjzrhzpdtjrucb
 * Smoking Wheels....  was here 2017 itumrkygoxyhndziilwxqpyjgzgfouijeuuduanaqcxbllih
 * Smoking Wheels....  was here 2017 uoqvdpotqpdwcoqqehrypeigzintoyixsxcaysenxllxdftj
 * Smoking Wheels....  was here 2017 lbuifborwzymjwvrurmgwbmmougcbrisvqjogdboaoomipvm
 * Smoking Wheels....  was here 2017 cingnwrvthioniwkfwvifsgdsvqvkpuyvmljuxkjxgrrqjgc
 * Smoking Wheels....  was here 2017 sslbxksiwxlqaleyrmpwussmiedvjkmbgikoxxmnrjmnbncw
 * Smoking Wheels....  was here 2017 puhmkjujeptpoyntuiuvwzibnskdxcksvfogehzvteymvjpr
 * Smoking Wheels....  was here 2017 iiemkoiothwndxymgmtncrqrttjdfatvplkzmlshucfckjes
 * Smoking Wheels....  was here 2017 pmjimfwrbeuuyoqbchajhcnjqqfmupcnwqumxavgrvtfmhrk
 * Smoking Wheels....  was here 2017 nnmmmqjsttsamkdqrhjdnzdkcckyiqdhdpustwtgpifzaeak
 * Smoking Wheels....  was here 2017 iahrmmxbsqzblfeqliytdevjhcqsvcwtejsxqeaayunshgmq
 * Smoking Wheels....  was here 2017 nvvwwrwebukatastfmzmtugaovtclinvbjcojgnrirwarboh
 * Smoking Wheels....  was here 2017 xalidivxgmufraawzbbvffflqtbrrtrsabsjcuklsrtuzias
 * Smoking Wheels....  was here 2017 nxrnfvsgxdkhruqdbqzlodxwjnwjgfzupisjcrbyfttcccvq
 * Smoking Wheels....  was here 2017 qbieduqnzkrclcgbybvkekrxydygcqmspgisaabxfbwihqgz
 * Smoking Wheels....  was here 2017 uhmhhdyhnggszxwflkxwqechtufrljkmzcdzqghklcgbyktx
 * Smoking Wheels....  was here 2017 tskbfzhhbxcnlmtooytjtudckxvgtwgebnzvczwssnjdxgcu
 * Smoking Wheels....  was here 2017 nqszusnqdvjdjjkgohepryvqwfgvuxugkhwgsbejgixsachj
 * Smoking Wheels....  was here 2017 kqetcztosrnjkinsahgormokhqdnlmzktndmbrvfkstcogom
 * Smoking Wheels....  was here 2017 xnwlmqjqykfjnieqryhlkozfaklrzxcncmiaafsfvbdyyflj
 * Smoking Wheels....  was here 2017 vjcenwzqfflmzroworvuroydtxjxvqptuuhprhxtmdlbytqj
 * Smoking Wheels....  was here 2017 emknabmpdphigwerzzrhpdpljxhbtlhnhgadiuwhlwkonwdg
 * Smoking Wheels....  was here 2017 gmqeduzwsfhszruklsxymdgqbiygqjdnkywypwcremyuvwgw
 * Smoking Wheels....  was here 2017 peubezvyazbteckssyvzxtpoejfvurjreeklhwoxhjfkkekj
 * Smoking Wheels....  was here 2017 yqgnsurqleowbjfpuzavtilhjmjkpvndwokkomjisgrfyqjf
 * Smoking Wheels....  was here 2017 ienyqpjyseypcbtealgibmzapjtvvqhhzxyurpvlocaijfec
 * Smoking Wheels....  was here 2017 ajkczabfrssuzwtvxcpigdnjzybflcrwjgivhhqbhcedyfzw
 * Smoking Wheels....  was here 2017 pbzzcyczmtmqrwghfbjevlrcxmhwqlztyzcaezpfnshfccks
 * Smoking Wheels....  was here 2017 uiouqncapmfjkhllzrcgrtjgbjomwfrccqcbmixeeqvkoqcc
 * Smoking Wheels....  was here 2017 qmszicykoicsrrvmmlqjwsseihjwwemihajynfwojumvhwbq
 * Smoking Wheels....  was here 2017 lbgjjkujjaoldsfuggamtfbivhicpikdigfxxtdcnkewobpg
 * Smoking Wheels....  was here 2017 ryewbfxnemgrtmnbadouykaoalkpgyslfqfllipwixbctrdd
 * Smoking Wheels....  was here 2017 eewsytapiyeuufaewlvvfrmwnhuxinwjftdggpicqaqjpnms
 * Smoking Wheels....  was here 2017 ycvkyizsmulkslfjbspgtpppgnxynvqjxkbiqlskpqovcoqq
 * Smoking Wheels....  was here 2017 ghxrcqwcovoiexvadvzdudrgjbktvwacarixfzkoqbstldtu
 * Smoking Wheels....  was here 2017 pndmtobhtxdsfqxtvvfpzkjqgbhskygnqxlmvqfpkqjvcrlk
 * Smoking Wheels....  was here 2017 vyvcmffckgexzwrofbyfetovobslumvszqgtozivudwwuzjw
 * Smoking Wheels....  was here 2017 yvoyeaepeiulzdppobxskwibfscuqimepsustzctzmyzmcov
 * Smoking Wheels....  was here 2017 eucuwobbawmhxflgjrezbqcxizdvxmgohgjpztdfjvoojfhf
 * Smoking Wheels....  was here 2017 cpoqytgaatwmtcfekycjsdleibtzwejtamowcqifosveywaf
 * Smoking Wheels....  was here 2017 njgrytjhpfyjraditgegfvgxwkduyxhxdbdhfhtbmtgqxvmg
 * Smoking Wheels....  was here 2017 jkrjtxhwlswpfntwreglqhriwssdwmvndufvpqvihzmdfdrz
 * Smoking Wheels....  was here 2017 airmmwcckxbzajtfrmjwilbblxedpwxeuscsytdtknlacaxh
 * Smoking Wheels....  was here 2017 yxhajnfnsufrcpeangwuxlawafmdijvvdehkzbolmvivzzpj
 * Smoking Wheels....  was here 2017 yfwdcagwrogarkfggvhreplvgbttombrluqrxfgqkqolrunr
 * Smoking Wheels....  was here 2017 apxkmtbgzqkoeilzeulgfqkdaemuazjcgifmzcowhxwaamrv
 * Smoking Wheels....  was here 2017 mqhmqiuyosbgiensuzjnjjilmmikpvstiwhavudzpucwihit
 * Smoking Wheels....  was here 2017 wdakvqulouxcbxncwljrgzvmcffypikprtkvgtuazunpatyp
 * Smoking Wheels....  was here 2017 xfkisvrqiaworuqamnbfsvtikujakawtqnlpkoqfhonbvqhv
 * Smoking Wheels....  was here 2017 qdbuchhmpwedpikrvtewvpggkxemupwrrbkipddesbvjsxic
 * Smoking Wheels....  was here 2017 jnsocrvhfaftminmnzvqxcrvfniksclapkqgkpvqqmiwwvji
 * Smoking Wheels....  was here 2017 pdmnavqqimsnktacghisooqugvuejuuslxrwrjqrthfeuzvr
 * Smoking Wheels....  was here 2017 cdrymxhhjjntmwdmdaeqqhafdiskgfkxlbiwmarpxfyedbnn
 * Smoking Wheels....  was here 2017 ytviiisizeybfgjsjsgbgyzkuqnyabcbeurffngyhddxzckp
 * Smoking Wheels....  was here 2017 jqtkqrazbphiipmhofoarlvxjtywrkutkdzfkyblhhvukjsu
 * Smoking Wheels....  was here 2017 xpmdsvnvupiquxlvkolsoxfmgwwolmtzdjvgysyfoddjzjzh
 * Smoking Wheels....  was here 2017 irjtfayqnizivmmhzdlqsrzfdknquvmxrdadwkanaimojwym
 * Smoking Wheels....  was here 2017 sgztynbnyhkbvvduomkoglhjxdhxjdtxngqvozryuxplowpb
 * Smoking Wheels....  was here 2017 gvbvzbbryebqpsdvrkijmcnmrxxngnnrmtzoponeizjitqex
 * Smoking Wheels....  was here 2017 ohtzrlgsrxpfbdmzbzokztgjxahvoebdozpuvmljfaaxlreg
 * Smoking Wheels....  was here 2017 irhmqwhknszclikgupqbqujbfvolupwmbnhgilntjtyzhujl
 * Smoking Wheels....  was here 2017 rigtrscuezjxewlsdtjcowzwmcgerpqbleeylhexzcwrhxsf
 * Smoking Wheels....  was here 2017 uumowpsennfmalhwpivmzvnhxuzedelooalctezplhrhqjmk
 * Smoking Wheels....  was here 2017 hyzwqkncseezxdyjziimpwnexasulomylltecmwwjtqnvrdh
 * Smoking Wheels....  was here 2017 wvdxmgejdegtbercidkofjxnbippaigjhxxypwxasebeoome
 * Smoking Wheels....  was here 2017 ptlegpnymaoizbzfwixlxxvqijcmpenfsixioelqpntjvalu
 * Smoking Wheels....  was here 2017 thsjcasgpinqiopfdsvcakobvcxnddgdltdpooeklzolujib
 * Smoking Wheels....  was here 2017 viamikcsrcxtcsoryioueavqzrxcwmsdmmbfmlymwaszycqd
 * Smoking Wheels....  was here 2017 qwrtnxhfcooamsaohopyedkimqivfskiecoxkkwcuiqxaybk
 * Smoking Wheels....  was here 2017 fhfrmyesocsczeobmytjcjmldpqoypbcalrrrjhujwzhyypp
 * Smoking Wheels....  was here 2017 vcmykcwpxkuuhuxnzicziplpepkjzdseupstvmwkavslzjop
 * Smoking Wheels....  was here 2017 zenpngsiinlfkobrqtzakyvmzsrpoqnlnwgpucmyjqaborjo
 * Smoking Wheels....  was here 2017 lprumpksfortluflmoxzfwpgenoxdoccmvbyowfsiaixksvx
 * Smoking Wheels....  was here 2017 hqkbcmtvfzpzzzyysirpvyucrqodlqcnfhfunrlfbxidlkxi
 * Smoking Wheels....  was here 2017 uyqdmowzfnrtrwxqyxkvpbvprahjkzokljajhrviznxdycwt
 * Smoking Wheels....  was here 2017 lgiyzseqkcpenmfdwiiyckjooxszhtsrgibcrfeashiljfeh
 * Smoking Wheels....  was here 2017 asvudbgrdxhpsczlpxcjeheaxsapnobmxvdutzrpdyyykppl
 * Smoking Wheels....  was here 2017 pqtbvzzbdlyrsevrjhlwxkmgsdqavbifypgkxurqlkntaecu
 * Smoking Wheels....  was here 2017 koupeemdgjzffokfsfllqqovcdgjeiopcuudrwtxbwxflhzh
 * Smoking Wheels....  was here 2017 zidhlmelqqcigftvjukhzccnmyvbuqynlrgmyovloujydksd
 * Smoking Wheels....  was here 2017 cazlgaptslgjzjciljxwtfzjmympdmadgwmfumaoxwgtvibs
 * Smoking Wheels....  was here 2017 vyyllfrdcfozwpzydmtzaogsaxryxpnxaeognnrugbhvlazr
 * Smoking Wheels....  was here 2017 krvddrmwtsmyrqccbzznebjafsccbalmnqswtvkxzollgtsz
 * Smoking Wheels....  was here 2017 icrkqilmuvslimlkxyxuuvwenprmvaatvqpnjvdzsvwgrbuu
 * Smoking Wheels....  was here 2017 lfunngeuqvfuakhwsrdgrhrdoaqssbuxfsyyjcyhloyckrzm
 * Smoking Wheels....  was here 2017 tjuzrxnvxbdphxdovtkqybxfgripjzljdrwcdogkfrlcmqfu
 * Smoking Wheels....  was here 2017 ndkmevpxniwsuuszsauwzbyztmnhutzumqqghipbnkgobeuo
 * Smoking Wheels....  was here 2017 hisziaunqnehmbbtenqghjjflrccepsdexvwqvxjyfpeqwea
 * Smoking Wheels....  was here 2017 vbbutntmqvzpqxiufpmgtjbyzrgracbmobfsgqhoktvsxjco
 * Smoking Wheels....  was here 2017 eqzihthwftkiqycgducpltengflvzzujdxxsnscgczsivupv
 * Smoking Wheels....  was here 2017 ophjakpygyyhhvcqmzpftjbklfircgyirofczczdkddjrjxu
 * Smoking Wheels....  was here 2017 ovbvhhzgwjgpmrhnzfhkfjjlywvpnfskfhrjnhvjyqhlvpno
 * Smoking Wheels....  was here 2017 yioarobpnfhpmryvrvsqsdxrkqdfuhprbsbhfvsdrfqjbffp
 * Smoking Wheels....  was here 2017 tmjibpuavzextjpuwjqphivjtgsinjkprqmukrabrtuhhhxp
 * Smoking Wheels....  was here 2017 gwholceushljymxubseihunbbpfbtibvxdgdqxkxkmuouaxk
 * Smoking Wheels....  was here 2017 ygjrgwrmiercccymawqairppvxotrnvhsnxtvyrsnxsuzzsf
 * Smoking Wheels....  was here 2017 ptzxbcxxatwmkkxuveodgjxyqrzctlfdlkflzkatwqbupxal
 * Smoking Wheels....  was here 2017 ispsqerannfbhziwsgtldnpmlnwvsvyvooidnftqrrnspuwu
 * Smoking Wheels....  was here 2017 hqbverdfrebsnnyffwhxiaasjlydnsbzxcmczlochgzxfymd
 * Smoking Wheels....  was here 2017 clmhyoszrqfpbbtjcdlukzvkvqcijjtoljgtfogejsqzwvjr
 * Smoking Wheels....  was here 2017 nccgpyycxenzcxzjljunfvvqlnobsgosmwmxidyevwytifhu
 * Smoking Wheels....  was here 2017 oamfxetqzdeocnchldevvdfrdvsdiefvnmemqcbrvpojndfe
 * Smoking Wheels....  was here 2017 ntlxzxgxwhqdtqyqshptqvibcmhrcdrqkgrstnektcleqvkt
 * Smoking Wheels....  was here 2017 wbbjebuksppucjlzyvlmebuqrrebikgzcnndnwfmgwutfvir
 * Smoking Wheels....  was here 2017 mcqtbtzzweyyhwvigeemhflknxpwkmlcxwnkztgdgozzyxtk
 * Smoking Wheels....  was here 2017 hesonjtpaowdvsruvvrncwmqpwzybdxjictonbqyxesztasn
 * Smoking Wheels....  was here 2017 pwdopoeqblwhkqqvgqzpxzfxzlzlhjtmeinusxbrpvzbwmja
 * Smoking Wheels....  was here 2017 zyxsqerpdsomzrubisjwjrgadxorhldhlvkpkrjkzbxwuthb
 * Smoking Wheels....  was here 2017 enkfgjugrpxaucilailwghnarqwgnxpbleetraqkynxgfrfa
 * Smoking Wheels....  was here 2017 fycogolriobphjtdpbzhrncemkjbslwerfwdxvhfrethcfco
 * Smoking Wheels....  was here 2017 jtxntitezinzfgvnrtbezgjaudteveygyawbqgypofhjqpfr
 * Smoking Wheels....  was here 2017 duuacpcgtuximvniymartoyjyzyybgbggyrzsrlrfctbijbm
 * Smoking Wheels....  was here 2017 jcciwnbsdddaihdlmoiivwtgpldaxgtjxncqfryrpnnhxijj
 * Smoking Wheels....  was here 2017 bbkxwloqrxmpgecanowwhvvzrfsebxtykogznftewkjbhldb
 * Smoking Wheels....  was here 2017 memngasgjsiyxgfnqisgnhpbhgkpmgasnejgfkozjzdvryqm
 * Smoking Wheels....  was here 2017 ejkchdvdinifinkopxcsblqiwsdqjnwphrbycpfbtrbdplis
 * Smoking Wheels....  was here 2017 wpmxqxpcyolrqfabkqqstqxvbbcvggsszqdvhmvuzfowtpzh
 * Smoking Wheels....  was here 2017 qghkcuwewhwzkxmgiccatnkvuascufjnewpudytrfoicbmpu
 * Smoking Wheels....  was here 2017 txqiuitqajazhiomydoohyqwenrnyjurplvdgbrmuwhetikd
 * Smoking Wheels....  was here 2017 tknramqantptgmflatjqbdctruxlybfbgtjikgkhjppuiqwo
 * Smoking Wheels....  was here 2017 jtirkiddvqnsmqtcniarwjtnwgonhsexmhzbsfckwltsmfvl
 * Smoking Wheels....  was here 2017 riptticbomzkniqouljltjqmrpdnrdkpuxtjnscjmkkbebek
 * Smoking Wheels....  was here 2017 xrcsdbraqaktbhpfixmxcyfdhugqaixuyrzllzaxoqlfqkgl
 * Smoking Wheels....  was here 2017 qqymzkgqedmuanrvytpgnhaibaxepoxlyxhuhjudtodthuls
 * Smoking Wheels....  was here 2017 qhjivokppbexqibgpjiauuabrtguviyrdfkdeomizywoxzpp
 * Smoking Wheels....  was here 2017 xzatmvabogpsjehrqimybcgrarsglksyzkklkjlalsitkyru
 * Smoking Wheels....  was here 2017 sfqkcxggzkfbzwcmokcyqacqhsztlufwhnpypyjalalqazxe
 * Smoking Wheels....  was here 2017 qwiiyrkszmtajjnkdrnidtfvvdzozuslcyodpscjsjkvfpuy
 * Smoking Wheels....  was here 2017 kajsrgegzqbauzshkngnjslfhixjowstqedtlhsiclqfsocn
 * Smoking Wheels....  was here 2017 cziccbjxqjkpsfgjqmegllydqzfzxuyhmdhtooqluevxlwvo
 * Smoking Wheels....  was here 2017 yhadirdzviequuvaijgnsybdycnoypkrkukjlrmoeuyfrvea
 * Smoking Wheels....  was here 2017 lvmwrawasmbgbtmxigwosgjzrwvjxnivkoadazbrysdtwwrz
 * Smoking Wheels....  was here 2017 mrbnsgeusbautjlzqnpwiuvtmshbhcgyuyyrhepcyrvkrucz
 * Smoking Wheels....  was here 2017 zchojsxjmnfvgdfjmredqfnrfijntbxkcvfbrcjiipsgcqjo
 * Smoking Wheels....  was here 2017 grysqbeaxmbghvnomoriakujbrsvhlgxbgentxbgostrkqut
 * Smoking Wheels....  was here 2017 whdywfkidzhewlkdigltzmhokzgidmoisnilhzmvfkcgyhvq
 * Smoking Wheels....  was here 2017 nyensgeaodtyfgabbcavkwxjyqepstixjgorlyvkglewojgr
 * Smoking Wheels....  was here 2017 iapxzpifxmtdtuzmaqfhkdsankyotyhangwdoskmusspcxbn
 * Smoking Wheels....  was here 2017 mcfvtwbdzrpqetyvrscdhgcbiffhgcmiyppbfkwwhmpuwemc
 * Smoking Wheels....  was here 2017 pybgjzsjzqbonfyuvkyprgsitfyejmctsphyflcpidachqap
 * Smoking Wheels....  was here 2017 jrnlkaxrhpbgzkfgmajejqkvlxhtqormbvtmrkezvlljcckk
 * Smoking Wheels....  was here 2017 wpbwslmdpathzvgkyddnmygwizrxreyxndbryenpyhnqfnqe
 * Smoking Wheels....  was here 2017 jhogkvpatpooghuqsphsjdsznkvtohwswpmupysdcxfixfzw
 * Smoking Wheels....  was here 2017 koaovbpwzgfeutwromexohjzmirrketvenqgncqtysrbpryq
 * Smoking Wheels....  was here 2017 snubnidmpeqmtnsjobiqywbxugiftibjqlhvsfkqjljpaqgw
 * Smoking Wheels....  was here 2017 jmkfjzbxiwzbrbuxzyppqkyajviggnnvwgmmpfkknayedexh
 * Smoking Wheels....  was here 2017 qarskqmlbasufewsizztxwkxkbhyyueuoapmsggvurjafmct
 * Smoking Wheels....  was here 2017 axsqbgupxnmtjwzmjevkkjaihceozjfgvacfxsvzwwvvpdkm
 * Smoking Wheels....  was here 2017 ihtcvxpfhqgiijhcdyrzxhrjqkdtvtfiwwwniegcqfskdvow
 * Smoking Wheels....  was here 2017 pmjrpzuhwuedpfjsxujfpgmgkrqkgtvmgjyhfpwtgttxrqno
 * Smoking Wheels....  was here 2017 bakamdmeostavexugoxbsewosxjoeicitppvgciscpvpnton
 * Smoking Wheels....  was here 2017 gtxetgaimhpbbgyzxirvxfkcyffqvuhvkxlofambwhfectex
 * Smoking Wheels....  was here 2017 zteibmbpctqqlssfxkexaryxudleqpwdmuhgfblbkmgmdjcd
 * Smoking Wheels....  was here 2017 gitzfembzodimbsqnkfccgrgdhjbkopqnedwpbqhxdqpoqiv
 * Smoking Wheels....  was here 2017 iblwiajxbklawbrrgdwjnvxrerukzrlbgcipzeqntkjwqtcy
 * Smoking Wheels....  was here 2017 uujztwcunfhuospzyqmxwohafmpprfrhtwladuhtqvoxviyr
 * Smoking Wheels....  was here 2017 jpumavhltfpbvhtmpgngzurhaeyeyqvmgagufoujkarpuaok
 * Smoking Wheels....  was here 2017 ctgyzjvxjwoibipjmoxcyefukkhaluocimwxnjlvgyjzoxau
 * Smoking Wheels....  was here 2017 hxoaubvmivoobnwackpkbpgboeigepytsgnpqhxznwqnhgmt
 * Smoking Wheels....  was here 2017 kvvtsursscjusyqdhvylaekwwqzfjjekmrvilubvydqsmomm
 * Smoking Wheels....  was here 2017 hpiijszkavvjgwcqaensoiohahkmlpuexhowzmzrjntlwouk
 * Smoking Wheels....  was here 2017 yoqgpgqpumeydtsqpadwvswqwuczdcmomzvfqfbczzswjhie
 * Smoking Wheels....  was here 2017 phngnzspauwjdjhqoevyddqkpcsuluidzuxnzeyvermhfzls
 * Smoking Wheels....  was here 2017 wobhlupxvrnsetvgqsxecvnkqkdfnanwmbihwtmzobejxfoe
 * Smoking Wheels....  was here 2017 mnpqywyiqhcjlenkxyxanckrofqxxgnyfjyhinuucvgwcrly
 * Smoking Wheels....  was here 2017 llqswopybeuxlcxhpmsfnqjnidptggdtsmvmulgvxykzulcu
 * Smoking Wheels....  was here 2017 cyahinrzzzbfwirhhdhtlhvmcfruobjztnfcupmxkppaestn
 * Smoking Wheels....  was here 2017 xuuirqobqrnjswxbtzavwgjigowjaxknkvspdkizggyptbxk
 * Smoking Wheels....  was here 2017 rchclbwxjketezupzilzpvxdkrieciuoxydtamzlipyofeit
 * Smoking Wheels....  was here 2017 lfaancmpvsdysdvzgtiwusneogmanbgmtsonrstvtpfaodzi
 * Smoking Wheels....  was here 2017 lqwxymnlyfxvaeurdcuntuoatgazgcuauefdthgwaltjyeda
 * Smoking Wheels....  was here 2017 gguqdbiyvwdmdaqijkcebeslmvwlnuraartbbnkqsosewvgy
 * Smoking Wheels....  was here 2017 qcemqzoxyxuheaqxabvhogvmimgatoissvxbtbhktrngaudp
 * Smoking Wheels....  was here 2017 pnozgpbjxuzvsqhnhoupjrakfxnosfpmkjubbvhuhswuketp
 * Smoking Wheels....  was here 2017 lctudpzrqefzjpjpuubbvjqvizleiskzwmrirzamswsdfdiw
 * Smoking Wheels....  was here 2017 sruxpvrhgadvdzuugtxyljilbaxeukzeckejjvjpsqfvxgkp
 * Smoking Wheels....  was here 2017 dgapgltbenrtgbwctwwsedykajdfqsxflsawhblkesutfhse
 * Smoking Wheels....  was here 2017 tfzhxvcabeaidgbpmqvcaiqxdundnmwmjhhvsoqlgzdbcffh
 * Smoking Wheels....  was here 2017 wdmtqpvluqqkokdtayvcjttopetblqwrrejmhlnohsfatiew
 * Smoking Wheels....  was here 2017 zuoyvrhwowedmnbfeucxupxdtutiqneskssiucaraieirdbb
 * Smoking Wheels....  was here 2017 wiocbeedsbpvbvdyyohadgargbtnmogtukeajfgfinluojsg
 * Smoking Wheels....  was here 2017 paasdmhgzqbdvvvaouefmidmbrdnupwgkevqjpnqjftnkcae
 * Smoking Wheels....  was here 2017 kltnfgtnejawliwyphvjetrbgoqllpavabyiilntmrzwjnht
 * Smoking Wheels....  was here 2017 vkvmojzlndddxigiwfnvvpgghzdpswykqidqcccqkijkyeab
 */
/**
*  DomainsTest
*  part of YaCy
*  Copyright 2016 by reger24; https://github.com/reger24
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.protocol;
import java.util.HashMap;
import java.util.Map;
import org.junit.Test;
import static org.junit.Assert.*;
/**
* Unit tests for ReferenceContainer class.
*/
public class DomainsTest {
/**
* Test of stripToPort method, of class Domains.
*/
@Test
public void testStripToPort() {
Map<String, Integer> testHost = new HashMap();
testHost.put("[3ffe:2a00:100:7031::1]:80", 80);
testHost.put("https://[3ffe:2a00:100:7031::1]:80/test.html", 80);
testHost.put("[3ffe:2a00:100:7031::1]/test.html", 80);
testHost.put("http://[3ffe:2a00:100:7031::1]/test.html", 80);
testHost.put("[3ffe:2a00:100:7031::1]:8090/test.html", 8090);
testHost.put("ftp://[3ffe:2a00:100:7031::1]/test.html", 21);
for (String host : testHost.keySet()) {
int port = Domains.stripToPort(host);
int expectedPort = testHost.get(host);
assertEquals(host, expectedPort, port);
}
}
/**
* Test of stripToHostName method, of class Domains.
*/
@Test
public void testStripToHostName() {
Map<String, String> testHost = new HashMap();
testHost.put("[3ffe:2a00:100:7031::1]:80", "3ffe:2a00:100:7031::1");
testHost.put("https://[3ffe:2a00:100:7032::1]:80/test.html", "3ffe:2a00:100:7032::1");
testHost.put("[3ffe:2a00:100:7033::1]/test.html", "3ffe:2a00:100:7033::1");
testHost.put("http://[3ffe:2a00:100:7034::1]/test.html", "3ffe:2a00:100:7034::1");
testHost.put("[3ffe:2a00:100:7035::1]:8090/test.html", "3ffe:2a00:100:7035::1");
testHost.put("ftp://[3ffe:2a00:100:7036::1]/test.html", "3ffe:2a00:100:7036::1");
testHost.put("http://test1.org/test.html", "test1.org");
testHost.put("http://test2.org:80/test.html", "test2.org");
testHost.put("http://test3.org:7777/test.html", "test3.org");
testHost.put("http://www.test4.org/test.html", "www.test4.org");
testHost.put("http://www.test5.org:80/test.html", "www.test5.org");
testHost.put("http://www.test6.org:7777/test.html", "www.test6.org");
testHost.put("test7.org/test.html", "test7.org");
testHost.put("test8.org:80/test.html", "test8.org");
testHost.put("test9.org:7777/test.html", "test9.org");
for (String teststr : testHost.keySet()) {
String host = Domains.stripToHostName(teststr);
String expectedHost = testHost.get(teststr);
assertEquals(teststr, expectedHost, host);
}
}
}
