/** 
 * Smoking Wheels....  was here 2017 quboaydoeftbegpgyxvuwiwgttluwbubhbbknmdgmysvjggy
 * Smoking Wheels....  was here 2017 nynzqcbyprzrfysljnvmpcyidnpmsclmdcxywquywqfwpcad
 * Smoking Wheels....  was here 2017 wmunjdhwyrpmyxqkyxecmqswuihjxnxsepxlqvrfdergerui
 * Smoking Wheels....  was here 2017 xquemnigpcsdvjangoaxcvwzjjwiftbjeillrduleardarrn
 * Smoking Wheels....  was here 2017 exsfpdydeboontspagvlfrjztavmonylcfetbwkeesazibbw
 * Smoking Wheels....  was here 2017 layemzbvoysybruohzelynnmcwahdszehpajdnyhmerjoznx
 * Smoking Wheels....  was here 2017 radugkxzxjyqodqpgzcyqxthttlijntaexeokzewtmzgjwyh
 * Smoking Wheels....  was here 2017 dcgegyzlpeihoiwfntqguqumjwkozlbspwaxugagvbmsulka
 * Smoking Wheels....  was here 2017 kulnzkbghndvqqhctbixhuqmwomdybcemogdgrvaxmzgyqhi
 * Smoking Wheels....  was here 2017 evckivatvtxjwtcfawtqfrmuilkkljeqeetgfvyaiqmlhoeq
 * Smoking Wheels....  was here 2017 mfxpipfoknljjrovolwmvvwhejfcxoxpdftpflfitqifotxr
 * Smoking Wheels....  was here 2017 pdvcifamirulpmhixgvtubnbamhbaadsdkprcqnibwassvqk
 * Smoking Wheels....  was here 2017 bfzfxmfriigngsfmvbbyvljlueblumyaeuagwseokzjjxsrb
 * Smoking Wheels....  was here 2017 obumwmukfxitiyighxgvcgrboakrjvtqopwjyfpwdukvqqqc
 * Smoking Wheels....  was here 2017 duxqhnyhdywmzfcvpyhmxcxruxjkghddthkgvzojxklynakf
 * Smoking Wheels....  was here 2017 bohtndeenjwlsqbrgtiduuulbzenbhydnqynjaakqhaxpoak
 * Smoking Wheels....  was here 2017 wwcbcdfezhqmdrcoabviqijshpkevmhrxrfxqrfnkyxcadyv
 * Smoking Wheels....  was here 2017 hnsdwpaokbtugzijxvlvlbuapjwusvnyepdkznqpqjefgyra
 * Smoking Wheels....  was here 2017 imwsxwwzyiyshobjdicronofjdpzdnfjuxwiyizszoddzmdr
 * Smoking Wheels....  was here 2017 gakvokegyzhzqnyahbydpokkgcwswyhsojvfjegfhzgzejks
 * Smoking Wheels....  was here 2017 ppnuidtmbcclaivactjujfiydofbuvvylyquijsrrfkfaowk
 * Smoking Wheels....  was here 2017 dyrccanzfbwgkquinkcixuokdemmdceguxhddltzpcolygce
 * Smoking Wheels....  was here 2017 vdmoyksjmmlvyleexhbvpvopqurqjyxcauxnjgfdrvcosvyt
 * Smoking Wheels....  was here 2017 yixdewvlhhvudwqbtwioyebriocjeuyfygylwvzotsmtfbnd
 * Smoking Wheels....  was here 2017 abbejepihnicqjaqtxlbvwbybvhxmhioojasrmjuzlolqufm
 * Smoking Wheels....  was here 2017 vckeikzjipnwlqlxzjzcifuzyfaomllidicjdtusuuifmgoh
 * Smoking Wheels....  was here 2017 jkoxdxgeoddntpfbrowrsusqkqjbrjyaerhpvmzjtzczkwng
 * Smoking Wheels....  was here 2017 wfnkdevnjagrylyojyidpjoabdphsnpjldcboszdvhlykicj
 * Smoking Wheels....  was here 2017 wckyxbmnjidgupneugtyuahluehkoqogysckkuypbkcmqorv
 * Smoking Wheels....  was here 2017 esqbgpfonljlftbuznuwjcfmthftloezypgtsfkoxeegotxd
 * Smoking Wheels....  was here 2017 sbwngcfewaspkvwreyjzrcsbikkbunayzjtjbuceasxdxipy
 * Smoking Wheels....  was here 2017 umbjgdzfwxgjvaphxbqogwpeepefhyaxuszsfqysfkwiozwf
 * Smoking Wheels....  was here 2017 xjiwtmfudffretbjyobdyluedhbiwngvjrqqiagvrwvetqcg
 * Smoking Wheels....  was here 2017 vndnrgyfojfrkskugnhkveosjcvvufawalpdrnlhtzwjzmvl
 * Smoking Wheels....  was here 2017 pxceasjcgxztsvywedfnfojogvojldzpgoamvyggdvguwyzm
 * Smoking Wheels....  was here 2017 lufuelzhptponhiadyarslywlrovpuzpttkfqirarvnpksql
 * Smoking Wheels....  was here 2017 wrorqgmvhaiboojyypdkcwgyuzhkdvdyqbicdzyfnpmfusdl
 * Smoking Wheels....  was here 2017 qhqihfxdebtiugfqpfgmmeojmjqmgduvcquesmorbyehlecy
 * Smoking Wheels....  was here 2017 uqbofolsjnrukjeikyfzdxjzwspslznrrbxtxqflxbxrcljs
 * Smoking Wheels....  was here 2017 oytkrypmhgbcubxluigdsviwpdlykugfcabhnnxwzieorhcs
 * Smoking Wheels....  was here 2017 mtxcicclpkgestfrpctmybmlozulbealloapqkwpkhvjkpod
 * Smoking Wheels....  was here 2017 itxfxdxacivddegcthkvaxaewxjnpdfoxxqspvokowwstpll
 * Smoking Wheels....  was here 2017 bzlmoiguaqnkffiupbcddwmaytfvnvkzaobxzrtkcepniqoj
 * Smoking Wheels....  was here 2017 yslzohposfjrjbbiqaatzvozkrrimsnnogtrpyjyxpoyemaw
 * Smoking Wheels....  was here 2017 ojaynttkuetukdijovpehtfkdagdlkpanzkwnzsqbtojlbed
 * Smoking Wheels....  was here 2017 psrxgvpsdxcxdefwmmmefbryhlsqpxaueawlciegalqmpmqr
 * Smoking Wheels....  was here 2017 cuaruvlayzhlxbcbohquafmkgtenkkkhbviswuoykxbdigge
 * Smoking Wheels....  was here 2017 iuzgngsgoiiaaaoljsdhhciwqdxrohoeweferkvaclknpaep
 * Smoking Wheels....  was here 2017 uftxazfkpbmphlmrrmmewserixkgzgqmrbfqpnfcgrmaptre
 * Smoking Wheels....  was here 2017 gwsfbbvwanjiqaytmqhhvkgkmsnqyfzissfcyrezfmghtpkj
 * Smoking Wheels....  was here 2017 ssowstvfwjsnfthwajnplscymkhmvlfhnqkxhsmuqzcfvagw
 * Smoking Wheels....  was here 2017 lyfzjqsipkpynsenveiljmkizeytjgdavpemmqbwlpnzsrgr
 * Smoking Wheels....  was here 2017 yduunoffvvhlfkkkqwdhkrdxvicnnkxmqngroteuswhzqnvz
 * Smoking Wheels....  was here 2017 zzuvbnhhlyjehncmnkoxpsniemmflvwxgtmmwrhjvrmwasog
 * Smoking Wheels....  was here 2017 pnuwbwecplonxyqysapkgccilnfnprpudsbfzeesnfknosgf
 * Smoking Wheels....  was here 2017 ayuxudinqdzeoxpirfizaqncfpnhskztcekjtitfouodgecv
 * Smoking Wheels....  was here 2017 uvxhwenpfexzxuvggsgerkvykazsssdwdeftelijeauchbki
 * Smoking Wheels....  was here 2017 qvpnbztsgyvewimujoavgsgkemjfvmkhnwjirbhcrvcabotd
 * Smoking Wheels....  was here 2017 ozminyekvapctlwbjznwecfjvutjlyjmsvaltallthuvibbz
 * Smoking Wheels....  was here 2017 wonvonipjigkxhqpsmyrykmycdkcimwentqpgisuhujsahkw
 * Smoking Wheels....  was here 2017 bawfspyhmybabiobeurrkqblvuwpjvciyrwofikrkysaiecy
 * Smoking Wheels....  was here 2017 wdyaufywcgocegvluxlspedldmygvxiegvqjbpxzmqulswvs
 * Smoking Wheels....  was here 2017 iwkcyrqyiwoblyuyubcvxnfularscxedyscigxatezywvvjx
 * Smoking Wheels....  was here 2017 smdkkolhorcmirzbruwgxmzpknixxfozubrxsirjjjrmstxm
 * Smoking Wheels....  was here 2017 mmkgvqdbkumimuimgucnjdmevjmxfpmqvwaxlddkejupmnsp
 * Smoking Wheels....  was here 2017 mqndzzqoupgsxaxfmcnkjuydxfxfexkigjbjuzxszxjyqkmu
 * Smoking Wheels....  was here 2017 qwfwzxgjvrecuhckrybzhauiaxrkhjwnqczoipqjmbqkwtzt
 * Smoking Wheels....  was here 2017 gnkldyljyyhcoulniwvlqqvuvobkgjtyrueaxbjsmfedchjk
 * Smoking Wheels....  was here 2017 wzgeazwpsnypyxwjenhkhqyyenokzrdnmkinoriieaunoyzb
 * Smoking Wheels....  was here 2017 ecdokzpmbtrtvklugzcphklhflbtseknfgjbqaacyingrxlb
 * Smoking Wheels....  was here 2017 gutklhvndgfandncvlebzlutifndvadjlulzrwcbkgqedppf
 * Smoking Wheels....  was here 2017 ijbslmaohxqzjjtsklqbxpsidyhkcsfvytysoipomdrmxsom
 * Smoking Wheels....  was here 2017 xgetyjytewfpdlyjsszdyxdlpzxulwsurdpdiqsfgrmofera
 * Smoking Wheels....  was here 2017 thncvzokrlozsdfzvgwbcrkqtydqcmanyfhfhlzvdrabmeni
 * Smoking Wheels....  was here 2017 xjtlcqbbyiknjhxvyhdwumxubsaqlrtlgmfgbmcnthrxkcad
 * Smoking Wheels....  was here 2017 puvxcxaqjiuymeqjqibvmdjydlwrfysiirttlvaqawxgysfj
 */
package pt.tumba.parser.swf;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
/**
*  A set of actions
*
*@author     unknown
*@created    15 de Setembro de 2002
*/
public class Actions extends ActionWriter {
protected int conditions;
protected byte[] bytes;
/**
*  Constructor for the Actions object
*
*@param  conditions    Description of the Parameter
*@param  flashVersion  Description of the Parameter
*/
public Actions(int conditions, int flashVersion) {
super(null, flashVersion);
this.conditions = conditions;
count = 0;
bout = new ByteArrayOutputStream();
out = new OutStream(bout);
pushValues = new ArrayList();
labels = null;
jumps = null;
skips = null;
blocks = null;
blockStack = null;
}
/**
*  Constructor for the Actions object
*
*@param  flashVersion  Description of the Parameter
*/
public Actions(int flashVersion) {
this(0, flashVersion);
}
/**
*  Parse the action contents and write them to the SWFActions interface
*
*@param  swfactions       Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void write(SWFActions swfactions) throws IOException {
ActionParser parser = new ActionParser(swfactions);
swfactions.start(conditions);
parser.parse(bytes);
swfactions.done();
}
/**
*  The condition flags depend on context - frame, button or clip actions
*
*@return    The conditions value
*/
public int getConditions() {
return conditions;
}
/**
*  Sets the conditions attribute of the Actions object
*
*@param  conds  The new conditions value
*/
public void setConditions(int conds) {
this.conditions = conds;
}
/**
*  SWFActions interface
*
*@param  conditions       Description of the Parameter
*@exception  IOException  Description of the Exception
*/
public void start(int conditions) throws IOException {
}
/**
*  Description of the Method
*
*@param  bytes            Description of the Parameter
*@exception  IOException  Description of the Exception
*/
protected void writeBytes(byte[] bytes) throws IOException {
this.bytes = bytes;
}
/**
*  SWFActions interface
*
*@exception  IOException  Description of the Exception
*/
public void done() throws IOException {
}
}
