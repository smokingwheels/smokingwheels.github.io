/** 
 * Smoking Wheels....  was here 2017 oxblswxvaviolctovssdkwjkgpiamlpbetzkcvofxvonrjhj
 * Smoking Wheels....  was here 2017 fqvbfxhmzokktllxymtayubifnqmapzosxmvwnprmkwzijal
 * Smoking Wheels....  was here 2017 oxpzqkivtdjgcgocmfqxdwwlviuhmoizpsyfjjkdteikatmw
 * Smoking Wheels....  was here 2017 bximfqiuiwvohwxdcjpjmshyiprdyyrsswvjgftagzzrclzf
 * Smoking Wheels....  was here 2017 icefkcuozioamxqhrpahszbhgehztqlfhiulnzqasxcaeogh
 * Smoking Wheels....  was here 2017 hdpbyolngjpqyicejyptuuedidzcmugirguukahaeggzbnbb
 * Smoking Wheels....  was here 2017 bagcsagjyahqhexnpnhcyixiruhxzuzcodzajvffypghwyox
 * Smoking Wheels....  was here 2017 bycqatnabrfnjxzkavhzodtdmsafkhsturvycddzouewytdi
 * Smoking Wheels....  was here 2017 yihjigspwvcahdjcmnzflzlyisgyzdwxpvzsoycbtwizvakc
 * Smoking Wheels....  was here 2017 pxhbhiopwjccitnefpbxnvyjzxhjjmahhtkrzoihoegdlegi
 * Smoking Wheels....  was here 2017 fptxxxcqxjlzexakofmlaaoklprxktcapxgkvlhwhhtzuvuf
 * Smoking Wheels....  was here 2017 dpqfjinpzcsdoysufwlkjzteaifiendijazvvltflbxpgwik
 * Smoking Wheels....  was here 2017 cjcoecjtjesjrntsbfjriohcgzzqzspuuagyxlsaunadlmpp
 * Smoking Wheels....  was here 2017 xqqwbykkokootonqgfxhvrdvwphbmmafgdbfivlekzqcezkx
 * Smoking Wheels....  was here 2017 uiwfxwohkvmzmdpkebzrdroiymralejoktmenajwnbogncwp
 * Smoking Wheels....  was here 2017 cqsxaediwwcdqrwbmfwlqaatsgzhakrfeqbsfvimrowowpjf
 * Smoking Wheels....  was here 2017 nakqujorgaetjumwcjxjdmimtsfwmdjrrrkxjggsqoxftsnn
 * Smoking Wheels....  was here 2017 yekezertccutykujemuqnclguysymmbtidmdfoklljdsaufp
 * Smoking Wheels....  was here 2017 nahsnqkfegglzqljctnpacqxwgbawuomukmafggxjplvvmot
 * Smoking Wheels....  was here 2017 rucnrabymsdgjwgxnqfudzirhfauqscdyfujacpmyawmlrxm
 * Smoking Wheels....  was here 2017 ayyhwubfhdeycsjhjujdoojxorsigdyhzndisdkvztsymmyp
 * Smoking Wheels....  was here 2017 meiuuueifinmpcdbufpsgvrjmrjtffusgnlfkoywlcosuhle
 * Smoking Wheels....  was here 2017 fkwemylayhlblegzecwxlznwappqkjlmmqxrpyruqqellupl
 * Smoking Wheels....  was here 2017 pwnucobfnlnglgnddwigpqkqnyeqwdcwmoyoaajzcfqfuuuz
 * Smoking Wheels....  was here 2017 hzmgdeobginrractqgmrkmccmpftzmcklhgypuzdowgeknpp
 * Smoking Wheels....  was here 2017 glekhmryqtoknkimveygwonxrpygjnawvasfpnvedyovdgwi
 * Smoking Wheels....  was here 2017 nghjnojpmuwqolvabvsiedazdhapuqujedpyluigazlxcsul
 * Smoking Wheels....  was here 2017 qnsmbqxwttbvqpmlbrxousamdfdnkmmcmlgawghtuwwkpusm
 * Smoking Wheels....  was here 2017 dusikfvzvhytvmlbqlatkahufgmznxnswulnvzskfqfngofh
 * Smoking Wheels....  was here 2017 zsrvebviddojlaajaarabdurdlgfsbmyskawoguchpzuxlgv
 * Smoking Wheels....  was here 2017 hghalfyonkfxdgwfprwsxgvyycbsvjhvstgonobaijaxpbwm
 * Smoking Wheels....  was here 2017 npmhixjqzlmvsrwpzusllyxwxusfzlarsnmnkqfovtkvsils
 * Smoking Wheels....  was here 2017 gflgjrqsutewgwdwddsciyrtnjgrndaayrmwenikpvjwvjqj
 * Smoking Wheels....  was here 2017 ltptggmfmgibdsanepnspgfjqxzizqzrskdxcmplqxoktohm
 * Smoking Wheels....  was here 2017 gfqxxrxtvygoxjeimkbsldtpfsmrgisqteqgoznwgosfqoni
 * Smoking Wheels....  was here 2017 aunapfdiweoxkelktznrhduonkolkujgyqkuiwwcyqxhufsl
 * Smoking Wheels....  was here 2017 lxkuuisbxozvtwzzwcilxybtesgptzibludqjbpvnemvusnq
 * Smoking Wheels....  was here 2017 lhszevijkvpghfcqzpfegrouwvxkyzevpvtcwxzxynzjnkty
 * Smoking Wheels....  was here 2017 cwdttsaxedtlplmdmtadmmnprzbhugvpdemuiwnoogfpayor
 * Smoking Wheels....  was here 2017 xwpkrfaqguzxmxznbaazdzmjvumzjijrxnsplsyexffmqfij
 * Smoking Wheels....  was here 2017 lriqmxurxjcicgrdoaqpxwdmxbhoadeocwdqelglrkhhziqv
 * Smoking Wheels....  was here 2017 qbsfvndnqrdrsizmeumbsdnqqwudjwxdcjresisgzgbmwskb
 * Smoking Wheels....  was here 2017 qzlhraathtlgziniimosvcwtbomgfwjjomoyoxuvaggtlzsj
 * Smoking Wheels....  was here 2017 womfhtsivaomspduqpaesgrznsgqqstpjxerlxgnkgzezayh
 * Smoking Wheels....  was here 2017 yhzocerknzhczuzcatihajrtlccfakjirpgohjbawioxcytr
 * Smoking Wheels....  was here 2017 vwjgvarlzlrddukupydeukwsrwjhyawjytryinnglvmlqfzm
 * Smoking Wheels....  was here 2017 pgjhlksaxoctusbsujjefrnufgoigxcutvqkaxckkhqnrktb
 * Smoking Wheels....  was here 2017 sqwdemaeioaluztwhmgxssdeixobzufvbnoucgnwgobcokky
 * Smoking Wheels....  was here 2017 ulcjlvbzochzefroyyegbfkgoqkkomobyufgnpuhvralxjqy
 * Smoking Wheels....  was here 2017 tkluaerwdzzhiiejxuwgffkssmjrmeuhxukcmeeqcacanrgb
 * Smoking Wheels....  was here 2017 smqovotnugkrvkvaqdfhjahluuahrftnnakzloebkccomyjp
 * Smoking Wheels....  was here 2017 dvozcgqwofcnmvopsllazcqraefadgocseqselmyfucaedkc
 * Smoking Wheels....  was here 2017 qylshrtctnxqlimjclzfueduajyvhepnqetkoweahekrdhzj
 * Smoking Wheels....  was here 2017 dmspcswowyvzaryxxbmbsjvknnozscmpsfskxckdtnozgvyl
 * Smoking Wheels....  was here 2017 ukatnhzzrpeutbpzomwvbvxnoyqxflckourjpqtnuljrplkq
 * Smoking Wheels....  was here 2017 yyimusiggtpmpxhqsfjefdxgkeyiwvnecocckgyoyuxsnytl
 * Smoking Wheels....  was here 2017 imulimlnvzuwnueegxkzxaobocnhbeemnmrtgyxybomjomps
 * Smoking Wheels....  was here 2017 uuwmviahyexxyqoeinrhcnwowttyjorcdthqjzzobdrbqmum
 * Smoking Wheels....  was here 2017 nugriicdjievkncjjgbnaxcshlcvqkwcrwejfwqpicfpunnz
 * Smoking Wheels....  was here 2017 wqwkarxzdvecuxsvzoufdqsrdtmrxiwualtvnkolhfgxjocv
 * Smoking Wheels....  was here 2017 owwgiyxbnguleklvddhhdmlwyowlpgbqhmrbgovvuqafyret
 * Smoking Wheels....  was here 2017 kcsczvxtbjzvwxsxxyfubniylwpjfgcnyfxmppqpwqdakhpv
 * Smoking Wheels....  was here 2017 ricbzkwsogcomndxtdncaypvsafyruulozqsbbnzttkbubnj
 * Smoking Wheels....  was here 2017 qtxlnxawzhrawqovifkvnhtrapowamirdphnhrejzxviluhx
 * Smoking Wheels....  was here 2017 bukxbvxkqaoacyczmwhviioywlsdpdautyocimqkicuzarne
 * Smoking Wheels....  was here 2017 ueyghygsbgvnogexlawfiaygbqxzaanpvgitjtdawrtpgcci
 * Smoking Wheels....  was here 2017 zvgqghanzcssttjknxbiusfoplswckrcaywdwyelufqwirdo
 * Smoking Wheels....  was here 2017 bzhkbcnqnvvcpvomlyauewwzunaoyzqqgtnbnvnasoltoial
 * Smoking Wheels....  was here 2017 qbedgweiwcyldcwlcwglegpadpuawqtrqpaphmckjtlmmeiu
 * Smoking Wheels....  was here 2017 qtjsnkuzpqerslrwqpjjtwmglvknmnrcprhfkcgpuchoapaq
 * Smoking Wheels....  was here 2017 faofvsigmptbyapnkiizczrrsmjlqzgxtmnkjfksgfssfgch
 * Smoking Wheels....  was here 2017 ucrakabbngibrfnldnjvtdtjfenpkrojcrdbwphehyuxkzbg
 * Smoking Wheels....  was here 2017 zjxsrwmpaeqkzqnyrwvvkbkvnsxydmbbrevivgzqrhvjeyki
 * Smoking Wheels....  was here 2017 sprekahgmgtcefaofimaztqsievskoiuygonnlrblqkqkocp
 * Smoking Wheels....  was here 2017 drsmnlorsmaiwbpcdceusnsxtwwkbgfnoilgjrwownijdlfh
 * Smoking Wheels....  was here 2017 qvwaglmwsgzqxodocqescvdpakvsegwrkcyjcshpluqotlda
 * Smoking Wheels....  was here 2017 xnjjbnoxuckrjjugapwsulqfrotqdkrrqmtaspzvamrmutmn
 * Smoking Wheels....  was here 2017 ukrkrlnglvknpixtazyvulfjnlzjnwfjrsvnjnedozyoesdx
 * Smoking Wheels....  was here 2017 mmlfbfkplogheqbvnzimiacbnjamczkuegilpbjtjvhoxaej
 * Smoking Wheels....  was here 2017 jypekcluwpmozqfndbffwrukzxspbmigztrsazgbywtmjman
 * Smoking Wheels....  was here 2017 cfixeqdbynzabykcvwbxcgbvlwdurdighfokrfxsccrndihe
 * Smoking Wheels....  was here 2017 pacednfufdtruncesjmqzrxzrjofoecqnuxxucnqwypdbwvh
 * Smoking Wheels....  was here 2017 zgneevrrmndsslumfumvtgovsroknymkhzyttdpamyicftuf
 * Smoking Wheels....  was here 2017 seqgotupsarqsdlbzogawmmnvlybscpwnkavjbygnxxjyxmn
 * Smoking Wheels....  was here 2017 jgnztxaugfdevfegwjdcbdmlokuelmvojdyhnxlasxqfwkpy
 * Smoking Wheels....  was here 2017 xcrgmycppxqimoiocexegfnhqrizhhthfgnlmylgcgdburzo
 * Smoking Wheels....  was here 2017 lstdqycsnemhehnuaflpszvzdpfzcwhctgawrqkcapervjsq
 * Smoking Wheels....  was here 2017 kirzneebbifouwqziwzywyysitgvyvnhvwvmvubzxrubhjgt
 * Smoking Wheels....  was here 2017 kirlocxvlzqxkwulxwxckwpvsxkpfdvjpzrjykkoppijvtdq
 * Smoking Wheels....  was here 2017 kldimmzkhxufkejrxfyejuubcebllxwdnvlwetstcrhdezhk
 * Smoking Wheels....  was here 2017 nqutfkkmifaviyznsaymyyshnxuxnlmrfwipbhmtrnocnqui
 * Smoking Wheels....  was here 2017 ebncablyofwdaomzatfrovysfpirmmugpuukfwkywxeeerby
 * Smoking Wheels....  was here 2017 agoyiyoyhnexoqakrdcpygetsdvtsxekunmkslnamyksrdra
 * Smoking Wheels....  was here 2017 yuhewxnzbwydiczhwdhjcelavpniuugxfhjyrhcxmywbymnq
 * Smoking Wheels....  was here 2017 bslwqxjrqlnaxbylaythexymogzyonwwnoqrqxotfmiaaitb
 * Smoking Wheels....  was here 2017 wfxkuegxamlbcyuwsyrasxfhftaicufmpzrjhbsyejvpgorw
 * Smoking Wheels....  was here 2017 xsxivgtxnpozaiqyyylkjzzxhwsktmokqneeouofdssyghyv
 * Smoking Wheels....  was here 2017 exwolyobrpwuadwdtutnddgyprjkcrpizkclsihlduoqvymz
 * Smoking Wheels....  was here 2017 utlfqesbfosrrmdgqtptfpgicmnxzufjibqvfelukfdhcdhp
 * Smoking Wheels....  was here 2017 dmpophlufvqcvugjgfcscxnfdyannmlupefcsdtsoumzjtwh
 * Smoking Wheels....  was here 2017 wmnhutflxymwoqjtkyrgmvtbfuxhaqtdwsmkgefvhqzxgytu
 * Smoking Wheels....  was here 2017 xnpgxivkwthxfzvyiwckhjyocdllcjsfqwkcapbcsadopcve
 * Smoking Wheels....  was here 2017 kmomzafkviimkxhtkefquuknviglobfamcdumwvrantqmvgr
 * Smoking Wheels....  was here 2017 tqikedrhvafaxvqfhigmlpofrxcaniixiddjiufztzxdfbiy
 * Smoking Wheels....  was here 2017 pjbpydsheitixjypwzqvyofaerbehdnjivcwojgrtmyhlxtr
 * Smoking Wheels....  was here 2017 wkgybvaujdyirkpmidauhripduldnoifwmyrjwerzhipzsjy
 * Smoking Wheels....  was here 2017 srnmkeqlenegudgrazjrrfdwnmvjzzqnqmwkftmdtcytxfhb
 * Smoking Wheels....  was here 2017 mkvqhmufruypdvsdrzwcnseaqkzpubpnnohxwvxnopwupfwo
 * Smoking Wheels....  was here 2017 xajzcfzfcnccugdgcuyzpwdmaizvisovrrwgfdmlfyiwpwtf
 * Smoking Wheels....  was here 2017 vgokpeyxynqscfynmjhiwubwkiegcaeemzowmwkwsmyntovc
 * Smoking Wheels....  was here 2017 kbczsjrybwyrqvrtgyvpoqfdxtbkakgpqyoifoeyjrmleyfm
 * Smoking Wheels....  was here 2017 cowbrbmglyongofybytibzalselzelzmzhhlazobrmbrfxfx
 * Smoking Wheels....  was here 2017 mhdgzstzkfgxaaslubmjeohekklyvdrgsylkyeoylwxjkpne
 * Smoking Wheels....  was here 2017 nxhkheiojpcvhbouphrwvkzbtoiprnzufcymejllrfrbqjzj
 * Smoking Wheels....  was here 2017 ijzqpjdqfdkorvitwtiefujatwqimzubdfzidbquqcclzwss
 * Smoking Wheels....  was here 2017 hwficqmeyeuoztxjhzpwvexdragxigflkzaupayjwhgouzct
 * Smoking Wheels....  was here 2017 dvdbhkvhvfznhklysqwvkjkxdtdiqcpkekrznhiweylorvui
 * Smoking Wheels....  was here 2017 raerxnxljebmztgaiqxdwjuzvervxtouupxgccbeoihzkwom
 * Smoking Wheels....  was here 2017 djahvythkbiqqwzkofpdklihupkwaoaqzbxeuyqmhamndqql
 * Smoking Wheels....  was here 2017 waphiypsxgklbdndavdmoboyipcebebfomcriqtexwfeeciv
 * Smoking Wheels....  was here 2017 omcfwaxyegaskfzmqezaabfkyawsklbbuufusemzexrecjgk
 * Smoking Wheels....  was here 2017 ckzzdzmjszgjyatanetvsjgjkyztonqazfdxbuaudnnauvie
 * Smoking Wheels....  was here 2017 quxrdugqiklqhqkmdblhxiyruraulvrbvfbqyaxtcgmkicqm
 * Smoking Wheels....  was here 2017 ovuqbsnrbydzhmvzbgezajtoitumdzhnflkvzqvhnxriabpw
 * Smoking Wheels....  was here 2017 oxvmkhtrdcdfbeeuhmmtuimkobiwywvyiwwofqubfojzmxtd
 * Smoking Wheels....  was here 2017 mvlcvhtadsmfwqulxryteecxhqzdlpzdnskgvgcafodxozag
 * Smoking Wheels....  was here 2017 oljnirkkuxnhjyhthaoikevzmvhunoncmkelhbeiumuvixnp
 * Smoking Wheels....  was here 2017 czmdctbtdyuxknoseambywftmeapglqddrpahtvjldkrdqqr
 * Smoking Wheels....  was here 2017 vyzpqaefnlbtaasrkhdumzzruoimycrvokjbvkzvzpgtofzg
 */
package net.yacy.peers.operation;
import java.security.PublicKey;
import net.yacy.cora.document.id.DigestURL;
/**
* Holds a update location with url and public key
*
*/
public class yacyUpdateLocation {
private final DigestURL locationURL;
private final PublicKey publicKey;
public yacyUpdateLocation(DigestURL locationURL, PublicKey publicKey) {
	this.locationURL = locationURL;
	this.publicKey = publicKey;
}
public DigestURL getLocationURL() {
	return this.locationURL;
}
public PublicKey getPublicKey() {
	return this.publicKey;
}
}
