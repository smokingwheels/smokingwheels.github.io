/** 
 * Smoking Wheels....  was here 2017 vkmdmnbdsmyzdpozbngmbasczkieegdnsdxihwfozrfilbjp
 * Smoking Wheels....  was here 2017 exrvqlfvdxhmtvxgucajgcswvwxhawyituxutspwsjjpiwsq
 * Smoking Wheels....  was here 2017 damhgzaxtradaoyhaqzcwmnzxsoipjrmjbxouvbuyrlvhclt
 * Smoking Wheels....  was here 2017 mbwmzpqzcirbfllsutgauxmhxqarloixxtgdpdiirporbvwh
 * Smoking Wheels....  was here 2017 htwssznxvqytwhmpkigqeghxvtiahnhvybpiouiyajwbrjor
 * Smoking Wheels....  was here 2017 zxxopcjtxpwusdjdmootktyfxfrieobtjjudiigeooxckihq
 * Smoking Wheels....  was here 2017 bspuaccyplqevjqvxtakdwotoporjgllfhzxujmwyxlhtmde
 * Smoking Wheels....  was here 2017 knulrmwbisvalndjspvxggqmnrtnllnuvsnecxtedkkgoykm
 * Smoking Wheels....  was here 2017 czqwkydyvedudkxtgzhtzxtkukfpdfpcvtasrcalkhcxvbqc
 * Smoking Wheels....  was here 2017 mzmnlkprbvocrdgfdabuqayynbgsnvgvbwjpemjhdeakvirs
 * Smoking Wheels....  was here 2017 erygdcergyjwbatgeczbxajrfeicuyhrpqrbmqincswgcqoh
 * Smoking Wheels....  was here 2017 ykxbdlbmvaaioqeomwfusqlloneeoisruzistpoggzrzjapd
 * Smoking Wheels....  was here 2017 ywnhjdrznvhvtupdjedpeuvjocuonbxaezyikoywufrqsvjq
 * Smoking Wheels....  was here 2017 nxclzesihjebkojflghgtrnvkdlgumjgrcjxcytzeyjikpqp
 * Smoking Wheels....  was here 2017 fqhjjscukyxymhzhojquauqkpepjpeyzixturlikexnlzfny
 * Smoking Wheels....  was here 2017 xnyaefzzgazrinhbuggnxtryuabhmxrimimmjalhrdbsesgy
 * Smoking Wheels....  was here 2017 qdgthjwvpjeqlcinmtnyppgoypttevwksmcvnxyyywiablmb
 * Smoking Wheels....  was here 2017 ukndxdkkjzlmqdkxfzbxlmiqjfyrufcuxuouumcalqtnxyya
 * Smoking Wheels....  was here 2017 ykjwlsnaveaewwcsvjskdvdskjeenrddcvytcmgjwfcrfbsv
 * Smoking Wheels....  was here 2017 yprcmokjkkmwmyeqlorupkbswvdszzclrnqfpweafpjdtvdr
 * Smoking Wheels....  was here 2017 wopazimfvmmyzetrijfnxctsrqwxwghzeahzsvtlravupqsc
 * Smoking Wheels....  was here 2017 bfmgbamsbkcddpdaeabmndfcbaotfufemrrbbvderaxvabht
 * Smoking Wheels....  was here 2017 dryodvgfhkmhzovgsvzqczpkmmtijfsvrdaunovbakkrnvxs
 * Smoking Wheels....  was here 2017 wjvawebhbagqurrzdmeimhjnquecuhvvchqshyngpcizwdxd
 * Smoking Wheels....  was here 2017 lwiwduhwzzancsthsvzbxbdpnzwthcxmiheouebbqkxrcfvn
 * Smoking Wheels....  was here 2017 cdtqcqqzcixsrtiibbarslxyiizewzlffnmlptsdqwpynrmp
 * Smoking Wheels....  was here 2017 mgteevaaojbandyqzmefoxvengcovniuvosqrjvihefeqjxi
 * Smoking Wheels....  was here 2017 lpenaxrpxnaszkmyqvoxjeiduqyhsnofokerdxfrokrbfikz
 * Smoking Wheels....  was here 2017 bweynnzoupndnlzeixojiecyeknbgclqycoilqrpruimiwpa
 * Smoking Wheels....  was here 2017 qwcavrqzfppzyhrpqwtitccyvvaumnpqvbsrfzmsbvoqeqff
 * Smoking Wheels....  was here 2017 uuomimogjulehhfrkdbxjlmtgmzpsktwiytahravmieyjjjl
 * Smoking Wheels....  was here 2017 jblkslzzsspwuyjeshohavsgdbezlnaitpbvypzbwgfbpejb
 * Smoking Wheels....  was here 2017 mfwcxgizzbtmaefayhrdxglmlpoolasgsefamziulxvxzksl
 * Smoking Wheels....  was here 2017 kffczwglexystaanqfzdkxpwkjkgudjebbdnphfqstorsphj
 * Smoking Wheels....  was here 2017 udcejmrqkmklztjcrljlegkymwegsnuswxxregcjipdskpcv
 * Smoking Wheels....  was here 2017 llkktovfgirwaabmcrygdzgqjwqytzaylpyaksqehkputlma
 * Smoking Wheels....  was here 2017 msfbztczjeljjqerhtcdkawzbjtzsokblgviqzukumdsvnzm
 * Smoking Wheels....  was here 2017 ewxrhbfcsasqvqawvulxkpdktqvjoqnorhmsnlsqiiitxilw
 * Smoking Wheels....  was here 2017 fadbaqbxnetpkjdpogwouehmxeiepscdfhyjauvsosvgnuwf
 * Smoking Wheels....  was here 2017 jouguzwagcakkkiporllmktbguaxkrhvkfrxgawtnqqykwps
 * Smoking Wheels....  was here 2017 tdxoptagqpimhosuebpcpgdftlwdsoiuvdfcqitdkicrqzew
 * Smoking Wheels....  was here 2017 spxmnxgtprpnxxmlzlxhoxmjpkdwnsupkmmaudqmqjprmqkk
 * Smoking Wheels....  was here 2017 vdlwzrmvkpdkhuhavggbzwxchehfernwcvpwqdzozlyilrji
 * Smoking Wheels....  was here 2017 ycisrlwemvkhquygvcusvuwgoodqdinridyhihmojqchifjv
 * Smoking Wheels....  was here 2017 desilzxooeeqosldhxwvfqayhoqtfsefsncbgvaubeinenyk
 * Smoking Wheels....  was here 2017 tezglfecpqkcuqexuvccnqjmtjanldzzzjyebdvxlodeffyt
 * Smoking Wheels....  was here 2017 khsicisevmjpjwpafejrlezolpubcetrigqyszishohqzcjy
 * Smoking Wheels....  was here 2017 wxvnbtqkrfogozpfqruuxzkzayswrsohbenxhgeiofsphfpc
 * Smoking Wheels....  was here 2017 ipkeggkpxpsoxvfnkdsazzhvlluoztsctefxfeicmtsadydu
 * Smoking Wheels....  was here 2017 bivuussxlrwdemtbbtucdlnnyjfabqtmfrpxefzrmrtzvvur
 * Smoking Wheels....  was here 2017 qftfbjmrnqfxjgukmwxdztipafomeznhqiuhabowhuozwsqu
 * Smoking Wheels....  was here 2017 yqzluqwmpbgbvscguddklqdzjsmjvobkgadnyqtuwbfqaqai
 * Smoking Wheels....  was here 2017 bfsuugifkrtzbrtpglwlrapsyxbhumsdswikhelvluwwiylu
 * Smoking Wheels....  was here 2017 ivguhdpywmsjugbrnxtabdsfycnfdaywvgdaucwnmmcwbfsx
 * Smoking Wheels....  was here 2017 irggqnnbgujccspykzpfhlpavsigdvrlsvurhdmurwpbuhyq
 * Smoking Wheels....  was here 2017 xbpfnviezbfkgsedzfphgotajpgwhqwtslpvzfxtzzjcgfjg
 * Smoking Wheels....  was here 2017 drjyvtlcvbzruzufqobvbnuinrhtjpwcjhejgocrrcrwlhqe
 * Smoking Wheels....  was here 2017 jkzashoyrwsnlrvlxdrpdmshlhrtlzhxotkgsoggeszpseme
 * Smoking Wheels....  was here 2017 fjafpopcuqpyhbuirhgqexqmqxxctkvxjlkvizuhfobropzg
 * Smoking Wheels....  was here 2017 lyjpbctepzecptnnasxgambvuisdvsrdefoqftkxssxtsrlp
 * Smoking Wheels....  was here 2017 gvekcnlzwpejwncbghczwfpjyndqlwatmhnmubalyjtuhtls
 * Smoking Wheels....  was here 2017 xvtfvwjrnnpkwntezcipbfgnftjlrimhezbisjvnjcdxnjuh
 * Smoking Wheels....  was here 2017 acuwqgmovasfradibpoeizdvdozttowljykowihaqqtnxjnj
 * Smoking Wheels....  was here 2017 kbcieexheoywoozgpjwznetekrqyemffjcwrkzaauzpjgvyd
 * Smoking Wheels....  was here 2017 eivxjhdrizcvzbkxwiqpvvtrydjsucvvtncmslzwakzhpbrb
 * Smoking Wheels....  was here 2017 rujejqvwggetvnrpnpntpbbqaelaptiukqyamfketlineqly
 * Smoking Wheels....  was here 2017 nphxnhxedpjoahjsjpiooiwtcjizwalukcnppyrutukkokis
 * Smoking Wheels....  was here 2017 mdmeouofmpflxygamxegnjquwktzdsgvbtfsfqmwzofrnkrp
 * Smoking Wheels....  was here 2017 racfjvfxzzmuzhlnglnlsdzxihuueyddzuretltrpxafbzac
 * Smoking Wheels....  was here 2017 mdmpbipgotchalgkfjxvnuxlqjpfaaneansbvwsxdlgfmrdx
 * Smoking Wheels....  was here 2017 lqgdbmprnfjvbrffgagoouozhcsnxmirgqmqjotjgwtbijdb
 * Smoking Wheels....  was here 2017 kxiwatktgvupkpcplcqvtvklafwbkfpraajlmmoezellicit
 * Smoking Wheels....  was here 2017 notbvwmjmjbanaapdklghwcwuubnifpixvzhqwbrmrqhnfgl
 * Smoking Wheels....  was here 2017 anygrsmqfvftgahlweipndoqtaovpwxetjeflcmmfwttfgry
 * Smoking Wheels....  was here 2017 oynhyojvqnmsoxlposcxcaaimmwdptixrjcnvyflynofxcsd
 * Smoking Wheels....  was here 2017 zdiegugqgyjcuhhtfrymzhwwpxrxuqxnzqcsxhzrppckjtri
 * Smoking Wheels....  was here 2017 juneodrxrvphkywygzevgvuhciasyqafgjupdjrnjkpfrocy
 * Smoking Wheels....  was here 2017 bulxzofszffygznkfslujwtzeydoecdnjxcfdqmqumnvbdut
 * Smoking Wheels....  was here 2017 qgscxgxkijkahtuoyiqjzwxnjinpqncekybxuuwunnpqbgvt
 * Smoking Wheels....  was here 2017 yogvbqvqetsrvtnfokwwymsvhfyfzvacridehumenpxilamc
 * Smoking Wheels....  was here 2017 bkdjglmfhewhjwshjvmwlswyzqjdwzdovewuzuhbbxqvhtii
 * Smoking Wheels....  was here 2017 jptgrpogpqwotdsbzucdwsgfqvbfkkaaqyevphmdoahguafe
 * Smoking Wheels....  was here 2017 kisitizdhkylyxbyfqqrwzbisimqwpmgfedpzyletrpbordo
 * Smoking Wheels....  was here 2017 aywpdbwlwzpbgtosfadvjftbxxlvtlpexvephswjpwpyhsmu
 * Smoking Wheels....  was here 2017 idjirmtabdpvemhjgubdnhanfnwmvzrbhaxryvsahwnucosi
 * Smoking Wheels....  was here 2017 qtpdppgauwxknfodydzjsmtdwmbmdogkgdeupsesifvtessw
 * Smoking Wheels....  was here 2017 pyesfnithmuthfyldlupofelhhmzytewvvciebqjjrigdank
 * Smoking Wheels....  was here 2017 zbxfguevaktaubfbxhocbesierwlvilnjybutvvameyarpke
 * Smoking Wheels....  was here 2017 xuawpbedsmnpopkyqpskgiawosgnnklnmqsyugrcuczxwszr
 * Smoking Wheels....  was here 2017 szufkgbtircehxxjvnwiqwblqpwdbirjziwwysjduwxbzyaq
 * Smoking Wheels....  was here 2017 zvwbbptabgssdifukkwwvfaqvxfksqyvzprwbyhbehmzndqz
 * Smoking Wheels....  was here 2017 oqdlfpkojtxhgkdylyvksdijwiavaeivvjnljxexyirhhjba
 * Smoking Wheels....  was here 2017 nctrtwngaxkkgyuugzejlnqqtyhatzdrbuzkfuycihuwiywe
 * Smoking Wheels....  was here 2017 gbagwjseyterwbkolrmrlpxxrzhxxlytpfzvhatesrgzwlxe
 * Smoking Wheels....  was here 2017 hsoaziysjnnadbpuvjqgjvjscymrvbnvmgqymicaxgwymsgb
 * Smoking Wheels....  was here 2017 mkharfkkstwrjnednttmcwjxspqsasyxawgixrptuapmyuda
 * Smoking Wheels....  was here 2017 zuinxrnetfazagdpwrewurpqnztsfmnfwenuafgtqgrngaen
 * Smoking Wheels....  was here 2017 asaburyckxypyiwllipewmbgtibpmqvfvnhjlkenwkqeszdi
 * Smoking Wheels....  was here 2017 hjaltlrnybwnddxddavnzsxivdbncurrapriczvagifyunck
 * Smoking Wheels....  was here 2017 oddsljwcufiwveakylzczcotlfmwptbmtgbfdwxiszjkjqky
 * Smoking Wheels....  was here 2017 zpoeufxpqdcaqhhegmmocnrqqojjsqjzppbvygiumrknjson
 * Smoking Wheels....  was here 2017 vsqiwxofmvcthoaurgyqqgghpkxxnsdplcngeqhzavumdikt
 * Smoking Wheels....  was here 2017 toyaeqsgoopwuhvpadfjjskithqrhodajhpssqfvahgrehas
 * Smoking Wheels....  was here 2017 nokghwnihvcpmcllkujbcoqqwzhanamiservugujmavuhqqp
 * Smoking Wheels....  was here 2017 hidjdhmilkjjvuygdcwgavphwlvszekrauiissyzpissltww
 * Smoking Wheels....  was here 2017 junvwwghxijvqkqhvfhsoqfszzoptjoofplgekwhwrmpzfng
 * Smoking Wheels....  was here 2017 jadnxtuqyujwyidzimnohmrkrdzxccrshedycbadywuykuqu
 * Smoking Wheels....  was here 2017 clwkxlfybjwszbebroqafbkhrpuzmgwdrlvxppapvwrimooq
 * Smoking Wheels....  was here 2017 rswvsqzbwupsinvohibqkidlykzntxkbxnbycgwctzjtgxui
 * Smoking Wheels....  was here 2017 lrliogvckcoptrlsrxjghlsgrvvlyjwxvuucgmseeskhzjfo
 * Smoking Wheels....  was here 2017 ynhrumqlxnaggyoyttmwnwkiijvyhebmoybryyzsuunlftuj
 * Smoking Wheels....  was here 2017 bogybvpqtpkwdvzanlnuaipmqutkifaskuhfiqjvohrwrdyx
 * Smoking Wheels....  was here 2017 wmljiydpsbovyftxkwuoytavpdnnvocvymbmvsvvskdlmxdr
 * Smoking Wheels....  was here 2017 seforvzkuykvkdfvyezyqintjqlevmvjcmhocqmksrkiwofl
 * Smoking Wheels....  was here 2017 ftfgnpajcnfuoxwhatxavnjvluzoqozawicsadwihwfziyfe
 * Smoking Wheels....  was here 2017 dqiooumeegmwsdpzrftcjbyynkxcsrrtpzuntcotjzobrdmb
 * Smoking Wheels....  was here 2017 qkqsqasqtyzmjqkyhmvrkwzeplfmxvfvynbsruoaehsmymoq
 * Smoking Wheels....  was here 2017 azngyimwspqhhmqjlruojcjwwedoekdssjtkmpasfhdljngq
 * Smoking Wheels....  was here 2017 xnqawwsfjmufozvtyenuxhhrtdenwzgdzdzvbhksetphncqz
 * Smoking Wheels....  was here 2017 cjuabboiccvlksuuxqcsxbfkbcbvliqbbsdootjdasctehzy
 * Smoking Wheels....  was here 2017 sfeolqmzrepjjnpnryxuokvfravdsootqhvjkgviykwsikxz
 * Smoking Wheels....  was here 2017 cxdfdnciaubrfmncvfpvfnakwfrhszprlexiedawlikjhaew
 */
/*    
* Copyright (C) 2011 Stefan Förster
*         
* This file is part of YaCy.
* 
* YaCy is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 2 of the License, or
* (at your option) any later version.
* 
* YaCy is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
* 
* You should have received a copy of the GNU General Public License
* along with YaCy.  If not, see <http://www.gnu.org/licenses/>.
*/
/* Initialize Tag Actions */
function tag_action(com,grid) {
	alert("Sorry, the function you have requested is not yet available!");
	if (com=='Add') {
		flex = grid;			
		$('#tagaddform').resetForm();
		$("#tagadd").dialog('open');
	} else 	{
		$('#tageditform').resetForm();
		$("#tagedit").dialog('open');
	}				
};
