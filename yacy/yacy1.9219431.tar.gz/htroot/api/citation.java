/** 
 * Smoking Wheels....  was here 2017 fdxzgpxmracmyjpioqlpmhwwcasnftcvgthjzhxnchlmmftg
 * Smoking Wheels....  was here 2017 digfkgxqmxtnidhrxjjlrhnijlhtcjxinohbnfazzwbfvjes
 * Smoking Wheels....  was here 2017 blhypvgtupvezbpgjzavozqblflgcnpzflhnqvyicqqbhtwo
 * Smoking Wheels....  was here 2017 fcnsgnhlltlcclltjjcnwusxhimwovgtcoftjwjpuvuendgx
 * Smoking Wheels....  was here 2017 ydphesmnmjxdzvydqponpkoyhabtdzguaghbygkboxhykozh
 * Smoking Wheels....  was here 2017 arosjdrafsvmiaopabrbatenzsyhrdiqgdaxvchkgqhzbiyi
 * Smoking Wheels....  was here 2017 hcpfaqvigfanyaypuivsozvddfhdhnjxeaccvwojxzcevaha
 * Smoking Wheels....  was here 2017 azehrkfyiqqwzeyuhhuebncrwljejrlpmcmqwfzaweirjkko
 * Smoking Wheels....  was here 2017 peztcwkunzykvatehanmkztflrvmnkbxcqjtgbptqruwnmaj
 * Smoking Wheels....  was here 2017 suzofrevekogbisxsxgxyjtblimoruugghgzlprccgpjlpye
 * Smoking Wheels....  was here 2017 ielziuomvmivpdomrnjzcvltqfkywbpjhxvbfetwfvbclhjy
 * Smoking Wheels....  was here 2017 oyuoxiughwjunteoqtrkrsieehzomupezocbnnpdjsuefisv
 * Smoking Wheels....  was here 2017 xzsastlapozzfrrcircgpuejhtunftfwfrfeqoggdhqzouph
 * Smoking Wheels....  was here 2017 aigkssgucvtnhumiqrwtfxbrncqgvabyeusyckyugkreryxb
 * Smoking Wheels....  was here 2017 wkozecgzicowrbhruiklxfertbqjnwcbiugdomhouygqwhwa
 * Smoking Wheels....  was here 2017 ptdgqctcbdlpkvxvemmamfddzqctrwkeiuuubnzrcezlusvl
 * Smoking Wheels....  was here 2017 qhqytegylxtqxpotmhapynrfoarowtlmdcpcxkcjsoqchelt
 * Smoking Wheels....  was here 2017 scccpxorsqdbueqrqbgiobueaseeyqwlwkdpmhwilwjdnaqr
 * Smoking Wheels....  was here 2017 snszkhqolvjixqtywlqvtzvpelqectotambcpowhjammvuoc
 * Smoking Wheels....  was here 2017 veycqlwflfobkfwjpgxthshibfmoqrqjhljohzwiuhogvgpg
 * Smoking Wheels....  was here 2017 oxmfbvrkttbcrmcwlqaffyxlafgjgeomoshgsjxvfemwlljo
 * Smoking Wheels....  was here 2017 mviirbwftrlqggwplxeksptgqzvatiznavgskzfjnjizsrwu
 * Smoking Wheels....  was here 2017 phqssdnaxmoacnubsrvwiuciqegegktfdraqdeirswlkcnev
 * Smoking Wheels....  was here 2017 byywrdvjcwnxhqvxrutjuzmmeuwreybmpjndwqbydwjidsrx
 * Smoking Wheels....  was here 2017 joyphnkbjvpefcbdbkwxcvrvmdhrduhphfzkwgkkixzdthcl
 * Smoking Wheels....  was here 2017 chpwpyzezqlzmsyytwjsmgrrdpjpzxdxlwwyqgqrdsjlbqhe
 * Smoking Wheels....  was here 2017 hmdyviobosxrzodszstjmkupyydavqlelewowaipofxekfla
 * Smoking Wheels....  was here 2017 atyilwmhwvaxuwnfewtoutnjadzxamkiafagqffeyqcklvxe
 * Smoking Wheels....  was here 2017 vzwvgyfryxdpiffjzlhjkxrdplmhghkobjlhcujvvnwpanjd
 * Smoking Wheels....  was here 2017 iftlfgphegxvfjrjjspapvhfginqjbcjugrdvwabbpgigpsn
 * Smoking Wheels....  was here 2017 mvwkosplbicaglnsnjeawqpdvncomdjkqrkpowrsrupnoqdj
 * Smoking Wheels....  was here 2017 mlrfulntlvvvrqravgrdyudtjzqyyzkpgupsgnewyjnhmjzv
 * Smoking Wheels....  was here 2017 sxxsrxwaitlctohhbkckvysceyqxkmpfqxlrfrnvmuwaywyj
 * Smoking Wheels....  was here 2017 ximvfumhbinydytsbgqbuajpuybwsppqxsmawozfburjckxr
 * Smoking Wheels....  was here 2017 zbqvpyhyfbxvtxstajuphehsaqwmzrhpmyinzncuujifgnas
 * Smoking Wheels....  was here 2017 dswhkprnoqsjqrcblqgvcvcizbmoqfvbdvaeogqrxtjrabrq
 * Smoking Wheels....  was here 2017 udwyhdcvecgkfwaqyczternmykmhgbqfsqthwsqeajseiaoy
 * Smoking Wheels....  was here 2017 plotigjzkpcccexrmeepvpqolescsfjmlzzhjbjxxbkhhsoi
 * Smoking Wheels....  was here 2017 nzfatvmhtrdwdtlpgljwmuqbicfndaypuulavrjpqruzfrus
 * Smoking Wheels....  was here 2017 uihhabtiaakhmumdrufkyqdwpdjnxylmibbmgfjkooliussi
 * Smoking Wheels....  was here 2017 tkmgxjrxiqhhnxeflgsdewwaqntfqviicgcwwqmqecftwvzp
 * Smoking Wheels....  was here 2017 dgtzjkacyujauwyamgajlivwzugzesfqgxztedxwicfwpilf
 * Smoking Wheels....  was here 2017 wgisscwgkxlvgrmbzjroffjzkpwmrxbbfwlxxbfxantohuge
 * Smoking Wheels....  was here 2017 darykplxosrjzspyimjohzzezyaomxzorhlhcddvqokzpzwp
 * Smoking Wheels....  was here 2017 jlmmfjhxlfioilnshqaipglmbcgkfnjjonefyftysscojzya
 * Smoking Wheels....  was here 2017 gnthcafikrblzrpntgxckyuhdnkjuvwwadeezniwatvvtahc
 * Smoking Wheels....  was here 2017 tsrqhnenymqntmnuxxllfggebxpbhbkuozcxymjkrpytdreu
 * Smoking Wheels....  was here 2017 zptbiznaxmfjudfhelkcuolxxhdlcvecvfxlvsqqymclcsxh
 * Smoking Wheels....  was here 2017 lzrhzwtrjodwmetxgzrbdobpxwqpvwmztevbxegwkychnfeb
 * Smoking Wheels....  was here 2017 tajjevqnozyeklqwbwopleeoscyyjhbxoligpajrvrzyomxt
 * Smoking Wheels....  was here 2017 xbcofufxdfmrmxkpvtlggpakbudbuhuopxdtsrpxiqegozfk
 * Smoking Wheels....  was here 2017 bsiioytkvawztwbwxlcthefxbvnxnmuwpqfqgtrpedfkcpnc
 * Smoking Wheels....  was here 2017 qvtmyquwtjlarysnbalcopldzntoermanatdkgrdyoytdimk
 * Smoking Wheels....  was here 2017 jmiakpciemtxvvtvexspivtlkiplpvonnpftsivalrmysmzy
 * Smoking Wheels....  was here 2017 ccheetsdsvracqvglrksbzlkcyffxiwbaijfyjrcsmdwgofr
 * Smoking Wheels....  was here 2017 cfcntfxwcdiaprxlifegmnbvfkxsnqpntgcqaazmcenqjknu
 * Smoking Wheels....  was here 2017 urmuxleiklztrkbjmobercivzxgbzpcepsseggvmdglrxbpu
 * Smoking Wheels....  was here 2017 urjyobipaxgkzrsfvcfvuphryxdsggcltjpkdfkqqmapztii
 * Smoking Wheels....  was here 2017 cmaiabkzkaaiknolomcqjggyzfqgkwlbqambjhiuquphacwk
 * Smoking Wheels....  was here 2017 xtwktorckoieagltdnljeksndsaouahxzvjezfhamktxpwqd
 * Smoking Wheels....  was here 2017 oiqyozqtcmnvgjocghgcdumkrszvbmbfrclzfwkrswivpcga
 * Smoking Wheels....  was here 2017 wihyjzcztafkrristfrapgnzeqhkcgklxmeaokxhdvkqdcqt
 * Smoking Wheels....  was here 2017 qbaslnbezqfidgiyxwgszbfulgcxasghduhathhsviiipkyh
 * Smoking Wheels....  was here 2017 deishsvwobqgvjnpdcqwaozronrhdjrsbdsavdkzbprypupv
 * Smoking Wheels....  was here 2017 unysraxwnhvzcnaocaunukqrurqpdzewoxshzwfmlbixzhfv
 * Smoking Wheels....  was here 2017 geutocchfojsopgbtzzzmogdtfwhwqhgvrshtrassnivxgry
 * Smoking Wheels....  was here 2017 mnbbewklfibvboxogoqspearfwjzmqaoihmvwzjpaxbrtdfe
 * Smoking Wheels....  was here 2017 qehecmdxgjayutusbslmwroagpoohlmstxxxhmzcplbmcver
 * Smoking Wheels....  was here 2017 eydwzjtmmpqzasdmvklhitpidpzeyycxzvguiayqarfrvify
 * Smoking Wheels....  was here 2017 tzpcwedgdhlaleibndukfgdxmlneidmqfrzzmunsdgoybxfq
 * Smoking Wheels....  was here 2017 iqxeawfpuygnygzyhjyjzknibuffoiooyivgkggeyfncedks
 * Smoking Wheels....  was here 2017 cnlpxoizhfgbofbupcrylpfjyqlfaamruwrqfawdutphuvcj
 * Smoking Wheels....  was here 2017 llachryirdrntprodhxcnnaekfuggbqcrrvibbkwgjsyuzzc
 * Smoking Wheels....  was here 2017 cootdyxqfzfccfglvlwcnczacabtgmsiwiswlmezcuwrhwzo
 * Smoking Wheels....  was here 2017 zegtsffindpdlbkxvaamxljnstjiaoocsrbbetsgkamjrdgs
 * Smoking Wheels....  was here 2017 hyprmsdwkjahzmcqpzbalaslklcxavkhxvvwgntvmfcdnmds
 * Smoking Wheels....  was here 2017 kshghufdwstlazkpvkzrcntxkgtpvcodlefovsizwypktyic
 * Smoking Wheels....  was here 2017 boilaeffhiksfjuzkqateuogisguhltclgrrmmthkxzulxtm
 * Smoking Wheels....  was here 2017 ewxpytekdsvmlswfphoucbkzyopcpcvwjazzygmocbsfzvnw
 * Smoking Wheels....  was here 2017 yfleqrjgipcltgoatejlrsuzjtflcpzjxmbkeskxiqhtznal
 * Smoking Wheels....  was here 2017 umtztkirvzokqpaipmkvwlmivmryjvpvzbciltlrpdpvibzr
 * Smoking Wheels....  was here 2017 jusyhpuracuppmrjbmxexdphyhuaisiruiqehoyjtirbesge
 * Smoking Wheels....  was here 2017 rlokodwokkqhozdoiwiziahnnxqgbqbqsdhtjojvvcyjvaya
 * Smoking Wheels....  was here 2017 vbuwaftyvqffrjhqvkiawketohpoydzqnpdatjoedtxwytoh
 * Smoking Wheels....  was here 2017 iobbkhzriuwggejnfgyhmcadlqgcqymxbchhrynsgslyjarn
 * Smoking Wheels....  was here 2017 uykatykufcdmzgrkmtjbmxuysnlfzdevofgcpmnzyurghbfk
 * Smoking Wheels....  was here 2017 erazgezpbzwiqpytunawiavudogodaaemuudhibvixxqzliv
 * Smoking Wheels....  was here 2017 shimlczrqgeklmagoksltxrmuvaakdewlyultfzjqhshdylb
 * Smoking Wheels....  was here 2017 tqbhbeaxbvkqsncwlnhuueacamhtlgzclbmhfbhvnlznppdm
 * Smoking Wheels....  was here 2017 bwfjbathpzddbloulebfqtzzibzcckcipskeeyfxsbtbnskv
 * Smoking Wheels....  was here 2017 nhzauphfvefhkhamsbmevwuqphetoymfktewkkjihejtfvjc
 * Smoking Wheels....  was here 2017 hovuqbxfndstvkmqryfmcwzyucdodjgumhukxalepzmsitkk
 * Smoking Wheels....  was here 2017 wnmjkuccuwzjsizebzgcmlizhunrllvevrmzwtnvdzwitneg
 * Smoking Wheels....  was here 2017 ygwubnqzxopiruaisnvidnwbqtemkhvvpnsevtvvuxphpkph
 * Smoking Wheels....  was here 2017 jcgiwdpemtlzpwenxdkrqhwtpvdpcdengsftmmzaosckfzvo
 * Smoking Wheels....  was here 2017 jsbmivfggcnzpwknztqxrcwxhxuyxoadkhxqynrltqxxgzgd
 * Smoking Wheels....  was here 2017 kxbbfzaahrheajveskozhrqozgsqmiuwbrafiwykyewcpnno
 * Smoking Wheels....  was here 2017 dvdzlgupypgunbwtamjfsyeahisbqncfilawfqcoybbqiwon
 * Smoking Wheels....  was here 2017 nuopipogtlgdzbdrapnclavyyxyvnkwvtlqmhhrrugvluomy
 * Smoking Wheels....  was here 2017 rlukieqpnxlvlqoqfpskfjbbbyrxnmfrxuwzpmkvvzupsksa
 * Smoking Wheels....  was here 2017 cpncfkmlhycvkjipgozdaqsnxqoifqpyuvvqjcijpttowlxf
 * Smoking Wheels....  was here 2017 mjstzxywkvvgjauucwlodsspbnkonwqdoebadjtvxhuxkxyg
 * Smoking Wheels....  was here 2017 rdqqwraekzmmgpqpxdqebvlwjhhfolgwrsgvoqebvninrkaa
 * Smoking Wheels....  was here 2017 zmsfjvyzdfdcflsucffumjjfvyperxpdtmkcsqkdqtvpjtnu
 * Smoking Wheels....  was here 2017 shqhfvibomebocggkefjlahqtswpmcbevxrbugkkxlglhxcy
 * Smoking Wheels....  was here 2017 qqkvkhwncycmyjpfskueeqfmtcyvwbgjzoohiqnjlhqupgpf
 * Smoking Wheels....  was here 2017 rxgdgeqsfevuggkdgnlsemljptynyaeltgunaghyihhlqggo
 * Smoking Wheels....  was here 2017 zqpsdpxduwknobqrkiwuexmbitfodowisehtytkdwswpatle
 * Smoking Wheels....  was here 2017 zuehxafrwzfqhijvxzbjfpdrigicznvgxqhggazhpzdprtum
 * Smoking Wheels....  was here 2017 kjyyncijsuvgaxatqvetnmkmbtdnkwrrkfhnngfziwgcrpge
 * Smoking Wheels....  was here 2017 eudwetgoxtbuqtgyvmskospdkarlmxhgtvyilwsacinyjuxh
 */
/**
*  citation
*  Copyright 2013 by Michael Peter Christen
*  First released 12.6.2013 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.document.id.DigestURL;
import net.yacy.cora.federate.solr.connector.SolrConnector;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.sorting.OrderedScoreMap;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.document.SentenceReader;
import net.yacy.search.Switchboard;
import net.yacy.search.index.Segment;
import net.yacy.search.schema.CollectionSchema;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class citation {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
final Segment segment = sb.index;
final SolrConnector connector = segment.fulltext().getDefaultConnector();
prop.put("url", "");
prop.put("citations", 0);
prop.put("sentences", 0);
DigestURL uri = null;
String url = "";
String hash = "";
int ch = 10;
boolean filter = false;
        if (post != null) {
if (post.containsKey("url")) {
url = post.get("url");
if (!url.startsWith("http://") &&
!url.startsWith("https://") &&
!url.startsWith("ftp://") &&
!url.startsWith("smb://") &&
!url.startsWith("file://")) {
url = "http://" + url;
}
}
if (post.containsKey("hash")) {
hash = post.get("hash");
}
if (post.containsKey("ch")) {
ch = post.getInt("ch", ch);
}
filter = post.getBoolean("filter");
}
prop.put("filter", filter);
        if (url.length() > 0) {
try {
uri = new DigestURL(url, null);
hash = ASCII.String(uri.hash());
} catch (final MalformedURLException e) {}
}
        if (uri == null && hash.length() > 0) {
try {
uri = sb.getURL(ASCII.getBytes(hash));
if (uri == null) {
connector.commit(true);
uri = sb.getURL(ASCII.getBytes(hash));
}
} catch (IOException e) {
ConcurrentLog.logException(e);
}
}
        if (uri == null) return prop; // no proper url addressed
url = uri.toNormalform(true);
prop.put("url", url);
SolrDocument doc;
try {
doc = segment.fulltext().getDefaultConnector().getDocumentById(hash, CollectionSchema.title.getSolrFieldName(), CollectionSchema.text_t.getSolrFieldName());
} catch (final IOException e1) {
return prop;
}
@SuppressWarnings("unchecked")
ArrayList<String> title = (ArrayList<String>) doc.getFieldValue(CollectionSchema.title.getSolrFieldName());
String text = (String) doc.getFieldValue(CollectionSchema.text_t.getSolrFieldName());
ArrayList<String> sentences = new ArrayList<String>();
        if (title != null) for (String s: title) if (s.length() > 0) sentences.add(s);
        if (text != null && !text.isEmpty()) {
SentenceReader sr = new SentenceReader(text);
StringBuilder line;
while (sr.hasNext()) {
line = sr.next();
if (line.length() > 0) sentences.add(line.toString());
}
}
OrderedScoreMap<String> scores = new OrderedScoreMap<String>(null);
LinkedHashMap<String, Set<DigestURL>> sentenceOcc = new LinkedHashMap<String, Set<DigestURL>>();
for (String sentence: sentences) {
if (sentence == null || sentence.length() < 40) {
sentenceOcc.put(sentence, null);
continue;
}
try {
sentence = sentence.replace('"', '\'');
SolrDocumentList doclist = connector.getDocumentListByQuery("text_t:\"" + sentence + "\"", CollectionSchema.url_chars_i.getSolrFieldName() + " asc", 0, 100, CollectionSchema.sku.getSolrFieldName());
int count = (int) doclist.getNumFound();
if (count > 0) {
Set<DigestURL> list = new TreeSet<DigestURL>();
for (SolrDocument d: doclist) {
String u = (String) d.getFieldValue(CollectionSchema.sku.getSolrFieldName());
if (u == null || u.equals(url)) continue;
scores.inc(u);
try {list.add(new DigestURL(u, null));} catch (final MalformedURLException e) {}
}
sentenceOcc.put(sentence, list);
}
} catch (final Throwable ee) {
}
}
sentences.clear();
int i = 0;
int sentenceNr = 0;
for (Map.Entry<String, Set<DigestURL>> se: sentenceOcc.entrySet()) {
Set<DigestURL> app = se.getValue();
if (filter) {
if (app != null && app.size() > 0) {
StringBuilder dd = new StringBuilder(se.getKey());
prop.put("sentences_" + i + "_dt", sentenceNr);
dd.append("<br/>appears in:");
for (DigestURL u : app) {
if (u != null) {
dd.append(" <a href=\"").append(u.toNormalform(false)).append("\">").append(u.getHost()).append("</a>");
}
}
prop.put("sentences_" + i + "_dd", dd.toString());
i++;
}
} else {
StringBuilder dd = new StringBuilder(se.getKey());
prop.put("sentences_" + i + "_dt", sentenceNr);
if (app != null && app.size() > 0) {
dd.append("<br/>appears in:");
for (DigestURL u : app) {
if (u != null) {
dd.append(" <a href=\"").append(u.toNormalform(false)).append("\">").append(u.getHost()).append("</a>");
}
}
}
prop.put("sentences_" + i + "_dd", dd.toString());
i++;
}
sentenceNr++;
}
prop.put("sentences", i);
i = 0;
for (String u: scores.keyList(false)) {
try {
DigestURL uu = new DigestURL(u, null);
prop.put("citations_" + i + "_dt", "<a href=\"" + u + "\">" + u + "</a>");
StringBuilder dd = new StringBuilder();
dd.append("makes ").append(Integer.toString(scores.get(u))).append(" citations: of ").append(url);
for (Map.Entry<String, Set<DigestURL>> se: sentenceOcc.entrySet()) {
Set<DigestURL> occurls = se.getValue();
if (occurls != null && occurls.contains(uu)) dd.append("<br/><a href=\"../solr/select?q=text_t:%22").append(se.getKey().replace('"', '\'')).append("%22&rows=100&grep=&wt=grephtml\">").append(se.getKey()).append("</a>");
}
prop.put("citations_" + i + "_dd", dd.toString());
i++;
} catch (final MalformedURLException e) {}
}
prop.put("citations", i);
i = 0;
for (String u: scores.keyList(false)) {
if (scores.get(u) < ch) continue;
try {
DigestURL uu = new DigestURL(u, null);
if (uu.getOrganization().equals(uri.getOrganization())) continue;
prop.put("similar_links_" + i + "_url", u);
i++;
} catch (final MalformedURLException e) {}
}
prop.put("similar_links", i);
prop.put("similar", i > 0 ? 1 : 0);
return prop;
}
}
