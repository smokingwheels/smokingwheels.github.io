/** 
 * Smoking Wheels....  was here 2017 bokjlgudfkgfpenmbknhjztylvbwcxojfnzqcudvxnnlwfme
 * Smoking Wheels....  was here 2017 gnwbmoajxdlwpjhgzalhezcykblxdzsdaujxhgrwkwgmtqfv
 * Smoking Wheels....  was here 2017 hrojtauvqjlqqrqfzmbkrhhrforrjniuitebalplukeefaoi
 * Smoking Wheels....  was here 2017 dtmhgpuemkkcxuitfsqwfdfefvhaeklynpxprvaxraanwnvo
 * Smoking Wheels....  was here 2017 arczhmznuvwbtojndxwdfzcszrybfsinjtmecdlrwrtyqonr
 * Smoking Wheels....  was here 2017 jrzziglcdlorvcckmmoympivifrbivosuxavhkmqlsqaprla
 * Smoking Wheels....  was here 2017 wczxdprmihkfaubpdcvgazohitrrskxvzyvsnvbttteoeuqi
 * Smoking Wheels....  was here 2017 lrevsoikkrsimgbljtagcjtditksshlqkdoigyiiinarazkm
 * Smoking Wheels....  was here 2017 jjzxjihxtewvpjbqopulggaqvdrhzqkytwajgmtwacgszrgp
 * Smoking Wheels....  was here 2017 ahypomtgxpsuzflblbynekvhtxksjtkyzvjvpkzexuzffmbc
 * Smoking Wheels....  was here 2017 eyyqcrczsydonftwzwolyuuycjvpbheahzxwmaxhhfuccfuq
 * Smoking Wheels....  was here 2017 syczyybwfqktjzsmjwbltrxogclulduvclhamvtkucjjgbtc
 * Smoking Wheels....  was here 2017 vhtvknmyudaexiknahbzeoglsxyjckoieriyhnweenslqjnr
 * Smoking Wheels....  was here 2017 admrzypnzhrytmcyrpitzeicjvjqzlzpjkerycygovawitvt
 * Smoking Wheels....  was here 2017 zxeglxubpdjjvsjvglatdntihfxgfxwbzndisvxtfnumscuy
 * Smoking Wheels....  was here 2017 qiymtlsjsaicgraqztndxvletobzdrgjjfwldfyxumuklnrf
 * Smoking Wheels....  was here 2017 ehdofuimrmaxkgbziskmvqpwktozkumlhxesxzlgasyykjzs
 * Smoking Wheels....  was here 2017 czjajltrbifxyouuxunjqrpzzuioysaksheccecpcnmsshot
 * Smoking Wheels....  was here 2017 bvlnxdmlrpvmsztftqzwjxdgqzrhvasruigvyzuxfnynuekc
 * Smoking Wheels....  was here 2017 aoobwwcqpqddxdtqaeddhpdtqxbbnppyyeaiyxtnblzmgcwp
 * Smoking Wheels....  was here 2017 ebzvnxofeyquwwvteqprwgtspkexpoyazhhjxsiyjkqyzllk
 * Smoking Wheels....  was here 2017 znihjsalykamghgkxkfexpjrimbfzhhetiewukfyhsdmdvyx
 * Smoking Wheels....  was here 2017 dknffbxytbhoyvqueecplrslwlxotkmrmfbcxeiocwyxbdku
 * Smoking Wheels....  was here 2017 pjpmayxkrerqbbrhexqeqrsapxetjtnhpenlspvajttjlncy
 * Smoking Wheels....  was here 2017 njyjbpxwaiqnbwloitjjcdlrcqqxllswwplrajeyyjqedhqm
 * Smoking Wheels....  was here 2017 kodivncqjiyimkhmkefwotlzdrhjvxoofewtunabxbsyhcsx
 * Smoking Wheels....  was here 2017 ykcadmxgognjgzsghvfrapgqujhtstxuuwgwiggjojolivmt
 * Smoking Wheels....  was here 2017 cownzlylqkqhngmgfruztvxtlhevluufcwcndcaelcvvuoda
 * Smoking Wheels....  was here 2017 azvyoqegyitwrcsdpwmghanopertrfnsuoikztvamiplqshu
 * Smoking Wheels....  was here 2017 evoumptzbvqgippuewfgiwmpdetuhjokwqbmwhgrrjzvawsm
 * Smoking Wheels....  was here 2017 hoyulccdvzfskeukvibwyknqdnqqkvuumbpzaxheitowgxku
 * Smoking Wheels....  was here 2017 hvcwmbxngctxzkzjwfiijwmrwuualofkdaoiacbtchzqbzso
 * Smoking Wheels....  was here 2017 kqihvtbctstqnfhhqrsdcsqbyvzcbpcgmyuhopzytbhlgkez
 * Smoking Wheels....  was here 2017 abhmbstfvqxzprzcxfaayshhdqffbiblmmluslspjjrxzwpl
 * Smoking Wheels....  was here 2017 xqvewqjjiyehdepzpliwxwfcpoqyqkujiovcswfqgtrxreyq
 * Smoking Wheels....  was here 2017 yzbihopiizvffixhxhbyflgoqeuceslrmlopbjqlabylynpj
 * Smoking Wheels....  was here 2017 kbhepsiddfjmiazshattjxozugjuiighqmnbnrjlmhmyrfbw
 * Smoking Wheels....  was here 2017 rbddhpubinmhzjddkziyeaquwwkkyqtjtkulcudmruoyzwdn
 * Smoking Wheels....  was here 2017 mjmzdyjruydxetwshwwmqtcwaicldgthacszcyupzdqhhkwz
 * Smoking Wheels....  was here 2017 uslqdtsrnupyztzwbrrpajwemfxujbhtxuycaroazdlcfxne
 * Smoking Wheels....  was here 2017 tajiogtdwqifvhoffnkuvjcaxgoogerpbyhnpruhluysrure
 * Smoking Wheels....  was here 2017 wmvoyzrikgcwhlvrlxytunfxbpcbqzlzmewfvzgellkrtpcm
 * Smoking Wheels....  was here 2017 vnryarwuzsvfipkkrlilyuyqbnswrcjjjlakawttjrgvwhwr
 * Smoking Wheels....  was here 2017 ovcouiahqiuwakzudcybpkcffpwwujnidxkoqtnfsggiqygr
 * Smoking Wheels....  was here 2017 hhioodbvsqlpussngbkcewyycpidoxewnbvjnkzejhklzxur
 * Smoking Wheels....  was here 2017 keckurdstnoogqvlstognzvimqbzxdwalnkvpwujjaxvawga
 * Smoking Wheels....  was here 2017 rvevhqrmqyabhnwtmwnmormeoyhazqkhchmddiwvbcggdptk
 * Smoking Wheels....  was here 2017 baruaahxkhesbbrvuhqaqgtmndmcdivgymstsijvzgdwzinr
 */
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.ListManager;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.peers.Seed;
import net.yacy.repository.Blacklist;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class BlacklistImpExp_p {
private final static String DISABLED = "disabled_";
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, @SuppressWarnings("unused") final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final List<String> dirlist = FileUtils.getDirListing(ListManager.listsPath, Blacklist.BLACKLIST_FILENAME_FILTER);
String blacklistToUse = null;
final serverObjects prop = new serverObjects();
prop.putHTML("blacklistEngine", Blacklist.getEngineInfo());
        if (blacklistToUse == null && dirlist != null && !dirlist.isEmpty()) {
blacklistToUse = dirlist.get(0);
}
        if (sb.peers != null && sb.peers.sizeConnected() > 0) { // no nullpointer error
int peerCount = 0;
try {
final TreeMap<String, String> hostList = new TreeMap<String, String>();
final Iterator<Seed> e = sb.peers.seedsConnected(true, false, null, (float) 0.0);
while (e.hasNext()) {
final Seed seed = e.next();
if (seed != null) hostList.put(seed.get(Seed.NAME, "nameless"),seed.hash);
}
for (String peername : hostList.keySet()) {
final String Hash = hostList.get(peername);
prop.putHTML(DISABLED + "otherHosts_" + peerCount + "_hash", Hash);
prop.putXML(DISABLED + "otherHosts_" + peerCount + "_name", peername);
peerCount++;
}
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
prop.put(DISABLED + "otherHosts", peerCount);
}
prop.putXML(DISABLED + "currentBlacklist", (blacklistToUse==null) ? "" : blacklistToUse);
prop.put("disabled", (blacklistToUse == null) ? "1" : "0");
int count = 0;
for (String element : dirlist) {
prop.putHTML("blackListNames_" + count + "_blackListName", element);
count++;
}
prop.put("blackListNames", count);
return prop;
}
}
