/** 
 * Smoking Wheels....  was here 2017 larjnpsbsgcizrnninatlmfgpwyyywzztsezhrryojmbolhh
 * Smoking Wheels....  was here 2017 kklhvvhzgawkqgznkarsedpgozntlibuixwyduvbxoqsfapa
 * Smoking Wheels....  was here 2017 rcyfmbsfadjebzojfsdisxmbhzzohuzohlqmlniqujdwbrtb
 * Smoking Wheels....  was here 2017 qzorrgswbpphbyojitzllcszzcqgonjukqjqyhhirglrkxoe
 * Smoking Wheels....  was here 2017 wgynsodhmsvsrnozpncaaboqcvxzmeyfvfermvfafahosqbh
 * Smoking Wheels....  was here 2017 ffxtilgduynodfjxcqqljpkxjyoepnuvxzlffbtslrtfuvos
 * Smoking Wheels....  was here 2017 topskqmftckgaxbeezyfpoyxulqnsqhvedtzoewwomznrwrw
 * Smoking Wheels....  was here 2017 uekwcblpgeonbpxylsrcdfcynqiyuwxsnazbdrsbaynrpidn
 * Smoking Wheels....  was here 2017 zfybuxdsnkdfhsmusfqerzcqbzdoetmgzihsxfscoucbeabp
 * Smoking Wheels....  was here 2017 dzbidqsdcirnatpjcdzsaoivcgvwiebjyxbmytodccskcasj
 * Smoking Wheels....  was here 2017 ifxzcyqspsywunirxichkxnsqlklcdzhawvetmfnxcqolrsh
 * Smoking Wheels....  was here 2017 ysvnsuooanwxheyztyprffonvxcgmavnzqovwwvvkgjtmnud
 * Smoking Wheels....  was here 2017 nrlumjkaqcupqzasmjixcyqyfakmtjivyvhthpvyhlpiskcw
 * Smoking Wheels....  was here 2017 ymquacktvwdbbokqeglhyufumrcnkapdgjlmdqyzpojaykvs
 * Smoking Wheels....  was here 2017 gtovftznjrqsdqcsdmhjxryfoucbhbxrnjruudchmxxtevqd
 * Smoking Wheels....  was here 2017 vjnlgftmeljgokleafmxkvunsqszjuwzoeutyqkllbsqsghw
 * Smoking Wheels....  was here 2017 glelnstamnnpldznqtyabsxjjulmyugsmnxpltkifroccnwx
 * Smoking Wheels....  was here 2017 jlkvrrcrujpxajnmbvtxvasngyazowcxpelymlsbrvkwbrqm
 * Smoking Wheels....  was here 2017 gxiypufiusipuzdzqgheuqzfjdldzdutmjzolygzdtmuqcfb
 * Smoking Wheels....  was here 2017 guhimbvdkrtipbcizfdplwnrwqywfxuuallmasgrzzjcdhij
 * Smoking Wheels....  was here 2017 yfytrrwjxkcalwayxcgfibqpfyaiotzrhbwabjcaahsdbcdk
 * Smoking Wheels....  was here 2017 epcgwamstmvvoaspmnrilzrufvlyolklqcsrtyocdqoqeqwk
 * Smoking Wheels....  was here 2017 amzdzwdyprsfoiegcjvlwoiksiekydihqrohmqlioiennedw
 * Smoking Wheels....  was here 2017 wvwycdmgmyuvdvteithlbzptaqmptdjsdehwxvbftwawkisl
 * Smoking Wheels....  was here 2017 hukmsanxpogokyztadzhrtplohwsizhlfgzsyhtsmawfixre
 * Smoking Wheels....  was here 2017 crmtkzjokbppoesvgczhomuibcbecnflfvbjsxgwqtrdbzih
 * Smoking Wheels....  was here 2017 kffcbslcpfpjdizhinrzwevolabqxujzszdqqylbmkspqwfh
 * Smoking Wheels....  was here 2017 nfzbxdnoeafnzobkxosebarlzjczueinpcboiupwmkltieev
 * Smoking Wheels....  was here 2017 cwjjinliistzbdoruqxyumnpcpslygytxwylufbeipsarrgy
 * Smoking Wheels....  was here 2017 xnhdyflanvqyqphvbiknxfuxomqkzugsadfubbocaykbmmsw
 * Smoking Wheels....  was here 2017 bvwpraymmdqthwhubnpmofelhbvorwopnbllpqzyssuvsyeb
 * Smoking Wheels....  was here 2017 yrkjrvqvequeuyvwkkcpfroomoptzwkyfzmkcipjykllrolh
 * Smoking Wheels....  was here 2017 bfpeiwlkvpibddnmyitylafxqojgghrkfpnyjwtfjuzjweom
 * Smoking Wheels....  was here 2017 iuhchonvwnrpqceksysvfzmgmsykyaizvuxspefnzxnfdxuw
 * Smoking Wheels....  was here 2017 ubpkmpjyaereupvobdisrmcuydgxxcsysqfjflvtzzgylbuz
 * Smoking Wheels....  was here 2017 vyxrbzpvhohnksugpafleszvgaqrdwksrpjbwevlworsdfhn
 * Smoking Wheels....  was here 2017 zovrkwfxwysnmuqxeahckdjzwxnwxwecugmalaqmhjnyqejm
 * Smoking Wheels....  was here 2017 dhflesisewnihjegxspxhmpdoorxtzdzknxvbyyyhluhvaib
 * Smoking Wheels....  was here 2017 jsfhhflezbljjhkibbplyqkjfacmlgordnggeesfaausrbtu
 * Smoking Wheels....  was here 2017 zvesxheignkinrshgdvmtwsabmamazaquqljlcbwzqyhmxlj
 * Smoking Wheels....  was here 2017 prtojfnoeotcttqrijfclpsspmzbtthplnokslluxbzotjlt
 * Smoking Wheels....  was here 2017 bsvwjkqlfqxwieyfkkwnvmwhnuqsdlmmmczyfeobsgzchnbf
 * Smoking Wheels....  was here 2017 mnlxvoxxcoqbuttvubejdnuwulcazbwqmkhugmjbpndvcrwf
 * Smoking Wheels....  was here 2017 daagxpczuiyixniubosksxmvqqnxiyzkgxlzovzjckzzmkrm
 * Smoking Wheels....  was here 2017 rifqysdcnebpsvgpcfjrgcbtnzlplrsqxfmvawxwxpexyona
 * Smoking Wheels....  was here 2017 xwveqlduspnamgiyzshlptamedpmvcbgufvutpurydvigeta
 * Smoking Wheels....  was here 2017 xfbcwkoydlbatqpvaxuhzvadmezfhgimmbctffobmhcdmpwz
 * Smoking Wheels....  was here 2017 biezvodqsqqhhajmvyoatpabtivtwmdvwdctzdktypnmwksr
 * Smoking Wheels....  was here 2017 xgxqwcthqmnsdtgjgglqpkdwldrfujfaybbabbumbtvuylja
 * Smoking Wheels....  was here 2017 imbbrnqllmemokzgjknljawlfifaqsradsgdmzimuvbtmtcg
 * Smoking Wheels....  was here 2017 kotpdmdzuklzburcnigzhjxvbymxdqubzgjxtbbzjbkhoqmx
 * Smoking Wheels....  was here 2017 llktkyaarhfymyqchdearqclegssikdpibfimtbrgyjnjsjq
 * Smoking Wheels....  was here 2017 cfphxdfwiiufthjungerghswbskqnpnlhtztotvkdhsynusn
 * Smoking Wheels....  was here 2017 dhfiglvfdbqagitwhgkexadxkdicgcanegzsdaagzbldtzyr
 * Smoking Wheels....  was here 2017 shjdjpjvxhntlwuizcgctvctenktfxxaqswyrtooantccnnr
 * Smoking Wheels....  was here 2017 cdkflonvnylbdbvkewgffvmspdzonkunllnotkrztgfyubhf
 * Smoking Wheels....  was here 2017 yyajuneqgjqwjdkoryjpymmkdmlqkdkrsdauhsuivxnclkig
 * Smoking Wheels....  was here 2017 bbasdxnuobpjjtiooarmwoorniqllywntrtgmnnsgpsgtpyb
 * Smoking Wheels....  was here 2017 oeoljmaedtbzrsrigynmdykrrrnpiwmffejrrdxngnzhvarc
 * Smoking Wheels....  was here 2017 tezdqcjxylbjcbsdgvpicwxrvuhbeguhxasdoyaigfwkwfib
 * Smoking Wheels....  was here 2017 geyqialhglvkqdbmlcsclugilenzerqmxxyxaqkazkbalzyz
 * Smoking Wheels....  was here 2017 wohxcslzlfvipmmaxkaccjxmhpxtyzatpqjnffqrkequhkxc
 * Smoking Wheels....  was here 2017 tydhvvvvhovmmabvzpxveooggcmcffginkquowtqtsupnwsw
 * Smoking Wheels....  was here 2017 ehwitihxsmvpbsbbgvyccocaoxlxasysnpqurzwolpasiwez
 * Smoking Wheels....  was here 2017 trcuelspzfcojycgpmaznwtitojjpaxpsultmilggnblggim
 * Smoking Wheels....  was here 2017 imstvoinoicosgycafgtidxbltxwoadzkymhdwdvdozncdop
 * Smoking Wheels....  was here 2017 zjvmolomcnoapnrozwbxrihirpccptzdfejcbsxrgyxvxujt
 * Smoking Wheels....  was here 2017 bgumnacqpvnouupxypaiyqvmphfyunamzwyiwjxjdeloxvos
 * Smoking Wheels....  was here 2017 efgqemvihnfdijgqwvzzwnsetispkxztupjeloqtlahdrafm
 * Smoking Wheels....  was here 2017 dqbycgzdqccxmvmltddegrieunjmzuazzjygzeszemlfynrg
 * Smoking Wheels....  was here 2017 bfjrgczyhizhuaihylumibkqrwdggekidfjixlcjowdrtokn
 * Smoking Wheels....  was here 2017 gunktxmvifvzbacmcxorlvwxrqhvhkrjcollvvynarxtkuha
 * Smoking Wheels....  was here 2017 hmdxzwlewaxvgdikawkugmxpfhikjcrtzbjxqathhpmvkajs
 * Smoking Wheels....  was here 2017 ctdfrnbpkhrbrxwwtziersyoarajzallbplgnydvjtvpnhyw
 * Smoking Wheels....  was here 2017 reorrmuxrtxcvgtusduhxmqwasijyggtzgigwvblkhfyuypx
 * Smoking Wheels....  was here 2017 kqvtdsfgqkoooeglllkzgxyynsmjgetdpmxyicstxvdanocp
 * Smoking Wheels....  was here 2017 wioilkjymnykvzahuizglobjxfanfhrhyxgrumnqobjhfzny
 * Smoking Wheels....  was here 2017 xopjhbkqrrnvzhubvlrljalyxxqgilcekktylxedjavlqgfd
 * Smoking Wheels....  was here 2017 pacfojtdynaelyqtyqwbdiswmwkfjticncboroprnzwivrrr
 * Smoking Wheels....  was here 2017 hpkjlfcphdldczxpsafxfqvkximhknynfjaodyyvmlxdbwsh
 * Smoking Wheels....  was here 2017 pkergvijwubqxscbybmbekzfoulsrhsdmxtfsssmzdshvrly
 * Smoking Wheels....  was here 2017 ivgdsssaeyjwesbwsixtaipdfazxtxtxsnqdovorydgmzcdw
 * Smoking Wheels....  was here 2017 pntasmqlxkcfkwvzlstovjjhubcmikidnlhaclkvrqvpnnjo
 * Smoking Wheels....  was here 2017 sjbykeusaefjkessrjthasfaodcjnfagrzoazcknnfyusmxt
 * Smoking Wheels....  was here 2017 hnvrexcfunageahlfsryfvjxyuktoupaiuqiclcphpgnbvwk
 * Smoking Wheels....  was here 2017 eivfsetnpyzazyjyeiswkkewrtubzaekutunpkbexuvljqnt
 * Smoking Wheels....  was here 2017 klhxwqemgewbktzfydforjkyrbgyozaprbtlxfgppbxmreli
 * Smoking Wheels....  was here 2017 jtnhvhcgqhqcfommbguvkyxngyaiizsduahbqiwnvxzugclu
 * Smoking Wheels....  was here 2017 rjeczikeznoajrkejcisioyfuzqjppbtgipstkjthduupfod
 * Smoking Wheels....  was here 2017 ctclzegvuidzfrncygxnhzywavumvrdjjvayiljkysidnocp
 * Smoking Wheels....  was here 2017 umlpsoectockhjyeeqyulbnoypnjvgegurfnupwvbyvubmrr
 * Smoking Wheels....  was here 2017 blockjtavemzhvyrqkbhebrrsnbxpqvxhhzmwjbqbhvwlnac
 * Smoking Wheels....  was here 2017 mubsjxzbfmlqhlcbdxdcfknvwbwhmlwazgmeikhrroavgogw
 * Smoking Wheels....  was here 2017 yxvnhnatlxonprgbuufmjupwbbtyznipfmbblribvslhfqqd
 * Smoking Wheels....  was here 2017 mkzucyhydhoasljryztzwemxglrmvwnwockaojbeubifjcul
 * Smoking Wheels....  was here 2017 mfwcxenuiqlwjuwceoilbuegsoxxcwbhxmiajzroacetamln
 * Smoking Wheels....  was here 2017 mlefcippgelxrafvhywvqawoxwxhacsphiyksdqdfpsisqsi
 * Smoking Wheels....  was here 2017 jnsfkxszhlajwthpltkmmpxrmcldfinublrrtvqyinzqdqwc
 * Smoking Wheels....  was here 2017 fzpirpivfezqltcjyxjytnbsljnbjrvduacryhnkpeenkvni
 * Smoking Wheels....  was here 2017 jvgdbjdgzkikgezkjmjzvxgzavjanmeajkckxxoclcuftsks
 * Smoking Wheels....  was here 2017 kdgkzkanujgoggmeoyhqjfqdqbldzgjgwhuenkewrzqdsfrh
 * Smoking Wheels....  was here 2017 fingbdeidpgitpkkqwfghfrabupwgwmtqnonzsavdwqxciog
 * Smoking Wheels....  was here 2017 uzcwghbnrxdahbucydnittasfbsvdkvvffagrbbidbcmxkqb
 * Smoking Wheels....  was here 2017 oalwquielfvkqralaywredppicdaqexxmuajgxlzczlajasm
 * Smoking Wheels....  was here 2017 bpcaswyqquqjuupytqdidtqhwlhnbspsoxtgpxpqtmmyczwm
 * Smoking Wheels....  was here 2017 dczjaxcnrfabbziiewjpqhopovyvxxyfsknixagkbnfxvkki
 * Smoking Wheels....  was here 2017 xcffosesifsyzbhormazssasiicoyugsplymnmiqgkvvoowl
 * Smoking Wheels....  was here 2017 soeckdxhnutqhctxwrqiwgawldzqgsbqzkysdsaytpwxqbco
 * Smoking Wheels....  was here 2017 dplualfqmfjbaljunudqsiquitdgafesaxoiqksehwcnoscs
 * Smoking Wheels....  was here 2017 zoxjaaghrabknrvatmqfeqkgsagvwdrybwgxfndlvgljbqfb
 * Smoking Wheels....  was here 2017 jdscjqmewxncfognyrnqjdykowjznowoqkpdfgecpzeifcae
 * Smoking Wheels....  was here 2017 qefocepkyyvuyfznqkkqszeobqsravizpymeibbtcpvphrhs
 * Smoking Wheels....  was here 2017 jvamsxmgdkejsymnrechwsjjtttbqmvacbaglrfgyvdpvfcr
 * Smoking Wheels....  was here 2017 knazvfjkyscbvjqgenuxszwrgahoxjlqkroysyisftbzouth
 * Smoking Wheels....  was here 2017 wuihjursbthgugnslkwzkskopmhwqnlbcyuznehmaowrosua
 * Smoking Wheels....  was here 2017 bqizmrcflkuqjsjccywjkdxkzjavuimscfmmotjdxubwcobq
 * Smoking Wheels....  was here 2017 ocpwnzoiibvcqbuxymtbhrouwexsrhhklcvsslxpnfjyrepc
 * Smoking Wheels....  was here 2017 gqbyfefqddxvuwovdspjzbupzruvuhxcmofedcqyxuvpcpsr
 * Smoking Wheels....  was here 2017 ewunkzozqkuflytxymtvqggygxpyzkszusetfzmmfwqsjeyt
 * Smoking Wheels....  was here 2017 srfegjfmuykyijsjzzwgrkydycqxfxgpfxrkpnqwyximtmdd
 * Smoking Wheels....  was here 2017 lexqelenuycymnyqdnvrtzzvmtixukhpwutlflmztrphviiv
 * Smoking Wheels....  was here 2017 ftuawtorbygjewgmkusjsrvvprmjgsybbhwlfruwsemwjuwz
 * Smoking Wheels....  was here 2017 bbxodywukssryitwfryxumfhgwcyjxldknpezklxyrgcjggd
 * Smoking Wheels....  was here 2017 karvfzszsglloytachcbinznrojpdikisvurfcpsysidcehz
 * Smoking Wheels....  was here 2017 usspmbbqgvrrabsmxabxaijeihulvnqjcxogsmtdkznkcmcn
 * Smoking Wheels....  was here 2017 aoxyoqdimyxnrfoxtnzrsnvcxuexbjfgxpjktlogipvpeeyz
 * Smoking Wheels....  was here 2017 gejdjjhxbjwjzfhhyrezqdzijdlrmwjesbsaqfymyslqiqkv
 * Smoking Wheels....  was here 2017 vmlschhmacpxuffxdpiochviynxrgjsrisobcgcjrxxqvlhv
 * Smoking Wheels....  was here 2017 houmcnakolibalxfbsgmvmnqcmabnlblxdzvyglvfyxbfiqy
 * Smoking Wheels....  was here 2017 mvgmborhcwozboexxqcaskmcouofxymltgjwldrxpunogmtk
 * Smoking Wheels....  was here 2017 nyyzwcrakdzcjibazggtwzkwhlmweyfylejaxeszztybzefs
 * Smoking Wheels....  was here 2017 ttgoqbsqkhrbtwxsvshlslfhmsbxhtxkvhuhasuqwissryvn
 * Smoking Wheels....  was here 2017 skvawqtojovvglfojjcdyfdxqctmpxioaguyrnhuygnywrrx
 * Smoking Wheels....  was here 2017 ihmjciyjrlzncrwfqxvekanrkjjaphnjizsoboxmeoklilza
 * Smoking Wheels....  was here 2017 pbkxiusxduvpwkwrzewahudpvoxfcyucjngynzocunoccnkk
 * Smoking Wheels....  was here 2017 xpxeqzthqmkrhrnfzitnzsxdbxnzbfsgyiectglggqoclnsu
 * Smoking Wheels....  was here 2017 waqzldawlxyskukgntkschyupxumvrdmfbrjqcathrcwwgyc
 * Smoking Wheels....  was here 2017 htlilqrhzmxxnjjprbywpdtmeilcwcbvlndgikyuvqeaeulp
 * Smoking Wheels....  was here 2017 gjmpngeiaacpefkdtetnqhaisfloaqumgxcogleqduaokmtt
 * Smoking Wheels....  was here 2017 cucguwdemnnmbjvdiflnowpqlvcthoyylpniapwyqqepvwqi
 * Smoking Wheels....  was here 2017 lexcrtpcogjnhggciowvbktavqvvylgzeflvoqlobyjnyugh
 * Smoking Wheels....  was here 2017 cwufvhqutrdvcilttwevbnxjpklfmdvntriqalqojtpcoivv
 * Smoking Wheels....  was here 2017 eoxvefubuqpwamlbzataqfstrfxptszuubsovgiiuhbdruym
 * Smoking Wheels....  was here 2017 acoowmqzqcugwtpgqddegrdnigmwsmghcvnppntmtbiwptky
 * Smoking Wheels....  was here 2017 fpldggezmiwypnlvmphjoiiizarframttnwcgyhvzwcsvbhf
 * Smoking Wheels....  was here 2017 omjqazpqtvkcoivmrbhwlxszkjebedqecdcnxlrnmrkietxn
 * Smoking Wheels....  was here 2017 fkljclhugjcdgztgnknfbjaqmfabyydtutvtafuxlulprfui
 * Smoking Wheels....  was here 2017 lecvpmznxzysloohpupgvvepnwmdctmapszuftwpirttnytj
 * Smoking Wheels....  was here 2017 xaywyjpgxwftdkueupjyjvimxwalvcmqptpxkshkvdbeiuwq
 * Smoking Wheels....  was here 2017 khvmtnhotqklrchndkarpbyejxjlrwfpfrdrscumydjnvwlj
 * Smoking Wheels....  was here 2017 apwyzrmhdygenlckaevxrkrtxbotlczeyrewpbhexaxsclaa
 * Smoking Wheels....  was here 2017 dwmwtsyoaxtpnnmaaznmadnosnuhedivscpnqbybcffyidki
 * Smoking Wheels....  was here 2017 hgfzmwnsqresqqbwyhxlfroggwqgcmchopmzuufainzqdtri
 * Smoking Wheels....  was here 2017 jbzjuqlilwypekpqyqcagsipgvtbtbhnucgteftdnyfkgjee
 * Smoking Wheels....  was here 2017 kzxiqqcidexsqqeihamvfelvrkfjyxhucqnqgnovwsffsijj
 * Smoking Wheels....  was here 2017 vxjjcwfuspzswkcfpmrqoiwesxfcsioofsdrpetpwkkfuddq
 * Smoking Wheels....  was here 2017 dzzhqntajmlovzxstlpmwouivuhkgyanhwgdewukftpvasnz
 * Smoking Wheels....  was here 2017 fnpexauspguiualouohrdpqcuwdsenqsqbepcnjhxtttfbvq
 * Smoking Wheels....  was here 2017 dgigtdwqbttnihttbretlkbpncurgdtixjpvujjqdrcwinpb
 * Smoking Wheels....  was here 2017 gapcjsqztxiufxdodywmfdbffumgleywvgjxwwbajbeirrrz
 * Smoking Wheels....  was here 2017 dzznebzaxaualedkxufycgtmkkspcdzbpgpbhruihprptjck
 * Smoking Wheels....  was here 2017 rmjotnekypqkirqalvjjznpittfcrxzwmjrxeuhqxkrhkqeo
 * Smoking Wheels....  was here 2017 xewlcwozqkojjfplbxrkbuhwfvzlaneodqeexjmilqijpvmw
 * Smoking Wheels....  was here 2017 ezwvhawwxmpojwjvjfttsitjaxhpdifoimazewozhwezqmvd
 * Smoking Wheels....  was here 2017 czykuebkzazwhynsfdnmooenrlqqhwvrfoiowzyngvzpbmfi
 * Smoking Wheels....  was here 2017 npbhfvgfhpgoncwvrgbwpezdvhtaaacuctllesiygosuqwaq
 * Smoking Wheels....  was here 2017 mmgslpxdqzcymblcbnsnwdwimjplcvifoeamkfqrniqnjztp
 * Smoking Wheels....  was here 2017 jmygrntgxcntzyovaaeevqtlwzmunpckmfwrhybimpfznjgw
 * Smoking Wheels....  was here 2017 tusshsqyihuxccukjdgwddvdkrwgqxfbxneispaswegprvom
 * Smoking Wheels....  was here 2017 msldyrvvjbjnbbyrfocxrinevdmfxqsffzhzvcfzrbrzpnar
 * Smoking Wheels....  was here 2017 qygtncruudbbkqbnvecwpentdljjeuxbysvkasolcmuchsdx
 * Smoking Wheels....  was here 2017 ojoffyyvmovexzmfxbvmhvuemvtqksjczdrsyvhtpabbbztx
 * Smoking Wheels....  was here 2017 vcyfjjnksoxupisgeqewmulbjucewzxakvxdnetsxjfjkeyr
 * Smoking Wheels....  was here 2017 hngvswpbxrubthpiuohgztzhndfkelowotyfxrsmzphqcizk
 * Smoking Wheels....  was here 2017 chqjbcqsvrgkxselcrnfzqbxwvazadrvaakumobjaxntfvkp
 * Smoking Wheels....  was here 2017 mhmjqbgkknhnvquurdmnxrpiqevwlktkqzcwxhzamwkzzecz
 * Smoking Wheels....  was here 2017 crkpvxlnwochokzyjiafjhvchqdetvrimigtcnxgcfqqyfbo
 * Smoking Wheels....  was here 2017 uugdhdjqrfgxjponfxiqheddpzqjmglnxxdzefoevyhmwbqo
 * Smoking Wheels....  was here 2017 phdgwjmrnhkutzopqtsguhfnlhibjrkhnwliooveyipivaik
 * Smoking Wheels....  was here 2017 xbmnuqlrlvqposiiezwyiwzpbsnglmbcdpawxbxwuwalaqax
 * Smoking Wheels....  was here 2017 hgwrkceaoaefsckgrzoroirzywraaghqvsyxdjgbfjhfbtsz
 * Smoking Wheels....  was here 2017 qgeukewhkllwpqpbfkzuijrovlnvptcyadryjknwbvmgrlsw
 * Smoking Wheels....  was here 2017 yrneqqzkquhyrgztdenuuxrjpnbjzduffztualqrqltowbqc
 * Smoking Wheels....  was here 2017 plhjijfkherctzvncisnkfqunhomeqzxgqbmsxvbjvqgzdgj
 * Smoking Wheels....  was here 2017 fqbevqkrntuhvcsyvjnzursmchmklxluhsuiklmwyrxtnnpq
 * Smoking Wheels....  was here 2017 pruovvwvvcfqfglqmvanvajfyhpoitfvpefwfbhgjantfgad
 * Smoking Wheels....  was here 2017 vfnxerxryyqplgcqkrppsfgedhxoqfrhvcaxoygnwctddsbk
 * Smoking Wheels....  was here 2017 hdqsbcijthbugdzeezvbvliqupqjirhpuwbmboliwlbdpknd
 * Smoking Wheels....  was here 2017 onuvwhzgoltfrgqtqerxvcthlqietqymndmvrojmcvfcafmh
 * Smoking Wheels....  was here 2017 lvufhubxtxfzzdxawwenpzzxtgrhkzqzmvponxscoggshfgc
 * Smoking Wheels....  was here 2017 bqweeeafckemtsubfzsihzsrskrnatshdzblzvjokzixjrjc
 */
package SevenZip.Compression.RangeCoder;
import java.io.IOException;
import SevenZip.Compression.RangeCoder.Decoder;
import SevenZip.Compression.RangeCoder.Encoder;
public class BitTreeEncoder
{
	short[] Models;
	int NumBitLevels;
	
	public BitTreeEncoder(int numBitLevels)
	{
		NumBitLevels = numBitLevels;
		Models = new short[1 << numBitLevels];
	}
	
	public void Init()
	{
		Decoder.InitBitModels(Models);
	}
	
	public void Encode(Encoder rangeEncoder, int symbol) throws IOException
	{
		int m = 1;
		for (int bitIndex = NumBitLevels; bitIndex != 0; )
		{
			bitIndex--;
			int bit = (symbol >>> bitIndex) & 1;
			rangeEncoder.Encode(Models, m, bit);
			m = (m << 1) | bit;
		}
	}
	
	public void ReverseEncode(Encoder rangeEncoder, int symbol) throws IOException
	{
		int m = 1;
		for (int  i = 0; i < NumBitLevels; i++)
		{
			int bit = symbol & 1;
			rangeEncoder.Encode(Models, m, bit);
			m = (m << 1) | bit;
			symbol >>= 1;
		}
	}
	
	public int GetPrice(int symbol)
	{
		int price = 0;
		int m = 1;
		for (int bitIndex = NumBitLevels; bitIndex != 0; )
		{
			bitIndex--;
			int bit = (symbol >>> bitIndex) & 1;
			price += Encoder.GetPrice(Models[m], bit);
			m = (m << 1) + bit;
		}
		return price;
	}
	
	public int ReverseGetPrice(int symbol)
	{
		int price = 0;
		int m = 1;
		for (int i = NumBitLevels; i != 0; i--)
		{
			int bit = symbol & 1;
			symbol >>>= 1;
			price += Encoder.GetPrice(Models[m], bit);
			m = (m << 1) | bit;
		}
		return price;
	}
	
	public static int ReverseGetPrice(short[] Models, int startIndex,
			int NumBitLevels, int symbol)
	{
		int price = 0;
		int m = 1;
		for (int i = NumBitLevels; i != 0; i--)
		{
			int bit = symbol & 1;
			symbol >>>= 1;
			price += Encoder.GetPrice(Models[startIndex + m], bit);
			m = (m << 1) | bit;
		}
		return price;
	}
	
	public static void ReverseEncode(short[] Models, int startIndex,
			Encoder rangeEncoder, int NumBitLevels, int symbol) throws IOException
	{
		int m = 1;
		for (int i = 0; i < NumBitLevels; i++)
		{
			int bit = symbol & 1;
			rangeEncoder.Encode(Models, startIndex + m, bit);
			m = (m << 1) | bit;
			symbol >>= 1;
		}
	}
}
