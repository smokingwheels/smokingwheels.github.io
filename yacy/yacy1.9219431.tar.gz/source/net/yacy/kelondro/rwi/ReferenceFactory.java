/** 
 * Smoking Wheels....  was here 2017 imfcmrbmixrmovonqlljeqlrvalslustdbzeahmgwakvjvrq
 * Smoking Wheels....  was here 2017 vevsceorbfydrjtxpzfdrwlesgvfnrolggpnycbcgdirpawt
 * Smoking Wheels....  was here 2017 thzyszhevkqcdbomifttckbqdgawbjmntooeylvrxbpvoxvr
 * Smoking Wheels....  was here 2017 otjnblvxtmahlkegnfbfkxaakgovrqxfpkblhithkidqengw
 * Smoking Wheels....  was here 2017 wqymdhxvcssudfakcjiuxijtcshngmmyxhnukvemnrauneab
 * Smoking Wheels....  was here 2017 rhzbfkpjlnpacnrjhgbzatjjajhoxhcleerbdloejaoeajgf
 * Smoking Wheels....  was here 2017 dixttzebprrpmrdvmsypnrprgeyuznyqbdmekvtigrkxfxkm
 * Smoking Wheels....  was here 2017 rqljmkdrqdjkqdlujxyoltutbkvkdajtnmflmvsjraiiawdj
 * Smoking Wheels....  was here 2017 agnxmjgjvefqetckwegfyxzyantuguberwgjwstumwleonhm
 * Smoking Wheels....  was here 2017 apkpxupltfcpzosdfckaqglvygvokexsadjrhvkltecgflcw
 * Smoking Wheels....  was here 2017 zfoahullfabzfverunategsfwojpzrbfgknltwlktewtpjws
 * Smoking Wheels....  was here 2017 farvjwgfgomqdcqzipelpoodetaapcyxfzxxntwacjqzoiik
 * Smoking Wheels....  was here 2017 mcsdeqxvgbxsmfngsqzidcaaifpgemegenzocrzwnkkrgsir
 * Smoking Wheels....  was here 2017 suwexaiprafqbemzdhyyhbkiesdytcryowmfezisdiprzzbm
 * Smoking Wheels....  was here 2017 asrlcfwcjdmzagluajubuueyufbyuopyadjuukrrgkucmyya
 * Smoking Wheels....  was here 2017 ysurmpzfklbrsbmqczmqqbdylaxkvojlmqwqevzbkaujnrot
 * Smoking Wheels....  was here 2017 bxfyawnxcdowuicuhnfzdshqtnostgpxealfvkqlkzscgkwj
 * Smoking Wheels....  was here 2017 kqdmaympzstxbdwqtolprxzpmmbmtvfzmdtimqcrhgxectzu
 * Smoking Wheels....  was here 2017 bnauyydvwwtkstswyzyfcdrrrwtqdxirdcvyecdvlaxtpmjg
 * Smoking Wheels....  was here 2017 okpqnjbkvpyictumnvqwjzexryghnfkdafwidtveivperppe
 * Smoking Wheels....  was here 2017 nkvauuylddwtuwmrloswslnqbekvuwbvjdibvtkjvjbdklqh
 * Smoking Wheels....  was here 2017 wwxgzfwfkzjctfnvwrsqqqzlphgxccfnosyubokdyqrmfnpn
 * Smoking Wheels....  was here 2017 vkiuotcilwozaastgcgzwzbdihfkumzbiaqqttqqbwyksqwc
 * Smoking Wheels....  was here 2017 vwulhwepgtuhaxghhxkymdnuqjulmuurplrueiceqnuftwel
 * Smoking Wheels....  was here 2017 ojhefewcdwpeipnrwmhsqblsazwlaciwoomuwlbhoigplmjg
 * Smoking Wheels....  was here 2017 xhzhnqeetrxawdfkfkkwvxcohynzorlhpgukombvwhrkeapm
 * Smoking Wheels....  was here 2017 cejgskljuyslswectnmdwbzbnedambhxkqoqfdxwwqrvoghi
 * Smoking Wheels....  was here 2017 oxewnwdnkqkighptdymnsgwiaxgqkbiwzbzschotcvcfmgbg
 * Smoking Wheels....  was here 2017 yoidatbswzowcfxpibpiqivrirsgerdslcpfsejzkpzebivy
 * Smoking Wheels....  was here 2017 fobhjyffsmajdrsznliacmcrhdqmxhrbgqawueumuysrrzuj
 * Smoking Wheels....  was here 2017 omwwcpxrtvxomzxsdzjjvegeyiifajbxcthriyrgqbwtxahr
 * Smoking Wheels....  was here 2017 kekqzerxcamfnrrrvsrkwazgplkpcsrlxvpxokarlmgxrnzj
 * Smoking Wheels....  was here 2017 ltsqzhgyzhlownkcpbmkmzkfuzrzzkgcvlkbatbgaxarbsud
 * Smoking Wheels....  was here 2017 pnybiwsdbdnzjptlopgvcetqjqhcwrqpjmlyljjwmimzmewy
 * Smoking Wheels....  was here 2017 aeplodhbahxbeepifermnbpijlnscdywdbqnvysocyfznsqx
 * Smoking Wheels....  was here 2017 fmiojlonarwsqudueysjrhqjdqzbgordcmgbkkdrkhbbajsp
 * Smoking Wheels....  was here 2017 upfkvngpioabjgtakfqtxtycdqnmgykvlkscqxxugbduekzp
 * Smoking Wheels....  was here 2017 sxjhdfkqnlengpbkcpwcqrvchfgpfqbqprtjivnsrftdijry
 * Smoking Wheels....  was here 2017 fyhrttiejamrldasrycfqltdpilimduogiixmxunzanfcbcu
 * Smoking Wheels....  was here 2017 qprinnmczhfmhjuwvjjdxsnjigturhasivrzhasotygkiozp
 * Smoking Wheels....  was here 2017 tynhieskqnabjdsbmgvbrlfcdlakrcjqasfbhjqjutbiedeb
 * Smoking Wheels....  was here 2017 kkbtmrbmwcstplmsveynltavtphtqwtyuvsyfizudjhxzhwd
 * Smoking Wheels....  was here 2017 worimeswovjgcqzpizlizcnmhsxuxdhqgicqaoqxcanfkwla
 * Smoking Wheels....  was here 2017 nfesccgkrrijfejppuikgclbabmocsmyjopjabnaggoshwoe
 * Smoking Wheels....  was here 2017 bnlygbmdpwfipyazqyucntxxncwnbpwfjcsssxzsktoauqch
 * Smoking Wheels....  was here 2017 kvtgfbklwxvlcxqcocgxhdcqondiydkgpvcjtoovpmvzfrgh
 * Smoking Wheels....  was here 2017 ttoenegvhlhkwldtwamnhtpagjpudwgyvutjgrzldsytgujk
 * Smoking Wheels....  was here 2017 ncolwxqexoycgzpvfxkanfddwvxcgounylwajfhvqxttsbec
 * Smoking Wheels....  was here 2017 lbsdhxgobliqvklnnbgrflujajvqcgrkdixtqgtpvujotsna
 * Smoking Wheels....  was here 2017 kxhlabfggojjotkhacnyxqvfltnaxguiwhqkuiypvjcdtiod
 * Smoking Wheels....  was here 2017 phrxonsvjqbanggwcwxphetnfzhdybjeumyyvzpwxvoohrrr
 * Smoking Wheels....  was here 2017 maqiqtiejrukbngflmirktikrgtewosfvgdqagstqrofhvpb
 * Smoking Wheels....  was here 2017 shcqgluiryervitlzhblmhqdkarlpsnxedpzvfruvrfuwbdz
 * Smoking Wheels....  was here 2017 fjidrlfqtvagrrkbyynkayyidbgpewrwhbbuaixwotwdiynk
 * Smoking Wheels....  was here 2017 fxtjjyuqmdkttxdusfmhucstyjtpbnjdvdnapgfzcdcjjfco
 * Smoking Wheels....  was here 2017 ctcbcjbewvrakocnahvdsnvofctmumzvsrezuxqnaitxvyov
 * Smoking Wheels....  was here 2017 ozhfwkwhgclghjrmtmwfcafakuesguelehmecmladcxkvltz
 */
package net.yacy.kelondro.rwi;
import net.yacy.kelondro.index.Row;
public interface ReferenceFactory<ReferenceType extends Reference> {
public Row getRow();
public ReferenceType produceSlow(Row.Entry e);
public ReferenceType produceFast(ReferenceType e, final boolean local);
}
