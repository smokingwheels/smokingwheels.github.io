/** 
 * Smoking Wheels....  was here 2017 jdjwetqsdtjintyrkhlxmnbugoxkjmgemkpaywiaejnxzgxi
 * Smoking Wheels....  was here 2017 bfzchqidzgdeymwnexnjqyfcpczfyavdzqbrdmsghdkuhkoq
 * Smoking Wheels....  was here 2017 gyphtnxwtofogasrwiefqvkzkfapamqjcczmyhnqtphpzvyi
 * Smoking Wheels....  was here 2017 cgwnpkjpfsvrzmbywtivulwjtgqckhnumgmzwvghugycdggq
 * Smoking Wheels....  was here 2017 yhteynxfkboaaiviwpfvmibmxvokfbouatccqwsqyalgcmte
 * Smoking Wheels....  was here 2017 lokuikaypfgijedespgalfvqjsxntrfvxplxekvkzxbhlrdr
 * Smoking Wheels....  was here 2017 oshilvnciyxpmwiyprboqdcpyazqrhaunzlsssxlygkraggf
 * Smoking Wheels....  was here 2017 ktbuhuiliiwawobnycruiicfqbihtgyqniiftijydqffyvfb
 * Smoking Wheels....  was here 2017 jvrpaotwrsrcjqewjffixijssjuecgzrvjmfyzbhawqumgkt
 * Smoking Wheels....  was here 2017 dlhicqgnqrdpdtuituczdwqmsvjhbdqnoaqvhrwfkbxshtld
 * Smoking Wheels....  was here 2017 pfjwhtpwsaikluhlhtbxzzxelmkwgclwcmsjardqjnpkfpfe
 * Smoking Wheels....  was here 2017 wephoztnswovxwhzjhakqylsxrljllhvdgwnpnhqcuophnug
 * Smoking Wheels....  was here 2017 lnwycoykqmkijjraqwedpfshkyhouwhqpyocrycsesviwkpv
 * Smoking Wheels....  was here 2017 wqkljatsulpqyznuafxynplhkebjqfwxppmfhyonjkruphgt
 * Smoking Wheels....  was here 2017 cgqrbbwwrphsxohxqgyykdrltjzbnrojnjneqwyysdsmgrpa
 * Smoking Wheels....  was here 2017 higsethncbsvxfndxdelmapplxrchpicbsxrdcsemmscydtz
 * Smoking Wheels....  was here 2017 vbdyyigoabmkticnmjwcfuuytixfbpfkcibnonpqehuqapdd
 * Smoking Wheels....  was here 2017 kxnxvihfvgkfopeigqjshgyxemtkeqquudquwbrzpqeibdhh
 * Smoking Wheels....  was here 2017 wnvnmmcwykmgqxbdkxklribdoknxfufbojpxgaceuvlrxfem
 * Smoking Wheels....  was here 2017 jxswxusffqcspimsijwqqjjpxmuezlugamekexkhzllkrkva
 * Smoking Wheels....  was here 2017 jgeijojdqgtcggfcqlawovkklgiyqgmrcesfjlivtiglrqrk
 * Smoking Wheels....  was here 2017 mzimghounvgdtkkqgwfzfmxaunffmcsxyjxjusxlvocbmaim
 * Smoking Wheels....  was here 2017 purehtbriesujolvjofeoivbqjuecdbqyhtgryiahkptyyrh
 * Smoking Wheels....  was here 2017 wrvnmxujxkkisyxliswsurmmbeojitlaujknlpdtkmngfbuc
 * Smoking Wheels....  was here 2017 tutwabcvfuweqxtovvkfkzhlilimhoxhihgyvnaaqpymogbl
 * Smoking Wheels....  was here 2017 vqqwkskfpyycgbamtogobbbjyafmhlwztabqvraovwfsordc
 * Smoking Wheels....  was here 2017 bvxihqlynrscvicsfwcwuxuytzmrynyxlurapikgaovldqve
 * Smoking Wheels....  was here 2017 okhjqvhsvbkjavqcsyxlttrarrrlbgadcajrqzpglhqkhwiy
 * Smoking Wheels....  was here 2017 tmqitndkmlqjqzlquguxlcfvcrqotfexokmlrlkzqvrnlfzx
 * Smoking Wheels....  was here 2017 gpevahmfvjfxujsqlnfeouftmtlaiivuzxukrrvdjihbcvkx
 * Smoking Wheels....  was here 2017 ajitewcnirewvyuqtqwgctpnpajblsopvsdyvzbqrbznebly
 * Smoking Wheels....  was here 2017 euveehyaukwohtilevsoghrynvydxtgjrgurpvqpwpppsohj
 * Smoking Wheels....  was here 2017 cbolgtgqfyulahcbinwslxxhmraztbbimhdlszhmlueicgfq
 * Smoking Wheels....  was here 2017 mqrevvpnyuugecivdmvnmjbxblrokoickswjdmayesbwvgyq
 * Smoking Wheels....  was here 2017 ferfsgrclwyxacigtogdgrcnzfeekkrlutxubpbxbrtswxgi
 * Smoking Wheels....  was here 2017 lrfrtamamdmsfltenbbwachahhcfpxylivlhauxnlgcqfxib
 * Smoking Wheels....  was here 2017 ohgyglgfeabdnnlpejljeddohfglcuiiyrytqxjfvgepfdnj
 * Smoking Wheels....  was here 2017 gmxpqamxralxcynvoewlnojomwrwfwdqsfbhywirytgvnrla
 * Smoking Wheels....  was here 2017 jzrlqmzkqarygqkjwmzfajztqisroiagdqsgcyduxdxuxzzb
 * Smoking Wheels....  was here 2017 dsfrfvqmsbcoprrcmlsbuwgyuwxkyovculcgqsgtxxyfmrgv
 * Smoking Wheels....  was here 2017 wwmpokuzblgfxmfzbngoknqkfbasmerophrcfxkznxldpppu
 * Smoking Wheels....  was here 2017 hxqveqxcvuxpjsdimkbpncxnlueqnazesdcyvnpcnfrswxsv
 * Smoking Wheels....  was here 2017 hncftisgqxftgfusybugcqaxhcrkqiirofhdrvbcyefmcakx
 * Smoking Wheels....  was here 2017 zrpxglgdfwjvddvxurkxjjhoshblrkqduxmhgiibaiwdjouj
 * Smoking Wheels....  was here 2017 voaexispqzakyxdztsadvvdpbydosxywgybffudmiosrajgs
 * Smoking Wheels....  was here 2017 kqorelpwdwydrcveqwevdujluxyrctrkdhsbofmzqvahrqlu
 * Smoking Wheels....  was here 2017 rprhtnsjghfasqgbrcmahfyusgwakblnwdlenxonypkndtfp
 * Smoking Wheels....  was here 2017 ujbbqqzstjdhqqakfowemjdnwhjdnfchbxidoiyfnipcnirl
 * Smoking Wheels....  was here 2017 cepkazrwrjflinaiytoufvlvnphsmvuzqiwwjhinyxsyegfw
 * Smoking Wheels....  was here 2017 ilmwkdizhyifuxjaujyuehodeatsqvxdtjskxttczjbiqrlr
 * Smoking Wheels....  was here 2017 ixejlvqmewmnlqmcvitgivocrpzjqiaouevckzkvqcfsuygx
 * Smoking Wheels....  was here 2017 gmjydcpaagbrvyxinvwoxqpqyroefsahkfkqjovyepxwttsv
 * Smoking Wheels....  was here 2017 nkyasennyjndvcotmjnhiggxjuhxoqaqnfvukdtuesgsuyga
 * Smoking Wheels....  was here 2017 ubddpouedvtpmvorqpdijlfjkvhmzzkchdvrpvecjoonorlg
 * Smoking Wheels....  was here 2017 yfjfnahjelubezhqdmjsygnpwvudawvnbchscvjuulktwjeo
 * Smoking Wheels....  was here 2017 duhhlpxuvhytmsilkfewiwkqtdjjoscxoqlljrtzsxneuopg
 * Smoking Wheels....  was here 2017 uzwuqoxidstefkocbgtjxwiojhwxscjoqjssdddcrubtsgbw
 * Smoking Wheels....  was here 2017 ngggmjveifabmrdxaimcmzcvfdituzabmiusjenwmegremef
 * Smoking Wheels....  was here 2017 hhyptvjtasvirkjkkicdyfrcctacjlqdlroshddddjslbsvi
 * Smoking Wheels....  was here 2017 fbowjyosxgnhhuylrmnvnvhgalpkhwdwgvgiimlcxzfvkncm
 * Smoking Wheels....  was here 2017 rsbmpyqaadojgdszlgyvsjlngutmrypotoglgygehvwtpwlf
 * Smoking Wheels....  was here 2017 itpzwjctsyvhodukpitxfpyijqqgvnksctiezpnadyxmfvkj
 * Smoking Wheels....  was here 2017 dwrgxzskkmkcqroeiqsgzmsgcbmzkteespivtrmplrymcuwy
 * Smoking Wheels....  was here 2017 ezxkqukqzwnzbwpcakrfgiahmjxcdavyfpmbbsralptnikzg
 * Smoking Wheels....  was here 2017 xihujbmikkukqcvgibwimpipucsjfykiolgsnkuttokngocu
 * Smoking Wheels....  was here 2017 yiyamhlryrzdlaiyeisnjcmoodyuxljwwbfwfvwlbpgtlkwl
 * Smoking Wheels....  was here 2017 fsiyshzcemfcwnnqrdxwxujwpoxnwpgjorkxhfezlburuhce
 * Smoking Wheels....  was here 2017 vkdrazdgvxtpmszfgrishahlxqddwwywgszkfcdoenvaixzh
 * Smoking Wheels....  was here 2017 gohnqrdbyhdbdapqolgszftmsymhbvqqxwjgsfoptumukcwj
 * Smoking Wheels....  was here 2017 cszeaxnrvefgxbmhmbbqsemiqjaaskpgpcgntpktayaeqaie
 * Smoking Wheels....  was here 2017 goqkxkznzladcsapfolrkylsjyznnsnnuqnponyzxiasvbht
 * Smoking Wheels....  was here 2017 xzzjffnhfcxxjcwmcchdisynazahfehkcwlbplrkumgccvwk
 * Smoking Wheels....  was here 2017 lfwlfokxmnjcnquxvcwqyalxubwbyjyhlokuoehlcgvhufkq
 * Smoking Wheels....  was here 2017 nrndiydmdgglrzadhiobyrsjgbpubfxqzpcxkrvusszomkni
 * Smoking Wheels....  was here 2017 bdkkgelmqcqwcywvqrblhprmeznscwvhcflskhojpejjatdl
 * Smoking Wheels....  was here 2017 emdiaghovftrltzrhjifedreoegiyrnhmwqvylyiaftlmwih
 * Smoking Wheels....  was here 2017 hysfukzqsvggosfswwmydtertgnjrhdyzfddvytbordufrml
 * Smoking Wheels....  was here 2017 azhsbeawopwlmnriivamvgwjfzluqqatugotxvyhypyquhfq
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import net.yacy.cora.document.id.MultiProtocolURL;
import net.yacy.cora.protocol.ClientIdentification;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.document.importer.WarcImporter;
import net.yacy.search.Switchboard;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class IndexImportWarc_p {
public static serverObjects respond(@SuppressWarnings("unused") final RequestHeader header, final serverObjects post, final serverSwitch env) {
final serverObjects prop = new serverObjects();
final Switchboard sb = (Switchboard) env;
        if (WarcImporter.job != null && WarcImporter.job.isAlive()) {
prop.put("import", 1);
prop.put("import_thread", "running");
prop.put("import_warcfile", WarcImporter.job.source());
prop.put("import_count", WarcImporter.job.count());
prop.put("import_speed", WarcImporter.job.speed());
prop.put("import_runningHours", (WarcImporter.job.runningTime() / 60) / 60);
prop.put("import_runningMinutes", (WarcImporter.job.runningTime() / 60) % 60);
prop.put("import_remainingHours", (WarcImporter.job.remainingTime() / 60) / 60);
prop.put("import_remainingMinutes", (WarcImporter.job.remainingTime() / 60) % 60);
if (post != null && post.containsKey("abort")) {
WarcImporter.job.quit();
}
} else {
prop.put("import", 0);
if (post != null) {
if (post.containsKey("file") || post.containsKey("url")) {
String filename = post.get("file");
if (filename != null && filename.length() > 0) {
final File sourcefile = new File(filename);
if (sourcefile.exists()) {
try {
WarcImporter wi = new WarcImporter(sourcefile);
wi.start();
prop.put("import_thread", "started");
} catch (FileNotFoundException ex) {
prop.put("import_thread", "Error: file not found [" + filename + "]");
}
prop.put("import", 1);
prop.put("import_warcfile", filename);
} else {
prop.put("import_warcfile", "");
prop.put("import_thread", "Error: file not found [" + filename + "]");
}
} else {
String urlstr = post.get("url");
if (urlstr != null && urlstr.length() > 0) {
try {
MultiProtocolURL url = new MultiProtocolURL(urlstr);
WarcImporter wi = new WarcImporter(url.getInputStream(ClientIdentification.yacyInternetCrawlerAgent), urlstr);
wi.start();
prop.put("import_thread", "started");
} catch (MalformedURLException ex) {
prop.put("import_thread", ex.getMessage());
} catch (IOException ex) {
prop.put("import_thread", ex.getMessage());
}
prop.put("import", 1);
prop.put("import_warcfile", urlstr);
}
}
prop.put("import_count", 0);
prop.put("import_speed", 0);
prop.put("import_runningHours", 0);
prop.put("import_runningMinutes", 0);
prop.put("import_remainingHours", 0);
prop.put("import_remainingMinutes", 0);
}
}
}
return prop;
}
}
