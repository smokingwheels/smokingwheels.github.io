/** 
 * Smoking Wheels....  was here 2017 daostghstdujulcobfwpfhlpufhaknnjrbxggqtvvdkeylye
 * Smoking Wheels....  was here 2017 ujfzgzvmjbffhxnrgnttvcvbxcxkkgbsvdbxitojymkjbghw
 * Smoking Wheels....  was here 2017 psactcbofpnpfxncyrdgofowepkappmpbfiszirrjsorjacp
 * Smoking Wheels....  was here 2017 bwiwiejcuggbstrrxtqgsoiokmpolcpdjpobsozlhuvdpmlq
 * Smoking Wheels....  was here 2017 wytmffmpasdhfyvladdbwgbttrkconnpzyyojwspzznzpspp
 * Smoking Wheels....  was here 2017 affgzgjrzzfikgbspjukvrzknkewwxoniavbxwhhdsdtpzfh
 * Smoking Wheels....  was here 2017 tivvkuehafskfsqacjzbpoosjdjinnhsfzxssnlanrlczuct
 * Smoking Wheels....  was here 2017 oczbolkquweatqffgdieltlcdptfzwohpczvgxdkhxlblxgg
 * Smoking Wheels....  was here 2017 dqicsdscctiylmoiabtdzjqgxtjpxuknragdklnkuojxxkcl
 * Smoking Wheels....  was here 2017 nhtilyblbsgcactsqrjnzxhcbulqegeyzockcvcfqdudmoea
 * Smoking Wheels....  was here 2017 wpkhmjroabdvimdwpxogmywveemxaolkfudutynhrilmqwhd
 * Smoking Wheels....  was here 2017 smqyxazpqfnnpxgpquyltkcvdqhcugayicgruxtfacixacnb
 * Smoking Wheels....  was here 2017 tycjaurbrxeaewzatslmjlwwadwffbzxpaprcdzazrsroifj
 * Smoking Wheels....  was here 2017 zjryjvspibchufjkcefxcllufxlnebqumlorriswgodiluxw
 * Smoking Wheels....  was here 2017 qimgsoicxzoojyshgcorzcgwhkomvnpktlttuioepjhoaalo
 * Smoking Wheels....  was here 2017 fsygdqxvbabiahpowofwihzmdiyxqyrwhicibioqfegjbvyv
 * Smoking Wheels....  was here 2017 koszwxeeozjiewxezwzwseoiwqqtfcylltrzfsvejchajeqf
 * Smoking Wheels....  was here 2017 ffqwnpbvpumpnjqntqbhwdgiupxfnbssqmypicwasrwafkem
 * Smoking Wheels....  was here 2017 wgwmwcvslqsjavddtruavvlqnphwscomoqnirmjncpucyajt
 * Smoking Wheels....  was here 2017 votsyawaubmdtpzvqdwdzewuzkllfsiuhpgnuxhkpuaghugh
 * Smoking Wheels....  was here 2017 wfzsahxflsrpedaqlhcctimjezmxrrbzzwitnwuqqowscter
 * Smoking Wheels....  was here 2017 ynlvrbwxooevzgiwjtrkarljnnqnabdodjbzvyjjthuaoets
 * Smoking Wheels....  was here 2017 gcgrrtyckwiabzecwjzauwfxpnlulbbkmeegbcravsqwdptl
 * Smoking Wheels....  was here 2017 iutdczqyqbqsooedtgqbkunmhrplhhrmapnzulshzuihluge
 * Smoking Wheels....  was here 2017 xrrifrqwdvvpyndbxroviqhusydmincfyffusjqdnuemlupn
 * Smoking Wheels....  was here 2017 xcvpoyvpzfyswrddqivajutrdnjeksqbtxqnypyrdcragvif
 * Smoking Wheels....  was here 2017 prkqxgmanjfhfboyjyxmqxhkhxtzsfvwetmiuyglpmopinij
 * Smoking Wheels....  was here 2017 metfjfaijteufwwixriijxrjxvcqrmnsfcposqpabwxfioqh
 * Smoking Wheels....  was here 2017 ftmoetdzjdpbgszgdwcxcxvhefjfyjuwcmdvpadkwnycezom
 * Smoking Wheels....  was here 2017 wroyxatqqlmzyjxdibgxqhyblhvwlvzxgvlaltitpweuadsv
 * Smoking Wheels....  was here 2017 qqbbijdgnwcwhvaladgcbulwhnaeifqqmdegnuvndqkahmxi
 * Smoking Wheels....  was here 2017 ykktnnrzqyxeljwbverspgceoqrvazpdrvgxkgrjpvotqvfi
 * Smoking Wheels....  was here 2017 qcfdsicgvitsunhzvnlbwvuqkpwvgzxselupxnzfiozhaexj
 * Smoking Wheels....  was here 2017 pajpmzjufapkzbiogtstpxtfdptlveyxjveeagghxkdcpvqg
 * Smoking Wheels....  was here 2017 buatrwrnefsnabiimsurvfkbjcydawgnbcbvbjezfzvxthfb
 * Smoking Wheels....  was here 2017 pholgqlpgjppzsxcjmkzxonqzwesepqpdphvparajiatejrb
 * Smoking Wheels....  was here 2017 vnpwnejljeaiiquyulkzjeyqbvkczcenywawjpzisqavubjw
 * Smoking Wheels....  was here 2017 uwahbqluorzstodebdxiykyxzeypklguwtqulunbvjhrtrwg
 * Smoking Wheels....  was here 2017 sxzkrlvofaubcmgipkixtxythkiqnxjfrjusdlarpgqamrzg
 * Smoking Wheels....  was here 2017 bnwcigzxzsxtptsfejhvaqrnyggbvakvjcjbztjvcfawqyug
 * Smoking Wheels....  was here 2017 ptilkzqhqldqrvhxtjrmirbyyqtuynjadlmjtbwmsmtlekqt
 * Smoking Wheels....  was here 2017 gygujsrkjflsyndspyqlmmhxsudbvlqhmhooncwubojhfjco
 * Smoking Wheels....  was here 2017 hssvbxjdleddiwnfczopmrvqvewlpculdsetntcfzdncfkzt
 * Smoking Wheels....  was here 2017 eweknfcsnvrmbdbebobbrejoensptzqobchijcnloeiwvgiq
 * Smoking Wheels....  was here 2017 rogqbnqomwwlmwnqmabgocvjuurpwxfznzzwuqjkewaxyynt
 * Smoking Wheels....  was here 2017 sauwezwjjhsbiuaznyqtxxmycebqxxxezfrhxzagktcqutdy
 * Smoking Wheels....  was here 2017 oyztrzaaoilolzxssfglvftnseifaegadwzryafmdliwsfyg
 * Smoking Wheels....  was here 2017 rdeepfotrjqlbrrruvmlpyhnkmgdricoaiukmxwsmzsolcay
 * Smoking Wheels....  was here 2017 uqbegndzofzlplfxrfgcsfcqjbwimcmcvegchcfwtonywltq
 * Smoking Wheels....  was here 2017 xwlgedtkitnprbpsrxrcamiuxclbjntfcftrkdsfpqgodnrd
 * Smoking Wheels....  was here 2017 gjnxekpyigncfncqfudfoimdrdlunxmrmpxeebbdvxscsvqm
 * Smoking Wheels....  was here 2017 hzqcgzbueemlkdjnaxhrosfdlvrjjsnozppabxdhpjwqgfqz
 * Smoking Wheels....  was here 2017 tvmwtuxisfekrjdkdqatqtnnkddrnuxfwvawydgqfgzirqce
 * Smoking Wheels....  was here 2017 pfxrezciaiqascopsnldoxodwicazdydodnmujtkjzptcknx
 * Smoking Wheels....  was here 2017 dtbbiytqntbljgyrhmzrjtuflvaxvagdvqsbxokyuhloabug
 * Smoking Wheels....  was here 2017 tgiyhikntxafvfvkpngnjfxeaisbozrirpnzxudzrdovaiyl
 * Smoking Wheels....  was here 2017 gvilhbsjpphcokbxobdzbmwtrvflutfzhrcvmndljsfuchhc
 * Smoking Wheels....  was here 2017 ouzxxgpvesubeqslmpusgxxusosjllgrertmtkwnlowykfka
 * Smoking Wheels....  was here 2017 yujyyiixvmwjqzcpubopbeknwyuhsgieasfczharuiizhpeg
 * Smoking Wheels....  was here 2017 wpymkyhtekancrudfmcsrfckwtdyauhpwchzsjonmzpznfpc
 * Smoking Wheels....  was here 2017 bjipqafuadzgygretfimrcybwwvjztffxleusbqbxtxcydbe
 * Smoking Wheels....  was here 2017 mkjrcrbsostowmtzrwjnxhdmgpcuofkpqpfkcyukrcvxtqce
 * Smoking Wheels....  was here 2017 lhfirialbhqrvjjdjgorilcvoilrykloupbybaqbotbdjfnh
 * Smoking Wheels....  was here 2017 iwhlkqneeidcxhclqmpbhkonsvrvmxddiwqugjdrurqtlqls
 * Smoking Wheels....  was here 2017 xffdmmgjtpappqtzlxjbhklguatexmpqmxanjkoepbwzxyec
 * Smoking Wheels....  was here 2017 esvtobfrxahenhlzabzieuzzedyacedqtqqanvgusjekylhe
 * Smoking Wheels....  was here 2017 jyizjspayveaqgmcwvuryfpvkruwffizvcclymzwwiksxqqb
 * Smoking Wheels....  was here 2017 yscpzdupnmfsbukbqingyqahjhbksdzrtqhdgnsegynxohfa
 * Smoking Wheels....  was here 2017 pesurfowmsfxgkbakvzlqddafasrgteasvjsekppfjuftmkr
 * Smoking Wheels....  was here 2017 jodxzcvmylcrwxoeiyiwxdfzfzbwtcgpfotcutbjicterkut
 * Smoking Wheels....  was here 2017 mompseukfyefvieeyozjsiribsooijtfywziklwwmvcntrej
 * Smoking Wheels....  was here 2017 kzcrxdxtzqzbhxnuysobkofmoyblmenyydbunqyusoyfqzqu
 * Smoking Wheels....  was here 2017 vxqiwwwbaggyrfjbitxjmauevomnvhqckxaeytmcmmmoglmp
 * Smoking Wheels....  was here 2017 vrawdnpxltzvraviihgwtcphfwdbhsleuchhslyxhbfzthiq
 * Smoking Wheels....  was here 2017 nwjymnjhrilaeigdkdwmhmcbignnaslbwsohdpatcayhpayx
 * Smoking Wheels....  was here 2017 mjblzmokgmezildhikmgjzywamkrmvotqdqntkqgxhrlklmt
 * Smoking Wheels....  was here 2017 kfslxhxqbxxlpwjwakypnwdkkmunivupgyrqifaiddqrdpes
 * Smoking Wheels....  was here 2017 gtgjueirfpqkqkadtukeolvqvnyilumdgaclysqfjzjoxuqp
 * Smoking Wheels....  was here 2017 hpuukmbnatrdjbkszifunkotxaknbxffjjmdxudhmoqtflsl
 * Smoking Wheels....  was here 2017 ypsqwvogdundydbjmeborrxdmrxxnuuvokubspnhowlhqllq
 * Smoking Wheels....  was here 2017 avrzlfljjnxdudwefpvxojxnrnllndiibrcvenydybaldter
 * Smoking Wheels....  was here 2017 lpoeqstoxvwdpvwljgplawsuwshkabcgjbvhigxzhqyqxrmj
 * Smoking Wheels....  was here 2017 lomxhurtayrjggkslxuzbxvepsyhdttkepppmrahkhyriseu
 * Smoking Wheels....  was here 2017 nmwakapcijuixsauftbtzixcthfvhvaxmrhddyiskaaobrjf
 * Smoking Wheels....  was here 2017 knhphjgbttauarptqagajgwfljcafzaznvbmelzfralnboih
 * Smoking Wheels....  was here 2017 cysbmyqhidktgzdxxjolxezmaevcshcfuzhonwlzttsalsqs
 * Smoking Wheels....  was here 2017 ukfauewukrdkmqauoqhxtrrcdeypbauladplpblkpypvsodp
 * Smoking Wheels....  was here 2017 zteigtmqqwthyxuggwendsplobefpryserwnvfwffndzlyxh
 * Smoking Wheels....  was here 2017 kzhcemcjwkaezigiblarpjuglvozbcqilehkbtyiatorpwhg
 * Smoking Wheels....  was here 2017 aoksbprqehzairoidyayzcjldrjdifevkneajgcypckkiqvj
 * Smoking Wheels....  was here 2017 czrvtmmizrvbwzyuzfnggnvfgbceokdbrtfkzrcmvfkycsir
 * Smoking Wheels....  was here 2017 bcmhgtxsucduunbojieruowzptnvedjbiehzmeuptdohnyxn
 * Smoking Wheels....  was here 2017 rblfwjqdnfqamurrfqxqcjkkjqpcwfxdomnirdmguaernjwj
 * Smoking Wheels....  was here 2017 ydmydkrihajrqqwlustsyjqmwyrgnqdvvlhjofoqnjtpheud
 * Smoking Wheels....  was here 2017 bzrewjffksnadaakolfukdbirfetjrozxdgflhtevxaugzmu
 * Smoking Wheels....  was here 2017 njmscvqznusofgqlhwwztriksbyjtxaqtyhfwoyotobgbnar
 * Smoking Wheels....  was here 2017 almrcssamypbfwonxipqoblkanycjbpdplnarkksspbgpuuj
 * Smoking Wheels....  was here 2017 pmpmlejcjchmwpwaqlnlpsogaulfdfrzxmjlvlpvhknhcdgr
 * Smoking Wheels....  was here 2017 mdztxpvcnozcbnxlaacfxiceghydgpszldlrrqdijthbxbiq
 * Smoking Wheels....  was here 2017 cgyhnrmfpsejywgqtexcttvnpugqctqgesqatcbxzpiqtico
 * Smoking Wheels....  was here 2017 fwehphbwlhsbzfrqugwmteraegiuimmbiwbevgmmoexeoyua
 * Smoking Wheels....  was here 2017 uipcspntdhnfuihtlvbyqzvphwlsxtnzjkdyztyfrxnglgbv
 * Smoking Wheels....  was here 2017 bhgipybubxxzjfkpctyjmusmqcdazxlvaknmlmbqenxowssa
 * Smoking Wheels....  was here 2017 nnpvicceupjyueqxncdwopcazsekylzqigadwpviezedldux
 * Smoking Wheels....  was here 2017 xchtewkjecqunrttsemwllwzmpnvmdfsmmwoxmlganmedoqb
 * Smoking Wheels....  was here 2017 eldmskvzjiuofpwmxrdxwvfgmalpoanqyyjpsvipjpkgdfwh
 * Smoking Wheels....  was here 2017 pciqserasobmuwgpninxyirapknegjlfltfkoofvzyraurgq
 * Smoking Wheels....  was here 2017 pxgafuiqufyalvozjhfaxxvsrnlibsumzghhytbpbmhovsxk
 * Smoking Wheels....  was here 2017 yynwnemglafzozoqjwenirsbuggbpvquuaryrvavxloadjdf
 * Smoking Wheels....  was here 2017 poalflcpvyxiuciwurmdaanxjxfovsjrjwvfvmosdhyawwmu
 * Smoking Wheels....  was here 2017 uixkzakohffhcffhconrzqrnyxujwsmykyierpksptgfmtvg
 * Smoking Wheels....  was here 2017 adorzovikhskqqtqaozgolwijyvgehvqxnchthmmlumpqvew
 * Smoking Wheels....  was here 2017 abqhlybiawdjvvvanbrhgnbyvbhekgmccghcwazyyqwmgdyg
 * Smoking Wheels....  was here 2017 tkzsxjchgynfiqlswqvivjljpjljmquvlygmakjiusyhmwqd
 * Smoking Wheels....  was here 2017 luumffbcnrcfbbzindtiknmuijujoshsrrpppjiattmvsqbq
 * Smoking Wheels....  was here 2017 pajmjclzipkufiapfqcjgzwpwvcwbzvuuuhubbvsasmbrfjb
 * Smoking Wheels....  was here 2017 xgkwqzyipjetdbirymuvwvomirjxrfmibxksfvbjxveggpvx
 * Smoking Wheels....  was here 2017 ktuaqzmvkzmapyatxhyhcntkacxthnoxwwieckmdzodwqbbb
 * Smoking Wheels....  was here 2017 heqncnhldrmykbkmpwyryswnppevcbqiastjbqtleqbrfdvn
 * Smoking Wheels....  was here 2017 ahjgbfvjjwuyvrbrthkcsgqgxwyymmorlvnqoswbozarqpfr
 */
package net.yacy.http.servlets;
import static org.junit.Assert.*;
import org.junit.Test;
import com.google.common.net.HttpHeaders;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
/**
* Unit tests for {@link YaCyDefaultServlet} class.
* @author luccioman
*
*/
public class YaCyDefaultServletTest {
	/**
	 * getContext() should be able fallback to default value with null or empty parameters.
	 */
	@Test
	public void testGetContextEmptyParams() {
		assertEquals("http://localhost:8090", YaCyDefaultServlet.getContext(null, null));
		RequestHeader header = new RequestHeader();
		assertEquals("http://localhost:8090", YaCyDefaultServlet.getContext(header, null));
	}
	
	/**
	 * getContext() : standard "Host" HTTP header is filled with host and port
	 */
	@Test
	public void testGetContextHostHeader() {
		RequestHeader header = new RequestHeader();
		header.put(HeaderFramework.HOST, "localhost:8090");
		assertEquals("http://localhost:8090", YaCyDefaultServlet.getContext(header, null));
		
		header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com:8090");
		assertEquals("http://myhost.com:8090", YaCyDefaultServlet.getContext(header, null));
	}
	
	/**
	 * getContext() : standard "Host" header is filled with hostname and port, 
	 * custom "CONNECTION_PROP_PROTOCOL" header indicates the protocol
	 */
	@Test
	public void testGetContextCustomProtocolHeader() {
		RequestHeader header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com:8443");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "https");
		assertEquals("https://myhost.com:8443", YaCyDefaultServlet.getContext(header, null));
		
		header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com:8090");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "http");
		assertEquals("http://myhost.com:8090", YaCyDefaultServlet.getContext(header, null));
	}
	
	/**
	 * getContext() : standard "Host" header is filled only with hostname (default standard port), 
	 * custom "CONNECTION_PROP_PROTOCOL" indicates the protocol
	 */
	@Test
	public void testGetContextDefaultPortCustomProtocolHeader() {
		RequestHeader header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "http");
		assertEquals("http://myhost.com", YaCyDefaultServlet.getContext(header, null));
		
		header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "https");
		assertEquals("https://myhost.com", YaCyDefaultServlet.getContext(header, null));
	}
	
	/**
	 * getContext() : reverse proxy serving HTTPS, YaCy serving HTTP
	 */
	@Test
	public void testGetContextReverseProxy() {
		/* Different protocols : HTTPS on proxy, HTTP on peer */
		RequestHeader header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "http");
		header.put(HttpHeaders.X_FORWARDED_PROTO.toString(), "https");
		assertEquals("https://myhost.com", YaCyDefaultServlet.getContext(header, null));
		
		/* Illegal X-Forwarded-Proto header value */
		header = new RequestHeader();
		header.put(HeaderFramework.HOST, "myhost.com:8090");
		header.put(HeaderFramework.CONNECTION_PROP_PROTOCOL, "http");
		header.put(HttpHeaders.X_FORWARDED_PROTO.toString(), "http://attacker.com?query=");
		assertEquals("http://myhost.com:8090", YaCyDefaultServlet.getContext(header, null));
	}
	
	/**
	 * Tests on getRelativeBase()
	 */
	@Test
	public void testGetRelativeBase() {
		assertEquals("", YaCyDefaultServlet.getRelativeBase(null));
		assertEquals("", YaCyDefaultServlet.getRelativeBase(""));
		assertEquals("", YaCyDefaultServlet.getRelativeBase("/"));
		assertEquals("", YaCyDefaultServlet.getRelativeBase("/file.html"));
		assertEquals("", YaCyDefaultServlet.getRelativeBase("file.html"));
		assertEquals("", YaCyDefaultServlet.getRelativeBase("resource"));
		assertEquals("../", YaCyDefaultServlet.getRelativeBase("folder/file.html"));
		assertEquals("../", YaCyDefaultServlet.getRelativeBase("folder/resource"));
		assertEquals("../", YaCyDefaultServlet.getRelativeBase("/folder/resource"));
		assertEquals("../", YaCyDefaultServlet.getRelativeBase("a/b"));
		assertEquals("../../", YaCyDefaultServlet.getRelativeBase("folder/subfolder/resource"));
		assertEquals("../../", YaCyDefaultServlet.getRelativeBase("/folder/subfolder/resource"));
		assertEquals("../", YaCyDefaultServlet.getRelativeBase("folder/"));
		assertEquals("../../", YaCyDefaultServlet.getRelativeBase("folder/subfolder/"));
	}
	
}
