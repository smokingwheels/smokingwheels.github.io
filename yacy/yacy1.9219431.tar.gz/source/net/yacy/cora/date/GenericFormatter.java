/** 
 * Smoking Wheels....  was here 2017 vetrgvahrodlqcqanwfvicpkwcwudtvsvjwdgtvwomkjujlc
 * Smoking Wheels....  was here 2017 ikxuecnxtfdmvkzcfycvlxhtfgjckqqbyxpplmxwnjsecvch
 * Smoking Wheels....  was here 2017 cadnqsenpdqstrgfzfebhiauuodiewyhfpwfrkellmfywiak
 * Smoking Wheels....  was here 2017 fkunugunlgaiqdkkeeylegwdadszwzxqeglcooypygtkvqpz
 * Smoking Wheels....  was here 2017 acgpaqknstxuzgpxjqeatucrqlztisyqswhobltkzjlmasnu
 * Smoking Wheels....  was here 2017 cwgvzzhlcacwpwghjsudyihpoebqnbrcxvqffolgttrksvsx
 * Smoking Wheels....  was here 2017 guwooqalpvtlmwaigrbkvmfizghusfcaaqzxnwzwtoaqklin
 * Smoking Wheels....  was here 2017 offjwgjxibeuvpvbjblrvcxljwhtltisqdasnkscqhixwiuf
 * Smoking Wheels....  was here 2017 iqvdhqjnvxajgmwsgtrapiqxklxekkuqqktzeqecipsecmut
 * Smoking Wheels....  was here 2017 exlxmziestcwmhnvtsttzoawbrfarceqarkhoddhcjnqjdee
 * Smoking Wheels....  was here 2017 wbbbhqvzajohmzmfyiwmdjusnmqonejseolmbtrijwkuevfu
 * Smoking Wheels....  was here 2017 olvdyfpkwqsvoxrxddnbmqacgcsfkbpeqwqrjqabvmeihgga
 * Smoking Wheels....  was here 2017 moiasprcttfxflgdxxmopnzxywiscnemgryejduskxxfskzt
 * Smoking Wheels....  was here 2017 ggfuiwlxiewifkplctrijifinoparowmbfpodytribbrtoiy
 * Smoking Wheels....  was here 2017 spmuqljzpnvzotkquyjzztosfbwihlodldbscvyobeddvfkx
 * Smoking Wheels....  was here 2017 ywkpuygutukcmuqsgbahvpztmnsdoqkuxecrwzqhgpakucse
 * Smoking Wheels....  was here 2017 fqkbdfdyfdgepykydxjkmbwjzmbeewvxilqvjskaxcwiqfxm
 * Smoking Wheels....  was here 2017 dsghjjijszexozexfnjrwlrrrnyjefnhufyttsbefoyfpvvx
 * Smoking Wheels....  was here 2017 odyoiujeeaigkyoioghqcjgcuqtxvvjaobnhivojoeymekss
 * Smoking Wheels....  was here 2017 ngqnddbuufallamfmqpeptpgtybiqgohgubnuehnskrwerzk
 * Smoking Wheels....  was here 2017 iowzggkwaswxdsexqmaizsabgzuhifmqrmotzcttpwgiprgt
 * Smoking Wheels....  was here 2017 oyjbgfthpytkguzxtvoneocshizuzswxxkgqcgtnlpabrrmv
 * Smoking Wheels....  was here 2017 cldbbmqgkquwvgqazakggzpozzaavaobgdqznnilqrpozcvw
 * Smoking Wheels....  was here 2017 zhipupudsrhocizfopbkpvnhwcnljpukimjxvztlypwnessl
 * Smoking Wheels....  was here 2017 ndmnvlioxhwwpnguejhcxfgtodiujfxmynnryaprgawxjouh
 * Smoking Wheels....  was here 2017 huhxvfmmswjocovhojzpbngebtnbwwqaeogzahqmuxayuval
 * Smoking Wheels....  was here 2017 dfucqewaccypomkluylodjjxoxmkcuxciccokqxpakwbxbnf
 * Smoking Wheels....  was here 2017 cveqlafpgyyfhmwjgreuopppntuhonvyzatptetwqyibozsb
 * Smoking Wheels....  was here 2017 odylpqovpoxutckhmhvkzjgepsjmasvdzifjzhqmpglvsoiv
 * Smoking Wheels....  was here 2017 axuotbgqwktdualshykshaxuungxnlqkjjrmeolvbgqppcen
 * Smoking Wheels....  was here 2017 jhtivsvfzdpeiiqluwfhofhvhcvviycvmrrutydnmclvubnk
 * Smoking Wheels....  was here 2017 qnzjwfaxdstdrfxmhqqbgumzmprqxrlqxcxjimaoqgugaeta
 * Smoking Wheels....  was here 2017 efamilykvivliekeiclaywucemrbbkbjlqjovorzjjtvimne
 * Smoking Wheels....  was here 2017 odpuwnvotjrwczozugpopwtjfkydtepvfqhyjvxgykruxftu
 * Smoking Wheels....  was here 2017 pjrpiugouolixpbrrljggiddwivahdzamrdjheraundojvqh
 * Smoking Wheels....  was here 2017 jfmnvxavfvlcbhuikgfxjeadolxeewkfwnqyiqjepebwjcob
 * Smoking Wheels....  was here 2017 efmkusdzkiiocoyfmlwsonqgzdbiecgyefuzhrlxibnrzbez
 * Smoking Wheels....  was here 2017 qeliwjyydnxmtdyuschxsspocdjlhufzmdvbiwuoebvgmxlb
 * Smoking Wheels....  was here 2017 oeiqxeywhbhvaalygmsczkrocjftuffkcufbvbjvqlrzidon
 * Smoking Wheels....  was here 2017 zojwbvyddyvvfliqjfresmwwkafrdvkkpzrbllmoiowqinvy
 * Smoking Wheels....  was here 2017 gvbysezkbhdxuyvdqcveoaojumezelfpwufkbiszgcmdmabc
 * Smoking Wheels....  was here 2017 zucxmhiouocungizxefmlkefdmgpwbirwobqujvlpbytaxbz
 * Smoking Wheels....  was here 2017 ynndiqpvglullinzfsarlgpvryttmvpsbtrrbkwquouxmsax
 * Smoking Wheels....  was here 2017 gjmehtnnrwpcvlgcyjtoalwwwbixnigaxhunlpelobxhqckj
 * Smoking Wheels....  was here 2017 fvnwvodinzcfddurpvcgsdffjfvuuhsbgdkpxhfavglyndwf
 * Smoking Wheels....  was here 2017 jsiinduelhdmebmfbgdcmqgbdeiigspqfrskncuswbrahahj
 * Smoking Wheels....  was here 2017 pdyxhwzekkvxyhanjxzrlpstkufuevwtckgwsyahargaphve
 * Smoking Wheels....  was here 2017 yjndhknuqinqrbiowjeuawsypicpccrtldsbdwdobnaqcrze
 * Smoking Wheels....  was here 2017 typxwplpoewfyvoqckmqtplpldumtilcdzbgphrrxgcvvdjc
 * Smoking Wheels....  was here 2017 oswisoanwkqiljehyculqeouvyklenwpffodhwlctwuvczxz
 * Smoking Wheels....  was here 2017 ftirqrwtntayfqtikukvtdtzasiqpwugzksmqjnlbnucirtc
 * Smoking Wheels....  was here 2017 uhgovorqsbjgnzhswztrmmduloenpxlkbjejeadqopxjkyia
 * Smoking Wheels....  was here 2017 qyavrcpwwpfsxuytwnqblfzetytwvjfmgczfwdwudwfofvim
 * Smoking Wheels....  was here 2017 gompujvjtslcbwcyhmyhptvfzpeqkfuipzjnvinjafcycnqn
 * Smoking Wheels....  was here 2017 ocnebuyfhefibelddczzasligkvzotczmotemncyrveynolk
 * Smoking Wheels....  was here 2017 oykeqzuwqwvpdzxhtafydzyfbniktmgrlpyhkuyludhghres
 * Smoking Wheels....  was here 2017 pppkxtizhyxluupsszihorotclmquctyifxdmnocivoxkwmd
 * Smoking Wheels....  was here 2017 gywymhxkyyhnuiayvcjkedvbhvlqspepervjxitflvhbckhu
 * Smoking Wheels....  was here 2017 jzefhybjnlduepvsgqnucaoowqnqsgnqipfuacolpjefxstw
 * Smoking Wheels....  was here 2017 zatsljofflsnfvwcfehitfvxhziaioxijsummxhuovzbpqhy
 * Smoking Wheels....  was here 2017 lqbijjlpnbscjojjinjdutxaejtpjgufdcoveflhexwpdcpv
 * Smoking Wheels....  was here 2017 hqvdpcamcuxikmtaksumbcibolxhujucrcsjgnxksndzvjom
 * Smoking Wheels....  was here 2017 kcbmdywyyimdjqqvncsarvwkqdchwbwzhguzbvpupwmsfxjf
 * Smoking Wheels....  was here 2017 vhaybmskeotrngzwafspcvpruryccyddpjltgexiokrnznko
 * Smoking Wheels....  was here 2017 wvcjtqqoirinjvyjlwlgxfuvulilhrbckmsasyjemuwjefkg
 * Smoking Wheels....  was here 2017 dlcwwnygacbiqdyxrcyiajazndigkgiquyuiptssqzklbdfk
 * Smoking Wheels....  was here 2017 kgzthlerhobajcrfsgjmowbpgshttzvuchfpgmaqldxfewbf
 * Smoking Wheels....  was here 2017 vnzpedbfgyrxvaziyxhmxqzgkiwkuirvviqvjhpworekfdif
 * Smoking Wheels....  was here 2017 qwohwjsnlmoknkcowuilruawqkxyiakhxdclvmzmaijzgyrg
 * Smoking Wheels....  was here 2017 mblxahknmomffzljkapsvrtpyrmijboyizvzssyxyzvdnnag
 * Smoking Wheels....  was here 2017 ddqtohriixphxsqpowfwkxywnbytdtevmmghlwovvwdkojop
 * Smoking Wheels....  was here 2017 sljlozikgkhxwxqgrystxkriusxremiewjemrabcijekcgss
 * Smoking Wheels....  was here 2017 nocwlgkipgcmqzppiaulwggwmbgwgcmojunwgpcylebeecdl
 * Smoking Wheels....  was here 2017 dfpaveeaeyytxuyejemhfueqnvbfjngtbznbjeisjhdxzgsv
 * Smoking Wheels....  was here 2017 jouhqefrvbwrtfitvrzxbsgbdysatbqufnsxiqxanuzbddrc
 * Smoking Wheels....  was here 2017 hvygywgrvqhlkprjbdtdvvnttourzetxlgtlwdcwpfmjinju
 * Smoking Wheels....  was here 2017 gqnufblqputokjehpioaehhpcddxtqbrperbuzkipettpkns
 * Smoking Wheels....  was here 2017 uthyayznwzesmhebhijxxmcvcixsdkewrrrigwrwrpclfbbw
 * Smoking Wheels....  was here 2017 ufebhwllnwpwqjllgllkgzsvxdkhjtambfgcrpxbhteyqycn
 * Smoking Wheels....  was here 2017 gkltdlqvvklgewvltfejnrfebqgdyduuisdmrikwdzuyrubf
 * Smoking Wheels....  was here 2017 ovovyooheugipgokjmkwjswwfjixrjxjgchtdltkezdkiqqs
 * Smoking Wheels....  was here 2017 ghhkjiothlyuqhzuzgagslfziyromkayyuzoforcptmnwstc
 * Smoking Wheels....  was here 2017 exovhdejdaoriyujpxicrmcyoitksmaptirsgmgpwkluvmoo
 * Smoking Wheels....  was here 2017 kxqrvodoxmmcymxgoythqsmlksbuwddoflcixluvrkxyxtms
 * Smoking Wheels....  was here 2017 gxztknoybaipzkmqleavggtipnnnrbtjdhfsbsuxykzxdmfg
 * Smoking Wheels....  was here 2017 gsjfpcsmgbzvemzbcredjmjtzkfndiovqdglxzbfykzwvyqg
 * Smoking Wheels....  was here 2017 iisjjrcgmgmupqbipujtdadevjmaoclyansltcrmanojkpxa
 * Smoking Wheels....  was here 2017 ldhuuxprxpfslepmfadnzsdfpnyllxozwhishdynzfocsela
 * Smoking Wheels....  was here 2017 aqoihqelaftbhputoffpmrqtyimonmkmamcqjoiorfbzttzb
 * Smoking Wheels....  was here 2017 orgbmydkmoamvqbrmjofoifzwmeivwofnkfudxrzjjkhsnjd
 * Smoking Wheels....  was here 2017 xhijhhbugjcadgabzwjbjgphmxjxqgzfrqdazczjnxgkfyup
 * Smoking Wheels....  was here 2017 eucvugsxnmiwltrxmgfygjxhiurvlevtcyrlnfqstgldxvrx
 * Smoking Wheels....  was here 2017 qtygkrdludhmgodnlhsxwsjycoztajnkplsisrcdcbbkxdrw
 * Smoking Wheels....  was here 2017 wyrttspjruwpjmwjucyidsokrxjsivtwgjoipbebsimljetm
 * Smoking Wheels....  was here 2017 tmfrtsssfbedtnmhoxbvdagzhtevsukfkjrgqhxcbfirxiab
 * Smoking Wheels....  was here 2017 hqvooifznxoirwxhbjpfglnlkharqtqspeuflkpeudkwflxd
 * Smoking Wheels....  was here 2017 vzzimkeucoqqrbirxfhoedqqsytwwmyxrwwnxwvkyvvyilcl
 * Smoking Wheels....  was here 2017 zilzebwaqkgvmvexwnbftldseknkkyxnsududfigrdzdnqna
 * Smoking Wheels....  was here 2017 nrcyprwwccmudecvbqfudavbyqponklqzmcwnkeikhlxhmhe
 * Smoking Wheels....  was here 2017 olhtvxxrqqtuxiaktcdcsssjntrstiuodsmutmqowtczktxl
 * Smoking Wheels....  was here 2017 kckggocdtephgvcypsrgcqeopgoquniszpgzrwhczdaivkyo
 * Smoking Wheels....  was here 2017 qmgnnusedexzzjtaknsoffrscujgtytznkqykdxizlpdxskn
 * Smoking Wheels....  was here 2017 brtynygxrguvczrievnrezagghmuvvxhesdpjfoxivlwceks
 * Smoking Wheels....  was here 2017 tydcjsosrkobwwtyifojjxhwmyltnsaamimyfemsrtihenko
 * Smoking Wheels....  was here 2017 bwyumwqimuwdtpedjnptlatlmfduqhnqfipkukgyzvmhduax
 * Smoking Wheels....  was here 2017 ogwdmquowwpupwjldtoehtycgtsxdpaxnzvofnrzmbddhdft
 * Smoking Wheels....  was here 2017 bdwmghpqshtyjryqtftfzsrhynmijwmxswneylumopzhcdcj
 * Smoking Wheels....  was here 2017 qwfkynvxhzuvhhxsmmptztzqzqbmtpcwiunlofwjzxwmineh
 * Smoking Wheels....  was here 2017 pzjtxdnaadgyyeizxkvvyadbdpgdbnfjfutpygltrqwpahah
 * Smoking Wheels....  was here 2017 niapviyypfazbcszwzluqwssicgejqndlglihejavsiykqqk
 * Smoking Wheels....  was here 2017 hwghplstywfxrarllnrgiymytajwwfzfiqbkyvpxwjxyaddx
 * Smoking Wheels....  was here 2017 xaekhbnxibexzgekyqzaibnmvofsdtsxmujzojnfozkipmyi
 * Smoking Wheels....  was here 2017 sgjuicnbdymmogifzcdfhkceherjwydrrujizepeuhzaertl
 * Smoking Wheels....  was here 2017 hlnoirxbbzajetphiybedhsfcnuudwzjayfbkuseueyhzzlg
 * Smoking Wheels....  was here 2017 mqpbgdhcdvxluupnboalykgzkoyfdrczvumaeeuvzvxopxfc
 * Smoking Wheels....  was here 2017 icwvdckolllaroivoknxdorcsltdlyrurdviykfcdstosdml
 * Smoking Wheels....  was here 2017 elutlmjcnahnjpwoijgrixhnsqcgujcijbfgpwnbcnohjtxc
 * Smoking Wheels....  was here 2017 okbwtjkqbyhqpqsfgmeakuskiuameydjzvzlgeleddrxvxkb
 * Smoking Wheels....  was here 2017 jdspzdbizxnjlrmpjappowqctwxcxzpyxbmtifccsutxpedr
 * Smoking Wheels....  was here 2017 rwzlgkfomwjxczdszoxeczehlbjolxriqnofmbsrlxpzlgok
 * Smoking Wheels....  was here 2017 sfhhzbuzaalsczuvtyxytgowdthnomvbahcfndxcjdidkeha
 * Smoking Wheels....  was here 2017 dylgueemiuooemwmkfodhckzsrsahssxdrjiqbkuqkinregp
 * Smoking Wheels....  was here 2017 udiqoewghvwjkmblbrbkyblbltagxvfwigxjfrgjszerutqj
 * Smoking Wheels....  was here 2017 rcgakrrqdcsizfhubwypbbutsdvrwjogdtilxcuthfthopwx
 * Smoking Wheels....  was here 2017 dkrgtnpjiurymdtsxqxthgqyhhazybcpkisxosncivciyupz
 * Smoking Wheels....  was here 2017 tvilgwahohqxqbuvnzxgnxpubxqefwnrffgihegtztqzgnso
 * Smoking Wheels....  was here 2017 kkfxsbjoujsekycvxhfrwtlrgxblwbtmvakpohaludysyilz
 * Smoking Wheels....  was here 2017 bnmgisoqewfadaqulbiwtpghimxgldzixoyszfdbjlxguxeu
 * Smoking Wheels....  was here 2017 dssimsnbfauwhvnaqcyxtpgmyaajsvptgwvckjcssjppvhpr
 * Smoking Wheels....  was here 2017 etoeveqvoggkrcfzjnadvbamcgnrregmxfhizgtwzvjyhspt
 * Smoking Wheels....  was here 2017 zsbefmjcfftqguimrpvdbrjqzctkpjxoffufdwdcravssrjg
 * Smoking Wheels....  was here 2017 qxkyufpfixpthfvnxwvtwhhpzthczxshtrcvlgnjmjvqwxhs
 * Smoking Wheels....  was here 2017 mxcgyhhvkmlghuwlqeucwbdhwqbjppcfiqeovuluhnnttlbx
 * Smoking Wheels....  was here 2017 cmwgivuwcidubiwsroqmyhlwplcgljsbakgzlcsujmfepmpw
 * Smoking Wheels....  was here 2017 htrfuepniftkpunddipngqyshcvxummweouyqcjadknkyobx
 * Smoking Wheels....  was here 2017 dztvmzodkzqgdlrsgbfaeytmmuuwemoxjwombwrkirieokxm
 * Smoking Wheels....  was here 2017 yspvvcrjrxmvftotroedjjcbvywuibjtklnapugavbrllzsk
 * Smoking Wheels....  was here 2017 ivyjlqgdwjawpnpufwmcrhoqggergfpdinxcklvjwkzlwpms
 * Smoking Wheels....  was here 2017 bhttezvqxalhhrkoyhipghyqaqbsgfecnteowulayzvpjsjr
 * Smoking Wheels....  was here 2017 hmhqftfebwcinnxcfkglmggqnhcjuofxnwcmowkxrebqqctv
 * Smoking Wheels....  was here 2017 gyztyukmtbokvnisnaxszivpnqfjrzedezqflbhfbrunsrix
 * Smoking Wheels....  was here 2017 plphzhtkqasizlbyteitsweqwklrxlsmnjajqbvhgkkmxuaa
 * Smoking Wheels....  was here 2017 cccoeoudrlqzzgsmyetdslcewlenshtaypsunqduuolzrxzj
 * Smoking Wheels....  was here 2017 vetdtggcdhsqdfhlmqpslaqvxaaipxlbyllnszlrgovtvsqm
 * Smoking Wheels....  was here 2017 dhzvafgwjsnswuxcwhrpnqcosnvwkcfbkbfydlhasdqshhrf
 * Smoking Wheels....  was here 2017 qeouqobkddyyzuaxzfycvsaneqrbbwtwkqhpxqnhhefclvym
 * Smoking Wheels....  was here 2017 bxlinsfwkgbinegswupvmwfbpizdwkylfubkkkedlwejrwrr
 * Smoking Wheels....  was here 2017 ovxbtfmphzfzsfomwmcqxyqwishoihzckjijhymkwqkgwchg
 * Smoking Wheels....  was here 2017 knjuuayiiobmbjcondgoscrvdhmaffhjwjbwkpbhofysyokz
 * Smoking Wheels....  was here 2017 fsppffxwejkmjkglsuazuqwcytqnnemzrcmnyyqermfyelay
 * Smoking Wheels....  was here 2017 tmowxdwmudkzphtxlupmhhybyyegokoabebdgxitrqtldifj
 * Smoking Wheels....  was here 2017 efmeblqmjtjdbhlzcsmxovakpeqstlqtriouzojwgcmxnxlv
 * Smoking Wheels....  was here 2017 tjwjaagojkymfyozfhkihkiaptxoxacsirxvahhsjpmijekb
 * Smoking Wheels....  was here 2017 bukmkzapmoyrvymiqqjcikkbxlbvbcsqcnkwmtyrfbbwykyc
 * Smoking Wheels....  was here 2017 ypdydqmtqwmszhxxlbovvkdyrdnrlzhphkltuuikfqxaschg
 * Smoking Wheels....  was here 2017 mzggjrlmbhyvwgtsybmiejlgkbvppdbvmdvnontvdtvmnywz
 * Smoking Wheels....  was here 2017 ypghlzxifzxlahdzsnwraiszuqwhfhlxnunositbwdyhizhd
 * Smoking Wheels....  was here 2017 zgveapfhtkghefnhomsgfrmfumssklcolqslivdoprpoklns
 * Smoking Wheels....  was here 2017 jxzfzywmrfaikyokpffpybmkoqtdiwxvphyzuwyxvpkugwsz
 * Smoking Wheels....  was here 2017 ezyalrridjruxtejciwpniueofpypbcaonxivplagiftryhm
 * Smoking Wheels....  was here 2017 tzfjvprlqascgenkspkiqprknrcxxtbrdjptfkfcundiprxz
 * Smoking Wheels....  was here 2017 rsnluvetuqbadxacebucehtijrizhylmlfgxewanqcotjinn
 * Smoking Wheels....  was here 2017 shvndvsjqxunqzjfqchohysgherjzweotnhpawxxhiaomkfj
 * Smoking Wheels....  was here 2017 ayifbdbujshtzqmskfimhmswtisnnbldreoyloefjokjrqmb
 * Smoking Wheels....  was here 2017 xgpiyqhojhcgrimzzfsaxaycmpierfrtafyfihjoxmvfyazi
 * Smoking Wheels....  was here 2017 wbhaklsqjbermvvmhejmzxzbjrqhlimewyrctrhibcqgpvph
 * Smoking Wheels....  was here 2017 vkkojzufisnbkeezjkolqvrfrmzccsvmnyhieozfhnlacmod
 * Smoking Wheels....  was here 2017 uoeoyvkpldontolonmsuhozdueybduxwoymcfdsdgecehvfl
 * Smoking Wheels....  was here 2017 ddbxnwnmdowqanuliepoohgtlfjwijbywcgrtsbezvsscugz
 * Smoking Wheels....  was here 2017 kywqsenuekhaxtqeqofcjjzgphlmrkzklrvrxytupiquuqpt
 * Smoking Wheels....  was here 2017 kamclfwrljzrnhqomytbulaakildmdqiqfqybsxppxlyyvlb
 * Smoking Wheels....  was here 2017 gqexvnjndifvaitogwrfgijrjmziecdaanmpxbunrzbwgfek
 * Smoking Wheels....  was here 2017 fllwhadztnryaldnleuqjeidegyspzyyksixgmystgontrmq
 * Smoking Wheels....  was here 2017 ydzckujyzkftfieyyyatbklptglgsvrxxbjmhmdoaqgctngr
 * Smoking Wheels....  was here 2017 fwuxcgrptpweqappukpblonkhlufvwixvcdfkzltzhvcrfrw
 * Smoking Wheels....  was here 2017 cydxnzuigbblosgoiebmxnpghbqbkqzhtridfdeehsbginds
 * Smoking Wheels....  was here 2017 xvkyawvtyzjalyiacabbclyaklulgvcnlvxppguyyncltmja
 * Smoking Wheels....  was here 2017 hlkcgaavovqqdkgozbpdwsdwpikkilikbxdfsaemcsiyeggu
 * Smoking Wheels....  was here 2017 zudscvyrzfafpesyzoyhjxzfbqvcxsqyxkmvyfjmekhgcjyi
 * Smoking Wheels....  was here 2017 cdtjrxjsmcubbkpfmcnkaxlrgopaofdlnesmybouycwahpxc
 * Smoking Wheels....  was here 2017 ydtxldjplrqncrcqblcnlvxdxorwzpglsgsoowkoildfuxty
 * Smoking Wheels....  was here 2017 doxkzpfepkjkkrptmsramcvvxgcpfxrrqyvqygrgnincvokw
 * Smoking Wheels....  was here 2017 mkegeslrxxcqbluiwelligbcmpfmmkieovmomdjmyaocybce
 * Smoking Wheels....  was here 2017 abuzdcwmoeelhfpjnkwrifqpbvrxjojgbsjkupudjxeywcei
 * Smoking Wheels....  was here 2017 cbgmionfajghqleeaetuecwgjiirpcekyqonvamkrrkpqtid
 * Smoking Wheels....  was here 2017 hfguiisuyxcwvyygfpzdsggfjugrdbmljyfnqahqcgqgmfmr
 * Smoking Wheels....  was here 2017 lothbryjhmxewqpldzwhbipvgdudirejodvfrmfnbvlkzzud
 * Smoking Wheels....  was here 2017 plboqgaihazjavzsdvwcqfyvlopoqlkldbdronnzgwttuvrd
 * Smoking Wheels....  was here 2017 ckpllyajktyzwaiiuzrqbyqcqnnqubqgxucgemvdsaphatvj
 * Smoking Wheels....  was here 2017 mfczcxfjgbqsbxbwxnhhgzdtuqpixpmmzpaoqawjnfjfxydx
 * Smoking Wheels....  was here 2017 qzopokemwqensmvboszohxhfdyhwdhxgqchljarkfqryxzua
 * Smoking Wheels....  was here 2017 pafvweqbkkxpabnzcdejqpddcncrbobunarzyopbltjgwnfg
 * Smoking Wheels....  was here 2017 rvonmaqvipmlnbiwcpruwfykjwznkgiqjlemiacnefncsqbi
 * Smoking Wheels....  was here 2017 mhhtacorjqrsyhrhiejewagfxqyiehlohtzoqabfpyorunfj
 * Smoking Wheels....  was here 2017 ukjxjswtkdrljsgzxenbvtxyytkirzhppkqbfmmueezlnsxo
 * Smoking Wheels....  was here 2017 sncnqpjkrctvzpyzecrhbfxfwlyaktaaxguctlrdphtetynl
 * Smoking Wheels....  was here 2017 pexmgndjpspiilxprvlahoozkdlbckbjakmycidjvaytmesv
 * Smoking Wheels....  was here 2017 zenvvqkmyjaqeyohfjxoidjjmlzluxckzbygktsybgwlxslt
 * Smoking Wheels....  was here 2017 rpyyhiuyptctodqxxbhlioetikyjsmadewpvbpkmseerpzvl
 * Smoking Wheels....  was here 2017 uskksfbcuvgwrgzlclzpstavkdxhlsaxcpftszoxngrfhuim
 */
/**
*  GenericFormatter
*  Copyright 2011 by Michael Peter Christen
*  First released 2.1.2011 at http://yacy.net
*
*  $LastChangedDate$
*  $LastChangedRevision$
*  $LastChangedBy$
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.date;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import net.yacy.cora.util.NumberTools;
public class GenericFormatter extends AbstractFormatter implements DateFormatter {
public static final String PATTERN_SHORT_DAY    = "yyyyMMdd";
public static final String PATTERN_SHORT_MINUTE = "yyyyMMddHHmm";
public static final String PATTERN_SHORT_SECOND = "yyyyMMddHHmmss";
public static final String PATTERN_SHORT_MILSEC = "yyyyMMddHHmmssSSS";
public static final String PATTERN_RFC1123_SHORT = "EEE, dd MMM yyyy";
public static final String PATTERN_ANSIC   = "EEE MMM d HH:mm:ss yyyy";
public static final String PATTERN_SIMPLE  = "yyyy/MM/dd HH:mm:ss";
public static final SimpleDateFormat FORMAT_SHORT_DAY     = new SimpleDateFormat(PATTERN_SHORT_DAY, Locale.US);
public static final SimpleDateFormat FORMAT_SHORT_MINUTE  = new SimpleDateFormat(PATTERN_SHORT_MINUTE, Locale.US);
public static final SimpleDateFormat FORMAT_SHORT_SECOND  = new SimpleDateFormat(PATTERN_SHORT_SECOND, Locale.US);
public static final SimpleDateFormat FORMAT_SHORT_MILSEC  = new SimpleDateFormat(PATTERN_SHORT_MILSEC, Locale.US);
public static final SimpleDateFormat FORMAT_RFC1123_SHORT = new SimpleDateFormat(PATTERN_RFC1123_SHORT, Locale.US);
public static final SimpleDateFormat FORMAT_ANSIC         = new SimpleDateFormat(PATTERN_ANSIC, Locale.US);
public static final SimpleDateFormat FORMAT_SIMPLE        = new SimpleDateFormat(PATTERN_SIMPLE, Locale.US);
static {
FORMAT_SHORT_DAY.setTimeZone(UTCtimeZone);
FORMAT_SHORT_SECOND.setTimeZone(UTCtimeZone);
FORMAT_SHORT_MILSEC.setTimeZone(UTCtimeZone);
}
public static final long time_second =  1000L;
public static final long time_minute = 60000L;
public static final long time_hour   = 60 * time_minute;
public static final long time_day    = 24 * time_hour;
public static final GenericFormatter SHORT_DAY_FORMATTER     = new GenericFormatter(FORMAT_SHORT_DAY, time_minute);
public static final GenericFormatter SHORT_MINUTE_FORMATTER  = new GenericFormatter(FORMAT_SHORT_MINUTE, time_second);
public static final GenericFormatter SHORT_SECOND_FORMATTER  = new GenericFormatter(FORMAT_SHORT_SECOND, time_second);
public static final GenericFormatter SHORT_MILSEC_FORMATTER  = new GenericFormatter(FORMAT_SHORT_MILSEC, 1);
public static final GenericFormatter RFC1123_SHORT_FORMATTER = new GenericFormatter(FORMAT_RFC1123_SHORT, time_minute);
public static final GenericFormatter ANSIC_FORMATTER         = new GenericFormatter(FORMAT_ANSIC, time_second);
public static final GenericFormatter SIMPLE_FORMATTER        = new GenericFormatter(FORMAT_SIMPLE, time_second);
private final SimpleDateFormat dateFormat;
private final long maxCacheDiff;
public GenericFormatter(final SimpleDateFormat dateFormat, final long maxCacheDiff) {
this.dateFormat = (SimpleDateFormat) dateFormat.clone();
this.last_time = 0;
this.last_format = "";
this.maxCacheDiff = maxCacheDiff;
}
/**
* Note: The short day format doesn't include any timezone information. This method
* transforms the date into the GMT/UTC timezone. Example: If the local system time is,
* 2007-12-18 01:15:00 +0200, then the resulting String will be "2007-12-17".
* In case you need a format with a timezone offset, use {@link #formatShortDay(TimeZone)}
* @return a String representation of the current system date in GMT using the
*         short day format, e.g. "20071218".
*/
@Override
public String format(final Date date) {
        if (date == null) return "";
synchronized (this.dateFormat) {
return this.dateFormat.format(date);
}
}
@Override
public String format() {
        if (Math.abs(System.currentTimeMillis() - this.last_time) < this.maxCacheDiff) return this.last_format;
final long time = System.currentTimeMillis();
synchronized (this.dateFormat) {
if (Math.abs(time - this.last_time) < this.maxCacheDiff) return this.last_format;
this.last_format = this.dateFormat.format(new Date(time));
}
this.last_time = time;
return this.last_format;
}
/**
* Parse a String representation of a Date in short day format assuming the date
* is aligned to the GMT/UTC timezone. An example for such a date string is "20071218".
* @see #formatShortDay()
* @throws ParseException The exception is thrown if an error occured during while parsing
* the String.
*/
@Override
public Calendar parse(final String timeString, final int timezoneOffset) throws ParseException {
synchronized (this.dateFormat) {
Calendar cal = Calendar.getInstance(UTCtimeZone);
cal.setTime(this.dateFormat.parse(timeString));
cal.add(Calendar.MINUTE, timezoneOffset);
return cal;
}
}
/**
* Like {@link #parseShortSecond(String)} using additional timezone information provided in an
* offset String, like "+0100" for CET.
* @throws ParseException 
*/
public Calendar parse(final String timeString, final String UTCOffset) throws ParseException {
        if (timeString == null || timeString.isEmpty()) { return Calendar.getInstance(UTCtimeZone); }
        if (UTCOffset == null || UTCOffset.isEmpty()) { return Calendar.getInstance(UTCtimeZone); }
return parse(timeString, UTCDiff(UTCOffset));
}
/**
* Calculates the time offset in minutes given as timezoneoffsetstring (diffString)
* e.g. "+0300"  returns 180
*
* @param diffString with fixed timezone format
* @return parsed timezone string in minutes
*/
private static int UTCDiff(final String diffString) {
        if (diffString.length() != 5) throw new IllegalArgumentException("UTC String malformed (wrong size):" + diffString);
boolean ahead = true;
        if (diffString.length() > 0 && diffString.charAt(0) == '+') ahead = true;
else if (diffString.length() > 0 && diffString.charAt(0) == '-') ahead = false;
else throw new IllegalArgumentException("UTC String malformed (wrong sign):" + diffString);
final int oh = NumberTools.parseIntDecSubstring(diffString, 1, 3);
final int om = NumberTools.parseIntDecSubstring(diffString, 3);
return (int) ( ((ahead) ? 1 : -1) * (oh * 60 + om));
}
/**
* get the difference of this servers time zone to UTC/GMT in milliseconds
* @return
*/
private static long UTCDiff() {
synchronized (testCalendar) {
testCalendar.setTimeInMillis(System.currentTimeMillis());
final long zoneOffsetHours = testCalendar.get(Calendar.ZONE_OFFSET);
final long DSTOffsetHours = testCalendar.get(Calendar.DST_OFFSET);
return zoneOffsetHours + DSTOffsetHours;
}
}
public static String UTCDiffString() {
final long offsetHours = UTCDiff();
final StringBuilder sb = new StringBuilder(5);
        if (offsetHours < 0) {
sb.append('-');
} else {
sb.append('+');
}
sb.append(D2.format(Math.abs((int) (offsetHours / AbstractFormatter.hourMillis))));
sb.append(D2.format(Math.abs((int) (offsetHours / AbstractFormatter.minuteMillis)) % 60));
return sb.toString();
}
private final static DecimalFormat D2 = new DecimalFormat("00");
public static void main(String[] args) {
System.out.println(UTCDiffString());
}
}
