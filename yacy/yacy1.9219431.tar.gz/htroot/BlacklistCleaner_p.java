/** 
 * Smoking Wheels....  was here 2017 apdcanlyspnlpboinzmyfnoraifiudgfhuytnjzhlobfdkda
 * Smoking Wheels....  was here 2017 bavlvwbqfcukaxkodqyiaheyircbaefroswxkwwtsihbhnpx
 * Smoking Wheels....  was here 2017 wfsynfjpniqbvhmxaodzzrjfojptmlwctqfuzukfgjnlxvlx
 * Smoking Wheels....  was here 2017 ocvotlodyxcauqahmaffbslbfhdhhpqqnbnwlmckutlmghij
 * Smoking Wheels....  was here 2017 mzjomnwuxqpdzpmxejulkszgamjusphursnyflvmivwnvzfa
 * Smoking Wheels....  was here 2017 ffxkwsxkdpvorcndwlomkduxyjcqhorfjnfxxkrscezemjiu
 * Smoking Wheels....  was here 2017 rqdwhpmareprlgcstdohtvzgglokvxbuytxcmlxrnreigbdv
 * Smoking Wheels....  was here 2017 ycdymxszrzbaamlpdqbdjtvxjqcbigwtzwbzcvddkjbckzhq
 * Smoking Wheels....  was here 2017 iwcviswurtqomlzxqmomkgyrcyjpeovoinliebeespnwnhtw
 * Smoking Wheels....  was here 2017 mkqczgogkryjdakcdjuchudpiufnuxvvesdbjzddqztgjjsk
 * Smoking Wheels....  was here 2017 hlkmwbpmubwvnkrxrgvzrfmzjsvibtdntrhnqnhnsiadzvqn
 * Smoking Wheels....  was here 2017 tymyrxatdmonkyzeriwknmikrpnzasewtwndbbfepucpqrgp
 * Smoking Wheels....  was here 2017 ibcshvfqwukkwiuescmuzyfqymaoxsqfaznrebtdiquayzlh
 * Smoking Wheels....  was here 2017 piujxdsysbznelugrfkylbyuftelhxliqaidnhatdlgcqelp
 * Smoking Wheels....  was here 2017 klhoyijsrrggvmxepsqwpqrdrycgzsvbzdftdvgnmdwpuxsr
 * Smoking Wheels....  was here 2017 vjqiaeggzeihstkvwultisqgvyewashrrwqbcxbhctgsrcyy
 * Smoking Wheels....  was here 2017 ghbydsrddkpkvarjdxidwnmykvcjrxkomwltxciczqjtvwcc
 * Smoking Wheels....  was here 2017 hscwkefevnrulckiftctpqzgjyrenjgkqdovddahikgkcqic
 * Smoking Wheels....  was here 2017 uinwgerkbumudfphfhspevgnywcxinydjwipubojqvjnladb
 * Smoking Wheels....  was here 2017 wdixjldebudasslfmumyncpgqkukdayzjofmzemfrbiefzem
 * Smoking Wheels....  was here 2017 vhugqzzahlaidgjiqrwgvtoidthuguzhmxzgdzpvjlauzrla
 * Smoking Wheels....  was here 2017 iijkgdssnuuxutbaorrhnhasmdnmfzzvuwqyygznynozllcp
 * Smoking Wheels....  was here 2017 fxxcpjekrdhcejmahswafnzvwfrbvydnrqltiazxydjpsypl
 * Smoking Wheels....  was here 2017 pzijkmlhbdsmcmwegbtswlwduubjdjymssyflpesalbtcdrx
 * Smoking Wheels....  was here 2017 uvzjnnwacpkzpuqtzevwqjenyyjpjebftvwarlibfsnwcdfu
 * Smoking Wheels....  was here 2017 mwisdszjnpzrydlektwgyutyjbmcemkjyxgfskpftoxnmimx
 * Smoking Wheels....  was here 2017 lwdbsqqjinkyssicptvvmmrvfsmlgsgxpeianlgucvopjkxn
 * Smoking Wheels....  was here 2017 usklwaxjsxulrxklxjbvcngrbtvosnzzjdpyfwwnypefzgda
 * Smoking Wheels....  was here 2017 yrkcoycxgpmawjflydzuadbgogdnuujbblwsfghnjgptxafd
 * Smoking Wheels....  was here 2017 leroxrvvotduqajmosklrwyssngtcshuubdjehpcmhzvycgt
 * Smoking Wheels....  was here 2017 ezymiswdrqqdlzvgwcjurmzhufivjqzcygrccbcuwqshcetc
 * Smoking Wheels....  was here 2017 fagyowhdvvdrdrwtfmbazamofcuqqfwfcmylbvjkfjkhrdjo
 * Smoking Wheels....  was here 2017 znveldllngagttvbfibsstzjtighgkrodltdmcgamtafgccv
 * Smoking Wheels....  was here 2017 zyfqfuyvkyxapcnrsjcpjgksifpftijudbcecsuyxmpqomdx
 * Smoking Wheels....  was here 2017 ezedfknjogrjexuhwoeqofsygjyywjcvlqguupisaiolszxw
 * Smoking Wheels....  was here 2017 prrpesijdtnwhnxvycobfthpzpsksfixsosmsdkdmkotymdg
 * Smoking Wheels....  was here 2017 qdaiztqjrhtlarilpmulnbsnfzosnttltpgahuxhibmyucsr
 * Smoking Wheels....  was here 2017 xxruvubevybdperorkplwsusyxhfwdjdrrwjfjwmuwmrcgxb
 * Smoking Wheels....  was here 2017 frmtdklwrcikqgyyhvadxmpnlycootiwwavujwqghqwtxpdr
 * Smoking Wheels....  was here 2017 skjeniuujiqvwhjluahspkmndyjppgbwxdruyptkpnjilbdw
 * Smoking Wheels....  was here 2017 tiriyolklklhjxigujzrctzmtzsmioinqrccjcbbsvvtitui
 * Smoking Wheels....  was here 2017 xwvsolaponjwlapweptuvaymijbogvboeqeshbqlvejsicia
 * Smoking Wheels....  was here 2017 btrbumhkuzhaoubxytralakvbtnldmlyxfexppuelikzltfe
 * Smoking Wheels....  was here 2017 hzdjhljdhiigpqyioybrwutbkylzccxtkxncnzcaglotapdc
 * Smoking Wheels....  was here 2017 ztoxaipiolwopesipsiehonacaojkqenokcdlrkciwsjpvap
 * Smoking Wheels....  was here 2017 snkdcmmvjkozuiaixsgicxnteirypgfwkruzbnuqudbmyvco
 * Smoking Wheels....  was here 2017 kalvykxrqpixtgwapzxcypwovmyhlheujxzvfnogfdxxdfvd
 * Smoking Wheels....  was here 2017 beszhvxeqngyhikharnsupwanhtizmokaqcfezgsgyxvkxwu
 * Smoking Wheels....  was here 2017 dgluzvvxvctakfcjtgpsuhcxawtdoraegnxxhjtcxxzojcff
 * Smoking Wheels....  was here 2017 erevfrgqyjlelwsssmwvjdjhhnwcrboucomwgnctlpgttdai
 * Smoking Wheels....  was here 2017 aequkwzmzsfwxjcyyhladxtmowdwczhezxajzkqeivbgqsui
 * Smoking Wheels....  was here 2017 vsvsffcrerfqpdmavxmpcqpbhtahyetnmcbwqjyfhtdfisdq
 * Smoking Wheels....  was here 2017 xnbuotxwzdvkpwjezunajqlvghdnmlqglvjdqxvxhrhaihcy
 * Smoking Wheels....  was here 2017 xavoqtaucdrhdkjtgrjajkevksjwfbvbaayertioofsgmvve
 * Smoking Wheels....  was here 2017 rzxtvsgnpbrquxnmtmzqutujytwzzhowmybfqawtpesuuaun
 * Smoking Wheels....  was here 2017 higjvkrjqnybjvyivlrbnqraldztuxhwnaftrxxhdqatnsrk
 * Smoking Wheels....  was here 2017 dheqoxpyshwmwtdkbbxvukjpnzkgyssmyaeogzjfdzlohdkn
 * Smoking Wheels....  was here 2017 ujebdlpzpmbzqqvfjzmsxnrdgrzxayukwvypaagvvuetwqgv
 * Smoking Wheels....  was here 2017 cfakbpnoflmydqwkugjqqvtyuuvitzsprtvexbxsswpggwpl
 * Smoking Wheels....  was here 2017 fusrxclauuezgcoxsawwwivqrckiflxexehrbixrniheutev
 * Smoking Wheels....  was here 2017 mjnbrzqxwhpzashxtumythoyquhcsgcqmwcyxkctfnfwzkys
 * Smoking Wheels....  was here 2017 mkzcmoszcdjbqktvsgypsgrypdkaunfqmthzcbohbalarhbz
 * Smoking Wheels....  was here 2017 bououinkooiothykujhulyjzvtwqftmcgccyohoumrkkwazv
 * Smoking Wheels....  was here 2017 jwajfbcjjgsdctamgjuuvmwpvmbwanifkhbknksdgosfvmlr
 * Smoking Wheels....  was here 2017 tmwvrutmcyuqtmmjtsycbbtphkpvnslludxbhxviibguewkg
 * Smoking Wheels....  was here 2017 txykkudplvhfzjyjddnlngxaewkxhoulnnrzpparysftqozl
 * Smoking Wheels....  was here 2017 iwxwtqzskfbgiplgmonvyvjfulqsbjpdzspijmoupjxzhfsl
 * Smoking Wheels....  was here 2017 mhvflakddqghpndxegfnevmsozqcxwhtsdfquwbkadaplsgs
 * Smoking Wheels....  was here 2017 qjyribtmfzfgwumnvqczlmuhgobfdyorqohqfghqeilzpfow
 * Smoking Wheels....  was here 2017 kqutqyonijqhjjdohlyzcjccuoujgsjpuwvjikkuhpgsneuy
 * Smoking Wheels....  was here 2017 pudetgrhmbjsqidsrqunxgojlnyhcqwmpjcackrkwsxsjema
 * Smoking Wheels....  was here 2017 iuyyjtddwsoendpvhkwvrdlrriytrhpnqlpdqmrhptzciehq
 * Smoking Wheels....  was here 2017 yvnjjmipzdpobkbfugrkqhiwgbkxhqebtwbljdfmndkfzhdj
 * Smoking Wheels....  was here 2017 cjjvysumolcynbcezxaafhaydafdmvpxaooxzgliukiscxgf
 * Smoking Wheels....  was here 2017 qdgenziwoyztlgunbhwqaxqgnvncbgbwwuivktpkzkcktscj
 * Smoking Wheels....  was here 2017 pddjtabbggjoqjfbhpnmbdmiyiroanygwzwruyiltfimgqif
 * Smoking Wheels....  was here 2017 lniqoxgpcerhdbychjldkgdzcpjtspbjwwyeokjpcezhctxl
 * Smoking Wheels....  was here 2017 rujmcxohvvmzfgozzglgovlhyzmzrphazjpjjvwcgxekcnbb
 * Smoking Wheels....  was here 2017 fqyqunsfkosclbckkhnwdpkoubcwryvbotbldhdnsffuhogd
 * Smoking Wheels....  was here 2017 dbddiowrcymfqysiypxgbpkibrrithdrfmvzactsffvmzucf
 * Smoking Wheels....  was here 2017 ugdfpahgiveeunxyesdwncakmytlfnyjugsqmsnrrfxxrkqx
 * Smoking Wheels....  was here 2017 vrnjufprxhmefrhrzhzlyrbwaeippudtkarleymukvnqgsae
 * Smoking Wheels....  was here 2017 bbaiiqoctsgmmpwemjlaybobzzmlsnztkaarzvbnvxcpqlse
 * Smoking Wheels....  was here 2017 pjqcwcitcppviqwkzcuvmgxluepupjxqksfucqsusngwgmkj
 * Smoking Wheels....  was here 2017 vurxhpeglwyavnrodznjsprxewhumfotguboywjoaawvnybl
 * Smoking Wheels....  was here 2017 iuphvkrjnpxehcaausjjbpqmdknuaezvagoyeiaezzdchhwi
 * Smoking Wheels....  was here 2017 ydfzwcrfibjsfnvnahkveaxmwijmxshudhzftbaebgkoqdge
 * Smoking Wheels....  was here 2017 utmyckfaaymfkfjafxxzawumxofqgmzuekuxthzkaxhiujzm
 * Smoking Wheels....  was here 2017 gvslkjqkeaqnyuaqyzhjsmwgycsmiishygurrprxvisuieyw
 * Smoking Wheels....  was here 2017 xwjaygnemklvcfmucikssjywyjuhrmmaqvzpesfzsbuobzih
 * Smoking Wheels....  was here 2017 ppgieqsixlvmlptgtvfaqgdqexntbhlvnjrwdswfeyxmzjqx
 * Smoking Wheels....  was here 2017 lzjlufggrsxbrjzxiszmlftddohsokcyhhhasvhjxcsrkgnf
 * Smoking Wheels....  was here 2017 vezoqcmlhbbmydrximgrhniemkuhlscusjqukqfoxwcowwzw
 * Smoking Wheels....  was here 2017 irofxmytmoxwmwmtsvuhprtthvwvhllbyntdvwuakuftfnet
 * Smoking Wheels....  was here 2017 ugydazmffpjnwqjbmsojamagrjrawygqiyvjxpijxukbkxod
 * Smoking Wheels....  was here 2017 iubirhfdtrpewxnvcivcnzoefxprfwbumelxubjkcwiruxwj
 * Smoking Wheels....  was here 2017 infasnkcnsxpohkfbeeaflvjqngypcnxgwipxutezkwxxrzf
 * Smoking Wheels....  was here 2017 izyskwqxhuazesspizgvnitxvnofqvorsaniyoozuzdknrdn
 * Smoking Wheels....  was here 2017 guyecxtpaftrhiktyrepdniadoqabllahvgkukckampbsmvo
 * Smoking Wheels....  was here 2017 eyhjmkvnzphgtoqogmenzzyjykwiyppdnubiqqzgjyuztars
 * Smoking Wheels....  was here 2017 lrfomkeeptzrmzyfxwscezdrbfwgofrmhorvxtzousroelrr
 * Smoking Wheels....  was here 2017 rlgggdjkrvmzxoydsnqcfctbkgocmkrrsdcygnfrpjjjueaj
 * Smoking Wheels....  was here 2017 tzcefefgccspmlqavmwmrbvugecolptrdtrvpyzcfvfhqvdz
 * Smoking Wheels....  was here 2017 tfviahvbeetcabevoxtnoxskbuvlokksevvbcjxrkbxlzjty
 * Smoking Wheels....  was here 2017 zjsyqmnjiyakozbrogsszyzuoejxbuieqdiiehsmdnigkwuz
 * Smoking Wheels....  was here 2017 dyfoebwyikdpkeybqgpvkqlyssriowltrpgrnmoupsphsumz
 * Smoking Wheels....  was here 2017 apdwbnrxezabctuqywjulwffvzvhtbykqlviayteinbkwtgc
 * Smoking Wheels....  was here 2017 tilxaraoaftlldvjuihxaoochugstaigddntwavlaalugrvw
 * Smoking Wheels....  was here 2017 rilxxngllztomamkvcxqjacmwgnrwqgvajdtmerqrootjsdw
 * Smoking Wheels....  was here 2017 lcpjxjxicirpmglewwytvuqjorpppbrsjdsimfhcnspyagjc
 * Smoking Wheels....  was here 2017 vjtalswizqjwzzrjaqkfdrgcospbtruxorlqwdbjbiwfgzzt
 * Smoking Wheels....  was here 2017 zavxeidtilaavqjyrppidqgejdwxiebofkxgshogyncsitre
 * Smoking Wheels....  was here 2017 hidfbhbdqqyxzvzckeaobagmsccisleceauxncovgpduvtkd
 * Smoking Wheels....  was here 2017 htemfughqhwrvofecekqihabpxdrjqcgnofpxlfjdeccnjjo
 * Smoking Wheels....  was here 2017 xaskclmhhtpsvwzyvmtongsefdcnddzyqeiovhtldbkmmgzp
 * Smoking Wheels....  was here 2017 fbubiaxkvphpwfnizjkpryokcqluaqihdjshkyvxyjrayhar
 * Smoking Wheels....  was here 2017 ncppwmtftrjfwfhmcgugwqeoxnupizvvvvcnbxftokuensjn
 * Smoking Wheels....  was here 2017 nqspwdqotclrfvywcwsfovksrdzhqjlewomhnyaifuxmyvfa
 * Smoking Wheels....  was here 2017 aivttojlvdjjlemdceeojjiepaenrfigpsevrdnejkjxhibk
 * Smoking Wheels....  was here 2017 dfacelbggljxhqbgkkkmhefmeatdodyhpvrpqtjctgwlwcpc
 * Smoking Wheels....  was here 2017 elnvbwallwsewxekqazmmqrmdhjgnaasuosjxgiejshpeits
 * Smoking Wheels....  was here 2017 vmwmoduxeldgkwmzrsqhhfnelcxgdbmefwidcmmsljsxbjsh
 * Smoking Wheels....  was here 2017 xcuudsfqknnonryroljylsvxjbmteqnpfauddlehlcogmxzy
 * Smoking Wheels....  was here 2017 neiulkkajtysxstmtmlrvdyfjanqrkqglmpxflyqcymtvwfd
 * Smoking Wheels....  was here 2017 zasqjgponxuosqjntgjzqulyecpzzhlmtxmdsyrxkgivpjio
 * Smoking Wheels....  was here 2017 zbmxcmmbqctfdjmfmlyohecdtorgpkzagimwjujipqhaoupc
 * Smoking Wheels....  was here 2017 izjibsupsrscubbiaccmlcabjbvziejugxxiaykndyshuvlz
 * Smoking Wheels....  was here 2017 ctlwyqqmxfttlchstjfyaooilkmbegdykceawtigtffrojoq
 * Smoking Wheels....  was here 2017 sqxuphihtoideeqpfsrmdvgtusfqnoxynrcqiszpmvtplows
 * Smoking Wheels....  was here 2017 sbgpfaluyvahedtkiwiuimxiihaauermtpsgbpkwljkrgvqf
 * Smoking Wheels....  was here 2017 atibggvbmhtqcdqveveydgqlhtyyxppmkafcakzqfqotyugg
 * Smoking Wheels....  was here 2017 rrccjwnlqqqurqmtdtlcoetpexjeukecemeqimfrmuwywjkh
 * Smoking Wheels....  was here 2017 bbualvxkvpbqygsltdrutnvpsxawvncvuqiplhabgdfrosca
 * Smoking Wheels....  was here 2017 uizirkmwujrggwbgysptcwrowarkmdhhmmsbzrjctgtnvfni
 * Smoking Wheels....  was here 2017 tfktmecunfjacqlxvkhahxktwwojqpylnfoexpqjkzwksocm
 * Smoking Wheels....  was here 2017 ysbgmwwohshphabirlyugthsghasgpomnhjnkjlralejlpnv
 * Smoking Wheels....  was here 2017 vzfcrnbrnutuwpjsehcpdqyhrjrmrauwjmyuvmnaoyovrnud
 * Smoking Wheels....  was here 2017 zojvelgzylmudicndrmejbendmlbkzpfergzwtzufbekcsbg
 * Smoking Wheels....  was here 2017 gcidldinpciypidjroenqwbtxelchzemgdpjlfenmsjzvwtl
 * Smoking Wheels....  was here 2017 sobackiqqglwcatfddkvvaymlhckipawfimltcrzdxvqcvqb
 * Smoking Wheels....  was here 2017 tfvtbfovpvekqaigdxrrdvjolyzevstuyzqxfzghczlumtqw
 * Smoking Wheels....  was here 2017 zmevnxpyewetnhqyootuyvdaylbtiojzozdvlqarqpiaucyt
 * Smoking Wheels....  was here 2017 gcwzxyhajsjeiyoxmbqdyukedkjuplbhjqekjahuenwfalaw
 * Smoking Wheels....  was here 2017 rawfwesjkzwkujidgqpzbtkqnrkbtcgzajgdfnrjnxrnntns
 * Smoking Wheels....  was here 2017 pmltipepunafagjtmtevlyuduisuakskiwftioynqbrhuely
 * Smoking Wheels....  was here 2017 pxedlmflfjnugmkgaccjnyitzrfhyniildailafnsoadqbzm
 * Smoking Wheels....  was here 2017 oatbqitaqwgmafkizrkryndvhjbfjuhqrkyalvuyggaxccoo
 * Smoking Wheels....  was here 2017 pvfopztpjrhxevnvtriyrrnxfeqkgycoqcmjmhfpzgkumfxn
 * Smoking Wheels....  was here 2017 bnvwflqtvocytafawojsvsaulgozzvklgykcazjnxwzcimyd
 * Smoking Wheels....  was here 2017 onclryxhuqhszqfhgbirvdnnaxtjbqfbnxtfrqibgsymkkxh
 * Smoking Wheels....  was here 2017 xquckbkhegsomxlizcfwktbldthdgtrhwfsykhislpruuoee
 * Smoking Wheels....  was here 2017 gswuaofahanezdcbkzgnkoybgopeqvgiwhwvigbjhqudtwng
 * Smoking Wheels....  was here 2017 ycrunlrbnsdjpbqsdczdawugenipntqqkxzpyzhasedyvmxe
 * Smoking Wheels....  was here 2017 pdroabifrmegnotradelrekauxitksuwozagvhbayuyuwvlw
 * Smoking Wheels....  was here 2017 apqvxwansrmfktlreevlbgwskhthcbxzsugzzgtxninpvoqo
 * Smoking Wheels....  was here 2017 jmprxqvjwugxzcvpziekaemwlpacqnldlsfjnbymcwokbneq
 * Smoking Wheels....  was here 2017 zyuhylbfpuwehejrzbuvvdwhrvshixctqnqcwhkustwqcyav
 * Smoking Wheels....  was here 2017 llsedoiyqrydqyvhcekkutubbjteslvoieoestgeporxsdja
 * Smoking Wheels....  was here 2017 rtdbymkozujeoocdjozeqtilwugmpmulzxgwyjufeeibzvqk
 * Smoking Wheels....  was here 2017 svcyazjkwuhxwjkeflwkhfwbnzqzzsmqccfqtnpqgqlgexol
 * Smoking Wheels....  was here 2017 xvwdgdoaulbfoceoehnnxiyrtynvfbpnpoehosnothywvncv
 * Smoking Wheels....  was here 2017 xgxbwfpgkxjeapduevsixrjipctlupbvofetarphxtymtbkl
 * Smoking Wheels....  was here 2017 pvamgrfctlbfraflgalvybfjgzojnubmjhmibmdkgwvzzezm
 * Smoking Wheels....  was here 2017 zmekbjoxcshxkuqnvcafylwjemfnlgcqpfqmvkuqlsgmvumk
 * Smoking Wheels....  was here 2017 nmrbfhyfvnmdgovflmxacdvcdqlawxvsctiyuyicnpcjubwx
 * Smoking Wheels....  was here 2017 tgazxtxwtyeblflyaxxzusyqcvcgiyfmawptoxvcremhsiix
 * Smoking Wheels....  was here 2017 nnzwnfhxujjaoxnjpjzcswhgiqiuprlurstcbhqflfvbpijo
 * Smoking Wheels....  was here 2017 zgosunepficqkbglpakqtqeogwnntvavrvfomkhfmwsvtxqh
 * Smoking Wheels....  was here 2017 mrzvoqwomrvuzhzioktacjfjpqhpbhocxwvugtqeulczsgbw
 * Smoking Wheels....  was here 2017 qgvraxzojodoqonnkdscenfrjinicebflvowadtjqnbcisxd
 * Smoking Wheels....  was here 2017 gqvypvhrugzkxzuqehhurxgvvlkkpytdqxszsnykmyzcoaoi
 * Smoking Wheels....  was here 2017 mxzszeygajlwoyzqhzvjloqkkwgrrfzadptrmhucavobtauw
 * Smoking Wheels....  was here 2017 qeoeayetotxvpcnshttissxewstgowojsqlqtwdlimqjkwmk
 * Smoking Wheels....  was here 2017 jybwzmpcbmalkkcgbhwkwyzfdhunvcjuoxwxecbvnnjqjzwy
 * Smoking Wheels....  was here 2017 nyhnegbgoxrbmytasoeqoawwnfmbhhqgaresszwtduduqzjp
 * Smoking Wheels....  was here 2017 ecfcjcpohpaipeowptyftxxqlgfuycuyqkyonvcbxjownvsv
 * Smoking Wheels....  was here 2017 srcwkzopslkbvscaijrqpzrirpquclohiuyezcquvooioqvi
 * Smoking Wheels....  was here 2017 scmjmfneomnlmmyxtcdrnrzbenqmilwzevepuqnfcafsovxa
 * Smoking Wheels....  was here 2017 bdchahhivbfvbpdfzxjjewxbdqilknxynrwawkczenzxoalb
 * Smoking Wheels....  was here 2017 vrzqrayjtuquinvwiaowmmuzdudoiieizwpzktyvwflcvecy
 * Smoking Wheels....  was here 2017 kzjrklvvtmeglwmbmyhspweoubryltiqlcbetdwvcjnoyjwi
 * Smoking Wheels....  was here 2017 jmuwiumpqglionugfhhrynxwetvzhzhnzihrqkxicrizrbwd
 * Smoking Wheels....  was here 2017 pyaawqtqilijirsbrdosffcgmnsiqjixytorynmvjwhgcwqn
 * Smoking Wheels....  was here 2017 fibbstricqazmsllgpkdiaafeettopwzyvkrvvbepczklsuz
 * Smoking Wheels....  was here 2017 nudhucqfkrwcchlplfiikdfpzupmiooewinkuuolvsiwitie
 * Smoking Wheels....  was here 2017 dwvegbfbaqmumijzfrbdxeplytbvmkletezxkezwhgmhmjla
 * Smoking Wheels....  was here 2017 yfvlmbezwwulcygfqxpnmwfcfpjlvoqxapakqcrckpumzgps
 * Smoking Wheels....  was here 2017 avedfypgeyxrvofhafgsbficifvdkrpogadjqtgwyvxpcgms
 * Smoking Wheels....  was here 2017 txdmitvllsgjrusjaznfuoofzqddnpcphfcpvslgwgtzkoaq
 * Smoking Wheels....  was here 2017 tygzzrmjlhkqxpmwmyeucktoegesrnzqgdyawtlpknkhrokm
 * Smoking Wheels....  was here 2017 vqfjqihccaiwcclnnbelrmykdpanrwosmyyyswmlblgkzxdk
 * Smoking Wheels....  was here 2017 cxcqxlkwrlcqbsvempvkkxmijpdmpgexqeowmjepoczkonxv
 * Smoking Wheels....  was here 2017 ybdatbdiqkcvvcbcyyrdmwydogcqspprmnomptjcwvmrzoql
 * Smoking Wheels....  was here 2017 ymwbhlagrbapqdvsuwkliydxrzvkobttfxzvuvbhfgvvbjnf
 * Smoking Wheels....  was here 2017 yyamaeyrwrsicycqdibhpxdxahmkybwadpccxpqsceltvqah
 * Smoking Wheels....  was here 2017 cjpgoyxyiwhozacwimxxeuhsacjmxeiswbjwdjrefszoohvd
 * Smoking Wheels....  was here 2017 tzxquvhpqmegiyfoyxmvhvddkmfttjwfgyqvyqyspehqvlyj
 * Smoking Wheels....  was here 2017 mgkeydqlmpzlkqeewfmuipmgeswqzulfkhvzxeprlenpjnmz
 * Smoking Wheels....  was here 2017 dxxokiuowoqovfyjfkztywmjolltkvhrrhgpaaxpgnbhheye
 * Smoking Wheels....  was here 2017 wxjuwfufyzgghescirgabqkzbnixcdutrkkdkmlhsjpwwhai
 * Smoking Wheels....  was here 2017 zlccgvazhrfiybynuosaxevzizfghpqwgibknbbvwzyrpard
 * Smoking Wheels....  was here 2017 czpbrlaspsdxzwhcmsfovbojlfyfpkwtnafiznunwagjiuco
 * Smoking Wheels....  was here 2017 chqipopkvmykartmnbtqmbsmouritypiwtdetyawggxtcgsu
 * Smoking Wheels....  was here 2017 bhfyrawkgntkuxnpfxnlwepxentnwwhtvyimzngttvpaegff
 * Smoking Wheels....  was here 2017 iepevuchisyvkgzrfrdncrujbowwdcrmhipxcvjfibendaqn
 * Smoking Wheels....  was here 2017 olglfdxuudescoxdjchpocdaeewvfssekwxotrkngntwtxbr
 * Smoking Wheels....  was here 2017 ovaphqdbpdhnlagrucarzgqcsaxxufnultnpwashxcsxapaw
 * Smoking Wheels....  was here 2017 mgwnrbvizhmvfadeuypzhdrefxjbzeqmbmyoqevhdwtuizem
 * Smoking Wheels....  was here 2017 qyaohkhfmkdmmgcvabmapbvcjyxjaossdtzelrqpvdsxdfng
 * Smoking Wheels....  was here 2017 qjcdizdmtqvrnnudhdmoimxxeljfnlsesnqlzhenhntwhreb
 * Smoking Wheels....  was here 2017 igtbfhdevhmswbestfppfgywvzyggiwueadpdbtpyvgmvare
 * Smoking Wheels....  was here 2017 woagpdlrxygfiglntmcicjjpwlyhfuosetaecgzqofvyzeqy
 * Smoking Wheels....  was here 2017 omfaknimmmncxtaswjnhebqxzxcmstnkmiawijqtbyjpjhcb
 * Smoking Wheels....  was here 2017 anvwusjlhyxmzmrtzpogwyqudrfeijsngueskfwetractten
 * Smoking Wheels....  was here 2017 djpmehkpishranhifegewtlpqjmbwahbvjtyhvxncffgfgjl
 * Smoking Wheels....  was here 2017 yznxgzmftivjvjcjwhwhbmjxwvgyhludvlfaelkotqnfypjh
 * Smoking Wheels....  was here 2017 wpxixvyydrwklpnbpkycpmznqeeyylvgcvkulqdkuhvjpbct
 */
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.yacy.cora.document.id.Punycode.PunycodeException;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.data.ListManager;
import net.yacy.kelondro.util.FileUtils;
import net.yacy.repository.Blacklist;
import net.yacy.repository.BlacklistHostAndPath;
import net.yacy.repository.Blacklist.BlacklistError;
import net.yacy.repository.Blacklist.BlacklistType;
import net.yacy.search.Switchboard;
import net.yacy.search.query.SearchEventCache;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
public class BlacklistCleaner_p {
/** Used for logging. */
private static final String APP_NAME = "BLACKLIST-CLEANER";
private static final String RESULTS = "results_";
private static final String DISABLED = "disabled_";
private static final String BLACKLISTS = "blacklists_";
private static final String ENTRIES = "entries_";
public static final Class<?>[] supportedBLEngines = { Blacklist.class };
public static serverObjects respond(
@SuppressWarnings("unused") final RequestHeader header,
final serverObjects post,
@SuppressWarnings("unused") final serverSwitch env) {
final serverObjects prop = new serverObjects();
String blacklistToUse = null;
prop.put(DISABLED + "checked", "1");
        if (post != null) {
final boolean allowRegex = post.get("allowRegex", "off")
.equalsIgnoreCase("on") ? true : false;
prop.put(DISABLED + "checked", (allowRegex) ? "1" : "0");
if (post.containsKey("listNames")) {
blacklistToUse = post.get("listNames");
if (blacklistToUse.isEmpty()
|| !ListManager.listSetContains(
"listManager.listsPath",
blacklistToUse)) {
prop.put("results", "2");
}
}
putBlacklists(prop, FileUtils.getDirListing(ListManager.listsPath,
Blacklist.BLACKLIST_FILENAME_FILTER),
blacklistToUse);
if (blacklistToUse != null) {
prop.put("results", "1");
if (post.containsKey("delete")) {
prop.put(RESULTS + "modified", "1");
prop.put(RESULTS + "modified_delCount",
removeEntries(blacklistToUse,
BlacklistType.values(),
getKeysByPrefix(post,
"select",
true)));
} else if (post.containsKey("alter")) {
prop.put(RESULTS + "modified", "2");
prop.put(RESULTS + "modified_alterCount",
alterEntries(blacklistToUse,
BlacklistType.values(),
getKeysByPrefix(post,
"select",
false),
getValuesByPrefix(post,
"entry",
false)));
}
final Map<String, BlacklistError> illegalEntries = getIllegalEntries(
blacklistToUse, Switchboard.urlBlacklist,
allowRegex);
prop.put(RESULTS + "blList", blacklistToUse);
prop.put(RESULTS + "entries", illegalEntries.size());
prop.putHTML(RESULTS + "blEngine", Blacklist.getEngineInfo());
prop.put(RESULTS + "disabled", (illegalEntries.isEmpty()) ? "1"
: "0");
if (!illegalEntries.isEmpty()) {
prop.put(RESULTS + DISABLED + "entries",
illegalEntries.size());
int i = 0;
String key;
for (final Entry<String, BlacklistError> entry : illegalEntries
.entrySet()) {
key = entry.getKey();
prop.put(RESULTS + DISABLED + ENTRIES + i + "_error",
entry.getValue().getLong());
prop.putHTML(RESULTS + DISABLED + ENTRIES + i
+ "_entry", key);
i++;
}
}
}
} else {
prop.put("results", "0");
putBlacklists(prop, FileUtils.getDirListing(ListManager.listsPath,
Blacklist.BLACKLIST_FILENAME_FILTER),
blacklistToUse);
}
return prop;
}
/**
* Adds a list of blacklist to the server objects properties which are used
* to display the blacklist in the HTML page belonging to this servlet.
* 
* @param prop
*            Server objects properties object.
* @param lists
*            List of blacklists.
* @param selected
*            Element in list of blacklists which will be preselected in
*            HTML.
*/
private static void putBlacklists(final serverObjects prop,
final List<String> lists, final String selected) {
boolean supported = false;
for (int i = 0; i < supportedBLEngines.length && !supported; i++) {
supported |= (Switchboard.urlBlacklist.getClass() == supportedBLEngines[i]);
}
        if (supported) {
if (!lists.isEmpty()) {
prop.put("disabled", "0");
prop.put(DISABLED + "blacklists", lists.size());
int count = 0;
for (final String list : lists) {
prop.putHTML(DISABLED + BLACKLISTS + count + "_name", list);
prop.put(DISABLED + BLACKLISTS + count + "_selected",
(list.equals(selected)) ? "1" : "0");
count++;
}
} else {
prop.put("disabled", "2");
}
} else {
prop.put("disabled", "1");
for (int i = 0; i < supportedBLEngines.length; i++) {
prop.putHTML(DISABLED + "engines_" + i + "_name",
supportedBLEngines[i].getName());
}
prop.put(DISABLED + "engines", supportedBLEngines.length);
}
}
/**
* Retrieves all keys with a certain prefix from the data which has been
* sent and returns them as an array. This method is only a wrapper for
* {@link getByPrefix(de.anomic.server.serverObjects, java.lang.String,
* boolean, boolean)} which has been created to make it easier to understand
* the code.
* 
* @param post
*            All POST values.
* @param prefix
*            Prefix by which the input is filtered.
* @param filterDoubles
*            Set true if only unique results shall be returned, else false.
* @return Keys which have been posted.
*/
private static String[] getKeysByPrefix(final serverObjects post,
final String prefix, final boolean filterDoubles) {
return getByPrefix(post, prefix, true, filterDoubles);
}
/**
* Retrieves all values with a certain prefix from the data which has been
* sent and returns them as an array. This method is only a wrapper for
* {@link getByPrefix(de.anomic.server.serverObjects, java.lang.String,
* boolean, boolean)}.
* 
* @param post
*            All POST values.
* @param prefix
*            Prefix by which the input is filtered.
* @param filterDoubles
*            Set true if only unique results shall be returned, else false.
* @return Values which have been posted.
*/
private static String[] getValuesByPrefix(final serverObjects post,
final String prefix, final boolean filterDoubles) {
return getByPrefix(post, prefix, false, filterDoubles);
}
/**
* Method which does all the work for {@link
* getKeysByPrefix(de.anomic.server.serverObjects, java.lang.String prefix,
* boolean)} and {@link getValuesByPrefix(de.anomic.server.serverObjects,
* java.lang.String prefix, boolean)} which have been crested to make it
* easier to understand the code.
* 
* @param post
* @param prefix
* @param useKeys
* @param useHashSet
* @return
*/
private static String[] getByPrefix(final serverObjects post,
final String prefix, final boolean useKeys,
final boolean useHashSet) {
Collection<String> r;
        if (useHashSet) {
r = new HashSet<String>();
} else {
r = new ArrayList<String>();
}
        if (useKeys) {
for (final String entry : post.keySet()) {
if (entry.indexOf(prefix) == 0) {
r.add(entry.substring(prefix.length()));
}
}
} else {
for (final Map.Entry<String, String> entry : post.entrySet()) {
if (entry.getKey().indexOf(prefix) == 0) {
r.add(entry.getValue());
}
}
}
return r.toArray(new String[r.size()]);
}
/**
* Finds illegal entries in black list.
* 
* @param blacklistToUse
*            The blacklist to be checked.
* @param blEngine
*            The blacklist engine which is used to check
* @param allowRegex
*            Set to true to allow regular expressions in host part of
*            blacklist entry.
* @return A map which contains all entries whoch have been identified as
*         being illegal by the blacklistEngine with the entry as key and an
*         error code as value.
*/
private static Map<String, BlacklistError> getIllegalEntries(
final String blacklistToUse, final Blacklist blEngine,
final boolean allowRegex) {
final Map<String, BlacklistError> illegalEntries = new HashMap<String, BlacklistError>();
final Set<String> legalEntries = new HashSet<String>();
final List<String> list = FileUtils.getListArray(new File(
ListManager.listsPath, blacklistToUse));
final Map<String, String> properties = new HashMap<String, String>();
properties.put("allowRegex", String.valueOf(allowRegex));
BlacklistError err = BlacklistError.NO_ERROR;
for (String element : list) {
element = element.trim();
if (legalEntries.contains(element)) {
illegalEntries.put(element, BlacklistError.DOUBLE_OCCURANCE);
continue;
}
legalEntries.add(element);
err = Blacklist.checkError(element, properties);
if (err.getInt() > 0) {
illegalEntries.put(element, err);
}
}
return illegalEntries;
}
/**
* Removes existing entries from a blacklist.
* 
* @param blacklistToUse
*            The blacklist which contains the
* @param supportedBlacklistTypes
*            Types of blacklists which the entry is to changed in.
* @param entries
*            Array of entries to be deleted.
* @return Length of the list of entries to be removed.
*/
private static int removeEntries(final String blacklistToUse,
final BlacklistType[] supportedBlacklistTypes,
final String[] entries) {
for (final String entry : entries) {
String s = entry;
if (s.contains("\\\\")) {
s = s.replaceAll(Pattern.quote("\\\\"),
Matcher.quoteReplacement("\\"));
}
for (final BlacklistType supportedBlacklistType : supportedBlacklistTypes) {
if (ListManager.listSetContains(supportedBlacklistType
+ ".BlackLists", blacklistToUse)) {
final String host = (s.indexOf('/', 0) == -1) ? s : s
.substring(0, s.indexOf('/', 0));
final String path = (s.indexOf('/', 0) == -1) ? ".*" : s
.substring(s.indexOf('/', 0) + 1);
try {
Switchboard.urlBlacklist.remove(supportedBlacklistType,
blacklistToUse, host, path);
} catch (final RuntimeException e) {
ConcurrentLog.severe(APP_NAME, e.getMessage() + ": "
+ host + "/" + path);
}
}
}
SearchEventCache.cleanupEvents(true);
}
return entries.length;
}
/**
* Changes existing entry in a blacklist.
* 
* @param blacklistToUse
*            The blacklist which contains the entry.
* @param supportedBlacklistTypes
*            Types of blacklists which the entry is to changed in.
* @param oldEntry
*            Entry to be changed.
* @param newEntry
*            Changed entry.
* @return The length of the new entry.
*/
private static int alterEntries(final String blacklistToUse,
final BlacklistType[] supportedBlacklistTypes,
final String[] oldEntry, final String[] newEntry) {
removeEntries(blacklistToUse, supportedBlacklistTypes, oldEntry);
String host, path;
/* Prepare the new blacklist items list to add then them in one operation for better performance */
final Collection<BlacklistHostAndPath> newEntries = new ArrayList<>();
for (final String n : newEntry) {
final int pos = n.indexOf('/', 0);
if (pos < 0) {
host = n;
path = ".*";
} else {
host = n.substring(0, pos);
path = n.substring(pos + 1);
}
newEntries.add(new BlacklistHostAndPath(host, path));
}
for (final BlacklistType s : supportedBlacklistTypes) {
if (ListManager.listSetContains(s + ".BlackLists",
blacklistToUse)) {
try {
Switchboard.urlBlacklist.add(s, blacklistToUse, newEntries);
} catch (PunycodeException e) {
ConcurrentLog.warn(APP_NAME,
"Unable to add blacklist entry to blacklist "
+ s, e);
}
}
}
SearchEventCache.cleanupEvents(true);
return newEntry.length;
}
}
