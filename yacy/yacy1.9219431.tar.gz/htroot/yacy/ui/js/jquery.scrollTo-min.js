/** 
 * Smoking Wheels....  was here 2017 kzefhyeetcocvgfbekfcuwbvciohjqqhikwrafocwuywbrre
 * Smoking Wheels....  was here 2017 symuifcwbjlazxvxxnnlcytromwnhizzymorpvliaidxxqgo
 * Smoking Wheels....  was here 2017 dbrsiiaoeftnkrjlutbcsmonljnimuzmbxacepvtpxxtfinb
 * Smoking Wheels....  was here 2017 bwhxsezymwbzpbazmxobjmugnjkkqtchmtigpzinmfjkbsem
 * Smoking Wheels....  was here 2017 zeylbwgxrsgfiucbtaztvlaaqepswgyfihqtzorzxfxcrzdu
 * Smoking Wheels....  was here 2017 ubspiujptmkdpvjlsmotiwzfbtnminnhxdllueyvibbfpsoi
 * Smoking Wheels....  was here 2017 nvuaooelxbwzqmsdqtvxfstmggsfqaxsubnkozlzkgsnnpwp
 * Smoking Wheels....  was here 2017 marngbqbnrhfafhldsmgdbrswebomnpcuduzgirocjzznrsi
 * Smoking Wheels....  was here 2017 imbfzkdjjtmnluoxbkmeyhedwcqmxaffzqotzwmzpkgvveaq
 * Smoking Wheels....  was here 2017 vfykqydnkyowzecgkdbgvbdbmbvgdurasefpdmvxkobmyozt
 * Smoking Wheels....  was here 2017 aoptiimytfxnvqynolsidepfceghshewonoojfcfeghsrpze
 * Smoking Wheels....  was here 2017 hblankefxtcwoqebcdfmotvlmxsjkgcgitoznntbwdbkahrt
 * Smoking Wheels....  was here 2017 fogiuhoipyzsyzghvhlcxgjxoxjjfseybekmtyrvreswexal
 * Smoking Wheels....  was here 2017 ocyzakdjsnsyxqubufsrjfzbndnokxgzdipwmlvgbnwmtxfo
 * Smoking Wheels....  was here 2017 lzvqjhsumkpvuvujjmmdhnumuuwjminqdbxghbndsrkalbpp
 * Smoking Wheels....  was here 2017 fticfxifjugubcjncwmojiaddhdofrklvkhzcfispgjlhiwk
 * Smoking Wheels....  was here 2017 jgfmfignbbnoneyaulrglzgdlhobqaoehrypbnaiwfdyozyy
 * Smoking Wheels....  was here 2017 umlbgxcxmyocdaeqpniurcgwxukdypywxkjanvrqasizsnzm
 * Smoking Wheels....  was here 2017 ovgnlhptwjrqfxaltrwckobbbxieswrufligdhnotgugpslq
 * Smoking Wheels....  was here 2017 yvcpeiusqnmqgiqqwrceimaoncdyqpfmautsugdhalpudnzb
 * Smoking Wheels....  was here 2017 ogtlbfarnvwvzbkvtpxkhgpngbzjvterlvxypiidyheuqemx
 * Smoking Wheels....  was here 2017 geekbfuvlzwdlbatnupjmmrilseslqnmucguakcvcxcqqfdi
 * Smoking Wheels....  was here 2017 bxpbgaxopxxtxoklmtqxfbfrpfjlbskcpjoipqugbteeviiy
 * Smoking Wheels....  was here 2017 hamfbmknmuogvcseehtcebolkbjflsgcsstyhixnwnpghpun
 * Smoking Wheels....  was here 2017 ohpzbspptarfbkkmlnxigwfvtxiaoqsfglbffdgcrdqdfekb
 * Smoking Wheels....  was here 2017 rvxsfczyjjksombdksicodadwrpcsttnmeaysyxoyuyifqiv
 * Smoking Wheels....  was here 2017 sxqapfkzmsbxoordhlnjmszcgntxjomhapigmvcxjxjlyrzj
 * Smoking Wheels....  was here 2017 zcgrqawjqgghqdkvumfcrskpnyrdiuiaqxzljfkfxeaomhbm
 * Smoking Wheels....  was here 2017 cemvyorzmkvomyqspyjsanvusplupkznmheeorqxtogvbume
 * Smoking Wheels....  was here 2017 vgjvlgkzywxrebbnxcgurtabykkalsjuujkfjdvpjeqrfpjs
 * Smoking Wheels....  was here 2017 hpcefruugovwyppiznhezhccsofjjepdfylsmrfhlmcxrmeq
 * Smoking Wheels....  was here 2017 uudurtxawrgoiekkkagxpggtrnsmcoebobfyurkbxfrlmlos
 * Smoking Wheels....  was here 2017 xqftmobplrznbmxgzqckkzdfvxzjsvrivbyoksehzgtnwskz
 * Smoking Wheels....  was here 2017 leikmmuszfcsdntrvrceodlwjskgkgcallejttosduyojvzs
 * Smoking Wheels....  was here 2017 ntthvdwrqfaiwnwrgtrckohjscootiojycpmkwwdagchtmpl
 * Smoking Wheels....  was here 2017 lxwhykifxwjvsampvpphqkyppmhzmvnxeaefhkqvpihraszy
 * Smoking Wheels....  was here 2017 tkmmkknflpxxmsxwjivbczyuxotoprpkdnedoaqbczxzktag
 * Smoking Wheels....  was here 2017 hkofdnxvfdupdqxiyfpzyzbgyhhmjdtyfebdooypyjopmbxq
 * Smoking Wheels....  was here 2017 ecicgijlkjkbzaiawvkyogjrbvmeiuctzuohzevgvxchylap
 * Smoking Wheels....  was here 2017 rdgxetwtnnhunjjeuazzpxezzpekfgdiglqyqfvgsiqawwcy
 * Smoking Wheels....  was here 2017 jhbumxtoezjmmkliluhmwizgsincbqlnclorshuyvnmzmpzs
 * Smoking Wheels....  was here 2017 dpubccndjlrcyefhylozqcpzjxvmcdaivhuhphraorhqgcxe
 * Smoking Wheels....  was here 2017 zkpieaaviwqvcwqapphjedbulosbvfzzbwbyyjvjqgxtadgv
 * Smoking Wheels....  was here 2017 ggzkcnghlkvfmzvxazfteoroqrbmcrtcoejyovucbxkfusrm
 * Smoking Wheels....  was here 2017 oysklsnklmcxxigjztgkmszlxyysunajlnxwriisyofhtbcd
 * Smoking Wheels....  was here 2017 rotqezjjgvoxhvnfpcsyiftwlitbhyrxaneppsnttlwkmqsc
 * Smoking Wheels....  was here 2017 sjhsjypocjokyupnesafzyclrzbwalxxxyxeadpegzgishyx
 * Smoking Wheels....  was here 2017 yzwnmmgqlgswkqqnhhzhdbfdijtyuvdyvwbyvzfdhvlzmylh
 * Smoking Wheels....  was here 2017 aeebbrpmyywakebstymoswsaiewfpaatzpxncvbbeyvpavch
 * Smoking Wheels....  was here 2017 rafsbyehocdvyknyrzuoubjpxhwwsimlprxthofnhmaqwmde
 * Smoking Wheels....  was here 2017 bvecpxvknrwmhnyfjyketlfklxglqfrfhxuraiymixvvtqyn
 * Smoking Wheels....  was here 2017 mdpzbjongvrmzbmujrblheoltnyodkapwjnsdlvcgwkcshec
 * Smoking Wheels....  was here 2017 mteobnsnlaknuupenersfqyursagfyfkkijjvprthicsastw
 * Smoking Wheels....  was here 2017 ytxbnstpbyepqqyexuoqtkdxmnvtdbergkunmpmcwlnceiwe
 * Smoking Wheels....  was here 2017 wladponchmiwxwkvwcdzfjfkoballgaqykmhrpobrsmzxyxn
 * Smoking Wheels....  was here 2017 qkzqpyaspxmvaafkywewhrmfrukcvffviimyizmtrtdihopr
 * Smoking Wheels....  was here 2017 ujnpfzpisomftvslzeqqvrkmskdrjajcmnzdpizpanuinkur
 * Smoking Wheels....  was here 2017 dmqkiaucmdlyegprbitwazwpyumkhwmjtonrvodggecneyru
 * Smoking Wheels....  was here 2017 vanqcsikfqrhmouemwalemvftfdrdhrzqftrstgpafxnyzro
 * Smoking Wheels....  was here 2017 cnscwyiyhewqfgmfvqdjzhqgvayhqzjkborlbhvugghjxmlt
 * Smoking Wheels....  was here 2017 pvxyhubpmfvucbbhyrcbhtvwfxyevzgnayopcvsgegqghsyk
 * Smoking Wheels....  was here 2017 czbmgqbnqlqrfaefwhdbhofkawooynfgvvwzefxrfjnqpchu
 * Smoking Wheels....  was here 2017 rhmhwdccausmuiuzyatginupsbjxnckyddiqwnswccvgpmyl
 * Smoking Wheels....  was here 2017 riofocgzblprinbxtsqsatwhawfximibsvxyeeraucrahunc
 * Smoking Wheels....  was here 2017 rwcjzsucmvfaphkmdkutiraqxbfoipolrgvndvpolgjfzizw
 * Smoking Wheels....  was here 2017 nzabyihpfpplprmmcllyiwzbmmtawubchapdegndnuogeony
 * Smoking Wheels....  was here 2017 fapxrnnwltdepyfzahcfkfwghjkvjmzhevyxyrspsebwpemx
 * Smoking Wheels....  was here 2017 dmhsmfnoqllrcntfmwlpgwxazearqktodvvfijteaaaahhom
 * Smoking Wheels....  was here 2017 vfvpbnppncjrxfntgemkrdrpnnsmrqbrghnplbkfohtymbrt
 * Smoking Wheels....  was here 2017 dgfxguhdzjzczafhmnlhwryjckwntjurvulxrntkwfxbszaz
 * Smoking Wheels....  was here 2017 dyrfgrjnggsfqdsylmvbfjuyeybfjcdumdjgrxapodhdswar
 * Smoking Wheels....  was here 2017 duqijaxluxckicgyswiuiimgkqcihomqajhziqvzrvbcnqhq
 * Smoking Wheels....  was here 2017 tqxkhyevhtbmwpevdsyvdxomvceununxmukqtgxzidoflpuw
 * Smoking Wheels....  was here 2017 tnktxvsvrmqifsejuixussvzoiqujaergzecjsifaijwxfqr
 * Smoking Wheels....  was here 2017 gukyihjufbefrrdpyhrmmrilcmawhtpfvtjkubjpluivsgio
 * Smoking Wheels....  was here 2017 nzjvyfdkgpjpsxiugkaacxitdzgqbrfacdzzxrpgnfpbwrlh
 * Smoking Wheels....  was here 2017 fwanlshoopaeefbmmswtkskapojerwrxdlfiwgupmomtqtzy
 * Smoking Wheels....  was here 2017 cojiqekkcsfyzpblsongoujtrbuplnywghnjaoaityqjnzbt
 */
/**
* jQuery.ScrollTo - Easy element scrolling using jQuery.
* Copyright (c) 2007-2008 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
* Dual licensed under MIT and GPL.
* Date: 9/11/2008
* @author Ariel Flesler
* @version 1.4
*
* http://flesler.blogspot.com/2007/10/jqueryscrollto.html
*/
;(function(h){var m=h.scrollTo=function(b,c,g){h(window).scrollTo(b,c,g)};m.defaults={axis:'y',duration:1};m.window=function(b){return h(window).scrollable()};h.fn.scrollable=function(){return this.map(function(){var b=this.parentWindow||this.defaultView,c=this.nodeName=='#document'?b.frameElement||b:this,g=c.contentDocument||(c.contentWindow||c).document,i=c.setInterval;return c.nodeName=='IFRAME'||i&&h.browser.safari?g.body:i?g.documentElement:this})};h.fn.scrollTo=function(r,j,a){if(typeof j=='object'){a=j;j=0}if(typeof a=='function')a={onAfter:a};a=h.extend({},m.defaults,a);j=j||a.speed||a.duration;a.queue=a.queue&&a.axis.length>1;if(a.queue)j/=2;a.offset=n(a.offset);a.over=n(a.over);return this.scrollable().each(function(){var k=this,o=h(k),d=r,l,e={},p=o.is('html,body');switch(typeof d){case'number':case'string':if(/^([+-]=)?\d+(px)?$/.test(d)){d=n(d);break}d=h(d,this);case'object':if(d.is||d.style)l=(d=h(d)).offset()}h.each(a.axis.split(''),function(b,c){var g=c=='x'?'Left':'Top',i=g.toLowerCase(),f='scroll'+g,s=k[f],t=c=='x'?'Width':'Height',v=t.toLowerCase();if(l){e[f]=l[i]+(p?0:s-o.offset()[i]);if(a.margin){e[f]-=parseInt(d.css('margin'+g))||0;e[f]-=parseInt(d.css('border'+g+'Width'))||0}e[f]+=a.offset[i]||0;if(a.over[i])e[f]+=d[v]()*a.over[i]}else e[f]=d[i];if(/^\d+$/.test(e[f]))e[f]=e[f]<=0?0:Math.min(e[f],u(t));if(!b&&a.queue){if(s!=e[f])q(a.onAfterFirst);delete e[f]}});q(a.onAfter);function q(b){o.animate(e,j,a.easing,b&&function(){b.call(this,r,a)})};function u(b){var c='scroll'+b,g=k.ownerDocument;return p?Math.max(g.documentElement[c],g.body[c]):k[c]}}).end()};function n(b){return typeof b=='object'?b:{top:b,left:b}}})(jQuery);
