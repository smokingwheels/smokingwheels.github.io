Sizcons
_________________________________________

http://www.randomjabber.com/static/sizcons/
_________________________________________

Sizcons is my own little icon set. Sizcons, if you couldn’t tell is a combination of my last name plus the word icons. smile

I will probably add more to the set later, but for now, I wanted a few icons that I could call my own, which were the exact colors I liked and that I knew I would use. I didn’t bloat the set with ones that I knew I would not use, so that’s the reason for a small selection.

The icons are free, so use them however you see fit. If you do use them, it would be nice to get a link displayed somewhere on your site saying where you got them, but it’s not required.
 
