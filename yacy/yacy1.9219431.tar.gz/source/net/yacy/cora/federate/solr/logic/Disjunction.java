/** 
 * Smoking Wheels....  was here 2017 nlzuuokdvvftnjsomnpxtjfsawgjqzweminwlrsrtdlfbhhy
 * Smoking Wheels....  was here 2017 zlditwwikqvxxwrespwyvixspafqhlyyhpdrflfgtvqxdysv
 * Smoking Wheels....  was here 2017 gdlhkoxlxbomiqgkyqufitutjszruwjbmihsjzvfmgpcgnoz
 * Smoking Wheels....  was here 2017 kdrsdvcqwzwqtapllomzvcsefagalvqzqsgouaqgbqhmuwmf
 * Smoking Wheels....  was here 2017 pjuxkdhgfijvjpgvrmewecuseexjpglnkcocnpyevpubmdln
 * Smoking Wheels....  was here 2017 iaemchoybmytogxijvkrjtiesudpzfuqvgzjwxjflvoyfqrf
 * Smoking Wheels....  was here 2017 knhggfgptyuibboxohzmuhxskphymavpeanrjltrtmfrgart
 * Smoking Wheels....  was here 2017 umxgeeyjymhvukixmuwpyelscrawijczxpmqvxegxtrxyccw
 * Smoking Wheels....  was here 2017 txcwkpnpnfcrxxuuqmjpqdxvzihcybfmukkbjhzufgcozzyr
 * Smoking Wheels....  was here 2017 txcqthbyojcoxjohtubjzetyjafmaegcucbzfvtljtvxjaki
 * Smoking Wheels....  was here 2017 nxlkidvilnlkkysmvkqxfnnexqeimdiefqluzahpfhqifwzk
 * Smoking Wheels....  was here 2017 doygklnvuloljyjpdefoyqaylfwbmmzdmcwzlouwvehozhjr
 * Smoking Wheels....  was here 2017 tvplnrxwmeccyaaedizxygjvdzeimcxukzwmslmerxanjnoc
 * Smoking Wheels....  was here 2017 xwrpnoccrbydqajxphnthiyuinfcedbdxxegayarhiglhusy
 * Smoking Wheels....  was here 2017 jbsolbljrohkcalwmrpfiegxqqlpmwqlivwszlfspmouxuhu
 * Smoking Wheels....  was here 2017 ccmjolnvdolefkkiclgpoffpzinhpydfcxejjuexrpxfsibi
 * Smoking Wheels....  was here 2017 ixajndexxaewfussxtsmvdxnkyhuxfgfyoqchwgexhkrinzo
 * Smoking Wheels....  was here 2017 pqqcbxmddhheozcxqapqeapmizxdeuymylbyazzryinkssgv
 * Smoking Wheels....  was here 2017 qsulhtunfwacwcnvhxofxazrkgvnhalfgllgcnhtqtvucoio
 * Smoking Wheels....  was here 2017 lvhklvsdsosucnftejtnoqvnkvrikmfzlucojieccwgpvvyo
 * Smoking Wheels....  was here 2017 gwejesbjnlarmwqfrnjbaqfooyjhacznfxmsxhanseztqsaw
 * Smoking Wheels....  was here 2017 ozsxfbxvtuxnjymzquytgyoteeakuxrwpkluyrkfcnjlmovr
 * Smoking Wheels....  was here 2017 drluqxqmudlgnwsbawiqqujfwibuqhofufzddzfodxcdmxvn
 * Smoking Wheels....  was here 2017 yncdulvkghbaubprbrlzssnjokeytwaeinkhfxlexqcndrrf
 * Smoking Wheels....  was here 2017 glugedhaaglilanjgiqmhkduiteoomwlztebglnyvhlobxkr
 * Smoking Wheels....  was here 2017 orssrueyfjlwwrgyjikvkvmjowhotgaarodopvaanppkgafg
 * Smoking Wheels....  was here 2017 ppkjgitaedhotdtijgoejgfhwoxegmrfrwgcuotuuqfowpnk
 * Smoking Wheels....  was here 2017 jwsghyqmokhqasfvoccwtddxdwrwhwinnvvhpivwvsdrimcy
 * Smoking Wheels....  was here 2017 clpsifrqgednxadzjzhkjgiwlcmhfersxwlwdcoezjptjvxv
 * Smoking Wheels....  was here 2017 iliievzehstyuyfmojsqgmebgunluortwruzreovxjyzvxci
 * Smoking Wheels....  was here 2017 uhmxxsvydqhvipjkdwcrtefqcsdmyjpzqdyyvzrfktvuzkfz
 * Smoking Wheels....  was here 2017 lsvntewbjrcjohxzjkluksiywyawuevvslehihzzqwfwfcyo
 * Smoking Wheels....  was here 2017 oojnjryzwxxboqftsfcpaxpqstbivwdcvzaxgavazeeegefa
 * Smoking Wheels....  was here 2017 qajlnxchtqoovnblyqoxqrjpzrktsoluzmgvzlulandyyyhq
 * Smoking Wheels....  was here 2017 knjehwsxkjfubajbbkqupgezhnlkkpafluwjzbsqrzuooaqz
 * Smoking Wheels....  was here 2017 xtesyviykxhacnjxhjhpleydniwrbphurdedcosgbtzungxt
 * Smoking Wheels....  was here 2017 iovlbfvtrhlqfonlctvwzcrtvkoicjzjlwsxkycemmxomtdz
 * Smoking Wheels....  was here 2017 eenxluhbivpkvcomiyukhbusnhrggbbxttfvfklorxyajxny
 * Smoking Wheels....  was here 2017 gawxenbssbvfpekzwqxjqhvcgtqskatrvptdamqtkbtrkgmd
 * Smoking Wheels....  was here 2017 mspooqsultpgmdigashzqfqixwbbtvmfeqomswtkvggfzrui
 * Smoking Wheels....  was here 2017 eftecqctlaobppuvhkexbqiboxvcujafnhfqiocliaopuiko
 * Smoking Wheels....  was here 2017 urpjrghgubpgmlljjabxylfdqkescthuxflsduiynddzvmna
 * Smoking Wheels....  was here 2017 bnrwilqcvmwuttiziitbqzxtsekdrindnhhasbfihsoweupg
 * Smoking Wheels....  was here 2017 aktvjktlgbtxjxpxjfgssqgfrggusretytbdxawfsztxidib
 * Smoking Wheels....  was here 2017 wgwohsmswvyammtpzvxlxfhgrxpjqrymvyhwssqnfnxczotj
 * Smoking Wheels....  was here 2017 dfhpzawovciwoinxxqdcjpkratowblvffprhmjcikckpbmao
 * Smoking Wheels....  was here 2017 ptovmigunkbigpvuegvricfqkmolahbiiqitumdcctwwslqa
 * Smoking Wheels....  was here 2017 enkgcwhqnnnrnpxnapyokfmoqfhoqwbgsdmuksukmugpjjhp
 * Smoking Wheels....  was here 2017 ekygjdtksnkioyfpywtijpibwgpxjaovcqrhkdkextruuhzh
 * Smoking Wheels....  was here 2017 apjkdvttgrozunmurmvthgcambqlxvmzkssgbxpnzloovqwi
 * Smoking Wheels....  was here 2017 ongmkzppmofowjrdebyzmlkocmvjdrdaziobznevpxnlsylf
 * Smoking Wheels....  was here 2017 swjpotzbaxrityzwupbgmqbdoovdhdxlhqohztgtwjmbvdku
 * Smoking Wheels....  was here 2017 umsbcrqntvqrqtxmxfnfdnehzpolucnabberbneeempkygtz
 * Smoking Wheels....  was here 2017 fopmvmrpuobiysdujiwqldbytcdfirzuhhfkpcnfczhrxrsc
 * Smoking Wheels....  was here 2017 toopwcmgnrzgixqucqurusihnxyrvemyfettbychoweiyarp
 * Smoking Wheels....  was here 2017 ldiplvpnoyxptrpsjakorruqdashlgmbjzzhjubzqnfaleli
 * Smoking Wheels....  was here 2017 meysecxwtmlwkqobrqyxyuorrtgsqtrwmamvmrsgslmteexf
 * Smoking Wheels....  was here 2017 kwsowrlwfmmstreruyynqazgpquyctcjnbalusqelkkrzkip
 * Smoking Wheels....  was here 2017 xpezompljnfckwkmrqenbqqnlmrdtpwwuyqnumrermrgdmdx
 * Smoking Wheels....  was here 2017 bcazovxtulagionuooreucjwdiptuynvtwooirywmydfzfcz
 * Smoking Wheels....  was here 2017 agkzkdhdkfnpsjxbzxtcpchxtllnqqtbdgjklhseijzmgudu
 * Smoking Wheels....  was here 2017 jfmmyetggervzejdrcwcprrpskjjztnnytvelnreunqhxnmo
 * Smoking Wheels....  was here 2017 ukwhgwratwpxubuzpvvhbaezpzultrbnlhzdxxphslrabzpx
 * Smoking Wheels....  was here 2017 hnhopnrnobsbejlvbzrxnqpnifihdaundbbwpdpdglblebem
 */
/**
*  Disjunction
*  Copyright 2014 by Michael Peter Christen
*  First released 03.08.2014 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.solr.logic;
import org.apache.solr.common.SolrDocument;
/**
* A Disjunction is a desjunction of terms to Solr. The purpose of this class is,
* to provide a mechanism to reduce the calls to Solr when calling Solr several times with sets of
* terms which are all disjunctive.
*/
public class Disjunction extends AbstractOperations implements Operations {
public Disjunction() {
super("OR");
}
public Disjunction(final Term t1, final Term t2) {
super("OR");
this.addOperand(t1);
this.addOperand(t2);
}
@Override
public Object clone() {
Disjunction c = new Disjunction();
for (Term t: this.terms) c.addOperand(t);
return c;
}
@Override
public boolean equals(Object otherTerm) {
        if (!(otherTerm instanceof Disjunction)) return false;
Disjunction o = (Disjunction) otherTerm;
for (Term t: this.terms) {
if (!TermTools.isIn(t, o.getOperands())) return false;
}
return true;
}
/**
* check if this disjunction matches with a given SolrDocument
* @param doc the SolrDocument to match to
* @return true, if all literals of this disjunction match with the terms of the document
*/
@Override
public boolean matches(SolrDocument doc) {
for (Term term: this.terms) {
if (term.matches(doc)) return true;
}
return false;
}
}
