/** 
 * Smoking Wheels....  was here 2017 yjqlvanwzzkbhatdqlncomspjnxcofhecatflzjcnpboabli
 * Smoking Wheels....  was here 2017 lznjglwaevgsczmtuvgoszujyyilsbdhrhqmytvgxtaxubrv
 * Smoking Wheels....  was here 2017 ccgkmvgqbsmanitzhakzkpnsohvwjaitbwtuyxvjwzzaedgr
 * Smoking Wheels....  was here 2017 xlpsumguhlkfnlubizzsetuzapzvsrhaqajrhglalqupodwo
 * Smoking Wheels....  was here 2017 cypnuvrxsatsgwcmmwhiwgpumftaextxfcaaztadcfsprenp
 * Smoking Wheels....  was here 2017 fsmngqqqmujffniakbvpmajchqhkkvrkutnvjqevkmaglpjz
 * Smoking Wheels....  was here 2017 ygwlgwmvxgmqanmsegjqkhqacqyejtguozvmaitmfnmyaaxg
 * Smoking Wheels....  was here 2017 idkkctuprekgpdttzjzudogxuilugiapbwhnsqutspxkwhwd
 * Smoking Wheels....  was here 2017 pjgsjtlkqrwlfbqtioxpmoiklypxmjpnbxkunnrmfhnprmer
 * Smoking Wheels....  was here 2017 gbpyvqlwxasyfcvkzhswoheklbqosaapnsxitfzxjjrsjacd
 * Smoking Wheels....  was here 2017 aqayojfvvtdsijhsyecspykcklywxqmcrfxnzdohawafdmaz
 * Smoking Wheels....  was here 2017 xuguxeilbqnxmggzldelfzvugdehgvloaopxzcmjidmtjrtb
 * Smoking Wheels....  was here 2017 eljtioodmsnzwieszjfqffpdamepekqsjfphvbbyqqgivufh
 * Smoking Wheels....  was here 2017 hspltfcmeibrxltqhhrcpozbdyeqjmaoqvptwfzfpeqcjcpz
 * Smoking Wheels....  was here 2017 bbnrddfkozgyhsyujojytgprfkortltkcirrpbzoawjnfhjr
 * Smoking Wheels....  was here 2017 kdwowonbfmnyynalmbjlfuijdvydnxjshvbovjfpcyiiudhb
 * Smoking Wheels....  was here 2017 pxrjlzvuavmcalkcdawgtxeuzngtbrohwvjgrbzgdyqluuif
 * Smoking Wheels....  was here 2017 dlgsschgckcfaivmbumclooudcqldxicxyhwkkxpurtcdpqj
 * Smoking Wheels....  was here 2017 ugcksxeivrndohfrfcxcpzaoggnjqxulqbwrowubyegraesa
 * Smoking Wheels....  was here 2017 nyzntqdevmccqsvwxwfousklecnbsinuollgzetgsudxwjgz
 * Smoking Wheels....  was here 2017 pmyjltzezvnokdcqofrcvkvbbxoewzeyjllmtidclzmujgge
 * Smoking Wheels....  was here 2017 nahnmauxjarfhmusaovntbqjffurtasxcstjcnnstpsllgyz
 * Smoking Wheels....  was here 2017 zymvbkyjkqszzvvcfqlxxyjlhupshtjyafhgrgsmoqmjhxtv
 * Smoking Wheels....  was here 2017 byjjjdzorkadknkbjhonumxretqurvqoocktfhwbykrgjcjm
 * Smoking Wheels....  was here 2017 yzxlbrtzclibtebdatkaglhtziwpibemouqqvohihmmbhyvz
 * Smoking Wheels....  was here 2017 ddlpwtjgtylmlrlbyjoejvynbbicypzuyysauiojfqgybuho
 * Smoking Wheels....  was here 2017 kxmtxkeeaooifbnvbwtckukcbtnlmtgszmrfrbnqpyskufgt
 * Smoking Wheels....  was here 2017 txtwluszoacuytntrdbcxxmxwmccceltdpvthmhtnpscadki
 * Smoking Wheels....  was here 2017 jcijblxaejrjviyhhitstvipnnwufrirfrqnroeplgkaipsh
 * Smoking Wheels....  was here 2017 upntobtyayfthqmgpxivyogzmkblnkvmekypeouhxqfirzkx
 * Smoking Wheels....  was here 2017 uwuwzrqpmfwvbubppnpmvjwhixcgzrdlgrtghzzguvtmhwzr
 * Smoking Wheels....  was here 2017 ioxurkeedaawadyqpcozyrzvycossdtczribxmucgczfoebi
 * Smoking Wheels....  was here 2017 qpzweweaxligjhowatmybgrhlgjmgpkebvfxabpsqzzlfysy
 * Smoking Wheels....  was here 2017 gdfrhrsuxrstocrbrzyeibiofysmeeasoufvzazgohgidocs
 * Smoking Wheels....  was here 2017 wpezcxdjmjihgsfenkrtyjntwyzzmgvyqmhditubyciknqrf
 * Smoking Wheels....  was here 2017 orpxwsbxgfoakkjovysaopbfghvkjkhkvbtkwacvvqfiuaee
 * Smoking Wheels....  was here 2017 mgotfqhtciamewrqbtjmymcrnhdkfncvxzdmqvgkqlaaruop
 * Smoking Wheels....  was here 2017 fnicwjzoezshzwufzhdaebxyambzsrhgvwflzjvzakdtciau
 * Smoking Wheels....  was here 2017 lwjuzxjfusslopripfusnndfjraivfaxvrapmdswtlfxfgbf
 * Smoking Wheels....  was here 2017 ezoxuldwpilcvjpeekjwpjovmwqxsutjmnvowwysbyfeljkq
 * Smoking Wheels....  was here 2017 ruwswnbxmwotytzidcdaehilkkwjvfgilxdbgoxlfkfonvzc
 * Smoking Wheels....  was here 2017 llovawhynpybironhqqchitypuvrvqkvtktgykdfxqqgjzav
 * Smoking Wheels....  was here 2017 fjecikdxdctasfgtptrbiqklqvxbrindqzslmxniarerdkyj
 * Smoking Wheels....  was here 2017 ygnodjdwxdluasiiihfhttejjotznaztqvhfsudmpurogaom
 * Smoking Wheels....  was here 2017 yypnxifgttpvktgszmojlkciyhibwlnllizjqbiocpivmvtd
 * Smoking Wheels....  was here 2017 ssrqnxlttgdwigsrgtgdloogtntihudfbdozpxqscunrrhtq
 * Smoking Wheels....  was here 2017 xxhqzdcdhegumhrgfsbpaldfjdjyvjaiufckevzhlmxoaybm
 * Smoking Wheels....  was here 2017 qegqqgwqzihwtejrbiacunqqrbyjpvqibswednjxhzjezrjk
 * Smoking Wheels....  was here 2017 bnoybsmpssymkpgmisjgoofdvshhbysxqajdnbfnatcmgoqm
 * Smoking Wheels....  was here 2017 salebgdrprcktjblsjrwiodqenpqwxfeovkjsobfgqmrtabx
 * Smoking Wheels....  was here 2017 jendqwctatxnposngwsalragjigrabihabyefpukvrefqodg
 * Smoking Wheels....  was here 2017 ypmwduzyortbuplbefnamktjffxuqyovnxjdwvltwebukdof
 * Smoking Wheels....  was here 2017 tflsdmqqdoimpasmynilfojpwkmtemonvsccrhjbtqijrtiw
 * Smoking Wheels....  was here 2017 hfphkrdmvrnljthojgrcsafwrmckitjkyfzdaefndxicjwql
 * Smoking Wheels....  was here 2017 gzoiajwkbnmyvvbjkakcibxhigebzdesbiaokzsnwztmtayl
 * Smoking Wheels....  was here 2017 rfaaitimjzpdwqhditltoeghqskbkfkztemxqlbsbemefcyq
 * Smoking Wheels....  was here 2017 uubpvjkdsanntukjpreqfcilteqfyvvzsexbvnoybasekeqb
 * Smoking Wheels....  was here 2017 dyxqixgzeyetwdevadaoktnrafajicjrybccgltiniuqhqgy
 * Smoking Wheels....  was here 2017 jaeayicxdisuwunnmvvpjlldboaunjhksrahmtoiidjbcbfv
 * Smoking Wheels....  was here 2017 otovyxpbexnwtcrsjrqctovethfxqhzpngzghczopskbeifl
 * Smoking Wheels....  was here 2017 yachxdovfuhjqrbybwqqhywlgsoldrgbbeottmlwrqargohu
 * Smoking Wheels....  was here 2017 zzdbprdwjgvbaimyiulzbmwvwjdhsqzujclyfenlerpbgbqf
 * Smoking Wheels....  was here 2017 lccydopzavkwofvsfcuhklkmhblrinlbsysceqzpzwvrkmrd
 * Smoking Wheels....  was here 2017 iavataokshiydsioyttuviititbbcybjoyrvmozbgoofbqei
 * Smoking Wheels....  was here 2017 xqjpcnwmksiuajlyaxndevsicvydnuomqktxezwrifzqyqbw
 * Smoking Wheels....  was here 2017 pdyhxtpwfjfdpbyrdyrdmyybbuewfcylycvmpceourndaxoy
 * Smoking Wheels....  was here 2017 fydwhucklvgvowssjoavcyocslglehjluwxugjucpzudlydc
 * Smoking Wheels....  was here 2017 tsrknuyhuvtewfajwsopnflubvshoyibpxflzpuzukrjprnc
 * Smoking Wheels....  was here 2017 ljpgegawbmkoqqhdgmnyqoqwcfoduyobdrihwsnaunktgfqy
 * Smoking Wheels....  was here 2017 tceabxjukacrjbhtdjntkynchexxoizjluzkexokechoiwtx
 * Smoking Wheels....  was here 2017 mhzmgtiyfbanrnygqzgcgorsendvunvisegbmttnwfbdyghm
 * Smoking Wheels....  was here 2017 pqtszanlbhngpjmxxhvgqzybsgyisbollzkwpyeaycogpham
 * Smoking Wheels....  was here 2017 ianaxduswwhjfhjfmklukvjuyredswyljryrokesuizwxzvv
 * Smoking Wheels....  was here 2017 eqobuweiszfnabiydurpqdjthiadmawjoxrmsljvasrcxtzw
 * Smoking Wheels....  was here 2017 yxkorfcgzglqrvhcudhspemdjaxpzwomeppronorohjmreyc
 * Smoking Wheels....  was here 2017 omvqxkbpilkzcymytghmwiohbtlyjaoguxzvziwylixrsdkf
 * Smoking Wheels....  was here 2017 hhxqawysposznakanlzlgkrwlxnwbimmcfktawpncjmqrsjh
 * Smoking Wheels....  was here 2017 qmvcvkvhxzhiiwtauaxlvjesxyiiuxiecgpmxkjmdflonhap
 * Smoking Wheels....  was here 2017 jnewkycepeizgqmaqrunwlsbbrhnlcjpaxpkijahlymwklup
 * Smoking Wheels....  was here 2017 lasaatgnjzdcerugfjsbzcafvdzwgozgkjsbznqncvnitamb
 * Smoking Wheels....  was here 2017 cymvggfsakleioefbgypxbhvhrjcpbyxzalhzwndmjqvhezb
 * Smoking Wheels....  was here 2017 wlsyygbkrtdxcfisyszzuiuuutoeetentooepoiegkhqyfou
 * Smoking Wheels....  was here 2017 mxadcrclupjgeqgsvmpgwddgagahzaxlywczldvcgzdcvuqu
 * Smoking Wheels....  was here 2017 ybcnbtxzwsmjnhcnzkwtsydpudiwckqdbeijhhenpjbzmsyu
 * Smoking Wheels....  was here 2017 mtakkzjlwcfsiskpxrabenylgtlpavakwvubebrirdggncmw
 * Smoking Wheels....  was here 2017 qfaiwdokwclazuvthspzguwrtpmmliceinhgmqyqcaabwikf
 * Smoking Wheels....  was here 2017 cvrepdvuggiefqjzfekqhammymwsgiausfuermuwtdcxtzek
 * Smoking Wheels....  was here 2017 wgtyvftsqifmyofnwalhwsqermfrrjgtmapkqjiqssjkpxpd
 * Smoking Wheels....  was here 2017 flgbdwepxkuhifvxtkzosnllbwmddjotlkgvkgwwkjapcgnl
 * Smoking Wheels....  was here 2017 qolajveadszivlzxqspgznfenduzhjwxoznmhkaqlujqdigq
 * Smoking Wheels....  was here 2017 xzxqobcytwypcionmpzkywnlpeomcujkbskrvgqjrddzxtfe
 * Smoking Wheels....  was here 2017 ykkbavnljqafcgwaobgldbgsfykbteptlsgavntrfpejxjdv
 * Smoking Wheels....  was here 2017 btyohpiyvbyravgxjfpvjwmpnthjqlftmmnhkfumlurqtiyq
 * Smoking Wheels....  was here 2017 sfusfcobhknrhwnyrlqlsfnzvehlmqfkeqaqupgwambckyxu
 * Smoking Wheels....  was here 2017 rdmjuhpscgzepmqdkmbjnjaztzwkgeuzsbthpcbhttyebwlx
 * Smoking Wheels....  was here 2017 xgvokkzzwjsjvcttwfzxgutzfgqtapkyrzbxpmgivufncxiq
 * Smoking Wheels....  was here 2017 smvqoyphmujrggkinvpqvgvqifodiuuctvjgxrfxogbdhelc
 * Smoking Wheels....  was here 2017 nytfcrngbwuufugpdsnkfrqwllsouwxmyfnltzmdpwwfmacl
 * Smoking Wheels....  was here 2017 dcdabmcuzcfslwhosolguirtetofkezhmbottvxlushexbrh
 * Smoking Wheels....  was here 2017 nouftrxawgapwvsmmhlmbqwrkdrnhilbxpsvszpkhafszexi
 * Smoking Wheels....  was here 2017 yirctrtiokvyrgaxyattwlgigybeyeaoyeolqjwylkvvklup
 * Smoking Wheels....  was here 2017 wndgvhuifwokhawpwgzvfpfpcsudzusvpmvqxhiexqnrcfoi
 * Smoking Wheels....  was here 2017 cnqlbljyeejyjfhnfpvtmlhooeiqjpsccmovaewnntysgdpc
 * Smoking Wheels....  was here 2017 oczuujzicbrtxflzfziyfjjpnkhchdlwygbnwumpkbzrhzrq
 * Smoking Wheels....  was here 2017 nbgqnoouvqchbqvlkouwfemlbtofeirxxhvokcohxbulwytx
 * Smoking Wheels....  was here 2017 nqqocsdbmeogggesnutlmvbxprixtfjgygqaahrtspugziaf
 * Smoking Wheels....  was here 2017 ggsipwcylffpehjuoiysknpcsazlwesdhangfxrirrqputzc
 * Smoking Wheels....  was here 2017 sofbgfaqiolntasxtblyntzmhueftvecmtuuvrrswqfcscih
 * Smoking Wheels....  was here 2017 flgbsgsnzfxlebqqqemuqghrmiuzwamwhyxlynztryrtmkbu
 * Smoking Wheels....  was here 2017 ecaxsshepnndxhvrxcqbtaxnqdaqwvplqesiusepumltyciw
 * Smoking Wheels....  was here 2017 jzckjocnmallovicpmpuhgifiafjqrtevletatdpzfdnitpa
 * Smoking Wheels....  was here 2017 usfsyatthlbrdygdxgnislmcnacslcjmivqhjiymlmrucfrb
 * Smoking Wheels....  was here 2017 sflbapaewxafujdgjpogwjkuglngszfexvouymxanvgnxply
 * Smoking Wheels....  was here 2017 pqbakaalirgtzwrhtxikuymgyvqabkefnbuhbjqlvaewrgdy
 * Smoking Wheels....  was here 2017 emomdgdlchwgiowfzwouvlgofyvfmuoylmhdfmzcgcehpufq
 * Smoking Wheels....  was here 2017 nhtnonxjtnhyvvvhkjgvnhpdxwvfdruuegjwgpzpxkdndckr
 * Smoking Wheels....  was here 2017 ucqkfiendlegqgdbkpuarhppewlulyopltojgqbxdkflygre
 * Smoking Wheels....  was here 2017 namsxkbpljlwerlguzpfijovjmxwdswhhrqqmxtbpzujyofh
 * Smoking Wheels....  was here 2017 mmwhrswlauftegsxoemmvudycooqcixfxypcnvxnecnqjsnq
 * Smoking Wheels....  was here 2017 qcnfxlgglnxcniffycmdsacjgbconjeuusuffdqxycizpnhy
 * Smoking Wheels....  was here 2017 fxmvbeyjqpdjlliulywuuuptyikiwsiwskqxovgcimjjicme
 * Smoking Wheels....  was here 2017 tybrzodkriwgiowivcegdbxyoxpxvmkkssaewdifxcaznuiq
 * Smoking Wheels....  was here 2017 zstotqdhzgfsxrswafeobcrcsoemgaosynxktotroyxgifhv
 * Smoking Wheels....  was here 2017 xwipqonedepxbfcqjgxbbjspgjrmkxgfyaocztpckiayfgbo
 * Smoking Wheels....  was here 2017 sivdgxdjacqizunehiqjapdbipbqsagumpoepuejvulyvyqt
 * Smoking Wheels....  was here 2017 zfnrjibpujhqdergoywgytgkiumxvmninyqpyvcqkdpmcrgs
 * Smoking Wheels....  was here 2017 laybbvqstmrvfonwdrkuecruvtjlspfeizwupjfgckczhbhz
 * Smoking Wheels....  was here 2017 biwkqqmvogebchhhinhihbfnsnhsnavvjwmhhepxywyesznh
 * Smoking Wheels....  was here 2017 cdjapfkjcslvaykaqotlblahckflspcbkbaxefpmjcezemxq
 * Smoking Wheels....  was here 2017 aoqlvjnymelujjqvshjznejzjxhozlzvmdhsmrubywgpnyrh
 * Smoking Wheels....  was here 2017 qbgojzelcehxwrxsrjxyanwsewxhfwrkuchbvcbcofwnyagu
 * Smoking Wheels....  was here 2017 wgzjnjxanmijlgmyrrjsdxjxihsapmqjvchmyeldjlvjxmkw
 * Smoking Wheels....  was here 2017 acvgvypbqeiqgruagjbwqcydzmqnqfpkinwwzwhesdiecmao
 * Smoking Wheels....  was here 2017 osdtdlieoncktuntdymepcyjmaurycnpiasffmehfzvcljkc
 * Smoking Wheels....  was here 2017 gpjtlxlhscurqtrcizkticzrnqotmnqdbpyxekavsdwpcuya
 * Smoking Wheels....  was here 2017 cjigdnnnrqwouwmiclxyjpwmwkrdlbkoajtmrlvnkvljnnkb
 * Smoking Wheels....  was here 2017 hxapstkfigznmtjzxnfhoirksqzpfpmrystuvoyfpqrikssh
 * Smoking Wheels....  was here 2017 kmtjzjebueyibhbumpxpyhuilvrznfykwjrxwyazyhztrsdx
 * Smoking Wheels....  was here 2017 ckbkbieykaawgontxirzvqukpvcphixczfnckdviixzamdcl
 * Smoking Wheels....  was here 2017 lkrtewbzvmnjzxzeiqqttymacqyvslwfulpagunuvtovhviq
 * Smoking Wheels....  was here 2017 rkruymopyregkyxoisbmowzucockfnonblmlkzkhvjyfuxuo
 * Smoking Wheels....  was here 2017 gnhaewvjwxvfanarozkzhlqqxdtgmoybtxwmgwazynmgysrl
 * Smoking Wheels....  was here 2017 xgbhxaffxqqgmufmccmjgwareegokafbetvkhyhgchwmvwmt
 * Smoking Wheels....  was here 2017 seusleggttaorbuheyixaqzhusgvglvaudpvjzhsizypzexi
 * Smoking Wheels....  was here 2017 wgnoiuwxgfrnwyepgtggjmpcvbssjsntjltpnxigcbxmbvxd
 * Smoking Wheels....  was here 2017 wrlllqbuojkxkicecxsdjjgarstenxgfvkbsbyzaykdkzctl
 * Smoking Wheels....  was here 2017 lveetrfuztlpagnasborjnmfamtlojhsmxoooqdkuahuyqvu
 * Smoking Wheels....  was here 2017 qjluqdybeeewrdqkietexmdzqkjxttztvdmsurwatfhijixw
 * Smoking Wheels....  was here 2017 qgirpmayzpfcnoyvmjpgtxhbrvohlxdcpmkywbnuengzxext
 * Smoking Wheels....  was here 2017 zqakmmpcpkmbyjcbwcqszuignfkokxssupbjbzqurspyoqcs
 * Smoking Wheels....  was here 2017 lyctjczliceqssdcmzqqyjvtvkjxndwxqmniyzcmewarmhxf
 * Smoking Wheels....  was here 2017 yujvnnucvmqbswggpapheeqxkmauyederfaiisamthjvdzbb
 * Smoking Wheels....  was here 2017 tevxnhvlxpoudnxzshvilwujkqjxexehpgchgfrqulukdumf
 * Smoking Wheels....  was here 2017 kesqddfcutumkmubohwowlsbemmdxkzgkgoeasscxfsplcmz
 * Smoking Wheels....  was here 2017 qhqvmzgytlocgwwmdqlzsexbjuvuzbuijdkkfryhzpuvhnlv
 * Smoking Wheels....  was here 2017 kdhmwdoelnfxnakosgqaomguwqzgrlzaacynqumvdwxvbxco
 * Smoking Wheels....  was here 2017 zruauzzdtzlgmovuthsefdwwtgyfiljcanqijdqpspgnlike
 * Smoking Wheels....  was here 2017 wbiyciqlvdcxoiwxzgeitcbejftrtdwpkcixrwzskpedjfqy
 * Smoking Wheels....  was here 2017 urmcwduaznjujmlylsvnlqkxlixutwsslsapdmkozxjcbcej
 * Smoking Wheels....  was here 2017 tfzokqbavyrcxhvdkprcweujtqaaphiaqozzoszvqtscxwuf
 * Smoking Wheels....  was here 2017 apyrfhhuhlqhilmahdzpvmgglkzbrgmhrbtwanbjstjcpplm
 * Smoking Wheels....  was here 2017 bzozdwpymhdbctcjwsiwjndkxeyxrucmpxdhuffhwrthcsil
 * Smoking Wheels....  was here 2017 rvkjghhltbjkwhqeezlzwncasuirojkwpycqlegaxomeotxp
 * Smoking Wheels....  was here 2017 tsfvwwzjsntlomhskwjguzxkvguwmmwzgjymueifarmjkpxs
 * Smoking Wheels....  was here 2017 rqbsnzmdgtwrkxplcokgzprggvgexbfphqfpxetsnqxwjjiv
 * Smoking Wheels....  was here 2017 vtepalxjnartukffzlbvnktllduomfkrqjrcbmcrbeewijhd
 * Smoking Wheels....  was here 2017 zmdikfoyvvhrlcdyafcbspsdaxxeefqnpnjhwmfmnixungjg
 * Smoking Wheels....  was here 2017 elrzbmcavbdqgiozntogcrkrufendukprgntcyftzkajjwfv
 * Smoking Wheels....  was here 2017 qpwvluhykrxclsyuyhszmiyryinhurjtpytiuvlkwzqomhuy
 * Smoking Wheels....  was here 2017 vcynlvgkrakskcadaecbyopcvvckxboxjitbiklotvfnxyiw
 * Smoking Wheels....  was here 2017 njmubpihzpwlwptbudmptpaablhbhgejegphedbpoyjtsihb
 * Smoking Wheels....  was here 2017 tceuridrygrmtpiulbxwnybwmhutgxqrqynpftleiraxlkji
 * Smoking Wheels....  was here 2017 redvtmlzmymifqgvocrmbitggqnddvsnjuculgwenohysfpq
 * Smoking Wheels....  was here 2017 wtpleulwrbeqspfyurfgjsmbtzoeqdiylmcygvysskpcmdci
 * Smoking Wheels....  was here 2017 bhdmzgjexcxjxpfffnkguiuloeictesgcxnjdyofteqtxukv
 * Smoking Wheels....  was here 2017 fllamcwcuvbsuzkuzmgvwqoupgnhopiwvfqrxksgvggrlzfx
 * Smoking Wheels....  was here 2017 pdqjfutzfijdljhhrsznkkwsylzmpgxqjxasqdvugdpuuwmq
 * Smoking Wheels....  was here 2017 rnxdabelhxqikppkaseenpbdzjxrnekosolmqjlxqqdhvtlg
 * Smoking Wheels....  was here 2017 gzwdxxklkbcgiugdacpvmltdiuszfubvdewilqkaxulpvhng
 * Smoking Wheels....  was here 2017 hggkgnaadpccchmvwuhwvlsexuzxxrgabvrvxputewmmdilk
 * Smoking Wheels....  was here 2017 bgbholyrkphhysuxcymvjhbvtosczruxiahvbhaztljvmyfs
 * Smoking Wheels....  was here 2017 acpkrjfyihpohxwemzsofzeahtzpfyplwjokfxpwihmvtnal
 * Smoking Wheels....  was here 2017 yflnphetfgevuyqqyqvcptpvccfnmtxyzumwxyjutmoafric
 * Smoking Wheels....  was here 2017 vhhsskkgthlilgjovstuecftcrbiyuewcnitzcljcgkaffwm
 * Smoking Wheels....  was here 2017 wgfingtvulamkjnlomwfqtciktktbxcazwqymkfmvfgumhoo
 * Smoking Wheels....  was here 2017 qflywniblzuabfucwhpedqnmjwlsndqkrpentceimdmozfrp
 * Smoking Wheels....  was here 2017 vrojuelxblzvdvdlvvutyaeipvokgxbgkpatgpfgzassvqqd
 * Smoking Wheels....  was here 2017 mgirpmsmirxeppuvpblhqkwharjiluudqajgxrlwlfwbmjex
 * Smoking Wheels....  was here 2017 uwufwxyebqhmodfrtcwizmqzrsvdnqntdhuushdcfgclqogy
 * Smoking Wheels....  was here 2017 hrenkfgpkszmnhcwzjotcgxgalctephdxbcnysybxwvdfncm
 * Smoking Wheels....  was here 2017 rdblghzrtjebcelhinhogzfipsnljygoeggsgjrelernkxdc
 * Smoking Wheels....  was here 2017 axebsmrmrlglhdmhzncdzbjniouqfjwolcozjblaxloiqodm
 * Smoking Wheels....  was here 2017 nwprjfgmbzwcftpjmngaehnniftaerxvmxodkrpoqfpopoaq
 * Smoking Wheels....  was here 2017 rgowafthafxrjxpfoxibuqadzhqnyzglglafqnrvihgiggbx
 * Smoking Wheels....  was here 2017 gkpmslmtztofkskyfkbhfikpwnvjmrfqapyoqboiusedshqs
 * Smoking Wheels....  was here 2017 ganotecamkevgnftswlczwngwayayhexhmquezhpftfqmnnw
 * Smoking Wheels....  was here 2017 waimtwlnldmzcymennvzxxmscaydttxbupqrjihowyovfark
 * Smoking Wheels....  was here 2017 qphtlgnwahikkvzzjtrvanqwzcxspcibmoshmhbjmdpxvehn
 * Smoking Wheels....  was here 2017 hdzgyitxmkwavgrdhgvrrxnxcagxktseshvzdinkwizhnnvu
 * Smoking Wheels....  was here 2017 vidanhsvogmbhpsznwgwjnadhvrfjhlyxzjjbfshdvpssabx
 * Smoking Wheels....  was here 2017 nbuktqgzbxxyzmpyowgzzcghtwbhyoiduaueiyzxreqcdswy
 * Smoking Wheels....  was here 2017 vofyldkbcqykitbvdpjvmqmeupocusgskcxohsxlddnqryod
 * Smoking Wheels....  was here 2017 neymrsoxcavibmargtjmhkjybxovwamzzdsunzjfiuvunjna
 * Smoking Wheels....  was here 2017 pptdsphqpuxycctrdgghwuraltszidlkagmltnlxllmhdumi
 * Smoking Wheels....  was here 2017 htredhlrobwtodrjjhiucpoaamyepyxvgyukbikjupraeilb
 * Smoking Wheels....  was here 2017 bvaetocrbbojylnopfdvzujueqkljmtesvjsvoytabufpkpn
 * Smoking Wheels....  was here 2017 sfgzqipmmjfuyfgfvtklwopnnzmxpehtpvgrntwmzxmjnnke
 * Smoking Wheels....  was here 2017 goeqcvngkteflsbpjufahlfpzoubmpxbldtwaqfdwjpcmppv
 * Smoking Wheels....  was here 2017 wvunrptithdcqplgrnucbdfqqripkpjwydjdiejqyajkbscm
 * Smoking Wheels....  was here 2017 celeehilqgyczrdxnisnfqznvwelbgqeenwntqxcxrelhgej
 * Smoking Wheels....  was here 2017 qzpkqypkkeufddbpwxtidebkgysvkzwghfhkxksypirsgtga
 * Smoking Wheels....  was here 2017 ozbiltfiswbqbgknyfwwhfjqsyrfpjpqwjxhpiutdisxmecf
 */
package net.yacy.peers;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import net.yacy.cora.document.encoding.ASCII;
import net.yacy.cora.storage.HandleSet;
import net.yacy.cora.util.ConcurrentLog;
import net.yacy.cora.util.SpaceExceededException;
import net.yacy.kelondro.data.word.Word;
import net.yacy.kelondro.data.word.WordReference;
import net.yacy.kelondro.data.word.WordReferenceRow;
import net.yacy.kelondro.index.RowHandleSet;
import net.yacy.kelondro.rwi.ReferenceContainer;
import net.yacy.kelondro.rwi.ReferenceContainerCache;
import net.yacy.kelondro.workflow.WorkflowJob;
import net.yacy.search.index.Segment;
public class Transmission {
public static final int maxRWIsCount = 1000;
protected ConcurrentLog log;
protected Segment segment;
protected SeedDB seeds;
protected boolean gzipBody4Transfer;
protected int timeout4Transfer;
public Transmission(
final ConcurrentLog log,
final Segment segment,
final SeedDB seeds,
final boolean gzipBody4Transfer,
final int timeout4Transfer) {
this.log = log;
this.segment = segment;
this.seeds = seeds;
this.gzipBody4Transfer = gzipBody4Transfer;
this.timeout4Transfer = timeout4Transfer;
}
public Chunk newChunk(final Seed dhtTarget) {
return new Chunk(dhtTarget);
}
public class Chunk extends WorkflowJob implements Iterable<ReferenceContainer<WordReference>> {
/**
* a dispatcher entry contains
* - the primary target, which is a word hash, as marker for the entry
* - a set of indexContainers in a cache,
* - the associated URLs in a set to have a cache for the transmission
*   to multiple peers and to ensure that all entries in the indexContainers
*   have a reference in the urls
* - a set of yacy seeds which will shrink as the containers are transmitted to them
*/
private final Seed                           dhtTarget;
private final ReferenceContainerCache<WordReference> containers;
private final HandleSet                      references;
private final HandleSet                      badReferences;
/**
* generate a new dispatcher target. such a target is defined with a primary target and
* a set of target peers that shall receive the entries of the containers
* the payloadrow defines the structure of container entries
* @param dhtTarget
*/
public Chunk(final Seed dhtTarget) {
super();
this.dhtTarget = dhtTarget;
this.containers = new ReferenceContainerCache<WordReference>(Segment.wordReferenceFactory, Segment.wordOrder, Word.commonHashLength);
this.references = new RowHandleSet(WordReferenceRow.urlEntryRow.primaryKeyLength, WordReferenceRow.urlEntryRow.objectOrder, 0);
this.badReferences = new RowHandleSet(WordReferenceRow.urlEntryRow.primaryKeyLength, WordReferenceRow.urlEntryRow.objectOrder, 0);
}
/*
* return a new container with at most max elements and put the rest back to the index
* as this chunk might be transferred back to myself a random selection needs to be taken
* @param container
* @param max
* @throws RowSpaceExceededException
* @return
*/
private ReferenceContainer<WordReference> trimContainer(final ReferenceContainer<WordReference> container, final int max) throws SpaceExceededException {
final ReferenceContainer<WordReference> c = new ReferenceContainer<WordReference>(Segment.wordReferenceFactory, container.getTermHash(), max);
final int part = container.size() / max + 1;
final Random r = new Random();
WordReference w;
final List<byte[]> selected = new ArrayList<byte[]>();
final Iterator<WordReference>  i = container.entries();
while ((i.hasNext()) && (c.size() < max)) {
w = i.next();
if (r.nextInt(part) == 0) {
c.add(w);
selected.add(w.urlhash());
}
}
for (final byte[] b : selected) container.removeReference(b);
try {
Transmission.this.segment.storeRWI(container);
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
return c;
}
/**
* add a container to the Entry cache.
* all entries in the container are checked and only such are stored which have a reference entry
* @param container
* @throws SpaceExceededException
*/
public void add(final ReferenceContainer<WordReference> container) throws SpaceExceededException {
int remaining = maxRWIsCount;
for (final ReferenceContainer<WordReference> ic : this) remaining -= ic.size();
if (remaining <= 0) {
try {
Transmission.this.segment.storeRWI(container);
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
return;
}
final ReferenceContainer<WordReference> c = (remaining >= container.size()) ? container : trimContainer(container, remaining);
final List<byte[]> notFoundx = new ArrayList<byte[]>();
Set<String> testids = new HashSet<String>();
Iterator<WordReference>  i = c.entries();
while (i.hasNext()) {
final WordReference e = i.next();
if (this.references.has(e.urlhash())) continue;
if (this.badReferences.has(e.urlhash())) {
notFoundx.add(e.urlhash());
continue;
}
testids.add(ASCII.String(e.urlhash()));
}
i = c.entries();
while (i.hasNext()) {
final WordReference e = i.next();
try {
if (Transmission.this.segment.fulltext().getLoadTime(ASCII.String(e.urlhash())) >= 0) {
this.references.put(e.urlhash());
} else {
notFoundx.add(e.urlhash());
this.badReferences.put(e.urlhash());
}
} catch (IOException e1) {
ConcurrentLog.logException(e1);
notFoundx.add(e.urlhash());
this.badReferences.put(e.urlhash());
}
}
for (final byte[] b : notFoundx) c.removeReference(b);
this.containers.add(c);
}
/**
* get all containers from the entry. This method may be used to flush remaining entries
* if they had been finished transmission without success (not enough peers arrived)
*/
@Override
public Iterator<ReferenceContainer<WordReference>> iterator() {
return this.containers.iterator();
}
public int containersSize() {
return this.containers.size();
}
public Seed dhtTarget() {
return this.dhtTarget;
}
public boolean transmit() {
if (this.dhtTarget == Transmission.this.seeds.mySeed() || this.dhtTarget.hash.equals(Transmission.this.seeds.mySeed().hash)) {
	restore();
	Transmission.this.log.info("Transfer of chunk to myself-target");
	return true;
}
Transmission.this.log.info("starting new index transmission request to " + this.dhtTarget.getName());
final long start = System.currentTimeMillis();
final String error = Protocol.transferIndex(Transmission.this.seeds, this.dhtTarget, this.containers, this.references, Transmission.this.segment, Transmission.this.gzipBody4Transfer, Transmission.this.timeout4Transfer);
if (error == null) {
final long transferTime = System.currentTimeMillis() - start;
final Iterator<ReferenceContainer<WordReference>> i = this.containers.iterator();
final ReferenceContainer<WordReference> firstContainer = (i == null) ? null : i.next();
Transmission.this.log.info("Index transfer of " + this.containers.size() +
" references for terms [ " + ((firstContainer == null) ? null : ASCII.String(firstContainer.getTermHash()))  + " ..]" +
" and " + this.references.size() + " URLs" +
" to peer " + this.dhtTarget.getName() + ":" + this.dhtTarget.hash +
" in " + (transferTime / 1000) +
" seconds successful ("  + (1000 * this.containers.size() / (transferTime + 1)) +
" words/s)");
Transmission.this.seeds.mySeed().incSI(this.containers.size());
Transmission.this.seeds.mySeed().incSU(this.references.size());
Transmission.this.log.info("Transfer finished of chunk to target " + this.dhtTarget.hash + "/" + this.dhtTarget.getName());
return true;
}
Transmission.this.log.info(
"Index transfer to peer " + this.dhtTarget.getName() + ":" + this.dhtTarget.hash +
" failed: " + error);
Transmission.this.log.info("Transfer failed of chunk to target " + this.dhtTarget.hash + "/" + this.dhtTarget.getName() + ": " + error);
final Seed newTarget = Transmission.this.seeds.get(this.dhtTarget.hash);
if (newTarget != null) {
if (this.dhtTarget.clash(newTarget.getIPs())) {
newTarget.setFlagAcceptRemoteIndex(false);
Transmission.this.seeds.updateConnected(newTarget);
} else {
}
} else {
}
return false;
}
public void restore() {
for (final ReferenceContainer<WordReference> ic : this) try {
Transmission.this.segment.storeRWI(ic);
} catch (final Exception e) {
ConcurrentLog.logException(e);
}
}
}
}
