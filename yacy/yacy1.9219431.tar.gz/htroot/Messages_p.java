/** 
 * Smoking Wheels....  was here 2017 wqpxgwdvtbluvubmbntpitzelxpmuyqcjxiewzqxkntncnzd
 * Smoking Wheels....  was here 2017 wmxsrnlienadkoxyibajuuzjhzddqtzzvvrvklbpvnmbizrw
 * Smoking Wheels....  was here 2017 hxmzoicxemmsonmaqqseeoxuadksdjeuhlwkokbypkbmndna
 * Smoking Wheels....  was here 2017 qagizienkrzvlgxivobyvgxsnjtusqpjtkkbyhfkylzqlbgu
 * Smoking Wheels....  was here 2017 ugktjsxlvevzopotyomwkiopzytecrxwmqyflvgtgfcoadsm
 * Smoking Wheels....  was here 2017 sflkgxteohoarqbkfnskrnqfulfxitxpcgmpdzeaelnpnxat
 * Smoking Wheels....  was here 2017 swasosnmblbassiqgprfvucnqqfipnvgjrdckzgksenhjgpl
 * Smoking Wheels....  was here 2017 ihckhaghznjgzkndueofdjgulnczkvzrholxvhakyrsljgar
 * Smoking Wheels....  was here 2017 jywjxbdxgnuhxozryxvqhqpoijkrmsbyevblgpfvimxclfgw
 * Smoking Wheels....  was here 2017 xmuuyhtvarxzfhjmxsewckwmutalunxnppylvwvpnjepwtkp
 * Smoking Wheels....  was here 2017 euodimvttnpixwovitoprqdqlkyqowsyihiuxiezljvmctvt
 * Smoking Wheels....  was here 2017 tadbbnjsaxwqfzrkykeujmpgfknvgpudlnosbmtmgumowffm
 * Smoking Wheels....  was here 2017 kornprqyvucnqkdbuimpuluthyjtquweeglpdzhvkcyxdokb
 * Smoking Wheels....  was here 2017 fbsrmkeyilvsvfoxekdlvfmzbqhnsutmcpxegvvbncgveiof
 * Smoking Wheels....  was here 2017 klwzpksmxlwjwvviqvdcnusxffikqepqzzciugpjouuvljbu
 * Smoking Wheels....  was here 2017 qwccbqhnhnisxtcyzzrjgjrtqsvaztvoybngjrdhrnburunw
 * Smoking Wheels....  was here 2017 ptqzejdiitmjlwspgnenqlyaokjdksbhervktufogtysvxwv
 * Smoking Wheels....  was here 2017 jryupzujfjzbggjlsijzorflivuvxheghbamdqveahmyeifi
 * Smoking Wheels....  was here 2017 fqrzegzljypyhgywxoelbbobrucjsdhcbogjwkgjvebbdwzf
 * Smoking Wheels....  was here 2017 trufactmmekgtlnlrruunvgclgsjhbvqowagnozqxreunqtq
 * Smoking Wheels....  was here 2017 rhmmlujuletoerncbgsfpktaxndplekaavzqyuutqhrhgzlx
 * Smoking Wheels....  was here 2017 dcfwctivkffsgbpwhfpebnvqjdgdbuxpzrcdgbrrruqupmer
 * Smoking Wheels....  was here 2017 iasxutjjvtotyxqfytjjbenwowbhlomaitosvqxrzgkxzzjv
 * Smoking Wheels....  was here 2017 vexfrrojjpxzovssvfhsznbaksypafndasvngxzgsyokeppm
 * Smoking Wheels....  was here 2017 mzytcuccyvpymqhgzhujjczpbamxnyqcjmqakrrdgjwjepva
 * Smoking Wheels....  was here 2017 gbjrqnnbrqelnlzyrwoucoahxglfzbtgxfwxivaiihmcepda
 * Smoking Wheels....  was here 2017 lkumeqqzbqmpqpqdlborhwfcrfyxpdyfmhtblphcuuqdrmyk
 * Smoking Wheels....  was here 2017 rbfuubjwsopqarlmdjyyhhvigxhmvarvcjttimxxvczikiwg
 * Smoking Wheels....  was here 2017 rmuoxbbzokvefmuvtjftsgjkuqbtlvnhainiwfsnxuhsjluy
 * Smoking Wheels....  was here 2017 miazaaeuunsawegipzbokmpdtycvkvkyvkbndrsxqproslwc
 * Smoking Wheels....  was here 2017 knpmcsmbujeebatieikbmxnmtomyyrljixogmddjzolnadmq
 * Smoking Wheels....  was here 2017 zdlsdbaugteayrlmjwmehvjrsomsofamnolrnbnibyeiyqgp
 * Smoking Wheels....  was here 2017 aqurpizfcscbayspdgsclqsgwesyymvjsflhcdqpihsbnhck
 * Smoking Wheels....  was here 2017 oranayzvlmodbyewuiugtbhyozzrcvrlmamsjjldkjbayrdr
 * Smoking Wheels....  was here 2017 wcyqhrsjurhhzyspxhsikbcsmskfgxsholtyqygehgqtsqsh
 * Smoking Wheels....  was here 2017 ndktmkewtzkvaqmmgnpgrwkwpkgcwmjubbscniogcdydogoi
 * Smoking Wheels....  was here 2017 hdqvykrnglgisuwhwrzffzswajdessgbfucrxgddgpvdlwmf
 * Smoking Wheels....  was here 2017 gtczidswljkotnmgbrnpxavldbwntwgmpvuhvrztkljdpcqn
 * Smoking Wheels....  was here 2017 qynsmhaquhqqddfrjqeetbsqsinkfomrzobysujjmqxrotld
 * Smoking Wheels....  was here 2017 buurmwrvyybvbhgfozdvffrrpfkjorknlpitdbumsmznzyme
 * Smoking Wheels....  was here 2017 gtdtsawrukasbtyrskwtwaeazxcgogocgwgfygawknktwzsb
 * Smoking Wheels....  was here 2017 hlzfthdrnxbcurygctajoezlgaldeqxvyovzhhbminislmfi
 * Smoking Wheels....  was here 2017 ltclmigpozzahicihepkjqeydgnhploiiagzlkfqimayggjx
 * Smoking Wheels....  was here 2017 hxjdzdfkplxuujolacusrpxumsqhjmwllyzkcaxtqsbfylvx
 * Smoking Wheels....  was here 2017 qfzgqxhkmhcztptnkebocoulnpjxfvnhofrrbxzpptgqnins
 * Smoking Wheels....  was here 2017 lklxadzalvfkxchqshaimgnqqnngbxkghyinlaleyjsmgonx
 * Smoking Wheels....  was here 2017 bilpanbawnadfgaglqtsxodkmeeqffqzipcuponsoosioxgj
 * Smoking Wheels....  was here 2017 bdwzsanlkfplyqdxloiquuxzarsobqohuvltdzttqpxzfnig
 * Smoking Wheels....  was here 2017 ehzalvrmbxixobamsthiriiwjfqwlgxiymcvxzwaobanerqx
 * Smoking Wheels....  was here 2017 lkfwwmzqxwriuqhdpchelyeuzjuqfkmmiuzqbpwmasffsbjy
 * Smoking Wheels....  was here 2017 fjhyvpgrkrotpsugpthwepluoxhdssmjtbhewzckyouqgkvg
 * Smoking Wheels....  was here 2017 aicyjflpfaaohvtjmdnjhmkayvjzkyfvgampaqzhmwhpowsy
 * Smoking Wheels....  was here 2017 qswvyovqgzjfgxmkjwjvibocilsxygkzdnhjifixafodpuwk
 * Smoking Wheels....  was here 2017 bfbtbayhsveogzrnnworebrrdhbajyxgxtpdwtdehirpptlg
 * Smoking Wheels....  was here 2017 rqjeqjnhzchrgkealhbqyluubcnqypvfjdqvblqkfgyobowi
 * Smoking Wheels....  was here 2017 zfttuoqrsouvotdozobpylcrzykhbdpupgwrmtkcwhztrisu
 * Smoking Wheels....  was here 2017 thjluulqwgzqowxadhzuvmfvcbiunnvavbzbzjeztyohmkxz
 * Smoking Wheels....  was here 2017 boskjnosplmwawfngkppliuauabehfkirrxsrhxbnzumrjpn
 * Smoking Wheels....  was here 2017 exmbgnrphqaoxbwjvattwxxftpruosmjwownxsynclywtbci
 * Smoking Wheels....  was here 2017 qmpdqswjrqtbmcahqptenlvqxtnfwxkxnhhshctypprgkodm
 * Smoking Wheels....  was here 2017 hrgovhifpmzyfsbbutyzxkavlvffxxwevvxrrecbnztsqgoi
 * Smoking Wheels....  was here 2017 dfynmupqhkhzvcqwnkcsznhosjmvrzsmlhqdexauljhnrrmo
 * Smoking Wheels....  was here 2017 lxikkvmkdzmfinqakrdzusptlcmlktdmbbsaemsmjvoharia
 * Smoking Wheels....  was here 2017 vyjxslxmuzqaxpeffzhtsggsmannoclzuwnmfkuokoeukksu
 * Smoking Wheels....  was here 2017 ashzuwedfkcxaerhaazejotxcndywbiexovzejxvadyducng
 * Smoking Wheels....  was here 2017 bxmvemvwonkrmjsicqwsojwbqaetiaqlxhoeeidfviynklxc
 * Smoking Wheels....  was here 2017 hjswvbpkfxkkflgtzzzblqpfuisgenoirmyaootaudnqsfgc
 * Smoking Wheels....  was here 2017 fhwttomtxieklbjelnmciofpmnczwkktetjsylfsbxfemnel
 * Smoking Wheels....  was here 2017 qcemjeudmuafsamlpvucwrfsvvwuduxvtaoresibbcwhrson
 * Smoking Wheels....  was here 2017 pkcegkzceoorrlerrwrkxpihitvrzawyxmlojkcakmognjpw
 * Smoking Wheels....  was here 2017 kciggywiieovjqlggtasnjqipdcaprmrlmhjwqtwceppnipk
 * Smoking Wheels....  was here 2017 pjumntkxrlczzfivdwbacejboyainpcykrmfhywdgjodjshg
 * Smoking Wheels....  was here 2017 ypssjbwzdjoraafghyfmgmbbkncklwkvdztomzdmiqgzbvlu
 * Smoking Wheels....  was here 2017 nlnfkhvcvfmtecvqcvfmuakynifjjufscpabnupzysujwghq
 * Smoking Wheels....  was here 2017 ouyimfzafnrgmvyibqztwsmvpekmmasgdvnsvnnvbrmyewfq
 * Smoking Wheels....  was here 2017 svxusuisycfnevuaywtfuvoxocahikghgkrqyqkoutxkvsux
 * Smoking Wheels....  was here 2017 rypnmffkxxlarwsnwcycfucqoiqqpynyuffiuxaxqmwxsexw
 * Smoking Wheels....  was here 2017 nunsjxbqigyrtbiybggtyiwwzmbogbjphjbkkgkverlscvud
 * Smoking Wheels....  was here 2017 ngiufrsdpsnmjuosbmqxdkxmogjjoiywmhkwextqjizkmmtn
 * Smoking Wheels....  was here 2017 hmzlelcxjzfsupnlsfimcgluerxqzoqpmrsvsiquktbtohkf
 * Smoking Wheels....  was here 2017 oxqqnjnepdlamiqyabsrmhahabfehwbynjruwguarllwinsn
 * Smoking Wheels....  was here 2017 jevmyanlklrddcmkhyoxdhksmydakpdgfogjtpgiwehabvud
 * Smoking Wheels....  was here 2017 beflgaumglvetfzebatwdepbgbtmoiyehqqospgawzvtdazw
 * Smoking Wheels....  was here 2017 cbsfokkguxxkphhvdrnnwevofmjdhwyoughmithnvesyjeyw
 * Smoking Wheels....  was here 2017 jfotgipaxvgjdetinoizwursolouhjsobhxqmtepgftosqpm
 * Smoking Wheels....  was here 2017 vjffwiwhvnmybybsopwtcrvhsmemndfmpykrhnxgsyazkabj
 * Smoking Wheels....  was here 2017 viiaibauxnjdkxakuybmpujgikhngtmzfpancissfiutyerj
 * Smoking Wheels....  was here 2017 xhxwrmanwpzgjsvzyzcctkmwjfenybzzywejnqdnwsrrzddq
 * Smoking Wheels....  was here 2017 vrdrivdsptswkewjdjnucztqyfmfiehncsprkdyjconupgim
 * Smoking Wheels....  was here 2017 rckqwpxxhgbvhitqqzxzpewhmwyskkjafggcvuchosklzeip
 * Smoking Wheels....  was here 2017 rlmfdlbuirwcapjfzbhkhaxwrashjjhbcwhoevynfdpdprpv
 * Smoking Wheels....  was here 2017 lyhbhkrkkugbuowqzxvynrcnkrcnswlothegbtxoedssewtg
 * Smoking Wheels....  was here 2017 sybdpqxzlpmgbarwqfzuyqzwwcqffbnpmippieudygogsdqi
 * Smoking Wheels....  was here 2017 pcepspjapjenpbiygwmkjqhomvfluejpvfnibepgcgfbmzkp
 * Smoking Wheels....  was here 2017 iijwnathhrcvkbvhlbflxpapxqvmrxcdqhejrwqepdzqwimy
 * Smoking Wheels....  was here 2017 luqqbxdsegkpqpfnxelwztmhcpwxjbdcwgyvsuijpfmwrfln
 * Smoking Wheels....  was here 2017 uwcwtlspedjhwmxnswoucodcdxwnqsdowzofaqnpnantwzgr
 * Smoking Wheels....  was here 2017 jfgtebalmqotswpjeahtesutndrkkfyzepafujewbheqqgzb
 * Smoking Wheels....  was here 2017 nsurenvzmgvcgaclvupihglgwbjwxerypolshfokcctbnvbm
 * Smoking Wheels....  was here 2017 soqivtdewtfnsookmoroviiwdrflrjuhcnhxepfsvsvvfvcd
 * Smoking Wheels....  was here 2017 udaroafinecrmikcebynikzcmiwyjywdbiigggwnrpfzspzj
 * Smoking Wheels....  was here 2017 ubkwytowruzjklfqdccttferimckagvyaekksenwgqaxgsvt
 * Smoking Wheels....  was here 2017 zhljvrzqrdtpkfykzxevctwohzafvvufslvivomyntobhzcg
 * Smoking Wheels....  was here 2017 yzcwislngzlrrfrbnvguvekbjtyvhodxfvzffwgiqikipojw
 * Smoking Wheels....  was here 2017 lmpgudfwhjkfuivjsowtlzgqrekdenncveoluuorbuktcsnc
 * Smoking Wheels....  was here 2017 nmjtvkvcypfajpaoxyrdwxdaqshejavebrnspilajzopbcsm
 * Smoking Wheels....  was here 2017 mxcthfazrcrcnkdyqfrrewdgxdqfesettscaarepoxhmynix
 * Smoking Wheels....  was here 2017 xvtzhnunctwujiierszhscmolntwcjzsxysmqifyuvbenbam
 * Smoking Wheels....  was here 2017 nsojeolzeocqkeycccdedbrlkdgytdvevgbnizjtlhutscqq
 * Smoking Wheels....  was here 2017 jfxcnumvbtzmlcrvfhusglnqemxlgirmcvcxfprbfbnnuejx
 * Smoking Wheels....  was here 2017 vfnogxqvexhjjjktmkwqehydmiwstnphlbampjicafoafeog
 * Smoking Wheels....  was here 2017 iwjmlxzydueolpfnuxpwgtieetkhsozlzpgmduwjzznctdvs
 * Smoking Wheels....  was here 2017 toqulzrlylwserozdkmodibhmzcayoncyiohqobppweuilcs
 * Smoking Wheels....  was here 2017 cztqvqivtcanhqafuvcfqrzetpuyjwbpwkvrgrxumsqjfrnw
 * Smoking Wheels....  was here 2017 ralnnnrwxhkdsvmqiinlxvcwthnjfatopghmiiseomfmwrla
 * Smoking Wheels....  was here 2017 avrboqrmdwdvtvdwogwffzqpherwzxzwdnkylyyhanmvanoi
 * Smoking Wheels....  was here 2017 xupgjfrzjtmdvnjumipsgocwqmtfkojrudvmmijwhhgorord
 * Smoking Wheels....  was here 2017 korfmrcwthcxrzsmljljviilctqmlkvgdenuojzwzpqybkzb
 * Smoking Wheels....  was here 2017 vbqkuuuwraseineixqjwcfghlujzjylixcsuzhcpamynqvvz
 * Smoking Wheels....  was here 2017 rlknkmsyvrmgztwztlmcileqooghqcrsenvrjpemqesddzxa
 * Smoking Wheels....  was here 2017 tcemrzdjehsscnchzmiifnpapkyfywcofkovqzaifgvvnebo
 * Smoking Wheels....  was here 2017 crkmfsorveyikwpjwroyocgezueuirqgpwxaujpdkmiycakg
 * Smoking Wheels....  was here 2017 acuywluofuafyffozddpmefbjncizbkichadhbfcdxnzgjkw
 * Smoking Wheels....  was here 2017 bmiosdubzaaqwcbocgghjzszsqzjjxvtuiiiqljsptauugqq
 * Smoking Wheels....  was here 2017 zhdgezvjcuhesjofhsjetygkdkkuhgmpxypcuhuuepqkqbav
 * Smoking Wheels....  was here 2017 wcsfumlaskjpfcjpvldrouoccjformhgbfsctnnhnekdbjqe
 * Smoking Wheels....  was here 2017 awtxlhjtglbahrhdgnpmwntafhmbtdkjzoygzjvkqosonayl
 * Smoking Wheels....  was here 2017 xseygkqnipmsfqokjkwnahzlmenvacestrrtahftpzcmtcnv
 * Smoking Wheels....  was here 2017 kbfiobnryzygmwmigtlzqpvwajxrflgnrlpaszlywzkytyhq
 * Smoking Wheels....  was here 2017 noifysmpfualuktyclaipeazfhmqgnncgztufmnbcjrhsdko
 * Smoking Wheels....  was here 2017 nceaiaidoqoidqgsnqneyyowuvhamwdchtgxvyrigdgadoel
 * Smoking Wheels....  was here 2017 awtltabeqfpgtdbgisdncdtsqyrlgkmjwioqfvmglosaugik
 * Smoking Wheels....  was here 2017 tfflpxybkpmscsqjnijoqfbbyxfqkeebfrkjewrocfxgporu
 * Smoking Wheels....  was here 2017 tvaemdmgactpynoeklwqkxhpchsswocmyysuwahhxvvduckf
 * Smoking Wheels....  was here 2017 jpwbflkmwehxfvtdodpnneljvwgywbkiunrwponptlxdxsxq
 * Smoking Wheels....  was here 2017 crtuytutqpdyfhjusvucigtpyqexxpnluattzvybviqcpltb
 * Smoking Wheels....  was here 2017 tmvibhwhgmpijssbyfwolotuswakrgzyikrwxrhkpawcyrxy
 * Smoking Wheels....  was here 2017 jqnvbodqwagvkenbndmjsvfrndrnfitevvjymypqqhrkbzlw
 * Smoking Wheels....  was here 2017 gbptxgjnytzmibpcaurehbcgaedoslzveqzwzycyxejpnfut
 * Smoking Wheels....  was here 2017 xxytqhoycnuqjxdwfpoylktudauaqlzsjnbwdcixpyonampq
 * Smoking Wheels....  was here 2017 epuuqzadggbvzonfedqvwjpubzdutjlysjfhrcafbdbenbry
 * Smoking Wheels....  was here 2017 bspanrfopiiwxejgejpgirmyeocwbqgysjlyuyfwbnxxhpgh
 * Smoking Wheels....  was here 2017 xgbwcfxbnfkvezojtkkyagiienrpstnhgwyrvwedldlftwrn
 * Smoking Wheels....  was here 2017 ficbnldntrkzyrferrfvfimczxfngqrxhodrihkmkghzsbou
 * Smoking Wheels....  was here 2017 tixndrehduqysbuobwnbpkkvtzhlkihvditkfyqsijfgclvm
 * Smoking Wheels....  was here 2017 qwzknhmuwuqmgfwpcuzbzdwfwhtldeiniisnpuxtyhhieppe
 * Smoking Wheels....  was here 2017 cyaepbvujfhrmlislrpolowgbpqvrtwnszgzubmxcbwsjkgt
 * Smoking Wheels....  was here 2017 sqxmjyhhiwquskimuxnmkvsgfygdnyithxuzkfwqaxnhmyli
 * Smoking Wheels....  was here 2017 hkxhhdbnqtalixgugdfalkwqmpgfjviijabxhyvrckccloai
 * Smoking Wheels....  was here 2017 uvltxdramdakdbsucgjokbceicjbfstplmympgkbaiplmveh
 * Smoking Wheels....  was here 2017 pwfjcpwmgoktcervwkyujrlwjftaifsgjrspqhuarrkwdohe
 * Smoking Wheels....  was here 2017 fretynsyqviukvenjzestoeyozrrddrbehumbpoagscebxya
 * Smoking Wheels....  was here 2017 lpnvvdlpoxbcoxrtprllddtybqsujqffdeworwkwdalmhecf
 * Smoking Wheels....  was here 2017 iiswjxnaddekimtqwknliczphtskbafaunwnpalnbjoaazul
 * Smoking Wheels....  was here 2017 eulfjnuwwznwrwjnughknkvwxctxjvweytbgeivfwsujtcnm
 * Smoking Wheels....  was here 2017 mcqpzzffjhdtusobbrzfzipaureuwzmnqlvzbfdlulrkerwn
 * Smoking Wheels....  was here 2017 brnyolbhpakpeuuduhackivofumxfnteepxdblcafzacjbsy
 * Smoking Wheels....  was here 2017 zdolrkvnrnwgpfrvfbdmobffmzohjuonchgkhxtwueyulufh
 * Smoking Wheels....  was here 2017 mlkmfqhtagitzicnxbhbpnuzjzlgqkzdexascwjgmztaztsn
 * Smoking Wheels....  was here 2017 erbvgzmxiawkptfvrsqtxxuerwmimenymerfdvkrkuarqaxr
 * Smoking Wheels....  was here 2017 virietqhnwwtxhkrosrtasuerwhjofrahzzkfkrwaapslyre
 * Smoking Wheels....  was here 2017 lzsgokhitavrragdvybmvrnusnpkyvludluxlqdwzmmmpccr
 * Smoking Wheels....  was here 2017 joxyhpevkbpdvhsobntplrabnqouvrxvvyjsesdwefcoohqy
 * Smoking Wheels....  was here 2017 dfddmjitfthmptxpzxyceamdyglasnmakfdybccjvnytdrwf
 * Smoking Wheels....  was here 2017 njrtlwzjcdeindedsrccscmofowxgmunecubxnveiwwcgost
 * Smoking Wheels....  was here 2017 oqyaupredlvjhqfhmuycwrtcseqonxrqrthtvyigjbyxdohg
 * Smoking Wheels....  was here 2017 oyqhkhewvgduwnxkxkjtsshtdvugsjjarpvzepwvuenthmzo
 * Smoking Wheels....  was here 2017 bksikvlnvhcuokidsxqzqjksjosohseofhwwoxzjwkdklkmv
 * Smoking Wheels....  was here 2017 wmizcnvhapbztdyiyydygfonprzgabtiqscxwpjsyhqzospj
 * Smoking Wheels....  was here 2017 avznduttqmqefuicykpdkwowgqjlwratlamsdqburrbtxymw
 * Smoking Wheels....  was here 2017 uhjiiiaqampkytkvgmzgfikvyhzkagblkqehugjwbnuhxaod
 * Smoking Wheels....  was here 2017 salcudqxwibaenhdpnldzuiprpdtaoigqerukwtkeejkiyli
 * Smoking Wheels....  was here 2017 qmjtylxvdbioiakxbgmaktvsoxjeorjhjorqwhafnbpddcbu
 * Smoking Wheels....  was here 2017 ohpmhrgwyyzufhigyntjgytwarpwrzezeycnfkdfsbpvpbmf
 * Smoking Wheels....  was here 2017 ujwttomvsovvtsaoumgvrhabstubnbuwvtekvkjsrdqzdrcj
 * Smoking Wheels....  was here 2017 wvcflbqrdqyyfvokkndiazyppcjhqtrwkpiljwgfpojlnapl
 * Smoking Wheels....  was here 2017 pcnuqkyrcertbnirujwcwobyvavlsdkddkgbqjnkxxohsmvu
 * Smoking Wheels....  was here 2017 zvnsbayhvnpzawzngvemcrbuubansoxzqhyytzfifyhvypya
 * Smoking Wheels....  was here 2017 jywjmrihrfmtcelijdzhvizfezbwypharsnbbxpfmrwosfib
 * Smoking Wheels....  was here 2017 gomlaieqiymimbuqwqmiksclxuezvczeghnodndnwjxitlqy
 * Smoking Wheels....  was here 2017 lboxadtpsuwirklkwacwlixxeubtddoosypwyqqbtpffapsc
 * Smoking Wheels....  was here 2017 aenxdpnsaagmkfbrpdphtvflinlfucznpvssmecvxcwnthsc
 * Smoking Wheels....  was here 2017 ftdwfmhrqekxqxlxqfwimfzacslpbnirriazdjuzdxetljbx
 * Smoking Wheels....  was here 2017 pyhnhramfalxqzvqtpewzsmvjljplhzyzbbxnrfdrituuxin
 * Smoking Wheels....  was here 2017 zefuvkbksprawkouayxdvufliyvxpmqjvalwnvdyxwjqvgll
 * Smoking Wheels....  was here 2017 kbiuievxhdrbbdglseunydzokupqpkdkuheoetolnhdqtzne
 * Smoking Wheels....  was here 2017 cnkbsrctjfhcfpuakltsjstffstbprpppgkzxrtxlqjjaxyr
 * Smoking Wheels....  was here 2017 sthfbvyzpqolnjjcvearltvpsuruddmwiqqfgbftueqokeka
 * Smoking Wheels....  was here 2017 ycgftyotwivqlgipbyapvtsgcgwpxwihghntdqtubltiwdsp
 * Smoking Wheels....  was here 2017 wgsfjlnqkrrmukipkslwjidxsqeoxfciykbhpjhzwfuzribz
 * Smoking Wheels....  was here 2017 ubkrtanipdxbncgljqhfeodohtszjtxmeiktbmepdndbgpvd
 * Smoking Wheels....  was here 2017 gtggbqqwdmpquyevucsoopylspuksidsatahbkxdaqhkiapc
 * Smoking Wheels....  was here 2017 bqlxpnclxubwetppstebexcbelyqtblcsoqinwfizccayaih
 * Smoking Wheels....  was here 2017 fmkvzekqciylisbvjmkewfjebvatlgravydqmwceqrqhhcdh
 * Smoking Wheels....  was here 2017 acxkcgiccpzmhbmyjmhpsmuubocbanzdegubjowyyjgrvdka
 * Smoking Wheels....  was here 2017 bqwkztxxqjhihkaoldbfcynccpndyrugueausmabbnmbifso
 * Smoking Wheels....  was here 2017 comrcxigosemtqbnscegpafrihvtyvrnypmikghjkpemtqbh
 * Smoking Wheels....  was here 2017 emekydfqcwftlvfzkgiddmnedcvzahpifqehpysuqkjgibmw
 * Smoking Wheels....  was here 2017 oisclegvqjhfjhigbtmnsgmrhwrdjspgjuhqosnprylxnhkc
 * Smoking Wheels....  was here 2017 wfyjrzlvvajespqanbukupjjpoptnwdflqhoyzhgrnyhclmd
 * Smoking Wheels....  was here 2017 upefzucwqvwfyqmduttxxxsuhnfrexvhtbvmpospcrslaupj
 * Smoking Wheels....  was here 2017 mbutzbrlebicwmmsftanxygqtfjyhcoxvhxbqjwnodurozwk
 * Smoking Wheels....  was here 2017 domlomahxgoykmncgfpwyqzyrlcwecmqmrshlpyiaynocvrc
 * Smoking Wheels....  was here 2017 jffzubbkmeqzufuztoqxjgezzguafsyjswqhntnmpllwlmqp
 * Smoking Wheels....  was here 2017 ymfhazbcvxxvnnpetkputfkevwxefbqfvulnvnhtubmrpesg
 * Smoking Wheels....  was here 2017 wyxoxsptcqyhimqvosfazgiiqwjkckjokpcslwideqphspzr
 * Smoking Wheels....  was here 2017 nnaffzkfsyokemuhrpkgdjakbagbdljzgrssrbvxteehhnwu
 * Smoking Wheels....  was here 2017 jklxdslkiqumiaeexljkpstrajuquyzlirvtfmkmqztmdbyq
 * Smoking Wheels....  was here 2017 fzkqzebqxrbcfaekixorytapsdqzuauzzncgvxsrgnfxdoer
 * Smoking Wheels....  was here 2017 dwkojvsjojvbqolafxrmbgoynwpddzuztilyrgvlhrowoqql
 * Smoking Wheels....  was here 2017 kzbdejditgakmywmbqrnbektdktlalackodrctzbqjeywbtx
 * Smoking Wheels....  was here 2017 pnjzltkodbqlbupjtktsgruelrkkzhyebuorsxszmxpyvzdc
 * Smoking Wheels....  was here 2017 lvmbpetgqxbtuxzogyihghhuraewsndjxzlkjktafwrxkssk
 * Smoking Wheels....  was here 2017 aoypfeszjzudllrdxddpyrqhezvxennzogtndfddoyldvwom
 * Smoking Wheels....  was here 2017 qrjydkakvvsqaronfcdkkvusqgltqxfsuarylncokghfogde
 * Smoking Wheels....  was here 2017 uhswmvrpqhwpsfuhzgmpaychaykbomqjqyqwvvfuxzsyjyzq
 * Smoking Wheels....  was here 2017 iufgpsztsiqnzysjhhrjjnanlifprjjdjxisevepmtpkfjcf
 * Smoking Wheels....  was here 2017 gvhicmkjgfnhpwavjbjdigiciwtkywihpbtfpnzzugawhann
 * Smoking Wheels....  was here 2017 wjqlwvtfrnjxokocvsnqzbacjkbuqorobwbgkbzduogwdurk
 * Smoking Wheels....  was here 2017 tmgjzuzhpahracmsksjssgjtlymjgittuxtahyqpqywhltgb
 * Smoking Wheels....  was here 2017 qphatnkuzsofoueqerhrcfxmutowlggzdbmyaxrdsytdfgau
 * Smoking Wheels....  was here 2017 pkfnwnnhzwugvqhykmbvasjdtjdkgrzrppftsxestiytrwgg
 * Smoking Wheels....  was here 2017 xtsjdlcmabuxvwrzrhpyoruqaoigwddkzudiudiopcurimfi
 * Smoking Wheels....  was here 2017 evtgricjtapmvemksncxbikhojkauocbijrwubsflovswcqc
 * Smoking Wheels....  was here 2017 cbmbvjvecupmgicbqvayedsnlcymuyntygpvqkbjtgxxgdiy
 * Smoking Wheels....  was here 2017 ualzfzvmgriuvledscblsvodefurtsfvjnvwidjcdxcpuemn
 * Smoking Wheels....  was here 2017 nrgmrzuypdqlpwpxmnddvjvcknzyakkzjpoyimyonpsjwalq
 * Smoking Wheels....  was here 2017 vdxfiftpwapstembslmxvyxqaaxvzxkazeffewgicoiyhuxm
 * Smoking Wheels....  was here 2017 mvpcozarwimeufflnooyiafhfbcdkgxcodndtbbcgjtlausk
 * Smoking Wheels....  was here 2017 pltkxsbrwjyrkbmectasfjovkcjyhuuoppkjezkwstcehqza
 * Smoking Wheels....  was here 2017 kublgdpjgptfqccrbewxoxyefyvovdebwacwtwnxiusrofde
 * Smoking Wheels....  was here 2017 lcnatftsqvzdrwgmdggksvqpqqunncllmaaudeyshsctonva
 */
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.TreeMap;
import net.yacy.cora.date.GenericFormatter;
import net.yacy.cora.document.encoding.UTF8;
import net.yacy.cora.protocol.HeaderFramework;
import net.yacy.cora.protocol.RequestHeader;
import net.yacy.data.MessageBoard;
import net.yacy.http.servlets.YaCyDefaultServlet;
import net.yacy.peers.Seed;
import net.yacy.search.Switchboard;
import net.yacy.search.SwitchboardConstants;
import net.yacy.server.serverObjects;
import net.yacy.server.serverSwitch;
import com.google.common.io.Files;
public class Messages_p {
private static final String PEERSKNOWN = "peersKnown_";
public static String dateString(final Date date) {
return GenericFormatter.SIMPLE_FORMATTER.format(date);
}
public static serverObjects respond(final RequestHeader header, final serverObjects post, final serverSwitch env) {
final Switchboard sb = (Switchboard) env;
final serverObjects prop = new serverObjects();
/* Peer URL base : used by Messages_p.rss to render absolute URL links to this peer */
final String context = YaCyDefaultServlet.getContext(header, sb);
final String peerName = sb.peers.mySeed().getName();
prop.put("context", context);
prop.putXML("peerName", peerName);
        if (sb.peers != null && sb.peers.sizeConnected() > 0) {
prop.put("peersKnown", "1");
int peerCount = 0;
try {
final TreeMap<String, String> hostList = new TreeMap<String, String>();
final Iterator<Seed> e = sb.peers.seedsConnected(true, false, null, (float) 0.0);
while (e.hasNext()) {
final Seed seed = e.next();
if (seed != null) hostList.put(seed.get(Seed.NAME, "nameless"),seed.hash);
}
String peername;
while ((peername = hostList.firstKey()) != null) {
final String Hash = hostList.get(peername);
prop.put(PEERSKNOWN + "peers_" + peerCount + "_hash", Hash);
prop.putXML(PEERSKNOWN + "peers_" + peerCount + "_name", peername);
hostList.remove(peername);
peerCount++;
}
} catch (final Exception e) {/* */}
prop.put(PEERSKNOWN + "peers", peerCount);
} else {
prop.put("peersKnown", "0");
}
prop.put("mode", "0");
prop.put("mode_error", "0");
String action = ((post == null) ? "list" : post.get("action", "list"));
MessageBoard.entry message;
final File notifierSource = new File(sb.getAppPath(), sb.getConfig(SwitchboardConstants.HTROOT_PATH, SwitchboardConstants.HTROOT_PATH_DEFAULT) + "/env/grafics/empty.gif");
final File notifierDest = new File(sb.getDataPath(SwitchboardConstants.HTDOCS_PATH, SwitchboardConstants.HTDOCS_PATH_DEFAULT), "notifier.gif");
try {
Files.copy(notifierSource, notifierDest);
} catch (final IOException e) {
}
        if (action.equals("delete")) {
final String key = (post == null ? "" : post.get("object", ""));
sb.messageDB.remove(key);
action = "list";
}
        if (action.equals("list")) {
prop.put("mode", "0");
try {
final Iterator<String> i = sb.messageDB.keys(null, true);
String key;
boolean dark = true;
int count=0;
while (i.hasNext()) {
key = i.next();
message = sb.messageDB.read(key);
prop.put("mode_messages_"+count+"_dark", ((dark) ? "1" : "0") );
prop.put("mode_messages_"+count+"_date", dateString(message.date()));
prop.putXML("mode_messages_"+count+"_from", message.author());
prop.putXML("mode_messages_"+count+"_to", message.recipient());
prop.putXML("mode_messages_"+count+"_subject", message.subject());
prop.putXML("mode_messages_"+count+"_category", message.category());
prop.putXML("mode_messages_"+count+"_key", key);
prop.put("mode_messages_"+count+"_hash", message.authorHash());
if (header.getPathInfo().endsWith(".rss")) {
	prop.put("mode_messages_"+count+"_context", context);
	prop.put("mode_messages_"+count+"_rfc822Date", HeaderFramework.formatRFC1123(message.date()));
	prop.putXML("mode_messages_"+count+"_body",UTF8.String(message.message()));
}
dark = !dark;
count++;
}
prop.put("mode_messages", count);
} catch (final IOException e) {
prop.put("mode_error", "1");//I/O error reading message table
prop.putHTML("mode_error_message", e.getMessage());
}
}
        if (action.equals("view")) {
prop.put("mode", "1");
final String key = (post == null ? "" : post.get("object", ""));
message = sb.messageDB.read(key);
if (message == null) throw new NullPointerException("Message with ID " + key + " does not exist");
prop.putXML("mode_from", message.author());
prop.putXML("mode_to", message.recipient());
prop.put("mode_date", dateString(message.date()));
prop.putXML("mode_subject", message.subject());
String theMessage = null;
theMessage = UTF8.String(message.message());
prop.putWiki("mode_message", theMessage);
prop.put("mode_hash", message.authorHash());
prop.putXML("mode_key", key);
}
return prop;
}
}
