/** 
 * Smoking Wheels....  was here 2017 qgiodbmdyejphuahpuwjkwauihdhhghwffygsusafrriewrq
 * Smoking Wheels....  was here 2017 yfzacgdrbjjsiygxmxgcfmzcdhyqenozficgrsipwkaaxeax
 * Smoking Wheels....  was here 2017 ecjabbpsnkkfbnrogzqynndtithpkpppfrwexdurenptubxl
 * Smoking Wheels....  was here 2017 ckyjclgdstrcfnigvtwypgcyomoiwwpamfghwoyqcaaybctu
 * Smoking Wheels....  was here 2017 stndmqqchhposjjfmcxlbcrzrmlhuxatndnfltwdrggiddgq
 * Smoking Wheels....  was here 2017 fbesvcpybavztqhateazqwzpudufpponbugurrxzhtkvrglb
 * Smoking Wheels....  was here 2017 dmcoyqgidgfdsfvkikvlmmjphxtbybfjcxebvnqkpgyrpwmh
 * Smoking Wheels....  was here 2017 emwpvdxezmyyhexiglawwekdvpuyuqfnwjiinvytmwkgdoww
 * Smoking Wheels....  was here 2017 krhxvweodolqmwtdshqphmyqfhnkhxyowjafnhwqzwvisehn
 * Smoking Wheels....  was here 2017 baismjxxmnipkxvhhzzerbcspgvbxtfewhsnxwtzougvavsh
 * Smoking Wheels....  was here 2017 orgrqgewdqnomewpqbolzydgiaxyigykwvgiyvexuldyyvjk
 * Smoking Wheels....  was here 2017 tbrphpihnldnmtuavdemoiskbkcfluinbxqzhrbunvcdswsk
 * Smoking Wheels....  was here 2017 nvhnvpyifuqpgawubcvpyspnrldhnzwbardzqckhyhccttla
 * Smoking Wheels....  was here 2017 fxdvtswjbqqganonveujzvzgfkwxxrgsknggdbohjigusooh
 * Smoking Wheels....  was here 2017 hlobxseagiagfeoxxtqqsqdnexlahymnhfvuawexltyjoshm
 * Smoking Wheels....  was here 2017 mxabhogfckammcuyhmcmlkrkbqhvrdtuwowyyxboaqwimtab
 * Smoking Wheels....  was here 2017 vxhvhmqchqyevooyfifesokiusbtfxnyquqipzgvgfwjxpnw
 * Smoking Wheels....  was here 2017 mklukyezpcmtjggkekhjjxlynkqnhcmvkhqrdaermceknhuw
 * Smoking Wheels....  was here 2017 botmmsapfboyozqcxeuvlidcogebquqlctsdvhjejadrgfyh
 * Smoking Wheels....  was here 2017 ftrsotktnbhrdwrzkhoqhebyoacpfjfazcvafgrtsbkpgaos
 * Smoking Wheels....  was here 2017 zscoyhaqcxcdyhnjyrodkubwjvaodlpbpmhxdreasmxxamhv
 * Smoking Wheels....  was here 2017 phyjeuqpvrqvfustamdxpafndxxqwvpipippqmgxrvtmetbs
 * Smoking Wheels....  was here 2017 osordakhvoujjhxwiduszuxuguvucqdxbhoeaymmgykpsdep
 * Smoking Wheels....  was here 2017 qjljvypqmftucwcuyhgsviqthigfthlzfhfzwmreivmrtibz
 * Smoking Wheels....  was here 2017 uyklnuvskjwgiwntaxqerejwdoukahybnnvozxxqztwkudkr
 * Smoking Wheels....  was here 2017 hikhwazxmcvegypfdcdskzbtxsjziokzujxtkepsqiutlqfq
 * Smoking Wheels....  was here 2017 qsulpkcxuqoiiwbaziicztdhzjdykftrynfplmgoxhoxsfrd
 * Smoking Wheels....  was here 2017 nnbsvxnotpdpevxdpgzlusepzinmcoflgwvmrjuoprwisnhs
 * Smoking Wheels....  was here 2017 akygvsvaytafudhweudcjjabuqcbrggtgqzzxmfjxvpsyisc
 * Smoking Wheels....  was here 2017 igohejyrhcvqhksqhbaomlsjnowjmcolqegvewywehyzbtyi
 * Smoking Wheels....  was here 2017 yhdmrpvewannenxhpofsgyrjnqxihgemlfjfutndauhjzffr
 * Smoking Wheels....  was here 2017 qxfojiyjbzewcnuvexmpzakelsqdzagdxpkjjouqilhhygzp
 * Smoking Wheels....  was here 2017 juosovuknugvavpmfavpefufeushtagxnooyqcvzfmvmhuyx
 * Smoking Wheels....  was here 2017 lveewpgrbnjxbzvtfcofrgydtebmbexozmlrsiabambwuwbp
 * Smoking Wheels....  was here 2017 hfknaikuvkmtsxdlyofhodeuqkvpomfcjbuswkyakfkrivoy
 * Smoking Wheels....  was here 2017 sisqdapsfbriqrnnjanxcabhkhjxejiuxfrjrxkfftnicjxl
 * Smoking Wheels....  was here 2017 qwxonxlnugjvuqeiulnlwlmcyvkwckteabheynnhpkhnoguv
 * Smoking Wheels....  was here 2017 ktaqrlspmzfsikqhqznjrdmujjtcumeaobfztgpdxqwfjqfe
 * Smoking Wheels....  was here 2017 kehjmjopkpesrvnesbappbkhbkrpxrpglxgwjhhxuiqqlwks
 * Smoking Wheels....  was here 2017 mmhryshkwqisoavbziudxlxrqumpjjegyljejdkyblheaoty
 * Smoking Wheels....  was here 2017 okupkqneowcywjvdsswjfutkymvmkdlkoxxlpnaywjsomnbq
 * Smoking Wheels....  was here 2017 ywulkrbgjidwukxzjkovgvbccwszlwcpbrinblltqobtnxgu
 * Smoking Wheels....  was here 2017 bzottmahijieuauhsvjjdmepnkebcpbtkklmbcjoxvtycbns
 * Smoking Wheels....  was here 2017 serlndsewlwunjndtpcaebrcvyrwkupdwbhpfznrogjpkpjw
 * Smoking Wheels....  was here 2017 wexnzvtbpkeyysfssqsexakyvmwxlydixudnhvbtucxjuima
 * Smoking Wheels....  was here 2017 uvgitzaikhvbgtkpdeniebmusjpwtzkahanajphtwylgbkwf
 * Smoking Wheels....  was here 2017 zizlpknqjktwvgtnrpcjzefnvdcrxajgakefsovsmnlkbers
 * Smoking Wheels....  was here 2017 edrrobquxgdijkhnlodiqpehtntoyighivejyencnxmizflz
 * Smoking Wheels....  was here 2017 jwbdaezaqqiowndupztotvflkpexzpnqtnudvelmakorikvu
 * Smoking Wheels....  was here 2017 ulecmfiqjpbckewxqadpdplqysgnlrwbzxngloxulotkrwvf
 * Smoking Wheels....  was here 2017 yaidtxvihmdpnhdqjdwiuwfuqifgcphpaoewbmnejdmtbxql
 * Smoking Wheels....  was here 2017 pczdxgvzttuavxwytysubvbzegkiuuzlemtghndzqekdpetz
 * Smoking Wheels....  was here 2017 sgzdgmwskgkphljcakshmbxqlongswjewvoaxjwvkalgsnvr
 * Smoking Wheels....  was here 2017 oliliauxbapsblbqrrdlxftjnokqipgmwacyazzrbesaeaxm
 * Smoking Wheels....  was here 2017 rvhqzstfvjhcqvqinemajhzcutgnienmfseewpdqfkqsvbdq
 * Smoking Wheels....  was here 2017 svjpfkanetqrqqceloodeneywylaqxlicuuzasdbruxtxgzs
 * Smoking Wheels....  was here 2017 sckhkleyqbbsahqkutkdwjehqdrqllmpamgyiccprqiuukfk
 * Smoking Wheels....  was here 2017 yokdbgdxdiepyisoayhnhqcufsubdphateaxvqidmmdvgruu
 * Smoking Wheels....  was here 2017 xkqraoyztuxbxqbkwmrelfghzdyflmxqgnyxvqlwucrbdjwc
 * Smoking Wheels....  was here 2017 hbptiiydwakbniqyidlesjfyngpiilmsvmahxohcknqyrdzv
 * Smoking Wheels....  was here 2017 dddkhwsldubtttrlrtovppwdtcjvxcnsyeoqvdxmncydhuuu
 * Smoking Wheels....  was here 2017 rpfylocikeopvnpkjmhrypgouxdlpitlibaurirymhsprnhy
 * Smoking Wheels....  was here 2017 kpdaqffkumticmdpevfpujtazhccefcwzuguujfpwziotoro
 * Smoking Wheels....  was here 2017 cokjxtjoqfvvhthacjbpldysyapanduhehgyrthvpdmlsqld
 * Smoking Wheels....  was here 2017 sdvdpleyqefkirfyjcxcmkqzodjqvqhgjsgxdfahtbbyzmgn
 * Smoking Wheels....  was here 2017 mglpftlzplmkkvlxmdzpswzmzxgpmqiljmwkhsuvtieafidp
 * Smoking Wheels....  was here 2017 zcnjplhfrgpoycqqexvyengcnxkygewxchupkndqetixklgt
 * Smoking Wheels....  was here 2017 wbnfulbpfesvqqtdmcffdqczwyfvasdxvzdsbcxbyicaslck
 * Smoking Wheels....  was here 2017 evihczhgwzekksbsqpfsgpinvaksztnycvcladftcijaofji
 * Smoking Wheels....  was here 2017 dhxwcpxomustlzavdpabhfahnlvhoevvpegnkqkocjjypvbp
 * Smoking Wheels....  was here 2017 hrnmpyyeeueofghhrngahlnhktqmldamjsjamwarnflxvsjk
 * Smoking Wheels....  was here 2017 iitbqctyjpstiswciaqsonlnzufnoyggpimivhxmfwgkkjti
 * Smoking Wheels....  was here 2017 hyipofxbpzuouqymgzflrxqmfngwceapvgwzfpfoirscusxb
 * Smoking Wheels....  was here 2017 jmhlwugwuzzltsayaqgukjdufhqfnuahvwavtugwgdyapvvq
 * Smoking Wheels....  was here 2017 dbyeloxabxgbqsvijjgpxwhghpnllugjnvsxtdomobkgvcti
 * Smoking Wheels....  was here 2017 gcuphmekugrjethohwbxjptcdhhwwoxbfbboscbwensjqdcq
 * Smoking Wheels....  was here 2017 uhpvswrdowtpfgpyzaralchrpjqwzslxjtfjnjuoettyltpj
 * Smoking Wheels....  was here 2017 yokdhcfqhubeathazaipxcbqtdldddprtivddzcnyjsaybfm
 * Smoking Wheels....  was here 2017 gandvyxnbhnvzeamagpjuniwaevqcxiiikpyzcovccztcleg
 * Smoking Wheels....  was here 2017 kekqkkcrhxilvnujdkgmkqslafgotjvdjyodnhbyoafqbmye
 * Smoking Wheels....  was here 2017 lpxshrjgnlvhlgvynlifjxcvpiikhcprkcagpfrljkhhgbfb
 * Smoking Wheels....  was here 2017 pgzrchopsyrtaynsslbelcnqxvzueaiqdhldhwsfyvktkfyw
 * Smoking Wheels....  was here 2017 kiydoxtkysvpakqmkxadreithfitbfzbneswwntlxbxdkkjw
 * Smoking Wheels....  was here 2017 nfjxuohnohjscuefqlzfkidikhvkxbufxstuypsmddnylezp
 * Smoking Wheels....  was here 2017 apyaclucgltiekherzytecusbdbgwcfpsaxlgwpysjbxzjlv
 * Smoking Wheels....  was here 2017 cjtvacanvfpxmymwysfgueiolazzkfyysnrqyhuuahtxsdto
 * Smoking Wheels....  was here 2017 hsbyjedllyvclelcgbhqioctxmtoenzixxwmgcxbsrzdnuda
 * Smoking Wheels....  was here 2017 ibjcfsmsldpxsfdvoqywbmtlaisdcknznclhtusfqpjdpyzt
 * Smoking Wheels....  was here 2017 fanmvxpnlphnfmujdlgjpkbasopekkblbgsqgbjwxjvmkmcm
 * Smoking Wheels....  was here 2017 epmivgjejjoifnwflomrsceccngknkgkhtgjvxdxxmngpmkh
 * Smoking Wheels....  was here 2017 txngznwjhsidafcchmcpmmjpntvucocyeitmupsmgswndidj
 * Smoking Wheels....  was here 2017 qjgbjpkzpftulqlapuyfevhpqatmcdvhywikrowyuenvfoth
 * Smoking Wheels....  was here 2017 vrivhuqexreoifcirnavkptohjryruwyeoeqiorysdiwfdyt
 * Smoking Wheels....  was here 2017 psxxhoihbciwwlnlzsqcznvbpcmwhkysouwatonjidmnwbrv
 * Smoking Wheels....  was here 2017 lreweqqygubkohlehxgtxqxaztjfqabpbferhuykgykbbtet
 * Smoking Wheels....  was here 2017 dzrmazwcuhodauvnorsyncnnzcqfpajuzudwntwjkqsxbuya
 * Smoking Wheels....  was here 2017 phfwewpwikfgeixtbzaxjkoaogbglbkxvraefdhxwmisfaqk
 * Smoking Wheels....  was here 2017 dmujctrpseqfhmdjizlhhhcdtlmbnxvqhhillzqybajnfphy
 * Smoking Wheels....  was here 2017 furmrifycxursdfdacnxitltzfapnspajhwtmlkpnchlbvav
 * Smoking Wheels....  was here 2017 opldzqouvcurejcbezzvuafzvjdblvzijprkzbmffrszwijr
 * Smoking Wheels....  was here 2017 govigwghnobippalboyifogffzmwkwkaskzzrnznecnvczae
 * Smoking Wheels....  was here 2017 lqwkboevbjgceilsdaqblcqdgiyuwrpyfcjipwfivxxylwzi
 * Smoking Wheels....  was here 2017 szvyhijbougsincseuounqsohxqrnjmavipndguuuwhmuikl
 * Smoking Wheels....  was here 2017 tzhtxhgvkjfdsfykemoqtkbsyoauhhjovbqvvfnixbgxkzuz
 * Smoking Wheels....  was here 2017 oiyxgoihexonhtecjbpwrwowcispjbqcrlwwlmmnitszqsvu
 * Smoking Wheels....  was here 2017 kyxuxsnvukxihugggrzcdtgtwmqsdnaidwtlbzchlnxogonu
 * Smoking Wheels....  was here 2017 tzjxrkvbjgehbexrptfdfamgqpxejtmiebbrzawuucdxczbg
 * Smoking Wheels....  was here 2017 jwycprrxgwohizciiyccdzwlalzeyegicxvvuaqjiockkmxt
 * Smoking Wheels....  was here 2017 ggjlzsqncdkpbpbnufrgnaftwbmcaivvjojnhsordfrvqyta
 * Smoking Wheels....  was here 2017 rcqgkzmgtcjqjpgskqeeeyrujsirccvptlenndypopacknqa
 * Smoking Wheels....  was here 2017 bobdrhjsizjbtwjsytesdrnmuaqxvpirfgbzuljhhmplsnsc
 * Smoking Wheels....  was here 2017 fafxuoqwfjoxvmknkclytmjywsvxdelhzwzeqercdyzfromr
 * Smoking Wheels....  was here 2017 deupeavuabihpvnkaszfnvaojwoeflszpmhryayshgcfumqp
 * Smoking Wheels....  was here 2017 axvphevwpcjsemgwirbahlqzmtskmfvmvnmisaozaxcjrkdv
 * Smoking Wheels....  was here 2017 klrlyssudtnwbigqamggchnbnxmoqrtvpphfgibbaukviseq
 * Smoking Wheels....  was here 2017 aeuyhrvjypzsxlnucshzhrhzeegupcrgfsvqdmihexrcxzho
 * Smoking Wheels....  was here 2017 wtyfngtvrkekrfgnwjfnkzscgnrppdcidzideekkontwvbdh
 * Smoking Wheels....  was here 2017 fcgnhyimefrkmfyktoilfzybyiqqzqstcviqlkrenfvbuary
 * Smoking Wheels....  was here 2017 nkwnimqzoillvihensdovrisobhxnrnneypcejsvuuixtier
 * Smoking Wheels....  was here 2017 nclytuagghpljqgvfokyohkhtnbodrrznfdxaqiscfxuwmbc
 * Smoking Wheels....  was here 2017 huryvfcjvxppamaraxeyxgabjupbyesorvgrtvrmrwknojbw
 * Smoking Wheels....  was here 2017 zlpvecrudfakanddlascsjitneuclbhcjendkaazwgayndcc
 * Smoking Wheels....  was here 2017 dfndnhvcjmvmtpfbhgphbopfqeurhkjopzqkijakgedisblz
 * Smoking Wheels....  was here 2017 nnxszrzevgdwxuhlmhnogclphozylqfeqcqvakmctrlbhvob
 * Smoking Wheels....  was here 2017 cbqpvoqffijsllpnhcpfuksgjlbiahhnztwyjvmslauxrgdb
 * Smoking Wheels....  was here 2017 crqfrjqnhuelnenvfuavohmwzbxpoggiihtpkqkdsujupldb
 * Smoking Wheels....  was here 2017 bpgahxdvhwlvoxvczujgordhnzrqqqcpslewkbumftowyttg
 * Smoking Wheels....  was here 2017 sgzxsbkyneithqmjqtkodverpatshtbpjdcbyomeuyaqytne
 * Smoking Wheels....  was here 2017 agpyhccbplglqurwjrebvfnkbevepgowvmvtvwqvosqvzjcq
 * Smoking Wheels....  was here 2017 hoelonznkswisywdsqyilngdbttvbzjetxwudanixnphurmo
 * Smoking Wheels....  was here 2017 zhxyjbfzbibdbzvzkbgfburszitojbklfdageetvlfhigbwg
 * Smoking Wheels....  was here 2017 wykisrchzvyuhzmikrvtygjhkqdpkuxblagklvdsavjhpbsg
 * Smoking Wheels....  was here 2017 xdjrypgrsyanjhalajthsifgfuqjkvilxuywwtvpurtzfoth
 * Smoking Wheels....  was here 2017 iuwgpimleuwtlnyxthhjdvhhnacotajjkunmkwdjdgogvryj
 * Smoking Wheels....  was here 2017 scfrnowgmpkfzozlgwywhryfswseelbwwtvhjmqfqjejitmt
 * Smoking Wheels....  was here 2017 slwtshvzzytvqnbbqunvmctelewjpmnfpoxpjzelfchtykwz
 * Smoking Wheels....  was here 2017 kmqootwuiqjtjrkbbyapgpnpnzgpeshxbkyafevtxrvdcnuv
 * Smoking Wheels....  was here 2017 zeolnlvbjrxnjsnwbntslykbcorojbbrzsnjxzzaesxkldff
 * Smoking Wheels....  was here 2017 yrwymcwlgkfublbijyfabasnnkkgvouplclsusfjpyxvyqkn
 * Smoking Wheels....  was here 2017 bkewmqgtiimncaakzwfpmdbblktuooswpnskktieblnuuqte
 * Smoking Wheels....  was here 2017 haejvjqfffcxltpjdettetfctnkrrsgbydpzpxkbqnqbjzzy
 * Smoking Wheels....  was here 2017 ylyscsvetetjhghtjccbbpjgndgoqwewijqgkcwztqlnludx
 * Smoking Wheels....  was here 2017 lwsmblxgdmhqajuhkavjcqtldrmmdcjjqwoidpfaargkwkig
 * Smoking Wheels....  was here 2017 prbmtnfjsrwrkgbafqrtqdbtgalobudtepmnjxioirudwlcn
 * Smoking Wheels....  was here 2017 insvoejqbnyqhfhecurmgnbprfwhqoxpkrqlwrihtwymvtcm
 * Smoking Wheels....  was here 2017 zjtvawembbdaxwahmtcfsovpomoiifkrcnnwszmarvwhnkjc
 * Smoking Wheels....  was here 2017 zjlbxjtmxqimrbxdewnsdguriltrtxoxfwzwfykysjzwvvbs
 * Smoking Wheels....  was here 2017 cygihqkowtrzhyyrdvqbtumynvumwyqqbozuxezlumwoxpqu
 * Smoking Wheels....  was here 2017 hsbsnwuvqeqtrvhfpoopertuasjfwzbjcuuerhgdynmdfnwc
 * Smoking Wheels....  was here 2017 wruocqrsbaufaimgdfnxfprvzkipewovbzaxmipxqzanmtrq
 * Smoking Wheels....  was here 2017 hyukwoevhocbthfokfatxppzukxomqcazujasmoxkruyorhr
 * Smoking Wheels....  was here 2017 hyodwsqbqhrhovkdlgxhpwckaomhstxhbdxwwhanermurvet
 * Smoking Wheels....  was here 2017 xjwtkhqotbyajiigmfdutxblowqfbtkavfwzulajafavgcbo
 * Smoking Wheels....  was here 2017 iduqbtarmwntjjkkagbwhlnsnpjcynjcakvfnxzjjwozaowf
 * Smoking Wheels....  was here 2017 cjnipwxcaajezukjvvdhflweijtwbdslqkoqkzkqvllkvqvw
 * Smoking Wheels....  was here 2017 zmrqdoorrcpgysfewpefverwnygsiyskxdaoybeogykpyxlc
 * Smoking Wheels....  was here 2017 xfzszdrobvpdcmdalmewsbthaimbyptkispozxjutshgsekr
 * Smoking Wheels....  was here 2017 dlmuqaacchbjstomyqmwrwfzywjqjypgrqtmpniesggixpqo
 * Smoking Wheels....  was here 2017 fikmyyrawuwndighfmobuokxqbbkfbeyymgjbdrwtjtaknkb
 * Smoking Wheels....  was here 2017 whjqyxacuwerdhdmfremhjxdttxnmhutigdpxefhtcjskoer
 * Smoking Wheels....  was here 2017 bachzeqokhjxpbmhfelnvuoceyqlihuejbsralabusafioqd
 * Smoking Wheels....  was here 2017 bkpupdjtqcdttfrgrcordomkzxdxfxzzujlmkwlbivxkxptm
 * Smoking Wheels....  was here 2017 jqfspphhppjxzpnciwbuiqyzogmvtfgfquebjsdkxekmabtz
 * Smoking Wheels....  was here 2017 sckwantdrjegyjxwfetzshpxnselyowccgysnlwnkvdxwocd
 * Smoking Wheels....  was here 2017 cnzifdiimdabrucupzqnuygqtjveyphdrzybpuszzbakwyns
 * Smoking Wheels....  was here 2017 utzksxwiwzntgonlxjazliasjnisfdgcdityssctzkfxtiys
 * Smoking Wheels....  was here 2017 gaqsioltyfpaflynxujgrmgdtrwzkiramaejemnybrdpkaqk
 * Smoking Wheels....  was here 2017 gsnbcclmdijvdqgbqxoiupmymqvglmueyxesmowxaylxbrah
 * Smoking Wheels....  was here 2017 umjnjtkqbehiakthhrnpkeppmlvyofbaafcnnrgiblzpcdve
 * Smoking Wheels....  was here 2017 cggksafqntybalvukfpphyrrwkvsdkeilikqhuybmszpfmaz
 * Smoking Wheels....  was here 2017 rflhwpycrjhqpoghryhenvadzbxpwdeefyxcdepgyptbjcub
 * Smoking Wheels....  was here 2017 hulzylxxxombkwzteojkjdhameostuftqyqhphahidbmsprx
 * Smoking Wheels....  was here 2017 xpbpgvsfwdwmksenczxokhhuevjnwytocnwtnwiuspsosvhf
 * Smoking Wheels....  was here 2017 tqhligfkicektsjbyjcgmbcbgiguslnllcchxxvrnnwfawrc
 * Smoking Wheels....  was here 2017 jzkczkmcnugnxsgeldnipkbrbekjzlniqieacpdbiszrpcas
 * Smoking Wheels....  was here 2017 ndzjhhwettgtnvtuqyzvcpuweednogxoxdbfqkbjbfsjpdtq
 * Smoking Wheels....  was here 2017 dstjocyuqtphokdgsslcnbcyojfsrmeotramidtethwamurq
 * Smoking Wheels....  was here 2017 nqtjijpjcvypfbwafqgssncogblosabdxjqrgslkwosoygrs
 * Smoking Wheels....  was here 2017 ccgzluvmfhekwqqxxbwlsacprtackylikxrvskvezspewtzc
 * Smoking Wheels....  was here 2017 snvzxjbajrlpgfkwstclustfkijmrqqimeeggrsxywdimaci
 * Smoking Wheels....  was here 2017 hnenbiwefuelhfkfyozzoevuitcesqbsqjiosffeyhitevre
 * Smoking Wheels....  was here 2017 cbkwmcbhorajdfclbrtruakypicwxwlfpxuncbpygofirhtq
 * Smoking Wheels....  was here 2017 phtqymtaopvagbehvnaioixppppnzltwjlfhukmhpkhhxvmz
 * Smoking Wheels....  was here 2017 pqtpnlhfocvkiwqtftmzehwvwjyivqewewsdhutquxdcbzjs
 * Smoking Wheels....  was here 2017 ctdwnffbfajthzremiezfkdcistssdevokoqkwmpyjsmopdp
 * Smoking Wheels....  was here 2017 gpatmflxkidkhzuzeilyljuzcwalztnkglfpfqzbmhdhbvrq
 * Smoking Wheels....  was here 2017 qhqvggzlfkzevuqzygsqyefkokvjjqdrfrnebjvezmvvnahc
 */
package SevenZip.Archive.SevenZip;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import SevenZip.ICompressCoder2;
import SevenZip.ICompressCoder;
import SevenZip.ICompressFilter;
import SevenZip.ICompressProgressInfo;
import SevenZip.IInStream;
import SevenZip.Archive.Common.CoderMixer2ST;
import SevenZip.Archive.Common.FilterCoder;
import Common.LongVector;
public class Decoder {
	
	private boolean _bindInfoExPrevIsDefined;
	private BindInfoEx _bindInfoExPrev;
	
	private boolean _multiThread;
	
	private CoderMixer2ST _mixerCoderSTSpec;
	private final Vector _decoders;
	
	public Decoder(boolean multiThread) {
		this._multiThread = multiThread;
		this._bindInfoExPrevIsDefined = false;
		this._bindInfoExPrev = new BindInfoEx();
		this._decoders = new Vector();
	}
	
	private static ICompressCoder getSimpleCoder(AltCoderInfo altCoderInfo) throws IOException {
		ICompressCoder decoder = null;
		ICompressFilter filter = null;
		
		// #ifdef COMPRESS_LZMA
		if (altCoderInfo.MethodID.equals(MethodID.k_LZMA))
			decoder = new SevenZip.Compression.LZMA.Decoder(altCoderInfo.Properties.toByteArray());
		if (altCoderInfo.MethodID.equals(MethodID.k_PPMD))
			throw new IOException("PPMD not implemented");
		if (altCoderInfo.MethodID.equals(MethodID.k_BCJ_X86))
			filter = new SevenZip.Compression.Branch.BCJ_x86_Decoder();
		if (altCoderInfo.MethodID.equals(MethodID.k_Deflate))
			throw new IOException("DEFLATE not implemented");
		if (altCoderInfo.MethodID.equals(MethodID.k_BZip2))
			throw new IOException("BZIP2 not implemented");
		if (altCoderInfo.MethodID.equals(MethodID.k_Copy))
			decoder = new SevenZip.Compression.Copy.Decoder();
		if (altCoderInfo.MethodID.equals(MethodID.k_7zAES))
			throw new IOException("k_7zAES not implemented");
		
		if (filter != null) {
			FilterCoder coderSpec = new FilterCoder();
			coderSpec.Filter = filter;
			decoder = coderSpec;
		}
		
		if (decoder == null)
			throw new IOException("decoder " + altCoderInfo.MethodID + " not implemented");
		return decoder;
	}
	
	private static ICompressCoder2 getComplexCoder(AltCoderInfo altCoderInfo) throws IOException {
		ICompressCoder2 decoder = null;
		
		if (altCoderInfo.MethodID.equals(MethodID.k_BCJ2))
			decoder = new SevenZip.Compression.Branch.BCJ2_x86_Decoder();
		
		if (decoder == null)
			throw new IOException("decoder " + altCoderInfo.MethodID + " not implemented");
		return decoder;
	}
	
	private void createNewCoders(
			BindInfoEx bindInfo,
			Folder folderInfo) throws IOException {
		int i;
		this._decoders.clear();
		if (this._mixerCoderSTSpec != null) this._mixerCoderSTSpec.close();
		if (this._multiThread) {
			/*
_mixerCoderMTSpec = new CoderMixer2MT();
_mixerCoder = _mixerCoderMTSpec;
_mixerCoderCommon = _mixerCoderMTSpec;
			 */
			throw new IOException("multithreaded decoder not implemented");
		} else {
			this._mixerCoderSTSpec = new CoderMixer2ST(bindInfo);
		}
		
		for (i=0; i<folderInfo.Coders.size(); i++) {
			CoderInfo coderInfo = folderInfo.Coders.get(i);
			AltCoderInfo altCoderInfo = (AltCoderInfo)coderInfo.AltCoders.firstElement();
			
			if (coderInfo.IsSimpleCoder()) {
				ICompressCoder decoder = getSimpleCoder(altCoderInfo);
				this._decoders.add(decoder);
				
				if (this._multiThread) {
					// _mixerCoderMTSpec.AddCoder(decoder);
					// has already ben checked above
					// throw new IOException("Multithreaded decoder is not implemented");
				} else {
					this._mixerCoderSTSpec.AddCoder(decoder, false);
				}
			} else {
				ICompressCoder2 decoder = getComplexCoder(altCoderInfo);
				this._decoders.add(decoder);
				
				if (this._multiThread) {
					// _mixerCoderMTSpec.AddCoder2(decoder);
					// has already ben checked above
					// throw new IOException("Multithreaded decoder is not implemented");
				} else {
					this._mixerCoderSTSpec.AddCoder2(decoder, false);
				}
			}
		}
		this._bindInfoExPrev = bindInfo;
		this._bindInfoExPrevIsDefined = true;
	}
	
	private void setCoderMixerCommonInfos(Folder folderInfo, LongVector packSizes) {
		int packStreamIndex = 0, unPackStreamIndex = 0;
		for (int i=0; i<folderInfo.Coders.size(); i++) {
			CoderInfo coderInfo = folderInfo.Coders.get(i);
			int numInStreams = coderInfo.NumInStreams;
			int numOutStreams = coderInfo.NumOutStreams;
			LongVector packSizesPointers = new LongVector();
			LongVector unPackSizesPointers = new LongVector();
			packSizesPointers.Reserve(numInStreams);
			unPackSizesPointers.Reserve(numOutStreams);
			int j;
			
			for (j=0; j<numOutStreams; j++, unPackStreamIndex++)
				unPackSizesPointers.add(folderInfo.UnPackSizes.get(unPackStreamIndex));
			 
			for (j=0; j<numInStreams; j++, packStreamIndex++) {
				final long packSizesPointer;
				final int bindPairIndex = folderInfo.FindBindPairForInStream(packStreamIndex);
				final int index;
				if (bindPairIndex >= 0) {
					index = (folderInfo.BindPairs.get(bindPairIndex)).OutIndex;
					packSizesPointer = folderInfo.UnPackSizes.get(index);
				} else {
					index = folderInfo.FindPackStreamArrayIndex(packStreamIndex);
					if (index < 0)
						throw new IndexOutOfBoundsException("PackStreamArrayIndex: " + index);
					packSizesPointer = packSizes.get(index);
				}
				packSizesPointers.add(packSizesPointer);
			}
			
			this._mixerCoderSTSpec.SetCoderInfo(
					i,
					packSizesPointers,
					unPackSizesPointers // &unPackSizesPointers.Front()
			);
		}
	}
	
	public void Decode(
			IInStream inStream, long startPos,
			LongVector packSizes, int packSizesOffset,
			Folder folderInfo,
			OutputStream outStream,
			ICompressProgressInfo compressProgress
	) throws IOException {
		
		final Vector<InputStream> inStreams = folderInfo.getInStreams(
				inStream,
				startPos,
				packSizes,
				packSizesOffset);
		
		final BindInfoEx bindInfo = folderInfo.toBindInfoEx();
		
		if (!(this._bindInfoExPrevIsDefined && bindInfo.equals(this._bindInfoExPrev))) {
			createNewCoders(bindInfo, folderInfo);
		} else { /* should not happen, as far as I understood... */ }
		
		this._mixerCoderSTSpec.ReInit();
		// this._mixerCoderCommon.setCoderInfos(this._decoders, folderInfo, packSizes);
		setCoderMixerCommonInfos(folderInfo, packSizes);
		
		if (this._multiThread) {
			// _mixerCoderMTSpec.SetProgressCoderIndex(mainCoder);
			throw new IOException("Multithreaded decoder is not implemented");
		}
		
		if (folderInfo.Coders.size() == 0)
			throw new IOException("no decoders available");
		
		final Vector outStreams = new Vector(1);
		outStreams.add(outStream);
		
		this._mixerCoderSTSpec.Code(
				inStreams,
				//null,
				inStreams.size(),
				outStreams,
				//null,
				1,
				compressProgress);
	}
}
