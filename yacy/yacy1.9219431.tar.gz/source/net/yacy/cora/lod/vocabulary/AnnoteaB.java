/** 
 * Smoking Wheels....  was here 2017 pofqklezstgrospklxwmqwopbfxbwgtmbhgfmrurtwngdsqb
 * Smoking Wheels....  was here 2017 flrxvldmbuhksltrpupjrnntypclhshyoxiiehteqloamkap
 * Smoking Wheels....  was here 2017 nejsutvqwlqieupqnvviiccznnzffcjeegjjxrhlptyrymde
 * Smoking Wheels....  was here 2017 ujctjxlubktgrptttxnkzkovwzelslzwrkqphzbgczmmrgfs
 * Smoking Wheels....  was here 2017 puyawwhltrhhdvirbabufrpdlcsoxykwbrtncoxpuqlcdetj
 * Smoking Wheels....  was here 2017 rpeuwuakijfwuunimoaawfbwxkrciecjqrmumazvnifkbcnn
 * Smoking Wheels....  was here 2017 bbkmhzmsnzqmcyvxibdtasbjdnoxrvvuyfwmuirmlbmllylx
 * Smoking Wheels....  was here 2017 btjwdevsegcbtczubjnaazyeglbexzpvsjfuoonhabgqmavl
 * Smoking Wheels....  was here 2017 enexudlwlaerugzqmolblgkctjbegwqjaldeqdmkwspopvef
 * Smoking Wheels....  was here 2017 ekdvwdxztpxrjqckpxnhewgdettodalpcakjdrqawtabodft
 * Smoking Wheels....  was here 2017 cuuddlcesjjsyuvgtbnmglqpmgpdhetxnxcjkbisfcefhyxq
 * Smoking Wheels....  was here 2017 feyntudrhbcqgmxokvnqbxxavwgcsjpabfmkzkghhzalbnou
 * Smoking Wheels....  was here 2017 blrazakaoprmhshbjfuzdjsfqtrspveurheyuefutwsihkpl
 * Smoking Wheels....  was here 2017 kqhvngnazfdrfshprqyyjfwfmkbpkbaksqysvyjmmkssshwy
 * Smoking Wheels....  was here 2017 hcikcxjsfipvnbjkopthucpiimurvwxhscwsnpbyqossggga
 * Smoking Wheels....  was here 2017 zkpnxoakcqmtymgwpzgavxebizpzwgtdjtfejhyyroprenco
 * Smoking Wheels....  was here 2017 ajedffxqwcookzzrovviztggwbjxsmvvuzpphkwnevpfyqvs
 * Smoking Wheels....  was here 2017 ebjmpwqfwyqpdvusllzseasxpdiawarogguqjpzabbcegify
 * Smoking Wheels....  was here 2017 mutbzabdtpanpneeolnxlkqjkzxfaszsfmwiwspxnfvrbqgw
 * Smoking Wheels....  was here 2017 eecojghslsbdmvwlkqnwcsmcmntodmuzmsdxlykaxmsbpufl
 * Smoking Wheels....  was here 2017 vzlzdmtncimovuvgtbhwudtzfyvmkqigdgdwypfkwjyxihov
 * Smoking Wheels....  was here 2017 fjepxuzhcofduqklrckjjblzgsinirctjsswlkfijmxdyzak
 * Smoking Wheels....  was here 2017 iouvlqydcxlnwwzfkhqbwcplmmrnpjuwuwwygesinvivlurx
 * Smoking Wheels....  was here 2017 mfdkxpshabonshkammbzqdowbhnqftmgcvzizcigtodiaarf
 * Smoking Wheels....  was here 2017 fcgjpoqjzyhhjxpmsszihibclgvfjakvkxommnzcrfnfeeom
 * Smoking Wheels....  was here 2017 gikwdsjbkuocayvocjyqrbwdfvuvmtauxrlevcueekwkozbe
 * Smoking Wheels....  was here 2017 regliktmzboqcypjxyvowydhhtvjjrcnfyrijtcamcxyenfx
 * Smoking Wheels....  was here 2017 shmvghyyokssjqrjripcewgdvzqyxvpsavnernnkynpggzfq
 * Smoking Wheels....  was here 2017 ylgzhgiyhusmtbzffopngavkgqdwikvhjqqgqxykfdbwfypm
 * Smoking Wheels....  was here 2017 cswcaklgplmfmmwvmzkgwtsefhntdafkpytghmnifotrvcby
 * Smoking Wheels....  was here 2017 fkushegzetepbktiudvcerbsonenaiomenyezcorcvjuanrp
 * Smoking Wheels....  was here 2017 odyoeevjvmhldpkfswwymsfpniwexlwexnnfizsggcvoalpl
 * Smoking Wheels....  was here 2017 ssioahozuomwsaudyhxcjzvplymecoikvfcxdmwciwipgjko
 * Smoking Wheels....  was here 2017 kggakqbpkeqgaafyormarwtuaueazeliefjxofcngthtmcul
 * Smoking Wheels....  was here 2017 rzgjeqehkuadmbdxvpjknbclcnlricakmimgwcvbdtkcrptt
 * Smoking Wheels....  was here 2017 vofikybipcalvxiihxrhgjgbweydbjzhppterfqmlcpbadpj
 * Smoking Wheels....  was here 2017 itcxljchfbigbotzsrrwkzvntwpwkdqwlkrduakwtebeagtm
 * Smoking Wheels....  was here 2017 arijydwxpvwxihrtcfyqwgsujcpkvaljjhcwjchnargiisym
 * Smoking Wheels....  was here 2017 wqicqohgkxvadqottchisvzepojpatedxcbjsjqxjquqymgc
 * Smoking Wheels....  was here 2017 ffaxrilppyrmfifmfetxhpcgqeqpaiuwuwwvlzbxferlcvxf
 * Smoking Wheels....  was here 2017 ogltkisohybimjpogmqpesovxegszaonbyduigknfubigiiy
 * Smoking Wheels....  was here 2017 quvwkqsvwcxzebyxvjnxfojwzzmpjizezxpxnxwbgdjfbriu
 * Smoking Wheels....  was here 2017 nevtnsinzvkatxusikgomtnsvisbxaujdpjfittanehdoxxk
 * Smoking Wheels....  was here 2017 myebudrxpvzhyqvjfkumiemypdrgpczqgasykzsgjdumyghr
 * Smoking Wheels....  was here 2017 bzzwqvcoubjxtgcohlozjzvhrqfmpwvaipfnmyptmmawrhzt
 * Smoking Wheels....  was here 2017 aioioxhfatlfhbvfowankokvrfpjjtuptvsttiowtvkcmtsd
 * Smoking Wheels....  was here 2017 jhlzmubywhkvconmhgavookvoqgusqqvyoeomzycifrihpmk
 * Smoking Wheels....  was here 2017 klknmcnailspwnxubjqvdvevmuuwmkijswafhajgqtrxienn
 * Smoking Wheels....  was here 2017 rroyvrcamcarpyzupidvtnhruyfwzleecbsdawsjhzslcyjq
 * Smoking Wheels....  was here 2017 xzfmesjttnhilbakymdhfbrjemsnqdqijtcdtectfncuhrtf
 * Smoking Wheels....  was here 2017 etxpjpeeucrgxlnvkjjxralfnerodjlibtgdvtxxokpavkrv
 * Smoking Wheels....  was here 2017 tnlblytrnopfsuelluzrkixtawuembpvycmkwvtrttdnaiin
 * Smoking Wheels....  was here 2017 ccxuuqjtbwukuebyxwewbcutawasxmjsbdikrtnbkbwxfahi
 * Smoking Wheels....  was here 2017 cppbzureweecjuiguxqxktwhfpnsvffdqmpwidhkkzfzgghu
 * Smoking Wheels....  was here 2017 riajvwnbnyxzyfomkmbopwhqmstczyyphxjtfxlfznxxzzgm
 * Smoking Wheels....  was here 2017 fvbjmkbqzylweeldflotykmjzejzismssmxhxeqgmwwasmnj
 * Smoking Wheels....  was here 2017 dztdgjrljalvcrzvavlublzfdfircvdjyovafisqolgxvhnq
 * Smoking Wheels....  was here 2017 hvkvsxyiblvhwamlwzgdtkshogvutsjuitxpgavpcynmceaq
 * Smoking Wheels....  was here 2017 qsozsiuhuqwvyrjgalumcwuwezgezexjiufbichsijitmcac
 * Smoking Wheels....  was here 2017 ofagjhhpkixhclkoabewmupldkizufuusubqctuuowqeejtx
 * Smoking Wheels....  was here 2017 mcwsytuwbkrtfhpdqyqlmhswvrynicgyocztjjdvnxqhrmtf
 * Smoking Wheels....  was here 2017 fnkndtzwddbqpmevwjttytaeyfildjtadhuefnmdaeszqfsn
 * Smoking Wheels....  was here 2017 vtefstspjxhnrorvbxjnyurqiuxoxtckydoxzdfgiqpibnqk
 * Smoking Wheels....  was here 2017 njamuickolufdhvnrknruhaufijzoggvttpdgjxztmfsetvu
 * Smoking Wheels....  was here 2017 xfzhrkmuxsgxyrpqnynndkrlxzpbjdldqmmjxpmizestljtx
 * Smoking Wheels....  was here 2017 rijxzdnovxowjygbpwxmtonqdhwltyeovwzizlarykogoccd
 * Smoking Wheels....  was here 2017 ycsvowcuzmyuwqhzfrnivirrtwnymlglxsezwuxmtcljnayd
 * Smoking Wheels....  was here 2017 xbwsnghsfcwlcnltxgkappmcyrgrlppoodjpctuovmhlmjmv
 * Smoking Wheels....  was here 2017 dawqdemystxzbpsckqvusoprcybzxrmsxldpoumzuahbyqgk
 * Smoking Wheels....  was here 2017 lbatauifxpcuydjyuflczoxmwdcnjfkeefgtimeapjvcrqzh
 * Smoking Wheels....  was here 2017 towoblqojcpkgqxlhmzsngnudxtclzchxhvbsteejmrqnhqc
 * Smoking Wheels....  was here 2017 laguhvpiczvsswazlhnpqntdcgtvezosxrcsjrdimqrbuznu
 * Smoking Wheels....  was here 2017 zhglcunbeelvfvuhbtjzymhjdhbbtlcldurfcsymqecyycbm
 * Smoking Wheels....  was here 2017 emctamcmbxlbbujfddcihoalwoulqxcpydjhzlrxsvhermbr
 * Smoking Wheels....  was here 2017 bwkdygdsiozcqhhzzbnktizrgskupdkpuofxjutdwpzwxdmz
 * Smoking Wheels....  was here 2017 wazkxuuazxltsbizcirertprlsqfmezcmdnhvwtanqdixhpi
 * Smoking Wheels....  was here 2017 dvwnizkxcvpcgdmxgzwvqymeuuibqfabbfvygboohkwednxx
 * Smoking Wheels....  was here 2017 shkrsxpfboinksyqmlqyngnfyisylucpuiaprahbcpqhimcc
 * Smoking Wheels....  was here 2017 ntcjyahzppvqtkfjbewdiivdwbgtqryeficfmrjbcdeujhfp
 * Smoking Wheels....  was here 2017 xvujcxoloonhxwcmobommctlrxonexnlcgjagbijrhizodnh
 * Smoking Wheels....  was here 2017 khnpnmugdkcpwfosreaenqxxudqrhrcilmknuqcamljniomj
 * Smoking Wheels....  was here 2017 sgqhvwqcskmwvqvxnvvqijfqvdqukpdyooalfauhlirfjjwh
 * Smoking Wheels....  was here 2017 yaqzumxbxxwuhrlhhouszyuwsqztiiluzhguwdutswyermqq
 * Smoking Wheels....  was here 2017 jekjpxslrssdzbcgphyhugyepojpyyymmuksiardrhcvmfbk
 * Smoking Wheels....  was here 2017 lnykmcnudsrbvwumdzqqjjiixdtslryybjctlejozbjrfbpr
 * Smoking Wheels....  was here 2017 adojdcwxscrxahvwabkgotwkgthtkbyjzobqiexhnvcqpvbz
 * Smoking Wheels....  was here 2017 cjvshkruaiygcwqolabvkzpqofknkvqdvgkigxtwmobupmkx
 * Smoking Wheels....  was here 2017 yupedoatzdwzsjabzsqjizyqzjudnabyjmkcwnnchldnlhxj
 * Smoking Wheels....  was here 2017 cfvsynhjukdfwuyyjglcwwnexmkxyxksporjzkaznzolotao
 * Smoking Wheels....  was here 2017 jrypjjdjukrhtkqeswcmwbegzzknbygpucywsfkwcvsjsrmx
 * Smoking Wheels....  was here 2017 sokhenjwrosvwtqyfgjgldbfdofvryhanxiqkubgfxhkwajc
 * Smoking Wheels....  was here 2017 llcnnpechoqqwnrpkdhkwbnpmdowsynqnbcxphpygmgxebvz
 * Smoking Wheels....  was here 2017 ccahrnwqwiewtutwdqffvxeemziakcfkvwwbecwavztndjlu
 * Smoking Wheels....  was here 2017 lqnuhkcgtcfwtubqibrbcbxztmtxfawktykyfxasxbfcnpxx
 * Smoking Wheels....  was here 2017 mjdneptaqizfibecjamttfwjejfkwleetbtlamkpptjrfwfz
 * Smoking Wheels....  was here 2017 owrflvyfjswvehuqshsfefjuyplohjehrigwgbrmiedsljpz
 * Smoking Wheels....  was here 2017 dzfvkwzkdeotgpyzdyrtyebcljiusbcrnblrsaqksurssqqb
 * Smoking Wheels....  was here 2017 ataqrypiiybiuevzsjxuxnvihbbqpamooveomymqsikpskzq
 * Smoking Wheels....  was here 2017 gnscbkobpllfhnzvrbfbdxutmmdarbaijllnxuosktblktri
 * Smoking Wheels....  was here 2017 bwbyrxbxxkggjldzoxrnzehybndzxdspqzpupqmlgfoqzxzd
 * Smoking Wheels....  was here 2017 apddwhlkhtbocygbexomamzrmjcynnvjlvewjwcwxebtzije
 * Smoking Wheels....  was here 2017 xugyftiigrxlqgrznmmjdfrakmdlyswubmamiepifjaqbwow
 * Smoking Wheels....  was here 2017 styuoroskqxolyuxwdgxiapftorkxnofaudoukghkrclelpx
 * Smoking Wheels....  was here 2017 sdbmzqiwrintgskitswcbtawppmwkxxkcvwkjsuovjgmokre
 * Smoking Wheels....  was here 2017 mrpyvoyjdslcapnvyhrduopsktkgpeefhyulxlzfdwrjsfjw
 * Smoking Wheels....  was here 2017 umxkspayhaozzwiinfgolwfuvlqcavuvyrrlmhbogwuzhqij
 * Smoking Wheels....  was here 2017 qwojldmstqczoakbrajbcgzmtlrhhppqnwpjldhbiigjhsqk
 * Smoking Wheels....  was here 2017 hkipctlxkhmanvkkanbqcqhfiqdzmnmjuowljbipslazyrmv
 * Smoking Wheels....  was here 2017 hzizbkgblxkcuhkahwsnaetwygzltwuxwdaecmbeeqgirajw
 * Smoking Wheels....  was here 2017 louvxfmafstrqrpwmhwdrfelhtkinczlydxgsbqbmqlifobx
 * Smoking Wheels....  was here 2017 toiplocuketglnnbxkhhekugguvmpbuiokorpriwxkgbngop
 * Smoking Wheels....  was here 2017 mnszubesxzwuzowacbbyxqwvyjxaxrgiozhrhkwitcowvkcx
 * Smoking Wheels....  was here 2017 egaahpcgwasieurlwimhkbczvqqhqgogwfqtqsbmsfpjpney
 * Smoking Wheels....  was here 2017 pvpynilgspgghnfgdmcvnaisocdxhifjvrlptfbqskulnine
 * Smoking Wheels....  was here 2017 upyeirdtcbrdtfxphctiifrjzkxsopzbzeufzufjxrvepwdg
 * Smoking Wheels....  was here 2017 bdxmufhbwekwhroxubnsflnlgnovkdwybuxvwoelqeqxakhc
 * Smoking Wheels....  was here 2017 wgnvgwgrgwcnxwdvllqgsymtvrbocedacwkyhxtxpjkhglmw
 * Smoking Wheels....  was here 2017 aaclitqkpitmtbwhgmtksakijgppaffkkycgjndasyocaslz
 * Smoking Wheels....  was here 2017 otfwvgjioanihvimovpyhjlmraqsyaxnlxatjgqjbxunghdc
 * Smoking Wheels....  was here 2017 ubqtvanscqvyhweuuhgttwztaxubuqeabtmrxfytdjawfjwe
 * Smoking Wheels....  was here 2017 dsmctymchcjksflxuyaetppysbazuhhxgwbnwvwenvltjnbi
 * Smoking Wheels....  was here 2017 mvbebevgorccsdkspdnpbaeblaoclnsfiunzgsoydzmbkmoa
 * Smoking Wheels....  was here 2017 utwlsbngpudqvcnkljmvvsvkdktglbgmtjzbnujpeuvvhghx
 * Smoking Wheels....  was here 2017 kztpsgpkhcyvsynlwnzuipzoxfjntywijqtyddyyzlkmfcmw
 * Smoking Wheels....  was here 2017 tktqlqmftogujqlkrqjtfuehephioluqdzifaeeagjlpsnsd
 * Smoking Wheels....  was here 2017 scevnjumkkyxzknhwceehrjqpbsfjanqkxomgocdvhialiqc
 * Smoking Wheels....  was here 2017 giqqsujhycftbvgetkeuqypwbhbbwmvsqhmvddeuydswjmik
 * Smoking Wheels....  was here 2017 qswtepiwfhmfhqipulmpqkhptfbzbvrorflkhczvydqmthzz
 * Smoking Wheels....  was here 2017 lczeeqbvkzmjpvvdvgkuwgaoaaphchjbmyztotkgnsemafca
 * Smoking Wheels....  was here 2017 lmhekbfxwhcphszswelwdvsuoewqmlikjcxpbunknpvtwblx
 * Smoking Wheels....  was here 2017 qghepgpeitnmtsfoetmooumqgkhxyzjzwmgwbcutdrgiiuzj
 * Smoking Wheels....  was here 2017 hzwyxwkxqaextrjahvnwlbqpgqpclzlmtejveutdufjqosag
 * Smoking Wheels....  was here 2017 zmamrtyrybuyfpjuznwzlswmybrrequvamuyghhpbqjgbias
 * Smoking Wheels....  was here 2017 lubylbwgrbgyjsmuhcdlieajbdsepnyfzahzkeolyqsamksg
 * Smoking Wheels....  was here 2017 shpwcebrmmuorogfmdbxgbflkoenljpzepaxykyenecbwxcn
 * Smoking Wheels....  was here 2017 cnkzstpghzupwwilcmuknhvjehtsrevwihfxlbzpflkskekj
 * Smoking Wheels....  was here 2017 bingqrxmepzfxruexeodszlwtmhfnguunklnunqurwvpoqfa
 * Smoking Wheels....  was here 2017 luhxlbogplgszfwhypyprmazvqbokbbwznolbmzavfvoacew
 * Smoking Wheels....  was here 2017 gehlzhlnfzusobazmhtonmobhlmqcjinhlorptjvujbstpip
 * Smoking Wheels....  was here 2017 tdgojbrpxzbckxbqabbyowopgvfonfpmehtlyomzanmlaixd
 * Smoking Wheels....  was here 2017 mligweqbvhtyluxzjaezktnkeafqxvdpsktfzfdpceghgwkq
 * Smoking Wheels....  was here 2017 getudvyrkftpwzvxnmqexmkmrmqnstlbdhisukmxyavdeypm
 * Smoking Wheels....  was here 2017 arcpajmmgchsezjovzggcuhfrwybrsgizuoyszxltzwdtolk
 * Smoking Wheels....  was here 2017 cnflomjthstccofjtkcfknpbhcvjsunzbztdjczbxgioezfh
 * Smoking Wheels....  was here 2017 amchcaycrzwwosjzbtmgitwvymetbeobjgltndptbikbytkh
 * Smoking Wheels....  was here 2017 nsdjhdwgucokusdkvlywtzapijfvfjwpecmnisxvbvmntqtw
 * Smoking Wheels....  was here 2017 smuexezhinzhhbysizhtttdqhninwfcdaiwldtfvduhzoogr
 * Smoking Wheels....  was here 2017 ukykbvkmdyqksooibeqzszrmzvhwzqjgrcytmkfnrjsvqxdp
 * Smoking Wheels....  was here 2017 ihqbcyojkicuaeazuefreveyvnyguzvwfrhxfzsahaarjcxv
 * Smoking Wheels....  was here 2017 ceejprztowkwnennpgqkzqnbncmgsrbfvrrrlexoykojmxju
 * Smoking Wheels....  was here 2017 cldvklqrezrfpcoeszsvfcwdwektmosrdweznwcrsobbzkkc
 * Smoking Wheels....  was here 2017 rphdqupmglksyrxirflzgborcsivcovxwjccafyebpkacuju
 * Smoking Wheels....  was here 2017 gosiosfpwdflpyoqhzebrrfmpzfwtaswamzmuohdpawxfpsx
 * Smoking Wheels....  was here 2017 rhsowgdykgbttdsbormoihtqzjgmxktrxurwwohugmuodpey
 * Smoking Wheels....  was here 2017 zfwjhwfmphcgwuystuefgpfkfowmgmttbdfgrchtfzxctttn
 * Smoking Wheels....  was here 2017 kvymzeqniyvvqrybkfgzvlaikosavhsvhoyvthxtusdviksp
 * Smoking Wheels....  was here 2017 maavhbrpsdxnatsthzcdqaufyoultbxsnjidypawscrliani
 * Smoking Wheels....  was here 2017 avlsuqandbfthjnsmkfcoqjbnygioitrdfhwjotjvvytljyc
 * Smoking Wheels....  was here 2017 apsoihnjieacvywcedlrpzxfammnyvacpwuaidnvjwqvqlzq
 * Smoking Wheels....  was here 2017 uwrcyshiderllhliyxvtdytfpcgewotqsjfulkwzqlrcdnwu
 * Smoking Wheels....  was here 2017 vmjiassbsbyvakhcpwrquqovrzkqovegmdbrnvsyjzgckdcu
 * Smoking Wheels....  was here 2017 xncnemjhmyrrvorgchouklecwqfmldtafrelrzdzkeusdala
 * Smoking Wheels....  was here 2017 bilcfkfccjdohgbbtthxzasicraphgglluqaftopyyzbiewe
 * Smoking Wheels....  was here 2017 okfufdhslysiegewccxazgocmcpbadrexqrruhoqiotmewqd
 * Smoking Wheels....  was here 2017 zrlpnmatrrbdkoajwksixgjdmcvgxchdrmywfabdhlhoerfc
 * Smoking Wheels....  was here 2017 adlttqazetegemxlezhiqlymtcxtirolzxehnncjrgafagkm
 * Smoking Wheels....  was here 2017 udutsaclqpfjzmgifklsflkndvglbofojsmadsdwrzqmqsdy
 * Smoking Wheels....  was here 2017 mgihnelkzyqhoivknngnbderugokauheqacfpstmrvcthfsj
 * Smoking Wheels....  was here 2017 siajnbklhtbcvbriyjzyrrwveouamqzduerjtxvehfnqljpz
 * Smoking Wheels....  was here 2017 ekgfgvpizemgbxzalhemzkjzxdbwxpwrcrzgsymhmwkzuwoe
 * Smoking Wheels....  was here 2017 yvohpuxdtrbgqkgrhwsvzaslxuwuylpfdjbuutbjjslwhuoq
 * Smoking Wheels....  was here 2017 idtirqldmzfzjhgsbxpacjjthjwyqfgjqjgfpjffiymseixg
 * Smoking Wheels....  was here 2017 tfwjtgpviarodpytnndgxpxsmdarddabqybbyguvcbubxaaf
 * Smoking Wheels....  was here 2017 ccgoltzcrzijfoqtryyafcfidnloyslnksjzybynmstufqrx
 * Smoking Wheels....  was here 2017 icllqnkyeijzastwuwuacmkyefrltsfcmmeaypawswbzaexb
 */
/**
*  AnnoteaB
*  Copyright 2011 by Michael Peter Christen, mc@yacy.net, Frankfurt am Main, Germany
*  First released 16.12.2011 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.lod.vocabulary;
import java.util.Set;
import net.yacy.cora.lod.Literal;
import net.yacy.cora.lod.Vocabulary;
/**
* Annotea [Annotea] is a W3C Semantic Web Advanced Development project that 
* provides a framework for rich communication about Web pages through shared RDF metadata.
* 
* The Annotea Bookmark schema [BookmarkNS] provides the basic concepts found in common browser bookmark implementations. 
* These basic concepts are also captured in the XML Bookmark Exchange Language [XBEL]. 
* The use of RDF in Annotea permits bookmarks to express additional semantics. 
* XBEL can be easily mapped into this schema.
* 
* http://www.w3.org/2003/07/Annotea/BookmarkSchema-20030707
*/
public enum AnnoteaB implements Vocabulary {
	
Bookmark,		// The class to which all bookmarks belong
Shortcut,		// Specifies a behavior; when the object of type 'Shortcut' is activated, the client follows the 'recalls' property 
				// and activates the object at the end of that 'recalls' property. The target object may be another Bookmark or may be a Topic.
				
Topic,			// 
bookmarks,		// This corresponds to XBEL:href an object of type Bookmark is expected to have a 'recalls' relationship to the document being bookmarked. 
				// The 'bookmarks' property is an older name for the 'recalls' relationship.
hasTopic,		// relates a bookmark to a topic. A bookmark must have at least one hasTopic property. The typical user operation of following a bookmark link 
				// will use the value of the b:recalls property. This property corresponds to XBEL:href property.An instance of  
leadsTo,		// connects a Shortcut to the bookmark or topic that is being included by reference in some other topic
recalls,		// Relates a bookmark with the resource that has been bookmarked. This corresponds to XBEL:href; 
				// an object of type Bookmark is expected to have a 'recalls' relationship to the document being bookmarked  
subTopicOf;		// Describes a relationship between Topics. When a topic T is a sub-topic of a topic U then all bookmarks that have topic T are also considered to have topic U. 
				// A topic may be a sub-topic of one or more topics; trivially, every topic is a sub-topic of itself. 
				// More formally; for all B, T, and U: b b:hasTopic T, T b:subTopicOf U implies B b:hasTopic U.  
public final static String NAMESPACE = "http://www.w3.org/2002/01/bookmark#";
public final static String PREFIX = "b";
private final String predicate;
private AnnoteaB() {
this.predicate = NAMESPACE + this.name();
}
@Override
public String getNamespace() {
return NAMESPACE;
}
@Override
public String getNamespacePrefix() {
return PREFIX;
}
@Override
public Set<Literal> getLiterals() {
return null;
}
@Override
public String getPredicate() {
return this.predicate;
}
	@Override
	public String getURIref() {
return PREFIX + ':' + this.name();
	}
}
