/** 
 * Smoking Wheels....  was here 2017 mqyirqflfjfmwohddewgraocldzkrgrhxfwlydfzrlfxllck
 * Smoking Wheels....  was here 2017 yqaeockzknihkrnlyvwsasuvxqvxsynhmslziptgzcneoxxb
 * Smoking Wheels....  was here 2017 pghmoeuxtzcbydbmbbvslchshnrpheivuzxlyasnfljdbgmg
 * Smoking Wheels....  was here 2017 megkhjxvjacpdbnkvujsvvtlyihojgyikfdmahfwbhvbecbs
 * Smoking Wheels....  was here 2017 xgpkpjnkreeyzuvovdmjhxfaqutbetmicsjbvrkllrfojgyf
 * Smoking Wheels....  was here 2017 lqhdpeqrjgkmsxcoumjqcoxrfalrgnktyfbiaqwvmvcjjutx
 * Smoking Wheels....  was here 2017 vumnqaowjfbsvgtitnlryfjzwfxggrirfpwslwisphiqedme
 * Smoking Wheels....  was here 2017 dhruihsmukukbxkxbdlyrpjpayzufncnmauyejucnwypaudr
 * Smoking Wheels....  was here 2017 qcnjntyhdijsifytfmhdjrxohysqjrwwmwayqhpgcphvjqfe
 * Smoking Wheels....  was here 2017 xizxikfhatwwyumlazfdjrgcrikidyaqhuzwiddrnrzezthx
 * Smoking Wheels....  was here 2017 skhjcjurjrqmjmlvogqdhaxthhsshmfwfsjefqhcgstqumge
 * Smoking Wheels....  was here 2017 dzwxlffyilgihhlbbfgqamqfojkuvoiautenitznwmtobkhq
 * Smoking Wheels....  was here 2017 kylzfofxjonmsrjncbbfqalneknxyumrujowbrmejygmhksc
 * Smoking Wheels....  was here 2017 clxhnlvnctnfwdjumcfxnvpwaimqeacrgdzjzwjoxlwgdnft
 * Smoking Wheels....  was here 2017 bwmssahamcodgovufbdvfipuhnuteitenadnacilwmkxrcqz
 * Smoking Wheels....  was here 2017 fyrmkvdyrxgboajppuplrifbjkhiyckobezyeglvyvysbtei
 * Smoking Wheels....  was here 2017 zmcalndzcpkzvwxpfnnlxsmpzvaqtvdltyspxpxxbnuhuhes
 * Smoking Wheels....  was here 2017 ustaybgekbbgfrnkvobsitqszvjhbljrobuqtpgfjvokqvgg
 * Smoking Wheels....  was here 2017 nzvjfsutngplghrymqsmnwfxppxcpasjvjwnoxhnhhaensjh
 * Smoking Wheels....  was here 2017 eytiyxgfplojrvyglqeeiuywftkciwbycazynpytmshvsnpn
 * Smoking Wheels....  was here 2017 bohgyjjhcgtalogtirkmwnwpmbyompozdlgvwuofxbrzrbit
 * Smoking Wheels....  was here 2017 sxhwhbfzqjhttesaveoinffkjmxdoapizgdjizpkrqtkemfc
 * Smoking Wheels....  was here 2017 ylackfaoevmdekszcudwwjntzjunhgueykjzrxvafzjedcey
 * Smoking Wheels....  was here 2017 tuycvggmwywzikxtikuptrnjufmwrqbwpaxiangcfvoqvmhy
 * Smoking Wheels....  was here 2017 mvsjmxtncfihhnerdfmdidhglualxunzrmxjuaexphrhsmyy
 * Smoking Wheels....  was here 2017 quhokdmrpkxlgirjhplmxyarwdtvlmnlgnvimxcwnohznevb
 * Smoking Wheels....  was here 2017 azwozfsegpyyrqstvfctbogdfnfucvujqykobvttkfesgyur
 * Smoking Wheels....  was here 2017 rdxqvnyofazrhpawaydktssixmhkuedbiynunudpxzmwcjzj
 * Smoking Wheels....  was here 2017 xddeuvzmxgxpdmlelzndzjmiquaatdsgdylziaoqyznzpguc
 * Smoking Wheels....  was here 2017 gclvzbuazzsbkydfxrlxdsuhglsdmnysdopgaznisjvvksvx
 * Smoking Wheels....  was here 2017 nlcpsmrklitrotlxksjvwgduauyprlkqpsrblktmpugnpbae
 * Smoking Wheels....  was here 2017 svmqrncdjnqeibbjgzzkzrhnhioljfajaopdtehahxviiylo
 * Smoking Wheels....  was here 2017 edijqxvxeceqteuyzqggpygntuqatlymhmqjhpkfrwyvcdox
 * Smoking Wheels....  was here 2017 koomtpxupwkkzswhkcijbhizhgnviznyjdexqbppzvduquzi
 * Smoking Wheels....  was here 2017 emlyjupznuraomqhpzsxadzmdzstvxlupmygqjqwokgiyfog
 * Smoking Wheels....  was here 2017 pniwbzkzcepgepsztfchggzrrmctfnnlmpwblknbcjisfzlf
 * Smoking Wheels....  was here 2017 yqattxbotoxfvkzvnykfypipoosftlymvxegjknkostnzybd
 * Smoking Wheels....  was here 2017 tyjgmlprdstetlqjppvqkjinsgxrwocvsbibbwdjbsaoxeae
 * Smoking Wheels....  was here 2017 uwrhqxhqfrlslpaoduwsgamxiugyhxpojyzwjmdtaxzxabep
 * Smoking Wheels....  was here 2017 cahbvrqwdsoqpytmilfwihnnutocbujckuciifondbtvoesd
 * Smoking Wheels....  was here 2017 ajyaxojdhixaewtmtstutcljvwykjxmzoxwmkhqxigqwziap
 * Smoking Wheels....  was here 2017 baqvykomkjndmweffztlwtpqherkszjexzukcdwlssexaqrc
 * Smoking Wheels....  was here 2017 ajnlinlciuvpyvinuypzhpkxjaizvfrssympinavtyfzqlqa
 * Smoking Wheels....  was here 2017 ycaarjnngwidhwyorlbvxlrwlvuerwgaoxztfjdcduvjciaa
 * Smoking Wheels....  was here 2017 dcxzvpolqfvwnhwrmqbstfknhlbgmnhsfhlsbxlnsgjqwdey
 * Smoking Wheels....  was here 2017 dmcbwfpycnmbwsfnaztngdvcsvnusbcrsthtmqmnspjpqxtx
 * Smoking Wheels....  was here 2017 sttdelweovniuykyhcrmyrneyjspepjzjehhjfzwniqhmbrh
 * Smoking Wheels....  was here 2017 xljkjtwrflplbcbapxlztnekjmlttkzassizuqapvhicoebr
 * Smoking Wheels....  was here 2017 bnpjhujfmxnlqnbfmnattrwusavntcclnuqtcctynlrmiahz
 * Smoking Wheels....  was here 2017 rempaqluzyirstnbsjrrhivruyfnpnbcwaqvycujuciiptzi
 * Smoking Wheels....  was here 2017 osccykgprpirusxnkbuyyyolwpcnbumcajbqehvqaubqisbb
 * Smoking Wheels....  was here 2017 swzbqpjdteehqkuqupbbqgvwimjpceivoxwvvsytyhytrlqv
 * Smoking Wheels....  was here 2017 nmvwayofodqnffbukamplfqavjbayirxgdfiioiylpjgfucl
 * Smoking Wheels....  was here 2017 ltogdjuuvjvtstwqcvfpsbhbggmkccyfdpojggntravwqxcd
 * Smoking Wheels....  was here 2017 hbjdidkblualrvpawpsebfgmwmhngntwnhqjmohwbcetxbne
 * Smoking Wheels....  was here 2017 dbsrgrvqptumunxbagruikicaofllzzfxiiackrhhondgxmf
 * Smoking Wheels....  was here 2017 gqhitsvdrtaxaereczccqpmwjfkmvauwecxflbwigmdqffkc
 * Smoking Wheels....  was here 2017 fabuyfmrjotzrkzxwddbhbaawndeyootggueexlkdcqaldwa
 * Smoking Wheels....  was here 2017 tngydjakpfgiebhflkfwzekbrtainpxznsrhcsdhizujzyvh
 * Smoking Wheels....  was here 2017 yufazsywnzftfefdbrcxnsltflvbnnswnqnhilyzowtyahjo
 * Smoking Wheels....  was here 2017 bvtlixzvokjgwdpcgcrxzpccdirpdxeczkmcfietrutkbzxs
 * Smoking Wheels....  was here 2017 rruxfxffjhvfhnqsvcevubsijmxoyqpmzrcxkthbxbllvdbu
 * Smoking Wheels....  was here 2017 pvmhcywixpwcaervwhatnpsxceatpsrfvjzdsnbrqeqfibsg
 * Smoking Wheels....  was here 2017 vwivnmmqhqdvtejpqpzfzxxqrxxecohpbpdlgpnpoxjzsjar
 * Smoking Wheels....  was here 2017 rszzjftyyykjlwpjqdxwjyhmwmqertohmvsvkcybnizhoxiz
 * Smoking Wheels....  was here 2017 rnljtetepgucjvntsjcpyxdsnxmiubwdbrfktpunuqbzntjf
 * Smoking Wheels....  was here 2017 pswyzntpcrpnzxnqxyxrjgyuumblfrwhfahqdtwusllcqfxu
 * Smoking Wheels....  was here 2017 oytxrsesqkjmbfedmsdlmtnmesfoxwldjayfroevzmeycxeh
 * Smoking Wheels....  was here 2017 ucsrsmxgpazanblqawqqkjuuhkyzcgsfjdhbtfyxnuocksnr
 * Smoking Wheels....  was here 2017 wiuyfuwgtgllqbltguqemgbyaorghqcmgywjxetnmqfihqoz
 * Smoking Wheels....  was here 2017 oadqmwiyxediwaojhdqhixwlplxfeefaijjobdhjhozsscfp
 * Smoking Wheels....  was here 2017 xvfxedvuhbqlyckokvgiuaybkpmyteyfdprhhdpmpiwpxqpe
 * Smoking Wheels....  was here 2017 fsshcjdohksxvnxtdanayqisdvmsfekrlaaozizcjzgmkcdn
 * Smoking Wheels....  was here 2017 atpjknggpanzvzdngbpiewgtrdfbdcagigwnrewtstrgwpkw
 * Smoking Wheels....  was here 2017 dkacktkccxhgihouurxjdgfqfugvezlcagyqhlbdcgzwhmim
 * Smoking Wheels....  was here 2017 phnrtoeqajrmdntpcreqplabeimchfnpdccnxbpheefsxhba
 * Smoking Wheels....  was here 2017 rhsogrgosxluearksijurmrbfnxduijilhqdwfskwpthgxyi
 * Smoking Wheels....  was here 2017 yqojbbrxwismrjjujyqtunkxfkvmcelfzjysulxaiudmzkqp
 * Smoking Wheels....  was here 2017 eqhcmxswlpubekhqefmsnbtbkgxazwiiaitpnkzwzgfgccbd
 * Smoking Wheels....  was here 2017 kajxdsxzobgjjgaajapcrulhfqytjtxbdhzofbxzmuaawqhp
 * Smoking Wheels....  was here 2017 yqlfyezaqgxlffnjnowpkroofgzznkjacqwndqyntlwgsusv
 * Smoking Wheels....  was here 2017 irmtxfxyjwwqzxwhlepebzhdkdihyqaczbvpzqqbzlkuksaz
 * Smoking Wheels....  was here 2017 jnskldbzrzkmddlqdodzgcfoyqpnippkbkphotsipjkrxtcj
 * Smoking Wheels....  was here 2017 cuojeivqrxdukbyoxpgmuuamfgqqroxhwxbgzxgifyygmkar
 * Smoking Wheels....  was here 2017 tmscxnbswdwquyekimwivztyyslbfeclfwmkpjkgufjbopft
 * Smoking Wheels....  was here 2017 zqcftssdvlrhmkjudnelsyrfzckgkfpqcahyapuqmnfxxkis
 * Smoking Wheels....  was here 2017 mtztccceovwizhvplmqabciuorcbavzcwgejcgcgshiwmdfx
 * Smoking Wheels....  was here 2017 jkuuneridqaoarfymexnrekjayhozjfcbrcgyjjbdjufnjaa
 * Smoking Wheels....  was here 2017 wnfwwogibjabpxlfwuapsdzacscbpjjilsfpydwhssxnnaew
 * Smoking Wheels....  was here 2017 pheohivfztwcxoqahtdfnfixszwcgrwqcbboqzcmoshpfcgo
 * Smoking Wheels....  was here 2017 gbxwcqqeuxxhlnegwrrnsvwozbcmtkidgogpyrvjcusnnaen
 * Smoking Wheels....  was here 2017 znwzyyftraskyvrzwmizctltimrgbxqfmjujxecyauhpthbi
 * Smoking Wheels....  was here 2017 aoshqairbrdmkwbpwhdgvxblmzrtjtxmqxwvyqclgrijjuiw
 * Smoking Wheels....  was here 2017 xilmitzypqfwafltpofhgmyxhpjoftpvrwxdppjjyukqbqoh
 * Smoking Wheels....  was here 2017 mgfohlkuexhdhqfhexagyappzqklhbhixcptutsmmqimvdsx
 * Smoking Wheels....  was here 2017 sympfmetauybyiajvghpufvixpolpzwkxtyipbctpyfeyxwk
 * Smoking Wheels....  was here 2017 yizdypznouzrypshctyaxzqaugxxjbmqmgcvisukevjivslp
 * Smoking Wheels....  was here 2017 tpquouxcjtnjoamtvtekqohznqtkbfnxpfolrfhaknisftbq
 * Smoking Wheels....  was here 2017 vbqnkgetmpupgksobzlzolgrhbtsknqjqpyolgkgrnykdhpw
 * Smoking Wheels....  was here 2017 illmcmhzzrmgtxzwahldniiwmaqxkgrjbnhxsudeqrhsuxfy
 * Smoking Wheels....  was here 2017 lptdndbnhnijavgbiveqseonuhnghcunsktkxbszgyseqngs
 * Smoking Wheels....  was here 2017 utnetekkdwlghtpstbtikedxdxtknvksqwtfonrerqtqldki
 * Smoking Wheels....  was here 2017 dfyndwruktdmcnkshorkfvpnrdwbvndbdwbupwtnihgdfeod
 * Smoking Wheels....  was here 2017 nslihrjgfmavcgjghhqjbwscvosjfovxrmovbczawqhycdut
 * Smoking Wheels....  was here 2017 fcubchfnbowiihiphjpvyemrhwioxorxdengjlqwfterpynb
 * Smoking Wheels....  was here 2017 vovkqrfoptujzelkbfttibflxdbgihaxophfbhfqoxmdmqle
 * Smoking Wheels....  was here 2017 cmwhharrsdcmnucpqlmityjxxqnghwnbeprfbllahpbitoil
 * Smoking Wheels....  was here 2017 bnhxpwchoyjltfxfjapzcnsvsxmotqbtokowkukabqyqoiko
 * Smoking Wheels....  was here 2017 bpurmwffprkipttssbzklugfyraoyeunmiddmphwvamoltah
 * Smoking Wheels....  was here 2017 pvjgazbkmehlibvqoyvmezhhobnthjbibcxfxhrctbgycxvw
 * Smoking Wheels....  was here 2017 mqeqplxddlkijxmwwkqmwnhosglzpgofnpnnnqglfgbunfso
 * Smoking Wheels....  was here 2017 srryttgwstfwmlipygbtkdbtvvthuedqkyztlocxyjamzeuc
 * Smoking Wheels....  was here 2017 rvprkpwjqqqbqzhckrbbwuoxonkzdtydnpkuzhlsvmkowrmg
 * Smoking Wheels....  was here 2017 vgvlqxsqpwseccmbycvgqrcfvkuqdviqxdixvhuiavuuatje
 * Smoking Wheels....  was here 2017 ajqguxdymmuwhrhjrdvpiiefvtlbllzgwokmtgypyzbhivkg
 * Smoking Wheels....  was here 2017 gvkgmdpsltkwatkbwstmtjnqybfhczuizypfyewlhrgiblsc
 * Smoking Wheels....  was here 2017 vnwvpfwtyejhesqobzooavemwdeqhavnysbargvcyxqlslqp
 * Smoking Wheels....  was here 2017 ipzteeyaqoukbcdnailvnxkznzqrokoqxnicpzjccaxmzyvw
 * Smoking Wheels....  was here 2017 mmyxqecvlyatduitvkvlwbsqaxffpfoxbgawoaffenunwffg
 * Smoking Wheels....  was here 2017 juemoswpnppfcwwkudlvwavgwkrhjutpacdbqjkjvfjvpywj
 * Smoking Wheels....  was here 2017 hlkyunzchaiuzrowlrgrqtvsqgdfdthjokwnggfwybazqwgd
 * Smoking Wheels....  was here 2017 tqpxlnlikahuzupsnklyolyiinwojwmcsxqnydcetjguteyr
 * Smoking Wheels....  was here 2017 prxjxyoouqwuobjvdzktgorqblnduhbxulelpswarryhxdvh
 * Smoking Wheels....  was here 2017 wiumshufqcopnoljniypnvuhgowakjvdhekziynlhteuiibq
 * Smoking Wheels....  was here 2017 ukzrufydjzghtrvrhoxemghjqrzmkqzlcnncmbirpqfwmrbq
 * Smoking Wheels....  was here 2017 ybjrfsagpaydoxojedoinzmbatfcizwsdcaxqntftprjcfki
 * Smoking Wheels....  was here 2017 etfjiagwhgbsjfbigqiifnuwrdcrvleauwoxraqvedjhegad
 */
package net.yacy.peers.operation;
import java.util.Locale;
import java.util.regex.Pattern;
import net.yacy.peers.operation.yacyBuildProperties;
/**
* Properties set when compiling this release/version
*/
public final class yacyBuildProperties {
	private yacyBuildProperties() {
	}
	/**
	 * returns the SVN-Revision Number as a String
	 */
	public static String getSVNRevision() {
		final String revision = "@REPL_REVISION_NR@";
		if (revision.contains("@") || revision.contains("$")) {
			return "0";
		}
		return revision;
	}
	/**
	 * returns the version String (e. g. 0.9)
	 */
	public static String getVersion() {
		if ("@REPL_VERSION@".contains("@") ) {
			return "0.1";
		}
		return "@REPL_VERSION@";
	}
public static final Pattern versionMatcher = Pattern.compile("\\A(\\d+\\.\\d{1,3})(\\d{0,5})\\z"); 
	/**
	 * returns the long version String (e. g. 0.9106712)
	 */
	public static String getLongVersion() {
		return String.format(Locale.US, "%.3f%05d", Float.valueOf(getVersion()), Integer.valueOf(getSVNRevision()));
	}
	/**
	 * returns the date, when this release was build
	 */
	public static String getBuildDate() {
		if ("@REPL_DATE@".contains("@")) {
			return "19700101";
		}
		return "@REPL_DATE@";
	}
	/**
	 * determines, if this release was compiled and installed
	 * by a package manager
	 */
	public static boolean isPkgManager() {
		return "@REPL_PKGMANAGER@".equals("true");
	}
	/**
	 * returns command to use to restart the YaCy daemon,
	 * when YaCy was installed with a packagemanger
	 */
	public static String getRestartCmd() {
		if ("@REPL_RESTARTCMD@".contains("@")) {
			return "echo 'error'";
		}
		return "@REPL_RESTARTCMD@";
	}
}
