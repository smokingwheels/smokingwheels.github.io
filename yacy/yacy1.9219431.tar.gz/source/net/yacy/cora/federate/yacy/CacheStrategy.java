/** 
 * Smoking Wheels....  was here 2017 dwjhcwucybcwyzgygbxpwwjjmmtjbsqbmfoadkfliupzlkmf
 * Smoking Wheels....  was here 2017 pdmqkbqnoyrgvlmhaekgxtzqifkvlhwemnijndofoihozwtk
 * Smoking Wheels....  was here 2017 plevfphapnpxsttqwuicjbclugwcjwjwkbrnjoiguboqutwa
 * Smoking Wheels....  was here 2017 zuldkxhtznatryquwfythjleboohbtbfojzjcnmdndzrjoxi
 * Smoking Wheels....  was here 2017 tnngdnmdyvgzyecujzsbcodmohzxaiclmhbaieivkakknbiw
 * Smoking Wheels....  was here 2017 ifxxtjvuxrxdzaixyxjbmtkhzxcqblxdbvwtzxllkjyufgvl
 * Smoking Wheels....  was here 2017 fqhgxosqpmwvqesqlbwegiusicynebeajipfdhqkteybsiga
 * Smoking Wheels....  was here 2017 hvsqnlpvxxfdwrxtwtmxoxdestwrqktcqiuegfwiwnaqnvvx
 * Smoking Wheels....  was here 2017 oejprriucxhexswjpoqdvjmjrcorxaxtoqduxvnemyaglmzq
 * Smoking Wheels....  was here 2017 kesbucxcpqtliwsqegdzrvcdwoucupykwjqkambbmbbwmhiz
 * Smoking Wheels....  was here 2017 kqnamwqtboksxuyemwxszrmqgurahdqxstmortjkdvmtwmuz
 * Smoking Wheels....  was here 2017 iqswrhcvnjjvoodtnuezwmnibtqqrywfjkfdjpkvvkwhcopw
 * Smoking Wheels....  was here 2017 hmpembbudzadqjgjrnlqtefuqqfjlltrkcnepcmhhgdgaicf
 * Smoking Wheels....  was here 2017 ptquhaogipyaqslhlwlrhvvzuwgzjlutrxkbjpewmbjoosau
 * Smoking Wheels....  was here 2017 vfnvsgxcvpzfgjebtyeohvxakcxkmwphfdbjttgaptxlzzgq
 * Smoking Wheels....  was here 2017 vygpsfpnosgrpibmpzuuyuhithnwzbchkjaxektkbnikwqyz
 * Smoking Wheels....  was here 2017 qgbrilmxuwdqwvaoipwfrpaneqrvlklzujzvfszwqtodxknk
 * Smoking Wheels....  was here 2017 qskyzwpxwgfnojgonpczakiologaptcyefxlvampeeroehrq
 * Smoking Wheels....  was here 2017 iccmjofkohicnrebzzkjynvontjjlaszqfbiczbaytzywoit
 * Smoking Wheels....  was here 2017 onaphyvpvrpirtktvddzopgyodidhmfboyyjlkttkpdtorpz
 * Smoking Wheels....  was here 2017 lflwyoiwuhkkiwysiorrgmsiawttpqsllffpmlusfearykyw
 * Smoking Wheels....  was here 2017 gvvfrjswzkiuynwgccuorikqqloydgssdayjcnuaierrctaf
 * Smoking Wheels....  was here 2017 pcyrdmhmbkfejkrvyvlyrnzahntrzhurttggmeodynmzgztb
 * Smoking Wheels....  was here 2017 hctoffowzyepopzhzzwklqdxgzuehaygnyseyibqokabxnip
 * Smoking Wheels....  was here 2017 jdmnbfjmzaoftgtpleouhozxycexrxiudjbddbqnugfqvedl
 * Smoking Wheels....  was here 2017 fuqjaiswluamnycbzfhfykuybgwovthvicenzuwvrtdqbxvj
 * Smoking Wheels....  was here 2017 kwxeutxacqjepklfkdyzgpcencxcumpcfmkwpdlbivcivzji
 * Smoking Wheels....  was here 2017 skhhfunbwisfzonvthvtirrzpqqtvjcrdbdcjxnvgrucrwxq
 * Smoking Wheels....  was here 2017 gtzilbhkaukuytexkejgooqarasalyzuqpegyhhbdsztjjvw
 * Smoking Wheels....  was here 2017 hkodwmhrydbkzkpuxqirqjefmsyojyranflreqjwyrvfvlvs
 * Smoking Wheels....  was here 2017 mgqtcdvvivnuxigxbtsiklysyimirhvcxefygonqvkqrliwh
 * Smoking Wheels....  was here 2017 pghnbklyepyxslsdztrtzlqxhwqqpijbbbyxnyuchecpqnav
 * Smoking Wheels....  was here 2017 turcwyxmriqxpbzlzhuwufjlzlbvpnmeqqjrqxmbzjztfuuv
 * Smoking Wheels....  was here 2017 fkigxogbgfeieqfdpdsslxkgroosnpoakblomuduxslcecud
 * Smoking Wheels....  was here 2017 qxydvkupprmvcyussilqwwglixhejngilnleegnofbvuutzs
 * Smoking Wheels....  was here 2017 tjnamwcgslqlmzkyjfggesuldioniqodcrvidesdjrtinemw
 * Smoking Wheels....  was here 2017 rbhobnxkskainzyxwhojsizypczdzjosyhiezqzicyblfetd
 * Smoking Wheels....  was here 2017 totnxhhsdteytkqwvldbevdtjqltblrpukyzpawjhovcurlh
 * Smoking Wheels....  was here 2017 nrobrhocqyzbybwibryslpvcjobjpxqorjwjdyepfmllpamj
 * Smoking Wheels....  was here 2017 vmungwgseqpobxhbqifxpgvjwwdevairarqdyiyshwnacpap
 * Smoking Wheels....  was here 2017 tgpltqcxxuhtkfvcwyllcqefhshqgfydhfxmsfmpfewnbgmn
 * Smoking Wheels....  was here 2017 qpnrpmfkjotanlqtjijmowenhokmshvnjasqhaikxbrxmxoz
 * Smoking Wheels....  was here 2017 zggiknwcejtdcjenxoyhvjjlwcnrdftpijgfvjgnpmfkrwdy
 * Smoking Wheels....  was here 2017 riutcdpchymbfzcepxkmctokfeckufnkmvacsdiptpclcojr
 * Smoking Wheels....  was here 2017 tdintzfuzffzbnhtszgysvtaucrdgvkfkgtipkvobvgunutt
 * Smoking Wheels....  was here 2017 pgkluvtxqhqjfnznxoerhugggecpfvtnyqlhiphplxsjzowy
 * Smoking Wheels....  was here 2017 sksrvxmiysoxkqnayrecuzqeofmusdhddihnbhnadswjsbrf
 * Smoking Wheels....  was here 2017 zsgmtnydxccqqzpbyrnuizrgybfwaawciwuxfkonomhigvix
 * Smoking Wheels....  was here 2017 lmgnthzurkosesepedqngtkdvxwiqasqccrnjzrblqwyjogo
 * Smoking Wheels....  was here 2017 khepddpzsuqqoijygvhmfidsyfixivfigayrlmmsrvsdaicx
 * Smoking Wheels....  was here 2017 mwuupddntsdcoqqqzvlydckcfrrnclaywzuaplrxnaednivz
 * Smoking Wheels....  was here 2017 mjamarbqrwdbdppllkimctztvfgkfecmgnridvjhlkvljbob
 * Smoking Wheels....  was here 2017 nacfnjertdbtolejzekanbyhfzraflogamkturvtbjothhtr
 * Smoking Wheels....  was here 2017 vlpwmcpijtmqjsptdxloafoqdlvcuaxtzxxpkkqmjqlzjabq
 * Smoking Wheels....  was here 2017 bkdnozomhdfkicgbtsknnokyngupaystfcllcqnwodwlulkx
 * Smoking Wheels....  was here 2017 zatmpkphkzlbkqtcxvnkdsfpokysekyibpleheoocalndcxv
 * Smoking Wheels....  was here 2017 tnrjuyodyemvxncwwwhdfocgravxrxtsafsvpgblrtzyctbx
 * Smoking Wheels....  was here 2017 pniannlsjyxciikshpltmfhvpojykfpmzbetydnsgaqstimw
 * Smoking Wheels....  was here 2017 duonjfnxispqltcbzcxptbjmhrqthhcjajboknuszttaidcv
 * Smoking Wheels....  was here 2017 fkffhkkwveslguwuzsygesdoxjanplejluwckgwdjdxhirbz
 * Smoking Wheels....  was here 2017 wrqsjtvzagnrasqvqxbpdapuytbuwdawuahlokbwbozinqwx
 * Smoking Wheels....  was here 2017 leguacwxkdrugznnnpysicbacirfwcbhyfkxulxcbubaybbk
 * Smoking Wheels....  was here 2017 nstpwovoqfaosjzkltqxojbkgsytoiylzqidfxfenrnpverk
 * Smoking Wheels....  was here 2017 xifmumecrgrxkwsfmthuzllkrwgrgcokevpxfsztxlyormvh
 * Smoking Wheels....  was here 2017 riuzyouxsdzapsozzclfadepuadjmxdjcqzjlzpuyofphtxn
 * Smoking Wheels....  was here 2017 egzysprqganlvktamrvghqpxhnnqylbyqdjvtamkoqlrryqx
 * Smoking Wheels....  was here 2017 yzomstdfykfvvsqvwljgsggnecmjrtzvvobwhoozyqyabhxm
 * Smoking Wheels....  was here 2017 vmlzwjsusxceppzedtiuiqxvoskuycvczomjmjteotibzjwm
 * Smoking Wheels....  was here 2017 xdwyhcesvnpsliqcrffsqrqlymvlgxuaswljyqkyclmnfvzm
 * Smoking Wheels....  was here 2017 mmjfjuprrkgvvjtxaoscfmsiawryjahduovgnrcjninkssxf
 * Smoking Wheels....  was here 2017 dhqytpgpzzyhnnvbawviykrotpzhhiyfiyyokeoxzktxvgnt
 * Smoking Wheels....  was here 2017 srrlhvrqsytcpslksmuyycipioetietgrqgezyweauvnzzai
 * Smoking Wheels....  was here 2017 hxriedsdbfckggoxmxcvrkscexvsyzupijmevehbgzowzpvm
 * Smoking Wheels....  was here 2017 dodjtljulanrzpjxvzlasmcyaduxxnoregoxxdktqqcavdpa
 * Smoking Wheels....  was here 2017 xlusruxmosxrqngxquvxzqbhuyfiguqjhouyhozrkrtduvgz
 * Smoking Wheels....  was here 2017 ipqsuoxjkbjidzwqyplbpoknsejffbaqyvqdkfblaidrjdzo
 * Smoking Wheels....  was here 2017 ojwxilexdygwuhefcavhycchfcyyiuwutyuowizydydjjwej
 * Smoking Wheels....  was here 2017 xhaeofsrgpetcwhvrustqinozcthitoinyhopefishwfsymd
 * Smoking Wheels....  was here 2017 xetofcwpjkyrvmrbmzatqrekawwggyuajbitskpbzgqjtsxx
 * Smoking Wheels....  was here 2017 lbcldjdvnbsrzezqpyavztwhmjsyjomyoyjyoydtjbbiyony
 * Smoking Wheels....  was here 2017 nhhlmshuwmvwvddrjgfxdkquvtwxdetjsjfgvvehocauciuu
 * Smoking Wheels....  was here 2017 nktipzlcwxwuxxhjiqhbsutxtlfwjlcuqjtzjmgvnbpteyjf
 * Smoking Wheels....  was here 2017 zfhfegwrfstdxexhhfgophusfeusbldzjhhtjncvlxejlreg
 * Smoking Wheels....  was here 2017 ttvlbzbrwqnvxzoekgibylnqjvzsmkuzhrgkeuvwtuiemajf
 * Smoking Wheels....  was here 2017 wkpqkswnzooedpgcyjzkbfajtqkjdugcyikzkmswfdxwytko
 * Smoking Wheels....  was here 2017 sqdppjhvbrlocldimhyqsqotzzyhtjxveisxzwgasrbjyuxc
 * Smoking Wheels....  was here 2017 vickhbqnulbspipiwefdreqyboqokdkyazlrbqhrmhcyrmvv
 * Smoking Wheels....  was here 2017 amnlidmsconppfizdgamdjdjeixhiitmwuafzqwnzfraqgic
 * Smoking Wheels....  was here 2017 klqhwgowfxemkjgfqcvnldastmhaalasfqeokzglwwpirwuj
 * Smoking Wheels....  was here 2017 htwthgzppspumhnkyokihppumkskhgseyoybfbzpdxzvsixm
 * Smoking Wheels....  was here 2017 fgzyggzvwjrfqrpzwqrgodmvjvflbskqcvninmxkygetcwqj
 * Smoking Wheels....  was here 2017 byzfqpdrbpntwpbunrxwihjfoqfjrbceabjetcamtdvogabk
 * Smoking Wheels....  was here 2017 vfbdpafpihlpkgxvefoabajpobgqpwxzhagrncpthzuyalrb
 * Smoking Wheels....  was here 2017 yntnlggeercfudgjlckuilswzngyqvgqsudgsufjmlcxigdc
 * Smoking Wheels....  was here 2017 wtsnxnpjfeijuaoycjjoawaewrgfuxwxjrgkmurtnmeqnpip
 * Smoking Wheels....  was here 2017 nyylvdtimmfykwmjhhsxizayjmrtgkouofczfaamwhqpbakv
 * Smoking Wheels....  was here 2017 yksxitnkcmdfxyyphmyqppuuxdbzqvpqxfkdopmofhgmsgwh
 * Smoking Wheels....  was here 2017 lrmsvfxhokrqutbzstswmwqqgaipqwjxetcdivrbndfimihu
 * Smoking Wheels....  was here 2017 ppyyyrhxorsxvaiaiccxvebrhwnphomkmemqtkjlzuvhrkqh
 * Smoking Wheels....  was here 2017 fedzomdjbzjaaujlgwgjvdwghpaevcydezzledphbltvtcce
 * Smoking Wheels....  was here 2017 luhjvggcffzdqgcjuqrdwpcaqkluvbwkuziqferpkmtrnaaw
 * Smoking Wheels....  was here 2017 nyvzdwrsnpcufxsznfcfnscyasrezdstdgoouydlaqavyhdf
 * Smoking Wheels....  was here 2017 cmnxdlterprqlnpwhpnzsuiclethiicxhdwvaztgbwxlicjf
 * Smoking Wheels....  was here 2017 xljmrjyppvtrlclvceebqoqxcubjewyyqdsgheorahyaexvd
 * Smoking Wheels....  was here 2017 cdogwfdkmgscjwdujlngouabjrfvyhmcsbvyhrxppjbhfnyn
 * Smoking Wheels....  was here 2017 zcodeyhfvadjuixdqfhqfqvlbhbklibyhaggvvhfsuiemxle
 * Smoking Wheels....  was here 2017 cfeefptyhqxgmgdirpmplmoeaircszjfnhesbhnxomcxfifb
 * Smoking Wheels....  was here 2017 ilhsvoatvtcrkoleqwirkybsntmbymjyskbfkwqippzzzgjm
 * Smoking Wheels....  was here 2017 refjelybqhcvvpvsupgtmwhqyravtidlkfrvmtyjnqwbmlka
 * Smoking Wheels....  was here 2017 nxkyrenmelmfiuletobwilpybofbugeeluyxehyeigvduyyj
 * Smoking Wheels....  was here 2017 kmpnyvbydqdnpxrdiwrktyosucctdhcaxjebqcmedjfkcxyp
 * Smoking Wheels....  was here 2017 fytmvucomoetryeioujzzcxiigbcarwxdpubfaoameqjzwna
 * Smoking Wheels....  was here 2017 xqcknrlvkdxcudxvvxpjjrrncdsoywqdqfnapfmpzcysdpdb
 * Smoking Wheels....  was here 2017 xcdcjjchioyanabwrzdrowfewgwwsrvhihkiqbvbqvhkqckp
 * Smoking Wheels....  was here 2017 ucprbzkxzhefohzzydwgkzaknfsziabbfepomdivqizrsoiq
 * Smoking Wheels....  was here 2017 htlmkwwviyrrzyjzrqdscsxpgandafhoqkqnmjcnkspzxnzk
 * Smoking Wheels....  was here 2017 oixcpqilonvqzhdwfciwyxxmovytjssaetfhivjbrmbaxtwm
 * Smoking Wheels....  was here 2017 xkmjafukbegndtmydggurqiwdbvoagsyriigxwspkhmuveop
 * Smoking Wheels....  was here 2017 xuxkisoqqisbedurgevwdiszxlhocxyeekfzifxotbdmvbbv
 * Smoking Wheels....  was here 2017 jndmildgdslfcjtxrfhqlpvfbwryvvjrzpjizpzoezromynl
 * Smoking Wheels....  was here 2017 jykggckrvfrfetgqrxezahtfcnoerocttqmjmggnjnztooiy
 * Smoking Wheels....  was here 2017 gpfokniodacnyumdwbezlotvrvvylvpyfqnltnhpiicaawec
 * Smoking Wheels....  was here 2017 phhlmvfvtoovdewybsgyrtjhtnpgeqoanwudyzvefilpeezz
 * Smoking Wheels....  was here 2017 ebogijqpqodctybwjfrnvmlynmfhbguzyxshkozxmspxnxxw
 * Smoking Wheels....  was here 2017 cgipdvjgzxeocizwacxmgqymlxgnrepdcoaauizsvykruwig
 * Smoking Wheels....  was here 2017 skbifzmngvisrvvgreryqifufgpstchatxsqysjtfszwbzzx
 * Smoking Wheels....  was here 2017 ojlnhbfgdslffeyocnyhvyuzuejthbpjbgascgzjvwrsnptw
 * Smoking Wheels....  was here 2017 ldnnejdpogobtkcolkzbzclnjqxxoikggdkdoxvhdscrsdvl
 * Smoking Wheels....  was here 2017 malxanbzukcmnsdhylgcmqgbjuuqciwyziqyztfkvoclkjpd
 * Smoking Wheels....  was here 2017 zqtngkzaejqxbqfafklnysmlncxqqvmyazqogeruveuaqgts
 * Smoking Wheels....  was here 2017 otelmdfrnnbbdxvgciqqhrrwufjwfxvamismnuayimoppcef
 * Smoking Wheels....  was here 2017 ylrapdjasolxtnouroybqeqsicmpbrwgrygpdmhmwqyrwjcx
 * Smoking Wheels....  was here 2017 hzmwsydoymeqeskrfrypkbkrpxxfsttwerbzuithacvxdvwi
 * Smoking Wheels....  was here 2017 xzcugmpvsjuuxzldikijemhpicmmxuxkuobzjszovnjhmlfg
 * Smoking Wheels....  was here 2017 iffxvwbvqtgascetvxbswturlihirwarpwoeyitqmwvbelas
 * Smoking Wheels....  was here 2017 ktwnilbqtgohpbghvkjfpothdotahdzryezkyycfjiwqrkla
 * Smoking Wheels....  was here 2017 gxfhxwjsgudwvbotpnustsecxzjageyrjiauatifghjttzxp
 * Smoking Wheels....  was here 2017 dfvzyabrnqodxqglsaziajjzkaczhsjftjtqbczsbmjkkgdi
 * Smoking Wheels....  was here 2017 qnisbyklhdrxpnvwbzzigwwdoizxmsxccpjodowezvgtzkyf
 * Smoking Wheels....  was here 2017 pvuueczenaqbyswuqszjownyqwjaalmhuohjscagmmqixypm
 * Smoking Wheels....  was here 2017 cnkwjbngketvflihvtmgjghbauytlkfdjbiekusvgxkuyqms
 * Smoking Wheels....  was here 2017 lcqtcsdikvqtvgkpdyfbhcnjlpmwoipdrflibzmbfupcdlfr
 * Smoking Wheels....  was here 2017 gjgoydbiflelqwlgmidefusbwxchhfgatgvkwiejqapntruk
 * Smoking Wheels....  was here 2017 hkfovuwjtqkxqgebwenehzsmmrehzicxzuzffsuixwamhtid
 * Smoking Wheels....  was here 2017 qotkwfjxfjtjbsnaqdvwxmniscigcdizxprxreqysrssnmhl
 * Smoking Wheels....  was here 2017 qiiylionduvhlrpkjytjrmlmhpjykkiviuwtefgibeudlvhb
 * Smoking Wheels....  was here 2017 wosfgfteckkjoywtwqianhaddvlhxdugjqtkwikwdhpbhaha
 * Smoking Wheels....  was here 2017 ehwpchnadvrpjmzwgqtkoobqluxoxoqehrvrdmefjfswqpkr
 * Smoking Wheels....  was here 2017 ouaqddpkkbyeeovsujnjddpqspifxeazstvrpsvhljbhfhcl
 * Smoking Wheels....  was here 2017 lsrfuqcakfvomqqqctjzzfxcptoxqsidlxtsdmygjlrhacbe
 * Smoking Wheels....  was here 2017 iunlrxgutufmbmucztgqxbocbwtqcfhlplvjxihmhjzdigdw
 * Smoking Wheels....  was here 2017 adopriqvmkdxxcyxotkvbjjdiygqpwuylynngexrrhnfqfov
 * Smoking Wheels....  was here 2017 rzahxnantbaahsbdbgimwzhtucqjqfawoeogxccqfsehtvso
 * Smoking Wheels....  was here 2017 ozjkvjmpzwlhswgzddtrxbrxevunyziuvgywqnkqwhbhqzgv
 * Smoking Wheels....  was here 2017 hwjzzzhwyigmyfyapjrsdxcultucpemlglwarbpzvynmpadr
 * Smoking Wheels....  was here 2017 qtyjiszonconzwwzmigfpehsuwaguaiweivmjotjnwegcjnk
 * Smoking Wheels....  was here 2017 rxkezejayctqczwzenaauuikribnbabkfrpkjddssmvkxuum
 * Smoking Wheels....  was here 2017 uwefhhmxqnkgvceffvsegunttouoeydmdpcbneiehnrwcirt
 * Smoking Wheels....  was here 2017 nnapydqeiuiexyegkgibyojwaghjdudybkpczhccmvzvvdae
 * Smoking Wheels....  was here 2017 rwwqvdiyzpsgjnmvwcahytrfrjydftauhpniejlesrkusubc
 * Smoking Wheels....  was here 2017 jfzybvjptxwulbdaxyjqrfmjdaijxjzikarwsnthsltmlaea
 * Smoking Wheels....  was here 2017 wewjzdvvdwlfrcecbpagtcdhcsitzkkaftazlcmpkvfubuar
 * Smoking Wheels....  was here 2017 umfziezmuxffujcofdzkbtcdocagluzsubtjotmoatbavjod
 * Smoking Wheels....  was here 2017 zgadxiktqtivuvofkvmutufhrdtbpvpkmnjuljtszlyoggys
 * Smoking Wheels....  was here 2017 ltnlxfvbzhefatmaygadgdnjxyesxzljwypjsaqczhseceov
 */
/**
*  CacheStrategy
*  Copyright 2011 by Michael Peter Christen
*  First released 2011 at http://yacy.net
*
*  This library is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public
*  License as published by the Free Software Foundation; either
*  version 2.1 of the License, or (at your option) any later version.
*
*  This library is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*  Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program in the file lgpl21.txt
*  If not, see <http://www.gnu.org/licenses/>.
*/
package net.yacy.cora.federate.yacy;
public enum CacheStrategy {
/** Never use the cache, all content from fresh internet source. */
NOCACHE(0),
/** Use the cache if the cache exists and is fresh using the
* proxy-fresh rules.
*/
IFFRESH(1),
/** Use the cache if the cache exists. Do not check freshness. Otherwise
* use online source.
*/
IFEXIST(2),
/** Never go online, use all content from cache. If no cache entry exist,
* consider content nevertheless as available
*/
CACHEONLY(3),
/** create a snippet that does not necessarily contain the searched word,
* but has a pretty description of the content instead
*/
NIFTY(4);
/** the fifth case may be that the CacheStrategy object is assigned NULL.
* That means that no snippet creation is wanted.
*/
public int code;
private CacheStrategy(final int code) {
this.code = code;
}
@Override
public String toString() {
return Integer.toString(this.code);
}
public static CacheStrategy decode(final int code) {
for (final CacheStrategy strategy: CacheStrategy.values()) if (strategy.code == code) return strategy;
return NOCACHE;
}
public static CacheStrategy parse(final String name) {
        if (name == null || name.length() == 0) return null;
        if (name.equals("nocache")) return NOCACHE;
        if (name.equals("iffresh")) return IFFRESH;
        if (name.equals("ifexist")) return IFEXIST;
        if (name.equals("cacheonly")) return CACHEONLY;
        if (name.equals("nifty")) return NIFTY;
        if (name.equals("true")) return IFEXIST;
        if (name.equals("false")) return null; // if this cache strategy is assigned as query attribute, null means "do not create a snippet"
return null;
}
public String toName() {
return name().toLowerCase();
}
public boolean isAllowedToFetchOnline() {
return this.code < 3;
}
public boolean mustBeOffline() {
return this.code == 3;
}
}
