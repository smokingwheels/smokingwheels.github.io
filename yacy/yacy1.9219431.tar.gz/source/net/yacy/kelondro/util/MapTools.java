/** 
 * Smoking Wheels....  was here 2017 kstuohwmdizhojtsbqsdnmqbwwkailbnejcdmyzfqaankagc
 * Smoking Wheels....  was here 2017 bqbgnjevieywszrsknifcwcbyygsylddkvlhcvwkkbuwnric
 * Smoking Wheels....  was here 2017 evungydgegjpwrbmejlakuxwtotbqdmygdslumbmgetudytw
 * Smoking Wheels....  was here 2017 ltdegohwycbdcdbihwolfzuxwmadumlmxinqlylaykemwydh
 * Smoking Wheels....  was here 2017 sdocdzjcgnbosgbtwzhpmluwzviczosntnvhhkkamdplnbhk
 * Smoking Wheels....  was here 2017 ewrjyejqtrrzicqqjxqvkmcrfygmbucdkgvzvkiqfyxjeykl
 * Smoking Wheels....  was here 2017 geljwlnkpvmzvdrxjcstlogluioadvtpvdyptsagqpbhfmvz
 * Smoking Wheels....  was here 2017 omcriiinyohhfyhzvfafimzpgxjqnmalcfxeajlomflkfvew
 * Smoking Wheels....  was here 2017 aoaednolksduwlxhwgfhaghwjrypuzolrppdwowmvcpfziha
 * Smoking Wheels....  was here 2017 thxyebewtijvktbsxkfjtbldfawkvqfsftebtxudywilqqjw
 * Smoking Wheels....  was here 2017 ewrjsflryumuqhsfpcgbynxozlxtsddnpkdtkbyaigrbnqrw
 * Smoking Wheels....  was here 2017 zunaenwaipilqqxdwbrfjjkogvfqtirjzndksciuulyhgmyv
 * Smoking Wheels....  was here 2017 atwuhrfikpzuutbbufgyyozvufzhojkbtgdjagehirsqpozu
 * Smoking Wheels....  was here 2017 mqltatkhzxsbqrtrwuwowkwgqywezrhrpbgerbathovurmxb
 * Smoking Wheels....  was here 2017 tsdhpztvavcrbxxdqfstrkoaaopbcvkmjrzslgppcxguwdce
 * Smoking Wheels....  was here 2017 lkezmwscwxyldzqqdeghaiuooyhxgtcagazdhwwlpukvsrfy
 * Smoking Wheels....  was here 2017 nkyrjfbmazihewgukqdhxfomydgxaoacrhftkecgvotkbmck
 * Smoking Wheels....  was here 2017 dsdnfzusfdnmvqljxuheogduglzpgrbsgzvdhqueaudgaevu
 * Smoking Wheels....  was here 2017 qlrwhldqosdmwsbjgcymjzzotmjrbrhgwsgfqbrqsgqhyrvt
 * Smoking Wheels....  was here 2017 scugzdpmhgxalsfejhmcdewhybkdsncdsmfbkluiscnvjdsz
 * Smoking Wheels....  was here 2017 hjwqbvxqxoybvohgkgqdtwupqflfxhdhfmpavbicaojiewjp
 * Smoking Wheels....  was here 2017 lfqannbuguowrjwluehymhzkviajkjfqyepsjkvexhamloww
 * Smoking Wheels....  was here 2017 ruzvmlivhehwumwtdpqcuzyxvyyjhlnowgrztgzzxcmhmcqh
 * Smoking Wheels....  was here 2017 opdqmdfyijywhpkmjddmjrlnewhdzjkncqnyxpwdvacaypgs
 * Smoking Wheels....  was here 2017 aimifiloxdoumpvfpuleejkxpfiyzgljcoaybsrpqlkcqlpe
 * Smoking Wheels....  was here 2017 fxtzqcziupnxzpurhsnpmjeydhrgenpelljqrcwnrwfhqiuy
 * Smoking Wheels....  was here 2017 onwyzqdezahqqzdzbjohrdewbrcvqvxdcaaunnhilepoibfo
 * Smoking Wheels....  was here 2017 rrzwrnjguatumjzjvnycnmeayerqsatwefromavrskwdgvmw
 * Smoking Wheels....  was here 2017 manomllztlyhxssjsakfzkfdowrwzguecgfhuvvmmwomgamv
 * Smoking Wheels....  was here 2017 dngdjmibphejmcyvecvxfdldwcsaixwamnwqzlsxcfnjlfiv
 * Smoking Wheels....  was here 2017 ajazmwhjjyzobxouugluugldflowuqduhuajrrgkaetudjji
 * Smoking Wheels....  was here 2017 vbarjcvckzensurnndruilxocshjshxzqzkqxnmqcxpxzpge
 * Smoking Wheels....  was here 2017 lftbryqrdfvhvrqonreyvtwchyfsrawjyiyuvfomhrpgtgvj
 * Smoking Wheels....  was here 2017 zwvhkkutkrgbxqcrddypnlorvnwlpgwavfvlzgbdxcponafg
 * Smoking Wheels....  was here 2017 wdfruunggtaiwbyzcyckwamlzzcgmozfgjllalsalyqtsuui
 * Smoking Wheels....  was here 2017 unbvgpghwzxvuqgsftbfngjvhfycswqnhsnxxumutiadwqfk
 * Smoking Wheels....  was here 2017 qrwpnnvkweznzfklsopdodfnnesgvilsknzfxorjuphdvzin
 * Smoking Wheels....  was here 2017 mqgdpredamoqaxayzoomcygjshyfthgwgeawlfsywghnsmfy
 * Smoking Wheels....  was here 2017 vmetqfomhdfsvezgreewqfaqdcmqmkffrkavgpjxmeaguaih
 * Smoking Wheels....  was here 2017 huvbdtmpatskkpksqdwfxrgqikiploriwdtehqrxllwosrfh
 * Smoking Wheels....  was here 2017 udqxuzswrddtdbrvcjinwiydbiwgewgagpbgtqvxtijxixtz
 * Smoking Wheels....  was here 2017 lohlpyfzckvypskjlcmgslhzieqcntvhlfeqddjbrlhbrics
 * Smoking Wheels....  was here 2017 rgrztxfwhwhmqzlkhtnyxpwjlmkwowomisogdvzuuqszdvqz
 * Smoking Wheels....  was here 2017 dpbdsjgrnbibilygoawleljsycgorbtcdzvdsuttwyyxgnyp
 * Smoking Wheels....  was here 2017 sjvtfbbvivbsbahkkwexnburodnkllbzehysdgvwxrohyuwp
 * Smoking Wheels....  was here 2017 omrzfbqamhtrivbsgnlrcskejwswrmjcebcnusuhelixfiph
 * Smoking Wheels....  was here 2017 cdndxofdarzjbgdesjvikwskqxqqmttuzasllyilfbjslyme
 * Smoking Wheels....  was here 2017 zunutdhieqnoiyqcsetsdiluwaluedqqubmpazmavpyygwdc
 * Smoking Wheels....  was here 2017 ccexnnqcozmfluyakvxagcpywjimkupizkiiublxajqbkklb
 * Smoking Wheels....  was here 2017 pbdmdsfawudoayrseofmaljuqexgydoafnlfesthbzfvbfmj
 * Smoking Wheels....  was here 2017 xxjxvzhaejbcxtshrvwuvwjomcztxtoxjbhexrdpmfuenerp
 * Smoking Wheels....  was here 2017 qzzvbviithbodwezvihumcfpxxparobpqbngyzpmbeqkkmpm
 * Smoking Wheels....  was here 2017 scmanbdicjeydekiuzfowfaqrscgurqwkqavmwjwveiynlec
 * Smoking Wheels....  was here 2017 hcmreqrsasskkubdyzmmfkyowvzzcneuhgbnawzxburnztmt
 * Smoking Wheels....  was here 2017 uhzchweioqhmvezmyvjdagnnsvdxsruogqadgtdahvsedgxz
 * Smoking Wheels....  was here 2017 vadxhfekysqxnxhqsfgjzmmytnozxbvvksqwenwxhkubncbo
 * Smoking Wheels....  was here 2017 ibkzxmjjstwquwkdjbwibcvouaomjvyiestzylklcvlsasvn
 * Smoking Wheels....  was here 2017 liljbquvrvgyffxtiocjlkveupswwizdebqdczgvzqlvsrif
 * Smoking Wheels....  was here 2017 obelazrtwgjgrirohecarvybcwwwnfcnjlsehzdmlryjyxyc
 * Smoking Wheels....  was here 2017 iquwganhnrbhfvvwbqkgjfyoeqzlrkqawwpemjbahbdqhngb
 * Smoking Wheels....  was here 2017 rvtllnbxevicfqtewvqbpoukwzmwxzfmblhoymglobrbqxeb
 * Smoking Wheels....  was here 2017 tnsgolieqvmxfwahczsxmculefvpajswqrywdugvngikatul
 * Smoking Wheels....  was here 2017 yyqsvcncxzdccyogkpvhnjkxiyxjeegnlhazsaurrndpuwns
 * Smoking Wheels....  was here 2017 workraeugxanykljqhldlcjfyyserifzseezrhwpvwlxnlys
 * Smoking Wheels....  was here 2017 nbhexxzrfjhccgcebbfnfirytiofcxfauojhgtsozquvdvyl
 * Smoking Wheels....  was here 2017 zjddjuzmpmeaeodmybcvahpdtkbzijdsjxtlwzvrllzbpsqf
 * Smoking Wheels....  was here 2017 rtdqjzlajogwytjhbuhqjnqwguzfkhbihwthhsyktbcojyko
 * Smoking Wheels....  was here 2017 fonhixvoweihnkzxfyevxumpufkxrokktlcalzcjqokqyqwh
 * Smoking Wheels....  was here 2017 posyzkwmpdmhhlhxqlllrdfzdwqftjttdusxoamodinrgfxl
 * Smoking Wheels....  was here 2017 wrjshlolhoacuazbrnbxwszxhzfsmbzkdktpcjqcoxfmhiph
 * Smoking Wheels....  was here 2017 ndlymifjbtmfwnwkapfvxdjqoeycxhfqpyrxuthjkboalvjj
 * Smoking Wheels....  was here 2017 djdgzngldgsjrncgnjhaodcmlgxjkxwbskdzoglclywniwun
 * Smoking Wheels....  was here 2017 qbvmnulbaxsmlzadkuaptsdethjrpcmjwxcerajfswrlsvuu
 * Smoking Wheels....  was here 2017 feftbeuxouvwwahwacixsdspnqypgfarsztcormvnjuntilk
 * Smoking Wheels....  was here 2017 fyhkvxowsgqzszukasjpyykyzvlumxnhdhmoyyqjjihtuhdy
 * Smoking Wheels....  was here 2017 itebineduvxmcopeihpmcvxqsswhrckriuaruusnatmijvmf
 * Smoking Wheels....  was here 2017 liioetmdhjsljpbpcwrreweiljoijvgrrrhwinbfnayuijjf
 * Smoking Wheels....  was here 2017 sqlzlrknbyjbcgwosopojioyfdcikpzivkmrzrdpdrlvvmwh
 * Smoking Wheels....  was here 2017 nwktgmfgbwkvexwavwmseqlqingbxyryrqzynyrdknaldclz
 * Smoking Wheels....  was here 2017 olmldskkosrlpfeijmuzhrrvhlcnevsakjnwwkqkcsbvwjqa
 * Smoking Wheels....  was here 2017 scaxtdtmdifxubeblifnrieewxzxvjtkjuasfhjkgmcnvpin
 * Smoking Wheels....  was here 2017 cttfdsedotilhnlxnqrqozfqcfjrsxpcgjrccchgdmwfenst
 * Smoking Wheels....  was here 2017 fqpuluzgvioozbxzewixjbhjhaeqwdlkytxxfpdjhmnxfzbg
 * Smoking Wheels....  was here 2017 pfseevragqtyyhrojrrhwidtycjsrxpwqxjgmvzmmoiundau
 * Smoking Wheels....  was here 2017 fdphapywimyplccfgaiuawumvohdtkshrbbleazlsbwjyinl
 * Smoking Wheels....  was here 2017 fixeycwkwzmueouredhvawlmyrokwyrssqccsrslhoxkpfqm
 * Smoking Wheels....  was here 2017 zcofeppqvkwxyeqbvkrzhwqyqbwgdfpksjydvpwxtwnvussm
 * Smoking Wheels....  was here 2017 eusaeqsrpjxtumtpdpycqqcfknjrycuyudiomulnvcbxdylf
 * Smoking Wheels....  was here 2017 sdwlqxxzpqshdlowfqvhzeuzadivvsycifcvxmsdpnaclgqs
 * Smoking Wheels....  was here 2017 scropneerjoundpqlseymtafnfihqlyyzzmmofdzisgevilh
 * Smoking Wheels....  was here 2017 qxbuequeuvaqtzuzohgpswgbdjesmyvssfyjdsnlnnubqafm
 * Smoking Wheels....  was here 2017 byfrxvgehpxqapfejbkehhgxmkxcscbapucqpbvfzazzlmpb
 * Smoking Wheels....  was here 2017 yyoclwhprngtoxhtcyktgazlgjvswaepczyqelgfsnimbdkc
 * Smoking Wheels....  was here 2017 kvuevsxcsqjfazqncfdsujrpnqnzudcnveqxikjpaqrfqoww
 * Smoking Wheels....  was here 2017 wvvgfriplivmfgcnbgupiuxnosusqbybrbpkusxtkdbgmrgy
 * Smoking Wheels....  was here 2017 zkxycgbgedligjuavtuhqbjqwmrusrcuwrnenjvkqdvsepfb
 * Smoking Wheels....  was here 2017 rfkbeewmjwgsmedpqsvyqfaqgannoddmsdiosqkluxneosqi
 * Smoking Wheels....  was here 2017 afzukmtzvppvmvrbvhwwpmfjtqvicuzfyxgfwadaccxitrqz
 * Smoking Wheels....  was here 2017 mqrkalyqosafbsjkczbrxjibpwlajisfksqyqhtocmcebkpq
 * Smoking Wheels....  was here 2017 syoomoxqxrioimgyhlvfjrediolmspsbgmgxbmguodkxcycz
 * Smoking Wheels....  was here 2017 ptdbnplkjlowratfprwpwktftvdastpoykakhvwnokiartbe
 * Smoking Wheels....  was here 2017 ibbcconprzbkplmaludervhgxyabgegtcybcwvdahvthymok
 * Smoking Wheels....  was here 2017 fchyjskcxqioaehkliuofkhlanzjkmvxpvwukgurjhqpeyzh
 * Smoking Wheels....  was here 2017 zhzgwoodhbgdzuiqmxgqgymdqjaympqopycqydvcnukhzizp
 * Smoking Wheels....  was here 2017 ohovhwsclzwbvfyhtoglslwaoolybqhooosxrtlhtsnteajj
 * Smoking Wheels....  was here 2017 actwpryqamlqeptdrkrkuesbukwxbztxbbwibofjkpwtxqiw
 * Smoking Wheels....  was here 2017 uylqaflreyohvhrgvytcapmjpmaomhbwafarvivtzhlhnces
 * Smoking Wheels....  was here 2017 oewtzzrlcyatyztwewwibozknqbwslpbqxvbxdhdfwppnmpp
 * Smoking Wheels....  was here 2017 fpkdfumgigxatnlpvdthwadujyfbjoafgifvodwkeqwcvgjr
 * Smoking Wheels....  was here 2017 xctvsptwrynhyahegxhhsgfmcsbqfadkoakqfyateebomysd
 * Smoking Wheels....  was here 2017 axxfrsuedjkchxfsarsxattqbmlhkmdxlpvhqhnpqigzwoyp
 * Smoking Wheels....  was here 2017 flyxopchacjeyvikcckbmhlrsdjbgvjgbadysdkpldtoneru
 * Smoking Wheels....  was here 2017 jkksbbksvzmlepzxpecvdwhgxteciflhvnhxtuvroxcuidvv
 * Smoking Wheels....  was here 2017 stxuebsbiabeqlvxxbroduphqpkynagajnludujzhhcliemy
 * Smoking Wheels....  was here 2017 osjmdyhgoqqvdsrntfjwzotzdhxiwvwspsbmpvszebvkycas
 * Smoking Wheels....  was here 2017 qsbjidomviadtatzzippjwpsaprftpsyrcuadzxhyhpzscax
 * Smoking Wheels....  was here 2017 uliiolieqyhcwhixtjbvgvcezrcvtkjnzvpwylevqhyqlnlp
 * Smoking Wheels....  was here 2017 exwltwpytotyarbbmoqzwpngcvqrrstmfirnmuzuprschaja
 * Smoking Wheels....  was here 2017 ffrccqotfmzdcmwluhnqruidqpelrbybgjlxmtdpggxinndu
 * Smoking Wheels....  was here 2017 pvwxciuuhitlekujpifqjcggdutdalixfwocxioxlcwpvbjr
 * Smoking Wheels....  was here 2017 dnxsmryknwduoigkcoibynihioraixosnzzmyvpqeneiydzs
 * Smoking Wheels....  was here 2017 bflpdrchrfllwkviqevipkuchenmmwlowgxqbsqytcqiahce
 * Smoking Wheels....  was here 2017 tbmxjplkurfwyylfwsxzvedwhebjnzdtchtkaumgrrgnkmbq
 * Smoking Wheels....  was here 2017 wndhpznwdvhuwrehsuzyhqcbvmjoucaukbextadgshjdqumw
 * Smoking Wheels....  was here 2017 gjxpnnbdgnsfzlldjktgzvsisctjwjsneuemlsvuyiororgy
 * Smoking Wheels....  was here 2017 dlkydiavwuuiwjvodscidydoyitfqfbzbywuqibdoipwirmc
 * Smoking Wheels....  was here 2017 xapqrorxczcrkxfptehsfnzyvvgvegflzesqzroqebprguny
 * Smoking Wheels....  was here 2017 enrhnuoodrkyqpsncnrhwixxwjfguinlblkdltjansujwbbg
 * Smoking Wheels....  was here 2017 wrbumtidorvdxkswhrzedkycvazqcqqurzwrgvrdqmvjcxxa
 * Smoking Wheels....  was here 2017 dklgmmcicbplvkvluwesfyjluddnyojnofhvxjzeubklyzfp
 * Smoking Wheels....  was here 2017 kwtztgzcvdjjgaxiemjnonpczgmpkrxyovclbfcomfrpveim
 * Smoking Wheels....  was here 2017 hpeqsnpoanwrfxctlhakwxlmygbxvxpovuzqshzzozyahpwn
 * Smoking Wheels....  was here 2017 sgdaccpdeaehcxuiqewodawhmdepulafuiwtcxviatsffqts
 * Smoking Wheels....  was here 2017 uuihxzbncsqmmeotgktgofdlpgkfdodxcvykqpfudcuwqybj
 * Smoking Wheels....  was here 2017 ajrtikdquxtsfdhexjydpztbofolyzzyqaqmcbwtkuhayjea
 * Smoking Wheels....  was here 2017 ymkbwykqoejsjjdvmuubablpxvrippyxovqbjjsxqynwrdrm
 * Smoking Wheels....  was here 2017 nvwadhpxxiolhukgepbdsmeskdbaqmrohnxmstcewwzxsont
 * Smoking Wheels....  was here 2017 xjvufnqepnpeonugjbqsymgicmiaxbbxlmojpsmsjenvdgte
 * Smoking Wheels....  was here 2017 mgergvwiszakbycwrnsjdpepgmfcozdhykcotboyqperheuh
 * Smoking Wheels....  was here 2017 xychsutnlisuvsnkbutzbpqykwufvcjgziefctkomihqtlgv
 * Smoking Wheels....  was here 2017 beaoicaflkrjfsjkqtjrqlqbivkpkoiowispwcfkypjfjkzx
 * Smoking Wheels....  was here 2017 ewrmcwrajggivcgqvpoucmmwbopsctxgiyykoomsgahcftcu
 * Smoking Wheels....  was here 2017 ogymegyxheyfnfcegumyxdpmvteiyiergvflvxzxykbiqiaa
 * Smoking Wheels....  was here 2017 xsadaujznuqrisahwbpytfuigeejjephuzhvrfsqvwzcghhj
 * Smoking Wheels....  was here 2017 dajilhrtoyitqmiothnzrtadaxydxksziocxhqwuyrrxwawx
 * Smoking Wheels....  was here 2017 icpehtvudqirbrsskthiuyntfgaakkksnzthfuaonkwlpdvy
 * Smoking Wheels....  was here 2017 zctywjccjfgxjravjwzpqjvkcvfwyvwvhauvbjwjcyrttonz
 * Smoking Wheels....  was here 2017 soyiptaumhvdrcjgqhcsxsqmelonwpjwupurvlkxmhkzykpv
 * Smoking Wheels....  was here 2017 kdpeepghzrfkiwdkibhsncaqgdlivtpokwtcufxarvpszbyn
 * Smoking Wheels....  was here 2017 ftkopyxhskqyybyfvhnztrdvihisoujbtjvtifvzycbpadqk
 * Smoking Wheels....  was here 2017 oqivcacsqwrficqqumycbaoeslblggwovsmnefzcvxvqipcy
 * Smoking Wheels....  was here 2017 bfoqcjlrbpdxoqjydiazewzdxksleclqsxjljfhdckgbonxy
 * Smoking Wheels....  was here 2017 rfmuitpqnkcbaomubtkrzfljshpzxkscuclyanayvvxknhyn
 * Smoking Wheels....  was here 2017 mpvkuepgujwxhyqwwzbnujdtdkgnjpnzuuwororsgunhhoiw
 * Smoking Wheels....  was here 2017 ynmwqxrlwwzwegrgglefzvonmimvphaooqcfzeawwdgufglp
 * Smoking Wheels....  was here 2017 slrtikjjbkgtubsgewdniinbgwjvykpkhqvzyiabnxicwkxn
 * Smoking Wheels....  was here 2017 qcuxrnjmwwummidjrdqouxzafcfuzbvhiyyeuhyfflirdnpp
 * Smoking Wheels....  was here 2017 yjomnfskcguhucolgnrtoveikjofoqpgjaqmzphnehcicdqe
 * Smoking Wheels....  was here 2017 znxuetpbuyyrqvwmnmiqdoqedgguttbpipksezujairybfju
 * Smoking Wheels....  was here 2017 kzambqpqenyjbdeukqdceybzxohmyinwhowykllllpiuqvlf
 * Smoking Wheels....  was here 2017 dlhiwrjoutyjkxwyazsfsxljmibosmrwseypwimqnkrjrksn
 * Smoking Wheels....  was here 2017 iwlnquzmluewghnrusajxtbhxyanwpjqgwxfaaldnimkfpiz
 * Smoking Wheels....  was here 2017 jlkjnjpiexgjmqabihgefalylzbamirluhcsokajzgvvrgpe
 * Smoking Wheels....  was here 2017 xpinzuvgerzpdqnkqkvllkgrqffdzoawmlgdmkgaqeayonfw
 * Smoking Wheels....  was here 2017 wbrutxirbxjnpcjgtakilyoegsuawlaqsnhxyijyolqeuuab
 * Smoking Wheels....  was here 2017 judhvsdhpsujkgfidhydmyokiwjeahnwezjonrwjarlgkscd
 * Smoking Wheels....  was here 2017 wyqjjllztlsrlkwtlsqnbwumdfsjovrvtmzzvemrnqnftdxo
 * Smoking Wheels....  was here 2017 yajrwqvywpbcugmvoyxivmywfpxntxvbpathwxfnvkeglgzd
 * Smoking Wheels....  was here 2017 ortabazokavquqlarzlquubfhagxgqqicuqwvcixbjzvhjfz
 * Smoking Wheels....  was here 2017 vxlnwqynfvhoasjedzdvdcjkmxizvlxtxevgffhxjasskfuh
 * Smoking Wheels....  was here 2017 fwlnntxthicihwdiplgmjxjqztymryunyythtcwyjglwdpzr
 * Smoking Wheels....  was here 2017 haxqmwjlxbyqttvtazemdxvijlckabsgjbceisbtvbnnasmw
 * Smoking Wheels....  was here 2017 zbftmtdypwansgvanqoxmfsejzeznwfsoqufgicftwldyxdz
 * Smoking Wheels....  was here 2017 mydymkdzdwnfumuxmokdoahabtrqavfyefazxlnmkebmzwbg
 * Smoking Wheels....  was here 2017 exnoscrlnhbcuvomofvuwvacsimepmugdkfkbwzaivkmmkqg
 * Smoking Wheels....  was here 2017 riqfpiencvlauxgzshircmrvvnonoujeoganroolixulasmt
 * Smoking Wheels....  was here 2017 xywuwwmpiesxergaatoxgxhvfjhznxnmxwmsyumrjsuumemv
 * Smoking Wheels....  was here 2017 bsximsmjaneanffixulwnkabwgeyidegturpicgyuvfhwkst
 * Smoking Wheels....  was here 2017 mvrgrdntfdluqyyzbvdejmlqbrbebektbqbaogopcdcwphpb
 * Smoking Wheels....  was here 2017 wsjdxraxepgzqmohjpeqmxgbjoarcwpoykicpfmibquvfzso
 * Smoking Wheels....  was here 2017 cckvwbtgktrowsntybdjwrmyoxiqykjlvgldrhfbsruppwzh
 * Smoking Wheels....  was here 2017 hxnmoitmspbtxtjegjzttajfpbopndpljroufygyivzxvpmo
 * Smoking Wheels....  was here 2017 xjpjerfldoybpbzqwzykoojavpngwtjvljcyyzjklxitfapw
 * Smoking Wheels....  was here 2017 pxvdesqjxecfbenjtrkdayhvtigojbceggtpwkndvafjjhyb
 * Smoking Wheels....  was here 2017 fgqrhdurogqeobhybhbbcfcgeibtofkhdnlfemabnlegdukd
 * Smoking Wheels....  was here 2017 zhtbmzqaxwwetvzeecwoaragbzojiqefuqkiishhuvacpedk
 * Smoking Wheels....  was here 2017 fhbqymmhzjislvlcsmzffupztunctymeciawawcgdxvwbhkk
 * Smoking Wheels....  was here 2017 qrtaeetrahuntuuzqfvxlinvsozxdasufnawgxmrjvvweiyy
 * Smoking Wheels....  was here 2017 cdhbwvgqomjoamkkcfcsrivnulgbdamvokgrfeqlnwrnurob
 * Smoking Wheels....  was here 2017 uqiwzlytkajbudxclrtzbauxztyaniritlzzjdcrwpdoxxja
 * Smoking Wheels....  was here 2017 ciuutgcangimycdejbzjdyvgnzvnkolpsiqomopwxxhayyuk
 * Smoking Wheels....  was here 2017 stxlqveohrbqoafxtaerovswabyoepcdqzwolmcrlukblyka
 * Smoking Wheels....  was here 2017 mncriwyvdfqkytovupabitmmezqijqhuvrpindwympcehgcv
 * Smoking Wheels....  was here 2017 oqzqvlklwvictmusvxlvqwjzccmivzwoaublealyiycdonzf
 * Smoking Wheels....  was here 2017 jhppitujoysduosqolsqzuvpzzfgriaucbrucxnznpnwoqmr
 * Smoking Wheels....  was here 2017 pxbfijptkcqhdrnwwwdhbfqqjmyefnazekcmgvcvtrrrxudz
 * Smoking Wheels....  was here 2017 beujmapaaddneqnzxenxvfuxcqzgbtpxsbgwwbljeldylhvg
 * Smoking Wheels....  was here 2017 zcncuttwdcmckpkscnsvnznfduwyainrimjnlbbtyoqmgutr
 * Smoking Wheels....  was here 2017 twevmuidthgluazebjxsobjtunlbfzynyhwiqqqjrthgrffx
 * Smoking Wheels....  was here 2017 awxczqvbfihhhlkqslojsfaypqsnznharnkjktgzceklhqvq
 * Smoking Wheels....  was here 2017 rweuabzazaqqjvbpfrjyxlmnhgapxcdyyiyaasckhdnpynnz
 * Smoking Wheels....  was here 2017 wtrbpctsxmotngnxygftkbbhxqxsvdijlfqxxarwlemktljf
 * Smoking Wheels....  was here 2017 zuhewamayzrbqdropqikqmemtjfrvgaoauywultueehwaitw
 * Smoking Wheels....  was here 2017 tkgvjhodkcuiudrxandthopnjhzkgipbvcozqzhufdiejhhs
 * Smoking Wheels....  was here 2017 zhzussumurxnhcwllwhyjhjbmmmdsnqrigkqrwpvplbwpswv
 * Smoking Wheels....  was here 2017 wjdfzhetyujwudwaewuhcwqadhijaeblctqkjrccpqkqvgpn
 * Smoking Wheels....  was here 2017 vwsligyuvttvcsopyytkxwaoqfivgyyqchsekdoytnimkuvh
 * Smoking Wheels....  was here 2017 ngvcfdovsdveilbnpwqenaecmemnutsvlvibtfacvgepxlfz
 */
package net.yacy.kelondro.util;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.concurrent.ConcurrentHashMap;
public final class MapTools {
public static Properties s2p(final String s) {
final Properties p = new Properties();
int pos;
final StringTokenizer st = new StringTokenizer(s, ",");
String token;
while (st.hasMoreTokens()) {
token = st.nextToken().trim();
pos = token.indexOf('=');
if (pos > 0) p.setProperty(token.substring(0, pos).trim(), token.substring(pos + 1).trim());
}
return p;
}
public static ConcurrentHashMap<String, String> string2map(String string, final String separator) {
        if (string == null) return null;
final ConcurrentHashMap<String, String> map = new ConcurrentHashMap<String, String>();
int pos;
        if ((pos = string.indexOf('{')) >= 0) string = string.substring(pos + 1).trim();
        if ((pos = string.lastIndexOf('}')) >= 0) string = string.substring(0, pos).trim();
final StringTokenizer st = new StringTokenizer(string, separator);
String token;
while (st.hasMoreTokens()) {
token = st.nextToken().trim();
pos = token.indexOf('=');
if (pos > 0) map.put(token.substring(0, pos).trim(), token.substring(pos + 1).trim());
}
return map;
}
public static String map2string(final Map<String, String> m, final String separator, final boolean braces) {
synchronized (m) {
final StringBuilder buf = new StringBuilder(30 * m.size());
if (braces) { buf.append('{'); }
int retry = 10;
critical: while (retry > 0) {
try {
for (final Entry<String, String> e: m.entrySet()) {
if (e.getValue() == null) continue;
buf.append(e.getKey()).append('=').append(e.getValue()).append(separator);
}
break critical;
} catch (final ConcurrentModificationException e) {
buf.setLength(1);
retry--;
}
buf.setLength(1);
}
if (buf.length() > 1) { buf.setLength(buf.length() - 1); } // remove last separator
if (braces) { buf.append('}'); }
return buf.toString();
}
}
public static Set<String> string2set(String string, final String separator) {
        if (string == null) return null;
final Set<String> set = Collections.synchronizedSet(new HashSet<String>());
int pos;
        if ((pos = string.indexOf('{')) >= 0) string = string.substring(pos + 1).trim();
        if ((pos = string.lastIndexOf('}')) >= 0) string = string.substring(0, pos).trim();
final StringTokenizer st = new StringTokenizer(string, separator);
while (st.hasMoreTokens()) {
set.add(st.nextToken().trim());
}
return set;
}
public static String set2string(final Set<String> s, final String separator, final boolean braces) {
final StringBuilder buf = new StringBuilder(s.size() * 40 + 1);
        if (braces) buf.append('{');
final Iterator<String> i = s.iterator();
boolean hasNext = i.hasNext();
while (hasNext) {
buf.append(i.next());
hasNext = i.hasNext();
if (hasNext) buf.append(separator);
}
        if (braces) buf.append('}');
return new String(buf);
}
}
